# Error Codes - Heady™ Error Code Catalog

**Last Updated:** March 9, 2026  
**Format:** HEADY-{SERVICE}-{NUMBER}  
**Coverage:** All services and error domains

---

## MCP PROTOCOL ERRORS (HEADY-MCP-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-MCP-001 | 400 | Invalid JSON-RPC request | Verify request format: `{"jsonrpc": "2.0", "method": "...", "params": {...}, "id": "..."}` |
| HEADY-MCP-002 | 400 | Missing required parameter | Check API documentation for required parameters per tool |
| HEADY-MCP-003 | 404 | Tool not found | Verify tool name matches MCP registry; list tools with `heady tools list` |
| HEADY-MCP-004 | 400 | Invalid parameter type | Ensure parameter types match schema (string, number, boolean, object, array) |
| HEADY-MCP-005 | 413 | Request payload too large | Limit request size to 10MB; split large operations |
| HEADY-MCP-006 | 408 | Request timeout | Tool execution exceeded 30s default; increase timeout or optimize operation |
| HEADY-MCP-007 | 503 | Tool execution failed | Check service logs; retry with exponential backoff |
| HEADY-MCP-008 | 401 | Authentication required | Provide valid authentication token in Authorization header |
| HEADY-MCP-009 | 403 | Insufficient permissions | Request tool permission in agent configuration |
| HEADY-MCP-010 | 500 | Internal server error | Report to support with request ID from response headers |

---

## AUTHENTICATION ERRORS (HEADY-AUTH-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-AUTH-001 | 401 | Invalid token | Re-authenticate with valid credentials via oauth or API key |
| HEADY-AUTH-002 | 401 | Token expired | Call auth:refresh tool to obtain new token |
| HEADY-AUTH-003 | 403 | Token revoked | Token was explicitly revoked; re-authenticate |
| HEADY-AUTH-004 | 400 | Invalid credentials | Verify username/password or API key correctness |
| HEADY-AUTH-005 | 429 | Too many failed login attempts | Account locked for 15 minutes; try again later |
| HEADY-AUTH-006 | 403 | MFA required | Provide MFA code via second authentication step |
| HEADY-AUTH-007 | 401 | Session expired | Reauthenticate to establish new session |
| HEADY-AUTH-008 | 403 | Insufficient scope | Request additional OAuth scope permissions |
| HEADY-AUTH-009 | 400 | CSRF token mismatch | Ensure CSRF token matches session; reload page and retry |
| HEADY-AUTH-010 | 401 | API key invalid | Verify API key from dashboard; regenerate if compromised |

---

## PIPELINE ERRORS (HEADY-PIPE-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-PIPE-001 | 400 | Invalid pipeline configuration | Verify all stages defined; check stage names and parameters |
| HEADY-PIPE-002 | 400 | Missing required stage | Pipeline requires all mandatory stages; add missing stage |
| HEADY-PIPE-003 | 422 | Stage validation failed | Stage input does not match schema; check types and required fields |
| HEADY-PIPE-004 | 500 | Stage execution error | Check stage implementation logs; verify input data |
| HEADY-PIPE-005 | 408 | Stage timeout | Increase stage timeout or optimize stage logic |
| HEADY-PIPE-006 | 400 | Invalid data transition | Output of stage N incompatible with input of stage N+1; adjust adapters |
| HEADY-PIPE-007 | 500 | Pipeline engine failure | Check system logs; restart service if necessary |
| HEADY-PIPE-008 | 400 | Circular dependency detected | Reorganize stages; ensure linear execution order |
| HEADY-PIPE-009 | 500 | Resource exhaustion | Too many concurrent pipelines; limit parallelism via φ-scaling |
| HEADY-PIPE-010 | 400 | Pipeline cancelled | Operation was cancelled; retry if needed or adjust timeout |

---

## CONDUCTOR / ORCHESTRATION ERRORS (HEADY-COND-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-COND-001 | 400 | Invalid workflow DAG | Verify all tasks and dependencies are valid; no circular references |
| HEADY-COND-002 | 400 | Task not found | Check task name matches registry; use orchestrate:list-tasks |
| HEADY-COND-003 | 422 | Condition evaluation failed | Verify condition syntax; check referenced fields exist |
| HEADY-COND-004 | 500 | Task execution failed | Check task logs; resolve dependency issues |
| HEADY-COND-005 | 408 | Task timeout | Increase task timeout or reduce task scope |
| HEADY-COND-006 | 500 | Orchestrator engine failure | Check system health; may indicate memory or resource issues |
| HEADY-COND-007 | 400 | Missing task dependency | All upstream tasks must complete before dependent task runs |
| HEADY-COND-008 | 429 | Too many concurrent tasks | φ-scaled concurrency limit reached; reduce parallelism |
| HEADY-COND-009 | 500 | State machine error | Workflow reached invalid state; check logs and restart |
| HEADY-COND-010 | 400 | Workflow cancelled | Workflow was cancelled; manual intervention may be required |

---

## MEMORY / VECTOR ERRORS (HEADY-MEM-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-MEM-001 | 400 | Invalid vector dimension | Vectors must match embedding dimension (default: 1536 for OpenAI) |
| HEADY-MEM-002 | 404 | Memory not found | Verify memory ID or search query; check memory exists |
| HEADY-MEM-003 | 500 | Vector store connection failed | Ensure Pinecone/Weaviate service is running and accessible |
| HEADY-MEM-004 | 413 | Vector too large | Embedding size exceeds limit; try smaller text chunks |
| HEADY-MEM-005 | 429 | Rate limit exceeded | Vector store has rate limits; implement exponential backoff |
| HEADY-MEM-006 | 400 | Invalid search query | Search query should be a text string; try with less specific terms |
| HEADY-MEM-007 | 500 | Embedding generation failed | Check OpenAI API availability; verify API key is valid |
| HEADY-MEM-008 | 422 | Metadata schema mismatch | Memory metadata does not match expected schema |
| HEADY-MEM-009 | 500 | Memory index corrupted | Run `memory:repair` command to rebuild index |
| HEADY-MEM-010 | 400 | Insufficient context | Not enough similar memories found; try different search terms |

---

## DRUPAL CMS ERRORS (HEADY-CMS-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-CMS-001 | 401 | Drupal authentication failed | Verify Drupal credentials and API token are correct |
| HEADY-CMS-002 | 404 | Content not found | Check content ID or path; may have been deleted |
| HEADY-CMS-003 | 422 | Invalid content structure | Drupal content type validation failed; check required fields |
| HEADY-CMS-004 | 409 | Content conflict | Content was modified by another user; reload and retry |
| HEADY-CMS-005 | 500 | Drupal API error | Check Drupal logs; may indicate database or configuration issue |
| HEADY-CMS-006 | 403 | Permission denied | User lacks permissions for this content operation |
| HEADY-CMS-007 | 400 | Invalid field value | Content field validation failed; check against schema |
| HEADY-CMS-008 | 500 | Content synchronization failed | Replication with Drupal failed; check network connectivity |
| HEADY-CMS-009 | 400 | Workflow transition invalid | Content does not support requested state transition |
| HEADY-CMS-010 | 500 | Media processing failed | Image/video optimization failed; check file type and size |

---

## SECURITY ERRORS (HEADY-SEC-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-SEC-001 | 403 | CORS policy violation | Request origin not in whitelist; add to `CORS_WHITELIST` env var |
| HEADY-SEC-002 | 403 | CSP policy violation | Inline script or external resource blocked by CSP; update policy |
| HEADY-SEC-003 | 403 | Rate limit exceeded | Too many requests from IP/user; wait before retrying |
| HEADY-SEC-004 | 403 | DDoS protection triggered | Request pattern detected as suspicious; wait or contact support |
| HEADY-SEC-005 | 403 | SQL injection detected | Request contains suspicious SQL patterns; review query |
| HEADY-SEC-006 | 403 | XSS attack detected | Request contains script injection; sanitize input |
| HEADY-SEC-007 | 403 | Invalid security header | Missing or invalid security headers; ensure HTTPS in production |
| HEADY-SEC-008 | 403 | Suspicious activity detected | Account flagged for suspicious behavior; verify identity |
| HEADY-SEC-009 | 403 | SSL/TLS certificate invalid | Server certificate not trusted; check certificate expiry |
| HEADY-SEC-010 | 403 | Geographic restriction | Request from blocked region; contact support if legitimate |

---

## RATE LIMITING ERRORS (HEADY-RATE-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-RATE-001 | 429 | API rate limit exceeded | Implement exponential backoff; see Retry-After header |
| HEADY-RATE-002 | 429 | Per-user quota exhausted | Premium tier required for higher limits |
| HEADY-RATE-003 | 429 | Per-endpoint limit exceeded | This endpoint has special limits; reduce request frequency |
| HEADY-RATE-004 | 429 | Concurrent request limit exceeded | Too many parallel requests; serialize or parallelize less |
| HEADY-RATE-005 | 429 | Burst limit exceeded | Requests too concentrated; spread over longer time period |

---

## VALIDATION ERRORS (HEADY-VAL-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-VAL-001 | 400 | Required field missing | Check all required fields are present in request |
| HEADY-VAL-002 | 400 | Field type mismatch | Field value does not match expected type (string, number, etc.) |
| HEADY-VAL-003 | 400 | String too long | Field exceeds maximum length; use shorter value |
| HEADY-VAL-004 | 400 | String too short | Field below minimum length; provide longer value |
| HEADY-VAL-005 | 400 | Invalid email format | Email does not match standard format; verify email address |
| HEADY-VAL-006 | 400 | Invalid URL format | URL does not start with http:// or https://; fix scheme |
| HEADY-VAL-007 | 400 | Invalid phone format | Phone does not match expected format; use international format |
| HEADY-VAL-008 | 400 | Invalid regex pattern | Regular expression is malformed; check pattern syntax |
| HEADY-VAL-009 | 400 | Invalid enum value | Value not in allowed enum list; check valid values |
| HEADY-VAL-010 | 400 | Constraint violation | Value violates database constraint; ensure uniqueness |

---

## SYSTEM ERRORS (HEADY-SYS-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-SYS-001 | 500 | Database connection failed | Check database is running and accessible |
| HEADY-SYS-002 | 500 | Redis connection failed | Check Redis service is running |
| HEADY-SYS-003 | 503 | Service unavailable | Service is down for maintenance; check status page |
| HEADY-SYS-004 | 500 | Out of memory | System memory exhausted; restart service or upgrade |
| HEADY-SYS-005 | 500 | Disk space full | Disk storage exhausted; delete old data or add capacity |
| HEADY-SYS-006 | 500 | Configuration error | Configuration file is invalid; check syntax |
| HEADY-SYS-007 | 500 | File not found | Critical file missing; restore from backup |
| HEADY-SYS-008 | 500 | Permission denied | File permission error; check ownership and mode |
| HEADY-SYS-009 | 500 | Network error | Network connectivity issue; check network status |
| HEADY-SYS-010 | 500 | Timeout | Operation exceeded timeout; may indicate slow operation or hanging |

---

## CIRCUIT BREAKER ERRORS (HEADY-CB-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-CB-001 | 503 | Circuit breaker open | Dependent service is down; wait for recovery |
| HEADY-CB-002 | 503 | Circuit breaker half-open | Service testing recovery; may fail; retry later |
| HEADY-CB-003 | 500 | Circuit breaker error | Breaker state machine error; check logs |

---

## WORKER POOL ERRORS (HEADY-WORK-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-WORK-001 | 503 | Worker pool exhausted | All workers busy; reduce task submission rate |
| HEADY-WORK-002 | 500 | Worker crash | Worker process crashed; automatically restarted |
| HEADY-WORK-003 | 408 | Task queue timeout | Task was queued too long; reduce queue depth |

---

## DEPLOYMENT ERRORS (HEADY-DEPLOY-*)

| Code | HTTP | Description | Suggested Fix |
|---|---|---|---|
| HEADY-DEPLOY-001 | N/A | Deployment failed | Check deployment logs; ensure health checks pass |
| HEADY-DEPLOY-002 | N/A | Health check failed | Service failed readiness probe; check service logs |
| HEADY-DEPLOY-003 | N/A | Rollback triggered | Deployment rolled back; check for errors |
| HEADY-DEPLOY-004 | N/A | Insufficient resources | Cluster lacks resources; scale up or free resources |
| HEADY-DEPLOY-005 | N/A | Configuration mismatch | Environment configuration does not match expected schema |

---

## ERROR HANDLING BEST PRACTICES

### Structured Error Response
All errors follow this format:
```json
{
  "error": {
    "code": "HEADY-SERVICE-NNN",
    "message": "Human-readable error description",
    "details": {
      "field": "specific_field_name",
      "constraint": "constraint_violated",
      "expected": "expected_value",
      "actual": "actual_value"
    },
    "retryable": true,
    "retryAfter": 5000
  },
  "requestId": "req_abc123xyz"
}
```

### Error Code Format
- **Service Code:** 3-5 uppercase letters (MCP, AUTH, PIPE, COND, MEM, CMS, SEC)
- **Number:** 001-010 per service domain
- **Full Format:** `HEADY-{SERVICE}-{NUMBER}`

### Retry Logic
- **Retryable Errors:** 408, 429, 500, 502, 503
- **Non-Retryable:** 400, 401, 403, 404, 422
- **Strategy:** Exponential backoff with jitter
- **Max Retries:** 3 by default
- **Backoff Formula:** delay = min(300000, baseDelay * 2^attempt + jitter)

### Logging Guidelines
When logging errors, include:
```javascript
logger.error('error_code_identifier', {
  errorCode: 'HEADY-SERVICE-001',
  message: 'Human-readable description',
  userId: user?.id,
  requestId: req.id,
  duration: responseTime,
  details: errorDetails
});
```

### Monitoring & Alerts
- **Critical:** HEADY-*-001 through -003 of critical services
- **High:** HEADY-SEC-*, HEADY-AUTH-*
- **Medium:** HEADY-PIPE-*, HEADY-COND-*
- **Low:** HEADY-VAL-*, non-critical HEADY-SYS-*

---

## Error Code Usage by Layer

### API Gateway Layer
- HEADY-MCP-001 through -010 (request parsing)
- HEADY-AUTH-001 through -010 (authentication)
- HEADY-SEC-001 through -010 (security)
- HEADY-RATE-001 through -005 (rate limiting)

### Service Layer
- HEADY-PIPE-001 through -010 (pipeline)
- HEADY-COND-001 through -010 (orchestration)
- HEADY-CMS-001 through -010 (Drupal)
- HEADY-SYS-001 through -010 (infrastructure)

### Infrastructure Layer
- HEADY-CB-001 through -003 (circuit breaker)
- HEADY-WORK-001 through -003 (worker pool)
- HEADY-DEPLOY-001 through -005 (deployment)

### Data Layer
- HEADY-MEM-001 through -010 (vector memory)
- HEADY-VAL-001 through -010 (validation)

---

## Support & Escalation

### How to Get Help
1. **Look up error code** in this document
2. **Follow suggested fix** for your error
3. **Check logs** for additional context: `npm run logs -- --service=SERVICE_NAME`
4. **Search issues:** GitHub Issues filtered by error code
5. **Contact support:** Include error code, request ID, and timestamp

### Error Code Not Found?
If you encounter an unlisted error code:
1. Note the code pattern (HEADY-SERVICE-NNN)
2. Open GitHub issue with details
3. Include logs, request ID, and reproduction steps
4. Will be added to catalog in next release

---

**Last Updated:** March 9, 2026  
**Coverage:** 70+ error codes across 11 service domains  
**Next Update:** Upon new error patterns discovered
