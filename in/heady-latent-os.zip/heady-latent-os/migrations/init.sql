-------------------------------------------------------------------------------
-- Heady Latent OS — pgvector initialization
-- Sacred Geometry v4.0 — phi-scaled HNSW parameters
-- © 2026 HeadySystems Inc.
-------------------------------------------------------------------------------

-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Enable full-text search
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-------------------------------------------------------------------------------
-- Vector Memory Table (384D embeddings)
-------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vector_memory (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    namespace     TEXT NOT NULL DEFAULT 'default',
    content       TEXT NOT NULL,
    embedding     vector(384) NOT NULL,
    metadata      JSONB NOT NULL DEFAULT '{}',
    coherence     REAL NOT NULL DEFAULT 1.0,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at    TIMESTAMPTZ,
    -- Full-text search column
    tsv           TSVECTOR GENERATED ALWAYS AS (to_tsvector('english', content)) STORED
);

-- HNSW index: m=21 (fib(8)), ef_construction=89 (fib(11)), cosine distance
CREATE INDEX IF NOT EXISTS idx_vector_memory_embedding
    ON vector_memory
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 21, ef_construction = 89);

-- GIN index for full-text search (BM25 component of hybrid search)
CREATE INDEX IF NOT EXISTS idx_vector_memory_tsv
    ON vector_memory USING gin (tsv);

-- B-tree index for namespace lookups
CREATE INDEX IF NOT EXISTS idx_vector_memory_namespace
    ON vector_memory (namespace);

-- GIN index for JSONB metadata queries
CREATE INDEX IF NOT EXISTS idx_vector_memory_metadata
    ON vector_memory USING gin (metadata);

-- Partial index for non-expired entries
CREATE INDEX IF NOT EXISTS idx_vector_memory_active
    ON vector_memory (created_at DESC)
    WHERE expires_at IS NULL OR expires_at > NOW();

-------------------------------------------------------------------------------
-- Node State Table (tracks 384D state of each liquid node)
-------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS node_state (
    node_id       TEXT PRIMARY KEY,
    node_type     TEXT NOT NULL,
    ring          TEXT NOT NULL CHECK (ring IN ('center', 'inner', 'middle', 'outer', 'governance', 'memory')),
    embedding     vector(384),
    status        TEXT NOT NULL DEFAULT 'initializing' CHECK (status IN ('initializing', 'active', 'degraded', 'healing', 'retired')),
    coherence     REAL NOT NULL DEFAULT 1.0,
    pool          TEXT NOT NULL DEFAULT 'warm' CHECK (pool IN ('hot', 'warm', 'cold', 'reserve', 'governance')),
    metadata      JSONB NOT NULL DEFAULT '{}',
    last_heartbeat TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_node_state_ring ON node_state (ring);
CREATE INDEX IF NOT EXISTS idx_node_state_status ON node_state (status);

-------------------------------------------------------------------------------
-- Bee Registry Table (tracks HeadyBee swarm members)
-------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bee_registry (
    bee_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bee_type      TEXT NOT NULL,
    status        TEXT NOT NULL DEFAULT 'idle' CHECK (status IN ('idle', 'spawning', 'executing', 'reporting', 'retiring', 'failed')),
    assigned_task TEXT,
    coherence     REAL NOT NULL DEFAULT 1.0,
    metrics       JSONB NOT NULL DEFAULT '{}',
    spawned_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at  TIMESTAMPTZ,
    retired_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_bee_registry_type ON bee_registry (bee_type);
CREATE INDEX IF NOT EXISTS idx_bee_registry_status ON bee_registry (status);

-------------------------------------------------------------------------------
-- Pipeline Runs Table (tracks HCFullPipeline executions)
-------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pipeline_runs (
    run_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    pipeline_type TEXT NOT NULL DEFAULT 'HCFullPipeline',
    status        TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'running', 'completed', 'failed', 'cancelled')),
    stages        JSONB NOT NULL DEFAULT '[]',
    input         JSONB NOT NULL DEFAULT '{}',
    output        JSONB,
    error         TEXT,
    duration_ms   INTEGER,
    started_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_pipeline_runs_status ON pipeline_runs (status);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_started ON pipeline_runs (started_at DESC);

-------------------------------------------------------------------------------
-- Audit Log Table (SOC 2 ready — cryptographic chain)
-------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    id            BIGSERIAL PRIMARY KEY,
    timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    tool          TEXT NOT NULL,
    user_id       TEXT NOT NULL,
    input_hash    TEXT NOT NULL,
    output_hash   TEXT NOT NULL,
    duration_ms   INTEGER NOT NULL,
    prev_hash     TEXT,
    record_hash   TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON audit_log (timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log (user_id);

-------------------------------------------------------------------------------
-- Pattern Library (learned patterns from HeadyPatterns)
-------------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS pattern_library (
    pattern_id    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category      TEXT NOT NULL,
    name          TEXT NOT NULL,
    description   TEXT NOT NULL,
    embedding     vector(384),
    frequency     INTEGER NOT NULL DEFAULT 1,
    success_rate  REAL NOT NULL DEFAULT 1.0,
    metadata      JSONB NOT NULL DEFAULT '{}',
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pattern_library_category ON pattern_library (category);

-------------------------------------------------------------------------------
-- Auto-update updated_at trigger
-------------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_vector_memory_updated
    BEFORE UPDATE ON vector_memory
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_node_state_updated
    BEFORE UPDATE ON node_state
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_pattern_library_updated
    BEFORE UPDATE ON pattern_library
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-------------------------------------------------------------------------------
-- Set HNSW search parameters (fib(8)=21 for ef_search on < 100K rows)
-------------------------------------------------------------------------------
SET hnsw.ef_search = 21;
