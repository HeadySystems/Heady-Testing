/**
 * Heady Latent OS — Express Server
 * Production-ready HTTP API with health endpoints, CORS whitelist,
 * structured logging, and graceful shutdown.
 *
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

'use strict';

const express = require('express');
const { createLogger } = require('./shared/liquid-nodes');
const { PHI, PSI, fib, CSL_THRESHOLDS } = require('./shared/phi-constants');
const HeadyOS = require('./src/core/heady-os');

const logger = createLogger('HeadyServer');
const PORT = parseInt(process.env.PORT || '3000', 10);
const NODE_ENV = process.env.NODE_ENV || 'development';

// ═══════════════════════════════════════════════════════════════
// CORS WHITELIST — No wildcards in production
// ═══════════════════════════════════════════════════════════════

const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || [
  'https://headyme.com',
  'https://headysystems.com',
  'https://headyconnection.org',
  'https://headybuddy.org',
  'https://headymcp.com',
  'https://headyio.com',
  'https://headybot.com',
  'https://headyapi.com',
  'https://headyai.com',
  'https://headyos.com',
].join(','))
  .split(',')
  .filter(Boolean)
  .map(o => o.trim());

function corsMiddleware(req, res, next) {
  const origin = req.headers.origin || '';
  if (ALLOWED_ORIGINS.includes(origin) || NODE_ENV === 'development') {
    res.setHeader('Access-Control-Allow-Origin', origin);
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization,X-Correlation-ID');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Max-Age', '86400');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }
  next();
}

// ═══════════════════════════════════════════════════════════════
// SECURITY HEADERS
// ═══════════════════════════════════════════════════════════════

function securityHeaders(req, res, next) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '0');
  res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
}

// ═══════════════════════════════════════════════════════════════
// RATE LIMITER — Fibonacci-based sliding window
// ═══════════════════════════════════════════════════════════════

const rateLimitStore = new Map();
const RATE_LIMIT_WINDOW_MS = fib(10) * 1000; // 55 seconds
const RATE_LIMIT_MAX = fib(11); // 89 requests per window

function rateLimiter(req, res, next) {
  const key = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const record = rateLimitStore.get(key) || { count: 0, windowStart: now };

  if (now - record.windowStart > RATE_LIMIT_WINDOW_MS) {
    record.count = 0;
    record.windowStart = now;
  }

  record.count++;
  rateLimitStore.set(key, record);

  res.setHeader('X-RateLimit-Limit', RATE_LIMIT_MAX);
  res.setHeader('X-RateLimit-Remaining', Math.max(0, RATE_LIMIT_MAX - record.count));
  res.setHeader('X-RateLimit-Reset', Math.ceil((record.windowStart + RATE_LIMIT_WINDOW_MS) / 1000));

  if (record.count > RATE_LIMIT_MAX) {
    return res.status(429).json({
      error: 'Too Many Requests',
      retryAfter: Math.ceil((record.windowStart + RATE_LIMIT_WINDOW_MS - now) / 1000),
    });
  }

  next();
}

// ═══════════════════════════════════════════════════════════════
// REQUEST LOGGING
// ═══════════════════════════════════════════════════════════════

function requestLogger(req, res, next) {
  const start = Date.now();
  const correlationId = req.headers['x-correlation-id'] || `req-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
  req.correlationId = correlationId;
  res.setHeader('X-Correlation-ID', correlationId);

  res.on('finish', () => {
    logger.info({
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      durationMs: Date.now() - start,
      correlationId,
      ip: req.ip,
    }, 'Request completed');
  });

  next();
}

// ═══════════════════════════════════════════════════════════════
// APP SETUP
// ═══════════════════════════════════════════════════════════════

const app = express();

// Middleware stack
app.use(securityHeaders);
app.use(corsMiddleware);
app.use(rateLimiter);
app.use(requestLogger);
app.use(express.json({ limit: '1mb' }));

// HeadyOS instance
const heady = new HeadyOS();

// ═══════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════

/**
 * Health check — Kubernetes/Cloud Run compatible
 */
app.get('/health', (req, res) => {
  const health = heady.health();
  const status = health.status === 'healthy' ? 200 : 503;
  res.status(status).json(health);
});

app.get('/healthz', (req, res) => {
  res.status(heady.initialized ? 200 : 503).json({
    status: heady.initialized ? 'ok' : 'initializing',
    timestamp: new Date().toISOString(),
  });
});

/**
 * Ready check
 */
app.get('/ready', (req, res) => {
  res.status(heady.initialized ? 200 : 503).json({
    ready: heady.initialized,
    timestamp: new Date().toISOString(),
  });
});

/**
 * System topology — shows Sacred Geometry node layout
 */
app.get('/api/v1/topology', (req, res) => {
  const health = heady.health();
  res.json({
    topology: health.topology,
    coherence: health.coherence,
    timestamp: health.timestamp,
  });
});

/**
 * Process a task through HCFullPipeline
 */
app.post('/api/v1/process', async (req, res) => {
  try {
    const task = req.body;
    if (!task || !task.type) {
      return res.status(400).json({ error: 'Task must include a "type" field' });
    }
    task.id = task.id || req.correlationId;
    const result = await heady.process(task);
    res.json(result);
  } catch (err) {
    logger.error({ error: err.message, correlationId: req.correlationId }, 'Process failed');
    res.status(500).json({ error: err.message, correlationId: req.correlationId });
  }
});

/**
 * Chat with HeadyBuddy companion
 */
app.post('/api/v1/chat', async (req, res) => {
  try {
    const { message, sessionId } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }
    const result = await heady.chat(message, sessionId);
    res.json(result);
  } catch (err) {
    logger.error({ error: err.message, correlationId: req.correlationId }, 'Chat failed');
    res.status(500).json({ error: err.message, correlationId: req.correlationId });
  }
});

/**
 * Route a task to specific node
 */
app.post('/api/v1/route', async (req, res) => {
  try {
    const task = req.body;
    task.id = task.id || req.correlationId;
    const result = await heady.route(task);
    res.json(result);
  } catch (err) {
    logger.error({ error: err.message }, 'Route failed');
    res.status(500).json({ error: err.message });
  }
});

/**
 * Bee Factory status
 */
app.get('/api/v1/bees', (req, res) => {
  res.json(heady.beeFactory?.health() || { error: 'BeeFactory not initialized' });
});

/**
 * Bee Factory templates
 */
app.get('/api/v1/bees/templates', (req, res) => {
  res.json(heady.beeFactory?.getTemplates() || {});
});

/**
 * Spawn and execute on a bee
 */
app.post('/api/v1/bees/execute', async (req, res) => {
  try {
    const { template, task } = req.body;
    if (!template) return res.status(400).json({ error: 'template is required' });
    const result = await heady.beeFactory.executeOn(template, task || {});
    res.json(result);
  } catch (err) {
    logger.error({ error: err.message }, 'Bee execution failed');
    res.status(500).json({ error: err.message });
  }
});

/**
 * Colab Bridge status
 */
app.get('/api/v1/colab', (req, res) => {
  res.json(heady.colabBridge?.bridgeHealth() || { error: 'ColabBridge not initialized' });
});

/**
 * Pipeline execution history
 */
app.get('/api/v1/pipeline/history', (req, res) => {
  res.json({
    history: heady.pipeline?.pipelineHistory || [],
    total: heady.pipeline?.pipelineHistory?.length || 0,
  });
});

/**
 * 404 handler
 */
app.use((req, res) => {
  res.status(404).json({
    error: 'Not Found',
    path: req.path,
    availableEndpoints: [
      'GET /health',
      'GET /healthz',
      'GET /ready',
      'GET /api/v1/topology',
      'POST /api/v1/process',
      'POST /api/v1/chat',
      'POST /api/v1/route',
      'GET /api/v1/bees',
      'GET /api/v1/bees/templates',
      'POST /api/v1/bees/execute',
      'GET /api/v1/colab',
      'GET /api/v1/pipeline/history',
    ],
  });
});

/**
 * Error handler
 */
app.use((err, req, res, _next) => {
  logger.error({ error: err.message, stack: err.stack, correlationId: req.correlationId }, 'Unhandled error');
  res.status(err.statusCode || 500).json({
    error: err.message,
    code: err.code || 'INTERNAL_ERROR',
    correlationId: req.correlationId,
  });
});

// ═══════════════════════════════════════════════════════════════
// SERVER START & GRACEFUL SHUTDOWN
// ═══════════════════════════════════════════════════════════════

async function start() {
  logger.info({ env: NODE_ENV }, 'Starting HeadyOS...');

  try {
    await heady.init();
    logger.info({}, 'HeadyOS initialized');
  } catch (err) {
    logger.error({ error: err.message }, 'HeadyOS init failed');
    process.exit(1);
  }

  const server = app.listen(PORT, () => {
    logger.info({ port: PORT, env: NODE_ENV }, 'HeadyOS server started');
  });

  const shutdown = async (signal) => {
    logger.info({ signal }, 'Graceful shutdown initiated');

    server.close(async () => {
      try {
        await heady.shutdown();
      } catch (err) {
        logger.error({ error: err.message }, 'Shutdown error');
      }
      logger.info({}, 'Server closed');
      process.exit(0);
    });

    // Force close after 30 seconds
    setTimeout(() => {
      logger.error({}, 'Forced shutdown after timeout');
      process.exit(1);
    }, 30000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('uncaughtException', (err) => {
    logger.error({ error: err.message, stack: err.stack }, 'Uncaught exception');
    shutdown('UNCAUGHT_EXCEPTION');
  });
  process.on('unhandledRejection', (reason) => {
    logger.error({ reason: String(reason) }, 'Unhandled rejection');
  });
}

if (require.main === module) {
  start();
}

module.exports = { app, heady, start };
