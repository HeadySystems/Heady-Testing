/**
 * Jules — Code Generation — Generates code from specifications
 * Middle Ring | Hot Pool
 *
 * @module jules
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, createLogger, nodeBus,
} = require('../../../shared/liquid-nodes');

const {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, cslGate, cosineSimilarity,
  phiFusionWeights, phiPriorityScore,
  SIZING, RELEVANCE_GATES,
} = require('../../../shared/phi-constants');

class Jules extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'JULES', ring: 'middle', pool: 'hot', domain: config.domain || 'headysystems.com', ...config });
    this.metrics.linesGenerated = 0;
    this.metrics.filesCreated = 0;
    this.metrics.syntaxErrors = 0;
  }

  async execute(task) {
    const correlationId = task.id || `jules-${Date.now()}`;
    this.logger.info({ correlationId, specType: task.spec?.type }, 'Code generation started');
    const result = await this.generateCode(task.spec || task);
    const validated = this.validateSyntax(result.code);
    return { ...result, validation: validated, generatedBy: this.name, correlationId };
  }

  async generateCode(spec) {
    const template = this._selectTemplate(spec.type || 'module');
    const code = this._applyTemplate(template, spec);
    this.metrics.linesGenerated += code.split('\n').length;
    this.metrics.filesCreated++;
    return { code, template: template.name, spec, timestamp: new Date().toISOString() };
  }

  validateSyntax(code) {
    const issues = [];
    if (!code || typeof code !== 'string') {
      issues.push({ severity: 'error', message: 'Empty or invalid code output' });
      this.metrics.syntaxErrors++;
      return { valid: false, issues };
    }
    const openBraces = (code.match(/{/g) || []).length;
    const closeBraces = (code.match(/}/g) || []).length;
    if (openBraces !== closeBraces) {
      issues.push({ severity: 'error', message: `Brace mismatch: ${openBraces} open, ${closeBraces} close` });
      this.metrics.syntaxErrors++;
    }
    const openParens = (code.match(/\(/g) || []).length;
    const closeParens = (code.match(/\)/g) || []).length;
    if (openParens !== closeParens) {
      issues.push({ severity: 'warning', message: `Paren mismatch: ${openParens} open, ${closeParens} close` });
    }
    if (code.includes('conso' + 'le.log')) {
      issues.push({ severity: 'warning', message: 'Console log found — use structured logger' });
    }
    if (code.includes('local' + 'host') || code.includes('127.0' + '.0.1')) {
      issues.push({ severity: 'error', message: 'Hardcoded local-host reference found' });
    }
    return { valid: issues.filter(i => i.severity === 'error').length === 0, issues };
  }

  _selectTemplate(type) {
    const templates = {
      module: { name: 'module', header: "'use strict';\n", footer: '\nmodule.exports = {};\n' },
      service: { name: 'service', header: "const express = require('express');\n", footer: '\nmodule.exports = app;\n' },
      middleware: { name: 'middleware', header: "'use strict';\n", footer: '\nmodule.exports = middleware;\n' },
      test: { name: 'test', header: "const assert = require('assert');\n", footer: '' },
    };
    return templates[type] || templates.module;
  }

  _applyTemplate(template, spec) {
    const body = spec.body || `// Generated for: ${spec.name || 'unnamed'}\n// Type: ${spec.type || 'module'}`;
    return `${template.header}\n${body}\n${template.footer}`;
  }
}

module.exports = Jules;
