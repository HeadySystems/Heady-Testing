/**
 * Observer — Code Review & Monitoring — Quality assessment and drift detection
 * Middle Ring | Hot Pool
 *
 * @module observer
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, createLogger, nodeBus,
} = require('../../../shared/liquid-nodes');

const {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, cslGate, cosineSimilarity,
  phiFusionWeights, phiPriorityScore,
  SIZING, RELEVANCE_GATES,
} = require('../../../shared/phi-constants');

class Observer extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'OBSERVER', ring: 'middle', pool: 'hot', domain: config.domain || 'headysystems.com', ...config });
    this.metrics.reviewsCompleted = 0;
    this.metrics.issuesFound = 0;
  }

  async execute(task) {
    const correlationId = task.id || `observer-${Date.now()}`;
    this.logger.info({ correlationId }, 'Code review started');
    const review = this.reviewCode(task.code || '', task.context || {});
    this.metrics.reviewsCompleted++;
    return { review, reviewedBy: this.name, correlationId };
  }

  reviewCode(code, context) {
    const findings = [];
    const lines = (code || '').split('\n');

    // Check for anti-patterns
    lines.forEach((line, i) => {
      const lineNum = i + 1;
      if (line.includes('TODO') || line.includes('FIXME') || line.includes('HACK')) {
        findings.push({ line: lineNum, severity: 'warning', rule: 'no-todo', message: 'Placeholder comment found' });
      }
      if (line.includes('conso' + 'le.log')) {
        findings.push({ line: lineNum, severity: 'warning', rule: 'no-console', message: 'Use structured logger' });
      }
      if (/catch\s*\([^)]*\)\s*{\s*}/.test(line)) {
        findings.push({ line: lineNum, severity: 'error', rule: 'no-empty-catch', message: 'Empty catch block' });
      }
      if (line.includes('local' + 'host') || line.includes('127.0' + '.0.1')) {
        findings.push({ line: lineNum, severity: 'error', rule: 'no-localhost', message: 'Hardcoded local-host' });
      }
      if (/Access-Control-Allow-Origin.*\*/.test(line)) {
        findings.push({ line: lineNum, severity: 'error', rule: 'no-cors-wildcard', message: 'CORS wildcard in production' });
      }
    });

    this.metrics.issuesFound += findings.length;
    const score = Math.max(0, 1 - (findings.filter(f => f.severity === 'error').length * PSI * 0.1));
    return { findings, score, totalLines: lines.length, timestamp: new Date().toISOString() };
  }

  monitorDrift(component) {
    if (!component.embedding || !component.baselineEmbedding) return { drift: 0, threshold: CSL_THRESHOLDS.MEDIUM, drifted: false };
    const similarity = cosineSimilarity(component.embedding, component.baselineEmbedding);
    return { drift: 1 - similarity, similarity, threshold: CSL_THRESHOLDS.MEDIUM, drifted: similarity < CSL_THRESHOLDS.MEDIUM };
  }

  scoreCohesion(codebase) {
    const modules = codebase.modules || [];
    if (modules.length < 2) return { cohesion: 1.0 };
    let totalSim = 0; let pairs = 0;
    for (let i = 0; i < modules.length; i++) {
      for (let j = i + 1; j < modules.length; j++) {
        if (modules[i].embedding && modules[j].embedding) {
          totalSim += cosineSimilarity(modules[i].embedding, modules[j].embedding);
          pairs++;
        }
      }
    }
    return { cohesion: pairs > 0 ? totalSim / pairs : 0, pairs };
  }
}

module.exports = Observer;
