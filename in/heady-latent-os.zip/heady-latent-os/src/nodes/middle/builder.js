/**
 * Builder — Full-stack System Builder — Orchestrates multi-file builds
 * Middle Ring | Hot Pool
 *
 * @module builder
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, createLogger, nodeBus,
} = require('../../../shared/liquid-nodes');

const {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, cslGate, cosineSimilarity,
  phiFusionWeights, phiPriorityScore,
  SIZING, RELEVANCE_GATES,
} = require('../../../shared/phi-constants');

class Builder extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'BUILDER', ring: 'middle', pool: 'hot', domain: config.domain || 'headysystems.com', ...config });
    this.metrics.systemsBuilt = 0;
    this.metrics.filesGenerated = 0;
    this.maxBatchSize = fib(6); // 8 files per batch
  }

  async execute(task) {
    const correlationId = task.id || `builder-${Date.now()}`;
    this.logger.info({ correlationId }, 'System build started');
    const manifest = await this.buildSystem(task.blueprint || task);
    const wired = this.wireComponents(manifest.components);
    const verified = this.verifyBuild(manifest);
    this.metrics.systemsBuilt++;
    return { manifest, wired, verified, builtBy: this.name, correlationId };
  }

  async buildSystem(blueprint) {
    const components = [];
    const files = blueprint.files || [];
    for (let i = 0; i < files.length; i += this.maxBatchSize) {
      const batch = files.slice(i, i + this.maxBatchSize);
      const built = batch.map(f => ({ path: f.path, type: f.type, status: 'created', size: f.content?.length || 0 }));
      components.push(...built);
      this.metrics.filesGenerated += built.length;
    }
    return { id: blueprint.id || `build-${Date.now()}`, components, totalFiles: components.length, timestamp: new Date().toISOString() };
  }

  wireComponents(components) {
    const connections = [];
    for (let i = 0; i < components.length; i++) {
      for (let j = i + 1; j < components.length; j++) {
        if (this._shouldConnect(components[i], components[j])) {
          connections.push({ from: components[i].path, to: components[j].path, type: 'import' });
        }
      }
    }
    return { connections, totalWired: connections.length };
  }

  verifyBuild(manifest) {
    const checks = [];
    for (const comp of manifest.components) {
      checks.push({ file: comp.path, exists: comp.status === 'created', valid: comp.size > 0 });
    }
    const allValid = checks.every(c => c.exists && c.valid);
    return { passed: allValid, checks, timestamp: new Date().toISOString() };
  }

  _shouldConnect(a, b) {
    const serviceTypes = ['service', 'middleware', 'route', 'controller'];
    return serviceTypes.includes(a.type) && serviceTypes.includes(b.type);
  }
}

module.exports = Builder;
