/**
 * Atlas — Architecture Documentation — System mapping and ADRs
 * Middle Ring | Warm Pool
 *
 * @module atlas
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, createLogger, nodeBus,
} = require('../../../shared/liquid-nodes');

const {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, cslGate, cosineSimilarity,
  phiFusionWeights, phiPriorityScore,
  SIZING, RELEVANCE_GATES,
} = require('../../../shared/phi-constants');

class Atlas extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'ATLAS', ring: 'middle', pool: 'warm', domain: config.domain || 'headysystems.com', ...config });
    this.metrics.documentsGenerated = 0;
    this.adrs = [];
    this.architectureMap = new Map();
  }

  async execute(task) {
    const correlationId = task.id || `atlas-${Date.now()}`;
    this.logger.info({ correlationId, taskType: task.type }, 'Documentation started');
    if (task.type === 'adr') return this.generateADR(task.decision);
    if (task.type === 'dependency') return this.trackDependencies(task.modules);
    return this.mapArchitecture(task.codebase || task);
  }

  mapArchitecture(codebase) {
    const modules = codebase.modules || [];
    const map = { nodes: [], edges: [], layers: {} };
    for (const mod of modules) {
      const node = { id: mod.name, type: mod.type || 'module', path: mod.path, layer: mod.layer || 'unknown' };
      map.nodes.push(node);
      this.architectureMap.set(mod.name, node);
      if (!map.layers[node.layer]) map.layers[node.layer] = [];
      map.layers[node.layer].push(node.id);
      for (const dep of (mod.dependencies || [])) {
        map.edges.push({ from: mod.name, to: dep, type: 'depends_on' });
      }
    }
    this.metrics.documentsGenerated++;
    return { map, totalNodes: map.nodes.length, totalEdges: map.edges.length, layers: Object.keys(map.layers).length, timestamp: new Date().toISOString() };
  }

  generateADR(decision) {
    const adr = {
      id: `ADR-${String(this.adrs.length + 1).padStart(4, '0')}`,
      title: decision.title,
      status: decision.status || 'proposed',
      context: decision.context,
      decision: decision.decision,
      consequences: decision.consequences || [],
      alternatives: decision.alternatives || [],
      createdAt: new Date().toISOString(),
      createdBy: this.name,
    };
    this.adrs.push(adr);
    this.metrics.documentsGenerated++;
    return adr;
  }

  trackDependencies(modules) {
    const graph = { nodes: [], edges: [], cycles: [] };
    const visited = new Set(); const inStack = new Set();
    for (const mod of (modules || [])) {
      graph.nodes.push(mod.name);
      for (const dep of (mod.dependencies || [])) graph.edges.push({ from: mod.name, to: dep });
    }
    const _dfs = (node, path) => {
      if (inStack.has(node)) { graph.cycles.push([...path, node]); return; }
      if (visited.has(node)) return;
      visited.add(node); inStack.add(node);
      for (const edge of graph.edges.filter(e => e.from === node)) _dfs(edge.to, [...path, node]);
      inStack.delete(node);
    };
    for (const node of graph.nodes) _dfs(node, []);
    return { graph, hasCycles: graph.cycles.length > 0 };
  }
}

module.exports = Atlas;
