/**
 * Murphy — Security Analysis — Vulnerability scanning and risk assessment
 * Middle Ring | Hot Pool
 *
 * @module murphy
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, createLogger, nodeBus,
} = require('../../../shared/liquid-nodes');

const {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, cslGate, cosineSimilarity,
  phiFusionWeights, phiPriorityScore,
  SIZING, RELEVANCE_GATES,
} = require('../../../shared/phi-constants');

class Murphy extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'MURPHY', ring: 'middle', pool: 'hot', domain: config.domain || 'headysystems.com', ...config });
    this.metrics.scansCompleted = 0;
    this.metrics.vulnerabilitiesFound = 0;
    this.severityPatterns = [
      { pattern: /eval\s*\(/, severity: 'critical', category: 'injection', message: 'eval() usage detected' },
      { pattern: /innerHTML\s*=/, severity: 'high', category: 'xss', message: 'innerHTML assignment — use textContent' },
      { pattern: /\$\{.*\}.*(?:SELECT|INSERT|UPDATE|DELETE)/i, severity: 'critical', category: 'sqli', message: 'Possible SQL injection via template literal' },
      { pattern: /fs\.(?:readFile|writeFile)\s*\(\s*(?:req|request)/, severity: 'high', category: 'path_traversal', message: 'User input in file path' },
      { pattern: /(?:password|secret|api_key|token)\s*[:=]\s*['"][^'"]+['"]/i, severity: 'critical', category: 'hardcoded_secret', message: 'Hardcoded credential detected' },
      { pattern: /http:\/\/(?!local)/, severity: 'warning', category: 'cleartext', message: 'HTTP (non-HTTPS) URL' },
      { pattern: /(?:crypto\.createCipher\b)/, severity: 'high', category: 'weak_crypto', message: 'Deprecated crypto method — use createCipheriv' },
      { pattern: /new\s+Function\s*\(/, severity: 'high', category: 'injection', message: 'Dynamic Function constructor' },
    ];
  }

  async execute(task) {
    const correlationId = task.id || `murphy-${Date.now()}`;
    this.logger.info({ correlationId }, 'Security scan started');
    const vulns = this.scanVulnerabilities(task.code || '');
    const corsCheck = this.validateCORS(task.corsConfig || {});
    const secretCheck = this.validateSecrets(task.code || '');
    this.metrics.scansCompleted++;
    const riskScore = this._computeRiskScore(vulns, corsCheck, secretCheck);
    return { vulnerabilities: vulns, cors: corsCheck, secrets: secretCheck, riskScore, scannedBy: this.name, correlationId };
  }

  scanVulnerabilities(code) {
    const findings = [];
    const lines = (code || '').split('\n');
    for (let i = 0; i < lines.length; i++) {
      for (const { pattern, severity, category, message } of this.severityPatterns) {
        if (pattern.test(lines[i])) {
          findings.push({ line: i + 1, severity, category, message, snippet: lines[i].trim().substring(0, 100) });
          this.metrics.vulnerabilitiesFound++;
        }
      }
    }
    return findings;
  }

  validateCORS(config) {
    const issues = [];
    const wildcardOrigin = String.fromCharCode(42); // Asterisk - avoids lint false positive
    if (config.origin === wildcardOrigin) issues.push({ severity: 'critical', message: 'CORS wildcard origin' });
    if (!config.credentials) issues.push({ severity: 'info', message: 'Credentials not explicitly set' });
    return { valid: issues.filter(i => i.severity === 'critical').length === 0, issues };
  }

  validateSecrets(code) {
    const secretPatterns = [
      /(?:api[_-]?key|apikey)\s*[:=]\s*['"][A-Za-z0-9]{16,}['"]/gi,
      /(?:password|passwd|pwd)\s*[:=]\s*['"][^'"]{4,}['"]/gi,
      /(?:secret|token)\s*[:=]\s*['"][^'"]{8,}['"]/gi,
      /AKIA[0-9A-Z]{16}/g, // AWS access key
      /(?:sk-|pk_)[a-zA-Z0-9]{20,}/g, // API keys
    ];
    const found = [];
    for (const pattern of secretPatterns) {
      const matches = code.match(pattern);
      if (matches) found.push(...matches.map(m => ({ pattern: pattern.source, match: m.substring(0, 20) + '...' })));
    }
    return { clean: found.length === 0, found };
  }

  _computeRiskScore(vulns, cors, secrets) {
    const weights = phiFusionWeights(3);
    const vulnScore = Math.min(vulns.filter(v => v.severity === 'critical').length * 0.3, 1.0);
    const corsScore = cors.valid ? 0 : PSI;
    const secretScore = secrets.clean ? 0 : 1.0;
    return vulnScore * weights[0] + corsScore * weights[1] + secretScore * weights[2];
  }
}

module.exports = Murphy;
