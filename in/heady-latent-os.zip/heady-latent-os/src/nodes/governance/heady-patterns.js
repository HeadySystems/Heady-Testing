/**
 * HeadyPatterns — Pattern Detection, Drift Classification & Learning
 * Governance Shell | Cold Pool
 * @module heady-patterns
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */
const { LiquidNode, createLogger, nodeBus } = require('../../../shared/liquid-nodes');
const { PHI, PSI, FIB, fib, CSL_THRESHOLDS, cslGate, cosineSimilarity, phiFusionWeights, SIZING } = require('../../../shared/phi-constants');

class HeadyPatterns extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyPatterns', ring: 'governance', pool: 'cold', ...config });
    this.patternStore = new Map();
    this.maxPatterns = SIZING.PATTERN_STORE;
  }
  async execute(task) {
    if (task.type === 'drift') return this.classifyDrift(task.before, task.after);
    if (task.type === 'learn') return this.recordLearning(task.pattern);
    return this.detectPatterns(task.data || task);
  }
  detectPatterns(data) {
    const patterns = [];
    const entries = Array.isArray(data) ? data : [data];
    for (let i = 0; i < entries.length; i++) {
      for (let j = i + 1; j < entries.length; j++) {
        if (entries[i].embedding && entries[j].embedding) {
          const sim = cosineSimilarity(entries[i].embedding, entries[j].embedding);
          if (sim >= CSL_THRESHOLDS.HIGH) patterns.push({ a: i, b: j, similarity: sim, type: 'high_similarity' });
        }
      }
    }
    return { patterns, count: patterns.length, detectedBy: this.name };
  }
  classifyDrift(before, after) {
    if (!before || !after) return { drift: 'unknown', severity: 'unknown' };
    const sim = before.embedding && after.embedding ? cosineSimilarity(before.embedding, after.embedding) : PSI;
    const driftAmount = 1 - sim;
    const severity = driftAmount > 1 - CSL_THRESHOLDS.MEDIUM ? 'critical' : driftAmount > 1 - CSL_THRESHOLDS.HIGH ? 'warning' : 'nominal';
    return { similarity: sim, drift: driftAmount, severity, threshold: CSL_THRESHOLDS.MEDIUM };
  }
  recordLearning(pattern) {
    const key = pattern.id || `pattern-${Date.now()}`;
    if (this.patternStore.size >= this.maxPatterns) { const oldest = this.patternStore.keys().next().value; this.patternStore.delete(oldest); }
    this.patternStore.set(key, { ...pattern, recordedAt: new Date().toISOString() });
    return { recorded: true, key, totalPatterns: this.patternStore.size };
  }
}
module.exports = HeadyPatterns;
