/**
 * HeadyCheck — Output Validation Quality Gate
 * Governance Shell | Governance Pool
 * @module heady-check
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */
const { LiquidNode, createLogger, nodeBus } = require('../../../shared/liquid-nodes');
const { PHI, PSI, FIB, fib, CSL_THRESHOLDS, cslGate, cosineSimilarity, phiFusionWeights, SIZING } = require('../../../shared/phi-constants');

class HeadyCheck extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyCheck', ring: 'governance', pool: 'governance', ...config });
    this.metrics.validationsRun = 0;
    this.metrics.passed = 0;
    this.metrics.failed = 0;
  }
  async execute(task) { return this.validateOutput(task.output, task.spec); }
  validateOutput(output, spec = {}) {
    const checks = [];
    if (!output) { checks.push({ check: 'exists', passed: false, message: 'Output is null or undefined' }); }
    else {
      checks.push({ check: 'exists', passed: true });
      if (spec.type && typeof output !== spec.type) checks.push({ check: 'type', passed: false, message: `Expected ${spec.type}, got ${typeof output}` });
      else checks.push({ check: 'type', passed: true });
      if (spec.minLength && (typeof output === 'string' ? output.length : JSON.stringify(output).length) < spec.minLength) checks.push({ check: 'minLength', passed: false });
      else checks.push({ check: 'minLength', passed: true });
    }
    const passed = checks.every(c => c.passed);
    this.metrics.validationsRun++;
    if (passed) this.metrics.passed++; else this.metrics.failed++;
    return { passed, checks, score: this.scoreQuality(output), validatedBy: this.name, timestamp: new Date().toISOString() };
  }
  scoreQuality(output) {
    if (!output) return 0;
    const size = typeof output === 'string' ? output.length : JSON.stringify(output).length;
    return cslGate(1.0, Math.min(size / 1000, 1.0), CSL_THRESHOLDS.MINIMUM);
  }
}
module.exports = HeadyCheck;
