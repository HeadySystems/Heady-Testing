/**
 * HeadyBuddy — AI Companion Interface
 * Inner Ring | Hot Pool
 *
 * User-facing conversational layer that processes messages,
 * routes to HeadyConductor, and formats responses.
 *
 * @module heady-buddy
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, createLogger, nodeBus,
} = require('../../../shared/liquid-nodes');

const {
  PHI, PSI, fib,
  CSL_THRESHOLDS, cslGate, cosineSimilarity,
  phiFusionWeights, phiTokenBudgets,
} = require('../../../shared/phi-constants');

class HeadyBuddy extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'HeadyBuddy',
      ring: 'inner',
      pool: 'hot',
      domain: config.domain || 'headybuddy.org',
      ...config,
    });
    this.conversationHistory = [];
    this.tokenBudgets = phiTokenBudgets();
    this.currentTokens = 0;
    this.maxHistoryLength = fib(8); // 21 messages
    this.personality = {
      warmth: PSI,
      precision: PSI + 0.1,
      creativity: PSI * PSI,
    };

    nodeBus.on('conductor:response', (data) => this._handleConductorResponse(data));
    this.cleanupStack.push(() => nodeBus.removeAllListeners('conductor:response'));
  }

  /**
   * Process a user message through the companion pipeline.
   * @param {Object} task
   * @param {string} task.message - User message
   * @param {string} [task.sessionId] - Session identifier
   * @returns {Promise<Object>} Formatted response
   */
  async execute(task) {
    const correlationId = task.id || `buddy-${Date.now()}`;
    this.logger.info({ correlationId, messageLength: task.message?.length }, 'Processing message');

    const processed = await this.processMessage(task.message, correlationId);
    return this.formatResponse(processed, correlationId);
  }

  /**
   * Process a user message: classify intent, route to Conductor.
   * @param {string} message - Raw user message
   * @param {string} correlationId - Correlation ID
   * @returns {Promise<Object>} Processed result
   */
  async processMessage(message, correlationId) {
    const intent = this._classifyIntent(message);
    this._addToHistory('user', message);

    const routingPayload = {
      id: correlationId,
      type: intent.type,
      message,
      intent,
      embedding: this.embedding,
      metadata: {
        sessionTokens: this.currentTokens,
        historyDepth: this.conversationHistory.length,
      },
    };

    nodeBus.emit('conductor:route', routingPayload);

    return {
      correlationId,
      intent,
      routed: true,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Format a Conductor response for user display.
   * @param {Object} result - Raw result from pipeline
   * @param {string} correlationId - Correlation ID
   * @returns {Object} Formatted response
   */
  formatResponse(result, correlationId) {
    const response = {
      id: correlationId,
      type: 'assistant',
      content: result.content || result,
      intent: result.intent,
      confidence: result.confidence || 1.0,
      metadata: {
        processedBy: this.name,
        coherence: this.coherenceScore,
        tokensUsed: this.currentTokens,
      },
      timestamp: new Date().toISOString(),
    };

    this._addToHistory('assistant', response.content);
    return response;
  }

  /**
   * Classify message intent using keyword matching and CSL scoring.
   * @param {string} message - User message
   * @returns {Object} Intent classification
   * @private
   */
  _classifyIntent(message) {
    const lower = (message || '').toLowerCase();
    const intents = [
      { type: 'code_generation', keywords: ['write', 'create', 'build', 'generate', 'implement', 'code'] },
      { type: 'code_review', keywords: ['review', 'check', 'audit', 'inspect', 'quality'] },
      { type: 'security_audit', keywords: ['security', 'vulnerability', 'scan', 'risk', 'threat'] },
      { type: 'architecture', keywords: ['architecture', 'design', 'plan', 'structure', 'topology'] },
      { type: 'research', keywords: ['research', 'find', 'search', 'explore', 'learn'] },
      { type: 'documentation', keywords: ['document', 'docs', 'readme', 'explain', 'describe'] },
      { type: 'creative', keywords: ['creative', 'design', 'ui', 'ux', 'visual', 'style'] },
      { type: 'quick_task', keywords: ['help', 'what', 'how', 'why', 'when'] },
    ];

    let bestMatch = { type: 'quick_task', confidence: CSL_THRESHOLDS.MINIMUM, keywords: [] };
    for (const intent of intents) {
      const matchCount = intent.keywords.filter(k => lower.includes(k)).length;
      const confidence = matchCount > 0
        ? cslGate(1.0, matchCount / intent.keywords.length, CSL_THRESHOLDS.MINIMUM)
        : 0;
      if (confidence > bestMatch.confidence) {
        bestMatch = { type: intent.type, confidence, keywords: intent.keywords.filter(k => lower.includes(k)) };
      }
    }

    return bestMatch;
  }

  /**
   * Add message to conversation history with token budget management.
   * @param {string} role - 'user' or 'assistant'
   * @param {*} content - Message content
   * @private
   */
  _addToHistory(role, content) {
    const estimatedTokens = typeof content === 'string'
      ? Math.ceil(content.length / 4)
      : fib(5); // 5 tokens for non-string

    this.conversationHistory.push({
      role,
      content,
      tokens: estimatedTokens,
      timestamp: new Date().toISOString(),
    });
    this.currentTokens += estimatedTokens;

    // Evict oldest when over budget or max length
    while (
      this.conversationHistory.length > this.maxHistoryLength ||
      this.currentTokens > this.tokenBudgets.session
    ) {
      const removed = this.conversationHistory.shift();
      if (removed) this.currentTokens -= removed.tokens;
    }
  }

  /**
   * Handle response from Conductor.
   * @param {Object} data - Response data
   * @private
   */
  _handleConductorResponse(data) {
    this.logger.info({ correlationId: data?.correlationId }, 'Conductor response received');
  }
}

module.exports = HeadyBuddy;
