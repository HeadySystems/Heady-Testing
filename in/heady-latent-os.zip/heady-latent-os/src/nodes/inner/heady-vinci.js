/**
 * HeadyVinci — Session Planner, Topology Maintainer, Multi-Step Planning
 * Inner Ring | Hot Pool
 *
 * Decomposes complex tasks into sub-task DAGs with dependency resolution
 * using topological sort (Kahn's algorithm) and phi-scored complexity.
 *
 * @module heady-vinci
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, createLogger, nodeBus,
} = require('../../../shared/liquid-nodes');

const {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, cosineSimilarity, cslGate,
  phiFusionWeights, phiPriorityScore,
  SIZING,
} = require('../../../shared/phi-constants');

/** Sub-task type classification */
const SUBTASK_TYPES = Object.freeze({
  RESEARCH:      'research',
  CODING:        'coding',
  DATA:          'data',
  REASONING:     'reasoning',
  SYNTHESIS:     'synthesis',
  VALIDATION:    'validation',
  RETRIEVAL:     'retrieval',
  INTEGRATION:   'integration',
  PLANNING:      'planning',
  COMMUNICATION: 'communication',
});

class HeadyVinci extends LiquidNode {
  /**
   * @param {Object} [config={}]
   */
  constructor(config = {}) {
    super({
      name: 'HeadyVinci',
      ring: 'inner',
      pool: 'hot',
      domain: config.domain || 'headyme.com',
      ...config,
    });
    /** @type {Map<string, Object>} Active session plans */
    this.sessions = new Map();
    this.maxConcurrentSubtasks = fib(6); // 8
    this.maxSubtasks = fib(10); // 55
  }

  /**
   * Execute a planning task.
   * @param {Object} task - Task to plan
   * @returns {Promise<Object>} Execution plan with DAG
   */
  async execute(task) {
    const correlationId = task.id || `vinci-${Date.now()}`;
    this.logger.info({ correlationId, taskType: task.type }, 'Planning started');

    const plan = await this.planSession(task);
    this.sessions.set(correlationId, plan);

    this.logger.info({
      correlationId,
      subtaskCount: plan.subtasks.length,
      complexity: plan.complexity,
      estimatedStages: plan.executionOrder.length,
    }, 'Plan complete');

    return plan;
  }

  /**
   * Decompose a complex task into a session plan with sub-task DAG.
   * @param {Object} task - Complex task to decompose
   * @returns {Promise<Object>} Session plan
   */
  async planSession(task) {
    const complexity = this.estimateComplexity(task);
    const subtasks = this._decomposeTask(task, complexity);
    const dag = this._buildDAG(subtasks);
    const executionOrder = this._topologicalSort(dag);
    const poolAssignment = this._assignPools(complexity);

    return {
      id: task.id || `plan-${Date.now()}`,
      originalTask: { id: task.id, type: task.type },
      complexity,
      subtasks,
      dag,
      executionOrder,
      poolAssignment,
      maxConcurrent: this.maxConcurrentSubtasks,
      createdAt: new Date().toISOString(),
      createdBy: this.name,
    };
  }

  /**
   * Estimate task complexity using phi-scaled scoring.
   * @param {Object} task - Task to evaluate
   * @returns {number} Complexity score between 0 and 1
   */
  estimateComplexity(task) {
    const factors = [];

    // Context depth factor
    const contextEntries = task.context?.entries?.length || 0;
    factors.push(Math.min(contextEntries / fib(8), 1.0));

    // Metadata richness
    const metaKeys = task.metadata ? Object.keys(task.metadata).length : 0;
    factors.push(Math.min(metaKeys / fib(7), 1.0));

    // Embedding spread (inverse of avg relevance = more complex)
    const avgRelevance = task.context?.avgRelevance || PSI;
    factors.push(1 - avgRelevance);

    // Type-based complexity
    const typeComplexity = {
      'code_generation': PSI,
      'architecture': PSI + 0.1,
      'security_audit': PSI,
      'research': PSI * PSI,
      'quick_task': PSI * PSI * PSI,
    };
    factors.push(typeComplexity[task.type] || PSI);

    const weights = phiFusionWeights(factors.length);
    return factors.reduce((sum, f, i) => sum + f * weights[i], 0);
  }

  /**
   * Decompose a task into subtasks based on complexity.
   * @param {Object} task - Task to decompose
   * @param {number} complexity - Estimated complexity
   * @returns {Object[]} Array of subtasks
   * @private
   */
  _decomposeTask(task, complexity) {
    const subtaskCount = Math.max(1, Math.min(
      Math.round(complexity * fib(7)), // scale to max 13 subtasks
      this.maxSubtasks
    ));

    const subtasks = [];
    const phases = this._determinePhases(task.type);

    for (let i = 0; i < Math.min(subtaskCount, phases.length); i++) {
      const phase = phases[i];
      subtasks.push({
        id: `${task.id || 'task'}-sub-${i}`,
        parentId: task.id,
        type: phase.type,
        name: phase.name,
        dependencies: phase.dependencies.map(d => `${task.id || 'task'}-sub-${d}`),
        pool: phase.pool,
        estimatedMs: Math.round(PHI * 1000 * fib(phase.fibWeight)),
        index: i,
      });
    }

    return subtasks;
  }

  /**
   * Determine execution phases based on task type.
   * @param {string} taskType - Type of task
   * @returns {Object[]} Phase definitions
   * @private
   */
  _determinePhases(taskType) {
    const commonPhases = [
      { type: SUBTASK_TYPES.RETRIEVAL, name: 'Gather context', dependencies: [], pool: 'hot', fibWeight: 3 },
      { type: SUBTASK_TYPES.PLANNING, name: 'Plan approach', dependencies: [0], pool: 'hot', fibWeight: 4 },
      { type: SUBTASK_TYPES.REASONING, name: 'Analyze requirements', dependencies: [0], pool: 'warm', fibWeight: 5 },
    ];

    const typePhases = {
      code_generation: [
        ...commonPhases,
        { type: SUBTASK_TYPES.CODING, name: 'Generate code', dependencies: [1, 2], pool: 'hot', fibWeight: 6 },
        { type: SUBTASK_TYPES.VALIDATION, name: 'Validate output', dependencies: [3], pool: 'hot', fibWeight: 4 },
        { type: SUBTASK_TYPES.INTEGRATION, name: 'Wire components', dependencies: [4], pool: 'warm', fibWeight: 5 },
      ],
      architecture: [
        ...commonPhases,
        { type: SUBTASK_TYPES.RESEARCH, name: 'Research patterns', dependencies: [1], pool: 'warm', fibWeight: 6 },
        { type: SUBTASK_TYPES.SYNTHESIS, name: 'Design architecture', dependencies: [2, 3], pool: 'hot', fibWeight: 7 },
        { type: SUBTASK_TYPES.VALIDATION, name: 'Validate design', dependencies: [4], pool: 'hot', fibWeight: 5 },
      ],
      security_audit: [
        ...commonPhases,
        { type: SUBTASK_TYPES.DATA, name: 'Scan vulnerabilities', dependencies: [1, 2], pool: 'hot', fibWeight: 6 },
        { type: SUBTASK_TYPES.REASONING, name: 'Assess risk', dependencies: [3], pool: 'warm', fibWeight: 5 },
        { type: SUBTASK_TYPES.COMMUNICATION, name: 'Generate report', dependencies: [4], pool: 'cold', fibWeight: 5 },
      ],
    };

    return typePhases[taskType] || [
      ...commonPhases,
      { type: SUBTASK_TYPES.REASONING, name: 'Process task', dependencies: [1, 2], pool: 'warm', fibWeight: 5 },
      { type: SUBTASK_TYPES.SYNTHESIS, name: 'Synthesize result', dependencies: [3], pool: 'hot', fibWeight: 4 },
    ];
  }

  /**
   * Build a DAG (Directed Acyclic Graph) from subtasks.
   * @param {Object[]} subtasks - Subtasks with dependencies
   * @returns {Object} DAG representation
   * @private
   */
  _buildDAG(subtasks) {
    const adjacency = new Map();
    const inDegree = new Map();

    for (const st of subtasks) {
      adjacency.set(st.id, []);
      inDegree.set(st.id, 0);
    }

    for (const st of subtasks) {
      for (const dep of st.dependencies) {
        if (adjacency.has(dep)) {
          adjacency.get(dep).push(st.id);
          inDegree.set(st.id, (inDegree.get(st.id) || 0) + 1);
        }
      }
    }

    return { adjacency, inDegree, nodes: subtasks.map(s => s.id) };
  }

  /**
   * Topological sort using Kahn's algorithm with cycle detection.
   * @param {Object} dag - DAG from _buildDAG
   * @returns {string[][]} Execution stages (parallelizable groups)
   * @private
   */
  _topologicalSort(dag) {
    const { adjacency, inDegree, nodes } = dag;
    const inDegreeCopy = new Map(inDegree);
    const stages = [];
    let processed = 0;

    while (processed < nodes.length) {
      const readyNodes = [];
      for (const [node, degree] of inDegreeCopy) {
        if (degree === 0) readyNodes.push(node);
      }

      if (readyNodes.length === 0 && processed < nodes.length) {
        this.logger.error({ processed, total: nodes.length }, 'Cycle detected in task DAG');
        break;
      }

      // Limit concurrent execution per stage
      const stage = readyNodes.slice(0, this.maxConcurrentSubtasks);
      stages.push(stage);

      for (const node of stage) {
        inDegreeCopy.delete(node);
        processed++;
        for (const neighbor of (adjacency.get(node) || [])) {
          inDegreeCopy.set(neighbor, (inDegreeCopy.get(neighbor) || 1) - 1);
        }
      }
    }

    return stages;
  }

  /**
   * Assign pool based on complexity score using phi-scaled boundaries.
   * @param {number} complexity - Task complexity (0-1)
   * @returns {string} Pool assignment
   * @private
   */
  _assignPools(complexity) {
    if (complexity < PSI * PSI) return 'hot';
    if (complexity < PSI) return 'warm';
    if (complexity < 1 - PSI * PSI * PSI) return 'cold';
    return 'reserve';
  }
}

module.exports = HeadyVinci;
