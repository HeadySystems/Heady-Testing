/**
 * HeadyBrains — Computational Pre-processor & Context Gathering
 * Inner Ring | Hot Pool
 *
 * Gathers context from vector memory, file system, and request metadata
 * before tasks are routed through HeadyConductor.
 *
 * @module heady-brains
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, createLogger, nodeBus,
} = require('../../../shared/liquid-nodes');

const {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, RELEVANCE_GATES,
  cslGate, cosineSimilarity, phiFusionWeights,
  SIZING,
} = require('../../../shared/phi-constants');

class HeadyBrains extends LiquidNode {
  /**
   * @param {Object} [config={}]
   */
  constructor(config = {}) {
    super({
      name: 'HeadyBrains',
      ring: 'inner',
      pool: 'hot',
      domain: config.domain || 'headyme.com',
      ...config,
    });
    /** @type {Map<string, { embedding: number[], metadata: Object }>} */
    this.contextCache = new Map();
    this.maxCacheSize = SIZING.CACHE_SIZE; // 987
    this.contextWindow = [];
    this.maxContextEntries = fib(8); // 21

    nodeBus.on('memory:result', (data) => this._handleMemoryResult(data));
    this.cleanupStack.push(() => nodeBus.removeAllListeners('memory:result'));
  }

  /**
   * Execute a context-gathering task.
   * @param {Object} task - Task requiring context assembly
   * @param {string} task.id - Unique task identifier
   * @param {string} task.type - Task type (e.g., 'context_assemble')
   * @param {number[]} [task.embedding] - 384D task embedding
   * @param {Object} [task.metadata] - Additional task metadata
   * @returns {Promise<Object>} Enriched task with assembled context
   */
  async execute(task) {
    const correlationId = task.id || `brains-${Date.now()}`;
    this.logger.info({ correlationId, taskType: task.type }, 'Context assembly started');

    const context = await this.contextAssemble(task);
    const enriched = this.enrichTask(task, context);

    this.logger.info({
      correlationId,
      contextEntries: context.entries.length,
      relevanceScore: context.avgRelevance,
    }, 'Context assembly complete');

    return enriched;
  }

  /**
   * Assemble context for a task by querying vector memory
   * and collecting relevant embeddings.
   * @param {Object} task - Task to gather context for
   * @returns {Promise<Object>} Assembled context
   */
  async contextAssemble(task) {
    const correlationId = task.id || `ctx-${Date.now()}`;
    const taskEmbedding = task.embedding || this.embedding;
    const entries = [];
    let totalRelevance = 0;

    // Query vector memory for relevant entries
    nodeBus.emit('memory:query', {
      correlationId,
      embedding: taskEmbedding,
      topK: fib(8), // 21
      threshold: RELEVANCE_GATES.include, // 0.382
    });

    // Check context cache for relevant entries
    for (const [key, cached] of this.contextCache) {
      const similarity = cosineSimilarity(taskEmbedding, cached.embedding);
      const gatedScore = cslGate(1.0, similarity, CSL_THRESHOLDS.MINIMUM);

      if (similarity >= RELEVANCE_GATES.include) {
        entries.push({
          key,
          similarity,
          gatedScore,
          metadata: cached.metadata,
          boosted: similarity >= RELEVANCE_GATES.boost,
          injected: similarity >= RELEVANCE_GATES.inject,
        });
        totalRelevance += similarity;
      }
    }

    // Sort by similarity descending, take top entries
    entries.sort((a, b) => b.similarity - a.similarity);
    const topEntries = entries.slice(0, this.maxContextEntries);
    const avgRelevance = topEntries.length > 0
      ? totalRelevance / topEntries.length
      : 0;

    return {
      correlationId,
      entries: topEntries,
      avgRelevance,
      totalCandidates: entries.length,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Enrich a task with assembled context.
   * @param {Object} task - Original task
   * @param {Object} context - Assembled context
   * @returns {Object} Enriched task ready for Conductor routing
   */
  enrichTask(task, context) {
    const weights = phiFusionWeights(3); // [0.528, 0.326, 0.146]

    const complexityScore = this._estimateComplexity(task, context);
    const poolRecommendation = this._recommendPool(complexityScore);

    return {
      ...task,
      context: {
        entries: context.entries,
        avgRelevance: context.avgRelevance,
        totalCandidates: context.totalCandidates,
      },
      enrichment: {
        complexityScore,
        poolRecommendation,
        contextDepth: context.entries.length,
        boostedCount: context.entries.filter(e => e.boosted).length,
        injectedCount: context.entries.filter(e => e.injected).length,
        weights: {
          relevance: weights[0],
          recency: weights[1],
          complexity: weights[2],
        },
      },
      enrichedAt: new Date().toISOString(),
      enrichedBy: this.name,
    };
  }

  /**
   * Estimate task complexity using phi-scaled scoring.
   * @param {Object} task - Task to evaluate
   * @param {Object} context - Assembled context
   * @returns {number} Complexity score between 0 and 1
   * @private
   */
  _estimateComplexity(task, context) {
    const weights = phiFusionWeights(3);
    const contextDepthFactor = Math.min(context.entries.length / this.maxContextEntries, 1.0);
    const embeddingSpread = context.avgRelevance > 0 ? 1 - context.avgRelevance : PSI;
    const metadataComplexity = task.metadata
      ? Math.min(Object.keys(task.metadata).length / fib(7), 1.0)
      : 0;

    return (
      contextDepthFactor * weights[0] +
      embeddingSpread * weights[1] +
      metadataComplexity * weights[2]
    );
  }

  /**
   * Recommend a resource pool based on complexity.
   * @param {number} complexityScore - Task complexity (0-1)
   * @returns {string} Recommended pool name
   * @private
   */
  _recommendPool(complexityScore) {
    if (complexityScore < PSI * PSI) return 'hot';    // < 0.382
    if (complexityScore < PSI) return 'warm';          // < 0.618
    return 'cold';
  }

  /**
   * Handle memory query results from HeadyMemory.
   * @param {Object} data - Memory result data
   * @private
   */
  _handleMemoryResult(data) {
    if (!data || !data.results) return;
    for (const result of data.results) {
      if (this.contextCache.size >= this.maxCacheSize) {
        const oldestKey = this.contextCache.keys().next().value;
        this.contextCache.delete(oldestKey);
      }
      this.contextCache.set(result.key || `mem-${Date.now()}-${Math.random()}`, {
        embedding: result.embedding,
        metadata: result.metadata || {},
      });
    }
  }
}

module.exports = HeadyBrains;
