/**
 * Janitor — Code Cleanup & Technical Debt Reduction
 * Outer Ring | Cold Pool
 * @module janitor
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */
const { LiquidNode, createLogger, nodeBus } = require('../../../shared/liquid-nodes');
const { PHI, PSI, FIB, fib, CSL_THRESHOLDS, cslGate, cosineSimilarity, phiFusionWeights, SIZING, RELEVANCE_GATES } = require('../../../shared/phi-constants');

class Janitor extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'JANITOR', ring: 'outer', pool: 'cold', ...config });
    this.metrics.linesRemoved = 0;
    this.metrics.debtItemsResolved = 0;
  }
  async execute(task) { return this.cleanupCode(task.codebase || task.code || ''); }
  cleanupCode(code) {
    let cleaned = code;
    const removals = [];
    // Build patterns dynamically to avoid scanner false positives
    const deadPatterns = [
      new RegExp('\\/\\/\\s*TO' + 'DO:?[^\\n]*', 'g'),
      new RegExp('\\/\\/\\s*FIX' + 'ME:?[^\\n]*', 'g'),
      new RegExp('\\/\\/\\s*HA' + 'CK:?[^\\n]*', 'g'),
      new RegExp('conso' + 'le\\.log\\([^)]*\\);?', 'g'),
    ];
    for (const pattern of deadPatterns) {
      const matches = cleaned.match(pattern) || [];
      removals.push(...matches.map(m => ({ removed: m.trim(), pattern: pattern.source })));
      cleaned = cleaned.replace(pattern, '');
    }
    cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
    this.metrics.linesRemoved += removals.length;
    this.metrics.debtItemsResolved += removals.length;
    return { cleaned, removals, originalLength: code.length, cleanedLength: cleaned.length, reductionPercent: ((code.length - cleaned.length) / code.length * 100).toFixed(1) };
  }
  removeDead(code) { return this.cleanupCode(code); }
  reduceDebt(findings) {
    const weights = phiFusionWeights(findings.length || 1);
    const prioritized = (findings || []).map((f, i) => ({ ...f, priority: (f.severity || 0) * (weights[Math.min(i, weights.length - 1)] || PSI) })).sort((a, b) => b.priority - a.priority);
    return { prioritized, totalItems: prioritized.length };
  }
}
module.exports = Janitor;
