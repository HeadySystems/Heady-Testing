/**
 * Lens — System Observation & Detailed Inspection
 * Outer Ring | Warm Pool
 * @module lens
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */
const { LiquidNode, createLogger, nodeBus } = require('../../../shared/liquid-nodes');
const { PHI, PSI, FIB, fib, CSL_THRESHOLDS, cslGate, cosineSimilarity, phiFusionWeights, SIZING, RELEVANCE_GATES } = require('../../../shared/phi-constants');

class Lens extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'LENS', ring: 'outer', pool: 'warm', ...config });
    this.observations = [];
    this.maxObservations = SIZING.QUEUE_DEPTH;
  }
  async execute(task) { return task.type === 'performance' ? this.measurePerformance(task.service) : this.inspect(task.component || task); }
  inspect(component) {
    const observation = { component: component.name || 'unknown', state: component.state || 'unknown', coherence: component.coherenceScore || 0, metrics: component.metrics || {}, health: component.health ? component.health() : null, inspectedAt: new Date().toISOString(), inspectedBy: this.name };
    this._recordObservation(observation);
    return observation;
  }
  measurePerformance(service) {
    const start = process.hrtime.bigint();
    const metrics = { responseTimeNs: Number(process.hrtime.bigint() - start), memoryUsageMb: Math.round(process.memoryUsage().heapUsed / 1024 / 1024 * 100) / 100, uptimeS: Math.round(process.uptime()), cpuUsage: process.cpuUsage(), timestamp: new Date().toISOString() };
    return { service: service?.name || 'system', metrics, measuredBy: this.name };
  }
  generateReport(filter = {}) {
    let obs = [...this.observations];
    if (filter.since) obs = obs.filter(o => new Date(o.inspectedAt) >= new Date(filter.since));
    if (filter.component) obs = obs.filter(o => o.component === filter.component);
    return { observations: obs, total: obs.length, reportedBy: this.name, generatedAt: new Date().toISOString() };
  }
  _recordObservation(obs) { this.observations.push(obs); while (this.observations.length > this.maxObservations) this.observations.shift(); }
}
module.exports = Lens;
