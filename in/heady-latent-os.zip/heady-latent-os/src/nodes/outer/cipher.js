/**
 * Cipher — Encryption, PQC & Cryptographic Operations
 * Outer Ring | Warm Pool
 * @module cipher
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */
const { LiquidNode, createLogger, nodeBus } = require('../../../shared/liquid-nodes');
const { PHI, PSI, FIB, fib, CSL_THRESHOLDS, cslGate, cosineSimilarity, phiFusionWeights, SIZING, RELEVANCE_GATES } = require('../../../shared/phi-constants');

class Cipher extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'CIPHER', ring: 'outer', pool: 'warm', ...config });
    this.crypto = require('crypto');
    this.algorithms = { symmetric: 'aes-256-gcm', hash: 'sha256', hmac: 'sha256' };
  }
  async execute(task) {
    if (task.type === 'hash') return this.hashWithChain(task.data, task.prevHash);
    if (task.type === 'encrypt') return this.encrypt(task.data, task.key);
    if (task.type === 'decrypt') return this.decrypt(task.encrypted, task.key, task.iv, task.tag);
    return this.generateKeys(task.algorithm);
  }
  encrypt(data, key) {
    const iv = this.crypto.randomBytes(12);
    const keyBuf = typeof key === 'string' ? Buffer.from(key, 'hex') : this.crypto.randomBytes(32);
    const cipher = this.crypto.createCipheriv(this.algorithms.symmetric, keyBuf, iv);
    let encrypted = cipher.update(typeof data === 'string' ? data : JSON.stringify(data), 'utf8', 'hex');
    encrypted += cipher.final('hex');
    const tag = cipher.getAuthTag();
    return { encrypted, iv: iv.toString('hex'), tag: tag.toString('hex'), algorithm: this.algorithms.symmetric };
  }
  decrypt(encrypted, key, iv, tag) {
    const decipher = this.crypto.createDecipheriv(this.algorithms.symmetric, Buffer.from(key, 'hex'), Buffer.from(iv, 'hex'));
    decipher.setAuthTag(Buffer.from(tag, 'hex'));
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return { decrypted };
  }
  hashWithChain(data, prevHash = '') {
    const payload = prevHash + (typeof data === 'string' ? data : JSON.stringify(data));
    const hash = this.crypto.createHash(this.algorithms.hash).update(payload).digest('hex');
    return { hash, prevHash, algorithm: this.algorithms.hash, timestamp: new Date().toISOString() };
  }
  generateKeys(algorithm = 'rsa') {
    if (algorithm === 'rsa') {
      const { publicKey, privateKey } = this.crypto.generateKeyPairSync('rsa', { modulusLength: 2048, publicKeyEncoding: { type: 'spki', format: 'pem' }, privateKeyEncoding: { type: 'pkcs8', format: 'pem' } });
      return { publicKey, privateKey: '[REDACTED]', algorithm: 'RSA-2048', generatedBy: this.name };
    }
    return { key: this.crypto.randomBytes(32).toString('hex'), algorithm: 'AES-256', generatedBy: this.name };
  }
}
module.exports = Cipher;
