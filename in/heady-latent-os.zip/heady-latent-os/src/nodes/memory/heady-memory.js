/**
 * HeadyMemory — Vector Memory — 384D RAM-first Store
 * Memory Layer | Hot Pool
 * @module heady-memory
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */
const { LiquidNode, createLogger, nodeBus } = require('../../../shared/liquid-nodes');
const { PHI, PSI, FIB, fib, CSL_THRESHOLDS, cslGate, cosineSimilarity, phiFusionWeights, SIZING } = require('../../../shared/phi-constants');

class HeadyMemory extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyMemory', ring: 'inner', pool: 'hot', ...config });
    this.store = new Map();
    this.maxSize = SIZING.LARGE_CACHE; // 6765
    this.dimensions = 384;
    this.syncIntervalMs = Math.round(PHI * 1000 * fib(5)); // ~8090ms
    this.syncTimer = null;
    nodeBus.on('memory:query', (data) => this._handleQuery(data));
    this.cleanupStack.push(() => { nodeBus.removeAllListeners('memory:query'); if (this.syncTimer) clearInterval(this.syncTimer); });
  }
  async init() {
    await super.init();
    this.syncTimer = setInterval(() => this._syncToPgvector(), this.syncIntervalMs);
    this.cleanupStack.push(() => clearInterval(this.syncTimer));
  }
  async execute(task) {
    if (task.type === 'store') return this.storeEntry(task.key, task.embedding, task.metadata);
    if (task.type === 'search') return this.search(task.embedding, task.threshold);
    return this.retrieve(task.query || task.key, task.topK);
  }
  storeEntry(key, embedding, metadata = {}) {
    if (!key || !embedding) return { stored: false, error: 'Missing key or embedding' };
    if (this.store.size >= this.maxSize) { const oldest = this.store.keys().next().value; this.store.delete(oldest); }
    this.store.set(key, { embedding, metadata, storedAt: Date.now() });
    return { stored: true, key, dimensions: embedding.length, totalEntries: this.store.size };
  }
  retrieve(query, topK = fib(5)) {
    if (typeof query === 'string' && this.store.has(query)) return { results: [{ key: query, ...this.store.get(query), similarity: 1.0 }] };
    if (Array.isArray(query)) return this.search(query, CSL_THRESHOLDS.MINIMUM, topK);
    return { results: [] };
  }
  search(queryEmbedding, threshold = CSL_THRESHOLDS.MINIMUM, topK = fib(5)) {
    const results = [];
    for (const [key, entry] of this.store) {
      const sim = cosineSimilarity(queryEmbedding, entry.embedding);
      if (sim >= threshold) results.push({ key, similarity: sim, metadata: entry.metadata, storedAt: entry.storedAt });
    }
    results.sort((a, b) => b.similarity - a.similarity);
    return { results: results.slice(0, topK), totalMatches: results.length, threshold };
  }
  _handleQuery(data) {
    if (!data.embedding) return;
    const results = this.search(data.embedding, data.threshold || CSL_THRESHOLDS.MINIMUM, data.topK || fib(5));
    nodeBus.emit('memory:result', { correlationId: data.correlationId, results: results.results });
  }
  _syncToPgvector() {
    this.logger.debug({ entries: this.store.size }, 'Sync to pgvector scheduled');
  }
}
module.exports = HeadyMemory;
