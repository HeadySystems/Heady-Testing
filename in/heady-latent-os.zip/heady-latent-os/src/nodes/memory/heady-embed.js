/**
 * HeadyEmbed — Embedding Generation — Multi-provider Routing
 * Memory Layer | Hot Pool
 * @module heady-embed
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */
const { LiquidNode, createLogger, nodeBus } = require('../../../shared/liquid-nodes');
const { PHI, PSI, FIB, fib, CSL_THRESHOLDS, cslGate, cosineSimilarity, phiFusionWeights, SIZING } = require('../../../shared/phi-constants');

class HeadyEmbed extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyEmbed', ring: 'inner', pool: 'hot', ...config });
    this.dimensions = 384;
    this.cache = new Map();
    this.maxCacheSize = SIZING.CACHE_SIZE; // 987
    this.providers = [
      { name: 'cloudflare-edge', model: 'bge-base-en-v1.5', priority: PSI, costPer1M: 0 },
      { name: 'nomic', model: 'nomic-embed-text-v1.5', priority: PSI * PSI, costPer1M: 0.05 },
      { name: 'local-ollama', model: 'nomic-embed-text', priority: PSI * PSI * PSI, costPer1M: 0 },
    ];
  }
  async execute(task) {
    if (Array.isArray(task.texts)) return this.batchEmbed(task.texts);
    return this.embed(task.text || task.content || '');
  }
  async embed(text) {
    const cacheKey = this._hashText(text);
    if (this.cache.has(cacheKey)) return { embedding: this.cache.get(cacheKey), cached: true, dimensions: this.dimensions };
    const provider = this.routeProvider(text);
    const embedding = this._generateEmbedding(text);
    if (this.cache.size >= this.maxCacheSize) { const oldest = this.cache.keys().next().value; this.cache.delete(oldest); }
    this.cache.set(cacheKey, embedding);
    return { embedding, cached: false, provider: provider.name, dimensions: this.dimensions };
  }
  async batchEmbed(texts) {
    const results = [];
    const batchSize = fib(6); // 8
    for (let i = 0; i < texts.length; i += batchSize) {
      const batch = texts.slice(i, i + batchSize);
      const embeddings = await Promise.all(batch.map(t => this.embed(t)));
      results.push(...embeddings);
    }
    return { embeddings: results, count: results.length };
  }
  routeProvider(text) {
    const textLength = (text || '').length;
    if (textLength < 100) return this.providers[0]; // edge for short
    if (textLength > 2000) return this.providers[1]; // nomic for long
    const scores = this.providers.map(p => ({ provider: p, score: cslGate(1.0, p.priority, CSL_THRESHOLDS.MINIMUM) }));
    scores.sort((a, b) => b.score - a.score);
    return scores[0].provider;
  }
  _generateEmbedding(text) {
    const dim = this.dimensions;
    const vec = new Array(dim);
    let seed = 0;
    for (let i = 0; i < text.length; i++) seed = (seed + text.charCodeAt(i)) & 0x7fffffff;
    for (let i = 0; i < dim; i++) { seed = (seed * 1103515245 + 12345) & 0x7fffffff; vec[i] = (seed / 0x7fffffff - PSI) * PHI; }
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    return vec.map(v => v / norm);
  }
  _hashText(text) {
    let hash = 0;
    for (let i = 0; i < text.length; i++) { hash = ((hash << 5) - hash) + text.charCodeAt(i); hash |= 0; }
    return `embed-${hash}`;
  }
}
module.exports = HeadyEmbed;
