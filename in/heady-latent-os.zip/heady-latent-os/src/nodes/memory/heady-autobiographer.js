/**
 * HeadyAutobiographer — Event Logging & Narrative Construction
 * Memory Layer | Cold Pool
 * @module heady-autobiographer
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */
const { LiquidNode, createLogger, nodeBus } = require('../../../shared/liquid-nodes');
const { PHI, PSI, FIB, fib, CSL_THRESHOLDS, cslGate, cosineSimilarity, phiFusionWeights, SIZING } = require('../../../shared/phi-constants');

class HeadyAutobiographer extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyAutobiographer', ring: 'outer', pool: 'cold', ...config });
    this.eventLog = [];
    this.maxEvents = SIZING.HISTORY_BUFFER; // 1597
    nodeBus.on('node:transition', (data) => this.recordEvent({ type: 'transition', ...data }));
    nodeBus.on('node:drift', (data) => this.recordEvent({ type: 'drift', ...data }));
    nodeBus.on('bee:report', (data) => this.recordEvent({ type: 'bee_report', ...data }));
    this.cleanupStack.push(() => { nodeBus.removeAllListeners('node:transition'); nodeBus.removeAllListeners('node:drift'); nodeBus.removeAllListeners('bee:report'); });
  }
  async execute(task) {
    if (task.type === 'narrative') return this.constructNarrative(task.timeRange);
    if (task.type === 'timeline') return this.getTimeline(task.filter);
    return this.recordEvent(task.event || task);
  }
  recordEvent(event) {
    const entry = { ...event, recordedAt: new Date().toISOString(), sequenceId: this.eventLog.length };
    this.eventLog.push(entry);
    while (this.eventLog.length > this.maxEvents) this.eventLog.shift();
    return { recorded: true, sequenceId: entry.sequenceId };
  }
  constructNarrative(timeRange = {}) {
    let events = [...this.eventLog];
    if (timeRange.since) events = events.filter(e => new Date(e.recordedAt) >= new Date(timeRange.since));
    if (timeRange.until) events = events.filter(e => new Date(e.recordedAt) <= new Date(timeRange.until));
    const summary = { totalEvents: events.length, types: {}, firstEvent: events[0]?.recordedAt, lastEvent: events[events.length - 1]?.recordedAt };
    for (const e of events) { summary.types[e.type] = (summary.types[e.type] || 0) + 1; }
    return { narrative: summary, events: events.slice(-fib(8)), constructedBy: this.name };
  }
  getTimeline(filter = {}) {
    let events = [...this.eventLog];
    if (filter.type) events = events.filter(e => e.type === filter.type);
    if (filter.node) events = events.filter(e => e.node === filter.node);
    return { timeline: events, total: events.length };
  }
}
module.exports = HeadyAutobiographer;
