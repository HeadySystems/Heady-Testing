/**
 * HCFullPipeline — 8-Stage Execution Engine
 * The core pipeline that every request flows through.
 *
 * Stages:
 * 1. Context Assembly    → HeadyBrains
 * 2. Intent Classification → HeadyConductor
 * 3. Node Selection      → CSL-scored routing
 * 4. Execution           → Parallel/sequential activation
 * 5. Quality Gate        → HeadyCheck
 * 6. Assurance Gate      → HeadyAssure
 * 7. Pattern Capture     → HeadyPatterns
 * 8. Story Update        → HeadyAutobiographer
 *
 * @module hc-full-pipeline
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, ConductorNode, createLogger, nodeBus,
} = require('../../shared/liquid-nodes');

const {
  PHI, PSI, fib,
  CSL_THRESHOLDS, cslGate, cosineSimilarity,
  phiFusionWeights, phiBackoff,
  SIZING,
} = require('../../shared/phi-constants');

/** Pipeline stage status */
const STAGE_STATUS = Object.freeze({
  PENDING:  'pending',
  RUNNING:  'running',
  PASSED:   'passed',
  FAILED:   'failed',
  SKIPPED:  'skipped',
});

class HCFullPipeline extends LiquidNode {
  /**
   * @param {Object} config
   * @param {Object} config.nodes - Registry of all available nodes
   */
  constructor(config = {}) {
    super({
      name: 'HCFullPipeline',
      ring: 'inner',
      pool: 'hot',
      domain: config.domain || 'headyme.com',
      ...config,
    });

    this.nodes = config.nodes || {};
    this.maxRetries = fib(4); // 3
    this.maxConcurrentExecutions = fib(6); // 8
    this.pipelineHistory = [];
    this.maxHistory = SIZING.QUEUE_DEPTH; // 233
  }

  /**
   * Execute the full 8-stage pipeline.
   * @param {Object} task - Input task
   * @returns {Promise<Object>} Pipeline result
   */
  async execute(task) {
    const pipelineId = `hcfp-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
    const correlationId = task.id || pipelineId;

    this.logger.info({ pipelineId, correlationId, taskType: task.type }, 'HCFP started');

    const pipelineState = {
      id: pipelineId,
      correlationId,
      task,
      stages: [],
      startedAt: new Date().toISOString(),
      completedAt: null,
      status: 'running',
    };

    try {
      // Stage 1: Context Assembly
      const context = await this._runStage(pipelineState, 'context_assembly', async () => {
        const brains = this.nodes.HeadyBrains;
        if (!brains) return { entries: [], avgRelevance: 0 };
        return brains.execute({ ...task, id: correlationId });
      });

      // Stage 2: Intent Classification
      const classification = await this._runStage(pipelineState, 'intent_classification', async () => {
        return this._classifyIntent(context || task);
      });

      // Stage 3: Node Selection
      const selectedNodes = await this._runStage(pipelineState, 'node_selection', async () => {
        return this._selectNodes(classification, task);
      });

      // Stage 4: Execution
      const executionResult = await this._runStage(pipelineState, 'execution', async () => {
        return this._executeOnNodes(selectedNodes, { ...task, context, classification });
      });

      // Stage 5: Quality Gate
      const qualityResult = await this._runStage(pipelineState, 'quality_gate', async () => {
        const check = this.nodes.HeadyCheck;
        if (!check) return { passed: true, score: 1.0 };
        return check.execute({ output: executionResult, spec: task.spec || {} });
      });

      // Stage 6: Assurance Gate
      const assuranceResult = await this._runStage(pipelineState, 'assurance_gate', async () => {
        if (!qualityResult?.passed) return { certified: false, reason: 'Quality gate failed' };
        const assure = this.nodes.HeadyAssure;
        if (!assure) return { certified: true };
        return assure.execute({ artifact: { ...executionResult, healthEndpoint: true, errorHandler: true, structuredLogs: true } });
      });

      // Stage 7: Pattern Capture
      await this._runStage(pipelineState, 'pattern_capture', async () => {
        const patterns = this.nodes.HeadyPatterns;
        if (!patterns) return { recorded: false };
        return patterns.execute({
          type: 'learn',
          pattern: {
            id: pipelineId,
            taskType: task.type,
            nodesUsed: selectedNodes.map(n => n.name || n),
            quality: qualityResult?.score || 0,
            certified: assuranceResult?.certified || false,
          },
        });
      });

      // Stage 8: Story Update
      await this._runStage(pipelineState, 'story_update', async () => {
        const autobiographer = this.nodes.HeadyAutobiographer;
        if (!autobiographer) return { recorded: false };
        return autobiographer.recordEvent({
          type: 'pipeline_complete',
          pipelineId,
          taskType: task.type,
          stageCount: pipelineState.stages.length,
          allPassed: pipelineState.stages.every(s => s.status === STAGE_STATUS.PASSED),
        });
      });

      pipelineState.status = 'completed';
      pipelineState.completedAt = new Date().toISOString();
      pipelineState.result = {
        execution: executionResult,
        quality: qualityResult,
        assurance: assuranceResult,
      };

      this._recordHistory(pipelineState);

      this.logger.info({
        pipelineId,
        duration: Date.now() - new Date(pipelineState.startedAt).getTime(),
        stagesRun: pipelineState.stages.length,
        allPassed: pipelineState.stages.every(s => s.status === STAGE_STATUS.PASSED),
      }, 'HCFP completed');

      return pipelineState;

    } catch (err) {
      pipelineState.status = 'failed';
      pipelineState.error = err.message;
      pipelineState.completedAt = new Date().toISOString();
      this._recordHistory(pipelineState);
      this.logger.error({ pipelineId, error: err.message }, 'HCFP failed');
      throw err;
    }
  }

  /**
   * Run a single pipeline stage with timing and error handling.
   * @param {Object} pipelineState - Current pipeline state
   * @param {string} stageName - Stage name
   * @param {Function} fn - Stage execution function
   * @returns {Promise<*>} Stage result
   * @private
   */
  async _runStage(pipelineState, stageName, fn) {
    const stage = {
      name: stageName,
      status: STAGE_STATUS.RUNNING,
      startedAt: new Date().toISOString(),
      completedAt: null,
      result: null,
      error: null,
    };
    pipelineState.stages.push(stage);

    try {
      const result = await fn();
      stage.status = STAGE_STATUS.PASSED;
      stage.result = result;
      stage.completedAt = new Date().toISOString();
      stage.durationMs = new Date(stage.completedAt) - new Date(stage.startedAt);

      this.logger.info({
        pipelineId: pipelineState.id,
        stage: stageName,
        durationMs: stage.durationMs,
      }, 'Stage passed');

      return result;
    } catch (err) {
      stage.status = STAGE_STATUS.FAILED;
      stage.error = err.message;
      stage.completedAt = new Date().toISOString();
      stage.durationMs = new Date(stage.completedAt) - new Date(stage.startedAt);

      this.logger.error({
        pipelineId: pipelineState.id,
        stage: stageName,
        error: err.message,
      }, 'Stage failed');

      throw err;
    }
  }

  /**
   * Classify task intent for routing.
   * @param {Object} task - Task with context
   * @returns {Object} Classification result
   * @private
   */
  _classifyIntent(task) {
    const typeMap = {
      code_generation: { pool: 'hot', primaryNodes: ['JULES', 'BUILDER'] },
      code_review: { pool: 'hot', primaryNodes: ['OBSERVER'] },
      security_audit: { pool: 'hot', primaryNodes: ['MURPHY', 'SENTINEL'] },
      architecture: { pool: 'hot', primaryNodes: ['ATLAS', 'PYTHIA'] },
      research: { pool: 'warm', primaryNodes: ['SOPHIA'] },
      documentation: { pool: 'warm', primaryNodes: ['ATLAS'] },
      creative: { pool: 'warm', primaryNodes: ['MUSE', 'NOVA'] },
      quick_task: { pool: 'hot', primaryNodes: ['HeadyBrains'] },
      cleanup: { pool: 'cold', primaryNodes: ['JANITOR', 'HeadyMaid'] },
      analytics: { pool: 'cold', primaryNodes: ['HeadyPatterns', 'HeadyMC'] },
    };

    const taskType = task.type || task.intent?.type || 'quick_task';
    const classification = typeMap[taskType] || typeMap.quick_task;

    return {
      taskType,
      ...classification,
      confidence: task.intent?.confidence || PSI,
      classifiedAt: new Date().toISOString(),
    };
  }

  /**
   * Select nodes for task execution via CSL scoring.
   * @param {Object} classification - Intent classification
   * @param {Object} task - Original task
   * @returns {Object[]} Selected nodes
   * @private
   */
  _selectNodes(classification, task) {
    const candidates = classification.primaryNodes || [];
    const selected = [];

    for (const nodeName of candidates) {
      const node = this.nodes[nodeName];
      if (node && typeof node.canAcceptWork === 'function' && node.canAcceptWork()) {
        const relevance = task.embedding && node.embedding
          ? cosineSimilarity(task.embedding, node.embedding)
          : PSI;
        const gated = cslGate(1.0, relevance, CSL_THRESHOLDS.MINIMUM);
        selected.push({ node, name: nodeName, relevance, gated });
      } else if (node) {
        selected.push({ node, name: nodeName, relevance: PSI, gated: PSI });
      }
    }

    selected.sort((a, b) => b.gated - a.gated);
    return selected;
  }

  /**
   * Execute task on selected nodes (parallel if independent).
   * @param {Object[]} nodes - Selected nodes
   * @param {Object} task - Task to execute
   * @returns {Promise<Object>} Execution results
   * @private
   */
  async _executeOnNodes(nodes, task) {
    if (nodes.length === 0) {
      return { executed: false, reason: 'No available nodes' };
    }

    // Execute on primary node
    const primary = nodes[0];
    const result = await primary.node.execute(task);

    return {
      executed: true,
      primaryNode: primary.name,
      result,
      nodesConsidered: nodes.length,
      executedAt: new Date().toISOString(),
    };
  }

  /**
   * Record pipeline execution in history.
   * @param {Object} state - Pipeline state
   * @private
   */
  _recordHistory(state) {
    this.pipelineHistory.push({
      id: state.id,
      taskType: state.task?.type,
      status: state.status,
      stageCount: state.stages.length,
      duration: state.completedAt
        ? new Date(state.completedAt) - new Date(state.startedAt)
        : null,
      completedAt: state.completedAt,
    });

    while (this.pipelineHistory.length > this.maxHistory) {
      this.pipelineHistory.shift();
    }
  }
}

module.exports = HCFullPipeline;
