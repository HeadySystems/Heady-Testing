/**
 * HeadyBee Swarm Factory & Registry
 * Creates, manages, and coordinates bee workers.
 *
 * @module bee-factory
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  BeeNode, createLogger, nodeBus,
} = require('../../shared/liquid-nodes');

const {
  PHI, PSI, fib,
  CSL_THRESHOLDS, cslGate, cosineSimilarity,
  phiFusionWeights,
  SIZING,
} = require('../../shared/phi-constants');

/** Bee specialization templates */
const BEE_TEMPLATES = Object.freeze({
  'agents-bee':           { pool: 'hot',  description: 'Agent creation and routing' },
  'auth-provider-bee':    { pool: 'hot',  description: 'Authentication provider orchestration' },
  'auto-success-bee':     { pool: 'hot',  description: 'Automated success pipeline execution' },
  'brain-bee':            { pool: 'hot',  description: 'LLM provider routing and model selection' },
  'config-bee':           { pool: 'warm', description: 'Configuration management and validation' },
  'connectors-bee':       { pool: 'warm', description: 'External service connector management' },
  'creative-bee':         { pool: 'warm', description: 'Creative content generation' },
  'deployment-bee':       { pool: 'warm', description: 'Cloud deployment automation' },
  'device-provisioner-bee': { pool: 'warm', description: 'Device onboarding and provisioning' },
  'documentation-bee':    { pool: 'warm', description: 'Auto-documentation generation' },
  'engines-bee':          { pool: 'hot',  description: 'Engine orchestration and lifecycle' },
  'governance-bee':       { pool: 'governance', description: 'Policy enforcement and compliance' },
  'health-bee':           { pool: 'governance', description: 'Health probe execution and reporting' },
  'intelligence-bee':     { pool: 'warm', description: 'Intelligence gathering and analysis' },
  'lifecycle-bee':        { pool: 'governance', description: 'Service lifecycle management' },
  'mcp-bee':              { pool: 'hot',  description: 'MCP protocol tool execution' },
  'memory-bee':           { pool: 'hot',  description: 'Memory operations (store, retrieve, embed)' },
  'middleware-bee':        { pool: 'warm', description: 'Middleware chain management' },
  'midi-bee':             { pool: 'cold', description: 'MIDI event processing' },
  'ops-bee':              { pool: 'warm', description: 'Operations automation' },
  'orchestration-bee':    { pool: 'hot',  description: 'Multi-bee orchestration coordination' },
  'pipeline-bee':         { pool: 'hot',  description: 'Pipeline stage execution' },
  'providers-bee':        { pool: 'warm', description: 'Provider health and failover' },
  'refactor-bee':         { pool: 'warm', description: 'Code refactoring automation' },
  'resilience-bee':       { pool: 'warm', description: 'Resilience pattern enforcement' },
  'routes-bee':           { pool: 'warm', description: 'API route management' },
  'security-bee':         { pool: 'governance', description: 'Security scanning and enforcement' },
  'services-bee':         { pool: 'warm', description: 'Service catalog management' },
  'sync-projection-bee':  { pool: 'cold', description: 'Repo projection synchronization' },
  'telemetry-bee':        { pool: 'warm', description: 'Telemetry collection and export' },
  'trading-bee':          { pool: 'hot',  description: 'Financial trading operations' },
  'vector-ops-bee':       { pool: 'hot',  description: 'Vector space operations' },
  'vector-template-bee':  { pool: 'warm', description: 'Vector template management' },
});

/**
 * Dynamic bee worker — extends BeeNode with template-specific behavior.
 */
class DynamicBee extends BeeNode {
  constructor(template, config = {}) {
    super({
      name: config.name || template,
      pool: BEE_TEMPLATES[template]?.pool || 'warm',
      ...config,
    });
    this.template = template;
    this.description = BEE_TEMPLATES[template]?.description || 'General worker';
    this.taskHistory = [];
    this.maxTaskHistory = fib(8); // 21
  }

  async execute(task) {
    const start = Date.now();
    this.logger.info({ template: this.template, taskId: task?.id }, 'Bee executing');

    const result = {
      bee: this.name,
      template: this.template,
      task: task?.type || 'generic',
      status: 'completed',
      timestamp: new Date().toISOString(),
    };

    this.taskHistory.push({
      taskId: task?.id,
      duration: Date.now() - start,
      completedAt: new Date().toISOString(),
    });

    while (this.taskHistory.length > this.maxTaskHistory) {
      this.taskHistory.shift();
    }

    return result;
  }
}

/**
 * BeeFactory — Creates and manages bee swarms.
 */
class BeeFactory {
  constructor() {
    this.logger = createLogger('BeeFactory');
    this.registry = new Map();
    this.activeBees = new Map();
    this.maxActiveBees = SIZING.MAX_ENTITIES; // 55
    this.metrics = {
      beesSpawned: 0,
      beesRetired: 0,
      tasksProcessed: 0,
    };

    // Register all templates
    for (const [name, template] of Object.entries(BEE_TEMPLATES)) {
      this.registry.set(name, template);
    }

    this.logger.info({ templates: this.registry.size }, 'BeeFactory initialized');
  }

  /**
   * Spawn a bee worker from template.
   * @param {string} template - Bee template name
   * @param {Object} [config={}] - Override configuration
   * @returns {Promise<DynamicBee>} Spawned bee instance
   */
  async spawn(template, config = {}) {
    if (!this.registry.has(template)) {
      throw new Error(`Unknown bee template: ${template}`);
    }

    if (this.activeBees.size >= this.maxActiveBees) {
      this.logger.warn({ active: this.activeBees.size, max: this.maxActiveBees }, 'Bee limit reached, retiring oldest');
      await this._retireOldest();
    }

    const instanceId = `${template}-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const bee = new DynamicBee(template, { ...config, name: instanceId });
    await bee.spawn({ factoryId: 'main' });

    this.activeBees.set(instanceId, bee);
    this.metrics.beesSpawned++;

    this.logger.info({ instanceId, template, activeBees: this.activeBees.size }, 'Bee spawned');
    return bee;
  }

  /**
   * Execute a task on a specific bee type, spawning if needed.
   * @param {string} template - Bee template
   * @param {Object} task - Task to execute
   * @returns {Promise<Object>} Task result
   */
  async executeOn(template, task) {
    const bee = await this.spawn(template);

    try {
      const result = await bee.execute(task);
      await bee.report(result);
      this.metrics.tasksProcessed++;
      return result;
    } finally {
      await this.retire(bee.name);
    }
  }

  /**
   * Execute tasks across a swarm of bees in parallel.
   * @param {Array<{ template: string, task: Object }>} swarmTasks - Tasks with template assignments
   * @returns {Promise<Object[]>} All results
   */
  async swarmExecute(swarmTasks) {
    const maxConcurrent = fib(6); // 8
    const results = [];

    for (let i = 0; i < swarmTasks.length; i += maxConcurrent) {
      const batch = swarmTasks.slice(i, i + maxConcurrent);
      const batchResults = await Promise.all(
        batch.map(({ template, task }) => this.executeOn(template, task))
      );
      results.push(...batchResults);
    }

    return results;
  }

  /**
   * Retire a bee and clean up resources.
   * @param {string} instanceId - Bee instance ID
   * @returns {Promise<void>}
   */
  async retire(instanceId) {
    const bee = this.activeBees.get(instanceId);
    if (!bee) return;

    await bee.retire();
    this.activeBees.delete(instanceId);
    this.metrics.beesRetired++;

    this.logger.info({ instanceId, activeBees: this.activeBees.size }, 'Bee retired');
  }

  /**
   * Retire the oldest active bee.
   * @private
   */
  async _retireOldest() {
    const oldestId = this.activeBees.keys().next().value;
    if (oldestId) await this.retire(oldestId);
  }

  /**
   * Get swarm health status.
   * @returns {Object} Swarm status
   */
  health() {
    const beeStatuses = [];
    for (const [id, bee] of this.activeBees) {
      beeStatuses.push({
        id,
        template: bee.template,
        state: bee.state,
        coherence: bee.coherenceScore,
      });
    }

    return {
      factory: 'BeeFactory',
      templates: this.registry.size,
      activeBees: this.activeBees.size,
      maxBees: this.maxActiveBees,
      metrics: { ...this.metrics },
      bees: beeStatuses,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Get registered templates.
   * @returns {Object} Template registry
   */
  getTemplates() {
    const templates = {};
    for (const [name, info] of this.registry) {
      templates[name] = { ...info };
    }
    return templates;
  }
}

module.exports = { BeeFactory, DynamicBee, BEE_TEMPLATES };
