/**
 * Colab Runtime Bridge — Connects 3 Colab Pro+ Runtimes to the Liquid Gateway
 *
 * Runtime 1: vector.headyos.com (port 3301) — Vector Memory & Embeddings
 * Runtime 2: llm.headyos.com (port 3302) — LLM Inference & Agents
 * Runtime 3: train.headyos.com (port 3303) — Training & Analytics
 *
 * @module colab-bridge
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, CircuitBreaker, createLogger, nodeBus,
} = require('../../shared/liquid-nodes');

const {
  PHI, PSI, fib,
  CSL_THRESHOLDS, cslGate,
  phiBackoff, phiAdaptiveInterval,
  SIZING,
} = require('../../shared/phi-constants');

const http = require('http');

/** Runtime endpoint configuration */
const RUNTIME_ENDPOINTS = Object.freeze({
  VECTOR_OPS: {
    id: 'heady-vector-runtime',
    host: process.env.VECTOR_RUNTIME_HOST || 'vector.headyos.com',
    port: parseInt(process.env.VECTOR_RUNTIME_PORT || '3301', 10),
    healthPort: parseInt(process.env.VECTOR_HEALTH_PORT || '3311', 10),
    capabilities: ['embed', 'vectorize', 'search', 'similarity'],
    weight: PSI * PSI, // ~0.382
  },
  LLM_INFERENCE: {
    id: 'heady-llm-runtime',
    host: process.env.LLM_RUNTIME_HOST || 'llm.headyos.com',
    port: parseInt(process.env.LLM_RUNTIME_PORT || '3302', 10),
    healthPort: parseInt(process.env.LLM_HEALTH_PORT || '3312', 10),
    capabilities: ['chat', 'generate', 'code', 'classify', 'agent'],
    weight: PSI, // ~0.618
  },
  TRAINING: {
    id: 'heady-training-runtime',
    host: process.env.TRAINING_RUNTIME_HOST || 'train.headyos.com',
    port: parseInt(process.env.TRAINING_RUNTIME_PORT || '3303', 10),
    healthPort: parseInt(process.env.TRAINING_HEALTH_PORT || '3313', 10),
    capabilities: ['train', 'finetune', 'evaluate', 'analytics', 'batch'],
    weight: PSI * PSI * PSI, // ~0.236
  },
});

class ColabBridge extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'ColabBridge',
      ring: 'inner',
      pool: 'hot',
      domain: config.domain || 'headyos.com',
      ...config,
    });

    this.endpoints = { ...RUNTIME_ENDPOINTS };
    this.healthStatus = {};
    this.circuitBreakers = {};
    this.healthCheckIntervalMs = Math.round(PHI * 1000 * fib(5)); // ~8090ms
    this.healthTimer = null;

    // Create circuit breakers for each runtime
    for (const [name, endpoint] of Object.entries(this.endpoints)) {
      this.circuitBreakers[name] = new CircuitBreaker({
        name: `CB:${name}`,
        failureThreshold: fib(5), // 5
        halfOpenProbes: fib(3), // 2
      });
    }
  }

  /**
   * Initialize the bridge and start health monitoring.
   * @returns {Promise<void>}
   */
  async init() {
    await super.init();

    // Initial health check
    await this.checkAllHealth();

    // Periodic health monitoring
    this.healthTimer = setInterval(() => this.checkAllHealth(), this.healthCheckIntervalMs);
    this.cleanupStack.push(() => clearInterval(this.healthTimer));

    this.logger.info({
      runtimes: Object.keys(this.endpoints).length,
      healthInterval: this.healthCheckIntervalMs,
    }, 'ColabBridge initialized');
  }

  /**
   * Route a compute task to the appropriate runtime.
   * @param {Object} task - Task to route
   * @returns {Promise<Object>} Execution result
   */
  async execute(task) {
    const taskType = task.computeType || task.type || 'chat';
    const runtime = this._selectRuntime(taskType);

    if (!runtime) {
      this.logger.error({ taskType }, 'No runtime available for task type');
      return { success: false, error: `No runtime handles task type: ${taskType}` };
    }

    const runtimeName = runtime.name;
    const endpoint = runtime.endpoint;

    this.logger.info({
      taskType,
      runtime: runtimeName,
      host: endpoint.host,
    }, 'Routing to Colab runtime');

    try {
      const result = await this.circuitBreakers[runtimeName].exec(async () => {
        return this._sendToRuntime(endpoint, task);
      });
      return { success: true, runtime: runtimeName, result };
    } catch (err) {
      this.logger.error({
        runtime: runtimeName,
        error: err.message,
      }, 'Runtime execution failed');
      return { success: false, runtime: runtimeName, error: err.message };
    }
  }

  /**
   * Check health of all 3 runtimes.
   * @returns {Promise<Object>} Health status map
   */
  async checkAllHealth() {
    const results = {};
    for (const [name, endpoint] of Object.entries(this.endpoints)) {
      results[name] = await this._checkHealth(name, endpoint);
    }
    this.healthStatus = results;

    const healthy = Object.values(results).filter(r => r.status === 'healthy').length;
    this.logger.info({
      healthy,
      total: Object.keys(results).length,
    }, 'Health check complete');

    return results;
  }

  /**
   * Get bridge status including all runtime health.
   * @returns {Object} Bridge status
   */
  bridgeHealth() {
    const runtimeStatuses = {};
    for (const [name, endpoint] of Object.entries(this.endpoints)) {
      runtimeStatuses[name] = {
        id: endpoint.id,
        host: endpoint.host,
        port: endpoint.port,
        capabilities: endpoint.capabilities,
        weight: endpoint.weight,
        health: this.healthStatus[name] || { status: 'unknown' },
        circuitBreaker: this.circuitBreakers[name]?.health() || { state: 'unknown' },
      };
    }

    return {
      bridge: this.name,
      state: this.state,
      coherence: this.coherenceScore,
      runtimes: runtimeStatuses,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Select the best runtime for a given task type.
   * @param {string} taskType - Task type
   * @returns {{ name: string, endpoint: Object } | null}
   * @private
   */
  _selectRuntime(taskType) {
    for (const [name, endpoint] of Object.entries(this.endpoints)) {
      if (endpoint.capabilities.includes(taskType)) {
        const health = this.healthStatus[name];
        const cb = this.circuitBreakers[name];
        if (cb?.state !== 'open' || (health?.status !== 'unhealthy')) {
          return { name, endpoint };
        }
      }
    }
    // Fallback to LLM runtime for unmatched tasks
    return { name: 'LLM_INFERENCE', endpoint: this.endpoints.LLM_INFERENCE };
  }

  /**
   * Send a request to a Colab runtime.
   * @param {Object} endpoint - Runtime endpoint config
   * @param {Object} task - Task payload
   * @returns {Promise<Object>} Response data
   * @private
   */
  async _sendToRuntime(endpoint, task) {
    return new Promise((resolve, reject) => {
      const payload = JSON.stringify(task);
      const options = {
        hostname: endpoint.host,
        port: endpoint.port,
        path: '/execute',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload),
          'X-Heady-Runtime': endpoint.id,
          'X-Correlation-ID': task.id || `bridge-${Date.now()}`,
        },
        timeout: Math.round(PHI * 1000 * fib(8)), // ~33978ms
      };

      const req = http.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          try {
            resolve(JSON.parse(data));
          } catch {
            resolve({ raw: data });
          }
        });
      });

      req.on('error', reject);
      req.on('timeout', () => {
        req.destroy();
        reject(new Error(`Timeout connecting to ${endpoint.host}:${endpoint.port}`));
      });

      req.write(payload);
      req.end();
    });
  }

  /**
   * Check health of a single runtime.
   * @param {string} name - Runtime name
   * @param {Object} endpoint - Runtime endpoint
   * @returns {Promise<Object>} Health result
   * @private
   */
  async _checkHealth(name, endpoint) {
    return new Promise((resolve) => {
      const options = {
        hostname: endpoint.host,
        port: endpoint.healthPort,
        path: '/health',
        method: 'GET',
        timeout: Math.round(PHI * 3000), // ~4854ms
      };

      const req = http.request(options, (res) => {
        let data = '';
        res.on('data', (chunk) => data += chunk);
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            resolve({ status: 'healthy', runtime: name, data: parsed, checkedAt: new Date().toISOString() });
          } catch {
            resolve({ status: 'unhealthy', runtime: name, error: 'Invalid response', checkedAt: new Date().toISOString() });
          }
        });
      });

      req.on('error', (err) => {
        resolve({ status: 'unhealthy', runtime: name, error: err.message, checkedAt: new Date().toISOString() });
      });

      req.on('timeout', () => {
        req.destroy();
        resolve({ status: 'unhealthy', runtime: name, error: 'Timeout', checkedAt: new Date().toISOString() });
      });

      req.end();
    });
  }
}

module.exports = { ColabBridge, RUNTIME_ENDPOINTS };
