/**
 * HeadyOS — Master Orchestrator
 * Wires all liquid nodes, initializes the Sacred Geometry topology,
 * and provides the unified API for the Heady Latent OS.
 *
 * @module heady-os
 * @version 4.0.0
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const {
  LiquidNode, ConductorNode, SoulNode, NodeRegistry,
  createLogger, nodeBus,
} = require('../../shared/liquid-nodes');

const {
  PHI, PSI, fib,
  CSL_THRESHOLDS, SIZING,
} = require('../../shared/phi-constants');

// ─── Inner Ring ───
const HeadyBrains = require('../nodes/inner/heady-brains');
const HeadyVinci = require('../nodes/inner/heady-vinci');
const HeadyBuddy = require('../nodes/inner/heady-buddy');

// ─── Middle Ring ───
const Jules = require('../nodes/middle/jules');
const Builder = require('../nodes/middle/builder');
const Observer = require('../nodes/middle/observer');
const Murphy = require('../nodes/middle/murphy');
const Atlas = require('../nodes/middle/atlas');
const Pythia = require('../nodes/middle/pythia');

// ─── Outer Ring ───
const Bridge = require('../nodes/outer/bridge');
const Muse = require('../nodes/outer/muse');
const Sentinel = require('../nodes/outer/sentinel');
const Nova = require('../nodes/outer/nova');
const Janitor = require('../nodes/outer/janitor');
const Sophia = require('../nodes/outer/sophia');
const Cipher = require('../nodes/outer/cipher');
const Lens = require('../nodes/outer/lens');

// ─── Governance Shell ───
const HeadyCheck = require('../nodes/governance/heady-check');
const HeadyAssure = require('../nodes/governance/heady-assure');
const HeadyAware = require('../nodes/governance/heady-aware');
const HeadyPatterns = require('../nodes/governance/heady-patterns');
const HeadyMC = require('../nodes/governance/heady-mc');
const HeadyRisks = require('../nodes/governance/heady-risks');

// ─── Memory & Intelligence ───
const HeadyMemory = require('../nodes/memory/heady-memory');
const HeadyEmbed = require('../nodes/memory/heady-embed');
const HeadyAutobiographer = require('../nodes/memory/heady-autobiographer');
const HeadyMaid = require('../nodes/memory/heady-maid');

// ─── Pipeline & Bees ───
const HCFullPipeline = require('../pipeline/hc-full-pipeline');
const { BeeFactory } = require('../bees/bee-factory');
const { ColabBridge } = require('./colab-bridge');

class HeadyOS {
  constructor(config = {}) {
    this.logger = createLogger('HeadyOS');
    this.registry = new NodeRegistry();
    this.config = config;
    this.initialized = false;
    this.startTime = null;

    // Node instances (populated during init)
    this.nodes = {};
    this.conductor = null;
    this.soul = null;
    this.pipeline = null;
    this.beeFactory = null;
    this.colabBridge = null;
  }

  /**
   * Initialize the entire Heady Latent OS.
   * Wires all nodes, sets up the Sacred Geometry topology, starts heartbeats.
   * @returns {Promise<void>}
   */
  async init() {
    this.startTime = Date.now();
    this.logger.info({}, 'HeadyOS initialization started');

    // ════════════════════════════════════════════════════
    // Phase 1: Create all node instances
    // ════════════════════════════════════════════════════

    // Center
    this.soul = new SoulNode({});
    this.nodes.HeadySoul = this.soul;

    // Inner Ring
    this.conductor = new ConductorNode({});
    this.nodes.HeadyConductor = this.conductor;
    this.nodes.HeadyBrains = new HeadyBrains();
    this.nodes.HeadyVinci = new HeadyVinci();
    this.nodes.HeadyBuddy = new HeadyBuddy();

    // Middle Ring
    this.nodes.JULES = new Jules();
    this.nodes.BUILDER = new Builder();
    this.nodes.OBSERVER = new Observer();
    this.nodes.MURPHY = new Murphy();
    this.nodes.ATLAS = new Atlas();
    this.nodes.PYTHIA = new Pythia();

    // Outer Ring
    this.nodes.BRIDGE = new Bridge();
    this.nodes.MUSE = new Muse();
    this.nodes.SENTINEL = new Sentinel();
    this.nodes.NOVA = new Nova();
    this.nodes.JANITOR = new Janitor();
    this.nodes.SOPHIA = new Sophia();
    this.nodes.CIPHER = new Cipher();
    this.nodes.LENS = new Lens();

    // Governance Shell
    this.nodes.HeadyCheck = new HeadyCheck();
    this.nodes.HeadyAssure = new HeadyAssure();
    this.nodes.HeadyAware = new HeadyAware();
    this.nodes.HeadyPatterns = new HeadyPatterns();
    this.nodes.HeadyMC = new HeadyMC();
    this.nodes.HeadyRisks = new HeadyRisks();

    // Memory & Intelligence
    this.nodes.HeadyMemory = new HeadyMemory();
    this.nodes.HeadyEmbed = new HeadyEmbed();
    this.nodes.HeadyAutobiographer = new HeadyAutobiographer();
    this.nodes.HeadyMaid = new HeadyMaid();

    // ════════════════════════════════════════════════════
    // Phase 2: Initialize all nodes
    // ════════════════════════════════════════════════════

    const initPromises = Object.entries(this.nodes).map(async ([name, node]) => {
      try {
        await node.init();
        this.registry.register(node);
        this.logger.info({ node: name, ring: node.ring, pool: node.pool }, 'Node initialized');
      } catch (err) {
        this.logger.error({ node: name, error: err.message }, 'Node init failed');
      }
    });

    await Promise.all(initPromises);

    // ════════════════════════════════════════════════════
    // Phase 3: Register nodes with Conductor
    // ════════════════════════════════════════════════════

    for (const [name, node] of Object.entries(this.nodes)) {
      if (name !== 'HeadyConductor') {
        this.conductor.registerNode(node);
      }
    }

    // ════════════════════════════════════════════════════
    // Phase 4: Initialize Pipeline
    // ════════════════════════════════════════════════════

    this.pipeline = new HCFullPipeline({ nodes: this.nodes });
    await this.pipeline.init();
    this.registry.register(this.pipeline);

    // ════════════════════════════════════════════════════
    // Phase 5: Initialize Bee Factory
    // ════════════════════════════════════════════════════

    this.beeFactory = new BeeFactory();

    // ════════════════════════════════════════════════════
    // Phase 6: Initialize Colab Bridge
    // ════════════════════════════════════════════════════

    this.colabBridge = new ColabBridge();
    await this.colabBridge.init();
    this.registry.register(this.colabBridge);

    // ════════════════════════════════════════════════════
    // Phase 7: Wire event bus handlers
    // ════════════════════════════════════════════════════

    nodeBus.on('conductor:route', (payload) => {
      this.conductor.execute(payload).catch(err => {
        this.logger.error({ error: err.message }, 'Conductor routing failed');
      });
    });

    nodeBus.on('sentinel:alert', (alert) => {
      this.logger.warn({ alert }, 'Security alert from Sentinel');
    });

    nodeBus.on('node:drift', (data) => {
      this.logger.warn({ node: data.node, coherence: data.coherence }, 'Semantic drift detected');
    });

    this.initialized = true;

    const initDuration = Date.now() - this.startTime;
    this.logger.info({
      totalNodes: this.registry.size,
      initDurationMs: initDuration,
      beeTemplates: this.beeFactory.getTemplates ? Object.keys(this.beeFactory.getTemplates()).length : 0,
    }, 'HeadyOS initialized');
  }

  /**
   * Process a task through the full HCFP pipeline.
   * @param {Object} task - Task to process
   * @returns {Promise<Object>} Pipeline result
   */
  async process(task) {
    if (!this.initialized) throw new Error('HeadyOS not initialized. Call init() first.');
    return this.pipeline.execute(task);
  }

  /**
   * Route a task directly to HeadyConductor.
   * @param {Object} task - Task to route
   * @returns {Promise<Object>} Routing result
   */
  async route(task) {
    if (!this.initialized) throw new Error('HeadyOS not initialized.');
    return this.conductor.execute(task);
  }

  /**
   * Send a message through HeadyBuddy companion.
   * @param {string} message - User message
   * @param {string} [sessionId] - Session ID
   * @returns {Promise<Object>} Companion response
   */
  async chat(message, sessionId) {
    if (!this.initialized) throw new Error('HeadyOS not initialized.');
    return this.nodes.HeadyBuddy.execute({
      id: `chat-${Date.now()}`,
      type: 'chat',
      message,
      sessionId,
    });
  }

  /**
   * Get full system health across all nodes.
   * @returns {Object} System health
   */
  health() {
    const nodeHealth = this.registry.healthAll();
    const byRing = {};
    const byPool = {};

    for (const h of nodeHealth) {
      if (!byRing[h.ring]) byRing[h.ring] = [];
      byRing[h.ring].push({ service: h.service, status: h.status, coherence: h.coherence });

      if (!byPool[h.pool]) byPool[h.pool] = [];
      byPool[h.pool].push({ service: h.service, status: h.status });
    }

    const allHealthy = nodeHealth.every(h => h.status === 'up');
    const avgCoherence = nodeHealth.reduce((s, h) => s + (h.coherence || 0), 0) / (nodeHealth.length || 1);

    return {
      system: 'HeadyOS',
      version: '4.0.0',
      status: allHealthy ? 'healthy' : 'degraded',
      initialized: this.initialized,
      uptime: {
        ms: this.startTime ? Date.now() - this.startTime : 0,
        human: this.startTime ? this._formatUptime(Date.now() - this.startTime) : '0s',
      },
      topology: {
        totalNodes: this.registry.size,
        byRing,
        byPool,
      },
      coherence: {
        average: avgCoherence,
        threshold: CSL_THRESHOLDS.MEDIUM,
        healthy: avgCoherence >= CSL_THRESHOLDS.MEDIUM,
      },
      beeFactory: this.beeFactory?.health() || null,
      colabBridge: this.colabBridge?.bridgeHealth() || null,
      pipeline: {
        history: this.pipeline?.pipelineHistory?.length || 0,
      },
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Graceful shutdown of all systems.
   * @returns {Promise<void>}
   */
  async shutdown() {
    this.logger.info({}, 'HeadyOS shutdown initiated');

    // Retire all active bees
    if (this.beeFactory) {
      for (const [id] of this.beeFactory.activeBees) {
        await this.beeFactory.retire(id);
      }
    }

    // Shutdown all nodes in reverse registration order (LIFO)
    const nodeNames = [...this.registry.nodes.keys()].reverse();
    for (const name of nodeNames) {
      const node = this.registry.get(name);
      if (node && typeof node.shutdown === 'function') {
        try {
          await node.shutdown('HEADY_OS_SHUTDOWN');
        } catch (err) {
          this.logger.error({ node: name, error: err.message }, 'Node shutdown failed');
        }
      }
    }

    this.initialized = false;
    this.logger.info({}, 'HeadyOS shutdown complete');
  }

  /**
   * Format uptime for human readability.
   * @param {number} ms - Milliseconds
   * @returns {string}
   * @private
   */
  _formatUptime(ms) {
    const s = Math.floor(ms / 1000);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    return `${d}d ${h}h ${m}m`;
  }
}

module.exports = HeadyOS;
