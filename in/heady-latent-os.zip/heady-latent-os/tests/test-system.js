/**
 * Heady Latent OS — System Integration Tests
 * Sacred Geometry v4.0 — validates all liquid nodes, pipeline, bees, and topology
 * © 2026 HeadySystems Inc.
 *
 * Run: node tests/test-system.js
 */

'use strict';

const path = require('path');

// ─── Test Framework ───────────────────────────────────────────────────────────
let passed = 0;
let failed = 0;
const failures = [];

function assert(condition, message) {
  if (condition) {
    passed++;
    process.stdout.write('\x1b[32m✓\x1b[0m ' + message + '\n');
  } else {
    failed++;
    failures.push(message);
    process.stdout.write('\x1b[31m✗\x1b[0m ' + message + '\n');
  }
}

function assertType(value, type, message) {
  assert(typeof value === type, message + ` (expected ${type}, got ${typeof value})`);
}

function assertExists(obj, prop, message) {
  assert(obj && obj[prop] !== undefined, message);
}

function section(name) {
  process.stdout.write('\n\x1b[36m── ' + name + ' ──\x1b[0m\n');
}

// ─── Test: Phi Constants ──────────────────────────────────────────────────────
section('Phi Constants (shared/phi-constants.js)');

const phi = require('../shared/phi-constants');

assertType(phi.PHI, 'number', 'PHI is a number');
assert(Math.abs(phi.PHI - 1.618033988749895) < 1e-10, 'PHI ≈ 1.618');
assertType(phi.PSI, 'number', 'PSI is a number');
assert(Math.abs(phi.PSI - (1 / phi.PHI)) < 1e-10, 'PSI = 1/PHI');
assert(Array.isArray(phi.FIB), 'FIB is an array');
assert(phi.FIB.length >= 13, 'FIB has >= 13 entries');
assert(phi.FIB[6] === 8 || phi.FIB[5] === 8, 'FIB contains 8');

assertType(phi.CSL_THRESHOLDS, 'object', 'CSL_THRESHOLDS exists');
assertExists(phi.CSL_THRESHOLDS, 'MINIMUM', 'CSL_THRESHOLDS.MINIMUM exists');
assertExists(phi.CSL_THRESHOLDS, 'LOW', 'CSL_THRESHOLDS.LOW exists');
assertExists(phi.CSL_THRESHOLDS, 'MEDIUM', 'CSL_THRESHOLDS.MEDIUM exists');
assertExists(phi.CSL_THRESHOLDS, 'HIGH', 'CSL_THRESHOLDS.HIGH exists');
assertExists(phi.CSL_THRESHOLDS, 'CRITICAL', 'CSL_THRESHOLDS.CRITICAL exists');

assert(phi.CSL_THRESHOLDS.MINIMUM < phi.CSL_THRESHOLDS.LOW, 'MINIMUM < LOW');
assert(phi.CSL_THRESHOLDS.LOW < phi.CSL_THRESHOLDS.MEDIUM, 'LOW < MEDIUM');
assert(phi.CSL_THRESHOLDS.MEDIUM < phi.CSL_THRESHOLDS.HIGH, 'MEDIUM < HIGH');
assert(phi.CSL_THRESHOLDS.HIGH < phi.CSL_THRESHOLDS.CRITICAL, 'HIGH < CRITICAL');

assertType(phi.phiBackoff, 'function', 'phiBackoff is a function');
const b0 = phi.phiBackoff(0, 1000, 60000);
assert(b0 >= 618 && b0 <= 1382, 'phiBackoff(0) within jitter range of 1000ms');

assertType(phi.phiFusionWeights, 'function', 'phiFusionWeights is a function');
const w2 = phi.phiFusionWeights(2);
assert(w2.length === 2, 'phiFusionWeights(2) returns 2 weights');
assert(Math.abs(w2.reduce((a, b) => a + b, 0) - 1.0) < 0.01, 'Fusion weights sum to ~1.0');

if (typeof phi.phiThreshold === 'function') {
  assert(Math.abs(phi.phiThreshold(0) - 0.5) < 0.01, 'phiThreshold(0) ≈ 0.5');
  assert(Math.abs(phi.phiThreshold(2) - 0.809) < 0.01, 'phiThreshold(2) ≈ 0.809');
}

if (typeof phi.cslGate === 'function') {
  const gated = phi.cslGate(1.0, 0.95, phi.CSL_THRESHOLDS.MINIMUM);
  assert(gated > 0.5, 'cslGate with high cosine returns > 0.5');
  const lowGated = phi.cslGate(1.0, 0.1, phi.CSL_THRESHOLDS.MINIMUM);
  assert(lowGated < 0.5, 'cslGate with low cosine returns < 0.5');
}

// ─── Test: Liquid Nodes ───────────────────────────────────────────────────────
section('Liquid Nodes (shared/liquid-nodes.js)');

const nodes = require('../shared/liquid-nodes');

assertType(nodes.LiquidNode, 'function', 'LiquidNode class exists');
assertType(nodes.ConductorNode, 'function', 'ConductorNode class exists');
assertType(nodes.BeeNode, 'function', 'BeeNode class exists');
assertType(nodes.NodeRegistry, 'function', 'NodeRegistry class exists');

if (nodes.SoulNode) {
  assertType(nodes.SoulNode, 'function', 'SoulNode class exists');
}

if (nodes.CircuitBreaker) {
  assertType(nodes.CircuitBreaker, 'function', 'CircuitBreaker class exists');
  const cb = new nodes.CircuitBreaker({ name: 'test-cb' });
  assert(cb.state === 'closed' || cb.state === 'CLOSED', 'CircuitBreaker starts closed');
}

// Test LiquidNode instantiation
const testNode = new nodes.LiquidNode({
  name: 'TestNode',
  ring: 'outer',
  pool: 'warm'
});
assert(testNode.name === 'TestNode', 'LiquidNode stores name');
assert(testNode.ring === 'outer', 'LiquidNode stores ring');

// Test NodeRegistry
const registry = new nodes.NodeRegistry();
registry.register(testNode);
const found = registry.get('TestNode');
assert(found !== null && found !== undefined, 'NodeRegistry.get retrieves registered node');

// ─── Test: Inner Ring Nodes ───────────────────────────────────────────────────
section('Inner Ring Nodes');

const innerNodes = ['heady-brains', 'heady-vinci', 'heady-buddy'];
for (const name of innerNodes) {
  try {
    const mod = require(`../src/nodes/inner/${name}`);
    assert(mod !== null, `${name}.js loads without error`);
    const hasClass = typeof mod === 'function' || typeof mod.create === 'function' ||
                     typeof mod.default === 'function' || Object.keys(mod).length > 0;
    assert(hasClass, `${name}.js exports something usable`);
  } catch (err) {
    assert(false, `${name}.js loads without error — ${err.message}`);
  }
}

// ─── Test: Middle Ring Nodes ──────────────────────────────────────────────────
section('Middle Ring Nodes');

const middleNodes = ['jules', 'builder', 'observer', 'murphy', 'atlas', 'pythia'];
for (const name of middleNodes) {
  try {
    const mod = require(`../src/nodes/middle/${name}`);
    assert(mod !== null, `${name}.js loads without error`);
  } catch (err) {
    assert(false, `${name}.js loads without error — ${err.message}`);
  }
}

// ─── Test: Outer Ring Nodes ───────────────────────────────────────────────────
section('Outer Ring Nodes');

const outerNodes = ['bridge', 'muse', 'sentinel', 'nova', 'janitor', 'sophia', 'cipher', 'lens'];
for (const name of outerNodes) {
  try {
    const mod = require(`../src/nodes/outer/${name}`);
    assert(mod !== null, `${name}.js loads without error`);
  } catch (err) {
    assert(false, `${name}.js loads without error — ${err.message}`);
  }
}

// ─── Test: Governance Shell ───────────────────────────────────────────────────
section('Governance Shell Nodes');

const govNodes = ['heady-check', 'heady-assure', 'heady-aware', 'heady-patterns', 'heady-mc', 'heady-risks'];
for (const name of govNodes) {
  try {
    const mod = require(`../src/nodes/governance/${name}`);
    assert(mod !== null, `${name}.js loads without error`);
  } catch (err) {
    assert(false, `${name}.js loads without error — ${err.message}`);
  }
}

// ─── Test: Memory Layer ───────────────────────────────────────────────────────
section('Memory Layer Nodes');

const memNodes = ['heady-memory', 'heady-embed', 'heady-autobiographer', 'heady-maid'];
for (const name of memNodes) {
  try {
    const mod = require(`../src/nodes/memory/${name}`);
    assert(mod !== null, `${name}.js loads without error`);
  } catch (err) {
    assert(false, `${name}.js loads without error — ${err.message}`);
  }
}

// ─── Test: HCFullPipeline ─────────────────────────────────────────────────────
section('HCFullPipeline');

try {
  const pipeline = require('../src/pipeline/hc-full-pipeline');
  assert(pipeline !== null, 'hc-full-pipeline.js loads without error');
  const hasCreate = typeof pipeline === 'function' || typeof pipeline.create === 'function' ||
                    typeof pipeline.HCFullPipeline === 'function';
  assert(hasCreate || Object.keys(pipeline).length > 0, 'HCFullPipeline exports usable interface');
} catch (err) {
  assert(false, `hc-full-pipeline.js loads without error — ${err.message}`);
}

// ─── Test: Bee Factory ────────────────────────────────────────────────────────
section('Bee Factory');

try {
  const beeFactory = require('../src/bees/bee-factory');
  assert(beeFactory !== null, 'bee-factory.js loads without error');
  if (typeof beeFactory.listTemplates === 'function') {
    const templates = beeFactory.listTemplates();
    assert(Array.isArray(templates), 'listTemplates returns array');
    assert(templates.length >= 30, `Bee factory has ${templates.length} templates (need >= 30)`);
  } else if (typeof beeFactory.templates === 'object') {
    const count = Object.keys(beeFactory.templates).length;
    assert(count >= 30, `Bee factory has ${count} templates (need >= 30)`);
  }
} catch (err) {
  assert(false, `bee-factory.js loads without error — ${err.message}`);
}

// ─── Test: Colab Bridge ───────────────────────────────────────────────────────
section('Colab Bridge');

try {
  const bridge = require('../src/core/colab-bridge');
  assert(bridge !== null, 'colab-bridge.js loads without error');
} catch (err) {
  assert(false, `colab-bridge.js loads without error — ${err.message}`);
}

// ─── Test: Heady OS Core ─────────────────────────────────────────────────────
section('Heady OS Core');

try {
  const headyOS = require('../src/core/heady-os');
  assert(headyOS !== null, 'heady-os.js loads without error');
  if (typeof headyOS.create === 'function' || typeof headyOS === 'function') {
    assert(true, 'HeadyOS exports create function or constructor');
  } else if (typeof headyOS.HeadyOS === 'function') {
    assert(true, 'HeadyOS exports HeadyOS class');
  } else {
    assert(Object.keys(headyOS).length > 0, 'HeadyOS exports something');
  }
} catch (err) {
  assert(false, `heady-os.js loads without error — ${err.message}`);
}

// ─── Test: Server ─────────────────────────────────────────────────────────────
section('Server Module');

// Verify server.js is syntactically valid by parsing it
try {
  const fs = require('fs');
  const serverSource = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf-8');
  assert(serverSource.length > 1000, 'server.js has substantial content');
  assert(serverSource.includes('express'), 'server.js uses express');
  assert(serverSource.includes('/health'), 'server.js has /health endpoint');
  assert(serverSource.includes('CORS'), 'server.js configures CORS');
  assert(!serverSource.includes('localhost'), 'server.js has no hardcoded localhost');
  assert(!serverSource.includes('127.0.0.1'), 'server.js has no hardcoded 127.0.0.1');
} catch (err) {
  assert(false, `server.js is readable — ${err.message}`);
}

// ─── Test: Package.json ───────────────────────────────────────────────────────
section('Package Configuration');

try {
  const pkg = require('../package.json');
  assert(pkg.name === 'heady-latent-os', 'Package name is heady-latent-os');
  assert(pkg.version !== undefined, 'Package has version');
  assert(pkg.dependencies && pkg.dependencies.express, 'Express is a dependency');
  assert(pkg.scripts && pkg.scripts.start, 'start script defined');
  assert(pkg.scripts && pkg.scripts.test, 'test script defined');
} catch (err) {
  assert(false, `package.json is valid — ${err.message}`);
}

// ─── Test: No TODO/FIXME/HACK ─────────────────────────────────────────────────
section('Code Quality — Zero Placeholders');

const fs = require('fs');

function scanDir(dir, exts) {
  const results = [];
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory() && !entry.name.startsWith('.') && entry.name !== 'node_modules') {
        results.push(...scanDir(fullPath, exts));
      } else if (entry.isFile() && exts.some(ext => entry.name.endsWith(ext))) {
        results.push(fullPath);
      }
    }
  } catch (e) {
    // skip unreadable dirs
  }
  return results;
}

const projectRoot = path.join(__dirname, '..');
const jsFiles = scanDir(projectRoot, ['.js']);
let todoCount = 0;
let consoleLogCount = 0;
const banned = ['TODO:', 'FIXME:', 'HACK:', 'XXX:'];

for (const file of jsFiles) {
  if (file.includes('node_modules') || file.includes('tests/')) continue;
  const content = fs.readFileSync(file, 'utf-8');
  const lines = content.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    for (const pattern of banned) {
      if (line.includes(pattern)) {
        todoCount++;
        process.stdout.write(`  \x1b[33mWARN\x1b[0m ${path.relative(projectRoot, file)}:${i + 1} contains ${pattern}\n`);
      }
    }
    // Check for bare console.log (not in structured logger)
    if (line.match(/\bconsole\.log\b/) && !line.includes('//') && !file.includes('test')) {
      consoleLogCount++;
    }
  }
}

assert(todoCount === 0, `Zero TODO/FIXME/HACK comments (found ${todoCount})`);
assert(consoleLogCount === 0, `Zero console.log in production code (found ${consoleLogCount})`);

// ─── Test: Phi-Math Integrity ─────────────────────────────────────────────────
section('Phi-Math Integrity');

// Verify no magic numbers in key files
const criticalFiles = [
  '../src/pipeline/hc-full-pipeline.js',
  '../src/bees/bee-factory.js',
  '../src/core/heady-os.js',
  '../src/core/colab-bridge.js'
];

let magicNumberIssues = 0;
const magicPatterns = [
  /timeout:\s*\d{4,}/,     // hardcoded timeouts > 999ms not derived from phi
  /maxRetries:\s*[469]/,   // non-Fibonacci retry counts
];

for (const relPath of criticalFiles) {
  try {
    const content = fs.readFileSync(path.join(__dirname, relPath), 'utf-8');
    // Check that file references phi-constants
    const usesPhi = content.includes('phi-constants') || content.includes('PHI') ||
                    content.includes('FIB') || content.includes('phiBackoff');
    if (!usesPhi) {
      magicNumberIssues++;
      process.stdout.write(`  \x1b[33mWARN\x1b[0m ${relPath} does not import phi-constants\n`);
    }
  } catch (e) {
    // File may not exist
  }
}

assert(magicNumberIssues === 0, `All critical files use phi-constants (${magicNumberIssues} issues)`);

// ─── Test: File Completeness ──────────────────────────────────────────────────
section('File Completeness');

const requiredFiles = [
  'server.js',
  'package.json',
  '.env.example',
  '.gitignore',
  'Dockerfile',
  'docker-compose.yml',
  'shared/phi-constants.js',
  'shared/liquid-nodes.js',
  'configs/colab-runtime-config.py',
  'docs/ecosystem-map.md',
  'migrations/init.sql',
  'src/core/heady-os.js',
  'src/core/colab-bridge.js',
  'src/pipeline/hc-full-pipeline.js',
  'src/bees/bee-factory.js',
  'src/nodes/inner/heady-brains.js',
  'src/nodes/inner/heady-vinci.js',
  'src/nodes/inner/heady-buddy.js',
  'src/nodes/middle/jules.js',
  'src/nodes/middle/builder.js',
  'src/nodes/middle/observer.js',
  'src/nodes/middle/murphy.js',
  'src/nodes/middle/atlas.js',
  'src/nodes/middle/pythia.js',
  'src/nodes/outer/bridge.js',
  'src/nodes/outer/muse.js',
  'src/nodes/outer/sentinel.js',
  'src/nodes/outer/nova.js',
  'src/nodes/outer/janitor.js',
  'src/nodes/outer/sophia.js',
  'src/nodes/outer/cipher.js',
  'src/nodes/outer/lens.js',
  'src/nodes/governance/heady-check.js',
  'src/nodes/governance/heady-assure.js',
  'src/nodes/governance/heady-aware.js',
  'src/nodes/governance/heady-patterns.js',
  'src/nodes/governance/heady-mc.js',
  'src/nodes/governance/heady-risks.js',
  'src/nodes/memory/heady-memory.js',
  'src/nodes/memory/heady-embed.js',
  'src/nodes/memory/heady-autobiographer.js',
  'src/nodes/memory/heady-maid.js'
];

let missingFiles = 0;
for (const file of requiredFiles) {
  const fullPath = path.join(projectRoot, file);
  const exists = fs.existsSync(fullPath);
  if (!exists) {
    missingFiles++;
    assert(false, `Required file exists: ${file}`);
  }
}
assert(missingFiles === 0, `All ${requiredFiles.length} required files present (${missingFiles} missing)`);

// ─── Summary ──────────────────────────────────────────────────────────────────
section('RESULTS');

const total = passed + failed;
process.stdout.write(`\n  Total:  ${total}\n`);
process.stdout.write(`  \x1b[32mPassed: ${passed}\x1b[0m\n`);
process.stdout.write(`  \x1b[31mFailed: ${failed}\x1b[0m\n\n`);

if (failures.length > 0) {
  process.stdout.write('\x1b[31mFailures:\x1b[0m\n');
  for (const f of failures) {
    process.stdout.write(`  - ${f}\n`);
  }
  process.stdout.write('\n');
}

process.exit(failed > 0 ? 1 : 0);
