/**
 * Heady Latent OS — Lint & Syntax Check
 * Validates all JS files parse correctly, checks require() paths resolve,
 * and enforces coding standards.
 *
 * Run: node tests/lint-check.js
 * © 2026 HeadySystems Inc. — Sacred Geometry v4.0
 */

'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

let passed = 0;
let failed = 0;
const failures = [];

function assert(condition, message) {
  if (condition) {
    passed++;
  } else {
    failed++;
    failures.push(message);
    process.stdout.write('\x1b[31m✗\x1b[0m ' + message + '\n');
  }
}

function section(name) {
  process.stdout.write('\n\x1b[36m── ' + name + ' ──\x1b[0m\n');
}

const projectRoot = path.join(__dirname, '..');

// ─── Collect all JS files ─────────────────────────────────────────────────────
function collectJSFiles(dir) {
  const results = [];
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === 'tests') continue;
        results.push(...collectJSFiles(fullPath));
      } else if (entry.isFile() && entry.name.endsWith('.js')) {
        results.push(fullPath);
      }
    }
  } catch (e) {
    // skip
  }
  return results;
}

const jsFiles = collectJSFiles(projectRoot);

// ─── Syntax Check ─────────────────────────────────────────────────────────────
section(`Syntax Check (${jsFiles.length} JS files)`);

for (const file of jsFiles) {
  const relPath = path.relative(projectRoot, file);
  try {
    const source = fs.readFileSync(file, 'utf-8');
    // Try to compile (parse) the file
    new vm.Script(source, { filename: relPath });
    passed++;
    process.stdout.write('\x1b[32m✓\x1b[0m ' + relPath + ' — syntax OK\n');
  } catch (err) {
    assert(false, `${relPath} — syntax error: ${err.message}`);
  }
}

// ─── Require Resolution Check ─────────────────────────────────────────────────
section('Require Resolution');

const requirePattern = /require\(\s*['"]([^'"]+)['"]\s*\)/g;

for (const file of jsFiles) {
  const relPath = path.relative(projectRoot, file);
  const source = fs.readFileSync(file, 'utf-8');
  let match;

  while ((match = requirePattern.exec(source)) !== null) {
    const dep = match[1];

    // Skip Node built-ins
    const builtins = ['fs', 'path', 'http', 'https', 'url', 'crypto', 'os',
                      'child_process', 'stream', 'util', 'events', 'net',
                      'tls', 'zlib', 'vm', 'assert', 'dns', 'cluster',
                      'readline', 'querystring', 'string_decoder', 'buffer',
                      'worker_threads', 'perf_hooks', 'async_hooks'];
    if (builtins.includes(dep) || dep.startsWith('node:')) continue;

    // Skip npm packages (no relative path)
    if (!dep.startsWith('.') && !dep.startsWith('/')) {
      // Check if it is a known dependency in package.json
      try {
        const pkg = require(path.join(projectRoot, 'package.json'));
        const allDeps = { ...pkg.dependencies, ...pkg.devDependencies };
        const pkgName = dep.split('/')[0];
        if (allDeps[pkgName]) {
          passed++;
        }
        // else external — skip validation, npm install needed
      } catch (e) {
        // no package.json
      }
      continue;
    }

    // Resolve relative require
    const fileDir = path.dirname(file);
    const resolvedBase = path.resolve(fileDir, dep);
    const candidates = [
      resolvedBase,
      resolvedBase + '.js',
      resolvedBase + '.json',
      path.join(resolvedBase, 'index.js')
    ];

    const found = candidates.some(c => fs.existsSync(c));
    if (found) {
      passed++;
    } else {
      assert(false, `${relPath} — unresolved require('${dep}')`);
    }
  }
}

// ─── Coding Standards Check ───────────────────────────────────────────────────
section('Coding Standards');

let strictModeViolations = 0;
let localhostViolations = 0;
let wildcardCorsViolations = 0;
let emptyCatchViolations = 0;

for (const file of jsFiles) {
  const relPath = path.relative(projectRoot, file);
  const source = fs.readFileSync(file, 'utf-8');
  const lines = source.split('\n');

  // Check 'use strict' (first non-comment, non-empty line should be 'use strict' or handled by class/module)
  const firstCode = lines.find(l => l.trim() && !l.trim().startsWith('//') && !l.trim().startsWith('/*') && !l.trim().startsWith('*'));
  if (firstCode && !source.includes("'use strict'") && !source.includes('"use strict"')) {
    strictModeViolations++;
    process.stdout.write(`  \x1b[33mWARN\x1b[0m ${relPath} — missing 'use strict'\n`);
  }

  // Check localhost contamination
  if (source.includes("'localhost") || source.includes('"localhost') || source.includes("'127.0.0.1") || source.includes('"127.0.0.1')) {
    localhostViolations++;
    process.stdout.write(`  \x1b[31mERROR\x1b[0m ${relPath} — contains localhost reference\n`);
  }

  // Check wildcard CORS
  if (source.includes("'*'") && (source.toLowerCase().includes('cors') || source.toLowerCase().includes('origin'))) {
    // Only flag if it looks like CORS configuration
    const corsLines = lines.filter(l => l.includes("'*'") && (l.toLowerCase().includes('origin') || l.toLowerCase().includes('cors')));
    if (corsLines.length > 0) {
      wildcardCorsViolations++;
      process.stdout.write(`  \x1b[31mERROR\x1b[0m ${relPath} — wildcard CORS origin detected\n`);
    }
  }

  // Check empty catch blocks
  const emptyCatchMatch = source.match(/catch\s*\([^)]*\)\s*\{\s*\}/g);
  if (emptyCatchMatch) {
    emptyCatchViolations += emptyCatchMatch.length;
    process.stdout.write(`  \x1b[33mWARN\x1b[0m ${relPath} — ${emptyCatchMatch.length} empty catch block(s)\n`);
  }
}

assert(localhostViolations === 0, `Zero localhost references (found ${localhostViolations})`);
assert(wildcardCorsViolations === 0, `Zero wildcard CORS origins (found ${wildcardCorsViolations})`);
assert(emptyCatchViolations === 0, `Zero empty catch blocks (found ${emptyCatchViolations})`);

// Strict mode is a warning, not a failure
if (strictModeViolations > 0) {
  process.stdout.write(`  \x1b[33mINFO\x1b[0m ${strictModeViolations} files without 'use strict' (advisory)\n`);
}

// ─── File Size Check ──────────────────────────────────────────────────────────
section('File Size Sanity');

for (const file of jsFiles) {
  const relPath = path.relative(projectRoot, file);
  const stat = fs.statSync(file);
  const sizeKB = (stat.size / 1024).toFixed(1);

  // Files should not be too small (stub) or too large (monolith)
  if (stat.size < 100) {
    assert(false, `${relPath} is suspiciously small (${sizeKB}KB) — possible stub`);
  } else if (stat.size > 50000) {
    process.stdout.write(`  \x1b[33mWARN\x1b[0m ${relPath} is large (${sizeKB}KB) — consider splitting\n`);
    passed++; // Not a failure, just advisory
  } else {
    passed++;
  }
}

// ─── Summary ──────────────────────────────────────────────────────────────────
section('RESULTS');

const total = passed + failed;
process.stdout.write(`\n  Total:  ${total}\n`);
process.stdout.write(`  \x1b[32mPassed: ${passed}\x1b[0m\n`);
process.stdout.write(`  \x1b[31mFailed: ${failed}\x1b[0m\n\n`);

if (failures.length > 0) {
  process.stdout.write('\x1b[31mFailures:\x1b[0m\n');
  for (const f of failures) {
    process.stdout.write(`  - ${f}\n`);
  }
  process.stdout.write('\n');
}

process.exit(failed > 0 ? 1 : 0);
