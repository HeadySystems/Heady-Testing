/**
 * Heady System — Top-Level Barrel Export
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * @module heady-system
 * @version 4.0.0
 */

const core = require('./core');
const { HeadyConductor, getConductor, TASK_TYPES, ROUTING_MATRIX } = require('./conductor/conductor');
const { BeeFactory, getBeeFactory, BEE_TYPES } = require('./bees/bee-factory');
const { HCFullPipeline, getPipeline, PIPELINE_STAGES } = require('./pipeline/hcfull-pipeline');

module.exports = {
  // Core
  ...core,

  // Conductor
  HeadyConductor,
  getConductor,
  TASK_TYPES,
  ROUTING_MATRIX,

  // Bee Factory
  BeeFactory,
  getBeeFactory,
  BEE_TYPES,

  // Pipeline
  HCFullPipeline,
  getPipeline,
  PIPELINE_STAGES,
};
