/**
 * HeadyBee Factory — Dynamic Agent Worker Creation
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Every bee follows: spawn() → execute() → report() → retire()
 * Bees are ephemeral workers — created for tasks, retired after completion.
 * 30+ specialized bee types for every domain in the ecosystem.
 *
 * @module bee-factory
 * @version 4.0.0
 */

const {
  BeeNode, nodeBus, createLogger,
  PHI, PSI, fib, SIZING,
  CSL_THRESHOLDS, cosineSimilarity, cslGate,
} = require('../core/liquid-node');

const logger = createLogger('BeeFactory');

// ═══════════════════════════════════════════════════════════════
// BEE TYPE REGISTRY
// ═══════════════════════════════════════════════════════════════

/**
 * Bee type definitions with roles and capabilities.
 * Each bee type has a name, description, pool, and capability keywords.
 */
const BEE_TYPES = Object.freeze({
  'agents-bee':             { description: 'Agent creation and routing', pool: 'hot', keywords: ['agent', 'create', 'route'] },
  'auth-provider-bee':      { description: 'Authentication provider orchestration', pool: 'hot', keywords: ['auth', 'login', 'token', 'oauth'] },
  'auto-success-bee':       { description: 'Automated success pipeline execution', pool: 'warm', keywords: ['auto', 'success', 'pipeline'] },
  'brain-bee':              { description: 'LLM provider routing and model selection', pool: 'hot', keywords: ['llm', 'model', 'inference', 'brain'] },
  'config-bee':             { description: 'Configuration management and validation', pool: 'cold', keywords: ['config', 'settings', 'environment'] },
  'connectors-bee':         { description: 'External service connector management', pool: 'warm', keywords: ['connector', 'external', 'api', 'integration'] },
  'creative-bee':           { description: 'Creative content generation', pool: 'warm', keywords: ['creative', 'image', 'music', 'content'] },
  'deployment-bee':         { description: 'Cloud deployment automation', pool: 'warm', keywords: ['deploy', 'cloud', 'container', 'release'] },
  'device-provisioner-bee': { description: 'Device onboarding and provisioning', pool: 'cold', keywords: ['device', 'provision', 'onboard'] },
  'documentation-bee':      { description: 'Auto-documentation generation', pool: 'warm', keywords: ['docs', 'documentation', 'readme', 'jsdoc'] },
  'engines-bee':            { description: 'Engine orchestration and lifecycle', pool: 'warm', keywords: ['engine', 'lifecycle', 'orchestrate'] },
  'governance-bee':         { description: 'Policy enforcement and compliance', pool: 'governance', keywords: ['policy', 'compliance', 'governance', 'rule'] },
  'health-bee':             { description: 'Health probe execution and reporting', pool: 'hot', keywords: ['health', 'probe', 'status', 'heartbeat'] },
  'intelligence-bee':       { description: 'Intelligence gathering and analysis', pool: 'warm', keywords: ['intelligence', 'gather', 'analyze', 'insight'] },
  'lifecycle-bee':          { description: 'Service lifecycle management', pool: 'warm', keywords: ['lifecycle', 'start', 'stop', 'restart'] },
  'mcp-bee':                { description: 'MCP protocol tool execution', pool: 'hot', keywords: ['mcp', 'tool', 'protocol', 'rpc'] },
  'memory-bee':             { description: 'Memory operations', pool: 'hot', keywords: ['memory', 'store', 'retrieve', 'embed', 'vector'] },
  'middleware-bee':         { description: 'Middleware chain management', pool: 'warm', keywords: ['middleware', 'chain', 'intercept', 'transform'] },
  'midi-bee':               { description: 'MIDI event processing', pool: 'cold', keywords: ['midi', 'music', 'audio', 'event'] },
  'ops-bee':                { description: 'Operations automation', pool: 'warm', keywords: ['ops', 'devops', 'automation', 'task'] },
  'orchestration-bee':      { description: 'Multi-bee orchestration coordination', pool: 'hot', keywords: ['orchestrate', 'coordinate', 'swarm', 'multi'] },
  'pipeline-bee':           { description: 'Pipeline stage execution', pool: 'hot', keywords: ['pipeline', 'stage', 'step', 'flow'] },
  'providers-bee':          { description: 'Provider health and failover', pool: 'warm', keywords: ['provider', 'health', 'failover', 'fallback'] },
  'refactor-bee':           { description: 'Code refactoring automation', pool: 'warm', keywords: ['refactor', 'improve', 'optimize', 'clean'] },
  'resilience-bee':         { description: 'Resilience pattern enforcement', pool: 'warm', keywords: ['resilience', 'circuit', 'breaker', 'retry'] },
  'routes-bee':             { description: 'API route management', pool: 'warm', keywords: ['route', 'api', 'endpoint', 'handler'] },
  'security-bee':           { description: 'Security scanning and enforcement', pool: 'governance', keywords: ['security', 'scan', 'vulnerability', 'audit'] },
  'services-bee':           { description: 'Service catalog management', pool: 'warm', keywords: ['service', 'catalog', 'registry', 'discover'] },
  'sync-projection-bee':    { description: 'Repo projection synchronization', pool: 'cold', keywords: ['sync', 'projection', 'repo', 'manifest'] },
  'telemetry-bee':          { description: 'Telemetry collection and export', pool: 'cold', keywords: ['telemetry', 'metric', 'trace', 'log'] },
  'trading-bee':            { description: 'Financial trading operations', pool: 'warm', keywords: ['trade', 'finance', 'token', 'ledger'] },
  'vector-ops-bee':         { description: 'Vector space operations', pool: 'hot', keywords: ['vector', 'embedding', 'similarity', 'search'] },
  'vector-template-bee':    { description: 'Vector template management', pool: 'cold', keywords: ['template', 'vector', 'schema', 'pattern'] },
});

// ═══════════════════════════════════════════════════════════════
// BEE IMPLEMENTATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Generic bee that executes a task handler function.
 * All specialized bees extend BeeNode and override execute().
 */
class GenericBee extends BeeNode {
  /**
   * @param {string} beeType - Type name from BEE_TYPES
   * @param {Function} handler - Task execution handler
   */
  constructor(beeType, handler) {
    const typeInfo = BEE_TYPES[beeType] || { pool: 'warm' };
    super({ name: `${beeType}-${Date.now().toString(36)}`, pool: typeInfo.pool });
    this.beeType = beeType;
    this.handler = handler;
    this.createdAt = Date.now();
  }

  async execute(task) {
    return this.handler(task, this);
  }
}

// ═══════════════════════════════════════════════════════════════
// BEE FACTORY
// ═══════════════════════════════════════════════════════════════

/**
 * BeeFactory — creates, tracks, and manages bee worker lifecycle.
 */
class BeeFactory {
  constructor() {
    this.activeBees = new Map();
    this.retiredBees = [];
    this.maxRetired = fib(16); // 987 history entries
    this.maxConcurrent = fib(6); // 8 concurrent bees
    this.logger = createLogger('BeeFactory');

    // Listen for bee reports
    nodeBus.on('bee:report', (report) => {
      this.logger.info({ bee: report.bee }, 'Bee report received');
    });
  }

  /**
   * Spawn a new bee of the given type.
   * @param {string} beeType - Type from BEE_TYPES
   * @param {Function} handler - Task execution handler
   * @param {Object} [context={}] - Spawn context
   * @returns {Promise<GenericBee>} Spawned bee
   */
  async spawn(beeType, handler, context = {}) {
    if (!BEE_TYPES[beeType]) {
      throw new Error(`Unknown bee type: ${beeType}`);
    }

    if (this.activeBees.size >= this.maxConcurrent) {
      this.logger.warn({
        active: this.activeBees.size,
        max: this.maxConcurrent,
      }, 'Max concurrent bees reached, queuing');
      await this._waitForSlot();
    }

    const bee = new GenericBee(beeType, handler);
    await bee.spawn(context);
    this.activeBees.set(bee.name, bee);
    this.logger.info({ bee: bee.name, type: beeType, active: this.activeBees.size }, 'Bee spawned');
    return bee;
  }

  /**
   * Execute a task with a bee — spawn, execute, report, retire.
   * @param {string} beeType - Bee type
   * @param {Object} task - Task to execute
   * @param {Function} handler - Task handler
   * @returns {Promise<*>} Task result
   */
  async executeWithBee(beeType, task, handler) {
    const bee = await this.spawn(beeType, handler);
    try {
      const result = await bee._handleTask(task);
      await bee.report(result);
      return result;
    } finally {
      await this.retire(bee.name);
    }
  }

  /**
   * Execute multiple tasks concurrently with a swarm of bees.
   * @param {string} beeType - Bee type for all swarm members
   * @param {Object[]} tasks - Array of tasks
   * @param {Function} handler - Shared task handler
   * @returns {Promise<Array<{ task: Object, result: *, error: Error|null }>>}
   */
  async swarmExecute(beeType, tasks, handler) {
    this.logger.info({ beeType, taskCount: tasks.length }, 'Swarm execution starting');

    const results = [];
    const batchSize = this.maxConcurrent;

    for (let i = 0; i < tasks.length; i += batchSize) {
      const batch = tasks.slice(i, i + batchSize);
      const batchResults = await Promise.allSettled(
        batch.map(task => this.executeWithBee(beeType, task, handler))
      );

      for (let j = 0; j < batch.length; j++) {
        const result = batchResults[j];
        results.push({
          task: batch[j],
          result: result.status === 'fulfilled' ? result.value : null,
          error: result.status === 'rejected' ? result.reason : null,
        });
      }
    }

    this.logger.info({
      beeType,
      total: tasks.length,
      succeeded: results.filter(r => !r.error).length,
      failed: results.filter(r => r.error).length,
    }, 'Swarm execution complete');

    return results;
  }

  /**
   * Retire a bee and remove from active pool.
   * @param {string} beeName - Bee to retire
   */
  async retire(beeName) {
    const bee = this.activeBees.get(beeName);
    if (!bee) return;

    await bee.retire();
    this.activeBees.delete(beeName);

    this.retiredBees.push({
      name: beeName,
      type: bee.beeType,
      retiredAt: Date.now(),
      metrics: bee.metrics,
    });

    if (this.retiredBees.length > this.maxRetired) {
      this.retiredBees = this.retiredBees.slice(-this.maxRetired);
    }

    this.logger.info({ bee: beeName, active: this.activeBees.size }, 'Bee retired');
    nodeBus.emit('beeFactory:slotAvailable');
  }

  /**
   * Retire all active bees.
   */
  async retireAll() {
    const names = [...this.activeBees.keys()];
    for (const name of names) {
      await this.retire(name);
    }
  }

  /**
   * Get factory status.
   * @returns {Object} Factory status
   */
  status() {
    return {
      activeBees: [...this.activeBees.entries()].map(([name, bee]) => ({
        name,
        type: bee.beeType,
        state: bee.state,
        pool: bee.pool,
        metrics: bee.metrics,
      })),
      activeCount: this.activeBees.size,
      maxConcurrent: this.maxConcurrent,
      retiredCount: this.retiredBees.length,
      beeTypes: Object.keys(BEE_TYPES),
      beeTypeCount: Object.keys(BEE_TYPES).length,
    };
  }

  /** @private */
  _waitForSlot() {
    return new Promise(resolve => {
      const handler = () => {
        if (this.activeBees.size < this.maxConcurrent) {
          nodeBus.removeListener('beeFactory:slotAvailable', handler);
          resolve();
        }
      };
      nodeBus.on('beeFactory:slotAvailable', handler);
    });
  }
}

// ═══════════════════════════════════════════════════════════════
// SINGLETON FACTORY
// ═══════════════════════════════════════════════════════════════

let factoryInstance = null;

/**
 * Get or create the singleton BeeFactory.
 * @returns {BeeFactory}
 */
function getBeeFactory() {
  if (!factoryInstance) {
    factoryInstance = new BeeFactory();
  }
  return factoryInstance;
}

module.exports = {
  BeeFactory,
  getBeeFactory,
  GenericBee,
  BEE_TYPES,
};
