/**
 * Heady Structured Logger — Production JSON Logging
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Zero console.log. All output is structured JSON to stdout/stderr.
 * Correlation ID tracking for distributed tracing.
 *
 * @module structured-logger
 * @version 4.0.0
 */

const { randomUUID } = require('crypto');

/** Log levels with numeric severity */
const LOG_LEVELS = Object.freeze({
  trace: 10,
  debug: 20,
  info:  30,
  warn:  40,
  error: 50,
  fatal: 60,
});

/** Current minimum log level from environment */
const MIN_LEVEL = LOG_LEVELS[process.env.LOG_LEVEL?.toLowerCase()] || LOG_LEVELS.info;

/**
 * Create a structured JSON logger for a service.
 * @param {string} service - Service/module name
 * @param {Object} [baseContext={}] - Default context fields on every log entry
 * @returns {Object} Logger with trace, debug, info, warn, error, fatal, child methods
 */
function createLogger(service, baseContext = {}) {
  const _write = (level, levelNum, data, msg) => {
    if (levelNum < MIN_LEVEL) return;

    const entry = {
      timestamp: new Date().toISOString(),
      level,
      service,
      correlationId: data?.correlationId || baseContext.correlationId || null,
      requestId: data?.requestId || baseContext.requestId || null,
      msg: msg || data?.message || '',
      ...baseContext,
      ...data,
    };

    // Remove duplicated fields
    delete entry.message;

    const out = levelNum >= LOG_LEVELS.error ? process.stderr : process.stdout;
    out.write(JSON.stringify(entry) + '\n');
  };

  return {
    trace: (data, msg) => _write('trace', LOG_LEVELS.trace, data, msg),
    debug: (data, msg) => _write('debug', LOG_LEVELS.debug, data, msg),
    info:  (data, msg) => _write('info',  LOG_LEVELS.info,  data, msg),
    warn:  (data, msg) => _write('warn',  LOG_LEVELS.warn,  data, msg),
    error: (data, msg) => _write('error', LOG_LEVELS.error, data, msg),
    fatal: (data, msg) => _write('fatal', LOG_LEVELS.fatal, data, msg),

    /**
     * Create a child logger with additional bound context.
     * @param {Object} context - Additional context fields
     * @returns {Object} Child logger
     */
    child(context) {
      return createLogger(service, { ...baseContext, ...context });
    },

    /**
     * Create a request-scoped logger with correlation ID.
     * @param {string} [correlationId] - Override correlation ID (auto-generated if omitted)
     * @returns {Object} Request-scoped logger
     */
    forRequest(correlationId) {
      return createLogger(service, {
        ...baseContext,
        correlationId: correlationId || randomUUID(),
        requestId: randomUUID(),
      });
    },
  };
}

/**
 * Express middleware that attaches a request logger with correlation ID.
 * @returns {Function} Express middleware
 */
function requestLoggerMiddleware() {
  return (req, res, next) => {
    const correlationId = req.headers['x-correlation-id'] || randomUUID();
    const requestId = randomUUID();
    const start = Date.now();

    req.correlationId = correlationId;
    req.requestId = requestId;
    req.logger = createLogger(req.app?.get?.('service') || 'http', {
      correlationId,
      requestId,
    });

    res.setHeader('X-Correlation-ID', correlationId);
    res.setHeader('X-Request-ID', requestId);

    res.on('finish', () => {
      const duration = Date.now() - start;
      const level = res.statusCode >= 500 ? 'error' : res.statusCode >= 400 ? 'warn' : 'info';
      req.logger[level]({
        method: req.method,
        path: req.originalUrl,
        statusCode: res.statusCode,
        durationMs: duration,
        userAgent: req.headers['user-agent'],
        ip: req.ip,
      }, 'Request completed');
    });

    next();
  };
}

module.exports = { createLogger, requestLoggerMiddleware, LOG_LEVELS };
