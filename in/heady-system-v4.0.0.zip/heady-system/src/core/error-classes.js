/**
 * Heady Error Class Hierarchy — Typed, Serializable Errors
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Every error in the Heady ecosystem is typed with a code, status, and details.
 * No empty catch blocks. No generic "Error" throws.
 *
 * @module error-classes
 * @version 4.0.0
 */

/**
 * Base application error with structured context.
 */
class AppError extends Error {
  /**
   * @param {string} message - Human-readable error message
   * @param {number} [statusCode=500] - HTTP status code
   * @param {string} [code='INTERNAL_ERROR'] - Machine-readable error code
   * @param {Object} [details={}] - Additional context
   */
  constructor(message, statusCode = 500, code = 'INTERNAL_ERROR', details = {}) {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.isOperational = true;
    this.timestamp = new Date().toISOString();
  }

  /**
   * Serialize to JSON for API responses.
   * @returns {Object} Serialized error
   */
  toJSON() {
    return {
      error: {
        code: this.code,
        message: this.message,
        details: this.details,
        timestamp: this.timestamp,
      },
    };
  }
}

/** Resource not found. */
class NotFoundError extends AppError {
  /**
   * @param {string} resource - Resource type (e.g., 'User', 'Node')
   * @param {string} id - Resource identifier
   */
  constructor(resource, id) {
    super(`${resource} '${id}' not found`, 404, 'NOT_FOUND', { resource, id });
  }
}

/** Input validation failure. */
class ValidationError extends AppError {
  /**
   * @param {string} field - Field that failed validation
   * @param {string} reason - Why it failed
   */
  constructor(field, reason) {
    super(`Validation failed: ${field} — ${reason}`, 422, 'VALIDATION_ERROR', { field, reason });
  }
}

/** Authorization failure. */
class AuthorizationError extends AppError {
  /**
   * @param {string} action - What was attempted
   */
  constructor(action) {
    super(`Not authorized to ${action}`, 403, 'FORBIDDEN', { action });
  }
}

/** Resource conflict. */
class ConflictError extends AppError {
  /**
   * @param {string} resource - Resource type
   * @param {string} constraint - Violated constraint
   */
  constructor(resource, constraint) {
    super(`${resource} conflicts with ${constraint}`, 409, 'CONFLICT', { resource, constraint });
  }
}

/** Circuit breaker is open — service unavailable. */
class CircuitBreakerError extends AppError {
  /**
   * @param {string} service - Service name
   * @param {number} resetMs - Time until half-open in ms
   */
  constructor(service, resetMs) {
    super(
      `Circuit breaker for '${service}' is OPEN`,
      503,
      'CIRCUIT_BREAKER_OPEN',
      { service, resetMs, retryAfterMs: resetMs }
    );
  }
}

/** Semantic drift detected — coherence violation. */
class DriftError extends AppError {
  /**
   * @param {string} node - Node name
   * @param {number} coherence - Current coherence score
   * @param {number} threshold - Required threshold
   */
  constructor(node, coherence, threshold) {
    super(
      `Semantic drift detected on '${node}': coherence ${coherence.toFixed(3)} < ${threshold.toFixed(3)}`,
      500,
      'SEMANTIC_DRIFT',
      { node, coherence, threshold }
    );
  }
}

/** Coherence violation — mutation rejected. */
class CoherenceViolationError extends AppError {
  /**
   * @param {string[]} violations - List of violated laws
   */
  constructor(violations) {
    super(
      `Mutation rejected: ${violations.length} law violation(s)`,
      422,
      'COHERENCE_VIOLATION',
      { violations }
    );
  }
}

/** Rate limit exceeded. */
class RateLimitError extends AppError {
  /**
   * @param {number} retryAfterMs - When to retry
   */
  constructor(retryAfterMs) {
    super(
      'Rate limit exceeded',
      429,
      'RATE_LIMIT_EXCEEDED',
      { retryAfterMs }
    );
  }
}

/** Node cannot accept work in current state. */
class NodeUnavailableError extends AppError {
  /**
   * @param {string} node - Node name
   * @param {string} state - Current node state
   */
  constructor(node, state) {
    super(
      `Node '${node}' cannot accept work in state '${state}'`,
      503,
      'NODE_UNAVAILABLE',
      { node, state }
    );
  }
}

/**
 * Global Express error handler.
 * @param {Object} logger - Structured logger instance
 * @returns {Function} Express error handling middleware
 */
function globalErrorHandler(logger) {
  return (err, req, res, _next) => {
    if (err instanceof AppError && err.isOperational) {
      logger.warn({
        code: err.code,
        statusCode: err.statusCode,
        message: err.message,
        path: req?.originalUrl,
        correlationId: req?.correlationId,
      }, 'Operational error');
      return res.status(err.statusCode).json(err.toJSON());
    }

    logger.error({
      error: err.message,
      stack: err.stack,
      path: req?.originalUrl,
      correlationId: req?.correlationId,
    }, 'Unhandled error');

    return res.status(500).json({
      error: {
        code: 'INTERNAL_ERROR',
        message: 'An internal error occurred',
        timestamp: new Date().toISOString(),
      },
    });
  };
}

module.exports = {
  AppError,
  NotFoundError,
  ValidationError,
  AuthorizationError,
  ConflictError,
  CircuitBreakerError,
  DriftError,
  CoherenceViolationError,
  RateLimitError,
  NodeUnavailableError,
  globalErrorHandler,
};
