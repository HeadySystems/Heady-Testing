/**
 * Heady System Configuration — Validated, Typed, Immutable
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * All configuration via environment variables with phi-scaled defaults.
 * Required fields validated at startup — fail fast, not fail silent.
 *
 * @module config
 * @version 4.0.0
 */

const { PHI, PSI, fib, SIZING } = require('./phi-constants');

/**
 * Parse an integer from env with fallback.
 * @param {string} key - Environment variable name
 * @param {number} fallback - Default value
 * @returns {number}
 */
function envInt(key, fallback) {
  const val = process.env[key];
  if (val === undefined || val === '') return fallback;
  const parsed = parseInt(val, 10);
  if (isNaN(parsed)) throw new Error(`Invalid integer for ${key}: ${val}`);
  return parsed;
}

/**
 * Parse a string from env with fallback.
 * @param {string} key - Environment variable name
 * @param {string} [fallback=''] - Default value
 * @returns {string}
 */
function envStr(key, fallback = '') {
  return process.env[key] || fallback;
}

/**
 * Parse a comma-separated list from env.
 * @param {string} key - Environment variable name
 * @param {string[]} [fallback=[]] - Default value
 * @returns {string[]}
 */
function envList(key, fallback = []) {
  const val = process.env[key];
  if (!val) return fallback;
  return val.split(',').map(s => s.trim()).filter(Boolean);
}

/** System configuration — frozen at startup */
const config = Object.freeze({
  /** Service identity */
  service: {
    name: envStr('HEADY_SERVICE_NAME', 'heady-manager'),
    version: envStr('HEADY_VERSION', '4.0.0'),
    environment: envStr('NODE_ENV', 'development'),
  },

  /** HTTP server */
  server: {
    host: envStr('HOST', '0.0.0.0'),
    port: envInt('PORT', 3000),
    trustProxy: envStr('TRUST_PROXY', 'false') === 'true',
  },

  /** CORS — explicit origin whitelist, never wildcard in production */
  cors: {
    origins: envList('CORS_ORIGINS', [
      'https://headyme.com',
      'https://headysystems.com',
      'https://headybuddy.org',
      'https://headymcp.com',
      'https://headyio.com',
      'https://headybot.com',
      'https://headyapi.com',
      'https://headyai.com',
      'https://headyconnection.org',
    ]),
    credentials: true,
  },

  /** Domain map — the 9 Heady domains */
  domains: Object.freeze({
    command:    envStr('HEADY_DOMAIN_COMMAND', 'headyme.com'),
    systems:    envStr('HEADY_DOMAIN_SYSTEMS', 'headysystems.com'),
    nonprofit:  envStr('HEADY_DOMAIN_NONPROFIT', 'headyconnection.org'),
    companion:  envStr('HEADY_DOMAIN_COMPANION', 'headybuddy.org'),
    mcp:        envStr('HEADY_DOMAIN_MCP', 'headymcp.com'),
    developer:  envStr('HEADY_DOMAIN_DEVELOPER', 'headyio.com'),
    automation: envStr('HEADY_DOMAIN_AUTOMATION', 'headybot.com'),
    api:        envStr('HEADY_DOMAIN_API', 'headyapi.com'),
    intelligence: envStr('HEADY_DOMAIN_INTELLIGENCE', 'headyai.com'),
  }),

  /** Database (PostgreSQL + pgvector) */
  database: {
    host: envStr('DB_HOST'),
    port: envInt('DB_PORT', 5432),
    name: envStr('DB_NAME', 'heady'),
    user: envStr('DB_USER', 'heady'),
    password: envStr('DB_PASSWORD'),
    pool: {
      min: fib(3),   // 2 — Fibonacci minimum
      max: fib(7),   // 13 — Fibonacci maximum
    },
    ssl: envStr('DB_SSL', 'true') === 'true',
  },

  /** 3 Colab Pro+ runtimes */
  runtimes: Object.freeze({
    vector: {
      url: envStr('RUNTIME_VECTOR_URL', 'https://vector.headyos.com'),
      port: envInt('RUNTIME_VECTOR_PORT', 3301),
      healthPort: envInt('RUNTIME_VECTOR_HEALTH_PORT', 3311),
    },
    llm: {
      url: envStr('RUNTIME_LLM_URL', 'https://llm.headyos.com'),
      port: envInt('RUNTIME_LLM_PORT', 3302),
      healthPort: envInt('RUNTIME_LLM_HEALTH_PORT', 3312),
    },
    training: {
      url: envStr('RUNTIME_TRAINING_URL', 'https://train.headyos.com'),
      port: envInt('RUNTIME_TRAINING_PORT', 3303),
      healthPort: envInt('RUNTIME_TRAINING_HEALTH_PORT', 3313),
    },
  }),

  /** Resource pool allocation (phi-scaled) */
  pools: Object.freeze({
    hot:        { percent: 0.34, timeoutMs: 30000 },
    warm:       { percent: 0.21, timeoutMs: 300000 },
    cold:       { percent: 0.13, timeoutMs: 1800000 },
    reserve:    { percent: 0.08, timeoutMs: 0 },
    governance: { percent: 0.05, timeoutMs: 0 },
  }),

  /** Rate limiting (Fibonacci-based) */
  rateLimit: {
    anonymous: { windowMs: 60000, max: fib(9) },     // 34/min
    authenticated: { windowMs: 60000, max: fib(11) }, // 89/min
    admin: { windowMs: 60000, max: fib(12) },         // 144/min
    auth: { windowMs: 60000, max: fib(6) },           // 8/min (strict)
  },

  /** Phi-scaled timeouts (ms) */
  timeouts: Object.freeze({
    instant:    100,
    fast:       Math.round(100 * PHI),       // 162ms
    normal:     Math.round(100 * PHI * PHI), // 262ms
    slow:       Math.round(100 * PHI * PHI * PHI), // 424ms
    network:    Math.round(1000 * PSI),      // 618ms
    api:        Math.round(1000 * PHI * PHI), // 2618ms
    db:         Math.round(1000 * PHI),       // 1618ms
    background: Math.round(1000 * PHI * PHI * PHI), // 4236ms
    shutdown:   Math.round(1000 * PHI * PHI * PHI * PHI), // 6854ms
  }),

  /** Cloudflare configuration */
  cloudflare: {
    accountId: envStr('CF_ACCOUNT_ID'),
    zoneId: envStr('CF_ZONE_ID'),
    apiToken: envStr('CF_API_TOKEN'),
  },

  /** Firebase / Auth */
  auth: {
    jwtSecret: envStr('JWT_SECRET'),
    accessTokenExpiryMinutes: envInt('ACCESS_TOKEN_EXPIRY_MINUTES', fib(8)), // 21 min
    refreshTokenExpiryDays: envInt('REFRESH_TOKEN_EXPIRY_DAYS', fib(6)),     // 8 days
    firebaseProjectId: envStr('FIREBASE_PROJECT_ID', 'gen-lang-client-0920560496'),
  },

  /** Embedding configuration */
  embedding: {
    dimensions: envInt('EMBEDDING_DIM', 384),
    provider: envStr('EMBEDDING_PROVIDER', 'nomic'),
    batchSize: fib(11),  // 89
    cacheSize: fib(16),  // 987
  },

  /** Logging */
  logging: {
    level: envStr('LOG_LEVEL', 'info'),
    format: 'json',
  },
});

/**
 * Validate required configuration fields at startup.
 * Throws if any required field is missing in production.
 * @throws {Error} If required configuration is missing
 */
function validateConfig() {
  if (config.service.environment === 'production') {
    const required = [
      ['auth.jwtSecret', config.auth.jwtSecret],
      ['database.host', config.database.host],
      ['database.password', config.database.password],
    ];

    const missing = required.filter(([_, val]) => !val).map(([key]) => key);
    if (missing.length > 0) {
      throw new Error(`Missing required production config: ${missing.join(', ')}`);
    }
  }
}

module.exports = { config, validateConfig };
