/**
 * Heady CSL Engine — Continuous Semantic Logic
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Vector operations as logical gates. 60+ provisional patents.
 * Domain: Unit vectors in R^D, D ∈ {384, 1536}
 * Truth value: τ(a,b) = cos(θ) ∈ [-1, +1]
 *
 * @module csl-engine
 * @version 4.0.0
 */

const {
  PHI, PSI, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD,
  phiFusionWeights, cosineSimilarity,
  cslGate, cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS,
  PHI_TEMPERATURE, adaptiveTemperature,
} = require('./phi-constants');

// ═══════════════════════════════════════════════════════════════
// ADVANCED CSL GATES
// ═══════════════════════════════════════════════════════════════

/**
 * CSL XOR — exclusive semantic components.
 * Extracts what is unique to each vector, removing shared content.
 * @param {number[]} a - First vector
 * @param {number[]} b - Second vector
 * @returns {number[]} XOR result (normalized)
 */
function cslXOR(a, b) {
  const orVec = cslOR(a, b);
  // Mutual projection: average of proj(a→b) and proj(b→a)
  const projAB = cslIMPLY(a, b);
  const projBA = cslIMPLY(b, a);
  const mutual = projAB.map((v, i) => (v + projBA[i]) / 2);
  // XOR = OR - mutual
  const xor = orVec.map((v, i) => v - mutual[i]);
  const norm = Math.sqrt(xor.reduce((s, v) => s + v * v, 0));
  return norm > 0 ? xor.map(v => v / norm) : xor;
}

/**
 * CSL GATE with adaptive temperature based on entropy.
 * @param {number} value - Input value to gate
 * @param {number} cosScore - Cosine similarity score
 * @param {number} tau - Threshold
 * @param {number} entropy - Current entropy measure
 * @param {number} maxEntropy - Maximum expected entropy
 * @returns {number} Gated output with adaptive temperature
 */
function cslAdaptiveGate(value, cosScore, tau, entropy, maxEntropy) {
  const temp = adaptiveTemperature(entropy, maxEntropy);
  return cslGate(value, cosScore, tau, temp);
}

// ═══════════════════════════════════════════════════════════════
// TERNARY LOGIC MAPPING
// ═══════════════════════════════════════════════════════════════

/**
 * Map cosine similarity to ternary logic value.
 * @param {number} cosScore - Cosine similarity (-1 to 1)
 * @returns {{ label: string, value: number, confidence: number }}
 */
function ternaryLogic(cosScore) {
  if (cosScore >= CSL_THRESHOLDS.MINIMUM) {
    return { label: 'TRUE', value: 1, confidence: cosScore };
  }
  if (cosScore <= -CSL_THRESHOLDS.MINIMUM) {
    return { label: 'FALSE', value: -1, confidence: Math.abs(cosScore) };
  }
  return { label: 'UNKNOWN', value: 0, confidence: 1 - Math.abs(cosScore) };
}

/**
 * Batch ternary evaluation of multiple vector pairs.
 * @param {number[]} query - Query vector
 * @param {number[][]} candidates - Array of candidate vectors
 * @returns {Array<{ index: number, label: string, value: number, similarity: number }>}
 */
function batchTernary(query, candidates) {
  return candidates.map((c, index) => {
    const sim = cosineSimilarity(query, c);
    const ternary = ternaryLogic(sim);
    return { index, ...ternary, similarity: sim };
  });
}

// ═══════════════════════════════════════════════════════════════
// MIXTURE OF EXPERTS ROUTER (CSL-Based)
// ═══════════════════════════════════════════════════════════════

/**
 * CSL-based Mixture of Experts router.
 * Routes input to top-K experts based on cosine similarity scoring.
 *
 * @param {number[]} input - Input embedding
 * @param {number[][]} expertGates - Array of expert gate vectors
 * @param {number} [k=2] - Number of experts to select (fib(3) = 2 default)
 * @param {number} [temperature] - Softmax temperature (default: PSI^3 ≈ 0.236)
 * @returns {Array<{ expertIndex: number, score: number, weight: number }>}
 */
function moeRoute(input, expertGates, k = fib(3), temperature = null) {
  const temp = temperature || Math.pow(PSI, 3);

  // Compute scores
  const scores = expertGates.map((gate, i) => ({
    expertIndex: i,
    score: cosineSimilarity(input, gate),
  }));

  // Softmax with temperature
  const scaledScores = scores.map(s => s.score / temp);
  const maxScore = Math.max(...scaledScores);
  const exps = scaledScores.map(s => Math.exp(s - maxScore));
  const sumExps = exps.reduce((a, b) => a + b, 0);
  const probs = exps.map(e => e / sumExps);

  // Assign probabilities and sort
  const withProbs = scores.map((s, i) => ({ ...s, weight: probs[i] }));
  withProbs.sort((a, b) => b.weight - a.weight);

  // Return top-K with renormalized weights
  const topK = withProbs.slice(0, k);
  const topKSum = topK.reduce((s, e) => s + e.weight, 0);
  return topK.map(e => ({ ...e, weight: e.weight / topKSum }));
}

// ═══════════════════════════════════════════════════════════════
// HDC/VSA OPERATIONS — Hyperdimensional Computing
// ═══════════════════════════════════════════════════════════════

/**
 * HDC BIND — element-wise multiplication (bipolar MAP).
 * Creates associations between vectors.
 * @param {number[]} a - First vector
 * @param {number[]} b - Second vector
 * @returns {number[]} Bound vector
 */
function hdcBind(a, b) {
  return a.map((v, i) => v * b[i]);
}

/**
 * HDC BUNDLE — element-wise sum with normalization (majority).
 * Creates superpositions (set-like representation).
 * @param {number[][]} vectors - Array of vectors to bundle
 * @param {number[]} [weights] - Optional weights (phi-fusion by default)
 * @returns {number[]} Bundled unit vector
 */
function hdcBundle(vectors, weights) {
  const w = weights || phiFusionWeights(vectors.length);
  const dim = vectors[0].length;
  const sum = new Array(dim).fill(0);
  for (let i = 0; i < vectors.length; i++) {
    for (let d = 0; d < dim; d++) {
      sum[d] += w[i] * vectors[i][d];
    }
  }
  const norm = Math.sqrt(sum.reduce((s, v) => s + v * v, 0));
  return norm > 0 ? sum.map(v => v / norm) : sum;
}

/**
 * HDC PERMUTE — circular shift (for positional encoding).
 * @param {number[]} v - Vector to permute
 * @param {number} n - Number of positions to shift (positive = right)
 * @returns {number[]} Permuted vector
 */
function hdcPermute(v, n) {
  const dim = v.length;
  const shift = ((n % dim) + dim) % dim;
  const result = new Array(dim);
  for (let i = 0; i < dim; i++) {
    result[(i + shift) % dim] = v[i];
  }
  return result;
}

/**
 * HDC ENCODE — encode a sequence as positional hypervector.
 * Uses permute + bind for positional encoding, then bundles.
 * @param {number[][]} sequence - Ordered array of item vectors
 * @returns {number[]} Encoded sequence vector
 */
function hdcEncode(sequence) {
  const positional = sequence.map((v, i) => hdcPermute(v, i));
  return hdcBundle(positional);
}

/**
 * HDC DECODE — probe a sequence encoding for an item at a position.
 * @param {number[]} encoded - Encoded sequence vector
 * @param {number} position - Position to probe
 * @returns {number[]} Decoded probe vector (compare against known items)
 */
function hdcDecode(encoded, position) {
  return hdcPermute(encoded, -position);
}

// ═══════════════════════════════════════════════════════════════
// SEMANTIC DEDUPLICATION
// ═══════════════════════════════════════════════════════════════

/**
 * Check if two vectors are semantically identical (deduplication).
 * @param {number[]} a - First vector
 * @param {number[]} b - Second vector
 * @param {number} [threshold] - Dedup threshold (default: ≈ 0.972)
 * @returns {boolean} True if vectors are semantic duplicates
 */
function isDuplicate(a, b, threshold = DEDUP_THRESHOLD) {
  return cosineSimilarity(a, b) >= threshold;
}

/**
 * Deduplicate an array of vectors, keeping unique entries.
 * @param {Array<{ embedding: number[], data: * }>} items - Items with embeddings
 * @param {number} [threshold] - Dedup threshold
 * @returns {Array<{ embedding: number[], data: * }>} Unique items
 */
function deduplicateVectors(items, threshold = DEDUP_THRESHOLD) {
  const unique = [];
  for (const item of items) {
    const isDup = unique.some(u => cosineSimilarity(u.embedding, item.embedding) >= threshold);
    if (!isDup) unique.push(item);
  }
  return unique;
}

// ═══════════════════════════════════════════════════════════════
// RELEVANCE SCORING & RANKING
// ═══════════════════════════════════════════════════════════════

/**
 * Score and rank candidates against a query using CSL gates.
 * @param {number[]} query - Query embedding
 * @param {Array<{ embedding: number[], data: * }>} candidates - Candidates
 * @param {number} [threshold] - Minimum similarity (default: CSL LOW ≈ 0.691)
 * @returns {Array<{ data: *, similarity: number, gatedScore: number }>}
 */
function rankBySimilarity(query, candidates, threshold = CSL_THRESHOLDS.LOW) {
  return candidates
    .map(c => {
      const similarity = cosineSimilarity(query, c.embedding);
      const gatedScore = cslGate(1.0, similarity, threshold);
      return { data: c.data, similarity, gatedScore };
    })
    .filter(r => r.gatedScore > 0)
    .sort((a, b) => b.gatedScore - a.gatedScore);
}

// ═══════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════

module.exports = {
  // Core re-exports
  cosineSimilarity, cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS, cslGate,
  // Advanced gates
  cslXOR, cslAdaptiveGate,
  // Ternary logic
  ternaryLogic, batchTernary,
  // MoE Router
  moeRoute,
  // HDC/VSA
  hdcBind, hdcBundle, hdcPermute, hdcEncode, hdcDecode,
  // Deduplication
  isDuplicate, deduplicateVectors,
  // Ranking
  rankBySimilarity,
  // Constants re-exports
  CSL_THRESHOLDS, DEDUP_THRESHOLD, PHI_TEMPERATURE,
};
