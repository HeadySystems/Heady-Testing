/**
 * Heady Core — Barrel Export
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * @module core
 * @version 4.0.0
 */

const phiConstants = require('./phi-constants');
const cslEngine = require('./csl-engine');
const liquidNode = require('./liquid-node');
const { createLogger, requestLoggerMiddleware, LOG_LEVELS } = require('./structured-logger');
const errors = require('./error-classes');
const { config, validateConfig } = require('./config');

module.exports = {
  // Phi-Math Foundation
  ...phiConstants,

  // CSL Engine
  ...cslEngine,

  // Liquid Node Architecture
  ...liquidNode,

  // Structured Logging
  createLogger,
  requestLoggerMiddleware,
  LOG_LEVELS,

  // Error Classes
  ...errors,

  // Configuration
  config,
  validateConfig,
};
