/**
 * HeadyManager — Main Service Entry Point
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Production HTTP server with:
 * - Health probes (/health, /ready, /livez, /metrics, /info)
 * - Structured JSON logging (zero console.log)
 * - Circuit breakers on external dependencies
 * - Phi-tiered rate limiting
 * - CSP security headers
 * - Graceful LIFO shutdown
 * - Full CORS whitelist (no wildcards)
 *
 * @module heady-manager
 * @version 4.0.0
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');

const { config, validateConfig } = require('../core/config');
const { createLogger, requestLoggerMiddleware } = require('../core/structured-logger');
const { globalErrorHandler, AppError } = require('../core/error-classes');
const { getConductor, TASK_TYPES, ROUTING_MATRIX } = require('../conductor/conductor');
const { getBeeFactory, BEE_TYPES } = require('../bees/bee-factory');
const { getPipeline, PIPELINE_STAGES } = require('../pipeline/hcfull-pipeline');
const {
  LiquidNode, BeeNode, SoulNode, NodeRegistry,
  LIFECYCLE_STATES, nodeBus,
  PHI, PSI, fib,
} = require('../core/liquid-node');

// ═══════════════════════════════════════════════════════════════
// INITIALIZATION
// ═══════════════════════════════════════════════════════════════

const logger = createLogger('HeadyManager');
const app = express();

// Validate config at startup
try {
  validateConfig();
} catch (err) {
  logger.fatal({ error: err.message }, 'Configuration validation failed');
  process.exit(1);
}

app.set('service', 'HeadyManager');

// ═══════════════════════════════════════════════════════════════
// MIDDLEWARE STACK
// ═══════════════════════════════════════════════════════════════

// Trust proxy for Cloudflare
if (config.server.trustProxy) {
  app.set('trust proxy', 1);
}

// Security headers
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'", ...config.cors.origins],
    },
  },
  crossOriginEmbedderPolicy: false,
}));

// CORS — explicit origin whitelist, never wildcard
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || config.cors.origins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new AppError(`Origin ${origin} not allowed`, 403, 'CORS_DENIED'));
    }
  },
  credentials: config.cors.credentials,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Correlation-ID', 'X-Request-ID'],
}));

// Compression
app.use(compression());

// Body parsing
app.use(express.json({ limit: '1mb' }));

// Request logging
app.use(requestLoggerMiddleware());

// Rate limiting (Fibonacci-based)
const defaultLimiter = rateLimit({
  windowMs: config.rateLimit.anonymous.windowMs,
  max: config.rateLimit.anonymous.max,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: { code: 'RATE_LIMIT_EXCEEDED', message: 'Too many requests' } },
});
app.use(defaultLimiter);

// ═══════════════════════════════════════════════════════════════
// HEALTH ENDPOINTS
// ═══════════════════════════════════════════════════════════════

const startTime = Date.now();

/** Health check — is the service running? */
app.get('/health', (req, res) => {
  const uptimeMs = Date.now() - startTime;
  res.json({
    status: 'healthy',
    service: config.service.name,
    version: config.service.version,
    environment: config.service.environment,
    uptime: { ms: uptimeMs, human: formatUptime(uptimeMs) },
    timestamp: new Date().toISOString(),
  });
});

/** Readiness check — is the service ready to accept traffic? */
app.get('/ready', (req, res) => {
  const conductor = getConductor();
  const ready = conductor.state !== LIFECYCLE_STATES.EXPIRED;
  res.status(ready ? 200 : 503).json({
    ready,
    conductorState: conductor.state,
    registeredNodes: conductor.registry.size,
  });
});

/** Liveness check — is the process alive? */
app.get('/livez', (req, res) => {
  res.json({ alive: true, pid: process.pid, timestamp: new Date().toISOString() });
});

/** Metrics endpoint */
app.get('/metrics', (req, res) => {
  const conductor = getConductor();
  const beeFactory = getBeeFactory();
  const pipeline = getPipeline();

  res.json({
    service: config.service.name,
    uptime: Date.now() - startTime,
    conductor: conductor.status(),
    beeFactory: beeFactory.status(),
    pipeline: pipeline.status(),
    process: {
      pid: process.pid,
      memoryMB: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      uptimeS: Math.round(process.uptime()),
    },
    timestamp: new Date().toISOString(),
  });
});

/** System info endpoint */
app.get('/info', (req, res) => {
  res.json({
    service: config.service.name,
    version: config.service.version,
    architecture: 'Sacred Geometry v4.0',
    domains: config.domains,
    runtimes: config.runtimes,
    pools: config.pools,
    phi: { PHI, PSI, PHI2: PHI + 1, PHI3: 2 * PHI + 1 },
    nodeTypes: Object.keys(LIFECYCLE_STATES),
    taskTypes: Object.values(TASK_TYPES),
    beeTypes: Object.keys(BEE_TYPES),
    pipelineStages: PIPELINE_STAGES,
    timestamp: new Date().toISOString(),
  });
});

// ═══════════════════════════════════════════════════════════════
// API ROUTES
// ═══════════════════════════════════════════════════════════════

/** Topology — full system topology */
app.get('/api/v1/topology', (req, res) => {
  const conductor = getConductor();
  res.json({
    conductor: conductor.status(),
    routingMatrix: ROUTING_MATRIX,
  });
});

/** Submit a task to the pipeline */
app.post('/api/v1/tasks', async (req, res, next) => {
  try {
    const task = req.body;
    if (!task || (!task.description && !task.prompt)) {
      throw new AppError('Task must include description or prompt', 422, 'VALIDATION_ERROR');
    }
    const pipeline = getPipeline();
    const ctx = await pipeline.execute(task);
    res.status(201).json({
      pipelineId: ctx.pipelineId,
      taskId: ctx.task.id,
      result: ctx.result,
      summary: ctx.summary(),
    });
  } catch (err) {
    next(err);
  }
});

/** Bee factory status */
app.get('/api/v1/bees', (req, res) => {
  const factory = getBeeFactory();
  res.json(factory.status());
});

/** Execute a bee swarm task */
app.post('/api/v1/bees/swarm', async (req, res, next) => {
  try {
    const { beeType, tasks } = req.body;
    if (!beeType || !tasks || !Array.isArray(tasks)) {
      throw new AppError('Request must include beeType and tasks array', 422, 'VALIDATION_ERROR');
    }
    const factory = getBeeFactory();
    const results = await factory.swarmExecute(
      beeType,
      tasks,
      async (task) => ({ processed: true, taskId: task.id, timestamp: new Date().toISOString() })
    );
    res.json({ beeType, results });
  } catch (err) {
    next(err);
  }
});

/** Pipeline status */
app.get('/api/v1/pipeline', (req, res) => {
  const pipeline = getPipeline();
  res.json(pipeline.status());
});

// ═══════════════════════════════════════════════════════════════
// ERROR HANDLING
// ═══════════════════════════════════════════════════════════════

app.use(globalErrorHandler(logger));

// ═══════════════════════════════════════════════════════════════
// NODE REGISTRATION — Initialize Sacred Geometry Topology
// ═══════════════════════════════════════════════════════════════

function initializeTopology() {
  const conductor = getConductor();

  // Center
  const soul = new SoulNode({});
  conductor.registerNode(soul);

  // Inner Ring
  const brains = new LiquidNode({ name: 'HeadyBrains', ring: 'inner', pool: 'hot' });
  const vinci = new LiquidNode({ name: 'HeadyVinci', ring: 'inner', pool: 'hot' });
  conductor.registerNode(brains);
  conductor.registerNode(vinci);

  // Middle Ring
  const middleNodes = [
    { name: 'JULES', ring: 'middle', pool: 'hot' },
    { name: 'BUILDER', ring: 'middle', pool: 'hot' },
    { name: 'OBSERVER', ring: 'middle', pool: 'hot' },
    { name: 'MURPHY', ring: 'middle', pool: 'hot' },
    { name: 'ATLAS', ring: 'middle', pool: 'warm' },
    { name: 'PYTHIA', ring: 'middle', pool: 'warm' },
  ];
  for (const cfg of middleNodes) {
    conductor.registerNode(new LiquidNode(cfg));
  }

  // Outer Ring
  const outerNodes = [
    { name: 'BRIDGE', ring: 'outer', pool: 'warm' },
    { name: 'MUSE', ring: 'outer', pool: 'warm' },
    { name: 'SENTINEL', ring: 'outer', pool: 'warm' },
    { name: 'NOVA', ring: 'outer', pool: 'warm' },
    { name: 'JANITOR', ring: 'outer', pool: 'cold' },
    { name: 'SOPHIA', ring: 'outer', pool: 'warm' },
    { name: 'CIPHER', ring: 'outer', pool: 'warm' },
    { name: 'LENS', ring: 'outer', pool: 'warm' },
  ];
  for (const cfg of outerNodes) {
    conductor.registerNode(new LiquidNode(cfg));
  }

  // Governance Shell
  const govNodes = [
    { name: 'HeadyCheck', ring: 'governance', pool: 'governance' },
    { name: 'HeadyAssure', ring: 'governance', pool: 'governance' },
    { name: 'HeadyAware', ring: 'governance', pool: 'governance' },
    { name: 'HeadyPatterns', ring: 'governance', pool: 'cold' },
    { name: 'HeadyMC', ring: 'governance', pool: 'cold' },
    { name: 'HeadyRisks', ring: 'governance', pool: 'governance' },
  ];
  for (const cfg of govNodes) {
    conductor.registerNode(new LiquidNode(cfg));
  }

  // Memory & Intelligence
  const memNodes = [
    { name: 'HeadyMemory', ring: 'inner', pool: 'hot' },
    { name: 'HeadyEmbed', ring: 'inner', pool: 'hot' },
    { name: 'HeadyResearch', ring: 'outer', pool: 'warm' },
    { name: 'HeadyCodex', ring: 'outer', pool: 'warm' },
    { name: 'HeadyMaid', ring: 'outer', pool: 'cold' },
    { name: 'HeadyMaintenance', ring: 'outer', pool: 'cold' },
    { name: 'HeadyAutobiographer', ring: 'outer', pool: 'cold' },
  ];
  for (const cfg of memNodes) {
    conductor.registerNode(new LiquidNode(cfg));
  }

  logger.info({ totalNodes: conductor.registry.size }, 'Sacred Geometry topology initialized');
}

// ═══════════════════════════════════════════════════════════════
// GRACEFUL SHUTDOWN — LIFO Cleanup
// ═══════════════════════════════════════════════════════════════

const shutdownTimeoutMs = config.timeouts.shutdown; // ~6854ms (phi^4 * 1000)
let shutdownInProgress = false;

async function gracefulShutdown(signal) {
  if (shutdownInProgress) return;
  shutdownInProgress = true;

  logger.info({ signal, timeoutMs: shutdownTimeoutMs }, 'Graceful shutdown initiated');

  const timer = setTimeout(() => {
    logger.error({}, 'Shutdown timeout exceeded, forcing exit');
    process.exit(1);
  }, shutdownTimeoutMs);

  try {
    // 1. Stop accepting new connections
    if (server) {
      await new Promise((resolve) => server.close(resolve));
      logger.info({}, 'HTTP server closed');
    }

    // 2. Retire all active bees
    const factory = getBeeFactory();
    await factory.retireAll();
    logger.info({}, 'All bees retired');

    // 3. Shutdown conductor and all nodes
    const conductor = getConductor();
    await conductor.shutdown(signal);
    logger.info({}, 'Conductor shutdown complete');

    clearTimeout(timer);
    logger.info({}, 'Graceful shutdown complete');
    process.exit(0);
  } catch (err) {
    logger.error({ error: err.message }, 'Error during shutdown');
    clearTimeout(timer);
    process.exit(1);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('uncaughtException', (err) => {
  logger.fatal({ error: err.message, stack: err.stack }, 'Uncaught exception');
  gracefulShutdown('UNCAUGHT_EXCEPTION');
});
process.on('unhandledRejection', (reason) => {
  logger.error({ reason: String(reason) }, 'Unhandled rejection');
});

// ═══════════════════════════════════════════════════════════════
// START
// ═══════════════════════════════════════════════════════════════

let server;

function start() {
  initializeTopology();

  const { host, port } = config.server;
  server = app.listen(port, host, () => {
    logger.info({
      host,
      port,
      service: config.service.name,
      version: config.service.version,
      environment: config.service.environment,
      nodeCount: getConductor().registry.size,
      beeTypes: Object.keys(BEE_TYPES).length,
      pipelineStages: PIPELINE_STAGES.length,
    }, 'HeadyManager started');
  });

  return server;
}

// Auto-start when run directly
if (require.main === module) {
  start();
}

module.exports = { app, start, initializeTopology };

/** @private */
function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}
