/**
 * HCFullPipeline (HCFP) — 8-Stage Execution Engine
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Every significant operation flows through the full pipeline:
 * 1. Context Assembly → 2. Intent Classification → 3. Node Selection →
 * 4. Execution → 5. Quality Gate → 6. Assurance Gate →
 * 7. Pattern Capture → 8. Story Update
 *
 * @module hcfull-pipeline
 * @version 4.0.0
 */

const { randomUUID } = require('crypto');
const { createLogger, nodeBus } = require('../core/liquid-node');
const { getConductor, TASK_TYPES } = require('../conductor/conductor');
const { getBeeFactory } = require('../bees/bee-factory');
const { PHI, PSI, fib, CSL_THRESHOLDS } = require('../core/phi-constants');
const { AppError } = require('../core/error-classes');

const logger = createLogger('HCFullPipeline');

// ═══════════════════════════════════════════════════════════════
// PIPELINE STAGES
// ═══════════════════════════════════════════════════════════════

const PIPELINE_STAGES = Object.freeze([
  'context_assembly',
  'intent_classification',
  'node_selection',
  'execution',
  'quality_gate',
  'assurance_gate',
  'pattern_capture',
  'story_update',
]);

/**
 * Pipeline execution context — tracks state across stages.
 */
class PipelineContext {
  /**
   * @param {Object} task - Original task
   */
  constructor(task) {
    this.pipelineId = randomUUID();
    this.task = { ...task, id: task.id || randomUUID() };
    this.startTime = Date.now();
    this.stages = {};
    this.currentStage = null;
    this.context = {};          // Gathered context from stage 1
    this.intent = null;         // Classified intent from stage 2
    this.selectedNode = null;   // Chosen node from stage 3
    this.result = null;         // Execution result from stage 4
    this.qualityScore = 0;      // Quality gate score from stage 5
    this.assured = false;       // Assurance gate pass from stage 6
    this.patterns = [];         // Captured patterns from stage 7
    this.narrative = '';        // Story update from stage 8
    this.errors = [];
  }

  /**
   * Record a stage's execution.
   * @param {string} stage - Stage name
   * @param {Object} data - Stage output data
   */
  recordStage(stage, data) {
    this.stages[stage] = {
      completedAt: new Date().toISOString(),
      durationMs: Date.now() - this.startTime,
      data,
    };
  }

  /**
   * Get pipeline summary.
   * @returns {Object}
   */
  summary() {
    return {
      pipelineId: this.pipelineId,
      taskId: this.task.id,
      totalDurationMs: Date.now() - this.startTime,
      stagesCompleted: Object.keys(this.stages).length,
      totalStages: PIPELINE_STAGES.length,
      intent: this.intent,
      selectedNode: this.selectedNode,
      qualityScore: this.qualityScore,
      assured: this.assured,
      success: this.errors.length === 0,
      errors: this.errors,
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// PIPELINE ENGINE
// ═══════════════════════════════════════════════════════════════

class HCFullPipeline {
  constructor() {
    this.conductor = getConductor();
    this.beeFactory = getBeeFactory();
    this.logger = createLogger('HCFP');
    this.history = [];
    this.maxHistory = fib(13); // 233 entries
  }

  /**
   * Execute the full 8-stage pipeline for a task.
   * @param {Object} task - Task to execute
   * @returns {Promise<Object>} Pipeline result with context
   */
  async execute(task) {
    const ctx = new PipelineContext(task);
    this.logger.info({ pipelineId: ctx.pipelineId, taskId: ctx.task.id }, 'Pipeline starting');

    try {
      // Stage 1: Context Assembly
      await this._stage1_contextAssembly(ctx);

      // Stage 2: Intent Classification
      await this._stage2_intentClassification(ctx);

      // Stage 3: Node Selection
      await this._stage3_nodeSelection(ctx);

      // Stage 4: Execution
      await this._stage4_execution(ctx);

      // Stage 5: Quality Gate
      await this._stage5_qualityGate(ctx);

      // Stage 6: Assurance Gate
      await this._stage6_assuranceGate(ctx);

      // Stage 7: Pattern Capture
      await this._stage7_patternCapture(ctx);

      // Stage 8: Story Update
      await this._stage8_storyUpdate(ctx);

      this.logger.info(ctx.summary(), 'Pipeline completed');
    } catch (err) {
      ctx.errors.push({
        stage: ctx.currentStage,
        error: err.message,
        timestamp: new Date().toISOString(),
      });
      this.logger.error({
        pipelineId: ctx.pipelineId,
        stage: ctx.currentStage,
        error: err.message,
      }, 'Pipeline failed');
    }

    this._recordHistory(ctx);
    nodeBus.emit('pipeline:complete', ctx.summary());
    return ctx;
  }

  // ─────────────────────────────────────────────────────────────
  // STAGE IMPLEMENTATIONS
  // ─────────────────────────────────────────────────────────────

  /** Stage 1: HeadyBrains gathers all relevant context */
  async _stage1_contextAssembly(ctx) {
    ctx.currentStage = 'context_assembly';
    this.logger.info({ pipelineId: ctx.pipelineId }, 'Stage 1: Context Assembly');

    ctx.context = {
      taskDescription: ctx.task.description || ctx.task.prompt || '',
      taskType: ctx.task.type || 'unknown',
      hasEmbedding: !!ctx.task.embedding,
      metadata: ctx.task.metadata || {},
      environment: process.env.NODE_ENV || 'development',
      timestamp: new Date().toISOString(),
    };

    ctx.recordStage('context_assembly', ctx.context);
  }

  /** Stage 2: Conductor determines task type + domain */
  async _stage2_intentClassification(ctx) {
    ctx.currentStage = 'intent_classification';
    this.logger.info({ pipelineId: ctx.pipelineId }, 'Stage 2: Intent Classification');

    ctx.intent = this.conductor.classifyTask(ctx.task);
    ctx.recordStage('intent_classification', { intent: ctx.intent });
  }

  /** Stage 3: CSL-scored capability routing picks optimal nodes */
  async _stage3_nodeSelection(ctx) {
    ctx.currentStage = 'node_selection';
    this.logger.info({ pipelineId: ctx.pipelineId }, 'Stage 3: Node Selection');

    const route = this.conductor.routeTask(ctx.task);
    ctx.selectedNode = route.node.name;
    ctx.recordStage('node_selection', {
      node: route.node.name,
      score: route.score,
      taskType: route.taskType,
    });
  }

  /** Stage 4: Parallel or sequential node activation */
  async _stage4_execution(ctx) {
    ctx.currentStage = 'execution';
    this.logger.info({ pipelineId: ctx.pipelineId, node: ctx.selectedNode }, 'Stage 4: Execution');

    ctx.result = await this.conductor.executeTask(ctx.task);
    ctx.recordStage('execution', { resultType: typeof ctx.result });
  }

  /** Stage 5: HeadyCheck validates output */
  async _stage5_qualityGate(ctx) {
    ctx.currentStage = 'quality_gate';
    this.logger.info({ pipelineId: ctx.pipelineId }, 'Stage 5: Quality Gate');

    // Quality scoring: check result completeness, no errors, valid structure
    let score = 0;
    if (ctx.result !== null && ctx.result !== undefined) score += 0.4;
    if (ctx.errors.length === 0) score += 0.3;
    if (typeof ctx.result === 'object') score += 0.3;

    ctx.qualityScore = Math.min(score, 1.0);
    const passed = ctx.qualityScore >= CSL_THRESHOLDS.LOW; // ≈ 0.691

    ctx.recordStage('quality_gate', { score: ctx.qualityScore, passed });

    if (!passed) {
      this.logger.warn({
        pipelineId: ctx.pipelineId,
        qualityScore: ctx.qualityScore,
        threshold: CSL_THRESHOLDS.LOW,
      }, 'Quality gate failed');
    }
  }

  /** Stage 6: HeadyAssure certifies for deployment */
  async _stage6_assuranceGate(ctx) {
    ctx.currentStage = 'assurance_gate';
    this.logger.info({ pipelineId: ctx.pipelineId }, 'Stage 6: Assurance Gate');

    ctx.assured = ctx.qualityScore >= CSL_THRESHOLDS.LOW && ctx.errors.length === 0;
    ctx.recordStage('assurance_gate', { assured: ctx.assured });
  }

  /** Stage 7: HeadyPatterns logs workflow for learning */
  async _stage7_patternCapture(ctx) {
    ctx.currentStage = 'pattern_capture';
    this.logger.info({ pipelineId: ctx.pipelineId }, 'Stage 7: Pattern Capture');

    ctx.patterns = [{
      type: 'pipeline_execution',
      intent: ctx.intent,
      node: ctx.selectedNode,
      qualityScore: ctx.qualityScore,
      durationMs: Date.now() - ctx.startTime,
      success: ctx.errors.length === 0,
      timestamp: new Date().toISOString(),
    }];

    ctx.recordStage('pattern_capture', { patterns: ctx.patterns });
    nodeBus.emit('patterns:captured', ctx.patterns);
  }

  /** Stage 8: HeadyAutobiographer records narrative */
  async _stage8_storyUpdate(ctx) {
    ctx.currentStage = 'story_update';
    this.logger.info({ pipelineId: ctx.pipelineId }, 'Stage 8: Story Update');

    const duration = Date.now() - ctx.startTime;
    ctx.narrative = [
      `Pipeline ${ctx.pipelineId} processed task ${ctx.task.id}.`,
      `Intent: ${ctx.intent}. Routed to: ${ctx.selectedNode}.`,
      `Quality: ${(ctx.qualityScore * 100).toFixed(1)}%. Duration: ${duration}ms.`,
      ctx.assured ? 'Assured for deployment.' : 'Assurance pending.',
    ].join(' ');

    ctx.recordStage('story_update', { narrative: ctx.narrative });
    nodeBus.emit('story:updated', { pipelineId: ctx.pipelineId, narrative: ctx.narrative });
  }

  // ─────────────────────────────────────────────────────────────
  // PIPELINE MANAGEMENT
  // ─────────────────────────────────────────────────────────────

  /**
   * Get pipeline status and history.
   * @returns {Object}
   */
  status() {
    return {
      stages: PIPELINE_STAGES,
      stageCount: PIPELINE_STAGES.length,
      historySize: this.history.length,
      recentPipelines: this.history.slice(-fib(6)).map(ctx => ctx.summary()),
    };
  }

  /** @private */
  _recordHistory(ctx) {
    this.history.push(ctx);
    if (this.history.length > this.maxHistory) {
      this.history = this.history.slice(-this.maxHistory);
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// SINGLETON
// ═══════════════════════════════════════════════════════════════

let pipelineInstance = null;

/**
 * Get or create the singleton HCFullPipeline.
 * @returns {HCFullPipeline}
 */
function getPipeline() {
  if (!pipelineInstance) {
    pipelineInstance = new HCFullPipeline();
  }
  return pipelineInstance;
}

module.exports = {
  HCFullPipeline,
  getPipeline,
  PipelineContext,
  PIPELINE_STAGES,
};
