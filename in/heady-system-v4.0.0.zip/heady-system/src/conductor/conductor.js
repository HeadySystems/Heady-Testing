/**
 * HeadyConductor — Central Orchestration Authority
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Every request flows through the Conductor:
 *   User → HeadyBuddy → HeadyConductor → Target Node(s) → HeadyConductor → HeadyBuddy
 *
 * Routing is CSL-scored, not priority-based. No arbitrary rankings.
 *
 * @module conductor
 * @version 4.0.0
 */

const {
  LiquidNode, ConductorNode, NodeRegistry, CircuitBreaker,
  createLogger, nodeBus,
  PHI, PSI, fib,
  CSL_THRESHOLDS, cosineSimilarity, cslGate,
  phiFusionWeights, phiBackoff,
  SIZING,
} = require('../core/liquid-node');

const { config } = require('../core/config');
const {
  AppError, NotFoundError, NodeUnavailableError,
} = require('../core/error-classes');

// ═══════════════════════════════════════════════════════════════
// TASK TYPES & ROUTING MATRIX
// ═══════════════════════════════════════════════════════════════

/** Task type definitions with their target node affinities */
const TASK_TYPES = Object.freeze({
  CODE_GENERATION:  'code_generation',
  CODE_REVIEW:      'code_review',
  SECURITY_AUDIT:   'security_audit',
  ARCHITECTURE:     'architecture',
  RESEARCH:         'research',
  DOCUMENTATION:    'documentation',
  QUICK_TASK:       'quick_task',
  CREATIVE:         'creative',
  CLEANUP:          'cleanup',
  ANALYTICS:        'analytics',
  EMBEDDING:        'embedding',
  MEMORY_OP:        'memory_op',
  VALIDATION:       'validation',
});

/**
 * Routing matrix: task type → ordered fallback chain of node names.
 * Conductor uses CSL scoring within each tier for final selection.
 */
const ROUTING_MATRIX = Object.freeze({
  [TASK_TYPES.CODE_GENERATION]:  ['JULES', 'BUILDER', 'HeadyBrains'],
  [TASK_TYPES.CODE_REVIEW]:      ['OBSERVER', 'MURPHY', 'HeadyBrains'],
  [TASK_TYPES.SECURITY_AUDIT]:   ['MURPHY', 'SENTINEL', 'CIPHER'],
  [TASK_TYPES.ARCHITECTURE]:     ['ATLAS', 'PYTHIA', 'HeadyVinci'],
  [TASK_TYPES.RESEARCH]:         ['SOPHIA', 'HeadyResearch', 'HeadyBrains'],
  [TASK_TYPES.DOCUMENTATION]:    ['HeadyCodex', 'ATLAS', 'BUILDER'],
  [TASK_TYPES.QUICK_TASK]:       ['HeadyBrains', 'JULES', 'BUILDER'],
  [TASK_TYPES.CREATIVE]:         ['MUSE', 'NOVA', 'HeadyBrains'],
  [TASK_TYPES.CLEANUP]:          ['JANITOR', 'HeadyMaid', 'HeadyMaintenance'],
  [TASK_TYPES.ANALYTICS]:        ['HeadyPatterns', 'HeadyMC', 'PYTHIA'],
  [TASK_TYPES.EMBEDDING]:        ['HeadyEmbed', 'HeadyMemory', 'HeadyBrains'],
  [TASK_TYPES.MEMORY_OP]:        ['HeadyMemory', 'HeadyEmbed', 'HeadyBrains'],
  [TASK_TYPES.VALIDATION]:       ['HeadyCheck', 'HeadyAssure', 'HeadySoul'],
});

// ═══════════════════════════════════════════════════════════════
// HEADY CONDUCTOR CLASS
// ═══════════════════════════════════════════════════════════════

class HeadyConductor extends ConductorNode {
  constructor() {
    super({ name: 'HeadyConductor' });
    this.registry = new NodeRegistry();
    this.breakers = new Map();
    this.taskHistory = [];
    this.maxHistory = fib(16); // 987 entries
  }

  /**
   * Register a node and create its circuit breaker.
   * @param {LiquidNode} node - Node to register
   */
  registerNode(node) {
    super.registerNode(node);
    this.registry.register(node);
    this.breakers.set(node.name, new CircuitBreaker({
      name: `cb-${node.name}`,
      failureThreshold: SIZING.FAILURE_THRESHOLD,
    }));
    this.logger.info({ node: node.name, ring: node.ring, pool: node.pool }, 'Node registered with circuit breaker');
  }

  /**
   * Classify a task's type based on its content or explicit type.
   * In production, this uses embedding + CSL scoring against task type prototypes.
   * @param {Object} task - Task to classify
   * @returns {string} Task type from TASK_TYPES
   */
  classifyTask(task) {
    if (task.type && TASK_TYPES[task.type.toUpperCase()]) {
      return TASK_TYPES[task.type.toUpperCase()];
    }
    if (task.taskType && Object.values(TASK_TYPES).includes(task.taskType)) {
      return task.taskType;
    }
    // Default classification by keywords
    const text = (task.description || task.prompt || '').toLowerCase();
    // Order matters: more specific matches first to avoid false positives
    if (text.includes('review') || text.includes('code review')) return TASK_TYPES.CODE_REVIEW;
    if (text.includes('security') || text.includes('audit') || text.includes('vulnerability')) return TASK_TYPES.SECURITY_AUDIT;
    if (text.includes('code') || text.includes('implement') || text.includes('build')) return TASK_TYPES.CODE_GENERATION;
    if (text.includes('architect') || text.includes('design') || text.includes('plan')) return TASK_TYPES.ARCHITECTURE;
    if (text.includes('research') || text.includes('find') || text.includes('search')) return TASK_TYPES.RESEARCH;
    if (text.includes('document') || text.includes('docs') || text.includes('readme')) return TASK_TYPES.DOCUMENTATION;
    if (text.includes('creative') || text.includes('generate') || text.includes('write')) return TASK_TYPES.CREATIVE;
    if (text.includes('clean') || text.includes('refactor')) return TASK_TYPES.CLEANUP;
    if (text.includes('analyz') || text.includes('metric') || text.includes('pattern')) return TASK_TYPES.ANALYTICS;
    if (text.includes('embed')) return TASK_TYPES.EMBEDDING;
    if (text.includes('memory') || text.includes('store') || text.includes('retrieve')) return TASK_TYPES.MEMORY_OP;
    if (text.includes('validate') || text.includes('verify') || text.includes('test')) return TASK_TYPES.VALIDATION;
    return TASK_TYPES.QUICK_TASK;
  }

  /**
   * Route a task to the optimal node(s) using CSL-scored capability matching.
   * Falls through the routing matrix with circuit breaker protection.
   *
   * @param {Object} task - Task with at minimum: { id, embedding?, type?, description? }
   * @returns {{ node: LiquidNode, score: number, taskType: string }}
   */
  routeTask(task) {
    const taskType = this.classifyTask(task);
    const fallbackChain = ROUTING_MATRIX[taskType] || ROUTING_MATRIX[TASK_TYPES.QUICK_TASK];

    this.logger.info({ taskId: task.id, taskType, fallbackChain }, 'Routing task');

    // Try each node in the fallback chain
    for (const nodeName of fallbackChain) {
      const node = this.registry.get(nodeName);
      if (!node) continue;
      if (!node.canAcceptWork()) continue;

      // Check circuit breaker
      const breaker = this.breakers.get(nodeName);
      if (breaker && breaker.state === 'open') {
        this.logger.warn({ node: nodeName, breakerState: breaker.state }, 'Circuit breaker open, skipping');
        continue;
      }

      // CSL-score if task has embedding
      let score = 1.0;
      if (task.embedding) {
        score = node.evaluateTask(task.embedding);
      }

      this.logger.info({ taskId: task.id, node: nodeName, score }, 'Task routed');
      return { node, score, taskType };
    }

    throw new NodeUnavailableError('all', 'no available nodes match task');
  }

  /**
   * Execute a task through the full Conductor pipeline.
   * @param {Object} task - Task to execute
   * @returns {Promise<Object>} Execution result
   */
  async executeTask(task) {
    const startTime = Date.now();
    const { node, score, taskType } = this.routeTask(task);
    const breaker = this.breakers.get(node.name);

    try {
      const result = await breaker.exec(() => node._handleTask(task));

      const elapsed = Date.now() - startTime;
      const record = {
        taskId: task.id,
        taskType,
        node: node.name,
        score,
        durationMs: elapsed,
        success: true,
        timestamp: new Date().toISOString(),
      };
      this._recordHistory(record);

      this.logger.info(record, 'Task completed');
      nodeBus.emit('conductor:taskComplete', record);

      return result;
    } catch (err) {
      const elapsed = Date.now() - startTime;
      const record = {
        taskId: task.id,
        taskType,
        node: node.name,
        score,
        durationMs: elapsed,
        success: false,
        error: err.message,
        timestamp: new Date().toISOString(),
      };
      this._recordHistory(record);

      this.logger.error(record, 'Task failed');
      nodeBus.emit('conductor:taskFailed', record);

      throw err;
    }
  }

  /**
   * Get conductor status and topology.
   * @returns {Object} Full conductor status
   */
  status() {
    const nodes = this.registry.healthAll();
    const breakers = [...this.breakers.entries()].map(([name, cb]) => cb.health());

    return {
      conductor: this.health(),
      nodes,
      breakers,
      taskTypes: Object.values(TASK_TYPES),
      routingMatrix: ROUTING_MATRIX,
      historySize: this.taskHistory.length,
      recentTasks: this.taskHistory.slice(-fib(6)),
    };
  }

  /** @private */
  _recordHistory(record) {
    this.taskHistory.push(record);
    if (this.taskHistory.length > this.maxHistory) {
      this.taskHistory = this.taskHistory.slice(-this.maxHistory);
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// SINGLETON CONDUCTOR INSTANCE
// ═══════════════════════════════════════════════════════════════

let conductorInstance = null;

/**
 * Get or create the singleton HeadyConductor.
 * @returns {HeadyConductor}
 */
function getConductor() {
  if (!conductorInstance) {
    conductorInstance = new HeadyConductor();
  }
  return conductorInstance;
}

module.exports = {
  HeadyConductor,
  getConductor,
  TASK_TYPES,
  ROUTING_MATRIX,
};
