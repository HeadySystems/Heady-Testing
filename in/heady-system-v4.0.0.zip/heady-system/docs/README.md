# Heady System — Sacred Geometry v4.0

> **Full-Stack Sovereign AI Platform**
> © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents

---

## Quick Start

```bash
# Clone and setup
git clone <repo>
cd heady-system
cp .env.example .env

# Install dependencies
npm install

# Validate system
npm run validate

# Start (development)
npm run dev

# Start (Docker)
docker-compose up -d
```

Application: `http://localhost:3000`
Health: `http://localhost:3000/health`
Metrics: `http://localhost:3000/metrics`
Info: `http://localhost:3000/info`

---

## Architecture

### Sacred Geometry Node Topology

```
                    ┌── Governance Shell ──────────────────┐
                    │  HeadyCheck · HeadyAssure · HeadyAware │
                    │  HeadyPatterns · HeadyMC · HeadyRisks  │
                    │                                        │
                    │  ┌── Outer Ring ────────────────────┐  │
                    │  │  BRIDGE · MUSE · SENTINEL · NOVA │  │
                    │  │  JANITOR · SOPHIA · CIPHER · LENS│  │
                    │  │                                  │  │
                    │  │  ┌── Middle Ring ─────────────┐  │  │
                    │  │  │  JULES · BUILDER · OBSERVER│  │  │
                    │  │  │  MURPHY · ATLAS · PYTHIA   │  │  │
                    │  │  │                            │  │  │
                    │  │  │  ┌── Inner Ring ────────┐  │  │  │
                    │  │  │  │  HeadyBrains         │  │  │  │
                    │  │  │  │  HeadyConductor      │  │  │  │
                    │  │  │  │  HeadyVinci          │  │  │  │
                    │  │  │  │    ┌─────────┐       │  │  │  │
                    │  │  │  │    │HeadySoul│       │  │  │  │
                    │  │  │  │    └─────────┘       │  │  │  │
                    │  │  │  └──────────────────────┘  │  │  │
                    │  │  └────────────────────────────┘  │  │
                    │  └──────────────────────────────────┘  │
                    └────────────────────────────────────────┘
```

### 9 Core Domains

| Domain | Role |
|--------|------|
| headyme.com | Command center |
| headysystems.com | Core architecture engine |
| headyconnection.org | 501(c)(3) nonprofit |
| headybuddy.org | AI companion experience |
| headymcp.com | MCP gateway layer |
| headyio.com | Developer platform |
| headybot.com | Automation and agents |
| headyapi.com | Public API gateway |
| headyai.com | Intelligence routing hub |

### 3 Colab Pro+ Runtimes (Latent Space)

| Runtime | Role | GPU | Port | Domain |
|---------|------|-----|------|--------|
| 1 | Vector Memory & Embeddings | A100/V100 | 3301 | vector.headyos.com |
| 2 | LLM Inference & Agents | A100 | 3302 | llm.headyos.com |
| 3 | Training & Analytics | TPU v2-8 | 3303 | train.headyos.com |

---

## Core Modules

### Phi-Math Foundation
Every constant derives from φ (1.618) or Fibonacci. Zero magic numbers.

### CSL Engine (Continuous Semantic Logic)
Vector operations as logical gates: AND, OR, NOT, IMPLY, XOR, CONSENSUS, GATE.
60+ provisional patents.

### Liquid Nodes
Every component is a LiquidNode — self-aware, self-healing, operating in 384D vector space.

### HeadyConductor
Central orchestration — CSL-scored task routing through the Sacred Geometry topology.

### HeadyBee Swarm (33 Types)
Ephemeral workers: spawn → execute → report → retire.

### HCFullPipeline (8 Stages)
1. Context Assembly → 2. Intent Classification → 3. Node Selection →
4. Execution → 5. Quality Gate → 6. Assurance Gate →
7. Pattern Capture → 8. Story Update

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /health | Health check |
| GET | /ready | Readiness probe |
| GET | /livez | Liveness probe |
| GET | /metrics | System metrics |
| GET | /info | System information |
| GET | /api/v1/topology | Full topology |
| POST | /api/v1/tasks | Submit task to pipeline |
| GET | /api/v1/bees | Bee factory status |
| POST | /api/v1/bees/swarm | Execute swarm task |
| GET | /api/v1/pipeline | Pipeline status |

---

## File Structure

```
heady-system/
├── package.json
├── Dockerfile
├── docker-compose.yml
├── .env.example
├── src/
│   ├── index.js                    # Barrel export
│   ├── core/
│   │   ├── index.js                # Core barrel
│   │   ├── phi-constants.js        # Phi-math foundation
│   │   ├── csl-engine.js           # CSL gates & operations
│   │   ├── liquid-node.js          # LiquidNode base class
│   │   ├── structured-logger.js    # JSON logger
│   │   ├── error-classes.js        # Typed error hierarchy
│   │   └── config.js               # Environment config
│   ├── conductor/
│   │   └── conductor.js            # HeadyConductor orchestrator
│   ├── bees/
│   │   └── bee-factory.js          # BeeFactory + 33 types
│   ├── pipeline/
│   │   └── hcfull-pipeline.js      # 8-stage pipeline
│   └── services/
│       └── heady-manager.js        # Main HTTP service
├── notebooks/
│   ├── colab_setup_vector_ops.py   # Runtime 1
│   ├── colab_setup_llm_inference.py # Runtime 2
│   ├── colab_setup_training.py     # Runtime 3
│   ├── colab-runtime-config.py     # Runtime manager
│   └── cloudflare_tunnel_config.yml
├── scripts/
│   ├── init-db.sql                 # PostgreSQL + pgvector
│   ├── health-check.js             # Health probe script
│   └── validate-system.js          # System validation
├── tests/
│   └── system.test.js              # Full test suite
├── ui/
│   └── command-center/
│       └── index.html              # Dashboard UI
└── docs/
    ├── README.md                   # This file
    └── ecosystem-map.md            # Complete ecosystem reference
```

---

## Commands

```bash
npm start           # Start HeadyManager
npm run dev         # Start with file watching
npm test            # Run test suite
npm run validate    # Validate system integrity
npm run health      # Check health endpoints
```

---

*Φ ≈ 1.618 · Sacred Geometry v4.0 · Alive Software Architecture · 60+ Provisional Patents*
*© 2026 HeadySystems Inc. — Eric Haywood, Founder*
