#!/usr/bin/env node
/**
 * Heady Health Check Script
 * Usage: node scripts/health-check.js [host] [port]
 */

const http = require('http');
const host = process.argv[2] || 'localhost';
const port = process.argv[3] || 3000;

const endpoints = ['/health', '/ready', '/livez', '/info'];

async function checkEndpoint(path) {
  return new Promise((resolve) => {
    const req = http.get(`http://${host}:${port}${path}`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ path, status: res.statusCode, data: JSON.parse(data) });
        } catch {
          resolve({ path, status: res.statusCode, data });
        }
      });
    });
    req.on('error', (err) => {
      resolve({ path, status: 0, error: err.message });
    });
    req.setTimeout(5000, () => {
      req.destroy();
      resolve({ path, status: 0, error: 'timeout' });
    });
  });
}

async function main() {
  const results = await Promise.all(endpoints.map(checkEndpoint));
  const allHealthy = results.every(r => r.status === 200);

  for (const r of results) {
    const icon = r.status === 200 ? '\u2705' : '\u274C';
    process.stdout.write(`${icon} ${r.path} → ${r.status}\n`);
    if (r.data && typeof r.data === 'object') {
      process.stdout.write(`   ${JSON.stringify(r.data, null, 2).split('\n').join('\n   ')}\n`);
    }
    if (r.error) {
      process.stderr.write(`   Error: ${r.error}\n`);
    }
  }

  process.exit(allHealthy ? 0 : 1);
}

main();
