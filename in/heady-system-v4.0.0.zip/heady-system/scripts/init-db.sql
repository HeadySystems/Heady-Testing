-- ═══════════════════════════════════════════════════════════════
-- Heady System — PostgreSQL + pgvector Initialization
-- © 2026 HeadySystems Inc. — Sacred Geometry v4.0
-- ═══════════════════════════════════════════════════════════════

-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- ─── Vector Memory Table (384D embeddings) ──────────────────
CREATE TABLE IF NOT EXISTS vector_memory (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content TEXT NOT NULL,
  embedding vector(384) NOT NULL,
  metadata JSONB DEFAULT '{}',
  node_name VARCHAR(255),
  ring VARCHAR(50),
  pool VARCHAR(50),
  coherence_score FLOAT DEFAULT 1.0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- HNSW index: m=21 (fib(8)), ef_construction=89 (fib(11))
CREATE INDEX IF NOT EXISTS idx_vector_memory_embedding
  ON vector_memory USING hnsw (embedding vector_cosine_ops)
  WITH (m = 21, ef_construction = 89);

-- Full-text search index (BM25 via tsvector)
ALTER TABLE vector_memory ADD COLUMN IF NOT EXISTS search_vector tsvector
  GENERATED ALWAYS AS (to_tsvector('english', content)) STORED;
CREATE INDEX IF NOT EXISTS idx_vector_memory_search ON vector_memory USING gin(search_vector);

-- Metadata index
CREATE INDEX IF NOT EXISTS idx_vector_memory_metadata ON vector_memory USING gin(metadata);

-- Node and pool indexes
CREATE INDEX IF NOT EXISTS idx_vector_memory_node ON vector_memory(node_name);
CREATE INDEX IF NOT EXISTS idx_vector_memory_pool ON vector_memory(pool);

-- ─── Node Registry Table ────────────────────────────────────
CREATE TABLE IF NOT EXISTS node_registry (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) UNIQUE NOT NULL,
  ring VARCHAR(50) NOT NULL,
  pool VARCHAR(50) NOT NULL,
  domain VARCHAR(255),
  state VARCHAR(50) DEFAULT 'init',
  coherence_score FLOAT DEFAULT 1.0,
  embedding vector(384),
  metrics JSONB DEFAULT '{}',
  last_heartbeat TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_node_registry_ring ON node_registry(ring);
CREATE INDEX IF NOT EXISTS idx_node_registry_pool ON node_registry(pool);
CREATE INDEX IF NOT EXISTS idx_node_registry_state ON node_registry(state);

-- ─── Pipeline History Table ─────────────────────────────────
CREATE TABLE IF NOT EXISTS pipeline_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  pipeline_id UUID NOT NULL,
  task_id UUID NOT NULL,
  task_type VARCHAR(100),
  intent VARCHAR(100),
  selected_node VARCHAR(255),
  quality_score FLOAT,
  assured BOOLEAN DEFAULT FALSE,
  stages JSONB DEFAULT '{}',
  patterns JSONB DEFAULT '[]',
  narrative TEXT,
  duration_ms INTEGER,
  success BOOLEAN DEFAULT TRUE,
  errors JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pipeline_history_task ON pipeline_history(task_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_history_node ON pipeline_history(selected_node);
CREATE INDEX IF NOT EXISTS idx_pipeline_history_created ON pipeline_history(created_at DESC);

-- ─── Bee Activity Log ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS bee_activity (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bee_name VARCHAR(255) NOT NULL,
  bee_type VARCHAR(100) NOT NULL,
  action VARCHAR(50) NOT NULL,
  task_id UUID,
  result JSONB,
  duration_ms INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_bee_activity_type ON bee_activity(bee_type);
CREATE INDEX IF NOT EXISTS idx_bee_activity_created ON bee_activity(created_at DESC);

-- ─── Audit Log (SOC 2 ready) ────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
  id BIGSERIAL PRIMARY KEY,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  tool VARCHAR(255),
  user_id VARCHAR(255),
  input_hash VARCHAR(64),
  output_hash VARCHAR(64),
  duration_ms INTEGER,
  prev_hash VARCHAR(64),
  record_hash VARCHAR(64)
);

CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp ON audit_log(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id);

-- ─── Graph RAG: Entity & Relationship Tables ────────────────
CREATE TABLE IF NOT EXISTS graph_entities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(500) NOT NULL,
  entity_type VARCHAR(100),
  embedding vector(384),
  properties JSONB DEFAULT '{}',
  community_id INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_graph_entities_name ON graph_entities(name);
CREATE INDEX IF NOT EXISTS idx_graph_entities_type ON graph_entities(entity_type);
CREATE INDEX IF NOT EXISTS idx_graph_entities_embedding
  ON graph_entities USING hnsw (embedding vector_cosine_ops)
  WITH (m = 21, ef_construction = 89);

CREATE TABLE IF NOT EXISTS graph_relationships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source_id UUID REFERENCES graph_entities(id),
  target_id UUID REFERENCES graph_entities(id),
  relationship_type VARCHAR(255),
  weight FLOAT DEFAULT 1.0,
  properties JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_graph_rel_source ON graph_relationships(source_id);
CREATE INDEX IF NOT EXISTS idx_graph_rel_target ON graph_relationships(target_id);
CREATE INDEX IF NOT EXISTS idx_graph_rel_type ON graph_relationships(relationship_type);

-- ─── Set HNSW search parameters ────────────────────────────
-- ef_search = 89 (fib(11)) for production quality
SET hnsw.ef_search = 89;
