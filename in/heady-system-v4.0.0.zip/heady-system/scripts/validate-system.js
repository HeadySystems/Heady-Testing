#!/usr/bin/env node
/**
 * Heady System Validation Script
 * Validates the entire system can load without errors.
 */

const process = require('process');

function validate() {
  const checks = [];

  // Check 1: Core modules load
  try {
    const core = require('../src/core');
    checks.push({ name: 'Core modules', pass: true, detail: `${Object.keys(core).length} exports` });
  } catch (err) {
    checks.push({ name: 'Core modules', pass: false, detail: err.message });
  }

  // Check 2: Phi constants are correct
  try {
    const { PHI, PSI, fib, CSL_THRESHOLDS } = require('../src/core/phi-constants');
    const phiCorrect = Math.abs(PHI - 1.618033988749895) < 1e-10;
    const psiCorrect = Math.abs(PSI - 0.618033988749895) < 1e-10;
    const fibCorrect = fib(10) === 55;
    checks.push({ name: 'Phi constants', pass: phiCorrect && psiCorrect && fibCorrect, detail: `PHI=${PHI.toFixed(6)}, PSI=${PSI.toFixed(6)}, fib(10)=${fib(10)}` });
  } catch (err) {
    checks.push({ name: 'Phi constants', pass: false, detail: err.message });
  }

  // Check 3: CSL engine works
  try {
    const { cosineSimilarity, cslAND, cslOR, cslNOT } = require('../src/core/csl-engine');
    const a = Array.from({ length: 384 }, (_, i) => Math.sin(i));
    const norm = Math.sqrt(a.reduce((s, v) => s + v * v, 0));
    const unitA = a.map(v => v / norm);
    const sim = cosineSimilarity(unitA, unitA);
    checks.push({ name: 'CSL engine', pass: Math.abs(sim - 1.0) < 1e-6, detail: `self-similarity=${sim.toFixed(6)}` });
  } catch (err) {
    checks.push({ name: 'CSL engine', pass: false, detail: err.message });
  }

  // Check 4: Conductor loads
  try {
    const { getConductor, TASK_TYPES } = require('../src/conductor/conductor');
    const conductor = getConductor();
    checks.push({ name: 'Conductor', pass: true, detail: `${Object.keys(TASK_TYPES).length} task types` });
  } catch (err) {
    checks.push({ name: 'Conductor', pass: false, detail: err.message });
  }

  // Check 5: Bee factory loads
  try {
    const { getBeeFactory, BEE_TYPES } = require('../src/bees/bee-factory');
    const factory = getBeeFactory();
    checks.push({ name: 'Bee factory', pass: true, detail: `${Object.keys(BEE_TYPES).length} bee types` });
  } catch (err) {
    checks.push({ name: 'Bee factory', pass: false, detail: err.message });
  }

  // Check 6: Pipeline loads
  try {
    const { getPipeline, PIPELINE_STAGES } = require('../src/pipeline/hcfull-pipeline');
    const pipeline = getPipeline();
    checks.push({ name: 'Pipeline', pass: true, detail: `${PIPELINE_STAGES.length} stages` });
  } catch (err) {
    checks.push({ name: 'Pipeline', pass: false, detail: err.message });
  }

  // Check 7: Error classes load
  try {
    const errors = require('../src/core/error-classes');
    const err = new errors.AppError('test', 500, 'TEST');
    checks.push({ name: 'Error classes', pass: err.toJSON && err.code === 'TEST', detail: `${Object.keys(errors).length} exports` });
  } catch (err) {
    checks.push({ name: 'Error classes', pass: false, detail: err.message });
  }

  // Check 8: No magic numbers in phi-constants
  try {
    const src = require('fs').readFileSync(require.resolve('../src/core/phi-constants'), 'utf8');
    const hasTodo = /\bTODO\b/i.test(src);
    const hasFixme = /\bFIXME\b/i.test(src);
    const hasConsoleLog = /console\.log/i.test(src);
    checks.push({ name: 'Code quality', pass: !hasTodo && !hasFixme && !hasConsoleLog, detail: 'No TODO/FIXME/console.log' });
  } catch (err) {
    checks.push({ name: 'Code quality', pass: false, detail: err.message });
  }

  // Print results
  process.stdout.write('\n\u2550'.repeat(60) + '\n');
  process.stdout.write('  HEADY SYSTEM VALIDATION\n');
  process.stdout.write('\u2550'.repeat(60) + '\n\n');

  let allPass = true;
  for (const check of checks) {
    const icon = check.pass ? '\u2705' : '\u274C';
    process.stdout.write(`  ${icon} ${check.name}: ${check.detail}\n`);
    if (!check.pass) allPass = false;
  }

  process.stdout.write('\n' + '\u2550'.repeat(60) + '\n');
  process.stdout.write(`  ${allPass ? '\u2705 ALL CHECKS PASSED' : '\u274C VALIDATION FAILED'}\n`);
  process.stdout.write('\u2550'.repeat(60) + '\n\n');

  process.exit(allPass ? 0 : 1);
}

validate();
