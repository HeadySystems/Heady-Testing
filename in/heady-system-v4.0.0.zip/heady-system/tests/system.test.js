/**
 * Heady System Tests — Critical Path Verification
 * © 2026 HeadySystems Inc. — Sacred Geometry v4.0
 */

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

// ─── Core: Phi Constants ────────────────────────────────────
describe('Phi Constants', () => {
  const { PHI, PSI, fib, FIB, CSL_THRESHOLDS, phiThreshold, phiBackoff } = require('../src/core/phi-constants');

  it('PHI is golden ratio', () => {
    assert.ok(Math.abs(PHI - 1.618033988749895) < 1e-10);
  });

  it('PSI is 1/PHI', () => {
    assert.ok(Math.abs(PSI - 1/PHI) < 1e-10);
  });

  it('PHI * PSI = 1', () => {
    assert.ok(Math.abs(PHI * PSI - 1) < 1e-10);
  });

  it('Fibonacci sequence is correct', () => {
    assert.equal(fib(0), 0);
    assert.equal(fib(1), 1);
    assert.equal(fib(5), 5);
    assert.equal(fib(8), 21);
    assert.equal(fib(10), 55);
    assert.equal(fib(20), 6765);
  });

  it('CSL thresholds are phi-harmonic', () => {
    assert.ok(CSL_THRESHOLDS.MINIMUM < CSL_THRESHOLDS.LOW);
    assert.ok(CSL_THRESHOLDS.LOW < CSL_THRESHOLDS.MEDIUM);
    assert.ok(CSL_THRESHOLDS.MEDIUM < CSL_THRESHOLDS.HIGH);
    assert.ok(CSL_THRESHOLDS.HIGH < CSL_THRESHOLDS.CRITICAL);
  });

  it('phiThreshold increases with level', () => {
    for (let i = 0; i < 4; i++) {
      assert.ok(phiThreshold(i) < phiThreshold(i + 1));
    }
  });

  it('phiBackoff increases with attempt', () => {
    const b0 = phiBackoff(0, 1000, 60000, false);
    const b1 = phiBackoff(1, 1000, 60000, false);
    const b2 = phiBackoff(2, 1000, 60000, false);
    assert.ok(b0 < b1);
    assert.ok(b1 < b2);
  });
});

// ─── Core: CSL Engine ───────────────────────────────────────
describe('CSL Engine', () => {
  const {
    cosineSimilarity, cslAND, cslOR, cslNOT, cslIMPLY,
    cslXOR, cslCONSENSUS, moeRoute,
    isDuplicate, ternaryLogic,
    hdcBind, hdcBundle, hdcPermute,
  } = require('../src/core/csl-engine');

  const dim = 384;
  const makeUnit = (seed) => {
    const v = Array.from({ length: dim }, (_, i) => Math.sin(i + seed));
    const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
    return v.map(x => x / norm);
  };

  const a = makeUnit(0);
  const b = makeUnit(1);

  it('cosine similarity of identical vectors is 1', () => {
    assert.ok(Math.abs(cosineSimilarity(a, a) - 1.0) < 1e-6);
  });

  it('CSL AND is commutative', () => {
    assert.ok(Math.abs(cslAND(a, b) - cslAND(b, a)) < 1e-10);
  });

  it('CSL NOT produces orthogonal vector', () => {
    const notAB = cslNOT(a, b);
    const dot = notAB.reduce((s, v, i) => s + v * b[i], 0);
    assert.ok(Math.abs(dot) < 1e-6);
  });

  it('CSL OR produces unit vector', () => {
    const orAB = cslOR(a, b);
    const norm = Math.sqrt(orAB.reduce((s, v) => s + v * v, 0));
    assert.ok(Math.abs(norm - 1.0) < 1e-6);
  });

  it('CSL CONSENSUS produces unit vector', () => {
    const cons = cslCONSENSUS([a, b]);
    const norm = Math.sqrt(cons.reduce((s, v) => s + v * v, 0));
    assert.ok(Math.abs(norm - 1.0) < 1e-6);
  });

  it('MoE router returns top-K experts', () => {
    const gates = [makeUnit(0), makeUnit(1), makeUnit(2), makeUnit(3)];
    const result = moeRoute(a, gates, 2);
    assert.equal(result.length, 2);
    assert.ok(result[0].weight >= result[1].weight);
    const totalWeight = result.reduce((s, r) => s + r.weight, 0);
    assert.ok(Math.abs(totalWeight - 1.0) < 1e-6);
  });

  it('isDuplicate detects identical vectors', () => {
    assert.ok(isDuplicate(a, a));
    assert.ok(!isDuplicate(a, b));
  });

  it('ternary logic maps correctly', () => {
    const t = ternaryLogic(0.9);
    assert.equal(t.label, 'TRUE');
    const u = ternaryLogic(0.1);
    assert.equal(u.label, 'UNKNOWN');
    const f = ternaryLogic(-0.9);
    assert.equal(f.label, 'FALSE');
  });

  it('HDC permute is reversible', () => {
    const p = hdcPermute(a, 5);
    const r = hdcPermute(p, -5);
    for (let i = 0; i < dim; i++) {
      assert.ok(Math.abs(a[i] - r[i]) < 1e-10);
    }
  });
});

// ─── Core: Liquid Node ──────────────────────────────────────
describe('Liquid Node', () => {
  const { LiquidNode, LIFECYCLE_STATES, CircuitBreaker } = require('../src/core/liquid-node');

  it('creates with correct initial state', () => {
    const node = new LiquidNode({ name: 'TestNode', ring: 'middle', pool: 'warm' });
    assert.equal(node.state, LIFECYCLE_STATES.INIT);
    assert.equal(node.ring, 'middle');
    assert.equal(node.pool, 'warm');
    assert.equal(node.embedding.length, 384);
  });

  it('transitions through valid states', () => {
    const node = new LiquidNode({ name: 'TestNode2', ring: 'inner', pool: 'hot' });
    node.transition(LIFECYCLE_STATES.ACTIVE);
    assert.equal(node.state, LIFECYCLE_STATES.ACTIVE);
    node.transition(LIFECYCLE_STATES.IDLE);
    assert.equal(node.state, LIFECYCLE_STATES.IDLE);
  });

  it('rejects invalid transitions', () => {
    const node = new LiquidNode({ name: 'TestNode3', ring: 'outer', pool: 'cold' });
    assert.throws(() => node.transition(LIFECYCLE_STATES.RESPONDING));
  });

  it('health() returns structured data', () => {
    const node = new LiquidNode({ name: 'HealthTest', ring: 'middle', pool: 'warm' });
    const h = node.health();
    assert.equal(h.service, 'HealthTest');
    assert.ok(h.uptime);
    assert.ok(h.timestamp);
  });

  it('circuit breaker opens after threshold failures', async () => {
    const cb = new CircuitBreaker({ name: 'test-cb', failureThreshold: 3 });
    const failFn = async () => { throw new Error('fail'); };
    for (let i = 0; i < 3; i++) {
      try { await cb.exec(failFn); } catch {}
    }
    assert.equal(cb.state, 'open');
  });
});

// ─── Conductor ──────────────────────────────────────────────
describe('Conductor', () => {
  const { getConductor, TASK_TYPES } = require('../src/conductor/conductor');

  it('classifies tasks by keywords', () => {
    const conductor = getConductor();
    assert.equal(conductor.classifyTask({ description: 'implement a new API' }), TASK_TYPES.CODE_GENERATION);
    assert.equal(conductor.classifyTask({ description: 'review this code' }), TASK_TYPES.CODE_REVIEW);
    assert.equal(conductor.classifyTask({ description: 'security audit' }), TASK_TYPES.SECURITY_AUDIT);
  });
});

// ─── Bee Factory ────────────────────────────────────────────
describe('Bee Factory', () => {
  const { getBeeFactory, BEE_TYPES } = require('../src/bees/bee-factory');

  it('has 33 bee types', () => {
    assert.equal(Object.keys(BEE_TYPES).length, 33);
  });

  it('factory status reports correctly', () => {
    const factory = getBeeFactory();
    const status = factory.status();
    assert.equal(status.beeTypeCount, 33);
    assert.ok(Array.isArray(status.beeTypes));
  });
});

// ─── Error Classes ──────────────────────────────────────────
describe('Error Classes', () => {
  const { AppError, NotFoundError, ValidationError, CircuitBreakerError } = require('../src/core/error-classes');

  it('AppError serializes to JSON', () => {
    const err = new AppError('test', 500, 'TEST_CODE', { detail: 'info' });
    const json = err.toJSON();
    assert.equal(json.error.code, 'TEST_CODE');
    assert.equal(json.error.message, 'test');
  });

  it('NotFoundError has 404 status', () => {
    const err = new NotFoundError('User', '123');
    assert.equal(err.statusCode, 404);
    assert.equal(err.code, 'NOT_FOUND');
  });

  it('ValidationError has 422 status', () => {
    const err = new ValidationError('email', 'invalid format');
    assert.equal(err.statusCode, 422);
  });

  it('CircuitBreakerError has 503 status', () => {
    const err = new CircuitBreakerError('api-service', 5000);
    assert.equal(err.statusCode, 503);
  });
});
