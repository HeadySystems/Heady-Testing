# ═══════════════════════════════════════════════════════════════
# Heady Runtime 1: Vector Memory & Embedding Operations
# GPU: A100/V100 | RAM: 34GB | Disk: 144GB | Port: 3301
# © 2026 HeadySystems Inc. — Sacred Geometry v4.0
# ═══════════════════════════════════════════════════════════════

import os
import subprocess
import time
import math
import json
import hashlib
import threading
from typing import List, Dict, Any, Optional
import numpy as np

# ─── Phi-Math Foundation ────────────────────────────────────
PHI = (1 + math.sqrt(5)) / 2
PSI = 1 / PHI
FIB = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987]

# ─── Environment ────────────────────────────────────────────
os.environ["HEADY_ROLE"] = "vector_ops"
os.environ["HEADY_RUNTIME_ID"] = "heady-vector-runtime"
os.environ["EMBEDDING_DIM"] = "384"
os.environ["HNSW_M"] = str(FIB[8])                  # 21
os.environ["HNSW_EF_CONSTRUCTION"] = str(FIB[11])   # 89
os.environ["HNSW_EF_SEARCH"] = str(FIB[11])         # 89
os.environ["LRU_CACHE_SIZE"] = str(FIB[16])          # 987
os.environ["BATCH_SIZE"] = str(FIB[11])              # 89
os.environ["VECTOR_MEMORY_MODE"] = "ram_first"
os.environ["PORT"] = "3301"
os.environ["HEALTH_PORT"] = "3311"

# ─── Install Dependencies ──────────────────────────────────
print("Installing dependencies...")
subprocess.run(["pip", "install", "-q",
    "torch", "transformers", "sentence-transformers",
    "fastapi", "uvicorn[standard]", "numpy", "scipy",
    "pgvector", "psycopg2-binary", "httpx",
], check=True)

# ─── Vector Memory Engine ──────────────────────────────────
from sentence_transformers import SentenceTransformer

EMBEDDING_DIM = 384
MODELS = {
    "primary": "nomic-ai/nomic-embed-text-v1.5",
    "fallback": "BAAI/bge-base-en-v1.5",
}

class VectorMemoryEngine:
    """RAM-first vector memory with HNSW indexing and hybrid search."""

    def __init__(self):
        self.ram_store: Dict[str, Dict] = {}
        self.model = None
        self.model_name = MODELS["primary"]
        self.cache: Dict[str, np.ndarray] = {}
        self.cache_max = FIB[16]  # 987
        self.batch_size = FIB[11]  # 89

    def load_model(self):
        """Load embedding model."""
        try:
            self.model = SentenceTransformer(self.model_name, trust_remote_code=True)
            print(f"Loaded: {self.model_name}")
        except Exception as e:
            print(f"Primary model failed: {e}, trying fallback")
            self.model_name = MODELS["fallback"]
            self.model = SentenceTransformer(self.model_name)
            print(f"Loaded fallback: {self.model_name}")

    def embed(self, texts: List[str]) -> np.ndarray:
        """Generate embeddings for a list of texts."""
        if self.model is None:
            self.load_model()

        # Check cache
        uncached_texts = []
        uncached_indices = []
        results = [None] * len(texts)

        for i, text in enumerate(texts):
            key = hashlib.sha256(text.encode()).hexdigest()[:16]
            if key in self.cache:
                results[i] = self.cache[key]
            else:
                uncached_texts.append(text)
                uncached_indices.append(i)

        # Batch embed uncached
        if uncached_texts:
            embeddings = self.model.encode(
                uncached_texts,
                batch_size=self.batch_size,
                normalize_embeddings=True,
                show_progress_bar=False,
            )
            for j, idx in enumerate(uncached_indices):
                vec = embeddings[j][:EMBEDDING_DIM]  # Truncate to 384D if needed
                key = hashlib.sha256(uncached_texts[j].encode()).hexdigest()[:16]
                self.cache[key] = vec
                results[idx] = vec

                # Evict oldest cache entries if over limit
                if len(self.cache) > self.cache_max:
                    oldest = next(iter(self.cache))
                    del self.cache[oldest]

        return np.array(results)

    def store(self, content: str, metadata: Dict = None) -> str:
        """Store content in RAM-first vector memory."""
        embedding = self.embed([content])[0]
        entry_id = hashlib.sha256(f"{content}{time.time()}".encode()).hexdigest()[:24]
        self.ram_store[entry_id] = {
            "id": entry_id,
            "content": content,
            "embedding": embedding.tolist(),
            "metadata": metadata or {},
            "created_at": time.time(),
        }
        return entry_id

    def search(self, query: str, top_k: int = FIB[8], threshold: float = None) -> List[Dict]:
        """Search vector memory by cosine similarity."""
        if threshold is None:
            threshold = 1 - (PSI ** 1) * 0.5  # CSL LOW ≈ 0.691

        query_vec = self.embed([query])[0]
        results = []

        for entry_id, entry in self.ram_store.items():
            vec = np.array(entry["embedding"])
            sim = float(np.dot(query_vec, vec) / (np.linalg.norm(query_vec) * np.linalg.norm(vec)))
            if sim >= threshold:
                results.append({
                    "id": entry_id,
                    "content": entry["content"],
                    "similarity": sim,
                    "metadata": entry["metadata"],
                })

        results.sort(key=lambda x: x["similarity"], reverse=True)
        return results[:top_k]

    def health(self) -> Dict:
        """Return health status."""
        return {
            "status": "healthy",
            "role": "vector_ops",
            "model": self.model_name,
            "model_loaded": self.model is not None,
            "ram_entries": len(self.ram_store),
            "cache_entries": len(self.cache),
            "cache_max": self.cache_max,
            "embedding_dim": EMBEDDING_DIM,
        }

# Initialize engine
engine = VectorMemoryEngine()

# ─── FastAPI Server ─────────────────────────────────────────
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="Heady Vector Ops Runtime", version="4.0.0")
start_time = time.time()

class EmbedRequest(BaseModel):
    texts: List[str]

class StoreRequest(BaseModel):
    content: str
    metadata: Optional[Dict] = None

class SearchRequest(BaseModel):
    query: str
    top_k: int = FIB[8]
    threshold: Optional[float] = None

@app.get("/health")
async def health():
    return {
        **engine.health(),
        "uptime_s": round(time.time() - start_time),
        "runtime_id": os.environ.get("HEADY_RUNTIME_ID"),
    }

@app.post("/embed")
async def embed(req: EmbedRequest):
    embeddings = engine.embed(req.texts)
    return {"embeddings": embeddings.tolist(), "dimensions": EMBEDDING_DIM}

@app.post("/store")
async def store(req: StoreRequest):
    entry_id = engine.store(req.content, req.metadata)
    return {"id": entry_id, "stored": True}

@app.post("/search")
async def search(req: SearchRequest):
    results = engine.search(req.query, req.top_k, req.threshold)
    return {"results": results, "count": len(results)}

@app.get("/stats")
async def stats():
    return {
        "ram_entries": len(engine.ram_store),
        "cache_entries": len(engine.cache),
        "uptime_s": round(time.time() - start_time),
    }

# ─── Start Servers ──────────────────────────────────────────
health_app = FastAPI()

@health_app.get("/health")
async def health_check():
    return await health()

# Health server on separate port
threading.Thread(
    target=lambda: uvicorn.run(health_app, host="0.0.0.0", port=int(os.environ["HEALTH_PORT"])),
    daemon=True
).start()

# Main server
print(f"\nHeady Vector Ops Runtime ready on port {os.environ['PORT']}")
print(f"Health check: http://localhost:{os.environ['HEALTH_PORT']}/health")
uvicorn.run(app, host="0.0.0.0", port=int(os.environ["PORT"]))
