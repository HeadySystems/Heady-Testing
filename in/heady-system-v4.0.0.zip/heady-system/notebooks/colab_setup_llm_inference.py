# ═══════════════════════════════════════════════════════════════
# Heady Runtime 2: LLM Inference & Agent Execution
# GPU: A100 | RAM: 55GB | Disk: 233GB | Port: 3302
# © 2026 HeadySystems Inc. — Sacred Geometry v4.0
# ═══════════════════════════════════════════════════════════════

import os
import subprocess
import time
import math
import json
import threading
from typing import List, Dict, Any, Optional

PHI = (1 + math.sqrt(5)) / 2
PSI = 1 / PHI
FIB = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987]

# ─── Environment ────────────────────────────────────────────
os.environ["HEADY_ROLE"] = "llm_inference"
os.environ["HEADY_RUNTIME_ID"] = "heady-llm-runtime"
os.environ["MAX_CONCURRENT_REQUESTS"] = str(FIB[6])   # 8
os.environ["MAX_BATCH_SIZE"] = str(FIB[5])             # 5
os.environ["KV_CACHE_GB"] = str(FIB[7])                # 13
os.environ["QUANTIZATION"] = "int4"
os.environ["PORT"] = "3302"
os.environ["HEALTH_PORT"] = "3312"

# ─── Install Dependencies ──────────────────────────────────
print("Installing dependencies...")
subprocess.run(["pip", "install", "-q",
    "torch", "transformers", "accelerate", "bitsandbytes",
    "vllm", "fastapi", "uvicorn[standard]", "httpx",
], check=True)

# ─── Model Configuration ───────────────────────────────────
MODELS = {
    "general": "meta-llama/Llama-3.1-8B-Instruct",
    "code": "codellama/CodeLlama-34b-Instruct-hf",
    "fast": "mistralai/Mistral-7B-Instruct-v0.3",
}

ACTIVE_MODEL = os.environ.get("HEADY_LLM_MODEL", MODELS["general"])

# ─── LLM Inference Engine ──────────────────────────────────
class LLMEngine:
    """vLLM-backed inference engine with phi-scaled parameters."""

    def __init__(self):
        self.model = None
        self.model_name = ACTIVE_MODEL
        self.max_concurrent = FIB[6]  # 8
        self.active_requests = 0
        self.total_requests = 0
        self.total_tokens = 0

    def load_model(self):
        """Load model with vLLM for optimized serving."""
        try:
            from vllm import LLM, SamplingParams
            self.model = LLM(
                model=self.model_name,
                quantization="awq" if "int4" in os.environ.get("QUANTIZATION", "") else None,
                max_model_len=FIB[16] * 8,  # 7896 tokens
                tensor_parallel_size=1,
                gpu_memory_utilization=PSI + 0.1,  # ≈ 0.718
            )
            self.SamplingParams = SamplingParams
            print(f"Loaded model: {self.model_name}")
        except Exception as e:
            print(f"vLLM load failed: {e}")
            print("Falling back to transformers pipeline")
            from transformers import pipeline
            self.model = pipeline("text-generation",
                model=self.model_name,
                device_map="auto",
                torch_dtype="auto",
            )
            self.SamplingParams = None

    def generate(self, prompt: str, max_tokens: int = 512,
                 temperature: float = 0.7, top_p: float = 0.9) -> Dict:
        """Generate text completion."""
        if self.model is None:
            self.load_model()

        self.active_requests += 1
        self.total_requests += 1
        start = time.time()

        try:
            if self.SamplingParams:
                params = self.SamplingParams(
                    max_tokens=max_tokens,
                    temperature=temperature,
                    top_p=top_p,
                )
                outputs = self.model.generate([prompt], params)
                text = outputs[0].outputs[0].text
                tokens = len(outputs[0].outputs[0].token_ids)
            else:
                result = self.model(prompt,
                    max_new_tokens=max_tokens,
                    temperature=temperature,
                    top_p=top_p,
                    do_sample=True,
                )
                text = result[0]["generated_text"][len(prompt):]
                tokens = max_tokens  # Approximate

            self.total_tokens += tokens
            duration_ms = round((time.time() - start) * 1000)

            return {
                "text": text.strip(),
                "tokens": tokens,
                "duration_ms": duration_ms,
                "model": self.model_name,
                "tokens_per_second": round(tokens / (duration_ms / 1000), 1) if duration_ms > 0 else 0,
            }
        finally:
            self.active_requests -= 1

    def health(self) -> Dict:
        return {
            "status": "healthy",
            "role": "llm_inference",
            "model": self.model_name,
            "model_loaded": self.model is not None,
            "active_requests": self.active_requests,
            "max_concurrent": self.max_concurrent,
            "total_requests": self.total_requests,
            "total_tokens": self.total_tokens,
        }

engine = LLMEngine()

# ─── FastAPI Server ─────────────────────────────────────────
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="Heady LLM Inference Runtime", version="4.0.0")
start_time = time.time()

class GenerateRequest(BaseModel):
    prompt: str
    max_tokens: int = 512
    temperature: float = 0.7
    top_p: float = 0.9
    system_prompt: Optional[str] = None

@app.get("/health")
async def health():
    return {
        **engine.health(),
        "uptime_s": round(time.time() - start_time),
        "runtime_id": os.environ.get("HEADY_RUNTIME_ID"),
    }

@app.post("/generate")
async def generate(req: GenerateRequest):
    if engine.active_requests >= engine.max_concurrent:
        raise HTTPException(429, "Max concurrent requests reached")
    full_prompt = f"[INST] {req.system_prompt or 'You are Heady, a helpful AI assistant.'}\n\n{req.prompt} [/INST]"
    return engine.generate(full_prompt, req.max_tokens, req.temperature, req.top_p)

@app.post("/chat")
async def chat(req: GenerateRequest):
    if engine.active_requests >= engine.max_concurrent:
        raise HTTPException(429, "Max concurrent requests reached")
    return engine.generate(req.prompt, req.max_tokens, req.temperature, req.top_p)

@app.get("/stats")
async def stats():
    return {
        "total_requests": engine.total_requests,
        "total_tokens": engine.total_tokens,
        "active_requests": engine.active_requests,
        "uptime_s": round(time.time() - start_time),
    }

# Health server
health_app = FastAPI()
@health_app.get("/health")
async def health_check():
    return await health()

threading.Thread(
    target=lambda: uvicorn.run(health_app, host="0.0.0.0", port=int(os.environ["HEALTH_PORT"])),
    daemon=True
).start()

print(f"\nHeady LLM Inference Runtime ready on port {os.environ['PORT']}")
uvicorn.run(app, host="0.0.0.0", port=int(os.environ["PORT"]))
