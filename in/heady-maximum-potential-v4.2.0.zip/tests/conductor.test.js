/**
 * conductor.test.js — Unit tests for the HeadyConductor Orchestration Engine
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import { describe, it, beforeEach } from 'node:test';
import assert from 'node:assert/strict';

import { HeadyConductor, ROUTING_MATRIX, COMPLEXITY_ROUTES } from '../orchestration/conductor.js';
import { LiquidNode, NodeRegistry } from '../shared/liquid-node.js';
import { PSI, FIB, CSL_THRESHOLDS } from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// CONSTRUCTION
// ═══════════════════════════════════════════════════════════════

describe('HeadyConductor construction', () => {
  it('defaults name to HeadyConductor', () => {
    const c = new HeadyConductor();
    assert.equal(c.name, 'HeadyConductor');
  });

  it('defaults ring to inner and pool to hot', () => {
    const c = new HeadyConductor();
    assert.equal(c.ring, 'inner');
    assert.equal(c.pool, 'hot');
  });

  it('extends LiquidNode', () => {
    const c = new HeadyConductor();
    assert.ok(c instanceof LiquidNode);
  });

  it('has maxPendingTasks set to FIB[13] = 233', () => {
    const c = new HeadyConductor();
    assert.equal(c.maxPendingTasks, FIB[13]);
    assert.equal(c.maxPendingTasks, 233);
  });

  it('has classification cache sized at FIB[16] = 987', () => {
    const c = new HeadyConductor();
    assert.equal(c._classificationCacheSize, FIB[16]);
    assert.equal(c._classificationCacheSize, 987);
  });

  it('initializes routing metrics to zero', () => {
    const c = new HeadyConductor();
    assert.equal(c._routingMetrics.totalClassified, 0);
    assert.equal(c._routingMetrics.totalRouted, 0);
    assert.equal(c._routingMetrics.fallbacksUsed, 0);
    assert.equal(c._routingMetrics.cacheHits, 0);
  });
});

// ═══════════════════════════════════════════════════════════════
// CAPABILITIES
// ═══════════════════════════════════════════════════════════════

describe('HeadyConductor capabilities', () => {
  it('has capabilities array from config (inherits via LiquidNode)', () => {
    const c = new HeadyConductor({
      capabilities: ['task-classification', 'node-routing', 'pipeline-orchestration'],
    });
    assert.ok(c.capabilities.includes('task-classification'));
    assert.ok(c.capabilities.includes('node-routing'));
    assert.ok(c.capabilities.includes('pipeline-orchestration'));
  });
});

// ═══════════════════════════════════════════════════════════════
// ROUTING MATRIX
// ═══════════════════════════════════════════════════════════════

describe('ROUTING_MATRIX', () => {
  it('is a frozen object', () => {
    assert.ok(Object.isFrozen(ROUTING_MATRIX));
  });

  it('has all expected task types', () => {
    const expectedTypes = [
      'code-generation', 'code-review', 'security-audit', 'architecture',
      'research', 'documentation', 'quick-task', 'creative',
      'cleanup', 'analytics', 'embeddings', 'monitoring', 'translation',
    ];
    for (const type of expectedTypes) {
      assert.ok(type in ROUTING_MATRIX, `Missing routing for: ${type}`);
    }
  });

  it('each entry has primary, fallback1, fallback2, and pool', () => {
    for (const [type, entry] of Object.entries(ROUTING_MATRIX)) {
      assert.ok(Array.isArray(entry.primary), `${type}.primary should be array`);
      assert.ok(Array.isArray(entry.fallback1), `${type}.fallback1 should be array`);
      assert.ok(Array.isArray(entry.fallback2), `${type}.fallback2 should be array`);
      assert.ok(typeof entry.pool === 'string', `${type}.pool should be string`);
    }
  });

  it('pool values are valid (hot, warm, or cold)', () => {
    const validPools = ['hot', 'warm', 'cold'];
    for (const [type, entry] of Object.entries(ROUTING_MATRIX)) {
      assert.ok(validPools.includes(entry.pool), `${type}.pool=${entry.pool} is invalid`);
    }
  });
});

// ═══════════════════════════════════════════════════════════════
// CLASSIFICATION
// ═══════════════════════════════════════════════════════════════

describe('HeadyConductor.classify', () => {
  it('returns a valid classification object', () => {
    const c = new HeadyConductor();
    const result = c.classify({ type: 'code-generation' });
    assert.ok('taskType' in result);
    assert.ok('domain' in result);
    assert.ok('complexity' in result);
    assert.ok('computeRoute' in result);
    assert.ok('pool' in result);
    assert.ok('confidence' in result);
    assert.ok('timestamp' in result);
  });

  it('exact match returns confidence 1.0', () => {
    const c = new HeadyConductor();
    const result = c.classify({ type: 'code-review' });
    assert.equal(result.taskType, 'code-review');
    assert.equal(result.confidence, 1.0);
  });

  it('falls back to quick-task for unknown types', () => {
    const c = new HeadyConductor();
    const result = c.classify({ type: 'completely-unknown-xyz' });
    assert.equal(result.taskType, 'quick-task');
  });

  it('caches classification results', () => {
    const c = new HeadyConductor();
    c.classify({ type: 'research' });
    c.classify({ type: 'research' });
    assert.equal(c._routingMetrics.cacheHits, 1);
    assert.equal(c._routingMetrics.totalClassified, 1);
  });

  it('complexity is between 0 and 1', () => {
    const c = new HeadyConductor();
    const result = c.classify({ type: 'architecture', steps: 5, contextLength: 4000 });
    assert.ok(result.complexity >= 0 && result.complexity <= 1,
      `complexity=${result.complexity} should be in [0,1]`);
  });

  it('complexity hint "high" forces origin-required route', () => {
    const c = new HeadyConductor();
    const result = c.classify({ type: 'research', complexity: 'high' });
    assert.equal(result.computeRoute, 'origin-required');
  });

  it('complexity hint "low" forces edge-only route', () => {
    const c = new HeadyConductor();
    const result = c.classify({ type: 'quick-task', complexity: 'low' });
    assert.equal(result.computeRoute, 'edge-only');
  });
});

// ═══════════════════════════════════════════════════════════════
// COMPLEXITY ROUTES
// ═══════════════════════════════════════════════════════════════

describe('COMPLEXITY_ROUTES', () => {
  it('EDGE_ONLY.max ≈ PSI² (≈ 0.382)', () => {
    assert.ok(Math.abs(COMPLEXITY_ROUTES.EDGE_ONLY.max - PSI * PSI) < 1e-6);
  });

  it('EDGE_PREFERRED.max ≈ PSI (≈ 0.618)', () => {
    assert.ok(Math.abs(COMPLEXITY_ROUTES.EDGE_PREFERRED.max - PSI) < 1e-6);
  });

  it('ORIGIN_REQUIRED.max = 1.0', () => {
    assert.equal(COMPLEXITY_ROUTES.ORIGIN_REQUIRED.max, 1.0);
  });
});

// ═══════════════════════════════════════════════════════════════
// ROUTING
// ═══════════════════════════════════════════════════════════════

describe('HeadyConductor.route', () => {
  it('routes with primary source for known task types', () => {
    const c = new HeadyConductor();
    const classification = c.classify({ type: 'code-generation' });
    const route = c.route(classification, { type: 'code-generation' });
    assert.ok(Array.isArray(route.nodes));
    assert.ok(route.nodes.length > 0);
    assert.equal(route.source, 'primary');
  });

  it('includes fallbackChain in route result', () => {
    const c = new HeadyConductor();
    const classification = c.classify({ type: 'research' });
    const route = c.route(classification, { type: 'research' });
    assert.ok(Array.isArray(route.fallbackChain));
  });

  it('increments totalRouted metric', () => {
    const c = new HeadyConductor();
    const classification = c.classify({ type: 'analytics' });
    c.route(classification, { type: 'analytics' });
    assert.equal(c._routingMetrics.totalRouted, 1);
  });

  it('route returns pool matching routing matrix entry', () => {
    const c = new HeadyConductor();
    const classification = c.classify({ type: 'cleanup' });
    const route = c.route(classification, { type: 'cleanup' });
    assert.equal(route.pool, 'cold');
  });
});

// ═══════════════════════════════════════════════════════════════
// ARENA PROMOTIONS (requires _log — test route override map directly)
// ═══════════════════════════════════════════════════════════════

describe('Arena promotions', () => {
  it('_routeOverrides map stores entries directly', () => {
    const c = new HeadyConductor();
    c._routeOverrides.set('security-audit', { nodes: ['NewScanner'], promotedAt: Date.now() });
    const overrides = c.getRouteOverrides();
    assert.ok('security-audit' in overrides);
    assert.deepStrictEqual(overrides['security-audit'].nodes, ['NewScanner']);
  });

  it('clearArenaPromotion removes the override (no _log call)', () => {
    const c = new HeadyConductor();
    c._routeOverrides.set('creative', { nodes: ['ArtBot'], promotedAt: Date.now() });
    c.clearArenaPromotion('creative');
    const overrides = c.getRouteOverrides();
    assert.ok(!('creative' in overrides));
  });

  it('route skips arena override path when no override is set', () => {
    const c = new HeadyConductor();
    const classification = c.classify({ type: 'code-review' });
    const route = c.route(classification, { type: 'code-review' });
    // Without override, source should be primary
    assert.equal(route.source, 'primary');
    assert.ok(!route.nodes.includes('CustomModel'));
  });
});

// ═══════════════════════════════════════════════════════════════
// EXECUTE VALIDATION
// ═══════════════════════════════════════════════════════════════

describe('HeadyConductor.execute validation', () => {
  it('rejects tasks without a type', async () => {
    const c = new HeadyConductor();
    await assert.rejects(() => c.execute({}), (err) => {
      assert.ok(err.message.includes('type'));
      return true;
    });
  });

  it('rejects null task', async () => {
    const c = new HeadyConductor();
    await assert.rejects(() => c.execute(null), (err) => {
      assert.ok(err.message.includes('type'));
      return true;
    });
  });

  it('classify + route pipeline produces a complete route for any valid type', () => {
    const c = new HeadyConductor();
    const types = ['code-generation', 'research', 'analytics', 'creative'];
    for (const type of types) {
      const classification = c.classify({ type });
      const route = c.route(classification, { type });
      assert.ok(route.nodes.length > 0, `${type}: should have at least one node`);
      assert.ok(typeof route.pool === 'string', `${type}: should have a pool`);
      assert.ok(typeof route.computeRoute === 'string', `${type}: should have a computeRoute`);
    }
  });
});

// ═══════════════════════════════════════════════════════════════
// HEALTH CHECK
// ═══════════════════════════════════════════════════════════════

describe('HeadyConductor.healthCheck', () => {
  it('returns healthy status with no breakers', () => {
    const c = new HeadyConductor();
    const h = c.healthCheck();
    assert.equal(h.status, 'healthy');
    assert.equal(h.healthRatio, 1.0);
    assert.equal(h.pendingTasks, 0);
    assert.equal(h.activeRoutings, 0);
  });

  it('includes metrics in health check', () => {
    const c = new HeadyConductor();
    const h = c.healthCheck();
    assert.ok('metrics' in h);
    assert.equal(h.metrics.totalClassified, 0);
  });
});

// ═══════════════════════════════════════════════════════════════
// QUERIES
// ═══════════════════════════════════════════════════════════════

describe('HeadyConductor queries', () => {
  it('getRoutingMatrix returns all task type entries', () => {
    const c = new HeadyConductor();
    const matrix = c.getRoutingMatrix();
    assert.ok('code-generation' in matrix);
    assert.ok('quick-task' in matrix);
  });

  it('getRouteOverrides returns empty when none set', () => {
    const c = new HeadyConductor();
    const overrides = c.getRouteOverrides();
    assert.deepStrictEqual(overrides, {});
  });
});
