/**
 * phi-constants.test.js — Unit tests for the Heady Phi-Math Foundation
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import {
  PHI, PSI, PHI2, PHI3, FIB, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD, DEDUP_THRESHOLD,
  phiThreshold, phiBackoff, phiFusionWeights, phiAdaptiveInterval,
  PRESSURE_LEVELS, ALERT_THRESHOLDS, POOL_ALLOCATION, RESOURCE_WEIGHTS,
  phiTokenBudgets, cslGate, cosineSimilarity,
  SIZING, POOL_SIZES, fibIndex,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// CORE CONSTANTS
// ═══════════════════════════════════════════════════════════════

describe('Core constants', () => {
  it('PHI equals the golden ratio within 1e-10', () => {
    const expected = (1 + Math.sqrt(5)) / 2;
    assert.ok(Math.abs(PHI - expected) < 1e-10, `PHI=${PHI} should ≈ ${expected}`);
    assert.ok(Math.abs(PHI - 1.618033988749895) < 1e-10);
  });

  it('PSI equals 1/PHI within 1e-10', () => {
    assert.ok(Math.abs(PSI - 0.618033988749895) < 1e-10);
    assert.ok(Math.abs(PSI - 1 / PHI) < 1e-15);
  });

  it('PHI * PSI ≈ 1.0', () => {
    assert.ok(Math.abs(PHI * PSI - 1.0) < 1e-15);
  });

  it('PHI2 ≈ PHI + 1 (golden ratio squared)', () => {
    assert.ok(Math.abs(PHI2 - (PHI + 1)) < 1e-15);
    assert.ok(Math.abs(PHI2 - PHI * PHI) < 1e-10);
  });

  it('PHI3 ≈ 2*PHI + 1 (golden ratio cubed)', () => {
    assert.ok(Math.abs(PHI3 - (2 * PHI + 1)) < 1e-15);
  });
});

// ═══════════════════════════════════════════════════════════════
// FIBONACCI SEQUENCE
// ═══════════════════════════════════════════════════════════════

describe('Fibonacci sequence', () => {
  it('FIB has 21 entries', () => {
    assert.equal(FIB.length, 21);
  });

  it('FIB starts with correct Fibonacci numbers', () => {
    assert.deepStrictEqual(FIB.slice(0, 10), [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]);
  });

  it('FIB[20] = 6765', () => {
    assert.equal(FIB[20], 6765);
  });

  it('fib(n) returns FIB[n] for n < 21', () => {
    for (let i = 0; i < FIB.length; i++) {
      assert.equal(fib(i), FIB[i], `fib(${i}) should be ${FIB[i]}`);
    }
  });

  it('fib(n) computes correctly beyond FIB table (n=25)', () => {
    // fib(25) = 75025
    assert.equal(fib(25), 75025);
  });

  it('fibIndex is an alias for fib', () => {
    assert.strictEqual(fibIndex, fib);
  });
});

// ═══════════════════════════════════════════════════════════════
// CSL THRESHOLDS
// ═══════════════════════════════════════════════════════════════

describe('CSL_THRESHOLDS', () => {
  it('all values are between 0 and 1', () => {
    for (const [key, val] of Object.entries(CSL_THRESHOLDS)) {
      assert.ok(val >= 0 && val <= 1, `${key}=${val} should be in [0,1]`);
    }
  });

  it('MINIMUM < LOW < MEDIUM < HIGH < CRITICAL (monotonically increasing)', () => {
    assert.ok(CSL_THRESHOLDS.MINIMUM < CSL_THRESHOLDS.LOW);
    assert.ok(CSL_THRESHOLDS.LOW < CSL_THRESHOLDS.MEDIUM);
    assert.ok(CSL_THRESHOLDS.MEDIUM < CSL_THRESHOLDS.HIGH);
    assert.ok(CSL_THRESHOLDS.HIGH < CSL_THRESHOLDS.CRITICAL);
  });

  it('COHERENCE_DRIFT_THRESHOLD equals MEDIUM', () => {
    assert.equal(COHERENCE_DRIFT_THRESHOLD, CSL_THRESHOLDS.MEDIUM);
  });

  it('DEDUP_THRESHOLD is between 0 and 1', () => {
    assert.ok(DEDUP_THRESHOLD > 0 && DEDUP_THRESHOLD < 1);
  });
});

// ═══════════════════════════════════════════════════════════════
// phiThreshold
// ═══════════════════════════════════════════════════════════════

describe('phiThreshold', () => {
  it('level 0 with default spread ≈ 0.5', () => {
    const val = phiThreshold(0);
    // 1 - PSI^0 * 0.5 = 1 - 1 * 0.5 = 0.5
    assert.ok(Math.abs(val - 0.5) < 1e-10);
  });

  it('is monotonically increasing with level', () => {
    const values = [0, 1, 2, 3, 4, 5].map(l => phiThreshold(l));
    for (let i = 1; i < values.length; i++) {
      assert.ok(values[i] > values[i - 1], `level ${i} should exceed level ${i - 1}`);
    }
  });
});

// ═══════════════════════════════════════════════════════════════
// phiBackoff
// ═══════════════════════════════════════════════════════════════

describe('phiBackoff', () => {
  it('attempt 0 without jitter returns baseMs', () => {
    const val = phiBackoff(0, 1000, 60000, false);
    assert.equal(val, 1000);
  });

  it('is monotonically increasing without jitter', () => {
    const values = [0, 1, 2, 3, 4].map(a => phiBackoff(a, 1000, 60000, false));
    for (let i = 1; i < values.length; i++) {
      assert.ok(values[i] >= values[i - 1], `attempt ${i} should be >= attempt ${i - 1}`);
    }
  });

  it('is capped at maxMs', () => {
    const val = phiBackoff(100, 1000, 5000, false);
    assert.equal(val, 5000);
  });

  it('with jitter returns a value within expected range around base', () => {
    const base = 1000;
    const val = phiBackoff(0, base, 60000, true);
    // jitterRange = PSI^2 ≈ 0.382, so factor ∈ [1 - 0.382, 1 + 0.382]
    assert.ok(val >= Math.round(base * (1 - PSI * PSI)));
    assert.ok(val <= Math.round(base * (1 + PSI * PSI)));
  });
});

// ═══════════════════════════════════════════════════════════════
// phiFusionWeights
// ═══════════════════════════════════════════════════════════════

describe('phiFusionWeights', () => {
  it('weights sum to ≈ 1.0', () => {
    for (const n of [2, 3, 4, 5, 8]) {
      const weights = phiFusionWeights(n);
      const sum = weights.reduce((a, b) => a + b, 0);
      assert.ok(Math.abs(sum - 1.0) < 1e-10, `n=${n} sum=${sum} should ≈ 1.0`);
    }
  });

  it('first weight is largest (phi-weighted decay)', () => {
    for (const n of [2, 3, 5]) {
      const weights = phiFusionWeights(n);
      for (let i = 1; i < weights.length; i++) {
        assert.ok(weights[0] >= weights[i], `weight[0] should be >= weight[${i}]`);
      }
    }
  });

  it('2-way weights ≈ [0.618, 0.382]', () => {
    const w = phiFusionWeights(2);
    assert.ok(Math.abs(w[0] - PSI) < 0.01, `w[0]=${w[0]} should ≈ PSI`);
    assert.ok(Math.abs(w[1] - PSI * PSI) < 0.01, `w[1]=${w[1]} should ≈ PSI²`);
  });
});

// ═══════════════════════════════════════════════════════════════
// POOL_ALLOCATION
// ═══════════════════════════════════════════════════════════════

describe('POOL_ALLOCATION', () => {
  it('all five pools sum to ≈ 0.81', () => {
    const sum = POOL_ALLOCATION.hot + POOL_ALLOCATION.warm +
                POOL_ALLOCATION.cold + POOL_ALLOCATION.reserve +
                POOL_ALLOCATION.governance;
    assert.ok(Math.abs(sum - 0.81) < 0.01, `sum=${sum} should ≈ 0.81`);
  });

  it('has all required pool keys', () => {
    for (const key of ['hot', 'warm', 'cold', 'reserve', 'governance']) {
      assert.ok(key in POOL_ALLOCATION, `Missing pool: ${key}`);
    }
  });
});

// ═══════════════════════════════════════════════════════════════
// cslGate
// ═══════════════════════════════════════════════════════════════

describe('cslGate', () => {
  it('returns ≈ 0 for cosScore far below tau', () => {
    const result = cslGate(1.0, 0.0, 0.9);
    assert.ok(result < 0.05, `cslGate(1, 0, 0.9)=${result} should be near 0`);
  });

  it('returns ≈ value for cosScore far above tau', () => {
    const result = cslGate(1.0, 1.0, 0.1);
    assert.ok(result > 0.95, `cslGate(1, 1, 0.1)=${result} should be near 1`);
  });

  it('returns ≈ value/2 when cosScore equals tau', () => {
    const result = cslGate(1.0, 0.5, 0.5);
    assert.ok(Math.abs(result - 0.5) < 0.01, `cslGate(1, 0.5, 0.5)=${result} should ≈ 0.5`);
  });

  it('scales with value parameter', () => {
    const r1 = cslGate(1.0, 0.8, 0.5);
    const r2 = cslGate(2.0, 0.8, 0.5);
    assert.ok(Math.abs(r2 / r1 - 2.0) < 0.01);
  });
});

// ═══════════════════════════════════════════════════════════════
// cosineSimilarity
// ═══════════════════════════════════════════════════════════════

describe('cosineSimilarity', () => {
  it('identical vectors → 1.0', () => {
    const v = [0.6, 0.8];
    assert.ok(Math.abs(cosineSimilarity(v, v) - 1.0) < 1e-10);
  });

  it('orthogonal vectors → 0.0', () => {
    const a = [1, 0, 0];
    const b = [0, 1, 0];
    assert.ok(Math.abs(cosineSimilarity(a, b)) < 1e-10);
  });

  it('opposite vectors → -1.0', () => {
    const a = [1, 0];
    const b = [-1, 0];
    assert.ok(Math.abs(cosineSimilarity(a, b) + 1.0) < 1e-10);
  });

  it('returns 0 for zero vectors', () => {
    assert.equal(cosineSimilarity([0, 0], [1, 0]), 0);
  });
});

// ═══════════════════════════════════════════════════════════════
// PRESSURE_LEVELS
// ═══════════════════════════════════════════════════════════════

describe('PRESSURE_LEVELS', () => {
  it('NOMINAL.max ≈ PSI² (≈ 0.382)', () => {
    assert.ok(Math.abs(PRESSURE_LEVELS.NOMINAL.max - PSI * PSI) < 1e-10);
  });

  it('ELEVATED.max ≈ PSI (≈ 0.618)', () => {
    assert.ok(Math.abs(PRESSURE_LEVELS.ELEVATED.max - PSI) < 1e-10);
  });

  it('CRITICAL.max = 1.0', () => {
    assert.equal(PRESSURE_LEVELS.CRITICAL.max, 1.0);
  });
});

// ═══════════════════════════════════════════════════════════════
// phiTokenBudgets
// ═══════════════════════════════════════════════════════════════

describe('phiTokenBudgets', () => {
  it('default working = 8192', () => {
    const budgets = phiTokenBudgets();
    assert.equal(budgets.working, 8192);
  });

  it('session > working > 0', () => {
    const b = phiTokenBudgets();
    assert.ok(b.session > b.working);
    assert.ok(b.working > 0);
  });

  it('memory > session', () => {
    const b = phiTokenBudgets();
    assert.ok(b.memory > b.session, `memory=${b.memory} should > session=${b.session}`);
  });

  it('artifacts > memory', () => {
    const b = phiTokenBudgets();
    assert.ok(b.artifacts > b.memory, `artifacts=${b.artifacts} should > memory=${b.memory}`);
  });

  it('custom base scales all tiers proportionally', () => {
    const b1 = phiTokenBudgets(1000);
    const b2 = phiTokenBudgets(2000);
    // Ratios should be approximately 2x
    assert.equal(b2.working, 2 * b1.working);
  });
});

// ═══════════════════════════════════════════════════════════════
// SIZING
// ═══════════════════════════════════════════════════════════════

describe('SIZING', () => {
  it('FAILURE_THRESHOLD = fib(5) = 5', () => {
    assert.equal(SIZING.FAILURE_THRESHOLD, 5);
  });

  it('PATTERN_STORE = fib(14) = 377', () => {
    assert.equal(SIZING.PATTERN_STORE, 377);
  });

  it('CACHE_SIZE = fib(16) = 987', () => {
    assert.equal(SIZING.CACHE_SIZE, 987);
  });

  it('LARGE_CACHE = fib(20) = 6765', () => {
    assert.equal(SIZING.LARGE_CACHE, 6765);
  });

  it('POOL_SIZES.min = fib(3) = 2 and max = fib(7) = 13', () => {
    assert.equal(POOL_SIZES.min, 2);
    assert.equal(POOL_SIZES.max, 13);
  });
});
