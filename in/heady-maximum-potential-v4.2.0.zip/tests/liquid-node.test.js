/**
 * liquid-node.test.js — Unit tests for the Heady Liquid Node Architecture
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import { describe, it, beforeEach } from 'node:test';
import assert from 'node:assert/strict';

import {
  LiquidNode, NodeRegistry, CircuitBreaker, HeadyError,
  BeeNode, SoulNode, createLogger,
  LIFECYCLE_STATES, VALID_TRANSITIONS, CB_STATES,
  nodeBus,
} from '../shared/liquid-node.js';

import { SIZING, CSL_THRESHOLDS } from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// LIQUID NODE CONSTRUCTION
// ═══════════════════════════════════════════════════════════════

describe('LiquidNode construction', () => {
  it('sets name, ring, pool from config', () => {
    const node = new LiquidNode({ name: 'TestNode', ring: 'inner', pool: 'hot' });
    assert.equal(node.name, 'TestNode');
    assert.equal(node.ring, 'inner');
    assert.equal(node.pool, 'hot');
  });

  it('defaults domain to headyme.com', () => {
    const node = new LiquidNode({ name: 'N1', ring: 'outer', pool: 'warm' });
    assert.equal(node.domain, 'headyme.com');
  });

  it('initializes state to init', () => {
    const node = new LiquidNode({ name: 'N2', ring: 'inner', pool: 'hot' });
    assert.equal(node.state, 'init');
    assert.equal(node.state, LIFECYCLE_STATES.INIT);
  });

  it('initializes coherenceScore to 1.0', () => {
    const node = new LiquidNode({ name: 'N3', ring: 'inner', pool: 'hot' });
    assert.equal(node.coherenceScore, 1.0);
  });

  it('generates a 384-dimensional embedding', () => {
    const node = new LiquidNode({ name: 'N4', ring: 'inner', pool: 'hot' });
    assert.equal(node.embedding.length, 384);
    // Check it's normalized (unit vector)
    const norm = Math.sqrt(node.embedding.reduce((s, v) => s + v * v, 0));
    assert.ok(Math.abs(norm - 1.0) < 1e-6, `Embedding norm=${norm} should ≈ 1.0`);
  });

  it('accepts custom embedding from config', () => {
    const emb = new Array(384).fill(0);
    emb[0] = 1.0;
    const node = new LiquidNode({ name: 'N5', ring: 'inner', pool: 'hot', embedding: emb });
    assert.equal(node.embedding[0], 1.0);
    assert.equal(node.embedding[1], 0);
  });

  it('sets up metrics object with expected keys', () => {
    const node = new LiquidNode({ name: 'N6', ring: 'inner', pool: 'hot' });
    assert.equal(node.metrics.requestsHandled, 0);
    assert.equal(node.metrics.errorsEncountered, 0);
    assert.equal(node.metrics.avgResponseMs, 0);
    assert.equal(node.metrics.driftEvents, 0);
  });
});

// ═══════════════════════════════════════════════════════════════
// STATE TRANSITIONS
// ═══════════════════════════════════════════════════════════════

describe('LiquidNode.transition', () => {
  it('valid transition init → active succeeds', () => {
    const node = new LiquidNode({ name: 'Trans1', ring: 'inner', pool: 'hot' });
    node.transition('active');
    assert.equal(node.state, 'active');
  });

  it('valid chain: init → active → thinking → responding → active', () => {
    const node = new LiquidNode({ name: 'Trans2', ring: 'inner', pool: 'hot' });
    node.transition('active');
    node.transition('thinking');
    node.transition('responding');
    node.transition('active');
    assert.equal(node.state, 'active');
  });

  it('invalid transition init → thinking throws', () => {
    const node = new LiquidNode({ name: 'Trans3', ring: 'inner', pool: 'hot' });
    assert.throws(() => node.transition('thinking'), /Invalid transition/);
  });

  it('expired state cannot transition anywhere', () => {
    const node = new LiquidNode({ name: 'Trans4', ring: 'inner', pool: 'hot' });
    node.transition('expired');
    assert.throws(() => node.transition('active'), /Invalid transition/);
  });
});

// ═══════════════════════════════════════════════════════════════
// HEALTH
// ═══════════════════════════════════════════════════════════════

describe('LiquidNode.health()', () => {
  it('returns object with required fields', () => {
    const node = new LiquidNode({ name: 'Health1', ring: 'inner', pool: 'hot' });
    const h = node.health();
    assert.equal(h.service, 'Health1');
    assert.equal(h.state, 'init');
    assert.equal(h.ring, 'inner');
    assert.equal(h.pool, 'hot');
    assert.equal(h.coherence, 1.0);
    assert.ok('uptime' in h);
    assert.ok('metrics' in h);
    assert.ok('timestamp' in h);
  });

  it('status is "up" for init and active states', () => {
    const node = new LiquidNode({ name: 'Health2', ring: 'inner', pool: 'hot' });
    assert.equal(node.health().status, 'up');
    node.transition('active');
    assert.equal(node.health().status, 'up');
  });

  it('status is "degraded" when state is degraded', () => {
    const node = new LiquidNode({ name: 'Health3', ring: 'inner', pool: 'hot' });
    node.transition('active');
    node.transition('degraded');
    assert.equal(node.health().status, 'degraded');
  });

  it('status is "down" when state is expired', () => {
    const node = new LiquidNode({ name: 'Health4', ring: 'inner', pool: 'hot' });
    node.transition('expired');
    assert.equal(node.health().status, 'down');
  });
});

// ═══════════════════════════════════════════════════════════════
// NODE REGISTRY
// ═══════════════════════════════════════════════════════════════

describe('NodeRegistry', () => {
  it('register stores nodes and get() retrieves by name', () => {
    const registry = new NodeRegistry();
    const node = new LiquidNode({ name: 'Reg1', ring: 'inner', pool: 'hot' });
    registry.register(node);
    assert.equal(registry.get('Reg1'), node);
  });

  it('size reflects registered count', () => {
    const registry = new NodeRegistry();
    assert.equal(registry.size, 0);
    registry.register(new LiquidNode({ name: 'Reg2', ring: 'inner', pool: 'hot' }));
    assert.equal(registry.size, 1);
    registry.register(new LiquidNode({ name: 'Reg3', ring: 'outer', pool: 'warm' }));
    assert.equal(registry.size, 2);
  });

  it('duplicate registration overwrites (Map semantics)', () => {
    const registry = new NodeRegistry();
    const node1 = new LiquidNode({ name: 'Dup', ring: 'inner', pool: 'hot' });
    const node2 = new LiquidNode({ name: 'Dup', ring: 'outer', pool: 'cold' });
    registry.register(node1);
    registry.register(node2);
    assert.equal(registry.size, 1);
    assert.equal(registry.get('Dup').ring, 'outer');
  });

  it('getByRing filters correctly', () => {
    const registry = new NodeRegistry();
    registry.register(new LiquidNode({ name: 'R1', ring: 'inner', pool: 'hot' }));
    registry.register(new LiquidNode({ name: 'R2', ring: 'outer', pool: 'warm' }));
    registry.register(new LiquidNode({ name: 'R3', ring: 'inner', pool: 'cold' }));
    const inner = registry.getByRing('inner');
    assert.equal(inner.length, 2);
  });

  it('getByCapability filters correctly', () => {
    const registry = new NodeRegistry();
    registry.register(new LiquidNode({ name: 'C1', ring: 'inner', pool: 'hot', capabilities: ['store', 'retrieve'] }));
    registry.register(new LiquidNode({ name: 'C2', ring: 'outer', pool: 'warm', capabilities: ['compute'] }));
    const stores = registry.getByCapability('store');
    assert.equal(stores.length, 1);
    assert.equal(stores[0].name, 'C1');
  });

  it('deregister removes a node', () => {
    const registry = new NodeRegistry();
    registry.register(new LiquidNode({ name: 'Dereg1', ring: 'inner', pool: 'hot' }));
    assert.equal(registry.size, 1);
    registry.deregister('Dereg1');
    assert.equal(registry.size, 0);
    assert.equal(registry.get('Dereg1'), undefined);
  });
});

// ═══════════════════════════════════════════════════════════════
// CIRCUIT BREAKER
// ═══════════════════════════════════════════════════════════════

describe('CircuitBreaker', () => {
  it('starts in CLOSED state', () => {
    const cb = new CircuitBreaker({ name: 'CB1' });
    assert.equal(cb.state, CB_STATES.CLOSED);
    assert.equal(cb.state, 'closed');
  });

  it('stays CLOSED on success', async () => {
    const cb = new CircuitBreaker({ name: 'CB2' });
    await cb.exec(() => Promise.resolve('ok'));
    assert.equal(cb.state, CB_STATES.CLOSED);
    assert.equal(cb.failures, 0);
  });

  it('opens after SIZING.FAILURE_THRESHOLD (fib(5) = 5) consecutive failures', async () => {
    const cb = new CircuitBreaker({ name: 'CB3' });
    const failureCount = SIZING.FAILURE_THRESHOLD; // 5
    for (let i = 0; i < failureCount; i++) {
      try {
        await cb.exec(() => Promise.reject(new Error('fail')));
      } catch { /* expected */ }
    }
    assert.equal(cb.state, CB_STATES.OPEN);
  });

  it('throws when OPEN and timeout has not elapsed', async () => {
    const cb = new CircuitBreaker({ name: 'CB4', resetTimeoutMs: 60000 });
    // Trip the breaker
    for (let i = 0; i < SIZING.FAILURE_THRESHOLD; i++) {
      try { await cb.exec(() => Promise.reject(new Error('fail'))); } catch { }
    }
    assert.equal(cb.state, CB_STATES.OPEN);
    await assert.rejects(() => cb.exec(() => Promise.resolve('ok')), /OPEN/);
  });

  it('transitions to HALF_OPEN after reset timeout', async () => {
    const cb = new CircuitBreaker({ name: 'CB5', resetTimeoutMs: 1 }); // 1ms timeout
    for (let i = 0; i < SIZING.FAILURE_THRESHOLD; i++) {
      try { await cb.exec(() => Promise.reject(new Error('fail'))); } catch { }
    }
    assert.equal(cb.state, CB_STATES.OPEN);
    // Wait for the timeout to elapse
    await new Promise(r => setTimeout(r, 10));
    // Next exec should transition to HALF_OPEN and succeed
    const result = await cb.exec(() => Promise.resolve('recovered'));
    assert.equal(result, 'recovered');
    // State should be HALF_OPEN (halfOpenProbes = fib(3) = 2, we did 1 success)
    assert.equal(cb.state, CB_STATES.HALF_OPEN);
  });

  it('closes after sufficient successes in HALF_OPEN', async () => {
    const cb = new CircuitBreaker({ name: 'CB6', resetTimeoutMs: 1, halfOpenProbes: 2 });
    for (let i = 0; i < SIZING.FAILURE_THRESHOLD; i++) {
      try { await cb.exec(() => Promise.reject(new Error('fail'))); } catch { }
    }
    await new Promise(r => setTimeout(r, 10));
    await cb.exec(() => Promise.resolve('ok'));
    assert.equal(cb.state, CB_STATES.HALF_OPEN);
    await cb.exec(() => Promise.resolve('ok'));
    assert.equal(cb.state, CB_STATES.CLOSED);
  });

  it('health() returns name, state, failures', () => {
    const cb = new CircuitBreaker({ name: 'CB7' });
    const h = cb.health();
    assert.equal(h.name, 'CB7');
    assert.equal(h.state, 'closed');
    assert.equal(h.failures, 0);
  });
});

// ═══════════════════════════════════════════════════════════════
// HEADY ERROR
// ═══════════════════════════════════════════════════════════════

describe('HeadyError', () => {
  it('sets name to HeadyError', () => {
    const err = new HeadyError('test error');
    assert.equal(err.name, 'HeadyError');
  });

  it('sets statusCode, code, and isOperational', () => {
    const err = new HeadyError('fail', 404, 'NOT_FOUND');
    assert.equal(err.statusCode, 404);
    assert.equal(err.code, 'NOT_FOUND');
    assert.equal(err.isOperational, true);
  });

  it('defaults to statusCode=500 and code=INTERNAL_ERROR', () => {
    const err = new HeadyError('generic');
    assert.equal(err.statusCode, 500);
    assert.equal(err.code, 'INTERNAL_ERROR');
  });

  it('is an instance of Error', () => {
    const err = new HeadyError('test');
    assert.ok(err instanceof Error);
    assert.ok(err instanceof HeadyError);
  });

  it('preserves details and coherenceImpact', () => {
    const err = new HeadyError('drift', 503, 'DRIFT', { coherenceImpact: 0.3 });
    assert.equal(err.coherenceImpact, 0.3);
    assert.deepStrictEqual(err.details, { coherenceImpact: 0.3 });
  });
});

// ═══════════════════════════════════════════════════════════════
// BEE NODE
// ═══════════════════════════════════════════════════════════════

describe('BeeNode', () => {
  it('extends LiquidNode', () => {
    const bee = new BeeNode({ name: 'TestBee', beeType: 'worker' });
    assert.ok(bee instanceof LiquidNode);
    assert.ok(bee instanceof BeeNode);
  });

  it('defaults ring to outer and pool to warm', () => {
    const bee = new BeeNode({ name: 'Bee1' });
    assert.equal(bee.ring, 'outer');
    assert.equal(bee.pool, 'warm');
  });

  it('has maxRetries, timeoutMs, and retired flag', () => {
    const bee = new BeeNode({ name: 'Bee2' });
    assert.ok(bee.maxRetries > 0);
    assert.ok(bee.timeoutMs > 0);
    assert.equal(bee.retired, false);
  });

  it('spawnContext starts as null', () => {
    const bee = new BeeNode({ name: 'Bee3' });
    assert.equal(bee.spawnContext, null);
  });
});

// ═══════════════════════════════════════════════════════════════
// SOUL NODE
// ═══════════════════════════════════════════════════════════════

describe('SoulNode', () => {
  it('extends LiquidNode', () => {
    const soul = new SoulNode();
    assert.ok(soul instanceof LiquidNode);
    assert.ok(soul instanceof SoulNode);
  });

  it('defaults to ring=center, pool=governance', () => {
    const soul = new SoulNode();
    assert.equal(soul.ring, 'center');
    assert.equal(soul.pool, 'governance');
  });

  it('has 3 Unbreakable Laws', () => {
    const soul = new SoulNode();
    assert.equal(soul.laws.length, 3);
    assert.ok(soul.laws[0].includes('Structural'));
    assert.ok(soul.laws[1].includes('Semantic'));
    assert.ok(soul.laws[2].includes('Mission'));
  });

  it('validates mutation — all valid passes', () => {
    const soul = new SoulNode();
    const result = soul.validateMutation({
      id: 'test-1',
      structurallyValid: true,
      semanticallyCoherent: true,
      missionAligned: true,
    });
    assert.equal(result.valid, true);
    assert.equal(result.violations.length, 0);
  });

  it('validates mutation — violations detected', () => {
    const soul = new SoulNode();
    const result = soul.validateMutation({
      id: 'test-2',
      structurallyValid: false,
      semanticallyCoherent: true,
      missionAligned: false,
    });
    assert.equal(result.valid, false);
    assert.equal(result.violations.length, 2);
  });

  it('validation history is bounded by SIZING.PATTERN_STORE', () => {
    const soul = new SoulNode();
    const maxEntries = SIZING.PATTERN_STORE; // 377
    for (let i = 0; i < maxEntries + 10; i++) {
      soul.validateMutation({
        id: `mut-${i}`,
        structurallyValid: true,
        semanticallyCoherent: true,
        missionAligned: true,
      });
    }
    assert.ok(soul.validationHistory.length <= maxEntries);
  });
});

// ═══════════════════════════════════════════════════════════════
// LIFECYCLE STATES
// ═══════════════════════════════════════════════════════════════

describe('LIFECYCLE_STATES', () => {
  it('has all 8 states', () => {
    const expected = ['init', 'active', 'thinking', 'responding', 'idle', 'degraded', 'hibernating', 'expired'];
    const actual = Object.values(LIFECYCLE_STATES);
    for (const state of expected) {
      assert.ok(actual.includes(state), `Missing state: ${state}`);
    }
    assert.equal(actual.length, 8);
  });

  it('is frozen', () => {
    assert.ok(Object.isFrozen(LIFECYCLE_STATES));
  });
});

// ═══════════════════════════════════════════════════════════════
// createLogger
// ═══════════════════════════════════════════════════════════════

describe('createLogger', () => {
  it('returns object with info, warn, error, debug methods', () => {
    const logger = createLogger('TestService');
    assert.equal(typeof logger.info, 'function');
    assert.equal(typeof logger.warn, 'function');
    assert.equal(typeof logger.error, 'function');
    assert.equal(typeof logger.debug, 'function');
  });

  it('does not throw when called with data and message', () => {
    const logger = createLogger('TestLogger');
    assert.doesNotThrow(() => logger.info({ key: 'val' }, 'test message'));
    assert.doesNotThrow(() => logger.warn({}, 'warning'));
    assert.doesNotThrow(() => logger.error({ err: 'x' }, 'error'));
    assert.doesNotThrow(() => logger.debug(null, 'debug'));
  });
});

// ═══════════════════════════════════════════════════════════════
// VALID_TRANSITIONS
// ═══════════════════════════════════════════════════════════════

describe('VALID_TRANSITIONS', () => {
  it('init can transition to active and expired', () => {
    assert.deepStrictEqual(VALID_TRANSITIONS.init, ['active', 'expired']);
  });

  it('expired has no valid transitions', () => {
    assert.deepStrictEqual(VALID_TRANSITIONS.expired, []);
  });

  it('covers all lifecycle states as keys', () => {
    for (const state of Object.values(LIFECYCLE_STATES)) {
      assert.ok(state in VALID_TRANSITIONS, `Missing transitions for state: ${state}`);
    }
  });
});
