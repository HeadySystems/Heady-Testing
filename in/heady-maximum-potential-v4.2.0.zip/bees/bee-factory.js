/**
 * BeeFactory — Singleton Registry for Creating, Tracking & Retiring Bees
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * The BeeFactory is the single source of truth for all bee lifecycle
 * management. It maintains a template registry of bee class constructors,
 * tracks all active bees by ID, and archives retired bees for post-mortem
 * analysis. Every bee creation goes through the factory to ensure
 * consistent initialization and telemetry.
 *
 * @module bee-factory
 * @version 4.1.0
 */

import { randomUUID } from 'node:crypto';

import { createLogger, nodeBus } from '../shared/liquid-node.js';
import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  cslGate, cosineSimilarity,
  POOL_ALLOCATION,
} from '../shared/phi-constants.js';

import { BaseHeadyBee } from './base-heady-bee.js';

// ═══════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════

/** Maximum retired bees to retain — FIB[16] = 987 */
const MAX_RETIRED = FIB[16];

/** All registered bee type names in the Heady ecosystem */
const ALL_BEE_TYPES = Object.freeze([
  'agents-bee',
  'auth-provider-bee',
  'auto-success-bee',
  'brain-bee',
  'config-bee',
  'connectors-bee',
  'creative-bee',
  'deployment-bee',
  'device-provisioner-bee',
  'documentation-bee',
  'engines-bee',
  'governance-bee',
  'health-bee',
  'intelligence-bee',
  'lifecycle-bee',
  'mcp-bee',
  'memory-bee',
  'middleware-bee',
  'midi-bee',
  'ops-bee',
  'orchestration-bee',
  'pipeline-bee',
  'providers-bee',
  'refactor-bee',
  'resilience-bee',
  'routes-bee',
  'security-bee',
  'services-bee',
  'sync-projection-bee',
  'telemetry-bee',
  'trading-bee',
  'vector-ops-bee',
  'vector-template-bee',
]);

// ═══════════════════════════════════════════════════════════════
// BEE FACTORY
// ═══════════════════════════════════════════════════════════════

/**
 * BeeFactory — Singleton registry that creates, tracks, and retires bees.
 *
 * Maintains a template registry of bee class constructors keyed by type name,
 * an active bees map for all live bees, and a bounded retired bees archive
 * capped at FIB[16] (987) entries for post-mortem analysis.
 */
class BeeFactory {
  /** @type {BeeFactory|null} Singleton instance */
  static _instance = null;

  /**
   * @param {Object} [config={}] - Factory configuration
   */
  constructor(config = {}) {
    /** @type {Map<string, typeof BaseHeadyBee>} Bee class constructors keyed by type name */
    this.templates = new Map();

    /** @type {Map<string, BaseHeadyBee>} All live bees keyed by beeId */
    this.activeBees = new Map();

    /** @type {Object[]} Archived retired bee records (capped at MAX_RETIRED) */
    this.retiredBees = [];

    /** @type {Object} Factory-level metrics */
    this.factoryMetrics = {
      totalCreated: 0,
      totalRetired: 0,
      totalFailed: 0,
      swarmsSpawned: 0,
    };

    /** @type {Object} Structured logger */
    this.logger = createLogger('BeeFactory');

    // Pre-register all known bee types with BaseHeadyBee as default
    this._preRegisterTypes();

    this.logger.info({
      registeredTypes: this.templates.size,
    }, 'BeeFactory initialized');
  }

  // ─────────────────────────────────────────────────────────────
  // SINGLETON ACCESS
  // ─────────────────────────────────────────────────────────────

  /**
   * Return the singleton BeeFactory instance.
   * Creates the instance on first call.
   *
   * @returns {BeeFactory} Singleton instance
   */
  static getInstance() {
    if (!BeeFactory._instance) {
      BeeFactory._instance = new BeeFactory();
    }
    return BeeFactory._instance;
  }

  // ─────────────────────────────────────────────────────────────
  // TEMPLATE REGISTRATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Register a bee class constructor for a given type name.
   *
   * Validates that the provided class extends BaseHeadyBee to ensure
   * lifecycle compatibility. Overwrites any existing registration for
   * the same type name.
   *
   * @param {string} type - Bee type identifier (e.g. 'brain-bee')
   * @param {typeof BaseHeadyBee} BeeClass - Class constructor extending BaseHeadyBee
   * @throws {Error} If BeeClass does not extend BaseHeadyBee
   */
  registerTemplate(type, BeeClass) {
    if (!type || typeof type !== 'string') {
      throw new Error('BeeFactory: type must be a non-empty string');
    }

    if (typeof BeeClass !== 'function') {
      throw new Error(`BeeFactory: BeeClass for '${type}' must be a constructor function`);
    }

    // Validate inheritance chain — BeeClass must extend BaseHeadyBee
    if (BeeClass !== BaseHeadyBee && !(BeeClass.prototype instanceof BaseHeadyBee)) {
      throw new Error(
        `BeeFactory: '${type}' class must extend BaseHeadyBee (got ${BeeClass.name || 'anonymous'})`
      );
    }

    this.templates.set(type, BeeClass);
    this.logger.info({ type, className: BeeClass.name }, 'Template registered');
  }

  // ─────────────────────────────────────────────────────────────
  // BEE CREATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Create a new bee instance from the registered template.
   *
   * Looks up the bee class constructor by type, instantiates it with
   * the provided config, assigns a unique beeId, and stores it in
   * the activeBees map.
   *
   * @param {string} type - Bee type identifier
   * @param {Object} [config={}] - Bee configuration passed to the constructor
   * @param {Object} [config.task] - Task for the bee to execute
   * @param {string} [config.swarmId] - Swarm group identifier
   * @param {string} [config.parentBee] - Parent bee ID
   * @returns {BaseHeadyBee} Newly created bee instance
   * @throws {Error} If type has no registered template
   */
  create(type, config = {}) {
    const BeeClass = this.templates.get(type);
    if (!BeeClass) {
      throw new Error(`BeeFactory: no template registered for type '${type}'`);
    }

    const bee = new BeeClass({
      ...config,
      type,
    });

    this.activeBees.set(bee.beeId, bee);
    this.factoryMetrics.totalCreated++;

    this.logger.info({
      beeId: bee.beeId,
      type,
      swarmId: bee.swarmId,
      totalActive: this.activeBees.size,
    }, 'Bee created');

    nodeBus.emit('factory:created', {
      beeId: bee.beeId,
      type,
      swarmId: bee.swarmId,
      timestamp: new Date().toISOString(),
    });

    return bee;
  }

  // ─────────────────────────────────────────────────────────────
  // BEE RETIREMENT
  // ─────────────────────────────────────────────────────────────

  /**
   * Retire a bee by ID — calls bee.retire(), moves from active to retired archive.
   *
   * The bee's telemetry and health report are archived for post-mortem
   * analysis. The retired archive is bounded at FIB[16] (987) entries.
   *
   * @param {string} beeId - Bee identifier to retire
   * @returns {Promise<Object|null>} Retired bee's health report, or null if not found
   */
  async retire(beeId) {
    const bee = this.activeBees.get(beeId);
    if (!bee) {
      this.logger.warn({ beeId }, 'Cannot retire: bee not found in activeBees');
      return null;
    }

    try {
      await bee.retire();
    } catch (err) {
      this.logger.error({ beeId, error: err.message }, 'Error during bee retirement');
      this.factoryMetrics.totalFailed++;
    }

    const healthReport = bee.toHealthReport();

    this.activeBees.delete(beeId);
    this.retiredBees.push({
      ...healthReport,
      retiredAt: new Date().toISOString(),
    });

    this.pruneRetired();
    this.factoryMetrics.totalRetired++;

    this.logger.info({
      beeId,
      type: bee.type,
      totalActive: this.activeBees.size,
      totalRetired: this.retiredBees.length,
    }, 'Bee retired');

    nodeBus.emit('factory:retired', {
      beeId,
      type: bee.type,
      timestamp: new Date().toISOString(),
    });

    return healthReport;
  }

  // ─────────────────────────────────────────────────────────────
  // QUERIES
  // ─────────────────────────────────────────────────────────────

  /**
   * Return all active bees as an array.
   *
   * @returns {BaseHeadyBee[]} Array of active bee instances
   */
  getActive() {
    return [...this.activeBees.values()];
  }

  /**
   * Filter active bees by type.
   *
   * @param {string} type - Bee type to filter by
   * @returns {BaseHeadyBee[]} Active bees matching the type
   */
  getByType(type) {
    return [...this.activeBees.values()].filter(bee => bee.type === type);
  }

  /**
   * Filter active bees by swarm ID.
   *
   * @param {string} swarmId - Swarm identifier to filter by
   * @returns {BaseHeadyBee[]} Active bees belonging to the swarm
   */
  getSwarm(swarmId) {
    return [...this.activeBees.values()].filter(bee => bee.swarmId === swarmId);
  }

  // ─────────────────────────────────────────────────────────────
  // HEALTH REPORTING
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate a comprehensive health report for the factory and all active bees.
   *
   * @returns {Object} Factory health report with totals, per-type counts, and bee details
   */
  healthReport() {
    const byType = new Map();
    const beeReports = [];

    for (const bee of this.activeBees.values()) {
      const count = byType.get(bee.type) || 0;
      byType.set(bee.type, count + 1);
      beeReports.push(bee.toHealthReport());
    }

    return {
      totalActive: this.activeBees.size,
      totalRetired: this.retiredBees.length,
      maxRetired: MAX_RETIRED,
      registeredTypes: this.templates.size,
      factoryMetrics: { ...this.factoryMetrics },
      byType: Object.fromEntries(byType),
      bees: beeReports,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // PRUNING
  // ─────────────────────────────────────────────────────────────

  /**
   * Trim the retired bees archive to the maximum capacity (FIB[16] = 987).
   * Oldest entries are removed first.
   *
   * @returns {number} Number of entries pruned
   */
  pruneRetired() {
    if (this.retiredBees.length <= MAX_RETIRED) return 0;

    const excess = this.retiredBees.length - MAX_RETIRED;
    this.retiredBees.splice(0, excess);

    this.logger.debug({ pruned: excess, remaining: this.retiredBees.length }, 'Retired bees pruned');
    return excess;
  }

  // ─────────────────────────────────────────────────────────────
  // SWARM SPAWNING
  // ─────────────────────────────────────────────────────────────

  /**
   * Spawn multiple bees concurrently as a swarm.
   *
   * Creates bees for each specified type, assigns them a shared swarmId,
   * and spawns them all concurrently. Returns the array of spawned bees.
   *
   * @param {string[]} types - Array of bee type identifiers to spawn
   * @param {Object} [context={}] - Shared spawn context for all bees
   * @param {Object} [config={}] - Shared config applied to all bees
   * @returns {Promise<BaseHeadyBee[]>} Array of spawned bee instances
   */
  async spawnSwarm(types, context = {}, config = {}) {
    const swarmId = config.swarmId || randomUUID();
    const bees = [];

    for (const type of types) {
      const bee = this.create(type, {
        ...config,
        swarmId,
        task: config.task || {},
      });
      bees.push(bee);
    }

    // Spawn all bees concurrently
    await Promise.all(bees.map(bee => bee.spawn(context)));

    this.factoryMetrics.swarmsSpawned++;

    this.logger.info({
      swarmId,
      types,
      beeCount: bees.length,
      totalActive: this.activeBees.size,
    }, 'Swarm spawned');

    nodeBus.emit('factory:swarmSpawned', {
      swarmId,
      beeIds: bees.map(b => b.beeId),
      types,
      timestamp: new Date().toISOString(),
    });

    return bees;
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL: PRE-REGISTRATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Pre-register all known bee types with BaseHeadyBee as the default
   * constructor. Concrete subclasses can re-register to override.
   */
  _preRegisterTypes() {
    for (const type of ALL_BEE_TYPES) {
      this.templates.set(type, BaseHeadyBee);
    }
    this.logger.debug({
      count: ALL_BEE_TYPES.length,
      types: ALL_BEE_TYPES,
    }, 'Pre-registered bee types');
  }
}

export { BeeFactory, BeeFactory as default };
