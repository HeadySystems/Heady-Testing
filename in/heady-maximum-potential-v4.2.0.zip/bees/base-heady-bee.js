/**
 * BaseHeadyBee — Universal Base Class for All Heady Bee Types
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Every bee in the Heady swarm extends BaseHeadyBee. This class provides the
 * complete spawn → execute → report → retire lifecycle with phi-scaled retry
 * logic, CSL-gated relevance scoring, structured telemetry, and LIFO cleanup.
 *
 * Lifecycle: spawned → executing → reporting → retired | failed
 *
 * @module base-heady-bee
 * @version 4.1.0
 */

import { randomUUID } from 'node:crypto';

import { BeeNode, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiBackoff, cslGate, cosineSimilarity,
  POOL_ALLOCATION,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// BEE STATUS LIFECYCLE
// ═══════════════════════════════════════════════════════════════

const BEE_STATUS = Object.freeze({
  SPAWNED:   'spawned',
  EXECUTING: 'executing',
  REPORTING: 'reporting',
  RETIRED:   'retired',
  FAILED:    'failed',
});

// ═══════════════════════════════════════════════════════════════
// BASE HEADY BEE
// ═══════════════════════════════════════════════════════════════

/**
 * BaseHeadyBee — The universal base class that all 30+ bee types extend.
 *
 * Provides phi-scaled retry logic, CSL-gated relevance scoring, structured
 * telemetry collection, LIFO cleanup via cleanupStack, and the full
 * spawn → execute → report → retire lifecycle.
 *
 * @extends BeeNode
 */
class BaseHeadyBee extends BeeNode {
  /**
   * @param {Object} config - Bee configuration
   * @param {string} config.type - Bee type identifier (e.g. 'brain-bee', 'memory-bee')
   * @param {Object} config.task - Task descriptor for this bee to execute
   * @param {string} [config.swarmId] - Swarm group identifier
   * @param {string} [config.parentBee] - Parent bee ID for hierarchical swarms
   * @param {string} [config.name] - Override node name (defaults to type-based name)
   * @param {string} [config.ring='outer'] - Topology ring
   * @param {string} [config.pool='warm'] - Resource pool
   * @param {string} [config.domain='headyme.com'] - Domain identifier
   * @param {string[]} [config.capabilities] - Bee capabilities
   */
  constructor(config = {}) {
    const beeId = randomUUID();
    const type = config.type || 'generic-bee';

    super({
      name: config.name || `${type}:${beeId.slice(0, 8)}`,
      ring: config.ring || 'outer',
      pool: config.pool || 'warm',
      domain: config.domain || 'headyme.com',
      capabilities: config.capabilities || [type],
      ...config,
    });

    /** @type {string} Unique bee identifier */
    this.beeId = beeId;

    /** @type {string} Bee type identifier */
    this.type = type;

    /** @type {Object} Task assigned to this bee */
    this.task = config.task || {};

    /** @type {string|null} Swarm group identifier */
    this.swarmId = config.swarmId || null;

    /** @type {string|null} Parent bee ID for hierarchical swarms */
    this.parentBee = config.parentBee || null;

    /** @type {number} Maximum retry attempts — FIB[6] = 8 */
    this.maxRetries = FIB[6];

    /** @type {number} Base timeout in ms — phi-scaled: round(PHI * 1000) = 1618 */
    this.timeout = Math.round(PHI * 1000);

    /** @type {number} Current retry count */
    this.retryCount = 0;

    /** @type {string} Current lifecycle status */
    this.status = BEE_STATUS.SPAWNED;

    /** @type {*} Execution results */
    this.results = null;

    /** @type {number|null} Execution start timestamp */
    this.startTime = null;

    /** @type {number|null} Execution end timestamp */
    this.endTime = null;

    /** @type {Object} Structured telemetry */
    this.telemetry = {
      tasksCompleted: 0,
      totalDurationMs: 0,
      errors: 0,
      avgCoherence: 1.0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // LIFECYCLE: SPAWN
  // ─────────────────────────────────────────────────────────────

  /**
   * Spawn the bee — validate the task, register with the factory, and emit lifecycle event.
   *
   * Validates that a task is present and has the minimum required structure,
   * calls the parent BeeNode spawn for initialization, and emits a
   * 'bee:spawned' event on the nodeBus.
   *
   * @param {Object} [context={}] - Spawn context (session, environment, metadata)
   * @returns {Promise<void>}
   * @throws {Error} If task is missing or invalid
   */
  async spawn(context = {}) {
    if (!this.task || (typeof this.task === 'object' && Object.keys(this.task).length === 0 && !this.task.type)) {
      this.logger.warn({ beeId: this.beeId, type: this.type }, 'Bee spawned without a task');
    }

    this.status = BEE_STATUS.SPAWNED;
    this.startTime = Date.now();

    await super.spawn(context);

    nodeBus.emit('bee:spawned', {
      beeId: this.beeId,
      type: this.type,
      swarmId: this.swarmId,
      parentBee: this.parentBee,
      task: this.task?.type || this.task?.id || 'unknown',
      timestamp: new Date().toISOString(),
    });

    this.logger.info({
      beeId: this.beeId,
      type: this.type,
      swarmId: this.swarmId,
      parentBee: this.parentBee,
    }, 'Bee spawned');
  }

  // ─────────────────────────────────────────────────────────────
  // LIFECYCLE: EXECUTE (with phi-scaled retry)
  // ─────────────────────────────────────────────────────────────

  /**
   * Execute the assigned task with phi-scaled backoff retry logic.
   *
   * Subclasses MUST override this method to provide their specific
   * execution logic. The base implementation throws to enforce this
   * contract. The run() orchestrator wraps this with retry handling
   * using phiBackoff for delay calculation between attempts.
   *
   * @param {Object} task - Task to execute
   * @returns {Promise<*>} Execution result
   * @throws {Error} Always — subclasses must override
   */
  async execute(task) {
    throw new Error(`${this.type}: execute() must be overridden by subclass`);
  }

  /**
   * Internal retry wrapper around execute().
   * Uses phiBackoff for exponential delay between attempts.
   *
   * @param {Object} task - Task to execute
   * @returns {Promise<*>} Execution result from successful attempt
   * @throws {Error} If all retry attempts are exhausted
   */
  async _executeWithRetry(task) {
    this.status = BEE_STATUS.EXECUTING;
    let lastError = null;

    for (let attempt = 0; attempt <= this.maxRetries; attempt++) {
      try {
        if (attempt > 0) {
          const delay = phiBackoff(attempt, this.timeout);
          this.logger.info({
            beeId: this.beeId,
            attempt,
            maxRetries: this.maxRetries,
            delayMs: delay,
          }, 'Retrying execution');
          await this._sleep(delay);
        }

        this.retryCount = attempt;
        const result = await this.execute(task);
        return result;
      } catch (err) {
        lastError = err;
        this.telemetry.errors++;
        this.logger.warn({
          beeId: this.beeId,
          attempt,
          maxRetries: this.maxRetries,
          error: err.message,
        }, 'Execution attempt failed');
      }
    }

    throw lastError;
  }

  // ─────────────────────────────────────────────────────────────
  // LIFECYCLE: REPORT
  // ─────────────────────────────────────────────────────────────

  /**
   * Collect results and telemetry, emit report event, and return the report.
   *
   * Computes coherence score, finalizes telemetry metrics, and emits
   * 'bee:report' on the nodeBus for aggregation by the swarm coordinator.
   *
   * @returns {Promise<Object>} Report containing beeId, type, results, telemetry, coherenceScore
   */
  async report() {
    this.status = BEE_STATUS.REPORTING;
    this.endTime = Date.now();

    const durationMs = this.endTime - (this.startTime || this.endTime);
    this.telemetry.totalDurationMs += durationMs;
    if (this.results !== null) {
      this.telemetry.tasksCompleted++;
    }

    // Update rolling average coherence
    const currentCoherence = this.coherenceScore;
    const completed = this.telemetry.tasksCompleted || 1;
    this.telemetry.avgCoherence =
      (this.telemetry.avgCoherence * (completed - 1) + currentCoherence) / completed;

    const reportData = {
      beeId: this.beeId,
      type: this.type,
      swarmId: this.swarmId,
      results: this.results,
      telemetry: { ...this.telemetry },
      coherenceScore: currentCoherence,
      durationMs,
      retryCount: this.retryCount,
      timestamp: new Date().toISOString(),
    };

    await super.report(reportData);

    nodeBus.emit('bee:report', reportData);

    this.logger.info({
      beeId: this.beeId,
      type: this.type,
      durationMs,
      coherence: currentCoherence.toFixed(4),
      tasksCompleted: this.telemetry.tasksCompleted,
    }, 'Bee report submitted');

    return reportData;
  }

  // ─────────────────────────────────────────────────────────────
  // LIFECYCLE: RETIRE
  // ─────────────────────────────────────────────────────────────

  /**
   * Retire the bee — perform LIFO cleanup and emit lifecycle event.
   *
   * Pops and executes all cleanup functions from the cleanupStack
   * in LIFO order, transitions status to retired, and emits
   * 'bee:retired' on the nodeBus.
   *
   * @returns {Promise<void>}
   */
  async retire() {
    this.status = BEE_STATUS.RETIRED;

    await super.retire();

    nodeBus.emit('bee:retired', {
      beeId: this.beeId,
      type: this.type,
      swarmId: this.swarmId,
      telemetry: { ...this.telemetry },
      timestamp: new Date().toISOString(),
    });

    this.logger.info({
      beeId: this.beeId,
      type: this.type,
      tasksCompleted: this.telemetry.tasksCompleted,
      totalDurationMs: this.telemetry.totalDurationMs,
    }, 'Bee retired');
  }

  // ─────────────────────────────────────────────────────────────
  // LIFECYCLE: RUN (Full Orchestrator)
  // ─────────────────────────────────────────────────────────────

  /**
   * Orchestrate the full bee lifecycle: spawn → execute → report → retire.
   *
   * Wraps the entire lifecycle in try/catch so that retire() is always
   * called on failure, ensuring LIFO cleanup even when execution throws.
   *
   * @param {Object} [context={}] - Spawn context
   * @returns {Promise<Object>} The report from the report() phase
   * @throws {Error} Re-throws execution errors after retirement
   */
  async run(context = {}) {
    try {
      await this.spawn(context);
      this.results = await this._executeWithRetry(this.task);
      const reportData = await this.report();
      await this.retire();
      return reportData;
    } catch (err) {
      this.status = BEE_STATUS.FAILED;
      this.telemetry.errors++;
      this.logger.error({
        beeId: this.beeId,
        type: this.type,
        error: err.message,
        retryCount: this.retryCount,
      }, 'Bee lifecycle failed');

      try {
        await this.retire();
      } catch (retireErr) {
        this.logger.error({
          beeId: this.beeId,
          error: retireErr.message,
        }, 'Retirement after failure also failed');
      }

      throw err;
    }
  }

  // ─────────────────────────────────────────────────────────────
  // CSL-GATED RELEVANCE SCORING
  // ─────────────────────────────────────────────────────────────

  /**
   * Compute CSL-gated relevance score between a task embedding and this bee's embedding.
   *
   * Uses cosine similarity gated through the CSL sigmoid function
   * with the LOW threshold to produce a [0,1] relevance score.
   *
   * @param {number[]} taskEmbedding - 384D task embedding vector
   * @returns {number} CSL-gated relevance score (0-1)
   */
  relevanceScore(taskEmbedding) {
    if (!taskEmbedding || !this.embedding) return 0;
    const similarity = cosineSimilarity(this.embedding, taskEmbedding);
    return cslGate(1.0, similarity, CSL_THRESHOLDS.LOW);
  }

  // ─────────────────────────────────────────────────────────────
  // HEALTH REPORTING
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate a structured health report for this bee.
   *
   * @returns {Object} Health report with name, type, status, coherence, uptime, telemetry
   */
  toHealthReport() {
    const uptimeMs = this.startTime ? Date.now() - this.startTime : 0;
    return {
      name: this.name,
      beeId: this.beeId,
      type: this.type,
      status: this.status,
      swarmId: this.swarmId,
      coherence: this.coherenceScore,
      uptime: uptimeMs,
      retryCount: this.retryCount,
      telemetry: { ...this.telemetry },
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL HELPERS
  // ─────────────────────────────────────────────────────────────

  /**
   * Async sleep helper for retry backoff.
   * @param {number} ms - Milliseconds to sleep
   * @returns {Promise<void>}
   */
  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export { BaseHeadyBee, BaseHeadyBee as default };
