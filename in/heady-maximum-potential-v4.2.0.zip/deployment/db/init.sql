-- ═══════════════════════════════════════════════════════════════
-- Heady PostgreSQL + pgvector — Database Initialization
-- Sacred Geometry v4.0 — Fibonacci-indexed HNSW parameters
-- © 2026 HeadySystems Inc. — Eric Haywood, Founder
-- ═══════════════════════════════════════════════════════════════

-- Enable extensions
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- ─── Vector Memory Table ────────────────────────────────────

CREATE TABLE IF NOT EXISTS vector_memory (
    id          TEXT PRIMARY KEY,
    embedding   vector(384),          -- 384D embeddings (Heady standard)
    content     TEXT NOT NULL,
    metadata    JSONB DEFAULT '{}',
    node_name   TEXT,
    ring        TEXT,                  -- center, inner, middle, outer, governance
    pool        TEXT DEFAULT 'warm',   -- hot, warm, cold, reserve, governance
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW(),
    accessed_at TIMESTAMPTZ DEFAULT NOW(),
    access_count INTEGER DEFAULT 0
);

-- HNSW Index: m=fib(8)=21, ef_construction=fib(11)=89
CREATE INDEX IF NOT EXISTS idx_vector_memory_embedding
    ON vector_memory USING hnsw (embedding vector_cosine_ops)
    WITH (m = 21, ef_construction = 89);

-- BM25 full-text search index
CREATE INDEX IF NOT EXISTS idx_vector_memory_content_gin
    ON vector_memory USING gin (to_tsvector('english', content));

-- Metadata GIN index for JSONB queries
CREATE INDEX IF NOT EXISTS idx_vector_memory_metadata
    ON vector_memory USING gin (metadata);

-- Pool + ring composite index
CREATE INDEX IF NOT EXISTS idx_vector_memory_pool_ring
    ON vector_memory (pool, ring);

-- ─── Node Registry ──────────────────────────────────────────

CREATE TABLE IF NOT EXISTS node_registry (
    name            TEXT PRIMARY KEY,
    version         TEXT NOT NULL,
    ring            TEXT NOT NULL,
    pool            TEXT NOT NULL,
    state           TEXT DEFAULT 'INIT',
    coherence_score DOUBLE PRECISION DEFAULT 1.0,
    embedding       vector(384),
    config          JSONB DEFAULT '{}',
    metadata        JSONB DEFAULT '{}',
    spawned_at      TIMESTAMPTZ,
    last_heartbeat  TIMESTAMPTZ DEFAULT NOW(),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Pipeline Runs ──────────────────────────────────────────

CREATE TABLE IF NOT EXISTS pipeline_runs (
    id              TEXT PRIMARY KEY,
    task_type       TEXT NOT NULL,
    state           TEXT NOT NULL DEFAULT 'PENDING',
    duration_ms     BIGINT,
    stage_count     INTEGER DEFAULT 0,
    retry_count     INTEGER DEFAULT 0,
    quality_score   DOUBLE PRECISION,
    assurance_score DOUBLE PRECISION,
    input_hash      TEXT,
    output_hash     TEXT,
    stages          JSONB DEFAULT '[]',
    metadata        JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    completed_at    TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_pipeline_runs_state
    ON pipeline_runs (state);

CREATE INDEX IF NOT EXISTS idx_pipeline_runs_task_type
    ON pipeline_runs (task_type);

CREATE INDEX IF NOT EXISTS idx_pipeline_runs_created
    ON pipeline_runs (created_at DESC);

-- ─── Audit Log (SOC 2 Ready) ────────────────────────────────

CREATE TABLE IF NOT EXISTS audit_log (
    id              BIGSERIAL PRIMARY KEY,
    timestamp       TIMESTAMPTZ DEFAULT NOW(),
    tool            TEXT NOT NULL,
    user_id         TEXT,
    action          TEXT NOT NULL,
    input_hash      TEXT,           -- SHA-256 of input
    output_hash     TEXT,           -- SHA-256 of output
    duration_ms     INTEGER,
    prev_hash       TEXT,           -- cryptographic chain
    record_hash     TEXT,           -- SHA-256 of this record
    metadata        JSONB DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_audit_log_timestamp
    ON audit_log (timestamp DESC);

CREATE INDEX IF NOT EXISTS idx_audit_log_user
    ON audit_log (user_id, timestamp DESC);

-- Retention policy: fib(11) = 89 days (handled by cron/HeadyMaid)

-- ─── Wisdom Store (Knowledge Graph) ─────────────────────────

CREATE TABLE IF NOT EXISTS wisdom_entries (
    id              TEXT PRIMARY KEY,
    content         TEXT NOT NULL,
    embedding       vector(384),
    category        TEXT,
    confidence      DOUBLE PRECISION DEFAULT 0.5,
    access_count    INTEGER DEFAULT 0,
    crystallized    BOOLEAN DEFAULT FALSE,
    metadata        JSONB DEFAULT '{}',
    connections     TEXT[] DEFAULT '{}',  -- related entry IDs
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_wisdom_embedding
    ON wisdom_entries USING hnsw (embedding vector_cosine_ops)
    WITH (m = 21, ef_construction = 89);

CREATE INDEX IF NOT EXISTS idx_wisdom_category
    ON wisdom_entries (category);

-- ─── Budget Tracking ────────────────────────────────────────

CREATE TABLE IF NOT EXISTS budget_entries (
    id              BIGSERIAL PRIMARY KEY,
    provider        TEXT NOT NULL,
    model           TEXT NOT NULL,
    tokens_input    INTEGER DEFAULT 0,
    tokens_output   INTEGER DEFAULT 0,
    cost_usd        DOUBLE PRECISION DEFAULT 0.0,
    task_type       TEXT,
    run_id          TEXT,
    recorded_at     TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_budget_provider
    ON budget_entries (provider, recorded_at DESC);

CREATE INDEX IF NOT EXISTS idx_budget_recorded
    ON budget_entries (recorded_at DESC);

-- ─── Arena Results ──────────────────────────────────────────

CREATE TABLE IF NOT EXISTS arena_results (
    id              TEXT PRIMARY KEY,
    task_type       TEXT NOT NULL,
    winner          TEXT NOT NULL,
    winner_nodes    TEXT[] NOT NULL,
    avg_score       DOUBLE PRECISION,
    contenders      JSONB DEFAULT '[]',
    evaluated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_arena_task_type
    ON arena_results (task_type, evaluated_at DESC);

-- ─── Helper Functions ───────────────────────────────────────

-- Hybrid search function: combines BM25 + vector cosine via RRF
CREATE OR REPLACE FUNCTION hybrid_search(
    query_text TEXT,
    query_embedding vector(384),
    result_limit INTEGER DEFAULT 21,    -- fib(8)
    bm25_weight DOUBLE PRECISION DEFAULT 0.382,  -- PSI^2
    dense_weight DOUBLE PRECISION DEFAULT 0.618   -- PSI
)
RETURNS TABLE (
    id TEXT,
    content TEXT,
    metadata JSONB,
    bm25_rank INTEGER,
    dense_rank INTEGER,
    rrf_score DOUBLE PRECISION
) AS $$
WITH bm25_results AS (
    SELECT vm.id, vm.content, vm.metadata,
           ROW_NUMBER() OVER (ORDER BY ts_rank(to_tsvector('english', vm.content), plainto_tsquery('english', query_text)) DESC) AS rank
    FROM vector_memory vm
    WHERE to_tsvector('english', vm.content) @@ plainto_tsquery('english', query_text)
    LIMIT result_limit * 3
),
dense_results AS (
    SELECT vm.id, vm.content, vm.metadata,
           ROW_NUMBER() OVER (ORDER BY vm.embedding <=> query_embedding) AS rank
    FROM vector_memory vm
    ORDER BY vm.embedding <=> query_embedding
    LIMIT result_limit * 3
),
combined AS (
    SELECT
        COALESCE(b.id, d.id) AS id,
        COALESCE(b.content, d.content) AS content,
        COALESCE(b.metadata, d.metadata) AS metadata,
        COALESCE(b.rank, 999) AS bm25_rank,
        COALESCE(d.rank, 999) AS dense_rank,
        (bm25_weight / (60.0 + COALESCE(b.rank, 999))) +
        (dense_weight / (60.0 + COALESCE(d.rank, 999))) AS rrf_score
    FROM bm25_results b
    FULL OUTER JOIN dense_results d ON b.id = d.id
)
SELECT combined.id, combined.content, combined.metadata,
       combined.bm25_rank::INTEGER, combined.dense_rank::INTEGER, combined.rrf_score
FROM combined
ORDER BY combined.rrf_score DESC
LIMIT result_limit;
$$ LANGUAGE SQL STABLE;

-- ─── Set efSearch at runtime ────────────────────────────────
-- fib(11) = 89 for standard queries
SET ivfflat.probes = 21;
