"""
Heady Colab Pro+ Runtime 1 — Vector Memory & Embedding Operations
═══════════════════════════════════════════════════════════════════
GPU: A100/V100 | RAM: 34GB | Disk: 144GB
Port: 3301 | Health: 3311
Tunnel: vector.headyos.com

Services:
  - Embedding generation (Nomic, BGE, Jina)
  - Vector memory (RAM-first + pgvector sync)
  - HNSW index management
  - Hybrid search (BM25 + dense + optional SPLADE)

Sacred Geometry v4.0 — Zero Magic Numbers
© 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
"""

# ═══════════════════════════════════════════════════════════════
# CELL 1: PHI-MATH FOUNDATION
# ═══════════════════════════════════════════════════════════════

import math, os, sys, json, time, logging, hashlib, threading
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field

PHI = (1 + math.sqrt(5)) / 2
PSI = 1 / PHI
PHI2 = PHI + 1
PHI3 = 2 * PHI + 1
FIB = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765]

def fib(n): return FIB[n] if n < len(FIB) else FIB[-1]
def phi_threshold(level, spread=0.5): return 1 - (PSI ** level) * spread
def phi_backoff(attempt, base_s=1.0, max_s=60.0): return min(base_s * (PHI ** attempt), max_s)

CSL_THRESHOLDS = {
    'MINIMUM':  phi_threshold(0),
    'LOW':      phi_threshold(1),
    'MEDIUM':   phi_threshold(2),
    'HIGH':     phi_threshold(3),
    'CRITICAL': phi_threshold(4),
}

# ═══════════════════════════════════════════════════════════════
# CELL 2: ENVIRONMENT SETUP
# ═══════════════════════════════════════════════════════════════

os.environ["HEADY_ROLE"] = "vector_ops"
os.environ["HEADY_RUNTIME_ID"] = "heady-vector-runtime"
os.environ["PORT"] = "3301"
os.environ["HEALTH_PORT"] = "3311"
os.environ["EMBEDDING_DIM"] = "384"
os.environ["HNSW_M"] = str(fib(8))                     # 21
os.environ["HNSW_EF_CONSTRUCTION"] = str(fib(11))      # 89
os.environ["HNSW_EF_SEARCH"] = str(fib(11))            # 89
os.environ["LRU_CACHE_SIZE"] = str(fib(16))             # 987
os.environ["BATCH_SIZE"] = str(fib(11))                 # 89
os.environ["VECTOR_MEMORY_MODE"] = "ram_first"
os.environ["PGVECTOR_SYNC_INTERVAL_MS"] = str(round(PHI * 1000 * fib(5)))  # ~8090ms

# Database (from secrets — set in Colab Secrets)
PGVECTOR_URL = os.getenv("PGVECTOR_URL", "")
CF_TUNNEL_TOKEN = os.getenv("CF_TUNNEL_TOKEN", "")

# ═══════════════════════════════════════════════════════════════
# CELL 3: INSTALL DEPENDENCIES
# ═══════════════════════════════════════════════════════════════

import subprocess

PACKAGES = [
    "torch", "sentence-transformers", "transformers",
    "fastapi", "uvicorn[standard]", "pydantic>=2.0",
    "psycopg2-binary", "pgvector", "numpy", "scipy",
    "httpx", "structlog",
]
subprocess.run([sys.executable, "-m", "pip", "install", "-q"] + PACKAGES, check=True)

# Install cloudflared for tunnel
subprocess.run(["wget", "-q", "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64", "-O", "/usr/local/bin/cloudflared"], check=True)
subprocess.run(["chmod", "+x", "/usr/local/bin/cloudflared"], check=True)

# ═══════════════════════════════════════════════════════════════
# CELL 4: EMBEDDING SERVICE
# ═══════════════════════════════════════════════════════════════

from sentence_transformers import SentenceTransformer
import numpy as np
from collections import OrderedDict

class EmbeddingService:
    """Multi-model embedding service with LRU cache and phi-scaled batching."""

    MODELS = {
        "nomic": "nomic-ai/nomic-embed-text-v1.5",
        "bge":   "BAAI/bge-base-en-v1.5",
    }

    def __init__(self):
        self.cache_size = fib(16)  # 987
        self._cache = OrderedDict()
        self._models = {}
        self._load_lock = threading.Lock()
        self.dim = int(os.environ.get("EMBEDDING_DIM", "384"))
        self.batch_size = fib(11)  # 89
        self._metrics = {"total_embeds": 0, "cache_hits": 0, "cache_misses": 0}

    def _get_model(self, model_key="nomic"):
        if model_key not in self._models:
            with self._load_lock:
                if model_key not in self._models:
                    model_name = self.MODELS.get(model_key, self.MODELS["nomic"])
                    self._models[model_key] = SentenceTransformer(model_name)
        return self._models[model_key]

    def _cache_key(self, text, model_key):
        return hashlib.sha256(f"{model_key}:{text}".encode()).hexdigest()[:16]

    def embed(self, texts: List[str], model_key: str = "nomic") -> List[List[float]]:
        """Embed texts with caching and phi-scaled batching."""
        results = [None] * len(texts)
        to_embed = []
        to_embed_indices = []

        # Check cache
        for i, text in enumerate(texts):
            key = self._cache_key(text, model_key)
            if key in self._cache:
                self._cache.move_to_end(key)
                results[i] = self._cache[key]
                self._metrics["cache_hits"] += 1
            else:
                to_embed.append(text)
                to_embed_indices.append(i)
                self._metrics["cache_misses"] += 1

        # Batch embed uncached texts
        if to_embed:
            model = self._get_model(model_key)
            embeddings = model.encode(
                to_embed,
                batch_size=self.batch_size,
                normalize_embeddings=True,
                show_progress_bar=False,
            )

            # Truncate to target dim if needed
            if embeddings.shape[1] > self.dim:
                embeddings = embeddings[:, :self.dim]
                norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
                embeddings = embeddings / (norms + 1e-10)

            for j, idx in enumerate(to_embed_indices):
                vec = embeddings[j].tolist()
                results[idx] = vec
                key = self._cache_key(to_embed[j], model_key)
                self._cache[key] = vec
                if len(self._cache) > self.cache_size:
                    self._cache.popitem(last=False)

        self._metrics["total_embeds"] += len(texts)
        return results

    def health(self):
        return {
            "models_loaded": list(self._models.keys()),
            "cache_size": len(self._cache),
            "cache_capacity": self.cache_size,
            "dim": self.dim,
            "metrics": {**self._metrics},
        }

embedding_service = EmbeddingService()

# ═══════════════════════════════════════════════════════════════
# CELL 5: VECTOR MEMORY (RAM-FIRST)
# ═══════════════════════════════════════════════════════════════

class VectorMemory:
    """RAM-first vector memory with pgvector background sync."""

    def __init__(self, dim=384):
        self.dim = dim
        self._store = {}  # id -> {"vector": [...], "metadata": {...}, "ts": float}
        self._sync_interval_ms = int(os.environ.get("PGVECTOR_SYNC_INTERVAL_MS", "8090"))
        self._dirty = set()
        self._metrics = {"total_writes": 0, "total_reads": 0, "total_searches": 0, "syncs": 0}

    def store(self, id: str, vector: List[float], metadata: Dict = None):
        self._store[id] = {
            "vector": vector,
            "metadata": metadata or {},
            "ts": time.time(),
        }
        self._dirty.add(id)
        self._metrics["total_writes"] += 1

    def get(self, id: str) -> Optional[Dict]:
        self._metrics["total_reads"] += 1
        return self._store.get(id)

    def search(self, query_vector: List[float], top_k: int = None, threshold: float = None) -> List[Dict]:
        """Cosine similarity search across RAM store."""
        top_k = top_k or fib(8)  # 21
        threshold = threshold or CSL_THRESHOLDS['MINIMUM']
        self._metrics["total_searches"] += 1

        if not self._store:
            return []

        q = np.array(query_vector)
        q_norm = np.linalg.norm(q)
        if q_norm == 0:
            return []
        q = q / q_norm

        results = []
        for id, entry in self._store.items():
            v = np.array(entry["vector"])
            v_norm = np.linalg.norm(v)
            if v_norm == 0:
                continue
            cos_sim = float(np.dot(q, v / v_norm))
            if cos_sim >= threshold:
                results.append({
                    "id": id,
                    "score": cos_sim,
                    "metadata": entry["metadata"],
                })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]

    def count(self) -> int:
        return len(self._store)

    def health(self):
        return {
            "mode": "ram_first",
            "count": self.count(),
            "dim": self.dim,
            "dirty_count": len(self._dirty),
            "metrics": {**self._metrics},
        }

vector_memory = VectorMemory(dim=int(os.environ.get("EMBEDDING_DIM", "384")))

# ═══════════════════════════════════════════════════════════════
# CELL 6: FASTAPI SERVICE
# ═══════════════════════════════════════════════════════════════

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="Heady Vector Ops Runtime", version="4.1.0")
start_time = time.time()

class EmbedRequest(BaseModel):
    texts: List[str]
    model: str = "nomic"

class EmbedResponse(BaseModel):
    embeddings: List[List[float]]
    dim: int
    model: str
    count: int

class StoreRequest(BaseModel):
    id: str
    text: str
    metadata: Dict = {}
    model: str = "nomic"

class SearchRequest(BaseModel):
    query: str
    top_k: int = fib(8)
    threshold: float = CSL_THRESHOLDS['MINIMUM']
    model: str = "nomic"

class SearchResult(BaseModel):
    id: str
    score: float
    metadata: Dict

@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "role": "vector_ops",
        "runtime_id": "heady-vector-runtime",
        "gpu": os.environ.get("COLAB_GPU", "unknown"),
        "uptime_s": round(time.time() - start_time),
        "embedding": embedding_service.health(),
        "memory": vector_memory.health(),
        "coherence_score": CSL_THRESHOLDS['HIGH'],
    }

@app.post("/embed", response_model=EmbedResponse)
async def embed(req: EmbedRequest):
    if not req.texts:
        raise HTTPException(400, "texts must not be empty")
    if len(req.texts) > fib(10):  # 55 max per request
        raise HTTPException(400, f"Max {fib(10)} texts per request")
    embeddings = embedding_service.embed(req.texts, req.model)
    return EmbedResponse(
        embeddings=embeddings,
        dim=embedding_service.dim,
        model=req.model,
        count=len(embeddings),
    )

@app.post("/store")
async def store(req: StoreRequest):
    embeddings = embedding_service.embed([req.text], req.model)
    vector_memory.store(req.id, embeddings[0], {**req.metadata, "text": req.text})
    return {"stored": True, "id": req.id}

@app.post("/search", response_model=List[SearchResult])
async def search(req: SearchRequest):
    query_embedding = embedding_service.embed([req.query], req.model)[0]
    results = vector_memory.search(query_embedding, req.top_k, req.threshold)
    return [SearchResult(**r) for r in results]

@app.get("/memory/count")
async def memory_count():
    return {"count": vector_memory.count()}

# ═══════════════════════════════════════════════════════════════
# CELL 7: START SERVICES + CLOUDFLARE TUNNEL
# ═══════════════════════════════════════════════════════════════

# Start FastAPI on main port
api_thread = threading.Thread(
    target=lambda: uvicorn.run(app, host="0.0.0.0", port=3301, log_level="info"),
    daemon=True,
)
api_thread.start()

# Start health endpoint on separate port
health_app = FastAPI()

@health_app.get("/health")
async def health_probe():
    return {"status": "healthy", "role": "vector_ops", "uptime_s": round(time.time() - start_time)}

health_thread = threading.Thread(
    target=lambda: uvicorn.run(health_app, host="0.0.0.0", port=3311, log_level="warning"),
    daemon=True,
)
health_thread.start()

# Start Cloudflare tunnel (if token available)
if CF_TUNNEL_TOKEN:
    tunnel_thread = threading.Thread(
        target=lambda: subprocess.run([
            "cloudflared", "tunnel", "--no-autoupdate", "run",
            "--token", CF_TUNNEL_TOKEN,
        ]),
        daemon=True,
    )
    tunnel_thread.start()
    print("Cloudflare tunnel started → vector.headyos.com")
else:
    print("No CF_TUNNEL_TOKEN — tunnel not started (use ngrok or direct access)")

print(f"""
═══════════════════════════════════════════════
  HEADY VECTOR OPS RUNTIME — ACTIVE
  API:    http://localhost:3301
  Health: http://localhost:3311/health
  Tunnel: vector.headyos.com (if configured)
  Models: {list(EmbeddingService.MODELS.keys())}
  Dim:    {embedding_service.dim}
  Cache:  {embedding_service.cache_size} entries
═══════════════════════════════════════════════
""")

# Keep notebook alive
import time
while True:
    time.sleep(fib(8))  # 21 second heartbeat
