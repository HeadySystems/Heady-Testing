/**
 * Heady MCP Gateway — Cloudflare Worker Entry Point
 *
 * Handles: routing, rate limiting, CSL-gated model selection,
 * edge embeddings via Workers AI, caching via KV, and proxying
 * to Cloud Run origin for complex tasks.
 *
 * Sacred Geometry v4.0 — Zero Magic Numbers
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

// ─── Phi Constants (Edge-Compatible) ────────────────────────────────────────

const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const FIB = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];

const CSL = {
  MINIMUM:  0.500,
  LOW:      0.691,
  MEDIUM:   0.809,
  HIGH:     0.882,
  CRITICAL: 0.927,
};

// ─── Rate Limiter (Token Bucket + Sliding Window) ───────────────────────────

async function checkRateLimit(request, env) {
  const ip = request.headers.get('cf-connecting-ip') || 'unknown';
  const key = `rl:${ip}:${Math.floor(Date.now() / 60000)}`; // per-minute window

  const current = parseInt(await env.HEADY_RATE_LIMIT.get(key) || '0', 10);
  const limit = parseInt(env.RATE_LIMIT_ANONYMOUS || '34', 10);

  if (current >= limit) {
    return new Response(JSON.stringify({
      error: { code: 'RATE_LIMITED', message: `Rate limit exceeded: ${limit}/min` }
    }), {
      status: 429,
      headers: {
        'Content-Type': 'application/json',
        'Retry-After': '60',
        'X-RateLimit-Limit': String(limit),
        'X-RateLimit-Remaining': '0',
      },
    });
  }

  await env.HEADY_RATE_LIMIT.put(key, String(current + 1), { expirationTtl: 120 });
  return null;
}

// ─── Security Headers ───────────────────────────────────────────────────────

function securityHeaders() {
  return {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline';",
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains',
  };
}

// ─── CORS ───────────────────────────────────────────────────────────────────

const ALLOWED_ORIGINS = [
  'https://headyme.com', 'https://www.headyme.com',
  'https://headysystems.com', 'https://www.headysystems.com',
  'https://headybuddy.org', 'https://www.headybuddy.org',
  'https://headymcp.com', 'https://www.headymcp.com',
  'https://headyio.com', 'https://www.headyio.com',
  'https://headybot.com', 'https://www.headybot.com',
  'https://headyapi.com', 'https://www.headyapi.com',
  'https://headyai.com', 'https://www.headyai.com',
  'https://headyconnection.org', 'https://www.headyconnection.org',
];

function corsHeaders(request) {
  const origin = request.headers.get('Origin') || '';
  const allowed = ALLOWED_ORIGINS.includes(origin) ? origin : '';
  return {
    'Access-Control-Allow-Origin': allowed,
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type, X-Request-ID',
    'Access-Control-Max-Age': '86400',
  };
}

// ─── Complexity Router (Edge vs Origin) ─────────────────────────────────────

function routeByComplexity(path, method) {
  // Edge-only (< PSI²): simple lookups, health, embeddings, cache hits
  const edgeOnlyPaths = ['/health', '/embed', '/classify', '/cache'];
  if (edgeOnlyPaths.some(p => path.startsWith(p))) return 'edge';

  // Origin-required (> PSI): complex reasoning, code gen, multi-step
  const originPaths = ['/generate', '/pipeline', '/agent', '/train'];
  if (originPaths.some(p => path.startsWith(p))) return 'origin';

  // Edge-preferred: moderate queries
  if (method === 'GET') return 'edge';
  return 'origin';
}

// ─── Main Fetch Handler ─────────────────────────────────────────────────────

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    // CORS preflight
    if (method === 'OPTIONS') {
      return new Response(null, {
        status: 204,
        headers: { ...corsHeaders(request), ...securityHeaders() },
      });
    }

    // Rate limiting
    const rateLimitResponse = await checkRateLimit(request, env);
    if (rateLimitResponse) return rateLimitResponse;

    // Health endpoint (always edge)
    if (path === '/health') {
      return new Response(JSON.stringify({
        status: 'healthy',
        service: 'heady-mcp-gateway',
        edge: true,
        timestamp: new Date().toISOString(),
        colo: request.cf?.colo || 'unknown',
      }), {
        headers: {
          'Content-Type': 'application/json',
          ...corsHeaders(request),
          ...securityHeaders(),
        },
      });
    }

    // Edge embedding via Workers AI
    if (path === '/embed' && method === 'POST') {
      try {
        const body = await request.json();
        const texts = body.texts || [];
        if (texts.length === 0) {
          return new Response(JSON.stringify({ error: 'texts required' }), { status: 400 });
        }

        const embeddings = await env.AI.run('@cf/baai/bge-base-en-v1.5', { text: texts });

        return new Response(JSON.stringify({
          embeddings: embeddings.data,
          model: 'bge-base-en-v1.5',
          dim: 768,
          edge: true,
        }), {
          headers: {
            'Content-Type': 'application/json',
            ...corsHeaders(request),
            ...securityHeaders(),
          },
        });
      } catch (err) {
        return new Response(JSON.stringify({
          error: { code: 'EMBEDDING_ERROR', message: err.message },
        }), { status: 500 });
      }
    }

    // Route decision
    const route = routeByComplexity(path, method);

    if (route === 'origin') {
      // Proxy to Cloud Run origin
      const originUrl = env.CLOUD_RUN_SERVICE_URL || 'https://heady-manager-us-east1.run.app';
      const proxyUrl = `${originUrl}${path}${url.search}`;

      const proxyRequest = new Request(proxyUrl, {
        method,
        headers: {
          ...Object.fromEntries(request.headers),
          'X-Forwarded-For': request.headers.get('cf-connecting-ip') || '',
          'X-Request-ID': crypto.randomUUID(),
        },
        body: method !== 'GET' ? request.body : undefined,
      });

      try {
        const originResponse = await fetch(proxyRequest);
        const response = new Response(originResponse.body, {
          status: originResponse.status,
          headers: {
            ...Object.fromEntries(originResponse.headers),
            ...corsHeaders(request),
            ...securityHeaders(),
            'X-Heady-Route': 'origin',
          },
        });
        return response;
      } catch (err) {
        return new Response(JSON.stringify({
          error: { code: 'ORIGIN_ERROR', message: 'Origin service unavailable' },
        }), {
          status: 502,
          headers: { 'Content-Type': 'application/json', ...securityHeaders() },
        });
      }
    }

    // Default: 404 for unknown edge paths
    return new Response(JSON.stringify({
      error: { code: 'NOT_FOUND', message: `Unknown path: ${path}` },
    }), {
      status: 404,
      headers: {
        'Content-Type': 'application/json',
        ...corsHeaders(request),
        ...securityHeaders(),
      },
    });
  },
};

// ─── Durable Object: HeadyAgentDO ──────────────────────────────────────────

export class HeadyAgentDO {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.storage = state.storage;
    this.sessions = new Map();
  }

  async fetch(request) {
    const url = new URL(request.url);

    if (url.pathname === '/ws') {
      if (request.headers.get('Upgrade') !== 'websocket') {
        return new Response('Expected WebSocket', { status: 400 });
      }
      const [client, server] = Object.values(new WebSocketPair());
      await this.handleSession(server);
      return new Response(null, { status: 101, webSocket: client });
    }

    if (url.pathname === '/state') {
      const agentState = await this.storage.get('agent_state') || { lifecycle: 'init' };
      return new Response(JSON.stringify(agentState), {
        headers: { 'Content-Type': 'application/json' },
      });
    }

    return new Response('Not Found', { status: 404 });
  }

  async handleSession(ws) {
    ws.accept();
    const sessionId = crypto.randomUUID();
    this.sessions.set(sessionId, ws);

    // Update agent lifecycle
    await this.storage.put('agent_state', {
      lifecycle: 'active',
      sessionId,
      connectedAt: Date.now(),
    });

    ws.addEventListener('message', async (event) => {
      try {
        const data = JSON.parse(event.data);
        // Echo with agent state context
        ws.send(JSON.stringify({
          type: 'response',
          sessionId,
          data,
          timestamp: Date.now(),
        }));
      } catch (err) {
        ws.send(JSON.stringify({ type: 'error', message: err.message }));
      }
    });

    ws.addEventListener('close', async () => {
      this.sessions.delete(sessionId);
      if (this.sessions.size === 0) {
        await this.storage.put('agent_state', {
          lifecycle: 'idle',
          lastSessionId: sessionId,
          idleSince: Date.now(),
        });
      }
    });
  }
}
