#!/usr/bin/env node
/**
 * Validate ESM — Heady MAXIMUM POTENTIAL Module Integrity Scanner
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Scans all .js files in shared/, nodes/, orchestration/, and bees/
 * directories for CommonJS contamination and ESM correctness.
 * Runs `node --check` on each file to verify syntax validity.
 *
 * Usage: node scripts/validate-esm.js
 *
 * @module validate-esm
 * @version 4.1.0
 */

import { execSync } from 'node:child_process';
import { readdirSync, readFileSync, statSync, existsSync } from 'node:fs';
import { join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = resolve(__filename, '..');
const ROOT = resolve(__dirname, '..');

// ═══════════════════════════════════════════════════════════════
// FIBONACCI-ALIGNED COLUMN WIDTHS
// ═══════════════════════════════════════════════════════════════

const COL_FILE   = 55;  // fib(10) = 55
const COL_SYNTAX = 8;   // fib(6) = 8
const COL_NOCJS  = 8;   // fib(6) = 8
const COL_EXPORT = 8;   // fib(6) = 8
const COL_RESULT = 8;   // fib(6) = 8

// ═══════════════════════════════════════════════════════════════
// FORMATTING
// ═══════════════════════════════════════════════════════════════

function pad(str, width) {
  const s = String(str);
  return s.length >= width ? s.slice(0, width) : s + ' '.repeat(width - s.length);
}

function topLine(widths) {
  return '┌' + widths.map(w => '─'.repeat(w + 2)).join('┬') + '┐';
}

function hrLine(widths) {
  return '├' + widths.map(w => '─'.repeat(w + 2)).join('┼') + '┤';
}

function bottomLine(widths) {
  return '└' + widths.map(w => '─'.repeat(w + 2)).join('┴') + '┘';
}

function row(cells, widths) {
  return '│ ' + cells.map((c, i) => pad(c, widths[i])).join(' │ ') + ' │';
}

// ═══════════════════════════════════════════════════════════════
// FILE DISCOVERY
// ═══════════════════════════════════════════════════════════════

const SCAN_DIRS = ['shared', 'nodes', 'orchestration', 'bees'];

function collectJsFiles() {
  const files = [];
  for (const dir of SCAN_DIRS) {
    const absDir = join(ROOT, dir);
    if (!existsSync(absDir)) continue;
    try {
      const entries = readdirSync(absDir);
      for (const entry of entries) {
        if (!entry.endsWith('.js')) continue;
        const absPath = join(absDir, entry);
        const stat = statSync(absPath);
        if (stat.isFile()) {
          files.push({ absPath, relPath: relative(ROOT, absPath) });
        }
      }
    } catch {
      // directory not readable, skip
    }
  }
  return files;
}

// ═══════════════════════════════════════════════════════════════
// VALIDATION CHECKS
// ═══════════════════════════════════════════════════════════════

/**
 * Run `node --check` to validate syntax.
 * @param {string} absPath
 * @returns {{ pass: boolean, error: string|null }}
 */
function checkSyntax(absPath) {
  try {
    execSync(`node --check "${absPath}"`, { stdio: 'pipe', timeout: 10000 });
    return { pass: true, error: null };
  } catch (err) {
    const stderr = err.stderr ? err.stderr.toString().trim() : err.message;
    return { pass: false, error: stderr };
  }
}

/**
 * Check for CommonJS contamination (require, module.exports).
 * Ignores occurrences inside comments and strings to reduce false positives.
 * @param {string} source
 * @returns {{ pass: boolean, violations: string[] }}
 */
function checkNoCJS(source) {
  const violations = [];
  const lines = source.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    // Skip single-line comments
    const trimmed = line.trimStart();
    if (trimmed.startsWith('//') || trimmed.startsWith('*') || trimmed.startsWith('/*')) continue;

    // Check for require() calls (not in string/comment context)
    if (/\brequire\s*\(/.test(line) && !/['"`].*require\s*\(.*['"`]/.test(line)) {
      violations.push(`L${i + 1}: require() call`);
    }

    // Check for module.exports
    if (/\bmodule\.exports\b/.test(line) && !/['"`].*module\.exports.*['"`]/.test(line)) {
      violations.push(`L${i + 1}: module.exports`);
    }
  }

  return { pass: violations.length === 0, violations };
}

/**
 * Check that the file has proper ESM export statements.
 * @param {string} source
 * @returns {{ pass: boolean, exportCount: number }}
 */
function checkExports(source) {
  // Match export declarations: export function, export class, export const,
  // export default, export { ... }
  const exportPattern = /^export\s/m;
  const matches = source.match(/^export\s/gm);
  const exportCount = matches ? matches.length : 0;
  return { pass: exportCount > 0, exportCount };
}

// ═══════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════

function main() {
  const files = collectJsFiles();

  if (files.length === 0) {
    console.log('No .js files found in scanned directories.');
    process.exit(0);
  }

  const widths = [COL_FILE, COL_SYNTAX, COL_NOCJS, COL_EXPORT, COL_RESULT];
  const headers = ['File', 'Syntax', 'No CJS', 'Exports', 'Result'];

  console.log('');
  console.log('  Heady MAXIMUM POTENTIAL — ESM Validation Report');
  console.log(`  ${new Date().toISOString()}`);
  console.log(`  Scanning ${SCAN_DIRS.join(', ')}...`);
  console.log('');

  console.log(topLine(widths));
  console.log(row(headers, widths));
  console.log(hrLine(widths));

  let totalPassed = 0;
  let totalFailed = 0;
  const failures = [];

  for (const file of files) {
    const source = readFileSync(file.absPath, 'utf-8');
    const syntax = checkSyntax(file.absPath);
    const noCJS = checkNoCJS(source);
    const exports = checkExports(source);

    const allPass = syntax.pass && noCJS.pass && exports.pass;
    if (allPass) {
      totalPassed++;
    } else {
      totalFailed++;
      const reasons = [];
      if (!syntax.pass) reasons.push(`syntax: ${syntax.error}`);
      if (!noCJS.pass) reasons.push(`cjs: ${noCJS.violations.join(', ')}`);
      if (!exports.pass) reasons.push('no exports found');
      failures.push({ file: file.relPath, reasons });
    }

    const cells = [
      file.relPath,
      syntax.pass ? 'PASS' : 'FAIL',
      noCJS.pass ? 'PASS' : 'FAIL',
      exports.pass ? 'PASS' : 'FAIL',
      allPass ? 'PASS' : 'FAIL',
    ];
    console.log(row(cells, widths));
  }

  console.log(bottomLine(widths));

  // Summary
  console.log('');
  console.log(`  Total: ${files.length}  |  Passed: ${totalPassed}  |  Failed: ${totalFailed}`);

  // Detail failures
  if (failures.length > 0) {
    console.log('');
    console.log('  Failures:');
    for (const f of failures) {
      console.log(`    ${f.file}:`);
      for (const reason of f.reasons) {
        console.log(`      - ${reason}`);
      }
    }
  }

  console.log('');
  process.exit(totalFailed > 0 ? 1 : 0);
}

main();
