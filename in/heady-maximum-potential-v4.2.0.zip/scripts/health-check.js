#!/usr/bin/env node
/**
 * Health Check CLI — Heady MAXIMUM POTENTIAL Node Health Inspector
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Instantiates every Heady node, calls health() on each, and prints a
 * formatted table to stdout. Exits 0 if all nodes are healthy, 1 if
 * any are degraded or expired.
 *
 * Usage: node scripts/health-check.js
 *
 * @module health-check
 * @version 4.1.0
 */

import { fib, PHI } from '../shared/phi-constants.js';
import { createLogger, NodeRegistry } from '../shared/liquid-node.js';

import { WisdomStoreNode } from '../nodes/wisdom-store.js';
import { BudgetTrackerNode } from '../nodes/budget-tracker.js';
import { HeadyLensNode } from '../nodes/heady-lens.js';
import { CouncilModeNode } from '../nodes/council-mode.js';
import { EvolutionEngineNode } from '../nodes/evolution-engine.js';
import { PersonaRouterNode } from '../nodes/persona-router.js';
import { AutoSuccessEngine } from '../nodes/auto-success-engine.js';
import { HeadySoulNode } from '../nodes/heady-soul.js';
import { HeadyBrainsNode } from '../nodes/heady-brains.js';
import { HeadyVinciNode } from '../nodes/heady-vinci.js';
import { HeadyConductor } from '../orchestration/conductor.js';

const logger = createLogger('HealthCheck');

// ═══════════════════════════════════════════════════════════════
// COLUMN WIDTHS — Fibonacci-aligned
// ═══════════════════════════════════════════════════════════════

const COL_NAME      = fib(8);   // 21
const COL_RING      = fib(7);   // 13
const COL_POOL      = fib(7);   // 13
const COL_STATE     = fib(7);   // 13
const COL_COHERENCE = fib(7);   // 13
const COL_STATUS    = fib(6);   //  8

// ═══════════════════════════════════════════════════════════════
// FORMATTING HELPERS
// ═══════════════════════════════════════════════════════════════

function pad(str, width) {
  const s = String(str);
  return s.length >= width ? s.slice(0, width) : s + ' '.repeat(width - s.length);
}

function center(str, width) {
  const s = String(str);
  if (s.length >= width) return s.slice(0, width);
  const left = Math.floor((width - s.length) / 2);
  const right = width - s.length - left;
  return ' '.repeat(left) + s + ' '.repeat(right);
}

function formatCoherence(score) {
  const pct = (score * 100).toFixed(1) + '%';
  return pct;
}

function hrLine(widths) {
  return '├' + widths.map(w => '─'.repeat(w + 2)).join('┼') + '┤';
}

function topLine(widths) {
  return '┌' + widths.map(w => '─'.repeat(w + 2)).join('┬') + '┐';
}

function bottomLine(widths) {
  return '└' + widths.map(w => '─'.repeat(w + 2)).join('┴') + '┘';
}

function row(cells, widths) {
  return '│ ' + cells.map((c, i) => pad(c, widths[i])).join(' │ ') + ' │';
}

// ═══════════════════════════════════════════════════════════════
// NODE INSTANTIATION
// ═══════════════════════════════════════════════════════════════

function createNodes() {
  const registry = new NodeRegistry();

  const nodes = [
    new HeadySoulNode(),
    new HeadyConductor({ nodeRegistry: registry }),
    new HeadyBrainsNode(),
    new HeadyVinciNode(),
    new WisdomStoreNode(),
    new BudgetTrackerNode(),
    new HeadyLensNode(),
    new CouncilModeNode(),
    new EvolutionEngineNode(),
    new PersonaRouterNode(),
    new AutoSuccessEngine({ nodeRegistry: registry }),
  ];

  for (const node of nodes) {
    registry.register(node);
  }

  return nodes;
}

// ═══════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════

function main() {
  const nodes = createNodes();
  const widths = [COL_NAME, COL_RING, COL_POOL, COL_STATE, COL_COHERENCE, COL_STATUS];
  const headers = ['Node Name', 'Ring', 'Pool', 'State', 'Coherence', 'Status'];

  const healthReports = nodes.map(node => {
    try {
      return node.health();
    } catch (err) {
      return {
        service: node.name,
        ring: node.ring || 'unknown',
        pool: node.pool || 'unknown',
        state: 'error',
        coherence: 0,
        status: 'down',
      };
    }
  });

  // Print header
  const title = '  Heady MAXIMUM POTENTIAL — Node Health Report';
  const timestamp = `  ${new Date().toISOString()}`;
  console.log('');
  console.log(title);
  console.log(timestamp);
  console.log('');

  // Print table
  console.log(topLine(widths));
  console.log(row(headers, widths));
  console.log(hrLine(widths));

  let hasUnhealthy = false;

  for (const h of healthReports) {
    const status = h.status === 'up' ? 'OK' : h.status === 'degraded' ? 'DEGRADED' : 'DOWN';
    if (status !== 'OK') hasUnhealthy = true;

    const cells = [
      h.service,
      h.ring || '-',
      h.pool || '-',
      h.state || '-',
      formatCoherence(h.coherence ?? 0),
      status,
    ];
    console.log(row(cells, widths));
  }

  console.log(bottomLine(widths));

  // Summary
  const total = healthReports.length;
  const healthy = healthReports.filter(h => h.status === 'up').length;
  const degraded = healthReports.filter(h => h.status === 'degraded').length;
  const down = healthReports.filter(h => h.status === 'down' || h.status === 'error').length;

  console.log('');
  console.log(`  Total: ${total}  |  Healthy: ${healthy}  |  Degraded: ${degraded}  |  Down: ${down}`);
  console.log('');

  logger.info({
    total,
    healthy,
    degraded,
    down,
    exitCode: hasUnhealthy ? 1 : 0,
  }, 'Health check complete');

  process.exit(hasUnhealthy ? 1 : 0);
}

main();
