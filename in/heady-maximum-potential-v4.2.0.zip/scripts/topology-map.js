#!/usr/bin/env node
/**
 * Topology Map — Heady MAXIMUM POTENTIAL Sacred Geometry Visualizer
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Prints the Sacred Geometry ring topology as ASCII art to the terminal,
 * showing node placement by ring, pool assignments, and domain summary.
 *
 * Usage: node scripts/topology-map.js
 *
 * @module topology-map
 * @version 4.1.0
 */

import { fib, PHI, POOL_ALLOCATION } from '../shared/phi-constants.js';
import { createLogger, NodeRegistry } from '../shared/liquid-node.js';

import { WisdomStoreNode } from '../nodes/wisdom-store.js';
import { BudgetTrackerNode } from '../nodes/budget-tracker.js';
import { HeadyLensNode } from '../nodes/heady-lens.js';
import { CouncilModeNode } from '../nodes/council-mode.js';
import { EvolutionEngineNode } from '../nodes/evolution-engine.js';
import { PersonaRouterNode } from '../nodes/persona-router.js';
import { AutoSuccessEngine } from '../nodes/auto-success-engine.js';
import { HeadySoulNode } from '../nodes/heady-soul.js';
import { HeadyBrainsNode } from '../nodes/heady-brains.js';
import { HeadyVinciNode } from '../nodes/heady-vinci.js';
import { HeadyConductor } from '../orchestration/conductor.js';

const logger = createLogger('TopologyMap');

// ═══════════════════════════════════════════════════════════════
// NODE INSTANTIATION & CLASSIFICATION
// ═══════════════════════════════════════════════════════════════

function createNodes() {
  const registry = new NodeRegistry();

  const nodes = [
    new HeadySoulNode(),
    new HeadyConductor({ nodeRegistry: registry }),
    new HeadyBrainsNode(),
    new HeadyVinciNode(),
    new WisdomStoreNode(),
    new BudgetTrackerNode(),
    new HeadyLensNode(),
    new CouncilModeNode(),
    new EvolutionEngineNode(),
    new PersonaRouterNode(),
    new AutoSuccessEngine({ nodeRegistry: registry }),
  ];

  for (const node of nodes) {
    registry.register(node);
  }

  return nodes;
}

function classifyByRing(nodes) {
  const rings = {
    center:     [],
    inner:      [],
    middle:     [],
    outer:      [],
    governance: [],
  };

  for (const node of nodes) {
    const ring = node.ring || 'outer';
    if (rings[ring]) {
      rings[ring].push(node.name);
    } else {
      rings.outer.push(node.name);
    }
  }

  return rings;
}

function classifyByPool(nodes) {
  const pools = {};
  for (const node of nodes) {
    const pool = node.pool || 'warm';
    if (!pools[pool]) pools[pool] = [];
    pools[pool].push(node.name);
  }
  return pools;
}

function classifyByDomain(nodes) {
  const domains = {};
  for (const node of nodes) {
    const domain = node.domain || 'headyme.com';
    if (!domains[domain]) domains[domain] = [];
    domains[domain].push({ name: node.name, pool: node.pool });
  }
  return domains;
}

// ═══════════════════════════════════════════════════════════════
// ASCII ART HELPERS
// ═══════════════════════════════════════════════════════════════

function padCenter(str, width) {
  const s = String(str);
  if (s.length >= width) return s.slice(0, width);
  const left = Math.floor((width - s.length) / 2);
  const right = width - s.length - left;
  return ' '.repeat(left) + s + ' '.repeat(right);
}

function padRight(str, width) {
  const s = String(str);
  return s.length >= width ? s.slice(0, width) : s + ' '.repeat(width - s.length);
}

function joinNames(names, maxWidth) {
  const result = [];
  let line = '';
  for (const name of names) {
    if (line.length > 0 && line.length + name.length + 2 > maxWidth) {
      result.push(line);
      line = name;
    } else {
      line = line ? `${line}, ${name}` : name;
    }
  }
  if (line) result.push(line);
  return result;
}

// ═══════════════════════════════════════════════════════════════
// TOPOLOGY RENDERING
// ═══════════════════════════════════════════════════════════════

function renderTopology(rings) {
  const W = fib(10);  // 55 inner width
  const lines = [];

  // Outer frame
  lines.push('╔' + '═'.repeat(W) + '╗');
  lines.push('║' + padCenter('SACRED GEOMETRY v4.0', W) + '║');
  lines.push('║' + padCenter('Heady Node Topology Map', W) + '║');
  lines.push('╠' + '═'.repeat(W) + '╣');
  lines.push('║' + ' '.repeat(W) + '║');

  // Governance shell
  const gW = W - 4;       // governance inner width
  const govNames = rings.governance.length > 0 ? rings.governance.join(', ') : '(none)';
  lines.push('║  ┌─── GOVERNANCE SHELL ' + '─'.repeat(gW - 23) + '┐  ║');
  const govLines = joinNames(rings.governance, gW - 4);
  for (const gl of govLines.length > 0 ? govLines : ['(none)']) {
    lines.push('║  │  ' + padRight(gl, gW - 4) + '  │  ║');
  }

  // Outer ring
  const oW = gW - 3;      // outer inner width
  lines.push('║  │  ┌─── OUTER RING ' + '─'.repeat(oW - 21) + '┐   │  ║');
  const outerLines = joinNames(rings.outer, oW - 4);
  for (const ol of outerLines.length > 0 ? outerLines : ['(none)']) {
    lines.push('║  │  │  ' + padRight(ol, oW - 4) + '  │   │  ║');
  }

  // Middle ring
  const mW = oW - 3;      // middle inner width
  lines.push('║  │  │  ┌─── MIDDLE RING ' + '─'.repeat(mW - 25) + '┐   │   │  ║');
  const middleLines = joinNames(rings.middle, mW - 4);
  for (const ml of middleLines.length > 0 ? middleLines : ['(none)']) {
    lines.push('║  │  │  │  ' + padRight(ml, mW - 4) + '  │   │   │  ║');
  }

  // Inner ring
  const iW = mW - 3;      // inner inner width
  lines.push('║  │  │  │  ┌── INNER RING ' + '─'.repeat(iW - 26) + '┐   │   │   │  ║');
  const innerLines = joinNames(rings.inner, iW - 4);
  for (const il of innerLines.length > 0 ? innerLines : ['(none)']) {
    lines.push('║  │  │  │  │  ' + padRight(il, iW - 4) + '  │   │   │   │  ║');
  }

  // Center (HeadySoul)
  const centerNames = rings.center.length > 0 ? rings.center.map(n => `● ${n} ●`).join('  ') : '● (empty) ●';
  lines.push('║  │  │  │  │ ' + padCenter(centerNames, iW - 2) + ' │   │   │   │  ║');

  // Close rings (inner → middle → outer → governance)
  lines.push('║  │  │  │  └' + '─'.repeat(iW - 1) + '┘   │   │   │  ║');
  lines.push('║  │  │  └' + '─'.repeat(mW - 1) + '┘   │   │  ║');
  lines.push('║  │  └' + '─'.repeat(oW - 1) + '┘   │  ║');
  lines.push('║  └' + '─'.repeat(gW - 1) + '┘  ║');

  lines.push('║' + ' '.repeat(W) + '║');
  lines.push('╚' + '═'.repeat(W) + '╝');

  return lines;
}

// ═══════════════════════════════════════════════════════════════
// SUMMARY TABLES
// ═══════════════════════════════════════════════════════════════

function renderRingSummary(rings) {
  const lines = [];
  lines.push('  Ring Summary:');
  const order = ['center', 'inner', 'middle', 'outer', 'governance'];
  for (const ring of order) {
    const count = (rings[ring] || []).length;
    lines.push(`    ${padRight(ring, fib(7))}  ${count} node${count !== 1 ? 's' : ''}`);
  }
  return lines;
}

function renderPoolSummary(pools) {
  const lines = [];
  lines.push('');
  lines.push('  Pool Summary:');
  const allocationKeys = Object.keys(POOL_ALLOCATION);
  for (const pool of Object.keys(pools).sort()) {
    const nodes = pools[pool];
    const allocation = POOL_ALLOCATION[pool];
    const pct = allocation ? `(${(allocation * 100).toFixed(0)}%)` : '';
    lines.push(`    ${padRight(pool, fib(7))}  ${nodes.length} node${nodes.length !== 1 ? 's' : ''}  ${pct}`);
  }
  return lines;
}

function renderDomainSummary(domains) {
  const lines = [];
  lines.push('');
  lines.push('  Domain Summary:');
  for (const [domain, nodes] of Object.entries(domains).sort()) {
    lines.push(`    ${padRight(domain, fib(8))}  ${nodes.length} node${nodes.length !== 1 ? 's' : ''}  [${[...new Set(nodes.map(n => n.pool))].join(', ')}]`);
  }
  return lines;
}

// ═══════════════════════════════════════════════════════════════
// MAIN
// ═══════════════════════════════════════════════════════════════

function main() {
  const nodes = createNodes();
  const rings = classifyByRing(nodes);
  const pools = classifyByPool(nodes);
  const domains = classifyByDomain(nodes);

  console.log('');
  console.log('  Heady MAXIMUM POTENTIAL — Sacred Geometry Topology');
  console.log(`  ${new Date().toISOString()}`);
  console.log(`  Total Nodes: ${nodes.length}`);
  console.log('');

  // Render topology ASCII
  const topologyLines = renderTopology(rings);
  for (const line of topologyLines) {
    console.log('  ' + line);
  }

  // Ring counts
  console.log('');
  const ringSummary = renderRingSummary(rings);
  for (const line of ringSummary) console.log(line);

  // Pool assignments
  const poolSummary = renderPoolSummary(pools);
  for (const line of poolSummary) console.log(line);

  // Domain listing
  const domainSummary = renderDomainSummary(domains);
  for (const line of domainSummary) console.log(line);

  console.log('');

  logger.info({
    totalNodes: nodes.length,
    rings: Object.fromEntries(Object.entries(rings).map(([k, v]) => [k, v.length])),
    pools: Object.fromEntries(Object.entries(pools).map(([k, v]) => [k, v.length])),
    domains: Object.keys(domains),
  }, 'Topology map rendered');
}

main();
