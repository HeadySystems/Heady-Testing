#!/usr/bin/env node
/**
 * Dev Server — Heady MAXIMUM POTENTIAL UI Development Server
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Minimal HTTP server using Node.js built-in modules. Serves static files
 * from the ui/ directory with proper MIME types and security headers.
 * Includes a /health JSON endpoint and graceful shutdown with LIFO cleanup.
 *
 * Usage: PORT=3000 node scripts/dev-server.js
 *
 * @module dev-server
 * @version 4.1.0
 */

import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { join, extname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

import { fib, PHI } from '../shared/phi-constants.js';
import { createLogger } from '../shared/liquid-node.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = resolve(__filename, '..');

// ═══════════════════════════════════════════════════════════════
// CONFIGURATION
// ═══════════════════════════════════════════════════════════════

const PORT = parseInt(process.env.PORT, 10) || 3000;
const UI_DIR = resolve(__dirname, '..', 'ui');
const SERVICE_NAME = 'heady-dev-server';
const logger = createLogger(SERVICE_NAME);
const startTime = Date.now();

// ═══════════════════════════════════════════════════════════════
// MIME TYPES
// ═══════════════════════════════════════════════════════════════

const MIME_TYPES = Object.freeze({
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript; charset=utf-8',
  '.css':  'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg':  'image/svg+xml',
  '.png':  'image/png',
  '.ico':  'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.map':  'application/json',
});

// ═══════════════════════════════════════════════════════════════
// SECURITY HEADERS
// ═══════════════════════════════════════════════════════════════

const SECURITY_HEADERS = Object.freeze({
  'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'",
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'X-XSS-Protection': '1; mode=block',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Cache-Control': 'no-store',
});

// ═══════════════════════════════════════════════════════════════
// CLEANUP STACK (LIFO)
// ═══════════════════════════════════════════════════════════════

const cleanupStack = [];

function pushCleanup(fn) {
  cleanupStack.push(fn);
}

async function runCleanup(signal) {
  logger.info({ signal }, 'Graceful shutdown initiated');
  while (cleanupStack.length > 0) {
    const cleanup = cleanupStack.pop();
    try {
      await cleanup();
    } catch (err) {
      logger.error({ error: err.message }, 'Cleanup step failed');
    }
  }
  logger.info({}, 'Shutdown complete');
  process.exit(0);
}

// ═══════════════════════════════════════════════════════════════
// REQUEST HANDLERS
// ═══════════════════════════════════════════════════════════════

/**
 * Apply security headers to a response.
 * @param {import('node:http').ServerResponse} res
 */
function applySecurityHeaders(res) {
  for (const [header, value] of Object.entries(SECURITY_HEADERS)) {
    res.setHeader(header, value);
  }
}

/**
 * Handle /health endpoint.
 * @param {import('node:http').ServerResponse} res
 */
function handleHealth(res) {
  const uptimeMs = Date.now() - startTime;
  const body = JSON.stringify({
    status: 'ok',
    service: SERVICE_NAME,
    uptime: uptimeMs,
    timestamp: new Date().toISOString(),
  });
  res.writeHead(200, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

/**
 * Serve a static file from the ui/ directory.
 * @param {string} urlPath - Requested URL path
 * @param {import('node:http').ServerResponse} res
 */
async function handleStaticFile(urlPath, res) {
  // Normalize and sanitize path — prevent directory traversal
  let safePath = urlPath.replace(/\.\./g, '').replace(/\/+/g, '/');
  if (safePath === '/' || safePath === '') safePath = '/index.html';

  const filePath = join(UI_DIR, safePath);

  // Verify the resolved path stays within UI_DIR
  const resolved = resolve(filePath);
  if (!resolved.startsWith(resolve(UI_DIR))) {
    sendError(res, 403, 'Forbidden');
    return;
  }

  try {
    const fileStat = await stat(resolved);
    if (fileStat.isDirectory()) {
      // Try index.html inside the directory
      const indexPath = join(resolved, 'index.html');
      const indexStat = await stat(indexPath);
      if (indexStat.isFile()) {
        await serveFile(indexPath, '.html', res);
        return;
      }
      sendError(res, 403, 'Directory listing not allowed');
      return;
    }

    const ext = extname(resolved).toLowerCase();
    await serveFile(resolved, ext, res);
  } catch (err) {
    if (err.code === 'ENOENT') {
      sendError(res, 404, 'Not Found');
    } else {
      logger.error({ error: err.message, path: safePath }, 'File serve error');
      sendError(res, 500, 'Internal Server Error');
    }
  }
}

/**
 * Read and serve a file with proper MIME type.
 * @param {string} filePath - Absolute file path
 * @param {string} ext - File extension
 * @param {import('node:http').ServerResponse} res
 */
async function serveFile(filePath, ext, res) {
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';
  const data = await readFile(filePath);
  res.writeHead(200, {
    'Content-Type': contentType,
    'Content-Length': data.length,
  });
  res.end(data);
}

/**
 * Send an error response.
 * @param {import('node:http').ServerResponse} res
 * @param {number} statusCode
 * @param {string} message
 */
function sendError(res, statusCode, message) {
  const body = JSON.stringify({ error: message, statusCode });
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

// ═══════════════════════════════════════════════════════════════
// SERVER
// ═══════════════════════════════════════════════════════════════

const server = createServer(async (req, res) => {
  const startMs = Date.now();

  applySecurityHeaders(res);

  const url = new URL(req.url, `http://localhost:${PORT}`);
  const pathname = url.pathname;

  try {
    if (pathname === '/health') {
      handleHealth(res);
    } else {
      await handleStaticFile(pathname, res);
    }
  } catch (err) {
    logger.error({ error: err.message, path: pathname }, 'Unhandled request error');
    if (!res.headersSent) {
      sendError(res, 500, 'Internal Server Error');
    }
  }

  const elapsed = Date.now() - startMs;
  logger.info({
    method: req.method,
    path: pathname,
    status: res.statusCode,
    elapsedMs: elapsed,
  }, 'Request handled');
});

// ═══════════════════════════════════════════════════════════════
// STARTUP & SHUTDOWN
// ═══════════════════════════════════════════════════════════════

pushCleanup(() => new Promise((resolve) => {
  server.close(() => {
    logger.info({}, 'HTTP server closed');
    resolve();
  });
  // Force close after fib(6) seconds = 8s
  setTimeout(resolve, fib(6) * 1000);
}));

process.on('SIGTERM', () => runCleanup('SIGTERM'));
process.on('SIGINT', () => runCleanup('SIGINT'));

server.listen(PORT, () => {
  logger.info({ port: PORT, uiDir: UI_DIR }, `Dev server listening on http://localhost:${PORT}`);
  console.log('');
  console.log(`  Heady MAXIMUM POTENTIAL — Dev Server`);
  console.log(`  Serving: ${UI_DIR}`);
  console.log(`  URL:     http://localhost:${PORT}`);
  console.log(`  Health:  http://localhost:${PORT}/health`);
  console.log('');
});
