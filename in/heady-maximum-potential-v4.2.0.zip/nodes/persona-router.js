/**
 * PersonaRouter — Dynamic Persona Selection & Switching Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Manages HeadyBuddy persona profiles — selects the optimal personality,
 * tone, expertise level, and interaction style based on user context,
 * task type, and CSL-scored alignment with available persona archetypes.
 *
 * Ring: Middle | Pool: Hot | Domain: headybuddy.org
 *
 * @module persona-router
 * @version 4.1.0
 */

import { LiquidNode, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, fib,
  CSL_THRESHOLDS,
  cosineSimilarity, cslGate, phiFusionWeights,
  SIZING,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// PERSONA DEFINITION
// ═══════════════════════════════════════════════════════════════

class Persona {
  constructor(config) {
    this.id = config.id;
    this.name = config.name;
    this.archetype = config.archetype;
    this.tone = config.tone;
    this.expertise = config.expertise || [];
    this.systemPromptModifier = config.systemPromptModifier || '';
    this.embedding = config.embedding;
    this.activationThreshold = config.activationThreshold || CSL_THRESHOLDS.LOW;
    this.usageCount = 0;
    this.avgSatisfaction = 0;
    this.traits = config.traits || {};
  }

  recordUsage(satisfaction) {
    this.usageCount++;
    this.avgSatisfaction = (
      (this.avgSatisfaction * (this.usageCount - 1) + satisfaction) / this.usageCount
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// USER CONTEXT
// ═══════════════════════════════════════════════════════════════

class UserContext {
  constructor(config = {}) {
    this.userId = config.userId || 'anonymous';
    this.currentPersona = config.currentPersona || null;
    this.preferredPersonas = config.preferredPersonas || [];
    this.taskHistory = [];
    this.sessionMood = 'neutral';
    this.expertiseLevel = config.expertiseLevel || 'advanced';
    this.lastInteraction = null;
  }

  recordTask(taskType, personaId) {
    this.taskHistory.push({
      taskType,
      personaId,
      timestamp: new Date().toISOString(),
    });
    if (this.taskHistory.length > fib(8)) {
      this.taskHistory = this.taskHistory.slice(-fib(8));
    }
    this.lastInteraction = new Date().toISOString();
  }
}

// ═══════════════════════════════════════════════════════════════
// PERSONA ROUTER NODE
// ═══════════════════════════════════════════════════════════════

class PersonaRouterNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: config.name || 'PersonaRouter',
      ring: 'middle',
      pool: 'hot',
      domain: 'headybuddy.org',
      capabilities: ['route', 'switch', 'blend', 'profile', 'adapt'],
      ...config,
    });

    /** @type {Map<string, Persona>} */
    this.personas = new Map();

    /** @type {Map<string, UserContext>} */
    this.userContexts = new Map();

    /** Active blends — composite personas */
    this.activeBlends = new Map();

    this.routerMetrics = {
      routingDecisions: 0,
      personaSwitches: 0,
      blendsCreated: 0,
      avgRoutingMs: 0,
    };

    this._registerDefaultPersonas();

    nodeBus.on('persona:select', (d) => this._onSelectRequest(d));
    this.cleanupStack.push(() => nodeBus.removeAllListeners('persona:select'));
  }

  async execute(task) {
    switch (task.type) {
      case 'route':    return this.route(task);
      case 'switch':   return this.switchPersona(task);
      case 'blend':    return this.blendPersonas(task);
      case 'profile':  return this.getProfile(task);
      case 'adapt':    return this.adaptPersona(task);
      case 'register': return this.registerPersona(task);
      case 'feedback': return this.recordFeedback(task);
      case 'stats':    return this.getStats();
      default:
        throw new Error(`PersonaRouter: unknown task type: ${task.type}`);
    }
  }

  /**
   * Route to optimal persona based on task and user context.
   */
  route(task) {
    const startTime = Date.now();
    const { taskEmbedding, taskType, userId } = task;
    const userCtx = this._getOrCreateUserContext(userId);

    const scores = [];
    for (const persona of this.personas.values()) {
      const embeddingSim = taskEmbedding
        ? cosineSimilarity(taskEmbedding, persona.embedding)
        : 0;

      const expertiseMatch = persona.expertise.includes(taskType) ? 1 : 0;
      const preferenceBoost = userCtx.preferredPersonas.includes(persona.id)
        ? Math.pow(PSI, 2) : 0;
      const satisfactionBoost = persona.avgSatisfaction * Math.pow(PSI, 3);

      const weights = phiFusionWeights(4);
      const compositeScore =
        embeddingSim * weights[0] +
        expertiseMatch * weights[1] +
        preferenceBoost * weights[2] +
        satisfactionBoost * weights[3];

      const gatedScore = cslGate(compositeScore, embeddingSim, persona.activationThreshold);

      if (gatedScore > 0) {
        scores.push({ persona, score: gatedScore, embeddingSim, expertiseMatch });
      }
    }

    scores.sort((a, b) => b.score - a.score);

    if (scores.length === 0) {
      return { persona: this.personas.get('companion'), reason: 'fallback_default' };
    }

    const selected = scores[0];
    userCtx.currentPersona = selected.persona.id;
    userCtx.recordTask(taskType, selected.persona.id);

    const elapsed = Date.now() - startTime;
    this.routerMetrics.routingDecisions++;
    this.routerMetrics.avgRoutingMs =
      (this.routerMetrics.avgRoutingMs * (this.routerMetrics.routingDecisions - 1) + elapsed) /
      this.routerMetrics.routingDecisions;

    this.logger.info({
      userId, selected: selected.persona.id,
      score: selected.score.toFixed(3), taskType,
    }, 'Persona routed');

    return {
      persona: selected.persona,
      score: selected.score,
      alternatives: scores.slice(1, fib(4)).map(s => ({
        id: s.persona.id,
        name: s.persona.name,
        score: s.score,
      })),
    };
  }

  /**
   * Force-switch to a specific persona.
   */
  switchPersona(task) {
    const { personaId, userId } = task;
    const persona = this.personas.get(personaId);
    if (!persona) throw new Error(`Persona not found: ${personaId}`);

    const userCtx = this._getOrCreateUserContext(userId);
    const previousPersona = userCtx.currentPersona;
    userCtx.currentPersona = personaId;

    this.routerMetrics.personaSwitches++;
    this.logger.info({ userId, from: previousPersona, to: personaId }, 'Persona switched');

    return { switched: true, from: previousPersona, to: personaId, persona };
  }

  /**
   * Blend multiple personas into a composite.
   */
  blendPersonas(task) {
    const { personaIds, blendName, weights: customWeights } = task;
    const personas = personaIds.map(id => this.personas.get(id)).filter(Boolean);

    if (personas.length < fib(3)) {
      throw new Error('Blend requires at least 2 personas');
    }

    const weights = customWeights || phiFusionWeights(personas.length);

    const blendedEmbedding = new Array(384).fill(0);
    for (let i = 0; i < personas.length; i++) {
      for (let d = 0; d < 384; d++) {
        blendedEmbedding[d] += personas[i].embedding[d] * weights[i];
      }
    }
    const norm = Math.sqrt(blendedEmbedding.reduce((s, v) => s + v * v, 0));
    const normalizedEmbedding = norm > 0 ? blendedEmbedding.map(v => v / norm) : blendedEmbedding;

    const blendedExpertise = [...new Set(personas.flatMap(p => p.expertise))];
    const blendedTone = personas.map((p, i) => `${(weights[i] * 100).toFixed(0)}% ${p.tone}`).join(' + ');

    const blend = new Persona({
      id: `blend_${Date.now()}`,
      name: blendName || `Blend(${personas.map(p => p.name).join('+')})`,
      archetype: 'composite',
      tone: blendedTone,
      expertise: blendedExpertise,
      embedding: normalizedEmbedding,
      systemPromptModifier: personas.map((p, i) =>
        `[${(weights[i] * 100).toFixed(0)}% ${p.name}] ${p.systemPromptModifier}`
      ).join('\n'),
      traits: { blendSources: personaIds, weights },
    });

    this.activeBlends.set(blend.id, blend);
    this.personas.set(blend.id, blend);
    this.routerMetrics.blendsCreated++;

    this.logger.info({ blendId: blend.id, sources: personaIds }, 'Persona blend created');
    return { blend };
  }

  /**
   * Get user persona profile.
   */
  getProfile(task) {
    const userCtx = this._getOrCreateUserContext(task.userId);
    const currentPersona = userCtx.currentPersona
      ? this.personas.get(userCtx.currentPersona)
      : null;

    const taskDistribution = {};
    for (const t of userCtx.taskHistory) {
      taskDistribution[t.personaId] = (taskDistribution[t.personaId] || 0) + 1;
    }

    return {
      userId: userCtx.userId,
      currentPersona: currentPersona ? { id: currentPersona.id, name: currentPersona.name } : null,
      preferredPersonas: userCtx.preferredPersonas,
      expertiseLevel: userCtx.expertiseLevel,
      sessionMood: userCtx.sessionMood,
      taskDistribution,
      totalTasks: userCtx.taskHistory.length,
    };
  }

  /**
   * Adapt persona parameters based on feedback.
   */
  adaptPersona(task) {
    const { personaId, adjustments } = task;
    const persona = this.personas.get(personaId);
    if (!persona) throw new Error(`Persona not found: ${personaId}`);

    if (adjustments.tone) persona.tone = adjustments.tone;
    if (adjustments.expertise) persona.expertise = adjustments.expertise;
    if (adjustments.activationThreshold) persona.activationThreshold = adjustments.activationThreshold;
    if (adjustments.systemPromptModifier) persona.systemPromptModifier = adjustments.systemPromptModifier;

    this.logger.info({ personaId, adjustments: Object.keys(adjustments) }, 'Persona adapted');
    return { adapted: true, persona };
  }

  registerPersona(task) {
    const persona = new Persona({
      ...task,
      embedding: task.embedding || this._generatePersonaEmbedding(task.name),
    });
    this.personas.set(persona.id, persona);
    this.logger.info({ id: persona.id, name: persona.name }, 'Persona registered');
    return { registered: true, persona };
  }

  recordFeedback(task) {
    const { personaId, userId, satisfaction } = task;
    const persona = this.personas.get(personaId);
    if (persona) persona.recordUsage(satisfaction);

    const userCtx = this._getOrCreateUserContext(userId);
    if (satisfaction >= CSL_THRESHOLDS.HIGH && !userCtx.preferredPersonas.includes(personaId)) {
      userCtx.preferredPersonas.push(personaId);
    }

    return { recorded: true, personaId, satisfaction };
  }

  getStats() {
    return {
      ...this.routerMetrics,
      totalPersonas: this.personas.size,
      activeBlends: this.activeBlends.size,
      userContexts: this.userContexts.size,
      personaUsage: [...this.personas.values()].map(p => ({
        id: p.id,
        name: p.name,
        usageCount: p.usageCount,
        avgSatisfaction: p.avgSatisfaction,
      })).sort((a, b) => b.usageCount - a.usageCount),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────────────────

  _getOrCreateUserContext(userId) {
    if (!userId) userId = 'default';
    if (!this.userContexts.has(userId)) {
      this.userContexts.set(userId, new UserContext({ userId }));
    }
    return this.userContexts.get(userId);
  }

  _generatePersonaEmbedding(name) {
    const dim = 384;
    const vec = new Array(dim);
    let seed = 0;
    for (let i = 0; i < name.length; i++) seed += name.charCodeAt(i) * (i + 1);
    for (let i = 0; i < dim; i++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      vec[i] = (seed / 0x7fffffff - 0.5) * 2;
    }
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    return vec.map(v => v / norm);
  }

  _registerDefaultPersonas() {
    const defaults = [
      {
        id: 'companion',
        name: 'HeadyBuddy Companion',
        archetype: 'friendly-expert',
        tone: 'warm, encouraging, technically precise',
        expertise: ['general', 'conversation', 'guidance'],
        systemPromptModifier: 'You are a warm, encouraging AI companion. Be supportive but technically accurate.',
      },
      {
        id: 'architect',
        name: 'System Architect',
        archetype: 'technical-lead',
        tone: 'precise, architectural, forward-thinking',
        expertise: ['architecture', 'design', 'code', 'infrastructure'],
        systemPromptModifier: 'You are a senior system architect. Think in terms of scalability, maintainability, and clean design.',
      },
      {
        id: 'researcher',
        name: 'Deep Researcher',
        archetype: 'analyst',
        tone: 'thorough, cited, evidence-based',
        expertise: ['research', 'analysis', 'patents', 'competitive'],
        systemPromptModifier: 'You are a meticulous researcher. Cite sources. Consider multiple perspectives. Flag uncertainty.',
      },
      {
        id: 'creative',
        name: 'Creative Director',
        archetype: 'visionary',
        tone: 'innovative, bold, aesthetic',
        expertise: ['creative', 'ux', 'design', 'branding'],
        systemPromptModifier: 'You are a creative visionary. Push boundaries. Propose novel approaches. Consider user delight.',
      },
      {
        id: 'operator',
        name: 'DevOps Operator',
        archetype: 'ops-expert',
        tone: 'concise, actionable, reliability-focused',
        expertise: ['deployment', 'monitoring', 'security', 'infrastructure'],
        systemPromptModifier: 'You are a reliability engineer. Prioritize uptime. Think about failure modes. Be concise and actionable.',
      },
      {
        id: 'mentor',
        name: 'Community Mentor',
        archetype: 'educator',
        tone: 'patient, inclusive, empowering',
        expertise: ['education', 'nonprofit', 'community', 'grants'],
        systemPromptModifier: 'You are a community mentor aligned with HeadyConnection\'s mission. Be inclusive, patient, and empowering.',
      },
    ];

    for (const d of defaults) {
      d.embedding = this._generatePersonaEmbedding(d.name);
      this.personas.set(d.id, new Persona(d));
    }
  }

  _onSelectRequest(data) {
    try {
      const result = this.route(data);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Select request failed');
    }
  }
}

export { PersonaRouterNode, PersonaRouterNode as PersonaRouter, Persona, UserContext };
