/**
 * AutoSuccessEngine — Heady MAXIMUM POTENTIAL Liquid Node
 * 
 * Automated success pipeline that chains Battle → Coder → Analyze → Risks → Patterns
 * into a single integrated workflow. Orchestrates the HCFullPipeline (HCFP) 8-stage
 * sequence with CSL-gated quality gates, phi-scaled timeouts, and self-healing retries.
 *
 * Sacred Geometry v4.0 — Zero Magic Numbers
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import {
  PHI, PSI, PHI2, PHI3, FIB,
  CSL_THRESHOLDS, DEDUP_THRESHOLD,
  PRESSURE_LEVELS, POOL_ALLOCATION,
  phiThreshold, phiBackoff, phiFusionWeights,
  cslGate, cslBlend, cslAND, cslOR, cslNOT, cslIMPLY, cslXOR,
  cslCONSENSUS, fibIndex, phiTokenBudgets
} from '../shared/phi-constants.js';

import { LiquidNode, CircuitBreaker, HeadyError, NodeRegistry } from '../shared/liquid-node.js';

// ─── HCFP Stage Definitions ─────────────────────────────────────────────────

const HCFP_STAGES = Object.freeze({
  CONTEXT_ASSEMBLY:     { id: 0, name: 'context-assembly',     node: 'HeadyBrains',         pool: 'hot',        timeoutMs: FIB[8] * 1000 },   // 21s
  INTENT_CLASSIFICATION:{ id: 1, name: 'intent-classification', node: 'HeadyConductor',       pool: 'hot',        timeoutMs: FIB[7] * 1000 },   // 13s
  NODE_SELECTION:       { id: 2, name: 'node-selection',        node: 'HeadyConductor',       pool: 'hot',        timeoutMs: FIB[7] * 1000 },   // 13s
  EXECUTION:            { id: 3, name: 'execution',             node: 'TargetNodes',          pool: 'hot',        timeoutMs: FIB[11] * 1000 },  // 89s
  QUALITY_GATE:         { id: 4, name: 'quality-gate',          node: 'HeadyCheck',           pool: 'governance', timeoutMs: FIB[8] * 1000 },   // 21s
  ASSURANCE_GATE:       { id: 5, name: 'assurance-gate',        node: 'HeadyAssure',          pool: 'governance', timeoutMs: FIB[8] * 1000 },   // 21s
  PATTERN_CAPTURE:      { id: 6, name: 'pattern-capture',       node: 'HeadyPatterns',        pool: 'cold',       timeoutMs: FIB[9] * 1000 },   // 34s
  STORY_UPDATE:         { id: 7, name: 'story-update',          node: 'HeadyAutobiographer',  pool: 'cold',       timeoutMs: FIB[9] * 1000 },   // 34s
});

const STAGE_COUNT = Object.keys(HCFP_STAGES).length; // 8

// ─── Arena Mode Config ──────────────────────────────────────────────────────

const ARENA_CONFIG = Object.freeze({
  maxContenders:        FIB[5],                     // 5 node configurations compete
  evaluationRounds:     FIB[4],                     // 3 rounds per contender
  winThreshold:         CSL_THRESHOLDS.HIGH,        // 0.882 — must strongly outperform
  tieBreakMetric:       'latencyMs',                // fastest wins if scores tied
  promotionCooldownMs:  FIB[9] * 1000 * PHI,        // ~55s cooldown before route update
});

// ─── Pipeline Run States ────────────────────────────────────────────────────

const RUN_STATES = Object.freeze({
  PENDING:    'PENDING',
  RUNNING:    'RUNNING',
  PAUSED:     'PAUSED',
  SUCCEEDED:  'SUCCEEDED',
  FAILED:     'FAILED',
  RETRYING:   'RETRYING',
  CANCELLED:  'CANCELLED',
});

// ─── AutoSuccessEngine ──────────────────────────────────────────────────────

export class AutoSuccessEngine extends LiquidNode {
  /**
   * @param {Object} config
   * @param {Object} config.nodeRegistry - NodeRegistry for resolving stage executors
   * @param {number} [config.maxConcurrentRuns] - fib(6)=8
   * @param {number} [config.maxRetries] - fib(4)=3
   * @param {number} [config.historyLimit] - fib(16)=987
   * @param {boolean} [config.arenaEnabled] - enable arena mode for competitive eval
   */
  constructor(config = {}) {
    super({
      name: 'AutoSuccessEngine',
      version: '4.1.0',
      pool: 'hot',
      ring: 'inner',
      ...config,
    });

    /** @type {NodeRegistry|null} */
    this.nodeRegistry = config.nodeRegistry || null;

    /** Max concurrent HCFP pipeline runs */
    this.maxConcurrentRuns = config.maxConcurrentRuns || FIB[6];  // 8

    /** Max retries per failed stage */
    this.maxRetries = config.maxRetries || FIB[4];  // 3

    /** Run history ring buffer limit */
    this.historyLimit = config.historyLimit || FIB[16]; // 987

    /** Arena mode toggle */
    this.arenaEnabled = config.arenaEnabled !== undefined ? config.arenaEnabled : false;

    // ─── Runtime State ────────────────────────────────────────────────

    /** @type {Map<string, PipelineRun>} Active pipeline runs keyed by runId */
    this._activeRuns = new Map();

    /** @type {Array<PipelineRunSummary>} Completed run history (ring buffer) */
    this._history = [];

    /** @type {Map<string, ArenaResult>} Arena evaluation results keyed by taskType */
    this._arenaResults = new Map();

    /** @type {Map<string, CircuitBreaker>} Per-stage circuit breakers */
    this._stageBreakers = new Map();

    /** Quality gate fusion weights: [accuracy, completeness, coherence] */
    this._qualityWeights = phiFusionWeights(3); // [0.528, 0.326, 0.146]

    /** Assurance gate fusion weights: [security, performance, compliance] */
    this._assuranceWeights = phiFusionWeights(3); // [0.528, 0.326, 0.146]

    /** Pipeline throughput metrics */
    this._metrics = {
      totalRuns:       0,
      successfulRuns:  0,
      failedRuns:      0,
      cancelledRuns:   0,
      totalStagesExecuted: 0,
      totalRetries:    0,
      avgDurationMs:   0,
      arenaEvals:      0,
    };

    // Initialize circuit breakers per stage
    for (const stage of Object.values(HCFP_STAGES)) {
      this._stageBreakers.set(stage.name, new CircuitBreaker({
        failureThreshold: FIB[5],       // 5 consecutive failures → OPEN
        resetTimeoutMs: FIB[8] * 1000,  // 21s base reset
        halfOpenProbes: FIB[3],         // 2 probe requests in HALF_OPEN
      }));
    }
  }

  // ─── Lifecycle ──────────────────────────────────────────────────────────────

  async spawn(context = {}) {
    this._log('info', 'Spawning AutoSuccessEngine', {
      maxConcurrentRuns: this.maxConcurrentRuns,
      maxRetries: this.maxRetries,
      arenaEnabled: this.arenaEnabled,
      stageCount: STAGE_COUNT,
    });

    if (this.nodeRegistry && typeof this.nodeRegistry.register === 'function') {
      this.nodeRegistry.register(this);
    }

    this._setState('ACTIVE');
    return { status: 'spawned', node: this.name, version: this.version };
  }

  async execute(task) {
    if (!task || !task.type) {
      throw new HeadyError('Task must include a type field', 400, 'INVALID_TASK');
    }

    // Arena mode: competitive evaluation before main pipeline
    if (this.arenaEnabled && task.arena) {
      return this._runArena(task);
    }

    return this._runPipeline(task);
  }

  async report() {
    return {
      node: this.name,
      state: this.state,
      version: this.version,
      activeRuns: this._activeRuns.size,
      maxConcurrentRuns: this.maxConcurrentRuns,
      metrics: { ...this._metrics },
      stageBreakers: this._getBreakersStatus(),
      arenaEnabled: this.arenaEnabled,
      arenaResults: this._arenaResults.size,
      historySize: this._history.length,
      coherenceScore: this._computeCoherenceScore(),
    };
  }

  async retire() {
    this._log('info', 'Retiring AutoSuccessEngine', { activeRuns: this._activeRuns.size });

    // Cancel active runs gracefully
    for (const [runId, run] of this._activeRuns) {
      run.state = RUN_STATES.CANCELLED;
      this._metrics.cancelledRuns++;
      this._log('warn', 'Cancelling active pipeline run during retirement', { runId });
    }
    this._activeRuns.clear();

    if (this.nodeRegistry && typeof this.nodeRegistry.unregister === 'function') {
      this.nodeRegistry.unregister(this.name);
    }

    this._setState('RETIRED');
    return { status: 'retired', metrics: { ...this._metrics } };
  }

  // ─── Pipeline Execution ─────────────────────────────────────────────────────

  /**
   * Execute the full HCFP 8-stage pipeline for a task.
   * @param {Object} task
   * @returns {Promise<PipelineResult>}
   */
  async _runPipeline(task) {
    if (this._activeRuns.size >= this.maxConcurrentRuns) {
      throw new HeadyError(
        `Max concurrent runs (${this.maxConcurrentRuns}) exceeded`,
        429,
        'PIPELINE_SATURATED',
        { activeRuns: this._activeRuns.size }
      );
    }

    const runId = this._generateRunId();
    const run = {
      id: runId,
      task,
      state: RUN_STATES.RUNNING,
      startedAt: Date.now(),
      completedAt: null,
      stages: [],
      result: null,
      retryCount: 0,
      context: {},       // accumulated context flowing through stages
    };

    this._activeRuns.set(runId, run);
    this._metrics.totalRuns++;

    try {
      // Stage 1: Context Assembly
      run.context = await this._executeStage(run, HCFP_STAGES.CONTEXT_ASSEMBLY, {
        task,
        sources: task.contextSources || [],
      });

      // Stage 2: Intent Classification
      const classification = await this._executeStage(run, HCFP_STAGES.INTENT_CLASSIFICATION, {
        task,
        context: run.context,
      });

      // Stage 3: Node Selection (CSL-scored capability routing)
      const selectedNodes = await this._executeStage(run, HCFP_STAGES.NODE_SELECTION, {
        taskType: classification.taskType || task.type,
        domain: classification.domain || 'general',
        context: run.context,
      });

      // Stage 4: Execution (parallel or sequential based on dependency graph)
      const executionResult = await this._executeStage(run, HCFP_STAGES.EXECUTION, {
        nodes: selectedNodes.nodes || [],
        task,
        context: run.context,
        classification,
      });

      // Stage 5: Quality Gate (HeadyCheck validation)
      const qualityResult = await this._executeStage(run, HCFP_STAGES.QUALITY_GATE, {
        output: executionResult,
        task,
        context: run.context,
      });

      // Check quality gate pass
      if (!this._passesQualityGate(qualityResult)) {
        // Retry execution up to maxRetries
        const retried = await this._retryExecution(run, task, classification, selectedNodes);
        if (!retried.passed) {
          run.state = RUN_STATES.FAILED;
          run.result = { error: 'Quality gate failed after retries', qualityResult: retried.lastQuality };
          this._finalizeRun(run);
          return { runId, state: run.state, result: run.result };
        }
        // Replace execution result with successful retry
        Object.assign(executionResult, retried.output);
      }

      // Stage 6: Assurance Gate (HeadyAssure deployment cert)
      const assuranceResult = await this._executeStage(run, HCFP_STAGES.ASSURANCE_GATE, {
        output: executionResult,
        quality: qualityResult,
        task,
      });

      if (!this._passesAssuranceGate(assuranceResult)) {
        run.state = RUN_STATES.FAILED;
        run.result = { error: 'Assurance gate failed', assuranceResult };
        this._finalizeRun(run);
        return { runId, state: run.state, result: run.result };
      }

      // Stage 7 & 8: Pattern Capture + Story Update (run concurrently — independent)
      const [patternResult, storyResult] = await Promise.allSettled([
        this._executeStage(run, HCFP_STAGES.PATTERN_CAPTURE, {
          run: { id: runId, task, classification, stages: run.stages },
          output: executionResult,
        }),
        this._executeStage(run, HCFP_STAGES.STORY_UPDATE, {
          run: { id: runId, task },
          output: executionResult,
          quality: qualityResult,
          assurance: assuranceResult,
        }),
      ]);

      // Pipeline succeeded
      run.state = RUN_STATES.SUCCEEDED;
      run.result = {
        output: executionResult,
        quality: qualityResult,
        assurance: assuranceResult,
        patterns: patternResult.status === 'fulfilled' ? patternResult.value : null,
        story: storyResult.status === 'fulfilled' ? storyResult.value : null,
      };

      this._metrics.successfulRuns++;
      this._finalizeRun(run);

      return { runId, state: run.state, result: run.result };

    } catch (err) {
      run.state = RUN_STATES.FAILED;
      run.result = { error: err.message, code: err.code || 'PIPELINE_ERROR' };
      this._metrics.failedRuns++;
      this._finalizeRun(run);
      this._log('error', 'Pipeline run failed', { runId, error: err.message });
      return { runId, state: run.state, result: run.result };
    }
  }

  // ─── Stage Execution ────────────────────────────────────────────────────────

  /**
   * Execute a single HCFP stage with circuit breaker, timeout, and telemetry.
   */
  async _executeStage(run, stageConfig, input) {
    const { name, node, pool, timeoutMs } = stageConfig;
    const breaker = this._stageBreakers.get(name);
    const stageRecord = {
      name,
      node,
      pool,
      startedAt: Date.now(),
      completedAt: null,
      durationMs: 0,
      status: 'running',
      retries: 0,
      output: null,
      error: null,
    };
    run.stages.push(stageRecord);
    this._metrics.totalStagesExecuted++;

    // Circuit breaker check
    if (breaker && !breaker.canExecute()) {
      stageRecord.status = 'circuit-open';
      stageRecord.completedAt = Date.now();
      stageRecord.durationMs = stageRecord.completedAt - stageRecord.startedAt;
      this._log('warn', 'Stage circuit breaker OPEN — degraded execution', { stage: name });

      // Return degraded result instead of blocking
      return this._degradedStageResult(stageConfig, input);
    }

    let lastError = null;
    const maxAttempts = this.maxRetries + 1;

    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      try {
        const result = await this._executeWithTimeout(
          () => this._resolveAndExecuteStage(stageConfig, input, run.context),
          timeoutMs
        );

        if (breaker) breaker.recordSuccess();

        stageRecord.output = result;
        stageRecord.status = 'succeeded';
        stageRecord.completedAt = Date.now();
        stageRecord.durationMs = stageRecord.completedAt - stageRecord.startedAt;
        stageRecord.retries = attempt;

        return result;

      } catch (err) {
        lastError = err;
        stageRecord.retries = attempt + 1;
        this._metrics.totalRetries++;

        if (attempt < maxAttempts - 1) {
          const delay = phiBackoff(attempt, FIB[6] * 100); // base 800ms
          this._log('warn', 'Stage execution failed, retrying', {
            stage: name, attempt: attempt + 1, delayMs: delay, error: err.message,
          });
          await this._sleep(delay);
        }
      }
    }

    // All attempts exhausted
    if (breaker) breaker.recordFailure();

    stageRecord.status = 'failed';
    stageRecord.error = lastError?.message || 'Unknown stage failure';
    stageRecord.completedAt = Date.now();
    stageRecord.durationMs = stageRecord.completedAt - stageRecord.startedAt;

    // For non-critical stages (pattern capture, story update), return degraded result
    if (stageConfig.pool === 'cold') {
      this._log('warn', 'Cold-pool stage failed — returning degraded result', { stage: name });
      return this._degradedStageResult(stageConfig, input);
    }

    throw new HeadyError(
      `Stage ${name} failed after ${maxAttempts} attempts: ${lastError?.message}`,
      503,
      'STAGE_FAILURE',
      { stage: name, attempts: maxAttempts, lastError: lastError?.message }
    );
  }

  /**
   * Resolve the target node from the registry and execute the stage.
   * If no registry is available, simulate the stage execution.
   */
  async _resolveAndExecuteStage(stageConfig, input, pipelineContext) {
    if (this.nodeRegistry) {
      const targetNode = this.nodeRegistry.getNode(stageConfig.node);
      if (targetNode && typeof targetNode.execute === 'function') {
        return targetNode.execute({
          stage: stageConfig.name,
          input,
          pipelineContext,
        });
      }
    }

    // Simulation mode: produce structured stage outputs
    return this._simulateStage(stageConfig, input);
  }

  /**
   * Simulate stage execution when real nodes are unavailable.
   * Each stage produces a structured result matching the HCFP contract.
   */
  _simulateStage(stageConfig, input) {
    const now = Date.now();
    switch (stageConfig.name) {
      case 'context-assembly':
        return {
          assembled: true,
          timestamp: now,
          sources: input.sources || [],
          tokenCount: Math.round(phiTokenBudgets().working * PSI),
          task: input.task,
        };

      case 'intent-classification':
        return {
          taskType: input.task?.type || 'unknown',
          domain: input.task?.domain || 'general',
          confidence: CSL_THRESHOLDS.HIGH,
          complexity: PSI,
          poolRecommendation: 'hot',
        };

      case 'node-selection':
        return {
          nodes: this._selectNodesForTaskType(input.taskType),
          routingScore: CSL_THRESHOLDS.HIGH,
          fallbackChain: [],
        };

      case 'execution':
        return {
          executed: true,
          timestamp: now,
          nodes: input.nodes || [],
          output: input.task?.payload || {},
          coherenceScore: CSL_THRESHOLDS.HIGH,
        };

      case 'quality-gate':
        return {
          passed: true,
          scores: {
            accuracy:     CSL_THRESHOLDS.HIGH,
            completeness: CSL_THRESHOLDS.HIGH,
            coherence:    CSL_THRESHOLDS.HIGH,
          },
          fusedScore: this._fuseQualityScores(
            CSL_THRESHOLDS.HIGH, CSL_THRESHOLDS.HIGH, CSL_THRESHOLDS.HIGH
          ),
          issues: [],
        };

      case 'assurance-gate':
        return {
          passed: true,
          scores: {
            security:    CSL_THRESHOLDS.HIGH,
            performance: CSL_THRESHOLDS.HIGH,
            compliance:  CSL_THRESHOLDS.HIGH,
          },
          fusedScore: this._fuseAssuranceScores(
            CSL_THRESHOLDS.HIGH, CSL_THRESHOLDS.HIGH, CSL_THRESHOLDS.HIGH
          ),
          certificationId: `cert-${now}-${Math.random().toString(36).slice(2, 8)}`,
        };

      case 'pattern-capture':
        return {
          captured: true,
          timestamp: now,
          patternId: `pat-${now}`,
          taskType: input.run?.task?.type,
          stagesCompleted: input.run?.stages?.length || 0,
        };

      case 'story-update':
        return {
          updated: true,
          timestamp: now,
          narrativeId: `nar-${now}`,
          summary: `Pipeline run ${input.run?.id} completed successfully`,
        };

      default:
        return { simulated: true, stage: stageConfig.name, timestamp: now };
    }
  }

  // ─── Node Selection (CSL-Scored) ──────────────────────────────────────────

  /**
   * Select optimal nodes for a task type using the conductor routing matrix.
   */
  _selectNodesForTaskType(taskType) {
    const ROUTING_MATRIX = {
      'code-generation': ['JULES', 'BUILDER'],
      'code-review':     ['OBSERVER'],
      'security-audit':  ['MURPHY', 'CIPHER'],
      'architecture':    ['ATLAS', 'PYTHIA', 'HeadyVinci'],
      'research':        ['HeadyResearch', 'SOPHIA'],
      'documentation':   ['ATLAS', 'HeadyCodex'],
      'creative':        ['MUSE', 'NOVA'],
      'cleanup':         ['JANITOR', 'HeadyMaid'],
      'analytics':       ['HeadyPatterns', 'HeadyMC'],
      'monitoring':      ['OBSERVER', 'LENS', 'SENTINEL'],
    };

    return ROUTING_MATRIX[taskType] || ['HeadyConductor'];
  }

  // ─── Quality & Assurance Gates ────────────────────────────────────────────

  /**
   * Fuse quality scores using phi-fusion weights [0.528, 0.326, 0.146].
   */
  _fuseQualityScores(accuracy, completeness, coherence) {
    const w = this._qualityWeights;
    return w[0] * accuracy + w[1] * completeness + w[2] * coherence;
  }

  /**
   * Fuse assurance scores using phi-fusion weights.
   */
  _fuseAssuranceScores(security, performance, compliance) {
    const w = this._assuranceWeights;
    return w[0] * security + w[1] * performance + w[2] * compliance;
  }

  /**
   * Check if quality gate result passes the CSL threshold.
   */
  _passesQualityGate(qualityResult) {
    if (!qualityResult) return false;
    if (qualityResult.passed === true) return true;
    const fusedScore = qualityResult.fusedScore || 0;
    return fusedScore >= CSL_THRESHOLDS.MEDIUM; // 0.809 coherence floor
  }

  /**
   * Check if assurance gate result passes the CSL threshold.
   */
  _passesAssuranceGate(assuranceResult) {
    if (!assuranceResult) return false;
    if (assuranceResult.passed === true) return true;
    const fusedScore = assuranceResult.fusedScore || 0;
    return fusedScore >= CSL_THRESHOLDS.MEDIUM; // 0.809 coherence floor
  }

  // ─── Retry Logic ──────────────────────────────────────────────────────────

  /**
   * Retry the execution stage when quality gate fails.
   * Re-runs stages 4 (execution) and 5 (quality gate) up to maxRetries times.
   */
  async _retryExecution(run, task, classification, selectedNodes) {
    let lastQuality = null;
    for (let retry = 0; retry < this.maxRetries; retry++) {
      run.retryCount++;
      run.state = RUN_STATES.RETRYING;

      this._log('info', 'Retrying execution after quality gate failure', {
        runId: run.id, retry: retry + 1, maxRetries: this.maxRetries,
      });

      const delay = phiBackoff(retry, FIB[7] * 100); // base 1300ms
      await this._sleep(delay);

      try {
        const retryOutput = await this._executeStage(run, HCFP_STAGES.EXECUTION, {
          nodes: selectedNodes.nodes || [],
          task,
          context: run.context,
          classification,
          retryAttempt: retry + 1,
        });

        const retryQuality = await this._executeStage(run, HCFP_STAGES.QUALITY_GATE, {
          output: retryOutput,
          task,
          context: run.context,
        });

        lastQuality = retryQuality;

        if (this._passesQualityGate(retryQuality)) {
          run.state = RUN_STATES.RUNNING;
          return { passed: true, output: retryOutput, quality: retryQuality };
        }
      } catch (err) {
        this._log('warn', 'Retry execution failed', { runId: run.id, retry, error: err.message });
        lastQuality = { passed: false, error: err.message };
      }
    }

    return { passed: false, lastQuality };
  }

  // ─── Arena Mode ─────────────────────────────────────────────────────────────

  /**
   * Run arena mode: pit multiple node configurations against each other
   * for the same task. The winner becomes the default routing.
   */
  async _runArena(task) {
    this._metrics.arenaEvals++;
    const contenders = task.arena.contenders || [];
    if (contenders.length === 0) {
      throw new HeadyError('Arena mode requires at least one contender', 400, 'ARENA_NO_CONTENDERS');
    }

    const maxContenders = Math.min(contenders.length, ARENA_CONFIG.maxContenders);
    const evalRounds = ARENA_CONFIG.evaluationRounds;

    const results = [];

    for (let i = 0; i < maxContenders; i++) {
      const contender = contenders[i];
      const roundScores = [];

      for (let round = 0; round < evalRounds; round++) {
        const startTime = Date.now();
        try {
          const result = await this._runPipeline({
            ...task,
            arena: null, // prevent infinite recursion
            nodeOverrides: contender.nodes,
          });

          const score = this._scoreArenaResult(result, Date.now() - startTime);
          roundScores.push(score);
        } catch (err) {
          roundScores.push({ overall: 0, error: err.message });
        }
      }

      // Average scores across rounds
      const avgScore = roundScores.reduce((sum, s) => sum + (s.overall || 0), 0) / evalRounds;
      const avgLatency = roundScores.reduce((sum, s) => sum + (s.latencyMs || 0), 0) / evalRounds;

      results.push({
        contender: contender.name || `contender-${i}`,
        nodes: contender.nodes,
        avgScore,
        avgLatency,
        rounds: roundScores,
      });
    }

    // Sort by score descending, then by latency ascending for ties
    results.sort((a, b) => {
      const scoreDiff = b.avgScore - a.avgScore;
      if (Math.abs(scoreDiff) < (1 - CSL_THRESHOLDS.CRITICAL)) { // within noise margin
        return a.avgLatency - b.avgLatency; // lower latency wins
      }
      return scoreDiff;
    });

    const winner = results[0];
    this._arenaResults.set(task.type, {
      winner: winner.contender,
      nodes: winner.nodes,
      avgScore: winner.avgScore,
      evaluatedAt: Date.now(),
      allResults: results,
    });

    this._log('info', 'Arena evaluation complete', {
      taskType: task.type,
      winner: winner.contender,
      score: winner.avgScore.toFixed(4),
    });

    return {
      type: 'arena-result',
      winner,
      results,
      promotionApplied: winner.avgScore >= ARENA_CONFIG.winThreshold,
    };
  }

  /**
   * Score an arena pipeline result based on quality, latency, and stage health.
   */
  _scoreArenaResult(pipelineResult, latencyMs) {
    if (!pipelineResult || pipelineResult.state !== RUN_STATES.SUCCEEDED) {
      return { overall: 0, latencyMs, error: 'pipeline failed' };
    }

    const result = pipelineResult.result || {};
    const qualityScore = result.quality?.fusedScore || 0;
    const assuranceScore = result.assurance?.fusedScore || 0;

    // Latency score: 1.0 at 0ms, decays by PSI per stage-timeout-unit
    const maxExpectedMs = FIB[11] * 1000; // 89s
    const latencyScore = Math.max(0, 1 - (latencyMs / maxExpectedMs));

    // Fuse: quality 0.528, assurance 0.326, latency 0.146
    const weights = phiFusionWeights(3);
    const overall = weights[0] * qualityScore + weights[1] * assuranceScore + weights[2] * latencyScore;

    return { overall, qualityScore, assuranceScore, latencyScore, latencyMs };
  }

  // ─── Degraded Mode ────────────────────────────────────────────────────────

  /**
   * Return a degraded but valid result when a stage is unreachable (circuit open, etc.)
   */
  _degradedStageResult(stageConfig, _input) {
    return {
      degraded: true,
      stage: stageConfig.name,
      timestamp: Date.now(),
      message: `Stage ${stageConfig.name} returned degraded result (circuit breaker or cold pool failure)`,
      passed: stageConfig.pool === 'cold', // cold stages degrade gracefully — non-blocking
      fusedScore: stageConfig.pool === 'cold' ? PSI : CSL_THRESHOLDS.MINIMUM,
    };
  }

  // ─── Helpers ──────────────────────────────────────────────────────────────

  _generateRunId() {
    const ts = Date.now().toString(36);
    const rand = Math.random().toString(36).slice(2, 8);
    return `hcfp-${ts}-${rand}`;
  }

  _finalizeRun(run) {
    run.completedAt = Date.now();
    const durationMs = run.completedAt - run.startedAt;

    // Update running average duration
    const total = this._metrics.successfulRuns + this._metrics.failedRuns;
    if (total > 0) {
      this._metrics.avgDurationMs = (
        this._metrics.avgDurationMs * (total - 1) + durationMs
      ) / total;
    }

    // Add to history ring buffer
    this._history.push({
      id: run.id,
      taskType: run.task?.type,
      state: run.state,
      durationMs,
      stageCount: run.stages.length,
      retryCount: run.retryCount,
      completedAt: run.completedAt,
    });

    // Trim history to limit
    if (this._history.length > this.historyLimit) {
      this._history = this._history.slice(-this.historyLimit);
    }

    // Remove from active
    this._activeRuns.delete(run.id);

    this._log('info', 'Pipeline run finalized', {
      runId: run.id, state: run.state, durationMs, stages: run.stages.length, retries: run.retryCount,
    });
  }

  _executeWithTimeout(fn, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new HeadyError(`Stage timed out after ${timeoutMs}ms`, 504, 'STAGE_TIMEOUT'));
      }, timeoutMs);

      Promise.resolve(fn())
        .then(result => { clearTimeout(timer); resolve(result); })
        .catch(err => { clearTimeout(timer); reject(err); });
    });
  }

  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  _getBreakersStatus() {
    const status = {};
    for (const [name, breaker] of this._stageBreakers) {
      status[name] = breaker.getStatus();
    }
    return status;
  }

  _computeCoherenceScore() {
    // Coherence based on success rate and active health
    const total = this._metrics.successfulRuns + this._metrics.failedRuns;
    if (total === 0) return 1.0;

    const successRate = this._metrics.successfulRuns / total;
    // CSL gate: if success rate above MEDIUM threshold, high coherence
    return cslGate(1.0, successRate, CSL_THRESHOLDS.LOW);
  }

  // ─── Queries ──────────────────────────────────────────────────────────────

  /**
   * Get pipeline run history with optional filtering.
   */
  getHistory(options = {}) {
    let results = [...this._history];

    if (options.state) {
      results = results.filter(r => r.state === options.state);
    }
    if (options.taskType) {
      results = results.filter(r => r.taskType === options.taskType);
    }
    if (options.limit) {
      results = results.slice(-options.limit);
    }

    return results;
  }

  /**
   * Get arena results for a given task type.
   */
  getArenaResult(taskType) {
    return this._arenaResults.get(taskType) || null;
  }

  /**
   * Get details of an active pipeline run.
   */
  getActiveRun(runId) {
    const run = this._activeRuns.get(runId);
    if (!run) return null;
    return {
      id: run.id,
      state: run.state,
      taskType: run.task?.type,
      startedAt: run.startedAt,
      stages: run.stages.map(s => ({
        name: s.name,
        status: s.status,
        durationMs: s.durationMs,
        retries: s.retries,
      })),
      retryCount: run.retryCount,
    };
  }

  /**
   * Get health check including coherence score.
   */
  healthCheck() {
    const coherence = this._computeCoherenceScore();
    const openBreakers = [...this._stageBreakers.values()].filter(b => {
      const s = b.getStatus();
      return s.state === 'OPEN';
    }).length;

    return {
      status: coherence >= CSL_THRESHOLDS.MEDIUM ? 'healthy' : (coherence >= CSL_THRESHOLDS.LOW ? 'degraded' : 'unhealthy'),
      coherenceScore: coherence,
      activeRuns: this._activeRuns.size,
      openCircuitBreakers: openBreakers,
      metrics: {
        totalRuns: this._metrics.totalRuns,
        successRate: this._metrics.totalRuns > 0
          ? (this._metrics.successfulRuns / this._metrics.totalRuns).toFixed(4)
          : '1.0000',
        avgDurationMs: Math.round(this._metrics.avgDurationMs),
      },
    };
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export { HCFP_STAGES, ARENA_CONFIG, RUN_STATES };
export default AutoSuccessEngine;
