/**
 * HeadySoul — The Awareness & Values Center of the Sacred Geometry Topology
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * HeadySoul sits at the center ring of the topology, serving as the
 * governance arbiter for all mutations, coherence audits, and mission
 * alignment checks. Every change in the Heady ecosystem must pass
 * through the 3 Unbreakable Laws before it can take effect.
 *
 * Ring: Center | Pool: Governance | Domain: headyme.com
 *
 * @module heady-soul
 * @version 4.1.0
 */

import { SoulNode, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD,
  cosineSimilarity, cslGate, phiFusionWeights, phiPriorityScore,
  SIZING,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// AUDIT LOG ENTRY
// ═══════════════════════════════════════════════════════════════

/**
 * Immutable record of a soul-level audit event.
 */
class AuditLogEntry {
  /**
   * @param {Object} config
   * @param {string} config.action - Audit action type
   * @param {string} config.target - Target node or mutation ID
   * @param {string} config.outcome - pass | fail | warning
   * @param {number} config.score - CSL-gated score (0-1)
   * @param {Object} [config.details] - Additional audit details
   */
  constructor(config) {
    this.id = `aud_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.action = config.action;
    this.target = config.target;
    this.outcome = config.outcome;
    this.score = config.score;
    this.details = config.details || {};
    this.timestamp = new Date().toISOString();
  }
}

// ═══════════════════════════════════════════════════════════════
// REFERENCE EMBEDDINGS FOR MISSION ALIGNMENT
// ═══════════════════════════════════════════════════════════════

const EMBEDDING_DIM = 384;

/**
 * Generate a deterministic reference embedding from a seed string.
 * Used for mission alignment and law validation baselines.
 * @param {string} seed - Seed string for deterministic generation
 * @returns {number[]} Normalized 384D vector
 */
function generateReferenceEmbedding(seed) {
  const vec = new Array(EMBEDDING_DIM);
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash += seed.charCodeAt(i);
  for (let i = 0; i < EMBEDDING_DIM; i++) {
    hash = (hash * 1103515245 + 12345) & 0x7fffffff;
    vec[i] = (hash / 0x7fffffff - PSI) * PHI;
  }
  const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
  return vec.map(v => v / norm);
}

const MISSION_EMBEDDING = generateReferenceEmbedding('HeadyConnection:community:equity:empowerment');
const STRUCTURAL_EMBEDDING = generateReferenceEmbedding('structural:integrity:compile:typecheck:module');
const SEMANTIC_EMBEDDING = generateReferenceEmbedding('semantic:coherence:design:embedding:tolerance');

// ═══════════════════════════════════════════════════════════════
// HEADY SOUL NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadySoulNode — The awareness and values center of the Sacred Geometry topology.
 *
 * Extends SoulNode to provide comprehensive governance capabilities including
 * mutation validation against the 3 Unbreakable Laws, coherence auditing
 * across the node topology, and mission alignment checking for proposals.
 *
 * All scoring uses CSL-gated cosine similarity — zero magic numbers.
 *
 * @extends SoulNode
 */
class HeadySoulNode extends SoulNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadySoul'] - Node name
   * @param {string} [config.domain='headyme.com'] - Domain identifier
   * @param {number[]} [config.embedding] - Initial 384D embedding
   */
  constructor(config = {}) {
    super({
      name: config.name || 'HeadySoul',
      domain: config.domain || 'headyme.com',
      ...(config.embedding ? { embedding: config.embedding } : {}),
    });

    this.capabilities = [
      'validation',
      'coherence-review',
      'mission-alignment',
      'ethics',
      'law-enforcement',
    ];

    /** @type {AuditLogEntry[]} Bounded audit log */
    this.auditLog = [];

    /** @type {number} Maximum audit log size — fib(14) = 377 */
    this.maxAuditEntries = SIZING.PATTERN_STORE;

    /** Reference embeddings for law validation */
    this.referenceEmbeddings = {
      structural: STRUCTURAL_EMBEDDING,
      semantic: SEMANTIC_EMBEDDING,
      mission: MISSION_EMBEDDING,
    };

    /** Validation statistics */
    this.validationStats = {
      totalValidations: 0,
      passed: 0,
      failed: 0,
      structuralViolations: 0,
      semanticViolations: 0,
      missionViolations: 0,
      coherenceAudits: 0,
      missionChecks: 0,
    };

    /** CSL gate thresholds for each law */
    this.lawThresholds = {
      structural: CSL_THRESHOLDS.HIGH,
      semantic: CSL_THRESHOLDS.MEDIUM,
      mission: CSL_THRESHOLDS.HIGH,
    };

    nodeBus.on('soul:validate', (data) => this._onValidateRequest(data));
    nodeBus.on('soul:audit', (data) => this._onAuditRequest(data));
    nodeBus.on('soul:mission-check', (data) => this._onMissionCheckRequest(data));
    this.cleanupStack.push(() => {
      nodeBus.removeAllListeners('soul:validate');
      nodeBus.removeAllListeners('soul:audit');
      nodeBus.removeAllListeners('soul:mission-check');
    });
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Execute a soul task by type.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - validate | coherenceReview | missionCheck | auditStats
   * @returns {Object} Task result
   */
  async execute(task) {
    switch (task.type) {
      case 'validate':        return this.validateMutation(task.mutation);
      case 'coherenceReview': return this.coherenceAudit(task.nodeHealthMap);
      case 'missionCheck':    return this.missionCheck(task.proposal);
      case 'auditStats':      return this.auditStats();
      default:
        throw new Error(`HeadySoul: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // MUTATION VALIDATION (3 Unbreakable Laws)
  // ─────────────────────────────────────────────────────────────

  /**
   * Validate a mutation against the 3 Unbreakable Laws using CSL-gated scoring.
   *
   * Law 1 — Structural Integrity: Code compiles, passes type checks, respects module boundaries.
   * Law 2 — Semantic Coherence: Changes stay within embedding tolerance of intended design.
   * Law 3 — Mission Alignment: Changes serve HeadyConnection mission (community, equity, empowerment).
   *
   * Each law is scored via cosine similarity against reference embeddings,
   * then gated through CSL to produce a binary pass/fail per law and
   * a composite governance score.
   *
   * @param {Object} mutation - Mutation descriptor
   * @param {string} mutation.id - Mutation identifier
   * @param {number[]} mutation.embedding - 384D embedding of the proposed mutation
   * @param {boolean} [mutation.structurallyValid] - External structural validation flag
   * @param {boolean} [mutation.semanticallyCoherent] - External semantic validation flag
   * @param {boolean} [mutation.missionAligned] - External mission alignment flag
   * @param {Object} [mutation.metadata] - Additional mutation metadata
   * @returns {Object} Validation result with per-law scores and composite outcome
   */
  validateMutation(mutation) {
    const mutationId = mutation.id || `mut-${Date.now()}`;
    const violations = [];
    const scores = {};

    // Law 1: Structural Integrity
    if (mutation.embedding) {
      const structuralSim = cosineSimilarity(mutation.embedding, this.referenceEmbeddings.structural);
      scores.structural = cslGate(1.0, structuralSim, this.lawThresholds.structural);
    } else {
      scores.structural = mutation.structurallyValid ? 1.0 : 0.0;
    }
    if (scores.structural < CSL_THRESHOLDS.MINIMUM) {
      violations.push(this.laws[0]);
      this.validationStats.structuralViolations++;
    }

    // Law 2: Semantic Coherence
    if (mutation.embedding) {
      const semanticSim = cosineSimilarity(mutation.embedding, this.referenceEmbeddings.semantic);
      scores.semantic = cslGate(1.0, semanticSim, this.lawThresholds.semantic);
    } else {
      scores.semantic = mutation.semanticallyCoherent ? 1.0 : 0.0;
    }
    if (scores.semantic < CSL_THRESHOLDS.MINIMUM) {
      violations.push(this.laws[1]);
      this.validationStats.semanticViolations++;
    }

    // Law 3: Mission Alignment
    if (mutation.embedding) {
      const missionSim = cosineSimilarity(mutation.embedding, this.referenceEmbeddings.mission);
      scores.mission = cslGate(1.0, missionSim, this.lawThresholds.mission);
    } else {
      scores.mission = mutation.missionAligned ? 1.0 : 0.0;
    }
    if (scores.mission < CSL_THRESHOLDS.MINIMUM) {
      violations.push(this.laws[2]);
      this.validationStats.missionViolations++;
    }

    // Composite score using phi-weighted fusion
    const weights = phiFusionWeights(3);
    const compositeScore =
      scores.structural * weights[0] +
      scores.semantic * weights[1] +
      scores.mission * weights[2];

    const valid = violations.length === 0;
    this.validationStats.totalValidations++;
    if (valid) {
      this.validationStats.passed++;
    } else {
      this.validationStats.failed++;
    }

    const result = {
      valid,
      mutationId,
      violations,
      scores,
      compositeScore,
      timestamp: new Date().toISOString(),
    };

    // Record in parent's validation history (bounded)
    this.validationHistory.push(result);
    if (this.validationHistory.length > SIZING.PATTERN_STORE) {
      this.validationHistory.shift();
    }

    // Record audit log entry
    this._appendAudit({
      action: 'validateMutation',
      target: mutationId,
      outcome: valid ? 'pass' : 'fail',
      score: compositeScore,
      details: { violations: violations.length, scores },
    });

    this.logger.info({
      mutationId,
      valid,
      compositeScore: compositeScore.toFixed(4),
      violations: violations.length,
    }, 'Mutation validated');

    nodeBus.emit('soul:validated', result);
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // COHERENCE AUDIT
  // ─────────────────────────────────────────────────────────────

  /**
   * Audit all node health data and identify coherence drift.
   *
   * Reviews each node's coherence score against the drift threshold,
   * classifies nodes into healthy, drifting, and critical buckets,
   * and computes a topology-wide coherence score using phi-weighted fusion.
   *
   * @param {Object} nodeHealthMap - Map of node name → health object
   * @param {string} nodeHealthMap[].service - Node service name
   * @param {number} nodeHealthMap[].coherence - Current coherence score
   * @param {string} nodeHealthMap[].state - Current lifecycle state
   * @returns {Object} Audit report with per-node assessments and topology score
   */
  coherenceAudit(nodeHealthMap) {
    const entries = Object.entries(nodeHealthMap || {});
    const healthy = [];
    const drifting = [];
    const critical = [];

    for (const [name, health] of entries) {
      const coherence = health.coherence ?? 1.0;
      const assessment = {
        node: name,
        coherence,
        state: health.state,
        status: 'healthy',
      };

      if (coherence < CSL_THRESHOLDS.MINIMUM) {
        assessment.status = 'critical';
        critical.push(assessment);
      } else if (coherence < COHERENCE_DRIFT_THRESHOLD) {
        assessment.status = 'drifting';
        drifting.push(assessment);
      } else {
        healthy.push(assessment);
      }
    }

    // Topology-wide coherence via phi-weighted average
    let topologyCoherence = 1.0;
    if (entries.length > 0) {
      const coherenceValues = entries.map(([, h]) => h.coherence ?? 1.0);
      const weights = phiFusionWeights(coherenceValues.length);
      // Sort by coherence descending so highest-coherence nodes get highest weight
      const sorted = coherenceValues.slice().sort((a, b) => b - a);
      topologyCoherence = sorted.reduce((sum, c, i) => sum + c * weights[i], 0);
    }

    const topologyHealthy = topologyCoherence >= COHERENCE_DRIFT_THRESHOLD;

    this.validationStats.coherenceAudits++;

    const report = {
      topologyCoherence,
      topologyHealthy,
      threshold: COHERENCE_DRIFT_THRESHOLD,
      totalNodes: entries.length,
      healthy: healthy.length,
      drifting: drifting.length,
      critical: critical.length,
      assessments: { healthy, drifting, critical },
      timestamp: new Date().toISOString(),
    };

    this._appendAudit({
      action: 'coherenceAudit',
      target: 'topology',
      outcome: topologyHealthy ? 'pass' : 'warning',
      score: topologyCoherence,
      details: {
        total: entries.length,
        healthy: healthy.length,
        drifting: drifting.length,
        critical: critical.length,
      },
    });

    this.logger.info({
      topologyCoherence: topologyCoherence.toFixed(4),
      healthy: healthy.length,
      drifting: drifting.length,
      critical: critical.length,
    }, 'Coherence audit complete');

    nodeBus.emit('soul:auditComplete', report);
    return report;
  }

  // ─────────────────────────────────────────────────────────────
  // MISSION CHECK
  // ─────────────────────────────────────────────────────────────

  /**
   * Evaluate if a proposed action aligns with HeadyConnection's nonprofit mission.
   *
   * Scores the proposal embedding against the mission reference embedding
   * using cosine similarity, then gates through CSL. Also evaluates
   * optional keyword indicators for community, equity, and empowerment focus.
   *
   * @param {Object} proposal - Proposal descriptor
   * @param {string} proposal.id - Proposal identifier
   * @param {string} proposal.description - Human-readable description
   * @param {number[]} [proposal.embedding] - 384D embedding of the proposal
   * @param {string[]} [proposal.keywords] - Keyword indicators
   * @param {Object} [proposal.metadata] - Additional proposal metadata
   * @returns {Object} Mission alignment result with score and recommendation
   */
  missionCheck(proposal) {
    const proposalId = proposal.id || `prop-${Date.now()}`;
    let missionScore = 0;

    // Primary: embedding-based cosine similarity
    if (proposal.embedding) {
      const similarity = cosineSimilarity(proposal.embedding, this.referenceEmbeddings.mission);
      missionScore = cslGate(1.0, similarity, CSL_THRESHOLDS.MEDIUM);
    }

    // Secondary: keyword indicator scoring
    const missionKeywords = ['community', 'equity', 'empowerment', 'nonprofit', 'connection', 'inclusion'];
    let keywordScore = 0;
    if (proposal.keywords && proposal.keywords.length > 0) {
      const matches = proposal.keywords.filter(k =>
        missionKeywords.some(mk => k.toLowerCase().includes(mk))
      );
      keywordScore = matches.length / missionKeywords.length;
    }

    // Fuse embedding and keyword scores with phi weights
    const fusionWeights = phiFusionWeights(2);
    const compositeScore = proposal.embedding
      ? missionScore * fusionWeights[0] + keywordScore * fusionWeights[1]
      : keywordScore;

    const aligned = compositeScore >= CSL_THRESHOLDS.MINIMUM;
    const recommendation = compositeScore >= CSL_THRESHOLDS.HIGH
      ? 'strongly-aligned'
      : compositeScore >= CSL_THRESHOLDS.MEDIUM
        ? 'aligned'
        : compositeScore >= CSL_THRESHOLDS.MINIMUM
          ? 'marginally-aligned'
          : 'misaligned';

    this.validationStats.missionChecks++;

    const result = {
      proposalId,
      aligned,
      missionScore,
      keywordScore,
      compositeScore,
      recommendation,
      timestamp: new Date().toISOString(),
    };

    this._appendAudit({
      action: 'missionCheck',
      target: proposalId,
      outcome: aligned ? 'pass' : 'fail',
      score: compositeScore,
      details: { recommendation, missionScore, keywordScore },
    });

    this.logger.info({
      proposalId,
      aligned,
      compositeScore: compositeScore.toFixed(4),
      recommendation,
    }, 'Mission check complete');

    nodeBus.emit('soul:missionChecked', result);
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // AUDIT LOG & STATS
  // ─────────────────────────────────────────────────────────────

  /**
   * Return current audit statistics.
   * @returns {Object} Validation stats and audit log summary
   */
  auditStats() {
    return {
      validationStats: { ...this.validationStats },
      auditLogSize: this.auditLog.length,
      maxAuditEntries: this.maxAuditEntries,
      recentAudits: this.auditLog.slice(-fib(5)).map(e => ({
        id: e.id,
        action: e.action,
        outcome: e.outcome,
        score: e.score,
        timestamp: e.timestamp,
      })),
    };
  }

  /**
   * Override health to include law validation stats.
   * @returns {Object} Health report with governance metrics
   */
  health() {
    const base = super.health();
    return {
      ...base,
      governance: {
        laws: this.laws,
        lawThresholds: { ...this.lawThresholds },
        validationStats: { ...this.validationStats },
        auditLogSize: this.auditLog.length,
        maxAuditEntries: this.maxAuditEntries,
      },
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  /**
   * Append an entry to the bounded audit log.
   * Evicts oldest entries when the log exceeds SIZING.PATTERN_STORE.
   * @param {Object} config - AuditLogEntry constructor config
   */
  _appendAudit(config) {
    const entry = new AuditLogEntry(config);
    this.auditLog.push(entry);
    while (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog.shift();
    }
  }

  /**
   * Handle incoming validation requests via nodeBus.
   * @param {Object} data - Validation request data
   */
  _onValidateRequest(data) {
    try {
      const result = this.validateMutation(data.mutation || data);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Validate request failed');
    }
  }

  /**
   * Handle incoming audit requests via nodeBus.
   * @param {Object} data - Audit request data
   */
  _onAuditRequest(data) {
    try {
      const result = this.coherenceAudit(data.nodeHealthMap || data);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Audit request failed');
    }
  }

  /**
   * Handle incoming mission check requests via nodeBus.
   * @param {Object} data - Mission check request data
   */
  _onMissionCheckRequest(data) {
    try {
      const result = this.missionCheck(data.proposal || data);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Mission check request failed');
    }
  }
}

export { HeadySoulNode, HeadySoulNode as HeadySoul };
