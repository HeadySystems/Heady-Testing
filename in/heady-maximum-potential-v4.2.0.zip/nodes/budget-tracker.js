/**
 * BudgetTracker — FinOps Cost Management Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Tracks and enforces spending across all LLM providers, cloud services,
 * and compute resources. Uses phi-scaled budget tiers and CSL-gated
 * cost routing to ensure optimal resource utilization.
 *
 * Ring: Inner | Pool: Governance | Domain: headysystems.com
 *
 * @module budget-tracker
 * @version 4.1.0
 */

import { LiquidNode, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, fib,
  CSL_THRESHOLDS, PRESSURE_LEVELS, ALERT_THRESHOLDS,
  phiFusionWeights, phiBackoff,
  SIZING,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// COST TRACKING
// ═══════════════════════════════════════════════════════════════

class CostEntry {
  constructor(config) {
    this.id = `cost_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.provider = config.provider;
    this.service = config.service;
    this.model = config.model || null;
    this.operation = config.operation;
    this.inputTokens = config.inputTokens || 0;
    this.outputTokens = config.outputTokens || 0;
    this.costUsd = config.costUsd;
    this.durationMs = config.durationMs || 0;
    this.nodeId = config.nodeId || null;
    this.taskId = config.taskId || null;
    this.timestamp = new Date().toISOString();
  }
}

// ═══════════════════════════════════════════════════════════════
// PROVIDER PRICING (per 1M tokens, USD)
// ═══════════════════════════════════════════════════════════════

const PROVIDER_PRICING = Object.freeze({
  'claude-sonnet':     { input: 3.00,   output: 15.00 },
  'claude-opus':       { input: 15.00,  output: 75.00 },
  'gpt-4o':            { input: 2.50,   output: 10.00 },
  'gpt-4o-mini':       { input: 0.15,   output: 0.60  },
  'gemini-pro':        { input: 1.25,   output: 5.00  },
  'gemini-flash':      { input: 0.075,  output: 0.30  },
  'groq-llama':        { input: 0.05,   output: 0.08  },
  'perplexity-sonar':  { input: 1.00,   output: 1.00  },
  'nomic-embed':       { input: 0.05,   output: 0     },
  'jina-embed':        { input: 0.018,  output: 0     },
  'cohere-embed':      { input: 0.10,   output: 0     },
  'voyage-embed':      { input: 0.12,   output: 0     },
  'cloudflare-ai':     { input: 0.011,  output: 0.011 },
  'local-ollama':      { input: 0,      output: 0     },
});

// ═══════════════════════════════════════════════════════════════
// BUDGET TRACKER NODE
// ═══════════════════════════════════════════════════════════════

class BudgetTrackerNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: config.name || 'BudgetTracker',
      ring: 'inner',
      pool: 'governance',
      domain: 'headysystems.com',
      capabilities: ['track', 'enforce', 'report', 'forecast', 'optimize'],
      ...config,
    });

    /** @type {CostEntry[]} Rolling window of cost entries */
    this.entries = [];

    /** Budget caps — phi-scaled tiers (USD) */
    this.budgets = config.budgets || {
      hourly:  fib(5),             // $5/hour
      daily:   fib(8),             // $21/day
      weekly:  fib(11),            // $89/week
      monthly: fib(14),            // $377/month
    };

    /** Per-provider daily caps (phi-derived fractions of daily budget) */
    this.providerCaps = {};
    const providerCount = Object.keys(PROVIDER_PRICING).length;
    const weights = phiFusionWeights(Math.min(providerCount, fib(5)));
    let idx = 0;
    for (const provider of Object.keys(PROVIDER_PRICING)) {
      this.providerCaps[provider] = this.budgets.daily * (weights[Math.min(idx, weights.length - 1)] || weights[weights.length - 1]);
      idx++;
    }

    /** Spending accumulators */
    this.spending = {
      hourly: 0,
      daily: 0,
      weekly: 0,
      monthly: 0,
      allTime: 0,
    };

    /** Per-provider spending */
    this.providerSpending = {};

    this.maxEntries = SIZING.LARGE_CACHE;
    this.alertsSent = new Set();

    /** Rolling window timestamps */
    this.windowStarts = {
      hourly:  Date.now(),
      daily:   Date.now(),
      weekly:  Date.now(),
      monthly: Date.now(),
    };

    nodeBus.on('budget:track', (data) => this._onTrackRequest(data));
    nodeBus.on('budget:check', (data) => this._onCheckRequest(data));
    this.cleanupStack.push(() => {
      nodeBus.removeAllListeners('budget:track');
      nodeBus.removeAllListeners('budget:check');
    });
  }

  async execute(task) {
    switch (task.type) {
      case 'track':       return this.track(task);
      case 'check':       return this.checkBudget(task);
      case 'report':      return this.report(task);
      case 'forecast':    return this.forecast(task);
      case 'optimize':    return this.optimizeCosts(task);
      case 'reset':       return this.resetWindow(task.window);
      default:
        throw new Error(`BudgetTracker: unknown task type: ${task.type}`);
    }
  }

  /**
   * Track a cost event.
   */
  track(task) {
    const entry = new CostEntry(task);

    if (!entry.costUsd && entry.model && PROVIDER_PRICING[entry.model]) {
      const pricing = PROVIDER_PRICING[entry.model];
      entry.costUsd = (
        (entry.inputTokens / 1_000_000) * pricing.input +
        (entry.outputTokens / 1_000_000) * pricing.output
      );
    }

    this.entries.push(entry);
    if (this.entries.length > this.maxEntries) {
      this.entries = this.entries.slice(-Math.round(this.maxEntries * PSI));
    }

    this._rollWindows();

    this.spending.hourly += entry.costUsd;
    this.spending.daily += entry.costUsd;
    this.spending.weekly += entry.costUsd;
    this.spending.monthly += entry.costUsd;
    this.spending.allTime += entry.costUsd;

    if (!this.providerSpending[entry.provider]) {
      this.providerSpending[entry.provider] = { daily: 0, total: 0, requests: 0 };
    }
    this.providerSpending[entry.provider].daily += entry.costUsd;
    this.providerSpending[entry.provider].total += entry.costUsd;
    this.providerSpending[entry.provider].requests++;

    this._checkAlerts();

    this.logger.info({
      provider: entry.provider,
      model: entry.model,
      cost: entry.costUsd.toFixed(6),
      dailyTotal: this.spending.daily.toFixed(4),
    }, 'Cost tracked');

    return { tracked: true, entry, budgetStatus: this._budgetStatus() };
  }

  /**
   * Check if a proposed operation fits within budget.
   */
  checkBudget(task) {
    const { model, estimatedInputTokens, estimatedOutputTokens } = task;
    const pricing = PROVIDER_PRICING[model];

    if (!pricing) {
      return { allowed: true, reason: 'unknown_model_no_cap', estimatedCost: 0 };
    }

    const estimatedCost = (
      (estimatedInputTokens / 1_000_000) * pricing.input +
      (estimatedOutputTokens / 1_000_000) * pricing.output
    );

    this._rollWindows();
    const status = this._budgetStatus();

    if (status.hourly.utilization >= ALERT_THRESHOLDS.exceeded) {
      return { allowed: false, reason: 'hourly_budget_exceeded', estimatedCost, status };
    }
    if (status.daily.utilization >= ALERT_THRESHOLDS.exceeded) {
      return { allowed: false, reason: 'daily_budget_exceeded', estimatedCost, status };
    }

    const costTier = this._costTier(model);
    return {
      allowed: true,
      estimatedCost,
      costTier,
      status,
      recommendation: costTier === 'premium' && status.daily.utilization > PSI
        ? `Consider downgrading to a cheaper model. Daily budget at ${(status.daily.utilization * 100).toFixed(1)}%`
        : null,
    };
  }

  /**
   * Generate spending report.
   */
  report(task = {}) {
    const period = task.period || 'daily';
    this._rollWindows();

    const byProvider = {};
    for (const [provider, data] of Object.entries(this.providerSpending)) {
      byProvider[provider] = {
        spending: data.daily,
        requests: data.requests,
        avgCostPerRequest: data.requests > 0 ? data.daily / data.requests : 0,
      };
    }

    const byModel = {};
    const cutoff = this._windowCutoff(period);
    for (const entry of this.entries) {
      if (new Date(entry.timestamp).getTime() < cutoff) continue;
      if (!byModel[entry.model || 'unknown']) {
        byModel[entry.model || 'unknown'] = { cost: 0, requests: 0, tokens: 0 };
      }
      byModel[entry.model || 'unknown'].cost += entry.costUsd;
      byModel[entry.model || 'unknown'].requests++;
      byModel[entry.model || 'unknown'].tokens += entry.inputTokens + entry.outputTokens;
    }

    return {
      period,
      spending: { ...this.spending },
      budgets: { ...this.budgets },
      status: this._budgetStatus(),
      byProvider,
      byModel,
      entriesInWindow: this.entries.filter(e => new Date(e.timestamp).getTime() >= cutoff).length,
    };
  }

  /**
   * Forecast spending based on current velocity.
   */
  forecast(task = {}) {
    this._rollWindows();
    const hourlyRate = this.spending.hourly;
    const dailyRate = this.spending.daily;

    return {
      projectedDaily: hourlyRate * 24,
      projectedWeekly: dailyRate * 7,
      projectedMonthly: dailyRate * 30,
      currentVelocity: {
        perHour: hourlyRate,
        perDay: dailyRate,
      },
      budgetExhaustion: {
        daily: dailyRate > 0 ? ((this.budgets.daily - this.spending.daily) / hourlyRate).toFixed(1) + ' hours' : 'never',
        monthly: dailyRate > 0 ? ((this.budgets.monthly - this.spending.monthly) / dailyRate).toFixed(1) + ' days' : 'never',
      },
      recommendation: hourlyRate * 24 > this.budgets.daily * PHI
        ? 'Spending velocity exceeds daily budget by φ. Recommend shifting to cheaper models.'
        : 'Spending within normal range.',
    };
  }

  /**
   * Suggest cost optimizations.
   */
  optimizeCosts(task = {}) {
    const report = this.report({ period: 'daily' });
    const suggestions = [];

    for (const [model, data] of Object.entries(report.byModel)) {
      const pricing = PROVIDER_PRICING[model];
      if (!pricing) continue;

      if (this._costTier(model) === 'premium' && data.requests > fib(6)) {
        suggestions.push({
          type: 'downgrade',
          model,
          reason: `${data.requests} requests to premium model ${model}`,
          potentialSavings: data.cost * PSI,
          alternative: this._cheaperAlternative(model),
        });
      }
    }

    if (report.status.daily.utilization > ALERT_THRESHOLDS.caution) {
      suggestions.push({
        type: 'cache',
        reason: 'High daily utilization — enable semantic deduplication cache',
        potentialSavings: this.spending.daily * Math.pow(PSI, 2),
      });
    }

    return { suggestions, currentDailySpend: this.spending.daily };
  }

  resetWindow(window) {
    if (window && this.spending[window] !== undefined) {
      this.spending[window] = 0;
      this.windowStarts[window] = Date.now();
      return { reset: window };
    }
    return { error: `Unknown window: ${window}` };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  _budgetStatus() {
    return {
      hourly:  { spent: this.spending.hourly,  budget: this.budgets.hourly,  utilization: this.spending.hourly / this.budgets.hourly },
      daily:   { spent: this.spending.daily,   budget: this.budgets.daily,   utilization: this.spending.daily / this.budgets.daily },
      weekly:  { spent: this.spending.weekly,  budget: this.budgets.weekly,  utilization: this.spending.weekly / this.budgets.weekly },
      monthly: { spent: this.spending.monthly, budget: this.budgets.monthly, utilization: this.spending.monthly / this.budgets.monthly },
    };
  }

  _rollWindows() {
    const now = Date.now();
    if (now - this.windowStarts.hourly > 3600000) {
      this.spending.hourly = 0;
      this.windowStarts.hourly = now;
    }
    if (now - this.windowStarts.daily > 86400000) {
      this.spending.daily = 0;
      this.windowStarts.daily = now;
      for (const p of Object.values(this.providerSpending)) p.daily = 0;
    }
    if (now - this.windowStarts.weekly > 604800000) {
      this.spending.weekly = 0;
      this.windowStarts.weekly = now;
    }
    if (now - this.windowStarts.monthly > 2592000000) {
      this.spending.monthly = 0;
      this.windowStarts.monthly = now;
    }
  }

  _windowCutoff(period) {
    const map = { hourly: 3600000, daily: 86400000, weekly: 604800000, monthly: 2592000000 };
    return Date.now() - (map[period] || map.daily);
  }

  _checkAlerts() {
    const status = this._budgetStatus();
    for (const [window, data] of Object.entries(status)) {
      for (const [level, threshold] of Object.entries(ALERT_THRESHOLDS)) {
        if (level === 'hard_max') continue;
        const alertKey = `${window}:${level}`;
        if (data.utilization >= threshold && !this.alertsSent.has(alertKey)) {
          this.alertsSent.add(alertKey);
          this.logger.warn({
            window, level, utilization: data.utilization.toFixed(3), threshold,
          }, `Budget alert: ${window} ${level}`);
          nodeBus.emit('budget:alert', { window, level, utilization: data.utilization, spent: data.spent, budget: data.budget });
        }
      }
    }
  }

  _costTier(model) {
    const pricing = PROVIDER_PRICING[model];
    if (!pricing) return 'unknown';
    const avgCost = (pricing.input + pricing.output) / 2;
    if (avgCost > 10) return 'premium';
    if (avgCost > 1) return 'standard';
    if (avgCost > 0.1) return 'economy';
    return 'minimal';
  }

  _cheaperAlternative(model) {
    const alternatives = {
      'claude-opus': 'claude-sonnet',
      'claude-sonnet': 'gemini-pro',
      'gpt-4o': 'gpt-4o-mini',
      'gemini-pro': 'gemini-flash',
      'perplexity-sonar': 'groq-llama',
    };
    return alternatives[model] || 'groq-llama';
  }

  _onTrackRequest(data) {
    try { this.track(data); } catch (err) {
      this.logger.error({ error: err.message }, 'Track request failed');
    }
  }

  _onCheckRequest(data) {
    try {
      const result = this.checkBudget(data);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Check request failed');
    }
  }
}

export { BudgetTrackerNode, BudgetTrackerNode as BudgetTracker, CostEntry, PROVIDER_PRICING };
