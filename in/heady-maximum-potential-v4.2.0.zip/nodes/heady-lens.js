/**
 * HeadyLens — System Observation & Deep Inspection Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Provides deep observability into the entire Heady ecosystem.
 * Monitors node health, resource utilization, request flows,
 * embedding drift, and swarm coordination in real-time.
 * Generates snapshots, dashboards, and anomaly alerts.
 *
 * Ring: Outer | Pool: Warm | Domain: headyme.com
 *
 * @module heady-lens
 * @version 4.1.0
 */

import { LiquidNode, NodeRegistry, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD, ALERT_THRESHOLDS,
  cosineSimilarity, phiFusionWeights, phiAdaptiveInterval,
  SIZING, PRESSURE_LEVELS,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// OBSERVATION RECORD
// ═══════════════════════════════════════════════════════════════

class Observation {
  constructor(config) {
    this.id = `obs_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.type = config.type;
    this.source = config.source;
    this.data = config.data;
    this.severity = config.severity || 'info';
    this.timestamp = new Date().toISOString();
    this.correlationId = config.correlationId || null;
  }
}

// ═══════════════════════════════════════════════════════════════
// HEADY LENS NODE
// ═══════════════════════════════════════════════════════════════

class HeadyLensNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: config.name || 'HeadyLens',
      ring: 'outer',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: ['observe', 'inspect', 'snapshot', 'anomaly', 'dashboard', 'trace'],
      ...config,
    });

    /** @type {NodeRegistry} Reference to the global registry */
    this.registry = config.registry || null;

    /** @type {Observation[]} Rolling observation log */
    this.observations = [];
    this.maxObservations = SIZING.LARGE_CACHE;

    /** Anomaly detection state */
    this.baselineMetrics = new Map();
    this.anomalyCount = 0;
    this.anomalyWindow = [];
    this.anomalyWindowMs = fib(11) * 60000;

    /** Flow tracing */
    this.activeTraces = new Map();
    this.completedTraces = [];
    this.maxTraces = SIZING.CACHE_SIZE;

    /** Snapshot history */
    this.snapshots = [];
    this.maxSnapshots = fib(8);

    /** Sampling interval — adaptive via phi */
    this.sampleIntervalMs = Math.round(PHI * 1000 * fib(3));
    this.sampleTimer = null;

    this.lensMetrics = {
      observationsRecorded: 0,
      anomaliesDetected: 0,
      snapshotsTaken: 0,
      tracesCompleted: 0,
    };

    this._subscribeToEvents();
  }

  async init() {
    await super.init();
    this.sampleTimer = setInterval(() => this._sampleAll(), this.sampleIntervalMs);
    this.cleanupStack.push(() => clearInterval(this.sampleTimer));
  }

  async execute(task) {
    switch (task.type) {
      case 'snapshot':      return this.snapshot();
      case 'inspect':       return this.inspect(task);
      case 'anomalyReport': return this.anomalyReport();
      case 'dashboard':     return this.dashboard();
      case 'traceStart':    return this.traceStart(task);
      case 'traceEnd':      return this.traceEnd(task);
      case 'traceReport':   return this.traceReport(task);
      case 'topology':      return this.topology();
      case 'driftMap':      return this.driftMap();
      default:
        throw new Error(`HeadyLens: unknown task type: ${task.type}`);
    }
  }

  /**
   * Take a full system snapshot.
   */
  snapshot() {
    const nodes = this.registry ? this.registry.healthAll() : [];
    const snap = {
      id: `snap_${Date.now()}`,
      timestamp: new Date().toISOString(),
      nodeCount: nodes.length,
      nodes,
      byRing: this._groupBy(nodes, 'ring'),
      byPool: this._groupBy(nodes, 'pool'),
      byStatus: this._groupBy(nodes, 'status'),
      systemCoherence: this._systemCoherence(nodes),
      pressure: this._systemPressure(nodes),
      anomalyRate: this._anomalyRate(),
    };

    this.snapshots.push(snap);
    if (this.snapshots.length > this.maxSnapshots) {
      this.snapshots.shift();
    }
    this.lensMetrics.snapshotsTaken++;
    this.logger.info({ nodeCount: snap.nodeCount, coherence: snap.systemCoherence.toFixed(3) }, 'Snapshot taken');
    return snap;
  }

  /**
   * Deep-inspect a specific node.
   */
  inspect(task) {
    const { nodeName } = task;
    if (!this.registry) throw new Error('No registry connected');
    const node = this.registry.get(nodeName);
    if (!node) throw new Error(`Node not found: ${nodeName}`);

    const health = node.health();
    const recentObs = this.observations
      .filter(o => o.source === nodeName)
      .slice(-fib(8));

    const baseline = this.baselineMetrics.get(nodeName);
    const deviations = baseline ? this._computeDeviations(health.metrics, baseline) : {};

    return {
      health,
      recentObservations: recentObs,
      deviations,
      embedding: {
        dimensions: node.embedding.length,
        normL2: Math.sqrt(node.embedding.reduce((s, v) => s + v * v, 0)),
        coherence: node.coherenceScore,
      },
      activeTraces: [...this.activeTraces.values()]
        .filter(t => t.nodes.includes(nodeName)),
    };
  }

  /**
   * Generate anomaly report.
   */
  anomalyReport() {
    const cutoff = Date.now() - this.anomalyWindowMs;
    const recent = this.anomalyWindow.filter(a => new Date(a.timestamp).getTime() >= cutoff);

    const byType = {};
    const byNode = {};
    for (const a of recent) {
      byType[a.type] = (byType[a.type] || 0) + 1;
      byNode[a.source] = (byNode[a.source] || 0) + 1;
    }

    return {
      totalAnomalies: this.anomalyCount,
      recentCount: recent.length,
      windowMs: this.anomalyWindowMs,
      byType,
      byNode,
      anomalyRate: this._anomalyRate(),
      recentAnomalies: recent.slice(-fib(7)),
    };
  }

  /**
   * Generate system dashboard data.
   */
  dashboard() {
    const snap = this.snapshot();
    const anomalies = this.anomalyReport();

    return {
      overview: {
        totalNodes: snap.nodeCount,
        healthyNodes: (snap.byStatus.up || []).length,
        degradedNodes: (snap.byStatus.degraded || []).length,
        downNodes: (snap.byStatus.down || []).length,
        systemCoherence: snap.systemCoherence,
        pressure: snap.pressure,
      },
      rings: snap.byRing,
      pools: snap.byPool,
      anomalies: {
        rate: anomalies.anomalyRate,
        recent: anomalies.recentCount,
        topNodes: anomalies.byNode,
      },
      traces: {
        active: this.activeTraces.size,
        completed: this.lensMetrics.tracesCompleted,
      },
      recentSnapshots: this.snapshots.slice(-fib(4)).map(s => ({
        id: s.id,
        timestamp: s.timestamp,
        coherence: s.systemCoherence,
        nodeCount: s.nodeCount,
      })),
    };
  }

  /**
   * Start a distributed trace.
   */
  traceStart(task) {
    const trace = {
      id: task.traceId || `trace_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      startTime: Date.now(),
      nodes: [task.sourceNode || 'unknown'],
      spans: [{
        node: task.sourceNode || 'unknown',
        operation: task.operation || 'start',
        startMs: Date.now(),
        endMs: null,
        metadata: task.metadata || {},
      }],
      status: 'active',
    };
    this.activeTraces.set(trace.id, trace);
    return { traceId: trace.id };
  }

  /**
   * End a distributed trace span or full trace.
   */
  traceEnd(task) {
    const trace = this.activeTraces.get(task.traceId);
    if (!trace) throw new Error(`Trace not found: ${task.traceId}`);

    if (task.span) {
      const lastSpan = trace.spans[trace.spans.length - 1];
      if (lastSpan && !lastSpan.endMs) lastSpan.endMs = Date.now();
      if (task.nextNode) {
        trace.nodes.push(task.nextNode);
        trace.spans.push({
          node: task.nextNode,
          operation: task.operation || 'continue',
          startMs: Date.now(),
          endMs: null,
          metadata: task.metadata || {},
        });
      }
    }

    if (task.complete) {
      const lastSpan = trace.spans[trace.spans.length - 1];
      if (lastSpan && !lastSpan.endMs) lastSpan.endMs = Date.now();
      trace.status = 'completed';
      trace.totalMs = Date.now() - trace.startTime;
      this.activeTraces.delete(task.traceId);
      this.completedTraces.push(trace);
      if (this.completedTraces.length > this.maxTraces) {
        this.completedTraces = this.completedTraces.slice(-Math.round(this.maxTraces * PSI));
      }
      this.lensMetrics.tracesCompleted++;
    }

    return { trace };
  }

  /**
   * Get trace report.
   */
  traceReport(task) {
    const trace = this.activeTraces.get(task.traceId)
      || this.completedTraces.find(t => t.id === task.traceId);
    if (!trace) throw new Error(`Trace not found: ${task.traceId}`);
    return { trace };
  }

  /**
   * Generate topology view of the Sacred Geometry layout.
   */
  topology() {
    if (!this.registry) return { rings: {} };
    const nodes = [...this.registry.nodes.values()];
    return {
      center:     nodes.filter(n => n.ring === 'center').map(n => this._nodeSummary(n)),
      inner:      nodes.filter(n => n.ring === 'inner').map(n => this._nodeSummary(n)),
      middle:     nodes.filter(n => n.ring === 'middle').map(n => this._nodeSummary(n)),
      outer:      nodes.filter(n => n.ring === 'outer').map(n => this._nodeSummary(n)),
      governance: nodes.filter(n => n.ring === 'governance').map(n => this._nodeSummary(n)),
    };
  }

  /**
   * Generate drift map showing coherence across all nodes.
   */
  driftMap() {
    if (!this.registry) return { nodes: [] };
    return {
      nodes: [...this.registry.nodes.values()].map(n => ({
        name: n.name,
        ring: n.ring,
        coherence: n.coherenceScore,
        drifting: n.coherenceScore < COHERENCE_DRIFT_THRESHOLD,
        driftEvents: n.metrics.driftEvents,
      })),
      threshold: COHERENCE_DRIFT_THRESHOLD,
      systemCoherence: this._systemCoherence([...this.registry.nodes.values()].map(n => n.health())),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  _subscribeToEvents() {
    const handlers = [
      ['node:heartbeat', (d) => this._observe('heartbeat', d.node, d)],
      ['node:transition', (d) => this._observe('transition', d.node, d)],
      ['node:drift', (d) => this._onDrift(d)],
      ['budget:alert', (d) => this._observe('budget_alert', 'BudgetTracker', d)],
      ['bee:report', (d) => this._observe('bee_report', d.bee, d)],
      ['wisdom:stored', (d) => this._observe('wisdom_stored', 'WisdomStore', d)],
    ];

    for (const [event, handler] of handlers) {
      nodeBus.on(event, handler);
      this.cleanupStack.push(() => nodeBus.removeListener(event, handler));
    }
  }

  _observe(type, source, data) {
    const obs = new Observation({ type, source, data });
    this.observations.push(obs);
    if (this.observations.length > this.maxObservations) {
      this.observations = this.observations.slice(-Math.round(this.maxObservations * PSI));
    }
    this.lensMetrics.observationsRecorded++;
  }

  _onDrift(data) {
    this._observe('drift', data.node, data);
    this._recordAnomaly({ type: 'coherence_drift', source: data.node, ...data });
  }

  _recordAnomaly(anomaly) {
    anomaly.timestamp = new Date().toISOString();
    this.anomalyWindow.push(anomaly);
    this.anomalyCount++;
    this.lensMetrics.anomaliesDetected++;

    const cutoff = Date.now() - this.anomalyWindowMs;
    this.anomalyWindow = this.anomalyWindow.filter(a => new Date(a.timestamp).getTime() >= cutoff);

    nodeBus.emit('lens:anomaly', anomaly);
  }

  _sampleAll() {
    if (!this.registry) return;
    for (const node of this.registry.nodes.values()) {
      const health = node.health();
      const baseline = this.baselineMetrics.get(node.name);

      if (!baseline) {
        this.baselineMetrics.set(node.name, { ...health.metrics });
        continue;
      }

      if (health.metrics.errorsEncountered > baseline.errorsEncountered + fib(4)) {
        this._recordAnomaly({
          type: 'error_spike',
          source: node.name,
          errors: health.metrics.errorsEncountered,
          baseline: baseline.errorsEncountered,
        });
      }

      if (health.metrics.avgResponseMs > baseline.avgResponseMs * PHI2) {
        this._recordAnomaly({
          type: 'latency_spike',
          source: node.name,
          latency: health.metrics.avgResponseMs,
          baseline: baseline.avgResponseMs,
        });
      }

      const alpha = Math.pow(PSI, 3);
      for (const key of Object.keys(baseline)) {
        if (typeof health.metrics[key] === 'number') {
          baseline[key] = baseline[key] * (1 - alpha) + health.metrics[key] * alpha;
        }
      }
      this.baselineMetrics.set(node.name, baseline);
    }
  }

  _systemCoherence(healthData) {
    if (healthData.length === 0) return 1.0;
    return healthData.reduce((s, h) => s + (h.coherence || 1), 0) / healthData.length;
  }

  _systemPressure(healthData) {
    const errorRate = healthData.length > 0
      ? healthData.filter(h => h.status !== 'up').length / healthData.length
      : 0;

    for (const [level, range] of Object.entries(PRESSURE_LEVELS)) {
      if (errorRate >= range.min && errorRate < range.max) return level;
    }
    return 'NOMINAL';
  }

  _anomalyRate() {
    const cutoff = Date.now() - this.anomalyWindowMs;
    const recent = this.anomalyWindow.filter(a => new Date(a.timestamp).getTime() >= cutoff);
    const windowMinutes = this.anomalyWindowMs / 60000;
    return recent.length / windowMinutes;
  }

  _groupBy(items, key) {
    const groups = {};
    for (const item of items) {
      const val = item[key] || 'unknown';
      if (!groups[val]) groups[val] = [];
      groups[val].push(item);
    }
    return groups;
  }

  _nodeSummary(node) {
    return {
      name: node.name,
      state: node.state,
      pool: node.pool,
      coherence: node.coherenceScore,
      capabilities: node.capabilities,
      requests: node.metrics.requestsHandled,
    };
  }

  _computeDeviations(current, baseline) {
    const deviations = {};
    for (const key of Object.keys(baseline)) {
      if (typeof current[key] === 'number' && typeof baseline[key] === 'number' && baseline[key] > 0) {
        deviations[key] = {
          current: current[key],
          baseline: baseline[key],
          ratio: current[key] / baseline[key],
          deviation: (current[key] - baseline[key]) / baseline[key],
        };
      }
    }
    return deviations;
  }
}

export { HeadyLensNode, HeadyLensNode as HeadyLens, Observation };
