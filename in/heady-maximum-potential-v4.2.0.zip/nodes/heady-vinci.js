/**
 * HeadyVinci — Session Planner, Topology Maintainer & Multi-Step Planning Engine
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * HeadyVinci decomposes complex tasks into subtask DAGs, performs topological
 * sorting with cycle detection, determines parallel execution batches, and
 * manages active sessions with phi-scaled token budgets. Every planning
 * decision uses CSL scoring against swarm capability embeddings.
 *
 * Ring: Inner | Pool: Hot | Domain: headyme.com
 *
 * @module heady-vinci
 * @version 4.1.0
 */

import { LiquidNode, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, fib,
  CSL_THRESHOLDS,
  cosineSimilarity, cslGate, phiFusionWeights, phiTokenBudgets,
  SIZING,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════

/** Maximum concurrent subtasks per batch — fib(6) = 8 */
const MAX_CONCURRENT = fib(6);

/** Plan history capacity — fib(14) = 377 */
const PLAN_HISTORY_SIZE = SIZING.PATTERN_STORE;

const EMBEDDING_DIM = 384;

// ═══════════════════════════════════════════════════════════════
// SUBTASK
// ═══════════════════════════════════════════════════════════════

/**
 * SubTask — A single unit of work within a task DAG.
 */
class SubTask {
  /**
   * @param {Object} config
   * @param {string} config.name - Subtask name
   * @param {string} config.description - What the subtask does
   * @param {string[]} [config.dependencies] - Names of subtasks this depends on
   * @param {string} [config.assignedNode] - Node best suited to execute
   * @param {number} [config.priority] - CSL-scored priority (0-1)
   * @param {number} [config.estimatedTokens] - Estimated token cost
   * @param {number[]} [config.embedding] - 384D task embedding
   */
  constructor(config) {
    this.id = `sub_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.name = config.name;
    this.description = config.description;
    this.dependencies = config.dependencies || [];
    this.assignedNode = config.assignedNode || null;
    this.priority = config.priority || 0;
    this.estimatedTokens = config.estimatedTokens || 0;
    this.embedding = config.embedding || null;
    this.status = 'pending';
    this.result = null;
    this.startedAt = null;
    this.completedAt = null;
  }
}

// ═══════════════════════════════════════════════════════════════
// EXECUTION PLAN
// ═══════════════════════════════════════════════════════════════

/**
 * ExecutionPlan — A fully resolved DAG of subtasks with batch scheduling.
 */
class ExecutionPlan {
  /**
   * @param {Object} config
   * @param {string} config.taskId - Original task identifier
   * @param {SubTask[]} config.subtasks - Ordered subtasks
   * @param {SubTask[][]} config.batches - Parallel execution batches
   * @param {number} config.totalTokens - Total estimated token cost
   */
  constructor(config) {
    this.id = `plan_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.taskId = config.taskId;
    this.subtasks = config.subtasks;
    this.batches = config.batches;
    this.totalTokens = config.totalTokens;
    this.batchCount = config.batches.length;
    this.maxConcurrent = MAX_CONCURRENT;
    this.createdAt = new Date().toISOString();
    this.status = 'ready';
  }

  /**
   * Return plan summary for logging.
   * @returns {Object}
   */
  summary() {
    return {
      id: this.id,
      taskId: this.taskId,
      subtaskCount: this.subtasks.length,
      batchCount: this.batchCount,
      maxConcurrent: this.maxConcurrent,
      totalTokens: this.totalTokens,
      status: this.status,
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// SESSION
// ═══════════════════════════════════════════════════════════════

/**
 * Session — Tracks an active user/agent session with phi-scaled token budgets.
 */
class Session {
  /**
   * @param {Object} config
   * @param {string} config.id - Session identifier
   * @param {string} [config.owner] - Session owner
   * @param {Object} [config.tokenBudgets] - Phi-scaled token budgets
   */
  constructor(config) {
    this.id = config.id;
    this.owner = config.owner || 'anonymous';
    this.tokenBudgets = config.tokenBudgets || phiTokenBudgets();
    this.tokensUsed = { working: 0, session: 0, memory: 0, artifacts: 0 };
    this.planIds = [];
    this.tasksCompleted = 0;
    this.createdAt = new Date().toISOString();
    this.lastActiveAt = new Date().toISOString();
    this.status = 'active';
  }

  /**
   * Record token usage for a tier.
   * @param {string} tier - working | session | memory | artifacts
   * @param {number} tokens - Tokens consumed
   * @returns {boolean} Whether usage is within budget
   */
  recordUsage(tier, tokens) {
    this.tokensUsed[tier] = (this.tokensUsed[tier] || 0) + tokens;
    this.lastActiveAt = new Date().toISOString();
    return this.tokensUsed[tier] <= (this.tokenBudgets[tier] || 0);
  }

  /**
   * Check if session is within all token budgets.
   * @returns {boolean}
   */
  withinBudgets() {
    for (const tier of Object.keys(this.tokenBudgets)) {
      if ((this.tokensUsed[tier] || 0) > this.tokenBudgets[tier]) return false;
    }
    return true;
  }
}

// ═══════════════════════════════════════════════════════════════
// CAPABILITY EMBEDDINGS FOR TASK DECOMPOSITION
// ═══════════════════════════════════════════════════════════════

/**
 * Generate a deterministic embedding from a seed string.
 * @param {string} seed
 * @returns {number[]} Normalized 384D vector
 */
function seedEmbedding(seed) {
  const vec = new Array(EMBEDDING_DIM);
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash += seed.charCodeAt(i);
  for (let i = 0; i < EMBEDDING_DIM; i++) {
    hash = (hash * 1103515245 + 12345) & 0x7fffffff;
    vec[i] = (hash / 0x7fffffff - PSI) * PHI;
  }
  const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
  return vec.map(v => v / norm);
}

const CAPABILITY_EMBEDDINGS = [
  { capability: 'context-assembly', node: 'HeadyBrains', embedding: seedEmbedding('capability:context:assembly:gather') },
  { capability: 'intent-extraction', node: 'HeadyBrains', embedding: seedEmbedding('capability:intent:classify:extract') },
  { capability: 'validation',        node: 'HeadySoul',   embedding: seedEmbedding('capability:validate:check:laws') },
  { capability: 'mission-alignment', node: 'HeadySoul',   embedding: seedEmbedding('capability:mission:align:ethics') },
  { capability: 'store',             node: 'WisdomStore', embedding: seedEmbedding('capability:store:persist:knowledge') },
  { capability: 'retrieve',          node: 'WisdomStore', embedding: seedEmbedding('capability:retrieve:search:recall') },
  { capability: 'planning',          node: 'HeadyVinci',  embedding: seedEmbedding('capability:plan:decompose:schedule') },
  { capability: 'execution',         node: 'SwarmRouter',  embedding: seedEmbedding('capability:execute:run:perform') },
];

// ═══════════════════════════════════════════════════════════════
// HEADY VINCI NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyVinciNode — Session planner, topology maintainer, and multi-step planning engine.
 *
 * Decomposes complex tasks into subtask DAGs using CSL scoring against swarm
 * capability embeddings, topologically sorts them with cycle detection via DFS,
 * determines parallel execution batches (max concurrent = fib(6) = 8),
 * and manages active sessions with phi-scaled token budgets.
 *
 * @extends LiquidNode
 */
class HeadyVinciNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyVinci'] - Node name
   * @param {string} [config.domain='headyme.com'] - Domain identifier
   * @param {number[]} [config.embedding] - Initial 384D embedding
   */
  constructor(config = {}) {
    super({
      name: config.name || 'HeadyVinci',
      ring: 'inner',
      pool: 'hot',
      domain: 'headyme.com',
      capabilities: [
        'planning',
        'decomposition',
        'topology-management',
        'session-tracking',
      ],
      ...config,
    });

    /** Swarm capability embeddings for task→node assignment */
    this.capabilityEmbeddings = CAPABILITY_EMBEDDINGS;

    /** @type {Map<string, Session>} Active sessions */
    this.sessions = new Map();

    /** @type {ExecutionPlan[]} Plan history for pattern learning */
    this.planHistory = [];

    /** @type {number} Max plan history size */
    this.maxPlanHistory = PLAN_HISTORY_SIZE;

    /** Planning metrics */
    this.planningMetrics = {
      totalDecompositions: 0,
      totalPlans: 0,
      avgSubtasks: 0,
      avgBatches: 0,
      cyclesDetected: 0,
      sessionsCreated: 0,
      sessionsExpired: 0,
    };

    nodeBus.on('vinci:decompose', (data) => this._onDecomposeRequest(data));
    nodeBus.on('vinci:plan', (data) => this._onPlanRequest(data));
    nodeBus.on('vinci:session', (data) => this._onSessionRequest(data));
    this.cleanupStack.push(() => {
      nodeBus.removeAllListeners('vinci:decompose');
      nodeBus.removeAllListeners('vinci:plan');
      nodeBus.removeAllListeners('vinci:session');
    });
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Execute a vinci task by type.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - decompose | plan | session | stats
   * @returns {Object} Task result
   */
  async execute(task) {
    switch (task.type) {
      case 'decompose': return this.decompose(task);
      case 'plan':      return this.planExecution(task.dag || task.subtasks);
      case 'session':   return this.manageSessions(task.sessionMap || {});
      case 'stats':     return this.stats();
      default:
        throw new Error(`HeadyVinci: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DECOMPOSITION
  // ─────────────────────────────────────────────────────────────

  /**
   * Decompose a complex task into a subtask DAG using CSL scoring
   * against swarm capability embeddings.
   *
   * Each subtask is assigned to the most capable node based on
   * cosine similarity between the subtask embedding and capability
   * embeddings. Dependencies are preserved from the input.
   *
   * @param {Object} task - Complex task descriptor
   * @param {string} task.id - Task identifier
   * @param {string} task.description - Task description
   * @param {Object[]} task.steps - Decomposed steps from upstream
   * @param {string} task.steps[].name - Step name
   * @param {string} task.steps[].description - Step description
   * @param {string[]} [task.steps[].dependencies] - Step dependency names
   * @param {number[]} [task.steps[].embedding] - Step 384D embedding
   * @param {number} [task.steps[].estimatedTokens] - Estimated token cost
   * @returns {Object} Decomposition result with subtask DAG
   */
  decompose(task) {
    const taskId = task.id || `task-${Date.now()}`;
    const steps = task.steps || [];

    if (steps.length === 0) {
      return { taskId, subtasks: [], message: 'No steps to decompose' };
    }

    const subtasks = [];

    for (const step of steps) {
      // Find best-matching capability node via CSL scoring
      let bestMatch = null;
      let bestScore = 0;

      if (step.embedding) {
        for (const cap of this.capabilityEmbeddings) {
          const similarity = cosineSimilarity(step.embedding, cap.embedding);
          const gated = cslGate(1.0, similarity, CSL_THRESHOLDS.LOW);
          if (gated > bestScore) {
            bestScore = gated;
            bestMatch = cap;
          }
        }
      }

      const subtask = new SubTask({
        name: step.name,
        description: step.description,
        dependencies: step.dependencies || [],
        assignedNode: bestMatch ? bestMatch.node : null,
        priority: bestScore,
        estimatedTokens: step.estimatedTokens || 0,
        embedding: step.embedding || null,
      });

      subtasks.push(subtask);
    }

    // Sort by priority descending (phi-weighted importance)
    subtasks.sort((a, b) => b.priority - a.priority);

    this.planningMetrics.totalDecompositions++;
    const total = this.planningMetrics.totalDecompositions;
    this.planningMetrics.avgSubtasks =
      (this.planningMetrics.avgSubtasks * (total - 1) + subtasks.length) / total;

    this.logger.info({
      taskId,
      subtaskCount: subtasks.length,
      assignedNodes: [...new Set(subtasks.map(s => s.assignedNode).filter(Boolean))],
    }, 'Task decomposed');

    nodeBus.emit('vinci:decomposed', { taskId, subtaskCount: subtasks.length });

    return {
      taskId,
      subtasks,
      nodeAssignments: this._summarizeAssignments(subtasks),
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TOPOLOGICAL SORT (Kahn's Algorithm + DFS Cycle Detection)
  // ─────────────────────────────────────────────────────────────

  /**
   * Topologically sort subtasks using Kahn's algorithm.
   * Detects cycles via DFS before sorting.
   *
   * @param {SubTask[]} subtasks - Subtask array with dependency names
   * @returns {Object} Sorted result with ordered subtasks or cycle error
   */
  topologicalSort(subtasks) {
    const nameToTask = new Map();
    for (const st of subtasks) nameToTask.set(st.name, st);

    // Build adjacency list and in-degree map
    const adj = new Map();
    const inDegree = new Map();
    for (const st of subtasks) {
      adj.set(st.name, []);
      inDegree.set(st.name, 0);
    }

    for (const st of subtasks) {
      for (const dep of st.dependencies) {
        if (adj.has(dep)) {
          adj.get(dep).push(st.name);
          inDegree.set(st.name, inDegree.get(st.name) + 1);
        }
      }
    }

    // DFS cycle detection
    const cycle = this._detectCycle(subtasks, adj);
    if (cycle) {
      this.planningMetrics.cyclesDetected++;
      this.logger.warn({ cycle }, 'Cycle detected in subtask DAG');
      return { sorted: false, cycle, subtasks: [] };
    }

    // Kahn's algorithm
    const queue = [];
    for (const [name, degree] of inDegree) {
      if (degree === 0) queue.push(name);
    }

    const sorted = [];
    while (queue.length > 0) {
      const current = queue.shift();
      sorted.push(nameToTask.get(current));
      for (const neighbor of (adj.get(current) || [])) {
        const newDegree = inDegree.get(neighbor) - 1;
        inDegree.set(neighbor, newDegree);
        if (newDegree === 0) queue.push(neighbor);
      }
    }

    if (sorted.length !== subtasks.length) {
      this.planningMetrics.cyclesDetected++;
      return { sorted: false, cycle: 'unresolvable dependencies', subtasks: [] };
    }

    return { sorted: true, cycle: null, subtasks: sorted };
  }

  // ─────────────────────────────────────────────────────────────
  // EXECUTION PLANNING
  // ─────────────────────────────────────────────────────────────

  /**
   * Determine parallel execution batches from a subtask DAG.
   *
   * First topologically sorts the subtasks, then groups them into
   * batches where all dependencies have been met. Each batch is
   * capped at MAX_CONCURRENT (fib(6) = 8) parallel subtasks.
   *
   * @param {SubTask[]} subtasks - Subtask array (unsorted or pre-sorted)
   * @returns {ExecutionPlan} Resolved execution plan with batches
   */
  planExecution(subtasks) {
    if (!subtasks || subtasks.length === 0) {
      return new ExecutionPlan({
        taskId: `empty-${Date.now()}`,
        subtasks: [],
        batches: [],
        totalTokens: 0,
      });
    }

    // Topological sort
    const sortResult = this.topologicalSort(subtasks);
    if (!sortResult.sorted) {
      this.logger.error({ cycle: sortResult.cycle }, 'Cannot plan execution: cycle detected');
      return new ExecutionPlan({
        taskId: `cycle-${Date.now()}`,
        subtasks,
        batches: [],
        totalTokens: 0,
      });
    }

    const sorted = sortResult.subtasks;

    // Build batches: group by dependency level
    const completed = new Set();
    const batches = [];

    while (completed.size < sorted.length) {
      const batch = [];
      for (const st of sorted) {
        if (completed.has(st.name)) continue;
        const depsResolved = st.dependencies.every(d => completed.has(d));
        if (depsResolved && batch.length < MAX_CONCURRENT) {
          batch.push(st);
        }
      }

      if (batch.length === 0) {
        this.logger.error({}, 'Deadlock in execution planning');
        break;
      }

      for (const st of batch) completed.add(st.name);
      batches.push(batch);
    }

    const totalTokens = sorted.reduce((sum, st) => sum + (st.estimatedTokens || 0), 0);

    const plan = new ExecutionPlan({
      taskId: sorted[0]?.id || `plan-${Date.now()}`,
      subtasks: sorted,
      batches,
      totalTokens,
    });

    // Record in history
    this.planHistory.push(plan);
    while (this.planHistory.length > this.maxPlanHistory) {
      this.planHistory.shift();
    }

    this.planningMetrics.totalPlans++;
    const totalPlans = this.planningMetrics.totalPlans;
    this.planningMetrics.avgBatches =
      (this.planningMetrics.avgBatches * (totalPlans - 1) + batches.length) / totalPlans;

    this.logger.info({
      planId: plan.id,
      subtasks: sorted.length,
      batches: batches.length,
      maxConcurrent: MAX_CONCURRENT,
      totalTokens,
    }, 'Execution plan created');

    nodeBus.emit('vinci:planned', plan.summary());
    return plan;
  }

  // ─────────────────────────────────────────────────────────────
  // SESSION MANAGEMENT
  // ─────────────────────────────────────────────────────────────

  /**
   * Manage active sessions with phi-scaled token budgets.
   *
   * Creates new sessions, updates existing ones, and expires
   * sessions that have exceeded their budgets.
   *
   * @param {Object} sessionMap - Map of session ID → session update data
   * @param {string} [sessionMap[].owner] - Session owner
   * @param {string} [sessionMap[].action] - create | update | expire
   * @param {Object} [sessionMap[].usage] - Token usage update { tier, tokens }
   * @returns {Object} Session management report
   */
  manageSessions(sessionMap) {
    const report = {
      created: [],
      updated: [],
      expired: [],
      active: 0,
    };

    for (const [sessionId, data] of Object.entries(sessionMap)) {
      const action = data.action || 'update';

      if (action === 'create') {
        if (!this.sessions.has(sessionId)) {
          const session = new Session({
            id: sessionId,
            owner: data.owner,
            tokenBudgets: data.tokenBudgets || phiTokenBudgets(),
          });
          this.sessions.set(sessionId, session);
          this.planningMetrics.sessionsCreated++;
          report.created.push(sessionId);
          this.logger.info({ sessionId, owner: session.owner }, 'Session created');
        }
      } else if (action === 'update') {
        const session = this.sessions.get(sessionId);
        if (session && data.usage) {
          const withinBudget = session.recordUsage(data.usage.tier, data.usage.tokens);
          if (!withinBudget) {
            this.logger.warn({
              sessionId,
              tier: data.usage.tier,
              used: session.tokensUsed[data.usage.tier],
              budget: session.tokenBudgets[data.usage.tier],
            }, 'Session token budget exceeded');
          }
          report.updated.push(sessionId);
        }
      } else if (action === 'expire') {
        const session = this.sessions.get(sessionId);
        if (session) {
          session.status = 'expired';
          this.sessions.delete(sessionId);
          this.planningMetrics.sessionsExpired++;
          report.expired.push(sessionId);
          this.logger.info({ sessionId }, 'Session expired');
        }
      }
    }

    report.active = this.sessions.size;

    this.logger.debug({
      active: report.active,
      created: report.created.length,
      updated: report.updated.length,
      expired: report.expired.length,
    }, 'Sessions managed');

    return report;
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & HEALTH
  // ─────────────────────────────────────────────────────────────

  /**
   * Return current operational statistics.
   * @returns {Object} Planning and session metrics
   */
  stats() {
    return {
      planning: { ...this.planningMetrics },
      sessions: {
        active: this.sessions.size,
        details: [...this.sessions.values()].map(s => ({
          id: s.id,
          owner: s.owner,
          status: s.status,
          tokensUsed: { ...s.tokensUsed },
          tasksCompleted: s.tasksCompleted,
          lastActiveAt: s.lastActiveAt,
        })),
      },
      planHistory: {
        size: this.planHistory.length,
        maxSize: this.maxPlanHistory,
        recent: this.planHistory.slice(-fib(5)).map(p => p.summary()),
      },
    };
  }

  /**
   * Override health to include vinci-specific metrics.
   * @returns {Object} Health report with planning and session stats
   */
  health() {
    const base = super.health();
    return {
      ...base,
      vinci: {
        planningMetrics: { ...this.planningMetrics },
        activeSessions: this.sessions.size,
        planHistorySize: this.planHistory.length,
        maxConcurrent: MAX_CONCURRENT,
        maxPlanHistory: this.maxPlanHistory,
      },
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  /**
   * Detect cycles in the subtask DAG using DFS.
   * @param {SubTask[]} subtasks - All subtasks
   * @param {Map<string, string[]>} adj - Adjacency list
   * @returns {string[]|null} Cycle path or null if acyclic
   */
  _detectCycle(subtasks, adj) {
    const WHITE = 0, GRAY = 1, BLACK = 2;
    const color = new Map();
    const parent = new Map();

    for (const st of subtasks) color.set(st.name, WHITE);

    for (const st of subtasks) {
      if (color.get(st.name) === WHITE) {
        const cycle = this._dfsVisit(st.name, adj, color, parent);
        if (cycle) return cycle;
      }
    }
    return null;
  }

  /**
   * DFS visit for cycle detection.
   * @param {string} node - Current node name
   * @param {Map<string, string[]>} adj - Adjacency list
   * @param {Map<string, number>} color - Node coloring
   * @param {Map<string, string>} parent - Parent tracking
   * @returns {string[]|null} Cycle path or null
   */
  _dfsVisit(node, adj, color, parent) {
    const WHITE = 0, GRAY = 1, BLACK = 2;
    color.set(node, GRAY);

    for (const neighbor of (adj.get(node) || [])) {
      if (color.get(neighbor) === GRAY) {
        // Back edge found — reconstruct cycle
        const cycle = [neighbor, node];
        let current = node;
        while (parent.has(current) && parent.get(current) !== neighbor) {
          current = parent.get(current);
          cycle.push(current);
        }
        return cycle.reverse();
      }
      if (color.get(neighbor) === WHITE) {
        parent.set(neighbor, node);
        const cycle = this._dfsVisit(neighbor, adj, color, parent);
        if (cycle) return cycle;
      }
    }

    color.set(node, BLACK);
    return null;
  }

  /**
   * Summarize node assignments from decomposed subtasks.
   * @param {SubTask[]} subtasks
   * @returns {Object} Node → count mapping
   */
  _summarizeAssignments(subtasks) {
    const assignments = {};
    for (const st of subtasks) {
      const node = st.assignedNode || 'unassigned';
      assignments[node] = (assignments[node] || 0) + 1;
    }
    return assignments;
  }

  /**
   * Handle incoming decompose requests via nodeBus.
   * @param {Object} data - Decompose request data
   */
  _onDecomposeRequest(data) {
    try {
      const result = this.decompose(data);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Decompose request failed');
    }
  }

  /**
   * Handle incoming plan requests via nodeBus.
   * @param {Object} data - Plan request data
   */
  _onPlanRequest(data) {
    try {
      const result = this.planExecution(data.subtasks || data.dag || []);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Plan request failed');
    }
  }

  /**
   * Handle incoming session management requests via nodeBus.
   * @param {Object} data - Session request data
   */
  _onSessionRequest(data) {
    try {
      const result = this.manageSessions(data.sessionMap || data);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Session request failed');
    }
  }
}

export { HeadyVinciNode, HeadyVinciNode as HeadyVinci };
