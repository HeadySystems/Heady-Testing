/**
 * WisdomStore — Persistent Knowledge Graph Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Accumulates validated insights, patterns, decisions, and architectural
 * wisdom across sessions. Operates as the long-term memory crystallization
 * layer — raw vector memory flows through WisdomStore to become distilled,
 * high-confidence knowledge entries with provenance chains.
 *
 * Ring: Inner | Pool: Hot | Domain: headyme.com
 *
 * @module wisdom-store
 * @version 4.1.0
 */

import { LiquidNode, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD,
  cosineSimilarity, cslGate, phiFusionWeights, phiBackoff,
  SIZING,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// WISDOM ENTRY
// ═══════════════════════════════════════════════════════════════

class WisdomEntry {
  /**
   * @param {Object} config
   * @param {string} config.content - Distilled wisdom text
   * @param {string} config.domain - Knowledge domain
   * @param {string} config.source - Origin node or session
   * @param {number} config.confidence - CSL-scored confidence (0-1)
   * @param {number[]} config.embedding - 384D vector
   * @param {string[]} [config.tags] - Classification tags
   * @param {string[]} [config.provenance] - Chain of contributing sources
   */
  constructor(config) {
    this.id = `wis_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.content = config.content;
    this.domain = config.domain;
    this.source = config.source;
    this.confidence = config.confidence;
    this.embedding = config.embedding;
    this.tags = config.tags || [];
    this.provenance = config.provenance || [config.source];
    this.accessCount = 0;
    this.lastAccessed = null;
    this.createdAt = new Date().toISOString();
    this.updatedAt = new Date().toISOString();
    this.validatedBy = [];
    this.contradictedBy = [];
    this.reinforcedCount = 0;
  }

  /**
   * Compute eviction score using phi-weighted factors.
   * Higher = more valuable = keep.
   */
  evictionScore() {
    const weights = phiFusionWeights(4);
    const recency = this.lastAccessed
      ? 1 - Math.min((Date.now() - new Date(this.lastAccessed).getTime()) / (fib(11) * 86400000), 1)
      : 0;
    const frequency = Math.min(this.accessCount / fib(8), 1);
    const reinforcement = Math.min(this.reinforcedCount / fib(5), 1);
    return (
      this.confidence * weights[0] +
      recency * weights[1] +
      frequency * weights[2] +
      reinforcement * weights[3]
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// WISDOM STORE NODE
// ═══════════════════════════════════════════════════════════════

class WisdomStoreNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: config.name || 'WisdomStore',
      ring: 'inner',
      pool: 'hot',
      domain: 'headyme.com',
      capabilities: ['store', 'retrieve', 'distill', 'validate', 'crystallize'],
      ...config,
    });

    /** @type {Map<string, WisdomEntry>} */
    this.entries = new Map();

    /** @type {Map<string, Set<string>>} domain → Set<entryId> */
    this.domainIndex = new Map();

    /** @type {Map<string, Set<string>>} tag → Set<entryId> */
    this.tagIndex = new Map();

    this.maxEntries = SIZING.LARGE_CACHE;
    this.distillThreshold = CSL_THRESHOLDS.HIGH;
    this.deduplicationThreshold = DEDUP_THRESHOLD;

    this.storeMetrics = {
      stored: 0,
      retrieved: 0,
      distilled: 0,
      evicted: 0,
      deduplicated: 0,
      contradictions: 0,
    };

    nodeBus.on('wisdom:store', (data) => this._onStoreRequest(data));
    nodeBus.on('wisdom:query', (data) => this._onQueryRequest(data));
    this.cleanupStack.push(() => {
      nodeBus.removeAllListeners('wisdom:store');
      nodeBus.removeAllListeners('wisdom:query');
    });
  }

  // ─────────────────────────────────────────────────────────────
  // CORE OPERATIONS
  // ─────────────────────────────────────────────────────────────

  async execute(task) {
    switch (task.type) {
      case 'store':       return this.store(task);
      case 'retrieve':    return this.retrieve(task);
      case 'distill':     return this.distill(task);
      case 'validate':    return this.validate(task);
      case 'crystallize': return this.crystallize(task);
      case 'prune':       return this.prune();
      case 'stats':       return this.stats();
      default:
        throw new Error(`WisdomStore: unknown task type: ${task.type}`);
    }
  }

  /**
   * Store a new wisdom entry with deduplication.
   */
  store(task) {
    const { content, domain, source, confidence, embedding, tags, provenance } = task;

    if (!content || !embedding || !domain) {
      throw new Error('WisdomStore: store requires content, domain, and embedding');
    }

    const duplicate = this._findDuplicate(embedding);
    if (duplicate) {
      duplicate.reinforcedCount++;
      duplicate.confidence = Math.min(
        1.0,
        duplicate.confidence + (1 - duplicate.confidence) * Math.pow(PSI, 2)
      );
      duplicate.updatedAt = new Date().toISOString();
      if (provenance) {
        for (const p of provenance) {
          if (!duplicate.provenance.includes(p)) duplicate.provenance.push(p);
        }
      }
      this.storeMetrics.deduplicated++;
      this.logger.info({ id: duplicate.id, reinforced: duplicate.reinforcedCount }, 'Wisdom reinforced');
      return { action: 'reinforced', entry: duplicate };
    }

    const entry = new WisdomEntry({ content, domain, source, confidence, embedding, tags, provenance });

    if (this.entries.size >= this.maxEntries) {
      this._evict(SIZING.BATCH_EVICTION);
    }

    this.entries.set(entry.id, entry);
    this._indexEntry(entry);
    this.storeMetrics.stored++;
    this.logger.info({ id: entry.id, domain, confidence: confidence.toFixed(3) }, 'Wisdom stored');

    nodeBus.emit('wisdom:stored', { id: entry.id, domain, confidence });
    return { action: 'stored', entry };
  }

  /**
   * Retrieve wisdom entries by semantic similarity.
   */
  retrieve(task) {
    const { embedding, domain, tags, topK, minConfidence } = task;
    const k = topK || fib(5);
    const minConf = minConfidence || CSL_THRESHOLDS.LOW;

    let candidates = [...this.entries.values()];

    if (domain) {
      const domainIds = this.domainIndex.get(domain);
      if (domainIds) {
        candidates = candidates.filter(e => domainIds.has(e.id));
      }
    }

    if (tags && tags.length > 0) {
      candidates = candidates.filter(e =>
        tags.some(t => e.tags.includes(t))
      );
    }

    const scored = candidates
      .filter(e => e.confidence >= minConf)
      .map(e => ({
        entry: e,
        similarity: embedding ? cosineSimilarity(embedding, e.embedding) : e.confidence,
        gated: embedding ? cslGate(1.0, cosineSimilarity(embedding, e.embedding), CSL_THRESHOLDS.MINIMUM) : e.confidence,
      }))
      .filter(s => s.gated > 0)
      .sort((a, b) => b.gated - a.gated)
      .slice(0, k);

    for (const s of scored) {
      s.entry.accessCount++;
      s.entry.lastAccessed = new Date().toISOString();
    }

    this.storeMetrics.retrieved += scored.length;
    return { results: scored.map(s => ({ ...s.entry, similarity: s.similarity })) };
  }

  /**
   * Distill raw observations into high-confidence wisdom.
   * Takes multiple low-confidence entries and crystallizes shared patterns.
   */
  distill(task) {
    const { domain, minEntries } = task;
    const min = minEntries || fib(4);
    const domainIds = this.domainIndex.get(domain);

    if (!domainIds || domainIds.size < min) {
      return { distilled: false, reason: 'insufficient_entries', count: domainIds?.size || 0 };
    }

    const entries = [...domainIds].map(id => this.entries.get(id)).filter(Boolean);
    const lowConfidence = entries.filter(e => e.confidence < this.distillThreshold);

    if (lowConfidence.length < min) {
      return { distilled: false, reason: 'insufficient_low_confidence', count: lowConfidence.length };
    }

    const clusters = this._clusterByEmbedding(lowConfidence, CSL_THRESHOLDS.HIGH);
    const distilled = [];

    for (const cluster of clusters) {
      if (cluster.length < fib(3)) continue;

      const avgConfidence = cluster.reduce((s, e) => s + e.confidence, 0) / cluster.length;
      const boostedConfidence = Math.min(1.0, avgConfidence * PHI);

      const centroidEmbedding = this._computeCentroid(cluster.map(e => e.embedding));
      const allProvenance = [...new Set(cluster.flatMap(e => e.provenance))];
      const allTags = [...new Set(cluster.flatMap(e => e.tags))];

      const wisdomContent = `[Distilled from ${cluster.length} observations] ${cluster[0].content}`;

      const newEntry = new WisdomEntry({
        content: wisdomContent,
        domain,
        source: 'WisdomStore:distill',
        confidence: boostedConfidence,
        embedding: centroidEmbedding,
        tags: allTags,
        provenance: allProvenance,
      });

      newEntry.validatedBy = cluster.map(e => e.id);
      this.entries.set(newEntry.id, newEntry);
      this._indexEntry(newEntry);
      distilled.push(newEntry);
    }

    this.storeMetrics.distilled += distilled.length;
    this.logger.info({ domain, distilledCount: distilled.length }, 'Wisdom distilled');
    return { distilled: true, entries: distilled };
  }

  /**
   * Validate an entry against existing wisdom — check for contradictions.
   */
  validate(task) {
    const { embedding, content, domain } = task;
    const related = this.retrieve({ embedding, domain, topK: fib(5), minConfidence: CSL_THRESHOLDS.MEDIUM });

    const contradictions = [];
    const confirmations = [];

    for (const r of related.results) {
      const sim = cosineSimilarity(embedding, r.embedding);
      if (sim < -CSL_THRESHOLDS.MINIMUM) {
        contradictions.push({ id: r.id, similarity: sim, content: r.content });
      } else if (sim > CSL_THRESHOLDS.HIGH) {
        confirmations.push({ id: r.id, similarity: sim, content: r.content });
      }
    }

    if (contradictions.length > 0) {
      this.storeMetrics.contradictions += contradictions.length;
    }

    return {
      valid: contradictions.length === 0,
      contradictions,
      confirmations,
      confidenceBoost: confirmations.length > 0
        ? Math.min(0.1, confirmations.length * Math.pow(PSI, 3))
        : 0,
    };
  }

  /**
   * Crystallize — promote high-value entries to permanent status.
   */
  crystallize(task) {
    const threshold = task.threshold || CSL_THRESHOLDS.CRITICAL;
    const crystallized = [];

    for (const entry of this.entries.values()) {
      if (entry.confidence >= threshold && entry.reinforcedCount >= fib(3)) {
        entry.tags = [...new Set([...entry.tags, 'crystallized'])];
        entry.updatedAt = new Date().toISOString();
        crystallized.push(entry.id);
      }
    }

    this.logger.info({ count: crystallized.length }, 'Wisdom crystallized');
    return { crystallized };
  }

  /**
   * Prune low-value entries.
   */
  prune() {
    const before = this.entries.size;
    const targetSize = Math.round(this.maxEntries * PSI);
    if (this.entries.size <= targetSize) {
      return { pruned: 0 };
    }
    this._evict(this.entries.size - targetSize);
    return { pruned: before - this.entries.size };
  }

  stats() {
    const domains = {};
    for (const [domain, ids] of this.domainIndex) {
      domains[domain] = ids.size;
    }
    return {
      totalEntries: this.entries.size,
      maxEntries: this.maxEntries,
      domains,
      metrics: { ...this.storeMetrics },
      avgConfidence: this.entries.size > 0
        ? [...this.entries.values()].reduce((s, e) => s + e.confidence, 0) / this.entries.size
        : 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  _findDuplicate(embedding) {
    for (const entry of this.entries.values()) {
      const sim = cosineSimilarity(embedding, entry.embedding);
      if (sim >= this.deduplicationThreshold) return entry;
    }
    return null;
  }

  _indexEntry(entry) {
    if (!this.domainIndex.has(entry.domain)) this.domainIndex.set(entry.domain, new Set());
    this.domainIndex.get(entry.domain).add(entry.id);
    for (const tag of entry.tags) {
      if (!this.tagIndex.has(tag)) this.tagIndex.set(tag, new Set());
      this.tagIndex.get(tag).add(entry.id);
    }
  }

  _evict(count) {
    const sorted = [...this.entries.values()]
      .filter(e => !e.tags.includes('crystallized'))
      .sort((a, b) => a.evictionScore() - b.evictionScore());

    const toEvict = sorted.slice(0, count);
    for (const entry of toEvict) {
      this.entries.delete(entry.id);
      const domainSet = this.domainIndex.get(entry.domain);
      if (domainSet) domainSet.delete(entry.id);
      for (const tag of entry.tags) {
        const tagSet = this.tagIndex.get(tag);
        if (tagSet) tagSet.delete(entry.id);
      }
    }
    this.storeMetrics.evicted += toEvict.length;
    this.logger.info({ evicted: toEvict.length }, 'Entries evicted');
  }

  _clusterByEmbedding(entries, threshold) {
    const clusters = [];
    const assigned = new Set();
    for (let i = 0; i < entries.length; i++) {
      if (assigned.has(i)) continue;
      const cluster = [entries[i]];
      assigned.add(i);
      for (let j = i + 1; j < entries.length; j++) {
        if (assigned.has(j)) continue;
        const sim = cosineSimilarity(entries[i].embedding, entries[j].embedding);
        if (sim >= threshold) {
          cluster.push(entries[j]);
          assigned.add(j);
        }
      }
      clusters.push(cluster);
    }
    return clusters;
  }

  _computeCentroid(embeddings) {
    const dim = embeddings[0].length;
    const sum = new Array(dim).fill(0);
    for (const emb of embeddings) {
      for (let i = 0; i < dim; i++) sum[i] += emb[i];
    }
    const norm = Math.sqrt(sum.reduce((s, v) => s + v * v, 0));
    return norm > 0 ? sum.map(v => v / norm) : sum;
  }

  _onStoreRequest(data) {
    try { this.store(data); } catch (err) {
      this.logger.error({ error: err.message }, 'Store request failed');
    }
  }

  _onQueryRequest(data) {
    try {
      const result = this.retrieve(data);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Query request failed');
    }
  }
}

export { WisdomStoreNode, WisdomStoreNode as WisdomStore, WisdomEntry };
