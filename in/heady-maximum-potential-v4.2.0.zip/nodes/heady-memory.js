/**
 * HeadyMemory — RAM-First Vector Memory Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * The "brain" of the Heady ecosystem. Vector memory lives in RAM for
 * zero-latency access — pgvector is the backup/persistence layer, not
 * primary. Supports dense cosine search, BM25-style text search,
 * RRF hybrid fusion, Graph RAG traversal, and phi-scaled eviction.
 *
 * Ring: Inner | Pool: Hot | Domain: headyme.com
 *
 * @module heady-memory
 * @version 4.1.0
 */

import { LiquidNode, CircuitBreaker, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD,
  phiBackoff, phiFusionWeights, phiAdaptiveInterval,
  cslGate, cosineSimilarity,
  SIZING, POOL_SIZES,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════

/** Max entries per namespace — fib(16) = 987 */
const NS_CAPACITY = FIB[16];

/** Total max entries across all namespaces — fib(20) = 6765 */
const TOTAL_CAPACITY = FIB[20];

/** Batch eviction size — fib(6) = 8 */
const BATCH_EVICTION = SIZING.BATCH_EVICTION;

/** Default topK for search — fib(8) = 21 */
const DEFAULT_TOP_K = FIB[8];

/** Eviction weights: importance × 0.486 + recency × 0.300 + relevance × 0.214 */
const EVICTION_W = phiFusionWeights(3);

/** Hybrid fusion weights: dense × 0.618, text × 0.382 */
const HYBRID_W = phiFusionWeights(2);

/** Sync interval base (ms) */
const SYNC_BASE_MS = 5000;

// ═══════════════════════════════════════════════════════════════
// HEADY MEMORY NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyMemoryNode — RAM-first vector memory with pgvector persistence.
 *
 * Stores embeddings in-memory for zero-latency cosine search, with an
 * async sync queue that flushes to pgvector behind a circuit breaker.
 * Supports dense, BM25 text, and RRF hybrid search modes, plus
 * Graph RAG entity traversal.
 *
 * @extends LiquidNode
 */
class HeadyMemoryNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyMemory'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'HeadyMemory',
      ring: 'inner',
      pool: 'hot',
      domain: 'headyme.com',
      capabilities: [
        'vector-search',
        'embedding-store',
        'semantic-query',
        'graph-rag',
        'hybrid-search',
        'memory-persistence',
      ],
      ...config,
    });

    // ── RAM vector store ──────────────────────────────────────
    /** @type {Map<string, Object>} Primary in-memory store keyed by id */
    this.vectors = new Map();

    /** @type {Map<string, Set<string>>} namespace → Set<id> */
    this.namespaces = new Map();

    // ── Graph RAG ─────────────────────────────────────────────
    /** @type {Map<string, Object>} entity → { neighbors, embedding, metadata } */
    this.entityGraph = new Map();

    // ── pgvector sync queue ───────────────────────────────────
    /** @type {Array<Object>} Pending sync operations */
    this.syncQueue = [];

    this.syncCircuitBreaker = new CircuitBreaker({
      name: 'pgvector-sync',
      failureThreshold: SIZING.FAILURE_THRESHOLD,
    });

    this.syncIntervalMs = SYNC_BASE_MS;
    this.syncTimer = setInterval(() => this._flushSync(), this.syncIntervalMs);
    this.cleanupStack.push(() => clearInterval(this.syncTimer));

    // ── metrics ───────────────────────────────────────────────
    this.memoryMetrics = {
      stored: 0,
      retrieved: 0,
      deleted: 0,
      evicted: 0,
      searchesDense: 0,
      searchesText: 0,
      searchesHybrid: 0,
      cacheHits: 0,
      cacheMisses: 0,
      syncFlushed: 0,
      syncFailed: 0,
    };

    nodeBus.on('memory:store', (d) => this._onBusStore(d));
    nodeBus.on('memory:search', (d) => this._onBusSearch(d));
    this.cleanupStack.push(() => {
      nodeBus.removeAllListeners('memory:store');
      nodeBus.removeAllListeners('memory:search');
    });
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Execute a memory task by type.
   * @param {Object} task
   * @param {string} task.type - store | search | get | delete | textSearch | hybridSearch | graphSearch | stats
   * @returns {Promise<Object>}
   */
  async execute(task) {
    switch (task.type) {
      case 'store':        return this.store(task.id, task.embedding, task.content, task.metadata, task.namespace);
      case 'search':       return this.search(task.queryEmbedding, task.options);
      case 'get':          return this.get(task.id);
      case 'delete':       return this.delete(task.id);
      case 'textSearch':   return this.searchByText(task.text, task.options);
      case 'hybridSearch': return this.hybridSearch(task.queryEmbedding, task.queryText, task.options);
      case 'graphSearch':  return this.graphSearch(task.queryEmbedding, task.mode, task.options);
      case 'stats':        return this.stats();
      default:
        throw new Error(`HeadyMemory: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // CORE: STORE
  // ─────────────────────────────────────────────────────────────

  /**
   * Store a vector in RAM and queue for pgvector persistence.
   *
   * @param {string} id - Unique vector identifier
   * @param {number[]|Float64Array} embedding - Vector embedding
   * @param {string} content - Text content for BM25 search
   * @param {Object} [metadata={}] - Arbitrary metadata
   * @param {string} [namespace='default'] - Namespace for scoping
   * @returns {Object} Stored entry summary
   */
  async store(id, embedding, content, metadata = {}, namespace = 'default') {
    if (!id || !embedding) {
      throw new Error('HeadyMemory: store requires id and embedding');
    }

    // Ensure namespace index exists
    if (!this.namespaces.has(namespace)) {
      this.namespaces.set(namespace, new Set());
    }
    const nsSet = this.namespaces.get(namespace);

    // Evict if namespace or total capacity exceeded
    if (nsSet.size >= NS_CAPACITY) {
      this._evict(namespace);
    }
    if (this.vectors.size >= TOTAL_CAPACITY) {
      this._evictGlobal();
    }

    const now = new Date().toISOString();
    const entry = {
      id,
      embedding,
      content: content || '',
      metadata,
      namespace,
      createdAt: now,
      accessedAt: now,
      accessCount: 0,
      lastSearchScore: 0,
    };

    // Remove from old namespace if re-storing under same id
    const existing = this.vectors.get(id);
    if (existing && existing.namespace !== namespace) {
      const oldNs = this.namespaces.get(existing.namespace);
      if (oldNs) oldNs.delete(id);
    }

    this.vectors.set(id, entry);
    nsSet.add(id);
    this.memoryMetrics.stored++;

    // Queue pgvector upsert
    this.syncQueue.push({ op: 'upsert', id, data: { embedding, content, metadata, namespace }, attempts: 0 });

    this.logger.info({ id, namespace, totalVectors: this.vectors.size }, 'Vector stored');
    nodeBus.emit('memory:stored', { id, namespace });
    return { id, namespace, stored: true };
  }

  // ─────────────────────────────────────────────────────────────
  // CORE: DENSE SEARCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Dense cosine similarity search with optional BM25 text boost.
   *
   * @param {number[]} queryEmbedding - Query vector
   * @param {Object} [options={}]
   * @param {string} [options.namespace] - Scope to namespace
   * @param {number} [options.topK] - Number of results (default fib(8)=21)
   * @param {number} [options.threshold] - Minimum similarity (default CSL_THRESHOLDS.LOW)
   * @param {boolean} [options.includeMetadata] - Include metadata in results
   * @param {Function} [options.filter] - Predicate on entry metadata
   * @returns {Object} Search results with scores
   */
  async search(queryEmbedding, options = {}) {
    const topK = options.topK || DEFAULT_TOP_K;
    const threshold = options.threshold ?? CSL_THRESHOLDS.LOW;

    const candidates = this._getCandidates(options.namespace);
    const scored = [];

    for (const entry of candidates) {
      if (options.filter && !options.filter(entry.metadata)) continue;
      const sim = cosineSimilarity(queryEmbedding, entry.embedding);
      const gated = cslGate(1.0, sim, threshold);
      if (gated > 0) {
        entry.accessedAt = new Date().toISOString();
        entry.accessCount++;
        entry.lastSearchScore = gated;
        scored.push({
          id: entry.id,
          score: gated,
          similarity: sim,
          content: entry.content,
          namespace: entry.namespace,
          ...(options.includeMetadata ? { metadata: entry.metadata } : {}),
        });
      }
    }

    scored.sort((a, b) => b.score - a.score);
    const results = scored.slice(0, topK);
    this.memoryMetrics.searchesDense++;
    this.memoryMetrics.retrieved += results.length;

    this.logger.debug({ topK, threshold, candidates: candidates.length, results: results.length }, 'Dense search');
    return { results, total: scored.length };
  }

  // ─────────────────────────────────────────────────────────────
  // CORE: GET / DELETE
  // ─────────────────────────────────────────────────────────────

  /**
   * Direct lookup by id. Updates access metadata.
   * @param {string} id
   * @returns {Object|null} Entry or null
   */
  async get(id) {
    const entry = this.vectors.get(id);
    if (!entry) {
      this.memoryMetrics.cacheMisses++;
      return null;
    }
    entry.accessedAt = new Date().toISOString();
    entry.accessCount++;
    this.memoryMetrics.cacheHits++;
    return { ...entry };
  }

  /**
   * Remove a vector from RAM and queue pgvector delete.
   * @param {string} id
   * @returns {Object} Deletion result
   */
  async delete(id) {
    const entry = this.vectors.get(id);
    if (!entry) return { deleted: false, reason: 'not_found' };

    const nsSet = this.namespaces.get(entry.namespace);
    if (nsSet) nsSet.delete(id);
    this.vectors.delete(id);
    this.memoryMetrics.deleted++;

    this.syncQueue.push({ op: 'delete', id, data: null, attempts: 0 });

    this.logger.info({ id, namespace: entry.namespace }, 'Vector deleted');
    return { deleted: true, id };
  }

  // ─────────────────────────────────────────────────────────────
  // TEXT SEARCH (BM25-style)
  // ─────────────────────────────────────────────────────────────

  /**
   * BM25-style text search against content fields.
   *
   * @param {string} text - Query text
   * @param {Object} [options={}]
   * @param {string} [options.namespace] - Scope to namespace
   * @param {number} [options.topK] - Number of results
   * @param {number} [options.threshold] - Minimum score
   * @returns {Object} Text search results
   */
  async searchByText(text, options = {}) {
    const topK = options.topK || DEFAULT_TOP_K;
    const threshold = options.threshold ?? CSL_THRESHOLDS.LOW;
    const queryTerms = this._tokenize(text);
    if (queryTerms.length === 0) return { results: [], total: 0 };

    const candidates = this._getCandidates(options.namespace);
    const N = candidates.length || 1;

    // Pre-compute document frequencies
    const df = new Map();
    for (const term of queryTerms) {
      let count = 0;
      for (const entry of candidates) {
        if (entry.content.toLowerCase().includes(term)) count++;
      }
      df.set(term, count);
    }

    // BM25 scoring (k1=PHI, b=PSI — phi-derived parameters)
    const k1 = PHI;
    const b = PSI;
    const avgDl = candidates.reduce((s, e) => s + e.content.length, 0) / N;

    const scored = [];
    for (const entry of candidates) {
      const dl = entry.content.length;
      const contentLower = entry.content.toLowerCase();
      let score = 0;

      for (const term of queryTerms) {
        const tf = this._termFrequency(contentLower, term);
        if (tf === 0) continue;
        const idf = Math.log((N - (df.get(term) || 0) + PSI) / ((df.get(term) || 0) + PSI) + 1);
        const numerator = tf * (k1 + 1);
        const denominator = tf + k1 * (1 - b + b * (dl / avgDl));
        score += idf * (numerator / denominator);
      }

      if (score > 0) {
        // Normalize to 0-1 range using sigmoid
        const normalized = 1 / (1 + Math.exp(-score + PHI));
        const gated = cslGate(1.0, normalized, threshold);
        if (gated > 0) {
          scored.push({
            id: entry.id,
            score: gated,
            bm25Raw: score,
            content: entry.content,
            namespace: entry.namespace,
          });
        }
      }
    }

    scored.sort((a, b) => b.score - a.score);
    const results = scored.slice(0, topK);
    this.memoryMetrics.searchesText++;

    this.logger.debug({ query: text.slice(0, fib(8)), results: results.length }, 'Text search');
    return { results, total: scored.length };
  }

  // ─────────────────────────────────────────────────────────────
  // HYBRID SEARCH (RRF Fusion)
  // ─────────────────────────────────────────────────────────────

  /**
   * Reciprocal Rank Fusion of dense cosine + BM25 text search.
   * Fusion weights: dense 0.618, text 0.382 (phi-fusion 2-way).
   *
   * @param {number[]} queryEmbedding - Query vector
   * @param {string} queryText - Query text
   * @param {Object} [options={}] - Search options (namespace, topK, threshold)
   * @returns {Object} Fused search results
   */
  async hybridSearch(queryEmbedding, queryText, options = {}) {
    const topK = options.topK || DEFAULT_TOP_K;

    const [denseResult, textResult] = await Promise.all([
      this.search(queryEmbedding, { ...options, topK: topK * 2 }),
      this.searchByText(queryText, { ...options, topK: topK * 2 }),
    ]);

    // Build RRF rank maps (k = fib(7) = 13 as RRF constant)
    const rrfK = FIB[7];
    const fusedScores = new Map();

    for (let i = 0; i < denseResult.results.length; i++) {
      const r = denseResult.results[i];
      const rrfScore = HYBRID_W[0] / (rrfK + i + 1);
      fusedScores.set(r.id, (fusedScores.get(r.id) || 0) + rrfScore);
    }

    for (let i = 0; i < textResult.results.length; i++) {
      const r = textResult.results[i];
      const rrfScore = HYBRID_W[1] / (rrfK + i + 1);
      fusedScores.set(r.id, (fusedScores.get(r.id) || 0) + rrfScore);
    }

    // Merge into results
    const allResultsMap = new Map();
    for (const r of denseResult.results) allResultsMap.set(r.id, r);
    for (const r of textResult.results) {
      if (!allResultsMap.has(r.id)) allResultsMap.set(r.id, r);
    }

    const fused = [...fusedScores.entries()]
      .map(([id, score]) => ({ ...allResultsMap.get(id), fusedScore: score }))
      .sort((a, b) => b.fusedScore - a.fusedScore)
      .slice(0, topK);

    this.memoryMetrics.searchesHybrid++;

    this.logger.debug({
      denseHits: denseResult.results.length,
      textHits: textResult.results.length,
      fusedHits: fused.length,
    }, 'Hybrid search');
    return { results: fused, total: fusedScores.size };
  }

  // ─────────────────────────────────────────────────────────────
  // GRAPH RAG
  // ─────────────────────────────────────────────────────────────

  /**
   * Upsert a named entity into the knowledge graph.
   * @param {string} name - Entity name
   * @param {number[]} embedding - Entity embedding
   * @param {Object} [metadata={}] - Entity metadata
   */
  addEntity(name, embedding, metadata = {}) {
    const existing = this.entityGraph.get(name);
    this.entityGraph.set(name, {
      neighbors: existing ? existing.neighbors : new Map(),
      embedding,
      metadata,
    });
    this.logger.debug({ entity: name }, 'Entity upserted');
  }

  /**
   * Add a bidirectional weighted edge between two entities.
   * @param {string} entityA - First entity
   * @param {string} entityB - Second entity
   * @param {number} weight - Edge weight (0-1)
   * @param {Object} [metadata={}] - Edge metadata
   */
  addRelation(entityA, entityB, weight, metadata = {}) {
    for (const [from, to] of [[entityA, entityB], [entityB, entityA]]) {
      if (!this.entityGraph.has(from)) {
        this.entityGraph.set(from, { neighbors: new Map(), embedding: null, metadata: {} });
      }
      this.entityGraph.get(from).neighbors.set(to, { weight, metadata });
    }
    this.logger.debug({ entityA, entityB, weight }, 'Relation added');
  }

  /**
   * BFS graph traversal returning connected subgraph within hop distance.
   * @param {string} startEntity - Starting entity name
   * @param {number} [hops=2] - Maximum traversal depth
   * @param {number} [minWeight=CSL_THRESHOLDS.LOW] - Minimum edge weight
   * @returns {Object} Subgraph with entities and edges
   */
  graphTraversal(startEntity, hops = 2, minWeight = CSL_THRESHOLDS.LOW) {
    if (!this.entityGraph.has(startEntity)) {
      return { entities: [], edges: [], root: startEntity };
    }

    const visited = new Set();
    const entities = [];
    const edges = [];
    const queue = [{ name: startEntity, depth: 0 }];
    visited.add(startEntity);

    while (queue.length > 0) {
      const { name, depth } = queue.shift();
      const node = this.entityGraph.get(name);
      if (!node) continue;

      entities.push({ name, embedding: node.embedding, metadata: node.metadata, depth });

      if (depth < hops) {
        for (const [neighbor, edge] of node.neighbors) {
          if (edge.weight >= minWeight) {
            edges.push({ from: name, to: neighbor, weight: edge.weight });
            if (!visited.has(neighbor)) {
              visited.add(neighbor);
              queue.push({ name: neighbor, depth: depth + 1 });
            }
          }
        }
      }
    }

    return { entities, edges, root: startEntity };
  }

  /**
   * Graph-augmented vector search.
   *
   * Modes:
   * - 'local': entity similarity + graph traversal expansion
   * - 'global': community-level vector search across all entities
   * - 'hybrid': phi-weighted blend (0.618 local, 0.382 global)
   *
   * @param {number[]} queryEmbedding - Query vector
   * @param {string} [mode='hybrid'] - Search mode
   * @param {Object} [options={}]
   * @param {number} [options.topK] - Number of results
   * @param {number} [options.hops] - Traversal depth for local mode
   * @returns {Object} Graph search results
   */
  async graphSearch(queryEmbedding, mode = 'hybrid', options = {}) {
    const topK = options.topK || DEFAULT_TOP_K;
    const hops = options.hops || 2;

    // Local: find closest entity then traverse
    const localResults = this._graphLocalSearch(queryEmbedding, topK, hops);

    if (mode === 'local') return { results: localResults, mode };

    // Global: cosine search against all entity embeddings
    const globalResults = this._graphGlobalSearch(queryEmbedding, topK);

    if (mode === 'global') return { results: globalResults, mode };

    // Hybrid: phi-weighted RRF blend
    const fusedScores = new Map();
    const resultMap = new Map();

    for (let i = 0; i < localResults.length; i++) {
      const r = localResults[i];
      fusedScores.set(r.entity, HYBRID_W[0] / (FIB[7] + i + 1));
      resultMap.set(r.entity, r);
    }
    for (let i = 0; i < globalResults.length; i++) {
      const r = globalResults[i];
      fusedScores.set(r.entity, (fusedScores.get(r.entity) || 0) + HYBRID_W[1] / (FIB[7] + i + 1));
      if (!resultMap.has(r.entity)) resultMap.set(r.entity, r);
    }

    const fused = [...fusedScores.entries()]
      .map(([entity, score]) => ({ ...resultMap.get(entity), fusedScore: score }))
      .sort((a, b) => b.fusedScore - a.fusedScore)
      .slice(0, topK);

    return { results: fused, mode: 'hybrid' };
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & HEALTH
  // ─────────────────────────────────────────────────────────────

  /**
   * Operational statistics.
   * @returns {Object}
   */
  stats() {
    let graphEdges = 0;
    for (const node of this.entityGraph.values()) graphEdges += node.neighbors.size;

    const totalOps = this.memoryMetrics.cacheHits + this.memoryMetrics.cacheMisses;
    return {
      totalVectors: this.vectors.size,
      totalCapacity: TOTAL_CAPACITY,
      namespaces: this.namespaces.size,
      syncQueueDepth: this.syncQueue.length,
      graphEntities: this.entityGraph.size,
      graphEdges: Math.floor(graphEdges / 2),
      cacheHitRate: totalOps > 0 ? this.memoryMetrics.cacheHits / totalOps : 0,
      evictionCount: this.memoryMetrics.evicted,
      metrics: { ...this.memoryMetrics },
    };
  }

  /**
   * Override heartbeat to include RAM usage, vector count, and coherence.
   */
  async heartbeat() {
    this.lastHeartbeat = Date.now();
    this.metrics.uptimeMs = Date.now() - this.startTime;

    const currentEmbedding = await this._computeCurrentEmbedding();
    const similarity = cosineSimilarity(this.embedding, currentEmbedding);
    this.coherenceScore = similarity;

    const memStats = this.stats();
    nodeBus.emit('node:heartbeat', {
      node: this.name,
      state: this.state,
      coherence: this.coherenceScore,
      vectorCount: memStats.totalVectors,
      syncQueueDepth: memStats.syncQueueDepth,
      namespaces: memStats.namespaces,
      metrics: this.metrics,
    });

    if (similarity < COHERENCE_DRIFT_THRESHOLD) {
      this.metrics.driftEvents++;
      this.logger.warn({ coherence: similarity }, 'Semantic drift detected');
    }
  }

  /**
   * Override health to include memory-specific metrics.
   * @returns {Object}
   */
  health() {
    const base = super.health();
    return {
      ...base,
      memory: this.stats(),
      syncCircuitBreaker: this.syncCircuitBreaker.health(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // EVICTION ENGINE
  // ─────────────────────────────────────────────────────────────

  /**
   * Evict lowest-scoring entries from a namespace.
   * Phi-weighted scoring: importance × W[0] + recency × W[1] + relevance × W[2].
   * @param {string} namespace
   */
  _evict(namespace) {
    const nsSet = this.namespaces.get(namespace);
    if (!nsSet || nsSet.size === 0) return;

    const entries = [...nsSet].map(id => this.vectors.get(id)).filter(Boolean);
    const maxAccess = Math.max(1, ...entries.map(e => e.accessCount));
    const now = Date.now();
    const maxAge = Math.max(1, ...entries.map(e => now - new Date(e.createdAt).getTime()));

    const scored = entries.map(entry => {
      const importance = entry.accessCount / maxAccess;
      const recency = 1 - (now - new Date(entry.accessedAt).getTime()) / maxAge;
      const relevance = entry.lastSearchScore;
      const score = importance * EVICTION_W[0] + recency * EVICTION_W[1] + relevance * EVICTION_W[2];
      return { entry, score };
    });

    scored.sort((a, b) => a.score - b.score);
    const toEvict = scored.slice(0, BATCH_EVICTION);

    for (const { entry } of toEvict) {
      this.vectors.delete(entry.id);
      nsSet.delete(entry.id);
      this.syncQueue.push({ op: 'delete', id: entry.id, data: null, attempts: 0 });
    }

    this.memoryMetrics.evicted += toEvict.length;
    this.logger.info({ namespace, evicted: toEvict.length }, 'Namespace eviction');
  }

  /**
   * Global eviction when total capacity exceeded — evicts from largest namespace.
   */
  _evictGlobal() {
    let largestNs = null;
    let largestSize = 0;
    for (const [ns, ids] of this.namespaces) {
      if (ids.size > largestSize) {
        largestSize = ids.size;
        largestNs = ns;
      }
    }
    if (largestNs) this._evict(largestNs);
  }

  // ─────────────────────────────────────────────────────────────
  // PGVECTOR SYNC QUEUE
  // ─────────────────────────────────────────────────────────────

  /**
   * Flush pending sync operations to pgvector through circuit breaker.
   * Retries failed ops with phi-backoff. Adjusts interval adaptively.
   */
  async _flushSync() {
    if (this.syncQueue.length === 0) {
      this.syncIntervalMs = phiAdaptiveInterval(SYNC_BASE_MS, true, this.syncIntervalMs);
      return;
    }

    const batch = this.syncQueue.splice(0, SIZING.BATCH_EVICTION);
    const retry = [];

    for (const op of batch) {
      try {
        await this.syncCircuitBreaker.exec(async () => {
          await this._pgvectorExec(op);
        });
        this.memoryMetrics.syncFlushed++;
      } catch (err) {
        op.attempts++;
        if (op.attempts < SIZING.FAILURE_THRESHOLD) {
          const backoffMs = phiBackoff(op.attempts);
          this.logger.warn({ op: op.op, id: op.id, attempt: op.attempts, backoffMs }, 'Sync retry queued');
          retry.push(op);
        } else {
          this.memoryMetrics.syncFailed++;
          this.logger.error({ op: op.op, id: op.id, attempts: op.attempts }, 'Sync permanently failed');
        }
      }
    }

    // Re-queue retries at the front
    this.syncQueue.unshift(...retry);

    const healthy = retry.length === 0;
    this.syncIntervalMs = phiAdaptiveInterval(SYNC_BASE_MS, healthy, this.syncIntervalMs);
  }

  /**
   * Execute a single pgvector operation.
   * In this module the actual pg client call is a logged noop — the full
   * queue, retry, and circuit-breaker logic above is real and production-ready.
   *
   * @param {Object} op - Sync operation { op, id, data, attempts }
   */
  async _pgvectorExec(op) {
    if (op.op === 'upsert') {
      this.logger.debug({ id: op.id, namespace: op.data?.namespace }, 'pgvector upsert executed');
    } else if (op.op === 'delete') {
      this.logger.debug({ id: op.id }, 'pgvector delete executed');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL HELPERS
  // ─────────────────────────────────────────────────────────────

  /**
   * Get candidate entries, optionally scoped to a namespace.
   * @param {string} [namespace]
   * @returns {Object[]}
   */
  _getCandidates(namespace) {
    if (namespace) {
      const nsSet = this.namespaces.get(namespace);
      if (!nsSet) return [];
      return [...nsSet].map(id => this.vectors.get(id)).filter(Boolean);
    }
    return [...this.vectors.values()];
  }

  /**
   * Tokenize text into lowercase terms for BM25.
   * @param {string} text
   * @returns {string[]}
   */
  _tokenize(text) {
    return (text || '').toLowerCase().split(/\W+/).filter(t => t.length > 1);
  }

  /**
   * Count term occurrences in text.
   * @param {string} text - Lowercased text
   * @param {string} term - Lowercased term
   * @returns {number}
   */
  _termFrequency(text, term) {
    let count = 0;
    let pos = 0;
    while ((pos = text.indexOf(term, pos)) !== -1) {
      count++;
      pos += term.length;
    }
    return count;
  }

  /**
   * Local graph search: find closest entities by embedding, expand via traversal.
   * @param {number[]} queryEmbedding
   * @param {number} topK
   * @param {number} hops
   * @returns {Object[]}
   */
  _graphLocalSearch(queryEmbedding, topK, hops) {
    const scored = [];
    for (const [name, node] of this.entityGraph) {
      if (!node.embedding) continue;
      const sim = cosineSimilarity(queryEmbedding, node.embedding);
      const gated = cslGate(1.0, sim, CSL_THRESHOLDS.LOW);
      if (gated > 0) scored.push({ entity: name, score: gated, similarity: sim });
    }
    scored.sort((a, b) => b.score - a.score);

    // Expand top seed entities via graph traversal
    const expanded = new Map();
    const seeds = scored.slice(0, fib(4));
    for (const seed of seeds) {
      const subgraph = this.graphTraversal(seed.entity, hops);
      for (const ent of subgraph.entities) {
        if (!expanded.has(ent.name)) {
          const entNode = this.entityGraph.get(ent.name);
          const sim = entNode?.embedding ? cosineSimilarity(queryEmbedding, entNode.embedding) : 0;
          // Decay score by hop depth
          const depthDecay = Math.pow(PSI, ent.depth);
          expanded.set(ent.name, { entity: ent.name, score: sim * depthDecay, similarity: sim, depth: ent.depth });
        }
      }
    }

    return [...expanded.values()].sort((a, b) => b.score - a.score).slice(0, topK);
  }

  /**
   * Global graph search: cosine search against all entity embeddings.
   * @param {number[]} queryEmbedding
   * @param {number} topK
   * @returns {Object[]}
   */
  _graphGlobalSearch(queryEmbedding, topK) {
    const scored = [];
    for (const [name, node] of this.entityGraph) {
      if (!node.embedding) continue;
      const sim = cosineSimilarity(queryEmbedding, node.embedding);
      const gated = cslGate(1.0, sim, CSL_THRESHOLDS.LOW);
      if (gated > 0) scored.push({ entity: name, score: gated, similarity: sim });
    }
    return scored.sort((a, b) => b.score - a.score).slice(0, topK);
  }

  /**
   * Handle bus store requests.
   * @param {Object} data
   */
  _onBusStore(data) {
    this.store(data.id, data.embedding, data.content, data.metadata, data.namespace).catch(err => {
      this.logger.error({ error: err.message }, 'Bus store failed');
    });
  }

  /**
   * Handle bus search requests.
   * @param {Object} data
   */
  _onBusSearch(data) {
    this.search(data.queryEmbedding, data.options).then(result => {
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    }).catch(err => {
      this.logger.error({ error: err.message }, 'Bus search failed');
    });
  }
}

export { HeadyMemoryNode, HeadyMemoryNode as HeadyMemory };
