/**
 * CouncilMode — Multi-Model Consensus Engine
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Runs the same task through multiple AI models/nodes simultaneously,
 * scores results via CSL cosine similarity, and produces a consensus
 * output. Implements HeadyBattle Arena for competitive evaluation
 * and HeadyCouncil for collaborative synthesis.
 *
 * Ring: Inner | Pool: Hot | Domain: headyai.com
 *
 * @module council-mode
 * @version 4.1.0
 */

import { LiquidNode, CircuitBreaker, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD,
  cosineSimilarity, cslCONSENSUS, cslGate, phiFusionWeights,
  phiBackoff, SIZING,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// COUNCIL MEMBER
// ═══════════════════════════════════════════════════════════════

class CouncilMember {
  constructor(config) {
    this.name = config.name;
    this.model = config.model;
    this.provider = config.provider;
    this.strengths = config.strengths || [];
    this.historicalScore = config.historicalScore || 0.5;
    this.breaker = new CircuitBreaker({ name: `council:${config.name}` });
    this.totalVotes = 0;
    this.wins = 0;
  }

  get winRate() {
    return this.totalVotes > 0 ? this.wins / this.totalVotes : 0.5;
  }
}

// ═══════════════════════════════════════════════════════════════
// COUNCIL RESULT
// ═══════════════════════════════════════════════════════════════

class CouncilResult {
  constructor(config) {
    this.id = `cncl_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.mode = config.mode;
    this.task = config.task;
    this.responses = config.responses;
    this.consensus = config.consensus;
    this.winner = config.winner || null;
    this.rankings = config.rankings || [];
    this.agreementScore = config.agreementScore;
    this.timestamp = new Date().toISOString();
    this.durationMs = config.durationMs;
  }
}

// ═══════════════════════════════════════════════════════════════
// COUNCIL MODE NODE
// ═══════════════════════════════════════════════════════════════

class CouncilModeNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: config.name || 'CouncilMode',
      ring: 'inner',
      pool: 'hot',
      domain: 'headyai.com',
      capabilities: ['council', 'arena', 'consensus', 'synthesize', 'evaluate'],
      ...config,
    });

    /** @type {Map<string, CouncilMember>} */
    this.members = new Map();

    /** @type {CouncilResult[]} */
    this.history = [];
    this.maxHistory = SIZING.CACHE_SIZE;

    /** Executor function — override for production */
    this.executor = config.executor || this._defaultExecutor.bind(this);

    /** Embedder function — override for production */
    this.embedder = config.embedder || this._defaultEmbedder.bind(this);

    this.councilMetrics = {
      sessionsRun: 0,
      arenaMatches: 0,
      consensusReached: 0,
      disagreements: 0,
      avgAgreementScore: 0,
    };

    this._registerDefaultMembers();
  }

  async execute(task) {
    switch (task.type) {
      case 'council':     return this.runCouncil(task);
      case 'arena':       return this.runArena(task);
      case 'synthesize':  return this.synthesize(task);
      case 'addMember':   return this.addMember(task);
      case 'rankings':    return this.getRankings();
      case 'stats':       return this.getStats();
      default:
        throw new Error(`CouncilMode: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // COUNCIL — Collaborative consensus
  // ─────────────────────────────────────────────────────────────

  async runCouncil(task) {
    const startTime = Date.now();
    const { prompt, members: memberNames, minAgreement } = task;
    const minAgree = minAgreement || CSL_THRESHOLDS.MEDIUM;

    const selectedMembers = memberNames
      ? memberNames.map(n => this.members.get(n)).filter(Boolean)
      : [...this.members.values()].slice(0, fib(5));

    if (selectedMembers.length < fib(3)) {
      throw new Error('Council requires at least 2 members');
    }

    this.logger.info({ members: selectedMembers.map(m => m.name), prompt: prompt.slice(0, 80) }, 'Council session starting');

    const responses = await this._executeParallel(selectedMembers, prompt);
    const validResponses = responses.filter(r => r.success);

    if (validResponses.length < fib(3)) {
      throw new Error(`Insufficient council responses: ${validResponses.length}`);
    }

    const embeddings = await Promise.all(
      validResponses.map(r => this.embedder(r.response))
    );

    const agreementMatrix = this._computeAgreementMatrix(embeddings);
    const avgAgreement = this._averageAgreement(agreementMatrix);

    const weights = phiFusionWeights(validResponses.length);
    const historicalWeights = validResponses.map((r, i) => {
      const member = this.members.get(r.member);
      return weights[i] * (member ? (0.5 + member.winRate * 0.5) : 0.5);
    });
    const totalWeight = historicalWeights.reduce((s, w) => s + w, 0);
    const normalizedWeights = historicalWeights.map(w => w / totalWeight);

    const consensusEmbedding = cslCONSENSUS(embeddings, normalizedWeights);

    const rankings = validResponses.map((r, i) => ({
      member: r.member,
      model: r.model,
      similarity: cosineSimilarity(embeddings[i], consensusEmbedding),
      response: r.response,
    })).sort((a, b) => b.similarity - a.similarity);

    const winner = rankings[0];
    const consensusResponse = avgAgreement >= minAgree
      ? winner.response
      : await this._synthesizeResponses(validResponses, rankings, prompt);

    for (const r of rankings) {
      const member = this.members.get(r.member);
      if (member) {
        member.totalVotes++;
        if (r.member === winner.member) member.wins++;
        member.historicalScore = member.historicalScore * PSI + r.similarity * (1 - PSI);
      }
    }

    this.councilMetrics.sessionsRun++;
    this.councilMetrics.avgAgreementScore =
      (this.councilMetrics.avgAgreementScore * (this.councilMetrics.sessionsRun - 1) + avgAgreement) /
      this.councilMetrics.sessionsRun;

    if (avgAgreement >= minAgree) {
      this.councilMetrics.consensusReached++;
    } else {
      this.councilMetrics.disagreements++;
    }

    const result = new CouncilResult({
      mode: 'council',
      task: prompt,
      responses: validResponses,
      consensus: consensusResponse,
      winner: winner.member,
      rankings,
      agreementScore: avgAgreement,
      durationMs: Date.now() - startTime,
    });

    this.history.push(result);
    if (this.history.length > this.maxHistory) {
      this.history = this.history.slice(-Math.round(this.maxHistory * PSI));
    }

    this.logger.info({
      agreement: avgAgreement.toFixed(3),
      winner: winner.member,
      durationMs: result.durationMs,
    }, 'Council session complete');

    nodeBus.emit('council:result', { id: result.id, winner: winner.member, agreement: avgAgreement });
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // ARENA — Competitive head-to-head evaluation
  // ─────────────────────────────────────────────────────────────

  async runArena(task) {
    const startTime = Date.now();
    const { prompt, challenger, defender, judges } = task;

    const challengerMember = this.members.get(challenger);
    const defenderMember = this.members.get(defender);
    if (!challengerMember || !defenderMember) {
      throw new Error('Arena requires valid challenger and defender');
    }

    const [challengerResult, defenderResult] = await this._executeParallel(
      [challengerMember, defenderMember], prompt
    );

    if (!challengerResult.success || !defenderResult.success) {
      throw new Error('Arena match failed — one or both contestants did not respond');
    }

    const [challEmb, defEmb] = await Promise.all([
      this.embedder(challengerResult.response),
      this.embedder(defenderResult.response),
    ]);

    let judgeScores = [];
    const judgeMembers = judges
      ? judges.map(j => this.members.get(j)).filter(Boolean)
      : [...this.members.values()].filter(m => m.name !== challenger && m.name !== defender).slice(0, fib(4));

    if (judgeMembers.length > 0) {
      const judgePrompt = `Given the task: "${prompt}"\n\nResponse A: ${challengerResult.response}\n\nResponse B: ${defenderResult.response}\n\nWhich response is better? Reply with just "A" or "B" and a brief reason.`;
      const judgeResults = await this._executeParallel(judgeMembers, judgePrompt);
      for (const jr of judgeResults.filter(r => r.success)) {
        const vote = jr.response.toUpperCase().includes('A') ? challenger : defender;
        judgeScores.push({ judge: jr.member, vote, reasoning: jr.response });
      }
    }

    const challengerVotes = judgeScores.filter(j => j.vote === challenger).length;
    const defenderVotes = judgeScores.filter(j => j.vote === defender).length;
    const similarity = cosineSimilarity(challEmb, defEmb);
    const arenaWinner = challengerVotes > defenderVotes ? challenger : defender;

    challengerMember.totalVotes++;
    defenderMember.totalVotes++;
    if (arenaWinner === challenger) challengerMember.wins++;
    else defenderMember.wins++;

    this.councilMetrics.arenaMatches++;

    const result = new CouncilResult({
      mode: 'arena',
      task: prompt,
      responses: [challengerResult, defenderResult],
      consensus: arenaWinner === challenger ? challengerResult.response : defenderResult.response,
      winner: arenaWinner,
      rankings: [
        { member: arenaWinner, votes: Math.max(challengerVotes, defenderVotes) },
        { member: arenaWinner === challenger ? defender : challenger, votes: Math.min(challengerVotes, defenderVotes) },
      ],
      agreementScore: similarity,
      durationMs: Date.now() - startTime,
    });

    this.history.push(result);
    this.logger.info({
      challenger, defender, winner: arenaWinner,
      votes: `${challengerVotes}-${defenderVotes}`,
    }, 'Arena match complete');

    nodeBus.emit('arena:result', { id: result.id, winner: arenaWinner });
    return { ...result, judgeScores };
  }

  // ─────────────────────────────────────────────────────────────
  // SYNTHESIZE — Merge multiple responses
  // ─────────────────────────────────────────────────────────────

  async synthesize(task) {
    const { responses, prompt } = task;
    const synthesized = await this._synthesizeResponses(
      responses.map((r, i) => ({ member: `input_${i}`, response: r, success: true })),
      responses.map((r, i) => ({ member: `input_${i}`, response: r, similarity: 1 })),
      prompt
    );
    return { synthesized };
  }

  addMember(task) {
    const member = new CouncilMember(task);
    this.members.set(member.name, member);
    this.logger.info({ member: member.name, model: member.model }, 'Member added');
    return { added: member.name };
  }

  getRankings() {
    return [...this.members.values()]
      .map(m => ({
        name: m.name,
        model: m.model,
        winRate: m.winRate,
        totalVotes: m.totalVotes,
        wins: m.wins,
        historicalScore: m.historicalScore,
        circuitState: m.breaker.health().state,
      }))
      .sort((a, b) => b.winRate - a.winRate);
  }

  getStats() {
    return {
      ...this.councilMetrics,
      memberCount: this.members.size,
      historySize: this.history.length,
      rankings: this.getRankings(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────────────────

  async _executeParallel(members, prompt) {
    return Promise.all(
      members.map(async (member) => {
        try {
          const response = await member.breaker.exec(() => this.executor(member, prompt));
          return { member: member.name, model: member.model, response, success: true };
        } catch (err) {
          this.logger.warn({ member: member.name, error: err.message }, 'Member execution failed');
          return { member: member.name, model: member.model, response: null, success: false, error: err.message };
        }
      })
    );
  }

  _computeAgreementMatrix(embeddings) {
    const n = embeddings.length;
    const matrix = Array.from({ length: n }, () => new Array(n).fill(0));
    for (let i = 0; i < n; i++) {
      for (let j = i; j < n; j++) {
        const sim = cosineSimilarity(embeddings[i], embeddings[j]);
        matrix[i][j] = sim;
        matrix[j][i] = sim;
      }
    }
    return matrix;
  }

  _averageAgreement(matrix) {
    const n = matrix.length;
    if (n < 2) return 1.0;
    let sum = 0, count = 0;
    for (let i = 0; i < n; i++) {
      for (let j = i + 1; j < n; j++) {
        sum += matrix[i][j];
        count++;
      }
    }
    return count > 0 ? sum / count : 0;
  }

  async _synthesizeResponses(responses, rankings, prompt) {
    if (rankings.length === 0) return '';
    return rankings[0].response;
  }

  async _defaultExecutor(member, prompt) {
    return `[${member.name}/${member.model}] Response to: ${prompt.slice(0, 50)}...`;
  }

  async _defaultEmbedder(text) {
    const dim = 384;
    const vec = new Array(dim);
    let seed = 0;
    for (let i = 0; i < text.length; i++) seed += text.charCodeAt(i);
    for (let i = 0; i < dim; i++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      vec[i] = (seed / 0x7fffffff - 0.5) * 2;
    }
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    return vec.map(v => v / norm);
  }

  _registerDefaultMembers() {
    const defaults = [
      { name: 'claude-sonnet', model: 'claude-sonnet', provider: 'anthropic', strengths: ['code', 'analysis', 'security'] },
      { name: 'claude-opus', model: 'claude-opus', provider: 'anthropic', strengths: ['architecture', 'creative', 'research'] },
      { name: 'gpt-4o', model: 'gpt-4o', provider: 'openai', strengths: ['general', 'documentation', 'ui'] },
      { name: 'gemini-pro', model: 'gemini-pro', provider: 'google', strengths: ['research', 'multilingual', 'reasoning'] },
      { name: 'groq-llama', model: 'groq-llama', provider: 'groq', strengths: ['speed', 'quick-tasks'] },
    ];
    for (const d of defaults) {
      this.members.set(d.name, new CouncilMember(d));
    }
  }
}

export { CouncilModeNode, CouncilModeNode as CouncilMode, CouncilMember, CouncilResult };
