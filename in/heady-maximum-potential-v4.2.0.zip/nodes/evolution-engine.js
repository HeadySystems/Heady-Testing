/**
 * EvolutionEngine — Adaptive System Growth & Optimization Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Manages the evolutionary lifecycle of the Heady ecosystem —
 * spawns new nodes, prunes underperformers, evolves configurations,
 * and adapts routing weights based on Fibonacci growth targets
 * and Monte Carlo simulation results.
 *
 * Ring: Governance | Pool: Cold | Domain: headysystems.com
 *
 * @module evolution-engine
 * @version 4.1.0
 */

import { LiquidNode, NodeRegistry, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD,
  cosineSimilarity, cslGate, phiFusionWeights, phiBackoff,
  SIZING,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// EVOLUTION STRATEGY
// ═══════════════════════════════════════════════════════════════

class EvolutionStrategy {
  constructor(config) {
    this.id = `evo_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.type = config.type;
    this.target = config.target;
    this.params = config.params || {};
    this.generation = config.generation || 0;
    this.fitnessHistory = [];
    this.status = 'pending';
    this.createdAt = new Date().toISOString();
  }

  recordFitness(score) {
    this.fitnessHistory.push({ score, timestamp: new Date().toISOString() });
    if (this.fitnessHistory.length > fib(8)) {
      this.fitnessHistory = this.fitnessHistory.slice(-fib(8));
    }
  }

  get currentFitness() {
    return this.fitnessHistory.length > 0
      ? this.fitnessHistory[this.fitnessHistory.length - 1].score
      : 0;
  }

  get trendSlope() {
    if (this.fitnessHistory.length < fib(3)) return 0;
    const recent = this.fitnessHistory.slice(-fib(5));
    const n = recent.length;
    const xMean = (n - 1) / 2;
    const yMean = recent.reduce((s, e) => s + e.score, 0) / n;
    let num = 0, den = 0;
    for (let i = 0; i < n; i++) {
      num += (i - xMean) * (recent[i].score - yMean);
      den += (i - xMean) * (i - xMean);
    }
    return den > 0 ? num / den : 0;
  }
}

// ═══════════════════════════════════════════════════════════════
// EVOLUTION ENGINE NODE
// ═══════════════════════════════════════════════════════════════

class EvolutionEngineNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: config.name || 'EvolutionEngine',
      ring: 'governance',
      pool: 'cold',
      domain: 'headysystems.com',
      capabilities: ['evolve', 'spawn', 'prune', 'mutate', 'select', 'simulate'],
      ...config,
    });

    /** @type {NodeRegistry} */
    this.registry = config.registry || null;

    /** @type {Map<string, EvolutionStrategy>} */
    this.strategies = new Map();

    /** Fibonacci population targets */
    this.populationTargets = {
      center:     fib(1),   // 1
      inner:      fib(4),   // 3
      middle:     fib(6),   // 8
      outer:      fib(6),   // 8
      governance: fib(6),   // 8
    };

    /** Evolution cycle interval — phi-scaled */
    this.cycleIntervalMs = Math.round(PHI * 1000 * fib(8));
    this.cycleTimer = null;
    this.currentGeneration = 0;

    /** Golden angle for agent distribution (≈137.5°) */
    this.goldenAngle = 2 * Math.PI * (1 - PSI);

    this.evoMetrics = {
      cyclesRun: 0,
      nodesSpawned: 0,
      nodesPruned: 0,
      mutationsApplied: 0,
      simulationsRun: 0,
    };

    nodeBus.on('node:drift', (d) => this._onDrift(d));
    nodeBus.on('node:transition', (d) => this._onTransition(d));
    this.cleanupStack.push(() => {
      nodeBus.removeAllListeners('node:drift');
    });
  }

  async init() {
    await super.init();
    this.cycleTimer = setInterval(() => this._runEvolutionCycle(), this.cycleIntervalMs);
    this.cleanupStack.push(() => clearInterval(this.cycleTimer));
  }

  async execute(task) {
    switch (task.type) {
      case 'evolve':     return this.evolve();
      case 'spawn':      return this.spawnNode(task);
      case 'prune':      return this.pruneNodes(task);
      case 'mutate':     return this.mutateConfig(task);
      case 'select':     return this.selectFittest(task);
      case 'simulate':   return this.monteCarlo(task);
      case 'population': return this.populationStatus();
      case 'stats':      return this.getStats();
      default:
        throw new Error(`EvolutionEngine: unknown task type: ${task.type}`);
    }
  }

  /**
   * Run a full evolution cycle — assess, spawn/prune, mutate.
   */
  evolve() {
    this.currentGeneration++;
    this.evoMetrics.cyclesRun++;

    const assessment = this._assessPopulation();
    const actions = [];

    for (const [ring, status] of Object.entries(assessment.byRing)) {
      const target = this.populationTargets[ring] || fib(5);
      const current = status.count;

      if (current < target) {
        const toSpawn = Math.min(target - current, fib(3));
        for (let i = 0; i < toSpawn; i++) {
          actions.push({ action: 'spawn', ring, reason: `population_deficit (${current}/${target})` });
        }
      } else if (current > Math.round(target * PHI)) {
        const toPrune = current - target;
        const weakest = status.nodes
          .sort((a, b) => a.coherence - b.coherence)
          .slice(0, toPrune);
        for (const node of weakest) {
          actions.push({ action: 'prune', node: node.name, ring, reason: `population_excess, coherence=${node.coherence.toFixed(3)}` });
        }
      }
    }

    for (const node of assessment.drifting) {
      actions.push({
        action: 'mutate',
        node: node.name,
        reason: `coherence_drift (${node.coherence.toFixed(3)} < ${COHERENCE_DRIFT_THRESHOLD})`,
      });
    }

    this.logger.info({
      generation: this.currentGeneration,
      actions: actions.length,
      drifting: assessment.drifting.length,
    }, 'Evolution cycle complete');

    nodeBus.emit('evolution:cycle', {
      generation: this.currentGeneration,
      assessment,
      actions,
    });

    return { generation: this.currentGeneration, assessment, actions };
  }

  /**
   * Spawn a new node in a ring.
   */
  spawnNode(task) {
    const { ring, name, pool, capabilities } = task;
    const nodeName = name || `evolved_${ring}_${this.currentGeneration}_${Date.now().toString(36).slice(-4)}`;

    const phaseAngle = this.goldenAngle * this.evoMetrics.nodesSpawned;
    this.logger.info({ name: nodeName, ring, phaseAngle: phaseAngle.toFixed(3) }, 'Spawning evolved node');

    this.evoMetrics.nodesSpawned++;

    return {
      spawned: true,
      name: nodeName,
      ring,
      pool: pool || this._defaultPool(ring),
      capabilities: capabilities || [],
      phaseAngle,
      generation: this.currentGeneration,
    };
  }

  /**
   * Prune underperforming nodes.
   */
  pruneNodes(task) {
    const { ring, count, minCoherence } = task;
    const threshold = minCoherence || CSL_THRESHOLDS.MINIMUM;

    if (!this.registry) return { pruned: [] };

    const candidates = this.registry.getByRing(ring || 'outer')
      .filter(n => n.coherenceScore < threshold)
      .sort((a, b) => a.coherenceScore - b.coherenceScore);

    const toPrune = candidates.slice(0, count || fib(3));
    const pruned = toPrune.map(n => n.name);

    this.evoMetrics.nodesPruned += pruned.length;
    this.logger.info({ ring, pruned: pruned.length }, 'Nodes pruned');
    return { pruned };
  }

  /**
   * Mutate a node's configuration to improve performance.
   */
  mutateConfig(task) {
    const { node: nodeName, params } = task;
    if (!this.registry) return { mutated: false, reason: 'no_registry' };

    const node = this.registry.get(nodeName);
    if (!node) return { mutated: false, reason: 'node_not_found' };

    const mutations = [];

    if (node.coherenceScore < CSL_THRESHOLDS.MEDIUM) {
      mutations.push({
        param: 'heartbeatInterval',
        from: 'current',
        to: 'reduced_by_psi',
        reason: 'Faster heartbeat to detect and correct drift sooner',
      });
    }

    if (node.metrics.errorsEncountered > fib(5)) {
      mutations.push({
        param: 'retryBackoff',
        from: 'current',
        to: 'phi_backoff_increased',
        reason: 'Higher backoff to reduce error pressure',
      });
    }

    if (params) {
      for (const [key, value] of Object.entries(params)) {
        mutations.push({ param: key, from: 'manual', to: value, reason: 'Manual mutation' });
      }
    }

    this.evoMetrics.mutationsApplied += mutations.length;
    this.logger.info({ node: nodeName, mutations: mutations.length }, 'Config mutated');

    return { mutated: true, node: nodeName, mutations, generation: this.currentGeneration };
  }

  /**
   * Select fittest nodes from a ring.
   */
  selectFittest(task) {
    const { ring, topK } = task;
    const k = topK || fib(4);

    if (!this.registry) return { selected: [] };

    const nodes = this.registry.getByRing(ring || 'middle');
    const ranked = nodes
      .map(n => ({
        name: n.name,
        coherence: n.coherenceScore,
        requests: n.metrics.requestsHandled,
        errors: n.metrics.errorsEncountered,
        fitness: this._computeFitness(n),
      }))
      .sort((a, b) => b.fitness - a.fitness);

    return { selected: ranked.slice(0, k) };
  }

  /**
   * Run Monte Carlo simulation for an evolution strategy.
   */
  monteCarlo(task) {
    const { scenario, iterations } = task;
    const numIterations = iterations || fib(11);
    const results = [];

    for (let i = 0; i < numIterations; i++) {
      const outcome = this._simulateScenario(scenario, i);
      results.push(outcome);
    }

    const fitnesses = results.map(r => r.fitness);
    const sorted = [...fitnesses].sort((a, b) => a - b);
    const p5 = sorted[Math.floor(sorted.length * 0.05)];
    const p50 = sorted[Math.floor(sorted.length * 0.5)];
    const p95 = sorted[Math.floor(sorted.length * 0.95)];
    const mean = fitnesses.reduce((s, f) => s + f, 0) / fitnesses.length;

    this.evoMetrics.simulationsRun += numIterations;

    return {
      scenario,
      iterations: numIterations,
      statistics: { mean, p5, p50, p95 },
      recommendation: p50 > CSL_THRESHOLDS.MEDIUM ? 'proceed' : 'reconsider',
    };
  }

  populationStatus() {
    const assessment = this._assessPopulation();
    return {
      ...assessment,
      targets: this.populationTargets,
      generation: this.currentGeneration,
    };
  }

  getStats() {
    return {
      ...this.evoMetrics,
      generation: this.currentGeneration,
      activeStrategies: this.strategies.size,
      targets: this.populationTargets,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────────────────

  _assessPopulation() {
    if (!this.registry) {
      return { total: 0, byRing: {}, drifting: [], avgCoherence: 1 };
    }

    const nodes = [...this.registry.nodes.values()];
    const byRing = {};

    for (const node of nodes) {
      if (!byRing[node.ring]) byRing[node.ring] = { count: 0, nodes: [] };
      byRing[node.ring].count++;
      byRing[node.ring].nodes.push({
        name: node.name,
        coherence: node.coherenceScore,
        state: node.state,
        requests: node.metrics.requestsHandled,
      });
    }

    const drifting = nodes.filter(n => n.coherenceScore < COHERENCE_DRIFT_THRESHOLD).map(n => ({
      name: n.name,
      ring: n.ring,
      coherence: n.coherenceScore,
    }));

    const avgCoherence = nodes.length > 0
      ? nodes.reduce((s, n) => s + n.coherenceScore, 0) / nodes.length
      : 1;

    return { total: nodes.length, byRing, drifting, avgCoherence };
  }

  _computeFitness(node) {
    const weights = phiFusionWeights(4);
    const coherence = node.coherenceScore;
    const throughput = Math.min(node.metrics.requestsHandled / fib(8), 1);
    const errorRate = node.metrics.requestsHandled > 0
      ? 1 - (node.metrics.errorsEncountered / node.metrics.requestsHandled)
      : 1;
    const latency = node.metrics.avgResponseMs > 0
      ? 1 - Math.min(node.metrics.avgResponseMs / (PHI * 10000), 1)
      : 1;
    return coherence * weights[0] + throughput * weights[1] + errorRate * weights[2] + latency * weights[3];
  }

  _simulateScenario(scenario, seed) {
    const rng = (s) => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; };
    let s = seed + 1;
    const coherence = rng(s); s = (s * 1103515245 + 12345) & 0x7fffffff;
    const throughput = rng(s); s = (s * 1103515245 + 12345) & 0x7fffffff;
    const errorRate = rng(s) * 0.2;
    const fitness = coherence * 0.486 + throughput * 0.300 + (1 - errorRate) * 0.214;
    return { coherence, throughput, errorRate, fitness };
  }

  _defaultPool(ring) {
    const map = { center: 'governance', inner: 'hot', middle: 'hot', outer: 'warm', governance: 'governance' };
    return map[ring] || 'warm';
  }

  _onDrift(data) {
    this.logger.warn({ node: data.node, coherence: data.coherence }, 'Drift event received');
  }

  _onTransition(data) {
    if (data.to === 'expired') {
      this.logger.info({ node: data.node }, 'Node expired — considering respawn');
    }
  }

  _runEvolutionCycle() {
    try { this.evolve(); } catch (err) {
      this.logger.error({ error: err.message }, 'Evolution cycle failed');
    }
  }
}

export { EvolutionEngineNode, EvolutionEngineNode as EvolutionEngine, EvolutionStrategy };
