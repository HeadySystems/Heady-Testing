/**
 * HeadyBrains — Computational Pre-Processor & Context Gathering Engine
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * HeadyBrains sits in the inner ring as the primary context assembly and
 * intent classification engine. Every inbound request passes through
 * HeadyBrains for context enrichment before routing to specialized nodes.
 * Uses CSL cosine scoring for intent classification and phi-geometric
 * token budgets for context capsule sizing.
 *
 * Ring: Inner | Pool: Hot | Domain: headyme.com
 *
 * @module heady-brains
 * @version 4.1.0
 */

import { LiquidNode, nodeBus, createLogger } from '../shared/liquid-node.js';
import {
  PHI, PSI, fib,
  CSL_THRESHOLDS,
  cosineSimilarity, cslGate, phiFusionWeights, phiTokenBudgets,
  SIZING,
} from '../shared/phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// CONTEXT CAPSULE
// ═══════════════════════════════════════════════════════════════

/**
 * ContextCapsule — Packaged context for inter-node transfer.
 * Contains all relevant context entries with metadata and a
 * phi-geometric token budget.
 */
class ContextCapsule {
  /**
   * @param {Object} config
   * @param {string} config.requestId - Originating request ID
   * @param {Object[]} config.entries - Context entries with content and scores
   * @param {Object} config.metadata - Request metadata (intent, source, etc.)
   * @param {number} config.tokenBudget - Allocated token budget
   * @param {number} config.relevanceFloor - Minimum relevance for inclusion
   */
  constructor(config) {
    this.id = `ctx_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.requestId = config.requestId;
    this.entries = config.entries || [];
    this.metadata = config.metadata || {};
    this.tokenBudget = config.tokenBudget;
    this.relevanceFloor = config.relevanceFloor;
    this.totalTokens = this.entries.reduce((sum, e) => sum + (e.tokenCount || 0), 0);
    this.createdAt = new Date().toISOString();
  }

  /**
   * Check whether the capsule is within its token budget.
   * @returns {boolean}
   */
  withinBudget() {
    return this.totalTokens <= this.tokenBudget;
  }

  /**
   * Return capsule summary for logging.
   * @returns {Object}
   */
  summary() {
    return {
      id: this.id,
      requestId: this.requestId,
      entryCount: this.entries.length,
      totalTokens: this.totalTokens,
      tokenBudget: this.tokenBudget,
      withinBudget: this.withinBudget(),
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// LRU CACHE
// ═══════════════════════════════════════════════════════════════

/**
 * Simple LRU cache bounded by fib(16) = 987 entries.
 * Used for caching context assemblies and intent classifications.
 */
class LRUCache {
  /**
   * @param {number} maxSize - Maximum cache entries
   */
  constructor(maxSize) {
    this.maxSize = maxSize;
    this.cache = new Map();
  }

  /**
   * Get a cached value, promoting it to most-recent.
   * @param {string} key
   * @returns {*} Cached value or undefined
   */
  get(key) {
    if (!this.cache.has(key)) return undefined;
    const value = this.cache.get(key);
    this.cache.delete(key);
    this.cache.set(key, value);
    return value;
  }

  /**
   * Set a value, evicting least-recently-used if at capacity.
   * @param {string} key
   * @param {*} value
   */
  set(key, value) {
    if (this.cache.has(key)) this.cache.delete(key);
    this.cache.set(key, value);
    if (this.cache.size > this.maxSize) {
      const oldest = this.cache.keys().next().value;
      this.cache.delete(oldest);
    }
  }

  /**
   * Check if key exists.
   * @param {string} key
   * @returns {boolean}
   */
  has(key) {
    return this.cache.has(key);
  }

  /** Current cache size. */
  get size() {
    return this.cache.size;
  }

  /** Clear all entries. */
  clear() {
    this.cache.clear();
  }
}

// ═══════════════════════════════════════════════════════════════
// KNOWN INTENT TYPES
// ═══════════════════════════════════════════════════════════════

const EMBEDDING_DIM = 384;

/**
 * Generate a deterministic embedding from a seed string.
 * @param {string} seed
 * @returns {number[]} Normalized 384D vector
 */
function seedEmbedding(seed) {
  const vec = new Array(EMBEDDING_DIM);
  let hash = 0;
  for (let i = 0; i < seed.length; i++) hash += seed.charCodeAt(i);
  for (let i = 0; i < EMBEDDING_DIM; i++) {
    hash = (hash * 1103515245 + 12345) & 0x7fffffff;
    vec[i] = (hash / 0x7fffffff - PSI) * PHI;
  }
  const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
  return vec.map(v => v / norm);
}

const KNOWN_INTENTS = [
  { type: 'query',       embedding: seedEmbedding('intent:query:search:find:lookup') },
  { type: 'create',      embedding: seedEmbedding('intent:create:build:generate:new') },
  { type: 'modify',      embedding: seedEmbedding('intent:modify:update:change:edit') },
  { type: 'delete',      embedding: seedEmbedding('intent:delete:remove:purge:clear') },
  { type: 'analyze',     embedding: seedEmbedding('intent:analyze:evaluate:assess:review') },
  { type: 'plan',        embedding: seedEmbedding('intent:plan:decompose:schedule:organize') },
  { type: 'validate',    embedding: seedEmbedding('intent:validate:check:verify:confirm') },
  { type: 'communicate', embedding: seedEmbedding('intent:communicate:notify:share:report') },
];

// ═══════════════════════════════════════════════════════════════
// HEADY BRAINS NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyBrainsNode — Computational pre-processor and context gathering engine.
 *
 * Assembles context from vector memory and node state, classifies inbound
 * request intents using CSL cosine scoring, and packages context capsules
 * for downstream node consumption with phi-geometric token budgets.
 *
 * @extends LiquidNode
 */
class HeadyBrainsNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyBrains'] - Node name
   * @param {string} [config.domain='headyme.com'] - Domain identifier
   * @param {number[]} [config.embedding] - Initial 384D embedding
   */
  constructor(config = {}) {
    super({
      name: config.name || 'HeadyBrains',
      ring: 'inner',
      pool: 'hot',
      domain: 'headyme.com',
      capabilities: [
        'context-assembly',
        'pre-processing',
        'intent-extraction',
        'embedding-generation',
      ],
      ...config,
    });

    /** @type {LRUCache} Context cache bounded by fib(16) = 987 */
    this.contextCache = new LRUCache(SIZING.CACHE_SIZE);

    /** Token budgets derived from phi-geometric scaling */
    this.tokenBudgets = phiTokenBudgets();

    /** Known intent type embeddings for classification */
    this.intentEmbeddings = KNOWN_INTENTS;

    /** Classification accuracy tracker */
    this.classificationMetrics = {
      totalClassifications: 0,
      byIntent: {},
      avgConfidence: 0,
      lowConfidenceCount: 0,
    };

    /** Context assembly metrics */
    this.assemblyMetrics = {
      totalAssemblies: 0,
      cacheHits: 0,
      cacheMisses: 0,
      avgEntryCount: 0,
      avgTokenUsage: 0,
      capsulesBudgetExceeded: 0,
    };

    nodeBus.on('brains:assemble', (data) => this._onAssembleRequest(data));
    nodeBus.on('brains:classify', (data) => this._onClassifyRequest(data));
    this.cleanupStack.push(() => {
      nodeBus.removeAllListeners('brains:assemble');
      nodeBus.removeAllListeners('brains:classify');
    });
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Execute a brains task by type.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - assemble | classify | capsule | stats
   * @returns {Object} Task result
   */
  async execute(task) {
    switch (task.type) {
      case 'assemble': return this.assembleContext(task.request);
      case 'classify': return this.classifyIntent(task.text, task.embedding);
      case 'capsule':  return this.buildContextCapsule(task.entries, task.metadata);
      case 'stats':    return this.stats();
      default:
        throw new Error(`HeadyBrains: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // CONTEXT ASSEMBLY
  // ─────────────────────────────────────────────────────────────

  /**
   * Assemble all relevant context for a request.
   *
   * Scans vector memory, retrieves relevant node state, classifies intent,
   * and builds a context capsule sized by phi-geometric token budgets.
   *
   * @param {Object} request - Inbound request descriptor
   * @param {string} request.id - Request identifier
   * @param {string} request.text - Request text
   * @param {number[]} [request.embedding] - Pre-computed embedding
   * @param {string} [request.domain] - Target domain filter
   * @param {Object[]} [request.memoryEntries] - Vector memory results
   * @param {Object[]} [request.nodeStates] - Current node state snapshots
   * @returns {Object} Assembled context with capsule and intent classification
   */
  assembleContext(request) {
    const requestId = request.id || `req-${Date.now()}`;

    // Check cache
    const cacheKey = this._computeCacheKey(request);
    const cached = this.contextCache.get(cacheKey);
    if (cached) {
      this.assemblyMetrics.cacheHits++;
      this.logger.info({ requestId, cacheHit: true }, 'Context cache hit');
      return cached;
    }
    this.assemblyMetrics.cacheMisses++;

    // Classify intent
    const intent = request.embedding
      ? this.classifyIntent(request.text, request.embedding)
      : this.classifyIntent(request.text);

    // Gather context entries from memory and node states
    const contextEntries = [];

    // Score and include memory entries
    if (request.memoryEntries && request.memoryEntries.length > 0) {
      for (const entry of request.memoryEntries) {
        const relevance = request.embedding && entry.embedding
          ? cosineSimilarity(request.embedding, entry.embedding)
          : entry.relevance || CSL_THRESHOLDS.LOW;

        const gatedRelevance = cslGate(1.0, relevance, CSL_THRESHOLDS.MINIMUM);
        if (gatedRelevance > 0) {
          contextEntries.push({
            source: 'memory',
            content: entry.content,
            relevance: gatedRelevance,
            tokenCount: entry.tokenCount || this._estimateTokens(entry.content),
            embedding: entry.embedding,
            metadata: entry.metadata || {},
          });
        }
      }
    }

    // Score and include node state context
    if (request.nodeStates && request.nodeStates.length > 0) {
      for (const state of request.nodeStates) {
        const relevance = request.embedding && state.embedding
          ? cosineSimilarity(request.embedding, state.embedding)
          : CSL_THRESHOLDS.LOW;

        const gatedRelevance = cslGate(1.0, relevance, CSL_THRESHOLDS.MINIMUM);
        if (gatedRelevance > 0) {
          const stateContent = JSON.stringify({
            node: state.name,
            capabilities: state.capabilities,
            status: state.status,
          });
          contextEntries.push({
            source: 'node-state',
            content: stateContent,
            relevance: gatedRelevance,
            tokenCount: this._estimateTokens(stateContent),
            metadata: { node: state.name },
          });
        }
      }
    }

    // Sort by relevance descending and cap to rerank limit
    contextEntries.sort((a, b) => b.relevance - a.relevance);
    const topEntries = contextEntries.slice(0, SIZING.RERANK_TOP_K);

    // Build context capsule
    const capsule = this.buildContextCapsule(topEntries, {
      requestId,
      intent: intent.type,
      intentConfidence: intent.confidence,
      domain: request.domain,
    });

    const result = {
      requestId,
      intent,
      capsule,
      totalCandidates: contextEntries.length,
      selectedEntries: topEntries.length,
      timestamp: new Date().toISOString(),
    };

    // Update metrics
    this.assemblyMetrics.totalAssemblies++;
    const totalAssemblies = this.assemblyMetrics.totalAssemblies;
    this.assemblyMetrics.avgEntryCount =
      (this.assemblyMetrics.avgEntryCount * (totalAssemblies - 1) + topEntries.length) / totalAssemblies;
    this.assemblyMetrics.avgTokenUsage =
      (this.assemblyMetrics.avgTokenUsage * (totalAssemblies - 1) + capsule.totalTokens) / totalAssemblies;

    // Cache result
    this.contextCache.set(cacheKey, result);

    this.logger.info({
      requestId,
      intent: intent.type,
      candidates: contextEntries.length,
      selected: topEntries.length,
      tokens: capsule.totalTokens,
    }, 'Context assembled');

    nodeBus.emit('brains:assembled', { requestId, intent: intent.type, entryCount: topEntries.length });
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // INTENT CLASSIFICATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Classify task intent using CSL cosine scoring against known intent embeddings.
   *
   * If an embedding is provided, scores it against all known intent type
   * embeddings. Otherwise, falls back to keyword-based heuristic classification.
   * Tracks classification accuracy metrics over time.
   *
   * @param {string} text - Request text
   * @param {number[]} [embedding] - Pre-computed 384D embedding
   * @returns {Object} Classification result with type, confidence, and scores
   */
  classifyIntent(text, embedding) {
    const scores = [];

    if (embedding) {
      // Embedding-based classification via CSL cosine scoring
      for (const known of this.intentEmbeddings) {
        const similarity = cosineSimilarity(embedding, known.embedding);
        const gated = cslGate(1.0, similarity, CSL_THRESHOLDS.LOW);
        scores.push({ type: known.type, similarity, gated });
      }
    } else {
      // Keyword-based fallback classification
      const textLower = (text || '').toLowerCase();
      const keywordMap = {
        query:       ['find', 'search', 'look', 'get', 'what', 'where', 'how'],
        create:      ['create', 'build', 'generate', 'new', 'add', 'make'],
        modify:      ['modify', 'update', 'change', 'edit', 'alter', 'fix'],
        delete:      ['delete', 'remove', 'purge', 'clear', 'drop'],
        analyze:     ['analyze', 'evaluate', 'assess', 'review', 'examine'],
        plan:        ['plan', 'decompose', 'schedule', 'organize', 'break down'],
        validate:    ['validate', 'check', 'verify', 'confirm', 'test'],
        communicate: ['notify', 'share', 'report', 'send', 'tell'],
      };

      for (const [type, keywords] of Object.entries(keywordMap)) {
        const matchCount = keywords.filter(k => textLower.includes(k)).length;
        const similarity = matchCount / keywords.length;
        const gated = cslGate(1.0, similarity, CSL_THRESHOLDS.MINIMUM);
        scores.push({ type, similarity, gated });
      }
    }

    // Sort by gated score descending
    scores.sort((a, b) => b.gated - a.gated);
    const best = scores[0] || { type: 'query', similarity: 0, gated: 0 };
    const confidence = best.gated;

    // Update classification metrics
    this.classificationMetrics.totalClassifications++;
    const total = this.classificationMetrics.totalClassifications;
    this.classificationMetrics.avgConfidence =
      (this.classificationMetrics.avgConfidence * (total - 1) + confidence) / total;

    if (confidence < CSL_THRESHOLDS.LOW) {
      this.classificationMetrics.lowConfidenceCount++;
    }

    if (!this.classificationMetrics.byIntent[best.type]) {
      this.classificationMetrics.byIntent[best.type] = 0;
    }
    this.classificationMetrics.byIntent[best.type]++;

    this.logger.debug({
      intent: best.type,
      confidence: confidence.toFixed(4),
      topScores: scores.slice(0, fib(4)).map(s => ({ type: s.type, score: s.gated.toFixed(4) })),
    }, 'Intent classified');

    return {
      type: best.type,
      confidence,
      scores: scores.slice(0, fib(5)),
      method: embedding ? 'embedding' : 'keyword',
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // CONTEXT CAPSULE BUILDER
  // ─────────────────────────────────────────────────────────────

  /**
   * Package context entries for inter-node transfer with phi-geometric token budgets.
   *
   * Allocates a token budget from the working tier, filters entries by
   * relevance floor, and trims to fit within the budget while preserving
   * the highest-relevance entries.
   *
   * @param {Object[]} entries - Context entries with content, relevance, tokenCount
   * @param {Object} metadata - Capsule metadata (requestId, intent, domain)
   * @returns {ContextCapsule} Packaged context capsule
   */
  buildContextCapsule(entries, metadata) {
    const tokenBudget = this.tokenBudgets.working;
    const relevanceFloor = CSL_THRESHOLDS.MINIMUM;

    // Filter by relevance floor
    const eligible = (entries || [])
      .filter(e => (e.relevance || 0) >= relevanceFloor)
      .sort((a, b) => (b.relevance || 0) - (a.relevance || 0));

    // Greedily pack entries within token budget
    const packed = [];
    let usedTokens = 0;
    for (const entry of eligible) {
      const tokens = entry.tokenCount || this._estimateTokens(entry.content);
      if (usedTokens + tokens <= tokenBudget) {
        packed.push({ ...entry, tokenCount: tokens });
        usedTokens += tokens;
      }
    }

    const capsule = new ContextCapsule({
      requestId: metadata?.requestId || `req-${Date.now()}`,
      entries: packed,
      metadata: metadata || {},
      tokenBudget,
      relevanceFloor,
    });

    if (!capsule.withinBudget()) {
      this.assemblyMetrics.capsulesBudgetExceeded++;
      this.logger.warn({
        capsuleId: capsule.id,
        totalTokens: capsule.totalTokens,
        budget: tokenBudget,
      }, 'Capsule exceeds token budget');
    }

    this.logger.debug({ capsule: capsule.summary() }, 'Context capsule built');
    return capsule;
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & HEALTH
  // ─────────────────────────────────────────────────────────────

  /**
   * Return current operational statistics.
   * @returns {Object} Assembly and classification metrics
   */
  stats() {
    return {
      assembly: { ...this.assemblyMetrics },
      classification: { ...this.classificationMetrics },
      cache: {
        size: this.contextCache.size,
        maxSize: SIZING.CACHE_SIZE,
      },
      tokenBudgets: { ...this.tokenBudgets },
    };
  }

  /**
   * Override health to include brains-specific metrics.
   * @returns {Object} Health report with context and classification stats
   */
  health() {
    const base = super.health();
    return {
      ...base,
      brains: {
        assemblyMetrics: { ...this.assemblyMetrics },
        classificationMetrics: { ...this.classificationMetrics },
        cacheSize: this.contextCache.size,
        cacheMaxSize: SIZING.CACHE_SIZE,
        tokenBudgets: { ...this.tokenBudgets },
      },
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  /**
   * Estimate token count for a text string.
   * Uses a phi-scaled approximation: ~1 token per PHI² characters.
   * @param {string} text
   * @returns {number} Estimated token count
   */
  _estimateTokens(text) {
    if (!text) return 0;
    const charsPerToken = PHI * PHI;
    return Math.ceil(text.length / charsPerToken);
  }

  /**
   * Compute a cache key for a request.
   * Combines request text hash with domain for deduplication.
   * @param {Object} request
   * @returns {string} Cache key
   */
  _computeCacheKey(request) {
    let hash = 0;
    const str = `${request.text || ''}:${request.domain || ''}`;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << fib(5)) - hash + str.charCodeAt(i)) | 0;
    }
    return `ctx_${hash}`;
  }

  /**
   * Handle incoming assembly requests via nodeBus.
   * @param {Object} data - Assembly request data
   */
  _onAssembleRequest(data) {
    try {
      const result = this.assembleContext(data.request || data);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Assemble request failed');
    }
  }

  /**
   * Handle incoming classification requests via nodeBus.
   * @param {Object} data - Classification request data
   */
  _onClassifyRequest(data) {
    try {
      const result = this.classifyIntent(data.text, data.embedding);
      if (data.replyTo) nodeBus.emit(data.replyTo, result);
    } catch (err) {
      this.logger.error({ error: err.message }, 'Classify request failed');
    }
  }
}

export { HeadyBrainsNode, HeadyBrainsNode as HeadyBrains };
