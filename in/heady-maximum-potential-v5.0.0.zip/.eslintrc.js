/**
 * Heady Platform — ESLint Configuration
 *
 * Enforces Heady Unbreakable Laws:
 * - No console.log in production
 * - No magic numbers (use phi-math-foundation)
 * - No wildcard CORS
 *
 * @module .eslintrc
 * @author Eric Haywood — HeadySystems Inc.
 */

export default {
  env: {
    node: true,
    es2024: true,
    jest: true,
  },
  parserOptions: {
    ecmaVersion: 2024,
    sourceType: 'module',
  },
  rules: {
    // === Heady Unbreakable Laws ===

    // No console.log in production (use structured-logger)
    'no-console': ['error', { allow: ['warn', 'error'] }],

    // No empty catch blocks
    'no-empty': ['error', { allowEmptyCatch: false }],

    // No unused variables
    'no-unused-vars': ['warn', { argsIgnorePattern: '^_', varsIgnorePattern: '^_' }],

    // Require const/let, no var
    'no-var': 'error',
    'prefer-const': 'error',

    // Strict equality
    eqeqeq: ['error', 'always'],

    // No eval (security)
    'no-eval': 'error',
    'no-implied-eval': 'error',

    // No with statements
    'no-with': 'error',

    // Require error handling in callbacks
    'no-throw-literal': 'error',

    // No debugger in production
    'no-debugger': 'error',

    // Consistent return
    'consistent-return': 'warn',

    // No duplicate imports
    'no-duplicate-imports': 'error',

    // Arrow function bodies
    'arrow-body-style': ['warn', 'as-needed'],

    // Template literals over string concatenation
    'prefer-template': 'warn',

    // Object shorthand
    'object-shorthand': 'warn',

    // Spacing and formatting
    'semi': ['error', 'always'],
    'comma-dangle': ['warn', 'always-multiline'],
    'quotes': ['warn', 'single', { avoidEscape: true }],
  },
  overrides: [
    {
      // Test files can use console for debugging
      files: ['tests/**/*.js', '**/*.test.js', '**/*.spec.js'],
      rules: {
        'no-console': 'off',
      },
    },
    {
      // Scripts can use console
      files: ['scripts/**/*.js', 'scripts/**/*.sh'],
      rules: {
        'no-console': 'off',
      },
    },
  ],
  ignorePatterns: [
    'node_modules/',
    'dist/',
    'coverage/',
    'ui/**/*.js', // UI scripts are inline, not linted by Node ESLint
  ],
};
