/**
 * Heady Platform — Jest Configuration
 *
 * ES module support, phi-scaled test timeouts.
 *
 * @module jest.config
 * @author Eric Haywood — HeadySystems Inc.
 */

const PHI = 1.618033988749895;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];

export default {
  // ES module support
  transform: {},
  extensionsToTreatAsEsm: [],

  // Test discovery
  testMatch: [
    '<rootDir>/tests/**/*.test.js',
    '<rootDir>/tests/**/*.spec.js',
  ],

  // Coverage
  collectCoverageFrom: [
    'core/**/*.js',
    'packages/*/src/**/*.js',
    'services/*/src/**/*.js',
    'shared/**/*.js',
    '!**/index.js', // barrel exports excluded
    '!**/node_modules/**',
  ],

  coverageDirectory: 'coverage',
  coverageReporters: ['text', 'lcov', 'clover'],

  // Phi-scaled timeouts
  testTimeout: Math.round(PHI * FIB[8] * 1000), // ≈ 33,978ms ≈ 34s

  // Module resolution for monorepo
  moduleNameMapper: {
    '^@heady/phi-math-foundation$': '<rootDir>/packages/phi-math-foundation/src/index.js',
    '^@heady/structured-logger$': '<rootDir>/packages/structured-logger/src/index.js',
    '^@heady/health-probes$': '<rootDir>/packages/health-probes/src/index.js',
    '^@heady/schema-registry$': '<rootDir>/packages/schema-registry/src/index.js',
  },

  // Environment
  testEnvironment: 'node',

  // Parallel execution
  maxWorkers: FIB[5], // 5 workers

  // Verbose output
  verbose: true,
};
