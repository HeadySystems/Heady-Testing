/**
 * HiveBootstrap — Heady System Bootstrap & Node Wiring
 *
 * Initializes the entire Heady node ecosystem: creates the NodeRegistry,
 * instantiates all liquid nodes, wires them together via HeadyConductor,
 * and starts the self-healing heartbeat loop. This is the single entry point
 * for bringing up the Heady Hive in any runtime (Cloud Run, Colab, Cloudflare).
 *
 * Sacred Geometry v4.0 — Zero Magic Numbers
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import {
  PHI, PSI, FIB,
  CSL_THRESHOLDS,
  phiBackoff, phiFusionWeights,
  cslGate
} from '../shared/phi-constants.js';

import { LiquidNode, NodeRegistry, HeadyError } from '../shared/liquid-node.js';

// ─── Node Imports ─────────────────────────────────────────────────────────────

import { WisdomStore } from '../nodes/wisdom-store.js';
import { BudgetTracker } from '../nodes/budget-tracker.js';
import { HeadyLens } from '../nodes/heady-lens.js';
import { CouncilMode } from '../nodes/council-mode.js';
import { EvolutionEngine } from '../nodes/evolution-engine.js';
import { PersonaRouter } from '../nodes/persona-router.js';
import { AutoSuccessEngine } from '../nodes/auto-success-engine.js';
import { HeadyConductor } from './conductor.js';

// ─── Sacred Geometry Topology ─────────────────────────────────────────────────

const TOPOLOGY = Object.freeze({
  CENTER: {
    ring: 'center',
    nodes: ['HeadySoul'],
    description: 'Awareness layer, values arbiter, coherence guardian',
  },
  INNER: {
    ring: 'inner',
    nodes: ['HeadyBrains', 'HeadyConductor', 'HeadyVinci', 'AutoSuccessEngine'],
    description: 'Processing core — orchestration, planning, pipeline execution',
  },
  MIDDLE: {
    ring: 'middle',
    nodes: ['JULES', 'BUILDER', 'OBSERVER', 'MURPHY', 'ATLAS', 'PYTHIA', 'CouncilMode'],
    description: 'Execution layer — code gen, review, security, architecture',
  },
  OUTER: {
    ring: 'outer',
    nodes: [
      'BRIDGE', 'MUSE', 'SENTINEL', 'NOVA', 'JANITOR', 'SOPHIA',
      'CIPHER', 'LENS', 'PersonaRouter', 'EvolutionEngine',
    ],
    description: 'Specialized capabilities — creative, security, persona, evolution',
  },
  GOVERNANCE: {
    ring: 'governance',
    nodes: ['HeadyCheck', 'HeadyAssure', 'HeadyAware', 'HeadyPatterns', 'HeadyMC', 'HeadyRisks'],
    description: 'Quality gates, pattern capture, risk assessment',
  },
  MEMORY: {
    ring: 'memory',
    nodes: ['HeadyMemory', 'HeadyEmbed', 'WisdomStore', 'HeadyAutobiographer'],
    description: 'Vector memory, embeddings, knowledge graph, narrative',
  },
  OPS: {
    ring: 'ops',
    nodes: ['HeadyLens', 'BudgetTracker', 'HeadyMaid', 'HeadyMaintenance'],
    description: 'Observability, cost management, cleanup, maintenance',
  },
});

// ─── Heartbeat Configuration ────────────────────────────────────────────────

const HEARTBEAT_CONFIG = Object.freeze({
  intervalMs:          FIB[8] * 1000,         // 21s between heartbeats
  driftThreshold:      CSL_THRESHOLDS.MEDIUM, // 0.809 — below = alert
  criticalThreshold:   CSL_THRESHOLDS.LOW,    // 0.691 — below = self-heal
  maxHealAttempts:     FIB[4],                // 3 heal attempts
  healBackoffBaseMs:   FIB[7] * 1000,         // 13s base backoff
});

// ─── HiveBootstrap ──────────────────────────────────────────────────────────

export class HiveBootstrap {
  /**
   * @param {Object} config
   * @param {string} [config.runtime] - 'cloud-run' | 'colab' | 'cloudflare' | 'local'
   * @param {Object} [config.env] - Environment variables
   * @param {boolean} [config.heartbeatEnabled] - Enable self-healing heartbeat
   * @param {boolean} [config.arenaEnabled] - Enable arena mode in AutoSuccessEngine
   */
  constructor(config = {}) {
    this.runtime = config.runtime || 'local';
    this.env = config.env || process.env || {};
    this.heartbeatEnabled = config.heartbeatEnabled !== false;
    this.arenaEnabled = config.arenaEnabled || false;

    /** @type {NodeRegistry} */
    this.registry = new NodeRegistry();

    /** @type {HeadyConductor|null} */
    this.conductor = null;

    /** @type {AutoSuccessEngine|null} */
    this.autoSuccess = null;

    /** @type {Map<string, LiquidNode>} All instantiated nodes */
    this._nodes = new Map();

    /** @type {NodeJS.Timeout|null} Heartbeat interval */
    this._heartbeatTimer = null;

    /** Bootstrap telemetry */
    this._bootMetrics = {
      startedAt: null,
      completedAt: null,
      nodesSpawned: 0,
      nodesFailed: 0,
      heartbeats: 0,
      healAttempts: 0,
    };

    /** Shutdown handlers (LIFO) */
    this._cleanups = [];
  }

  // ─── Bootstrap ──────────────────────────────────────────────────────────────

  /**
   * Boot the entire Heady Hive. Call this once at startup.
   * @returns {Promise<BootResult>}
   */
  async boot() {
    this._bootMetrics.startedAt = Date.now();
    const log = (msg, data) => console.log(JSON.stringify({ level: 'info', service: 'HiveBootstrap', msg, ...data, ts: new Date().toISOString() }));

    log('Booting Heady Hive', { runtime: this.runtime, heartbeatEnabled: this.heartbeatEnabled });

    // Phase 1: Instantiate all liquid nodes
    const nodes = this._createNodes();

    // Phase 2: Spawn all nodes concurrently (independent — no data deps)
    const spawnResults = await this._spawnAll(nodes);

    // Phase 3: Wire conductor references
    this._wireConductor();

    // Phase 4: Start heartbeat if enabled
    if (this.heartbeatEnabled) {
      this._startHeartbeat();
    }

    // Phase 5: Register graceful shutdown
    this._registerShutdown();

    this._bootMetrics.completedAt = Date.now();
    const bootDurationMs = this._bootMetrics.completedAt - this._bootMetrics.startedAt;

    log('Heady Hive booted', {
      nodesSpawned: this._bootMetrics.nodesSpawned,
      nodesFailed: this._bootMetrics.nodesFailed,
      bootDurationMs,
      runtime: this.runtime,
    });

    return {
      status: this._bootMetrics.nodesFailed === 0 ? 'healthy' : 'degraded',
      runtime: this.runtime,
      nodesSpawned: this._bootMetrics.nodesSpawned,
      nodesFailed: this._bootMetrics.nodesFailed,
      bootDurationMs,
      topology: this._getTopologyStatus(),
    };
  }

  // ─── Node Creation ────────────────────────────────────────────────────────

  /**
   * Create all liquid node instances.
   */
  _createNodes() {
    const nodeConfigs = [
      // Inner Ring (Processing Core)
      { Class: HeadyConductor, config: { nodeRegistry: this.registry } },
      { Class: AutoSuccessEngine, config: { nodeRegistry: this.registry, arenaEnabled: this.arenaEnabled } },

      // Memory & Intelligence
      { Class: WisdomStore, config: {} },

      // Ops & Observability
      { Class: BudgetTracker, config: {} },
      { Class: HeadyLens, config: {} },

      // Execution Layer
      { Class: CouncilMode, config: {} },

      // Specialized
      { Class: EvolutionEngine, config: {} },
      { Class: PersonaRouter, config: {} },
    ];

    const nodes = [];
    for (const { Class, config } of nodeConfigs) {
      try {
        const node = new Class(config);
        this._nodes.set(node.name, node);
        nodes.push(node);

        // Track special references
        if (node instanceof HeadyConductor) this.conductor = node;
        if (node instanceof AutoSuccessEngine) this.autoSuccess = node;
      } catch (err) {
        console.error(JSON.stringify({
          level: 'error',
          service: 'HiveBootstrap',
          msg: `Failed to create node: ${Class.name}`,
          error: err.message,
          ts: new Date().toISOString(),
        }));
        this._bootMetrics.nodesFailed++;
      }
    }

    return nodes;
  }

  /**
   * Spawn all nodes concurrently — they are independent.
   */
  async _spawnAll(nodes) {
    const results = await Promise.allSettled(
      nodes.map(async (node) => {
        try {
          await node.spawn({ runtime: this.runtime, env: this.env });
          this.registry.register(node);
          this._bootMetrics.nodesSpawned++;
          return { node: node.name, status: 'spawned' };
        } catch (err) {
          this._bootMetrics.nodesFailed++;
          console.error(JSON.stringify({
            level: 'error',
            service: 'HiveBootstrap',
            msg: `Failed to spawn ${node.name}`,
            error: err.message,
            ts: new Date().toISOString(),
          }));
          return { node: node.name, status: 'failed', error: err.message };
        }
      })
    );

    return results.map(r => r.status === 'fulfilled' ? r.value : { status: 'failed', error: r.reason?.message });
  }

  /**
   * Wire the conductor with references to all registered nodes.
   */
  _wireConductor() {
    if (!this.conductor) return;
    this.conductor.nodeRegistry = this.registry;

    // AutoSuccessEngine also needs registry
    if (this.autoSuccess) {
      this.autoSuccess.nodeRegistry = this.registry;
    }
  }

  // ─── Heartbeat (Self-Healing) ─────────────────────────────────────────────

  _startHeartbeat() {
    this._heartbeatTimer = setInterval(() => {
      this._runHeartbeat().catch(err => {
        console.error(JSON.stringify({
          level: 'error',
          service: 'HiveBootstrap',
          msg: 'Heartbeat error',
          error: err.message,
          ts: new Date().toISOString(),
        }));
      });
    }, HEARTBEAT_CONFIG.intervalMs);

    // Register cleanup
    this._cleanups.unshift({
      name: 'heartbeat',
      fn: () => {
        if (this._heartbeatTimer) {
          clearInterval(this._heartbeatTimer);
          this._heartbeatTimer = null;
        }
      },
    });
  }

  async _runHeartbeat() {
    this._bootMetrics.heartbeats++;

    const reports = [];
    for (const [name, node] of this._nodes) {
      try {
        if (typeof node.report === 'function') {
          const report = await node.report();
          reports.push({ name, ...report });
        } else {
          reports.push({ name, state: node.state || 'unknown' });
        }
      } catch (err) {
        reports.push({ name, state: 'error', error: err.message });
      }
    }

    // Check for coherence drift
    const drifted = reports.filter(r => {
      const score = r.coherenceScore || r.healthRatio || 1.0;
      return score < HEARTBEAT_CONFIG.driftThreshold;
    });

    if (drifted.length > 0) {
      console.warn(JSON.stringify({
        level: 'warn',
        service: 'HiveBootstrap',
        msg: 'Coherence drift detected',
        driftedNodes: drifted.map(d => ({ name: d.name, score: d.coherenceScore || d.healthRatio })),
        ts: new Date().toISOString(),
      }));

      // Critical drift → attempt self-healing
      const critical = drifted.filter(r => {
        const score = r.coherenceScore || r.healthRatio || 1.0;
        return score < HEARTBEAT_CONFIG.criticalThreshold;
      });

      for (const node of critical) {
        await this._healNode(node.name);
      }
    }
  }

  /**
   * Attempt to heal a drifted node by retiring and re-spawning.
   */
  async _healNode(nodeName) {
    this._bootMetrics.healAttempts++;
    const node = this._nodes.get(nodeName);
    if (!node) return;

    console.warn(JSON.stringify({
      level: 'warn',
      service: 'HiveBootstrap',
      msg: `Healing node: ${nodeName}`,
      ts: new Date().toISOString(),
    }));

    for (let attempt = 0; attempt < HEARTBEAT_CONFIG.maxHealAttempts; attempt++) {
      try {
        // Retire the unhealthy node
        if (typeof node.retire === 'function') {
          await node.retire();
        }
        this.registry.unregister(nodeName);

        // Re-spawn
        await node.spawn({ runtime: this.runtime, env: this.env });
        this.registry.register(node);

        console.log(JSON.stringify({
          level: 'info',
          service: 'HiveBootstrap',
          msg: `Node healed: ${nodeName}`,
          attempt: attempt + 1,
          ts: new Date().toISOString(),
        }));
        return;

      } catch (err) {
        const delay = phiBackoff(attempt, HEARTBEAT_CONFIG.healBackoffBaseMs);
        console.error(JSON.stringify({
          level: 'error',
          service: 'HiveBootstrap',
          msg: `Heal attempt ${attempt + 1} failed for ${nodeName}`,
          error: err.message,
          retryDelayMs: delay,
          ts: new Date().toISOString(),
        }));
        await new Promise(r => setTimeout(r, delay));
      }
    }

    console.error(JSON.stringify({
      level: 'error',
      service: 'HiveBootstrap',
      msg: `Failed to heal ${nodeName} after ${HEARTBEAT_CONFIG.maxHealAttempts} attempts`,
      ts: new Date().toISOString(),
    }));
  }

  // ─── Graceful Shutdown ────────────────────────────────────────────────────

  _registerShutdown() {
    // Register node retirements as cleanup (LIFO order — outer first, inner last)
    const rings = ['governance', 'ops', 'outer', 'middle', 'memory', 'inner', 'center'];
    for (const ring of rings) {
      const ringConfig = Object.values(TOPOLOGY).find(t => t.ring === ring);
      if (!ringConfig) continue;

      for (const nodeName of ringConfig.nodes) {
        const node = this._nodes.get(nodeName);
        if (node && typeof node.retire === 'function') {
          this._cleanups.push({
            name: `retire-${nodeName}`,
            fn: () => node.retire(),
          });
        }
      }
    }

    const shutdown = async (signal) => {
      console.log(JSON.stringify({
        level: 'info',
        service: 'HiveBootstrap',
        msg: `Graceful shutdown initiated: ${signal}`,
        ts: new Date().toISOString(),
      }));

      for (const { name, fn } of this._cleanups) {
        try {
          await fn();
          console.log(JSON.stringify({
            level: 'info',
            service: 'HiveBootstrap',
            msg: `Cleanup complete: ${name}`,
            ts: new Date().toISOString(),
          }));
        } catch (err) {
          console.error(JSON.stringify({
            level: 'error',
            service: 'HiveBootstrap',
            msg: `Cleanup failed: ${name}`,
            error: err.message,
            ts: new Date().toISOString(),
          }));
        }
      }

      process.exit(0);
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
  }

  // ─── Queries ──────────────────────────────────────────────────────────────

  /**
   * Get current topology status with coherence scores per ring.
   */
  _getTopologyStatus() {
    const status = {};
    for (const [key, ringConfig] of Object.entries(TOPOLOGY)) {
      const nodeStatuses = ringConfig.nodes.map(name => {
        const node = this._nodes.get(name);
        return {
          name,
          state: node?.state || 'not-instantiated',
          registered: this.registry.hasNode ? this.registry.hasNode(name) : this._nodes.has(name),
        };
      });
      status[key] = {
        ring: ringConfig.ring,
        description: ringConfig.description,
        nodes: nodeStatuses,
        activeCount: nodeStatuses.filter(n => n.state === 'ACTIVE').length,
        totalCount: nodeStatuses.length,
      };
    }
    return status;
  }

  /**
   * Get a node by name from the registry.
   */
  getNode(name) {
    return this._nodes.get(name) || null;
  }

  /**
   * Get the conductor node.
   */
  getConductor() {
    return this.conductor;
  }

  /**
   * Get the auto-success engine.
   */
  getAutoSuccess() {
    return this.autoSuccess;
  }

  /**
   * Full system health check.
   */
  async healthCheck() {
    const nodeReports = [];
    for (const [name, node] of this._nodes) {
      try {
        if (typeof node.healthCheck === 'function') {
          nodeReports.push({ name, health: await node.healthCheck() });
        } else if (typeof node.report === 'function') {
          nodeReports.push({ name, health: await node.report() });
        } else {
          nodeReports.push({ name, health: { state: node.state || 'unknown' } });
        }
      } catch (err) {
        nodeReports.push({ name, health: { state: 'error', error: err.message } });
      }
    }

    const healthyCount = nodeReports.filter(r =>
      r.health?.status === 'healthy' || r.health?.state === 'ACTIVE'
    ).length;
    const totalCount = nodeReports.length;
    const healthRatio = totalCount > 0 ? healthyCount / totalCount : 0;

    return {
      status: healthRatio >= PSI ? 'healthy' : (healthRatio >= PSI * PSI ? 'degraded' : 'unhealthy'),
      healthRatio,
      runtime: this.runtime,
      uptime: Date.now() - (this._bootMetrics.startedAt || Date.now()),
      nodes: nodeReports,
      metrics: { ...this._bootMetrics },
    };
  }
}

// ─── Quick Boot Helper ──────────────────────────────────────────────────────

/**
 * Boot the Heady Hive with a single function call.
 * @param {Object} [options] - Override defaults
 * @returns {Promise<{ hive: HiveBootstrap, bootResult: Object }>}
 */
export async function bootHive(options = {}) {
  const hive = new HiveBootstrap(options);
  const bootResult = await hive.boot();
  return { hive, bootResult };
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export { TOPOLOGY, HEARTBEAT_CONFIG };
export default HiveBootstrap;
