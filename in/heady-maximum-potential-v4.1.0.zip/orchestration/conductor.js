/**
 * HeadyConductor — Central Orchestration Engine
 *
 * The Conductor is the routing authority for all Heady pipeline executions.
 * Classifies tasks via CSL cosine scoring, routes to optimal nodes, manages
 * the full HCFullPipeline lifecycle, and coordinates HeadyBee swarms.
 *
 * Sacred Geometry v4.0 — Zero Magic Numbers
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import {
  PHI, PSI, PHI2, PHI3, FIB,
  CSL_THRESHOLDS, DEDUP_THRESHOLD,
  PRESSURE_LEVELS, POOL_ALLOCATION,
  phiThreshold, phiBackoff, phiFusionWeights,
  cslGate, cslBlend, cslAND, cslOR, cslNOT, cslIMPLY,
  cslCONSENSUS, fibIndex, phiTokenBudgets
} from '../shared/phi-constants.js';

import { LiquidNode, CircuitBreaker, HeadyError, NodeRegistry } from '../shared/liquid-node.js';

// ─── Routing Matrix ─────────────────────────────────────────────────────────

const ROUTING_MATRIX = Object.freeze({
  'code-generation':  { primary: ['JULES', 'BUILDER'],             fallback1: ['GPT4o', 'BUILDER'],     fallback2: ['GroqLlama'],        pool: 'hot' },
  'code-review':      { primary: ['OBSERVER'],                     fallback1: ['GPT4o'],                fallback2: ['GeminiPro'],        pool: 'hot' },
  'security-audit':   { primary: ['MURPHY', 'CIPHER'],             fallback1: ['GPT4o'],                fallback2: ['ClaudeOpus'],       pool: 'hot' },
  'architecture':     { primary: ['ATLAS', 'PYTHIA', 'HeadyVinci'],fallback1: ['GPT4o', 'HeadyVinci'],  fallback2: ['ClaudeSonnet'],     pool: 'hot' },
  'research':         { primary: ['HeadyResearch', 'SOPHIA'],      fallback1: ['ClaudeSonnet'],         fallback2: ['GPT4o'],            pool: 'warm' },
  'documentation':    { primary: ['ATLAS', 'HeadyCodex'],          fallback1: ['ClaudeSonnet'],         fallback2: ['GeminiPro'],        pool: 'warm' },
  'quick-task':       { primary: ['GroqLlama'],                    fallback1: ['GPT4oMini'],            fallback2: ['GeminiFlash'],      pool: 'hot' },
  'creative':         { primary: ['MUSE', 'NOVA'],                 fallback1: ['GPT4o', 'NOVA'],        fallback2: ['GeminiPro'],        pool: 'warm' },
  'cleanup':          { primary: ['JANITOR', 'HeadyMaid'],         fallback1: ['HeadyMaintenance'],     fallback2: [],                   pool: 'cold' },
  'analytics':        { primary: ['HeadyPatterns', 'HeadyMC'],     fallback1: ['DuckDBLocal'],          fallback2: [],                   pool: 'cold' },
  'embeddings':       { primary: ['CloudflareEdge'],               fallback1: ['NomicV2'],              fallback2: ['LocalOllama'],       pool: 'hot' },
  'monitoring':       { primary: ['OBSERVER', 'LENS', 'SENTINEL'], fallback1: ['HeadyLens'],            fallback2: [],                   pool: 'warm' },
  'translation':      { primary: ['BRIDGE'],                       fallback1: ['GPT4o'],                fallback2: ['GeminiPro'],        pool: 'warm' },
});

// ─── Edge-Origin Complexity Routing ─────────────────────────────────────────

const COMPLEXITY_ROUTES = Object.freeze({
  EDGE_ONLY:      { max: PSI * PSI, label: 'edge-only' },       // < 0.382
  EDGE_PREFERRED: { max: PSI,       label: 'edge-preferred' },  // 0.382–0.618
  ORIGIN_REQUIRED:{ max: 1.0,       label: 'origin-required' }, // > 0.618
});

// ─── Task Classification Embeddings (Simulated 384D → compressed keys) ──────

const TASK_TYPE_KEYS = Object.keys(ROUTING_MATRIX);

// ─── HeadyConductor ─────────────────────────────────────────────────────────

export class HeadyConductor extends LiquidNode {
  /**
   * @param {Object} config
   * @param {NodeRegistry} [config.nodeRegistry]
   * @param {number} [config.maxPendingTasks] - fib(13)=233
   * @param {number} [config.classificationCacheSize] - fib(16)=987
   */
  constructor(config = {}) {
    super({
      name: 'HeadyConductor',
      version: '4.1.0',
      pool: 'hot',
      ring: 'inner',
      ...config,
    });

    this.nodeRegistry = config.nodeRegistry || null;

    /** Max pending tasks before backpressure */
    this.maxPendingTasks = config.maxPendingTasks || FIB[13]; // 233

    /** Classification result cache (LRU) */
    this._classificationCacheSize = config.classificationCacheSize || FIB[16]; // 987
    this._classificationCache = new Map();

    /** @type {Map<string, CircuitBreaker>} Per-node circuit breakers */
    this._nodeBreakers = new Map();

    /** @type {Array<Object>} Pending task queue */
    this._taskQueue = [];

    /** @type {number} Tasks currently being routed */
    this._activeRoutings = 0;
    this._maxActiveRoutings = FIB[6]; // 8 concurrent routings

    /** Routing telemetry */
    this._routingMetrics = {
      totalClassified: 0,
      totalRouted: 0,
      fallbacksUsed: 0,
      cacheHits: 0,
      backpressureEvents: 0,
    };

    /** Route override table (from ArenaMode promotions) */
    this._routeOverrides = new Map();
  }

  // ─── Lifecycle ──────────────────────────────────────────────────────────────

  async spawn(context = {}) {
    this._log('info', 'Spawning HeadyConductor', {
      maxPendingTasks: this.maxPendingTasks,
      routingMatrixSize: TASK_TYPE_KEYS.length,
    });

    if (this.nodeRegistry && typeof this.nodeRegistry.register === 'function') {
      this.nodeRegistry.register(this);
    }

    this._setState('ACTIVE');
    return { status: 'spawned', node: this.name };
  }

  async execute(task) {
    if (!task || !task.type) {
      throw new HeadyError('Task must include a type field', 400, 'INVALID_TASK');
    }

    // Backpressure check
    if (this._taskQueue.length >= this.maxPendingTasks) {
      this._routingMetrics.backpressureEvents++;
      throw new HeadyError(
        `Conductor backpressure: ${this._taskQueue.length} pending tasks`,
        429,
        'CONDUCTOR_BACKPRESSURE'
      );
    }

    // Classify → Route → Dispatch
    const classification = this.classify(task);
    const route = this.route(classification, task);
    const result = await this.dispatch(route, task);

    return result;
  }

  async report() {
    return {
      node: this.name,
      state: this.state,
      version: this.version,
      pendingTasks: this._taskQueue.length,
      activeRoutings: this._activeRoutings,
      metrics: { ...this._routingMetrics },
      routeOverrides: this._routeOverrides.size,
      cacheSize: this._classificationCache.size,
      nodeBreakers: this._getBreakersStatus(),
    };
  }

  async retire() {
    this._log('info', 'Retiring HeadyConductor', { pendingTasks: this._taskQueue.length });
    this._taskQueue = [];
    this._classificationCache.clear();
    this._routeOverrides.clear();

    if (this.nodeRegistry && typeof this.nodeRegistry.unregister === 'function') {
      this.nodeRegistry.unregister(this.name);
    }

    this._setState('RETIRED');
    return { status: 'retired', metrics: { ...this._routingMetrics } };
  }

  // ─── Classification ─────────────────────────────────────────────────────────

  /**
   * Classify a task by type and compute complexity score.
   * Uses CSL cosine scoring against the routing matrix keys.
   */
  classify(task) {
    const cacheKey = `${task.type}:${task.domain || ''}`;

    // Cache check
    if (this._classificationCache.has(cacheKey)) {
      this._routingMetrics.cacheHits++;
      return this._classificationCache.get(cacheKey);
    }

    this._routingMetrics.totalClassified++;

    // Direct match against routing matrix
    const taskType = this._matchTaskType(task.type);
    const complexity = this._estimateComplexity(task);
    const computeRoute = this._computeRouteForComplexity(complexity);

    const classification = {
      taskType,
      domain: task.domain || 'general',
      complexity,
      computeRoute,
      pool: ROUTING_MATRIX[taskType]?.pool || 'warm',
      confidence: taskType === task.type ? 1.0 : CSL_THRESHOLDS.HIGH,
      timestamp: Date.now(),
    };

    // LRU cache insert
    this._classificationCache.set(cacheKey, classification);
    if (this._classificationCache.size > this._classificationCacheSize) {
      const firstKey = this._classificationCache.keys().next().value;
      this._classificationCache.delete(firstKey);
    }

    return classification;
  }

  /**
   * Match task type string to closest routing matrix key.
   * Uses string similarity as a simplified CSL proxy.
   */
  _matchTaskType(type) {
    const normalized = type.toLowerCase().replace(/[_\s]+/g, '-');
    if (ROUTING_MATRIX[normalized]) return normalized;

    // Fuzzy match: find best overlap
    let bestMatch = 'quick-task'; // default fallback
    let bestScore = 0;

    for (const key of TASK_TYPE_KEYS) {
      const score = this._stringSimilarity(normalized, key);
      if (score > bestScore) {
        bestScore = score;
        bestMatch = key;
      }
    }

    return bestScore >= CSL_THRESHOLDS.LOW ? bestMatch : 'quick-task';
  }

  /**
   * Simple Jaccard-like string similarity for task matching.
   */
  _stringSimilarity(a, b) {
    const setA = new Set(a.split('-'));
    const setB = new Set(b.split('-'));
    let intersection = 0;
    for (const token of setA) {
      if (setB.has(token)) intersection++;
    }
    const union = setA.size + setB.size - intersection;
    return union > 0 ? intersection / union : 0;
  }

  /**
   * Estimate task complexity on a [0,1] scale using heuristics.
   */
  _estimateComplexity(task) {
    let score = PSI * PSI; // 0.382 baseline

    // Context length increases complexity
    if (task.contextLength) {
      const tokens = phiTokenBudgets();
      score += (task.contextLength / tokens.memory) * PSI; // scaled by memory budget
    }

    // Multi-step tasks are more complex
    if (task.steps && task.steps > 1) {
      score += Math.min(task.steps / FIB[6], PSI) * PSI; // up to PSI^2 addition
    }

    // Explicit complexity hints
    if (task.complexity === 'high' || task.complexity === 'origin-required') {
      score = Math.max(score, PSI + 0.01); // force origin-required
    }
    if (task.complexity === 'low' || task.complexity === 'edge-only') {
      score = Math.min(score, PSI * PSI - 0.01); // force edge-only
    }

    return Math.min(score, 1.0);
  }

  /**
   * Determine compute route (edge/origin) based on complexity score.
   */
  _computeRouteForComplexity(complexity) {
    if (complexity < COMPLEXITY_ROUTES.EDGE_ONLY.max) return 'edge-only';
    if (complexity < COMPLEXITY_ROUTES.EDGE_PREFERRED.max) return 'edge-preferred';
    return 'origin-required';
  }

  // ─── Routing ────────────────────────────────────────────────────────────────

  /**
   * Route a classified task to the optimal node chain.
   */
  route(classification, task) {
    this._routingMetrics.totalRouted++;

    const { taskType } = classification;

    // Check for arena-promoted override
    if (this._routeOverrides.has(taskType)) {
      const override = this._routeOverrides.get(taskType);
      this._log('info', 'Using arena-promoted route override', { taskType, override: override.nodes });
      return {
        nodes: override.nodes,
        fallbackChain: ROUTING_MATRIX[taskType]?.primary || [],
        pool: classification.pool,
        computeRoute: classification.computeRoute,
        source: 'arena-override',
      };
    }

    const matrixEntry = ROUTING_MATRIX[taskType] || ROUTING_MATRIX['quick-task'];

    // Build fallback chain: primary → fallback1 → fallback2
    const primaryNodes = this._filterAvailableNodes(matrixEntry.primary);
    const fallback1 = this._filterAvailableNodes(matrixEntry.fallback1);
    const fallback2 = this._filterAvailableNodes(matrixEntry.fallback2);

    let selectedNodes = primaryNodes;
    let source = 'primary';

    if (selectedNodes.length === 0) {
      selectedNodes = fallback1;
      source = 'fallback1';
      this._routingMetrics.fallbacksUsed++;
      this._log('warn', 'Primary nodes unavailable, using fallback1', { taskType });
    }

    if (selectedNodes.length === 0) {
      selectedNodes = fallback2;
      source = 'fallback2';
      this._log('warn', 'Fallback1 unavailable, using fallback2', { taskType });
    }

    if (selectedNodes.length === 0) {
      selectedNodes = ['HeadyConductor']; // self-handle as last resort
      source = 'self-fallback';
      this._log('error', 'All nodes unavailable for task type', { taskType });
    }

    return {
      nodes: selectedNodes,
      fallbackChain: [...fallback1, ...fallback2],
      pool: matrixEntry.pool,
      computeRoute: classification.computeRoute,
      source,
    };
  }

  /**
   * Filter node list to only those whose circuit breakers allow execution.
   */
  _filterAvailableNodes(nodeNames) {
    return (nodeNames || []).filter(name => {
      const breaker = this._nodeBreakers.get(name);
      if (!breaker) return true; // no breaker = assume healthy
      return breaker.canExecute();
    });
  }

  // ─── Dispatch ─────────────────────────────────────────────────────────────

  /**
   * Dispatch a task to the routed nodes and collect results.
   */
  async dispatch(route, task) {
    this._activeRoutings++;

    try {
      const { nodes, pool, computeRoute } = route;

      // For hot pool: execute primary node, with fallback on failure
      // For warm/cold: try nodes sequentially
      for (const nodeName of nodes) {
        try {
          const result = await this._executeOnNode(nodeName, task, pool);
          this._recordNodeSuccess(nodeName);
          return {
            executedBy: nodeName,
            pool,
            computeRoute,
            result,
            source: route.source,
          };
        } catch (err) {
          this._recordNodeFailure(nodeName, err);
          this._log('warn', 'Node execution failed, trying next', {
            node: nodeName, error: err.message,
          });
        }
      }

      // All nodes failed — try fallback chain
      for (const fallbackNode of route.fallbackChain) {
        try {
          const result = await this._executeOnNode(fallbackNode, task, pool);
          this._recordNodeSuccess(fallbackNode);
          this._routingMetrics.fallbacksUsed++;
          return {
            executedBy: fallbackNode,
            pool,
            computeRoute,
            result,
            source: 'fallback-dispatch',
          };
        } catch (err) {
          this._recordNodeFailure(fallbackNode, err);
        }
      }

      throw new HeadyError(
        `All nodes exhausted for task type ${task.type}`,
        503,
        'ALL_NODES_EXHAUSTED',
        { taskType: task.type, attemptedNodes: [...nodes, ...route.fallbackChain] }
      );

    } finally {
      this._activeRoutings--;
    }
  }

  /**
   * Execute a task on a specific node (via registry or simulation).
   */
  async _executeOnNode(nodeName, task, pool) {
    // Ensure breaker exists
    if (!this._nodeBreakers.has(nodeName)) {
      this._nodeBreakers.set(nodeName, new CircuitBreaker({
        failureThreshold: FIB[5],       // 5 failures
        resetTimeoutMs: FIB[8] * 1000,  // 21s
        halfOpenProbes: FIB[3],         // 2 probes
      }));
    }

    const breaker = this._nodeBreakers.get(nodeName);
    if (!breaker.canExecute()) {
      throw new HeadyError(`Circuit breaker OPEN for ${nodeName}`, 503, 'CIRCUIT_OPEN');
    }

    // Try real node from registry
    if (this.nodeRegistry) {
      const node = this.nodeRegistry.getNode(nodeName);
      if (node && typeof node.execute === 'function') {
        return node.execute(task);
      }
    }

    // Simulation fallback
    return {
      simulated: true,
      node: nodeName,
      taskType: task.type,
      pool,
      timestamp: Date.now(),
      output: task.payload || {},
    };
  }

  _recordNodeSuccess(nodeName) {
    const breaker = this._nodeBreakers.get(nodeName);
    if (breaker) breaker.recordSuccess();
  }

  _recordNodeFailure(nodeName, err) {
    const breaker = this._nodeBreakers.get(nodeName);
    if (breaker) breaker.recordFailure();
  }

  // ─── Arena Integration ────────────────────────────────────────────────────

  /**
   * Apply an arena-promoted route override for a task type.
   */
  applyArenaPromotion(taskType, winningNodes) {
    this._routeOverrides.set(taskType, {
      nodes: winningNodes,
      promotedAt: Date.now(),
    });
    this._log('info', 'Arena promotion applied', { taskType, nodes: winningNodes });
  }

  /**
   * Clear an arena promotion (revert to routing matrix).
   */
  clearArenaPromotion(taskType) {
    this._routeOverrides.delete(taskType);
  }

  // ─── Queries ──────────────────────────────────────────────────────────────

  getRoutingMatrix() {
    return { ...ROUTING_MATRIX };
  }

  getRouteOverrides() {
    const overrides = {};
    for (const [k, v] of this._routeOverrides) {
      overrides[k] = { ...v };
    }
    return overrides;
  }

  _getBreakersStatus() {
    const status = {};
    for (const [name, breaker] of this._nodeBreakers) {
      status[name] = breaker.getStatus();
    }
    return status;
  }

  healthCheck() {
    const openBreakers = [...this._nodeBreakers.values()].filter(b => {
      const s = b.getStatus();
      return s.state === 'OPEN';
    }).length;
    const totalBreakers = this._nodeBreakers.size;

    const healthRatio = totalBreakers > 0 ? 1 - (openBreakers / totalBreakers) : 1.0;

    return {
      status: healthRatio >= PSI ? 'healthy' : (healthRatio >= PSI * PSI ? 'degraded' : 'unhealthy'),
      healthRatio,
      pendingTasks: this._taskQueue.length,
      activeRoutings: this._activeRoutings,
      openCircuitBreakers: openBreakers,
      totalNodes: totalBreakers,
      metrics: { ...this._routingMetrics },
    };
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export { ROUTING_MATRIX, COMPLEXITY_ROUTES };
export default HeadyConductor;
