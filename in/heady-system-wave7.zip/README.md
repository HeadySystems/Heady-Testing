# Heady™ Alive Software Platform

Self-aware, self-improving AI operating system built on Sacred Geometry principles.
All numeric values derive from phi (φ ≈ 1.618) and Fibonacci sequences — zero magic numbers.

**Author:** Eric Haywood — HeadySystems Inc.  
**Contact:** eric@headyconnection.org  
**License:** Proprietary

## Quick Start

```bash
# Start entire system
node src/bootstrap.js

# Or with Docker Compose
docker compose -f infrastructure/docker/docker-compose.yml up -d

# Run tests
node tests/phi-math.test.js
node tests/security.test.js
node tests/integration/docker-compose.test.js
```

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  EDGE (Cloudflare Workers)                                      │
│  src/edge/worker.js — routing, caching, AI inference            │
├─────────────────────────────────────────────────────────────────┤
│  INTELLIGENCE LAYER                                             │
│  HeadySoul → HeadyBrains → HeadyConductor → Nodes              │
│  HeadyMemory (RAM-first, pgvector backup, 384D HNSW)           │
│  HeadyAutobiographer (event sourcing, narrative construction)   │
├─────────────────────────────────────────────────────────────────┤
│  SERVICE LAYER (ports 3310-3396)                                │
│  Auth(3310) Notification(3320) Analytics(3330) Scheduler(3340)  │
│  RateLimiter(3350) Conductor(3360) Memory(3385) Backup(3396)   │
├─────────────────────────────────────────────────────────────────┤
│  LIQUID ARCHITECTURE                                            │
│  LiquidNode → LiquidMesh → LiquidTaskExecutor                  │
│  HeadyBee → HeadySwarm → SwarmIntelligence                     │
├─────────────────────────────────────────────────────────────────┤
│  COLAB PRO+ (3 Runtimes — Latent Space Ops)                    │
│  Primary: Vector Ops (A100) | Secondary: LLM (A100)            │
│  Tertiary: Training (V100)                                      │
├─────────────────────────────────────────────────────────────────┤
│  WEBSITES (9 domains, ports 3371-3379)                          │
│  headyme.com | headysystems.com | heady-ai.com | headyos.com   │
│  headyconnection.org/.com | headyex.com | headyfinance.com     │
│  admin.headysystems.com                                         │
├─────────────────────────────────────────────────────────────────┤
│  INFRASTRUCTURE                                                 │
│  PostgreSQL+pgvector | PgBouncer | Redis | NATS JetStream      │
│  Envoy mTLS | Prometheus+Grafana | OpenTelemetry               │
│  Kubernetes (Helm) | Docker Compose | GitHub Actions            │
└─────────────────────────────────────────────────────────────────┘
```

## Directory Structure

```
heady-system/
├── src/
│   ├── intelligence/       # HeadySoul, HeadyBrains, HeadyAutobiographer
│   ├── edge/               # Cloudflare Workers handler
│   ├── memory/             # HeadyMemory (RAM-first vector memory)
│   ├── lifecycle/          # Graceful shutdown manager
│   ├── orchestration/      # HeadyConductor
│   ├── liquid/             # Liquid node, mesh, task executor
│   ├── bees/               # HeadyBee, swarm, swarm intelligence
│   ├── colab/              # Colab runtime, vector ops, templates, deploy
│   ├── services/           # Auth, analytics, notification, scheduler, etc.
│   ├── websites/           # All 9 website servers
│   └── bootstrap.js        # Unified system entrypoint
├── shared/                 # phi-math, logger, health, DB clients, security
├── tests/                  # Unit + integration tests
├── migrations/             # Database migrations
├── infrastructure/
│   ├── docker/             # Docker Compose, Dockerfile, OTel config
│   ├── kubernetes/         # Helm chart (Chart.yaml, values.yaml, templates/)
│   ├── prometheus/         # prometheus.yml, alert-rules.yml
│   ├── grafana/            # Dashboards, datasources
│   ├── envoy/              # mTLS proxy config
│   ├── cloudflare/         # wrangler.toml
│   └── ci-cd/              # GitHub Actions
├── docs/                   # OpenAPI spec, ADR, C4, runbooks
├── CHANGES.md              # Changelog
├── GAPS_FOUND.md           # Gap analysis
├── IMPROVEMENTS.md         # Improvements log
└── package.json
```

## Key Phi Values

| Constant | Value | Usage |
|----------|-------|-------|
| φ | 1.618 | Golden ratio — base multiplier |
| ψ (1/φ) | 0.618 | Conjugate — weight factors |
| ψ² | 0.382 | Secondary weight |
| CSL CRITICAL | 0.927 | Near-certain threshold |
| CSL HIGH | 0.882 | Strong alignment |
| CSL MEDIUM | 0.809 | Moderate alignment |
| CSL LOW | 0.691 | Weak alignment |
| Backoff | 1000→1618→2618→4236→6854→11090ms | Phi-exponential retry |
| HNSW M | 21 (fib(8)) | Vector index parameter |
| Pool sizes | 5, 8, 13, 21, 34, 55, 89 | Fibonacci connection pools |

## GCP Configuration

- **Project:** gen-lang-client-0920560496
- **Region:** us-east1
- **Cloudflare Account:** 8b1fa38f282c691423c6399247d53323
- **GitHub Org:** HeadyMe
- **Auth:** Firebase Auth → httpOnly cookies (zero localStorage)

## Security

- Zero localStorage tokens — httpOnly `__Host-heady_session` cookies only
- Zero console.log — structured JSON logging only
- AES-256-GCM encryption with HKDF key derivation
- mTLS between all internal services via Envoy
- Zero-trust request validation with HMAC integrity
- CSP, HSTS, X-Frame-Options on all endpoints
