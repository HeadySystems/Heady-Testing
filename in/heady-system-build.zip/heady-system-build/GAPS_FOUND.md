# GAPS FOUND

## Confirmed gaps addressed
- Missing root operational documents: `CHANGES.md`, `GAPS_FOUND.md`, and `IMPROVEMENTS.md` were absent.
- Missing knowledge-base tree: no `docs/` hierarchy existed for architecture, ADRs, runbooks, onboarding, or security.
- `heady-auto-context` did not expose the concrete endpoints used elsewhere in the bundle, especially `/context/enrich`, `/context/index-batch`, and `/context/remove`.
- Auth UI linked to `/oauth/google` and `/oauth/github`, but the auth service did not implement those routes.
- The site generator still contained legacy browser-storage behavior and alert-driven OAuth placeholders.

## Remaining external-environment blockers
- Real OAuth completion requires provider credentials and callback registration in Google and GitHub consoles.
- Firebase password and anonymous flows require a valid `FIREBASE_API_KEY` and project configuration at deploy time.
- Full Docker Compose startup depends on Docker availability plus secrets like `POSTGRES_PASSWORD`, `DRUPAL_WEBHOOK_SECRET`, and provider credentials.
- Cross-domain cookie exchange for final production domains still depends on deployment-specific DNS, TLS, and edge routing choices.
