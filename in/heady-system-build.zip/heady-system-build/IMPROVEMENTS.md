# IMPROVEMENTS

## Runtime
- HeadyAutoContext now behaves like a real upstream dependency instead of a passive placeholder service.
- Auth now covers password, anonymous, Google, and GitHub flows from the same central domain boundary.

## Security
- OAuth flow integrity is protected with signed, expiring flow cookies tied to state and nonce.
- Client runtime context no longer writes browser storage records, reducing persistence surface area.

## Operability
- Added a validation script and test suite to prove core bundle invariants before packaging.
- Added architecture, security, onboarding, error-catalog, and runbook material so the bundle is easier to operate and extend.
