/**
 * @fileoverview generate-services.js
 * Generates all 50+ Heady service implementation files programmatically.
 * Run with: node generate-services.js
 */

import { writeFileSync, mkdirSync } from 'fs';
import { join } from 'path';

const ROOT = '/home/user/workspace/heady-system-build/services';

const SERVICES = [
  // Core Intelligence
  { dir: 'core-intelligence/heady-brain',       port: 8100, domain: 'inference',     desc: 'Central AI reasoning engine — routes inference requests by CSL domain and capability match' },
  { dir: 'core-intelligence/heady-brains',      port: 8101, domain: 'federation',    desc: 'Multi-brain federation — coordinates distributed AI reasoning across provider endpoints' },
  { dir: 'core-intelligence/heady-soul',        port: 8102, domain: 'orchestration', desc: 'Orchestration core — the center of the 17-swarm sacred geometry ring topology' },
  { dir: 'core-intelligence/heady-conductor',   port: 8103, domain: 'pipeline',      desc: 'Pipeline conductor — drives HCFullPipeline 21-stage cognitive state machine' },
  { dir: 'core-intelligence/heady-infer',       port: 8104, domain: 'inference',     desc: 'Inference engine — multi-provider LLM request handling with phi-backoff retries' },
  { dir: 'core-intelligence/heady-embed',       port: 8105, domain: 'embedding',     desc: 'Embedding service — 384-dim dense vector generation for all content types' },
  { dir: 'core-intelligence/heady-memory',      port: 8106, domain: 'memory',        desc: 'Memory persistence — pgvector long-term storage with CSL retrieval gates' },
  { dir: 'core-intelligence/heady-vector',      port: 8107, domain: 'vector',        desc: 'Vector operations — cosine similarity, projection, and 3D octree spatial indexing' },
  { dir: 'core-intelligence/heady-projection',  port: 8108, domain: 'projection',    desc: 'Vector projection engine — 3D spatial computing and VALU tensor core bridge' },

  // Agent & Bee Services
  { dir: 'agent-bee/heady-bee-factory',         port: 8200, domain: 'bee',           desc: 'Dynamic bee creation — spawns concurrent equal-status bee workers with no ranking' },
  { dir: 'agent-bee/heady-hive',                port: 8201, domain: 'bee',           desc: 'Bee coordination hub — routes bee tasks via CSL domain match, concurrent dispatch' },
  { dir: 'agent-bee/heady-orchestration',       port: 8202, domain: 'orchestration', desc: 'Swarm orchestration — coordinates all 17 swarms simultaneously in equal standing' },
  { dir: 'agent-bee/heady-federation',          port: 8203, domain: 'federation',    desc: 'Agent federation — manages cross-domain agent collaboration and capability sharing' },

  // Security & Governance
  { dir: 'security-governance/heady-guard',     port: 8300, domain: 'security',      desc: 'Security enforcement — zero-trust sanitization on all input/output channels' },
  { dir: 'security-governance/heady-security',  port: 8301, domain: 'security',      desc: 'Security scanning — TruffleHog secret detection, vuln scanning, SSRF prevention' },
  { dir: 'security-governance/heady-governance',port: 8302, domain: 'governance',    desc: 'Policy enforcement — compliance rules, audit trails, Ed25519 receipt signing' },

  // Monitoring & Health
  { dir: 'monitoring-health/heady-health',      port: 8400, domain: 'monitoring',    desc: 'Health monitoring — aggregates health from all 17 swarms and 50 services' },
  { dir: 'monitoring-health/heady-eval',        port: 8401, domain: 'evaluation',    desc: 'Evaluation engine — agent metrics: task success, tool accuracy, trajectory quality' },
  { dir: 'monitoring-health/heady-maintenance', port: 8402, domain: 'reliability',   desc: 'Self-healing maintenance — quarantine, respawn, drift recovery, phi-heartbeat' },
  { dir: 'monitoring-health/heady-testing',     port: 8403, domain: 'testing',       desc: 'Testing framework — integration tests, smoke tests, Arena Mode evaluation' },

  // User-Facing Services
  { dir: 'user-facing/heady-web',               port: 8500, domain: 'web',           desc: 'Web platform — serves 9 Heady sites with SSR, sacred geometry, and auto-context injection' },
  { dir: 'user-facing/heady-buddy',             port: 8501, domain: 'companion',     desc: 'HeadyBuddy companion widget — chat, context enrichment, and personalization engine' },
  { dir: 'user-facing/heady-ui',                port: 8502, domain: 'ui',            desc: 'UI component library — shared glassmorphism components and phi-scaled design tokens' },
  { dir: 'user-facing/heady-onboarding',        port: 8503, domain: 'onboarding',    desc: 'User onboarding — adaptive multi-step onboarding with vector-indexed user journey' },
  { dir: 'user-facing/heady-pilot-onboarding',  port: 8504, domain: 'onboarding',    desc: 'Pilot program onboarding — enterprise pilot enrollment and guided setup flows' },
  { dir: 'user-facing/heady-task-browser',      port: 8505, domain: 'tasks',         desc: 'Task management UI — real-time concurrent task status with no priority ordering' },

  // Pipeline & Workflow
  { dir: 'pipeline-workflow/auto-success-engine',       port: 8600, domain: 'pipeline',   desc: 'φ-scaled auto-success engine — dynamic resource allocation across 9 task categories' },
  { dir: 'pipeline-workflow/hcfullpipeline-executor',   port: 8601, domain: 'pipeline',   desc: 'HCFullPipeline executor — 21-stage cognitive state machine with CSL routing at Stage 4' },
  { dir: 'pipeline-workflow/heady-chain',               port: 8602, domain: 'pipeline',   desc: 'Chain execution — DAG-based subtask chaining with concurrent node dispatch' },
  { dir: 'pipeline-workflow/heady-cache',               port: 8603, domain: 'cache',      desc: 'Caching layer — hot-cold cache with phi-scaled TTL and LRU eviction' },

  // AI Routing & Gateway
  { dir: 'ai-routing/ai-router',                port: 8700, domain: 'routing',       desc: 'Multi-model AI routing — CSL-scored provider selection and capability match' },
  { dir: 'ai-routing/api-gateway',              port: 8701, domain: 'gateway',       desc: 'API gateway — request routing, rate limiting, auth validation, OTEL span injection' },
  { dir: 'ai-routing/model-gateway',            port: 8702, domain: 'routing',       desc: 'Model selection gateway — capability vector matching for Claude/GPT/Gemini/Groq/Workers AI' },
  { dir: 'ai-routing/domain-router',            port: 8703, domain: 'routing',       desc: 'Domain-based router — resolves all 9 Heady sites plus aliases via CSL similarity' },

  // External Integrations
  { dir: 'external-integrations/mcp-server',            port: 8800, domain: 'mcp',       desc: 'MCP protocol server — JSON-RPC 2.0 over SSE/stdio with CSL-gated tool routing' },
  { dir: 'external-integrations/google-mcp',            port: 8801, domain: 'mcp',       desc: 'Google MCP integration — Google Search, Gmail, Drive, Workspace tool adapters' },
  { dir: 'external-integrations/memory-mcp',            port: 8802, domain: 'mcp',       desc: 'Memory MCP server — exposes vector memory as MCP tool endpoints' },
  { dir: 'external-integrations/perplexity-mcp',        port: 8803, domain: 'mcp',       desc: 'Perplexity MCP — Sonar Pro research with citation injection via MCP protocol' },
  { dir: 'external-integrations/jules-mcp',             port: 8804, domain: 'mcp',       desc: 'Jules MCP — async code task delegation to Jules AI with result streaming' },
  { dir: 'external-integrations/huggingface-gateway',   port: 8805, domain: 'integration', desc: 'HuggingFace integration — model inference, dataset access, and embedding endpoints' },
  { dir: 'external-integrations/colab-gateway',         port: 8806, domain: 'integration', desc: 'Colab integration — notebook execution dispatch and result ingestion' },
  { dir: 'external-integrations/silicon-bridge',        port: 8807, domain: 'integration', desc: 'Silicon computing bridge — edge compute routing to Cloudflare Workers AI' },
  { dir: 'external-integrations/discord-bot',           port: 8808, domain: 'integration', desc: 'Discord bot — HeadyBuddy presence in Discord with slash commands and webhooks' },
  { dir: 'external-integrations/drupal-sync',           port: 8809, domain: 'cms',       desc: 'Drupal webhook/polling sync — indexes Drupal JSON:API content into vector memory' },

  // Specialized Services
  { dir: 'specialized/heady-vinci',             port: 8900, domain: 'learning',      desc: 'Pattern learning engine — extracts, scores, and surfaces reusable execution patterns' },
  { dir: 'specialized/heady-autobiographer',    port: 8901, domain: 'documentation', desc: 'Auto-documentation — generates architectural docs from code analysis and chat history' },
  { dir: 'specialized/heady-midi',              port: 8902, domain: 'creative',      desc: 'MIDI/creative interface — CC→MCP bridge, MIDI→LLM tool dispatch, A/V sync' },
  { dir: 'specialized/budget-tracker',          port: 8903, domain: 'finops',        desc: 'Cost tracking — AI provider spend metering, rate limit monitoring, budget alerts' },
  { dir: 'specialized/cli-service',             port: 8904, domain: 'cli',           desc: 'CLI interface — interactive terminal with OAuth, phi-scaled theming, and REPL' },
  { dir: 'specialized/prompt-manager',          port: 8905, domain: 'prompts',       desc: 'Prompt management — 64-prompt catalogue with version control and CSL retrieval' },
  { dir: 'specialized/secret-gateway',          port: 8906, domain: 'security',      desc: 'Secret management — Vault-backed secret storage, OAuth token rotation, SDK layers' },
  { dir: 'specialized/heady-auto-context',      port: 8907, domain: 'context',       desc: 'HeadyAutoContext primary service — 384-dim vector indexing, CSL gates, enrichment API' },
];

function serviceTemplate(svc) {
  const className = svc.dir.split('/').pop().replace(/-([a-z])/g, (_, c) => c.toUpperCase());
  return `/**
 * @fileoverview ${svc.dir.split('/').pop()} — ${svc.desc}
 *
 * Service: ${svc.dir.split('/').pop()}
 * Domain:  ${svc.domain}
 * Port:    ${svc.port}
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO priority-based routing. CSL domain match only. Everything is instantaneous.
 *
 * @module ${svc.dir.split('/').pop()}
 * @version 2.1.0
 */

import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, PSI, CSL_GATES, phiBackoff, cslGate } from '../../shared/phi-math.js';

const SERVICE_NAME = '${svc.dir.split('/').pop()}';
process.env.SERVICE_NAME = SERVICE_NAME;

// ─── Service-specific state ───────────────────────────────────────────────────

const state = {
  initialized: false,
  domain: '${svc.domain}',
  startTime: Date.now(),
};

// ─── Route handlers ───────────────────────────────────────────────────────────

/**
 * Primary domain endpoint — processes requests enriched with AutoContext.
 * Routes by CSL domain similarity (${svc.domain}) ONLY.
 */
async function handleDomainRequest(req, res) {
  const { headyContext, correlationId, body } = req;
  const t0 = Date.now();

  // CSL domain match gate — only process requests aligned to this service's domain
  const cslScore = headyContext?.cslScore || 0;
  if (!cslGate(cslScore, 'include') && body?.strict !== false) {
    log('info', 'csl.gate.miss', { domain: '${svc.domain}', cslScore, correlationId });
    // Graceful: still process but flag the low relevance
  }

  try {
    // Service-specific logic entrypoint — bind domain handlers here
    const result = await processDomainOperation({
      input: body,
      context: headyContext,
      domain: '${svc.domain}',
    });

    emitSpan('domain-request', {
      domain: '${svc.domain}',
      cslScore,
      correlationId,
      durationMs: Date.now() - t0,
    });

    res.json({
      service:       SERVICE_NAME,
      domain:        '${svc.domain}',
      result,
      cslScore,
      correlationId,
      durationMs:    Date.now() - t0,
    });
  } catch (err) {
    log('error', 'domain-request.error', { error: err.message, correlationId });
    throw err;
  }
}

/**
 * Internal service logic contract. Override with domain-specific handlers where needed.
 */
async function processDomainOperation({ input, context, domain }) {
  return {
    domain,
    processed: true,
    inputKeys: Object.keys(input || {}),
    contextEnriched: context?.enriched || false,
  };
}

/**
 * Status endpoint — returns service-specific operational metrics.
 */
async function handleStatus(req, res) {
  res.json({
    service:      SERVICE_NAME,
    domain:       '${svc.domain}',
    state,
    uptime:       Date.now() - state.startTime,
    phi:          PHI,
    cslGates:     CSL_GATES,
    version:      '2.1.0',
  });
}

// ─── Service bootstrap ────────────────────────────────────────────────────────

const { start, stop } = createHeadyService({
  name:  SERVICE_NAME,
  port:  ${svc.port},
  routes: [
    { method: 'POST', path: '/',        handler: handleDomainRequest },
    { method: 'GET',  path: '/status',  handler: handleStatus },
    { method: 'POST', path: '/process', handler: handleDomainRequest },
  ],
  onStart: async () => {
    state.initialized = true;
    log('info', 'service.init', { service: SERVICE_NAME, domain: '${svc.domain}', port: ${svc.port} });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
`;
}

function dockerfileTemplate(svc) {
  return `FROM node:22-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY . .
ENV SERVICE_NAME=${svc.dir.split('/').pop()}
ENV PORT=${svc.port}
EXPOSE ${svc.port}
HEALTHCHECK --interval=30s --timeout=10s --start-period=15s --retries=3 \\
  CMD-SHELL wget -qO- "http://$HOSTNAME:$PORT/health" >/dev/null || exit 1
CMD ["node", "--experimental-vm-modules", "index.js"]
`;
}

function kubeManifestTemplate(svc) {
  const name = svc.dir.split('/').pop();
  return `apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${name}
  labels:
    app: ${name}
    heady.io/domain: ${svc.domain}
    heady.io/autocontext: "true"
spec:
  replicas: 2
  selector:
    matchLabels:
      app: ${name}
  template:
    metadata:
      labels:
        app: ${name}
        heady.io/domain: ${svc.domain}
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/port: "${svc.port}"
    spec:
      terminationGracePeriodSeconds: 34
      containers:
      - name: ${name}
        image: gcr.io/gen-lang-client-0920560496/${name}:latest
        ports:
        - containerPort: ${svc.port}
          name: http
        env:
        - name: SERVICE_NAME
          value: "${name}"
        - name: PORT
          value: "${svc.port}"
        - name: AUTOCONTEXT_URL
          value: "http://heady-auto-context:8907"
        - name: CONSUL_URL
          value: "http://consul:8500"
        - name: OTEL_ENDPOINT
          value: "http://otel-collector:4318"
        resources:
          requests:
            cpu: "100m"
            memory: "128Mi"
          limits:
            cpu: "500m"
            memory: "512Mi"
        livenessProbe:
          httpGet:
            path: /health
            port: ${svc.port}
          initialDelaySeconds: 13
          periodSeconds: 21
          timeoutSeconds: 8
          failureThreshold: 3
        readinessProbe:
          httpGet:
            path: /health
            port: ${svc.port}
          initialDelaySeconds: 8
          periodSeconds: 13
          timeoutSeconds: 5
          failureThreshold: 2
---
apiVersion: v1
kind: Service
metadata:
  name: ${name}
  labels:
    app: ${name}
    heady.io/domain: ${svc.domain}
spec:
  selector:
    app: ${name}
  ports:
  - name: http
    port: ${svc.port}
    targetPort: ${svc.port}
`;
}

function packageJsonTemplate(svc) {
  const name = svc.dir.split('/').pop();
  return JSON.stringify({
    name: `@heady/${name}`,
    version: '2.1.0',
    type: 'module',
    description: svc.desc,
    main: 'index.js',
    scripts: {
      start: 'node index.js',
      dev: 'node --watch index.js',
      test: 'node --test',
    },
    dependencies: {
      'zod': '^3.22.0',
    },
    engines: { node: '>=22' },
  }, null, 2);
}

// Generate all services
let count = 0;
for (const svc of SERVICES) {
  const dir = join(ROOT, svc.dir);
  mkdirSync(dir, { recursive: true });

  writeFileSync(join(dir, 'index.js'), serviceTemplate(svc), 'utf-8');
  writeFileSync(join(dir, 'Dockerfile'), dockerfileTemplate(svc), 'utf-8');
  writeFileSync(join(dir, 'package.json'), packageJsonTemplate(svc), 'utf-8');

  // Write Kubernetes manifest
  const kubeDir = join('/home/user/workspace/heady-system-build/infra/kubernetes', svc.dir.split('/').pop());
  mkdirSync(kubeDir, { recursive: true });
  writeFileSync(join(kubeDir, 'deployment.yaml'), kubeManifestTemplate(svc), 'utf-8');

  count++;
}

console.log(`Generated ${count} services + Kubernetes manifests.`);
console.log('Services list:');
SERVICES.forEach(s => console.log(`  - ${s.dir.split('/').pop()} (port ${s.port}, domain: ${s.domain})`));
