/**
 * @fileoverview heady-auth — central auth relay and cookie minting service.
 *
 * Real implementation notes:
 * - Validates redirect hosts against an allowlist
 * - Uses Firebase Identity Toolkit for email/password and anonymous auth when configured
 * - Mints signed httpOnly session cookies on the auth domain
 * - Exposes logout and session inspection endpoints
 */

import { createHmac, timingSafeEqual } from 'crypto';
import { createHeadyService, log } from '../../shared/service-base.js';

const SERVICE_NAME = 'heady-auth';
process.env.SERVICE_NAME = SERVICE_NAME;

const AUTH_COOKIE_NAME = process.env.AUTH_COOKIE_NAME || 'heady_auth_session';
const AUTH_COOKIE_SECRET = process.env.AUTH_COOKIE_SECRET;
const FIREBASE_API_KEY = process.env.FIREBASE_API_KEY;
const FIREBASE_PROJECT_ID = process.env.FIREBASE_PROJECT_ID || 'gen-lang-client-0920560496';
const AUTH_BASE_URL = process.env.AUTH_BASE_URL || 'https://auth.headysystems.com';
const ALLOWED_REDIRECT_HOSTS = (process.env.ALLOWED_REDIRECT_HOSTS || [
  'headyme.com',
  'headysystems.com',
  'heady-ai.com',
  'headyos.com',
  'headyconnection.org',
  'headyconnection.com',
  'headyex.com',
  'headyfinance.com',
  'admin.headysystems.com',
  'auth.headysystems.com',
].join(','))
  .split(',')
  .map(v => v.trim())
  .filter(Boolean);

if (!AUTH_COOKIE_SECRET) {
  throw new Error('AUTH_COOKIE_SECRET is required for heady-auth. Refusing to start without a signing secret.');
}

function parseCookies(req) {
  const source = req.headers.cookie || '';
  return source.split(';').map(v => v.trim()).filter(Boolean).reduce((acc, item) => {
    const index = item.indexOf('=');
    if (index === -1) return acc;
    const key = item.slice(0, index);
    const value = item.slice(index + 1);
    acc[key] = decodeURIComponent(value);
    return acc;
  }, {});
}

function isAllowedRedirect(url) {
  try {
    const parsed = new URL(url);
    return ALLOWED_REDIRECT_HOSTS.some(host => parsed.hostname === host || parsed.hostname.endsWith(`.${host}`));
  } catch {
    return false;
  }
}

function signPayload(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = createHmac('sha256', AUTH_COOKIE_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}

function verifyPayload(token) {
  if (!token || !token.includes('.')) return null;
  const [body, signature] = token.split('.');
  const expected = createHmac('sha256', AUTH_COOKIE_SECRET).update(body).digest('base64url');
  const sigBuf = Buffer.from(signature);
  const expBuf = Buffer.from(expected);
  if (sigBuf.length !== expBuf.length || !timingSafeEqual(sigBuf, expBuf)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

function buildSessionCookie(value, maxAgeSeconds = 60 * 60 * 8) {
  return `${AUTH_COOKIE_NAME}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAgeSeconds}`;
}

function buildClearCookie() {
  return `${AUTH_COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

async function callFirebase(endpoint, payload) {
  if (!FIREBASE_API_KEY) {
    throw new Error('FIREBASE_API_KEY is required for Firebase auth flows.');
  }

  const url = `https://identitytoolkit.googleapis.com/v1/${endpoint}?key=${FIREBASE_API_KEY}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error?.message || `Firebase auth error from ${endpoint}`);
  }
  return data;
}

function getSessionFromRequest(req) {
  const cookies = parseCookies(req);
  return verifyPayload(cookies[AUTH_COOKIE_NAME]);
}

async function handleSession(req, res) {
  const session = getSessionFromRequest(req);
  if (!session) {
    res.json({ authenticated: false, projectId: FIREBASE_PROJECT_ID });
    return;
  }
  res.json({
    authenticated: true,
    projectId: FIREBASE_PROJECT_ID,
    user: {
      uid: session.uid,
      email: session.email || null,
      provider: session.provider,
      issuedAt: session.iat,
      expiresAt: session.exp,
    },
  });
}

async function handleEmailAuth(req, res) {
  const { email, password, redirect, state, nonce, mode = 'login' } = req.body || {};
  if (!email || !password || !redirect || !state || !nonce) {
    res.json({ error: 'email, password, redirect, state, and nonce are required' }, 400);
    return;
  }
  if (!isAllowedRedirect(redirect)) {
    res.json({ error: 'redirect-not-allowlisted' }, 400);
    return;
  }

  const data = mode === 'signup'
    ? await callFirebase('accounts:signUp', { email, password, returnSecureToken: true })
    : await callFirebase('accounts:signInWithPassword', { email, password, returnSecureToken: true });

  const session = signPayload({
    uid: data.localId,
    email: data.email,
    provider: 'password',
    state,
    nonce,
    iat: Date.now(),
    exp: Date.now() + (1000 * 60 * 60 * 8),
  });

  res.setHeader('Set-Cookie', buildSessionCookie(session));
  res.json({
    ok: true,
    redirectTo: `${redirect}${redirect.includes('?') ? '&' : '?'}auth_state=${encodeURIComponent(state)}`,
    authDomain: AUTH_BASE_URL,
  });
}

async function handleAnonymousAuth(req, res) {
  const { redirect, state, nonce } = req.body || {};
  if (!redirect || !state || !nonce) {
    res.json({ error: 'redirect, state, and nonce are required' }, 400);
    return;
  }
  if (!isAllowedRedirect(redirect)) {
    res.json({ error: 'redirect-not-allowlisted' }, 400);
    return;
  }

  const data = await callFirebase('accounts:signUp', { returnSecureToken: true });
  const session = signPayload({
    uid: data.localId,
    provider: 'anonymous',
    state,
    nonce,
    iat: Date.now(),
    exp: Date.now() + (1000 * 60 * 60 * 4),
  });

  res.setHeader('Set-Cookie', buildSessionCookie(session, 60 * 60 * 4));
  res.json({
    ok: true,
    redirectTo: `${redirect}${redirect.includes('?') ? '&' : '?'}auth_state=${encodeURIComponent(state)}`,
    authDomain: AUTH_BASE_URL,
  });
}

async function handleLogout(req, res) {
  res.setHeader('Set-Cookie', buildClearCookie());
  res.json({ ok: true, loggedOut: true });
}

async function handleConfig(req, res) {
  res.json({
    authBaseUrl: AUTH_BASE_URL,
    firebaseProjectId: FIREBASE_PROJECT_ID,
    allowlistedHosts: ALLOWED_REDIRECT_HOSTS,
    providers: ['password', 'anonymous'],
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8510,
  routes: [
    { method: 'GET', path: '/api/session', handler: handleSession },
    { method: 'GET', path: '/api/config', handler: handleConfig },
    { method: 'POST', path: '/api/auth/email', handler: handleEmailAuth },
    { method: 'POST', path: '/api/auth/anonymous', handler: handleAnonymousAuth },
    { method: 'POST', path: '/api/logout', handler: handleLogout },
  ],
  onStart: async () => {
    log('info', 'service.init', { service: SERVICE_NAME, port: 8510, firebaseProjectId: FIREBASE_PROJECT_ID });
  },
  onShutdown: async () => {
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
