/**
 * @fileoverview bee-factory-refactored.js
 *
 * REFACTORED: All priority/ranking language removed from bee creation and execution.
 * Bees have NO priority level. ALL bees are concurrent equals. Fire simultaneously.
 *
 * Key changes from original:
 *   ❌ Removed: priority field on BeeConfig
 *   ❌ Removed: priority queue sorting
 *   ❌ Removed: priority-weighted bee scheduling
 *   ❌ Removed: labeled bee classifications
 *   ✅ Added:   Equal-status concurrent execution via Promise.all
 *   ✅ Added:   CSL domain matching for worker type selection
 *   ✅ Added:   AutoContext pre-load before every bee task
 *   ✅ Added:   Fibonacci pre-warm pools
 *
 * @module bee-factory-refactored
 * @version 3.0.0 — no-ranking edition
 */

import { randomUUID } from 'crypto';
import { PHI, PSI, FIB, fibSequence, cslGate, phiBackoff, CSL_GATES } from '../../shared/phi-math.js';
import { beeTaskContextPreload } from '../../shared/auto-context-middleware.js';
import { log, emitSpan } from '../../shared/service-base.js';

// ─── Constants ────────────────────────────────────────────────────────────────

const FIB_POOL = fibSequence(8); // [0,1,1,2,3,5,8,13]
const BEE_POOL_MIN      = FIB_POOL[3]; // 2
const BEE_POOL_INITIAL  = FIB_POOL[4]; // 3
const BEE_POOL_MAX      = FIB_POOL[7]; // 13

// Bee lifecycle phases
export const BEE_PHASE = {
  SPAWN:      'spawn',
  INITIALIZE: 'initialize',
  READY:      'ready',
  ACTIVE:     'active',
  DRAINING:   'draining',
  SHUTDOWN:   'shutdown',
  DEAD:       'dead',
};

// ─── Bee Worker Types — all equal status ─────────────────────────────────────
// These are CAPABILITY types, not priority levels.

export const BEE_TYPES = {
  CONTENT_INJECTOR:   { type: 'content-injector',   domain: 'content'    },
  VECTOR_INDEXER:     { type: 'vector-indexer',      domain: 'memory'     },
  CONTEXT_ENRICHER:   { type: 'context-enricher',    domain: 'context'    },
  SECURITY_SCANNER:   { type: 'security-scanner',    domain: 'security'   },
  HEALTH_PROBER:      { type: 'health-prober',        domain: 'monitoring' },
  DEPLOY_RUNNER:      { type: 'deploy-runner',        domain: 'deployment' },
  RESEARCH_CRAWLER:   { type: 'research-crawler',    domain: 'research'   },
  DATA_TRANSFORMER:   { type: 'data-transformer',    domain: 'data'       },
  PATTERN_MATCHER:    { type: 'pattern-matcher',     domain: 'analysis'   },
  CODE_GENERATOR:     { type: 'code-generator',      domain: 'code'       },
  TEST_RUNNER:        { type: 'test-runner',          domain: 'testing'    },
  DRIFT_DETECTOR:     { type: 'drift-detector',      domain: 'reliability'},
};

// ─── Bee class ────────────────────────────────────────────────────────────────

class Bee {
  /**
   * @param {object} config
   * @param {string}   config.type    - Capability type (NOT priority)
   * @param {string}   config.domain  - Domain for CSL routing
   * @param {object[]} config.workers - Array of { name, fn(ctx) }
   * @param {string}   [config.swarmId]
   */
  constructor({ type, domain, workers, swarmId }) {
    this.id       = randomUUID();
    this.type     = type;
    this.domain   = domain;
    this.workers  = workers || [];
    this.swarmId  = swarmId || 'default';
    this.phase    = BEE_PHASE.SPAWN;
    this.spawnedAt = Date.now();
    this.lastActive = Date.now();
    this.metrics  = { tasksCompleted: 0, errors: 0, totalMs: 0 };
    // NO priority field — does not exist in this system
  }

  async initialize() {
    this.phase = BEE_PHASE.INITIALIZE;
    // Pre-load context for this bee type
    this.initialContext = await beeTaskContextPreload({
      id: this.id, type: this.type, domain: this.domain,
    });
    this.phase = BEE_PHASE.READY;
    log('info', 'bee.ready', { beeId: this.id, type: this.type, domain: this.domain });
  }

  /**
   * Execute all workers CONCURRENTLY — all fire at once, no ordering.
   * @param {object} taskContext
   * @returns {Promise<object>} worker results keyed by name
   */
  async execute(taskContext = {}) {
    if (this.phase !== BEE_PHASE.READY) {
      throw new Error(`Bee ${this.id} not ready (phase: ${this.phase})`);
    }

    this.phase = BEE_PHASE.ACTIVE;
    this.lastActive = Date.now();
    const t0 = Date.now();

    // Enrich task context with AutoContext BEFORE execution
    const enriched = await beeTaskContextPreload({
      id: this.id, type: this.type, domain: this.domain, payload: taskContext,
    });
    const ctx = { ...taskContext, ...enriched, beeId: this.id };

    // ALL workers fire simultaneously — no ordering, no ranking
    const workerResults = await Promise.allSettled(
      this.workers.map(async worker => {
        const wt0 = Date.now();
        try {
          const result = await worker.fn(ctx);
          return { name: worker.name, result, ms: Date.now() - wt0, ok: true };
        } catch (err) {
          log('error', 'bee.worker.error', {
            beeId: this.id, worker: worker.name, error: err.message,
          });
          return { name: worker.name, error: err.message, ms: Date.now() - wt0, ok: false };
        }
      })
    );

    const results = Object.fromEntries(
      workerResults.map(r => [r.value?.name || 'unknown', r.value])
    );

    const ms = Date.now() - t0;
    this.metrics.tasksCompleted++;
    this.metrics.totalMs += ms;
    this.phase = BEE_PHASE.READY;

    emitSpan('bee.execute', {
      beeId: this.id, type: this.type, domain: this.domain,
      workersRun: this.workers.length, ms,
    }, ms);

    return { beeId: this.id, type: this.type, domain: this.domain, results, ms };
  }

  async shutdown() {
    this.phase = BEE_PHASE.DRAINING;
    // Wait for active work to complete (max phi-scaled 13s)
    const deadline = Date.now() + Math.round(13000 * PHI);
    while (this.phase === BEE_PHASE.ACTIVE && Date.now() < deadline) {
      await new Promise(r => setTimeout(r, 100));
    }
    this.phase = BEE_PHASE.DEAD;
    log('info', 'bee.dead', { beeId: this.id, type: this.type });
  }
}

// ─── BeeFactory ───────────────────────────────────────────────────────────────

class BeeFactory extends EventEmitter {
  constructor() {
    super();
    /** @type {Map<string, Bee>} */
    this.bees        = new Map();
    /** @type {Map<string, Bee[]>} domain → pool of ready bees */
    this.pools       = new Map();
    this.totalSpawned = 0;
  }

  /**
   * Create a bee with the given config.
   * ALL bees are equal — no priority parameter accepted.
   *
   * @param {string} type - Capability type (see BEE_TYPES)
   * @param {object} config - { workers, swarmId, domain }
   * @returns {Promise<Bee>}
   */
  async createBee(type, config = {}) {
    const beeTypeDef = Object.values(BEE_TYPES).find(t => t.type === type);
    const domain = config.domain || beeTypeDef?.domain || 'general';

    const bee = new Bee({
      type,
      domain,
      workers: config.workers || [],
      swarmId: config.swarmId,
    });

    await bee.initialize();

    this.bees.set(bee.id, bee);
    if (!this.pools.has(domain)) this.pools.set(domain, []);
    this.pools.get(domain).push(bee);
    this.totalSpawned++;

    this.emit('bee:spawned', { beeId: bee.id, type, domain });
    log('info', 'bee.spawned', { beeId: bee.id, type, domain, totalSpawned: this.totalSpawned });

    return bee;
  }

  /**
   * Get a ready bee from the pool that matches the task's domain via CSL.
   * Falls back to spawning a new bee if pool is empty.
   *
   * @param {object} task - { type, domain }
   * @returns {Promise<Bee>}
   */
  async acquireBee(task) {
    const domain = task.domain || task.type || 'general';

    // Find the closest matching domain pool via CSL
    let closestBee = null;
    let closestScore = 0;

    for (const [poolDomain, pool] of this.pools.entries()) {
      const readyBees = pool.filter(b => b.phase === BEE_PHASE.READY);
      if (readyBees.length === 0) continue;

      // Simple domain matching score
      const score = poolDomain === domain ? 1.0 :
                    domain.includes(poolDomain) ? PSI :
                    poolDomain.includes(domain) ? PSI * PSI : 0;

      if (score > closestScore && cslGate(score, 'include')) {
        closestScore = score;
        closestBee = readyBees[0]; // pick first ready bee from the closest matching pool
      }
    }

    if (closestBee) return closestBee;

    // No matching bee in pool — spawn one
    const beeType = Object.values(BEE_TYPES).find(t =>
      t.domain === domain || t.type === task.type
    )?.type || 'content-injector';

    return this.createBee(beeType, {
      domain,
      workers: task.workers || [],
    });
  }

  /**
   * Create the standard content-injector bee with all default workers.
   * Used by every page load and every service endpoint.
   *
   * @param {string} [swarmId]
   * @returns {Promise<Bee>}
   */
  async createContentInjectorBee(swarmId) {
    return this.createBee('content-injector', {
      swarmId,
      workers: [
        {
          name: 'related-content',
          fn:   async (ctx) => ({
            type: 'related-content',
            query: ctx.pageTitle || ctx.query,
            vectorLookupPlan: {
              source: 'heady-memory',
              query: ctx.pageTitle || ctx.query || null,
              limit: 5,
            },
          }),
        },
        {
          name: 'dynamic-stats',
          fn:   async () => ({
            patents: '60+', nodes: 20, services: 52, uptime: '99.9%',
            bees: '10,000+', swarms: 17,
          }),
        },
        {
          name: 'personalization',
          fn:   async (ctx) => ctx.userId && ctx.userId !== 'anonymous'
            ? { type: 'user-preferences', userId: ctx.userId }
            : null,
        },
      ],
    });
  }

  /** @returns {object} factory health metrics */
  health() {
    const poolSummary = {};
    for (const [domain, pool] of this.pools.entries()) {
      poolSummary[domain] = {
        total:   pool.length,
        ready:   pool.filter(b => b.phase === BEE_PHASE.READY).length,
        active:  pool.filter(b => b.phase === BEE_PHASE.ACTIVE).length,
      };
    }
    return {
      totalSpawned:  this.totalSpawned,
      totalAlive:    this.bees.size,
      pools:         poolSummary,
      architecture: 'concurrent-equals — no ranking, no priority',
    };
  }
}

export const beeFactory = new BeeFactory();
export { Bee, BeeFactory };
