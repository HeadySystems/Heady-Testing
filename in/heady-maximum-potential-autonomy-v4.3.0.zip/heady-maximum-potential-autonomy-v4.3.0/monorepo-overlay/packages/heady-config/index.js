module.exports = {
  eslint: {
    root: true,
    env: { node: true, es2023: true },
    extends: [],
    parserOptions: { ecmaVersion: 'latest' },
    rules: {
      'no-console': ['error', { allow: ['error', 'warn'] }],
      'no-empty': ['error', { allowEmptyCatch: false }]
    }
  },
  prettier: {
    semi: true,
    singleQuote: true,
    trailingComma: 'es5'
  },
  typescript: {
    compilerOptions: {
      target: 'ES2023',
      module: 'CommonJS',
      strict: true,
      noUncheckedIndexedAccess: true
    }
  }
};
