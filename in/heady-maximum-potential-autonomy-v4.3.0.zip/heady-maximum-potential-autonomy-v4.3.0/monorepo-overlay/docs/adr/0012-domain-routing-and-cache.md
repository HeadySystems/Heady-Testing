# 0012 Domain Routing and Cache

## Problem
The overlay lacked explicit host resolution and low-latency cache control for frequent reads across the nine-site surface.

## Decision
Add `domain-router` for site resolution and `heady-cache` for Fibonacci-sized in-memory cache control.

## Consequences
Site ownership and low-latency reads now have explicit operational surfaces inside the overlay.
