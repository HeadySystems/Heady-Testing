# ADR 0009 — Pgbouncer And Otel Baseline

## Problem

Heady needs a repeatable decision record for why connection pooling and observability are baseline infra rather than optional add-ons.

## Decision

Adopt the pattern packaged in this overlay bundle and treat it as the governed default for new services and site surfaces.

## Consequences

- fewer hidden architecture assumptions
- clearer rollout, rollback, and auditability
- easier onboarding and contract testing across the monorepo
