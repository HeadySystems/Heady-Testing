# 0013 Health Aggregation Surface

## Problem
The overlay health signal depended on external scripts only and lacked a constitutional monitoring endpoint.

## Decision
Add `heady-health` with matrix aggregation based on the local service map.

## Consequences
Operators can now inspect a consistent health matrix through a service endpoint as well as scripts.
