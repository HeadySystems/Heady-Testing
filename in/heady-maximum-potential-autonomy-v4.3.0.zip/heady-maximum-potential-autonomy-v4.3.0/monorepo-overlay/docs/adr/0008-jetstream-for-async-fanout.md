# ADR 0008 — Jetstream For Async Fanout

## Problem

Heady needs a repeatable decision record for why NATS JetStream is the async backbone for durable subjects and DLQs.

## Decision

Adopt the pattern packaged in this overlay bundle and treat it as the governed default for new services and site surfaces.

## Consequences

- fewer hidden architecture assumptions
- clearer rollout, rollback, and auditability
- easier onboarding and contract testing across the monorepo
