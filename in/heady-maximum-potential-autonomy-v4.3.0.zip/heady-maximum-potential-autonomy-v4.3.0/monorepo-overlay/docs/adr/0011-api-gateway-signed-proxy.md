# 0011 API Gateway Signed Proxy

## Problem
The overlay needed a constitutional external ingress layer that can proxy to internal services without trusting unsigned service-to-service calls.

## Decision
Introduce `api-gateway` with shared HMAC request signing and correlation headers for downstream proxy traffic.

## Consequences
Gateway routing becomes explicit, auditable, and harder to spoof from untrusted callers.
