# ADR 0007 — Hybrid Search Service

## Problem

Heady needs a repeatable decision record for why lexical plus vector retrieval ships as one service contract.

## Decision

Adopt the pattern packaged in this overlay bundle and treat it as the governed default for new services and site surfaces.

## Consequences

- fewer hidden architecture assumptions
- clearer rollout, rollback, and auditability
- easier onboarding and contract testing across the monorepo
