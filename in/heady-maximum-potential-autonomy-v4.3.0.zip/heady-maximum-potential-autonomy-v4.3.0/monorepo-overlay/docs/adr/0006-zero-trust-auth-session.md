# ADR 0006 — Zero Trust Auth Session

## Problem

Heady needs a repeatable decision record for why the session exchange moved to `__Host-` cookies and origin allowlists.

## Decision

Adopt the pattern packaged in this overlay bundle and treat it as the governed default for new services and site surfaces.

## Consequences

- fewer hidden architecture assumptions
- clearer rollout, rollback, and auditability
- easier onboarding and contract testing across the monorepo
