# API Collections

The overlay now includes a Postman collection for the authenticated gateway, domain routing, cache, and health surfaces.

## Collection file
- `collections/heady-overlay.postman_collection.json`

## Suggested flow
1. create a session through `auth-session-server`
2. verify the session via `api-gateway`
3. resolve site metadata via `domain-router`
4. warm and read cache entries through signed gateway endpoints
5. inspect the matrix through `heady-health`
