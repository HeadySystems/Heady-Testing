# Developer Onboarding

## Goal

Reach a running local overlay in under five minutes on a machine with Node 20+, Docker, and curl.

## Commands

```bash
bash scripts/setup-dev.sh
npm test
npm run validate
```

## What this boots

- new auth, notification, analytics, billing, search, scheduler, migration, and asset services
- local health matrix validation
- architecture SVG generation
- repo audit summary against the current workspace clone
