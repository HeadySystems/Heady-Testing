# Secrets and Rotation

Production secrets are defined to live in Google Secret Manager or HashiCorp Vault only. Local `.env.example` remains a bootstrap contract and never a production secret store.

## Rotation windows
- API keys: 21 days
- Certificates: 89 days
- Rotation events require RBAC approval and JSONL audit trail

## Enforcement
- see `configs/security/secret-rotation-policy.json`
- see `configs/security/autonomy-guardrails.json`
