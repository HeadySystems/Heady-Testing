# Patent Implementation Map

| Patent Theme | Implementation Surface |
|---|---|
| phi-scaled runtime controls | `shared/phi-math.js`, scheduler intervals, rollout flags |
| CSL-gated decisioning | `shared/csl-gates.js`, hybrid search ordering |
| zero-trust sovereign auth | `services/auth-session-server/` |
| durable async orchestration | `configs/nats/jetstream.conf`, scheduler contracts |
| vector memory retrieval | `services/search-service/src/search-index.js`, migration SQL |
