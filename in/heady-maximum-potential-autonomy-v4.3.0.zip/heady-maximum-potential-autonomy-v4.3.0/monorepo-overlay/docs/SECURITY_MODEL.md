# Security Model

## Principles

- zero-trust between services
- no localStorage token persistence
- httpOnly `__Host-` cookies for session continuity
- schema-first request and response contracts
- structured JSON logging with correlation IDs
- Git-versioned approval trail for production-impacting changes

## Auth flow

1. client receives a Firebase or upstream identity assertion
2. client exchanges it with `auth-session-server`
3. auth service validates origin, applies anonymous quotas, and issues a signed session cookie
4. relay iframe bootstrap uses a strict origin allowlist and frame ancestors policy
5. downstream services verify session token binding on every privileged call

## Secret posture

- production secrets belong in Secret Manager or Vault
- `.env.example` exists only as a contract for local bootstrap
- rotation intervals should be phi-scaled: 21 days for API keys, 89 days for certificates, with immutable audit trails

## WebSocket posture

- auth is rechecked on every inbound frame
- invalid or expired sessions cause immediate disconnect
- channels are never trusted solely because the handshake succeeded
