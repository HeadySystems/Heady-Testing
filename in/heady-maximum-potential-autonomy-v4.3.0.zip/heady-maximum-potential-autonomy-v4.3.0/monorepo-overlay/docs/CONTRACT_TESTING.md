# Contract Testing

The overlay now includes schema-backed contract checks for session and feature-flag payloads.

## Commands
- `npm run contracts`
- `node scripts/full-service-report.js`

## Coverage
- `auth-session-server` session payload contract
- feature-flag rollout payload contract
- service implementation coverage against the 50-service catalog
