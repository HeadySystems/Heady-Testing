# Load Testing

Run `node scripts/load-test.js` to exercise the overlay health endpoints with Fibonacci-sized sample loops. The script boots the local overlay services, collects latency snapshots, and reports per-service averages for a repeatable baseline.

Run `node scripts/chaos-drill.js` to validate restart recovery for the scheduler service using phi-backoff probe timing.
