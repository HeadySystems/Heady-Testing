# ERROR CODES

| Code | HTTP | Service | Meaning |
|---|---:|---|---|
| HEADY-AUTH-001 | 403 | auth-session-server | request origin denied |
| HEADY-AUTH-002 | 401 | auth-session-server | invalid or expired session |
| HEADY-AUTH-003 | 429 | auth-session-server | anonymous or member quota exceeded |
| HEADY-AUTH-004 | 403 | auth-session-server | relay bootstrap denied |
| HEADY-NOTIFY-001 | 401 | notification-service | publish or frame auth failed |
| HEADY-BILLING-001 | 404 | billing-service | requested plan does not exist |
| HEADY-BILLING-002 | 401 | billing-service | webhook signature invalid |
| HEADY-SEARCH-404 | 404 | search-service | route not found |
| HEADY-MIGRATION-404 | 404 | migration-service | route not found |
| HEADY-ASSET-404 | 404 | asset-pipeline | route not found |
