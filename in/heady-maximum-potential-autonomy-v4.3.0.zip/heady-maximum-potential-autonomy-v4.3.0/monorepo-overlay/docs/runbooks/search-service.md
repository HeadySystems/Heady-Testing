# Runbook — search service

## Symptoms

- health endpoint reports degraded behavior
- requests return service-specific error codes

## Diagnosis

- inspect service JSON logs
- verify dependent config files and data paths
- replay the failing request with curl

## Remediation

If search quality or latency degrades, inspect document indexing, lexical tokenization, and embedding normalization.

## Post-incident review

- capture root cause
- record missed signal
- update test coverage if the failure escaped validation
