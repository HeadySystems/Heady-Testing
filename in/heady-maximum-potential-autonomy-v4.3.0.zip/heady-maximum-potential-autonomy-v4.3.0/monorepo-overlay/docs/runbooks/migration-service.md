# migration-service

## Symptoms
- migration status stalls in pending
- checksum mismatch appears during rollout
- rollback state cannot be confirmed

## Diagnosis
1. check `/health/live`
2. inspect `services/migration-service/data/migration-state.json`
3. compare checksums against `services/migration-service/migrations/`
4. verify backup manifest exists before rerunning migrations

## Remediation
- restore the last successful migration state
- replay migrations in order with checksum verification
- block rollout if rollback metadata is incomplete
