# scheduler-service

## Symptoms
- jobs stop advancing
- recurring workloads drift beyond phi window
- inspection endpoint shows stale nextRunAt

## Diagnosis
1. call `/health/live`
2. review `services/scheduler-service/data/jobs.json`
3. inspect logs for `job_failed` and `job_scheduled`
4. run `node scripts/chaos-drill.js` to verify restart recovery

## Remediation
- restore last known job snapshot from backups
- restart the scheduler and requeue failed jobs
- widen workload distribution rather than adding priority ordering
