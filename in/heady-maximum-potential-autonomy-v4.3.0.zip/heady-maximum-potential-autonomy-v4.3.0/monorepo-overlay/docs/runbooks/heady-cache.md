# heady-cache

## Symptoms
- cache hits unexpectedly miss
- gateway set or get operations return 401
- cache capacity saturates

## Diagnosis
1. check `/health/live`
2. inspect `/cache/stats`
3. verify `HEADY_INTERSERVICE_SECRET` alignment when requests are signed

## Remediation
- restore shared secret alignment
- widen value distribution rather than introducing priority order
- restart the cache service if stale in-memory state persists
