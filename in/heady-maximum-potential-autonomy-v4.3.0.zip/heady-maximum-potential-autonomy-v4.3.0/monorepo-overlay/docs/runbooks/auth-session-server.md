# Runbook — auth session server

## Symptoms

- health endpoint reports degraded behavior
- requests return service-specific error codes

## Diagnosis

- inspect service JSON logs
- verify dependent config files and data paths
- replay the failing request with curl

## Remediation

If auth starts failing, inspect trusted origins, cookie issuance, and binding mismatch responses before restarting the service.

## Post-incident review

- capture root cause
- record missed signal
- update test coverage if the failure escaped validation
