# heady-health

## Symptoms
- matrix output shows repeated unhealthy services
- health aggregation stalls

## Diagnosis
1. check `/health/live`
2. call `/matrix`
3. verify `configs/services/local-service-map.json` matches the active overlay service set

## Remediation
- restore missing services to the service map
- restart failed services and re-run the matrix aggregation
