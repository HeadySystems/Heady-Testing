# Runbook — notification service

## Symptoms

- health endpoint reports degraded behavior
- requests return service-specific error codes

## Diagnosis

- inspect service JSON logs
- verify dependent config files and data paths
- replay the failing request with curl

## Remediation

If real-time delivery fails, inspect SSE subscribers, WebSocket frame validation, and session expiry handling.

## Post-incident review

- capture root cause
- record missed signal
- update test coverage if the failure escaped validation
