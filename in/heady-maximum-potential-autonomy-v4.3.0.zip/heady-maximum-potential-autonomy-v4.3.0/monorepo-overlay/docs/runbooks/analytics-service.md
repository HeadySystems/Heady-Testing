# analytics-service

## Symptoms
- ingestion latency spikes
- funnel summaries stop updating
- durable event file growth stalls

## Diagnosis
1. check `/health/live`
2. inspect `services/analytics-service/data/events.jsonl`
3. verify structured logs contain `request_failed` or `event_ingested`
4. confirm downstream storage path remains writable

## Remediation
- restart service with fresh writable volume
- rotate oversized JSONL files into backup storage
- replay buffered events after storage is restored
