# asset-pipeline

## Symptoms
- manifest generation fails
- responsive variants are missing
- digest mismatches appear between deploy stages

## Diagnosis
1. check `/health/live`
2. inspect generated asset manifest output
3. confirm digest generation path is writable
4. verify CDN metadata contract remains immutable

## Remediation
- regenerate the manifest and compare digests
- clear only the affected variant set, not the full asset fleet
- redeploy after SRI values are refreshed
