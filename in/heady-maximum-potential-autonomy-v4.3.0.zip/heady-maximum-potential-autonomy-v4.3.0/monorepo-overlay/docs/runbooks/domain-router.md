# domain-router

## Symptoms
- hosts resolve to the wrong site metadata
- admin surfaces route to stale destinations

## Diagnosis
1. check `/health/live`
2. inspect `configs/domains/domain-map.json`
3. query `/resolve?host=headysystems.com`

## Remediation
- update the domain map and redeploy the router
- keep site metadata synchronized with service ownership
