# Backup and Recovery

## Strategy
- nightly logical backup manifest for vector memory overlays
- point-in-time recovery window of 55 hours
- retention of 34 days before archival rotation

## Validation
- run `node scripts/backup-pgvector.js --dry-run`
- confirm the backup manifest includes auth, search, scheduler, and migration state files
- store digests with immutable audit records

## Recovery
1. restore the latest manifest
2. replay WAL archive into a shadow environment
3. verify search index and migration state before production cutover
