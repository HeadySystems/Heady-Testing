# api-gateway

## Symptoms
- gateway routes return 502
- inter-service signature verification fails
- route catalog diverges from downstream availability

## Diagnosis
1. check `/health/live`
2. inspect `configs/services/api-gateway-routes.json`
3. verify `HEADY_INTERSERVICE_SECRET` alignment across gateway and targets
4. review JSON logs for `gateway_proxy_failed`

## Remediation
- restore shared secret alignment
- remove stale routes or restore downstream service availability
- replay requests through signed gateway flow after fix
