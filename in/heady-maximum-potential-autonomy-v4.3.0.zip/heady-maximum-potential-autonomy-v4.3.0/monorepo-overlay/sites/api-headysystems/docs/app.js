document.querySelectorAll('[data-now]').forEach((node) => {
  node.textContent = new Date().toLocaleString();
});
