datacenter = "heady-us-east1"
data_dir = "/consul/data"
server = false
retry_join = ["consul-server.service.consul"]
ports {
  grpc = 8502
  http = 8500
}
connect {
  enabled = true
}
telemetry {
  prometheus_retention_time = "21m"
}
service {
  name = "heady-overlay"
  port = 4310
  tags = ["domain:security", "mode:concurrent-equals"]
}
