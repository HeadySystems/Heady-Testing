const { fib } = require('../../../shared/phi-math');

function createCacheStore(maxEntries = fib(8)) {
  const cache = new Map();

  function purgeExpired(now = Date.now()) {
    for (const [key, value] of cache.entries()) {
      if (value.expiresAt <= now) {
        cache.delete(key);
      }
    }
  }

  function set(key, value, ttlSeconds = fib(9)) {
    purgeExpired();
    if (cache.has(key)) {
      cache.delete(key);
    }
    cache.set(key, { value, expiresAt: Date.now() + ttlSeconds * 1000 });
    while (cache.size > maxEntries) {
      const oldestKey = cache.keys().next().value;
      cache.delete(oldestKey);
    }
    return { key, value, ttlSeconds, size: cache.size };
  }

  function get(key) {
    purgeExpired();
    const hit = cache.get(key);
    if (!hit) {
      return { ok: false };
    }
    cache.delete(key);
    cache.set(key, hit);
    return { ok: true, key, value: hit.value };
  }

  return {
    set,
    get,
    stats() {
      purgeExpired();
      return { size: cache.size, maxEntries };
    }
  };
}

module.exports = { createCacheStore };
