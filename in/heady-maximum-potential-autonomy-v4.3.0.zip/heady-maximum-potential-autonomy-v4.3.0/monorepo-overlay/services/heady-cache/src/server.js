const http = require('http');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readBody, sendJson, requestUrl } = require('../../../shared/http-helpers');
const { verifySignedRequest } = require('../../../shared/interservice-auth');
const { createCacheStore } = require('./cache-store');

const logger = createLogger('heady-cache');
const port = Number(process.env.PORT || 4322);
const store = createCacheStore();

function verifyIfSigned(req, rawBody) {
  if (!req.headers['x-heady-source']) {
    return { ok: true };
  }
  return verifySignedRequest(rawBody, req.headers['x-heady-signature'], req.headers['x-heady-source'], req.headers['x-heady-timestamp']);
}

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'heady-cache', ...store.stats() });
    }
    if (req.method === 'GET' && url.pathname === '/cache/stats') {
      return sendJson(res, 200, { ok: true, ...store.stats() });
    }
    if (req.method === 'POST' && (url.pathname === '/cache/set' || url.pathname === '/cache/get')) {
      const rawBody = await readBody(req);
      const verification = verifyIfSigned(req, rawBody);
      if (!verification.ok) {
        return sendJson(res, 401, { error: 'HEADY-CACHE-401', ...verification });
      }
      const body = rawBody ? JSON.parse(rawBody) : {};
      if (url.pathname === '/cache/set') {
        return sendJson(res, 200, { ok: true, entry: store.set(body.key, body.value, Number(body.ttlSeconds || 55)) });
      }
      return sendJson(res, 200, store.get(body.key));
    }
    return sendJson(res, 404, { error: 'HEADY-CACHE-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-CACHE-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server, store };
