# heady-cache

## Failure modes
- cache saturation beyond Fibonacci entry cap
- expired entries not purged on read path
- signature validation failure on gateway writes

## Local checks
- `curl http://127.0.0.1:4322/health/live`
- use api-gateway cache routes to confirm set and get behavior
