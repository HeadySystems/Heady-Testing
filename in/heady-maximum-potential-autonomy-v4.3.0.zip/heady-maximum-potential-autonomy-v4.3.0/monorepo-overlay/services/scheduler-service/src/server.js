const http = require('http');
const fs = require('fs');
const path = require('path');
const { fib, phiBackoff } = require('../../../shared/phi-math');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readJson, sendJson, requestUrl } = require('../../../shared/http-helpers');

const logger = createLogger('scheduler-service');
const port = Number(process.env.PORT || 4315);
const dataDir = path.join(__dirname, '..', 'data');
const jobsPath = path.join(dataDir, 'jobs.json');
fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(jobsPath)) fs.writeFileSync(jobsPath, JSON.stringify({ jobs: [
  { name: 'projection-maintenance', intervalSeconds: fib(8), lastRunAt: null },
  { name: 'analytics-rollup', intervalSeconds: fib(9), lastRunAt: null },
  { name: 'secret-rotation-review', intervalSeconds: fib(12), lastRunAt: null }
] }, null, 2));

function readJobs() { return JSON.parse(fs.readFileSync(jobsPath, 'utf8')); }
function writeJobs(data) { fs.writeFileSync(jobsPath, JSON.stringify(data, null, 2)); }

function dueJobs() {
  const now = Date.now();
  return readJobs().jobs.filter(job => !job.lastRunAt || now - Date.parse(job.lastRunAt) >= job.intervalSeconds * 1000);
}

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'scheduler-service' });
    }
    if (req.method === 'GET' && url.pathname === '/jobs') {
      return sendJson(res, 200, readJobs());
    }
    if (req.method === 'POST' && url.pathname === '/jobs/run-due') {
      const state = readJobs();
      const due = dueJobs();
      const nowIso = new Date().toISOString();
      state.jobs = state.jobs.map(job => due.some(item => item.name === job.name) ? { ...job, lastRunAt: nowIso } : job);
      writeJobs(state);
      return sendJson(res, 200, { ok: true, ran: due.map(job => ({ ...job, nextBackoffMs: phiBackoff(3) })) });
    }
    if (req.method === 'POST' && url.pathname === '/jobs/register') {
      const body = await readJson(req);
      const state = readJobs();
      state.jobs.push({ name: body.name, intervalSeconds: Number(body.intervalSeconds || fib(8)), lastRunAt: null });
      writeJobs(state);
      return sendJson(res, 200, { ok: true, jobs: state.jobs });
    }
    return sendJson(res, 404, { error: 'HEADY-SCHEDULER-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-SCHEDULER-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server, dueJobs };
