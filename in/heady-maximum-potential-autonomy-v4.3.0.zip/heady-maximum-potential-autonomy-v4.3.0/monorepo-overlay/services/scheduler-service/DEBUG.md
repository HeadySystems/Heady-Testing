# DEBUG — scheduler-service

## Health
- live: `GET /health/live`
- jobs: `GET /jobs`
- run due jobs: `POST /jobs/run-due`
