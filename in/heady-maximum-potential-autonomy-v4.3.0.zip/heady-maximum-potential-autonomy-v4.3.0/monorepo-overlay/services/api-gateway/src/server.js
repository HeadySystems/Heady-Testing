const http = require('http');
const fs = require('fs');
const path = require('path');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readBody, sendJson, requestUrl } = require('../../../shared/http-helpers');
const { signedHeaders } = require('../../../shared/interservice-auth');
const { loadServiceMap } = require('../../../shared/service-map');

const logger = createLogger('api-gateway');
const port = Number(process.env.PORT || 4320);
const routeConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', '..', 'configs', 'services', 'api-gateway-routes.json'), 'utf8'));

function resolveTargetService(name) {
  const map = loadServiceMap();
  const service = map.services[name];
  if (!service) {
    throw new Error(`Unknown target service: ${name}`);
  }
  return `http://127.0.0.1:${service.port}`;
}

async function proxyJson(route, rawBody, context) {
  const body = rawBody || '{}';
  const targetUrl = `${resolveTargetService(route.target)}${route.targetPath}`;
  const response = await fetch(targetUrl, {
    method: route.method,
    headers: signedHeaders(body, 'api-gateway', context.requestId),
    body: route.method === 'GET' ? undefined : body
  });
  const text = await response.text();
  return { status: response.status, text };
}

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'api-gateway' });
    }
    if (req.method === 'GET' && url.pathname === '/gateway/routes') {
      return sendJson(res, 200, routeConfig);
    }
    const route = routeConfig.routes.find(item => item.publicPath === url.pathname && item.method === req.method);
    if (!route) {
      return sendJson(res, 404, { error: 'HEADY-GATEWAY-404', message: 'Route not found.' });
    }
    const rawBody = req.method === 'GET' ? '' : await readBody(req);
    const proxied = await proxyJson(route, rawBody, context);
    res.writeHead(proxied.status, { 'content-type': 'application/json; charset=utf-8' });
    res.end(proxied.text);
  } catch (error) {
    logger.error('gateway_proxy_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 502, { error: 'HEADY-GATEWAY-502', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server, resolveTargetService };
