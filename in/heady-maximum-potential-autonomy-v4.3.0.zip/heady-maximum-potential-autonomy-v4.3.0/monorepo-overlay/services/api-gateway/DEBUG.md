# api-gateway

## Failure modes
- internal route signature mismatch
- downstream search or auth dependency unavailable
- route catalog drift from config

## Local checks
- `curl http://127.0.0.1:4320/health/live`
- `curl http://127.0.0.1:4320/gateway/routes`
- inspect JSON logs for `gateway_proxy_failed`
