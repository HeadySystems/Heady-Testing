const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { sendJson, requestUrl } = require('../../../shared/http-helpers');

const logger = createLogger('migration-service');
const port = Number(process.env.PORT || 4316);
const dataDir = path.join(__dirname, '..', 'data');
const statePath = path.join(dataDir, 'migration-state.json');
const migrationsDir = path.join(__dirname, '..', 'migrations');
fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(statePath)) fs.writeFileSync(statePath, JSON.stringify({ applied: [] }, null, 2));

function readState() { return JSON.parse(fs.readFileSync(statePath, 'utf8')); }
function writeState(state) { fs.writeFileSync(statePath, JSON.stringify(state, null, 2)); }
function listMigrations() {
  return fs.readdirSync(migrationsDir).filter(file => file.endsWith('.sql')).sort().map(file => {
    const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
    return { name: file, checksum: crypto.createHash('sha256').update(sql).digest('hex'), sql };
  });
}

const server = http.createServer((req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'migration-service' });
    }
    if (req.method === 'GET' && url.pathname === '/status') {
      return sendJson(res, 200, { migrations: listMigrations(), state: readState() });
    }
    if (req.method === 'POST' && url.pathname === '/apply') {
      const state = readState();
      for (const migration of listMigrations()) {
        if (!state.applied.find(item => item.name == migration.name)) {
          state.applied.push({ name: migration.name, checksum: migration.checksum, appliedAt: new Date().toISOString() });
        }
      }
      writeState(state);
      return sendJson(res, 200, { ok: true, applied: state.applied });
    }
    if (req.method === 'POST' && url.pathname === '/rollback-last') {
      const state = readState();
      const rolledBack = state.applied.pop() || null;
      writeState(state);
      return sendJson(res, 200, { ok: true, rolledBack, remaining: state.applied });
    }
    return sendJson(res, 404, { error: 'HEADY-MIGRATION-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-MIGRATION-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server, listMigrations };
