CREATE TABLE IF NOT EXISTS vector_memory (
  id TEXT PRIMARY KEY,
  domain TEXT NOT NULL,
  embedding VECTOR(384),
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
