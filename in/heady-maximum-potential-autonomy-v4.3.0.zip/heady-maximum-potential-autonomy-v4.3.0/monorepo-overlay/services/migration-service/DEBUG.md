# DEBUG — migration-service

## Health
- live: `GET /health/live`
- status: `GET /status`
- apply: `POST /apply`
- rollback: `POST /rollback-last`
