const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const { fib } = require('../../../shared/phi-math');

const secret = process.env.HEADY_SESSION_SECRET || 'heady-dev-session-secret';
const dataDir = path.join(__dirname, '..', 'data');
const sessionPath = path.join(dataDir, 'sessions.json');

function ensureStore() {
  fs.mkdirSync(dataDir, { recursive: true });
  if (!fs.existsSync(sessionPath)) {
    fs.writeFileSync(sessionPath, JSON.stringify({ sessions: [] }, null, 2));
  }
}

function readStore() {
  ensureStore();
  return JSON.parse(fs.readFileSync(sessionPath, 'utf8'));
}

function writeStore(data) {
  ensureStore();
  fs.writeFileSync(sessionPath, JSON.stringify(data, null, 2));
}

function base64url(input) {
  return Buffer.from(input).toString('base64url');
}

function signSession(payload) {
  const header = { alg: 'HS256', typ: 'JWT', kid: process.env.HEADY_API_KEYS_KID || 'key-v1' };
  const encodedHeader = base64url(JSON.stringify(header));
  const encodedPayload = base64url(JSON.stringify(payload));
  const signature = crypto.createHmac('sha256', secret).update(`${encodedHeader}.${encodedPayload}`).digest('base64url');
  return `${encodedHeader}.${encodedPayload}.${signature}`;
}

function hashBinding(ip, userAgent) {
  return crypto.createHmac('sha256', secret).update(`${ip}:${userAgent}`).digest('hex');
}

function createSession({ sub, provider, roles = [], anonymous = false, ip, userAgent, origin }) {
  const issuedAt = Math.floor(Date.now() / 1000);
  const ttlSeconds = fib(10) * fib(9);
  const payload = {
    sub,
    provider,
    roles,
    anonymous,
    origin,
    iat: issuedAt,
    exp: issuedAt + ttlSeconds,
    binding: hashBinding(ip, userAgent)
  };
  const token = signSession(payload);
  const store = readStore();
  store.sessions.push({ token, ...payload });
  writeStore(store);
  return { token, payload };
}

function verifySession(token, ip, userAgent) {
  const [encodedHeader, encodedPayload, signature] = String(token || '').split('.');
  if (!encodedHeader || !encodedPayload || !signature) {
    return { ok: false, reason: 'missing_token_parts' };
  }
  const expected = crypto.createHmac('sha256', secret).update(`${encodedHeader}.${encodedPayload}`).digest('base64url');
  if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
    return { ok: false, reason: 'invalid_signature' };
  }
  const payload = JSON.parse(Buffer.from(encodedPayload, 'base64url').toString('utf8'));
  if (payload.exp < Math.floor(Date.now() / 1000)) {
    return { ok: false, reason: 'expired' };
  }
  if (payload.binding !== hashBinding(ip, userAgent)) {
    return { ok: false, reason: 'binding_mismatch' };
  }
  return { ok: true, payload };
}

const quotaState = new Map();

function checkQuota(subject, anonymous) {
  const limit = anonymous ? fib(8) : fib(10);
  const enterpriseLimit = fib(12);
  const effectiveLimit = subject.startsWith('enterprise:') ? enterpriseLimit : limit;
  const nowWindow = Math.floor(Date.now() / 60000);
  const key = `${subject}:${nowWindow}`;
  const current = quotaState.get(key) || 0;
  if (current >= effectiveLimit) {
    return { ok: false, limit: effectiveLimit, count: current };
  }
  quotaState.set(key, current + 1);
  return { ok: true, limit: effectiveLimit, count: current + 1 };
}

module.exports = {
  createSession,
  verifySession,
  checkQuota,
  hashBinding
};
