const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '..', '..', '..', 'configs', 'auth', 'trusted-origins.json');

function loadOrigins() {
  return JSON.parse(fs.readFileSync(configPath, 'utf8'));
}

function isAllowedOrigin(origin) {
  const { relayOrigins } = loadOrigins();
  return relayOrigins.includes(origin);
}

module.exports = { loadOrigins, isAllowedOrigin };
