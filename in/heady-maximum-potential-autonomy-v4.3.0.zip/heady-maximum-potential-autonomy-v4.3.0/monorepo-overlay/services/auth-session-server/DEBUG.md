# DEBUG — auth-session-server

## Health
- live: `GET /health/live`
- ready: `GET /health/ready`

## Common failures
- `HEADY-AUTH-001`: request origin is not allowlisted in `configs/auth/trusted-origins.json`
- `HEADY-AUTH-002`: missing, expired, or client-mismatched session token
- `HEADY-AUTH-003`: anonymous or member quota exceeded within the current minute bucket
- `HEADY-AUTH-004`: relay iframe bootstrap denied because the source origin is not trusted

## Local test procedure
1. `node src/server.js`
2. `curl -X POST http://127.0.0.1:4310/session/create -H 'content-type: application/json' -d '{"subject":"user:1","origin":"https://headysystems.com"}' -i`
3. replay the returned cookie to `POST /session/verify`
