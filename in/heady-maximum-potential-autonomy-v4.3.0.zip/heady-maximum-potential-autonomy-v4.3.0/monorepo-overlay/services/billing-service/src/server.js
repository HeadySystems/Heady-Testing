const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readJson, sendJson, requestUrl } = require('../../../shared/http-helpers');

const logger = createLogger('billing-service');
const port = Number(process.env.PORT || 4313);
const plans = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', '..', 'configs', 'billing', 'plans.json'), 'utf8'));
const dataDir = path.join(__dirname, '..', 'data');
const ledgerPath = path.join(dataDir, 'ledger.jsonl');
fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(ledgerPath)) fs.writeFileSync(ledgerPath, '');

function appendLedger(entry) {
  fs.appendFileSync(ledgerPath, `${JSON.stringify(entry)}\n`);
}

function verifyStripeSignature(payload, signatureHeader) {
  const secret = process.env.HEADY_STRIPE_WEBHOOK_SECRET || 'heady-stripe-webhook-secret';
  const expected = crypto.createHmac('sha256', secret).update(payload).digest('hex');
  return signatureHeader === expected;
}

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'billing-service' });
    }
    if (req.method === 'GET' && url.pathname === '/plans') {
      return sendJson(res, 200, plans);
    }
    if (req.method === 'POST' && url.pathname === '/checkout-intent') {
      const body = await readJson(req);
      const plan = plans.plans.find(item => item.id === body.planId);
      if (!plan) {
        return sendJson(res, 404, { error: 'HEADY-BILLING-001', message: 'Plan not found.' });
      }
      const quantity = Number(body.quantity || 1);
      const intent = {
        customerId: body.customerId,
        planId: plan.id,
        quantity,
        amount: plan.monthly * quantity,
        currency: plans.currency,
        createdAt: new Date().toISOString(),
        mode: 'subscription'
      };
      appendLedger({ type: 'checkout_intent', ...intent });
      return sendJson(res, 200, { ok: true, intent });
    }
    if (req.method === 'POST' && url.pathname === '/webhooks/stripe') {
      const chunks = [];
      for await (const chunk of req) chunks.push(Buffer.from(chunk));
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!verifyStripeSignature(raw, req.headers['stripe-signature'])) {
        return sendJson(res, 401, { error: 'HEADY-BILLING-002', message: 'Invalid webhook signature.' });
      }
      const event = JSON.parse(raw);
      appendLedger({ type: 'stripe_webhook', event, receivedAt: new Date().toISOString() });
      return sendJson(res, 200, { ok: true });
    }
    return sendJson(res, 404, { error: 'HEADY-BILLING-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-BILLING-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server, verifyStripeSignature };
