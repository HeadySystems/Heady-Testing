# DEBUG — billing-service

## Health
- live: `GET /health/live`
- plans: `GET /plans`
- checkout intent: `POST /checkout-intent`
- Stripe webhooks: `POST /webhooks/stripe`
