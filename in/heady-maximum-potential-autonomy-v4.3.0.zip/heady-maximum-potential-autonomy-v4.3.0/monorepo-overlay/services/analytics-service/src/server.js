const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readJson, sendJson, requestUrl } = require('../../../shared/http-helpers');
const { fib } = require('../../../shared/phi-math');

const logger = createLogger('analytics-service');
const port = Number(process.env.PORT || 4312);
const dataDir = path.join(__dirname, '..', 'data');
const eventsPath = path.join(dataDir, 'events.jsonl');
const salt = process.env.HEADY_ANALYTICS_SALT || 'heady-analytics-salt';
fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(eventsPath)) fs.writeFileSync(eventsPath, '');

function hashActor(actor) {
  return crypto.createHmac('sha256', salt).update(actor || 'anonymous').digest('hex');
}

function readEvents() {
  const lines = fs.readFileSync(eventsPath, 'utf8').trim();
  if (!lines) return [];
  return lines.split('\n').map(line => JSON.parse(line));
}

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'analytics-service' });
    }
    if (req.method === 'POST' && url.pathname === '/ingest') {
      const body = await readJson(req);
      const event = {
        eventName: body.eventName,
        occurredAt: body.occurredAt || new Date().toISOString(),
        actorHash: hashActor(body.actorId || body.anonymousId || context.ip),
        properties: body.properties || {},
        source: body.source || 'heady'
      };
      fs.appendFileSync(eventsPath, `${JSON.stringify(event)}\n`);
      return sendJson(res, 200, { ok: true, event });
    }
    if (req.method === 'GET' && url.pathname === '/summary') {
      const windowMinutes = Number(url.searchParams.get('windowMinutes') || fib(9));
      const cutoff = Date.now() - windowMinutes * 60000;
      const events = readEvents().filter(event => Date.parse(event.occurredAt) >= cutoff);
      const byEvent = {};
      for (const event of events) {
        byEvent[event.eventName] = (byEvent[event.eventName] || 0) + 1;
      }
      return sendJson(res, 200, {
        ok: true,
        windowMinutes,
        totalEvents: events.length,
        uniqueActors: new Set(events.map(event => event.actorHash)).size,
        byEvent
      });
    }
    return sendJson(res, 404, { error: 'HEADY-ANALYTICS-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-ANALYTICS-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server };
