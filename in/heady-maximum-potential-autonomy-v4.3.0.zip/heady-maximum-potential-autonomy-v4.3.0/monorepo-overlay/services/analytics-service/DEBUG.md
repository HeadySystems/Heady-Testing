# DEBUG — analytics-service

## Health
- live: `GET /health/live`
- ingest: `POST /ingest`
- summary: `GET /summary?windowMinutes=34`

## Failure modes
- malformed JSON body on ingest
- unwritable JSONL data path in `services/analytics-service/data/`
