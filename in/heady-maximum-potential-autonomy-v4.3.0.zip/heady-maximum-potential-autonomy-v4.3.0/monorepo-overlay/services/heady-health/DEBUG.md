# heady-health

## Failure modes
- service map drift leaves health matrix incomplete
- upstream services fail to answer within probe window

## Local checks
- `curl http://127.0.0.1:4323/health/live`
- `curl http://127.0.0.1:4323/matrix`
