const { loadServiceMap } = require('../../../shared/service-map');

async function buildMatrix(skipServices = new Set()) {
  const map = loadServiceMap();
  const results = [];
  for (const [service, details] of Object.entries(map.services)) {
    if (skipServices.has(service)) {
      continue;
    }
    const response = await fetch(`http://127.0.0.1:${details.port}/health/live`);
    results.push({ service, port: details.port, status: response.status, body: await response.json() });
  }
  return results;
}

module.exports = { buildMatrix };
