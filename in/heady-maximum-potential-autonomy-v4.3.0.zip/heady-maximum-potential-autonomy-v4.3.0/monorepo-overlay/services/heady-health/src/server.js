const http = require('http');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { sendJson, requestUrl } = require('../../../shared/http-helpers');
const { buildMatrix } = require('./health-checks');

const logger = createLogger('heady-health');
const port = Number(process.env.PORT || 4323);

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'heady-health' });
    }
    if (req.method === 'GET' && url.pathname === '/matrix') {
      const matrix = await buildMatrix(new Set(['heady-health']));
      return sendJson(res, 200, { ok: true, results: matrix });
    }
    return sendJson(res, 404, { error: 'HEADY-HEALTH-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-HEALTH-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server };
