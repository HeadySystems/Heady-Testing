# DEBUG — notification-service

## Health
- live: `GET /health/live`
- SSE: `GET /events?channel=global`
- publish: `POST /publish`

## Common failures
- `HEADY-NOTIFY-001`: session token missing, expired, or client binding mismatch
- WebSocket disconnect after first frame: token was not revalidated successfully on a client message
