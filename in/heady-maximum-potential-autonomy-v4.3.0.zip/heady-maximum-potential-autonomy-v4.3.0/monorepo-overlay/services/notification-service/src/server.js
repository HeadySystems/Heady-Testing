const http = require('http');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readJson, sendJson, requestUrl } = require('../../../shared/http-helpers');
const { verifySession } = require('../../auth-session-server/src/session-store');
const { acceptKey, encodeFrame, decodeFrame } = require('./websocket');

const logger = createLogger('notification-service');
const port = Number(process.env.PORT || 4311);
const channels = new Map();
const sockets = new Set();

function broadcast(channel, packet) {
  const encoded = `event: ${packet.event}\ndata: ${JSON.stringify(packet.data)}\n\n`;
  for (const res of channels.get(channel) || []) {
    res.write(encoded);
  }
  for (const socket of sockets) {
    if (socket.channels.has(channel)) {
      socket.socket.write(encodeFrame(JSON.stringify(packet)));
    }
  }
}

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'notification-service' });
    }
    if (req.method === 'GET' && url.pathname === '/events') {
      const channel = url.searchParams.get('channel') || 'global';
      res.writeHead(200, {
        'content-type': 'text/event-stream',
        'cache-control': 'no-store',
        connection: 'keep-alive'
      });
      if (!channels.has(channel)) {
        channels.set(channel, new Set());
      }
      channels.get(channel).add(res);
      res.write(`event: ready\ndata: ${JSON.stringify({ channel })}\n\n`);
      req.on('close', () => channels.get(channel)?.delete(res));
      return;
    }
    if (req.method === 'POST' && url.pathname === '/publish') {
      const body = await readJson(req);
      const session = verifySession(body.token, context.ip, context.userAgent);
      if (!session.ok) {
        return sendJson(res, 401, { error: 'HEADY-NOTIFY-001', reason: session.reason });
      }
      const packet = {
        channel: body.channel || 'global',
        event: body.event || 'message',
        data: {
          ...body.data,
          actor: session.payload.sub,
          at: new Date().toISOString()
        }
      };
      broadcast(packet.channel, packet);
      return sendJson(res, 200, { ok: true, delivered: true, packet });
    }
    if (req.method === 'POST' && url.pathname === '/push/subscribe') {
      const body = await readJson(req);
      return sendJson(res, 200, {
        ok: true,
        subscription: {
          endpoint: body.endpoint,
          channel: body.channel || 'global',
          savedAt: new Date().toISOString()
        }
      });
    }
    return sendJson(res, 404, { error: 'HEADY-NOTIFY-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-NOTIFY-500', message: error.message });
  }
});

server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key) {
    socket.destroy();
    return;
  }
  socket.write([
    'HTTP/1.1 101 Switching Protocols',
    'Upgrade: websocket',
    'Connection: Upgrade',
    `Sec-WebSocket-Accept: ${acceptKey(key)}`,
    '',
    ''
  ].join('\r\n'));
  const client = { socket, channels: new Set(['global']) };
  sockets.add(client);
  socket.on('data', chunk => {
    const text = decodeFrame(Buffer.from(chunk));
    if (!text) {
      return;
    }
    try {
      const message = JSON.parse(text);
      const session = verifySession(message.token, (req.socket.remoteAddress || '').replace('::ffff:', '') || '0.0.0.0', req.headers['user-agent'] || 'unknown');
      if (!session.ok) {
        socket.write(encodeFrame(JSON.stringify({ event: 'error', data: { reason: session.reason } })));
        socket.destroy();
        return;
      }
      if (message.action === 'subscribe' && message.channel) {
        client.channels.add(message.channel);
        socket.write(encodeFrame(JSON.stringify({ event: 'subscribed', data: { channel: message.channel } })));
        return;
      }
      if (message.action === 'publish') {
        broadcast(message.channel || 'global', {
          channel: message.channel || 'global',
          event: message.event || 'message',
          data: { ...message.data, actor: session.payload.sub, at: new Date().toISOString() }
        });
      }
    } catch (error) {
      socket.write(encodeFrame(JSON.stringify({ event: 'error', data: { message: error.message } })));
    }
  });
  socket.on('close', () => sockets.delete(client));
  socket.on('error', () => sockets.delete(client));
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server };
