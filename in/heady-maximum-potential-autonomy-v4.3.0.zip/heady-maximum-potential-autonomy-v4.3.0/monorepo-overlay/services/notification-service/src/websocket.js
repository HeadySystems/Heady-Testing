const crypto = require('crypto');

function acceptKey(key) {
  return crypto.createHash('sha1').update(`${key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`).digest('base64');
}

function encodeFrame(payload) {
  const data = Buffer.from(payload, 'utf8');
  const header = [0x81];
  if (data.length < 126) {
    header.push(data.length);
    return Buffer.concat([Buffer.from(header), data]);
  }
  header.push(126, data.length >> 8, data.length & 255);
  return Buffer.concat([Buffer.from(header), data]);
}

function decodeFrame(buffer) {
  const first = buffer[0];
  const second = buffer[1];
  const masked = Boolean(second & 0x80);
  let length = second & 0x7f;
  let offset = 2;
  if (length === 126) {
    length = buffer.readUInt16BE(offset);
    offset += 2;
  }
  const mask = masked ? buffer.subarray(offset, offset + 4) : null;
  offset += masked ? 4 : 0;
  const payload = buffer.subarray(offset, offset + length);
  if (!masked) {
    return payload.toString('utf8');
  }
  for (let index = 0; index < payload.length; index += 1) {
    payload[index] ^= mask[index % 4];
  }
  return payload.toString('utf8');
}

module.exports = { acceptKey, encodeFrame, decodeFrame };
