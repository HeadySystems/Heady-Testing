# domain-router

## Failure modes
- host not present in domain map
- stale domain metadata after config changes

## Local checks
- `curl http://127.0.0.1:4321/resolve?host=headysystems.com`
- `curl http://127.0.0.1:4321/sites`
