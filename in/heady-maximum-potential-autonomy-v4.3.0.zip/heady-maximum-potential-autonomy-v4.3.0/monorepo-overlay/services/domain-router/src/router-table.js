const fs = require('fs');
const path = require('path');

function loadDomainMap() {
  return JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', '..', 'configs', 'domains', 'domain-map.json'), 'utf8'));
}

function resolveHost(host) {
  const map = loadDomainMap();
  return map.domains[host] || null;
}

module.exports = {
  loadDomainMap,
  resolveHost
};
