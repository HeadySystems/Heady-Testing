const http = require('http');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { sendJson, requestUrl } = require('../../../shared/http-helpers');
const { resolveHost, loadDomainMap } = require('./router-table');

const logger = createLogger('domain-router');
const port = Number(process.env.PORT || 4321);

const server = http.createServer((req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'domain-router' });
    }
    if (req.method === 'GET' && url.pathname === '/resolve') {
      const host = url.searchParams.get('host') || '';
      const resolved = resolveHost(host);
      if (!resolved) {
        return sendJson(res, 404, { error: 'HEADY-ROUTER-404', message: 'Host not found.' });
      }
      return sendJson(res, 200, { ok: true, host, resolved });
    }
    if (req.method === 'GET' && url.pathname === '/sites') {
      return sendJson(res, 200, loadDomainMap());
    }
    return sendJson(res, 404, { error: 'HEADY-ROUTER-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-ROUTER-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server };
