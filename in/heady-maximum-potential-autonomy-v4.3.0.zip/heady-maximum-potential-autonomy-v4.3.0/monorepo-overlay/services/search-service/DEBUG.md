# DEBUG — search-service

## Health
- live: `GET /health/live`
- index: `POST /index`
- search: `POST /search`
