const fs = require('fs');
const path = require('path');
const { concurrentEqualsMerge } = require('../../../shared/csl-gates');

const dims = 384;
const dataDir = path.join(__dirname, '..', 'data');
const indexPath = path.join(dataDir, 'index.json');
fs.mkdirSync(dataDir, { recursive: true });
if (!fs.existsSync(indexPath)) fs.writeFileSync(indexPath, JSON.stringify({ documents: [] }, null, 2));

function tokenize(text) {
  return String(text || '').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
}

function createEmbedding(text) {
  const vector = Array.from({ length: dims }, () => 0);
  for (const token of tokenize(text)) {
    let hash = 0;
    for (const char of token) hash = (hash * 31 + char.charCodeAt(0)) % dims;
    vector[hash] += 1;
  }
  const magnitude = Math.sqrt(vector.reduce((sum, value) => sum + value * value, 0)) || 1;
  return vector.map(value => value / magnitude);
}

function cosine(left, right) {
  let total = 0;
  for (let index = 0; index < left.length; index += 1) total += left[index] * right[index];
  return total;
}

function readIndex() {
  return JSON.parse(fs.readFileSync(indexPath, 'utf8'));
}

function writeIndex(data) {
  fs.writeFileSync(indexPath, JSON.stringify(data, null, 2));
}

function addDocument(document) {
  const index = readIndex();
  const lexical = tokenize(`${document.title} ${document.body} ${(document.tags || []).join(' ')}`);
  const embedding = createEmbedding(`${document.title} ${document.body}`);
  const stored = { ...document, lexical, embedding };
  index.documents = index.documents.filter(item => item.id !== document.id);
  index.documents.push(stored);
  writeIndex(index);
  return stored;
}

function search(query, limit = 8) {
  const queryTokens = tokenize(query);
  const queryEmbedding = createEmbedding(query);
  const results = readIndex().documents.map(document => {
    const lexicalHits = queryTokens.reduce((count, token) => count + (document.lexical.includes(token) ? 1 : 0), 0);
    const lexicalScore = queryTokens.length ? lexicalHits / queryTokens.length : 0;
    const vectorScore = cosine(queryEmbedding, document.embedding);
    return {
      id: document.id,
      title: document.title,
      url: document.url,
      score: Number((lexicalScore * 0.382 + vectorScore * 0.618).toFixed(6)),
      lexicalScore,
      vectorScore
    };
  });
  return concurrentEqualsMerge(results).slice(0, limit);
}

module.exports = {
  addDocument,
  search,
  createEmbedding,
  cosine
};
