const http = require('http');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readBody, sendJson, requestUrl } = require('../../../shared/http-helpers');
const { verifySignedRequest } = require('../../../shared/interservice-auth');
const { addDocument, search } = require('./search-index');

const logger = createLogger('search-service');
const port = Number(process.env.PORT || 4314);

function verifyIfSigned(req, rawBody) {
  if (!req.headers['x-heady-source']) {
    return { ok: true };
  }
  return verifySignedRequest(rawBody, req.headers['x-heady-signature'], req.headers['x-heady-source'], req.headers['x-heady-timestamp']);
}

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'search-service' });
    }
    if (req.method === 'POST' && (url.pathname === '/index' || url.pathname === '/search')) {
      const rawBody = await readBody(req);
      const verification = verifyIfSigned(req, rawBody);
      if (!verification.ok) {
        return sendJson(res, 401, { error: 'HEADY-SEARCH-401', ...verification });
      }
      const body = rawBody ? JSON.parse(rawBody) : {};
      if (url.pathname === '/index') {
        return sendJson(res, 200, { ok: true, document: addDocument(body) });
      }
      return sendJson(res, 200, { ok: true, results: search(body.query || '', Number(body.limit || 8)) });
    }
    return sendJson(res, 404, { error: 'HEADY-SEARCH-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-SEARCH-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server };
