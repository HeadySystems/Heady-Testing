const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readJson, sendJson, requestUrl } = require('../../../shared/http-helpers');
const { fib } = require('../../../shared/phi-math');

const logger = createLogger('asset-pipeline');
const port = Number(process.env.PORT || 4317);
const dataDir = path.join(__dirname, '..', 'data');
const manifestPath = path.join(dataDir, 'manifest.json');
fs.mkdirSync(dataDir, { recursive: true });

function planAsset(filePath) {
  const absolute = path.resolve(filePath);
  const stat = fs.statSync(absolute);
  const digest = crypto.createHash('sha256').update(fs.readFileSync(absolute)).digest('hex');
  const widths = [fib(13), fib(14), fib(15), fib(16)];
  return {
    source: absolute,
    bytes: stat.size,
    digest,
    immutableCacheSeconds: fib(11) * fib(10),
    variants: widths.map(width => ({ width, cdnKey: `${digest}/${width}${path.extname(absolute)}` }))
  };
}

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'asset-pipeline' });
    }
    if (req.method === 'POST' && url.pathname === '/process') {
      const body = await readJson(req);
      const manifest = { generatedAt: new Date().toISOString(), assets: (body.files || []).map(planAsset) };
      fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
      return sendJson(res, 200, { ok: true, manifest });
    }
    if (req.method === 'GET' && url.pathname === '/manifest') {
      if (!fs.existsSync(manifestPath)) {
        return sendJson(res, 200, { generatedAt: null, assets: [] });
      }
      return sendJson(res, 200, JSON.parse(fs.readFileSync(manifestPath, 'utf8')));
    }
    return sendJson(res, 404, { error: 'HEADY-ASSET-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-ASSET-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server, planAsset };
