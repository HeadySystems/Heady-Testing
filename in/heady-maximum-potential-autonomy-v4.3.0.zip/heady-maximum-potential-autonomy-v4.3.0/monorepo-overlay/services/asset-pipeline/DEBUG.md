# DEBUG — asset-pipeline

## Health
- live: `GET /health/live`
- process: `POST /process`
- manifest: `GET /manifest`
