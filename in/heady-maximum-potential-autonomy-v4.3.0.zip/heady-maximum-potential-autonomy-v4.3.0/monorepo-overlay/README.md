# Heady Maximum Potential Autonomy Overlay v4.3.0

This overlay extends the v4.2.0 pass with constitutional service coverage for `api-gateway`, `domain-router`, `heady-cache`, and `heady-health`, plus signed inter-service routing, a twelve-service local health matrix, and a Postman collection.

## Added in v4.3.0
- signed internal request flow for gateway, auth verification, search, and cache
- constitutional service coverage for gateway, domain routing, cache, and health aggregation
- config-driven local service map with twelve overlay services
- Postman collection and new runbooks for the expanded operational surface
