const crypto = require('crypto');

function deriveContext(req) {
  const origin = req.headers.origin || null;
  const requestId = req.headers['x-request-id'] || crypto.randomUUID();
  const domain = req.headers.host || 'unknown';
  const ip = (req.socket.remoteAddress || '').replace('::ffff:', '') || '0.0.0.0';
  return {
    requestId,
    origin,
    domain,
    ip,
    userAgent: req.headers['user-agent'] || 'unknown'
  };
}

module.exports = { deriveContext };
