const crypto = require('crypto');

function createLogger(service) {
  return {
    info(event, details = {}) {
      process.stdout.write(`${JSON.stringify(format('info', service, event, details))}\n`);
    },
    warn(event, details = {}) {
      process.stdout.write(`${JSON.stringify(format('warn', service, event, details))}\n`);
    },
    error(event, details = {}) {
      process.stderr.write(`${JSON.stringify(format('error', service, event, details))}\n`);
    }
  };
}

function format(level, service, event, details) {
  return {
    timestamp: new Date().toISOString(),
    level,
    service,
    event,
    correlationId: details.correlationId || crypto.randomUUID(),
    ...details
  };
}

module.exports = { createLogger };
