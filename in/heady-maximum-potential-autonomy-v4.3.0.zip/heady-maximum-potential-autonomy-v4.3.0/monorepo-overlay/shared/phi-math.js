const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function fib(index) {
  if (index < 0 || index >= FIB.length) {
    throw new RangeError(`Unsupported Fibonacci index: ${index}`);
  }
  return FIB[index];
}

function phiThreshold(level, spread = 0.5) {
  return 1 - Math.pow(PSI, level) * spread;
}

function phiBackoff(attempt, base = 1000, ceiling = 60000) {
  return Math.min(Math.round(base * Math.pow(PHI, attempt)), ceiling);
}

function rolloutPhases() {
  return [6.18, 38.2, 61.8, 100.0];
}

function phiWindow(minutes) {
  return Math.round(minutes * PHI);
}

module.exports = {
  PHI,
  PSI,
  PSI2,
  FIB,
  fib,
  phiThreshold,
  phiBackoff,
  rolloutPhases,
  phiWindow
};
