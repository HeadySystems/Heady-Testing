#!/usr/bin/env bash
set -euo pipefail

command -v node >/dev/null || { echo "Node.js is required"; exit 1; }
command -v docker >/dev/null || { echo "Docker is required"; exit 1; }
command -v gcloud >/dev/null || { echo "gcloud CLI is required"; exit 1; }
command -v npm >/dev/null || { echo "npm is required"; exit 1; }
[ -f .env.example ] || { echo ".env.example missing"; exit 1; }
node --version
npm --version
printf "Installing workspace dependencies if package manifests evolve.\n"
npm install --ignore-scripts --package-lock-only >/dev/null 2>&1 || true
printf "Rendering architecture artifact.\n"
node scripts/generate-architecture-svg.js
printf "Validating console policy.\n"
node scripts/lint-no-console.js
printf "Docker Compose contract check.\n"
docker compose -f docker-compose.autonomy.yml config >/dev/null
printf "Setup checks complete. Run npm test, npm run contracts, and npm run validate next.\n"
