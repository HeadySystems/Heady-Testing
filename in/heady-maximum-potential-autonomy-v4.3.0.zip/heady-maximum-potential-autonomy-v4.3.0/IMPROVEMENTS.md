# IMPROVEMENTS

## Security

- added signed inter-service request verification for gateway, auth verification, search, and cache flows
- preserved strict `__Host-heady_session` cookies, per-frame WebSocket auth checks, and JSON logging conventions
- kept autonomy guardrails, secret rotation policy, and rate-limit policy aligned with prior passes

## Runtime coverage

- expanded the overlay from eight to twelve runnable local services
- added domain routing, cache control, and health aggregation to the local constitutional surface
- updated Prometheus and compose topology to reflect the wider overlay map

## Developer experience

- added a Postman collection for the expanded API surface
- updated run scripts and health scripts to use a single config-driven service map
- expanded runbooks for the new constitutional services
