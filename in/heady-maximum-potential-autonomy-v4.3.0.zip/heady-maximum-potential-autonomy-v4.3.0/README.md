# Heady Maximum Potential Autonomy v4.3.0

This bundle extends the previous autonomous improvement pass with additional constitutional services, signed gateway routing, domain resolution, in-memory cache control, health aggregation, and API collection assets.

## Included
- `foundation/heady-sacred-genesis-v4.0.0/`
- `projections/heady-sacred-projections-v4.0.0/`
- `monorepo-overlay/` with twelve local overlay services, sites, docs, tests, scripts, and infra overlays

## Validation
Run `npm test`, `npm run gateway:test`, and `npm run validate` from `monorepo-overlay/`.
