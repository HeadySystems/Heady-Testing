/**
 * Heady™ Phi-Math Foundation v5.1
 * Sacred Geometry mathematical primitives — ALL numeric constants derived from φ
 * Zero magic numbers. Every value traces to the golden ratio.
 *
 * Canonical reference: Heady Phi-Math Foundation v4.1.0
 * Extended with v5.0 platform-specific constants (ports, timing, HNSW, Colab).
 *
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * @author Eric Haywood — HeadySystems Inc.
 * @license Proprietary — HeadySystems Inc.
 * @module phi-constants
 * @version 5.1.0
 */

'use strict';

// ═══════════════════════════════════════════════════════════
// CORE CONSTANTS — The Sacred Foundation
// ═══════════════════════════════════════════════════════════

const PHI = (1 + Math.sqrt(5)) / 2;          // φ  ≈ 1.6180339887
const PSI = 1 / PHI;                          // ψ  ≈ 0.6180339887 (conjugate)

// Canonical aliases (v4.1.0)
const PHI2 = PHI + 1;                         // φ² ≈ 2.6180339887
const PHI3 = 2 * PHI + 1;                     // φ³ ≈ 4.2360679775

// Extended aliases (v5.0 compatibility)
const PHI_SQ = PHI2;                           // φ² — alias for backward compatibility
const PHI_CUBE = PHI3;                         // φ³ — alias
const PHI_FOURTH = 3 * PHI + 2;              // φ⁴ ≈ 6.8541019662

const PSI_SQ = PSI * PSI;                     // ψ² ≈ 0.3819660113
const PSI_CUBE = PSI * PSI * PSI;             // ψ³ ≈ 0.2360679775
const PSI_FOURTH = PSI * PSI * PSI * PSI;     // ψ⁴ ≈ 0.1458980338

const EMBEDDING_DIM = 384;                     // fib-adjacent: 377=fib(14), 384=nearest power-aligned

// ═══════════════════════════════════════════════════════════
// FIBONACCI SEQUENCE — The Sacred Sequence
// ═══════════════════════════════════════════════════════════

const FIB = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765];

// Backward compatibility alias
const FIB_CACHE = FIB;

function fib(n) {
  if (n < FIB.length) return FIB[n];
  let a = FIB[FIB.length - 2];
  let b = FIB[FIB.length - 1];
  for (let i = FIB.length; i <= n; i++) {
    [a, b] = [b, a + b];
  }
  return b;
}

function nearestFib(value) {
  let i = 0;
  while (fib(i) < value) i++;
  const upper = fib(i);
  const lower = i > 0 ? fib(i - 1) : 0;
  return (value - lower <= upper - value) ? lower : upper;
}

// ═══════════════════════════════════════════════════════════
// CSL GATE THRESHOLDS — Phi-Harmonic Levels
// phiThreshold(level, spread=0.5) = 1 - ψ^level × spread
// ═══════════════════════════════════════════════════════════

function phiThreshold(level, spread = 0.5) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = Object.freeze({
  MINIMUM:  phiThreshold(0),   // ≈ 0.500
  LOW:      phiThreshold(1),   // ≈ 0.691
  MEDIUM:   phiThreshold(2),   // ≈ 0.809
  HIGH:     phiThreshold(3),   // ≈ 0.882
  CRITICAL: phiThreshold(4),   // ≈ 0.927
});

const DEDUP_THRESHOLD = 1 - Math.pow(PSI, 6) * 0.5;  // ≈ 0.972
const COHERENCE_DRIFT_THRESHOLD = CSL_THRESHOLDS.MEDIUM;  // ≈ 0.809

// ═══════════════════════════════════════════════════════════
// PRESSURE LEVELS — Phi-Derived System Health
// ═══════════════════════════════════════════════════════════

const PRESSURE_LEVELS = Object.freeze({
  NOMINAL:   { min: 0, max: Math.pow(PSI, 2) },           // 0 – 0.382
  ELEVATED:  { min: Math.pow(PSI, 2), max: PSI },         // 0.382 – 0.618
  HIGH:      { min: PSI, max: 1 - Math.pow(PSI, 3) },    // 0.618 – 0.764
  CRITICAL:  { min: 1 - Math.pow(PSI, 4), max: 1.0 },   // 0.854+
});

function getPressureLevel(value) {
  if (value <= PSI_SQ) return 'NOMINAL';
  if (value <= PSI) return 'ELEVATED';
  if (value <= 1 - PSI_CUBE) return 'HIGH';
  return 'CRITICAL';
}

// ═══════════════════════════════════════════════════════════
// ALERT THRESHOLDS — Canonical (lowercase keys)
// ═══════════════════════════════════════════════════════════

const ALERT_THRESHOLDS = Object.freeze({
  warning:  PSI,                // ≈ 0.618
  caution:  1 - Math.pow(PSI, 2),  // ≈ 0.618 (1 - 0.382)
  critical: 1 - Math.pow(PSI, 3),  // ≈ 0.764
  exceeded: 1 - Math.pow(PSI, 4),  // ≈ 0.854
  hard_max: 1.0,
});

// ═══════════════════════════════════════════════════════════
// FUSION & SCORING — N-Factor Phi-Weighted
// ═══════════════════════════════════════════════════════════

function phiFusionWeights(n) {
  const raw = Array.from({ length: n }, (_, i) => Math.pow(PSI, i));
  const sum = raw.reduce((a, b) => a + b, 0);
  return raw.map(w => w / sum);
}

function phiPriorityScore(...factors) {
  const weights = phiFusionWeights(factors.length);
  return factors.reduce((sum, f, i) => sum + f * weights[i], 0);
}

function phiFusionScore(factors, weights = null) {
  const w = weights || phiFusionWeights(factors.length);
  return factors.reduce((sum, f, i) => sum + f * w[i], 0);
}

const EVICTION_WEIGHTS = Object.freeze({
  importance: phiFusionWeights(3)[0],  // ≈ 0.486
  recency:    phiFusionWeights(3)[1],  // ≈ 0.300
  relevance:  phiFusionWeights(3)[2],  // ≈ 0.214
});

// Canonical resource weights (v4.1.0)
const RESOURCE_WEIGHTS = Object.freeze({
  hot:        0.387,
  warm:       0.239,
  cold:       0.148,
  reserve:    0.092,
  governance: 0.057,
});

// Extended percentage-based alias (v5.0 compatibility)
const RESOURCE_ALLOCATION = Object.freeze({
  HOT:        0.34,   // fib(9)/100 ≈ 34%
  WARM:       0.21,   // fib(8)/100 ≈ 21%
  COLD:       0.13,   // fib(7)/100 ≈ 13%
  RESERVE:    0.08,   // fib(6)/100 ≈ 8%
  GOVERNANCE: 0.05,   // fib(5)/100 ≈ 5%
});

function phiResourceWeights(n) { return phiFusionWeights(n); }

// ═══════════════════════════════════════════════════════════
// BACKOFF & TIMING
// ═══════════════════════════════════════════════════════════

function phiBackoff(attempt, baseMs = 1000, maxMs = 60000, jitter = true) {
  const delay = Math.min(baseMs * Math.pow(PHI, attempt), maxMs);
  if (!jitter) return Math.round(delay);
  const jitterRange = Math.pow(PSI, 2);
  const factor = 1 + (Math.random() * 2 - 1) * jitterRange;
  return Math.round(delay * factor);
}

// Backward compatibility — explicit jitter version
function phiBackoffWithJitter(attempt, baseMs = 1000, maxMs = 60000) {
  return phiBackoff(attempt, baseMs, maxMs, true);
}

// Canonical Fibonacci retry sequence
function fibRetryBackoff(count = 5, multiplier = 100) {
  return FIB.slice(4, 4 + count).map(n => n * multiplier);
}

// Canonical adaptive polling interval
function phiAdaptiveInterval(baseMs, healthy, currentMs) {
  if (healthy) return Math.min(currentMs * PHI, baseMs * PHI3);
  return Math.max(currentMs * PSI, baseMs * PSI);
}

const BACKOFF_SEQUENCE = Object.freeze([
  1000, 1618, 2618, 4236, 6854, 11090, 17944, 29034
]);

// ═══════════════════════════════════════════════════════════
// TOKEN BUDGETS — Phi-Geometric Progression
// ═══════════════════════════════════════════════════════════

function phiTokenBudgets(base = 8192) {
  return {
    working:    base,                                    // 8192
    session:    Math.round(base * PHI2),                 // 21450
    memory:     Math.round(base * PHI2 * PHI2),         // 56131
    artifacts:  Math.round(base * Math.pow(PHI, 6)),     // 146920
  };
}

// Canonical compression trigger — ψ⁴ proximity
const COMPRESSION_TRIGGER = 1 - Math.pow(PSI, 4);  // ≈ 0.854

// ═══════════════════════════════════════════════════════════
// CSL GATES — Continuous Semantic Logic
// ═══════════════════════════════════════════════════════════

/** Canonical gate temperature = ψ³ ≈ 0.236 */
const PHI_TEMPERATURE = Math.pow(PSI, 3);

/**
 * Sigmoid-gated value scaling.
 * output = value × σ((cosScore − τ) / temperature)
 *
 * @param {number} value — the value to gate
 * @param {number} cosScore — cosine similarity or quality score [0,1]
 * @param {number} tau — threshold
 * @param {number} [temp=PHI_TEMPERATURE] — transition sharpness
 * @returns {number}
 */
function cslGate(value, cosScore, tau, temp = PHI_TEMPERATURE) {
  const sigmoid = 1 / (1 + Math.exp(-(cosScore - tau) / temp));
  return value * sigmoid;
}

/**
 * Sigmoid-based weight interpolation between high and low.
 * result = weightLow + (weightHigh − weightLow) × σ((cosScore − τ) / PHI_TEMPERATURE)
 *
 * @param {number} weightHigh — weight when cosScore >> tau
 * @param {number} weightLow — weight when cosScore << tau
 * @param {number} cosScore — similarity score
 * @param {number} tau — threshold
 * @returns {number}
 */
function cslBlend(weightHigh, weightLow, cosScore, tau) {
  const sigmoid = 1 / (1 + Math.exp(-(cosScore - tau) / PHI_TEMPERATURE));
  return weightLow + (weightHigh - weightLow) * sigmoid;
}

/**
 * Entropy-responsive temperature scaling.
 * temp = PHI_TEMPERATURE × (1 + ratio × φ)
 *
 * @param {number} entropy — current entropy
 * @param {number} maxEntropy — maximum possible entropy
 * @returns {number}
 */
function adaptiveTemperature(entropy, maxEntropy) {
  const ratio = entropy / maxEntropy;
  return PHI_TEMPERATURE * (1 + ratio * PHI);
}

// ═══════════════════════════════════════════════════════════
// CSL VECTOR OPERATIONS — Geometric Logic Gates
// ═══════════════════════════════════════════════════════════

/**
 * Cosine similarity between two vectors.
 * @param {Array<number>|Float32Array} a
 * @param {Array<number>|Float32Array} b
 * @returns {number} — similarity in [-1, +1]
 */
function cosineSimilarity(a, b) {
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom > 0 ? dot / denom : 0;
}

/**
 * CSL AND — cosine similarity as logical conjunction.
 * +1 = aligned (TRUE), 0 = orthogonal (UNKNOWN), -1 = antipodal (FALSE)
 */
function cslAND(a, b) { return cosineSimilarity(a, b); }

/**
 * CSL OR — normalized superposition (soft union).
 */
function cslOR(a, b) {
  const sum = a.map((v, i) => v + b[i]);
  const norm = Math.sqrt(sum.reduce((s, v) => s + v * v, 0));
  return norm > 0 ? sum.map(v => v / norm) : sum;
}

/**
 * CSL NOT — orthogonal projection (semantic negation).
 * Removes the component of a that lies in the direction of b.
 * NOT(a, b) · b = 0 (proven orthogonality)
 */
function cslNOT(a, b) {
  const dot = a.reduce((s, v, i) => s + v * b[i], 0);
  const normB2 = b.reduce((s, v) => s + v * v, 0);
  const proj = normB2 > 0 ? dot / normB2 : 0;
  return a.map((v, i) => v - proj * b[i]);
}

/**
 * CSL IMPLY — projection of a onto b.
 * Component of a in the direction of b.
 */
function cslIMPLY(a, b) {
  const dot = a.reduce((s, v, i) => s + v * b[i], 0);
  const normB2 = b.reduce((s, v) => s + v * v, 0);
  const proj = normB2 > 0 ? dot / normB2 : 0;
  return b.map(v => proj * v);
}

/**
 * CSL CONSENSUS — phi-weighted centroid of multiple vectors.
 * @param {Array<Array<number>>} vectors
 * @param {Array<number>} [weights] — defaults to phiFusionWeights
 */
function cslCONSENSUS(vectors, weights) {
  const w = weights || phiFusionWeights(vectors.length);
  const dim = vectors[0].length;
  const sum = new Array(dim).fill(0);
  for (let i = 0; i < vectors.length; i++) {
    for (let d = 0; d < dim; d++) { sum[d] += w[i] * vectors[i][d]; }
  }
  const norm = Math.sqrt(sum.reduce((s, v) => s + v * v, 0));
  return norm > 0 ? sum.map(v => v / norm) : sum;
}

/**
 * CSL XOR — exclusive components (what's in either but not both).
 */
function cslXOR(a, b) {
  const orVec = cslOR(a, b);
  const andScore = cslAND(a, b);
  const andProj = cslIMPLY(orVec, a).map((v) => v * andScore);
  return cslNOT(orVec, andProj);
}

// ═══════════════════════════════════════════════════════════
// SIZING — Consolidated Fibonacci Sizing Constants
// ═══════════════════════════════════════════════════════════

const SIZING = Object.freeze({
  FAILURE_THRESHOLD:  fib(5),   // 5
  BATCH_EVICTION:     fib(6),   // 8
  MAX_CONCURRENT:     fib(6),   // 8
  SMALL_LIMIT:        fib(7),   // 13
  HNSW_M:             fib(8),   // 21
  RERANK_TOP_K:       fib(8),   // 21
  SLIDING_WINDOW:     fib(9),   // 34
  MAX_ENTITIES:       fib(10),  // 55
  RETENTION_DAYS:     fib(11),  // 89
  EF_SEARCH:          fib(11),  // 89
  EF_CONSTRUCTION:    fib(12),  // 144
  QUEUE_DEPTH:        fib(13),  // 233
  PATTERN_STORE:      fib(14),  // 377
  CACHE_SIZE:         fib(16),  // 987
  HISTORY_BUFFER:     fib(17),  // 1597
  LARGE_CACHE:        fib(20),  // 6765
});

const POOL_SIZES = Object.freeze({
  min:    fib(3),   // 2  — canonical min
  max:    fib(7),   // 13 — canonical max
  MICRO:  fib(5),   // 5
  SMALL:  fib(6),   // 8
  MEDIUM: fib(7),   // 13
  LARGE:  fib(8),   // 21
  XLARGE: fib(9),   // 34
  HUGE:   fib(10),  // 55
  MEGA:   fib(11),  // 89
});

const RELEVANCE_GATES = Object.freeze({
  include: Math.pow(PSI, 2),   // ≈ 0.382
  boost:   PSI,                 // ≈ 0.618
  inject:  PSI + 0.1,           // ≈ 0.718
});

// ═══════════════════════════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════════════════════════

function phiMultiSplit(whole, n) {
  const weights = phiResourceWeights(n);
  return weights.map(w => Math.round(whole * w));
}

// ═══════════════════════════════════════════════════════════
// TIMING CONSTANTS — All Fibonacci/Phi Derived
// ═══════════════════════════════════════════════════════════

const TIMING = Object.freeze({
  HEARTBEAT_MS:       fib(7) * 1000,    // 13s
  HEALTH_CHECK_MS:    fib(9) * 1000,    // 34s
  DRIFT_CHECK_MS:     fib(11) * 1000,   // 89s
  CACHE_TTL_MS:       fib(13) * 1000,   // 233s
  SESSION_TTL_MS:     fib(17) * 1000,   // 1597s (~26min)
  COOL_DOWN_MS:       fib(8) * 1000,    // 21s
  HOT_TIMEOUT_MS:     fib(9) * 1000,    // 34s
  WARM_TIMEOUT_MS:    fib(13) * 1000,   // 233s (~3.9min)
  COLD_TIMEOUT_MS:    fib(17) * 1000,   // 1597s (~26.6min)
});

// ═══════════════════════════════════════════════════════════
// HNSW INDEX PARAMETERS — Fibonacci/Phi Scaled
// ═══════════════════════════════════════════════════════════

const HNSW_PARAMS = Object.freeze({
  M:                fib(8),    // 21 — connections per node
  EF_CONSTRUCTION:  fib(12),   // 144 — build-time search width
  EF_SEARCH:        fib(11),   // 89 — query-time search width
  DIMENSIONS:       EMBEDDING_DIM,  // 384
});

// ═══════════════════════════════════════════════════════════
// PIPELINE STAGES
// ═══════════════════════════════════════════════════════════

const PIPELINE_STAGE_COUNT = fib(8); // 21

// ═══════════════════════════════════════════════════════════
// COLAB RUNTIME CONSTANTS
// ═══════════════════════════════════════════════════════════

const COLAB_RUNTIMES = Object.freeze({
  COUNT: 3,                          // 3 Colab Pro+ memberships
  GPU_MEMORY_GB: fib(10),            // 55GB (A100 80GB available, phi-scaled allocation)
  MAX_CONCURRENT_TASKS: fib(8),      // 21 concurrent tasks per runtime
  BATCH_SIZE: fib(9),                // 34 items per batch
  VECTOR_CACHE_SIZE: fib(20),        // 6765 vectors in hot cache
  EMBEDDING_BATCH: fib(12),          // 144 embeddings per batch
  CHECKPOINT_INTERVAL_S: fib(13),    // 233s between checkpoints
});

// ═══════════════════════════════════════════════════════════
// SERVICE PORT MAP — 50+ services on ports 3310-3396
// ═══════════════════════════════════════════════════════════

const SERVICE_PORTS = Object.freeze({
  // Inference Services (3310-3319)
  HEADY_INFERENCE:        3310,
  HEADY_EMBED:            3311,
  HEADY_CLASSIFY:         3312,
  HEADY_SUMMARIZE:        3313,
  HEADY_TRANSLATE:        3314,
  HEADY_VISION:           3315,
  HEADY_SPEECH:           3316,
  HEADY_CODE_GEN:         3317,
  HEADY_REASONING:        3318,
  HEADY_MULTI_MODAL:      3319,
  // Memory Services (3320-3329)
  HEADY_MEMORY:           3320,
  HEADY_VECTOR_STORE:     3321,
  HEADY_GRAPH_RAG:        3322,
  HEADY_KNOWLEDGE_BASE:   3323,
  HEADY_CONTEXT_MANAGER:  3324,
  HEADY_CACHE:            3325,
  HEADY_EMBEDDING_ROUTER: 3326,
  HEADY_SEARCH:           3327,
  HEADY_INDEX:            3328,
  HEADY_RERANK:           3329,
  // Agent Services (3330-3339)
  HEADY_CONDUCTOR:        3330,
  HEADY_BEE_FACTORY:      3331,
  HEADY_SWARM:            3332,
  HEADY_SOUL:             3333,
  HEADY_BRAINS:           3334,
  HEADY_VINCI:            3335,
  HEADY_BUDDY:            3336,
  HEADY_MANAGER:          3337,
  HEADY_AUTOBIOGRAPHER:   3338,
  HEADY_PATTERNS:         3339,
  // Orchestration (3340-3349)
  HEADY_PIPELINE:         3340,
  HEADY_SCHEDULER:        3341,
  HEADY_TASK_DECOMP:      3342,
  HEADY_BACKPRESSURE:     3343,
  HEADY_LIQUID_MESH:      3344,
  HEADY_LIQUID_GATEWAY:   3345,
  HEADY_ARENA:            3346,
  HEADY_CONSENSUS:        3347,
  HEADY_CIRCUIT_BREAKER:  3348,
  HEADY_LOAD_BALANCER:    3349,
  // Security (3350-3359)
  HEADY_AUTH:             3350,
  HEADY_OAUTH:            3351,
  HEADY_FIREWALL:         3352,
  HEADY_AUDIT:            3353,
  HEADY_GOVERNANCE:       3354,
  HEADY_ENCRYPTION:       3355,
  HEADY_RATE_LIMITER:     3356,
  HEADY_IDENTITY:         3357,
  HEADY_MCP_GATEWAY:      3358,
  HEADY_ZERO_TRUST:       3359,
  // Monitoring (3360-3369)
  HEADY_HEALTH:           3360,
  HEADY_METRICS:          3361,
  HEADY_TELEMETRY:        3362,
  HEADY_ALERTING:         3363,
  HEADY_DASHBOARD:        3364,
  HEADY_LOG_AGGREGATOR:   3365,
  HEADY_TRACE_COLLECTOR:  3366,
  HEADY_DRIFT_DETECTOR:   3367,
  HEADY_SELF_HEALING:     3368,
  HEADY_MONTE_CARLO:      3369,
  // Web Services (3370-3379)
  HEADY_WEB_GATEWAY:      3370,
  HEADYME_COM:            3371,
  HEADYSYSTEMS_COM:       3372,
  HEADY_AI_COM:           3373,
  HEADYOS_COM:            3374,
  HEADYCONNECTION_ORG:    3375,
  HEADYCONNECTION_COM:    3376,
  HEADYEX_COM:            3377,
  HEADYFINANCE_COM:       3378,
  ADMIN_HEADYSYSTEMS:     3379,
  // Data Services (3380-3389)
  HEADY_PGVECTOR:         3380,
  HEADY_PGBOUNCER:        3381,
  HEADY_NATS:             3382,
  HEADY_REDIS:            3383,
  HEADY_STORAGE:          3384,
  HEADY_BACKUP:           3385,
  HEADY_MIGRATION:        3386,
  HEADY_ETL:              3387,
  HEADY_ANALYTICS:        3388,
  HEADY_REPORTING:        3389,
  // Integration & Specialized (3390-3396)
  HEADY_NOTIFICATION:     3390,
  HEADY_WEBHOOK:          3391,
  HEADY_COLAB_BRIDGE:     3392,
  HEADY_LIQUID_DEPLOY:    3393,
  HEADY_EVOLUTION:        3394,
  HEADY_DOCUMENTATION:    3395,
  HEADY_AUTO_SUCCESS:     3396,
});

// ═══════════════════════════════════════════════════════════
// BACKWARD-COMPAT ALIASES
// ═══════════════════════════════════════════════════════════

/** @deprecated Use fib() — kept for downstream compatibility */
const fibonacci = fib;

/** @deprecated Use SIZING — kept for heady-brains.js compatibility */
const FIBONACCI_SIZES = SIZING;

// camelCase aliases for CSL vector ops (v5.0 naming)
const cslAnd = cslAND;
const cslOr = cslOR;
const cslNot = cslNOT;
const cslImply = cslIMPLY;
const cslConsensus = cslCONSENSUS;
const cslXor = cslXOR;

// ═══════════════════════════════════════════════════════════
// EXPORTS — Canonical v4.1.0 + v5.0 extensions + compat aliases
// ═══════════════════════════════════════════════════════════

module.exports = {
  // Core constants (canonical + extended)
  PHI, PSI, PHI2, PHI3,
  PHI_SQ, PHI_CUBE, PHI_FOURTH,
  PSI_SQ, PSI_CUBE, PSI_FOURTH,
  EMBEDDING_DIM,

  // Fibonacci
  FIB, FIB_CACHE, fib, fibonacci, nearestFib,

  // Thresholds
  phiThreshold, CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,

  // Pressure
  PRESSURE_LEVELS, getPressureLevel,

  // Alerts
  ALERT_THRESHOLDS,

  // Fusion & Scoring
  phiFusionWeights, phiFusionScore, phiPriorityScore,
  EVICTION_WEIGHTS, RESOURCE_WEIGHTS, RESOURCE_ALLOCATION,
  phiResourceWeights,

  // Backoff & Timing
  phiBackoff, phiBackoffWithJitter, fibRetryBackoff, phiAdaptiveInterval,
  BACKOFF_SEQUENCE,

  // Token Budgets
  phiTokenBudgets, COMPRESSION_TRIGGER,

  // CSL Gates
  PHI_TEMPERATURE,
  cslGate, cslBlend, adaptiveTemperature,

  // CSL Vector Operations (UPPERCASE = canonical, camelCase = compat)
  cosineSimilarity,
  cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS, cslXOR,
  cslAnd, cslOr, cslNot, cslImply, cslConsensus, cslXor,

  // Sizing
  SIZING, FIBONACCI_SIZES, POOL_SIZES, RELEVANCE_GATES,

  // Utilities
  phiMultiSplit,

  // Timing
  TIMING,

  // HNSW
  HNSW_PARAMS,

  // Pipeline
  PIPELINE_STAGE_COUNT,

  // Colab
  COLAB_RUNTIMES,

  // Services
  SERVICE_PORTS,
};
