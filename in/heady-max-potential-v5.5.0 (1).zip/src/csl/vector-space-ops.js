/**
 * Heady™ Latent OS v5.5.0
 * © 2026 HeadySystems Inc. — Eric Haywood — 60+ Provisional Patents
 * ZERO MAGIC NUMBERS — All constants φ-derived or Fibonacci
 *
 * Vector Space Operations — delegates to canonical phi-math CSL ops
 * with additional 377D-specific utilities for the Heady vector brain.
 *
 * @module vector-space-ops
 */

'use strict';

const {
  PHI, PSI, fib,
  CSL_THRESHOLDS, PHI_TEMPERATURE,
  cosineSimilarity, normalize,
  cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS, cslXOR,
  cslGate, cslBlend, adaptiveTemperature,
  phiFusionWeights,
  sigmoid,
} = require('../../shared/phi-math');

// ─── Constants ──────────────────────────────────────────────────────────────

const DEFAULT_DIM = fib(14);                    // 377 dimensions
const COLLAPSE_THRESHOLD = Math.pow(PSI, 8);    // ≈ 0.0131

// ─── Higher-Level Vector Brain Utilities ────────────────────────────────────

/**
 * Adaptive GATE — temperature adjusts based on entropy
 */
function adaptiveGATE(value, cosScore, entropy, maxEntropy, tau = CSL_THRESHOLDS.MINIMUM) {
  const adaptiveTemp = adaptiveTemperature(entropy, maxEntropy);
  return cslGate(value, cosScore, tau, adaptiveTemp);
}

/**
 * Generate random unit vector of given dimension
 */
function randomUnitVector(dim = DEFAULT_DIM) {
  const v = new Array(dim);
  for (let i = 0; i < dim; i++) v[i] = Math.random() * 2 - 1;
  return normalize(v);
}

/**
 * Generate zero vector of given dimension
 */
function zeroVector(dim = DEFAULT_DIM) {
  return new Array(dim).fill(0);
}

/**
 * Phi-weighted fusion of N scores
 */
function phiFusionScores(scores) {
  if (scores.length === 0) return 0;
  if (scores.length === 1) return scores[0];
  let weightedSum = 0;
  let weightTotal = 0;
  for (let i = 0; i < scores.length; i++) {
    const w = Math.pow(PSI, i);
    weightedSum += scores[i] * w;
    weightTotal += w;
  }
  return weightedSum / weightTotal;
}

/**
 * Check if vector is near-zero (collapsed)
 */
function isCollapsed(v) {
  let mag = 0;
  for (let i = 0; i < v.length; i++) mag += v[i] * v[i];
  return Math.sqrt(mag) < COLLAPSE_THRESHOLD;
}

/**
 * Dot product of two vectors
 */
function dot(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i] * b[i];
  return sum;
}

/**
 * Magnitude of a vector
 */
function magnitude(v) {
  let sum = 0;
  for (let i = 0; i < v.length; i++) sum += v[i] * v[i];
  return Math.sqrt(sum);
}

// ─── Exports ────────────────────────────────────────────────────────────────

module.exports = {
  // Re-export canonical CSL ops for convenience
  cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS, cslXOR,
  cslGate, cslBlend, adaptiveTemperature,
  cosineSimilarity, normalize,
  sigmoid,
  // CSL constants
  CSL_THRESHOLDS, PHI_TEMPERATURE,
  // Vector brain utilities
  DEFAULT_DIM, COLLAPSE_THRESHOLD,
  adaptiveGATE,
  randomUnitVector, zeroVector,
  phiFusionScores, isCollapsed,
  dot, magnitude,
  phiFusionWeights,
};
