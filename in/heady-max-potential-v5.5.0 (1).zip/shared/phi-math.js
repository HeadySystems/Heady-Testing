/**
 * Heady™ Phi-Math Foundation — Canonical Reference Implementation
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Every constant in the Heady ecosystem derives from the golden ratio (φ)
 * or Fibonacci numbers. Zero magic numbers. Zero arbitrary thresholds.
 *
 * @module phi-constants
 * @version 4.1.0
 */

'use strict';

// ═══════════════════════════════════════════════════════════════
// CORE CONSTANTS
// ═══════════════════════════════════════════════════════════════

const PHI = (1 + Math.sqrt(5)) / 2;
const PSI = 1 / PHI;
const PHI2 = PHI + 1;
const PHI3 = 2 * PHI + 1;
const SQRT5 = Math.sqrt(5);
const FIB = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765];

function fib(n) {
  if (n < 0) return 0;
  if (n < FIB.length) return FIB[n];
  let a = FIB[FIB.length - 2], b = FIB[FIB.length - 1];
  for (let i = FIB.length; i <= n; i++) { [a, b] = [b, a + b]; }
  return b;
}

// Backward-compat aliases
const PHI_SQ = PHI2;
const PHI_CUBED = PHI3;
const FIB_CACHE = FIB;

/** Closest Fibonacci number ≥ n */
function fibCeil(n) {
  let i = 1;
  while (fib(i) < n) i++;
  return fib(i);
}

/** Closest Fibonacci number ≤ n */
function fibFloor(n) {
  let i = 1;
  while (fib(i + 1) <= n) i++;
  return fib(i);
}

// ═══════════════════════════════════════════════════════════════
// CSL THRESHOLDS
// ═══════════════════════════════════════════════════════════════

function phiThreshold(level, spread = 0.5) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = Object.freeze({
  MINIMUM:  phiThreshold(0),
  LOW:      phiThreshold(1),
  MEDIUM:   phiThreshold(2),
  HIGH:     phiThreshold(3),
  CRITICAL: phiThreshold(4),
  // Backward-compat extensions
  DEFAULT:  PSI,
  DEDUP:    1 - Math.pow(PSI, 6) * 0.5,
  COHERENCE: phiThreshold(2),
});

const DEDUP_THRESHOLD = 1 - Math.pow(PSI, 6) * 0.5;
const COHERENCE_DRIFT_THRESHOLD = CSL_THRESHOLDS.MEDIUM;

// ═══════════════════════════════════════════════════════════════
// PRESSURE & ALERTS
// ═══════════════════════════════════════════════════════════════

const PRESSURE_LEVELS = Object.freeze({
  NOMINAL:  { min: 0, max: Math.pow(PSI, 2), label: 'NOMINAL' },
  ELEVATED: { min: Math.pow(PSI, 2), max: PSI, label: 'ELEVATED' },
  HIGH:     { min: PSI, max: 1 - Math.pow(PSI, 3), label: 'HIGH' },
  CRITICAL: { min: 1 - Math.pow(PSI, 4), max: 1.0, label: 'CRITICAL' },
});

const ALERT_THRESHOLDS = Object.freeze({
  warning:  PSI,
  caution:  1 - Math.pow(PSI, 2),
  critical: 1 - Math.pow(PSI, 3),
  exceeded: 1 - Math.pow(PSI, 4),
  hard_max: 1.0,
  // Backward-compat uppercase aliases
  WARNING:  PSI,
  CAUTION:  1 - Math.pow(PSI, 2),
  CRITICAL: 1 - Math.pow(PSI, 3),
  EXCEEDED: 1 - Math.pow(PSI, 4),
  HARD_MAX: 1.0,
});

// Backward-compat aliases
const PRESSURE = PRESSURE_LEVELS;
const ALERTS = ALERT_THRESHOLDS;

function getPressureLevel(utilization) {
  if (utilization < PRESSURE_LEVELS.NOMINAL.max) return PRESSURE_LEVELS.NOMINAL;
  if (utilization < PRESSURE_LEVELS.ELEVATED.max) return PRESSURE_LEVELS.ELEVATED;
  if (utilization < PRESSURE_LEVELS.HIGH.max) return PRESSURE_LEVELS.HIGH;
  return PRESSURE_LEVELS.CRITICAL;
}

// ═══════════════════════════════════════════════════════════════
// FUSION & SCORING
// ═══════════════════════════════════════════════════════════════

function phiFusionWeights(n) {
  const raw = Array.from({ length: n }, (_, i) => Math.pow(PSI, i));
  const sum = raw.reduce((a, b) => a + b, 0);
  return raw.map(w => w / sum);
}

function phiPriorityScore(...factors) {
  const weights = phiFusionWeights(factors.length);
  return factors.reduce((sum, f, i) => sum + f * weights[i], 0);
}

function phiMultiSplit(whole, n) {
  const weights = phiFusionWeights(n);
  return weights.map(w => Math.round(whole * w));
}

const EVICTION_WEIGHTS = Object.freeze({
  importance: phiFusionWeights(3)[0],
  recency:    phiFusionWeights(3)[1],
  relevance:  phiFusionWeights(3)[2],
});

const RESOURCE_WEIGHTS = Object.freeze({
  hot:        0.387,
  warm:       0.239,
  cold:       0.148,
  reserve:    0.092,
  governance: 0.057,
});

function phiResourceWeights(n) { return phiFusionWeights(n); }

// Backward-compat aliases
const EVICTION = Object.freeze({
  IMPORTANCE: EVICTION_WEIGHTS.importance,
  RECENCY:    EVICTION_WEIGHTS.recency,
  RELEVANCE:  EVICTION_WEIGHTS.relevance,
});

// ═══════════════════════════════════════════════════════════════
// BACKOFF & TIMING
// ═══════════════════════════════════════════════════════════════

function phiBackoff(attempt, baseMs = 1000, maxMs = 60000, jitter = true) {
  const delay = Math.min(baseMs * Math.pow(PHI, attempt), maxMs);
  if (!jitter) return Math.round(delay);
  const jitterRange = Math.pow(PSI, 2);
  const factor = 1 + (Math.random() * 2 - 1) * jitterRange;
  return Math.round(delay * factor);
}

function phiBackoffWithJitter(attempt, baseMs = 1000, maxMs = 60000) {
  return phiBackoff(attempt, baseMs, maxMs, true);
}

function fibRetryBackoff(count = 5, multiplier = 100) {
  return FIB.slice(4, 4 + count).map(n => n * multiplier);
}

function phiAdaptiveInterval(baseMs, healthy, currentMs) {
  if (healthy) return Math.min(currentMs * PHI, baseMs * PHI3);
  return Math.max(currentMs * PSI, baseMs * PSI);
}

// PHI-POWER TIMING (preserved from previous version for backward compat)
function phiPower(n) { return Math.pow(PHI, n); }
function phiMs(n) { return Math.round(phiPower(n) * 1000); }

const PHI_TIMING = Object.freeze({
  PHI_1:  phiMs(1),
  PHI_2:  phiMs(2),
  PHI_3:  phiMs(3),
  PHI_4:  phiMs(4),
  PHI_5:  phiMs(5),
  PHI_6:  phiMs(6),
  PHI_7:  phiMs(7),
  PHI_8:  phiMs(8),
  PHI_9:  phiMs(9),
  PHI_10: phiMs(10),
});

const PHI_BACKOFF_SEQ = Object.freeze([
  1000, 1618, 2618, 4236, 6854, 11090, 17944, 29034
]);

// ═══════════════════════════════════════════════════════════════
// TOKEN BUDGETS
// ═══════════════════════════════════════════════════════════════

function phiTokenBudgets(base = 8192) {
  return {
    working:   base,
    session:   Math.round(base * PHI2),
    memory:    Math.round(base * PHI2 * PHI2),
    artifacts: Math.round(base * Math.pow(PHI, 6)),
  };
}

const COMPRESSION_TRIGGER = 1 - Math.pow(PSI, 4);

// ═══════════════════════════════════════════════════════════════
// CSL GATES
// ═══════════════════════════════════════════════════════════════

const PHI_TEMPERATURE = Math.pow(PSI, 3);

function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}

function cslGate(value, cosScore, tau, temp = PHI_TEMPERATURE) {
  const s = 1 / (1 + Math.exp(-(cosScore - tau) / temp));
  return value * s;
}

function cslBlend(weightHigh, weightLow, cosScore, tau) {
  const s = 1 / (1 + Math.exp(-(cosScore - tau) / PHI_TEMPERATURE));
  return weightLow + (weightHigh - weightLow) * s;
}

function adaptiveTemperature(entropy, maxEntropy) {
  const ratio = entropy / maxEntropy;
  return PHI_TEMPERATURE * (1 + ratio * PHI);
}

// ═══════════════════════════════════════════════════════════════
// CSL VECTOR OPERATIONS
// ═══════════════════════════════════════════════════════════════

function cosineSimilarity(a, b) {
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom > 0 ? dot / denom : 0;
}

function normalize(v) {
  const mag = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
  return mag > 0 ? v.map(x => x / mag) : v;
}

function cslAND(a, b) { return cosineSimilarity(a, b); }

function cslOR(a, b) {
  const sum = a.map((v, i) => v + b[i]);
  const norm = Math.sqrt(sum.reduce((s, v) => s + v * v, 0));
  return norm > 0 ? sum.map(v => v / norm) : sum;
}

function cslNOT(a, b) {
  const dot = a.reduce((s, v, i) => s + v * b[i], 0);
  const normB2 = b.reduce((s, v) => s + v * v, 0);
  const proj = normB2 > 0 ? dot / normB2 : 0;
  return a.map((v, i) => v - proj * b[i]);
}

function cslIMPLY(a, b) {
  const dot = a.reduce((s, v, i) => s + v * b[i], 0);
  const normB2 = b.reduce((s, v) => s + v * v, 0);
  const proj = normB2 > 0 ? dot / normB2 : 0;
  return b.map(v => proj * v);
}

function cslCONSENSUS(vectors, weights) {
  const w = weights || phiFusionWeights(vectors.length);
  const dim = vectors[0].length;
  const sum = new Array(dim).fill(0);
  for (let i = 0; i < vectors.length; i++) {
    for (let d = 0; d < dim; d++) { sum[d] += w[i] * vectors[i][d]; }
  }
  const norm = Math.sqrt(sum.reduce((s, v) => s + v * v, 0));
  return norm > 0 ? sum.map(v => v / norm) : sum;
}

function cslXOR(a, b) {
  const orVec = cslOR(a, b);
  const andScore = cslAND(a, b);
  const andProj = cslIMPLY(orVec, a).map((v, i) => v * andScore);
  return cslNOT(orVec, andProj);
}

// ═══════════════════════════════════════════════════════════════
// SIZING
// ═══════════════════════════════════════════════════════════════

const SIZING = Object.freeze({
  FAILURE_THRESHOLD:  fib(5),
  BATCH_EVICTION:     fib(6),
  MAX_CONCURRENT:     fib(6),
  SMALL_LIMIT:        fib(7),
  HNSW_M:             fib(8),
  RERANK_TOP_K:       fib(8),
  SLIDING_WINDOW:     fib(9),
  MAX_ENTITIES:       fib(10),
  RETENTION_DAYS:     fib(11),
  EF_SEARCH:          fib(11),
  EF_CONSTRUCTION:    fib(12),
  QUEUE_DEPTH:        fib(13),
  PATTERN_STORE:      fib(14),
  CACHE_SIZE:         fib(16),
  HISTORY_BUFFER:     fib(17),
  LARGE_CACHE:        fib(20),
});

const POOL_SIZES = Object.freeze({ min: fib(3), max: fib(7) });

const RELEVANCE_GATES = Object.freeze({
  include: Math.pow(PSI, 2),
  boost:   PSI,
  inject:  PSI + 0.1,
});

// ═══════════════════════════════════════════════════════════════
// DOMAIN-SPECIFIC CONSTANTS (preserved from v5.4.0)
// ═══════════════════════════════════════════════════════════════

const POOLS = Object.freeze({
  HOT:        0.34,
  WARM:       0.21,
  COLD:       0.13,
  RESERVE:    0.08,
  GOVERNANCE: 0.05,
});

const AUTO_SUCCESS = Object.freeze({
  CYCLE_MS:           PHI_TIMING.PHI_7,
  CATEGORIES:         fib(7),
  TASKS_TOTAL:        fib(12),
  TASKS_PER_CAT:      Math.floor(fib(12) / fib(7)),
  TASK_TIMEOUT_MS:    PHI_TIMING.PHI_3,
  MAX_RETRIES_CYCLE:  fib(4),
  MAX_RETRIES_TOTAL:  fib(6),
});

const PIPELINE = Object.freeze({
  STAGES:           fib(8),
  MAX_CONCURRENT:   fib(6),
  MAX_RETRIES:      fib(4),
  CONTEXT_GATE:     CSL_THRESHOLDS.CRITICAL,
  BACKOFF_MS:       [phiMs(1), phiMs(2), phiMs(3)],
  MAX_BACKOFF_MS:   phiMs(5),
  TIMEOUT: Object.freeze({
    RECON:        phiMs(4),
    INTAKE:       phiMs(3),
    TRIAL:        phiMs(6),
    EXECUTE:      phiMs(10),
    AWARENESS:    phiMs(5),
    SEARCH:       phiMs(7),
    EVOLUTION:    phiMs(7),
    RECEIPT:      phiMs(4),
    DEFAULT:      phiMs(7),
  }),
});

const BEE = Object.freeze({
  PRE_WARM: [fib(5), fib(6), fib(7), fib(8)],
  SCALE_UP:   PHI,
  SCALE_DOWN: 1 - 1/PHI,
  STALE_MS:   phiMs(8),
  MAX_TOTAL:  fib(20),
  SWARMS:     17,
  TYPES:      fib(11),
  LIFECYCLE: ['SPAWN', 'INITIALIZE', 'READY', 'ACTIVE', 'DRAINING', 'SHUTDOWN', 'DEAD'],
});

const JUDGE = Object.freeze({
  CORRECTNESS: 0.34,
  SAFETY:      0.21,
  PERFORMANCE: 0.21,
  QUALITY:     0.13,
  ELEGANCE:    0.11,
});

const COST_W = Object.freeze({
  TIME:    Math.pow(PSI, 1) / (Math.pow(PSI, 1) + Math.pow(PSI, 1) + Math.pow(PSI, 2)),
  MONEY:   Math.pow(PSI, 1) / (Math.pow(PSI, 1) + Math.pow(PSI, 1) + Math.pow(PSI, 2)),
  QUALITY: Math.pow(PSI, 2) / (Math.pow(PSI, 1) + Math.pow(PSI, 1) + Math.pow(PSI, 2)),
});

const VECTOR = Object.freeze({
  DIMS:       fib(14),
  PROJ_DIMS:  fib(4),
  DRIFT:      CSL_THRESHOLDS.COHERENCE,
  DEDUP:      CSL_THRESHOLDS.DEDUP,
  MIN_SCORE:  PSI,
});

// ═══════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════

module.exports = {
  // Core (canonical v4.1.0)
  PHI, PSI, PHI2, PHI3, FIB, fib,
  // Core (backward-compat aliases)
  PHI_SQ, PHI_CUBED, SQRT5, FIB_CACHE, fibCeil, fibFloor,
  // Timing (preserved for system-wide use)
  phiPower, phiMs, PHI_TIMING,
  // CSL Thresholds
  CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD, phiThreshold,
  // Pressure & Alerts (canonical + compat)
  PRESSURE_LEVELS, ALERT_THRESHOLDS,
  PRESSURE, ALERTS, getPressureLevel,
  // Fusion & Scoring (canonical + compat)
  phiFusionWeights, phiPriorityScore, EVICTION_WEIGHTS, RESOURCE_WEIGHTS, phiResourceWeights,
  phiMultiSplit,
  EVICTION,
  // Backoff (canonical + compat)
  phiBackoff, phiBackoffWithJitter, fibRetryBackoff, phiAdaptiveInterval,
  PHI_BACKOFF_SEQ,
  // Token budgets
  phiTokenBudgets, COMPRESSION_TRIGGER,
  // CSL gates
  PHI_TEMPERATURE, sigmoid, cslGate, cslBlend, adaptiveTemperature,
  // CSL vector operations (new in v4.1.0)
  cosineSimilarity, normalize,
  cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS, cslXOR,
  // Sizing (new in v4.1.0)
  SIZING, POOL_SIZES, RELEVANCE_GATES,
  // Domain constants (preserved)
  AUTO_SUCCESS, PIPELINE, BEE, POOLS,
  JUDGE, COST_W, VECTOR,
};
