# Heady™ Latent OS v5.5.0 — File Manifest

> Complete inventory of all files in the system
> © 2026 HeadySystems Inc. — Eric Haywood — 60+ Provisional Patents

## Statistics

| Category | Count |
|----------|-------|
| Source modules | 51 |
| Services | 8 (with Dockerfiles, READMEs) |
| Tests | 13 suites (244+ assertions) |
| Documentation | 34 files |
| Infrastructure | 9 files |
| Configuration | 3 files |
| Colab Integration | 9 files |
| UIs | 3 dashboards |
| Observability | 2 files |
| **Total** | **~170 files** |

## Sacred Geometry Ring Topology

### Inner Ring — Core
| File | Purpose | Pool |
|------|---------|------|
| `src/core/heady-soul.js` | Values engine — 8 core values as 377D vectors | Hot |
| `src/core/heady-brains.js` | Context assembly + knowledge routing | Hot |
| `src/core/heady-logger.js` | Structured JSON logging (no console.log) | Hot |
| `src/core/event-bus.js` | φ-buffered event emitter (fib(13)=233 queue) | Hot |
| `src/core/health-probes.js` | Kubernetes-compatible liveness/readiness | Hot |

### Inner Ring — Orchestration
| File | Purpose | Pool |
|------|---------|------|
| `src/orchestration/heady-conductor.js` | Task classification + CSL routing | Hot |
| `src/orchestration/heady-vinci.js` | Session planner — DAG decomposition | Hot |
| `src/orchestration/async-parallel-executor.js` | DAG-aware concurrent task execution | Hot |
| `src/orchestration/swarm-intelligence.js` | Multi-swarm CSL consensus scoring | Warm |
| `src/orchestration/pool-manager.js` | Hot/Warm/Cold Fibonacci-weighted pools | Hot |
| `src/orchestration/liquid-scheduler.js` | Durable Object-compatible scheduling | Warm |

### Middle Ring — Bee Factory & Swarms
| File | Purpose | Pool |
|------|---------|------|
| `src/bees/bee-factory.js` | Dynamic worker creation (17 swarms, 89 types) | Hot |
| `src/bees/swarm-coordinator.js` | Swarm lifecycle and consensus | Warm |

### Middle Ring — CSL Engine
| File | Purpose | Pool |
|------|---------|------|
| `src/csl/csl-engine.js` | CSL AND/OR/NOT/IMPLY/XOR/GATE | Hot |
| `src/csl/csl-router.js` | MoE cosine routing (CSL-based) | Hot |
| `src/csl/vector-space-ops.js` | Full 377D vector operations suite | Hot |

### Middle Ring — Memory & Embeddings
| File | Purpose | Pool |
|------|---------|------|
| `src/memory/vector-memory.js` | 3D vector memory + pgvector HNSW | Hot |
| `src/memory/embedding-router.js` | Multi-provider embedding + circuit breaker | Hot |
| `src/memory/context-window-manager.js` | 4-tier context + phi-eviction | Warm |
| `src/memory/vectorize-sync.js` | Edge Vectorize ↔ pgvector sync | Warm |

### Middle Ring — Resilience
| File | Purpose | Pool |
|------|---------|------|
| `src/resilience/circuit-breaker.js` | Half-open probe + phi-backoff | Hot |
| `src/resilience/exponential-backoff.js` | φ-scaled retry timing | Hot |
| `src/resilience/drift-detector.js` | Coherence drift + threshold alerts | Warm |
| `src/resilience/self-healer.js` | Quarantine → attest → respawn lifecycle | Warm |

### Outer Ring — Governance
| File | Purpose | Pool |
|------|---------|------|
| `src/governance/governance-gate.js` | CSL-gated quality enforcement | Warm |
| `src/governance/budget-tracker.js` | φ-scaled cost caps per provider | Warm |
| `src/governance/semantic-backpressure.js` | SRE throttling + dedup + load shedding | Warm |

### Outer Ring — Pipeline
| File | Purpose | Pool |
|------|---------|------|
| `src/pipeline/pipeline-core.js` | 12-stage HCFP orchestration | Hot |
| `src/pipeline/pipeline-stages.js` | Stage definitions and validators | Hot |

### Outer Ring — Auto-Success
| File | Purpose | Pool |
|------|---------|------|
| `src/auto-success/auto-success-engine.js` | Battle→Coder→Analyze→Risk→Patterns | Hot |

### Liquid Nodes — Edge AI
| File | Purpose | Pool |
|------|---------|------|
| `src/liquid-nodes/index.js` | Liquid node registry + exports | Hot |
| `src/liquid-nodes/edge-worker.js` | Cloudflare Worker for edge inference | Hot |
| `src/liquid-nodes/edge-origin-router.js` | φ-scored complexity routing | Hot |
| `src/liquid-nodes/durable-agent-state.js` | Hibernatable WebSocket + SQLite | Hot |

### Security Layer
| File | Purpose | Pool |
|------|---------|------|
| `src/security/index.js` | Security module exports | Hot |
| `src/security/cross-domain-auth.js` | 9-domain relay + PKCE + CSL confidence | Hot |
| `src/security/token-manager.js` | httpOnly cookies, no localStorage | Hot |
| `src/security/security-headers.js` | CSP, HSTS, X-Frame-Options | Hot |
| `src/security/csrf-protection.js` | Double-submit CSRF tokens | Hot |
| `src/security/input-validator.js` | Schema-based input validation | Hot |
| `src/security/secret-manager.js` | GCP Secret Manager integration | Hot |

### Middleware
| File | Purpose | Pool |
|------|---------|------|
| `src/middleware/index.js` | Middleware chain exports | Hot |
| `src/middleware/cors.js` | Explicit 9-domain origin whitelist | Hot |
| `src/middleware/auth-verify.js` | JWT verification middleware | Hot |
| `src/middleware/request-id.js` | Crypto-random request ID injection | Hot |
| `src/middleware/error-handler.js` | Structured error response handler | Hot |

### Bootstrap
| File | Purpose | Pool |
|------|---------|------|
| `src/bootstrap/bootstrap.js` | Service bootstrapper with graceful shutdown | Hot |
| `src/bootstrap/heady-manager.js` | MCP server + JSON-RPC handler | Hot |

### Utilities
| File | Purpose | Pool |
|------|---------|------|
| `src/utils/app-error.js` | Standard AppError class | Hot |
| `src/utils/config-loader.js` | φ-validated config loader | Hot |
| `src/utils/retry-helper.js` | Retry with phi-backoff | Hot |

## Shared Foundation

| File | Purpose |
|------|---------|
| `shared/phi-math.js` | Canonical φ-math: PHI, PSI, fib(), phiThreshold(), phiFusionWeights(), phiBackoff(), phiResourceWeights() |
| `shared/heady-domains.js` | 9 domains, ALLOWED_ORIGINS, NAVIGATION_MAP, isAllowedOrigin() |

## Services (8 microservices)

| Service | Port | Pool | Files |
|---------|------|------|-------|
| auth-session | 3360 | Hot | index.js, Dockerfile, package.json, README.md |
| notification | 3361 | Warm | index.js, Dockerfile, package.json, README.md |
| analytics | 3362 | Cold | index.js, Dockerfile, package.json, README.md |
| scheduler | 3363 | Warm | index.js, Dockerfile, package.json, README.md |
| search | 3364 | Hot | index.js, Dockerfile, package.json, README.md |
| onboarding | 3365 | Warm | index.js, Dockerfile, package.json, README.md, ui/index.html |
| domain-router | 3366 | Hot | index.js, Dockerfile, package.json, README.md |
| api-gateway | 3370 | Hot | index.js, Dockerfile, package.json, README.md, ui/index.html |

## UIs (3 Dashboards)

| Dashboard | Location | Features |
|-----------|----------|----------|
| Colab Runtime Dashboard | `colab-integration/ui/index.html` | 3 runtime cards (Hot/Warm/Cold), real-time VRAM, GPU util, task log, φ-heartbeat |
| System Dashboard | `services/api-gateway/ui/index.html` | 8 services + 9 domains, CSL scores, pool badges, nav bar |
| Onboarding Flow | `services/onboarding/ui/index.html` | Multi-step wizard, Sacred Geometry styling |

## Colab Integration (3 Pro+ Runtimes)

| File | Purpose |
|------|---------|
| `colab-integration/colab-gateway.js` | Express gateway bridging runtimes to services |
| `colab-integration/colab-runtime-bridge.py` | Python gRPC bridge running inside Colab |
| `colab-integration/colab-task-router.js` | CSL-scored task routing to Hot/Warm/Cold |
| `colab-integration/colab-vector-ops.js` | Vector operations delegated to GPU runtimes |
| `colab-integration/package.json` | Gateway dependencies |
| `colab-integration/colab-notebooks/heady-runtime-hot.ipynb` | A100 — inference, embeddings, search |
| `colab-integration/colab-notebooks/heady-runtime-warm.ipynb` | A100 — batch processing, fine-tuning |
| `colab-integration/colab-notebooks/heady-runtime-cold.ipynb` | A100 — analytics, pattern mining |
| `colab-integration/ui/index.html` | Runtime monitoring dashboard |

## Tests (13 suites, 244+ assertions)

| Suite | Type | Assertions |
|-------|------|------------|
| `tests/unit/phi-math.test.js` | Unit | 92 |
| `tests/unit/vector-space-ops.test.js` | Unit | 26 |
| `tests/unit/heady-domains.test.js` | Unit | 17 |
| `tests/unit/cross-domain-auth.test.js` | Unit | 16 |
| `tests/unit/token-manager.test.js` | Unit | 13 |
| `tests/unit/csl-engine.test.js` | Unit | 8 |
| `tests/unit/heady-soul.test.js` | Unit | 7 |
| `tests/unit/heady-vinci.test.js` | Unit | 7 |
| `tests/unit/auth-session.test.js` | Unit | 6 |
| `tests/integration/liquid-nodes.test.js` | Integration | 18 |
| `tests/integration/middleware.test.js` | Integration | 17 |
| `tests/integration/domain-router.test.js` | Integration | 10 |
| `tests/integration/security-headers.test.js` | Integration | 7 |

## Documentation (34 files)

### Core Docs
| File | Topic |
|------|-------|
| `docs/README.md` | Documentation hub — links to all docs |
| `docs/ERROR_CODES.md` | Error code reference |

### Architecture Decision Records (7)
| File | Decision |
|------|----------|
| `docs/adrs/README.md` | ADR index |
| `docs/adrs/001-why-sacred-geometry.md` | Why Sacred Geometry topology |
| `docs/adrs/002-why-50-services.md` | Why microservice decomposition |
| `docs/adrs/003-why-colab-as-latent-space.md` | Why Colab Pro+ as GPU compute |
| `docs/adrs/004-why-cross-domain-relay.md` | Why cross-domain auth relay |
| `docs/adrs/005-why-csl-over-boolean.md` | Why CSL replaces boolean logic |
| `docs/adrs/006-why-phi-derived-constants.md` | Why zero magic numbers |

### Section Docs
| File | Topic |
|------|-------|
| `docs/api-reference/README.md` | API reference overview |
| `docs/architecture/README.md` | System architecture overview |
| `docs/getting-started/README.md` | Getting started guide |
| `docs/phi-compliance/README.md` | φ-compliance rules and tooling |
| `docs/security/README.md` | Security architecture overview |
| `docs/services/README.md` | Services overview |

### Service Documentation (8)
| File | Service |
|------|---------|
| `docs/services/auth-session.md` | Auth Session service |
| `docs/services/notification.md` | Notification service |
| `docs/services/analytics.md` | Analytics service |
| `docs/services/scheduler.md` | Scheduler service |
| `docs/services/search.md` | Search service |
| `docs/services/onboarding.md` | Onboarding service |
| `docs/services/domain-router.md` | Domain Router service |
| `docs/services/api-gateway.md` | API Gateway service |

### Operational Runbooks (10)
| File | Runbook |
|------|---------|
| `docs/runbooks/README.md` | Runbook index |
| `docs/runbooks/auth-session-runbook.md` | Auth Session ops |
| `docs/runbooks/notification-runbook.md` | Notification ops |
| `docs/runbooks/analytics-runbook.md` | Analytics ops |
| `docs/runbooks/scheduler-runbook.md` | Scheduler ops |
| `docs/runbooks/search-runbook.md` | Search ops |
| `docs/runbooks/onboarding-runbook.md` | Onboarding ops |
| `docs/runbooks/domain-router-runbook.md` | Domain Router ops |
| `docs/runbooks/api-gateway-runbook.md` | API Gateway ops |
| `docs/runbooks/incident-response-runbook.md` | Incident response playbook |

## Infrastructure

| File | Purpose |
|------|---------|
| `Dockerfile` | Root multi-stage Docker build |
| `docker-compose.yml` | 8-service compose with phi-health checks |
| `infrastructure/docker/Dockerfile.service` | Service template Dockerfile |
| `infrastructure/docker/docker-compose.yml` | Full infra compose |
| `infrastructure/docker/.env.example` | Environment template |
| `infrastructure/envoy/envoy.yaml` | Envoy sidecar proxy config |
| `infrastructure/prometheus/prometheus.yml` | Prometheus scrape config |
| `infrastructure/grafana/dashboards/heady-overview.json` | Grafana dashboard |
| `infrastructure/ci-cd/test.yaml` | CI test pipeline |
| `infrastructure/ci-cd/deploy.yaml` | CD deploy pipeline |
| `infrastructure/consul/consul-config.json` | Service discovery config |

## Configuration

| File | Purpose |
|------|---------|
| `configs/system.yaml` | System-wide φ-derived configuration |
| `configs/domains.yaml` | Domain routing rules |
| `configs/sacred-geometry.yaml` | Ring topology + node placement |

## Observability

| File | Purpose |
|------|---------|
| `observability/metrics-collector.js` | Prometheus-compatible metrics |
| `observability/otel-config.js` | OpenTelemetry configuration |

## Security (Standalone)

| File | Purpose |
|------|---------|
| `security/rate-limiter.js` | Token bucket rate limiter |
| `security/csp-headers.js` | Content Security Policy generator |
| `security/prompt-defense.js` | LLM prompt injection defense |

## Root Files

| File | Purpose |
|------|---------|
| `package.json` | @heady/latent-os v5.5.0 |
| `MANIFEST.md` | This file |
| `ARCHITECTURE.md` | System architecture overview |
| `CHANGES.md` | Version changelog |
| `IMPROVEMENTS.md` | Improvement tracking |
| `GAPS_FOUND.md` | Gap analysis results |
| `PHI-COMPLIANCE-SCORECARD.md` | φ compliance audit results |

## φ-Compliance Summary

- **ZERO console.log** in src/ — all structured JSON logging
- **ZERO localStorage** — httpOnly cookies only
- **ZERO TODO/FIXME/HACK** — no placeholders
- **ZERO empty catch blocks** — all named error parameters
- **ZERO wildcard CORS** — explicit 9-domain origin whitelist
- **ZERO magic numbers** — all constants φ-derived or Fibonacci
- **ZERO localhost** — service names and 0.0.0.0 only
- **All** modules import from `shared/phi-math.js`
- **Author**: Eric Haywood (eric@headysystems.com)
- **13/13 test suites passing** (244+ assertions)
