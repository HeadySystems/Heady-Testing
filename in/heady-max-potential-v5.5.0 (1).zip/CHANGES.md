# Changelog

## v5.5.0 — phi-math.js v4.1.0 Canonical Integration (2026-03-11)

### Breaking Changes
- `shared/phi-math.js` upgraded to v4.1.0 canonical reference implementation
- All magic numbers in domain constants eliminated:
  - `PIPELINE.CONTEXT_GATE`: 0.92 → `CSL_THRESHOLDS.CRITICAL` (≈ 0.927)
  - `PIPELINE.TIMEOUT.EXECUTE`: 120000 → `phiMs(10)` (121,393ms)
  - `BEE.STALE_MS`: 60000 → `phiMs(8)` (46,979ms)
  - `BEE.MAX_TOTAL`: 10000 → `fib(20)` (6,765)
  - `VECTOR.DIMS`: 384 → `fib(14)` (377)
  - `COST_W` values: hardcoded → φ-derived ratios

### New Exports (from phi-math v4.1.0)
- `PHI2`, `PHI3` — canonical names for φ², φ³
- `DEDUP_THRESHOLD`, `COHERENCE_DRIFT_THRESHOLD` — standalone constants
- `COMPRESSION_TRIGGER` — 1 - ψ⁴ ≈ 0.910
- `PHI_TEMPERATURE` — ψ³ ≈ 0.236
- `phiPriorityScore()` — φ-weighted N-factor scoring
- `phiResourceWeights()` — alias for phiFusionWeights
- `fibRetryBackoff()` — Fibonacci-stepped retry delays
- `phiAdaptiveInterval()` — health-aware interval adjustment
- `cslAND`, `cslOR`, `cslNOT`, `cslIMPLY`, `cslCONSENSUS`, `cslXOR` — canonical CSL vector operations
- `SIZING` — Fibonacci-sized constants for caches, queues, pools
- `POOL_SIZES` — min/max pool boundaries
- `RELEVANCE_GATES` — ψ²/ψ/ψ+0.1 relevance scoring gates
- `PRESSURE_LEVELS`, `ALERT_THRESHOLDS` — canonical names
- `EVICTION_WEIGHTS`, `RESOURCE_WEIGHTS` — canonical names

### Backward Compatibility
- All previous exports preserved as aliases:
  - `PHI_SQ` → `PHI2`, `PHI_CUBED` → `PHI3`, `FIB_CACHE` → `FIB`
  - `PRESSURE` → `PRESSURE_LEVELS`, `ALERTS` → `ALERT_THRESHOLDS`
  - `EVICTION` → `EVICTION_WEIGHTS` (with uppercase keys)
  - `phiPower`, `phiMs`, `PHI_TIMING` — all preserved
  - `phiBackoffWithJitter`, `PHI_BACKOFF_SEQ` — preserved
  - `phiMultiSplit`, `getPressureLevel` — preserved
  - `sigmoid`, `normalize` — preserved
  - `AUTO_SUCCESS`, `PIPELINE`, `BEE`, `POOLS`, `JUDGE`, `COST_W`, `VECTOR` — preserved

### Updated Modules
- `src/csl/vector-space-ops.js` — delegates to canonical phi-math CSL ops
- `src/csl/csl-engine.js` — imports new canonical exports
- `tests/unit/phi-math.test.js` — comprehensive v4.1.0 test suite (75+ assertions)
- `tests/unit/vector-space-ops.test.js` — updated for canonical CSL delegation
- Patent count updated: 51 → 60+ Provisional Patents

# Heady™ Latent OS — Changelog

## v5.4.0 (2026-03-10)

### Sacred Geometry Inner Ring
- **NEW**: `src/core/heady-soul.js` — Values, Awareness, and Ethical Core (center of all rings)
- **NEW**: `src/core/heady-brains.js` — Context Assembly Engine (tiered context capsules)
- **NEW**: `src/orchestration/heady-vinci.js` — Session Planner with DAG decomposition

### Vector Space Computing
- **NEW**: `src/csl/vector-space-ops.js` — Full CSL operations (AND, OR, NOT, IMPLY, XOR, CONSENSUS, GATE)
- **NEW**: `src/orchestration/async-parallel-executor.js` — DAG-aware concurrent task execution
- **NEW**: `src/orchestration/swarm-intelligence.js` — Arena Mode, Consensus Mode, Delegation Mode
- **NEW**: `src/memory/vectorize-sync.js` — Cloudflare Vectorize ↔ pgvector bidirectional sync

### User Interfaces
- **NEW**: `colab-integration/ui/index.html` — Colab Runtime Dashboard (3 Pro+ runtimes, real-time metrics)
- **NEW**: `services/api-gateway/ui/index.html` — System Dashboard (Sacred Geometry node visualization, 9-domain nav)

### Improvements
- **FIX**: Domain Router now has graceful shutdown (SIGTERM/SIGINT)
- All φ-derived constants verified across new modules
- Zero TODO/FIXME/HACK placeholders

### Tests
- **NEW**: `tests/unit/vector-space-ops.test.js` — 24 assertions (CSL operations)
- **NEW**: `tests/unit/heady-soul.test.js` — 7 assertions
- **NEW**: `tests/unit/heady-vinci.test.js` — 7 assertions (HeadyVinci + AsyncParallelExecutor)
- Total: 13 test files, 150+ assertions

## v5.3.0 (2026-03-10)

### Auth & Cross-Domain
- **NEW**: `shared/heady-domains.js` — Canonical domain registry (single source of truth for all 9 domains)
- **NEW**: `src/security/cross-domain-auth.js` — Cross-domain auth relay with one-time codes, PKCE, bridge iframe
- **NEW**: `src/security/token-manager.js` — Centralized token lifecycle (generate, verify, refresh, revoke)
- **NEW**: `src/security/security-headers.js` — CSP, HSTS, security response headers from canonical domain list
- **NEW**: `services/domain-router/` — Cross-domain link verification + auth handoff service (Port 3366)
- **FIX**: ALLOWED_ORIGINS mismatch — all services now import from `shared/heady-domains.js`

### Documentation Hub
- **NEW**: `docs/README.md` — Comprehensive documentation hub with navigation table
- **NEW**: `docs/getting-started/README.md` — Developer quickstart guide
- **NEW**: `docs/architecture/README.md` — System design, topology, data flow
- **NEW**: `docs/api-reference/README.md` — Complete endpoint reference for all 8 services
- **NEW**: `docs/services/` — Individual documentation for each of the 8 services
- **NEW**: `docs/security/README.md` — Auth flows, CSP, cross-domain security, CSL-gated confidence
- **NEW**: `docs/phi-compliance/README.md` — φ-math rules, threshold tables, compliance scoring
- **NEW**: ADR-004 (Cross-Domain Relay), ADR-005 (CSL over Boolean), ADR-006 (φ-Derived Constants)
- **NEW**: 8 operational runbooks + incident response runbook
- **NEW**: Indexed ADR and runbook directories

### Tests
- **NEW**: `tests/unit/cross-domain-auth.test.js` — 17 assertions
- **NEW**: `tests/unit/token-manager.test.js` — 12 assertions
- **NEW**: `tests/unit/heady-domains.test.js` — 17 assertions
- **NEW**: `tests/integration/domain-router.test.js` — 10 assertions
- **NEW**: `tests/integration/security-headers.test.js` — 8 assertions
- Total: 120+ assertions across 10 test files

## v5.2.0 (2026-03-09)
- Added API Gateway service (Port 3370)
- Added middleware layer (auth, CORS, errors, request-id)
- Added security layer (CSRF, input validation, secret management)
- Added utils (AppError, config loader, retry helper)
- Added liquid nodes (Durable Objects, edge workers)
- Added onboarding service (Port 3365)
- Added root Dockerfile and docker-compose.yml
- Added 2 integration test suites (35 assertions)
- Total: 117 files, 84 tests passing

## v5.1.0 (2026-03-09)
- Added 5 core services (auth, notification, analytics, scheduler, search)
- Added Colab integration (gateway, bridge, notebooks)
- Added security modules (CSP, rate limiter, prompt defense)
- Added observability (OpenTelemetry, Prometheus metrics)
- Added infrastructure (Docker, Envoy, Consul, Grafana, CI/CD)
- Added 3 unit test suites (49 assertions)
- Added 3 ADRs, ERROR_CODES.md, 2 runbooks
- Total: 87 files, 49 tests passing

## v5.0.0 (2026-03-09)
- Complete Latent OS core: 35 modules
- φ-math foundation: 100/100 compliance
- CSL engine, Sacred Geometry topology
- Resilience, memory, orchestration, pipeline, governance
- Budget tracking, semantic backpressure
- Self-healing, drift detection

## v4.0.0 (2026-03-09)
- Deep scan audit of 7 files + 13 repos
- Found and corrected 37 magic numbers
- Established zero-magic-numbers baseline
