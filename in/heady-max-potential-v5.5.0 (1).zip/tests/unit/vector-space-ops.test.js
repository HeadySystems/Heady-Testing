/**
 * Heady™ Latent OS v5.5.0
 * vector-space-ops test suite
 * © 2026 HeadySystems Inc. — Eric Haywood — 60+ Provisional Patents
 */
'use strict';
const assert = require('assert');
const {
  cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS, cslXOR,
  cslGate, cslBlend, cosineSimilarity, normalize, sigmoid,
  CSL_THRESHOLDS, PHI_TEMPERATURE,
  DEFAULT_DIM, COLLAPSE_THRESHOLD,
  adaptiveGATE,
  randomUnitVector, zeroVector,
  phiFusionScores, isCollapsed,
  dot, magnitude, phiFusionWeights,
} = require('../../src/csl/vector-space-ops');

const { PSI, fib } = require('../../shared/phi-math');

let passed = 0, failed = 0, total = 0;
function test(name, fn) {
  total++;
  try { fn(); passed++;
    process.stdout.write(JSON.stringify({ level: 'info', test: name, status: 'PASS' }) + '\n');
  } catch (testErr) { failed++;
    process.stdout.write(JSON.stringify({ level: 'error', test: name, status: 'FAIL', error: testErr.message }) + '\n');
  }
}

function approx(a, b, eps = 1e-6) {
  assert.ok(Math.abs(a - b) < eps, `Expected ${a} ≈ ${b}`);
}

// ─── CSL GATE OPERATIONS ────────────────────────────────────────────────────

test('cslAND: identical vectors = 1.0', () => approx(cslAND([1,0,0], [1,0,0]), 1.0));
test('cslAND: opposite vectors ≈ -1.0', () => approx(cslAND([1,0], [-1,0]), -1.0));
test('cslAND: orthogonal vectors = 0', () => approx(cslAND([1,0,0], [0,1,0]), 0));
test('cslAND: is commutative', () => {
  const a = [0.5, 0.8, 0.3], b = [0.1, 0.9, 0.4];
  approx(cslAND(a, b), cslAND(b, a));
});
test('cslOR: result is unit vector', () => {
  const r = cslOR([1,0,0], [0,1,0]);
  approx(Math.sqrt(r.reduce((s,v) => s + v*v, 0)), 1.0, 0.001);
});
test('cslOR: self-union is self', () => {
  const v = [1, 0, 0];
  const r = cslOR(v, v);
  approx(r[0], 1.0, 0.001);
});
test('cslNOT: result is orthogonal to b', () => {
  const r = cslNOT([1,1,0], [1,0,0]);
  approx(r.reduce((s,v,i) => s + v * [1,0,0][i], 0), 0, 0.001);
});
test('cslNOT: is idempotent (NOT(NOT(a,b),b) = NOT(a,b))', () => {
  const a = [0.7, 0.3, 0.5], b = [1, 0, 0];
  const first = cslNOT(a, b);
  const second = cslNOT(first, b);
  for (let i = 0; i < a.length; i++) approx(first[i], second[i], 0.001);
});
test('cslIMPLY: projection of aligned vectors', () => {
  const r = cslIMPLY([2,0,0], [1,0,0]);
  approx(r[0], 2.0, 0.001);
});
test('cslCONSENSUS: single vector returns itself', () => {
  const r = cslCONSENSUS([[1,0,0]]);
  approx(r[0], 1.0, 0.001);
});
test('cslCONSENSUS: result is unit vector', () => {
  const r = cslCONSENSUS([[1,0,0], [0,1,0]]);
  approx(Math.sqrt(r.reduce((s,v) => s + v*v, 0)), 1.0, 0.001);
});
test('cslXOR: exists and returns array', () => {
  const r = cslXOR([1,0,0], [0,1,0]);
  assert.ok(Array.isArray(r) && r.length === 3);
});

// ─── GATE ───────────────────────────────────────────────────────────────────

test('cslGate: high score passes gate', () => {
  const gated = cslGate(1.0, 0.95, CSL_THRESHOLDS.MINIMUM);
  assert.ok(gated > 0.8, `Expected >0.8, got ${gated}`);
});
test('cslGate: low score blocks gate', () => {
  const gated = cslGate(1.0, 0.1, CSL_THRESHOLDS.MEDIUM);
  assert.ok(gated < 0.1, `Expected <0.1, got ${gated}`);
});
test('cslGate: works with number value', () => {
  const gated = cslGate(5.0, 0.95, CSL_THRESHOLDS.MINIMUM);
  assert.ok(gated > 4.0 && gated <= 5.0);
});
test('sigmoid(0) = 0.5', () => assert.strictEqual(sigmoid(0), 0.5));

// ─── UTILITIES ──────────────────────────────────────────────────────────────

test('normalize: produces unit vector', () => {
  const r = normalize([3, 4]);
  approx(Math.sqrt(r[0]*r[0] + r[1]*r[1]), 1.0, 0.001);
});
test('randomUnitVector: correct dimension and unit length', () => {
  const v = randomUnitVector(8);
  assert.strictEqual(v.length, 8);
  approx(magnitude(v), 1.0, 0.01);
});
test('phiFusionScores: single score returns itself', () => {
  approx(phiFusionScores([0.75]), 0.75);
});
test('phiFusionScores: first score carries most weight', () => {
  const result = phiFusionScores([1.0, 0.0, 0.0]);
  assert.ok(result >= 0.5, `Expected >=0.5, got ${result}`);
});
test('isCollapsed: zero vector is collapsed', () => {
  assert.strictEqual(isCollapsed(zeroVector(8)), true);
});
test('isCollapsed: unit vector is not collapsed', () => {
  assert.strictEqual(isCollapsed(randomUnitVector(8)), false);
});
test('DEFAULT_DIM is fib(14) = 377', () => {
  assert.strictEqual(DEFAULT_DIM, 377);
});
test('PHI_TEMPERATURE is ψ³', () => {
  approx(PHI_TEMPERATURE, Math.pow(PSI, 3));
});
test('dot product basic', () => {
  approx(dot([1,2,3], [4,5,6]), 32);
});
test('magnitude basic', () => {
  approx(magnitude([3,4]), 5.0);
});

// ─── RESULTS ────────────────────────────────────────────────────────────────

process.stdout.write(JSON.stringify({
  level: 'info', suite: 'vector-space-ops',
  passed, total, status: passed === total ? 'ALL_PASS' : 'SOME_FAIL'
}) + '\n');
process.exit(passed === total ? 0 : 1);
