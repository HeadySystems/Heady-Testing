/**
 * Heady™ Latent OS v5.5.0
 * phi-math.js v4.1.0 — Comprehensive test suite
 * © 2026 HeadySystems Inc. — Eric Haywood — 60+ Provisional Patents
 */
'use strict';
const assert = require('assert');
const {
  PHI, PSI, PHI2, PHI3, PHI_SQ, PHI_CUBED, SQRT5,
  FIB, FIB_CACHE, fib, fibCeil, fibFloor,
  phiPower, phiMs, PHI_TIMING,
  phiThreshold, CSL_THRESHOLDS,
  DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  phiBackoff, phiBackoffWithJitter, fibRetryBackoff, phiAdaptiveInterval,
  PHI_BACKOFF_SEQ,
  phiFusionWeights, phiPriorityScore, phiMultiSplit,
  EVICTION_WEIGHTS, RESOURCE_WEIGHTS, phiResourceWeights,
  EVICTION,
  PRESSURE_LEVELS, ALERT_THRESHOLDS,
  PRESSURE, ALERTS, getPressureLevel,
  PHI_TEMPERATURE, sigmoid, cslGate, cslBlend, adaptiveTemperature,
  cosineSimilarity, normalize,
  cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS, cslXOR,
  SIZING, POOL_SIZES, RELEVANCE_GATES,
  COMPRESSION_TRIGGER,
  phiTokenBudgets,
  AUTO_SUCCESS, PIPELINE, BEE, POOLS,
  JUDGE, COST_W, VECTOR,
} = require('../../shared/phi-math');

let passed = 0, failed = 0, total = 0;

function test(name, fn) {
  total++;
  try {
    fn();
    passed++;
  } catch (testErr) {
    failed++;
    process.stderr.write(JSON.stringify({
      level: 'error', test: name, status: 'FAIL', error: testErr.message
    }) + '\n');
  }
}

function approx(a, b, eps = 1e-6) {
  assert.ok(Math.abs(a - b) < eps, `Expected ${a} ≈ ${b} (diff: ${Math.abs(a - b)})`);
}

// ─── CORE CONSTANTS ─────────────────────────────────────────────────────────

test('PHI ≈ 1.618', () => approx(PHI, 1.6180339887, 1e-6));
test('PSI ≈ 0.618', () => approx(PSI, 0.6180339887, 1e-6));
test('PHI * PSI = 1', () => approx(PHI * PSI, 1.0));
test('PHI2 = PHI + 1', () => approx(PHI2, PHI + 1));
test('PHI3 = 2*PHI + 1', () => approx(PHI3, 2 * PHI + 1));
test('PHI_SQ is alias for PHI2', () => assert.strictEqual(PHI_SQ, PHI2));
test('PHI_CUBED is alias for PHI3', () => assert.strictEqual(PHI_CUBED, PHI3));
test('SQRT5 ≈ 2.236', () => approx(SQRT5, Math.sqrt(5)));

// ─── FIBONACCI ──────────────────────────────────────────────────────────────

test('fib(0) = 0', () => assert.strictEqual(fib(0), 0));
test('fib(1) = 1', () => assert.strictEqual(fib(1), 1));
test('fib(7) = 13', () => assert.strictEqual(fib(7), 13));
test('fib(12) = 144', () => assert.strictEqual(fib(12), 144));
test('fib(14) = 377', () => assert.strictEqual(fib(14), 377));
test('fib(20) = 6765', () => assert.strictEqual(fib(20), 6765));
test('fib(-1) = 0', () => assert.strictEqual(fib(-1), 0));
test('fib(25) computed beyond cache', () => assert.ok(fib(25) > 0));
test('FIB is alias for FIB_CACHE', () => assert.strictEqual(FIB, FIB_CACHE));
test('fibCeil(10) = 13', () => assert.strictEqual(fibCeil(10), 13));
test('fibFloor(10) = 8', () => assert.strictEqual(fibFloor(10), 8));

// ─── PHI TIMING ─────────────────────────────────────────────────────────────

test('PHI_TIMING.PHI_7 ≈ 29034', () => assert.strictEqual(PHI_TIMING.PHI_7, 29034));
test('phiMs(1) = 1618', () => assert.strictEqual(phiMs(1), 1618));
test('phiPower(2) = PHI2', () => approx(phiPower(2), PHI2));

// ─── CSL THRESHOLDS ─────────────────────────────────────────────────────────

test('CSL MINIMUM = 0.5', () => assert.strictEqual(CSL_THRESHOLDS.MINIMUM, 0.5));
test('CSL LOW ≈ 0.691', () => approx(CSL_THRESHOLDS.LOW, 0.691, 0.001));
test('CSL MEDIUM ≈ 0.809', () => approx(CSL_THRESHOLDS.MEDIUM, 0.809, 0.001));
test('CSL HIGH ≈ 0.882', () => approx(CSL_THRESHOLDS.HIGH, 0.882, 0.001));
test('CSL CRITICAL ≈ 0.927', () => approx(CSL_THRESHOLDS.CRITICAL, 0.927, 0.001));
test('CSL hierarchy: MIN < LOW < MED < HIGH < CRIT', () => {
  const t = CSL_THRESHOLDS;
  assert.ok(t.MINIMUM < t.LOW && t.LOW < t.MEDIUM && t.MEDIUM < t.HIGH && t.HIGH < t.CRITICAL);
});
test('DEDUP_THRESHOLD > CRITICAL', () => assert.ok(DEDUP_THRESHOLD > CSL_THRESHOLDS.CRITICAL));
test('COHERENCE_DRIFT_THRESHOLD = MEDIUM', () => assert.strictEqual(COHERENCE_DRIFT_THRESHOLD, CSL_THRESHOLDS.MEDIUM));
test('CSL_THRESHOLDS.DEDUP matches standalone', () => approx(CSL_THRESHOLDS.DEDUP, DEDUP_THRESHOLD, 0.001));
test('CSL_THRESHOLDS.COHERENCE matches standalone', () => assert.strictEqual(CSL_THRESHOLDS.COHERENCE, COHERENCE_DRIFT_THRESHOLD));

// ─── PRESSURE & ALERTS ──────────────────────────────────────────────────────

test('PRESSURE_LEVELS.NOMINAL.max ≈ 0.382', () => approx(PRESSURE_LEVELS.NOMINAL.max, 0.382, 0.001));
test('PRESSURE is alias for PRESSURE_LEVELS', () => assert.strictEqual(PRESSURE, PRESSURE_LEVELS));
test('ALERTS is alias for ALERT_THRESHOLDS', () => assert.strictEqual(ALERTS, ALERT_THRESHOLDS));
test('ALERT_THRESHOLDS.warning = PSI', () => assert.strictEqual(ALERT_THRESHOLDS.warning, PSI));
test('ALERT_THRESHOLDS has uppercase compat', () => assert.strictEqual(ALERT_THRESHOLDS.WARNING, PSI));
test('getPressureLevel(0.1) = NOMINAL', () => assert.strictEqual(getPressureLevel(0.1).label, 'NOMINAL'));
test('getPressureLevel(0.5) = ELEVATED', () => assert.strictEqual(getPressureLevel(0.5).label, 'ELEVATED'));
test('getPressureLevel(0.7) = HIGH', () => assert.strictEqual(getPressureLevel(0.7).label, 'HIGH'));
test('getPressureLevel(0.95) = CRITICAL', () => assert.strictEqual(getPressureLevel(0.95).label, 'CRITICAL'));

// ─── FUSION & SCORING ───────────────────────────────────────────────────────

test('phiFusionWeights(2) sums to 1', () => {
  const w = phiFusionWeights(2);
  approx(w.reduce((a, b) => a + b, 0), 1.0, 0.001);
});
test('phiFusionWeights(3) sums to 1', () => {
  const w = phiFusionWeights(3);
  approx(w.reduce((a, b) => a + b, 0), 1.0, 0.001);
});
test('phiFusionWeights(2)[0] > [1]', () => {
  const w = phiFusionWeights(2);
  assert.ok(w[0] > w[1]);
});
test('phiPriorityScore exists and is callable', () => {
  const score = phiPriorityScore(0.9, 0.7, 0.5);
  assert.ok(typeof score === 'number' && score > 0);
});
test('phiMultiSplit preserves total', () => {
  const splits = phiMultiSplit(100, 3);
  assert.ok(Math.abs(splits.reduce((a, b) => a + b, 0) - 100) <= 2);
});
test('EVICTION_WEIGHTS.importance > recency > relevance', () => {
  assert.ok(EVICTION_WEIGHTS.importance > EVICTION_WEIGHTS.recency);
  assert.ok(EVICTION_WEIGHTS.recency > EVICTION_WEIGHTS.relevance);
});
test('EVICTION backward compat (uppercase)', () => {
  approx(EVICTION.IMPORTANCE, EVICTION_WEIGHTS.importance);
});
test('RESOURCE_WEIGHTS.hot > warm > cold', () => {
  assert.ok(RESOURCE_WEIGHTS.hot > RESOURCE_WEIGHTS.warm);
  assert.ok(RESOURCE_WEIGHTS.warm > RESOURCE_WEIGHTS.cold);
});
test('phiResourceWeights is an alias for phiFusionWeights', () => {
  const a = phiResourceWeights(3);
  const b = phiFusionWeights(3);
  approx(a[0], b[0]);
});

// ─── BACKOFF ────────────────────────────────────────────────────────────────

test('phiBackoff(0) ≈ 1000', () => {
  const val = phiBackoff(0, 1000, 60000, false);
  assert.strictEqual(val, 1000);
});
test('phiBackoff increases with attempts', () => {
  const a0 = phiBackoff(0, 1000, 60000, false);
  const a1 = phiBackoff(1, 1000, 60000, false);
  assert.ok(a1 > a0);
});
test('phiBackoff respects max', () => {
  const val = phiBackoff(100, 1000, 5000, false);
  assert.ok(val <= 5000);
});
test('phiBackoffWithJitter callable', () => {
  const val = phiBackoffWithJitter(0);
  assert.ok(typeof val === 'number' && val > 0);
});
test('fibRetryBackoff returns array', () => {
  const arr = fibRetryBackoff(5, 100);
  assert.strictEqual(arr.length, 5);
  assert.strictEqual(arr[0], 300); // fib(4)=3 * 100
});
test('phiAdaptiveInterval: healthy increases', () => {
  const next = phiAdaptiveInterval(1000, true, 1000);
  assert.ok(next > 1000);
});
test('phiAdaptiveInterval: unhealthy decreases', () => {
  const next = phiAdaptiveInterval(1000, false, 1000);
  assert.ok(next < 1000);
});
test('PHI_BACKOFF_SEQ[0] = 1000', () => assert.strictEqual(PHI_BACKOFF_SEQ[0], 1000));

// ─── TOKEN BUDGETS ──────────────────────────────────────────────────────────

test('phiTokenBudgets: working < session < memory < artifacts', () => {
  const b = phiTokenBudgets();
  assert.ok(b.working < b.session && b.session < b.memory && b.memory < b.artifacts);
});
test('COMPRESSION_TRIGGER ≈ 0.91', () => approx(COMPRESSION_TRIGGER, 1 - Math.pow(PSI, 4), 0.001));

// ─── CSL GATES ──────────────────────────────────────────────────────────────

test('PHI_TEMPERATURE = PSI^3', () => approx(PHI_TEMPERATURE, Math.pow(PSI, 3)));
test('sigmoid(0) = 0.5', () => assert.strictEqual(sigmoid(0), 0.5));
test('sigmoid is monotonic', () => assert.ok(sigmoid(1) > sigmoid(0)));
test('cslGate: high cos passes', () => {
  const gated = cslGate(1.0, 0.95, CSL_THRESHOLDS.MINIMUM);
  assert.ok(gated > 0.8);
});
test('cslGate: low cos blocks', () => {
  const gated = cslGate(1.0, 0.1, CSL_THRESHOLDS.MEDIUM);
  assert.ok(gated < 0.1);
});
test('cslBlend interpolates', () => {
  const blended = cslBlend(1.0, 0.0, 0.9, 0.5);
  assert.ok(blended > 0.5 && blended < 1.0);
});
test('adaptiveTemperature: higher entropy = higher temp', () => {
  const t1 = adaptiveTemperature(0.5, 1.0);
  const t2 = adaptiveTemperature(0.9, 1.0);
  assert.ok(t2 > t1);
});

// ─── CSL VECTOR OPERATIONS ──────────────────────────────────────────────────

test('cosineSimilarity: identical = 1.0', () => {
  approx(cosineSimilarity([1,0,0], [1,0,0]), 1.0);
});
test('cosineSimilarity: orthogonal = 0', () => {
  approx(cosineSimilarity([1,0,0], [0,1,0]), 0);
});
test('cslAND is cosineSimilarity', () => {
  approx(cslAND([1,0], [1,0]), 1.0);
});
test('cslOR: result is unit vector', () => {
  const r = cslOR([1,0,0], [0,1,0]);
  const mag = Math.sqrt(r.reduce((s,v) => s + v*v, 0));
  approx(mag, 1.0, 0.001);
});
test('cslNOT: result orthogonal to b', () => {
  const result = cslNOT([1,1,0], [1,0,0]);
  const dotProd = result.reduce((s,v,i) => s + v * [1,0,0][i], 0);
  approx(dotProd, 0, 0.001);
});
test('cslIMPLY: projection of aligned vectors', () => {
  const result = cslIMPLY([2,0,0], [1,0,0]);
  approx(result[0], 2.0, 0.001);
});
test('cslCONSENSUS: single vector returns itself', () => {
  const r = cslCONSENSUS([[1,0,0]]);
  approx(r[0], 1.0, 0.001);
});
test('cslXOR: exists and returns array', () => {
  const r = cslXOR([1,0,0], [0,1,0]);
  assert.ok(Array.isArray(r) && r.length === 3);
});
test('normalize: produces unit vector', () => {
  const r = normalize([3, 4]);
  approx(Math.sqrt(r[0]*r[0] + r[1]*r[1]), 1.0, 0.001);
});

// ─── SIZING ─────────────────────────────────────────────────────────────────

test('SIZING.CACHE_SIZE = fib(16) = 987', () => assert.strictEqual(SIZING.CACHE_SIZE, 987));
test('SIZING.QUEUE_DEPTH = fib(13) = 233', () => assert.strictEqual(SIZING.QUEUE_DEPTH, 233));
test('SIZING.MAX_CONCURRENT = fib(6) = 8', () => assert.strictEqual(SIZING.MAX_CONCURRENT, 8));
test('POOL_SIZES.min = fib(3) = 2', () => assert.strictEqual(POOL_SIZES.min, 2));
test('POOL_SIZES.max = fib(7) = 13', () => assert.strictEqual(POOL_SIZES.max, 13));
test('RELEVANCE_GATES.boost = PSI', () => assert.strictEqual(RELEVANCE_GATES.boost, PSI));

// ─── DOMAIN CONSTANTS ───────────────────────────────────────────────────────

test('AUTO_SUCCESS.CYCLE_MS = PHI_TIMING.PHI_7', () => assert.strictEqual(AUTO_SUCCESS.CYCLE_MS, 29034));
test('PIPELINE.STAGES = fib(8) = 21', () => assert.strictEqual(PIPELINE.STAGES, 21));
test('PIPELINE.CONTEXT_GATE uses CSL threshold', () => approx(PIPELINE.CONTEXT_GATE, CSL_THRESHOLDS.CRITICAL, 0.001));
test('BEE.SWARMS = 17', () => assert.strictEqual(BEE.SWARMS, 17));
test('BEE.TYPES = fib(11) = 89', () => assert.strictEqual(BEE.TYPES, 89));
test('BEE.MAX_TOTAL = fib(20) = 6765', () => assert.strictEqual(BEE.MAX_TOTAL, 6765));
test('BEE.STALE_MS uses phiMs', () => assert.strictEqual(BEE.STALE_MS, phiMs(8)));
test('POOLS.HOT = 0.34', () => assert.strictEqual(POOLS.HOT, 0.34));
test('JUDGE.CORRECTNESS = 0.34', () => assert.strictEqual(JUDGE.CORRECTNESS, 0.34));
test('VECTOR.DIMS = fib(14) = 377', () => assert.strictEqual(VECTOR.DIMS, 377));

// ─── RESULTS ────────────────────────────────────────────────────────────────

process.stdout.write('\n' + '═'.repeat(60) + '\n');
process.stdout.write(`  phi-math.js v4.1.0 Tests: ${passed} passed, ${failed} failed\n`);
process.stdout.write('═'.repeat(60) + '\n\n');
process.exit(failed > 0 ? 1 : 0);
