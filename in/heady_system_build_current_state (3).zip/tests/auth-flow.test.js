import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();

test('auth relay keeps nonce, allowlist, and postMessage flow without localStorage', () => {
  const relay = fs.readFileSync(path.join(root, 'apps', 'sites', 'auth-headysystems', 'relay.html'), 'utf8');
  assert.match(relay, /ALLOWED_ORIGINS/);
  assert.match(relay, /postMessage/);
  assert.match(relay, /nonce/);
  assert.doesNotMatch(relay, /localStorage/);
});

test('shared auth runtime uses explicit allowed origins, relay nonce checks, and visible error dispatching', () => {
  const runtime = fs.readFileSync(path.join(root, 'packages', 'web-shared', 'js', 'heady-shared.js'), 'utf8');
  assert.match(runtime, /allowedOrigins/);
  assert.match(runtime, /_relayNonce/);
  assert.match(runtime, /CustomEvent\('heady:error'/);
  assert.match(runtime, /sandbox', 'allow-scripts allow-same-origin'/);
  assert.doesNotMatch(runtime, /catch \(e\) \{ \/\* silent \*\/ \}/);
});

test('platform auth module exposes JWT and service auth layers', () => {
  const auth = fs.readFileSync(path.join(root, 'packages', 'platform', 'src', 'auth', 'index.js'), 'utf8');
  assert.match(auth, /class JwtValidator/);
  assert.match(auth, /serviceAuthMiddleware/);
  assert.match(auth, /ReceiptSigner/);
  assert.match(auth, /issueSessionToken/);
  assert.match(auth, /verifyRefreshToken/);
  assert.match(auth, /normalizeReturnUrl/);
});

test('auth service implements session, refresh, logout, and provider flows with strict cookies', () => {
  const authService = fs.readFileSync(path.join(root, 'services', 'heady-auth', 'src', 'index.js'), 'utf8');
  assert.match(authService, /SESSION_COOKIE_NAME/);
  assert.match(authService, /app\.post\('\/api\/session\/start'/);
  assert.match(authService, /app\.post\('\/api\/session\/refresh'/);
  assert.match(authService, /app\.post\('\/api\/session\/logout'/);
  assert.match(authService, /app\.get\('\/api\/provider\/start'/);
  assert.match(authService, /buildCookieHeader/);
  assert.match(authService, /HttpOnly/);
  assert.match(authService, /SameSite: config\.cookies\.sameSite/);
});

test('platform middleware enforces explicit CORS allowlist and strict cookie helper defaults', () => {
  const middleware = fs.readFileSync(path.join(root, 'packages', 'platform', 'src', 'middleware', 'index.js'), 'utf8');
  assert.match(middleware, /export function headyCors/);
  assert.match(middleware, /Access-Control-Allow-Origin/);
  assert.match(middleware, /origin_not_allowed/);
  assert.match(middleware, /export function buildCookieHeader/);
  assert.match(middleware, /HttpOnly/);
  assert.match(middleware, /SameSite=\$\{opts\.sameSite \?\? 'Strict'\}/);
});

test('site auth config points to live auth session endpoints', () => {
  const authSite = fs.readFileSync(path.join(root, 'apps', 'sites', 'auth-headysystems', 'index.html'), 'utf8');
  assert.match(authSite, /api\/session\/start/);
  assert.match(authSite, /api\/session"/);
  assert.match(authSite, /api\/session\/refresh/);
  assert.match(authSite, /api\/session\/logout/);
  assert.match(authSite, /data-heady-auth-form/);
});
