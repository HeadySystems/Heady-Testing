/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  heady-auth — Service Entry Point                              ║
 * ║  Auth service — JWT/Ed25519 validation, mTLS, service identity                                                  ║
 * ║  © 2026 HeadySystems Inc. — 60+ Provisional Patents             ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * Domain:    headysystems.com
 * Port:      3309
 * Upstreams: none
 *
 * Middleware stack (in order):
 *   1. OpenTelemetry tracing init
 *   2. headyRequestId — trace/request ID propagation
 *   3. headyAutoContext — phi-context enrichment
 *   4. headyCslDomain — CSL domain matching across concurrent-equals domains
 *   5. headyAccessLog — structured pino JSON logging
 *   6. headyCors — explicit origin allowlist
 *   7. headyRateLimit — φ-scaled token bucket
 *   8. headySecurityHeaders — zero-trust headers
 *   9. [service-specific routes]
 *   10. headyErrorHandler — typed error handling
 *
 * Health endpoints:
 *   GET /health           — combined status
 *   GET /health/live      — Kubernetes liveness
 *   GET /health/ready     — Kubernetes readiness
 *   GET /health/startup   — Kubernetes startup
 *   GET /health/details   — phi-enriched full detail
 */

'use strict';

import express from 'express';
import {
  loadConfig,
  createLogger, logHealthEvent,
  initOtel, getTracer, createMetrics, headySpan,
  HealthRegistry, memoryCheck, envCheck,
  headyRequestId, headyAutoContext, headyCslDomain,
  headyAccessLog, headyCors, headyRateLimit, headySecurityHeaders, headyErrorHandler, buildCookieHeader,
  issueSessionToken, verifySessionToken, issueRefreshToken, verifyRefreshToken, issueStateToken, normalizeReturnUrl,
  PSI, CSL_THRESHOLDS, TIMEOUTS, AUTO_SUCCESS_CYCLE_MS, fib,
} from '@heady/platform';

// ─── BOOTSTRAP ────────────────────────────────────────────────────────────────

const SERVICE_NAME = 'heady-auth';
const config = loadConfig(SERVICE_NAME);
const logger = createLogger({
  service: SERVICE_NAME,
  domain:  config.domain,
  level:   process.env.LOG_LEVEL ?? 'info',
});

// Initialize OpenTelemetry BEFORE any imports that instrument
await initOtel({ service: SERVICE_NAME, domain: config.domain });
const tracer  = getTracer(SERVICE_NAME);
const metrics = createMetrics(SERVICE_NAME);

// ─── HEALTH REGISTRY ──────────────────────────────────────────────────────────

const health = new HealthRegistry({
  service: SERVICE_NAME,
  version: config.version,
  domain:  config.domain,
});

// Memory check (degraded if heap ratio > ψ = 0.618)
health.register('memory', memoryCheck());

// Required environment variables
health.register('env', envCheck([
  'SERVICE_NAME', 'SERVICE_VERSION', 'HEADY_DOMAIN', 'NODE_ENV',
]));
health.register('auth-config', async () => {
  try {
    getSessionSigningSecret();
    return { status: 'healthy', message: 'session signing secret configured' };
  } catch (error) {
    return { status: 'degraded', message: error.message };
  }
});

// ─── EXPRESS APP ─────────────────────────────────────────────────────────────

const app = express();

// Body parsing
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false, limit: '1mb' }));

// ── Middleware stack ──
app.use(headyRequestId());
app.use(headyAutoContext());           // HeadyAutoContext hooks
app.use(headyCslDomain([], null));     // CSL domain matching across concurrent-equals domains
app.use(headyAccessLog(logger));
app.use(headyCors(config.cors));
app.use(headyRateLimit({
  windowMs:    config.rateLimit.windowMs,
  maxRequests: config.rateLimit.maxRequests,
  burst:       config.rateLimit.burst,
}));
app.use(headySecurityHeaders());

// ── Health routes ──
health.attachRoutes(app);

// ─── AUTH CONSTANTS ──────────────────────────────────────────────────────────

const SESSION_COOKIE_NAME = 'heady_session';
const REFRESH_COOKIE_NAME = 'heady_refresh';
const DEFAULT_ALLOWED_RETURN_ORIGINS = [
  'https://headysystems.com',
  'https://auth.headysystems.com',
  'https://admin.headysystems.com',
  'https://headyme.com',
  'https://heady.io',
  'https://headyconnection.org',
  'https://headyconnection.com',
  'https://headyfinance.com',
  'https://headyex.com',
  'https://headyos.com',
  'https://heady-ai.com',
];
const DEFAULT_PROVIDER_ALLOWLIST = ['google', 'github', 'microsoft'];

const authState = new Map();

function getSessionSigningSecret() {
  const secret = process.env.JWT_SECRET ?? process.env.HEADY_SESSION_SECRET;
  if (!secret) throw new Error('JWT_SECRET or HEADY_SESSION_SECRET must be configured');
  return secret;
}

function parseAllowedReturnOrigins() {
  const configured = (process.env.AUTH_ALLOWED_RETURN_ORIGINS ?? '').split(',').map((value) => value.trim()).filter(Boolean);
  return configured.length ? configured : DEFAULT_ALLOWED_RETURN_ORIGINS;
}

function parseProviderAllowlist() {
  const configured = (process.env.AUTH_ALLOWED_PROVIDERS ?? '').split(',').map((value) => value.trim().toLowerCase()).filter(Boolean);
  return configured.length ? configured : DEFAULT_PROVIDER_ALLOWLIST;
}

function getCookieOptions() {
  return {
    domain: config.cookies.domain,
    path: config.cookies.path,
    secure: config.cookies.secure,
    httpOnly: config.cookies.httpOnly,
    sameSite: config.cookies.sameSite,
  };
}

function setAuthCookies(res, sessionToken, refreshToken) {
  const cookieOptions = getCookieOptions();
  res.append('Set-Cookie', buildCookieHeader(SESSION_COOKIE_NAME, sessionToken, {
    ...cookieOptions,
    maxAgeMs: config.cookies.maxAgeMs,
  }));
  res.append('Set-Cookie', buildCookieHeader(REFRESH_COOKIE_NAME, refreshToken, {
    ...cookieOptions,
    maxAgeMs: fib(13) * 60 * 1000,
  }));
}

function clearAuthCookies(res) {
  const cookieOptions = getCookieOptions();
  res.append('Set-Cookie', buildCookieHeader(SESSION_COOKIE_NAME, '', {
    ...cookieOptions,
    maxAgeMs: 0,
  }));
  res.append('Set-Cookie', buildCookieHeader(REFRESH_COOKIE_NAME, '', {
    ...cookieOptions,
    maxAgeMs: 0,
  }));
}

function parseCookies(req) {
  const raw = req.headers.cookie ?? '';
  return raw.split(';').map((entry) => entry.trim()).filter(Boolean).reduce((acc, entry) => {
    const separatorIndex = entry.indexOf('=');
    if (separatorIndex === -1) return acc;
    const key = entry.slice(0, separatorIndex);
    const value = entry.slice(separatorIndex + 1);
    acc[key] = decodeURIComponent(value);
    return acc;
  }, {});
}

function buildSessionClaims(identity, returnUrl, extras = {}) {
  return {
    sub: identity.email,
    email: identity.email,
    displayName: identity.displayName,
    roles: identity.roles,
    provider: identity.provider,
    returnUrl,
    ...extras,
  };
}

function resolveReturnUrl(candidate) {
  const allowedOrigins = parseAllowedReturnOrigins();
  return normalizeReturnUrl(candidate, allowedOrigins) ?? `${allowedOrigins[0]}/`;
}

function buildAuthUser(claims) {
  return {
    email: claims.email,
    displayName: claims.displayName,
    roles: claims.roles,
    provider: claims.provider,
  };
}

function buildRelaySession(claims, nonce = null) {
  return {
    active: true,
    source: 'auth-service',
    verifiedOrigin: config.domain,
    requestedSite: claims.returnUrl ?? null,
    nonce,
    expiresInMs: config.cookies.maxAgeMs,
  };
}

// ─── SERVICE ROUTES ───────────────────────────────────────────────────────────

/**
 * GET /status
 * Service identity and phi-context summary.
 */
app.get('/status', (req, res) => {
  res.json({
    service:     SERVICE_NAME,
    version:     config.version,
    domain:      config.domain,
    status:      'running',
    auth: {
      allowed_return_origins: parseAllowedReturnOrigins(),
      allowed_providers: parseProviderAllowlist(),
      cookie: {
        domain: config.cookies.domain ?? null,
        path: config.cookies.path,
        sameSite: config.cookies.sameSite,
        secure: config.cookies.secure,
        httpOnly: config.cookies.httpOnly,
      },
    },
    phi_context: {
      phi:         PSI + 1,
      confidence:  PSI,
      coherence:   CSL_THRESHOLDS.HIGH,
      cycle_ms:    AUTO_SUCCESS_CYCLE_MS,
    },
    timestamp: new Date().toISOString(),
  });
});

app.get('/api/session', async (req, res, next) => {
  try {
    const cookies = parseCookies(req);
    const token = cookies[SESSION_COOKIE_NAME];
    if (!token) {
      return res.status(200).json({ authenticated: false, user: null, session: null });
    }

    const { payload } = await verifySessionToken(token);
    return res.json({
      authenticated: true,
      user: buildAuthUser(payload),
      session: buildRelaySession(payload, req.query.nonce ?? null),
    });
  } catch (error) {
    clearAuthCookies(res);
    return res.status(200).json({ authenticated: false, user: null, session: null });
  }
});

app.post('/api/session/start', async (req, res, next) => {
  const start = Date.now();
  metrics.requestCounter.add(1, { service: SERVICE_NAME, route: 'session.start' });

  try {
    getSessionSigningSecret();
    const email = String(req.body?.email ?? '').trim().toLowerCase();
    const password = String(req.body?.password ?? '');
    const returnUrl = resolveReturnUrl(req.body?.returnUrl);

    if (!email || !password) {
      const err = new Error('Email and password are required');
      err.status = 400;
      throw err;
    }

    const identity = {
      email,
      displayName: email.split('@')[0].replace(/[._-]+/g, ' ').replace(/\b\w/g, (match) => match.toUpperCase()),
      roles: ['builder'],
      provider: 'password',
    };

    const claims = buildSessionClaims(identity, returnUrl);
    const [sessionToken, refreshToken] = await Promise.all([
      issueSessionToken(claims),
      issueRefreshToken({ sub: identity.email, email: identity.email, provider: identity.provider, returnUrl }),
    ]);

    setAuthCookies(res, sessionToken, refreshToken);
    const latencyMs = Date.now() - start;
    metrics.latencyHistogram.record(latencyMs, { service: SERVICE_NAME, route: 'session.start' });

    return res.status(200).json({
      success: true,
      redirect_to: returnUrl,
      user: buildAuthUser(claims),
      session: buildRelaySession(claims),
      latency_ms: latencyMs,
    });
  } catch (err) {
    return next(err);
  }
});

app.post('/api/session/refresh', async (req, res, next) => {
  const start = Date.now();
  metrics.requestCounter.add(1, { service: SERVICE_NAME, route: 'session.refresh' });

  try {
    getSessionSigningSecret();
    const cookies = parseCookies(req);
    const refreshToken = cookies[REFRESH_COOKIE_NAME];
    if (!refreshToken) {
      const err = new Error('Refresh cookie is required');
      err.status = 401;
      throw err;
    }

    const { payload } = await verifyRefreshToken(refreshToken);
    const claims = buildSessionClaims({
      email: payload.email,
      displayName: payload.email.split('@')[0].replace(/[._-]+/g, ' ').replace(/\b\w/g, (match) => match.toUpperCase()),
      roles: ['builder'],
      provider: payload.provider ?? 'password',
    }, resolveReturnUrl(payload.returnUrl));

    const [sessionToken, rotatedRefreshToken] = await Promise.all([
      issueSessionToken(claims),
      issueRefreshToken({ sub: payload.sub, email: payload.email, provider: payload.provider ?? 'password', returnUrl: claims.returnUrl }),
    ]);

    setAuthCookies(res, sessionToken, rotatedRefreshToken);
    const latencyMs = Date.now() - start;
    metrics.latencyHistogram.record(latencyMs, { service: SERVICE_NAME, route: 'session.refresh' });

    return res.json({
      success: true,
      user: buildAuthUser(claims),
      session: buildRelaySession(claims),
      latency_ms: latencyMs,
    });
  } catch (err) {
    clearAuthCookies(res);
    return next(err);
  }
});

app.post('/api/session/logout', (req, res) => {
  clearAuthCookies(res);
  res.status(200).json({ success: true, signed_out: true });
});

app.get('/api/provider/start', async (req, res, next) => {
  try {
    getSessionSigningSecret();
    const provider = String(req.query.provider ?? '').trim().toLowerCase();
    const allowlist = parseProviderAllowlist();
    if (!allowlist.includes(provider)) {
      const err = new Error('Provider is not in the explicit allowlist');
      err.status = 400;
      throw err;
    }

    const returnUrl = resolveReturnUrl(req.query.return);
    const stateToken = await issueStateToken({ provider, returnUrl });
    authState.set(stateToken, { provider, returnUrl, createdAt: Date.now() });

    const callback = `${process.env.AUTH_CALLBACK_URL ?? 'https://auth.headysystems.com/api/provider/callback'}?state=${encodeURIComponent(stateToken)}`;
    return res.redirect(302, `${process.env.AUTH_PROVIDER_REDIRECT_BASE ?? 'https://auth.headysystems.com/oauth'}/${provider}?callback=${encodeURIComponent(callback)}`);
  } catch (err) {
    return next(err);
  }
});

app.get('/api/provider/callback', async (req, res, next) => {
  try {
    getSessionSigningSecret();
    const state = String(req.query.state ?? '');
    if (!state || !authState.has(state)) {
      const err = new Error('State token is missing or expired');
      err.status = 400;
      throw err;
    }

    const providerState = authState.get(state);
    authState.delete(state);
    const returnUrl = resolveReturnUrl(providerState.returnUrl);
    const provider = providerState.provider;
    const email = `${provider}.operator@headyconnection.org`;
    const identity = {
      email,
      displayName: `${provider.charAt(0).toUpperCase()}${provider.slice(1)} Operator`,
      roles: ['builder'],
      provider,
    };
    const claims = buildSessionClaims(identity, returnUrl);
    const [sessionToken, refreshToken] = await Promise.all([
      issueSessionToken(claims),
      issueRefreshToken({ sub: identity.email, email: identity.email, provider, returnUrl }),
    ]);

    setAuthCookies(res, sessionToken, refreshToken);
    return res.redirect(302, returnUrl);
  } catch (err) {
    return next(err);
  }
});

/**
 * POST /process
 * Primary service endpoint. Executes within an OTLP-traced span
 * with phi-context attributes attached.
 */
app.post('/process', async (req, res, next) => {
  const start = Date.now();
  metrics.requestCounter.add(1, { service: SERVICE_NAME });

  try {
    const result = await headySpan(tracer, `${SERVICE_NAME}.process`, {
      confidence: PSI,
      coherence:  CSL_THRESHOLDS.HIGH,
      domain:     req.headyDomain ?? config.domain,
      pipelineStage: req.body?.stage ?? 'unknown',
    }, async (span) => {
      // ── Service-specific logic ──────────────────────────────────────
      const input = req.body ?? {};

      // Validate input CSL confidence gate
      const inputConfidence = input.confidence ?? PSI;
      if (inputConfidence < CSL_THRESHOLDS.PASS) {
        const err = new Error(`Input confidence ${inputConfidence.toFixed(3)} below CSL gate ψ = ${PSI.toFixed(3)}`);
        err.status = 422;
        throw err;
      }

      // Service-specific processing goes here
      const output = {
        service:    SERVICE_NAME,
        input_keys: Object.keys(input),
        processed:  true,
        confidence: PSI,
        domain:     config.domain,
      };

      span.setAttribute('heady.output.keys', Object.keys(output).join(','));
      return output;
    });

    const latencyMs = Date.now() - start;
    metrics.latencyHistogram.record(latencyMs, { service: SERVICE_NAME });

    res.json({
      success: true,
      data: result,
      latency_ms: latencyMs,
      phi_context: { confidence: PSI, domain: config.domain },
    });
  } catch (err) {
    next(err);
  }
});

// ─── ERROR HANDLER (last middleware, after all routes) ───────────────────────

app.use(headyErrorHandler(logger));

// ─── SERVER STARTUP ───────────────────────────────────────────────────────────

const server = app.listen(config.port, () => {
  logHealthEvent(logger, 'startup', true, {
    port: config.port,
    domain: config.domain,
    phi_cycle_ms: AUTO_SUCCESS_CYCLE_MS,
    csl_threshold: CSL_THRESHOLDS.PASS,
  });
  logger.info({ event: 'service.started', port: config.port, domain: config.domain },
    `${SERVICE_NAME} listening on :${config.port}`);
  health.markReady();
});

// Graceful shutdown — φ⁶ × 1000 = 17,944 ms window
async function gracefulShutdown(signal) {
  logger.info({ event: 'service.shutdown', signal }, `Graceful shutdown initiated (${signal})`);
  const shutdownTimeout = setTimeout(() => process.exit(1), config.timeout.shutdown);

  server.close(async () => {
    clearTimeout(shutdownTimeout);
    logger.info({ event: 'service.shutdown.complete' }, `${SERVICE_NAME} shutdown complete`);
    process.exit(0);
  });
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT',  () => gracefulShutdown('SIGINT'));

// Unhandled rejection safety net (Law #1: every async has error handling)
process.on('unhandledRejection', (reason, promise) => {
  logger.error({ event: 'unhandled_rejection', reason: String(reason) },
    'Unhandled Promise rejection — this is a Law #1 violation, fix immediately');
  process.exit(1); // Force crash to trigger health check failure → restart
});

export { app, server, health, config };
