import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const targets = [
  'packages/platform/src/config/index.js',
  'packages/platform/src/middleware/index.js',
  'packages/platform/src/otel/index.js',
  '.env.example',
  'packages/platform/envoy/envoy-bootstrap.yaml',
  'docker-compose.yml',
];

const dockerDir = path.join(root, 'services');
const badPatterns = [
  { re: /https?:\/\/localhost(?::\d+)?/i, label: 'localhost URL reference' },
  { re: /https?:\/\/127\.0\.0\.1(?::\d+)?/i, label: '127.0.0.1 URL reference' },
  { re: /address:\s*127\.0\.0\.1/i, label: '127.0.0.1 bind reference' },
  { re: /console\.log/, label: 'console.log' },
  { re: /localStorage/, label: 'localStorage token pattern' },
  { re: /Eric Head/, label: 'legacy founder name' },
  { re: /TODO|implement later|stub/i, label: 'placeholder text' },
  { re: /Access-Control-Allow-Origin\s*['"`]?\s*[:=]\s*['"`]\*/i, label: 'wildcard CORS policy' },
];

function scanFile(file) {
  const text = fs.readFileSync(file, 'utf8');
  for (const pattern of badPatterns) {
    if (pattern.re.test(text)) {
      throw new Error(`${pattern.label} found in ${path.relative(root, file)}`);
    }
  }
}

for (const rel of targets) {
  scanFile(path.join(root, rel));
}

const envExample = fs.readFileSync(path.join(root, '.env.example'), 'utf8');
for (const requiredVar of ['ALLOWED_ORIGINS=', 'CORS_ALLOW_METHODS=', 'CORS_ALLOW_HEADERS=', 'COOKIE_HTTP_ONLY=true', 'COOKIE_SECURE=true', 'COOKIE_SAMESITE=Strict']) {
  if (!envExample.includes(requiredVar)) {
    throw new Error(`missing required security env setting: ${requiredVar}`);
  }
}

const middlewareText = fs.readFileSync(path.join(root, 'packages', 'platform', 'src', 'middleware', 'index.js'), 'utf8');
for (const requiredToken of ['export function headyCors', 'origin_not_allowed', 'export function buildCookieHeader', 'SameSite']) {
  if (!middlewareText.includes(requiredToken)) {
    throw new Error(`missing required middleware security token: ${requiredToken}`);
  }
}

for (const service of fs.readdirSync(dockerDir)) {
  const dockerfile = path.join(dockerDir, service, 'Dockerfile');
  if (fs.existsSync(dockerfile)) scanFile(dockerfile);
}

const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
for (const required of ['dev', 'build', 'start', 'lint', 'compose:up', 'health:all']) {
  if (!pkg.scripts?.[required]) {
    throw new Error(`missing required root script: ${required}`);
  }
}

process.stdout.write('Compliance checks passed.\n');
