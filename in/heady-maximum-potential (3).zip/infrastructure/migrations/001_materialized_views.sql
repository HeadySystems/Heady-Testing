-- Migration 001: Materialized Views for CQRS Read Model
-- Eric Haywood — Sacred Geometry v4.0
-- Run by migration-service on startup

-- Domain statistics
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_domain_stats AS
SELECT domain,
       count(*) AS vector_count,
       avg(importance) AS avg_importance,
       max(updated_at) AS last_updated
FROM vector_memory
GROUP BY domain;

CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_domain_stats ON mv_domain_stats(domain);

-- Hot vectors (importance > PSI, frequently accessed)
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_hot_vectors AS
SELECT id, content, embedding, domain, importance, access_count
FROM vector_memory
WHERE importance > 0.618
  AND access_count > 5
ORDER BY importance DESC, access_count DESC
LIMIT 987;

CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_hot_vectors ON mv_hot_vectors(id);

-- Entity graph summary for Graph RAG
CREATE MATERIALIZED VIEW IF NOT EXISTS mv_entity_graph AS
SELECT e.id, e.name, e.entity_type,
       count(r.id) AS relationship_count,
       array_agg(DISTINCT r.rel_type) AS rel_types
FROM entities e
LEFT JOIN relationships r ON e.id = r.source_id OR e.id = r.target_id
GROUP BY e.id, e.name, e.entity_type;

CREATE UNIQUE INDEX IF NOT EXISTS idx_mv_entity_graph ON mv_entity_graph(id);

-- Track migration
INSERT INTO schema_migrations (version, checksum)
VALUES ('001_materialized_views', 'sha256:mv001')
ON CONFLICT (version) DO NOTHING;
