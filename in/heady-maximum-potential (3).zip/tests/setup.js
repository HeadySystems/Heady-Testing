'use strict';
/**
 * Jest Test Setup — Heady Production
 * Configures test environment with phi constants and structured logging.
 */

const PHI = 1.6180339887;
const PSI = 0.6180339887;

// Suppress stdout during tests unless VERBOSE=true
if (!process.env.VERBOSE) {
  const origWrite = process.stdout.write.bind(process.stdout);
  process.stdout.write = (chunk, encoding, callback) => {
    if (typeof chunk === 'string' && chunk.startsWith('{')) {
      // Suppress structured log output during tests
      if (callback) callback();
      return true;
    }
    return origWrite(chunk, encoding, callback);
  };
}

// Global test utilities
global.PHI = PHI;
global.PSI = PSI;
global.fib = (n) => {
  let a = 0, b = 1;
  for (let i = 0; i < n; i++) [a, b] = [b, a + b];
  return a;
};

// Test timeout (phi-derived)
jest.setTimeout(Math.round(PHI * 5000)); // ~8090ms
