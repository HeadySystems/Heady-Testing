# Contributing to Heady

Thank you for your interest in contributing to the Heady Sovereign AI Latent OS.

## Development Setup

1. Fork and clone the repository
2. Copy `.env.example` to `.env` in each service you're working on
3. Run `npm install` in the root and relevant service directories
4. Start infrastructure: `docker compose up -d postgres redis`

## Code Standards

### The 8 Unbreakable Laws

All contributions MUST comply with the 8 Unbreakable Laws. See `laws/` for details.

### Phi-Derived Constants

Every numeric constant must derive from φ (1.6180339887), ψ (0.6180339887), or Fibonacci.
Import from `shared/phi-math.js`:

```javascript
const { PHI, PSI, fib, phiThreshold, phiBackoff } = require('../../shared/phi-math');
```

### Structured Logging

Zero `console.log`. Use the structured logger:

```javascript
const log = (level, msg, meta = {}) =>
  process.stdout.write(JSON.stringify({ level, msg, ...meta, ts: new Date().toISOString() }) + '\n');
```

### Bee Development

New bees must extend `BaseHeadyBee` and implement the full lifecycle:
`spawn()` → `execute()` → `report()` → `retire()`

### Testing

- Unit tests: `tests/unit/`
- Integration tests: `tests/integration/`
- Load tests: `tests/load/` (k6)
- Chaos tests: `tests/chaos/`
- Contract tests: `tests/contract/` (Pact)

Run all: `npm test`

## Pull Request Process

1. Create a feature branch from `main`
2. Ensure all tests pass
3. Ensure ESLint passes with zero errors
4. Update relevant documentation
5. Submit PR with description of changes
6. PR must pass automated CI/CD checks
7. Review by at least one maintainer

## Commit Messages

Follow conventional commits:
- `feat(service-name): description`
- `fix(service-name): description`
- `docs: description`
- `refactor(module): description`
- `test(module): description`
