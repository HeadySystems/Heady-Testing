# Security Policy — Heady

## Supported Versions

| Version | Supported |
|---------|-----------|
| 4.x     | Current   |
| 3.x     | Security patches only |
| < 3.0   | Not supported |

## Reporting a Vulnerability

If you discover a security vulnerability, please report it responsibly:

1. **Email**: security@headysystems.com
2. **Do NOT** open a public GitHub issue for security vulnerabilities
3. Include:
   - Description of the vulnerability
   - Steps to reproduce
   - Potential impact
   - Suggested fix (if any)

We will acknowledge receipt within 48 hours and aim to provide a fix within 7 days for critical issues.

## Security Architecture

### Authentication
- **httpOnly cookies** for JWT tokens (LAW-07 — zero localStorage)
- OAuth 2.1 + OIDC via HeadyGuard
- WebAuthn/FIDO2 passwordless option
- Mutual TLS for inter-service communication

### Authorization
- RBAC with phi-weighted permission scores
- CSL-gated feature access (cosine similarity thresholds)
- Per-request governance validation

### Data Protection
- AES-256-GCM encryption at rest
- TLS 1.3 in transit
- Post-quantum cryptography readiness (CRYSTALS-Kyber, CRYSTALS-Dilithium)
- Secret rotation via HeadyGuard secret gateway

### Network Security
- Cloudflare WAF + DDoS protection on edge
- VPC network isolation on GCP
- Zero-trust inter-service authentication
- IP classification and geo-guarding

### Observability
- Structured JSON audit logging
- Cryptographic log integrity (Merkle tree receipts)
- Anomaly detection via semantic drift monitoring
- Real-time alerting via Prometheus + Alertmanager

## Dependency Management

- Automated Dependabot updates
- npm audit runs in CI pipeline
- License compliance scanning
- SBOM generation per release
