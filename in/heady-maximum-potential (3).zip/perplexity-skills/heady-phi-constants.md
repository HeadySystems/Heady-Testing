---
name: heady-phi-constants
description: Phi Constants Quick Reference for the Heady Latent OS
version: 1.0.0
---


# Heady Phi Constants Quick Reference

Use when working with any numeric values in the Heady system.

## Core Constants
- φ = 1.6180339887 (golden ratio)
- ψ = 0.6180339887 (1/φ)
- Golden angle = 137.508°

## CSL Thresholds
- MINIMUM = 0.500 (noise floor)
- LOW = 0.691 (weak alignment)
- MEDIUM = 0.809 (moderate)
- HIGH = 0.882 (strong)
- CRITICAL = 0.927 (near-certain)

## Timing (φⁿ × 1000ms)
- φ¹ = 1,618ms | φ² = 2,618ms | φ³ = 4,236ms
- φ⁴ = 6,854ms | φ⁵ = 11,090ms | φ⁶ = 17,944ms
- φ⁷ = 29,034ms (Auto-Success cycle) | φ⁸ = 46,979ms

## Fibonacci Reference
1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597

## Pool Allocation
Hot: 34% | Warm: 21% | Cold: 13% | Reserve: 8% | Governance: 5%

