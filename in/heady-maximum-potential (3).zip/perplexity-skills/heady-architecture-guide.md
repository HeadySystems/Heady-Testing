# Heady Architecture Quick Reference — Perplexity Skill

## System Overview
- 59 microservices on ports 3310-3368
- 9 websites across 6 domains
- 34+ HeadyBee agent types
- 21-stage HCFullPipeline
- 384D vector memory (pgvector + RAM-first)

## Infrastructure
- GCP Project: gen-lang-client-0920560496 (us-east1)
- Cloudflare Account: 8b1fa38f282c691423c6399247d53323
- 3 Colab Pro+ runtimes (A100/T4)
- PostgreSQL 16 + pgvector 0.7+
- Redis 7+

## Resource Pools (phi-derived)
- Hot: 34% (user-facing, latency-critical)
- Warm: 21% (background processing)
- Cold: 13% (batch analytics)
- Reserve: 8% (burst capacity)
- Governance: 5% (always-on compliance)

## CSL Thresholds
- CRITICAL: 0.927 (phiThreshold(4))
- HIGH: 0.882 (phiThreshold(3))
- MEDIUM: 0.809 (phiThreshold(2))
- LOW: 0.691 (phiThreshold(1))
- MINIMUM: 0.500 (phiThreshold(0))
