---
name: heady-production-ops
description: Production Operations for the Heady Latent OS
version: 1.0.0
---


# Heady Production Operations Skill

Use when deploying, monitoring, or troubleshooting the Heady production system.

## Quick Reference

### Boot Sequence
1. HeadyManager.boot() initializes all subsystems
2. Ed25519 receipt signer generates keys
3. MCP tools registered (5+ core tools)
4. Shutdown hooks registered (LIFO order)
5. Self-healing mesh starts
6. Auto-success engine starts (φ⁷ × 1000ms = 29,034ms cycle)
7. HTTP server starts on PORT env var

### Health Check
GET /health → Returns full system status

### MCP Endpoint
POST /mcp → JSON-RPC 2.0 for all MCP tools

### Key Metrics
- Bee factory utilization (target: <80%)
- Vector memory search latency (target: <100ms)
- Gateway provider health (all providers should be available)
- Pipeline state (should not be stuck in FAILED)

### Troubleshooting
1. Check /health endpoint first
2. If bees at capacity → scale Cloud Run instances
3. If gateway providers failing → check API keys in env
4. If memory searches slow → check pgvector HNSW index
5. If pipeline stuck → check stage handlers registration

