# Heady Debugging Guide — Perplexity Skill

## Common Issues

### Service won't start
1. Check .env exists (copy from .env.example)
2. Verify DATABASE_URL and REDIS_URL
3. Check port conflict: `lsof -i :PORT`
4. Review structured logs: `docker logs SERVICE_NAME | jq .`

### Vector memory issues
1. Verify pgvector extension: `SELECT * FROM pg_extension WHERE extname = 'vector';`
2. Check embedding dimensions: must be 384
3. Verify index: `SELECT * FROM pg_indexes WHERE indexname LIKE 'idx_vector%';`
4. Test cosine similarity: `SELECT 1 - (embedding <=> query_vec) AS similarity`

### CSL gate returning unexpected values
1. Verify input vectors are normalized (magnitude ~ 1.0)
2. Check threshold level (MINIMUM=0.500, LOW=0.691, MEDIUM=0.809)
3. Check temperature (default PHI_TEMPERATURE = 0.2361)
4. Verify gate formula: `value * sigmoid((cosScore - tau) / temp)`

### Health check failing
1. Every service must expose GET /health, GET /ready, GET /metrics
2. Check: `curl http://SERVICE_HOST:PORT/health`
3. Verify graceful shutdown handles SIGTERM/SIGINT
4. Check LIFO cleanup order in shutdown handler
