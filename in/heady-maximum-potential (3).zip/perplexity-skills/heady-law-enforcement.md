# Heady Law Enforcement Checklist — Perplexity Skill

## Pre-commit Checks

- [ ] LAW-01: All numeric constants derive from phi/psi/Fibonacci
- [ ] LAW-02: Zero console.log — structured JSON logging only
- [ ] LAW-03: /health, /ready, /metrics endpoints exist
- [ ] LAW-04: No TODOs, stubs, placeholders, empty catch blocks
- [ ] LAW-05: Zero localhost references in production code
- [ ] LAW-06: Architecture supports 10,000 concurrent bees
- [ ] LAW-07: Auth uses httpOnly cookies, zero localStorage
- [ ] LAW-08: Graceful shutdown with LIFO cleanup implemented

## Phi Reference
- φ = 1.6180339887
- ψ = 0.6180339887
- Fibonacci: 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597

## Quick Fixes
- console.log → `process.stdout.write(JSON.stringify({level, msg, ts}) + '\n')`
- localhost → `process.env.SERVICE_HOST || '0.0.0.0'`
- magic number 0.7 → `phiThreshold(1)` (≈ 0.691)
- timeout 5000 → `Math.round(PHI * 3000)` (≈ 4854)
- cache size 1000 → `fib(16)` (= 987)
