---
name: heady-swarm-reference
description: 17-Swarm Matrix Reference for the Heady Latent OS
version: 1.0.0
---


# Heady 17-Swarm Matrix Reference

Quick reference for the 17-swarm organizational matrix.

| # | Swarm | Key Agents |
|---|-------|-----------|
| 1 | Core Intelligence | HeadyCoder, HeadyBuddy, HeadyResearch |
| 2 | Orchestration | HeadyConductor, LiquidGateway, LLMRouter |
| 3 | Memory & Knowledge | HeadyMemory, HeadyEmbed, WisdomStore |
| 4 | Security & Trust | HeadyRisks, Ed25519Signer, PQCBee |
| 5 | Deployment & Ops | HeadyDeploy, HeadyOps, HeadyHealth |
| 6 | Creative | HeadyDolphin, LandingPageBuilder, CreativeBee |
| 7 | Trading Intelligence | HeadyTrader, ValuationAnalyzer |
| 8 | Infrastructure | CloudRunDeployer, SelfHealingMesh |
| 9 | Learning & Evolution | HeadyVinci, EvolutionEngine, MistakeAnalyzer |
| 10 | Communication | HeadyBuddy, PersonaRouter |
| 11 | Data Pipeline | GraphRAGBee, EmbedderBee |
| 12 | Quality & Compliance | ComplianceAuditor, PhiComplianceChecker |
| 13 | Cost Management | BudgetTracker, CostTrackerBee |
| 14 | Developer Tools | HeadyAI-IDE, HeadyIO |
| 15 | Bot & Automation | HeadyBot, AutoSuccessEngine |
| 16 | Community | HeadyConnection |
| 17 | Governance | GovernanceBee, JudgeBee |

