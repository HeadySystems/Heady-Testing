/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ PIPELINE ENGINE — 21-Stage HCFullPipeline v4.0.0        ║
 * ║  Cognitive processing pipeline with φ-scaled timeouts            ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import {
  PHI, PSI, fib, phiBackoff,
  CSL_THRESHOLDS, PHI_TIMING,
} from '../../shared/phi-math.js';
import { cslAND } from '../../shared/csl-engine.js';

// ─── STAGE DEFINITIONS ───────────────────────────────────────────────────────

/**
 * All 21 pipeline stages with φ-derived timeouts and CSL gate thresholds.
 * @type {Object[]}
 */
const STAGES = Object.freeze([
  { id: 0,  name: 'CHANNEL_ENTRY',     timeoutMs: PHI_TIMING.PHI_2,  gate: CSL_THRESHOLDS.MINIMUM,  desc: 'Multi-channel gateway, identity resolution' },
  { id: 1,  name: 'RECON',             timeoutMs: PHI_TIMING.PHI_4,  gate: CSL_THRESHOLDS.LOW,      desc: 'Deep scan, threat surface, context archaeology' },
  { id: 2,  name: 'INTAKE',            timeoutMs: PHI_TIMING.PHI_3,  gate: CSL_THRESHOLDS.LOW,      desc: 'Async semantic barrier, context retrieval, vector memory search' },
  { id: 3,  name: 'CLASSIFY',          timeoutMs: PHI_TIMING.PHI_2,  gate: CSL_THRESHOLDS.MEDIUM,   desc: 'CSL resonance gate, intent classification, risk scoring' },
  { id: 4,  name: 'TRIAGE',            timeoutMs: PHI_TIMING.PHI_2,  gate: CSL_THRESHOLDS.MEDIUM,   desc: 'Priority scoring, bee swarm assignment, resource estimation' },
  { id: 5,  name: 'DECOMPOSE',         timeoutMs: PHI_TIMING.PHI_4,  gate: CSL_THRESHOLDS.MEDIUM,   desc: 'Task DAG construction, dependency analysis, subtask CSL scoring' },
  { id: 6,  name: 'TRIAL_AND_ERROR',   timeoutMs: PHI_TIMING.PHI_6,  gate: CSL_THRESHOLDS.LOW,      desc: 'Sandboxed candidate execution, mutation testing' },
  { id: 7,  name: 'ORCHESTRATE',       timeoutMs: PHI_TIMING.PHI_4,  gate: CSL_THRESHOLDS.MEDIUM,   desc: 'Bee spawning, resource allocation, pool management' },
  { id: 8,  name: 'MONTE_CARLO',       timeoutMs: PHI_TIMING.PHI_6,  gate: CSL_THRESHOLDS.LOW,      desc: 'HeadySims risk simulation (34 passes minimum)' },
  { id: 9,  name: 'ARENA',             timeoutMs: PHI_TIMING.PHI_6,  gate: CSL_THRESHOLDS.MEDIUM,   desc: 'Multi-candidate competition (3-5 models)' },
  { id: 10, name: 'JUDGE',             timeoutMs: PHI_TIMING.PHI_3,  gate: CSL_THRESHOLDS.HIGH,     desc: 'Quantitative 5-factor scoring' },
  { id: 11, name: 'APPROVE',           timeoutMs: PHI_TIMING.PHI_7,  gate: CSL_THRESHOLDS.HIGH,     desc: 'Human-in-the-loop gate for HIGH/CRITICAL risk' },
  { id: 12, name: 'EXECUTE',           timeoutMs: PHI_TIMING.PHI_5,  gate: CSL_THRESHOLDS.HIGH,     desc: 'Metacognitive execution gate with rollback' },
  { id: 13, name: 'VERIFY',            timeoutMs: PHI_TIMING.PHI_4,  gate: CSL_THRESHOLDS.HIGH,     desc: 'Output validation, telemetry, regression check' },
  { id: 14, name: 'SELF_AWARENESS',    timeoutMs: PHI_TIMING.PHI_5,  gate: CSL_THRESHOLDS.MEDIUM,   desc: 'Metacognition: confidence, blind spots, biases' },
  { id: 15, name: 'SELF_CRITIQUE',     timeoutMs: PHI_TIMING.PHI_5,  gate: CSL_THRESHOLDS.MEDIUM,   desc: 'Performance review against standards' },
  { id: 16, name: 'MISTAKE_ANALYSIS',  timeoutMs: PHI_TIMING.PHI_5,  gate: CSL_THRESHOLDS.MEDIUM,   desc: 'Root cause analysis, prevention rules' },
  { id: 17, name: 'OPTIMIZATION_OPS',  timeoutMs: PHI_TIMING.PHI_6,  gate: CSL_THRESHOLDS.LOW,      desc: 'Parameter tuning, efficiency improvements' },
  { id: 18, name: 'CONTINUOUS_SEARCH', timeoutMs: PHI_TIMING.PHI_7,  gate: CSL_THRESHOLDS.LOW,      desc: 'Background research, knowledge expansion' },
  { id: 19, name: 'EVOLUTION',         timeoutMs: PHI_TIMING.PHI_7,  gate: CSL_THRESHOLDS.LOW,      desc: 'Controlled pipeline self-mutation, A/B testing' },
  { id: 20, name: 'RECEIPT',           timeoutMs: PHI_TIMING.PHI_2,  gate: CSL_THRESHOLDS.CRITICAL, desc: 'Ed25519 cryptographic audit receipt' },
]);

/** Pipeline variants with their stage sequences */
const VARIANTS = Object.freeze({
  FastPath:     [0, 1, 2, 7, 12, 13, 20],
  FullPath:     STAGES.map(s => s.id),
  ArenaPath:    [0, 1, 2, 3, 4, 8, 9, 10, 20],
  LearningPath: [0, 1, 16, 17, 18, 19, 20],
});

/** Pipeline states */
const STATE = Object.freeze({
  IDLE:       'IDLE',
  RUNNING:    'RUNNING',
  GATE_CHECK: 'GATE_CHECK',
  PAUSED:     'PAUSED',
  COMPLETE:   'COMPLETE',
  FAILED:     'FAILED',
});

// ─── PIPELINE ENGINE CLASS ───────────────────────────────────────────────────

/**
 * HCFullPipeline v4.0.0 — 21-stage cognitive pipeline engine.
 * Manages stage execution, gate checks, timeouts, and error recovery.
 */
export class PipelineEngine {
  /**
   * @param {Object} options
   * @param {Object} options.handlers - Map of stage name → handler function
   * @param {Object} [options.telemetry] - Telemetry emitter
   * @param {number} [options.maxRetries] - Max retries per stage (default: fib(5) = 5)
   */
  constructor({ handlers = {}, telemetry = null, maxRetries = fib(5) } = {}) {
    /** @private */ this._handlers = handlers;
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._maxRetries = maxRetries;
    /** @private */ this._state = STATE.IDLE;
    /** @private */ this._currentStage = null;
    /** @private */ this._context = {};
    /** @private */ this._stageResults = new Map();
    /** @private */ this._startTime = null;
    /** @private */ this._runId = null;
  }

  /** @returns {string} Current pipeline state */
  get state() { return this._state; }

  /** @returns {string|null} Current stage name */
  get currentStage() { return this._currentStage; }

  /**
   * Execute a pipeline variant.
   * @param {string} variantName - One of: FastPath, FullPath, ArenaPath, LearningPath
   * @param {Object} input - Pipeline input
   * @returns {Promise<Object>} Pipeline result with all stage outputs
   */
  async execute(variantName, input) {
    const stageIds = VARIANTS[variantName];
    if (!stageIds) {
      throw new Error(`Unknown pipeline variant: ${variantName}. Valid: ${Object.keys(VARIANTS).join(', ')}`);
    }

    this._runId = `hcfp_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
    this._state = STATE.RUNNING;
    this._startTime = Date.now();
    this._context = { input, runId: this._runId, variant: variantName };
    this._stageResults.clear();

    this._emit('pipeline.started', { runId: this._runId, variant: variantName, stages: stageIds.length });

    try {
      for (const stageId of stageIds) {
        const stageDef = STAGES[stageId];
        if (!stageDef) {
          throw new Error(`Stage ${stageId} not defined in pipeline`);
        }

        this._currentStage = stageDef.name;
        this._state = STATE.RUNNING;

        const result = await this._executeStage(stageDef);
        this._stageResults.set(stageDef.name, result);

        // Accumulate context for next stages
        this._context[stageDef.name] = result;

        // Gate check
        this._state = STATE.GATE_CHECK;
        const gatePass = this._checkGate(stageDef, result);
        if (!gatePass) {
          throw new Error(`Gate check failed at stage ${stageDef.name} (threshold: ${stageDef.gate})`);
        }
      }

      this._state = STATE.COMPLETE;
      const totalMs = Date.now() - this._startTime;

      this._emit('pipeline.completed', {
        runId: this._runId,
        variant: variantName,
        totalMs,
        stagesExecuted: stageIds.length,
      });

      return {
        runId: this._runId,
        variant: variantName,
        state: STATE.COMPLETE,
        totalMs,
        results: Object.fromEntries(this._stageResults),
      };
    } catch (err) {
      this._state = STATE.FAILED;
      this._emit('pipeline.failed', {
        runId: this._runId,
        stage: this._currentStage,
        error: err.message,
      });
      throw err;
    }
  }

  /**
   * Execute a single stage with retries and timeout.
   * @private
   * @param {Object} stageDef - Stage definition
   * @returns {Promise<Object>} Stage result
   */
  async _executeStage(stageDef) {
    const handler = this._handlers[stageDef.name];
    if (!handler) {
      // Default passthrough for unregistered stages
      return { stage: stageDef.name, status: 'passthrough', timestamp: Date.now() };
    }

    let lastError = null;

    for (let attempt = 0; attempt < this._maxRetries; attempt++) {
      try {
        const stageStart = Date.now();

        this._emit('stage.started', {
          stage: stageDef.name,
          stageId: stageDef.id,
          attempt,
          timeoutMs: stageDef.timeoutMs,
        });

        const result = await Promise.race([
          handler(this._context, stageDef),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Stage ${stageDef.name} timeout after ${stageDef.timeoutMs}ms`)), stageDef.timeoutMs)
          ),
        ]);

        const stageMs = Date.now() - stageStart;
        this._emit('stage.completed', {
          stage: stageDef.name,
          stageMs,
          attempt,
        });

        return {
          ...result,
          _meta: { stage: stageDef.name, stageMs, attempt, timestamp: Date.now() },
        };
      } catch (err) {
        lastError = err;
        this._emit('stage.retry', {
          stage: stageDef.name,
          attempt,
          error: err.message,
        });

        if (attempt < this._maxRetries - 1) {
          const backoffMs = phiBackoff(attempt);
          await new Promise(r => setTimeout(r, backoffMs));
        }
      }
    }

    throw new Error(`Stage ${stageDef.name} failed after ${this._maxRetries} attempts: ${lastError?.message}`);
  }

  /**
   * Check CSL gate threshold for a stage result.
   * @private
   */
  _checkGate(stageDef, result) {
    const confidence = result?.confidence ?? result?._meta?.confidence ?? 1.0;
    return confidence >= stageDef.gate;
  }

  /**
   * Emit telemetry event.
   * @private
   */
  _emit(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: 'PipelineEngine', ...data });
    }
  }
}

export { STAGES, VARIANTS, STATE };
export default PipelineEngine;
