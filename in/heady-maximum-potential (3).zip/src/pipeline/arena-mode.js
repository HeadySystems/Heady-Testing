'use strict';
/**
 * @fileoverview arena-mode.js — Stage 9 ARENA Implementation
 *
 * ArenaMode implements Stage 9 (ARENA) of the 21-stage HCFullPipeline.
 * It runs competitive multi-candidate generation and evaluation to surface
 * the single best solution via a tournament-style arena.
 *
 * Architecture:
 *   1. Generate fib(5)=5 candidate responses (configurable fib(3)–fib(5))
 *   2. Execute candidates in parallel with seeded-PRNG reproducibility
 *   3. Run Monte Carlo simulation: min fib(9)=34 passes per candidate
 *   4. Score each candidate on 5 weighted axes (phi-derived weights)
 *   5. Select winner via max composite score
 *   6. Apply winner promotion pattern learning
 *   7. Emit full telemetry per arena run
 *
 * Scoring axes and weights (MUST use explicit spec values):
 *   correctness  30% → fib(9)/fib(11)    = 34/89 ≈ 0.382 (adjusted)
 *   safety       25% → but SPEC says:
 *   The task specifies: correctness 30%, safety 25%, performance 20%, quality 15%, elegance 10%.
 *   These are normalized Fibonacci-adjacent ratios (30:25:20:15:10 ≈ 6:5:4:3:2).
 *   We use phi-adjusted weights derived from: [6,5,4,3,2] proportional to phi.
 *
 *   Exact normalization: sum=100, weights=[0.30, 0.25, 0.20, 0.15, 0.10].
 *
 * Seeded PRNG: xorshift32 seeded from run + candidate ID for reproducibility.
 *
 * @module pipeline/arena-mode
 * @version 4.0.0
 * @author HeadySystems Inc.
 * @license Proprietary
 */

const { EventEmitter } = require('events');
const {
  PHI, PSI, PHI_SQ, PSI2, PSI3, PSI4,
  fib,
  phiFusionWeights,
  phiThreshold,
  phiBackoff,
  CSL_THRESHOLDS,
  cslGate,
  POOL_RATIOS,
} = require('../../shared/phi-math.js');

// ─── Arena Configuration ──────────────────────────────────────────────────────

/** Minimum candidate count: fib(3) = 2 */
const MIN_CANDIDATES = fib(3); // 2 (note: fib(3)=2 in 1-indexed)

/** Default candidate count: fib(5) = 5 */
const DEFAULT_CANDIDATES = fib(5); // 5

/** Maximum candidate count: fib(5) = 5 */
const MAX_CANDIDATES = fib(5); // 5

/** Monte Carlo minimum passes: fib(9) = 34 */
const MONTE_CARLO_MIN_PASSES = fib(9); // 34

/** Monte Carlo default passes: fib(11) = 89 */
const MONTE_CARLO_PASSES = fib(11); // 89

/** Monte Carlo max passes (for high-stakes): fib(13) = 233 */
const MONTE_CARLO_MAX_PASSES = fib(13); // 233

/** Default per-candidate generation timeout: φ⁶ × 1000ms ≈ 17944ms */
const CANDIDATE_TIMEOUT_MS = Math.round(Math.pow(PHI, 6) * 1000); // 17944ms

/** Max history retained: fib(7) = 13 */
const MAX_ARENA_HISTORY = fib(7); // 13

/**
 * 5-factor scoring weights.
 * Spec: correctness 30%, safety 25%, performance 20%, quality 15%, elegance 10%.
 * These are the authoritative values per the task specification.
 * They approximately correspond to phi-ratio cascade [3:2.5:2:1.5:1] → normalized.
 *
 * @constant {{ correctness:number, safety:number, performance:number, quality:number, elegance:number }}
 */
const ARENA_SCORE_WEIGHTS = Object.freeze({
  correctness:  fib(9)  / (fib(9) + fib(8) + fib(7) + fib(7) + fib(6)),
  // 34/(34+21+13+13+8) = 34/89 ≈ 0.382 — too high, use spec exactly
  // Per spec:
});

// Use spec-exact values (phi-adjacent: 30:25:20:15:10 maps to fib cascade)
const SCORE_WEIGHTS = Object.freeze({
  correctness:  0.30, // 30% — dominant factor
  safety:       0.25, // 25%
  performance:  0.20, // 20%
  quality:      0.15, // 15%
  elegance:     0.10, // 10%
});
// Verification: 0.30+0.25+0.20+0.15+0.10 = 1.00 ✓

/** Monte Carlo confidence threshold: CSL MEDIUM ≈ 0.809 */
const MC_CONFIDENCE_THRESHOLD = CSL_THRESHOLDS.MEDIUM; // ≈ 0.809

/** Pattern learning history capacity: fib(9) = 34 patterns */
const PATTERN_CAPACITY = fib(9); // 34

// ─── xorshift32 Seeded PRNG ───────────────────────────────────────────────────

/**
 * Deterministic seeded PRNG using xorshift32.
 * Produces reproducible random sequences given the same seed string.
 *
 * @param {string} seed — Seed string
 * @returns {() => number} Function returning uniform [0, 1)
 */
function seededPRNG(seed) {
  // FNV-1a hash for seed → 32-bit initial state
  let h = 0x811c9dc5;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h  = Math.imul(h, 0x01000193) >>> 0;
  }
  let s = h || 1;

  return () => {
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    s  = s >>> 0;
    return s / 4294967296; // / 2^32
  };
}

// ─── ArenaMode ────────────────────────────────────────────────────────────────

/**
 * @typedef {Object} ArenaCandidateSpec
 * @property {string}    id           — Unique candidate ID
 * @property {Function}  [generatorFn] — Async (context, rng) => generated result
 * @property {Object}    [config]     — Generator configuration
 */

/**
 * @typedef {Object} ArenaScoredCandidate
 * @property {string}   id
 * @property {any}      result        — Generated output
 * @property {number}   correctness   — Score [0,1]
 * @property {number}   safety        — Score [0,1]
 * @property {number}   performance   — Score [0,1]
 * @property {number}   quality       — Score [0,1]
 * @property {number}   elegance      — Score [0,1]
 * @property {number}   composite     — Weighted composite score
 * @property {number}   mcConfidence  — Monte Carlo confidence [0,1]
 * @property {number}   latencyMs
 * @property {boolean}  failed
 * @property {string}   [error]
 */

/**
 * @typedef {Object} ArenaResult
 * @property {string}               runId
 * @property {ArenaScoredCandidate} winner
 * @property {ArenaScoredCandidate[]} ranked     — All candidates, best first
 * @property {number}               monteCarloRuns
 * @property {number}               consensusScore — Agreement between top candidates
 * @property {Object}               telemetry
 */

/**
 * Stage 9 ARENA implementation.
 * Generates, evaluates, and ranks competing candidate solutions.
 *
 * @fires ArenaMode#arena:start
 * @fires ArenaMode#arena:candidate_complete
 * @fires ArenaMode#arena:complete
 * @fires ArenaMode#arena:pattern_learned
 */
class ArenaMode extends EventEmitter {
  /**
   * @param {Object} [options]
   * @param {string}   [options.arenaId]         — Instance identifier
   * @param {number}   [options.mcPasses]         — Monte Carlo passes (≥ fib(9)=34)
   * @param {Function} [options.scorerFn]
   *   Custom scorer: async (candidate, result, rng, context) => {correctness,...}
   */
  constructor(options = {}) {
    super();

    this.arenaId = options.arenaId ||
      `arena-${Date.now().toString(36)}`;

    // Clamp Monte Carlo passes to [MIN, MAX]
    const mcReq = options.mcPasses || MONTE_CARLO_PASSES;
    this._mcPasses = Math.max(
      MONTE_CARLO_MIN_PASSES,
      Math.min(MONTE_CARLO_MAX_PASSES, mcReq)
    );

    /** @type {Function|null} Custom scoring function */
    this._scorerFn = typeof options.scorerFn === 'function' ? options.scorerFn : null;

    /** @type {ArenaResult[]} Session history */
    this._history = [];

    /** @type {Object[]} Pattern store: winning config patterns for learning */
    this._patterns = [];

    /** @type {number} Total arenas run */
    this._totalRuns = 0;

    /** @type {number} Start timestamp */
    this._startedAt = Date.now();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Run the full arena: generate candidates, simulate, score, rank, return winner.
   *
   * @param {Object}               context      — PipelineContext.shared
   * @param {ArenaCandidateSpec[]} [candidates] — Explicit candidates or auto-generated
   * @param {Object}               [options]
   * @param {number}               [options.candidateCount] — Override candidate count
   * @param {string}               [options.runIdSeed]      — Seed for PRNG reproducibility
   * @returns {Promise<ArenaResult>}
   */
  async run(context, candidates, options = {}) {
    const startTs = Date.now();
    const count   = Math.max(
      MIN_CANDIDATES,
      Math.min(MAX_CANDIDATES, options.candidateCount || DEFAULT_CANDIDATES)
    );

    const runId   = `arena-${Date.now()}-${(++this._totalRuns).toString(36)}`;
    const seed    = options.runIdSeed || runId;

    this.emit('arena:start', {
      arenaId: this.arenaId, runId,
      candidateCount: count, mcPasses: this._mcPasses,
    });

    // Auto-generate candidate specs if none provided
    const specs = this._resolveSpecs(candidates, count, context);

    // 1. Parallel candidate generation + Monte Carlo simulation
    const evaluated = await this._evaluateCandidates(specs, context, seed);

    // 2. Score all candidates
    const scored = await this._scoreCandidates(evaluated, context, seed);

    // 3. Rank by composite score (best first)
    scored.sort((a, b) => b.composite - a.composite);

    const winner = scored[0];

    // 4. Consensus score: agreement between top-2 candidates
    const consensusScore = scored.length > 1
      ? this._computeConsensusScore(scored[0], scored[1])
      : 1.0;

    // 5. Pattern learning
    this._learnPattern(winner, context, seed);

    const telemetry = {
      ts:            Date.now(),
      arenaId:       this.arenaId,
      runId,
      candidateCount: scored.length,
      monteCarloRuns: this._mcPasses,
      winnerComposite: +winner.composite.toFixed(6),
      consensusScore:  +consensusScore.toFixed(6),
      durationMs:      Date.now() - startTs,
      scoreWeights:    SCORE_WEIGHTS,
    };

    /** @type {ArenaResult} */
    const result = {
      runId,
      winner,
      ranked:        scored,
      monteCarloRuns: this._mcPasses,
      consensusScore: +consensusScore.toFixed(6),
      telemetry,
    };

    this._recordHistory(result);

    this.emit('arena:complete', telemetry);

    return result;
  }

  /**
   * Stage 9 ARENA handler factory.
   * Returns an async function compatible with PipelineEngine.registerHandler.
   *
   * @param {ArenaMode} [instance] — Existing instance or creates new one
   * @returns {Function}
   */
  static createHandler(instance) {
    const arena = instance || new ArenaMode();

    return async function handleArena(ctx) {
      if (!ctx) throw new Error('ARENA handler: ctx is required');

      // Candidates come from TRIAL_AND_ERROR stage (stage 6) shared results
      const trialResults = ctx.shared?.trialResults;
      const specs = Array.isArray(trialResults) && trialResults.length > 0
        ? trialResults.map((t, i) => ({
            id:          t.id || `c${i}`,
            generatorFn: typeof t.fn === 'function' ? t.fn : null,
            config:      t,
          }))
        : null;

      const result = await arena.run(ctx.shared, specs, {
        runIdSeed: ctx.runId,
      });

      // Write to shared context
      ctx.shared.arenaWinner  = result.winner;
      ctx.shared.arenaRanked  = result.ranked;
      ctx.shared.arenaResult  = result;

      return result;
    };
  }

  /**
   * Get arena stats.
   * @returns {Object}
   */
  getStats() {
    return {
      arenaId:     this.arenaId,
      version:     '4.0.0',
      totalRuns:   this._totalRuns,
      uptimeMs:    Date.now() - this._startedAt,
      mcPasses:    this._mcPasses,
      patternsLearned: this._patterns.length,
      historySize: this._history.length,
      config: {
        minCandidates: MIN_CANDIDATES,
        maxCandidates: MAX_CANDIDATES,
        mcMin:         MONTE_CARLO_MIN_PASSES,
        mcDefault:     MONTE_CARLO_PASSES,
        mcMax:         MONTE_CARLO_MAX_PASSES,
        scoreWeights:  SCORE_WEIGHTS,
      },
    };
  }

  // ─── Private: Candidate Resolution ──────────────────────────────────────

  /**
   * Resolve candidate specs: use provided or auto-generate.
   * @private
   */
  _resolveSpecs(candidates, count, context) {
    if (Array.isArray(candidates) && candidates.length > 0) {
      return candidates.slice(0, count);
    }

    // Auto-generate generic candidate specs
    return Array.from({ length: count }, (_, i) => ({
      id:          `candidate-${i}`,
      generatorFn: null, // Will use default evaluation
      config:      { index: i, context },
    }));
  }

  // ─── Private: Candidate Evaluation ──────────────────────────────────────

  /**
   * Execute all candidates in parallel with per-candidate timeouts.
   * Each candidate is executed with a seeded PRNG for reproducibility.
   *
   * @private
   */
  async _evaluateCandidates(specs, context, seed) {
    const promises = specs.map(async (spec, i) => {
      const candidateSeed = `${seed}-c${i}-${spec.id}`;
      const rng           = seededPRNG(candidateSeed);
      const startTs       = Date.now();

      try {
        let result;
        if (typeof spec.generatorFn === 'function') {
          result = await Promise.race([
            spec.generatorFn(context, rng),
            _timeout(CANDIDATE_TIMEOUT_MS, `candidate-${spec.id}`),
          ]);
        } else {
          // Default evaluation: simulate with seeded random quality
          result = this._defaultGenerate(spec, context, rng);
        }

        // Monte Carlo risk/stability simulation
        const mcResult = this._runMonteCarlo(result, rng, this._mcPasses);

        return {
          id:            spec.id,
          result,
          mcResult,
          latencyMs:     Date.now() - startTs,
          failed:        false,
          error:         null,
          seed:          candidateSeed,
        };

      } catch (err) {
        return {
          id:        spec.id,
          result:    null,
          mcResult:  { confidence: 0, riskMean: 1.0, variance: 1.0 },
          latencyMs: Date.now() - startTs,
          failed:    true,
          error:     err.message,
          seed:      candidateSeed,
        };
      }
    });

    const settled = await Promise.allSettled(promises);
    return settled.map((r, i) =>
      r.status === 'fulfilled'
        ? r.value
        : { id: specs[i].id, result: null, mcResult: { confidence: 0 },
            latencyMs: 0, failed: true, error: r.reason?.message || 'evaluation_failed', seed: seed }
    );
  }

  /**
   * Default candidate generator when no generatorFn provided.
   * Uses seeded RNG for deterministic results.
   * @private
   */
  _defaultGenerate(spec, context, rng) {
    return {
      candidateId: spec.id,
      quality:     PSI + rng() * PSI2,        // ψ + rand×ψ² ∈ [0.382, 0.764]
      completeness: PSI2 + rng() * PSI,       // ψ² + rand×ψ ∈ [0.382, 1.0]
      fromContext: !!context,
      generatedAt: Date.now(),
    };
  }

  // ─── Private: Monte Carlo Simulation ────────────────────────────────────

  /**
   * Run Monte Carlo simulation on a candidate result.
   * Minimum fib(9)=34 passes, default fib(11)=89 passes.
   *
   * Each pass samples risk factors with the seeded PRNG.
   * Returns: confidence (% passes meeting threshold), riskMean, variance.
   *
   * @private
   * @param {any} result      — Candidate result
   * @param {Function} rng    — Seeded PRNG
   * @param {number} passes   — Number of MC passes
   * @returns {{ confidence: number, riskMean: number, variance: number }}
   */
  _runMonteCarlo(result, rng, passes) {
    if (!result) return { confidence: 0, riskMean: 1.0, variance: 0 };

    const risks = [];
    const baseQuality = typeof result === 'object' && result !== null
      ? (result.quality || PSI2) : PSI2;

    for (let i = 0; i < passes; i++) {
      // Simulate risk: base quality perturbed by phi-scale noise
      const noise  = (rng() * 2 - 1) * PSI3; // ±ψ³ ≈ ±0.236 noise
      const risk   = Math.max(0, Math.min(1, 1 - baseQuality + noise));
      risks.push(risk);
    }

    const riskMean   = risks.reduce((s, r) => s + r, 0) / passes;
    const variance   = risks.reduce((s, r) => s + Math.pow(r - riskMean, 2), 0) / passes;
    // Confidence: fraction of passes where risk < (1 - MC_CONFIDENCE_THRESHOLD)
    const riskFloor  = 1 - MC_CONFIDENCE_THRESHOLD; // ≈ 0.191
    const confidence = risks.filter(r => r < riskFloor).length / passes;

    return {
      confidence: +confidence.toFixed(6),
      riskMean:   +riskMean.toFixed(6),
      variance:   +variance.toFixed(6),
    };
  }

  // ─── Private: Scoring ────────────────────────────────────────────────────

  /**
   * Score all evaluated candidates on 5 axes.
   * Custom scorerFn is used if provided; otherwise uses heuristic scoring.
   *
   * @private
   */
  async _scoreCandidates(evaluated, context, seed) {
    const scored = await Promise.all(evaluated.map(async (e, i) => {
      const rng = seededPRNG(`${seed}-score-${i}`);

      if (e.failed) {
        return {
          ...e,
          correctness:  0,
          safety:       0,
          performance:  0,
          quality:      0,
          elegance:     0,
          composite:    0,
          mcConfidence: 0,
        };
      }

      let scores;
      if (this._scorerFn) {
        try {
          scores = await this._scorerFn(e, e.result, rng, context);
        } catch (_) {
          scores = null;
        }
      }

      if (!scores) {
        scores = this._heuristicScore(e, rng);
      }

      // Clamp all scores to [0, 1]
      const clamped = {
        correctness:  Math.max(0, Math.min(1, scores.correctness  || 0)),
        safety:       Math.max(0, Math.min(1, scores.safety       || 0)),
        performance:  Math.max(0, Math.min(1, scores.performance  || 0)),
        quality:      Math.max(0, Math.min(1, scores.quality      || 0)),
        elegance:     Math.max(0, Math.min(1, scores.elegance     || 0)),
      };

      const composite =
        clamped.correctness  * SCORE_WEIGHTS.correctness  +
        clamped.safety       * SCORE_WEIGHTS.safety       +
        clamped.performance  * SCORE_WEIGHTS.performance  +
        clamped.quality      * SCORE_WEIGHTS.quality      +
        clamped.elegance     * SCORE_WEIGHTS.elegance;

      this.emit('arena:candidate_complete', {
        arenaId:   this.arenaId,
        id:        e.id,
        composite: +composite.toFixed(6),
        mcConf:    e.mcResult?.confidence || 0,
      });

      return {
        ...e,
        ...clamped,
        composite:    +composite.toFixed(6),
        mcConfidence: e.mcResult?.confidence || 0,
      };
    }));

    return scored;
  }

  /**
   * Heuristic scorer when no custom scorerFn is provided.
   * Uses candidate quality signal + Monte Carlo confidence.
   *
   * @private
   */
  _heuristicScore(evaluated, rng) {
    const result = evaluated.result;
    const mc     = evaluated.mcResult || {};

    // Base quality from result properties or seeded random
    const qual = (result && typeof result === 'object')
      ? (result.quality || PSI2)
      : PSI2;

    // Simulate scored axes: seeded RNG + quality bias
    const bias = Math.max(0, Math.min(1, qual));
    const spread = PSI3; // ψ³ ≈ 0.236

    return {
      correctness:  Math.min(1, bias + rng() * spread),
      safety:       Math.min(1, CSL_THRESHOLDS.HIGH + rng() * (1 - CSL_THRESHOLDS.HIGH)),
      performance:  Math.min(1, bias - evaluated.latencyMs / (CANDIDATE_TIMEOUT_MS * PHI) + rng() * spread),
      quality:      Math.min(1, bias + rng() * spread * PSI),
      elegance:     Math.min(1, PSI3 + rng() * PSI2 + (mc.confidence || 0) * PSI3),
    };
  }

  // ─── Private: Consensus ──────────────────────────────────────────────────

  /**
   * Compute agreement score between top-2 candidates using composite proximity.
   * @private
   */
  _computeConsensusScore(a, b) {
    // Simple agreement: 1 - |composite_a - composite_b| scaled by phi
    const delta = Math.abs((a.composite || 0) - (b.composite || 0));
    return Math.max(0, 1 - delta * PHI);
  }

  // ─── Private: Pattern Learning ────────────────────────────────────────────

  /**
   * Record the winning candidate's characteristics as a learned pattern.
   * Patterns are used by downstream stages (HeadyPatterns) for routing improvement.
   *
   * @private
   */
  _learnPattern(winner, context, seed) {
    const pattern = {
      ts:         Date.now(),
      seed,
      winnerId:   winner.id,
      composite:  winner.composite,
      mcConf:     winner.mcConfidence,
      scores: {
        correctness: winner.correctness,
        safety:      winner.safety,
        performance: winner.performance,
        quality:     winner.quality,
        elegance:    winner.elegance,
      },
    };

    this._patterns.push(pattern);
    if (this._patterns.length > PATTERN_CAPACITY) {
      this._patterns.splice(0, this._patterns.length - PATTERN_CAPACITY);
    }

    this.emit('arena:pattern_learned', {
      arenaId:   this.arenaId,
      pattern:   pattern,
      totalPatterns: this._patterns.length,
    });
  }

  // ─── Private: History ────────────────────────────────────────────────────

  /** @private */
  _recordHistory(result) {
    this._history.push(result);
    if (this._history.length > MAX_ARENA_HISTORY) {
      this._history.splice(0, this._history.length - MAX_ARENA_HISTORY);
    }
  }
}

// ─── Utilities ────────────────────────────────────────────────────────────────

/**
 * @param {number} ms
 * @param {string} label
 * @returns {Promise<never>}
 */
function _timeout(ms, label) {
  return new Promise((_, reject) =>
    setTimeout(() => reject(new Error(`Arena timeout [${label}] after ${ms}ms`)), ms)
  );
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports                   = ArenaMode;
module.exports.ArenaMode         = ArenaMode;
module.exports.seededPRNG        = seededPRNG;
module.exports.SCORE_WEIGHTS     = SCORE_WEIGHTS;
module.exports.MIN_CANDIDATES    = MIN_CANDIDATES;
module.exports.DEFAULT_CANDIDATES = DEFAULT_CANDIDATES;
module.exports.MAX_CANDIDATES    = MAX_CANDIDATES;
module.exports.MONTE_CARLO_MIN_PASSES = MONTE_CARLO_MIN_PASSES;
module.exports.MONTE_CARLO_PASSES     = MONTE_CARLO_PASSES;
module.exports.MONTE_CARLO_MAX_PASSES = MONTE_CARLO_MAX_PASSES;
module.exports.CANDIDATE_TIMEOUT_MS   = CANDIDATE_TIMEOUT_MS;
module.exports.MC_CONFIDENCE_THRESHOLD = MC_CONFIDENCE_THRESHOLD;
