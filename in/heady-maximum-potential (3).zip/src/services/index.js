/**
 * Services Module — Service registry, discovery, and mesh communication
 * Heady Systems Inc. — Eric Haywood, Founder
 */
'use strict';

const { ServiceRegistry } = require('./service-registry');
const { MeshCircuitBreaker, PhiLoadBalancer, meshCall } = require('./service-mesh');

module.exports = {
  ServiceRegistry,
  MeshCircuitBreaker,
  PhiLoadBalancer,
  meshCall,
};
