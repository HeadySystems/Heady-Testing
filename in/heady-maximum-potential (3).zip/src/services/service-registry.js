/**
 * ServiceRegistry — Dynamic service registration with phi-scaled health tracking
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const PSI2 = PSI * PSI;
const PSI3 = PSI * PSI * PSI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

const CSL_THRESHOLDS = {
  MINIMUM:  1 - PSI2 * 1,
  LOW:      1 - Math.pow(PSI, 1) * 0.5,
  MEDIUM:   1 - Math.pow(PSI, 2) * 0.5,
  HIGH:     1 - Math.pow(PSI, 3) * 0.5,
  CRITICAL: 1 - Math.pow(PSI, 4) * 0.5,
};

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('service-registry');

class ServiceRegistry {
  constructor(options = {}) {
    this.services = new Map();
    this.healthCheckInterval = options.healthCheckInterval || FIB[8] * 1000; // 21s
    this.staleThreshold = options.staleThreshold || FIB[10] * 1000; // 55s
    this.maxServices = options.maxServices || FIB[16]; // 987
    this._healthTimer = null;
  }

  /**
   * Register a service instance
   */
  register(name, instance) {
    if (this.services.size >= this.maxServices) {
      logger.warn('Registry capacity reached', { max: this.maxServices, current: this.services.size });
      return false;
    }

    const entry = {
      name,
      host: instance.host,
      port: instance.port,
      domain: instance.domain || 'unknown',
      version: instance.version || '4.0.0',
      metadata: instance.metadata || {},
      status: 'healthy',
      registered_at: Date.now(),
      last_heartbeat: Date.now(),
      health_score: CSL_THRESHOLDS.HIGH,
      consecutive_failures: 0,
    };

    const key = `${name}:${instance.host}:${instance.port}`;
    this.services.set(key, entry);
    logger.info('Service registered', { name, host: instance.host, port: instance.port, total: this.services.size });
    return true;
  }

  /**
   * Deregister a service instance
   */
  deregister(name, host, port) {
    const key = `${name}:${host}:${port}`;
    const removed = this.services.delete(key);
    if (removed) {
      logger.info('Service deregistered', { name, host, port, remaining: this.services.size });
    }
    return removed;
  }

  /**
   * Record heartbeat from service
   */
  heartbeat(name, host, port) {
    const key = `${name}:${host}:${port}`;
    const entry = this.services.get(key);
    if (entry) {
      entry.last_heartbeat = Date.now();
      entry.status = 'healthy';
      entry.consecutive_failures = 0;
      entry.health_score = Math.min(CSL_THRESHOLDS.CRITICAL, entry.health_score + PSI3);
      return true;
    }
    return false;
  }

  /**
   * Discover healthy instances of a service
   */
  discover(name) {
    const instances = [];
    for (const [key, entry] of this.services) {
      if (entry.name === name && entry.status === 'healthy') {
        instances.push({ ...entry });
      }
    }
    return instances.sort((a, b) => b.health_score - a.health_score);
  }

  /**
   * Get all registered services
   */
  list() {
    const all = [];
    for (const [key, entry] of this.services) {
      all.push({ key, ...entry });
    }
    return all;
  }

  /**
   * Prune stale services
   */
  prune() {
    const now = Date.now();
    let pruned = 0;
    for (const [key, entry] of this.services) {
      if (now - entry.last_heartbeat > this.staleThreshold) {
        entry.consecutive_failures += 1;
        entry.health_score = Math.max(0, entry.health_score - PSI2);

        if (entry.consecutive_failures >= FIB[5]) { // 5 consecutive failures
          this.services.delete(key);
          pruned += 1;
          logger.warn('Stale service pruned', { name: entry.name, key, failures: entry.consecutive_failures });
        } else {
          entry.status = 'degraded';
          logger.warn('Service degraded', { name: entry.name, key, failures: entry.consecutive_failures });
        }
      }
    }
    return pruned;
  }

  /**
   * Start periodic health check
   */
  startHealthCheck() {
    this._healthTimer = setInterval(() => {
      const pruned = this.prune();
      if (pruned > 0) {
        logger.info('Health check completed', { pruned, remaining: this.services.size });
      }
    }, this.healthCheckInterval);
  }

  /**
   * Stop health check
   */
  stopHealthCheck() {
    if (this._healthTimer) {
      clearInterval(this._healthTimer);
      this._healthTimer = null;
    }
  }

  /**
   * Get registry statistics
   */
  stats() {
    let healthy = 0, degraded = 0, unhealthy = 0;
    for (const entry of this.services.values()) {
      if (entry.status === 'healthy') { healthy += 1; }
      else if (entry.status === 'degraded') { degraded += 1; }
      else { unhealthy += 1; }
    }
    return {
      total: this.services.size,
      healthy,
      degraded,
      unhealthy,
      capacity: this.maxServices,
      utilization: this.services.size / this.maxServices,
    };
  }
}

module.exports = { ServiceRegistry, CSL_THRESHOLDS, PHI, PSI, FIB };
