/**
 * ServiceMesh — Inter-service communication with circuit breaking and load balancing
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const http = require('http');

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const PSI2 = PSI * PSI;
const PSI3 = PSI * PSI * PSI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

const CSL_THRESHOLDS = {
  MINIMUM:  1 - PSI2 * 1,
  LOW:      1 - Math.pow(PSI, 1) * 0.5,
  MEDIUM:   1 - Math.pow(PSI, 2) * 0.5,
  HIGH:     1 - Math.pow(PSI, 3) * 0.5,
  CRITICAL: 1 - Math.pow(PSI, 4) * 0.5,
};

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('service-mesh');

/**
 * Circuit breaker for inter-service calls
 */
class MeshCircuitBreaker {
  constructor(target, options = {}) {
    this.target = target;
    this.state = 'CLOSED';
    this.failures = 0;
    this.threshold = options.threshold || FIB[7]; // 13
    this.resetMs = options.resetMs || Math.round(PHI * PHI * PHI * 1000); // 4236ms
    this.halfOpenMax = options.halfOpenMax || FIB[4]; // 5
    this.halfOpenCount = 0;
    this.lastFailure = 0;
  }

  canExecute() {
    if (this.state === 'CLOSED') { return true; }
    if (this.state === 'OPEN' && Date.now() - this.lastFailure > this.resetMs) {
      this.state = 'HALF_OPEN';
      this.halfOpenCount = 0;
      return true;
    }
    if (this.state === 'HALF_OPEN' && this.halfOpenCount < this.halfOpenMax) {
      this.halfOpenCount += 1;
      return true;
    }
    return false;
  }

  recordSuccess() {
    if (this.state === 'HALF_OPEN') {
      this.state = 'CLOSED';
      this.failures = 0;
      logger.info('Circuit closed', { target: this.target });
    }
    this.failures = Math.max(0, this.failures - 1);
  }

  recordFailure() {
    this.failures += 1;
    this.lastFailure = Date.now();
    if (this.failures >= this.threshold) {
      this.state = 'OPEN';
      logger.warn('Circuit opened', { target: this.target, failures: this.failures });
    }
  }
}

/**
 * Phi-weighted load balancer
 */
class PhiLoadBalancer {
  constructor() {
    this.endpoints = new Map();
  }

  addEndpoint(name, host, port, weight = PSI) {
    const key = `${host}:${port}`;
    this.endpoints.set(key, {
      name, host, port, weight,
      active_connections: 0,
      total_requests: 0,
      avg_latency_ms: 0,
    });
  }

  removeEndpoint(host, port) {
    this.endpoints.delete(`${host}:${port}`);
  }

  /**
   * Select endpoint using phi-weighted scoring
   */
  select() {
    let best = null;
    let bestScore = -Infinity;

    for (const ep of this.endpoints.values()) {
      // Phi-weighted score: lower connections + lower latency = higher score
      const connectionPenalty = ep.active_connections / (FIB[10] || 1);
      const latencyPenalty = ep.avg_latency_ms / (Math.round(PHI * PHI * 1000) || 1);
      const score = ep.weight * PHI - connectionPenalty * PSI - latencyPenalty * PSI2;

      if (score > bestScore) {
        bestScore = score;
        best = ep;
      }
    }

    return best;
  }
}

/**
 * Service-to-service HTTP call with retry, circuit breaking, timeout
 */
async function meshCall(target, options = {}) {
  const { host, port, path, method, body, timeoutMs } = options;
  const timeout = timeoutMs || Math.round(PHI * PHI * PHI * 1000); // 4236ms

  return new Promise((resolve, reject) => {
    const reqOptions = {
      hostname: host,
      port,
      path: path || '/',
      method: method || 'GET',
      headers: {
        'Content-Type': 'application/json',
        'X-Mesh-Source': target,
        'X-Request-Id': `mesh-${Date.now()}`,
      },
      timeout,
    };

    const req = http.request(reqOptions, (res) => {
      const chunks = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => {
        try {
          const data = JSON.parse(Buffer.concat(chunks).toString());
          resolve({ status: res.statusCode, data, latency_ms: Date.now() });
        } catch (err) {
          resolve({ status: res.statusCode, data: Buffer.concat(chunks).toString(), latency_ms: Date.now() });
        }
      });
    });

    req.on('timeout', () => {
      req.destroy();
      reject(new Error(`Mesh call timeout after ${timeout}ms`));
    });

    req.on('error', reject);

    if (body) {
      req.write(typeof body === 'string' ? body : JSON.stringify(body));
    }
    req.end();
  });
}

module.exports = {
  MeshCircuitBreaker,
  PhiLoadBalancer,
  meshCall,
  CSL_THRESHOLDS,
  PHI, PSI, FIB,
};
