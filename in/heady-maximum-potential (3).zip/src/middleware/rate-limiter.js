/**
 * RateLimiter — Phi-scaled sliding window rate limiting with token bucket
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('rate-limiter');

/**
 * Token bucket rate limiter with phi-scaled refill
 */
class TokenBucketLimiter {
  constructor(options = {}) {
    this.maxTokens = options.maxTokens || FIB[12];        // 144 tokens
    this.refillRate = options.refillRate || FIB[8];        // 21 tokens/second
    this.refillInterval = options.refillInterval || 1000;  // 1 second
    this.buckets = new Map();
    this.cleanupInterval = FIB[8] * 1000;                 // 21s
    this._cleanupTimer = setInterval(() => this.cleanup(), this.cleanupInterval);
  }

  /**
   * Consume tokens for a client
   */
  consume(clientId, tokens = 1) {
    const now = Date.now();
    let bucket = this.buckets.get(clientId);

    if (!bucket) {
      bucket = { tokens: this.maxTokens, lastRefill: now };
      this.buckets.set(clientId, bucket);
    }

    // Refill tokens based on elapsed time
    const elapsed = now - bucket.lastRefill;
    const refillTokens = Math.floor(elapsed / this.refillInterval) * this.refillRate;
    bucket.tokens = Math.min(this.maxTokens, bucket.tokens + refillTokens);
    bucket.lastRefill = now;

    // Check if enough tokens
    if (bucket.tokens >= tokens) {
      bucket.tokens -= tokens;
      return {
        allowed: true,
        remaining: bucket.tokens,
        limit: this.maxTokens,
        reset_ms: Math.ceil((this.maxTokens - bucket.tokens) / this.refillRate * this.refillInterval),
      };
    }

    const retryAfterMs = Math.ceil((tokens - bucket.tokens) / this.refillRate * this.refillInterval);
    logger.warn('Rate limit exceeded', { clientId, requested: tokens, available: bucket.tokens, retry_after_ms: retryAfterMs });

    return {
      allowed: false,
      remaining: bucket.tokens,
      limit: this.maxTokens,
      retry_after_ms: retryAfterMs,
    };
  }

  /**
   * Cleanup stale buckets (phi-scaled staleness)
   */
  cleanup() {
    const now = Date.now();
    const staleMs = FIB[10] * 1000; // 55s
    let cleaned = 0;
    for (const [clientId, bucket] of this.buckets) {
      if (now - bucket.lastRefill > staleMs) {
        this.buckets.delete(clientId);
        cleaned += 1;
      }
    }
    if (cleaned > 0) {
      logger.info('Cleaned stale rate limit buckets', { cleaned, remaining: this.buckets.size });
    }
  }

  /**
   * Get rate limiter stats
   */
  stats() {
    return {
      active_clients: this.buckets.size,
      max_tokens: this.maxTokens,
      refill_rate: this.refillRate,
    };
  }

  /**
   * Destroy the rate limiter
   */
  destroy() {
    if (this._cleanupTimer) {
      clearInterval(this._cleanupTimer);
      this._cleanupTimer = null;
    }
    this.buckets.clear();
  }
}

/**
 * Express/Connect-style middleware factory
 */
function rateLimiterMiddleware(options = {}) {
  const limiter = new TokenBucketLimiter(options);
  return function rateLimit(req, res, next) {
    const clientId = req.headers['x-client-id'] ||
                     req.headers['x-forwarded-for'] ||
                     req.connection?.remoteAddress ||
                     'unknown';
    const result = limiter.consume(clientId);

    res.setHeader('X-RateLimit-Limit', result.limit);
    res.setHeader('X-RateLimit-Remaining', result.remaining);

    if (!result.allowed) {
      res.setHeader('Retry-After', Math.ceil(result.retry_after_ms / 1000));
      res.writeHead(429, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        error: 'Rate limit exceeded',
        retry_after_ms: result.retry_after_ms,
        limit: result.limit,
      }));
      return;
    }

    if (typeof next === 'function') { next(); }
  };
}

module.exports = { TokenBucketLimiter, rateLimiterMiddleware, PHI, PSI, FIB };
