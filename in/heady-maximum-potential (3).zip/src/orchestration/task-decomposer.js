/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ TASK DECOMPOSER — Stage 5 DECOMPOSE                     ║
 * ║  DAG construction, topological sort, CSL-scored subtask routing  ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib, CSL_THRESHOLDS, phiFusionWeights } from '../../shared/phi-math.js';
import { cslAND, normalize } from '../../shared/csl-engine.js';

/** Maximum DAG depth before forced serialization */
const MAX_DAG_DEPTH = fib(8); // 21

/** Maximum subtask count per decomposition */
const MAX_SUBTASKS = fib(10); // 55

/**
 * Represents a subtask node in the task DAG.
 */
class SubtaskNode {
  /**
   * @param {Object} opts
   * @param {string} opts.id - Unique subtask ID
   * @param {string} opts.description - What this subtask does
   * @param {string[]} opts.dependencies - IDs of subtasks this depends on
   * @param {Float64Array} [opts.embedding] - Semantic embedding
   * @param {number} [opts.priority] - Phi-weighted priority (0-1)
   * @param {string} [opts.assignedSwarm] - Target swarm
   */
  constructor({ id, description, dependencies = [], embedding = null, priority = PSI, assignedSwarm = null }) {
    this.id = id;
    this.description = description;
    this.dependencies = dependencies;
    this.embedding = embedding;
    this.priority = priority;
    this.assignedSwarm = assignedSwarm;
    this.status = 'pending';   // pending → running → completed → failed
    this.result = null;
    this.startTime = null;
    this.endTime = null;
  }
}

/**
 * 17-Swarm capability embeddings for CSL scoring.
 * In production, these are loaded from vector memory.
 */
const SWARM_CAPABILITIES = [
  'core_intelligence', 'orchestration', 'memory_knowledge',
  'security_trust', 'deployment_ops', 'creative', 'trading_intelligence',
  'infrastructure', 'learning_evolution', 'communication',
  'data_pipeline', 'quality_compliance', 'cost_management',
  'developer_tools', 'bot_automation', 'community', 'governance',
];

/**
 * TaskDecomposer — breaks complex tasks into a DAG of subtasks
 * scored against 17-swarm capabilities via CSL cosine similarity.
 */
export class TaskDecomposer {
  /**
   * @param {Object} options
   * @param {Function} options.embedFn - Async function to embed text → Float64Array
   * @param {Object} [options.swarmEmbeddings] - Pre-computed swarm capability embeddings
   * @param {Object} [options.telemetry] - Telemetry emitter
   */
  constructor({ embedFn, swarmEmbeddings = null, telemetry = null }) {
    /** @private */ this._embedFn = embedFn;
    /** @private */ this._swarmEmbeddings = swarmEmbeddings || {};
    /** @private */ this._telemetry = telemetry;
  }

  /**
   * Decompose a task into a DAG of subtasks.
   * @param {Object} task
   * @param {string} task.description - Full task description
   * @param {Object} [task.context] - Pipeline context from previous stages
   * @returns {Promise<Object>} DAG with nodes, edges, execution plan
   */
  async decompose(task) {
    const startMs = Date.now();

    // Step 1: Generate subtasks (from LLM or rule-based)
    const subtasks = await this._generateSubtasks(task);

    if (subtasks.length > MAX_SUBTASKS) {
      subtasks.length = MAX_SUBTASKS;
    }

    // Step 2: Build dependency graph
    const graph = this._buildGraph(subtasks);

    // Step 3: Detect cycles
    if (this._hasCycle(graph)) {
      throw new Error('Cycle detected in task DAG — cannot decompose');
    }

    // Step 4: Topological sort
    const executionOrder = this._topologicalSort(graph);

    // Step 5: CSL-score subtasks against swarm capabilities
    await this._scoreAgainstSwarms(subtasks);

    // Step 6: Identify parallelizable groups
    const parallelGroups = this._findParallelGroups(subtasks, executionOrder);

    const result = {
      subtasks,
      executionOrder,
      parallelGroups,
      totalSubtasks: subtasks.length,
      maxParallelism: Math.max(...parallelGroups.map(g => g.length)),
      decompositionMs: Date.now() - startMs,
    };

    this._emit('task.decomposed', result);
    return result;
  }

  /**
   * Generate subtasks from a task description.
   * @private
   */
  async _generateSubtasks(task) {
    // In production, this calls an LLM to decompose the task.
    // Default: single-node passthrough.
    const subtasks = [
      new SubtaskNode({
        id: 'root',
        description: task.description,
        dependencies: [],
        priority: 1.0,
      }),
    ];

    // Embed each subtask
    for (const st of subtasks) {
      if (this._embedFn) {
        st.embedding = await this._embedFn(st.description);
      }
    }

    return subtasks;
  }

  /**
   * Build adjacency list from subtask dependencies.
   * @private
   */
  _buildGraph(subtasks) {
    const graph = new Map();
    const nodeMap = new Map();
    for (const st of subtasks) {
      nodeMap.set(st.id, st);
      graph.set(st.id, []);
    }
    for (const st of subtasks) {
      for (const dep of st.dependencies) {
        if (graph.has(dep)) {
          graph.get(dep).push(st.id);
        }
      }
    }
    return { adjacency: graph, nodes: nodeMap };
  }

  /**
   * Detect cycles using DFS with color marking.
   * @private
   * @returns {boolean} True if cycle exists
   */
  _hasCycle(graph) {
    const WHITE = 0, GRAY = 1, BLACK = 2;
    const color = new Map();
    for (const id of graph.adjacency.keys()) color.set(id, WHITE);

    const dfs = (nodeId) => {
      color.set(nodeId, GRAY);
      for (const neighbor of (graph.adjacency.get(nodeId) || [])) {
        if (color.get(neighbor) === GRAY) return true;
        if (color.get(neighbor) === WHITE && dfs(neighbor)) return true;
      }
      color.set(nodeId, BLACK);
      return false;
    };

    for (const id of graph.adjacency.keys()) {
      if (color.get(id) === WHITE && dfs(id)) return true;
    }
    return false;
  }

  /**
   * Topological sort using Kahn's algorithm.
   * @private
   * @returns {string[]} Execution order (subtask IDs)
   */
  _topologicalSort(graph) {
    const inDegree = new Map();
    for (const id of graph.adjacency.keys()) inDegree.set(id, 0);
    for (const [, neighbors] of graph.adjacency) {
      for (const n of neighbors) {
        inDegree.set(n, (inDegree.get(n) || 0) + 1);
      }
    }

    // Priority queue: phi-weighted priority scoring
    const queue = [];
    for (const [id, deg] of inDegree) {
      if (deg === 0) queue.push(id);
    }
    queue.sort((a, b) => {
      const pa = graph.nodes.get(a)?.priority ?? PSI;
      const pb = graph.nodes.get(b)?.priority ?? PSI;
      return pb - pa; // Higher priority first
    });

    const order = [];
    while (queue.length > 0) {
      const current = queue.shift();
      order.push(current);
      for (const neighbor of (graph.adjacency.get(current) || [])) {
        const newDeg = inDegree.get(neighbor) - 1;
        inDegree.set(neighbor, newDeg);
        if (newDeg === 0) {
          queue.push(neighbor);
          queue.sort((a, b) => {
            const pa = graph.nodes.get(a)?.priority ?? PSI;
            const pb = graph.nodes.get(b)?.priority ?? PSI;
            return pb - pa;
          });
        }
      }
    }

    if (order.length !== graph.adjacency.size) {
      throw new Error('Topological sort incomplete — likely cycle in DAG');
    }

    return order;
  }

  /**
   * Score subtasks against 17-swarm capabilities via CSL AND.
   * @private
   */
  async _scoreAgainstSwarms(subtasks) {
    for (const st of subtasks) {
      if (!st.embedding) continue;

      let bestSwarm = null;
      let bestScore = -1;

      for (const swarmName of SWARM_CAPABILITIES) {
        const swarmEmb = this._swarmEmbeddings[swarmName];
        if (!swarmEmb) continue;

        const score = cslAND(st.embedding, swarmEmb);
        if (score > bestScore) {
          bestScore = score;
          bestSwarm = swarmName;
        }
      }

      if (bestSwarm && bestScore >= CSL_THRESHOLDS.MINIMUM) {
        st.assignedSwarm = bestSwarm;
        st.swarmScore = bestScore;
      }
    }
  }

  /**
   * Find groups of subtasks that can execute in parallel.
   * @private
   */
  _findParallelGroups(subtasks, executionOrder) {
    const subtaskMap = new Map(subtasks.map(s => [s.id, s]));
    const groups = [];
    const completed = new Set();

    while (completed.size < executionOrder.length) {
      const group = [];
      for (const id of executionOrder) {
        if (completed.has(id)) continue;
        const st = subtaskMap.get(id);
        const depsComplete = st.dependencies.every(d => completed.has(d));
        if (depsComplete) group.push(id);
      }
      if (group.length === 0) break; // Deadlock safety
      for (const id of group) completed.add(id);
      groups.push(group);
    }

    return groups;
  }

  /** @private */
  _emit(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: 'TaskDecomposer', ...data });
    }
  }
}

export { SubtaskNode, MAX_DAG_DEPTH, MAX_SUBTASKS };
export default TaskDecomposer;
