/**
 * SagaCoordinator — Distributed saga with compensating transactions
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('saga-coordinator');

/**
 * Saga step definition
 */
class SagaStep {
  constructor(name, execute, compensate) {
    this.name = name;
    this.execute = execute;
    this.compensate = compensate;
    this.status = 'pending'; // pending | executing | completed | compensating | compensated | failed
    this.result = null;
    this.error = null;
    this.startedAt = null;
    this.completedAt = null;
  }
}

/**
 * Saga orchestrator with phi-scaled timeouts and retry
 */
class SagaCoordinator {
  constructor(options = {}) {
    this.sagaId = `saga-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
    this.steps = [];
    this.maxRetries = options.maxRetries || FIB[5]; // 5
    this.timeoutMs = options.timeoutMs || Math.round(PHI * PHI * PHI * PHI * 1000); // 6854ms per step
    this.status = 'pending';
    this.completedSteps = [];
  }

  /**
   * Add a step to the saga
   */
  addStep(name, executeFn, compensateFn) {
    this.steps.push(new SagaStep(name, executeFn, compensateFn));
    return this;
  }

  /**
   * Execute the saga forward
   */
  async execute(context = {}) {
    this.status = 'executing';
    logger.info('Saga started', { sagaId: this.sagaId, steps: this.steps.length });

    for (let i = 0; i < this.steps.length; i++) {
      const step = this.steps[i];
      step.status = 'executing';
      step.startedAt = Date.now();

      let success = false;
      let lastError = null;

      for (let attempt = 0; attempt < this.maxRetries; attempt++) {
        try {
          step.result = await Promise.race([
            step.execute(context, step.result),
            new Promise((_, reject) =>
              setTimeout(() => reject(new Error(`Step ${step.name} timed out after ${this.timeoutMs}ms`)), this.timeoutMs)
            ),
          ]);
          step.status = 'completed';
          step.completedAt = Date.now();
          this.completedSteps.push(step);
          success = true;
          logger.info('Saga step completed', { sagaId: this.sagaId, step: step.name, attempt: attempt + 1, duration_ms: step.completedAt - step.startedAt });
          break;
        } catch (err) {
          lastError = err;
          const backoffMs = Math.round(PHI * 1000 * Math.pow(PHI, attempt));
          logger.warn('Saga step failed, retrying', { sagaId: this.sagaId, step: step.name, attempt: attempt + 1, error: err.message, backoff_ms: backoffMs });
          await new Promise(resolve => setTimeout(resolve, Math.min(backoffMs, FIB[10] * 1000)));
        }
      }

      if (!success) {
        step.status = 'failed';
        step.error = lastError ? lastError.message : 'Unknown error';
        logger.error('Saga step failed permanently', { sagaId: this.sagaId, step: step.name, error: step.error });

        // Compensate completed steps in LIFO order
        await this._compensate(context);
        this.status = 'compensated';
        return { success: false, sagaId: this.sagaId, failedStep: step.name, error: step.error };
      }
    }

    this.status = 'completed';
    logger.info('Saga completed successfully', { sagaId: this.sagaId, steps: this.steps.length });
    return { success: true, sagaId: this.sagaId, steps: this.steps.length };
  }

  /**
   * Compensate completed steps in LIFO order
   */
  async _compensate(context) {
    logger.info('Starting saga compensation', { sagaId: this.sagaId, stepsToCompensate: this.completedSteps.length });

    for (let i = this.completedSteps.length - 1; i >= 0; i--) {
      const step = this.completedSteps[i];
      step.status = 'compensating';

      try {
        await step.compensate(context, step.result);
        step.status = 'compensated';
        logger.info('Step compensated', { sagaId: this.sagaId, step: step.name });
      } catch (err) {
        step.status = 'compensation-failed';
        logger.error('Compensation failed', { sagaId: this.sagaId, step: step.name, error: err.message });
      }
    }
  }

  /**
   * Get saga status
   */
  getStatus() {
    return {
      sagaId: this.sagaId,
      status: this.status,
      steps: this.steps.map(s => ({
        name: s.name,
        status: s.status,
        duration_ms: s.completedAt && s.startedAt ? s.completedAt - s.startedAt : null,
        error: s.error,
      })),
    };
  }
}

module.exports = { SagaCoordinator, SagaStep, PHI, PSI, FIB };
