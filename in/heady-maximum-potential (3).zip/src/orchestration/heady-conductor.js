/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ CONDUCTOR — Central Orchestration Authority              ║
 * ║  Routes tasks across 17-Swarm Matrix via CSL-gated decisions     ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import {
  PHI, PSI, fib, phiBackoff, phiThreshold,
  CSL_THRESHOLDS, POOL_PERCENT, FIBONACCI,
  AUTO_SUCCESS, PHI_TIMING,
} from '../../shared/phi-math.js';
import { cslAND, cslCONSENSUS, cslGATE } from '../../shared/csl-engine.js';
import { RINGS, getRingForNode } from '../../shared/sacred-geometry.js';

// ─── POOL CONFIGURATION ──────────────────────────────────────────────────────

/** @enum {string} Resource pool tiers */
const POOL = Object.freeze({
  HOT:        'hot',        // 34% — user-facing, latency-critical
  WARM:       'warm',       // 21% — background processing
  COLD:       'cold',       // 13% — batch, analytics, ingestion
  RESERVE:    'reserve',    // 8%  — burst capacity
  GOVERNANCE: 'governance', // 5%  — always-on oversight
});

/** Pool capacity allocations (Fibonacci percentages) */
const POOL_CAPACITY = Object.freeze({
  [POOL.HOT]:        { percent: 0.34, maxBees: Math.round(10000 * 0.34),  timeoutMs: PHI_TIMING.PHI_3 },
  [POOL.WARM]:       { percent: 0.21, maxBees: Math.round(10000 * 0.21),  timeoutMs: PHI_TIMING.PHI_5 },
  [POOL.COLD]:       { percent: 0.13, maxBees: Math.round(10000 * 0.13),  timeoutMs: PHI_TIMING.PHI_7 },
  [POOL.RESERVE]:    { percent: 0.08, maxBees: Math.round(10000 * 0.08),  timeoutMs: PHI_TIMING.PHI_6 },
  [POOL.GOVERNANCE]: { percent: 0.05, maxBees: Math.round(10000 * 0.05),  timeoutMs: PHI_TIMING.PHI_8 },
});

// ─── DOMAIN ROUTING TABLE ────────────────────────────────────────────────────

/**
 * Maps task domains to their primary nodes, fallback nodes, and pool assignments.
 * @type {Object<string, {primary: string[], fallback: string[], pool: string}>}
 */
const ROUTING_TABLE = Object.freeze({
  'code.generation':   { primary: ['JULES', 'BUILDER', 'HeadyCoder'],       fallback: ['ATLAS'],        pool: POOL.HOT },
  'code.review':       { primary: ['OBSERVER', 'HeadyAnalyze'],             fallback: ['PYTHIA'],       pool: POOL.HOT },
  'security.scan':     { primary: ['MURPHY', 'CIPHER', 'HeadyRisks'],      fallback: ['SENTINEL'],     pool: POOL.HOT },
  'architecture':      { primary: ['ATLAS', 'PYTHIA', 'HeadyVinci'],       fallback: ['HeadyBrains'],  pool: POOL.HOT },
  'research':          { primary: ['HeadyResearch', 'SOPHIA'],              fallback: ['HeadyBrains'],  pool: POOL.WARM },
  'documentation':     { primary: ['ATLAS', 'HeadyCodex'],                  fallback: ['BUILDER'],      pool: POOL.WARM },
  'creative':          { primary: ['MUSE', 'NOVA'],                         fallback: ['HeadyDolphin'], pool: POOL.WARM },
  'translation':       { primary: ['BRIDGE'],                               fallback: ['HeadyBrains'],  pool: POOL.WARM },
  'monitoring':        { primary: ['OBSERVER', 'LENS', 'SENTINEL'],         fallback: ['HeadyHealth'],  pool: POOL.WARM },
  'cleanup':           { primary: ['JANITOR', 'HeadyMaid'],                 fallback: ['HeadyOps'],     pool: POOL.COLD },
  'analytics':         { primary: ['HeadyPatterns', 'HeadyMC'],             fallback: ['HeadyVinci'],   pool: POOL.COLD },
  'maintenance':       { primary: ['HeadyMaintenance'],                     fallback: ['HeadyOps'],     pool: POOL.COLD },
  'governance':        { primary: ['HeadyCheck', 'HeadyAssure'],            fallback: ['HeadyAware'],   pool: POOL.GOVERNANCE },
  'trading':           { primary: ['HeadyTrader', 'ValuationAnalyzer'],     fallback: ['HeadyMC'],      pool: POOL.WARM },
  'deployment':        { primary: ['HeadyDeploy', 'CloudRunDeployer'],      fallback: ['HeadyOps'],     pool: POOL.HOT },
  'memory':            { primary: ['HeadyMemory', 'HeadyEmbed'],            fallback: ['WisdomStore'],  pool: POOL.HOT },
  'bot':               { primary: ['HeadyBot', 'AutoSuccessEngine'],        fallback: ['HeadyBuddy'],   pool: POOL.WARM },
});

/** Pipeline variant definitions */
const VARIANTS = Object.freeze({
  FAST_PATH:     { stages: [0,1,2,7,12,13,20],           name: 'FastPath' },
  FULL_PATH:     { stages: Array.from({length:21},(_,i)=>i), name: 'FullPath' },
  ARENA_PATH:    { stages: [0,1,2,3,4,8,9,10,20],        name: 'ArenaPath' },
  LEARNING_PATH: { stages: [0,1,16,17,18,19,20],         name: 'LearningPath' },
});

// ─── CONDUCTOR CLASS ─────────────────────────────────────────────────────────

/**
 * HeadyConductor — central orchestration authority.
 * Classifies tasks, selects pipeline variants, routes to nodes, manages pools.
 */
export class HeadyConductor {
  /**
   * @param {Object} options
   * @param {Object} options.soul - HeadySoul reference for values arbitration
   * @param {Object} options.brains - HeadyBrains for context assembly
   * @param {Object} options.vinci - HeadyVinci for session planning
   * @param {Object} [options.telemetry] - Telemetry emitter
   */
  constructor({ soul, brains, vinci, telemetry = null }) {
    /** @private */ this._soul = soul;
    /** @private */ this._brains = brains;
    /** @private */ this._vinci = vinci;
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._poolStats = new Map();
    /** @private */ this._taskHistory = [];
    /** @private */ this._maxHistory = fib(17); // 1597

    for (const pool of Object.values(POOL)) {
      this._poolStats.set(pool, { active: 0, completed: 0, failed: 0 });
    }
  }

  /**
   * Classify a task and determine routing.
   * @param {Object} task
   * @param {string} task.input - User input or trigger
   * @param {Float64Array} [task.embedding] - Pre-computed embedding
   * @param {string} [task.hint] - Domain hint from caller
   * @returns {Object} Classification result with domain, pool, variant, nodes
   */
  async classify(task) {
    const startMs = Date.now();

    // Step 1: Context assembly via HeadyBrains
    const context = await this._brains.assembleContext(task.input);

    // Step 2: Domain classification via CSL scoring
    let bestDomain = null;
    let bestScore = -1;

    if (task.embedding) {
      for (const [domain, route] of Object.entries(ROUTING_TABLE)) {
        const domainEmbedding = context.domainEmbeddings?.[domain];
        if (domainEmbedding) {
          const score = cslAND(task.embedding, domainEmbedding);
          if (score > bestScore) {
            bestScore = score;
            bestDomain = domain;
          }
        }
      }
    }

    // Fallback to hint or default
    if (!bestDomain || bestScore < CSL_THRESHOLDS.MINIMUM) {
      bestDomain = task.hint || 'code.generation';
      bestScore = CSL_THRESHOLDS.MINIMUM;
    }

    // Step 3: Risk assessment for variant selection
    const riskLevel = this._assessRisk(task, context);
    const variant = this._selectVariant(riskLevel, bestScore);

    // Step 4: Node selection from routing table
    const route = ROUTING_TABLE[bestDomain];
    const nodes = this._selectNodes(route, bestDomain);

    const result = {
      domain: bestDomain,
      confidence: bestScore,
      pool: route.pool,
      variant,
      nodes,
      riskLevel,
      classificationMs: Date.now() - startMs,
    };

    this._emitTelemetry('task.classified', result);
    return result;
  }

  /**
   * Route a classified task to the appropriate nodes for execution.
   * @param {Object} classification - Output from classify()
   * @param {Object} task - Original task
   * @returns {Promise<Object>} Execution result
   */
  async route(classification, task) {
    const { pool, nodes, variant } = classification;
    const poolConfig = POOL_CAPACITY[pool];
    const stats = this._poolStats.get(pool);

    // Check pool capacity
    if (stats.active >= poolConfig.maxBees) {
      // Try reserve pool
      const reserveStats = this._poolStats.get(POOL.RESERVE);
      if (reserveStats.active >= POOL_CAPACITY[POOL.RESERVE].maxBees) {
        throw new Error(`Pool ${pool} at capacity (${stats.active}/${poolConfig.maxBees}) and reserve exhausted`);
      }
      this._emitTelemetry('pool.overflow', { pool, redirectTo: POOL.RESERVE });
    }

    stats.active++;
    const startMs = Date.now();

    try {
      // Execute with timeout
      const result = await Promise.race([
        this._executeOnNodes(nodes, task, variant),
        this._createTimeout(poolConfig.timeoutMs, pool),
      ]);

      stats.completed++;
      const elapsedMs = Date.now() - startMs;

      this._recordHistory({
        domain: classification.domain,
        pool,
        variant: variant.name,
        elapsedMs,
        success: true,
      });

      this._emitTelemetry('task.completed', {
        domain: classification.domain,
        elapsedMs,
        pool,
      });

      return result;
    } catch (err) {
      stats.failed++;
      this._emitTelemetry('task.failed', {
        domain: classification.domain,
        error: err.message,
        pool,
      });
      throw err;
    } finally {
      stats.active--;
    }
  }

  /**
   * Full classify → route pipeline in one call.
   * @param {Object} task
   * @returns {Promise<Object>}
   */
  async dispatch(task) {
    const classification = await this.classify(task);

    // HeadySoul values check
    if (this._soul) {
      const soulApproval = await this._soul.validateTask(task, classification);
      if (!soulApproval.approved) {
        throw new Error(`HeadySoul rejected task: ${soulApproval.reason}`);
      }
    }

    return this.route(classification, task);
  }

  /**
   * Get current pool utilization stats.
   * @returns {Object} Pool stats keyed by pool name
   */
  getPoolStats() {
    const result = {};
    for (const [pool, stats] of this._poolStats) {
      const capacity = POOL_CAPACITY[pool];
      result[pool] = {
        ...stats,
        maxBees: capacity.maxBees,
        utilization: stats.active / capacity.maxBees,
      };
    }
    return result;
  }

  // ─── PRIVATE METHODS ───────────────────────────────────────────────────────

  /**
   * Assess risk level of a task.
   * @private
   */
  _assessRisk(task, context) {
    const factors = [
      context.isNovel ? 0.8 : 0.2,
      context.touchesProduction ? 0.9 : 0.1,
      context.hasExternalEffects ? 0.7 : 0.1,
      context.complexityScore || 0.5,
    ];
    const avg = factors.reduce((a, b) => a + b, 0) / factors.length;
    if (avg >= CSL_THRESHOLDS.HIGH) return 'CRITICAL';
    if (avg >= CSL_THRESHOLDS.MEDIUM) return 'HIGH';
    if (avg >= CSL_THRESHOLDS.LOW) return 'MEDIUM';
    return 'LOW';
  }

  /**
   * Select pipeline variant based on risk and confidence.
   * @private
   */
  _selectVariant(riskLevel, confidence) {
    if (riskLevel === 'CRITICAL' || riskLevel === 'HIGH') return VARIANTS.FULL_PATH;
    if (confidence >= CSL_THRESHOLDS.HIGH) return VARIANTS.FAST_PATH;
    if (riskLevel === 'MEDIUM') return VARIANTS.ARENA_PATH;
    return VARIANTS.FAST_PATH;
  }

  /**
   * Select nodes from route, preferring primary, falling back.
   * @private
   */
  _selectNodes(route, domain) {
    const available = route.primary.filter(n => this._isNodeHealthy(n));
    if (available.length > 0) return available;
    const fallback = route.fallback.filter(n => this._isNodeHealthy(n));
    if (fallback.length > 0) return fallback;
    return route.primary; // Return primary anyway, let execution handle failures
  }

  /**
   * Check if a node is healthy (simplified — real impl checks HeadyHealth).
   * @private
   */
  _isNodeHealthy(nodeName) {
    return true; // Overridden by HeadyHealth integration
  }

  /**
   * Execute task on selected nodes.
   * @private
   */
  async _executeOnNodes(nodes, task, variant) {
    // For FullPath/ArenaPath, first node is primary executor
    const primaryNode = nodes[0];
    return {
      executor: primaryNode,
      variant: variant.name,
      stages: variant.stages,
      timestamp: Date.now(),
    };
  }

  /**
   * Create a timeout promise.
   * @private
   */
  _createTimeout(ms, label) {
    return new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`Pool ${label} timeout after ${ms}ms`)), ms)
    );
  }

  /**
   * Record task in history ring buffer.
   * @private
   */
  _recordHistory(entry) {
    this._taskHistory.push({ ...entry, timestamp: Date.now() });
    if (this._taskHistory.length > this._maxHistory) {
      this._taskHistory.shift();
    }
  }

  /**
   * Emit telemetry event.
   * @private
   */
  _emitTelemetry(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: 'HeadyConductor', ...data });
    }
  }
}

export { POOL, POOL_CAPACITY, ROUTING_TABLE, VARIANTS };
export default HeadyConductor;
