'use strict';
/**
 * @fileoverview swarm-consensus.js — 17-Swarm Coordination Protocol
 *
 * SwarmConsensus implements the distributed coordination protocol for the
 * 17-swarm Heady matrix.  It handles:
 *
 *   1. CSL-weighted voting for multi-agent disagreements
 *   2. Quorum requirements derived from phi thresholds
 *   3. Conflict resolution via HeadySoul arbitration
 *   4. Convergence tracking with phi-harmonic scoring
 *   5. Vote collection with phi-backoff timeouts
 *   6. Telemetry emission per consensus session
 *
 * Quorum model:
 *   - Soft quorum:  cos ≥ CSL_THRESHOLDS.MEDIUM (≈ 0.809) → proceed
 *   - Hard quorum:  cos ≥ CSL_THRESHOLDS.HIGH   (≈ 0.882) → high confidence
 *   - Super quorum: cos ≥ CSL_THRESHOLDS.CRITICAL (≈ 0.927) → unanimous
 *
 * Convergence is tracked as a rolling Fibonacci-windowed average of CSL scores.
 *
 * @module orchestration/swarm-consensus
 * @version 4.0.0
 * @author HeadySystems Inc.
 * @license Proprietary
 */

const { EventEmitter } = require('events');
const {
  PHI, PSI, PHI_SQ, PSI2, PSI3, PSI4,
  fib,
  phiFusionWeights,
  phiThreshold,
  phiBackoff,
  phiBackoffWithJitter,
  CSL_THRESHOLDS,
  cslGate,
  cslBlend,
  adaptiveTemperature,
  cosineSimilarity,
  normalize,
  dot,
  magnitude,
  placeholderVector,
  VECTOR_DIMENSIONS,
  POOL_RATIOS,
} = require('../../shared/phi-math.js');

// ─── Constants ────────────────────────────────────────────────────────────────

/** Swarm count: 17 (prime adjacent to Fibonacci range) */
const SWARM_COUNT = 17;

/** Minimum swarms for a valid vote: fib(4) = 3 */
const MIN_VOTERS = fib(4); // 3

/**
 * Quorum thresholds via phi-harmonic levels.
 * soft:  MEDIUM ≈ 0.809 (majority, proceed)
 * hard:  HIGH   ≈ 0.882 (strong consensus)
 * super: CRITICAL ≈ 0.927 (near-unanimous)
 */
const QUORUM = Object.freeze({
  SOFT:  CSL_THRESHOLDS.MEDIUM,   // ≈ 0.809
  HARD:  CSL_THRESHOLDS.HIGH,     // ≈ 0.882
  SUPER: CSL_THRESHOLDS.CRITICAL, // ≈ 0.927
});

/** Vote weight floor — swarms below this threshold are disregarded: ψ² ≈ 0.382 */
const VOTE_WEIGHT_FLOOR = PSI2; // ≈ 0.382

/** Convergence history window: fib(9) = 34 rounds */
const CONVERGENCE_WINDOW = fib(9); // 34

/** Vote collection timeout base: φ³ × 1000ms ≈ 4236ms */
const VOTE_TIMEOUT_BASE_MS = Math.round(Math.pow(PHI, 3) * 1000); // 4236ms

/** Max vote collection timeout: fib(10) × 1000ms = 55000ms */
const VOTE_TIMEOUT_MAX_MS  = fib(10) * 1000; // 55000ms

/** Conflict CSL threshold — below DISAGREEMENT_THRESHOLD: ψ ≈ 0.618 */
const CONFLICT_THRESHOLD = CSL_THRESHOLDS.LOW; // ≈ 0.691

/** HeadySoul arbitration timeout: fib(9) × 1000ms = 34000ms */
const SOUL_ARBITRATION_TIMEOUT_MS = fib(9) * 1000; // 34000ms

/** Max retained consensus sessions: fib(8) = 21 */
const MAX_HISTORY = fib(8); // 21

// ─── Swarm Registry ──────────────────────────────────────────────────────────

/**
 * 17-swarm registry with phi-weighted trust scores and capability vectors.
 * Trust weights decay toward ψ² when swarm has no history.
 * @constant {Object[]}
 */
const SWARM_REGISTRY = Object.freeze(
  Array.from({ length: SWARM_COUNT }, (_, i) => ({
    id:          `swarm-${String(i).padStart(2, '0')}`,
    index:       i,
    // Phi-weighted initial trust (higher Fibonacci index = higher weight)
    trustWeight: i < fib(4) ? PHI        // swarms 0–2: highest trust
                : i < fib(5) ? PSI       // swarms 3–4
                : i < fib(6) ? PSI2      // swarms 5–7
                : PSI3,                  // swarms 8–16
    capabilityVec: placeholderVector(`swarm:${i}`, VECTOR_DIMENSIONS),
    voteHistory: [], // rolling vote correctness
  }))
);

// ─── Vote Struct ──────────────────────────────────────────────────────────────

/**
 * @typedef {Object} SwarmVote
 * @property {string}   swarmId       — Voting swarm identifier
 * @property {any}      position      — The swarm's stated position/answer
 * @property {number[]} embedding     — Vector embedding of the position
 * @property {number}   confidence    — Self-reported confidence [0, 1]
 * @property {number}   timestamp     — Vote submission time (ms)
 * @property {number}   weight        — Assigned vote weight (CSL-derived)
 */

/**
 * @typedef {Object} ConsensusResult
 * @property {string}   sessionId
 * @property {any}      winner          — Winning position
 * @property {string}   winnerSwarmId   — Swarm whose position won
 * @property {number}   consensusScore  — CSL-weighted agreement score [0,1]
 * @property {string}   quorumLevel     — 'SOFT' | 'HARD' | 'SUPER' | 'FAILED'
 * @property {boolean}  conflictDetected
 * @property {boolean}  arbitrated       — HeadySoul resolved a conflict
 * @property {number}   voterCount
 * @property {number}   convergenceTrend — Positive = improving consensus over time
 * @property {Object}   telemetry
 */

// ─── SwarmConsensus ──────────────────────────────────────────────────────────

/**
 * 17-swarm CSL-weighted consensus coordinator.
 *
 * @fires SwarmConsensus#consensus:start
 * @fires SwarmConsensus#consensus:complete
 * @fires SwarmConsensus#consensus:conflict
 * @fires SwarmConsensus#consensus:arbitration
 * @fires SwarmConsensus#vote:received
 * @fires SwarmConsensus#vote:timeout
 */
class SwarmConsensus extends EventEmitter {
  /**
   * @param {Object} [options]
   * @param {string} [options.consensusId]   — Instance identifier
   * @param {Function} [options.soulArbitratorFn]
   *   Async function for HeadySoul arbitration: (votes, context) => resolvedPosition
   */
  constructor(options = {}) {
    super();

    this.consensusId = options.consensusId ||
      `consensus-${Date.now().toString(36)}`;

    /** @type {Function|null} HeadySoul arbitration function */
    this._soulArbitratorFn = options.soulArbitratorFn || null;

    /** @type {ConsensusResult[]} Session history */
    this._history = [];

    /** @type {number[]} Rolling convergence scores */
    this._convergenceHistory = [];

    /** @type {number} Total sessions */
    this._totalSessions = 0;

    /** @type {number} Conflicts detected */
    this._conflictsDetected = 0;

    /** @type {number} Arbitrations invoked */
    this._arbitrations = 0;

    /** @type {number} Start time */
    this._startedAt = Date.now();

    // Build mutable trust weight table (starts from SWARM_REGISTRY values)
    /** @type {Map<string, number>} swarmId → current trust weight */
    this._trustWeights = new Map(
      SWARM_REGISTRY.map(s => [s.id, s.trustWeight])
    );
  }

  // ─── Public API ────────────────────────────────────────────────────────────

  /**
   * Conduct a consensus session over provided swarm votes.
   *
   * @param {SwarmVote[]} votes        — Votes from participating swarms
   * @param {Object}      [context]    — Optional context for arbitration
   * @param {Object}      [options]
   * @param {number}      [options.quorumTarget] — Minimum quorum: SOFT|HARD|SUPER
   * @param {boolean}     [options.forceArbitration] — Always invoke HeadySoul
   * @returns {Promise<ConsensusResult>}
   * @throws {Error} If insufficient voters or fatal arbitration failure
   */
  async conduct(votes, context = {}, options = {}) {
    if (!Array.isArray(votes)) {
      throw new TypeError('SwarmConsensus.conduct: votes must be an array');
    }
    if (votes.length < MIN_VOTERS) {
      throw new Error(
        `SwarmConsensus: quorum requires ≥ ${MIN_VOTERS} votes, got ${votes.length}`
      );
    }

    const sessionId = this._generateSessionId();
    const startTs   = Date.now();
    this._totalSessions++;

    this.emit('consensus:start', {
      sessionId, voterCount: votes.length,
      consensusId: this.consensusId,
    });

    // 1. Validate and sanitize votes
    const sanitized = this._sanitizeVotes(votes);

    // 2. Assign CSL-weighted vote weights
    const weighted = this._assignWeights(sanitized);

    // 3. Compute pairwise CSL agreement matrix
    const { matrix, conflictPairs } = this._computeAgreementMatrix(weighted);

    // 4. Detect conflicts
    const conflictDetected = conflictPairs.length > 0;
    if (conflictDetected) {
      this._conflictsDetected++;
      this.emit('consensus:conflict', {
        sessionId, conflictPairs, consensusId: this.consensusId,
      });
    }

    // 5. Compute consensus vector (CSL-weighted centroid)
    const { consensusVec, consensusScore } = this._computeConsensus(weighted, matrix);

    // 6. Determine quorum level
    const quorumLevel = this._quorumLevel(consensusScore);

    // 7. Arbitration: invoke HeadySoul if conflict or forced
    let arbitrated   = false;
    let winnerSwarmId;
    let winner;

    if ((conflictDetected || options.forceArbitration) && this._soulArbitratorFn) {
      try {
        const arbResult = await this._arbitrate(weighted, context, sessionId);
        winner         = arbResult.position;
        winnerSwarmId  = arbResult.swarmId;
        arbitrated     = true;
        this._arbitrations++;
      } catch (err) {
        this.emit('consensus:arbitration', {
          sessionId, result: 'failed', error: err.message, consensusId: this.consensusId,
        });
        // Fall through to standard winner selection
      }
    }

    // Standard winner: highest-weighted vote most aligned with consensus vector
    if (!winner) {
      const best = this._selectWinner(weighted, consensusVec);
      winner        = best.vote.position;
      winnerSwarmId = best.vote.swarmId;
    }

    // 8. Update trust weights based on outcome
    this._updateTrustWeights(weighted, winnerSwarmId);

    // 9. Track convergence
    this._convergenceHistory.push(consensusScore);
    if (this._convergenceHistory.length > CONVERGENCE_WINDOW) {
      this._convergenceHistory.splice(0, this._convergenceHistory.length - CONVERGENCE_WINDOW);
    }
    const convergenceTrend = this._computeConvergenceTrend();

    const telemetry = {
      ts:              Date.now(),
      sessionId,
      consensusId:     this.consensusId,
      voterCount:      weighted.length,
      consensusScore:  +consensusScore.toFixed(6),
      quorumLevel,
      conflictDetected,
      conflictPairs:   conflictPairs.length,
      arbitrated,
      convergenceTrend: +convergenceTrend.toFixed(4),
      durationMs:      Date.now() - startTs,
    };

    /** @type {ConsensusResult} */
    const result = {
      sessionId,
      winner,
      winnerSwarmId,
      consensusScore:  +consensusScore.toFixed(6),
      quorumLevel,
      conflictDetected,
      arbitrated,
      voterCount:      weighted.length,
      convergenceTrend,
      telemetry,
    };

    this._recordHistory(result);

    this.emit('consensus:complete', telemetry);

    return result;
  }

  /**
   * Collect votes from a set of swarm resolver functions with timeout.
   * Phi-backoff is applied if fewer than MIN_VOTERS respond.
   *
   * @param {string[]}           swarmIds   — IDs of swarms to poll
   * @param {Object}             question   — Question/task to present to each swarm
   * @param {Function}           resolverFn — Async (swarmId, question) => SwarmVote
   * @param {number}             [timeoutMs] — Vote collection timeout per swarm
   * @returns {Promise<SwarmVote[]>}
   */
  async collectVotes(swarmIds, question, resolverFn, timeoutMs = VOTE_TIMEOUT_BASE_MS) {
    if (typeof resolverFn !== 'function') {
      throw new TypeError('SwarmConsensus.collectVotes: resolverFn must be a function');
    }

    const votePromises = swarmIds.map(async swarmId => {
      try {
        const vote = await Promise.race([
          resolverFn(swarmId, question),
          new Promise((_, rej) =>
            setTimeout(() => rej(new Error(`Vote timeout: ${swarmId}`)), timeoutMs)
          ),
        ]);
        this.emit('vote:received', { swarmId, sessionId: this.consensusId });
        return vote;
      } catch (err) {
        this.emit('vote:timeout', { swarmId, error: err.message });
        return null;
      }
    });

    const settled = await Promise.allSettled(votePromises);
    const valid   = settled
      .filter(r => r.status === 'fulfilled' && r.value !== null)
      .map(r => r.value);

    // Retry with phi-backoff if below MIN_VOTERS
    if (valid.length < MIN_VOTERS) {
      for (let attempt = 0; attempt < fib(4); attempt++) {
        const delay = phiBackoffWithJitter(attempt, VOTE_TIMEOUT_BASE_MS, VOTE_TIMEOUT_MAX_MS);
        await _sleep(delay);
        // Re-poll timed-out swarms
        const missing = swarmIds.filter(
          id => !valid.some(v => v.swarmId === id)
        );
        for (const id of missing) {
          try {
            const vote = await Promise.race([
              resolverFn(id, question),
              new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), timeoutMs)),
            ]);
            if (vote) valid.push(vote);
            if (valid.length >= MIN_VOTERS) break;
          } catch (_) { /* silent retry */ }
        }
        if (valid.length >= MIN_VOTERS) break;
      }
    }

    return valid;
  }

  /**
   * Get consensus health statistics.
   * @returns {Object}
   */
  getStats() {
    const avgConvergence = this._convergenceHistory.length > 0
      ? this._convergenceHistory.reduce((s, x) => s + x, 0) / this._convergenceHistory.length
      : 0;

    return {
      consensusId:       this.consensusId,
      version:           '4.0.0',
      uptimeMs:          Date.now() - this._startedAt,
      totalSessions:     this._totalSessions,
      conflictsDetected: this._conflictsDetected,
      arbitrations:      this._arbitrations,
      avgConvergence:    +avgConvergence.toFixed(4),
      convergenceTrend:  +this._computeConvergenceTrend().toFixed(4),
      swarmCount:        SWARM_COUNT,
      minVoters:         MIN_VOTERS,
      quorum:            QUORUM,
      phi:               PHI,
      psi:               PSI,
      trustWeights:      Object.fromEntries(this._trustWeights),
    };
  }

  // ─── Private: Vote Sanitization ──────────────────────────────────────────

  /**
   * Validate votes and ensure required fields are present.
   * @private
   */
  _sanitizeVotes(votes) {
    return votes
      .filter(v => v && typeof v === 'object' && v.swarmId)
      .map(v => ({
        swarmId:    String(v.swarmId),
        position:   v.position !== undefined ? v.position : null,
        embedding:  Array.isArray(v.embedding) && v.embedding.length > 0
          ? v.embedding
          : placeholderVector(`vote:${v.swarmId}:${Date.now()}`, VECTOR_DIMENSIONS),
        confidence: typeof v.confidence === 'number'
          ? Math.max(0, Math.min(1, v.confidence)) : PSI2,
        timestamp:  typeof v.timestamp === 'number' ? v.timestamp : Date.now(),
        weight:     0, // computed in _assignWeights
      }));
  }

  // ─── Private: Weight Assignment ──────────────────────────────────────────

  /**
   * Assign CSL-weighted vote weights.
   * Weight = swarm trust × confidence, gated by VOTE_WEIGHT_FLOOR.
   *
   * @private
   */
  _assignWeights(votes) {
    return votes.map(v => {
      const trust     = this._trustWeights.get(v.swarmId) || PSI3;
      const rawWeight = trust * v.confidence;
      const gated     = cslGate(rawWeight, v.confidence, VOTE_WEIGHT_FLOOR, PSI3);
      return { ...v, weight: Math.max(VOTE_WEIGHT_FLOOR * PSI, gated) };
    });
  }

  // ─── Private: Agreement Matrix ────────────────────────────────────────────

  /**
   * Compute pairwise cosine similarity matrix between all vote embeddings.
   * Flag pairs below CONFLICT_THRESHOLD as conflicts.
   *
   * @private
   * @returns {{ matrix: number[][], conflictPairs: Array<{a,b,score}> }}
   */
  _computeAgreementMatrix(votes) {
    const n       = votes.length;
    const matrix  = Array.from({ length: n }, () => new Array(n).fill(0));
    const conflictPairs = [];

    for (let i = 0; i < n; i++) {
      matrix[i][i] = 1.0;
      for (let j = i + 1; j < n; j++) {
        const sim = cosineSimilarity(votes[i].embedding, votes[j].embedding);
        matrix[i][j] = sim;
        matrix[j][i] = sim;

        if (sim < CONFLICT_THRESHOLD) {
          conflictPairs.push({
            a:     votes[i].swarmId,
            b:     votes[j].swarmId,
            score: +sim.toFixed(6),
          });
        }
      }
    }

    return { matrix, conflictPairs };
  }

  // ─── Private: Consensus Computation ──────────────────────────────────────

  /**
   * Compute the CSL-weighted consensus vector and overall agreement score.
   * Consensus vector = Σ(weight_i × embedding_i) / ‖Σ(...)‖
   * Consensus score  = avg pairwise similarity weighted by product of weights.
   *
   * @private
   */
  _computeConsensus(votes, matrix) {
    const dim     = votes[0].embedding.length;
    const vec     = new Array(dim).fill(0);
    let   totalW  = 0;

    for (const v of votes) {
      for (let d = 0; d < dim; d++) {
        vec[d] += v.weight * v.embedding[d];
      }
      totalW += v.weight;
    }

    // Normalize consensus vector
    const mag = Math.sqrt(vec.reduce((s, x) => s + x * x, 0));
    const consensusVec = mag > 0 ? vec.map(x => x / mag) : vec;

    // Score: phi-weighted pairwise similarity average
    let weightedSim = 0;
    let weightSum   = 0;
    for (let i = 0; i < votes.length; i++) {
      for (let j = i + 1; j < votes.length; j++) {
        const pairW = votes[i].weight * votes[j].weight;
        weightedSim += pairW * matrix[i][j];
        weightSum   += pairW;
      }
    }

    const consensusScore = weightSum > 0 ? weightedSim / weightSum : CSL_THRESHOLDS.MINIMUM;

    return { consensusVec, consensusScore };
  }

  // ─── Private: Quorum Level ────────────────────────────────────────────────

  /**
   * Classify the consensus score into quorum levels.
   * @private
   */
  _quorumLevel(score) {
    if (score >= QUORUM.SUPER) return 'SUPER';
    if (score >= QUORUM.HARD)  return 'HARD';
    if (score >= QUORUM.SOFT)  return 'SOFT';
    return 'FAILED';
  }

  // ─── Private: Winner Selection ────────────────────────────────────────────

  /**
   * Select the winning vote: highest weight × cosine-with-consensus product.
   * @private
   */
  _selectWinner(votes, consensusVec) {
    let best      = null;
    let bestScore = -Infinity;

    for (const v of votes) {
      const alignment = cosineSimilarity(v.embedding, consensusVec);
      const score     = v.weight * alignment;
      if (score > bestScore) {
        bestScore = score;
        best      = { vote: v, score };
      }
    }

    return best || { vote: votes[0], score: 0 };
  }

  // ─── Private: Arbitration ────────────────────────────────────────────────

  /**
   * Invoke HeadySoul arbitration for conflict resolution.
   * @private
   */
  async _arbitrate(votes, context, sessionId) {
    this.emit('consensus:arbitration', {
      sessionId, result: 'invoked', consensusId: this.consensusId,
    });

    const result = await Promise.race([
      this._soulArbitratorFn(votes, context),
      new Promise((_, rej) =>
        setTimeout(() => rej(new Error('Soul arbitration timeout')), SOUL_ARBITRATION_TIMEOUT_MS)
      ),
    ]);

    this.emit('consensus:arbitration', {
      sessionId, result: 'resolved', consensusId: this.consensusId,
    });

    return result;
  }

  // ─── Private: Trust Weight Updates ───────────────────────────────────────

  /**
   * Update trust weights after consensus resolution.
   * Winner swarm gets a small trust boost (×φ, capped at 1.0).
   * Losing swarms in conflict get a small decay (×ψ, floored at ψ⁴).
   *
   * @private
   */
  _updateTrustWeights(votes, winnerSwarmId) {
    for (const v of votes) {
      const current = this._trustWeights.get(v.swarmId) || PSI3;
      if (v.swarmId === winnerSwarmId) {
        // Boost winner: multiply by small phi factor, cap at 1.0
        const boosted = Math.min(1.0, current * (1 + PSI4)); // + ψ⁴ ≈ +0.146
        this._trustWeights.set(v.swarmId, boosted);
      } else if (v.weight < VOTE_WEIGHT_FLOOR) {
        // Decay low-weight losers: multiply by ψ
        const decayed = Math.max(PSI4, current * PSI); // floor: ψ⁴ ≈ 0.146
        this._trustWeights.set(v.swarmId, decayed);
      }
    }
  }

  // ─── Private: Convergence ─────────────────────────────────────────────────

  /**
   * Compute convergence trend using golden-ratio split of history window.
   * Positive = improving consensus, negative = degrading.
   *
   * @private
   */
  _computeConvergenceTrend() {
    const h = this._convergenceHistory;
    if (h.length < fib(3)) return 0; // need at least fib(3)=2 data points

    const mid    = Math.floor(h.length * PSI); // split at golden ratio
    const recent = h.slice(mid);
    const older  = h.slice(0, mid);

    const recentAvg = recent.reduce((s, x) => s + x, 0) / recent.length;
    const olderAvg  = older.length > 0
      ? older.reduce((s, x) => s + x, 0) / older.length
      : recentAvg;

    return recentAvg - olderAvg;
  }

  // ─── Private: History ─────────────────────────────────────────────────────

  /** @private */
  _recordHistory(result) {
    this._history.push(result);
    if (this._history.length > MAX_HISTORY) {
      this._history.splice(0, this._history.length - MAX_HISTORY);
    }
  }

  /** @private */
  _generateSessionId() {
    return `session-${Date.now()}-${(this._totalSessions + 1).toString(36).padStart(4, '0')}`;
  }
}

// ─── Utilities ────────────────────────────────────────────────────────────────

/**
 * @param {number} ms
 * @returns {Promise<void>}
 */
function _sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports                  = SwarmConsensus;
module.exports.SwarmConsensus   = SwarmConsensus;
module.exports.SWARM_REGISTRY   = SWARM_REGISTRY;
module.exports.SWARM_COUNT      = SWARM_COUNT;
module.exports.MIN_VOTERS       = MIN_VOTERS;
module.exports.QUORUM           = QUORUM;
module.exports.VOTE_WEIGHT_FLOOR = VOTE_WEIGHT_FLOOR;
module.exports.CONVERGENCE_WINDOW = CONVERGENCE_WINDOW;
module.exports.VOTE_TIMEOUT_BASE_MS = VOTE_TIMEOUT_BASE_MS;
module.exports.CONFLICT_THRESHOLD = CONFLICT_THRESHOLD;
