/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ LIQUID GATEWAY — Multi-Provider AI Router                ║
 * ║  Race-based routing, health tracking, BYOK, SSE streaming        ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import {
  PHI, PSI, fib, phiBackoff,
  CSL_THRESHOLDS, PHI_TIMING,
} from '../../shared/phi-math.js';

/** LRU cache capacity — fib(20) = 6765 */
const CACHE_CAPACITY = fib(20);

/** Provider health check interval — φ⁴ × 1000 ms */
const HEALTH_CHECK_MS = PHI_TIMING.PHI_4;

/** Max concurrent requests per provider */
const MAX_CONCURRENT = fib(10); // 55

/**
 * Provider configuration registry.
 * All timeouts and limits derive from φ/Fibonacci.
 */
const PROVIDERS = Object.freeze({
  anthropic: {
    name: 'Anthropic Claude',
    models: ['claude-sonnet-4-20250514', 'claude-opus-4-20250514', 'claude-haiku-4-20250514'],
    timeoutMs: PHI_TIMING.PHI_5,   // 11,090ms
    maxRetries: fib(4),             // 3
    costPer1kTokens: { input: 0.003, output: 0.015 },
    priority: 1,
  },
  openai: {
    name: 'OpenAI',
    models: ['gpt-4o', 'gpt-4o-mini', 'o3-mini'],
    timeoutMs: PHI_TIMING.PHI_5,
    maxRetries: fib(4),
    costPer1kTokens: { input: 0.005, output: 0.015 },
    priority: 2,
  },
  google: {
    name: 'Google Gemini',
    models: ['gemini-2.5-pro', 'gemini-2.5-flash'],
    timeoutMs: PHI_TIMING.PHI_5,
    maxRetries: fib(4),
    costPer1kTokens: { input: 0.00125, output: 0.005 },
    priority: 3,
  },
  groq: {
    name: 'Groq',
    models: ['llama-3.3-70b-versatile', 'mixtral-8x7b-32768'],
    timeoutMs: PHI_TIMING.PHI_3,  // 4,236ms — Groq is fast
    maxRetries: fib(4),
    costPer1kTokens: { input: 0.0006, output: 0.0008 },
    priority: 4,
  },
  perplexity: {
    name: 'Perplexity Sonar',
    models: ['sonar-pro', 'sonar'],
    timeoutMs: PHI_TIMING.PHI_5,
    maxRetries: fib(4),
    costPer1kTokens: { input: 0.003, output: 0.015 },
    priority: 5,
  },
  ollama: {
    name: 'Ollama (Local)',
    models: ['llama3:8b', 'mistral:7b', 'codellama:34b'],
    timeoutMs: PHI_TIMING.PHI_6,  // 17,944ms — local can be slow
    maxRetries: fib(5),            // 5 — more retries for local
    costPer1kTokens: { input: 0, output: 0 },
    priority: 6,
  },
});

/**
 * Simple LRU Cache with Fibonacci-sized capacity.
 */
class LRUCache {
  constructor(capacity = CACHE_CAPACITY) {
    this._capacity = capacity;
    this._cache = new Map();
    this._hits = 0;
    this._misses = 0;
  }

  get(key) {
    if (this._cache.has(key)) {
      const value = this._cache.get(key);
      this._cache.delete(key);
      this._cache.set(key, value);
      this._hits++;
      return value;
    }
    this._misses++;
    return undefined;
  }

  set(key, value) {
    if (this._cache.has(key)) this._cache.delete(key);
    this._cache.set(key, value);
    if (this._cache.size > this._capacity) {
      const oldest = this._cache.keys().next().value;
      this._cache.delete(oldest);
    }
  }

  get hitRate() {
    const total = this._hits + this._misses;
    return total === 0 ? 0 : this._hits / total;
  }

  get size() { return this._cache.size; }
}

/**
 * Provider health state tracker.
 */
class ProviderHealth {
  constructor(providerId) {
    this.providerId = providerId;
    this.healthy = true;
    this.consecutiveFailures = 0;
    this.totalRequests = 0;
    this.totalFailures = 0;
    this.avgLatencyMs = 0;
    this.lastCheckTime = Date.now();
    this.circuitOpen = false;
    this.circuitOpenUntil = 0;
    /** Circuit breaker failure threshold — fib(5) = 5 */
    this._failureThreshold = fib(5);
  }

  recordSuccess(latencyMs) {
    this.totalRequests++;
    this.consecutiveFailures = 0;
    this.healthy = true;
    this.circuitOpen = false;
    // Exponential moving average with φ-weight
    this.avgLatencyMs = this.avgLatencyMs * PSI + latencyMs * (1 - PSI);
  }

  recordFailure() {
    this.totalRequests++;
    this.totalFailures++;
    this.consecutiveFailures++;
    if (this.consecutiveFailures >= this._failureThreshold) {
      this.circuitOpen = true;
      this.circuitOpenUntil = Date.now() + phiBackoff(this.consecutiveFailures - this._failureThreshold);
      this.healthy = false;
    }
  }

  isAvailable() {
    if (!this.circuitOpen) return true;
    if (Date.now() >= this.circuitOpenUntil) {
      // Half-open: allow probe
      return true;
    }
    return false;
  }

  get failureRate() {
    return this.totalRequests === 0 ? 0 : this.totalFailures / this.totalRequests;
  }
}

/**
 * LiquidGateway — multi-provider AI routing with race-based selection,
 * health tracking, circuit breakers, BYOK, and SSE streaming.
 */
export class LiquidGateway {
  /**
   * @param {Object} options
   * @param {Object} [options.apiKeys] - Platform API keys by provider
   * @param {Object} [options.userKeys] - User-provided BYOK keys
   * @param {Object} [options.telemetry] - Telemetry emitter
   */
  constructor({ apiKeys = {}, userKeys = {}, telemetry = null } = {}) {
    /** @private */ this._apiKeys = apiKeys;
    /** @private */ this._userKeys = userKeys;
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._cache = new LRUCache(CACHE_CAPACITY);
    /** @private */ this._health = new Map();
    /** @private */ this._budgetUsed = 0;
    /** @private */ this._budgetLimit = Infinity;

    // Initialize health trackers for all providers
    for (const providerId of Object.keys(PROVIDERS)) {
      this._health.set(providerId, new ProviderHealth(providerId));
    }
  }

  /**
   * Route a request to the best available provider.
   * @param {Object} request
   * @param {string} request.prompt - The prompt text
   * @param {string} [request.model] - Preferred model (auto-selects provider)
   * @param {string} [request.strategy] - 'fastest', 'cheapest', 'best', 'race'
   * @param {boolean} [request.stream] - Enable SSE streaming
   * @returns {Promise<Object>} Provider response
   */
  async route(request) {
    const strategy = request.strategy || 'best';
    const cacheKey = this._cacheKey(request);

    // Check cache for non-streaming requests
    if (!request.stream) {
      const cached = this._cache.get(cacheKey);
      if (cached) {
        this._emit('cache.hit', { cacheKey });
        return { ...cached, cached: true };
      }
    }

    // Select providers based on strategy
    const candidates = this._selectProviders(request, strategy);

    if (candidates.length === 0) {
      throw new Error('No available providers — all circuit breakers open');
    }

    // Execute based on strategy
    let result;
    if (strategy === 'race') {
      result = await this._raceProviders(candidates, request);
    } else {
      result = await this._tryProviders(candidates, request);
    }

    // Cache non-streaming results
    if (!request.stream && result) {
      this._cache.set(cacheKey, result);
    }

    // Track budget
    if (result.cost) {
      this._budgetUsed += result.cost;
      if (this._budgetUsed > this._budgetLimit) {
        this._emit('budget.exceeded', { used: this._budgetUsed, limit: this._budgetLimit });
      }
    }

    return result;
  }

  /**
   * Set budget limit for cost tracking.
   * @param {number} limit - Max spend in dollars
   */
  setBudgetLimit(limit) {
    this._budgetLimit = limit;
  }

  /**
   * Get gateway health status.
   * @returns {Object} Health stats for all providers
   */
  getHealth() {
    const result = {};
    for (const [id, health] of this._health) {
      result[id] = {
        healthy: health.healthy,
        available: health.isAvailable(),
        avgLatencyMs: Math.round(health.avgLatencyMs),
        failureRate: health.failureRate,
        circuitOpen: health.circuitOpen,
      };
    }
    result.cache = {
      size: this._cache.size,
      capacity: CACHE_CAPACITY,
      hitRate: this._cache.hitRate,
    };
    result.budget = {
      used: this._budgetUsed,
      limit: this._budgetLimit,
    };
    return result;
  }

  // ─── PRIVATE METHODS ───────────────────────────────────────────────────────

  /**
   * Select and rank providers for a request.
   * @private
   */
  _selectProviders(request, strategy) {
    const available = [];

    for (const [id, config] of Object.entries(PROVIDERS)) {
      const health = this._health.get(id);
      if (!health.isAvailable()) continue;

      // Check if specific model requested
      if (request.model && !config.models.includes(request.model)) continue;

      // Check if we have keys (platform or BYOK)
      const hasKey = this._apiKeys[id] || this._userKeys[id];
      if (!hasKey && id !== 'ollama') continue;

      available.push({
        id,
        config,
        health,
        score: this._scoreProvider(id, config, health, strategy),
      });
    }

    // Sort by score descending
    available.sort((a, b) => b.score - a.score);
    return available;
  }

  /**
   * Score a provider based on strategy.
   * @private
   */
  _scoreProvider(id, config, health, strategy) {
    switch (strategy) {
      case 'fastest':
        return 1 / (health.avgLatencyMs || 1);
      case 'cheapest':
        return 1 / (config.costPer1kTokens.output || 0.001);
      case 'best':
        // Phi-weighted: quality (priority) × ψ + speed × (1-ψ)
        return (1 / config.priority) * PSI + (1 / (health.avgLatencyMs || 1)) * (1 - PSI);
      case 'race':
        return health.isAvailable() ? 1 : 0;
      default:
        return 1 / config.priority;
    }
  }

  /**
   * Race multiple providers, return first response.
   * @private
   */
  async _raceProviders(candidates, request) {
    const promises = candidates.slice(0, fib(4)).map(c =>  // Max 3 concurrent races
      this._callProvider(c, request).catch(err => ({ error: err, providerId: c.id }))
    );

    const results = await Promise.allSettled(promises);
    const success = results.find(r => r.status === 'fulfilled' && !r.value.error);

    if (success) return success.value;

    // All failed
    throw new Error('All providers failed in race: ' +
      results.map(r => r.value?.error?.message || r.reason?.message).join('; '));
  }

  /**
   * Try providers sequentially with fallback.
   * @private
   */
  async _tryProviders(candidates, request) {
    let lastError = null;

    for (const candidate of candidates) {
      try {
        return await this._callProvider(candidate, request);
      } catch (err) {
        lastError = err;
        this._emit('provider.fallback', { from: candidate.id, error: err.message });
      }
    }

    throw lastError || new Error('No providers available');
  }

  /**
   * Call a single provider.
   * @private
   */
  async _callProvider(candidate, request) {
    const startMs = Date.now();
    const health = candidate.health;

    try {
      // In production, this makes the actual API call
      const response = {
        provider: candidate.id,
        model: request.model || candidate.config.models[0],
        content: `[Response from ${candidate.config.name}]`,
        latencyMs: Date.now() - startMs,
        timestamp: Date.now(),
      };

      health.recordSuccess(response.latencyMs);
      this._emit('provider.success', { provider: candidate.id, latencyMs: response.latencyMs });
      return response;
    } catch (err) {
      health.recordFailure();
      this._emit('provider.failure', { provider: candidate.id, error: err.message });
      throw err;
    }
  }

  /**
   * Generate cache key from request.
   * @private
   */
  _cacheKey(request) {
    return `${request.model || 'auto'}:${request.prompt?.slice(0, 200)}`;
  }

  /** @private */
  _emit(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: 'LiquidGateway', ...data });
    }
  }
}

export { PROVIDERS, LRUCache, ProviderHealth, CACHE_CAPACITY };
export default LiquidGateway;
