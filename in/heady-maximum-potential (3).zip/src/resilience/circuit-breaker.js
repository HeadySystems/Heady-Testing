/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ CIRCUIT BREAKER — Cascade Failure Prevention             ║
 * ║  State machine: CLOSED → OPEN → HALF_OPEN → CLOSED              ║
 * ║  φ-exponential backoff recovery with Fibonacci thresholds        ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib, phiBackoff, CSL_THRESHOLDS } from '../../shared/phi-math.js';

/** Circuit breaker states */
const STATE = Object.freeze({
  CLOSED:    'CLOSED',
  OPEN:      'OPEN',
  HALF_OPEN: 'HALF_OPEN',
});

/** Default failure threshold — fib(5) = 5 consecutive failures */
const DEFAULT_FAILURE_THRESHOLD = fib(5);

/** Default success threshold for HALF_OPEN → CLOSED — fib(4) = 3 */
const DEFAULT_SUCCESS_THRESHOLD = fib(4);

/** Default sliding window size — fib(9) = 34 seconds */
const DEFAULT_WINDOW_MS = fib(9) * 1000;

/** Max open duration — fib(11) × 1000 = 89,000ms */
const MAX_OPEN_MS = fib(11) * 1000;

/**
 * CircuitBreaker — prevents cascade failures with phi-scaled recovery.
 *
 * CLOSED: All requests pass through. Failures are counted in a sliding window.
 *   → OPEN when consecutiveFailures >= failureThreshold
 *
 * OPEN: All requests are rejected immediately (fail-fast).
 *   → HALF_OPEN after phi-exponential backoff timeout
 *
 * HALF_OPEN: Limited probe requests pass through.
 *   → CLOSED when successThreshold probes succeed
 *   → OPEN when any probe fails
 */
export class CircuitBreaker {
  /**
   * @param {Object} options
   * @param {string} options.name - Circuit name (for logging)
   * @param {number} [options.failureThreshold] - Failures before opening (default: 5)
   * @param {number} [options.successThreshold] - Successes to close (default: 3)
   * @param {number} [options.windowMs] - Sliding window (default: 34,000ms)
   * @param {Function} [options.onStateChange] - Callback(newState, oldState, name)
   * @param {Object} [options.telemetry] - Telemetry emitter
   */
  constructor({
    name,
    failureThreshold = DEFAULT_FAILURE_THRESHOLD,
    successThreshold = DEFAULT_SUCCESS_THRESHOLD,
    windowMs = DEFAULT_WINDOW_MS,
    onStateChange = null,
    telemetry = null,
  }) {
    /** @readonly */ this.name = name;
    /** @private */ this._failureThreshold = failureThreshold;
    /** @private */ this._successThreshold = successThreshold;
    /** @private */ this._windowMs = windowMs;
    /** @private */ this._onStateChange = onStateChange;
    /** @private */ this._telemetry = telemetry;

    /** @private */ this._state = STATE.CLOSED;
    /** @private */ this._failures = [];      // Timestamps of recent failures
    /** @private */ this._consecutiveFailures = 0;
    /** @private */ this._halfOpenSuccesses = 0;
    /** @private */ this._openSince = 0;
    /** @private */ this._openAttempt = 0;     // For phi-backoff escalation
    /** @private */ this._totalRequests = 0;
    /** @private */ this._totalFailures = 0;
    /** @private */ this._totalSuccesses = 0;
    /** @private */ this._totalRejected = 0;
  }

  /** @returns {string} Current state */
  get state() { return this._state; }

  /** @returns {boolean} Whether requests are allowed */
  get isAllowed() {
    this._pruneOldFailures();

    switch (this._state) {
      case STATE.CLOSED:
        return true;
      case STATE.OPEN:
        return this._shouldTransitionToHalfOpen();
      case STATE.HALF_OPEN:
        return true; // Probe requests allowed
      default:
        return false;
    }
  }

  /**
   * Execute a function through the circuit breaker.
   * @template T
   * @param {Function} fn - Async function to execute
   * @returns {Promise<T>} Function result
   * @throws {Error} If circuit is OPEN
   */
  async execute(fn) {
    this._totalRequests++;

    if (!this.isAllowed) {
      this._totalRejected++;
      this._emit('circuit.rejected', { name: this.name, state: this._state });
      throw new CircuitBreakerError(
        `Circuit ${this.name} is OPEN — failing fast. Retry after ${this._getRetryAfterMs()}ms`,
        this.name,
        this._state
      );
    }

    try {
      const result = await fn();
      this._recordSuccess();
      return result;
    } catch (err) {
      this._recordFailure();
      throw err;
    }
  }

  /**
   * Manually force the circuit to a specific state (for testing/admin).
   * @param {string} state - One of CLOSED, OPEN, HALF_OPEN
   */
  forceState(state) {
    if (!Object.values(STATE).includes(state)) {
      throw new Error(`Invalid state: ${state}`);
    }
    const old = this._state;
    this._state = state;
    this._onStateChange?.(state, old, this.name);
    this._emit('circuit.forced', { name: this.name, from: old, to: state });
  }

  /**
   * Get circuit breaker statistics.
   * @returns {Object}
   */
  getStats() {
    return {
      name: this.name,
      state: this._state,
      consecutiveFailures: this._consecutiveFailures,
      failureThreshold: this._failureThreshold,
      totalRequests: this._totalRequests,
      totalSuccesses: this._totalSuccesses,
      totalFailures: this._totalFailures,
      totalRejected: this._totalRejected,
      failureRate: this._totalRequests === 0 ? 0 : this._totalFailures / this._totalRequests,
      retryAfterMs: this._state === STATE.OPEN ? this._getRetryAfterMs() : 0,
    };
  }

  /**
   * Reset the circuit breaker to initial state.
   */
  reset() {
    const old = this._state;
    this._state = STATE.CLOSED;
    this._failures = [];
    this._consecutiveFailures = 0;
    this._halfOpenSuccesses = 0;
    this._openSince = 0;
    this._openAttempt = 0;
    if (old !== STATE.CLOSED) {
      this._onStateChange?.(STATE.CLOSED, old, this.name);
    }
  }

  // ─── PRIVATE METHODS ───────────────────────────────────────────────────────

  /** @private */
  _recordSuccess() {
    this._totalSuccesses++;
    this._consecutiveFailures = 0;

    if (this._state === STATE.HALF_OPEN) {
      this._halfOpenSuccesses++;
      if (this._halfOpenSuccesses >= this._successThreshold) {
        this._transition(STATE.CLOSED);
        this._openAttempt = 0; // Reset backoff escalation
      }
    }
  }

  /** @private */
  _recordFailure() {
    this._totalFailures++;
    this._consecutiveFailures++;
    this._failures.push(Date.now());

    if (this._state === STATE.HALF_OPEN) {
      // Any failure in HALF_OPEN immediately re-opens
      this._openAttempt++;
      this._transition(STATE.OPEN);
    } else if (this._state === STATE.CLOSED) {
      if (this._consecutiveFailures >= this._failureThreshold) {
        this._transition(STATE.OPEN);
      }
    }
  }

  /** @private */
  _transition(newState) {
    const old = this._state;
    this._state = newState;

    if (newState === STATE.OPEN) {
      this._openSince = Date.now();
      this._halfOpenSuccesses = 0;
    }

    if (newState === STATE.CLOSED) {
      this._failures = [];
      this._consecutiveFailures = 0;
      this._halfOpenSuccesses = 0;
    }

    this._onStateChange?.(newState, old, this.name);
    this._emit('circuit.transition', { name: this.name, from: old, to: newState });
  }

  /** @private */
  _shouldTransitionToHalfOpen() {
    const elapsed = Date.now() - this._openSince;
    const backoffMs = Math.min(phiBackoff(this._openAttempt), MAX_OPEN_MS);

    if (elapsed >= backoffMs) {
      this._transition(STATE.HALF_OPEN);
      return true;
    }
    return false;
  }

  /** @private */
  _getRetryAfterMs() {
    const elapsed = Date.now() - this._openSince;
    const backoffMs = Math.min(phiBackoff(this._openAttempt), MAX_OPEN_MS);
    return Math.max(0, backoffMs - elapsed);
  }

  /** @private */
  _pruneOldFailures() {
    const cutoff = Date.now() - this._windowMs;
    this._failures = this._failures.filter(ts => ts > cutoff);
  }

  /** @private */
  _emit(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: 'CircuitBreaker', ...data });
    }
  }
}

/**
 * Custom error for circuit breaker rejections.
 */
export class CircuitBreakerError extends Error {
  constructor(message, circuitName, state) {
    super(message);
    this.name = 'CircuitBreakerError';
    this.circuitName = circuitName;
    this.circuitState = state;
  }
}

export { STATE, DEFAULT_FAILURE_THRESHOLD };
export default CircuitBreaker;
