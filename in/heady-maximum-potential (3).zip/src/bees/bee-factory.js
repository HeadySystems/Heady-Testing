/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ BEE FACTORY — Dynamic Agent Worker Factory               ║
 * ║  Spawns, manages, and retires 10,000+ concurrent bees            ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib, phiBackoff, PHI_TIMING } from '../../shared/phi-math.js';
import { BaseHeadyBee, BEE_STATE } from './base-bee.js';

/** Maximum concurrent bees — LAW-06 10K scale readiness */
const MAX_CONCURRENT_BEES = 10000;

/** Total bee types — fib(11) = 89 */
const TOTAL_BEE_TYPES = fib(11);

/** Spawn latency target — < 50ms */
const SPAWN_LATENCY_TARGET_MS = 50;

/** Memory per bee baseline — 2MB */
const MEMORY_PER_BEE_BYTES = 2 * 1024 * 1024;

/**
 * BeeFactory — the core mechanism for liquid architecture.
 * Dynamically spawns, manages, and retires bee workers across 17 swarms.
 */
export class BeeFactory {
  /**
   * @param {Object} options
   * @param {Object} [options.registry] - Bee type → constructor mapping
   * @param {Object} [options.telemetry]
   */
  constructor({ registry = {}, telemetry = null } = {}) {
    /** @private */ this._registry = new Map(Object.entries(registry));
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._activeBees = new Map();  // id → bee instance
    /** @private */ this._beesByType = new Map();  // type → Set<id>
    /** @private */ this._beesBySwarm = new Map(); // swarm → Set<id>
    /** @private */ this._totalSpawned = 0;
    /** @private */ this._totalRetired = 0;
  }

  /**
   * Register a bee type constructor.
   * @param {string} type - Bee type name
   * @param {Function} BeeClass - Constructor extending BaseHeadyBee
   */
  registerType(type, BeeClass) {
    this._registry.set(type, BeeClass);
  }

  /**
   * Spawn a new bee of the given type.
   * @param {string} type - Bee type
   * @param {Object} [config] - Additional config
   * @returns {Promise<BaseHeadyBee>} Spawned bee instance
   */
  async spawn(type, config = {}) {
    if (this._activeBees.size >= MAX_CONCURRENT_BEES) {
      throw new Error(`Bee factory at capacity: ${this._activeBees.size}/${MAX_CONCURRENT_BEES}`);
    }

    const BeeClass = this._registry.get(type) || BaseHeadyBee;
    const id = `bee_${type}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const bee = new BeeClass({
      id,
      type,
      swarm: config.swarm || null,
      telemetry: this._telemetry,
      ...config,
    });

    const spawnStart = Date.now();
    await bee.spawn(config.context || {});
    const spawnMs = Date.now() - spawnStart;

    // Track in all indices
    this._activeBees.set(id, bee);
    if (!this._beesByType.has(type)) this._beesByType.set(type, new Set());
    this._beesByType.get(type).add(id);
    if (config.swarm) {
      if (!this._beesBySwarm.has(config.swarm)) this._beesBySwarm.set(config.swarm, new Set());
      this._beesBySwarm.get(config.swarm).add(id);
    }

    this._totalSpawned++;

    if (spawnMs > SPAWN_LATENCY_TARGET_MS) {
      this._emit('bee.spawn.slow', { id, type, spawnMs, target: SPAWN_LATENCY_TARGET_MS });
    }

    return bee;
  }

  /**
   * Spawn multiple bees of the same type.
   * @param {string} type - Bee type
   * @param {number} count - Number to spawn
   * @param {Object} [config]
   * @returns {Promise<BaseHeadyBee[]>}
   */
  async spawnBatch(type, count, config = {}) {
    const bees = [];
    for (let i = 0; i < count; i++) {
      bees.push(this.spawn(type, config));
    }
    return Promise.all(bees);
  }

  /**
   * Retire a bee by ID.
   * @param {string} beeId
   * @returns {Promise<void>}
   */
  async retire(beeId) {
    const bee = this._activeBees.get(beeId);
    if (!bee) return;

    await bee.retire();

    this._activeBees.delete(beeId);
    const typeSet = this._beesByType.get(bee.type);
    if (typeSet) typeSet.delete(beeId);
    if (bee.swarm) {
      const swarmSet = this._beesBySwarm.get(bee.swarm);
      if (swarmSet) swarmSet.delete(beeId);
    }

    this._totalRetired++;
  }

  /**
   * Retire all bees of a given type.
   * @param {string} type
   */
  async retireByType(type) {
    const ids = this._beesByType.get(type);
    if (!ids) return;
    for (const id of [...ids]) {
      await this.retire(id);
    }
  }

  /**
   * Retire all bees in a swarm.
   * @param {string} swarm
   */
  async retireBySwarm(swarm) {
    const ids = this._beesBySwarm.get(swarm);
    if (!ids) return;
    for (const id of [...ids]) {
      await this.retire(id);
    }
  }

  /**
   * Get a bee by ID.
   * @param {string} beeId
   * @returns {BaseHeadyBee|undefined}
   */
  get(beeId) {
    return this._activeBees.get(beeId);
  }

  /**
   * Get all bees of a type.
   * @param {string} type
   * @returns {BaseHeadyBee[]}
   */
  getByType(type) {
    const ids = this._beesByType.get(type) || new Set();
    return [...ids].map(id => this._activeBees.get(id)).filter(Boolean);
  }

  /**
   * Graceful shutdown — retire all bees in LIFO order.
   * @returns {Promise<void>}
   */
  async shutdown() {
    const ids = [...this._activeBees.keys()].reverse();
    this._emit('factory.shutting_down', { bees: ids.length });

    for (const id of ids) {
      try {
        await this.retire(id);
      } catch (err) {
        this._emit('factory.retire.error', { id, error: err.message });
      }
    }

    this._emit('factory.shutdown', { retired: this._totalRetired });
  }

  /**
   * Get factory statistics.
   * @returns {Object}
   */
  getStats() {
    const typeBreakdown = {};
    for (const [type, ids] of this._beesByType) {
      typeBreakdown[type] = ids.size;
    }

    const swarmBreakdown = {};
    for (const [swarm, ids] of this._beesBySwarm) {
      swarmBreakdown[swarm] = ids.size;
    }

    return {
      active: this._activeBees.size,
      maxCapacity: MAX_CONCURRENT_BEES,
      utilization: this._activeBees.size / MAX_CONCURRENT_BEES,
      registeredTypes: this._registry.size,
      totalBeeTypes: TOTAL_BEE_TYPES,
      totalSpawned: this._totalSpawned,
      totalRetired: this._totalRetired,
      estimatedMemoryMB: (this._activeBees.size * MEMORY_PER_BEE_BYTES) / (1024 * 1024),
      typeBreakdown,
      swarmBreakdown,
    };
  }

  /** @private */
  _emit(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: 'BeeFactory', ...data });
    }
  }
}

export { MAX_CONCURRENT_BEES, TOTAL_BEE_TYPES };
export default BeeFactory;
