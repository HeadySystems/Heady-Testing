/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ BASE BEE — Abstract Base Class for All Bee Workers       ║
 * ║  spawn() → execute() → report() → retire() lifecycle            ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib, phiBackoff, PHI_TIMING } from '../../shared/phi-math.js';

/** Bee lifecycle states */
const BEE_STATE = Object.freeze({
  CREATED:   'CREATED',
  SPAWNING:  'SPAWNING',
  READY:     'READY',
  EXECUTING: 'EXECUTING',
  REPORTING: 'REPORTING',
  RETIRING:  'RETIRING',
  RETIRED:   'RETIRED',
  FAILED:    'FAILED',
});

/** Default timeout for bee execution — φ³ × 1000ms */
const DEFAULT_TIMEOUT = PHI_TIMING.PHI_3;

/** Max retries — fib(5) = 5 */
const MAX_RETRIES = fib(5);

/**
 * BaseHeadyBee — abstract base class for all bee agent workers.
 * Every bee type in the 89-type registry extends this class.
 *
 * Lifecycle: CREATED → SPAWNING → READY → EXECUTING → REPORTING → RETIRING → RETIRED
 */
export class BaseHeadyBee {
  /**
   * @param {Object} config
   * @param {string} config.id - Unique bee ID
   * @param {string} config.type - Bee type (e.g., 'agents-bee', 'brain-bee')
   * @param {string} [config.swarm] - Assigned swarm (1-17)
   * @param {Object} [config.telemetry]
   */
  constructor({ id, type, swarm = null, telemetry = null }) {
    /** @readonly */ this.id = id;
    /** @readonly */ this.type = type;
    /** @readonly */ this.swarm = swarm;
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._state = BEE_STATE.CREATED;
    /** @private */ this._spawnTime = null;
    /** @private */ this._executeStartTime = null;
    /** @private */ this._resources = new Map();
    /** @private */ this._metrics = { executions: 0, failures: 0, totalMs: 0 };
  }

  /** @returns {string} Current lifecycle state */
  get state() { return this._state; }

  /**
   * Phase 1: Initialize resources, validate config, register with factory.
   * @param {Object} context - Spawn context from the bee factory
   * @returns {Promise<void>}
   */
  async spawn(context = {}) {
    this._state = BEE_STATE.SPAWNING;
    this._spawnTime = Date.now();
    this._emit('bee.spawning', { id: this.id, type: this.type });

    try {
      await this._onSpawn(context);
      this._state = BEE_STATE.READY;
      this._emit('bee.ready', { id: this.id, spawnMs: Date.now() - this._spawnTime });
    } catch (err) {
      this._state = BEE_STATE.FAILED;
      this._emit('bee.spawn.failed', { id: this.id, error: err.message });
      throw err;
    }
  }

  /**
   * Phase 2: Core task execution with CSL-gated logic.
   * @param {Object} task - Task to execute
   * @returns {Promise<Object>} Execution result
   */
  async execute(task) {
    if (this._state !== BEE_STATE.READY) {
      throw new Error(`Bee ${this.id} not ready (state: ${this._state})`);
    }

    this._state = BEE_STATE.EXECUTING;
    this._executeStartTime = Date.now();
    this._metrics.executions++;

    try {
      const result = await Promise.race([
        this._onExecute(task),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`Bee ${this.id} execution timeout (${DEFAULT_TIMEOUT}ms)`)), DEFAULT_TIMEOUT)
        ),
      ]);

      const execMs = Date.now() - this._executeStartTime;
      this._metrics.totalMs += execMs;
      this._state = BEE_STATE.READY; // Back to ready for next task

      this._emit('bee.executed', { id: this.id, execMs });
      return result;
    } catch (err) {
      this._metrics.failures++;
      this._state = BEE_STATE.READY; // Allow retry
      this._emit('bee.execute.failed', { id: this.id, error: err.message });
      throw err;
    }
  }

  /**
   * Phase 3: Report results to orchestration-bee and health-bee.
   * @returns {Promise<Object>} Health report
   */
  async report() {
    this._state = BEE_STATE.REPORTING;
    const report = {
      id: this.id,
      type: this.type,
      swarm: this.swarm,
      state: this._state,
      metrics: { ...this._metrics },
      avgExecMs: this._metrics.executions > 0
        ? this._metrics.totalMs / this._metrics.executions
        : 0,
      uptime: Date.now() - (this._spawnTime || Date.now()),
    };

    const customReport = await this._onReport();
    this._state = BEE_STATE.READY;
    return { ...report, ...customReport };
  }

  /**
   * Phase 4: Cleanup resources in LIFO order, deregister from registry.
   * @returns {Promise<void>}
   */
  async retire() {
    this._state = BEE_STATE.RETIRING;
    this._emit('bee.retiring', { id: this.id });

    try {
      // LIFO cleanup of resources
      const resourceKeys = [...this._resources.keys()].reverse();
      for (const key of resourceKeys) {
        const cleanup = this._resources.get(key);
        if (typeof cleanup === 'function') await cleanup();
        this._resources.delete(key);
      }

      await this._onRetire();
      this._state = BEE_STATE.RETIRED;
      this._emit('bee.retired', { id: this.id, uptime: Date.now() - this._spawnTime });
    } catch (err) {
      this._state = BEE_STATE.FAILED;
      this._emit('bee.retire.failed', { id: this.id, error: err.message });
      throw err;
    }
  }

  /**
   * Register a resource with a cleanup function (for LIFO teardown).
   * @param {string} name - Resource name
   * @param {Function} cleanupFn - Async cleanup function
   */
  registerResource(name, cleanupFn) {
    this._resources.set(name, cleanupFn);
  }

  // ─── HOOKS (Override in subclasses) ────────────────────────────────────────

  /** @protected */ async _onSpawn(context) {}
  /** @protected */ async _onExecute(task) { return { status: 'completed' }; }
  /** @protected */ async _onReport() { return {}; }
  /** @protected */ async _onRetire() {}

  /** @private */
  _emit(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: `Bee:${this.type}`, ...data });
    }
  }
}

export { BEE_STATE, DEFAULT_TIMEOUT, MAX_RETRIES };
export default BaseHeadyBee;
