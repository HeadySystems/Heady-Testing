/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ ED25519 RECEIPT SIGNER — Cryptographic Audit Receipts    ║
 * ║  Stage 20 RECEIPT — immutable chain of signed execution proofs   ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { fib, PHI_TIMING } from '../../shared/phi-math.js';
import crypto from 'crypto';

/** Receipt chain max length — fib(17) = 1597 */
const MAX_CHAIN_LENGTH = fib(17);

/**
 * Ed25519ReceiptSigner — generates cryptographic audit receipts
 * for every pipeline execution (Stage 20).
 */
export class Ed25519ReceiptSigner {
  constructor() {
    /** @private */ this._keyPair = null;
    /** @private */ this._chain = [];
    /** @private */ this._chainHash = null;
  }

  /**
   * Initialize the signer with a new or existing key pair.
   * @param {Object} [options]
   * @param {Buffer} [options.privateKey] - Existing Ed25519 private key
   */
  async initialize(options = {}) {
    if (options.privateKey) {
      this._keyPair = {
        privateKey: options.privateKey,
        publicKey: crypto.createPublicKey(options.privateKey),
      };
    } else {
      const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
      this._keyPair = { publicKey, privateKey };
    }
  }

  /**
   * Sign a pipeline execution receipt.
   * @param {Object} data
   * @param {string} data.runId - Pipeline run ID
   * @param {string} data.variant - Pipeline variant used
   * @param {Object} data.results - Stage results summary
   * @param {number} data.totalMs - Total execution time
   * @returns {Object} Signed receipt
   */
  sign(data) {
    if (!this._keyPair) throw new Error('Signer not initialized');

    const receipt = {
      version: '4.0.0',
      runId: data.runId,
      variant: data.variant,
      timestamp: new Date().toISOString(),
      epochMs: Date.now(),
      totalMs: data.totalMs,
      stageCount: data.results ? Object.keys(data.results).length : 0,
      contentHash: this._hashContent(data),
      previousHash: this._chainHash,
      chainIndex: this._chain.length,
    };

    // Sign the receipt
    const payload = JSON.stringify(receipt);
    const signature = crypto.sign(null, Buffer.from(payload), this._keyPair.privateKey);
    receipt.signature = signature.toString('base64');

    // Update chain
    this._chainHash = this._hashContent(receipt);
    this._chain.push(receipt);

    // Trim chain to max length
    if (this._chain.length > MAX_CHAIN_LENGTH) {
      this._chain.shift();
    }

    return receipt;
  }

  /**
   * Verify a receipt's signature.
   * @param {Object} receipt
   * @returns {boolean}
   */
  verify(receipt) {
    if (!this._keyPair) throw new Error('Signer not initialized');

    const { signature, ...payload } = receipt;
    const payloadStr = JSON.stringify(payload);

    return crypto.verify(
      null,
      Buffer.from(payloadStr),
      this._keyPair.publicKey,
      Buffer.from(signature, 'base64')
    );
  }

  /**
   * Get the public key for verification sharing.
   * @returns {string} PEM-encoded public key
   */
  getPublicKey() {
    if (!this._keyPair) throw new Error('Signer not initialized');
    return this._keyPair.publicKey.export({ type: 'spki', format: 'pem' });
  }

  /**
   * Get chain integrity status.
   * @returns {Object}
   */
  getChainStatus() {
    return {
      length: this._chain.length,
      maxLength: MAX_CHAIN_LENGTH,
      latestHash: this._chainHash,
      isValid: this._verifyChain(),
    };
  }

  /** @private */
  _hashContent(data) {
    return crypto.createHash('sha256')
      .update(JSON.stringify(data))
      .digest('hex');
  }

  /** @private */
  _verifyChain() {
    for (let i = 1; i < this._chain.length; i++) {
      const expected = this._hashContent(this._chain[i - 1]);
      if (this._chain[i].previousHash !== expected) return false;
    }
    return true;
  }
}

export { MAX_CHAIN_LENGTH };
export default Ed25519ReceiptSigner;
