/**
 * WebSocketAuth — Secure WebSocket authentication with httpOnly cookie verification
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const { createHmac, timingSafeEqual } = require('crypto');

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('websocket-auth');

/**
 * Parse cookies from request headers
 */
function parseCookies(cookieHeader) {
  const cookies = {};
  if (!cookieHeader) { return cookies; }
  cookieHeader.split(';').forEach(cookie => {
    const parts = cookie.trim().split('=');
    if (parts.length >= 2) {
      cookies[parts[0].trim()] = parts.slice(1).join('=').trim();
    }
  });
  return cookies;
}

/**
 * Verify HMAC token
 */
function verifyToken(token, secret) {
  if (!token || !secret) { return { valid: false, reason: 'Missing token or secret' }; }

  const parts = token.split('.');
  if (parts.length !== 3) { return { valid: false, reason: 'Invalid token format' }; }

  const [header, payload, signature] = parts;
  const expectedSig = createHmac('sha256', secret)
    .update(`${header}.${payload}`)
    .digest('base64url');

  try {
    const sigBuffer = Buffer.from(signature, 'base64url');
    const expectedBuffer = Buffer.from(expectedSig, 'base64url');

    if (sigBuffer.length !== expectedBuffer.length) {
      return { valid: false, reason: 'Signature length mismatch' };
    }

    if (!timingSafeEqual(sigBuffer, expectedBuffer)) {
      return { valid: false, reason: 'Invalid signature' };
    }

    const decoded = JSON.parse(Buffer.from(payload, 'base64url').toString());

    // Check expiration
    if (decoded.exp && decoded.exp < Date.now() / 1000) {
      return { valid: false, reason: 'Token expired' };
    }

    return { valid: true, payload: decoded };
  } catch (err) {
    return { valid: false, reason: `Verification error: ${err.message}` };
  }
}

/**
 * WebSocket upgrade authentication middleware
 */
function authenticateWebSocket(req, options = {}) {
  const secret = options.secret || process.env.JWT_SECRET;
  const cookieName = options.cookieName || 'heady_session';

  if (!secret) {
    logger.error('JWT_SECRET not configured');
    return { authenticated: false, reason: 'Server configuration error' };
  }

  // Extract token from httpOnly cookie (primary) or query param (fallback for initial handshake)
  const cookies = parseCookies(req.headers.cookie);
  const token = cookies[cookieName];

  if (!token) {
    // Fallback: check URL query parameter for initial handshake
    const urlObj = new URL(req.url, `http://${req.headers.host}`);
    const queryToken = urlObj.searchParams.get('token');

    if (!queryToken) {
      logger.warn('No authentication token found', { source: 'websocket' });
      return { authenticated: false, reason: 'No authentication token' };
    }

    const result = verifyToken(queryToken, secret);
    if (!result.valid) {
      logger.warn('WebSocket auth failed (query)', { reason: result.reason });
      return { authenticated: false, reason: result.reason };
    }

    logger.info('WebSocket authenticated via query token', { user: result.payload.sub });
    return { authenticated: true, user: result.payload };
  }

  const result = verifyToken(token, secret);
  if (!result.valid) {
    logger.warn('WebSocket auth failed (cookie)', { reason: result.reason });
    return { authenticated: false, reason: result.reason };
  }

  logger.info('WebSocket authenticated via httpOnly cookie', { user: result.payload.sub });
  return { authenticated: true, user: result.payload };
}

/**
 * Maximum concurrent WebSocket connections (Fibonacci-scaled)
 */
const WS_LIMITS = {
  MAX_CONNECTIONS_PER_USER: FIB[5],       // 5
  MAX_TOTAL_CONNECTIONS: FIB[16],          // 987
  HEARTBEAT_INTERVAL_MS: FIB[8] * 1000,   // 21s
  IDLE_TIMEOUT_MS: FIB[10] * 1000,        // 55s
  MAX_MESSAGE_SIZE: FIB[16] * 1024,       // ~987KB
};

module.exports = {
  authenticateWebSocket,
  parseCookies,
  verifyToken,
  WS_LIMITS,
  PHI, PSI, FIB,
};
