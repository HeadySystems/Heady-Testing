/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ GRACEFUL SHUTDOWN — LIFO Cleanup & Drain                  ║
 * ║  Boot → Operate → Heal → Evolve → Shutdown lifecycle             ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib, PHI_TIMING } from '../../shared/phi-math.js';

/** Shutdown grace period — fib(8) × 1000 = 21,000ms */
const GRACE_PERIOD_MS = fib(8) * 1000;

/** Drain timeout — φ⁵ × 1000 = 11,090ms */
const DRAIN_TIMEOUT_MS = PHI_TIMING.PHI_5;

/**
 * GracefulShutdown — manages LIFO cleanup of all system resources.
 * Resources registered first are cleaned up last.
 */
export class GracefulShutdown {
  constructor({ telemetry = null } = {}) {
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._resources = []; // { name, cleanupFn, registeredAt }
    /** @private */ this._shutdownInProgress = false;
    /** @private */ this._signalHandlersRegistered = false;
  }

  /**
   * Register a resource with its cleanup function.
   * @param {string} name - Resource name
   * @param {Function} cleanupFn - Async cleanup function
   */
  register(name, cleanupFn) {
    this._resources.push({ name, cleanupFn, registeredAt: Date.now() });
  }

  /**
   * Register process signal handlers (SIGTERM, SIGINT).
   */
  registerSignalHandlers() {
    if (this._signalHandlersRegistered) return;
    process.on('SIGTERM', () => this.shutdown('SIGTERM'));
    process.on('SIGINT', () => this.shutdown('SIGINT'));
    this._signalHandlersRegistered = true;
  }

  /**
   * Execute graceful shutdown — cleanup all resources in LIFO order.
   * @param {string} [reason] - Why shutdown was triggered
   * @returns {Promise<Object>} Shutdown report
   */
  async shutdown(reason = 'manual') {
    if (this._shutdownInProgress) return;
    this._shutdownInProgress = true;

    const startMs = Date.now();
    const report = { reason, started: startMs, resources: [], errors: [] };

    // LIFO order: last registered → first cleaned up
    const reversed = [...this._resources].reverse();

    for (const resource of reversed) {
      try {
        await Promise.race([
          resource.cleanupFn(),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Drain timeout for ${resource.name}`)), DRAIN_TIMEOUT_MS)
          ),
        ]);
        report.resources.push({ name: resource.name, status: 'cleaned' });
      } catch (err) {
        report.errors.push({ name: resource.name, error: err.message });
      }
    }

    report.totalMs = Date.now() - startMs;
    report.success = report.errors.length === 0;

    return report;
  }
}

export { GRACE_PERIOD_MS, DRAIN_TIMEOUT_MS };
export default GracefulShutdown;
