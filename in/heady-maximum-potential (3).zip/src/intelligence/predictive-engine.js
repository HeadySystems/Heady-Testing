/**
 * PredictiveEngine — Phi-scaled predictive analytics and forecasting
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

const CSL_THRESHOLDS = {
  MINIMUM:  1 - PSI2 * 1,
  LOW:      1 - Math.pow(PSI, 1) * 0.5,
  MEDIUM:   1 - Math.pow(PSI, 2) * 0.5,
  HIGH:     1 - Math.pow(PSI, 3) * 0.5,
  CRITICAL: 1 - Math.pow(PSI, 4) * 0.5,
};

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('predictive-engine');

/**
 * Exponential moving average with phi-decay
 */
function exponentialMovingAverage(values, alpha = PSI) {
  if (values.length === 0) { return []; }
  const ema = [values[0]];
  for (let i = 1; i < values.length; i++) {
    ema.push(alpha * values[i] + (1 - alpha) * ema[i - 1]);
  }
  return ema;
}

/**
 * Phi-scaled linear regression
 */
function linearRegression(values) {
  const n = values.length;
  if (n < FIB[4]) { return { slope: 0, intercept: 0, r_squared: 0, insufficient_data: true }; }

  let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
  for (let i = 0; i < n; i++) {
    sumX += i;
    sumY += values[i];
    sumXY += i * values[i];
    sumX2 += i * i;
  }

  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;

  // R-squared
  const meanY = sumY / n;
  let ssRes = 0, ssTot = 0;
  for (let i = 0; i < n; i++) {
    const predicted = slope * i + intercept;
    ssRes += Math.pow(values[i] - predicted, 2);
    ssTot += Math.pow(values[i] - meanY, 2);
  }
  const rSquared = ssTot === 0 ? 0 : 1 - ssRes / ssTot;

  return { slope, intercept, r_squared: rSquared, n };
}

/**
 * Forecast future values using phi-weighted trend projection
 */
function forecast(values, horizonSteps = FIB[5]) {
  const reg = linearRegression(values);
  if (reg.insufficient_data) { return { predictions: [], ...reg }; }

  const ema = exponentialMovingAverage(values);
  const lastEma = ema[ema.length - 1] || 0;
  const n = values.length;

  const predictions = [];
  for (let h = 1; h <= horizonSteps; h++) {
    const linearPred = reg.slope * (n + h) + reg.intercept;
    const emaPred = lastEma + reg.slope * h * PSI;

    // Phi-weighted blend of linear and EMA predictions
    const blended = linearPred * PSI + emaPred * (1 - PSI);

    // Confidence decays with phi over horizon
    const confidence = Math.max(0, CSL_THRESHOLDS.HIGH - (h / horizonSteps) * PSI2);

    predictions.push({
      step: h,
      predicted: blended,
      confidence,
      linear_component: linearPred,
      ema_component: emaPred,
    });
  }

  return {
    predictions,
    model: { regression: reg, ema_alpha: PSI, blend_weight: PSI },
    horizon: horizonSteps,
  };
}

/**
 * Capacity planning using phi-geometric growth model
 */
function capacityForecast(currentUsage, growthRate, maxCapacity, horizonDays = FIB[8]) {
  const predictions = [];
  let usage = currentUsage;

  for (let day = 1; day <= horizonDays; day++) {
    usage = usage * (1 + growthRate * PSI); // phi-dampened growth
    const utilization = usage / maxCapacity;
    const pressure = utilization < PSI2 ? 'nominal' :
                     utilization < PSI ? 'elevated' :
                     utilization < (1 - PSI * PSI * PSI) ? 'high' : 'critical';

    predictions.push({ day, usage, utilization, pressure });

    if (utilization >= 1) {
      logger.warn('Capacity exhaustion predicted', { day, usage, maxCapacity });
      break;
    }
  }

  const exhaustionDay = predictions.find(p => p.utilization >= 1);
  return {
    predictions,
    exhaustion_day: exhaustionDay ? exhaustionDay.day : null,
    current_utilization: currentUsage / maxCapacity,
    growth_rate: growthRate,
    phi_dampening: PSI,
  };
}

module.exports = {
  exponentialMovingAverage,
  linearRegression,
  forecast,
  capacityForecast,
  CSL_THRESHOLDS,
  PHI, PSI, FIB,
};
