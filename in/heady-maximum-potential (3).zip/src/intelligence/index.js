/**
 * Intelligence Module — Pattern detection, anomaly detection, predictive analytics
 * Heady Systems Inc. — Eric Haywood, Founder
 */
'use strict';

const patternDetector = require('./pattern-detector');
const anomalyDetector = require('./anomaly-detector');
const predictiveEngine = require('./predictive-engine');

module.exports = {
  patternDetector,
  anomalyDetector,
  predictiveEngine,
};
