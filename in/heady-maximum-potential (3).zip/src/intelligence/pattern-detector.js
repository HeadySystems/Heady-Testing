/**
 * PatternDetector — CSL-gated pattern detection in system telemetry
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const PSI2 = PSI * PSI;
const PSI3 = PSI * PSI * PSI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

const CSL_THRESHOLDS = {
  MINIMUM:  1 - PSI2 * 1,
  LOW:      1 - Math.pow(PSI, 1) * 0.5,
  MEDIUM:   1 - Math.pow(PSI, 2) * 0.5,
  HIGH:     1 - Math.pow(PSI, 3) * 0.5,
  CRITICAL: 1 - Math.pow(PSI, 4) * 0.5,
};

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('pattern-detector');

/**
 * Sliding window pattern buffer using Fibonacci-sized ring buffer
 */
class PatternBuffer {
  constructor(size = FIB[10]) { // 55 entries
    this.buffer = new Array(size);
    this.size = size;
    this.head = 0;
    this.count = 0;
  }

  push(entry) {
    this.buffer[this.head] = { ...entry, timestamp: Date.now() };
    this.head = (this.head + 1) % this.size;
    if (this.count < this.size) { this.count += 1; }
  }

  getWindow(windowSize = FIB[8]) { // 21 recent entries
    const entries = [];
    const start = (this.head - Math.min(windowSize, this.count) + this.size) % this.size;
    for (let i = 0; i < Math.min(windowSize, this.count); i++) {
      const idx = (start + i) % this.size;
      if (this.buffer[idx]) { entries.push(this.buffer[idx]); }
    }
    return entries;
  }
}

/**
 * CSL-gated cosine similarity for pattern matching
 */
function cosineSimilarity(a, b) {
  if (a.length !== b.length) {
    logger.warn('Vector dimension mismatch', { a_len: a.length, b_len: b.length });
    return 0;
  }
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

/**
 * CSL gate: soft sigmoid activation
 */
function cslGate(value, cosScore, tau = CSL_THRESHOLDS.MEDIUM, temp = PSI3) {
  return value * (1 / (1 + Math.exp(-(cosScore - tau) / temp)));
}

/**
 * Detect repeating patterns in telemetry stream using phi-harmonic analysis
 */
function detectPatterns(entries, referencePatterns = []) {
  const detected = [];
  const windowSize = FIB[8]; // 21
  const window = entries.slice(-windowSize);

  for (const ref of referencePatterns) {
    if (!ref.embedding || window.length < FIB[4]) { continue; }

    // Create window embedding (simplified: average of entry values)
    const windowEmb = window.map(e => e.value || 0);
    const padded = Array.from({ length: ref.embedding.length }, (_, i) =>
      i < windowEmb.length ? windowEmb[i] : 0
    );

    const similarity = cosineSimilarity(padded, ref.embedding);
    const gatedScore = cslGate(similarity, similarity, CSL_THRESHOLDS.MEDIUM, PSI3);

    if (gatedScore >= CSL_THRESHOLDS.LOW) {
      detected.push({
        pattern: ref.name,
        similarity,
        gated_score: gatedScore,
        confidence: gatedScore >= CSL_THRESHOLDS.HIGH ? 'high' : gatedScore >= CSL_THRESHOLDS.MEDIUM ? 'medium' : 'low',
        window_size: window.length,
      });
    }
  }

  return detected.sort((a, b) => b.gated_score - a.gated_score);
}

/**
 * Frequency analysis using phi-harmonic intervals
 */
function analyzeFrequency(entries, property = 'value') {
  if (entries.length < FIB[5]) { return { insufficient_data: true, minimum_entries: FIB[5] }; }

  const values = entries.map(e => e[property] || 0);
  const mean = values.reduce((s, v) => s + v, 0) / values.length;
  const variance = values.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / values.length;
  const stddev = Math.sqrt(variance);

  // Phi-harmonic frequency bands
  const bands = {
    high_frequency: values.filter(v => Math.abs(v - mean) > stddev * PHI).length,
    medium_frequency: values.filter(v => Math.abs(v - mean) > stddev && Math.abs(v - mean) <= stddev * PHI).length,
    low_frequency: values.filter(v => Math.abs(v - mean) <= stddev).length,
  };

  return {
    mean,
    stddev,
    variance,
    phi_coefficient_of_variation: stddev / (mean || 1) / PHI,
    bands,
    trend: values[values.length - 1] > mean ? 'ascending' : 'descending',
    entries_analyzed: values.length,
  };
}

module.exports = {
  PatternBuffer,
  cosineSimilarity,
  cslGate,
  detectPatterns,
  analyzeFrequency,
  CSL_THRESHOLDS,
  PHI, PSI, FIB,
};
