/**
 * AnomalyDetector — Phi-scaled anomaly detection with CSL confidence scoring
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const PSI2 = PSI * PSI;
const PSI3 = PSI * PSI * PSI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

const CSL_THRESHOLDS = {
  MINIMUM:  1 - PSI2 * 1,
  LOW:      1 - Math.pow(PSI, 1) * 0.5,
  MEDIUM:   1 - Math.pow(PSI, 2) * 0.5,
  HIGH:     1 - Math.pow(PSI, 3) * 0.5,
  CRITICAL: 1 - Math.pow(PSI, 4) * 0.5,
};

// Pressure levels (phi-derived)
const PRESSURE = {
  NOMINAL:  PSI2,          // 0.382
  ELEVATED: PSI,           // 0.618
  HIGH:     1 - PSI3,      // 0.764
  CRITICAL: 1 - PSI * PSI * PSI * PSI, // 0.854
};

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('anomaly-detector');

/**
 * Z-score anomaly detection with phi-scaled thresholds
 */
function detectZScoreAnomalies(values, options = {}) {
  const threshold = options.threshold || PHI; // 1.618 standard deviations
  if (values.length < FIB[5]) { return { anomalies: [], insufficient_data: true }; }

  const mean = values.reduce((s, v) => s + v, 0) / values.length;
  const stddev = Math.sqrt(values.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / values.length);

  if (stddev === 0) { return { anomalies: [], mean, stddev: 0, message: 'No variance detected' }; }

  const anomalies = [];
  for (let i = 0; i < values.length; i++) {
    const zScore = Math.abs(values[i] - mean) / stddev;
    if (zScore > threshold) {
      const severity = zScore > threshold * PHI ? 'critical' :
                       zScore > threshold * (1 + PSI) ? 'high' : 'medium';
      anomalies.push({
        index: i,
        value: values[i],
        z_score: zScore,
        deviation: values[i] - mean,
        severity,
        phi_distance: zScore / PHI,
      });
    }
  }

  return { anomalies, mean, stddev, threshold, phi_factor: PHI, total_checked: values.length };
}

/**
 * Moving average anomaly detection with Fibonacci window
 */
function detectMovingAverageAnomalies(values, options = {}) {
  const windowSize = options.window || FIB[8]; // 21
  const deviationFactor = options.factor || PHI;

  if (values.length < windowSize + FIB[4]) {
    return { anomalies: [], insufficient_data: true, minimum: windowSize + FIB[4] };
  }

  const anomalies = [];
  for (let i = windowSize; i < values.length; i++) {
    const window = values.slice(i - windowSize, i);
    const ma = window.reduce((s, v) => s + v, 0) / windowSize;
    const maStd = Math.sqrt(window.reduce((s, v) => s + Math.pow(v - ma, 2), 0) / windowSize);

    const deviation = Math.abs(values[i] - ma);
    if (deviation > maStd * deviationFactor) {
      anomalies.push({
        index: i,
        value: values[i],
        moving_average: ma,
        deviation,
        deviation_ratio: deviation / (maStd || 1),
        window_size: windowSize,
      });
    }
  }

  return { anomalies, window_size: windowSize, factor: deviationFactor, total_checked: values.length };
}

/**
 * Rate-of-change anomaly detection (sudden spikes/drops)
 */
function detectRateOfChangeAnomalies(values, options = {}) {
  const maxRate = options.max_rate || PHI * PSI; // ~1.0 (100% change)

  if (values.length < FIB[4]) { return { anomalies: [], insufficient_data: true }; }

  const anomalies = [];
  for (let i = 1; i < values.length; i++) {
    const prev = values[i - 1] || 1;
    const rate = Math.abs(values[i] - prev) / Math.abs(prev);
    if (rate > maxRate) {
      anomalies.push({
        index: i,
        value: values[i],
        previous: prev,
        rate_of_change: rate,
        direction: values[i] > prev ? 'spike' : 'drop',
      });
    }
  }

  return { anomalies, max_rate: maxRate, total_checked: values.length };
}

/**
 * Composite anomaly score using phi-weighted fusion
 */
function compositeAnomalyScore(zResult, maResult, rocResult) {
  const weights = { z_score: PSI, moving_average: PSI2, rate_of_change: PSI3 };
  const totalWeight = weights.z_score + weights.moving_average + weights.rate_of_change;

  const zNorm = zResult.anomalies.length / (zResult.total_checked || 1);
  const maNorm = maResult.anomalies.length / (maResult.total_checked || 1);
  const rocNorm = rocResult.anomalies.length / (rocResult.total_checked || 1);

  const composite = (zNorm * weights.z_score + maNorm * weights.moving_average + rocNorm * weights.rate_of_change) / totalWeight;

  const pressure = composite < PRESSURE.NOMINAL ? 'nominal' :
                   composite < PRESSURE.ELEVATED ? 'elevated' :
                   composite < PRESSURE.HIGH ? 'high' : 'critical';

  return {
    score: composite,
    pressure,
    weights,
    breakdown: {
      z_score_anomalies: zResult.anomalies.length,
      moving_average_anomalies: maResult.anomalies.length,
      rate_of_change_anomalies: rocResult.anomalies.length,
    },
  };
}

module.exports = {
  detectZScoreAnomalies,
  detectMovingAverageAnomalies,
  detectRateOfChangeAnomalies,
  compositeAnomalyScore,
  PRESSURE,
  CSL_THRESHOLDS,
  PHI, PSI, FIB,
};
