/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ MCP GATEWAY — Master Control Program                     ║
 * ║  31+ MCP tools, JSON-RPC 2.0, SSE transport, zero-trust          ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib, CSL_THRESHOLDS, PHI_TIMING } from '../../shared/phi-math.js';
import { cslAND } from '../../shared/csl-engine.js';

/** MCP protocol version */
const MCP_VERSION = '2024-11-05';

/** Max tools registered — 42 (6 × 7, close to fib) */
const MAX_TOOLS = 42;

/** Rate limit — fib(16) = 987 requests/hour */
const RATE_LIMIT = fib(16);

/** Connection pool size — fib(8) = 21 */
const POOL_SIZE = fib(8);

/**
 * MCP Tool definition.
 */
class MCPTool {
  constructor({ name, description, inputSchema, handler }) {
    this.name = name;
    this.description = description;
    this.inputSchema = inputSchema;
    this.handler = handler;
    this.callCount = 0;
    this.avgLatencyMs = 0;
    this.lastCalledAt = null;
  }
}

/**
 * MCPGateway — the Master Control Program gateway.
 * Exposes 31+ tools via JSON-RPC 2.0 with SSE streaming.
 */
export class MCPGateway {
  constructor({ telemetry = null } = {}) {
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._tools = new Map();
    /** @private */ this._connections = new Map();
    /** @private */ this._totalRequests = 0;
  }

  /**
   * Register an MCP tool.
   * @param {Object} toolDef - Tool definition
   */
  registerTool(toolDef) {
    if (this._tools.size >= MAX_TOOLS) {
      throw new Error(`MCP gateway at max tool capacity: ${MAX_TOOLS}`);
    }
    this._tools.set(toolDef.name, new MCPTool(toolDef));
  }

  /**
   * Handle a JSON-RPC 2.0 request.
   * @param {Object} request - { jsonrpc: "2.0", method, params, id }
   * @returns {Promise<Object>} JSON-RPC response
   */
  async handleRequest(request) {
    this._totalRequests++;

    if (request.jsonrpc !== '2.0') {
      return this._error(request.id, -32600, 'Invalid Request: must be JSON-RPC 2.0');
    }

    switch (request.method) {
      case 'tools/list':
        return this._success(request.id, { tools: this._listTools() });

      case 'tools/call':
        return this._callTool(request);

      case 'initialize':
        return this._success(request.id, {
          protocolVersion: MCP_VERSION,
          serverInfo: { name: 'HeadyMCP', version: '4.0.0' },
          capabilities: { tools: { listChanged: true } },
        });

      default:
        return this._error(request.id, -32601, `Method not found: ${request.method}`);
    }
  }

  /**
   * List all registered tools.
   * @returns {Object[]}
   */
  _listTools() {
    return [...this._tools.values()].map(t => ({
      name: t.name,
      description: t.description,
      inputSchema: t.inputSchema,
    }));
  }

  /**
   * Call a specific tool.
   * @private
   */
  async _callTool(request) {
    const { name, arguments: args } = request.params || {};
    const tool = this._tools.get(name);

    if (!tool) {
      return this._error(request.id, -32602, `Tool not found: ${name}`);
    }

    const startMs = Date.now();
    try {
      const result = await Promise.race([
        tool.handler(args),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error(`Tool ${name} timeout`)), PHI_TIMING.PHI_5)
        ),
      ]);

      const latencyMs = Date.now() - startMs;
      tool.callCount++;
      tool.avgLatencyMs = tool.avgLatencyMs * PSI + latencyMs * (1 - PSI);
      tool.lastCalledAt = Date.now();

      return this._success(request.id, { content: [{ type: 'text', text: JSON.stringify(result) }] });
    } catch (err) {
      return this._error(request.id, -32000, err.message);
    }
  }

  /** @private */
  _success(id, result) {
    return { jsonrpc: '2.0', id, result };
  }

  /** @private */
  _error(id, code, message) {
    return { jsonrpc: '2.0', id, error: { code, message } };
  }

  /**
   * Get gateway status.
   */
  getStatus() {
    return {
      mcpVersion: MCP_VERSION,
      registeredTools: this._tools.size,
      maxTools: MAX_TOOLS,
      totalRequests: this._totalRequests,
      tools: [...this._tools.values()].map(t => ({
        name: t.name,
        callCount: t.callCount,
        avgLatencyMs: Math.round(t.avgLatencyMs),
      })),
    };
  }
}

export { MCP_VERSION, MAX_TOOLS, RATE_LIMIT };
export default MCPGateway;
