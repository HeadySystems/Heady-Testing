/**
 * DistributedTracer — Trace propagation across service mesh
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const { randomBytes } = require('crypto');

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('distributed-tracer');

/**
 * Generate trace ID (W3C Trace Context compatible)
 */
function generateTraceId() {
  return randomBytes(FIB[7]).toString('hex'); // 16 bytes = 32 hex chars
}

/**
 * Generate span ID
 */
function generateSpanId() {
  return randomBytes(FIB[6]).toString('hex'); // 8 bytes = 16 hex chars
}

/**
 * Span represents a unit of work
 */
class Span {
  constructor(options = {}) {
    this.traceId = options.traceId || generateTraceId();
    this.spanId = generateSpanId();
    this.parentSpanId = options.parentSpanId || null;
    this.name = options.name || 'unknown';
    this.service = options.service || 'unknown';
    this.startTime = Date.now();
    this.endTime = null;
    this.status = 'in_progress';
    this.attributes = options.attributes || {};
    this.events = [];
    this.children = [];
  }

  /**
   * Add event to span
   */
  addEvent(name, attributes = {}) {
    this.events.push({ name, timestamp: Date.now(), attributes });
    return this;
  }

  /**
   * Set attribute
   */
  setAttribute(key, value) {
    this.attributes[key] = value;
    return this;
  }

  /**
   * Create child span
   */
  createChild(name, service) {
    const child = new Span({
      traceId: this.traceId,
      parentSpanId: this.spanId,
      name,
      service: service || this.service,
    });
    this.children.push(child);
    return child;
  }

  /**
   * End span
   */
  end(status = 'ok') {
    this.endTime = Date.now();
    this.status = status;
    const duration = this.endTime - this.startTime;

    logger.info('Span completed', {
      trace_id: this.traceId,
      span_id: this.spanId,
      parent_span_id: this.parentSpanId,
      name: this.name,
      service: this.service,
      duration_ms: duration,
      status: this.status,
      events: this.events.length,
      children: this.children.length,
    });

    return this;
  }

  /**
   * Export to W3C traceparent format
   */
  toTraceparent() {
    const version = '00';
    const flags = '01'; // sampled
    return `${version}-${this.traceId}-${this.spanId}-${flags}`;
  }
}

/**
 * Tracer manages active traces
 */
class DistributedTracer {
  constructor(serviceName) {
    this.serviceName = serviceName;
    this.activeSpans = new Map();
    this.maxActiveSpans = FIB[12]; // 144
  }

  /**
   * Start a new root span
   */
  startSpan(name, options = {}) {
    const span = new Span({
      name,
      service: this.serviceName,
      traceId: options.traceId,
      parentSpanId: options.parentSpanId,
      attributes: options.attributes,
    });

    this.activeSpans.set(span.spanId, span);

    // Enforce max active spans
    if (this.activeSpans.size > this.maxActiveSpans) {
      const oldest = this.activeSpans.keys().next().value;
      const oldSpan = this.activeSpans.get(oldest);
      if (oldSpan) { oldSpan.end('evicted'); }
      this.activeSpans.delete(oldest);
      logger.warn('Evicted oldest span', { evicted: oldest, max: this.maxActiveSpans });
    }

    return span;
  }

  /**
   * Extract trace context from incoming request headers
   */
  extractFromHeaders(headers) {
    const traceparent = headers['traceparent'] || headers['x-trace-id'];
    if (!traceparent) { return {}; }

    const parts = traceparent.split('-');
    if (parts.length >= 3) {
      return { traceId: parts[1], parentSpanId: parts[2] };
    }
    return {};
  }

  /**
   * Inject trace context into outgoing request headers
   */
  injectToHeaders(span, headers = {}) {
    headers['traceparent'] = span.toTraceparent();
    headers['x-trace-id'] = span.traceId;
    headers['x-span-id'] = span.spanId;
    headers['x-service'] = this.serviceName;
    return headers;
  }

  /**
   * Get tracer stats
   */
  stats() {
    return {
      service: this.serviceName,
      active_spans: this.activeSpans.size,
      max_active_spans: this.maxActiveSpans,
    };
  }
}

module.exports = { DistributedTracer, Span, generateTraceId, generateSpanId, PHI, PSI, FIB };
