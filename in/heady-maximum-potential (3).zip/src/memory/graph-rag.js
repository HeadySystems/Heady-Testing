/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ GRAPH RAG — Knowledge Graph + Vector Memory Fusion       ║
 * ║  Multi-hop reasoning over entity-relationship graphs             ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib, CSL_THRESHOLDS } from '../../shared/phi-math.js';
import { cslAND } from '../../shared/csl-engine.js';

/** Max graph depth for multi-hop queries — fib(5) = 5 */
const MAX_HOPS = fib(5);

/** Entity confidence threshold — phiThreshold(1) ≈ 0.691 */
const ENTITY_THRESHOLD = CSL_THRESHOLDS.LOW;

/** Community detection resolution — ψ² ≈ 0.382 */
const LOUVAIN_RESOLUTION = PSI * PSI;

/**
 * GraphNode — entity in the knowledge graph.
 */
class GraphNode {
  constructor(id, label, embedding = null, metadata = {}) {
    this.id = id;
    this.label = label;
    this.embedding = embedding;
    this.metadata = metadata;
    this.community = null;
    this.degree = 0;
  }
}

/**
 * GraphEdge — relationship between two entities.
 */
class GraphEdge {
  constructor(source, target, relation, weight = PSI, metadata = {}) {
    this.source = source;
    this.target = target;
    this.relation = relation;
    this.weight = weight;
    this.metadata = metadata;
  }
}

/**
 * GraphRAG — combines knowledge graph traversal with vector memory
 * for multi-hop reasoning and contextual retrieval.
 */
export class GraphRAG {
  /**
   * @param {Object} options
   * @param {Object} options.vectorMemory - VectorMemory instance
   * @param {Function} [options.extractEntitiesFn] - LLM-based NER function
   * @param {Object} [options.telemetry]
   */
  constructor({ vectorMemory, extractEntitiesFn = null, telemetry = null }) {
    /** @private */ this._vectorMemory = vectorMemory;
    /** @private */ this._extractEntities = extractEntitiesFn;
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._nodes = new Map();
    /** @private */ this._edges = [];
    /** @private */ this._adjacency = new Map(); // node id → [edge]
  }

  /**
   * Ingest a document into the knowledge graph.
   * Extracts entities, builds relationships, and stores in vector memory.
   * @param {string} content - Document text
   * @param {Object} [metadata]
   * @returns {Promise<Object>} Ingestion result
   */
  async ingest(content, metadata = {}) {
    // Store in vector memory
    const memEntry = await this._vectorMemory.store(content, metadata);

    // Extract entities if NER available
    if (this._extractEntities) {
      const entities = await this._extractEntities(content);

      for (const entity of entities) {
        this._addNode(entity.id || entity.name, entity.name, entity.embedding, {
          type: entity.type,
          memoryId: memEntry.id,
        });
      }

      // Build relationships between co-occurring entities
      for (let i = 0; i < entities.length; i++) {
        for (let j = i + 1; j < entities.length; j++) {
          const weight = entities[i].embedding && entities[j].embedding
            ? Math.abs(cslAND(entities[i].embedding, entities[j].embedding))
            : PSI;

          if (weight >= ENTITY_THRESHOLD) {
            this._addEdge(
              entities[i].id || entities[i].name,
              entities[j].id || entities[j].name,
              'co_occurs',
              weight
            );
          }
        }
      }
    }

    return {
      memoryId: memEntry.id,
      nodesAdded: this._nodes.size,
      edgesAdded: this._edges.length,
    };
  }

  /**
   * Query the knowledge graph with multi-hop reasoning.
   * @param {string} query - Natural language query
   * @param {Object} [options]
   * @param {string} [options.mode] - 'local', 'global', or 'hybrid'
   * @param {number} [options.maxHops] - Max traversal depth
   * @returns {Promise<Object>} Query result with context
   */
  async query(query, { mode = 'hybrid', maxHops = MAX_HOPS } = {}) {
    // Step 1: Vector memory search for relevant entries
    const vectorResults = await this._vectorMemory.search(query, { limit: fib(8) });

    // Step 2: Find related entities from vector results
    const seedEntities = new Set();
    for (const vr of vectorResults) {
      const relatedNodes = this._findNodesForMemory(vr.id);
      for (const node of relatedNodes) seedEntities.add(node.id);
    }

    // Step 3: Multi-hop graph traversal
    let graphContext = [];
    if (mode === 'local' || mode === 'hybrid') {
      graphContext = this._localTraversal(seedEntities, maxHops);
    }

    // Step 4: Community-level context for global queries
    let communityContext = [];
    if (mode === 'global' || mode === 'hybrid') {
      communityContext = this._getCommunityContext(seedEntities);
    }

    return {
      vectorResults: vectorResults.map(r => ({
        id: r.id,
        score: r.score,
        content: r.entry?.content?.slice(0, 500),
      })),
      graphContext,
      communityContext,
      mode,
      hops: maxHops,
      totalNodes: this._nodes.size,
      totalEdges: this._edges.length,
    };
  }

  /**
   * Run Louvain community detection.
   * @returns {Object} Community assignments
   */
  detectCommunities() {
    // Simplified Louvain — assign communities based on connected components
    const visited = new Set();
    let communityId = 0;
    const communities = {};

    for (const nodeId of this._nodes.keys()) {
      if (visited.has(nodeId)) continue;

      const component = this._bfs(nodeId);
      communities[communityId] = [];

      for (const memberId of component) {
        visited.add(memberId);
        const node = this._nodes.get(memberId);
        if (node) {
          node.community = communityId;
          communities[communityId].push(memberId);
        }
      }
      communityId++;
    }

    return communities;
  }

  /**
   * Get graph statistics.
   * @returns {Object}
   */
  getStats() {
    return {
      nodes: this._nodes.size,
      edges: this._edges.length,
      avgDegree: this._nodes.size > 0
        ? this._edges.length * 2 / this._nodes.size
        : 0,
    };
  }

  // ─── PRIVATE ───────────────────────────────────────────────────────────────

  /** @private */
  _addNode(id, label, embedding, metadata) {
    if (!this._nodes.has(id)) {
      this._nodes.set(id, new GraphNode(id, label, embedding, metadata));
      this._adjacency.set(id, []);
    }
  }

  /** @private */
  _addEdge(sourceId, targetId, relation, weight) {
    const edge = new GraphEdge(sourceId, targetId, relation, weight);
    this._edges.push(edge);

    if (!this._adjacency.has(sourceId)) this._adjacency.set(sourceId, []);
    if (!this._adjacency.has(targetId)) this._adjacency.set(targetId, []);
    this._adjacency.get(sourceId).push(edge);
    this._adjacency.get(targetId).push(edge);

    const srcNode = this._nodes.get(sourceId);
    const tgtNode = this._nodes.get(targetId);
    if (srcNode) srcNode.degree++;
    if (tgtNode) tgtNode.degree++;
  }

  /** @private */
  _findNodesForMemory(memoryId) {
    const nodes = [];
    for (const node of this._nodes.values()) {
      if (node.metadata.memoryId === memoryId) nodes.push(node);
    }
    return nodes;
  }

  /** @private */
  _localTraversal(seedIds, maxHops) {
    const visited = new Set();
    const context = [];
    let frontier = [...seedIds];

    for (let hop = 0; hop < maxHops && frontier.length > 0; hop++) {
      const nextFrontier = [];
      for (const nodeId of frontier) {
        if (visited.has(nodeId)) continue;
        visited.add(nodeId);

        const node = this._nodes.get(nodeId);
        if (node) {
          context.push({
            id: node.id,
            label: node.label,
            community: node.community,
            hop,
          });
        }

        for (const edge of (this._adjacency.get(nodeId) || [])) {
          const neighbor = edge.source === nodeId ? edge.target : edge.source;
          if (!visited.has(neighbor)) {
            nextFrontier.push(neighbor);
            context.push({
              relation: edge.relation,
              from: edge.source,
              to: edge.target,
              weight: edge.weight,
              hop,
            });
          }
        }
      }
      frontier = nextFrontier;
    }

    return context;
  }

  /** @private */
  _getCommunityContext(seedIds) {
    const communities = new Set();
    for (const id of seedIds) {
      const node = this._nodes.get(id);
      if (node?.community != null) communities.add(node.community);
    }

    const context = [];
    for (const node of this._nodes.values()) {
      if (communities.has(node.community)) {
        context.push({ id: node.id, label: node.label, community: node.community });
      }
    }
    return context;
  }

  /** @private */
  _bfs(startId) {
    const visited = new Set();
    const queue = [startId];
    while (queue.length > 0) {
      const current = queue.shift();
      if (visited.has(current)) continue;
      visited.add(current);
      for (const edge of (this._adjacency.get(current) || [])) {
        const neighbor = edge.source === current ? edge.target : edge.source;
        if (!visited.has(neighbor)) queue.push(neighbor);
      }
    }
    return visited;
  }

  /** @private */
  _emit(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: 'GraphRAG', ...data });
    }
  }
}

export { MAX_HOPS, ENTITY_THRESHOLD, GraphNode, GraphEdge };
export default GraphRAG;
