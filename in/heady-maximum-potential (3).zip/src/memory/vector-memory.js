/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ VECTOR MEMORY — 3D Spatial Vector Memory with pgvector   ║
 * ║  384-dim embeddings, HNSW index, hybrid BM25 + dense search      ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import {
  PHI, PSI, fib, CSL_THRESHOLDS,
} from '../../shared/phi-math.js';
import { cslAND, normalize } from '../../shared/csl-engine.js';

/** Vector dimensions — all-MiniLM-L6-v2 */
const VECTOR_DIM = 384;

/** 3D projection dimensions for spatial memory */
const PROJECTION_DIM = 3;

/** HNSW parameters (Fibonacci-compliant) */
const HNSW_CONFIG = Object.freeze({
  m: fib(9),              // 34 connections per node
  efConstruction: fib(13), // 233 build parameter
  efSearch: fib(11),       // 89 search parameter
});

/** Max results per search — fib(10) = 55 */
const MAX_RESULTS = fib(10);

/** Similarity floor — ψ = 0.618 */
const SIMILARITY_FLOOR = PSI;

/** Rerank top-K — fib(8) = 21 */
const RERANK_TOP_K = fib(8);

/**
 * MemoryEntry — a single entry in vector memory.
 */
class MemoryEntry {
  constructor({ id, content, embedding, metadata = {}, timestamp = Date.now() }) {
    this.id = id;
    this.content = content;
    this.embedding = embedding;           // Float64Array[384]
    this.projection = null;               // Float64Array[3] — 3D spatial projection
    this.metadata = metadata;
    this.timestamp = timestamp;
    this.accessCount = 0;
    this.lastAccessed = timestamp;
  }
}

/**
 * VectorMemory — RAM-first 3D spatial vector memory.
 * This is the "brain" — not the database, not the filesystem.
 * PostgreSQL/pgvector is the backup, not the primary.
 */
export class VectorMemory {
  /**
   * @param {Object} options
   * @param {Function} options.embedFn - Async text → Float64Array[384]
   * @param {Object} [options.pgClient] - PostgreSQL client for persistence
   * @param {Object} [options.telemetry]
   */
  constructor({ embedFn, pgClient = null, telemetry = null }) {
    /** @private */ this._embedFn = embedFn;
    /** @private */ this._pgClient = pgClient;
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._entries = new Map();
    /** @private */ this._projectionMatrix = null;
    /** @private */ this._totalSearches = 0;
    /** @private */ this._totalStores = 0;
  }

  /**
   * Store content in vector memory.
   * @param {string} content - Text content to store
   * @param {Object} [metadata] - Additional metadata
   * @returns {Promise<MemoryEntry>} Stored entry
   */
  async store(content, metadata = {}) {
    const embedding = await this._embedFn(content);
    const id = `mem_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const entry = new MemoryEntry({ id, content, embedding, metadata });
    entry.projection = this._projectTo3D(embedding);

    this._entries.set(id, entry);
    this._totalStores++;

    // Persist to pgvector if available
    if (this._pgClient) {
      await this._persistEntry(entry);
    }

    this._emit('memory.stored', { id, contentLength: content.length });
    return entry;
  }

  /**
   * Search vector memory using hybrid BM25 + dense vector similarity.
   * @param {string} query - Search query
   * @param {Object} [options]
   * @param {number} [options.limit] - Max results (default: fib(10) = 55)
   * @param {number} [options.minScore] - Minimum similarity (default: ψ = 0.618)
   * @param {boolean} [options.rerank] - Enable reranking
   * @returns {Promise<Object[]>} Ranked results
   */
  async search(query, { limit = MAX_RESULTS, minScore = SIMILARITY_FLOOR, rerank = true } = {}) {
    this._totalSearches++;
    const queryEmbedding = await this._embedFn(query);

    // Dense vector search — cosine similarity
    const denseResults = this._denseSearch(queryEmbedding, limit * 2); // Oversample for reranking

    // BM25 text search
    const bm25Results = this._bm25Search(query, limit * 2);

    // Reciprocal Rank Fusion
    const fused = this._reciprocalRankFusion(denseResults, bm25Results);

    // Filter by minimum score
    const filtered = fused.filter(r => r.score >= minScore);

    // Rerank top-K
    const results = rerank
      ? this._rerank(filtered.slice(0, RERANK_TOP_K), queryEmbedding)
      : filtered;

    // Update access counts
    for (const r of results.slice(0, limit)) {
      const entry = this._entries.get(r.id);
      if (entry) {
        entry.accessCount++;
        entry.lastAccessed = Date.now();
      }
    }

    this._emit('memory.searched', { query: query.slice(0, 100), results: results.length });
    return results.slice(0, limit);
  }

  /**
   * Get entries near a 3D spatial coordinate.
   * @param {number[]} point - [x, y, z] in projected space
   * @param {number} radius - Search radius
   * @returns {MemoryEntry[]}
   */
  spatialSearch(point, radius = PHI) {
    const results = [];
    for (const entry of this._entries.values()) {
      if (!entry.projection) continue;
      const dist = Math.sqrt(
        Math.pow(entry.projection[0] - point[0], 2) +
        Math.pow(entry.projection[1] - point[1], 2) +
        Math.pow(entry.projection[2] - point[2], 2)
      );
      if (dist <= radius) {
        results.push({ entry, distance: dist });
      }
    }
    return results.sort((a, b) => a.distance - b.distance);
  }

  /**
   * Get memory statistics.
   * @returns {Object}
   */
  getStats() {
    return {
      totalEntries: this._entries.size,
      totalSearches: this._totalSearches,
      totalStores: this._totalStores,
      vectorDim: VECTOR_DIM,
      projectionDim: PROJECTION_DIM,
      hnswConfig: HNSW_CONFIG,
    };
  }

  // ─── PRIVATE METHODS ───────────────────────────────────────────────────────

  /**
   * Dense vector search using cosine similarity.
   * @private
   */
  _denseSearch(queryEmbedding, limit) {
    const scored = [];
    for (const entry of this._entries.values()) {
      const score = cslAND(queryEmbedding, entry.embedding);
      scored.push({ id: entry.id, score, entry });
    }
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, limit);
  }

  /**
   * Simple BM25-like text search.
   * @private
   */
  _bm25Search(query, limit) {
    const terms = query.toLowerCase().split(/\s+/);
    const scored = [];

    for (const entry of this._entries.values()) {
      const content = entry.content.toLowerCase();
      let score = 0;
      for (const term of terms) {
        const regex = new RegExp(term, 'gi');
        const matches = content.match(regex);
        if (matches) {
          // TF component
          const tf = matches.length / (content.split(/\s+/).length || 1);
          // IDF approximation
          const idf = Math.log(1 + this._entries.size / (1 + this._countDocsWithTerm(term)));
          score += tf * idf;
        }
      }
      if (score > 0) scored.push({ id: entry.id, score, entry });
    }

    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, limit);
  }

  /**
   * Count documents containing a term.
   * @private
   */
  _countDocsWithTerm(term) {
    let count = 0;
    for (const entry of this._entries.values()) {
      if (entry.content.toLowerCase().includes(term)) count++;
    }
    return count;
  }

  /**
   * Reciprocal Rank Fusion to merge dense and BM25 results.
   * RRF(d) = Σ 1 / (k + rank_i(d))  where k = fib(8) = 21
   * @private
   */
  _reciprocalRankFusion(denseResults, bm25Results) {
    const k = fib(8); // 21
    const scores = new Map();

    for (let i = 0; i < denseResults.length; i++) {
      const id = denseResults[i].id;
      const rrfScore = 1 / (k + i + 1);
      scores.set(id, (scores.get(id) || 0) + rrfScore * PSI); // Weight dense by ψ
    }

    for (let i = 0; i < bm25Results.length; i++) {
      const id = bm25Results[i].id;
      const rrfScore = 1 / (k + i + 1);
      scores.set(id, (scores.get(id) || 0) + rrfScore * (1 - PSI)); // Weight BM25 by (1-ψ)
    }

    const results = [];
    for (const [id, score] of scores) {
      const entry = this._entries.get(id);
      if (entry) results.push({ id, score, entry });
    }

    return results.sort((a, b) => b.score - a.score);
  }

  /**
   * Rerank results using direct cosine similarity.
   * @private
   */
  _rerank(results, queryEmbedding) {
    for (const r of results) {
      r.rerankScore = cslAND(queryEmbedding, r.entry.embedding);
    }
    return results.sort((a, b) => b.rerankScore - a.rerankScore);
  }

  /**
   * Project 384-dim embedding to 3D space using PCA-like reduction.
   * @private
   */
  _projectTo3D(embedding) {
    // Simple projection: take evenly spaced slices
    const step = Math.floor(VECTOR_DIM / PROJECTION_DIM);
    const projection = new Float64Array(PROJECTION_DIM);
    for (let d = 0; d < PROJECTION_DIM; d++) {
      let sum = 0;
      const start = d * step;
      const end = Math.min(start + step, VECTOR_DIM);
      for (let i = start; i < end; i++) {
        sum += embedding[i];
      }
      projection[d] = sum / (end - start);
    }
    return projection;
  }

  /**
   * Persist entry to pgvector.
   * @private
   */
  async _persistEntry(entry) {
    if (!this._pgClient) return;
    try {
      await this._pgClient.query(
        `INSERT INTO heady_memories (id, content, embedding, projection, metadata, created_at)
         VALUES ($1, $2, $3, $4, $5, NOW())
         ON CONFLICT (id) DO UPDATE SET embedding = $3, metadata = $5`,
        [entry.id, entry.content, `[${Array.from(entry.embedding).join(',')}]`,
         `[${Array.from(entry.projection).join(',')}]`, JSON.stringify(entry.metadata)]
      );
    } catch (err) {
      this._emit('memory.persist.error', { id: entry.id, error: err.message });
    }
  }

  /** @private */
  _emit(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: 'VectorMemory', ...data });
    }
  }
}

export { VECTOR_DIM, PROJECTION_DIM, HNSW_CONFIG, MAX_RESULTS, SIMILARITY_FLOOR };
export default VectorMemory;
