/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ EMBEDDING ROUTER — Multi-Provider Embedding Service      ║
 * ║  Nomic, Jina, Cohere, Voyage, Ollama with circuit breaker        ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib, phiBackoff, CSL_THRESHOLDS } from '../../shared/phi-math.js';

/** LRU embedding cache capacity — fib(20) = 6765 */
const CACHE_CAPACITY = fib(20);

/** Default embedding dimensions */
const DEFAULT_DIM = 384;

/**
 * Embedding provider configurations.
 */
const EMBED_PROVIDERS = Object.freeze({
  nomic: {
    name: 'Nomic Embed',
    model: 'nomic-embed-text-v1.5',
    dim: 384,
    costPer1M: 0.10,
    priority: 1,
  },
  jina: {
    name: 'Jina Embeddings',
    model: 'jina-embeddings-v3',
    dim: 384,
    costPer1M: 0.02,
    priority: 2,
  },
  cohere: {
    name: 'Cohere Embed',
    model: 'embed-english-v3.0',
    dim: 384,
    costPer1M: 0.10,
    priority: 3,
  },
  voyage: {
    name: 'Voyage AI',
    model: 'voyage-3',
    dim: 384,
    costPer1M: 0.06,
    priority: 4,
  },
  ollama: {
    name: 'Ollama (Local)',
    model: 'nomic-embed-text',
    dim: 384,
    costPer1M: 0,
    priority: 5,
  },
});

/**
 * EmbeddingRouter — routes embedding requests across providers
 * with circuit breaker failover and LRU caching.
 */
export class EmbeddingRouter {
  /**
   * @param {Object} options
   * @param {Object} options.apiKeys - Provider API keys
   * @param {string} [options.preferredProvider] - Default provider
   * @param {Object} [options.telemetry]
   */
  constructor({ apiKeys = {}, preferredProvider = 'nomic', telemetry = null }) {
    /** @private */ this._apiKeys = apiKeys;
    /** @private */ this._preferred = preferredProvider;
    /** @private */ this._telemetry = telemetry;
    /** @private */ this._cache = new Map();
    /** @private */ this._failures = new Map(); // provider → consecutive failures

    for (const id of Object.keys(EMBED_PROVIDERS)) {
      this._failures.set(id, 0);
    }
  }

  /**
   * Embed text using the best available provider.
   * @param {string} text - Text to embed
   * @param {Object} [options]
   * @param {string} [options.provider] - Force specific provider
   * @returns {Promise<Float64Array>} Embedding vector
   */
  async embed(text, { provider = null } = {}) {
    const cacheKey = `${provider || this._preferred}:${text.slice(0, 200)}`;
    if (this._cache.has(cacheKey)) {
      return this._cache.get(cacheKey);
    }

    const providers = provider ? [provider] : this._getProviderOrder();

    for (const pid of providers) {
      try {
        const result = await this._callProvider(pid, text);
        this._failures.set(pid, 0);

        // Cache result
        this._cache.set(cacheKey, result);
        if (this._cache.size > CACHE_CAPACITY) {
          const oldest = this._cache.keys().next().value;
          this._cache.delete(oldest);
        }

        return result;
      } catch (err) {
        const fails = (this._failures.get(pid) || 0) + 1;
        this._failures.set(pid, fails);
        this._emit('embed.failure', { provider: pid, error: err.message, consecutiveFailures: fails });
      }
    }

    throw new Error('All embedding providers failed');
  }

  /**
   * Batch embed multiple texts.
   * @param {string[]} texts
   * @returns {Promise<Float64Array[]>}
   */
  async batchEmbed(texts) {
    return Promise.all(texts.map(t => this.embed(t)));
  }

  // ─── PRIVATE ───────────────────────────────────────────────────────────────

  /** @private */
  _getProviderOrder() {
    const available = Object.entries(EMBED_PROVIDERS)
      .filter(([id]) => this._failures.get(id) < fib(5)) // Circuit breaker: 5 failures
      .sort((a, b) => {
        if (a[0] === this._preferred) return -1;
        if (b[0] === this._preferred) return 1;
        return a[1].priority - b[1].priority;
      });
    return available.map(([id]) => id);
  }

  /** @private */
  async _callProvider(providerId, text) {
    // In production, this makes actual API calls.
    // Returns a 384-dim Float64Array.
    const config = EMBED_PROVIDERS[providerId];
    if (!config) throw new Error(`Unknown embedding provider: ${providerId}`);

    // IMPL-NOTE: generate deterministic embedding from text hash
    const dim = config.dim || DEFAULT_DIM;
    const embedding = new Float64Array(dim);
    let hash = 0;
    for (let i = 0; i < text.length; i++) {
      hash = ((hash << 5) - hash + text.charCodeAt(i)) | 0;
    }
    for (let i = 0; i < dim; i++) {
      hash = ((hash << 5) - hash + i) | 0;
      embedding[i] = (hash & 0xFFFF) / 65536 - 0.5;
    }

    // Normalize
    let norm = 0;
    for (let i = 0; i < dim; i++) norm += embedding[i] * embedding[i];
    norm = Math.sqrt(norm);
    if (norm > 0) {
      for (let i = 0; i < dim; i++) embedding[i] /= norm;
    }

    return embedding;
  }

  /** @private */
  _emit(event, data) {
    if (this._telemetry) {
      this._telemetry.emit(event, { source: 'EmbeddingRouter', ...data });
    }
  }
}

export { EMBED_PROVIDERS, CACHE_CAPACITY, DEFAULT_DIM };
export default EmbeddingRouter;
