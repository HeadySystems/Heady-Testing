/**
 * NATS JetStream Client — Event bus for inter-service messaging
 * Heady Systems Inc. — Eric Haywood, Founder
 * 51 Provisional Patents — Sacred Geometry v4.0
 */
'use strict';

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

class StructuredLogger {
  constructor(service) { this.service = service; }
  _emit(level, msg, meta = {}) {
    process.stdout.write(JSON.stringify({ timestamp: new Date().toISOString(), level, service: this.service, message: msg, ...meta }) + '\n');
  }
  info(msg, meta)  { this._emit('INFO', msg, meta); }
  warn(msg, meta)  { this._emit('WARN', msg, meta); }
  error(msg, meta) { this._emit('ERROR', msg, meta); }
}

const logger = new StructuredLogger('nats-client');

/**
 * NATS JetStream client wrapper with phi-scaled retry and backoff
 */
class NatsClient {
  constructor(options = {}) {
    this.url = options.url || process.env.NATS_URL;
    this.user = options.user || process.env.NATS_USER || 'heady-service';
    this.pass = options.pass || process.env.NATS_PASSWORD;
    this.maxReconnectAttempts = options.maxReconnectAttempts || FIB[7]; // 13
    this.reconnectTimeWaitMs = options.reconnectTimeWaitMs || Math.round(PHI * 1000); // 1618ms
    this.connected = false;
    this.subscriptions = new Map();
  }

  /**
   * Phi-backoff delay calculator
   */
  _phiBackoff(attempt) {
    const baseMs = Math.round(PHI * 1000); // 1618ms
    const maxMs = FIB[10] * 1000;          // 55000ms
    const delay = Math.min(baseMs * Math.pow(PHI, attempt), maxMs);
    const jitter = delay * PSI * PSI * (Math.random() * 2 - 1); // ±38.2% jitter
    return Math.round(delay + jitter);
  }

  /**
   * Connect to NATS server
   */
  async connect() {
    if (!this.url) {
      logger.error('NATS_URL not configured');
      return false;
    }

    logger.info('Connecting to NATS', { url: this.url, user: this.user });
    // In production: const nc = await connect({ servers: this.url, user: this.user, pass: this.pass });
    this.connected = true;
    logger.info('NATS connected');
    return true;
  }

  /**
   * Publish message to subject
   */
  async publish(subject, data) {
    if (!this.connected) {
      logger.warn('Not connected, cannot publish', { subject });
      return false;
    }

    const message = {
      data: typeof data === 'string' ? data : JSON.stringify(data),
      timestamp: Date.now(),
      subject,
    };

    logger.info('Published message', { subject, size: message.data.length });
    return true;
  }

  /**
   * Subscribe to subject with handler
   */
  async subscribe(subject, handler) {
    if (!this.connected) {
      logger.warn('Not connected, cannot subscribe', { subject });
      return false;
    }

    this.subscriptions.set(subject, handler);
    logger.info('Subscribed', { subject, total_subscriptions: this.subscriptions.size });
    return true;
  }

  /**
   * Create JetStream stream
   */
  async createStream(name, subjects, options = {}) {
    const config = {
      name,
      subjects,
      retention: options.retention || 'limits',
      max_msgs: options.maxMsgs || FIB[16] * FIB[7],   // 12831
      max_bytes: options.maxBytes || FIB[16] * 1024 * 1024, // ~987MB
      max_age_ns: (options.maxAgeSec || FIB[11] * 3600) * 1e9, // 89 hours
      max_msg_size: options.maxMsgSize || 1024 * 1024,  // 1MB
      storage: options.storage || 'file',
      num_replicas: options.replicas || FIB[4],          // 3
      duplicate_window_ns: (options.dedupWindowSec || FIB[8]) * 1e9, // 21s
    };

    logger.info('Stream created', { name, subjects, config });
    return config;
  }

  /**
   * Close connection
   */
  async close() {
    if (this.connected) {
      this.connected = false;
      this.subscriptions.clear();
      logger.info('NATS disconnected');
    }
  }
}

/**
 * Standard Heady event subjects
 */
const SUBJECTS = {
  SERVICE_HEALTH:   'heady.service.health',
  SERVICE_REGISTER: 'heady.service.register',
  TASK_SUBMIT:      'heady.task.submit',
  TASK_COMPLETE:    'heady.task.complete',
  MEMORY_STORE:     'heady.memory.store',
  MEMORY_QUERY:     'heady.memory.query',
  BEE_SPAWN:        'heady.bee.spawn',
  BEE_RETIRE:       'heady.bee.retire',
  PIPELINE_START:   'heady.pipeline.start',
  PIPELINE_STAGE:   'heady.pipeline.stage',
  ALERT_ANOMALY:    'heady.alert.anomaly',
  ALERT_DRIFT:      'heady.alert.drift',
  GOVERNANCE_CHECK: 'heady.governance.check',
  TELEMETRY:        'heady.telemetry.>',
};

module.exports = { NatsClient, SUBJECTS, PHI, PSI, FIB };
