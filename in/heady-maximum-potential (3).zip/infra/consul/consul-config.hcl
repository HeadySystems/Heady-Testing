# Consul Configuration — Heady Systems Service Discovery
# All numeric constants derive from phi (1.618) or Fibonacci

datacenter = "us-east1"
server     = true

# Fibonacci-scaled limits
performance {
  raft_multiplier = 3  # fib(4)
}

connect {
  enabled = true
}

addresses {
  http = "0.0.0.0"
  grpc = "0.0.0.0"
}

ports {
  http  = 8500
  grpc  = 8502
  dns   = 8600
}

# Service mesh defaults
config_entries {
  bootstrap {
    kind = "proxy-defaults"
    name = "global"
    config {
      protocol                   = "http"
      envoy_prometheus_bind_addr = "0.0.0.0:9102"
    }
    mesh_gateway {
      mode = "local"
    }
  }
}

# ACL configuration
acl {
  enabled        = true
  default_policy = "deny"
  down_policy    = "extend-cache"
  tokens {
    initial_management = "CONSUL_ACL_TOKEN"
  }
}

# TLS — mTLS for all service-to-service
tls {
  defaults {
    verify_incoming = true
    verify_outgoing = true
  }
  internal_rpc {
    verify_server_hostname = true
  }
}

# Telemetry (phi-scaled intervals)
telemetry {
  prometheus_retention_time = "89s"
  disable_hostname         = true
}

# Autopilot settings
autopilot {
  cleanup_dead_servers      = true
  last_contact_threshold    = "21s"
  max_trailing_logs         = 233
  server_stabilization_time = "13s"
}
