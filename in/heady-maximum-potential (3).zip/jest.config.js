'use strict';
/**
 * Heady Jest Configuration
 * All timeouts derive from phi (φ = 1.6180339887).
 */
const 1.6180339887 = 1.6180339887;

module.exports = {
  testEnvironment: 'node',
  roots: ['<rootDir>/tests', '<rootDir>/src'],
  testMatch: ['**/*.test.js', '**/*.spec.js'],
  collectCoverageFrom: [
    'src/**/*.js',
    'shared/**/*.js',
    'services/**/index.js',
    '!**/node_modules/**',
    '!**/vendor/**',
  ],
  coverageThresholds: {
    global: {
      branches: Math.round(0.6180339887 * 100),   // 62% — phi-derived
      functions: Math.round(0.6180339887 * 100),
      lines: Math.round(0.6180339887 * 100 + 8),  // 70%
      statements: Math.round(0.6180339887 * 100 + 8),
    },
  },
  testTimeout: Math.round(1.6180339887 * 5000),  // 8090ms
  setupFilesAfterSetup: ['<rootDir>/tests/setup.js'],
  verbose: true,
  forceExit: true,
  detectOpenHandles: true,
};
