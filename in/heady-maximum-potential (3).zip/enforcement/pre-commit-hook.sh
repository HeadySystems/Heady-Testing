#!/usr/bin/env bash
# Heady Pre-Commit Hook — Enforces the 8 Unbreakable Laws
# Install: cp enforcement/pre-commit-hook.sh .husky/pre-commit && chmod +x .husky/pre-commit

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m'

STAGED_JS=$(git diff --cached --name-only --diff-filter=ACM | grep -E '\.js$' || true)
VIOLATIONS=0

if [ -n "$STAGED_JS" ]; then
    echo "Running Heady Law Enforcement on staged files..."

    # LAW-02: No console.log
    if echo "$STAGED_JS" | xargs grep -l 'console\.log(' 2>/dev/null | grep -v '.test.js' | grep -v '.spec.js'; then
        echo -e "${RED}LAW-02 VIOLATION: console.log found. Use structured JSON logging.${NC}"
        VIOLATIONS=$((VIOLATIONS + 1))
    fi

    # LAW-04: No TODOs/stubs
    if echo "$STAGED_JS" | xargs grep -l 'TODO\|FIXME\|STUB\|PLACEHOLDER' 2>/dev/null; then
        echo -e "${RED}LAW-04 VIOLATION: TODO/FIXME/STUB/PLACEHOLDER found.${NC}"
        VIOLATIONS=$((VIOLATIONS + 1))
    fi

    # LAW-04: No empty catch blocks
    if echo "$STAGED_JS" | xargs grep -Pl 'catch\s*\([^)]*\)\s*\{\s*\}' 2>/dev/null; then
        echo -e "${RED}LAW-04 VIOLATION: Empty catch block found.${NC}"
        VIOLATIONS=$((VIOLATIONS + 1))
    fi

    # LAW-05: No localhost
    if echo "$STAGED_JS" | xargs grep -l 'localhost' 2>/dev/null | grep -v '.test.js' | grep -v '.spec.js'; then
        echo -e "${RED}LAW-05 VIOLATION: localhost reference found. Use env vars.${NC}"
        VIOLATIONS=$((VIOLATIONS + 1))
    fi
fi

if [ "$VIOLATIONS" -gt 0 ]; then
    echo -e "${RED}$VIOLATIONS law violation(s) detected. Commit blocked.${NC}"
    exit 1
fi

echo -e "${GREEN}All 8 Unbreakable Laws satisfied. Commit approved.${NC}"
