# Heady Systems — Security Model

**Eric Haywood, Founder — Sacred Geometry v4.0**
**Classification: Internal — Do not distribute externally**

## Authentication Flow

```
User → Firebase Auth (Google OAuth / Email / Anonymous)
     → Firebase ID Token
     → auth-relay service (port 3356)
     → Validates ID token with Firebase Admin SDK
     → Creates __Host-heady_session httpOnly cookie
     → Cookie bound to: domain (.headysystems.com), IP hash, UA hash
     → Cross-domain propagation via postMessage relay iframe
```

### Session Security

- **Cookie prefix:** `__Host-` (binds to domain, requires HTTPS, no subdomain override)
- **Cookie flags:** httpOnly, Secure, SameSite=None, Path=/
- **Session binding:** Hash of (IP + User-Agent) stored with session
- **Replay prevention:** Session token includes client binding hash
- **Rotation:** Sessions rotate every 21 hours (phi-scaled from 24h)

### Rate Limits (Fibonacci-scaled)

| Tier | Requests/min | Requests/hour |
|------|-------------|---------------|
| Anonymous | 55 (fib(10)) | 987 (fib(16)) |
| Authenticated | 144 (fib(12)) | 2584 (fib(18)) |
| Enterprise | 233 (fib(12)) | 4181 (fib(19)) |

## Inter-Service Security

- **Envoy mTLS:** Every service-to-service call goes through Envoy sidecar with mutual TLS
- **Service mesh:** Consul for service discovery with health checks
- **Request signing:** HMAC-SHA256 on request body + timestamp + nonce
- **Circuit breakers:** Fibonacci thresholds (13 failures → OPEN, 3 successes → CLOSED)
- **Bulkhead isolation:** 55 concurrent / 89 queued per service (Fibonacci)

## Secret Management

- **Storage:** Google Secret Manager (production) / .env file (development)
- **Rotation:** API keys every 21 days (fib(8)), certificates every 89 days (fib(11))
- **Access:** RBAC with audit trail in structured JSON logs
- **Never in code:** All secrets via environment variables, never hardcoded

## OWASP Top 10 Protections

| # | Threat | Protection |
|---|--------|------------|
| A01 | Broken Access Control | RBAC + CSL-gated permissions + session binding |
| A02 | Cryptographic Failures | TLS 1.3, Ed25519 signing, no MD5/SHA1 |
| A03 | Injection | Parameterized queries, input validation against JSON Schema |
| A04 | Insecure Design | Threat modeling, ADRs, security reviews |
| A05 | Security Misconfiguration | CSP headers, no default credentials, CORS allowlist |
| A06 | Vulnerable Components | Snyk scanning, SBOM generation, Dependabot |
| A07 | Auth Failures | Firebase Auth, httpOnly cookies, rate limiting |
| A08 | Data Integrity | Ed25519 receipt signing, HMAC request signing |
| A09 | Logging Failures | Structured JSON logging, OpenTelemetry, Loki aggregation |
| A10 | SSRF | URL allowlisting, no user-controlled redirects |

## AI-Specific Security

- **Prompt injection defense:** Parameterized prompt templates (no string concatenation)
- **Output validation:** All LLM outputs validated against JSON Schema before downstream use
- **HTML sanitization:** DOMPurify on all LLM-generated HTML
- **Autonomy guardrails:** Operation whitelist (ALLOWED: deploy, update deps, run tests; FORBIDDEN: delete data, rotate prod secrets, modify auth)

## Content Security Policy

```
default-src 'self';
script-src 'self';
style-src 'self' 'unsafe-inline';
img-src 'self' data: https:;
font-src 'self';
connect-src 'self' https://*.headysystems.com;
frame-ancestors 'self' https://*.headysystems.com;
```

## Container Security

- Multi-stage Docker builds with distroless base images (<100MB)
- SBOM generated for every image (CycloneDX format)
- Dependency scanning via Snyk before every build
- No root user in containers

---
*© 2026 HeadySystems Inc. — Eric Haywood — 51 Provisional Patents*
