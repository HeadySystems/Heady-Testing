# Heady Systems — Developer Onboarding Guide

**Eric Haywood, Founder — Sacred Geometry v4.0**
**51 Provisional Patents — Concurrent-Equals Architecture**

Welcome to Heady. This guide gets you from zero to running the full platform in under 5 minutes.

## Prerequisites

- Node.js 20+ (LTS)
- Docker + Docker Compose
- Git
- gcloud CLI (optional, for Cloud Run deployment)

## Quick Start

```bash
git clone https://github.com/HeadyMe/heady.git
cd heady
chmod +x scripts/setup-dev.sh
./scripts/setup-dev.sh
```

This script validates your environment, installs dependencies, pulls Docker images,
and boots infrastructure (pgvector, NATS, Redis, Consul).

## Architecture Overview

Heady is a **sovereign AI operating system** with 59 microservices organized into 9 domains:

| Domain | Services | Port Range | Purpose |
|--------|----------|------------|---------|
| Inference | 5 | 3310-3314 | LLM routing, model gateway, inference |
| Memory | 4 | 3315-3318 | Vector memory, embeddings, graph RAG |
| Agents | 3 | 3319-3321 | Bee factory, hive, federation |
| Orchestration | 8 | 3322-3329 | Conductor, pipeline, soul, chain |
| Security | 4 | 3330-3333 | Guard, governance, secrets |
| Monitoring | 4 | 3334-3337 | Health, eval, maintenance, testing |
| Web | 6 | 3338-3343 | UI, buddy, onboarding, task browser |
| Integration | 12 | 3344-3356 | API gateway, MCP, bots, cloud gateways |
| Specialized | 5 | 3357-3361 | Art, music, autobiographer, CLI |
| Infrastructure | 7 | 3362-3368 | Notifications, analytics, billing, search |

## The 8 Unbreakable Laws

Every line of code must follow these laws:

1. **Thoroughness over speed** — Correctness first
2. **Complete implementation** — No stubs, no TODOs, no placeholders
3. **phi-scaled everything** — All numbers derive from phi/psi/Fibonacci
4. **CSL gates** — Confidence-weighted decisions, not boolean
5. **HeadyAutoContext** — Context middleware on every endpoint
6. **Zero-trust security** — mTLS, httpOnly cookies, no localStorage tokens
7. **Concurrent-equals** — No priorities, no rankings
8. **Sacred Geometry** — phi, Fibonacci, golden spiral inform all design

## Key Concepts

### Phi-Math

Every numeric constant in the system derives from the golden ratio:

```javascript
const PHI = 1.618033988749895;
const PSI = 1 / PHI;           // 0.618
const FIB = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987];
```

- Cache sizes: Fibonacci numbers (34, 55, 89, 144, 233)
- Timeouts: phi-scaled (1618ms, 2618ms, 4236ms)
- Rate limits: Fibonacci per tier (55, 144, 233)
- Backoff: phi-exponential with ±38.2% jitter

### CSL (Continuous Semantic Logic)

Replaces boolean logic with vector space operations:

- AND = cosine similarity
- OR = vector superposition (normalize(a + b))
- NOT = orthogonal projection (a - proj_b(a))
- GATE = sigmoid((cosScore - threshold) / temperature)

### Bee Swarm

Autonomous agent workers following lifecycle: spawn → execute → report → retire.
34+ specialized types. Scaled to 10,000 concurrent (LAW-06).

## Running the Full Stack

```bash
# Start everything
docker compose up

# Start specific domain
docker compose up heady-brain heady-memory api-gateway

# Health check all services
for port in $(seq 3310 3368); do
  echo -n "Port $port: "
  curl -s http://0.0.0.0:$port/health | jq -r .status 2>/dev/null || echo "N/A"
done
```

## Making Changes

1. Create a feature branch: `git checkout -b feat/your-feature`
2. Follow conventional commits: `feat:`, `fix:`, `docs:`, `perf:`, `security:`
3. Run tests: `npm test` in the service directory
4. Lint: `npm run lint`
5. Submit PR — CI/CD runs automatically

## Getting Help

- Architecture decisions: `docs/adr/`
- Service debugging: `services/{name}/DEBUG.md`
- Incident response: `docs/runbooks/`
- Error codes: `ERROR_CODES.md`

---
*© 2026 HeadySystems Inc. — Eric Haywood, Founder — 51 Provisional Patents*
