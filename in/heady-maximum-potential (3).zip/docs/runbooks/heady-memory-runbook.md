        # Runbook: heady-memory

        **Port:** 3316 | **Description:** Vector memory
        **Eric Haywood — Heady Systems Inc.**

        ## Quick Health Check

        ```bash
        curl -s http://0.0.0.0:3316/health | jq .
        curl -s http://0.0.0.0:3316/metrics
        ```

        ## Incident Scenarios


### HNSW Index Corruption
1. Run: REINDEX INDEX CONCURRENTLY idx_vector_memory_hnsw;
2. Verify with: SELECT count(*) FROM vector_memory WHERE embedding IS NOT NULL;
3. If still failing: rebuild index with m=21, ef_construction=144
4. Notify heady-maintenance service for automated healing

### Connection Pool Exhausted
1. Check PgBouncer stats: docker exec heady-pgbouncer pgbouncer "SHOW POOLS"
2. Current pool: default_pool_size=34, max_client_conn=233
3. If at max: increase reserve_pool_size from 13 to 21
4. Long term: implement read replicas (CQRS pattern)


        ## Post-Incident Review Template

        1. **Timeline:** When did the issue start/end?
        2. **Impact:** Which services/users were affected?
        3. **Root Cause:** What failed and why?
        4. **Detection:** How was the issue detected (automated alert or manual)?
        5. **Resolution:** What fixed it?
        6. **Prevention:** What changes prevent recurrence?
        7. **Phi-Compliance:** Were all numeric constants still phi-derived?

        ---
        *Sacred Geometry v4.0 — Auto-recovery targets: phi-backoff, fib-sized pools*
