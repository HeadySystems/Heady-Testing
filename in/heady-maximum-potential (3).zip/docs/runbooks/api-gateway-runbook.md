        # Runbook: api-gateway

        **Port:** 3345 | **Description:** API gateway
        **Eric Haywood — Heady Systems Inc.**

        ## Quick Health Check

        ```bash
        curl -s http://0.0.0.0:3345/health | jq .
        curl -s http://0.0.0.0:3345/metrics
        ```

        ## Incident Scenarios


### 502 Bad Gateway
1. Check upstream service health: curl http://0.0.0.0:3334/health
2. Verify Envoy cluster config for target service
3. Check NATS connectivity: docker logs heady-nats
4. If widespread: check Consul service discovery

### Rate Limit Cascade
1. Check rate limiter state: curl http://0.0.0.0:3345/health | jq .bulkhead
2. Verify per-tier limits: 55 anon, 144 auth, 233 enterprise
3. If legitimate spike: temporarily increase to next Fibonacci tier
4. Add IP to allowlist for trusted services


        ## Post-Incident Review Template

        1. **Timeline:** When did the issue start/end?
        2. **Impact:** Which services/users were affected?
        3. **Root Cause:** What failed and why?
        4. **Detection:** How was the issue detected (automated alert or manual)?
        5. **Resolution:** What fixed it?
        6. **Prevention:** What changes prevent recurrence?
        7. **Phi-Compliance:** Were all numeric constants still phi-derived?

        ---
        *Sacred Geometry v4.0 — Auto-recovery targets: phi-backoff, fib-sized pools*
