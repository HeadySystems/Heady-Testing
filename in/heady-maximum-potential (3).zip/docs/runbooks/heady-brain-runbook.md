        # Runbook: heady-brain

        **Port:** 3310 | **Description:** LLM inference
        **Eric Haywood — Heady Systems Inc.**

        ## Quick Health Check

        ```bash
        curl -s http://0.0.0.0:3310/health | jq .
        curl -s http://0.0.0.0:3310/metrics
        ```

        ## Incident Scenarios


### 503 Service Unavailable
1. Check LLM provider status (Anthropic, OpenAI, Google, Groq)
2. Verify circuit breaker state: curl http://0.0.0.0:3310/health | jq .circuit_breaker
3. If OPEN: wait 4236ms for auto-recovery to HALF_OPEN
4. If all providers down: enable cached response fallback
5. Scale to min-instances=2 on Cloud Run for redundancy

### High Latency (>2618ms)
1. Check current model routing: curl http://0.0.0.0:3310/info
2. Switch to faster model (Groq for speed, GPT-4o-mini for cost)
3. Reduce prompt size below 987 tokens (fib(16))
4. Check NATS backpressure on heady.inference.* subjects


        ## Post-Incident Review Template

        1. **Timeline:** When did the issue start/end?
        2. **Impact:** Which services/users were affected?
        3. **Root Cause:** What failed and why?
        4. **Detection:** How was the issue detected (automated alert or manual)?
        5. **Resolution:** What fixed it?
        6. **Prevention:** What changes prevent recurrence?
        7. **Phi-Compliance:** Were all numeric constants still phi-derived?

        ---
        *Sacred Geometry v4.0 — Auto-recovery targets: phi-backoff, fib-sized pools*
