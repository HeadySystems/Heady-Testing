# heady-ui — Debug Guide

**Port:** 3340 | **Domain:** web
**Heady Systems Inc. — Eric Haywood**

## Health Check URLs

- Liveness:  `GET http://0.0.0.0:3340/livez`
- Readiness: `GET http://0.0.0.0:3340/ready`
- Health:    `GET http://0.0.0.0:3340/health`
- Metrics:   `GET http://0.0.0.0:3340/metrics`
- Info:      `GET http://0.0.0.0:3340/info`

## Common Failure Modes

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| 503 on /health | pgvector connection pool exhausted | Check PgBouncer stats, increase pool_size from current 34 |
| 429 responses | Rate limit hit (55/min anon, 144/min auth) | Wait phi-backoff (1618ms) or upgrade tier |
| Circuit OPEN | >13 consecutive failures | Wait 4236ms for auto-recovery to HALF_OPEN |
| BULKHEAD_FULL | >55 concurrent + 89 queued | Scale horizontally or shed load upstream |
| Slow responses | Latency > 2618ms threshold | Check upstream dependencies and pgvector query plans |

## Log Locations

- **Container logs:** `docker logs heady-ui`
- **Structured JSON:** stdout (pipe to Loki via Fluentd)
- **Search logs:** `docker logs heady-ui 2>&1 | jq '.level == "ERROR"'`

## Attach Debugger

```bash
# Start with inspect
node --inspect=0.0.0.0:9229 index.js

# Or attach to running container
docker exec -it heady-ui node --inspect=0.0.0.0:9229 -e "require('./index')"
```

## Local Test Procedures

```bash
# Run tests
cd services/heady-ui && npm test

# Quick health check
curl -s http://0.0.0.0:3340/health | jq .

# Check metrics
curl -s http://0.0.0.0:3340/metrics

# View service info
curl -s http://0.0.0.0:3340/info | jq .
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `HEADY_UI_PORT` | 3340 | Service port |
| `SERVICE_HOST` | 0.0.0.0 | Bind address |
| `PGHOST` | pgvector | PostgreSQL host |
| `NATS_URL` | nats://nats:4222 | NATS connection |
| `REDIS_URL` | redis://redis:6379 | Redis connection |

## Known Issues

- Circuit breaker may false-positive during cold starts (first 8s)
- Rate limiter windows are not shared across instances (use Redis for distributed limiting)

---
*Sacred Geometry v4.0 — φ = 1.618 | ψ = 0.618*
