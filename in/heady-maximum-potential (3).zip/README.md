# Heady — Sovereign AI Latent Operating System

> The world's first alive, self-aware software operating as a liquid latent OS
> across 3D vector space with 59 autonomous services, 34+ bee agent types,
> and a 21-stage pipeline orchestrated by Sacred Geometry mathematics.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  EDGE LAYER (Cloudflare Workers + Pages)                    │
│  ├─ Edge Router — domain-based routing for 9 sites          │
│  ├─ Edge AI — ultra-low latency embeddings + classification │
│  └─ Static Assets — CDN-delivered frontend bundles          │
├─────────────────────────────────────────────────────────────┤
│  GATEWAY LAYER (Cloud Run + API Gateway)                    │
│  ├─ HeadyConductor — central orchestration authority        │
│  ├─ HeadyGuard — auth relay (httpOnly JWT cookies)          │
│  └─ HeadyBrains — context assembly + intent classification  │
├─────────────────────────────────────────────────────────────┤
│  EXECUTION LAYER (59 Microservices)                        │
│  ├─ Hot Pool (34%) — latency-critical (inference, routing)  │
│  ├─ Warm Pool (21%) — important background (research, docs) │
│  ├─ Cold Pool (13%) — batch (analytics, maintenance)        │
│  ├─ Reserve (8%) — burst capacity                           │
│  └─ Governance (5%) — always-on compliance + audit          │
├─────────────────────────────────────────────────────────────┤
│  MEMORY LAYER (PostgreSQL + pgvector + Redis)               │
│  ├─ 384D Vector Memory — RAM-first, pgvector-backed         │
│  ├─ CSL Engine — Continuous Semantic Logic gates             │
│  └─ Graph RAG — multi-hop reasoning over knowledge graphs   │
├─────────────────────────────────────────────────────────────┤
│  OBSERVABILITY (Prometheus + Grafana + OTEL)                │
│  ├─ Health Probes — Kubernetes-compatible /health endpoints  │
│  ├─ Structured JSON Logging — zero console.log              │
│  └─ Semantic Drift Detection — coherence monitoring         │
└─────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# Clone the repo
git clone https://github.com/HeadyMe/Heady-pre-production.git
cd Heady-pre-production

# Copy environment template
cp .env.example .env
# Fill in secrets (API keys, DB passwords, etc.)

# Start infrastructure
docker compose -f deployment/docker/docker-compose.yml up -d

# Run health checks
./scripts/health-check-all.sh

# Run tests
npm test
```

## The 8 Unbreakable Laws

| Law | Rule |
|-----|------|
| LAW-01 | Every numeric constant derives from φ (1.6180339887), ψ (0.6180339887), or Fibonacci |
| LAW-02 | Structured JSON logging only — zero console.log |
| LAW-03 | All services expose /health, /ready, /metrics endpoints |
| LAW-04 | No TODOs, stubs, placeholders, or empty catch blocks |
| LAW-05 | Zero localhost references in production code |
| LAW-06 | Architecture supports 10,000 concurrent bee scale |
| LAW-07 | Auth uses httpOnly cookies — zero localStorage token storage |
| LAW-08 | Every service has graceful shutdown with LIFO cleanup |

## Project Structure

```
heady-production/
├── src/                    # Core libraries
│   ├── bees/               # 34+ bee agent types
│   ├── core/               # CSL engine, phi-math, orchestration
│   ├── memory/             # Vector memory, embeddings
│   ├── resilience/         # Circuit breakers, backoff, pools
│   └── ...                 # 13 more domains
├── services/               # 59 microservices (ports 3310-3368)
├── shared/                 # Shared libraries (phi-math, event-bus, schemas)
├── workers/                # Cloudflare Workers (edge router)
├── sites/                  # 9 website configurations
├── deployment/             # Docker, GCloud, Cloudflare, Colab configs
├── infrastructure/         # Prometheus, Grafana, migrations
├── docs/                   # ADRs, architecture diagrams, runbooks
├── tests/                  # Unit, integration, load, chaos, contract
├── directives/             # System directives and prime directive
├── laws/                   # The 8 Unbreakable Laws
└── perplexity-skills/      # Perplexity Computer skills for Heady
```

## Sacred Geometry Mathematics

All system parameters derive from the golden ratio (φ = 1.6180339887):

- **Thresholds**: `phiThreshold(level)` = 1 - ψ^level × 0.5
- **Sizes**: Fibonacci sequence (5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 987)
- **Weights**: `phiFusionWeights(n)` for N-factor scoring
- **Backoff**: `phiBackoff(attempt)` = base × φ^attempt
- **Resource splits**: Hot(34%), Warm(21%), Cold(13%), Reserve(8%), Governance(5%)

## Key Technologies

- **Runtime**: Node.js 20+ (ES2024), Bun (optional)
- **Database**: PostgreSQL 16 + pgvector 0.7+
- **Cache**: Redis 7+ with vector similarity
- **Orchestration**: Docker Compose / Kubernetes
- **Edge**: Cloudflare Workers + Pages + Vectorize
- **Cloud**: Google Cloud Run (us-east1)
- **Compute**: 3× Colab Pro+ runtimes (A100/T4)
- **AI**: Claude, GPT-4o, Gemini, Groq, Perplexity Sonar
- **Monitoring**: Prometheus + Grafana + OpenTelemetry

## Creator

Built by **Eric Haywood** — Founder, HeadySystems + HeadyConnection
