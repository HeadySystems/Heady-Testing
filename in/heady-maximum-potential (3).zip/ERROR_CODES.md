# Heady Error Code Catalog
> Eric Haywood — Heady Systems Inc. — Sacred Geometry v4.0
> Every error has a unique code, HTTP status, description, and resolution.

## HEADY-AUTH

| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| `HEADY-AUTH-001` | 401 | Invalid or expired session token | Re-authenticate via auth.headysystems.com |
| `HEADY-AUTH-002` | 403 | Insufficient permissions | Request elevated access from administrator |
| `HEADY-AUTH-003` | 429 | Authentication rate limit exceeded | Wait phi-scaled interval before retry |
| `HEADY-AUTH-004` | 401 | Invalid Firebase ID token | Refresh Firebase token and retry |
| `HEADY-AUTH-005` | 403 | Cross-domain session mismatch | Clear cookies and re-authenticate |

## HEADY-BRAIN

| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| `HEADY-BRAIN-001` | 503 | LLM provider unavailable | Circuit breaker engaged; auto-failover to backup provider |
| `HEADY-BRAIN-002` | 408 | Inference timeout exceeded | Reduce prompt size or switch to faster model |
| `HEADY-BRAIN-003` | 429 | Model rate limit reached | Backoff phi-scaled: 1618ms, 2618ms, 4236ms |
| `HEADY-BRAIN-004` | 400 | Invalid prompt template | Validate prompt against schema registry |
| `HEADY-BRAIN-005` | 500 | Model output failed schema validation | Retry with stricter output constraints |

## HEADY-MEMORY

| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| `HEADY-MEMORY-001` | 503 | pgvector connection pool exhausted | PgBouncer will queue; retry after 1618ms |
| `HEADY-MEMORY-002` | 400 | Invalid embedding dimensions (expected 384) | Verify embedding model outputs 384-dim vectors |
| `HEADY-MEMORY-003` | 404 | Vector not found in memory | Check domain filter and reindex if needed |
| `HEADY-MEMORY-004` | 500 | HNSW index corruption detected | Run REINDEX and notify heady-maintenance |
| `HEADY-MEMORY-005` | 429 | Embedding rate limit exceeded | Queue embeddings via NATS JetStream |

## HEADY-GATEWAY

| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| `HEADY-GATEWAY-001` | 502 | Upstream service unreachable | Check service health; Envoy will retry |
| `HEADY-GATEWAY-002` | 429 | API rate limit exceeded (phi-scaled window) | Respect X-RateLimit-Remaining header |
| `HEADY-GATEWAY-003` | 503 | Bulkhead capacity full | Shed load; retry after phi-backoff |
| `HEADY-GATEWAY-004` | 408 | Request timeout (4.236s exceeded) | Optimize request or use async pattern |
| `HEADY-GATEWAY-005` | 400 | Invalid API version | Use supported version from /info endpoint |

## HEADY-BEE

| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| `HEADY-BEE-001` | 500 | Bee spawn failure | Check bee-factory registry for template availability |
| `HEADY-BEE-002` | 408 | Bee execution timeout | Increase timeout or decompose task |
| `HEADY-BEE-003` | 503 | Swarm capacity exceeded (10,000 limit) | Queue via scheduler-service |
| `HEADY-BEE-004` | 500 | Bee retirement cleanup failed | Manual cleanup via ops-bee |
| `HEADY-BEE-005` | 409 | Bee ID conflict in registry | Regenerate bee ID with higher entropy |

## HEADY-PIPELINE

| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| `HEADY-PIPELINE-001` | 500 | HCFullPipeline stage failure | Check stage handler logs; auto-retry engaged |
| `HEADY-PIPELINE-002` | 408 | Pipeline execution timeout (21 stages) | Review stage durations in telemetry |
| `HEADY-PIPELINE-003` | 409 | Pipeline already running for this context | Wait for completion or cancel |
| `HEADY-PIPELINE-004` | 500 | Arena mode scoring failure | Fallback to single-model execution |
| `HEADY-PIPELINE-005` | 400 | Invalid pipeline configuration | Validate against hcfullpipeline-canonical.json |

## HEADY-CSL

| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| `HEADY-CSL-001` | 400 | CSL gate threshold not met | Score below minimum 0.500; improve input quality |
| `HEADY-CSL-002` | 500 | Vector dimension mismatch in CSL operation | Ensure all vectors are 384-dim |
| `HEADY-CSL-003` | 400 | Invalid ternary logic mode | Use: kleene, lukasiewicz, godel, product, or csl-continuous |
| `HEADY-CSL-004` | 500 | HDC codebook overflow (capacity: 96 items at 384-dim) | Increase vector dimensions |
| `HEADY-CSL-005` | 400 | Cosine similarity out of range | Normalize input vectors before CSL operations |

## HEADY-NATS

| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| `HEADY-NATS-001` | 503 | NATS JetStream connection lost | Auto-reconnect with phi-backoff |
| `HEADY-NATS-002` | 500 | Message delivery failed after phi^3 retries | Moved to dead letter queue |
| `HEADY-NATS-003` | 400 | Invalid NATS subject format | Use: heady.{domain}.{action} |
| `HEADY-NATS-004` | 503 | Stream storage limit reached | Purge old messages or increase limit |
| `HEADY-NATS-005` | 500 | Consumer group rebalance in progress | Retry after 1618ms |

