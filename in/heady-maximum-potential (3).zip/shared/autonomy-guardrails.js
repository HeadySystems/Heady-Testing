/**
 * Autonomy Guardrails — Heady Systems
 * Eric Haywood — Sacred Geometry v4.0
 *
 * Defines operation whitelist for autonomous agents.
 * ALLOWED: deploy, update deps, generate configs, run tests
 * FORBIDDEN: delete data, rotate prod secrets, modify auth, change billing
 * All production changes require Git-versioned approval trail.
 */
'use strict';

const crypto = require('crypto');

const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const FIB = [1,1,2,3,5,8,13,21,34,55,89,144,233];

// Operation categories with CSL confidence requirements
const ALLOWED_OPERATIONS = {
  'deploy.staging':           { minConfidence: 0.618, requiresApproval: false, auditLevel: 'INFO'  },
  'deploy.production':        { minConfidence: 0.927, requiresApproval: true,  auditLevel: 'WARN'  },
  'dependencies.update':      { minConfidence: 0.618, requiresApproval: false, auditLevel: 'INFO'  },
  'dependencies.audit':       { minConfidence: 0.500, requiresApproval: false, auditLevel: 'INFO'  },
  'config.generate':          { minConfidence: 0.500, requiresApproval: false, auditLevel: 'INFO'  },
  'config.apply.staging':     { minConfidence: 0.618, requiresApproval: false, auditLevel: 'INFO'  },
  'config.apply.production':  { minConfidence: 0.882, requiresApproval: true,  auditLevel: 'WARN'  },
  'test.run':                 { minConfidence: 0.382, requiresApproval: false, auditLevel: 'DEBUG' },
  'test.generate':            { minConfidence: 0.500, requiresApproval: false, auditLevel: 'INFO'  },
  'observability.configure':  { minConfidence: 0.500, requiresApproval: false, auditLevel: 'INFO'  },
  'docs.generate':            { minConfidence: 0.382, requiresApproval: false, auditLevel: 'DEBUG' },
  'health.check':             { minConfidence: 0.382, requiresApproval: false, auditLevel: 'DEBUG' },
  'scale.horizontal':         { minConfidence: 0.809, requiresApproval: false, auditLevel: 'INFO'  },
  'cache.invalidate':         { minConfidence: 0.618, requiresApproval: false, auditLevel: 'INFO'  },
  'backup.trigger':           { minConfidence: 0.618, requiresApproval: false, auditLevel: 'INFO'  },
  'migration.dry_run':        { minConfidence: 0.618, requiresApproval: false, auditLevel: 'INFO'  },
  'migration.execute':        { minConfidence: 0.927, requiresApproval: true,  auditLevel: 'WARN'  },
};

const FORBIDDEN_OPERATIONS = new Set([
  'data.delete',
  'data.truncate',
  'data.drop_table',
  'secrets.rotate.production',
  'auth.modify_rules',
  'auth.delete_users',
  'billing.modify_plan',
  'billing.process_refund',
  'billing.change_payment',
  'dns.modify_records',
  'certificates.revoke',
  'firewall.modify_rules',
  'iam.modify_permissions',
  'encryption.rotate_master_key',
]);

class AutonomyGuardrails {
  constructor(agentId) {
    this.agentId = agentId;
    this.auditLog = [];
    this.maxAuditSize = FIB[12]; // 233 entries before rotation
  }

  /**
   * Check if an operation is allowed.
   * @param {string} operation - Operation identifier (e.g., 'deploy.staging')
   * @param {number} confidence - CSL confidence score (0-1)
   * @returns {{ allowed: boolean, reason: string, requiresApproval: boolean }}
   */
  check(operation, confidence = 0) {
    const timestamp = new Date().toISOString();

    // Check forbidden list first
    if (FORBIDDEN_OPERATIONS.has(operation)) {
      const entry = {
        timestamp,
        agentId: this.agentId,
        operation,
        confidence,
        result: 'FORBIDDEN',
        reason: 'Operation is on the FORBIDDEN list — requires human approval via Git',
      };
      this._audit(entry);
      return { allowed: false, reason: entry.reason, requiresApproval: true };
    }

    // Check allowed list
    const policy = ALLOWED_OPERATIONS[operation];
    if (!policy) {
      const entry = {
        timestamp,
        agentId: this.agentId,
        operation,
        confidence,
        result: 'UNKNOWN',
        reason: `Operation '${operation}' not in whitelist — denied by default`,
      };
      this._audit(entry);
      return { allowed: false, reason: entry.reason, requiresApproval: true };
    }

    // Check confidence threshold
    if (confidence < policy.minConfidence) {
      const entry = {
        timestamp,
        agentId: this.agentId,
        operation,
        confidence,
        result: 'INSUFFICIENT_CONFIDENCE',
        reason: `Confidence ${confidence.toFixed(3)} below threshold ${policy.minConfidence.toFixed(3)}`,
      };
      this._audit(entry);
      return { allowed: false, reason: entry.reason, requiresApproval: true };
    }

    const entry = {
      timestamp,
      agentId: this.agentId,
      operation,
      confidence,
      result: 'ALLOWED',
      requiresApproval: policy.requiresApproval,
    };
    this._audit(entry);

    return {
      allowed: true,
      reason: policy.requiresApproval ? 'Allowed but requires approval trail' : 'Allowed',
      requiresApproval: policy.requiresApproval,
    };
  }

  /**
   * Generate cryptographic approval hash for audit trail.
   */
  generateApprovalHash(operation, timestamp) {
    const payload = `${this.agentId}:${operation}:${timestamp}`;
    return crypto.createHash('sha256').update(payload).digest('hex');
  }

  _audit(entry) {
    entry.hash = this.generateApprovalHash(entry.operation, entry.timestamp);
    this.auditLog.push(entry);
    process.stdout.write(JSON.stringify({ ...entry, level: entry.result === 'ALLOWED' ? 'INFO' : 'WARN' }) + '\n');

    if (this.auditLog.length > this.maxAuditSize) {
      this.auditLog = this.auditLog.slice(-FIB[11]); // Keep last 144
    }
  }

  getAuditLog() {
    return [...this.auditLog];
  }
}

module.exports = {
  AutonomyGuardrails,
  ALLOWED_OPERATIONS,
  FORBIDDEN_OPERATIONS,
};
