/**
 * HeadyAutoContext — Mandatory Context Middleware (LAW-05)
 * Eric Haywood — Sacred Geometry v4.0
 *
 * Every service, page, and endpoint MUST include this middleware.
 * It injects: correlation ID, service identity, CSL confidence,
 * phi constants, auth context, and telemetry hooks.
 *
 * Unbreakable Law #5: HeadyAutoContext mandatory on all endpoints.
 */
'use strict';

const crypto = require('crypto');

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const PSI2 = PSI * PSI;
const PSI3 = PSI * PSI * PSI;
const FIB  = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987];

const CSL_THRESHOLDS = {
  MINIMUM:  0.500,
  LOW:      1 - PSI * 0.5,
  MEDIUM:   1 - PSI2 * 0.5,
  HIGH:     1 - PSI3 * 0.5,
  CRITICAL: 1 - Math.pow(PSI, 4) * 0.5,
};

/**
 * Generate a correlation ID for distributed tracing.
 * Format: heady-{service}-{timestamp36}-{random}
 */
function generateCorrelationId(serviceName) {
  const ts = Date.now().toString(36);
  const rand = crypto.randomBytes(4).toString('hex');
  return `heady-${serviceName}-${ts}-${rand}`;
}

/**
 * Extract auth context from request.
 * Checks __Host-heady_session cookie first (preferred),
 * then Authorization Bearer header (Firebase ID token).
 * Returns { authenticated, userId, tier, sessionId }.
 */
function extractAuthContext(req) {
  const cookies = parseCookies(req.headers.cookie || '');
  const sessionCookie = cookies['__Host-heady_session'];

  if (sessionCookie) {
    // Session cookie present — validated by auth-relay
    return {
      authenticated: true,
      method: 'session_cookie',
      tier: 'authenticated',
      sessionId: sessionCookie.slice(0, 13),
    };
  }

  const authHeader = req.headers.authorization || '';
  if (authHeader.startsWith('Bearer ')) {
    return {
      authenticated: true,
      method: 'bearer_token',
      tier: 'authenticated',
      tokenPrefix: authHeader.slice(7, 20),
    };
  }

  return {
    authenticated: false,
    method: 'anonymous',
    tier: 'anonymous',
  };
}

function parseCookies(cookieStr) {
  const cookies = {};
  if (!cookieStr) return cookies;
  cookieStr.split(';').forEach(pair => {
    const [key, ...val] = pair.trim().split('=');
    if (key) cookies[key.trim()] = val.join('=').trim();
  });
  return cookies;
}

/**
 * HeadyAutoContext middleware factory.
 *
 * @param {Object} config
 * @param {string} config.service - Service name
 * @param {string} config.domain  - Service domain
 * @param {number} config.port    - Service port
 * @returns {Function} HTTP middleware (req, res, next)
 */
function createAutoContext(config) {
  const { service, domain, port } = config;

  return function headyAutoContext(req, res, next) {
    const startTime = Date.now();

    // 1. Correlation ID (propagate or generate)
    const incomingCorrelation = req.headers['x-correlation-id']
      || req.headers['x-request-id']
      || req.headers['traceparent'];
    const correlationId = incomingCorrelation || generateCorrelationId(service);

    // 2. Auth context
    const auth = extractAuthContext(req);

    // 3. Build context object
    const ctx = {
      correlationId,
      service,
      domain,
      port,
      auth,
      phi: {
        PHI, PSI, PSI2, PSI3,
        thresholds: CSL_THRESHOLDS,
      },
      timing: {
        startTime,
        requestTimeout: Math.round(PHI * PHI * 1000), // 2618ms
      },
      request: {
        method: req.method,
        path: req.url,
        clientIp: req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown',
        userAgent: req.headers['user-agent'] || 'unknown',
      },
    };

    // 4. Attach to request
    req.headyContext = ctx;

    // 5. Set response headers
    res.setHeader('X-Correlation-Id', correlationId);
    res.setHeader('X-Heady-Service', service);
    res.setHeader('X-Heady-Domain', domain);
    res.setHeader('X-Heady-Version', '4.0.0');
    res.setHeader('X-Heady-Phi', PHI.toString());

    // 6. Telemetry hook: log completion on response finish
    res.on('finish', () => {
      const duration = Date.now() - startTime;
      const entry = {
        timestamp: new Date().toISOString(),
        level: res.statusCode >= 500 ? 'ERROR' : res.statusCode >= 400 ? 'WARN' : 'INFO',
        service,
        domain,
        correlationId,
        method: req.method,
        path: req.url,
        status: res.statusCode,
        duration_ms: duration,
        auth_tier: auth.tier,
        csl_gate: duration < Math.round(PHI * PHI * 1000) ? 'PASS' : 'WARN',
      };
      process.stdout.write(JSON.stringify(entry) + '\n');
    });

    // 7. Pass to next handler
    if (typeof next === 'function') {
      next();
    }
  };
}

module.exports = {
  createAutoContext,
  generateCorrelationId,
  extractAuthContext,
  parseCookies,
  PHI, PSI, PSI2, PSI3, FIB, CSL_THRESHOLDS,
};
