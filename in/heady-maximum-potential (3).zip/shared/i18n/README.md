# Heady i18n — Internationalization

All user-facing strings are extracted into JSON files per locale.

## Structure

- `en.json` — English (default)
- Add `es.json`, `fr.json`, `de.json`, `zh.json`, `ja.json` etc. as needed

## Usage

```javascript
const i18n = require('./i18n/en.json');
const label = i18n.auth.sign_in; // "Sign In"
```

## Guidelines

- Never hardcode user-facing strings in components
- Always reference i18n keys
- Keep keys organized by domain (auth, nav, memory, agents, etc.)
- Maximum string length follows Fibonacci: 233 chars for labels, 987 for descriptions
