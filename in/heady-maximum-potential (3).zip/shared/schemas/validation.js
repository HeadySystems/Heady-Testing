'use strict';
/**
 * Heady Schema Validation Library
 * Lightweight JSON Schema validator for inter-service contracts.
 * All limits derive from phi (1.6180339887) / Fibonacci.
 */

const PHI = 1.6180339887;
const PSI = 0.6180339887;
const MAX_DEPTH = 13;      // fib(7)
const MAX_PROPERTIES = 89; // fib(11)
const MAX_ARRAY_LEN = 987; // fib(16)

const log = (level, msg, meta = {}) =>
  process.stdout.write(JSON.stringify({ level, msg, ...meta, ts: new Date().toISOString() }) + '\n');

class ValidationError extends Error {
  constructor(path, message, value) {
    super(`Validation failed at ${path}: ${message}`);
    this.name = 'ValidationError';
    this.path = path;
    this.validationMessage = message;
    this.value = value;
  }
}

function validate(schema, data, path = '$', depth = 0) {
  if (depth > MAX_DEPTH) {
    throw new ValidationError(path, `Max nesting depth (${MAX_DEPTH}) exceeded`, data);
  }

  const errors = [];

  // Type checking
  if (schema.type) {
    const actualType = Array.isArray(data) ? 'array' : typeof data;
    if (schema.type === 'integer') {
      if (!Number.isInteger(data)) {
        errors.push(new ValidationError(path, `Expected integer, got ${actualType}`, data));
      }
    } else if (actualType !== schema.type) {
      errors.push(new ValidationError(path, `Expected ${schema.type}, got ${actualType}`, data));
    }
  }

  // Required fields
  if (schema.required && typeof data === 'object' && data !== null) {
    for (const field of schema.required) {
      if (!(field in data)) {
        errors.push(new ValidationError(`${path}.${field}`, 'Required field missing', undefined));
      }
    }
  }

  // String constraints
  if (schema.type === 'string' && typeof data === 'string') {
    if (schema.minLength !== undefined && data.length < schema.minLength) {
      errors.push(new ValidationError(path, `String too short (min: ${schema.minLength})`, data));
    }
    if (schema.maxLength !== undefined && data.length > schema.maxLength) {
      errors.push(new ValidationError(path, `String too long (max: ${schema.maxLength})`, data));
    }
    if (schema.pattern && !new RegExp(schema.pattern).test(data)) {
      errors.push(new ValidationError(path, `Does not match pattern ${schema.pattern}`, data));
    }
    if (schema.enum && !schema.enum.includes(data)) {
      errors.push(new ValidationError(path, `Must be one of: ${schema.enum.join(', ')}`, data));
    }
  }

  // Number constraints
  if ((schema.type === 'number' || schema.type === 'integer') && typeof data === 'number') {
    if (schema.minimum !== undefined && data < schema.minimum) {
      errors.push(new ValidationError(path, `Below minimum (${schema.minimum})`, data));
    }
    if (schema.maximum !== undefined && data > schema.maximum) {
      errors.push(new ValidationError(path, `Above maximum (${schema.maximum})`, data));
    }
  }

  // Array constraints
  if (schema.type === 'array' && Array.isArray(data)) {
    if (data.length > MAX_ARRAY_LEN) {
      errors.push(new ValidationError(path, `Array exceeds max length (${MAX_ARRAY_LEN})`, data.length));
    }
    if (schema.items) {
      data.forEach((item, i) => {
        errors.push(...validate(schema.items, item, `${path}[${i}]`, depth + 1));
      });
    }
  }

  // Object constraints
  if (schema.type === 'object' && typeof data === 'object' && data !== null) {
    const keys = Object.keys(data);
    if (keys.length > MAX_PROPERTIES) {
      errors.push(new ValidationError(path, `Too many properties (${keys.length} > ${MAX_PROPERTIES})`, keys.length));
    }
    if (schema.properties) {
      for (const [key, propSchema] of Object.entries(schema.properties)) {
        if (key in data) {
          errors.push(...validate(propSchema, data[key], `${path}.${key}`, depth + 1));
        }
      }
    }
  }

  return errors;
}

function assertValid(schema, data) {
  const errors = validate(schema, data);
  if (errors.length > 0) {
    log('error', 'schema_validation_failed', {
      errorCount: errors.length,
      firstError: errors[0].message,
    });
    throw errors[0];
  }
  return true;
}

module.exports = { validate, assertValid, ValidationError, MAX_DEPTH, MAX_PROPERTIES, MAX_ARRAY_LEN };
