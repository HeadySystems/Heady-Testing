#!/usr/bin/env bash
# Health Check All Services — Heady Systems
# Eric Haywood — Sacred Geometry v4.0
# Checks all 59 services and reports status

set -uo pipefail

GREEN="\033[32m"
RED="\033[31m"
YELLOW="\033[33m"
NC="\033[0m"

HOST="${SERVICE_HOST:-0.0.0.0}"
TIMEOUT=3
HEALTHY=0
DEGRADED=0
UNHEALTHY=0
UNREACHABLE=0

echo "╔═══════════════════════════════════════════════════════════╗"
echo "║  Heady Systems — Health Check All (59 Services)          ║"
echo "║  Sacred Geometry v4.0 — φ = 1.618                        ║"
echo "╚═══════════════════════════════════════════════════════════╝"
echo ""

for port in $(seq 3310 3368); do
  RESULT=$(curl -s --connect-timeout $TIMEOUT --max-time $TIMEOUT "http://${HOST}:${port}/health" 2>/dev/null)
  if [ $? -ne 0 ]; then
    printf "  Port %d: ${RED}UNREACHABLE${NC}\n" "$port"
    UNREACHABLE=$((UNREACHABLE + 1))
    continue
  fi

  STATUS=$(echo "$RESULT" | grep -o '"status":"[^"]*"' | cut -d'"' -f4)
  SERVICE=$(echo "$RESULT" | grep -o '"service":"[^"]*"' | cut -d'"' -f4)

  case "$STATUS" in
    healthy)
      printf "  Port %d %-30s ${GREEN}%s${NC}\n" "$port" "$SERVICE" "$STATUS"
      HEALTHY=$((HEALTHY + 1))
      ;;
    degraded)
      printf "  Port %d %-30s ${YELLOW}%s${NC}\n" "$port" "$SERVICE" "$STATUS"
      DEGRADED=$((DEGRADED + 1))
      ;;
    *)
      printf "  Port %d %-30s ${RED}%s${NC}\n" "$port" "${SERVICE:-unknown}" "${STATUS:-unhealthy}"
      UNHEALTHY=$((UNHEALTHY + 1))
      ;;
  esac
done

TOTAL=$((HEALTHY + DEGRADED + UNHEALTHY + UNREACHABLE))
echo ""
echo "══════════════════════════════════════════════════════════════"
printf "  Total: %d | ${GREEN}Healthy: %d${NC} | ${YELLOW}Degraded: %d${NC} | ${RED}Unhealthy: %d${NC} | Unreachable: %d\n" "$TOTAL" "$HEALTHY" "$DEGRADED" "$UNHEALTHY" "$UNREACHABLE"

HEALTH_RATE=$(echo "scale=3; $HEALTHY / $TOTAL" | bc 2>/dev/null || echo "0")
echo "  Health Rate: ${HEALTH_RATE} (target: > 0.618 = ψ)"
echo ""

if [ "$UNHEALTHY" -gt 0 ] || [ "$UNREACHABLE" -gt 13 ]; then
  echo "  ${RED}SYSTEM STATUS: DEGRADED${NC}"
  exit 1
else
  echo "  ${GREEN}SYSTEM STATUS: OPERATIONAL${NC}"
  exit 0
fi
