#!/usr/bin/env bash
# pgvector Backup Restore — Heady Systems
# Eric Haywood — Sacred Geometry v4.0
# Usage: ./backup-restore.sh <backup_file>

set -euo pipefail

BACKUP_FILE="${1:?Usage: backup-restore.sh <backup_file>}"

PGHOST="${PGHOST:-pgvector}"
PGPORT="${PGPORT:-5432}"
PGUSER="${PGUSER:-heady}"
PGDATABASE="${PGDATABASE:-heady}"

echo "Restoring from: ${BACKUP_FILE}"
echo "Target: ${PGHOST}:${PGPORT}/${PGDATABASE}"
echo ""
read -p "This will OVERWRITE the current database. Continue? (yes/no): " confirm
if [ "$confirm" != "yes" ]; then
  echo "Aborted."
  exit 0
fi

pg_restore \
  -h "$PGHOST" \
  -p "$PGPORT" \
  -U "$PGUSER" \
  -d "$PGDATABASE" \
  --clean \
  --if-exists \
  --verbose \
  "$BACKUP_FILE"

echo "Restore complete."
