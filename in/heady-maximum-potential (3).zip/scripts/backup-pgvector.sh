#!/usr/bin/env bash
# pgvector Automated Backup — Heady Systems
# Eric Haywood — Sacred Geometry v4.0
# Schedule: every 21 hours (phi-scaled from 24h)
# Retention: 89 days (fib(11))

set -euo pipefail

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="${BACKUP_DIR:-/backups/pgvector}"
RETENTION_DAYS=89  # fib(11)
GCS_BUCKET="${GCS_BUCKET:-gs://heady-backups-${GCP_PROJECT:-gen-lang-client-0920560496}}"

PGHOST="${PGHOST:-pgvector}"
PGPORT="${PGPORT:-5432}"
PGUSER="${PGUSER:-heady}"
PGDATABASE="${PGDATABASE:-heady}"

log() {
  echo "{\"timestamp\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"level\":\"INFO\",\"service\":\"backup\",\"message\":\"$1\"}"
}

error() {
  echo "{\"timestamp\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"level\":\"ERROR\",\"service\":\"backup\",\"message\":\"$1\"}" >&2
}

mkdir -p "$BACKUP_DIR"

BACKUP_FILE="${BACKUP_DIR}/heady_pgvector_${TIMESTAMP}.sql.gz"

log "Starting pgvector backup to ${BACKUP_FILE}"

# Full database dump with compression
pg_dump \
  -h "$PGHOST" \
  -p "$PGPORT" \
  -U "$PGUSER" \
  -d "$PGDATABASE" \
  --format=custom \
  --compress=8 \
  --verbose \
  --file="${BACKUP_FILE}" 2>&1 || {
    error "pg_dump failed"
    exit 1
  }

BACKUP_SIZE=$(du -h "$BACKUP_FILE" | cut -f1)
log "Backup complete: ${BACKUP_FILE} (${BACKUP_SIZE})"

# Upload to GCS
if command -v gsutil &> /dev/null; then
  gsutil cp "$BACKUP_FILE" "${GCS_BUCKET}/pgvector/${TIMESTAMP}.sql.gz" && \
    log "Uploaded to ${GCS_BUCKET}" || \
    error "GCS upload failed"
fi

# Clean up old local backups (retain fib(11) = 89 days)
find "$BACKUP_DIR" -name "heady_pgvector_*.sql.gz" -mtime +${RETENTION_DAYS} -delete
REMAINING=$(find "$BACKUP_DIR" -name "heady_pgvector_*.sql.gz" | wc -l)
log "Cleanup complete. ${REMAINING} local backups retained (${RETENTION_DAYS}-day retention)"

# Verify backup integrity
pg_restore --list "$BACKUP_FILE" > /dev/null 2>&1 && \
  log "Backup integrity verified" || \
  error "Backup integrity check failed"
