#!/usr/bin/env bash
# setup-dev.sh — Heady Development Environment Setup
# Heady Systems Inc. — Eric Haywood, Founder
# 51 Provisional Patents — Sacred Geometry v4.0
set -euo pipefail

# ── Constants (Fibonacci) ─────────────────────────────────────────
readonly NODE_MIN_VERSION=21
readonly REQUIRED_TOOLS=("node" "npm" "docker" "git" "gcloud" "wrangler")
readonly NATS_PORT=4222
readonly CONSUL_PORT=8500
readonly PGBOUNCER_PORT=6432
readonly OTEL_GRPC_PORT=4317

# ── Colors ────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info()  { echo -e "${BLUE}[INFO]${NC} $1"; }
log_ok()    { echo -e "${GREEN}[OK]${NC} $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# ── Check Prerequisites ──────────────────────────────────────────
check_prerequisites() {
  log_info "Checking prerequisites..."
  local missing=()

  for tool in "${REQUIRED_TOOLS[@]}"; do
    if ! command -v "$tool" &>/dev/null; then
      missing+=("$tool")
    fi
  done

  if [ ${#missing[@]} -gt 0 ]; then
    log_error "Missing tools: ${missing[*]}"
    log_info "Install missing tools and re-run this script."
    exit 1
  fi

  # Check Node.js version
  local node_version
  node_version=$(node -v | sed 's/v//' | cut -d. -f1)
  if [ "$node_version" -lt "$NODE_MIN_VERSION" ]; then
    log_error "Node.js >= $NODE_MIN_VERSION required (found v$node_version)"
    exit 1
  fi

  log_ok "All prerequisites satisfied"
}

# ── Setup Environment ─────────────────────────────────────────────
setup_env() {
  log_info "Setting up environment files..."

  if [ ! -f .env ]; then
    if [ -f .env.example ]; then
      cp .env.example .env
      log_ok "Created .env from .env.example"
    else
      log_warn ".env.example not found, creating minimal .env"
      cat > .env << 'ENVEOF'
NODE_ENV=development
SERVICE_HOST=0.0.0.0
GCP_PROJECT_ID=gen-lang-client-0920560496
GCP_REGION=us-east1
CLOUDFLARE_ACCOUNT_ID=8b1fa38f282c691423c6399247d53323
PGVECTOR_HOST=127.0.0.1
PGVECTOR_PORT=5432
PGVECTOR_DB=heady_dev
PGVECTOR_USER=heady
NATS_URL=nats://127.0.0.1:4222
CONSUL_URL=http://127.0.0.1:8500
OTEL_EXPORTER_OTLP_ENDPOINT=http://127.0.0.1:4317
LOG_LEVEL=debug
ENVEOF
      log_ok "Created minimal .env"
    fi
  else
    log_ok ".env already exists"
  fi
}

# ── Install Dependencies ──────────────────────────────────────────
install_deps() {
  log_info "Installing root dependencies..."
  npm install 2>/dev/null || log_warn "npm install had warnings (may be OK)"
  log_ok "Root dependencies installed"

  log_info "Installing service dependencies..."
  local count=0
  for svc_dir in services/*/; do
    if [ -f "$svc_dir/package.json" ]; then
      (cd "$svc_dir" && npm install 2>/dev/null) || true
      count=$((count + 1))
    fi
  done
  log_ok "$count service dependencies installed"
}

# ── Start Infrastructure ──────────────────────────────────────────
start_infra() {
  log_info "Starting infrastructure services..."

  if command -v docker-compose &>/dev/null || docker compose version &>/dev/null 2>&1; then
    docker compose -f docker-compose.yml up -d postgres nats consul otel-collector 2>/dev/null || {
      log_warn "docker compose up failed — infrastructure may need manual setup"
      return 0
    }
    log_ok "Infrastructure services started"
  else
    log_warn "Docker Compose not available — start infrastructure manually"
  fi
}

# ── Run Health Checks ─────────────────────────────────────────────
run_health_checks() {
  log_info "Running health checks..."
  local healthy=0
  local total=0

  # Check PostgreSQL
  total=$((total + 1))
  if pg_isready -h 127.0.0.1 -p 5432 &>/dev/null; then
    log_ok "PostgreSQL is ready"
    healthy=$((healthy + 1))
  else
    log_warn "PostgreSQL not reachable (may not be started yet)"
  fi

  # Check NATS
  total=$((total + 1))
  if curl -s "http://127.0.0.1:8222/healthz" &>/dev/null; then
    log_ok "NATS is ready"
    healthy=$((healthy + 1))
  else
    log_warn "NATS not reachable"
  fi

  # Check Consul
  total=$((total + 1))
  if curl -s "http://127.0.0.1:8500/v1/status/leader" &>/dev/null; then
    log_ok "Consul is ready"
    healthy=$((healthy + 1))
  else
    log_warn "Consul not reachable"
  fi

  log_info "Health check: $healthy/$total services healthy"
}

# ── Print Summary ─────────────────────────────────────────────────
print_summary() {
  echo ""
  echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
  echo -e "${GREEN}  Heady Development Environment Ready${NC}"
  echo -e "${GREEN}═══════════════════════════════════════════════════════${NC}"
  echo ""
  echo -e "  ${BLUE}Services:${NC}    59 microservices (ports 3310-3368)"
  echo -e "  ${BLUE}PostgreSQL:${NC}  Port 5432 (pgvector)"
  echo -e "  ${BLUE}NATS:${NC}        Port $NATS_PORT (JetStream)"
  echo -e "  ${BLUE}Consul:${NC}      Port $CONSUL_PORT (Service Discovery)"
  echo -e "  ${BLUE}PgBouncer:${NC}   Port $PGBOUNCER_PORT (Connection Pool)"
  echo -e "  ${BLUE}OTEL:${NC}        Port $OTEL_GRPC_PORT (Telemetry)"
  echo ""
  echo -e "  ${YELLOW}Quick start:${NC}"
  echo -e "    make dev          # Start all services"
  echo -e "    make test         # Run test suite"
  echo -e "    make health       # Check all service health"
  echo -e "    make lint         # Lint all code"
  echo ""
  echo -e "  ${BLUE}φ = 1.618 | Sacred Geometry v4.0${NC}"
  echo ""
}

# ── Main ──────────────────────────────────────────────────────────
main() {
  echo ""
  echo -e "${BLUE}╔═══════════════════════════════════════════════════════╗${NC}"
  echo -e "${BLUE}║  Heady Development Environment Setup                 ║${NC}"
  echo -e "${BLUE}║  Heady Systems Inc. — Eric Haywood                   ║${NC}"
  echo -e "${BLUE}║  Sacred Geometry v4.0 — 51 Provisional Patents       ║${NC}"
  echo -e "${BLUE}╚═══════════════════════════════════════════════════════╝${NC}"
  echo ""

  check_prerequisites
  setup_env
  install_deps
  start_infra
  run_health_checks
  print_summary
}

main "$@"
