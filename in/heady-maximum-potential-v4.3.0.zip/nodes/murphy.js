/**
 * MURPHY — Security Analysis & Vulnerability Detection Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Comprehensive security analysis engine providing vulnerability detection,
 * STRIDE threat modeling, compliance checking, and CSL-gated risk scoring.
 * Named after Murphy's Law — if something can go wrong, MURPHY will find it.
 *
 * Ring: Middle | Pool: Hot | Domain: headyme.com
 *
 * @module murphy
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// RISK WEIGHTS — phi-fusion 3-way
// ═══════════════════════════════════════════════════════════════

const RISK_WEIGHTS = phiFusionWeights(3);
// severity ≈ 0.528, exploitability ≈ 0.326, impact ≈ 0.146

// ═══════════════════════════════════════════════════════════════
// STRIDE CATEGORIES
// ═══════════════════════════════════════════════════════════════

const STRIDE = Object.freeze([
  'Spoofing', 'Tampering', 'Repudiation',
  'Information Disclosure', 'Denial of Service', 'Elevation of Privilege',
]);

// ═══════════════════════════════════════════════════════════════
// MURPHY NODE
// ═══════════════════════════════════════════════════════════════

/**
 * MurphyNode — Security auditing, vulnerability detection, threat modeling.
 *
 * Scans code for OWASP Top 10 vulnerabilities, builds STRIDE threat
 * models, checks compliance against standards, and scores risk using
 * CSL-gated phi-fusion 3-way weights (severity, exploitability, impact).
 *
 * @extends LiquidNode
 */
class MurphyNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='MURPHY'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'MURPHY',
      ring: 'middle',
      pool: 'hot',
      domain: 'headyme.com',
      capabilities: [
        'security-audit',
        'vulnerability-detection',
        'threat-modeling',
        'penetration-analysis',
        'compliance-check',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Known threat patterns */
    this.threatDatabase = new Map();

    /** @type {string[]} Vulnerability signature patterns */
    this.vulnerabilityPatterns = [
      'eval(', 'innerHTML', 'dangerouslySetInnerHTML',
      'exec(', 'spawn(', 'SELECT.*FROM.*WHERE',
      'password', 'secret', 'token',
    ];

    /** @type {Map<string, Object>} Compliance rule sets */
    this.complianceRules = new Map();

    this.murphyMetrics = {
      audits: 0,
      vulnerabilitiesFound: 0,
      threatsModeled: 0,
      complianceChecks: 0,
      avgRiskScore: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Classify and route a security task.
   * @param {Object} task
   * @param {string} task.type - audit | detect | threat | compliance
   * @returns {Object} Security analysis result
   */
  async process(task) {
    if (!task || !task.type) {
      throw new HeadyError('MURPHY: task must include a type', 400, 'INVALID_TASK');
    }
    switch (task.type) {
      case 'audit':      return this.auditSecurity(task.code || task);
      case 'detect':     return this.detectVulnerabilities(task.target || task);
      case 'threat':     return this.modelThreats(task.system || task);
      case 'compliance': return this.checkCompliance(task.code, task.standard);
      default:
        throw new HeadyError(`MURPHY: unknown task type: ${task.type}`, 400, 'UNKNOWN_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // SECURITY AUDIT
  // ─────────────────────────────────────────────────────────────

  /**
   * Comprehensive security scan of code.
   * @param {Object|string} code - Code or code descriptor
   * @returns {Object} Audit result with findings and risk score
   */
  auditSecurity(code) {
    const source = typeof code === 'string' ? code : (code.code || code.source || '');
    if (!source) throw new HeadyError('MURPHY: audit requires code', 400, 'MISSING_CODE');

    const vulnerabilities = this._scanForVulnerabilities(source);
    const riskScore = this.scoreRisk(vulnerabilities);

    this.murphyMetrics.audits++;
    this.murphyMetrics.vulnerabilitiesFound += vulnerabilities.length;
    this.metrics.requestsHandled++;
    this.logger.info({ vulns: vulnerabilities.length, risk: riskScore.composite.toFixed(4) }, 'Security audit complete');

    return {
      id: `audit_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      vulnerabilities,
      riskScore,
      passed: riskScore.composite < CSL_THRESHOLDS.MEDIUM,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // VULNERABILITY DETECTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Identify vulnerabilities (CVEs, OWASP Top 10).
   * @param {Object} target - Scan target
   * @param {string} target.code - Code to scan
   * @param {number[]} [target.embedding] - Code embedding
   * @returns {Object} Detection result with classified vulnerabilities
   */
  detectVulnerabilities(target) {
    const code = target.code || '';
    const vulnerabilities = this._scanForVulnerabilities(code);

    // Embedding-based threat matching
    if (target.embedding) {
      for (const [name, threat] of this.threatDatabase) {
        if (threat.embedding) {
          const similarity = cosineSimilarity(target.embedding, threat.embedding);
          const match = cslGate(1.0, similarity, CSL_THRESHOLDS.HIGH);
          if (match > CSL_THRESHOLDS.MINIMUM) {
            vulnerabilities.push({
              type: 'threat-match',
              pattern: name,
              confidence: match,
              severity: threat.severity || PSI,
              category: threat.category || 'unknown',
            });
          }
        }
      }
    }

    this.murphyMetrics.vulnerabilitiesFound += vulnerabilities.length;
    this.metrics.requestsHandled++;
    this.logger.info({ found: vulnerabilities.length }, 'Vulnerabilities detected');

    return { vulnerabilities, total: vulnerabilities.length, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // THREAT MODELING (STRIDE)
  // ─────────────────────────────────────────────────────────────

  /**
   * STRIDE threat modeling for a system.
   * @param {Object} system - System descriptor
   * @param {string} system.name - System name
   * @param {Object[]} [system.components] - System components
   * @param {Object[]} [system.dataFlows] - Data flow descriptors
   * @returns {Object} Threat model with STRIDE-classified threats
   */
  modelThreats(system) {
    const components = system.components || [];
    const dataFlows = system.dataFlows || [];
    const threats = [];
    const weights = phiFusionWeights(STRIDE.length);

    for (let i = 0; i < STRIDE.length; i++) {
      const category = STRIDE[i];
      const likelihood = cslGate(
        weights[i],
        (components.length + dataFlows.length) / fib(8),
        CSL_THRESHOLDS.LOW
      );
      threats.push({
        category,
        likelihood,
        impact: weights[i],
        riskScore: likelihood * weights[i],
        mitigations: [],
      });
    }

    const overallRisk = threats.reduce((s, t) => s + t.riskScore, 0) / threats.length;

    this.murphyMetrics.threatsModeled++;
    this.metrics.requestsHandled++;
    this.logger.info({ system: system.name, threats: threats.length, risk: overallRisk.toFixed(4) }, 'Threats modeled');

    return {
      system: system.name,
      threats,
      overallRisk,
      riskLevel: overallRisk >= CSL_THRESHOLDS.HIGH ? 'critical'
        : overallRisk >= CSL_THRESHOLDS.MEDIUM ? 'high'
          : overallRisk >= CSL_THRESHOLDS.LOW ? 'medium' : 'low',
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // COMPLIANCE CHECK
  // ─────────────────────────────────────────────────────────────

  /**
   * Check code against security standards (OWASP, SOC2, PCI).
   * @param {string} code - Code to check
   * @param {string} standard - Compliance standard name
   * @returns {Object} Compliance result with pass/fail per rule
   */
  checkCompliance(code, standard) {
    if (!code) throw new HeadyError('MURPHY: compliance check requires code', 400, 'MISSING_CODE');
    const standardName = standard || 'OWASP';

    const rules = this.complianceRules.get(standardName) || this._defaultRules(standardName);
    const results = [];

    for (const rule of rules) {
      const violation = rule.pattern && code.includes(rule.pattern);
      const score = violation ? 0 : 1.0;
      const gated = cslGate(score, score, CSL_THRESHOLDS.MEDIUM);
      results.push({ rule: rule.name, passed: !violation, score: gated, category: rule.category });
    }

    const passedCount = results.filter(r => r.passed).length;
    const compliant = passedCount === results.length;

    this.murphyMetrics.complianceChecks++;
    this.metrics.requestsHandled++;
    this.logger.info({ standard: standardName, passed: passedCount, total: results.length }, 'Compliance checked');

    return { standard: standardName, results, compliant, passedCount, totalRules: results.length, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // RISK SCORING
  // ─────────────────────────────────────────────────────────────

  /**
   * CSL-gated risk scoring using phi-fusion 3-way weights.
   * Dimensions: severity × 0.528, exploitability × 0.326, impact × 0.146.
   * @param {Object[]} findings - Vulnerability findings
   * @returns {Object} Risk score breakdown
   */
  scoreRisk(findings) {
    if (findings.length === 0) return { severity: 0, exploitability: 0, impact: 0, composite: 0 };

    const avgSeverity = findings.reduce((s, f) => s + (f.severity || PSI), 0) / findings.length;
    const avgExploitability = findings.reduce((s, f) => s + (f.confidence || PSI * PSI), 0) / findings.length;
    const scaledImpact = Math.min(findings.length / fib(5), 1.0);

    const severity = cslGate(avgSeverity, avgSeverity, CSL_THRESHOLDS.LOW);
    const exploitability = cslGate(avgExploitability, avgExploitability, CSL_THRESHOLDS.LOW);
    const impact = cslGate(scaledImpact, scaledImpact, CSL_THRESHOLDS.LOW);

    const composite =
      severity * RISK_WEIGHTS[0] +
      exploitability * RISK_WEIGHTS[1] +
      impact * RISK_WEIGHTS[2];

    const total = this.murphyMetrics.audits + 1;
    this.murphyMetrics.avgRiskScore =
      (this.murphyMetrics.avgRiskScore * (total - 1) + composite) / total;

    return { severity, exploitability, impact, composite, weights: [...RISK_WEIGHTS] };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  _scanForVulnerabilities(source) {
    const findings = [];
    for (const pattern of this.vulnerabilityPatterns) {
      const idx = source.indexOf(pattern);
      if (idx !== -1) {
        findings.push({
          type: 'pattern-match',
          pattern,
          location: idx,
          severity: pattern.includes('eval') || pattern.includes('exec') ? (1.0 - Math.pow(PSI, 3)) : PSI,
          confidence: CSL_THRESHOLDS.HIGH,
          category: 'owasp',
        });
      }
    }
    return findings;
  }

  _defaultRules(standard) {
    return [
      { name: 'no-eval', pattern: 'eval(', category: 'injection' },
      { name: 'no-innerHTML', pattern: 'innerHTML', category: 'xss' },
      { name: 'no-hardcoded-secrets', pattern: 'password=', category: 'secrets' },
      { name: 'no-exec', pattern: 'exec(', category: 'injection' },
    ];
  }
}

export { MurphyNode, MurphyNode as Murphy };
