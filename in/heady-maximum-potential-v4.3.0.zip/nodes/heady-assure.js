/**
 * HeadyAssure — Deployment Certification & Assurance Gate
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * HeadyAssure certifies deployments through a multi-criteria readiness
 * checklist, assigns certification levels using phi-derived scoring,
 * and maintains rollback plans for every certified artifact. No code
 * ships without HeadyAssure's stamp.
 *
 * Ring: Governance | Pool: Governance | Domain: headyme.com
 *
 * @module heady-assure
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// CERTIFICATION LEVELS (phi-derived thresholds)
// ═══════════════════════════════════════════════════════════════

const CERTIFICATION_LEVELS = Object.freeze({
  CERTIFIED:   CSL_THRESHOLDS.CRITICAL,
  PROVISIONAL: CSL_THRESHOLDS.HIGH,
  CONDITIONAL: CSL_THRESHOLDS.MEDIUM,
  REJECTED:    0,
});

// ═══════════════════════════════════════════════════════════════
// HEADY ASSURE NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyAssureNode — Deployment certification and assurance gate.
 *
 * Evaluates deployment artifacts against a multi-criteria readiness
 * checklist, assigns certification levels, and maintains rollback plans.
 *
 * @extends LiquidNode
 */
class HeadyAssureNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyAssure']
   */
  constructor(config = {}) {
    super({
      name: 'HeadyAssure',
      ring: 'governance',
      pool: 'governance',
      domain: 'headyme.com',
      capabilities: [
        'deployment-certification',
        'assurance-gate',
        'readiness-check',
        'rollback-planning',
        'canary-validation',
      ],
      ...config,
    });

    /** @type {Object[]} Bounded certification log — FIB[9] = 34 max */
    this.certificationLog = [];
    this.maxCertificationLog = FIB[9];

    /** @type {Map<string, Object[]>} Checklist templates by environment */
    this.checklistTemplates = new Map();

    /** @type {Map<string, Object>} Rollback plans by deployment ID */
    this.rollbackPlans = new Map();

    this.certMetrics = {
      totalCertifications: 0,
      certified: 0,
      provisional: 0,
      conditional: 0,
      rejected: 0,
      rollbacksPlanned: 0,
      canaryValidations: 0,
    };

    this._registerDefaultChecklists();
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process an assurance task.
   * @param {Object} task
   * @param {string} task.type - certifyDeployment | checkReadiness | planRollback | validateCanary
   * @returns {Object}
   */
  async process(task) {
    this.metrics.requestsHandled++;
    switch (task.type) {
      case 'certifyDeployment': return this.certifyDeployment(task.artifact, task.environment);
      case 'checkReadiness':    return this.checkReadiness(task.service, task.checklist);
      case 'planRollback':      return this.planRollback(task.deployment);
      case 'validateCanary':    return this.validateCanary(task.metrics);
      default:
        throw new HeadyError(`HeadyAssure: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // DEPLOYMENT CERTIFICATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Certify a deployment artifact for a target environment.
   *
   * Runs the environment checklist, computes a phi-weighted composite
   * score, and assigns a certification level.
   *
   * @param {Object} artifact - Deployment artifact with test/security/config data
   * @param {string} [environment='production'] - Target environment
   * @returns {Object} Certification result with level, score, checklist results
   */
  certifyDeployment(artifact, environment = 'production') {
    if (!artifact) throw new HeadyError('HeadyAssure: artifact is required', 400, 'MISSING_ARTIFACT');

    const checklist = this.checklistTemplates.get(environment) || this.checklistTemplates.get('production');
    const results = [];

    for (const item of checklist) {
      const score = this._evaluateChecklistItem(item, artifact);
      results.push({ item: item.name, score, passed: score >= CSL_THRESHOLDS.MINIMUM });
    }

    const weights = phiFusionWeights(results.length);
    const compositeScore = results.reduce((sum, r, i) => sum + r.score * weights[i], 0);

    let level;
    if (compositeScore >= CERTIFICATION_LEVELS.CERTIFIED) level = 'certified';
    else if (compositeScore >= CERTIFICATION_LEVELS.PROVISIONAL) level = 'provisional';
    else if (compositeScore >= CERTIFICATION_LEVELS.CONDITIONAL) level = 'conditional';
    else level = 'rejected';

    this.certMetrics.totalCertifications++;
    this.certMetrics[level]++;

    const entry = {
      id: `cert_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      level,
      score: compositeScore,
      environment,
      results,
      timestamp: new Date().toISOString(),
    };

    this.certificationLog.push(entry);
    if (this.certificationLog.length > this.maxCertificationLog) this.certificationLog.shift();

    this.logger.info({ level, score: compositeScore.toFixed(4), environment }, 'Deployment certified');
    return entry;
  }

  // ─────────────────────────────────────────────────────────────
  // READINESS CHECK
  // ─────────────────────────────────────────────────────────────

  /**
   * Check service readiness against a checklist.
   * @param {Object} service - Service descriptor with health, tests, security data
   * @param {Object[]} [checklist] - Custom checklist items
   * @returns {Object} Readiness result
   */
  checkReadiness(service, checklist) {
    if (!service) throw new HeadyError('HeadyAssure: service is required', 400, 'MISSING_SERVICE');

    const items = checklist || [
      { name: 'health-endpoint', key: 'healthEndpoint' },
      { name: 'test-coverage', key: 'testCoverage', threshold: CSL_THRESHOLDS.MEDIUM },
      { name: 'security-scan', key: 'securityScan' },
      { name: 'config-validation', key: 'configValid' },
      { name: 'rollback-plan', key: 'rollbackPlan' },
    ];

    const results = items.map(item => {
      const value = service[item.key];
      const passed = typeof value === 'number'
        ? value >= (item.threshold || CSL_THRESHOLDS.MINIMUM)
        : Boolean(value);
      return { item: item.name, passed, value };
    });

    const readyCount = results.filter(r => r.passed).length;
    const readyScore = results.length > 0 ? readyCount / results.length : 0;

    return {
      ready: readyScore >= CSL_THRESHOLDS.MEDIUM,
      score: readyScore,
      passed: readyCount,
      total: results.length,
      results,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // ROLLBACK PLANNING
  // ─────────────────────────────────────────────────────────────

  /**
   * Create a rollback plan for a deployment.
   * @param {Object} deployment - Deployment descriptor
   * @param {string} deployment.id - Deployment ID
   * @param {string} deployment.previousVersion - Version to roll back to
   * @param {string[]} [deployment.services] - Affected services
   * @returns {Object} Rollback plan
   */
  planRollback(deployment) {
    if (!deployment || !deployment.id) {
      throw new HeadyError('HeadyAssure: deployment with id is required', 400, 'MISSING_DEPLOYMENT');
    }

    const plan = {
      id: `rb_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      deploymentId: deployment.id,
      previousVersion: deployment.previousVersion || 'unknown',
      services: deployment.services || [],
      steps: [
        { order: 1, action: 'pause-traffic', description: 'Pause incoming traffic to affected services' },
        { order: 2, action: 'snapshot-state', description: 'Snapshot current state for forensic analysis' },
        { order: 3, action: 'revert-deployment', description: `Revert to version ${deployment.previousVersion || 'previous'}` },
        { order: 4, action: 'verify-health', description: 'Run health checks on reverted services' },
        { order: fib(5), action: 'resume-traffic', description: 'Resume traffic after health verification' },
      ],
      maxRollbackTimeMs: Math.round(fib(8) * 1000 * PHI),
      createdAt: new Date().toISOString(),
    };

    this.rollbackPlans.set(deployment.id, plan);
    this.certMetrics.rollbacksPlanned++;
    this.logger.info({ deploymentId: deployment.id, steps: plan.steps.length }, 'Rollback plan created');
    return plan;
  }

  // ─────────────────────────────────────────────────────────────
  // CANARY VALIDATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Validate canary deployment metrics against baselines.
   * @param {Object} metrics - Canary metrics (errorRate, latencyP99, throughput, successRate)
   * @returns {Object} Canary validation result
   */
  validateCanary(metrics) {
    if (!metrics) throw new HeadyError('HeadyAssure: metrics are required', 400, 'MISSING_METRICS');

    const checks = [];

    if (metrics.errorRate != null) {
      const score = 1.0 - Math.min(metrics.errorRate / PSI, 1.0);
      checks.push({ metric: 'errorRate', value: metrics.errorRate, score, passed: score >= CSL_THRESHOLDS.MEDIUM });
    }
    if (metrics.latencyP99 != null && metrics.baselineLatency != null) {
      const ratio = metrics.latencyP99 / metrics.baselineLatency;
      const score = cslGate(1.0, 1.0 / ratio, CSL_THRESHOLDS.LOW);
      checks.push({ metric: 'latencyP99', value: metrics.latencyP99, score, passed: score >= CSL_THRESHOLDS.MINIMUM });
    }
    if (metrics.successRate != null) {
      const score = metrics.successRate;
      checks.push({ metric: 'successRate', value: metrics.successRate, score, passed: score >= CSL_THRESHOLDS.MEDIUM });
    }

    const weights = phiFusionWeights(Math.max(checks.length, 1));
    const overallScore = checks.length > 0
      ? checks.reduce((sum, c, i) => sum + c.score * weights[i], 0)
      : 0;
    const canaryHealthy = checks.every(c => c.passed);

    this.certMetrics.canaryValidations++;
    this.logger.info({ healthy: canaryHealthy, score: overallScore.toFixed(4) }, 'Canary validated');

    return { healthy: canaryHealthy, score: overallScore, checks, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────────────────

  _evaluateChecklistItem(item, artifact) {
    const value = artifact[item.key];
    if (value === undefined || value === null) return 0;
    if (typeof value === 'boolean') return value ? 1.0 : 0;
    if (typeof value === 'number') return Math.min(Math.max(value, 0), 1.0);
    return CSL_THRESHOLDS.MINIMUM;
  }

  _registerDefaultChecklists() {
    this.checklistTemplates.set('production', [
      { name: 'health-endpoint', key: 'healthEndpoint' },
      { name: 'test-coverage', key: 'testCoverage' },
      { name: 'security-scan', key: 'securityScan' },
      { name: 'config-validation', key: 'configValid' },
      { name: 'rollback-plan', key: 'rollbackPlan' },
    ]);
    this.checklistTemplates.set('staging', [
      { name: 'health-endpoint', key: 'healthEndpoint' },
      { name: 'test-coverage', key: 'testCoverage' },
      { name: 'config-validation', key: 'configValid' },
    ]);
  }
}

export { HeadyAssureNode, HeadyAssureNode as HeadyAssure };
