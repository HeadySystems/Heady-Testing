/**
 * HeadyEmbed — Embedding Generation & Multi-Provider Routing
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Routes embedding requests to the optimal provider using CSL-gated scoring
 * across sovereignty, quality, and cost dimensions. Supports MRL truncation
 * for dimensionality reduction and batch embedding with phi-scaled limits.
 *
 * Ring: Memory | Pool: Hot | Domain: headyme.com
 *
 * @module heady-embed
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiBackoff, phiFusionWeights,
  cslGate, cosineSimilarity, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, CircuitBreaker, createLogger } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// PROVIDER REGISTRY
// ═══════════════════════════════════════════════════════════════

const EMBEDDING_DIM = 384;

const PROVIDERS = Object.freeze([
  { name: 'cloudflare',  model: 'bge-base-en-v1.5', dim: EMBEDDING_DIM, costPerMToken: 0,      sovereignty: 1.0, quality: 0.82, edge: true  },
  { name: 'nomic',       model: 'nomic-embed-v2',   dim: 768,           costPerMToken: 0.05,   sovereignty: 0.7, quality: 0.88, edge: false },
  { name: 'jina',        model: 'jina-v3',          dim: 1024,          costPerMToken: 0.018,  sovereignty: 0.6, quality: 0.91, edge: false },
  { name: 'cohere',      model: 'embed-v4',         dim: 1024,          costPerMToken: 0.1,    sovereignty: 0.5, quality: 0.90, edge: false },
  { name: 'voyage',      model: 'voyage-3',         dim: 1024,          costPerMToken: 0.12,   sovereignty: 0.5, quality: 0.95, edge: false },
  { name: 'ollama',      model: 'nomic-embed-text',  dim: 768,           costPerMToken: 0,      sovereignty: 1.0, quality: 0.80, edge: true  },
]);

/** Phi-derived selection weights: sovereignty × 0.528 + quality × 0.326 + cost × 0.146 */
const SELECTION_WEIGHTS = phiFusionWeights(3);

// ═══════════════════════════════════════════════════════════════
// HEADY EMBED NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyEmbedNode — Multi-provider embedding router with CSL-gated selection,
 * MRL dimensionality reduction, and per-provider circuit breakers.
 *
 * @extends LiquidNode
 */
class HeadyEmbedNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyEmbed'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'HeadyEmbed',
      ring: 'memory',
      pool: 'hot',
      domain: 'headyme.com',
      capabilities: [
        'embedding-generation',
        'multi-provider-routing',
        'dimensionality-reduction',
        'batch-embedding',
        'model-selection',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Provider configurations */
    this.providerRegistry = new Map();
    for (const p of PROVIDERS) this.providerRegistry.set(p.name, { ...p });

    /** @type {Map<string, CircuitBreaker>} Per-provider circuit breakers */
    this.circuitBreakers = new Map();
    for (const p of PROVIDERS) {
      this.circuitBreakers.set(p.name, new CircuitBreaker({
        name: `embed:${p.name}`,
        failureThreshold: SIZING.FAILURE_THRESHOLD,
        resetTimeoutMs: Math.round(phiBackoff(fib(3), 1000, 30000, false)),
      }));
    }

    /** @type {Map<string, Object>} LRU embedding cache bounded by FIB[16]=987 */
    this.embedCache = new Map();

    /** @type {Map<string, Object>} Per-provider metrics */
    this.providerMetrics = new Map();
    for (const p of PROVIDERS) {
      this.providerMetrics.set(p.name, {
        requests: 0, successes: 0, failures: 0, avgLatencyMs: 0,
      });
    }
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process an embedding task.
   * @param {Object} task
   * @param {string} task.type - embed | embedBatch | selectProvider | stats
   * @returns {Promise<Object>}
   */
  async process(task) {
    switch (task.type) {
      case 'embed':          return this.embed(task.text, task.options);
      case 'embedBatch':     return this.embedBatch(task.texts, task.options);
      case 'selectProvider': return this.selectProvider(task.text, task.requirements);
      case 'stats':          return this._stats();
      default:
        throw new Error(`HeadyEmbed: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // EMBED
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate an embedding for a single text, routing to the optimal provider.
   * @param {string} text - Input text
   * @param {Object} [options={}]
   * @param {string} [options.provider] - Force a specific provider
   * @param {number} [options.targetDim] - Target output dimensions (MRL truncation)
   * @returns {Promise<Object>} Embedding result with vector and metadata
   */
  async embed(text, options = {}) {
    if (!text) throw new Error('HeadyEmbed: text is required');

    const cacheKey = `${text.slice(0, fib(8))}:${options.provider || 'auto'}:${options.targetDim || EMBEDDING_DIM}`;
    const cached = this._cacheGet(cacheKey);
    if (cached) return cached;

    const selection = options.provider
      ? { provider: this.providerRegistry.get(options.provider), score: 1.0 }
      : this.selectProvider(text, options);

    const provider = selection.provider;
    const start = Date.now();
    const breaker = this.circuitBreakers.get(provider.name);
    const metrics = this.providerMetrics.get(provider.name);

    let embedding;
    try {
      embedding = await breaker.exec(() => this._callProvider(provider.name, text));
      metrics.requests++;
      metrics.successes++;
      const elapsed = Date.now() - start;
      metrics.avgLatencyMs = (metrics.avgLatencyMs * (metrics.successes - 1) + elapsed) / metrics.successes;
    } catch (err) {
      metrics.requests++;
      metrics.failures++;
      this.logger.error({ provider: provider.name, error: err.message }, 'Embed failed');
      throw err;
    }

    if (options.targetDim && options.targetDim < embedding.length) {
      embedding = this.truncateDimensions(embedding, options.targetDim);
    }

    const result = {
      embedding,
      provider: provider.name,
      model: provider.model,
      dimensions: embedding.length,
      score: selection.score,
      timestamp: new Date().toISOString(),
    };

    this._cacheSet(cacheKey, result);
    this.metrics.requestsHandled++;
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // BATCH EMBED
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate embeddings for a batch of texts. Max batch size = FIB[10] = 55.
   * @param {string[]} texts - Input texts
   * @param {Object} [options={}]
   * @returns {Promise<Object>} Batch result with embeddings array
   */
  async embedBatch(texts, options = {}) {
    if (!texts || texts.length === 0) throw new Error('HeadyEmbed: texts array is required');

    const maxBatch = SIZING.MAX_ENTITIES;
    const batches = [];
    for (let i = 0; i < texts.length; i += maxBatch) {
      batches.push(texts.slice(i, i + maxBatch));
    }

    const allResults = [];
    for (const batch of batches) {
      const batchResults = await Promise.all(
        batch.map(text => this.embed(text, options))
      );
      allResults.push(...batchResults);
    }

    this.logger.info({
      totalTexts: texts.length,
      batches: batches.length,
      maxBatch,
    }, 'Batch embedding complete');

    return {
      embeddings: allResults,
      count: allResults.length,
      batches: batches.length,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // PROVIDER SELECTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Select the optimal embedding provider using CSL-gated scoring.
   * Scores: sovereignty × w[0] + quality × w[1] + costEfficiency × w[2]
   *
   * @param {string} text - Input text for context-aware selection
   * @param {Object} [requirements={}]
   * @param {boolean} [requirements.edgeOnly] - Restrict to edge providers
   * @param {number} [requirements.minQuality] - Minimum quality score
   * @returns {Object} Selected provider with score
   */
  selectProvider(text, requirements = {}) {
    let candidates = [...this.providerRegistry.values()];

    if (requirements.edgeOnly) {
      candidates = candidates.filter(p => p.edge);
    }
    if (requirements.minQuality) {
      candidates = candidates.filter(p => p.quality >= requirements.minQuality);
    }

    // Filter by circuit breaker health
    candidates = candidates.filter(p => this.circuitBreakers.get(p.name).canExecute());

    if (candidates.length === 0) {
      this.logger.warn({}, 'No available providers, falling back to cloudflare');
      return { provider: this.providerRegistry.get('cloudflare'), score: 0 };
    }

    const scored = candidates.map(p => {
      const costEfficiency = p.costPerMToken === 0 ? 1.0 : 1.0 / (1.0 + p.costPerMToken * fib(8));
      const raw = p.sovereignty * SELECTION_WEIGHTS[0] +
                  p.quality * SELECTION_WEIGHTS[1] +
                  costEfficiency * SELECTION_WEIGHTS[2];
      const gated = cslGate(raw, raw, CSL_THRESHOLDS.LOW);
      return { provider: p, score: gated };
    });

    scored.sort((a, b) => b.score - a.score);
    const selected = scored[0];

    this.logger.debug({
      selected: selected.provider.name,
      score: selected.score.toFixed(4),
      candidates: scored.length,
    }, 'Provider selected');

    return selected;
  }

  // ─────────────────────────────────────────────────────────────
  // MRL TRUNCATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Truncate an embedding to a target dimension using Matryoshka Representation Learning.
   * Takes the first targetDim components and re-normalizes.
   *
   * @param {number[]} embedding - Full-dimension embedding
   * @param {number} targetDim - Target dimensionality
   * @returns {number[]} Truncated and re-normalized embedding
   */
  truncateDimensions(embedding, targetDim) {
    if (targetDim >= embedding.length) return embedding;
    const truncated = embedding.slice(0, targetDim);
    const norm = Math.sqrt(truncated.reduce((s, v) => s + v * v, 0));
    return norm > 0 ? truncated.map(v => v / norm) : truncated;
  }

  // ─────────────────────────────────────────────────────────────
  // PROVIDER CALL STUBS
  // ─────────────────────────────────────────────────────────────

  /**
   * Route to the correct provider method. Each returns a mock unit vector
   * with real logging and circuit breaker integration.
   * @param {string} providerName
   * @param {string} text
   * @returns {Promise<number[]>} Embedding vector
   */
  async _callProvider(providerName, text) {
    const provider = this.providerRegistry.get(providerName);
    this.logger.info({
      provider: providerName,
      model: provider.model,
      textLength: text.length,
      nativeDim: provider.dim,
    }, 'Embedding request');

    // Generate deterministic mock embedding from text content
    const vec = new Array(provider.dim);
    let seed = 0;
    for (let i = 0; i < Math.min(text.length, fib(9)); i++) seed += text.charCodeAt(i);
    for (let i = 0; i < provider.dim; i++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      vec[i] = (seed / 0x7fffffff - PSI) * PHI;
    }
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    return norm > 0 ? vec.map(v => v / norm) : vec;
  }

  // ─────────────────────────────────────────────────────────────
  // CACHE (LRU)
  // ─────────────────────────────────────────────────────────────

  /** @param {string} key */
  _cacheGet(key) {
    if (!this.embedCache.has(key)) return undefined;
    const val = this.embedCache.get(key);
    this.embedCache.delete(key);
    this.embedCache.set(key, val);
    return val;
  }

  /** @param {string} key @param {*} value */
  _cacheSet(key, value) {
    if (this.embedCache.has(key)) this.embedCache.delete(key);
    this.embedCache.set(key, value);
    if (this.embedCache.size > SIZING.CACHE_SIZE) {
      const oldest = this.embedCache.keys().next().value;
      this.embedCache.delete(oldest);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & HEALTH
  // ─────────────────────────────────────────────────────────────

  _stats() {
    const providers = {};
    for (const [name, m] of this.providerMetrics) {
      providers[name] = { ...m, breakerState: this.circuitBreakers.get(name).state };
    }
    return { providers, cacheSize: this.embedCache.size, maxCache: SIZING.CACHE_SIZE };
  }

  health() {
    return { ...super.health(), embed: this._stats() };
  }
}

export { HeadyEmbedNode, HeadyEmbedNode as HeadyEmbed };
