/**
 * HeadyAutobiographer — Event Logging & Narrative Construction
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Records the "life story" of the Heady system — every significant event,
 * decision, and outcome. Detects milestones when coherence exceeds
 * CSL_THRESHOLDS.HIGH and constructs human-readable narratives from
 * event timelines.
 *
 * Ring: Memory | Pool: Cold | Domain: headyme.com
 *
 * @module heady-autobiographer
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights,
  cslGate, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// HEADY AUTOBIOGRAPHER NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyAutobiographerNode — Event logging, milestone detection, and
 * narrative construction for the Heady system's life story.
 *
 * @extends LiquidNode
 */
class HeadyAutobiographerNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyAutobiographer'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'HeadyAutobiographer',
      ring: 'memory',
      pool: 'cold',
      domain: 'headyme.com',
      capabilities: [
        'event-logging',
        'narrative-construction',
        'timeline-tracking',
        'milestone-detection',
        'story-generation',
      ],
      ...config,
    });

    /** @type {Object[]} Event log bounded by SIZING.LARGE_CACHE = fib(20) = 6765 */
    this.eventLog = [];
    this.maxEvents = SIZING.LARGE_CACHE;

    /** @type {Object[]} Milestone log bounded by SIZING.CACHE_SIZE = fib(16) = 987 */
    this.milestones = [];
    this.maxMilestones = SIZING.CACHE_SIZE;

    /** @type {Map<string, Object>} Narrative cache keyed by time range hash */
    this.narrativeCache = new Map();

    /** Milestone coherence threshold */
    this.milestoneThreshold = CSL_THRESHOLDS.HIGH;

    /** Event logging metrics */
    this.logMetrics = {
      totalLogged: 0,
      milestonesDetected: 0,
      narrativesBuilt: 0,
      eventsEvicted: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process an autobiographer task.
   * @param {Object} task
   * @param {string} task.type - logEvent | narrative | milestone | timeline | story | stats
   * @returns {Object}
   */
  async process(task) {
    switch (task.type) {
      case 'logEvent':  return this.logEvent(task.event);
      case 'narrative': return this.constructNarrative(task.timeRange);
      case 'milestone': return this.detectMilestone(task.event);
      case 'timeline':  return this.getTimeline(task.filter);
      case 'story':     return this.generateStory(task.events || this.eventLog.slice(-fib(8)));
      case 'stats':     return this._stats();
      default:
        throw new Error(`HeadyAutobiographer: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // EVENT LOGGING
  // ─────────────────────────────────────────────────────────────

  /**
   * Log a structured event with automatic milestone detection.
   *
   * @param {Object} event - Event descriptor
   * @param {string} event.actor - Origin node or agent
   * @param {string} event.action - What happened
   * @param {string} [event.outcome='success'] - Event outcome
   * @param {number} [event.coherenceScore=1.0] - Coherence at time of event
   * @param {Object} [event.metadata={}] - Additional event data
   * @returns {Object} Logged event with id and milestone flag
   */
  logEvent(event) {
    if (!event || !event.actor || !event.action) {
      throw new Error('HeadyAutobiographer: event requires actor and action');
    }

    const entry = {
      id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      timestamp: new Date().toISOString(),
      actor: event.actor,
      action: event.action,
      outcome: event.outcome || 'success',
      coherenceScore: event.coherenceScore ?? 1.0,
      metadata: event.metadata || {},
      isMilestone: false,
    };

    // Milestone detection
    const milestone = this.detectMilestone(entry);
    entry.isMilestone = milestone.isMilestone;

    // Append to log with eviction
    if (this.eventLog.length >= this.maxEvents) {
      const evictCount = SIZING.BATCH_EVICTION;
      this.eventLog.splice(0, evictCount);
      this.logMetrics.eventsEvicted += evictCount;
    }
    this.eventLog.push(entry);
    this.logMetrics.totalLogged++;
    this.metrics.requestsHandled++;

    this.logger.info({
      eventId: entry.id,
      actor: entry.actor,
      action: entry.action,
      isMilestone: entry.isMilestone,
    }, 'Event logged');

    return entry;
  }

  // ─────────────────────────────────────────────────────────────
  // NARRATIVE CONSTRUCTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Build a narrative from events within a time range.
   *
   * @param {Object} timeRange - Time range filter
   * @param {string} timeRange.start - ISO start timestamp
   * @param {string} timeRange.end - ISO end timestamp
   * @returns {Object} Narrative with chapters, milestones, and summary
   */
  constructNarrative(timeRange) {
    const cacheKey = `${timeRange.start}:${timeRange.end}`;
    if (this.narrativeCache.has(cacheKey)) return this.narrativeCache.get(cacheKey);

    const startMs = new Date(timeRange.start).getTime();
    const endMs = new Date(timeRange.end).getTime();

    const events = this.eventLog.filter(e => {
      const ts = new Date(e.timestamp).getTime();
      return ts >= startMs && ts <= endMs;
    });

    const milestoneEvents = events.filter(e => e.isMilestone);

    // Build chapters: group events into phi-scaled segments
    const chapterCount = Math.max(1, Math.min(fib(5), Math.ceil(events.length / fib(6))));
    const chapterSize = Math.ceil(events.length / chapterCount);
    const chapters = [];

    for (let i = 0; i < chapterCount; i++) {
      const chapterEvents = events.slice(i * chapterSize, (i + 1) * chapterSize);
      if (chapterEvents.length === 0) continue;

      const avgCoherence = chapterEvents.reduce((s, e) => s + e.coherenceScore, 0) / chapterEvents.length;
      const actors = [...new Set(chapterEvents.map(e => e.actor))];
      const actions = [...new Set(chapterEvents.map(e => e.action))];

      chapters.push({
        index: i,
        eventCount: chapterEvents.length,
        avgCoherence,
        actors,
        actions,
        firstEvent: chapterEvents[0].timestamp,
        lastEvent: chapterEvents[chapterEvents.length - 1].timestamp,
      });
    }

    // Compute overall coherence trajectory
    const coherenceValues = events.map(e => e.coherenceScore);
    const weights = coherenceValues.length > 0 ? phiFusionWeights(Math.min(coherenceValues.length, fib(8))) : [];
    const sorted = coherenceValues.slice().sort((a, b) => b - a).slice(0, weights.length);
    const weightedCoherence = sorted.reduce((sum, c, i) => sum + c * (weights[i] || 0), 0);

    const narrative = {
      timeRange,
      totalEvents: events.length,
      milestoneCount: milestoneEvents.length,
      chapters,
      coherenceTrajectory: weightedCoherence,
      timestamp: new Date().toISOString(),
    };

    this.narrativeCache.set(cacheKey, narrative);
    this.logMetrics.narrativesBuilt++;

    this.logger.info({
      events: events.length,
      milestones: milestoneEvents.length,
      chapters: chapters.length,
    }, 'Narrative constructed');

    return narrative;
  }

  // ─────────────────────────────────────────────────────────────
  // MILESTONE DETECTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Check if an event represents a significant milestone.
   * A milestone occurs when coherenceScore exceeds CSL_THRESHOLDS.HIGH.
   *
   * @param {Object} event - Event to evaluate
   * @returns {Object} Milestone assessment
   */
  detectMilestone(event) {
    const coherence = event.coherenceScore ?? 0;
    const gated = cslGate(coherence, coherence, this.milestoneThreshold);
    const isMilestone = gated >= this.milestoneThreshold;

    if (isMilestone) {
      const milestone = {
        eventId: event.id,
        actor: event.actor,
        action: event.action,
        coherenceScore: coherence,
        gatedScore: gated,
        detectedAt: new Date().toISOString(),
      };

      if (this.milestones.length >= this.maxMilestones) {
        this.milestones.shift();
      }
      this.milestones.push(milestone);
      this.logMetrics.milestonesDetected++;

      this.logger.info({
        eventId: event.id,
        coherence: coherence.toFixed(4),
        gated: gated.toFixed(4),
      }, 'Milestone detected');
    }

    return { isMilestone, coherence, gatedScore: gated, threshold: this.milestoneThreshold };
  }

  // ─────────────────────────────────────────────────────────────
  // STORY GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate a human-readable summary from a list of events.
   *
   * @param {Object[]} events - Events to summarize
   * @returns {Object} Story with summary lines and actor statistics
   */
  generateStory(events) {
    if (!events || events.length === 0) {
      return { lines: [], actors: {}, eventCount: 0 };
    }

    const actors = {};
    const lines = [];

    for (const event of events) {
      if (!actors[event.actor]) {
        actors[event.actor] = { actions: 0, milestones: 0, avgCoherence: 0, totalCoherence: 0 };
      }
      actors[event.actor].actions++;
      actors[event.actor].totalCoherence += event.coherenceScore;
      if (event.isMilestone) actors[event.actor].milestones++;

      lines.push(`[${event.timestamp}] ${event.actor} ${event.action} → ${event.outcome} (coherence: ${event.coherenceScore.toFixed(4)})`);
    }

    for (const actor of Object.values(actors)) {
      actor.avgCoherence = actor.totalCoherence / actor.actions;
      delete actor.totalCoherence;
    }

    return { lines, actors, eventCount: events.length, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // TIMELINE
  // ─────────────────────────────────────────────────────────────

  /**
   * Retrieve events matching filter criteria.
   *
   * @param {Object} [filter={}]
   * @param {string} [filter.actor] - Filter by actor name
   * @param {string} [filter.action] - Filter by action
   * @param {boolean} [filter.milestonesOnly] - Only return milestones
   * @param {number} [filter.minCoherence] - Minimum coherence score
   * @param {number} [filter.limit] - Max results (default fib(8) = 21)
   * @returns {Object} Filtered timeline
   */
  getTimeline(filter = {}) {
    let events = [...this.eventLog];

    if (filter.actor) events = events.filter(e => e.actor === filter.actor);
    if (filter.action) events = events.filter(e => e.action === filter.action);
    if (filter.milestonesOnly) events = events.filter(e => e.isMilestone);
    if (filter.minCoherence) events = events.filter(e => e.coherenceScore >= filter.minCoherence);

    const limit = filter.limit || SIZING.RERANK_TOP_K;
    events = events.slice(-limit);

    return { events, count: events.length, totalInLog: this.eventLog.length };
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & HEALTH
  // ─────────────────────────────────────────────────────────────

  _stats() {
    return {
      logMetrics: { ...this.logMetrics },
      eventLogSize: this.eventLog.length,
      maxEvents: this.maxEvents,
      milestoneCount: this.milestones.length,
      maxMilestones: this.maxMilestones,
      narrativeCacheSize: this.narrativeCache.size,
    };
  }

  health() {
    return { ...super.health(), autobiographer: this._stats() };
  }
}

export { HeadyAutobiographerNode, HeadyAutobiographerNode as HeadyAutobiographer };
