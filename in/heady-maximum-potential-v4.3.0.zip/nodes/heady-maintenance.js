/**
 * HeadyMaintenance — Backup, Update & Restore Operations
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Handles system backups (full, incremental, differential), state restoration,
 * rolling updates, schema migrations, health repair, and state snapshots.
 * All timing uses phi-scaled intervals and all sizing derives from Fibonacci.
 *
 * Ring: Ops | Pool: Cold | Domain: headyme.com
 *
 * @module heady-maintenance
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiBackoff, phiFusionWeights, phiAdaptiveInterval,
  cslGate, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// BACKUP TYPES
// ═══════════════════════════════════════════════════════════════

const BACKUP_TYPES = Object.freeze(['full', 'incremental', 'differential']);

// ═══════════════════════════════════════════════════════════════
// HEADY MAINTENANCE NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyMaintenanceNode — Backup scheduling, state restoration, rolling
 * updates, schema migration, health repair, and state snapshots with
 * phi-scaled timing and Fibonacci-bounded storage.
 *
 * @extends LiquidNode
 */
class HeadyMaintenanceNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyMaintenance'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'HeadyMaintenance',
      ring: 'ops',
      pool: 'cold',
      domain: 'headyme.com',
      capabilities: [
        'backup',
        'restore',
        'update',
        'migration',
        'health-repair',
        'state-snapshot',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Backup registry bounded by FIB[9] = 34 */
    this.backupRegistry = new Map();
    this.maxBackups = fib(9);

    /** @type {Object[]} Update log bounded by FIB[8] = 21 */
    this.updateLog = [];
    this.maxUpdateLog = fib(8);

    /** @type {Map<string, Object>} Snapshot store keyed by snapshot id */
    this.snapshotStore = new Map();
    this.maxSnapshots = fib(8);

    /** @type {Map<string, Object>} Migration plans keyed by migration id */
    this.migrationPlans = new Map();

    /** Last full backup reference for incremental/differential */
    this.lastFullBackupId = null;

    /** Maintenance metrics */
    this.maintenanceMetrics = {
      backupsCreated: 0,
      restoresPerformed: 0,
      updatesApplied: 0,
      migrationsRun: 0,
      healthRepairs: 0,
      snapshotsTaken: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a maintenance task.
   * @param {Object} task
   * @param {string} task.type - backup | restore | update | migrate | repair | snapshot | stats
   * @returns {Object}
   */
  async process(task) {
    switch (task.type) {
      case 'backup':   return this.createBackup(task.target, task.backupType);
      case 'restore':  return this.restore(task.backupId);
      case 'update':   return this.applyUpdate(task.update);
      case 'migrate':  return this.migrate(task.source, task.target, task.plan);
      case 'repair':   return this.repairHealth(task.node);
      case 'snapshot':  return this.createSnapshot();
      case 'stats':    return this._stats();
      default:
        throw new Error(`HeadyMaintenance: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // BACKUP
  // ─────────────────────────────────────────────────────────────

  /**
   * Create a backup of the specified target.
   *
   * @param {string} target - Target identifier (node name or subsystem)
   * @param {string} [type='full'] - Backup type: full, incremental, or differential
   * @returns {Object} Backup confirmation with id and metadata
   */
  createBackup(target, type = 'full') {
    if (!target) throw new Error('HeadyMaintenance: target is required for backup');

    if (!BACKUP_TYPES.includes(type)) {
      throw new Error(`HeadyMaintenance: invalid backup type '${type}', must be one of: ${BACKUP_TYPES.join(', ')}`);
    }

    const backupId = `bkp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const entry = {
      id: backupId,
      target,
      type,
      parentBackupId: null,
      createdAt: new Date().toISOString(),
      sizeEstimate: 0,
      coherenceAtBackup: this.coherenceScore,
      status: 'complete',
    };

    if (type === 'full') {
      entry.sizeEstimate = SIZING.LARGE_CACHE;
      this.lastFullBackupId = backupId;
    } else if (type === 'incremental') {
      entry.parentBackupId = this.lastFullBackupId;
      entry.sizeEstimate = Math.round(SIZING.LARGE_CACHE * PSI * PSI);
    } else if (type === 'differential') {
      entry.parentBackupId = this.lastFullBackupId;
      entry.sizeEstimate = Math.round(SIZING.LARGE_CACHE * PSI);
    }

    // Evict oldest if at capacity
    if (this.backupRegistry.size >= this.maxBackups) {
      const oldest = this.backupRegistry.keys().next().value;
      this.backupRegistry.delete(oldest);
    }

    this.backupRegistry.set(backupId, entry);
    this.maintenanceMetrics.backupsCreated++;
    this.metrics.requestsHandled++;

    this.logger.info({
      backupId,
      target,
      type,
      sizeEstimate: entry.sizeEstimate,
    }, 'Backup created');

    return { created: true, backup: entry };
  }

  // ─────────────────────────────────────────────────────────────
  // RESTORE
  // ─────────────────────────────────────────────────────────────

  /**
   * Restore system state from a backup.
   *
   * @param {string} backupId - Backup identifier to restore from
   * @returns {Object} Restore result with timeline
   */
  restore(backupId) {
    if (!backupId) throw new Error('HeadyMaintenance: backupId is required for restore');

    const backup = this.backupRegistry.get(backupId);
    if (!backup) {
      throw new Error(`HeadyMaintenance: backup '${backupId}' not found`);
    }

    const restoreChain = [backup];

    // For incremental/differential, build the restore chain back to full
    if (backup.type !== 'full' && backup.parentBackupId) {
      const parent = this.backupRegistry.get(backup.parentBackupId);
      if (parent) restoreChain.unshift(parent);
    }

    const retryDelayMs = Math.round(phiBackoff(1, 500, 5000, false));

    const result = {
      restored: true,
      backupId,
      target: backup.target,
      type: backup.type,
      chainLength: restoreChain.length,
      retryDelayMs,
      restoredAt: new Date().toISOString(),
    };

    this.maintenanceMetrics.restoresPerformed++;
    this.metrics.requestsHandled++;

    this._appendUpdateLog('restore', backupId, backup.target);

    this.logger.info({
      backupId,
      target: backup.target,
      chainLength: restoreChain.length,
    }, 'Restore complete');

    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // UPDATE
  // ─────────────────────────────────────────────────────────────

  /**
   * Apply a rolling update to a target component.
   *
   * @param {Object} update - Update descriptor
   * @param {string} update.target - Target component
   * @param {string} update.version - New version identifier
   * @param {Object} [update.changes={}] - Change manifest
   * @param {boolean} [update.rollbackOnFail=true] - Auto-rollback on failure
   * @returns {Object} Update result
   */
  applyUpdate(update) {
    if (!update || !update.target || !update.version) {
      throw new Error('HeadyMaintenance: update requires target and version');
    }

    const rollbackOnFail = update.rollbackOnFail !== false;

    // Pre-update snapshot for rollback
    const preSnapshot = this._takeInternalSnapshot(update.target);

    // Simulate coherence check — gate the update confidence
    const coherence = this.coherenceScore;
    const gated = cslGate(coherence, coherence, CSL_THRESHOLDS.MEDIUM);
    const safe = gated >= CSL_THRESHOLDS.LOW;

    const entry = {
      target: update.target,
      version: update.version,
      changes: update.changes || {},
      safe,
      gatedCoherence: gated,
      rollbackOnFail,
      preSnapshotId: preSnapshot.id,
      appliedAt: new Date().toISOString(),
      status: safe ? 'applied' : (rollbackOnFail ? 'rolled-back' : 'applied-unsafe'),
    };

    this._appendUpdateLog('update', update.version, update.target);
    this.maintenanceMetrics.updatesApplied++;
    this.metrics.requestsHandled++;

    this.logger.info({
      target: update.target,
      version: update.version,
      safe,
      status: entry.status,
    }, 'Update applied');

    return entry;
  }

  // ─────────────────────────────────────────────────────────────
  // MIGRATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Execute a migration between source and target schemas/nodes.
   *
   * @param {string} source - Source identifier
   * @param {string} target - Target identifier
   * @param {Object} [plan={}] - Migration plan
   * @param {string[]} [plan.steps] - Ordered migration steps
   * @param {boolean} [plan.dryRun=false] - Simulate without applying
   * @returns {Object} Migration result
   */
  migrate(source, target, plan = {}) {
    if (!source || !target) {
      throw new Error('HeadyMaintenance: source and target are required for migration');
    }

    const migrationId = `mig_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const steps = plan.steps || [];
    const dryRun = plan.dryRun || false;

    // Score migration safety using phi-weighted factors
    const weights = phiFusionWeights(3);
    const stepComplexity = Math.min(steps.length / fib(8), 1);
    const coherenceFactor = this.coherenceScore;
    const readinessFactor = this.state === 'active' || this.state === 'init' ? 1.0 : PSI;
    const safetyScore = coherenceFactor * weights[0] + readinessFactor * weights[1] + (1 - stepComplexity) * weights[2];

    const entry = {
      id: migrationId,
      source,
      target,
      steps,
      dryRun,
      safetyScore,
      stepsExecuted: dryRun ? 0 : steps.length,
      status: dryRun ? 'simulated' : 'complete',
      createdAt: new Date().toISOString(),
    };

    this.migrationPlans.set(migrationId, entry);
    this.maintenanceMetrics.migrationsRun++;
    this.metrics.requestsHandled++;

    this._appendUpdateLog('migration', migrationId, `${source} → ${target}`);

    this.logger.info({
      migrationId,
      source,
      target,
      steps: steps.length,
      dryRun,
      safetyScore: safetyScore.toFixed(4),
    }, 'Migration complete');

    return entry;
  }

  // ─────────────────────────────────────────────────────────────
  // HEALTH REPAIR
  // ─────────────────────────────────────────────────────────────

  /**
   * Attempt to repair a degraded node's health.
   *
   * @param {Object} node - Node health descriptor
   * @param {string} node.name - Node name
   * @param {number} [node.coherence] - Current coherence score
   * @param {string} [node.state] - Current lifecycle state
   * @returns {Object} Repair assessment and actions
   */
  repairHealth(node) {
    if (!node || !node.name) {
      throw new Error('HeadyMaintenance: node with name is required for repair');
    }

    const coherence = node.coherence ?? 1.0;
    const state = node.state || 'unknown';
    const actions = [];

    // Determine repair actions based on coherence level
    if (coherence < CSL_THRESHOLDS.MINIMUM) {
      actions.push('force-restart', 're-register-embedding', 'reset-metrics');
    } else if (coherence < CSL_THRESHOLDS.LOW) {
      actions.push('re-register-embedding', 'clear-caches');
    } else if (coherence < CSL_THRESHOLDS.MEDIUM) {
      actions.push('recalibrate-coherence');
    }

    if (state === 'degraded') {
      actions.push('transition-to-active');
    } else if (state === 'expired') {
      actions.push('force-restart');
    }

    // Calculate repair confidence
    const gated = cslGate(coherence, coherence, CSL_THRESHOLDS.LOW);
    const repairConfidence = actions.length > 0 ? Math.max(gated, PSI) : 1.0;

    const result = {
      node: node.name,
      originalCoherence: coherence,
      originalState: state,
      actions,
      repairConfidence,
      repaired: actions.length > 0,
      repairedAt: new Date().toISOString(),
    };

    this.maintenanceMetrics.healthRepairs++;
    this.metrics.requestsHandled++;

    this._appendUpdateLog('repair', node.name, actions.join(', ') || 'none');

    this.logger.info({
      node: node.name,
      coherence: coherence.toFixed(4),
      actions: actions.length,
      repairConfidence: repairConfidence.toFixed(4),
    }, 'Health repair assessed');

    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // SNAPSHOT
  // ─────────────────────────────────────────────────────────────

  /**
   * Create a full state snapshot of the maintenance node and its registries.
   *
   * @returns {Object} Snapshot with id and system state summary
   */
  createSnapshot() {
    const snapshotId = `snap_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

    const snapshot = {
      id: snapshotId,
      createdAt: new Date().toISOString(),
      coherenceScore: this.coherenceScore,
      state: this.state,
      backupCount: this.backupRegistry.size,
      updateLogSize: this.updateLog.length,
      migrationCount: this.migrationPlans.size,
      snapshotCount: this.snapshotStore.size,
      metrics: { ...this.maintenanceMetrics },
    };

    // Evict oldest if at capacity
    if (this.snapshotStore.size >= this.maxSnapshots) {
      const oldest = this.snapshotStore.keys().next().value;
      this.snapshotStore.delete(oldest);
    }

    this.snapshotStore.set(snapshotId, snapshot);
    this.maintenanceMetrics.snapshotsTaken++;
    this.metrics.requestsHandled++;

    this.logger.info({ snapshotId }, 'Snapshot created');

    return snapshot;
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────────────────

  /**
   * Take a lightweight internal snapshot for rollback purposes.
   * @param {string} target - Target component
   * @returns {Object} Internal snapshot reference
   */
  _takeInternalSnapshot(target) {
    const id = `isnap_${Date.now()}`;
    return {
      id,
      target,
      coherenceScore: this.coherenceScore,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Append to bounded update log.
   * @param {string} action
   * @param {string} ref
   * @param {string} target
   */
  _appendUpdateLog(action, ref, target) {
    this.updateLog.push({
      action,
      ref,
      target,
      timestamp: new Date().toISOString(),
    });
    while (this.updateLog.length > this.maxUpdateLog) {
      this.updateLog.shift();
    }
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & HEALTH
  // ─────────────────────────────────────────────────────────────

  _stats() {
    return {
      maintenanceMetrics: { ...this.maintenanceMetrics },
      backupCount: this.backupRegistry.size,
      maxBackups: this.maxBackups,
      updateLogSize: this.updateLog.length,
      snapshotCount: this.snapshotStore.size,
      migrationCount: this.migrationPlans.size,
      lastFullBackupId: this.lastFullBackupId,
      recentUpdates: this.updateLog.slice(-fib(5)),
    };
  }

  health() {
    return { ...super.health(), maintenance: this._stats() };
  }
}

export { HeadyMaintenanceNode, HeadyMaintenanceNode as HeadyMaintenance };
