/**
 * HeadyMaid — Cleanup Scheduling & Cache Management
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Manages cache eviction, resource reclamation, and garbage collection
 * across the Heady ecosystem. Cleanup intervals are phi-scaled, and
 * eviction policies include LRU, LFU, TTL, and phi-weighted composite.
 *
 * Ring: Ops | Pool: Cold | Domain: headyme.com
 *
 * @module heady-maid
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiBackoff, phiFusionWeights, phiAdaptiveInterval,
  cslGate, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// CLEANUP POLICIES
// ═══════════════════════════════════════════════════════════════

const CLEANUP_POLICIES = Object.freeze(['lru', 'lfu', 'ttl', 'phi-weighted']);

/** Minor cleanup base interval: 60s, major: 1h */
const MINOR_BASE_MS = 60000;
const MAJOR_BASE_MS = 3600000;

// ═══════════════════════════════════════════════════════════════
// HEADY MAID NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyMaidNode — Cleanup scheduling, cache eviction, and resource
 * reclamation with phi-scaled intervals and multiple eviction policies.
 *
 * @extends LiquidNode
 */
class HeadyMaidNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyMaid'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'HeadyMaid',
      ring: 'ops',
      pool: 'cold',
      domain: 'headyme.com',
      capabilities: [
        'cache-cleanup',
        'resource-reclamation',
        'schedule-management',
        'garbage-collection',
        'storage-optimization',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Scheduled cleanup tasks */
    this.scheduledTasks = new Map();

    /** @type {Object[]} Cleanup log bounded by FIB[8] = 21 */
    this.cleanupLog = [];
    this.maxCleanupLog = SIZING.RERANK_TOP_K;

    /** @type {Map<string, Object>} Resource metrics per target */
    this.resourceMetrics = new Map();

    /** Last cleanup timestamps per target */
    this.lastCleanupTime = new Map();

    /** Adaptive interval state */
    this.minorIntervalMs = MINOR_BASE_MS;
    this.majorIntervalMs = MAJOR_BASE_MS;

    /** Cleanup statistics */
    this.cleanupMetrics = {
      totalCleanups: 0,
      cachesCleaned: 0,
      entriesEvicted: 0,
      resourcesReclaimed: 0,
      scheduledRuns: 0,
      gcCycles: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a maid task.
   * @param {Object} task
   * @param {string} task.type - schedule | cleanup | reclaim | gc | stats
   * @returns {Object}
   */
  async process(task) {
    switch (task.type) {
      case 'schedule': return this.scheduleCleanup(task.target, task.schedule);
      case 'cleanup':  return this.cleanupCache(task.cacheRef, task.policy);
      case 'reclaim':  return this.reclaimResources(task.scope);
      case 'gc':       return this.collectGarbage(task.options);
      case 'stats':    return this._stats();
      default:
        throw new Error(`HeadyMaid: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // SCHEDULE CLEANUP
  // ─────────────────────────────────────────────────────────────

  /**
   * Schedule a cleanup task for a target.
   *
   * @param {string} target - Target identifier (node name or cache name)
   * @param {Object} schedule - Schedule configuration
   * @param {string} [schedule.policy='lru'] - Cleanup policy
   * @param {string} [schedule.frequency='minor'] - minor or major
   * @param {number} [schedule.maxAge] - TTL in ms for ttl policy
   * @returns {Object} Scheduled task confirmation
   */
  scheduleCleanup(target, schedule = {}) {
    if (!target) throw new Error('HeadyMaid: target is required for scheduling');

    const policy = schedule.policy || 'lru';
    if (!CLEANUP_POLICIES.includes(policy)) {
      throw new Error(`HeadyMaid: invalid policy '${policy}', must be one of: ${CLEANUP_POLICIES.join(', ')}`);
    }

    const frequency = schedule.frequency || 'minor';
    const intervalMs = frequency === 'major'
      ? phiAdaptiveInterval(MAJOR_BASE_MS, true, this.majorIntervalMs)
      : phiAdaptiveInterval(MINOR_BASE_MS, true, this.minorIntervalMs);

    const entry = {
      target,
      policy,
      frequency,
      intervalMs: Math.round(intervalMs),
      maxAge: schedule.maxAge || null,
      createdAt: new Date().toISOString(),
      lastRun: null,
      runCount: 0,
    };

    this.scheduledTasks.set(target, entry);
    this.cleanupMetrics.scheduledRuns++;
    this.metrics.requestsHandled++;

    this.logger.info({
      target,
      policy,
      frequency,
      intervalMs: entry.intervalMs,
    }, 'Cleanup scheduled');

    return { scheduled: true, target, entry };
  }

  // ─────────────────────────────────────────────────────────────
  // CACHE CLEANUP
  // ─────────────────────────────────────────────────────────────

  /**
   * Clean a cache reference according to the specified eviction policy.
   *
   * @param {Object} cacheRef - Cache descriptor
   * @param {Map|Object[]} cacheRef.store - The cache store (Map or array)
   * @param {number} cacheRef.maxSize - Maximum allowed entries
   * @param {string} [policy='lru'] - Eviction policy
   * @returns {Object} Cleanup result with eviction count
   */
  cleanupCache(cacheRef, policy = 'lru') {
    if (!cacheRef || !cacheRef.store) {
      throw new Error('HeadyMaid: cacheRef with store is required');
    }

    const store = cacheRef.store;
    const maxSize = cacheRef.maxSize || SIZING.CACHE_SIZE;
    const isMap = store instanceof Map;
    const currentSize = isMap ? store.size : store.length;
    let evicted = 0;

    if (currentSize <= maxSize) {
      return { evicted: 0, remaining: currentSize, policy };
    }

    const targetSize = Math.round(maxSize * PSI);
    const toEvict = currentSize - targetSize;

    if (policy === 'lru' && isMap) {
      const keys = [...store.keys()];
      for (let i = 0; i < toEvict && i < keys.length; i++) {
        store.delete(keys[i]);
        evicted++;
      }
    } else if (policy === 'lfu' && isMap) {
      const entries = [...store.entries()]
        .sort((a, b) => (a[1].accessCount || 0) - (b[1].accessCount || 0));
      for (let i = 0; i < toEvict && i < entries.length; i++) {
        store.delete(entries[i][0]);
        evicted++;
      }
    } else if (policy === 'ttl' && isMap) {
      const now = Date.now();
      const maxAge = cacheRef.maxAge || SIZING.RETENTION_DAYS * 86400000;
      for (const [key, val] of store) {
        const created = val.createdAt ? new Date(val.createdAt).getTime() : 0;
        if (now - created > maxAge) {
          store.delete(key);
          evicted++;
        }
      }
    } else if (policy === 'phi-weighted' && isMap) {
      const weights = phiFusionWeights(3);
      const entries = [...store.entries()].map(([key, val]) => {
        const recency = val.lastAccessed
          ? 1 - Math.min((Date.now() - new Date(val.lastAccessed).getTime()) / (SIZING.RETENTION_DAYS * 86400000), 1)
          : 0;
        const frequency = Math.min((val.accessCount || 0) / fib(8), 1);
        const importance = val.confidence || val.relevance || PSI;
        const score = recency * weights[0] + frequency * weights[1] + importance * weights[2];
        return { key, score };
      }).sort((a, b) => a.score - b.score);

      for (let i = 0; i < toEvict && i < entries.length; i++) {
        store.delete(entries[i].key);
        evicted++;
      }
    } else if (Array.isArray(store)) {
      const removeCount = Math.min(toEvict, store.length);
      store.splice(0, removeCount);
      evicted = removeCount;
    }

    this.cleanupMetrics.totalCleanups++;
    this.cleanupMetrics.cachesCleaned++;
    this.cleanupMetrics.entriesEvicted += evicted;
    this.metrics.requestsHandled++;

    this._appendCleanupLog('cleanup', cacheRef.name || 'unknown', evicted, policy);

    this.logger.info({
      policy,
      evicted,
      remaining: isMap ? store.size : store.length,
      maxSize,
    }, 'Cache cleanup complete');

    return { evicted, remaining: isMap ? store.size : store.length, policy };
  }

  // ─────────────────────────────────────────────────────────────
  // RESOURCE RECLAMATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Reclaim resources across a scope (node, ring, or global).
   *
   * @param {Object} scope - Reclamation scope
   * @param {string} [scope.level='node'] - node | ring | global
   * @param {string} [scope.target] - Target name
   * @param {Object} [scope.caches] - Map of cache names to cache refs
   * @returns {Object} Reclamation result
   */
  reclaimResources(scope = {}) {
    const level = scope.level || 'node';
    const target = scope.target || 'all';
    let totalReclaimed = 0;

    if (scope.caches) {
      for (const [name, cacheRef] of Object.entries(scope.caches)) {
        const result = this.cleanupCache({ ...cacheRef, name }, 'phi-weighted');
        totalReclaimed += result.evicted;
      }
    }

    this.cleanupMetrics.resourcesReclaimed += totalReclaimed;
    this.lastCleanupTime.set(target, Date.now());
    this.resourceMetrics.set(target, {
      lastReclaimed: totalReclaimed,
      lastReclaimAt: new Date().toISOString(),
      level,
    });

    this._appendCleanupLog('reclaim', target, totalReclaimed, 'phi-weighted');

    this.logger.info({ level, target, totalReclaimed }, 'Resources reclaimed');
    return { level, target, totalReclaimed, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // GARBAGE COLLECTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Run a garbage collection cycle across all tracked resources.
   *
   * @param {Object} [options={}]
   * @param {boolean} [options.aggressive] - Use lower retention thresholds
   * @param {string[]} [options.targets] - Specific targets to GC
   * @returns {Object} GC result
   */
  collectGarbage(options = {}) {
    const aggressive = options.aggressive || false;
    const targets = options.targets || [...this.scheduledTasks.keys()];
    let totalCollected = 0;

    for (const target of targets) {
      const task = this.scheduledTasks.get(target);
      if (!task) continue;

      task.lastRun = new Date().toISOString();
      task.runCount++;

      const simulatedEvicted = aggressive ? SIZING.BATCH_EVICTION : fib(3);
      totalCollected += simulatedEvicted;
    }

    this.cleanupMetrics.gcCycles++;
    this.cleanupMetrics.totalCleanups++;
    this.cleanupMetrics.entriesEvicted += totalCollected;
    this.metrics.requestsHandled++;

    this._appendCleanupLog('gc', 'global', totalCollected, aggressive ? 'aggressive' : 'standard');

    this.logger.info({
      targets: targets.length,
      totalCollected,
      aggressive,
    }, 'Garbage collection complete');

    return { targets: targets.length, totalCollected, aggressive, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────────────────

  /**
   * Append to bounded cleanup log.
   * @param {string} action
   * @param {string} target
   * @param {number} evicted
   * @param {string} policy
   */
  _appendCleanupLog(action, target, evicted, policy) {
    this.cleanupLog.push({
      action,
      target,
      evicted,
      policy,
      timestamp: new Date().toISOString(),
    });
    while (this.cleanupLog.length > this.maxCleanupLog) {
      this.cleanupLog.shift();
    }
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & HEALTH
  // ─────────────────────────────────────────────────────────────

  _stats() {
    return {
      cleanupMetrics: { ...this.cleanupMetrics },
      scheduledTasks: this.scheduledTasks.size,
      cleanupLogSize: this.cleanupLog.length,
      resourceTargets: this.resourceMetrics.size,
      recentCleanups: this.cleanupLog.slice(-fib(5)),
    };
  }

  health() {
    return { ...super.health(), maid: this._stats() };
  }
}

export { HeadyMaidNode, HeadyMaidNode as HeadyMaid };
