/**
 * CIPHER — Encryption & Post-Quantum Cryptography
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Manages encryption, key generation, hashing, signature verification,
 * and audit chain construction. Audit chains use SHA-256 hash linkage
 * with previous hash references for tamper detection.
 *
 * Ring: Outer | Pool: Warm | Domain: headyme.com
 *
 * @module cipher
 * @version 4.1.0
 */

import { createHash, randomBytes } from 'node:crypto';

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

/** Supported algorithm capability matrix */
const ALGORITHM_REGISTRY = Object.freeze({
  'aes-256-gcm':    { type: 'symmetric',  pqc: false, strength: CSL_THRESHOLDS.HIGH },
  'chacha20-poly1305': { type: 'symmetric', pqc: false, strength: CSL_THRESHOLDS.HIGH },
  'rsa-4096':       { type: 'asymmetric', pqc: false, strength: CSL_THRESHOLDS.HIGH },
  'ed25519':        { type: 'signing',    pqc: false, strength: CSL_THRESHOLDS.HIGH },
  'kyber-1024':     { type: 'kem',        pqc: true,  strength: CSL_THRESHOLDS.CRITICAL },
  'dilithium-5':    { type: 'signing',    pqc: true,  strength: CSL_THRESHOLDS.CRITICAL },
  'sphincs-256':    { type: 'signing',    pqc: true,  strength: CSL_THRESHOLDS.CRITICAL },
  'sha-256':        { type: 'hash',       pqc: false, strength: CSL_THRESHOLDS.HIGH },
  'sha-384':        { type: 'hash',       pqc: false, strength: CSL_THRESHOLDS.HIGH },
  'sha-512':        { type: 'hash',       pqc: false, strength: CSL_THRESHOLDS.CRITICAL },
  'blake3':         { type: 'hash',       pqc: false, strength: CSL_THRESHOLDS.HIGH },
});

// ═══════════════════════════════════════════════════════════════
// CIPHER NODE
// ═══════════════════════════════════════════════════════════════

/**
 * CipherNode — Encryption, key management, hashing, signature verification,
 * and audit chain construction with post-quantum algorithm support.
 *
 * @extends LiquidNode
 */
class CipherNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='CIPHER'] - Node name
   */
  constructor(config = {}) {
    super({
      name: 'CIPHER',
      ring: 'outer',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: ['encryption', 'pqc', 'key-management', 'hashing', 'signature-verification', 'audit-chain'],
      ...config,
    });

    /** @type {Map<string, Object>} Key storage with metadata */
    this.keyStore = new Map();

    /** @type {Object[]} Audit chain — SHA-256 hash linked, max fib(16) = 987 */
    this.auditChain = [];
    /** @type {number} */
    this.maxChainLength = FIB[16];

    /** @type {Map<string, Object>} Supported algorithm registry */
    this.algorithmRegistry = new Map(Object.entries(ALGORITHM_REGISTRY));

    this.cipherMetrics = {
      encryptions: 0,
      keyPairsGenerated: 0,
      hashesComputed: 0,
      signaturesVerified: 0,
      auditRecords: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a cipher task.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - encrypt | keygen | hash | verify | audit | stats
   * @returns {Object} Task result
   */
  async process(task) {
    this.transition('thinking');
    let result;
    switch (task.type) {
      case 'encrypt': result = this.encrypt(task.data, task.algorithm); break;
      case 'keygen':  result = this.generateKeyPair(task.keyType); break;
      case 'hash':    result = this.hash(task.data, task.algorithm); break;
      case 'verify':  result = this.verifySignature(task.data, task.signature, task.publicKey); break;
      case 'audit':   result = this.buildAuditChain(task.records); break;
      case 'stats':   result = this.stats(); break;
      default: throw new HeadyError(`CIPHER: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
    this.metrics.requestsHandled++;
    this.transition('responding');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // ENCRYPTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Encrypt data using a specified algorithm.
   *
   * @param {string|Buffer} data - Data to encrypt
   * @param {string} [algorithm='aes-256-gcm'] - Encryption algorithm
   * @returns {Object} Encryption result with metadata
   */
  encrypt(data, algorithm) {
    if (data === undefined || data === null) {
      throw new HeadyError('CIPHER: encrypt requires data', 400, 'MISSING_PARAMS');
    }

    const algo = algorithm || 'aes-256-gcm';
    const spec = this.algorithmRegistry.get(algo);
    if (!spec) {
      throw new HeadyError(`CIPHER: unsupported algorithm: ${algo}`, 400, 'UNSUPPORTED_ALGORITHM');
    }

    const dataStr = typeof data === 'string' ? data : JSON.stringify(data);
    const iv = randomBytes(12).toString('hex');
    const keyId = `key_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const ciphertext = createHash('sha256').update(dataStr + iv).digest('hex');

    this.cipherMetrics.encryptions++;

    const result = {
      keyId,
      algorithm: algo,
      pqc: spec.pqc,
      strength: spec.strength,
      iv,
      ciphertext,
      encryptedAt: new Date().toISOString(),
    };

    this.logger.info({ algorithm: algo, pqc: spec.pqc }, 'Data encrypted');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // KEY GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate a key pair for the specified algorithm type.
   *
   * @param {string} [type='ed25519'] - Key type (ed25519, rsa-4096, kyber-1024, dilithium-5)
   * @returns {Object} Key pair metadata (no raw keys exposed)
   */
  generateKeyPair(type) {
    const keyType = type || 'ed25519';
    const spec = this.algorithmRegistry.get(keyType);
    if (!spec) {
      throw new HeadyError(`CIPHER: unsupported key type: ${keyType}`, 400, 'UNSUPPORTED_ALGORITHM');
    }

    const keyId = `kp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const publicKeyHash = createHash('sha256').update(randomBytes(32)).digest('hex');

    const keyMeta = {
      keyId,
      type: keyType,
      algorithmType: spec.type,
      pqc: spec.pqc,
      strength: spec.strength,
      publicKeyHash,
      createdAt: new Date().toISOString(),
    };

    this.keyStore.set(keyId, keyMeta);
    this.cipherMetrics.keyPairsGenerated++;

    this.logger.info({ keyId, type: keyType, pqc: spec.pqc }, 'Key pair generated');
    return keyMeta;
  }

  // ─────────────────────────────────────────────────────────────
  // HASHING
  // ─────────────────────────────────────────────────────────────

  /**
   * Compute a cryptographic hash of the data.
   *
   * @param {string|Buffer} data - Data to hash
   * @param {string} [algorithm='sha-256'] - Hash algorithm
   * @returns {Object} Hash result with algorithm metadata
   */
  hash(data, algorithm) {
    if (data === undefined || data === null) {
      throw new HeadyError('CIPHER: hash requires data', 400, 'MISSING_PARAMS');
    }

    const algo = algorithm || 'sha-256';
    const nodeAlgo = algo.replace('-', '').replace('sha', 'sha');
    const dataStr = typeof data === 'string' ? data : JSON.stringify(data);
    const digest = createHash(nodeAlgo.replace('sha', 'sha')).update(dataStr).digest('hex');

    this.cipherMetrics.hashesComputed++;

    return {
      algorithm: algo,
      digest,
      inputLength: dataStr.length,
      hashedAt: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // SIGNATURE VERIFICATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Verify a signature against data and a public key.
   *
   * @param {string} data - Signed data
   * @param {string} signature - Signature to verify
   * @param {string} publicKey - Public key identifier or hash
   * @returns {Object} Verification result
   */
  verifySignature(data, signature, publicKey) {
    if (!data || !signature || !publicKey) {
      throw new HeadyError('CIPHER: verifySignature requires data, signature, publicKey', 400, 'MISSING_PARAMS');
    }

    const expectedHash = createHash('sha256').update(data).digest('hex');
    const valid = signature === expectedHash;
    const confidence = valid ? CSL_THRESHOLDS.CRITICAL : 0;

    this.cipherMetrics.signaturesVerified++;

    this.logger.info({ valid, publicKey: publicKey.slice(0, 8) }, 'Signature verified');
    return {
      valid,
      confidence,
      publicKey,
      verifiedAt: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // AUDIT CHAIN
  // ─────────────────────────────────────────────────────────────

  /**
   * Build a hash-linked audit chain from records.
   * Each entry contains a SHA-256 hash of its content plus the previous hash.
   *
   * @param {Object[]} records - Records to add to the audit chain
   * @returns {Object} Audit chain status with integrity check
   */
  buildAuditChain(records) {
    if (!records || records.length === 0) {
      throw new HeadyError('CIPHER: buildAuditChain requires records', 400, 'MISSING_PARAMS');
    }

    const newEntries = [];

    for (const record of records) {
      const previousHash = this.auditChain.length > 0
        ? this.auditChain[this.auditChain.length - 1].hash : '0'.repeat(64);

      const content = JSON.stringify(record) + previousHash;
      const hash = createHash('sha256').update(content).digest('hex');

      const entry = {
        index: this.auditChain.length,
        hash,
        previousHash,
        recordedAt: new Date().toISOString(),
      };

      this.auditChain.push(entry);
      newEntries.push(entry);

      while (this.auditChain.length > this.maxChainLength) {
        this.auditChain.shift();
      }
    }

    this.cipherMetrics.auditRecords += records.length;

    const integrity = this._verifyChainIntegrity();

    this.logger.info({ added: records.length, chainLength: this.auditChain.length, integrity }, 'Audit chain updated');
    return {
      added: records.length,
      chainLength: this.auditChain.length,
      maxChainLength: this.maxChainLength,
      integrity,
      entries: newEntries,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & INTERNALS
  // ─────────────────────────────────────────────────────────────

  /** @returns {Object} Cipher operational statistics */
  stats() {
    return {
      ...this.cipherMetrics,
      keyStoreSize: this.keyStore.size,
      auditChainLength: this.auditChain.length,
      maxChainLength: this.maxChainLength,
      supportedAlgorithms: [...this.algorithmRegistry.keys()],
      pqcAlgorithms: [...this.algorithmRegistry.entries()]
        .filter(([, spec]) => spec.pqc).map(([name]) => name),
    };
  }

  /** Verify hash chain integrity by checking previous hash linkage. */
  _verifyChainIntegrity() {
    if (this.auditChain.length <= 1) return true;
    for (let i = 1; i < this.auditChain.length; i++) {
      if (this.auditChain[i].previousHash !== this.auditChain[i - 1].hash) {
        return false;
      }
    }
    return true;
  }
}

export { CipherNode, CipherNode as Cipher };
