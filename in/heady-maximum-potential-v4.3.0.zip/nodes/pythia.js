/**
 * PYTHIA — Predictive Analysis & Forecasting Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Generates predictions with phi-scaled confidence intervals, detects
 * anomalies using phi-derived z-scores, analyzes trends, plans capacity
 * using Fibonacci-stepped recommendations, and assesses risk via
 * simplified Monte Carlo simulation.
 *
 * Ring: Middle | Pool: Warm | Domain: headyme.com
 *
 * @module pythia
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// PYTHIA NODE
// ═══════════════════════════════════════════════════════════════

/**
 * PythiaNode — Prediction, forecasting, anomaly detection, and capacity planning.
 *
 * All confidence intervals scale by phi, z-score thresholds derive from
 * PSI powers, and capacity recommendations follow Fibonacci steps.
 *
 * @extends LiquidNode
 */
class PythiaNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='PYTHIA'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'PYTHIA',
      ring: 'middle',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: [
        'prediction',
        'forecasting',
        'trend-analysis',
        'anomaly-detection',
        'capacity-planning',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Cached prediction models */
    this.modelCache = new Map();

    /** @type {Object[]} Last FIB[9]=34 predictions */
    this.predictionHistory = [];

    /** @type {Map<string, Object>} Per-metric anomaly baselines */
    this.anomalyBaselines = new Map();

    this.pythiaMetrics = {
      predictions: 0,
      anomaliesDetected: 0,
      trendsAnalyzed: 0,
      capacityPlans: 0,
      riskAssessments: 0,
      avgConfidence: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Route to prediction or analysis task.
   * @param {Object} task
   * @param {string} task.type - predict | anomaly | trend | capacity | risk
   * @returns {Object} Analysis result
   */
  async process(task) {
    if (!task || !task.type) {
      throw new HeadyError('PYTHIA: task must include a type', 400, 'INVALID_TASK');
    }
    switch (task.type) {
      case 'predict':  return this.predict(task.data || [], task.horizon);
      case 'anomaly':  return this.detectAnomalies(task.timeSeries || []);
      case 'trend':    return this.analyzeTrend(task.data || []);
      case 'capacity': return this.planCapacity(task.metrics || {}, task.growthRate);
      case 'risk':     return this.assessRisk(task.scenario || task);
      default:
        throw new HeadyError(`PYTHIA: unknown task type: ${task.type}`, 400, 'UNKNOWN_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // PREDICTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate predictions with phi-scaled confidence intervals.
   * @param {number[]} data - Historical data points
   * @param {number} [horizon] - Prediction horizon (number of steps)
   * @returns {Object} Predictions with confidence intervals
   */
  predict(data, horizon) {
    if (!data || data.length < fib(4)) {
      throw new HeadyError('PYTHIA: predict requires at least fib(4) data points', 400, 'INSUFFICIENT_DATA');
    }

    const steps = horizon || fib(5);
    const stats = this._computeStats(data);
    const trend = this._linearTrend(data);

    const predictions = [];
    for (let i = 1; i <= steps; i++) {
      const predicted = stats.mean + trend.slope * i;
      const uncertainty = stats.stdDev * Math.pow(PHI, i / steps);
      const confidence = cslGate(1.0, 1.0 - (uncertainty / (Math.abs(predicted) + 1)), CSL_THRESHOLDS.LOW);

      predictions.push({
        step: i,
        value: predicted,
        lower: predicted - uncertainty * PHI,
        upper: predicted + uncertainty * PHI,
        confidence,
      });
    }

    const avgConfidence = predictions.reduce((s, p) => s + p.confidence, 0) / predictions.length;
    this._recordPrediction({ data: data.length, steps, avgConfidence });

    this.pythiaMetrics.predictions++;
    const total = this.pythiaMetrics.predictions;
    this.pythiaMetrics.avgConfidence =
      (this.pythiaMetrics.avgConfidence * (total - 1) + avgConfidence) / total;
    this.metrics.requestsHandled++;
    this.logger.info({ steps, avgConfidence: avgConfidence.toFixed(4) }, 'Prediction generated');

    return { predictions, stats, trend, avgConfidence, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // ANOMALY DETECTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Statistical anomaly detection using phi-derived z-scores.
   * Anomaly threshold: z-score > PHI (≈ 1.618).
   * @param {number[]} timeSeries - Time series data
   * @returns {Object} Anomalies with z-scores
   */
  detectAnomalies(timeSeries) {
    if (!timeSeries || timeSeries.length < fib(4)) {
      return { anomalies: [], message: 'Insufficient data' };
    }

    const stats = this._computeStats(timeSeries);
    const zThreshold = PHI;
    const anomalies = [];

    for (let i = 0; i < timeSeries.length; i++) {
      const zScore = stats.stdDev > 0
        ? Math.abs(timeSeries[i] - stats.mean) / stats.stdDev
        : 0;

      if (zScore > zThreshold) {
        const severity = cslGate(1.0, zScore / (zThreshold * PHI), CSL_THRESHOLDS.MEDIUM);
        anomalies.push({ index: i, value: timeSeries[i], zScore, severity });
      }
    }

    this.pythiaMetrics.anomaliesDetected += anomalies.length;
    this.metrics.requestsHandled++;
    this.logger.info({ dataPoints: timeSeries.length, anomalies: anomalies.length }, 'Anomalies detected');

    return { anomalies, stats, zThreshold, totalPoints: timeSeries.length, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // TREND ANALYSIS
  // ─────────────────────────────────────────────────────────────

  /**
   * Identify trend direction and strength.
   * @param {number[]} data - Data points
   * @returns {Object} Trend analysis with direction and strength
   */
  analyzeTrend(data) {
    if (!data || data.length < fib(3)) {
      return { direction: 'flat', strength: 0, message: 'Insufficient data' };
    }

    const trend = this._linearTrend(data);
    const stats = this._computeStats(data);
    const normalizedSlope = stats.stdDev > 0 ? Math.abs(trend.slope) / stats.stdDev : 0;
    const strength = cslGate(1.0, normalizedSlope, CSL_THRESHOLDS.LOW);

    const direction = trend.slope > stats.stdDev * PSI * PSI ? 'up'
      : trend.slope < -stats.stdDev * PSI * PSI ? 'down' : 'flat';

    this.pythiaMetrics.trendsAnalyzed++;
    this.metrics.requestsHandled++;
    this.logger.info({ direction, strength: strength.toFixed(4), slope: trend.slope.toFixed(4) }, 'Trend analyzed');

    return { direction, strength, slope: trend.slope, intercept: trend.intercept, stats, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // CAPACITY PLANNING
  // ─────────────────────────────────────────────────────────────

  /**
   * Fibonacci-stepped capacity recommendations.
   * @param {Object} metrics - Current metrics
   * @param {number} metrics.currentUsage - Current resource usage
   * @param {number} metrics.maxCapacity - Maximum capacity
   * @param {number} [growthRate] - Expected growth rate (0-1)
   * @returns {Object} Capacity plan with Fibonacci-stepped recommendations
   */
  planCapacity(metrics, growthRate) {
    const current = metrics.currentUsage || 0;
    const max = metrics.maxCapacity || fib(10);
    const growth = growthRate || PSI * PSI;
    const utilization = max > 0 ? current / max : 0;

    const recommendations = [];
    const fibSteps = [fib(3), fib(4), fib(5), fib(6), fib(7)];

    for (const step of fibSteps) {
      const projectedUsage = current * (1 + growth * step);
      const projectedUtilization = max > 0 ? projectedUsage / max : 0;
      const urgency = cslGate(1.0, projectedUtilization, CSL_THRESHOLDS.MEDIUM);

      recommendations.push({
        timeHorizon: step,
        projectedUsage: Math.round(projectedUsage),
        projectedUtilization,
        urgency,
        action: projectedUtilization >= CSL_THRESHOLDS.HIGH ? 'scale-now'
          : projectedUtilization >= CSL_THRESHOLDS.MEDIUM ? 'plan-scaling'
            : projectedUtilization >= CSL_THRESHOLDS.LOW ? 'monitor' : 'nominal',
      });
    }

    this.pythiaMetrics.capacityPlans++;
    this.metrics.requestsHandled++;
    this.logger.info({ utilization: utilization.toFixed(4), growth, steps: recommendations.length }, 'Capacity planned');

    return { currentUtilization: utilization, growth, recommendations, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // RISK ASSESSMENT
  // ─────────────────────────────────────────────────────────────

  /**
   * Simplified Monte Carlo-style risk assessment.
   * @param {Object} scenario - Scenario descriptor
   * @param {number} scenario.probability - Event probability (0-1)
   * @param {number} scenario.impact - Impact magnitude (0-1)
   * @param {number} [scenario.simulations] - Number of simulations
   * @returns {Object} Risk assessment result
   */
  assessRisk(scenario) {
    const probability = scenario.probability || PSI;
    const impact = scenario.impact || PSI;
    const simCount = scenario.simulations || fib(8);

    let occurrences = 0;
    let totalImpact = 0;

    for (let i = 0; i < simCount; i++) {
      const seed = (i * 1103515245 + 12345) & 0x7fffffff;
      const roll = seed / 0x7fffffff;
      if (roll < probability) {
        occurrences++;
        const impactVariation = impact * (1 + (roll - PSI) * PSI);
        totalImpact += impactVariation;
      }
    }

    const expectedFrequency = occurrences / simCount;
    const expectedImpact = occurrences > 0 ? totalImpact / occurrences : 0;
    const riskScore = cslGate(expectedFrequency * expectedImpact, expectedFrequency, CSL_THRESHOLDS.LOW);

    const riskLevel = riskScore >= CSL_THRESHOLDS.HIGH ? 'critical'
      : riskScore >= CSL_THRESHOLDS.MEDIUM ? 'high'
        : riskScore >= CSL_THRESHOLDS.LOW ? 'medium' : 'low';

    this.pythiaMetrics.riskAssessments++;
    this.metrics.requestsHandled++;
    this.logger.info({ riskScore: riskScore.toFixed(4), riskLevel, simulations: simCount }, 'Risk assessed');

    return {
      riskScore, riskLevel, expectedFrequency, expectedImpact,
      simulations: simCount, occurrences,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  _computeStats(data) {
    const n = data.length;
    const mean = data.reduce((s, v) => s + v, 0) / n;
    const variance = data.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / n;
    const stdDev = Math.sqrt(variance);
    const min = Math.min(...data);
    const max = Math.max(...data);
    return { mean, variance, stdDev, min, max, count: n };
  }

  _linearTrend(data) {
    const n = data.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    for (let i = 0; i < n; i++) {
      sumX += i;
      sumY += data[i];
      sumXY += i * data[i];
      sumX2 += i * i;
    }
    const denom = n * sumX2 - sumX * sumX;
    const slope = denom !== 0 ? (n * sumXY - sumX * sumY) / denom : 0;
    const intercept = (sumY - slope * sumX) / n;
    return { slope, intercept };
  }

  _recordPrediction(entry) {
    this.predictionHistory.push({ ...entry, timestamp: new Date().toISOString() });
    while (this.predictionHistory.length > FIB[9]) {
      this.predictionHistory.shift();
    }
  }
}

export { PythiaNode, PythiaNode as Pythia };
