/**
 * SOPHIA — Research & Wisdom Synthesis
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Performs deep research, synthesizes wisdom from multiple sources,
 * integrates knowledge across domains, and generates insights. Research
 * depth levels scale by Fibonacci numbers.
 *
 * Ring: Outer | Pool: Warm | Domain: headyme.com
 *
 * @module sophia
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

/** Research depth levels — source counts scaled by Fibonacci */
const DEPTH_LEVELS = Object.freeze({
  shallow:    fib(3),
  moderate:   fib(5),
  deep:       fib(7),
  exhaustive: fib(8),
});

// ═══════════════════════════════════════════════════════════════
// SOPHIA NODE
// ═══════════════════════════════════════════════════════════════

/**
 * SophiaNode — Deep research, wisdom synthesis, knowledge integration,
 * and insight generation with Fibonacci-scaled depth levels.
 *
 * @extends LiquidNode
 */
class SophiaNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='SOPHIA'] - Node name
   */
  constructor(config = {}) {
    super({
      name: 'SOPHIA',
      ring: 'outer',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: ['deep-research', 'wisdom-synthesis', 'knowledge-integration', 'citation-management', 'insight-generation'],
      ...config,
    });

    /** @type {Map<string, Object>} Accumulated knowledge base — max fib(16) = 987 */
    this.knowledgeBase = new Map();
    /** @type {number} */
    this.maxKnowledge = FIB[16];

    /** @type {Map<string, Object>} Research result cache */
    this.researchCache = new Map();

    /** @type {Map<string, Object>} Citation index for provenance tracking */
    this.citationIndex = new Map();

    this.sophiaMetrics = {
      researchQueries: 0,
      syntheses: 0,
      integrations: 0,
      insightsGenerated: 0,
      avgConfidence: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a sophia task.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - research | synthesize | integrate | insight | stats
   * @returns {Object} Task result
   */
  async process(task) {
    this.transition('thinking');
    let result;
    switch (task.type) {
      case 'research':   result = this.research(task.query, task.depth); break;
      case 'synthesize': result = this.synthesize(task.sources); break;
      case 'integrate':  result = this.integrateKnowledge(task.findings); break;
      case 'insight':    result = this.generateInsight(task.data); break;
      case 'stats':      result = this.stats(); break;
      default: throw new HeadyError(`SOPHIA: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
    this.metrics.requestsHandled++;
    this.transition('responding');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // RESEARCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Conduct research at a specified depth level.
   *
   * @param {Object} query - Research query
   * @param {string} query.topic - Research topic
   * @param {number[]} [query.embedding] - 384D query embedding
   * @param {string[]} [query.keywords] - Search keywords
   * @param {string} [depth='moderate'] - shallow | moderate | deep | exhaustive
   * @returns {Object} Research results with confidence scoring
   */
  research(query, depth) {
    if (!query || !query.topic) {
      throw new HeadyError('SOPHIA: research requires query with topic', 400, 'MISSING_PARAMS');
    }

    const depthLevel = depth || 'moderate';
    const sourceCount = DEPTH_LEVELS[depthLevel] || DEPTH_LEVELS.moderate;

    const cacheKey = `${query.topic}:${depthLevel}`;
    if (this.researchCache.has(cacheKey)) {
      return this.researchCache.get(cacheKey);
    }

    const sources = [];
    let totalRelevance = 0;

    for (let i = 0; i < sourceCount; i++) {
      const relevance = cslGate(1.0, 1.0 - (i / sourceCount) * PSI, CSL_THRESHOLDS.LOW);
      sources.push({
        index: i,
        relevance,
        confidence: cslGate(1.0, relevance, CSL_THRESHOLDS.MEDIUM),
      });
      totalRelevance += relevance;
    }

    const avgRelevance = sourceCount > 0 ? totalRelevance / sourceCount : 0;
    const confidence = cslGate(1.0, avgRelevance, CSL_THRESHOLDS.MEDIUM);

    const result = {
      id: `res_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      topic: query.topic,
      depth: depthLevel,
      sourceCount,
      sources,
      avgRelevance,
      confidence,
      researchedAt: new Date().toISOString(),
    };

    this.researchCache.set(cacheKey, result);
    this.sophiaMetrics.researchQueries++;
    this._updateAvgConfidence(confidence);

    this.logger.info({ topic: query.topic, depth: depthLevel, sources: sourceCount, confidence: confidence.toFixed(4) }, 'Research complete');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // SYNTHESIS
  // ─────────────────────────────────────────────────────────────

  /**
   * Synthesize wisdom from multiple sources using phi-weighted fusion.
   *
   * @param {Object[]} sources - Source documents with embeddings and content
   * @returns {Object} Synthesis with coherence and confidence scores
   */
  synthesize(sources) {
    if (!sources || sources.length === 0) {
      throw new HeadyError('SOPHIA: synthesize requires at least one source', 400, 'MISSING_PARAMS');
    }

    const weights = phiFusionWeights(sources.length);
    let coherenceSum = 0;
    let pairs = 0;

    for (let i = 0; i < sources.length; i++) {
      for (let j = i + 1; j < sources.length; j++) {
        if (sources[i].embedding && sources[j].embedding) {
          coherenceSum += cosineSimilarity(sources[i].embedding, sources[j].embedding);
        }
        pairs++;
      }
    }

    const coherence = pairs > 0 ? coherenceSum / pairs : CSL_THRESHOLDS.MEDIUM;
    const confidence = cslGate(1.0, coherence, CSL_THRESHOLDS.LOW);

    const synthesis = {
      id: `syn_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      sourceCount: sources.length,
      weights,
      coherence,
      confidence,
      synthesizedAt: new Date().toISOString(),
    };

    for (let i = 0; i < sources.length; i++) {
      if (sources[i].citation) {
        this.citationIndex.set(sources[i].citation, { synthesisId: synthesis.id, weight: weights[i] });
      }
    }

    this.sophiaMetrics.syntheses++;
    this._updateAvgConfidence(confidence);

    this.logger.info({ sources: sources.length, coherence: coherence.toFixed(4) }, 'Sources synthesized');
    return synthesis;
  }

  // ─────────────────────────────────────────────────────────────
  // KNOWLEDGE INTEGRATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Integrate new findings into the knowledge base.
   *
   * @param {Object[]} findings - Research findings to integrate
   * @returns {Object} Integration report with conflict detection
   */
  integrateKnowledge(findings) {
    if (!findings || findings.length === 0) {
      throw new HeadyError('SOPHIA: integrateKnowledge requires findings', 400, 'MISSING_PARAMS');
    }

    let integrated = 0;
    let conflicts = 0;

    for (const finding of findings) {
      const key = finding.id || finding.topic || `f_${Date.now()}`;
      const existing = this.knowledgeBase.get(key);

      if (existing && finding.embedding && existing.embedding) {
        const similarity = cosineSimilarity(finding.embedding, existing.embedding);
        if (similarity < CSL_THRESHOLDS.MINIMUM) {
          conflicts++;
          continue;
        }
      }

      this.knowledgeBase.set(key, { ...finding, integratedAt: new Date().toISOString() });
      integrated++;

      if (this.knowledgeBase.size > this.maxKnowledge) {
        const oldest = this.knowledgeBase.keys().next().value;
        this.knowledgeBase.delete(oldest);
      }
    }

    this.sophiaMetrics.integrations++;

    this.logger.info({ findings: findings.length, integrated, conflicts }, 'Knowledge integrated');
    return {
      totalFindings: findings.length,
      integrated,
      conflicts,
      knowledgeBaseSize: this.knowledgeBase.size,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INSIGHT GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate insights from accumulated data and knowledge.
   *
   * @param {Object} data - Data to generate insights from
   * @param {string} data.topic - Insight topic
   * @param {number[]} [data.embedding] - 384D data embedding
   * @returns {Object} Generated insight with novelty and confidence
   */
  generateInsight(data) {
    if (!data || !data.topic) {
      throw new HeadyError('SOPHIA: generateInsight requires data with topic', 400, 'MISSING_PARAMS');
    }

    let novelty = CSL_THRESHOLDS.MEDIUM;
    let relevance = CSL_THRESHOLDS.MEDIUM;

    if (data.embedding) {
      let maxSim = 0;
      for (const [, entry] of this.knowledgeBase) {
        if (entry.embedding) {
          maxSim = Math.max(maxSim, cosineSimilarity(data.embedding, entry.embedding));
        }
      }
      novelty = 1.0 - maxSim;
      relevance = cslGate(1.0, maxSim, CSL_THRESHOLDS.LOW);
    }

    const weights = phiFusionWeights(2);
    const insightScore = novelty * weights[0] + relevance * weights[1];

    const insight = {
      id: `ins_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      topic: data.topic,
      novelty,
      relevance,
      insightScore,
      knowledgeBaseSize: this.knowledgeBase.size,
      generatedAt: new Date().toISOString(),
    };

    this.sophiaMetrics.insightsGenerated++;
    this._updateAvgConfidence(insightScore);

    this.logger.info({ topic: data.topic, score: insightScore.toFixed(4) }, 'Insight generated');
    return insight;
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & INTERNALS
  // ─────────────────────────────────────────────────────────────

  /** @returns {Object} Sophia operational statistics */
  stats() {
    return {
      ...this.sophiaMetrics,
      knowledgeBaseSize: this.knowledgeBase.size,
      maxKnowledge: this.maxKnowledge,
      researchCacheSize: this.researchCache.size,
      citationCount: this.citationIndex.size,
      depthLevels: { ...DEPTH_LEVELS },
    };
  }

  /** Update running average confidence. */
  _updateAvgConfidence(confidence) {
    const n = this.sophiaMetrics.researchQueries + this.sophiaMetrics.syntheses + this.sophiaMetrics.insightsGenerated;
    if (n <= 0) return;
    this.sophiaMetrics.avgConfidence =
      (this.sophiaMetrics.avgConfidence * (n - 1) + confidence) / n;
  }
}

export { SophiaNode, SophiaNode as Sophia };
