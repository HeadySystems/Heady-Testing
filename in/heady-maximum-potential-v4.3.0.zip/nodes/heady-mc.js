/**
 * HeadyMC — Monte Carlo Simulation & Optimization
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * HeadyMC runs Monte Carlo simulations across the Heady ecosystem,
 * optimizes objectives under constraints, models risk scenarios, and
 * performs multi-metric scenario analysis. Convergence is phi-gated:
 * simulations halt early when running-mean stdDev falls below PSI⁴.
 *
 * Ring: Governance | Pool: Cold | Domain: headyme.com
 *
 * @module heady-mc
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// CONVERGENCE THRESHOLD
// ═══════════════════════════════════════════════════════════════

/** Early-stop when running-mean stdDev drops below PSI⁴ ≈ 0.146 */
const CONVERGENCE_THRESHOLD = Math.pow(PSI, 4);

// ═══════════════════════════════════════════════════════════════
// HEADY MC NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyMCNode — Monte Carlo simulation, optimization, and scenario analysis.
 *
 * Runs bounded-iteration simulations, tracks running statistics, checks
 * phi-gated convergence, optimizes objectives via random search under
 * constraints, models risk distributions, and analyzes multi-metric scenarios.
 *
 * @extends LiquidNode
 */
class HeadyMCNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyMC']
   */
  constructor(config = {}) {
    super({
      name: 'HeadyMC',
      ring: 'governance',
      pool: 'cold',
      domain: 'headyme.com',
      capabilities: [
        'monte-carlo',
        'simulation',
        'optimization',
        'risk-modeling',
        'scenario-analysis',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Simulation result cache — FIB[16] = 987 max */
    this.simulationCache = new Map();
    this.maxSimulationCache = SIZING.CACHE_SIZE;

    /** @type {Object[]} Optimization history — FIB[8] = 21 entries */
    this.optimizationHistory = [];
    this.maxOptimizationHistory = FIB[8];

    /** @type {Object} Convergence metrics for the most recent simulation */
    this.convergenceMetrics = {
      lastConverged: false,
      lastIterationsUsed: 0,
      lastRunningStdDev: 0,
    };

    this.mcMetrics = {
      totalSimulations: 0,
      totalOptimizations: 0,
      riskModels: 0,
      scenarioAnalyses: 0,
      earlyConvergences: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a Monte Carlo task.
   * @param {Object} task
   * @param {string} task.type - simulate | optimize | modelRisk | analyzeScenarios
   * @returns {Object}
   */
  async process(task) {
    this.metrics.requestsHandled++;
    switch (task.type) {
      case 'simulate':         return this.simulate(task.model, task.iterations);
      case 'optimize':         return this.optimize(task.objective, task.constraints);
      case 'modelRisk':        return this.modelRisk(task.scenarios);
      case 'analyzeScenarios': return this.analyzeScenarios(task.scenarios, task.metrics);
      default:
        throw new HeadyError(`HeadyMC: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // SIMULATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Run a Monte Carlo simulation.
   * @param {Function|Object} model - Model function or descriptor with evaluate()
   * @param {number} [iterations] - Max iterations, defaults to fib(16) = 987
   * @returns {Object} Statistical results with convergence info
   */
  simulate(model, iterations) {
    if (!model) {
      throw new HeadyError('HeadyMC: model is required', 400, 'MISSING_MODEL');
    }

    const maxIter = iterations || FIB[16];
    const evaluator = typeof model === 'function' ? model : model.evaluate;
    if (typeof evaluator !== 'function') {
      throw new HeadyError('HeadyMC: model must be a function or have evaluate()', 400, 'INVALID_MODEL');
    }

    const results = [];
    let runningSum = 0;
    let runningMeans = [];
    let converged = false;
    let iterationsUsed = 0;

    for (let i = 0; i < maxIter; i++) {
      const sample = evaluator(i, maxIter);
      results.push(sample);
      runningSum += sample;
      const currentMean = runningSum / (i + 1);
      runningMeans.push(currentMean);
      iterationsUsed = i + 1;

      // Check convergence every fib(5) = 5 iterations after a minimum of fib(7) = 13
      if (i >= FIB[7] && i % FIB[5] === 0) {
        const recentMeans = runningMeans.slice(-FIB[7]);
        const meanOfMeans = recentMeans.reduce((s, v) => s + v, 0) / recentMeans.length;
        const variance = recentMeans.reduce((s, v) => s + Math.pow(v - meanOfMeans, 2), 0) / recentMeans.length;
        const stdDev = Math.sqrt(variance);

        if (stdDev < CONVERGENCE_THRESHOLD) {
          converged = true;
          this.mcMetrics.earlyConvergences++;
          break;
        }
      }
    }

    const stats = this._computeStats(results);

    this.convergenceMetrics = {
      lastConverged: converged,
      lastIterationsUsed: iterationsUsed,
      lastRunningStdDev: runningMeans.length > 1
        ? Math.sqrt(runningMeans.slice(-FIB[7]).reduce((s, v, _, a) => {
            const m = a.reduce((ss, vv) => ss + vv, 0) / a.length;
            return s + Math.pow(v - m, 2);
          }, 0) / Math.min(runningMeans.length, FIB[7]))
        : 0,
    };

    // Cache result
    const cacheKey = `sim_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    if (this.simulationCache.size >= this.maxSimulationCache) {
      const oldest = this.simulationCache.keys().next().value;
      this.simulationCache.delete(oldest);
    }
    this.simulationCache.set(cacheKey, { stats, converged, iterationsUsed });

    this.mcMetrics.totalSimulations++;
    this.logger.info({
      iterations: iterationsUsed, maxIter, converged, mean: stats.mean.toFixed(4),
    }, 'Simulation complete');

    return {
      stats,
      converged,
      iterationsUsed,
      maxIterations: maxIter,
      cacheKey,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // OPTIMIZATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Optimize an objective function under constraints via random search.
   * @param {Function} objective - Objective function to maximize (params → score)
   * @param {Object} constraints - { paramName: { min, max } }
   * @returns {Object} Best parameters and score
   */
  optimize(objective, constraints) {
    if (!objective || typeof objective !== 'function') {
      throw new HeadyError('HeadyMC: objective function is required', 400, 'MISSING_OBJECTIVE');
    }
    if (!constraints || typeof constraints !== 'object') {
      throw new HeadyError('HeadyMC: constraints object is required', 400, 'MISSING_CONSTRAINTS');
    }

    const paramNames = Object.keys(constraints);
    const searchIterations = FIB[16]; // 987
    let bestScore = -Infinity;
    let bestParams = null;
    const scores = [];

    for (let i = 0; i < searchIterations; i++) {
      const params = {};
      for (const name of paramNames) {
        const { min, max } = constraints[name];
        // Phi-weighted exploration: narrow toward best as iterations progress
        const progress = i / searchIterations;
        const spread = 1.0 - progress * PSI;
        params[name] = min + (max - min) * (Math.random() * spread + (1 - spread) * Math.random());
      }

      const score = objective(params);
      scores.push(score);

      if (score > bestScore) {
        bestScore = score;
        bestParams = { ...params };
      }
    }

    const result = {
      bestParams,
      bestScore,
      iterations: searchIterations,
      scoreStats: this._computeStats(scores),
      timestamp: new Date().toISOString(),
    };

    this.optimizationHistory.push(result);
    if (this.optimizationHistory.length > this.maxOptimizationHistory) {
      this.optimizationHistory.shift();
    }

    this.mcMetrics.totalOptimizations++;
    this.logger.info({
      bestScore: bestScore.toFixed(4), iterations: searchIterations, params: paramNames.length,
    }, 'Optimization complete');

    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // RISK MODELING
  // ─────────────────────────────────────────────────────────────

  /**
   * Model risk across a set of scenarios.
   * @param {Object[]} scenarios - Array of { name, probability, impact, embedding? }
   * @returns {Object} Risk model with weighted scores and classification
   */
  modelRisk(scenarios) {
    if (!scenarios || !Array.isArray(scenarios) || scenarios.length === 0) {
      throw new HeadyError('HeadyMC: scenarios array is required', 400, 'MISSING_SCENARIOS');
    }

    const weights = phiFusionWeights(scenarios.length);
    const riskScores = scenarios.map((s, i) => {
      const probability = s.probability ?? PSI;
      const impact = s.impact ?? PSI;
      const rawRisk = probability * impact;
      const weightedRisk = rawRisk * weights[i];
      return {
        name: s.name || `scenario-${i}`,
        probability,
        impact,
        rawRisk,
        weightedRisk,
      };
    });

    const totalWeightedRisk = riskScores.reduce((s, r) => s + r.weightedRisk, 0);
    const maxRawRisk = Math.max(...riskScores.map(r => r.rawRisk));

    let classification;
    if (maxRawRisk >= CSL_THRESHOLDS.HIGH) classification = 'critical';
    else if (maxRawRisk >= CSL_THRESHOLDS.MEDIUM) classification = 'high';
    else if (maxRawRisk >= CSL_THRESHOLDS.LOW) classification = 'moderate';
    else if (maxRawRisk >= CSL_THRESHOLDS.MINIMUM) classification = 'low';
    else classification = 'negligible';

    this.mcMetrics.riskModels++;
    this.logger.info({
      scenarioCount: scenarios.length, classification, totalWeightedRisk: totalWeightedRisk.toFixed(4),
    }, 'Risk model complete');

    return {
      riskScores,
      totalWeightedRisk,
      maxRawRisk,
      classification,
      scenarioCount: scenarios.length,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // SCENARIO ANALYSIS
  // ─────────────────────────────────────────────────────────────

  /**
   * Analyze scenarios across multiple metrics.
   * @param {Object[]} scenarios - Array of scenario objects with metric values
   * @param {string[]} metrics - Metric names to analyze across scenarios
   * @returns {Object} Per-metric statistics and scenario rankings
   */
  analyzeScenarios(scenarios, metrics) {
    if (!scenarios || !Array.isArray(scenarios) || scenarios.length === 0) {
      throw new HeadyError('HeadyMC: scenarios array is required', 400, 'MISSING_SCENARIOS');
    }
    if (!metrics || !Array.isArray(metrics) || metrics.length === 0) {
      throw new HeadyError('HeadyMC: metrics array is required', 400, 'MISSING_METRICS');
    }

    const analysis = {};

    for (const metric of metrics) {
      const values = scenarios
        .map((s, i) => ({ index: i, name: s.name || `scenario-${i}`, value: s[metric] ?? 0 }))
        .sort((a, b) => b.value - a.value);

      const numericValues = values.map(v => v.value);
      const stats = this._computeStats(numericValues);

      analysis[metric] = {
        stats,
        ranking: values.map(v => ({ name: v.name, value: v.value })),
        bestScenario: values[0]?.name || null,
        worstScenario: values[values.length - 1]?.name || null,
      };
    }

    // Composite ranking via phi-weighted fusion across metrics
    const metricWeights = phiFusionWeights(metrics.length);
    const compositeScores = scenarios.map((s, i) => {
      let score = 0;
      for (let m = 0; m < metrics.length; m++) {
        const metricName = metrics[m];
        const metricStats = analysis[metricName].stats;
        const value = s[metricName] ?? 0;
        // Normalize to [0, 1] range based on stats
        const range = metricStats.max - metricStats.min;
        const normalized = range > 0 ? (value - metricStats.min) / range : PSI;
        score += normalized * metricWeights[m];
      }
      return { name: s.name || `scenario-${i}`, compositeScore: score };
    });

    compositeScores.sort((a, b) => b.compositeScore - a.compositeScore);

    this.mcMetrics.scenarioAnalyses++;
    this.logger.info({
      scenarioCount: scenarios.length, metricCount: metrics.length,
      bestComposite: compositeScores[0]?.name,
    }, 'Scenario analysis complete');

    return {
      analysis,
      compositeRanking: compositeScores,
      scenarioCount: scenarios.length,
      metricCount: metrics.length,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // STATISTICAL HELPERS
  // ─────────────────────────────────────────────────────────────

  /**
   * Compute descriptive statistics for a numeric array.
   * @param {number[]} values
   * @returns {Object} { mean, median, stdDev, min, max, p5, p25, p75, p95 }
   * @private
   */
  _computeStats(values) {
    if (!values || values.length === 0) {
      return { mean: 0, median: 0, stdDev: 0, min: 0, max: 0, p5: 0, p25: 0, p75: 0, p95: 0 };
    }

    const sorted = [...values].sort((a, b) => a - b);
    const n = sorted.length;
    const mean = sorted.reduce((s, v) => s + v, 0) / n;
    const variance = sorted.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / n;

    return {
      mean,
      median: n % 2 === 1 ? sorted[Math.floor(n / 2)] : (sorted[n / 2 - 1] + sorted[n / 2]) / 2,
      stdDev: Math.sqrt(variance),
      min: sorted[0],
      max: sorted[n - 1],
      p5: sorted[Math.floor(n * 0.05)],
      p25: sorted[Math.floor(n * 0.25)],
      p75: sorted[Math.floor(n * 0.75)],
      p95: sorted[Math.floor(n * 0.95)],
    };
  }
}

export { HeadyMCNode, HeadyMCNode as HeadyMC };
