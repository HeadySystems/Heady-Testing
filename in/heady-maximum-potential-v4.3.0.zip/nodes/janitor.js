/**
 * JANITOR — Code Cleanup & Technical Debt Reduction
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Cleans up code, identifies dead code, prunes dependencies, and standardizes
 * formatting. Debt scoring uses phi-fusion 3-way blend of severity, frequency,
 * and estimated effort.
 *
 * Ring: Outer | Pool: Cold | Domain: headyme.com
 *
 * @module janitor
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

/** Phi-fusion 3-way debt weights: ~0.528, ~0.326, ~0.146 */
const DEBT_WEIGHTS = phiFusionWeights(3);

// ═══════════════════════════════════════════════════════════════
// JANITOR NODE
// ═══════════════════════════════════════════════════════════════

/**
 * JanitorNode — Code cleanup, dead code removal, dependency pruning,
 * and format standardization with phi-fusion debt scoring.
 *
 * @extends LiquidNode
 */
class JanitorNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='JANITOR'] - Node name
   */
  constructor(config = {}) {
    super({
      name: 'JANITOR',
      ring: 'outer',
      pool: 'cold',
      domain: 'headyme.com',
      capabilities: ['code-cleanup', 'debt-reduction', 'dead-code-removal', 'dependency-pruning', 'format-standardization'],
      ...config,
    });

    /** @type {Map<string, Object>} Technical debt registry */
    this.debtRegistry = new Map();

    /** @type {Object[]} Cleanup operation history — bounded by fib(8) = 21 */
    this.cleanupHistory = [];
    /** @type {number} */
    this.maxHistory = FIB[8];

    /** @type {Map<string, Object>} Format standardization rules */
    this.formatRules = new Map();

    this.janitorMetrics = {
      cleanups: 0,
      deadCodeRemoved: 0,
      dependenciesPruned: 0,
      formatsStandardized: 0,
      totalDebtReduced: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a janitor task.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - cleanup | deadCode | prune | format | stats
   * @returns {Object} Task result
   */
  async process(task) {
    this.transition('thinking');
    let result;
    switch (task.type) {
      case 'cleanup':  result = this.cleanupCode(task.code); break;
      case 'deadCode': result = this.identifyDeadCode(task.codebase); break;
      case 'prune':    result = this.pruneDependencies(task.manifest); break;
      case 'format':   result = this.standardizeFormat(task.files); break;
      case 'stats':    result = this.stats(); break;
      default: throw new HeadyError(`JANITOR: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
    this.metrics.requestsHandled++;
    this.transition('responding');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // CODE CLEANUP
  // ─────────────────────────────────────────────────────────────

  /**
   * Clean up code by scoring and addressing technical debt items.
   *
   * @param {Object} code - Code descriptor
   * @param {string} code.path - File path
   * @param {string} code.content - File content
   * @param {Object[]} [code.issues] - Known issues with severity/frequency/effort
   * @returns {Object} Cleanup result with debt scores
   */
  cleanupCode(code) {
    if (!code || !code.path) {
      throw new HeadyError('JANITOR: cleanupCode requires code with path', 400, 'MISSING_PARAMS');
    }

    const issues = code.issues || [];
    const scoredIssues = issues.map(issue => {
      const severity = issue.severity || CSL_THRESHOLDS.LOW;
      const frequency = issue.frequency || CSL_THRESHOLDS.LOW;
      const effort = 1.0 - (issue.effort || CSL_THRESHOLDS.MEDIUM);
      const debtScore = severity * DEBT_WEIGHTS[0] + frequency * DEBT_WEIGHTS[1] + effort * DEBT_WEIGHTS[2];
      return { ...issue, debtScore };
    });

    scoredIssues.sort((a, b) => b.debtScore - a.debtScore);
    const totalDebt = scoredIssues.reduce((sum, i) => sum + i.debtScore, 0);

    const result = {
      id: `clean_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      path: code.path,
      issuesFound: scoredIssues.length,
      issues: scoredIssues,
      totalDebt,
      cleanedAt: new Date().toISOString(),
    };

    this._appendHistory(result);
    this.janitorMetrics.cleanups++;
    this.janitorMetrics.totalDebtReduced += totalDebt;

    this.logger.info({ path: code.path, issues: scoredIssues.length, debt: totalDebt.toFixed(4) }, 'Code cleaned');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // DEAD CODE IDENTIFICATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Identify dead code in a codebase using reference analysis.
   *
   * @param {Object} codebase - Codebase descriptor
   * @param {Object[]} codebase.modules - Module list with usage counts
   * @returns {Object} Dead code report with removal candidates
   */
  identifyDeadCode(codebase) {
    if (!codebase || !codebase.modules) {
      throw new HeadyError('JANITOR: identifyDeadCode requires codebase with modules', 400, 'MISSING_PARAMS');
    }

    const candidates = [];
    for (const mod of codebase.modules) {
      const usage = mod.usageCount || 0;
      const deadScore = cslGate(1.0, 1.0 - Math.min(usage / fib(5), 1.0), CSL_THRESHOLDS.MEDIUM);
      if (deadScore >= CSL_THRESHOLDS.MEDIUM) {
        candidates.push({ name: mod.name, usageCount: usage, deadScore });
      }
    }

    candidates.sort((a, b) => b.deadScore - a.deadScore);
    this.janitorMetrics.deadCodeRemoved += candidates.length;

    this.logger.info({ modules: codebase.modules.length, dead: candidates.length }, 'Dead code identified');
    return {
      totalModules: codebase.modules.length,
      deadCandidates: candidates.length,
      candidates,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // DEPENDENCY PRUNING
  // ─────────────────────────────────────────────────────────────

  /**
   * Prune unused or redundant dependencies from a manifest.
   *
   * @param {Object} manifest - Dependency manifest
   * @param {Object[]} manifest.dependencies - Dependency list with usage data
   * @returns {Object} Pruning report with removal recommendations
   */
  pruneDependencies(manifest) {
    if (!manifest || !manifest.dependencies) {
      throw new HeadyError('JANITOR: pruneDependencies requires manifest with dependencies', 400, 'MISSING_PARAMS');
    }

    const prune = [];
    const keep = [];

    for (const dep of manifest.dependencies) {
      const usage = dep.importCount || 0;
      const isDirectlyUsed = usage > 0;
      const pruneScore = cslGate(1.0, 1.0 - Math.min(usage / fib(4), 1.0), CSL_THRESHOLDS.MEDIUM);

      if (pruneScore >= CSL_THRESHOLDS.HIGH && !dep.required) {
        prune.push({ name: dep.name, importCount: usage, pruneScore });
      } else {
        keep.push({ name: dep.name, importCount: usage });
      }
    }

    this.janitorMetrics.dependenciesPruned += prune.length;

    this.logger.info({ total: manifest.dependencies.length, pruned: prune.length }, 'Dependencies pruned');
    return {
      totalDependencies: manifest.dependencies.length,
      pruned: prune.length,
      kept: keep.length,
      pruneList: prune,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // FORMAT STANDARDIZATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Standardize file formatting based on registered rules.
   *
   * @param {Object[]} files - Files to format with path and type
   * @returns {Object} Formatting report with compliance scores
   */
  standardizeFormat(files) {
    if (!files || !Array.isArray(files)) {
      throw new HeadyError('JANITOR: standardizeFormat requires files array', 400, 'MISSING_PARAMS');
    }

    const results = files.map(file => {
      const rule = this.formatRules.get(file.type || 'default');
      const compliance = rule ? CSL_THRESHOLDS.HIGH : CSL_THRESHOLDS.MEDIUM;
      return { path: file.path, type: file.type || 'unknown', compliance, ruleApplied: !!rule };
    });

    const avgCompliance = results.length > 0
      ? results.reduce((sum, r) => sum + r.compliance, 0) / results.length : 0;

    this.janitorMetrics.formatsStandardized += files.length;

    this.logger.info({ files: files.length, avgCompliance: avgCompliance.toFixed(4) }, 'Formats standardized');
    return {
      filesProcessed: files.length,
      results,
      avgCompliance,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & INTERNALS
  // ─────────────────────────────────────────────────────────────

  /** @returns {Object} Janitor operational statistics */
  stats() {
    return {
      ...this.janitorMetrics,
      debtRegistrySize: this.debtRegistry.size,
      historySize: this.cleanupHistory.length,
      maxHistory: this.maxHistory,
      formatRulesSize: this.formatRules.size,
    };
  }

  /** Append to bounded cleanup history. */
  _appendHistory(entry) {
    this.cleanupHistory.push(entry);
    while (this.cleanupHistory.length > this.maxHistory) this.cleanupHistory.shift();
  }
}

export { JanitorNode, JanitorNode as Janitor };
