/**
 * HeadyAware — Ethics Monitoring & Bias Detection
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * HeadyAware is the ethical compass of the governance shell. It monitors
 * outputs for bias, assesses fairness across protected attributes, scores
 * value alignment against the HeadyConnection mission embedding, and
 * evaluates the social impact of proposed changes.
 *
 * Ring: Governance | Pool: Governance | Domain: headyme.com
 *
 * @module heady-aware
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════

const EMBEDDING_DIM = 384;

/** Bias detection tolerance — demographic parity gap must be below this */
const PARITY_TOLERANCE = Math.pow(PSI, 3);

// ═══════════════════════════════════════════════════════════════
// HEADY AWARE NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyAwareNode — Ethics monitoring, bias detection, and value alignment.
 *
 * Monitors outputs for ethical violations, detects statistical bias across
 * protected attributes, and scores value alignment using cosine similarity
 * against the HeadyConnection mission embedding.
 *
 * @extends LiquidNode
 */
class HeadyAwareNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyAware']
   */
  constructor(config = {}) {
    super({
      name: 'HeadyAware',
      ring: 'governance',
      pool: 'governance',
      domain: 'headyme.com',
      capabilities: [
        'ethics-monitoring',
        'bias-detection',
        'fairness-analysis',
        'impact-assessment',
        'value-alignment',
      ],
      ...config,
    });

    /** @type {Object[]} Bounded ethics log — FIB[9] = 34 max */
    this.ethicsLog = [];
    this.maxEthicsLog = FIB[9];

    /** @type {Map<string, Object>} Baseline distributions for bias detection */
    this.biasBaselines = new Map();

    /**
     * Mission embedding — 384D zero-initialized.
     * In production this is loaded from vector memory at init time.
     * @type {number[]}
     */
    this.missionEmbedding = new Array(EMBEDDING_DIM).fill(0);

    this.ethicsMetrics = {
      totalMonitored: 0,
      biasDetections: 0,
      fairnessAnalyses: 0,
      impactAssessments: 0,
      alignmentChecks: 0,
      violations: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process an ethics task.
   * @param {Object} task
   * @param {string} task.type - monitorEthics | detectBias | analyzeFairness | assessImpact | checkAlignment
   * @returns {Object}
   */
  async process(task) {
    this.metrics.requestsHandled++;
    switch (task.type) {
      case 'monitorEthics':  return this.monitorEthics(task.output, task.context);
      case 'detectBias':     return this.detectBias(task.data, task.protectedAttributes);
      case 'analyzeFairness': return this.analyzeFairness(task.model, task.dataset);
      case 'assessImpact':   return this.assessImpact(task.change, task.stakeholders);
      case 'checkAlignment': return this.checkAlignment(task.action, task.values);
      default:
        throw new HeadyError(`HeadyAware: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // ETHICS MONITORING
  // ─────────────────────────────────────────────────────────────

  /**
   * Monitor an output for ethical concerns.
   * @param {Object} output - Output to monitor (with optional embedding)
   * @param {Object} [context] - Contextual information
   * @returns {Object} Monitoring result with flags and score
   */
  monitorEthics(output, context = {}) {
    if (!output) throw new HeadyError('HeadyAware: output is required', 400, 'MISSING_OUTPUT');

    const flags = [];

    if (output.embedding) {
      const missionNorm = Math.sqrt(this.missionEmbedding.reduce((s, v) => s + v * v, 0));
      if (missionNorm > 0) {
        const sim = cosineSimilarity(output.embedding, this.missionEmbedding);
        if (sim < CSL_THRESHOLDS.MINIMUM) {
          flags.push({ type: 'mission-drift', severity: 'warning', similarity: sim });
        }
      }
    }

    if (output.sensitiveContent) {
      flags.push({ type: 'sensitive-content', severity: 'warning', details: 'Output flagged as sensitive' });
    }

    if (context.excludedGroups && context.excludedGroups.length > 0) {
      flags.push({ type: 'exclusion-risk', severity: 'error', groups: context.excludedGroups });
    }

    const score = flags.length === 0 ? 1.0
      : Math.max(0, 1.0 - flags.filter(f => f.severity === 'error').length * PSI
        - flags.filter(f => f.severity === 'warning').length * Math.pow(PSI, 3));

    this.ethicsMetrics.totalMonitored++;
    if (flags.length > 0) this.ethicsMetrics.violations++;

    const entry = { action: 'monitorEthics', score, flags, timestamp: new Date().toISOString() };
    this._appendEthicsLog(entry);
    this.logger.info({ flags: flags.length, score: score.toFixed(4) }, 'Ethics monitored');

    return { clean: flags.length === 0, score, flags };
  }

  // ─────────────────────────────────────────────────────────────
  // BIAS DETECTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Detect bias in data across protected attributes.
   *
   * Checks statistical parity: for each protected attribute, computes
   * the positive outcome rate per group and flags gaps exceeding PSI³.
   *
   * @param {Object[]} data - Array of data points with outcomes
   * @param {string[]} protectedAttributes - Attribute names to check
   * @returns {Object} Bias detection result
   */
  detectBias(data, protectedAttributes) {
    if (!data || !protectedAttributes) {
      throw new HeadyError('HeadyAware: data and protectedAttributes are required', 400, 'MISSING_PARAMS');
    }

    const biasFlags = [];

    for (const attr of protectedAttributes) {
      const groups = new Map();

      for (const point of data) {
        const groupKey = String(point[attr] ?? 'unknown');
        if (!groups.has(groupKey)) groups.set(groupKey, { positive: 0, total: 0 });
        const g = groups.get(groupKey);
        g.total++;
        if (point.outcome) g.positive++;
      }

      const rates = [];
      for (const [group, counts] of groups) {
        const rate = counts.total > 0 ? counts.positive / counts.total : 0;
        rates.push({ group, rate, count: counts.total });
      }

      if (rates.length >= 2) {
        const maxRate = Math.max(...rates.map(r => r.rate));
        const minRate = Math.min(...rates.map(r => r.rate));
        const gap = maxRate - minRate;

        if (gap > PARITY_TOLERANCE) {
          biasFlags.push({
            attribute: attr,
            gap,
            tolerance: PARITY_TOLERANCE,
            groups: rates,
            severity: gap > PSI ? 'error' : 'warning',
          });
        }
      }
    }

    this.ethicsMetrics.biasDetections++;
    if (biasFlags.length > 0) this.ethicsMetrics.violations++;

    this._appendEthicsLog({ action: 'detectBias', flags: biasFlags.length, timestamp: new Date().toISOString() });
    this.logger.info({ attributes: protectedAttributes.length, flags: biasFlags.length }, 'Bias detection complete');

    return { biased: biasFlags.length > 0, flags: biasFlags, attributesChecked: protectedAttributes.length };
  }

  // ─────────────────────────────────────────────────────────────
  // FAIRNESS ANALYSIS
  // ─────────────────────────────────────────────────────────────

  /**
   * Analyze fairness of a model on a dataset.
   * @param {Object} model - Model descriptor with predictions per group
   * @param {Object} dataset - Dataset descriptor with ground truth per group
   * @returns {Object} Fairness analysis result
   */
  analyzeFairness(model, dataset) {
    if (!model || !dataset) {
      throw new HeadyError('HeadyAware: model and dataset are required', 400, 'MISSING_PARAMS');
    }

    const metrics = {};
    const groups = Object.keys(dataset.groups || {});

    for (const group of groups) {
      const truth = dataset.groups[group] || {};
      const preds = model.predictions?.[group] || {};
      const tp = preds.truePositive || 0;
      const fp = preds.falsePositive || 0;
      const fn = preds.falseNegative || 0;
      const tn = preds.trueNegative || 0;
      const total = tp + fp + fn + tn;
      metrics[group] = {
        accuracy: total > 0 ? (tp + tn) / total : 0,
        positiveRate: (tp + fp) > 0 ? tp / (tp + fp) : 0,
        selectionRate: total > 0 ? (tp + fp) / total : 0,
      };
    }

    const selectionRates = Object.values(metrics).map(m => m.selectionRate);
    const maxSR = Math.max(...selectionRates, 0);
    const minSR = Math.min(...selectionRates, 0);
    const disparateImpact = maxSR > 0 ? minSR / maxSR : 1.0;
    const fair = disparateImpact >= CSL_THRESHOLDS.MEDIUM;

    this.ethicsMetrics.fairnessAnalyses++;
    this.logger.info({ groups: groups.length, disparateImpact: disparateImpact.toFixed(4), fair }, 'Fairness analyzed');

    return { fair, disparateImpact, groupMetrics: metrics, groupCount: groups.length };
  }

  // ─────────────────────────────────────────────────────────────
  // IMPACT ASSESSMENT
  // ─────────────────────────────────────────────────────────────

  /**
   * Assess the impact of a change on stakeholders.
   * @param {Object} change - Change descriptor with scope and effects
   * @param {Object[]} stakeholders - Array of stakeholder descriptors
   * @returns {Object} Impact assessment result
   */
  assessImpact(change, stakeholders) {
    if (!change) throw new HeadyError('HeadyAware: change is required', 400, 'MISSING_CHANGE');

    const assessments = (stakeholders || []).map(s => {
      const positiveEffect = s.benefit || 0;
      const negativeEffect = s.harm || 0;
      const netImpact = positiveEffect - negativeEffect;
      const severity = negativeEffect > PSI ? 'high' : negativeEffect > Math.pow(PSI, 2) ? 'medium' : 'low';
      return { stakeholder: s.name || s.id, netImpact, positiveEffect, negativeEffect, severity };
    });

    const weights = phiFusionWeights(Math.max(assessments.length, 1));
    const compositeImpact = assessments.length > 0
      ? assessments.reduce((sum, a, i) => sum + a.netImpact * weights[i], 0)
      : 0;
    const acceptable = compositeImpact >= 0 || Math.abs(compositeImpact) < Math.pow(PSI, 3);

    this.ethicsMetrics.impactAssessments++;
    this._appendEthicsLog({ action: 'assessImpact', compositeImpact, acceptable, timestamp: new Date().toISOString() });
    this.logger.info({ stakeholders: assessments.length, compositeImpact: compositeImpact.toFixed(4), acceptable }, 'Impact assessed');

    return { acceptable, compositeImpact, assessments, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // VALUE ALIGNMENT
  // ─────────────────────────────────────────────────────────────

  /**
   * Check if an action aligns with specified values using cosine similarity.
   * @param {Object} action - Action descriptor with optional embedding
   * @param {Object} values - Values descriptor with optional embedding and keywords
   * @returns {Object} Alignment check result
   */
  checkAlignment(action, values) {
    if (!action) throw new HeadyError('HeadyAware: action is required', 400, 'MISSING_ACTION');

    let embeddingScore = 0;
    if (action.embedding && values?.embedding) {
      const sim = cosineSimilarity(action.embedding, values.embedding);
      embeddingScore = cslGate(1.0, sim, CSL_THRESHOLDS.LOW);
    }

    let keywordScore = 0;
    const valueKeywords = values?.keywords || ['community', 'equity', 'empowerment', 'inclusion'];
    if (action.description) {
      const descLower = action.description.toLowerCase();
      const matches = valueKeywords.filter(k => descLower.includes(k.toLowerCase()));
      keywordScore = valueKeywords.length > 0 ? matches.length / valueKeywords.length : 0;
    }

    const fusionWeights = phiFusionWeights(2);
    const score = action.embedding && values?.embedding
      ? embeddingScore * fusionWeights[0] + keywordScore * fusionWeights[1]
      : keywordScore;
    const aligned = score >= CSL_THRESHOLDS.MINIMUM;

    this.ethicsMetrics.alignmentChecks++;
    this.logger.info({ aligned, score: score.toFixed(4) }, 'Alignment checked');

    return { aligned, score, embeddingScore, keywordScore, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────────────────

  _appendEthicsLog(entry) {
    this.ethicsLog.push(entry);
    if (this.ethicsLog.length > this.maxEthicsLog) this.ethicsLog.shift();
  }
}

export { HeadyAwareNode, HeadyAwareNode as HeadyAware };
