/**
 * HeadyRisks — Risk Assessment & Security Audit Node
 *
 * Governance Shell node responsible for risk assessment, security auditing,
 * threat analysis, vulnerability scoring, and mitigation planning.
 * Uses CVSS-inspired scoring with phi-fusion weights.
 *
 * Sacred Geometry v4.0 — Zero Magic Numbers
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * @module heady-risks
 * @version 4.3.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD,
  phiBackoff, phiFusionWeights, phiAdaptiveInterval,
  cslGate, cosineSimilarity, SIZING, POOL_SIZES,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ─── Risk Classification ───────────────────────────────────────────────────

const RISK_LEVELS = Object.freeze({
  CRITICAL: { min: CSL_THRESHOLDS.CRITICAL, label: 'critical', color: '#d44a00' },
  HIGH:     { min: CSL_THRESHOLDS.HIGH,     label: 'high',     color: '#d4a017' },
  MEDIUM:   { min: CSL_THRESHOLDS.MEDIUM,   label: 'medium',   color: '#d4d400' },
  LOW:      { min: CSL_THRESHOLDS.LOW,      label: 'low',      color: '#00d4aa' },
  INFO:     { min: 0,                        label: 'info',     color: '#3388dd' },
});

const VULNERABILITY_CATEGORIES = Object.freeze([
  'injection', 'broken-auth', 'sensitive-data', 'xxe', 'broken-access',
  'misconfiguration', 'xss', 'deserialization', 'components', 'logging',
]);

const SCORING_WEIGHTS = phiFusionWeights(3); // [0.528, 0.326, 0.146]

// ═══════════════════════════════════════════════════════════════════════════

class HeadyRisksNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'HeadyRisks',
      ring: 'governance',
      pool: 'governance',
      domain: 'headyme.com',
      capabilities: [
        'risk-assessment', 'security-audit', 'threat-analysis',
        'vulnerability-scoring', 'mitigation-planning',
      ],
      ...config,
    });

    /** @type {Map<string, object>} Risk registry keyed by ID */
    this.riskRegistry = new Map();

    /** @type {Array<object>} Audit log (capped at FIB[9]=34) */
    this.auditLog = [];

    /** @type {Map<string, object>} Mitigation plans keyed by risk ID */
    this.mitigationPlans = new Map();

    /** @type {Map<string, object>} Threat intelligence keyed by signature */
    this.threatIntel = new Map();

    /** @type {object} Aggregated risk metrics */
    this.riskMetrics = {
      assessmentsCompleted: 0,
      criticalFindings: 0,
      mitigationsPlanned: 0,
      avgRiskScore: 0,
      lastAssessmentTime: null,
    };
  }

  /**
   * Process an incoming risk/security task.
   * @param {object} task - Task with type and payload
   * @returns {Promise<object>} Processing result
   */
  async process(task) {
    this.transition('thinking');
    const startTime = Date.now();

    let result;
    switch (task.type) {
      case 'assess-risk':
        result = await this.assessRisk(task.target, task.context || {});
        break;
      case 'audit-security':
        result = await this.auditSecurity(task.system);
        break;
      case 'analyze-threat':
        result = await this.analyzeThreat(task.threat);
        break;
      case 'score-vulnerability':
        result = await this.scoreVulnerability(task.vulnerability);
        break;
      case 'plan-mitigation':
        result = await this.planMitigation(task.risks);
        break;
      default:
        result = await this.assessRisk(task.target || task, task.context || {});
    }

    const durationMs = Date.now() - startTime;
    this.metrics.requestsHandled++;
    this.metrics.avgResponseMs = this.metrics.avgResponseMs === 0
      ? durationMs
      : this.metrics.avgResponseMs * PSI + durationMs * (1 - PSI);

    this.transition('responding');
    return result;
  }

  /**
   * Assess risk for a target system or component.
   * @param {object} target - The system/component to assess
   * @param {object} context - Additional context for assessment
   * @returns {Promise<object>} Risk assessment report
   */
  async assessRisk(target, context = {}) {
    const assessmentId = `risk-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    // Evaluate risk dimensions
    const exploitability = this._evaluateExploitability(target);
    const impact = this._evaluateImpact(target, context);
    const scope = this._evaluateScope(target, context);

    // CVSS-inspired composite score using phi-fusion 3-way
    const riskScore = exploitability * SCORING_WEIGHTS[0]
      + impact * SCORING_WEIGHTS[1]
      + scope * SCORING_WEIGHTS[2];

    const riskLevel = this._classifyRisk(riskScore);

    // CSL-gated severity amplification for compound risks
    const amplifiedScore = cslGate(
      riskScore,
      Math.max(exploitability, impact),
      CSL_THRESHOLDS.MEDIUM,
      PSI * PSI * PSI,
    );

    const assessment = {
      id: assessmentId,
      target: target.name || 'unknown',
      timestamp: new Date().toISOString(),
      scores: { exploitability, impact, scope },
      compositeScore: riskScore,
      amplifiedScore,
      riskLevel: riskLevel.label,
      findings: this._generateFindings(target, { exploitability, impact, scope }),
      recommendations: this._generateRecommendations(riskLevel, { exploitability, impact, scope }),
    };

    // Store in registry
    this.riskRegistry.set(assessmentId, assessment);
    if (this.riskRegistry.size > FIB[16]) {
      const oldest = this.riskRegistry.keys().next().value;
      this.riskRegistry.delete(oldest);
    }

    // Update metrics
    this.riskMetrics.assessmentsCompleted++;
    if (riskLevel.label === 'critical') this.riskMetrics.criticalFindings++;
    this.riskMetrics.lastAssessmentTime = Date.now();
    this.riskMetrics.avgRiskScore = this.riskMetrics.avgRiskScore === 0
      ? riskScore
      : this.riskMetrics.avgRiskScore * PSI + riskScore * (1 - PSI);

    this.logger.info({ assessmentId, riskLevel: riskLevel.label, score: riskScore }, 'Risk assessment complete');
    return assessment;
  }

  /**
   * Perform a security audit on a system.
   * @param {object} system - System to audit
   * @returns {Promise<object>} Audit report
   */
  async auditSecurity(system) {
    const auditId = `audit-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const checks = [];

    // Check each OWASP top-10 category
    for (const category of VULNERABILITY_CATEGORIES) {
      const score = this._checkCategory(system, category);
      const level = this._classifyRisk(score);
      checks.push({ category, score, level: level.label, passed: score < CSL_THRESHOLDS.LOW });
    }

    const overallScore = checks.reduce((sum, c) => sum + c.score, 0) / checks.length;
    const failedChecks = checks.filter(c => !c.passed);

    const report = {
      id: auditId,
      system: system.name || 'unknown',
      timestamp: new Date().toISOString(),
      overallScore,
      overallLevel: this._classifyRisk(overallScore).label,
      totalChecks: checks.length,
      passed: checks.length - failedChecks.length,
      failed: failedChecks.length,
      checks,
      summary: failedChecks.length === 0
        ? 'All security checks passed.'
        : `${failedChecks.length} security check(s) require attention.`,
    };

    // Store in audit log (capped)
    this.auditLog.push(report);
    if (this.auditLog.length > fib(9)) {
      this.auditLog.splice(0, this.auditLog.length - fib(9));
    }

    this.logger.info({ auditId, passed: report.passed, failed: report.failed }, 'Security audit complete');
    return report;
  }

  /**
   * Analyze a specific threat.
   * @param {object} threat - Threat to analyze
   * @returns {Promise<object>} Threat analysis
   */
  async analyzeThreat(threat) {
    const likelihood = typeof threat.likelihood === 'number' ? threat.likelihood : PSI;
    const impact = typeof threat.impact === 'number' ? threat.impact : PSI;
    const riskScore = likelihood * impact;
    const riskLevel = this._classifyRisk(riskScore);

    const analysis = {
      threat: threat.name || 'unknown',
      timestamp: new Date().toISOString(),
      likelihood,
      impact,
      riskScore,
      riskLevel: riskLevel.label,
      attackVector: threat.vector || 'unknown',
      affectedAssets: threat.assets || [],
      countermeasures: this._suggestCountermeasures(threat, riskLevel),
    };

    this.threatIntel.set(threat.name || `threat-${Date.now()}`, analysis);
    if (this.threatIntel.size > FIB[16]) {
      const oldest = this.threatIntel.keys().next().value;
      this.threatIntel.delete(oldest);
    }

    this.logger.info({ threat: threat.name, riskLevel: riskLevel.label }, 'Threat analyzed');
    return analysis;
  }

  /**
   * Score a vulnerability using CVSS-inspired phi-fusion.
   * @param {object} vuln - Vulnerability details
   * @returns {object} Scored vulnerability
   */
  async scoreVulnerability(vuln) {
    const exploitability = vuln.exploitability ?? PSI;
    const impact = vuln.impact ?? PSI;
    const scope = vuln.scope ?? PSI * PSI;

    const score = exploitability * SCORING_WEIGHTS[0]
      + impact * SCORING_WEIGHTS[1]
      + scope * SCORING_WEIGHTS[2];

    return {
      vulnerability: vuln.name || vuln.cve || 'unknown',
      scores: { exploitability, impact, scope },
      compositeScore: score,
      riskLevel: this._classifyRisk(score).label,
      priority: score >= CSL_THRESHOLDS.HIGH ? 'immediate' : score >= CSL_THRESHOLDS.MEDIUM ? 'scheduled' : 'backlog',
    };
  }

  /**
   * Plan mitigations for a set of risks.
   * @param {Array<object>} risks - Risks to mitigate
   * @returns {Promise<object>} Mitigation plan
   */
  async planMitigation(risks) {
    const plans = [];

    for (const risk of (risks || [])) {
      const riskId = risk.id || `risk-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const score = risk.compositeScore || risk.score || PSI;

      const plan = {
        riskId,
        riskLevel: this._classifyRisk(score).label,
        actions: this._generateMitigationActions(risk, score),
        estimatedEffort: score >= CSL_THRESHOLDS.HIGH ? 'high' : score >= CSL_THRESHOLDS.MEDIUM ? 'medium' : 'low',
        deadline: score >= CSL_THRESHOLDS.CRITICAL
          ? `${fib(3)} days`
          : score >= CSL_THRESHOLDS.HIGH
            ? `${fib(5)} days`
            : `${fib(8)} days`,
      };

      this.mitigationPlans.set(riskId, plan);
      plans.push(plan);
    }

    this.riskMetrics.mitigationsPlanned += plans.length;
    this.logger.info({ count: plans.length }, 'Mitigation plans created');
    return { plans, totalRisks: risks?.length || 0, mitigated: plans.length };
  }

  // ─── Internal Methods ──────────────────────────────────────────────────────

  _evaluateExploitability(target) {
    const factors = [
      target.publiclyAccessible ? 0.9 : 0.3,
      target.authenticated ? 0.4 : 0.8,
      target.complexity === 'low' ? 0.9 : target.complexity === 'high' ? 0.3 : 0.6,
    ];
    return factors.reduce((a, b) => a + b, 0) / factors.length;
  }

  _evaluateImpact(target, context) {
    const dataClassification = context.dataClassification || 'internal';
    const classificationScores = { public: 0.2, internal: 0.5, confidential: 0.8, restricted: 0.95 };
    return classificationScores[dataClassification] || PSI;
  }

  _evaluateScope(target, context) {
    const dependents = context.dependents || 1;
    return Math.min(1.0, dependents / fib(8));
  }

  _classifyRisk(score) {
    for (const level of Object.values(RISK_LEVELS)) {
      if (score >= level.min) return level;
    }
    return RISK_LEVELS.INFO;
  }

  _checkCategory(system, category) {
    // Deterministic scoring based on system properties and category
    const base = system.securityScore ?? PSI;
    const hash = category.split('').reduce((h, c) => ((h << 5) - h + c.charCodeAt(0)) | 0, 0);
    const variation = Math.abs(Math.sin(hash)) * PSI * PSI;
    return Math.min(1.0, Math.max(0, base + variation - PSI * PSI));
  }

  _generateFindings(target, scores) {
    const findings = [];
    if (scores.exploitability > CSL_THRESHOLDS.MEDIUM) {
      findings.push({ severity: 'high', finding: 'Elevated exploitability detected', score: scores.exploitability });
    }
    if (scores.impact > CSL_THRESHOLDS.MEDIUM) {
      findings.push({ severity: 'high', finding: 'High potential impact identified', score: scores.impact });
    }
    if (scores.scope > CSL_THRESHOLDS.LOW) {
      findings.push({ severity: 'medium', finding: 'Broad scope of affected components', score: scores.scope });
    }
    if (findings.length === 0) {
      findings.push({ severity: 'info', finding: 'No significant risks identified', score: 0 });
    }
    return findings;
  }

  _generateRecommendations(riskLevel, scores) {
    const recs = [];
    if (riskLevel.label === 'critical' || riskLevel.label === 'high') {
      recs.push('Implement immediate compensating controls');
      recs.push('Escalate to security team for review');
    }
    if (scores.exploitability > CSL_THRESHOLDS.MEDIUM) {
      recs.push('Reduce attack surface — restrict public access');
      recs.push('Add authentication and authorization checks');
    }
    if (scores.impact > CSL_THRESHOLDS.MEDIUM) {
      recs.push('Implement data encryption at rest and in transit');
      recs.push('Add audit logging for sensitive operations');
    }
    if (recs.length === 0) {
      recs.push('Continue monitoring — no immediate action required');
    }
    return recs;
  }

  _suggestCountermeasures(threat, riskLevel) {
    const measures = [];
    if (riskLevel.label === 'critical') measures.push('Isolate affected systems immediately');
    if (riskLevel.label === 'critical' || riskLevel.label === 'high') measures.push('Activate incident response team');
    measures.push('Monitor for indicators of compromise');
    measures.push('Update threat signatures');
    if (threat.vector === 'network') measures.push('Review network segmentation');
    if (threat.vector === 'application') measures.push('Deploy WAF rules');
    return measures;
  }

  _generateMitigationActions(risk, score) {
    const actions = [];
    if (score >= CSL_THRESHOLDS.CRITICAL) {
      actions.push({ action: 'Emergency patch', priority: 'immediate', effort: fib(3) });
    }
    if (score >= CSL_THRESHOLDS.HIGH) {
      actions.push({ action: 'Implement compensating control', priority: 'high', effort: fib(5) });
    }
    if (score >= CSL_THRESHOLDS.MEDIUM) {
      actions.push({ action: 'Schedule remediation', priority: 'medium', effort: fib(8) });
    }
    actions.push({ action: 'Update risk documentation', priority: 'low', effort: fib(3) });
    return actions;
  }
}

export { HeadyRisksNode, HeadyRisksNode as HeadyRisks };
