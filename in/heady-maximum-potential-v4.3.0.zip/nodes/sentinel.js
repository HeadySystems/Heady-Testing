/**
 * SENTINEL — Real-Time Security Monitoring
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Monitors event streams for threats, detects intrusions, raises alerts,
 * and coordinates incident response. Threat severity is scored against
 * CSL thresholds — zero arbitrary cutoffs.
 *
 * Ring: Outer | Pool: Warm | Domain: headyme.com
 *
 * @module sentinel
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

/** Threat severity thresholds mapped directly from CSL */
const SEVERITY = Object.freeze({
  LOW:      CSL_THRESHOLDS.LOW,
  MEDIUM:   CSL_THRESHOLDS.MEDIUM,
  HIGH:     CSL_THRESHOLDS.HIGH,
  CRITICAL: CSL_THRESHOLDS.CRITICAL,
});

// ═══════════════════════════════════════════════════════════════
// SENTINEL NODE
// ═══════════════════════════════════════════════════════════════

/**
 * SentinelNode — Real-time security monitoring, intrusion detection,
 * and incident response with CSL-gated threat scoring.
 *
 * @extends LiquidNode
 */
class SentinelNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='SENTINEL'] - Node name
   */
  constructor(config = {}) {
    super({
      name: 'SENTINEL',
      ring: 'outer',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: ['threat-monitoring', 'intrusion-detection', 'anomaly-alerting', 'incident-response', 'security-logging'],
      ...config,
    });

    /** @type {Object[]} Alert queue — max fib(13) = 233 */
    this.alertQueue = [];
    /** @type {number} */
    this.maxAlerts = FIB[13];

    /** @type {Map<string, Object>} Known threat signature embeddings */
    this.threatSignatures = new Map();

    /** @type {Object[]} Incident log — bounded by fib(16) = 987 */
    this.incidentLog = [];
    /** @type {number} */
    this.maxIncidents = FIB[16];

    this.sentinelMetrics = {
      eventsMonitored: 0,
      intrusionsDetected: 0,
      alertsRaised: 0,
      incidentsHandled: 0,
      falsePositives: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a sentinel task.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - monitor | detect | alert | respond | stats
   * @returns {Object} Task result
   */
  async process(task) {
    this.transition('thinking');
    let result;
    switch (task.type) {
      case 'monitor': result = this.monitor(task.stream); break;
      case 'detect':  result = this.detectIntrusion(task.event); break;
      case 'alert':   result = this.raiseAlert(task.threat); break;
      case 'respond': result = this.respondToIncident(task.incident); break;
      case 'stats':   result = this.stats(); break;
      default: throw new HeadyError(`SENTINEL: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
    this.metrics.requestsHandled++;
    this.transition('responding');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // MONITORING
  // ─────────────────────────────────────────────────────────────

  /**
   * Monitor an event stream for security threats.
   *
   * @param {Object[]} stream - Array of events to scan
   * @returns {Object} Monitoring report with detected threats
   */
  monitor(stream) {
    if (!stream || !Array.isArray(stream)) {
      throw new HeadyError('SENTINEL: monitor requires an event stream array', 400, 'MISSING_PARAMS');
    }

    const threats = [];
    for (const event of stream) {
      const detection = this.detectIntrusion(event);
      if (detection.threatLevel >= SEVERITY.LOW) {
        threats.push(detection);
      }
    }

    this.sentinelMetrics.eventsMonitored += stream.length;

    const report = {
      scanned: stream.length,
      threats: threats.length,
      details: threats,
      highestSeverity: threats.length > 0 ? Math.max(...threats.map(t => t.threatLevel)) : 0,
      timestamp: new Date().toISOString(),
    };

    this.logger.info({ scanned: stream.length, threats: threats.length }, 'Stream monitored');
    return report;
  }

  // ─────────────────────────────────────────────────────────────
  // INTRUSION DETECTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Detect potential intrusion from a single event using CSL scoring.
   *
   * @param {Object} event - Security event
   * @param {string} event.type - Event type identifier
   * @param {number[]} [event.embedding] - 384D event embedding
   * @param {Object} [event.metadata] - Event metadata
   * @returns {Object} Detection result with threat level and matches
   */
  detectIntrusion(event) {
    if (!event) {
      throw new HeadyError('SENTINEL: detectIntrusion requires an event', 400, 'MISSING_PARAMS');
    }

    let maxThreat = 0;
    let matchedSignature = null;

    if (event.embedding) {
      for (const [sigName, sig] of this.threatSignatures) {
        const similarity = cosineSimilarity(event.embedding, sig.embedding);
        const threatScore = cslGate(1.0, similarity, CSL_THRESHOLDS.MEDIUM);
        if (threatScore > maxThreat) {
          maxThreat = threatScore;
          matchedSignature = sigName;
        }
      }
    }

    const severity = maxThreat >= SEVERITY.CRITICAL ? 'critical'
      : maxThreat >= SEVERITY.HIGH ? 'high'
        : maxThreat >= SEVERITY.MEDIUM ? 'medium'
          : maxThreat >= SEVERITY.LOW ? 'low' : 'none';

    if (severity !== 'none') {
      this.sentinelMetrics.intrusionsDetected++;
    }

    return {
      eventType: event.type || 'unknown',
      threatLevel: maxThreat,
      severity,
      matchedSignature,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // ALERTING
  // ─────────────────────────────────────────────────────────────

  /**
   * Raise a security alert and queue it for processing.
   *
   * @param {Object} threat - Threat descriptor
   * @param {string} threat.severity - critical | high | medium | low
   * @param {string} threat.description - Threat description
   * @param {string} [threat.source] - Origin of the threat
   * @returns {Object} Alert record
   */
  raiseAlert(threat) {
    if (!threat || !threat.severity || !threat.description) {
      throw new HeadyError('SENTINEL: raiseAlert requires severity and description', 400, 'MISSING_PARAMS');
    }

    const alert = {
      id: `alert_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      severity: threat.severity,
      description: threat.description,
      source: threat.source || 'unknown',
      status: 'open',
      raisedAt: new Date().toISOString(),
    };

    this.alertQueue.push(alert);
    while (this.alertQueue.length > this.maxAlerts) this.alertQueue.shift();

    this.sentinelMetrics.alertsRaised++;
    this.logger.warn({ id: alert.id, severity: alert.severity }, 'Security alert raised');
    return alert;
  }

  // ─────────────────────────────────────────────────────────────
  // INCIDENT RESPONSE
  // ─────────────────────────────────────────────────────────────

  /**
   * Respond to a security incident with scored containment actions.
   *
   * @param {Object} incident - Incident descriptor
   * @param {string} incident.alertId - Originating alert ID
   * @param {string} incident.type - Incident classification
   * @param {string[]} [incident.actions] - Containment actions taken
   * @returns {Object} Incident response record
   */
  respondToIncident(incident) {
    if (!incident || !incident.alertId) {
      throw new HeadyError('SENTINEL: respondToIncident requires alertId', 400, 'MISSING_PARAMS');
    }

    const actions = incident.actions || ['isolate', 'log', 'notify'];
    const weights = phiFusionWeights(actions.length);
    const containmentScore = weights.reduce((sum, w) => sum + w * CSL_THRESHOLDS.HIGH, 0);

    const response = {
      id: `inc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      alertId: incident.alertId,
      type: incident.type || 'generic',
      actions,
      containmentScore,
      status: 'contained',
      respondedAt: new Date().toISOString(),
    };

    this.incidentLog.push(response);
    while (this.incidentLog.length > this.maxIncidents) this.incidentLog.shift();

    this.sentinelMetrics.incidentsHandled++;
    this.logger.info({ id: response.id, type: response.type, score: containmentScore.toFixed(4) }, 'Incident responded');
    return response;
  }

  // ─────────────────────────────────────────────────────────────
  // STATS
  // ─────────────────────────────────────────────────────────────

  /** @returns {Object} Sentinel operational statistics */
  stats() {
    return {
      ...this.sentinelMetrics,
      alertQueueSize: this.alertQueue.length,
      maxAlerts: this.maxAlerts,
      incidentLogSize: this.incidentLog.length,
      maxIncidents: this.maxIncidents,
      signatureCount: this.threatSignatures.size,
      severityThresholds: { ...SEVERITY },
    };
  }
}

export { SentinelNode, SentinelNode as Sentinel };
