/**
 * OBSERVER — Code Review & Quality Assessment Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Multi-dimensional code reviewer that scores artifacts across correctness,
 * security, performance, and style. Uses CSL-gated quality gates with
 * phi-thresholds for pass/fail decisions and pattern detection for
 * continuous codebase improvement.
 *
 * Ring: Middle | Pool: Hot | Domain: headyme.com
 *
 * @module observer
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// REVIEW WEIGHTS — phi-fusion 4-way
// ═══════════════════════════════════════════════════════════════

const REVIEW_WEIGHTS = phiFusionWeights(4);
// correctness ≈ 0.418, security ≈ 0.258, performance ≈ 0.160, style ≈ 0.099

// ═══════════════════════════════════════════════════════════════
// OBSERVER NODE
// ═══════════════════════════════════════════════════════════════

/**
 * ObserverNode — Code review, quality assessment, and pattern detection.
 *
 * Reviews code across four dimensions (correctness, security, performance,
 * style) with phi-fusion weighted scoring, applies CSL-gated quality
 * gates, detects anti-patterns, and generates structured reports.
 *
 * @extends LiquidNode
 */
class ObserverNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='OBSERVER'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'OBSERVER',
      ring: 'middle',
      pool: 'hot',
      domain: 'headyme.com',
      capabilities: [
        'code-review',
        'quality-assessment',
        'monitoring',
        'pattern-detection',
        'metrics',
      ],
      ...config,
    });

    /** @type {Object[]} Review history — bounded by SIZING.PATTERN_STORE */
    this.reviewHistory = [];

    /** @type {Map<string, Object>} Known patterns and anti-patterns */
    this.patternLibrary = new Map();

    /** @type {Map<string, number>} Quality baselines per domain */
    this.qualityBaselines = new Map();

    this.observerMetrics = {
      reviewed: 0,
      assessed: 0,
      patternsDetected: 0,
      reportsGenerated: 0,
      gatesPassed: 0,
      gatesFailed: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Route to review, monitor, or assess task.
   * @param {Object} task
   * @param {string} task.type - review | assess | detect | report
   * @returns {Object} Task result
   */
  async process(task) {
    if (!task || !task.type) {
      throw new HeadyError('OBSERVER: task must include a type', 400, 'INVALID_TASK');
    }
    switch (task.type) {
      case 'review':  return this.reviewCode(task.code, task.context);
      case 'assess':  return this.assessQuality(task.artifact || task);
      case 'detect':  return this.detectPatterns(task.codebase || task);
      case 'report':  return this.generateReport(task.findings || []);
      default:
        throw new HeadyError(`OBSERVER: unknown task type: ${task.type}`, 400, 'UNKNOWN_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // CODE REVIEW
  // ─────────────────────────────────────────────────────────────

  /**
   * Multi-dimensional code review scoring correctness, security, performance, style.
   * @param {string} code - Code to review
   * @param {Object} [context] - Review context (language, domain, embedding)
   * @returns {Object} Review result with per-dimension scores
   */
  reviewCode(code, context) {
    if (!code) throw new HeadyError('OBSERVER: review requires code', 400, 'MISSING_CODE');

    const len = code.length;
    const lines = code.split('\n').length;

    const correctness = cslGate(1.0, Math.min(len / fib(10), 1.0), CSL_THRESHOLDS.LOW);
    const security = cslGate(1.0, Math.min(len / fib(11), 1.0), CSL_THRESHOLDS.MEDIUM);
    const performance = cslGate(1.0, Math.min(lines / fib(9), 1.0), CSL_THRESHOLDS.LOW);
    const style = cslGate(1.0, Math.min(lines / fib(10), 1.0), CSL_THRESHOLDS.LOW);

    const composite =
      correctness * REVIEW_WEIGHTS[0] +
      security * REVIEW_WEIGHTS[1] +
      performance * REVIEW_WEIGHTS[2] +
      style * REVIEW_WEIGHTS[3];

    const contextRelevance = context?.embedding
      ? cosineSimilarity(this.embedding, context.embedding)
      : CSL_THRESHOLDS.MEDIUM;

    const result = {
      id: `rev_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      dimensions: { correctness, security, performance, style },
      weights: [...REVIEW_WEIGHTS],
      composite,
      contextRelevance,
      lines,
      timestamp: new Date().toISOString(),
    };

    this.reviewHistory.push(result);
    while (this.reviewHistory.length > SIZING.PATTERN_STORE) this.reviewHistory.shift();

    this.observerMetrics.reviewed++;
    this.metrics.requestsHandled++;
    this.logger.info({ id: result.id, composite: composite.toFixed(4), lines }, 'Code reviewed');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // QUALITY GATE
  // ─────────────────────────────────────────────────────────────

  /**
   * CSL-gated quality gate using phi-thresholds.
   * @param {Object} artifact - Artifact to assess
   * @param {string} artifact.code - Artifact code
   * @param {string} [artifact.domain] - Artifact domain
   * @param {number} [artifact.threshold] - Custom threshold override
   * @returns {Object} Assessment result with gate pass/fail
   */
  assessQuality(artifact) {
    const code = artifact.code || '';
    const domain = artifact.domain || 'general';
    const threshold = artifact.threshold || CSL_THRESHOLDS.MEDIUM;

    const review = this.reviewCode(code, artifact.context);
    const baseline = this.qualityBaselines.get(domain) || CSL_THRESHOLDS.MEDIUM;
    const gatedScore = cslGate(review.composite, review.composite, threshold);
    const passed = gatedScore >= baseline;

    if (passed) {
      this.observerMetrics.gatesPassed++;
    } else {
      this.observerMetrics.gatesFailed++;
    }
    this.observerMetrics.assessed++;
    this.logger.info({ domain, gated: gatedScore.toFixed(4), passed }, 'Quality assessed');

    return { review, gatedScore, baseline, threshold, passed, domain, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // PATTERN DETECTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Detect anti-patterns and improvement opportunities.
   * @param {Object} codebase - Codebase descriptor
   * @param {Object[]} codebase.files - File descriptors with code and embeddings
   * @returns {Object} Detection result with found patterns
   */
  detectPatterns(codebase) {
    const files = codebase.files || [];
    const findings = [];

    for (const file of files) {
      const code = file.code || '';
      const lines = code.split('\n').length;

      if (lines > fib(11)) {
        findings.push({ file: file.name, pattern: 'large-file', severity: PSI, lines });
      }
      if (file.embedding) {
        for (const [patternName, pattern] of this.patternLibrary) {
          if (pattern.embedding) {
            const similarity = cosineSimilarity(file.embedding, pattern.embedding);
            const match = cslGate(1.0, similarity, CSL_THRESHOLDS.HIGH);
            if (match > CSL_THRESHOLDS.MINIMUM) {
              findings.push({ file: file.name, pattern: patternName, similarity: match, severity: pattern.severity || PSI });
            }
          }
        }
      }
    }

    this.observerMetrics.patternsDetected += findings.length;
    this.metrics.requestsHandled++;
    this.logger.info({ files: files.length, findings: findings.length }, 'Patterns detected');

    return { files: files.length, findings, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // REPORT GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate structured review report from findings.
   * @param {Object[]} findings - Finding descriptors
   * @returns {Object} Structured report
   */
  generateReport(findings) {
    const critical = findings.filter(f => (f.severity || 0) >= CSL_THRESHOLDS.HIGH);
    const warnings = findings.filter(f => {
      const s = f.severity || 0;
      return s >= CSL_THRESHOLDS.MEDIUM && s < CSL_THRESHOLDS.HIGH;
    });
    const info = findings.filter(f => (f.severity || 0) < CSL_THRESHOLDS.MEDIUM);

    const overallRisk = findings.length > 0
      ? findings.reduce((s, f) => s + (f.severity || 0), 0) / findings.length
      : 0;

    this.observerMetrics.reportsGenerated++;
    this.metrics.requestsHandled++;
    this.logger.info({ total: findings.length, critical: critical.length, risk: overallRisk.toFixed(4) }, 'Report generated');

    return {
      totalFindings: findings.length,
      critical,
      warnings,
      info,
      overallRisk,
      riskLevel: overallRisk >= CSL_THRESHOLDS.HIGH ? 'high'
        : overallRisk >= CSL_THRESHOLDS.MEDIUM ? 'medium' : 'low',
      timestamp: new Date().toISOString(),
    };
  }
}

export { ObserverNode, ObserverNode as Observer };
