/**
 * NOVA — Innovation & Experimental Approaches
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Generates hypotheses, designs experiments, prototypes ideas, and evaluates
 * novelty. All novelty scoring uses cosine distance from existing solutions —
 * higher distance equals more novel.
 *
 * Ring: Outer | Pool: Warm | Domain: headyme.com
 *
 * @module nova
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// NOVA NODE
// ═══════════════════════════════════════════════════════════════

/**
 * NovaNode — Innovation engine that generates hypotheses, designs experiments,
 * and evaluates novelty using cosine distance scoring.
 *
 * @extends LiquidNode
 */
class NovaNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='NOVA'] - Node name
   */
  constructor(config = {}) {
    super({
      name: 'NOVA',
      ring: 'outer',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: ['innovation', 'experimentation', 'hypothesis-generation', 'prototype-design', 'creative-coding'],
      ...config,
    });

    /** @type {Object[]} Experiment log — bounded by fib(9) = 34 */
    this.experimentLog = [];
    /** @type {number} */
    this.maxExperiments = FIB[9];

    /** @type {Map<string, Object>} Hypothesis result cache */
    this.hypothesisCache = new Map();

    this.innovationMetrics = {
      hypothesesGenerated: 0,
      experimentsDesigned: 0,
      prototypesCreated: 0,
      noveltyEvaluations: 0,
      avgNoveltyScore: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a nova task.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - hypothesize | experiment | prototype | evaluate | stats
   * @returns {Object} Task result
   */
  async process(task) {
    this.transition('thinking');
    let result;
    switch (task.type) {
      case 'hypothesize': result = this.generateHypotheses(task.problem, task.count); break;
      case 'experiment':  result = this.designExperiment(task.hypothesis); break;
      case 'prototype':   result = this.prototypeIdea(task.concept); break;
      case 'evaluate':    result = this.evaluateNovelty(task.idea); break;
      case 'stats':       result = this.stats(); break;
      default: throw new HeadyError(`NOVA: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
    this.metrics.requestsHandled++;
    this.transition('responding');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // HYPOTHESIS GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate hypotheses for a problem using divergent exploration.
   *
   * @param {Object} problem - Problem descriptor
   * @param {string} problem.description - Problem statement
   * @param {number[]} [problem.embedding] - 384D problem embedding
   * @param {string[]} [problem.constraints] - Known constraints
   * @param {number} [count=fib(5)] - Number of hypotheses to generate
   * @returns {Object} Hypothesis set with diversity scoring
   */
  generateHypotheses(problem, count) {
    if (!problem || !problem.description) {
      throw new HeadyError('NOVA: generateHypotheses requires problem with description', 400, 'MISSING_PARAMS');
    }

    const n = count || fib(5);
    const hypotheses = [];

    for (let i = 0; i < n; i++) {
      const divergence = Math.pow(PSI, i);
      const confidence = cslGate(1.0, 1.0 - divergence, CSL_THRESHOLDS.LOW);

      hypotheses.push({
        id: `hyp_${Date.now()}_${i}_${Math.random().toString(36).slice(2, 6)}`,
        index: i,
        divergence,
        confidence,
        constraints: problem.constraints || [],
        createdAt: new Date().toISOString(),
      });
    }

    const diversityScore = this._computeDiversityScore(hypotheses);
    this.innovationMetrics.hypothesesGenerated += n;

    const result = {
      problemDescription: problem.description,
      hypotheses,
      count: n,
      diversityScore,
      timestamp: new Date().toISOString(),
    };

    this.logger.info({ count: n, diversity: diversityScore.toFixed(4) }, 'Hypotheses generated');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // EXPERIMENT DESIGN
  // ─────────────────────────────────────────────────────────────

  /**
   * Design an experiment to test a hypothesis.
   *
   * @param {Object} hypothesis - Hypothesis to test
   * @param {string} hypothesis.id - Hypothesis identifier
   * @param {string} hypothesis.claim - Testable claim
   * @param {string[]} [hypothesis.variables] - Independent variables
   * @returns {Object} Experiment design with rigor scoring
   */
  designExperiment(hypothesis) {
    if (!hypothesis || !hypothesis.claim) {
      throw new HeadyError('NOVA: designExperiment requires hypothesis with claim', 400, 'MISSING_PARAMS');
    }

    const variables = hypothesis.variables || ['control', 'treatment'];
    const weights = phiFusionWeights(3);
    const controlScore = CSL_THRESHOLDS.HIGH;
    const measurementScore = CSL_THRESHOLDS.MEDIUM;
    const replicability = CSL_THRESHOLDS.HIGH;
    const rigorScore = controlScore * weights[0] + measurementScore * weights[1] + replicability * weights[2];

    const experiment = {
      id: `exp_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      hypothesisId: hypothesis.id || 'unknown',
      claim: hypothesis.claim,
      variables,
      rigorScore,
      sampleSize: fib(8),
      designedAt: new Date().toISOString(),
    };

    this.experimentLog.push(experiment);
    while (this.experimentLog.length > this.maxExperiments) this.experimentLog.shift();

    this.innovationMetrics.experimentsDesigned++;
    this.logger.info({ id: experiment.id, rigor: rigorScore.toFixed(4) }, 'Experiment designed');
    return experiment;
  }

  // ─────────────────────────────────────────────────────────────
  // PROTOTYPING
  // ─────────────────────────────────────────────────────────────

  /**
   * Create a rapid prototype from a concept.
   *
   * @param {Object} concept - Concept descriptor
   * @param {string} concept.name - Concept name
   * @param {string} concept.description - Concept description
   * @param {number[]} [concept.embedding] - 384D concept embedding
   * @returns {Object} Prototype with feasibility and novelty scores
   */
  prototypeIdea(concept) {
    if (!concept || !concept.name) {
      throw new HeadyError('NOVA: prototypeIdea requires concept with name', 400, 'MISSING_PARAMS');
    }

    const novelty = this.evaluateNovelty(concept);
    const feasibility = cslGate(1.0, CSL_THRESHOLDS.HIGH, CSL_THRESHOLDS.MEDIUM);
    const weights = phiFusionWeights(2);
    const viabilityScore = novelty.noveltyScore * weights[0] + feasibility * weights[1];

    const prototype = {
      id: `proto_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      conceptName: concept.name,
      noveltyScore: novelty.noveltyScore,
      feasibility,
      viabilityScore,
      status: 'drafted',
      createdAt: new Date().toISOString(),
    };

    this.innovationMetrics.prototypesCreated++;
    this.logger.info({ id: prototype.id, viability: viabilityScore.toFixed(4) }, 'Prototype created');
    return prototype;
  }

  // ─────────────────────────────────────────────────────────────
  // NOVELTY EVALUATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Evaluate the novelty of an idea using cosine distance from existing solutions.
   * Higher distance = more novel.
   *
   * @param {Object} idea - Idea to evaluate
   * @param {number[]} [idea.embedding] - 384D idea embedding
   * @returns {Object} Novelty evaluation with score and comparisons
   */
  evaluateNovelty(idea) {
    let noveltyScore = CSL_THRESHOLDS.MEDIUM;
    let closestMatch = null;
    let minSimilarity = 1.0;

    if (idea && idea.embedding && this.experimentLog.length > 0) {
      for (const exp of this.experimentLog) {
        if (exp.embedding) {
          const sim = cosineSimilarity(idea.embedding, exp.embedding);
          if (sim < minSimilarity) {
            minSimilarity = sim;
            closestMatch = exp.id;
          }
        }
      }
      noveltyScore = 1.0 - minSimilarity;
    }

    this.innovationMetrics.noveltyEvaluations++;
    const total = this.innovationMetrics.noveltyEvaluations;
    this.innovationMetrics.avgNoveltyScore =
      (this.innovationMetrics.avgNoveltyScore * (total - 1) + noveltyScore) / total;

    return {
      noveltyScore,
      closestMatch,
      minSimilarity,
      isNovel: noveltyScore >= CSL_THRESHOLDS.MEDIUM,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & INTERNALS
  // ─────────────────────────────────────────────────────────────

  /** @returns {Object} Nova operational statistics */
  stats() {
    return {
      ...this.innovationMetrics,
      experimentLogSize: this.experimentLog.length,
      maxExperiments: this.maxExperiments,
      hypothesisCacheSize: this.hypothesisCache.size,
    };
  }

  /** Compute diversity across hypotheses using divergence spread. */
  _computeDiversityScore(hypotheses) {
    if (hypotheses.length <= 1) return 0;
    const divergences = hypotheses.map(h => h.divergence);
    const spread = Math.max(...divergences) - Math.min(...divergences);
    return cslGate(1.0, spread, CSL_THRESHOLDS.LOW);
  }
}

export { NovaNode, NovaNode as Nova };
