/**
 * HeadyPatterns — Pattern Detection & Learning
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * HeadyPatterns identifies recurring, emerging, declining, cyclic, and
 * anomalous patterns across the Heady ecosystem. It classifies drift
 * via cosine similarity against baseline embeddings, learns from
 * operational experience, and catalogs anomalies for further analysis.
 *
 * Ring: Governance | Pool: Cold | Domain: headyme.com
 *
 * @module heady-patterns
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// PATTERN TYPES
// ═══════════════════════════════════════════════════════════════

const PATTERN_TYPES = Object.freeze(['recurring', 'emerging', 'declining', 'cyclic', 'anomalous']);

// ═══════════════════════════════════════════════════════════════
// HEADY PATTERNS NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyPatternsNode — Pattern detection, drift classification, and learning.
 *
 * Detects patterns across sliding windows, classifies coherence drift
 * via cosine similarity, learns from experience buffers, identifies
 * trends in time series, and catalogs anomalies.
 *
 * @extends LiquidNode
 */
class HeadyPatternsNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyPatterns']
   */
  constructor(config = {}) {
    super({
      name: 'HeadyPatterns',
      ring: 'governance',
      pool: 'cold',
      domain: 'headyme.com',
      capabilities: [
        'pattern-detection',
        'drift-classification',
        'learning',
        'trend-identification',
        'anomaly-cataloging',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Pattern library — FIB[16] = 987 max */
    this.patternLibrary = new Map();
    this.maxPatternLibrary = SIZING.CACHE_SIZE;

    /** @type {Object[]} Bounded drift log — FIB[9] = 34 max */
    this.driftLog = [];
    this.maxDriftLog = FIB[9];

    /** @type {Object[]} Learning buffer — FIB[8] = 21 entries */
    this.learningBuffer = [];
    this.maxLearningBuffer = FIB[8];

    this.patternMetrics = {
      totalDetections: 0,
      driftClassifications: 0,
      learningCycles: 0,
      trendsIdentified: 0,
      anomaliesCataloged: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a pattern task.
   * @param {Object} task
   * @param {string} task.type - detectPatterns | classifyDrift | learn | identifyTrend | catalogAnomaly
   * @returns {Object}
   */
  async process(task) {
    this.metrics.requestsHandled++;
    switch (task.type) {
      case 'detectPatterns': return this.detectPatterns(task.data, task.windowSize);
      case 'classifyDrift':  return this.classifyDrift(task.current, task.baseline);
      case 'learn':          return this.learn(task.experience);
      case 'identifyTrend':  return this.identifyTrend(task.timeSeries);
      case 'catalogAnomaly': return this.catalogAnomaly(task.event);
      default:
        throw new HeadyError(`HeadyPatterns: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // PATTERN DETECTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Detect patterns in data using a sliding window.
   * @param {number[]} data - Numeric time series data
   * @param {number} [windowSize] - Sliding window size, defaults to fib(9) = 34
   * @returns {Object} Detected patterns with types and scores
   */
  detectPatterns(data, windowSize) {
    if (!data || !Array.isArray(data) || data.length === 0) {
      throw new HeadyError('HeadyPatterns: numeric data array is required', 400, 'MISSING_DATA');
    }

    const window = windowSize || FIB[9];
    const patterns = [];
    const len = data.length;

    if (len < fib(4)) {
      return { patterns: [], message: 'Insufficient data', dataLength: len };
    }

    // Compute rolling statistics over windows
    const windowCount = Math.max(1, Math.floor(len / window));
    const windowMeans = [];
    for (let w = 0; w < windowCount; w++) {
      const start = w * window;
      const end = Math.min(start + window, len);
      const slice = data.slice(start, end);
      const mean = slice.reduce((s, v) => s + v, 0) / slice.length;
      windowMeans.push(mean);
    }

    // Recurring: low variance across windows
    if (windowMeans.length >= fib(3)) {
      const overallMean = windowMeans.reduce((s, v) => s + v, 0) / windowMeans.length;
      const variance = windowMeans.reduce((s, v) => s + Math.pow(v - overallMean, 2), 0) / windowMeans.length;
      const cv = overallMean !== 0 ? Math.sqrt(variance) / Math.abs(overallMean) : 0;
      if (cv < Math.pow(PSI, 2)) {
        patterns.push({ type: 'recurring', confidence: 1.0 - cv, coefficient: cv });
      }
    }

    // Emerging/declining: monotonic trend in window means
    if (windowMeans.length >= fib(3)) {
      let increasing = 0;
      let decreasing = 0;
      for (let i = 1; i < windowMeans.length; i++) {
        if (windowMeans[i] > windowMeans[i - 1]) increasing++;
        if (windowMeans[i] < windowMeans[i - 1]) decreasing++;
      }
      const steps = windowMeans.length - 1;
      if (increasing / steps >= CSL_THRESHOLDS.MEDIUM) {
        patterns.push({ type: 'emerging', confidence: increasing / steps });
      }
      if (decreasing / steps >= CSL_THRESHOLDS.MEDIUM) {
        patterns.push({ type: 'declining', confidence: decreasing / steps });
      }
    }

    // Cyclic: autocorrelation check (simplified)
    if (len >= window * fib(3)) {
      let corr = 0;
      let norm = 0;
      for (let i = 0; i < len - window; i++) {
        corr += data[i] * data[i + window];
        norm += data[i] * data[i];
      }
      const autocorr = norm > 0 ? corr / norm : 0;
      if (autocorr > CSL_THRESHOLDS.LOW) {
        patterns.push({ type: 'cyclic', confidence: Math.min(autocorr, 1.0), period: window });
      }
    }

    // Anomalous: points beyond PSI standard deviations from mean
    const mean = data.reduce((s, v) => s + v, 0) / len;
    const stdDev = Math.sqrt(data.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / len);
    const anomalyThreshold = stdDev * (1 / PSI);
    const anomalies = data.filter(v => Math.abs(v - mean) > anomalyThreshold);
    if (anomalies.length > 0) {
      patterns.push({ type: 'anomalous', confidence: Math.min(anomalies.length / len * PHI, 1.0), count: anomalies.length });
    }

    this.patternMetrics.totalDetections++;
    this.logger.info({ patterns: patterns.length, dataLength: len, windowSize: window }, 'Patterns detected');

    return { patterns, dataLength: len, windowSize: window, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // DRIFT CLASSIFICATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Classify drift between current and baseline embeddings.
   * @param {number[]} current - Current 384D embedding
   * @param {number[]} baseline - Baseline 384D embedding
   * @returns {Object} Drift classification result
   */
  classifyDrift(current, baseline) {
    if (!current || !baseline) {
      throw new HeadyError('HeadyPatterns: current and baseline embeddings are required', 400, 'MISSING_EMBEDDINGS');
    }

    const similarity = cosineSimilarity(current, baseline);
    const driftMagnitude = 1.0 - similarity;

    let classification;
    if (similarity >= CSL_THRESHOLDS.HIGH) classification = 'stable';
    else if (similarity >= CSL_THRESHOLDS.MEDIUM) classification = 'minor-drift';
    else if (similarity >= CSL_THRESHOLDS.LOW) classification = 'moderate-drift';
    else if (similarity >= CSL_THRESHOLDS.MINIMUM) classification = 'major-drift';
    else classification = 'critical-drift';

    const entry = { classification, similarity, driftMagnitude, timestamp: new Date().toISOString() };
    this.driftLog.push(entry);
    if (this.driftLog.length > this.maxDriftLog) this.driftLog.shift();

    this.patternMetrics.driftClassifications++;
    this.logger.info({ classification, similarity: similarity.toFixed(4) }, 'Drift classified');

    return entry;
  }

  // ─────────────────────────────────────────────────────────────
  // LEARNING
  // ─────────────────────────────────────────────────────────────

  /**
   * Learn from an operational experience and update pattern library.
   * @param {Object} experience - Experience entry with pattern, outcome, embedding
   * @returns {Object} Learning result
   */
  learn(experience) {
    if (!experience) throw new HeadyError('HeadyPatterns: experience is required', 400, 'MISSING_EXPERIENCE');

    this.learningBuffer.push({ ...experience, learnedAt: new Date().toISOString() });
    if (this.learningBuffer.length > this.maxLearningBuffer) this.learningBuffer.shift();

    // If pattern has embedding, store/update in library
    if (experience.patternId && experience.embedding) {
      const existing = this.patternLibrary.get(experience.patternId);
      if (existing) {
        existing.occurrences++;
        existing.lastSeen = new Date().toISOString();
        existing.confidence = Math.min(1.0, existing.confidence + Math.pow(PSI, 3));
      } else {
        if (this.patternLibrary.size >= this.maxPatternLibrary) {
          const oldest = this.patternLibrary.keys().next().value;
          this.patternLibrary.delete(oldest);
        }
        this.patternLibrary.set(experience.patternId, {
          embedding: experience.embedding,
          type: experience.patternType || 'unknown',
          confidence: CSL_THRESHOLDS.LOW,
          occurrences: 1,
          firstSeen: new Date().toISOString(),
          lastSeen: new Date().toISOString(),
        });
      }
    }

    this.patternMetrics.learningCycles++;
    this.logger.info({ bufferSize: this.learningBuffer.length, librarySize: this.patternLibrary.size }, 'Learning cycle complete');

    return { learned: true, bufferSize: this.learningBuffer.length, librarySize: this.patternLibrary.size };
  }

  // ─────────────────────────────────────────────────────────────
  // TREND IDENTIFICATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Identify trend direction and strength in a time series.
   * @param {number[]} timeSeries - Numeric time series
   * @returns {Object} Trend result with direction, slope, strength
   */
  identifyTrend(timeSeries) {
    if (!timeSeries || timeSeries.length < fib(3)) {
      throw new HeadyError('HeadyPatterns: time series with >= 2 points is required', 400, 'INSUFFICIENT_DATA');
    }

    const n = timeSeries.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    for (let i = 0; i < n; i++) {
      sumX += i;
      sumY += timeSeries[i];
      sumXY += i * timeSeries[i];
      sumX2 += i * i;
    }
    const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
    const meanY = sumY / n;
    const normalizedSlope = meanY !== 0 ? slope / Math.abs(meanY) : 0;

    const direction = normalizedSlope > Math.pow(PSI, 4) ? 'increasing'
      : normalizedSlope < -Math.pow(PSI, 4) ? 'decreasing' : 'stable';
    const strength = Math.min(Math.abs(normalizedSlope) / PSI, 1.0);

    this.patternMetrics.trendsIdentified++;
    this.logger.info({ direction, strength: strength.toFixed(4) }, 'Trend identified');

    return { direction, slope, normalizedSlope, strength, dataPoints: n, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // ANOMALY CATALOGING
  // ─────────────────────────────────────────────────────────────

  /**
   * Catalog an anomalous event into the pattern library.
   * @param {Object} event - Anomaly event descriptor
   * @returns {Object} Catalog entry
   */
  catalogAnomaly(event) {
    if (!event) throw new HeadyError('HeadyPatterns: event is required', 400, 'MISSING_EVENT');

    const entry = {
      id: `anom_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      type: 'anomalous',
      source: event.source || 'unknown',
      severity: event.severity || 'unknown',
      details: event.details || {},
      catalogedAt: new Date().toISOString(),
    };

    if (this.patternLibrary.size >= this.maxPatternLibrary) {
      const oldest = this.patternLibrary.keys().next().value;
      this.patternLibrary.delete(oldest);
    }
    this.patternLibrary.set(entry.id, entry);

    this.patternMetrics.anomaliesCataloged++;
    this.logger.info({ id: entry.id, source: entry.source, severity: entry.severity }, 'Anomaly cataloged');

    return entry;
  }
}

export { HeadyPatternsNode, HeadyPatternsNode as HeadyPatterns };
