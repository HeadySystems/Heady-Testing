/**
 * MUSE — Creative Content & UX Design
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Generates creative content, designs UX flows, synthesizes visual styles,
 * and composes visual elements. Creativity scoring uses a phi-fusion 3-way
 * blend of novelty, relevance, and coherence.
 *
 * Ring: Outer | Pool: Warm | Domain: headyme.com
 *
 * @module muse
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

/** Phi-fusion 3-way creativity weights: ~0.528, ~0.326, ~0.146 */
const CREATIVITY_WEIGHTS = phiFusionWeights(3);

// ═══════════════════════════════════════════════════════════════
// MUSE NODE
// ═══════════════════════════════════════════════════════════════

/**
 * MuseNode — Creative content generation and UX design engine.
 * Scores all creative output via phi-fusion blend of novelty, relevance,
 * and coherence against reference embeddings.
 *
 * @extends LiquidNode
 */
class MuseNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='MUSE'] - Node name
   */
  constructor(config = {}) {
    super({
      name: 'MUSE',
      ring: 'outer',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: ['creative-generation', 'ux-design', 'content-creation', 'style-synthesis', 'visual-composition'],
      ...config,
    });

    /** @type {Map<string, Object>} Style library for synthesis */
    this.styleLibrary = new Map();

    /** @type {Object[]} Recent creative outputs — bounded by fib(8) = 21 */
    this.creativeHistory = [];
    /** @type {number} */
    this.maxHistory = FIB[8];

    /** @type {Map<string, Object>} Reusable design pattern templates */
    this.designPatterns = new Map();

    this.museMetrics = {
      creativesGenerated: 0,
      uxDesigns: 0,
      stylesSynthesized: 0,
      visualsComposed: 0,
      avgCreativityScore: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a muse task.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - creative | ux | style | visual | stats
   * @returns {Object} Task result
   */
  async process(task) {
    this.transition('thinking');
    let result;
    switch (task.type) {
      case 'creative': result = this.generateCreative(task.brief); break;
      case 'ux':       result = this.designUX(task.requirements); break;
      case 'style':    result = this.synthesizeStyle(task.references); break;
      case 'visual':   result = this.composeVisual(task.elements); break;
      case 'stats':    result = this.stats(); break;
      default: throw new HeadyError(`MUSE: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
    this.metrics.requestsHandled++;
    this.transition('responding');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // CREATIVE GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate creative content from a brief with phi-fusion scoring.
   *
   * @param {Object} brief - Creative brief
   * @param {string} brief.prompt - Creative prompt text
   * @param {string} [brief.style] - Target style
   * @param {number[]} [brief.embedding] - 384D reference embedding
   * @param {Object} [brief.constraints] - Creative constraints
   * @returns {Object} Creative output with creativity score
   */
  generateCreative(brief) {
    if (!brief || !brief.prompt) {
      throw new HeadyError('MUSE: generateCreative requires brief with prompt', 400, 'MISSING_PARAMS');
    }

    const novelty = this._computeNovelty(brief.embedding);
    const relevance = brief.embedding ? cslGate(1.0, 1.0, CSL_THRESHOLDS.LOW) : CSL_THRESHOLDS.MEDIUM;
    const coherence = CSL_THRESHOLDS.HIGH;

    const creativityScore =
      novelty * CREATIVITY_WEIGHTS[0] +
      relevance * CREATIVITY_WEIGHTS[1] +
      coherence * CREATIVITY_WEIGHTS[2];

    const output = {
      id: `cre_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      prompt: brief.prompt,
      style: brief.style || 'default',
      scores: { novelty, relevance, coherence },
      creativityScore,
      constraints: brief.constraints || {},
      createdAt: new Date().toISOString(),
    };

    this._appendHistory(output);
    this.museMetrics.creativesGenerated++;
    this._updateAvgScore(creativityScore);

    this.logger.info({ id: output.id, score: creativityScore.toFixed(4) }, 'Creative generated');
    return output;
  }

  // ─────────────────────────────────────────────────────────────
  // UX DESIGN
  // ─────────────────────────────────────────────────────────────

  /**
   * Design a UX flow from requirements.
   *
   * @param {Object} requirements - UX requirements
   * @param {string} requirements.goal - Primary user goal
   * @param {string[]} [requirements.screens] - Screen/view list
   * @param {string} [requirements.pattern] - Design pattern reference
   * @returns {Object} UX design with flow and scoring
   */
  designUX(requirements) {
    if (!requirements || !requirements.goal) {
      throw new HeadyError('MUSE: designUX requires requirements with goal', 400, 'MISSING_PARAMS');
    }

    const pattern = requirements.pattern ? this.designPatterns.get(requirements.pattern) : null;
    const screens = requirements.screens || ['landing', 'main', 'detail'];
    const flowComplexity = Math.min(screens.length / FIB[8], 1.0);
    const patternBoost = pattern ? CSL_THRESHOLDS.MEDIUM : 0;
    const weights = phiFusionWeights(2);
    const designScore = (1.0 - flowComplexity) * weights[0] + (CSL_THRESHOLDS.HIGH + patternBoost) * weights[1];

    const design = {
      id: `ux_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      goal: requirements.goal,
      screens,
      patternUsed: pattern ? requirements.pattern : null,
      flowComplexity,
      designScore,
      createdAt: new Date().toISOString(),
    };

    this.museMetrics.uxDesigns++;
    this.logger.info({ id: design.id, screens: screens.length, score: designScore.toFixed(4) }, 'UX designed');
    return design;
  }

  // ─────────────────────────────────────────────────────────────
  // STYLE SYNTHESIS
  // ─────────────────────────────────────────────────────────────

  /**
   * Synthesize a new style from reference styles.
   *
   * @param {Object[]} references - Style reference objects with embeddings
   * @returns {Object} Synthesized style with coherence score
   */
  synthesizeStyle(references) {
    if (!references || references.length === 0) {
      throw new HeadyError('MUSE: synthesizeStyle requires at least one reference', 400, 'MISSING_PARAMS');
    }

    const weights = phiFusionWeights(references.length);
    let coherenceSum = 0;

    for (let i = 0; i < references.length; i++) {
      for (let j = i + 1; j < references.length; j++) {
        if (references[i].embedding && references[j].embedding) {
          coherenceSum += cosineSimilarity(references[i].embedding, references[j].embedding);
        }
      }
    }
    const pairs = references.length > 1 ? (references.length * (references.length - 1)) / 2 : 1;
    const avgCoherence = coherenceSum / pairs;
    const coherenceScore = cslGate(1.0, avgCoherence, CSL_THRESHOLDS.LOW);

    const style = {
      id: `sty_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      sourceCount: references.length,
      weights,
      coherenceScore,
      createdAt: new Date().toISOString(),
    };

    this.styleLibrary.set(style.id, style);
    this.museMetrics.stylesSynthesized++;
    this.logger.info({ id: style.id, sources: references.length, coherence: coherenceScore.toFixed(4) }, 'Style synthesized');
    return style;
  }

  // ─────────────────────────────────────────────────────────────
  // VISUAL COMPOSITION
  // ─────────────────────────────────────────────────────────────

  /**
   * Compose visual elements into a cohesive layout.
   *
   * @param {Object[]} elements - Visual elements with position/weight
   * @returns {Object} Composition with balance score
   */
  composeVisual(elements) {
    if (!elements || elements.length === 0) {
      throw new HeadyError('MUSE: composeVisual requires elements', 400, 'MISSING_PARAMS');
    }

    const weights = phiFusionWeights(elements.length);
    const balanceScore = cslGate(1.0, PSI, CSL_THRESHOLDS.LOW);

    const composition = {
      id: `vis_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      elementCount: elements.length,
      weights,
      balanceScore,
      goldenRatioApplied: true,
      createdAt: new Date().toISOString(),
    };

    this.museMetrics.visualsComposed++;
    this.logger.info({ id: composition.id, elements: elements.length, balance: balanceScore.toFixed(4) }, 'Visual composed');
    return composition;
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & INTERNALS
  // ─────────────────────────────────────────────────────────────

  /** @returns {Object} Muse operational statistics */
  stats() {
    return {
      ...this.museMetrics,
      historySize: this.creativeHistory.length,
      maxHistory: this.maxHistory,
      styleLibrarySize: this.styleLibrary.size,
      designPatternsSize: this.designPatterns.size,
    };
  }

  /** Compute novelty as distance from recent creative history. */
  _computeNovelty(embedding) {
    if (!embedding || this.creativeHistory.length === 0) return CSL_THRESHOLDS.MEDIUM;
    let maxSim = 0;
    for (const entry of this.creativeHistory) {
      if (entry.embedding) {
        maxSim = Math.max(maxSim, cosineSimilarity(embedding, entry.embedding));
      }
    }
    return 1.0 - maxSim;
  }

  /** Append to bounded creative history. */
  _appendHistory(output) {
    this.creativeHistory.push(output);
    while (this.creativeHistory.length > this.maxHistory) this.creativeHistory.shift();
  }

  /** Update running average creativity score. */
  _updateAvgScore(score) {
    const n = this.museMetrics.creativesGenerated;
    this.museMetrics.avgCreativityScore =
      (this.museMetrics.avgCreativityScore * (n - 1) + score) / n;
  }
}

export { MuseNode, MuseNode as Muse };
