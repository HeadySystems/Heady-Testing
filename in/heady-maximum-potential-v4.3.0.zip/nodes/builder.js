/**
 * BUILDER — Full-Stack System Building Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Orchestrates multi-file system builds, scaffolding, service wiring, and
 * integration validation. Manages concurrent builds capped at FIB[6]=8
 * and scores integration integrity via CSL-gated coherence checks.
 *
 * Ring: Middle | Pool: Hot | Domain: headyme.com
 *
 * @module builder
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// BUILDER NODE
// ═══════════════════════════════════════════════════════════════

/**
 * BuilderNode — Full-stack system building, scaffolding, and integration.
 *
 * Manages concurrent build sessions (max FIB[6]=8), scaffolds project
 * structures, wires services together, builds multi-stage pipelines,
 * and validates integration coherence via CSL gating.
 *
 * @extends LiquidNode
 */
class BuilderNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='BUILDER'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'BUILDER',
      ring: 'middle',
      pool: 'hot',
      domain: 'headyme.com',
      capabilities: [
        'full-stack-building',
        'system-design',
        'scaffolding',
        'integration',
        'wiring',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Active builds — max FIB[6]=8 concurrent */
    this.activeBuilds = new Map();

    /** @type {Map<string, Object>} Reusable build templates */
    this.buildTemplates = new Map();

    this.builderMetrics = {
      scaffolded: 0,
      wired: 0,
      pipelines: 0,
      validated: 0,
      failedIntegrations: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Orchestrate multi-file system builds.
   * @param {Object} task
   * @param {string} task.type - scaffold | wire | pipeline | validate
   * @returns {Object} Build result
   */
  async process(task) {
    if (!task || !task.type) {
      throw new HeadyError('BUILDER: task must include a type', 400, 'INVALID_TASK');
    }
    switch (task.type) {
      case 'scaffold': return this.scaffold(task.projectSpec || task);
      case 'wire':     return this.wireServices(task.services || []);
      case 'pipeline': return this.buildPipeline(task.stages || []);
      case 'validate': return this.validateIntegration(task.system || task);
      default:
        throw new HeadyError(`BUILDER: unknown task type: ${task.type}`, 400, 'UNKNOWN_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // SCAFFOLDING
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate a project structure from specification.
   * @param {Object} projectSpec - Project specification
   * @param {string} projectSpec.name - Project name
   * @param {string} projectSpec.type - Project type (api, web, library, monorepo)
   * @param {string[]} [projectSpec.modules] - Module list
   * @param {string} [projectSpec.language] - Primary language
   * @returns {Object} Scaffold result with file tree
   */
  scaffold(projectSpec) {
    if (this.activeBuilds.size >= SIZING.MAX_CONCURRENT) {
      throw new HeadyError('BUILDER: max concurrent builds reached', 429, 'BUILD_CAPACITY');
    }

    const buildId = `build_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const modules = projectSpec.modules || [];
    const structure = {
      root: projectSpec.name || 'project',
      type: projectSpec.type || 'api',
      language: projectSpec.language || 'javascript',
      directories: ['src', 'tests', 'docs', 'config'],
      files: ['package.json', 'README.md', '.gitignore'],
      modules: modules.map(m => ({ name: m, path: `src/${m}`, files: ['index.js', `${m}.test.js`] })),
    };

    this.activeBuilds.set(buildId, { spec: projectSpec, structure, status: 'scaffolded', startedAt: Date.now() });
    this.builderMetrics.scaffolded++;
    this.metrics.requestsHandled++;
    this.logger.info({ buildId, type: structure.type, modules: modules.length }, 'Project scaffolded');

    return { buildId, structure, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // SERVICE WIRING
  // ─────────────────────────────────────────────────────────────

  /**
   * Connect services together with coherence validation.
   * @param {Object[]} services - Service descriptors
   * @param {string} services[].name - Service name
   * @param {string} services[].type - Service type (api, db, queue, cache)
   * @param {string[]} [services[].dependsOn] - Dependencies
   * @param {number[]} [services[].embedding] - 384D service embedding
   * @returns {Object} Wiring result with connection map
   */
  wireServices(services) {
    const connections = [];
    const weights = phiFusionWeights(Math.max(services.length, 1));

    for (let i = 0; i < services.length; i++) {
      const svc = services[i];
      for (const dep of (svc.dependsOn || [])) {
        const target = services.find(s => s.name === dep);
        if (!target) continue;

        const coherence = svc.embedding && target.embedding
          ? cosineSimilarity(svc.embedding, target.embedding)
          : CSL_THRESHOLDS.MEDIUM;

        const gatedCoherence = cslGate(1.0, coherence, CSL_THRESHOLDS.LOW);
        connections.push({
          from: svc.name,
          to: target.name,
          coherence: gatedCoherence,
          healthy: gatedCoherence >= CSL_THRESHOLDS.MINIMUM,
        });
      }
    }

    this.builderMetrics.wired++;
    this.metrics.requestsHandled++;
    this.logger.info({ services: services.length, connections: connections.length }, 'Services wired');

    return { services: services.length, connections, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // BUILD PIPELINE
  // ─────────────────────────────────────────────────────────────

  /**
   * Create a multi-stage build pipeline.
   * @param {Object[]} stages - Pipeline stage descriptors
   * @param {string} stages[].name - Stage name
   * @param {string} stages[].action - Stage action (compile, test, lint, deploy)
   * @param {string[]} [stages[].dependsOn] - Stage dependencies
   * @returns {Object} Pipeline definition with execution order
   */
  buildPipeline(stages) {
    // Topological ordering via in-degree
    const nameMap = new Map(stages.map(s => [s.name, s]));
    const inDegree = new Map(stages.map(s => [s.name, 0]));
    for (const stage of stages) {
      for (const dep of (stage.dependsOn || [])) {
        if (inDegree.has(dep)) inDegree.set(stage.name, inDegree.get(stage.name) + 1);
      }
    }

    const ordered = [];
    const queue = [...inDegree.entries()].filter(([, d]) => d === 0).map(([n]) => n);
    while (queue.length > 0) {
      const current = queue.shift();
      ordered.push(nameMap.get(current));
      for (const stage of stages) {
        if ((stage.dependsOn || []).includes(current)) {
          const newDeg = inDegree.get(stage.name) - 1;
          inDegree.set(stage.name, newDeg);
          if (newDeg === 0) queue.push(stage.name);
        }
      }
    }

    // Group into parallel batches (max FIB[6]=8 per batch)
    const completed = new Set();
    const batches = [];
    while (completed.size < ordered.length) {
      const batch = [];
      for (const stage of ordered) {
        if (completed.has(stage.name)) continue;
        const depsResolved = (stage.dependsOn || []).every(d => completed.has(d));
        if (depsResolved && batch.length < SIZING.MAX_CONCURRENT) batch.push(stage);
      }
      if (batch.length === 0) break;
      for (const s of batch) completed.add(s.name);
      batches.push(batch);
    }

    this.builderMetrics.pipelines++;
    this.metrics.requestsHandled++;
    this.logger.info({ stages: stages.length, batches: batches.length }, 'Pipeline built');

    return { stages: ordered, batches, totalStages: stages.length, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // INTEGRATION VALIDATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Validate all connections in a system.
   * @param {Object} system - System descriptor
   * @param {Object[]} system.services - Service descriptors
   * @param {Object[]} [system.connections] - Pre-computed connections
   * @returns {Object} Validation result
   */
  validateIntegration(system) {
    const services = system.services || [];
    const connections = system.connections || this.wireServices(services).connections;

    const healthy = connections.filter(c => c.healthy);
    const broken = connections.filter(c => !c.healthy);
    const overallCoherence = connections.length > 0
      ? connections.reduce((s, c) => s + c.coherence, 0) / connections.length
      : 1.0;

    const valid = broken.length === 0 && overallCoherence >= CSL_THRESHOLDS.MINIMUM;

    if (!valid) this.builderMetrics.failedIntegrations++;
    this.builderMetrics.validated++;
    this.metrics.requestsHandled++;
    this.logger.info({
      total: connections.length,
      healthy: healthy.length,
      broken: broken.length,
      coherence: overallCoherence.toFixed(4),
    }, 'Integration validated');

    return {
      valid,
      overallCoherence,
      totalConnections: connections.length,
      healthy: healthy.length,
      broken,
      timestamp: new Date().toISOString(),
    };
  }
}

export { BuilderNode, BuilderNode as Builder };
