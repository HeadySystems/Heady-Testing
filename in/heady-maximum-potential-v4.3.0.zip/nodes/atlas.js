/**
 * ATLAS — Architecture Documentation & System Mapping Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Generates architecture documentation, Architecture Decision Records (ADRs),
 * dependency graphs, API documentation, and topology visualizations. Maintains
 * a document cache bounded at FIB[16]=987 for rapid retrieval.
 *
 * Ring: Middle | Pool: Warm | Domain: headyme.com
 *
 * @module atlas
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// ATLAS NODE
// ═══════════════════════════════════════════════════════════════

/**
 * AtlasNode — Architecture documentation, ADR generation, and system mapping.
 *
 * Maintains a bounded document cache (FIB[16]=987), generates architecture
 * overviews, ADRs, API documentation, dependency graphs, and topology
 * descriptions. All relevance scoring uses CSL gating.
 *
 * @extends LiquidNode
 */
class AtlasNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='ATLAS'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'ATLAS',
      ring: 'middle',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: [
        'architecture-docs',
        'system-mapping',
        'adr-generation',
        'api-documentation',
        'dependency-graphing',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Document cache — max FIB[16]=987 */
    this.documentCache = new Map();

    /** @type {Object[]} ADR registry */
    this.adrRegistry = [];

    /** @type {Map<string, Set<string>>} Dependency graph: module → Set<dependency> */
    this.dependencyGraph = new Map();

    this.atlasMetrics = {
      docsGenerated: 0,
      adrsCreated: 0,
      apisDocumented: 0,
      graphsMapped: 0,
      topologiesVisualized: 0,
      cacheHits: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Route to documentation or mapping task.
   * @param {Object} task
   * @param {string} task.type - document | adr | dependencies | api | topology
   * @returns {Object} Documentation result
   */
  async process(task) {
    if (!task || !task.type) {
      throw new HeadyError('ATLAS: task must include a type', 400, 'INVALID_TASK');
    }
    switch (task.type) {
      case 'document':     return this.documentArchitecture(task.system || task);
      case 'adr':          return this.generateADR(task.decision || task);
      case 'dependencies': return this.mapDependencies(task.modules || []);
      case 'api':          return this.documentAPI(task.endpoints || []);
      case 'topology':     return this.visualizeTopology(task.nodes || []);
      default:
        throw new HeadyError(`ATLAS: unknown task type: ${task.type}`, 400, 'UNKNOWN_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // ARCHITECTURE DOCUMENTATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate architecture overview for a system.
   * @param {Object} system - System descriptor
   * @param {string} system.name - System name
   * @param {Object[]} [system.components] - Component descriptors
   * @param {string} [system.description] - System description
   * @returns {Object} Architecture document
   */
  documentArchitecture(system) {
    const cacheKey = `arch:${system.name || 'system'}`;
    if (this.documentCache.has(cacheKey)) {
      this.atlasMetrics.cacheHits++;
      return this.documentCache.get(cacheKey);
    }

    const components = system.components || [];
    const sections = [
      { title: 'Overview', content: system.description || `Architecture of ${system.name}` },
      { title: 'Components', content: components.map(c => ({ name: c.name, type: c.type, ring: c.ring })) },
      { title: 'Rings', content: this._groupByRing(components) },
      { title: 'Pools', content: this._groupByPool(components) },
    ];

    const doc = {
      id: `doc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      system: system.name,
      sections,
      componentCount: components.length,
      timestamp: new Date().toISOString(),
    };

    this._cacheDocument(cacheKey, doc);
    this.atlasMetrics.docsGenerated++;
    this.metrics.requestsHandled++;
    this.logger.info({ system: system.name, components: components.length }, 'Architecture documented');
    return doc;
  }

  // ─────────────────────────────────────────────────────────────
  // ADR GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate an Architecture Decision Record.
   * @param {Object} decision - Decision descriptor
   * @param {string} decision.title - Decision title
   * @param {string} decision.context - Decision context
   * @param {string} decision.decision - The decision made
   * @param {string[]} [decision.consequences] - Expected consequences
   * @param {string} [decision.status] - accepted | proposed | deprecated
   * @returns {Object} ADR document
   */
  generateADR(decision) {
    const adrNumber = this.adrRegistry.length + 1;
    const adr = {
      id: `ADR-${String(adrNumber).padStart(fib(4), '0')}`,
      title: decision.title,
      status: decision.status || 'proposed',
      context: decision.context,
      decision: decision.decision,
      consequences: decision.consequences || [],
      createdAt: new Date().toISOString(),
    };

    this.adrRegistry.push(adr);
    if (this.adrRegistry.length > SIZING.PATTERN_STORE) this.adrRegistry.shift();

    this.atlasMetrics.adrsCreated++;
    this.metrics.requestsHandled++;
    this.logger.info({ id: adr.id, title: adr.title }, 'ADR generated');
    return adr;
  }

  // ─────────────────────────────────────────────────────────────
  // DEPENDENCY GRAPHING
  // ─────────────────────────────────────────────────────────────

  /**
   * Build dependency graph from module descriptors.
   * @param {Object[]} modules - Module descriptors
   * @param {string} modules[].name - Module name
   * @param {string[]} [modules[].dependsOn] - Module dependencies
   * @returns {Object} Dependency graph analysis
   */
  mapDependencies(modules) {
    this.dependencyGraph.clear();

    for (const mod of modules) {
      if (!this.dependencyGraph.has(mod.name)) {
        this.dependencyGraph.set(mod.name, new Set());
      }
      for (const dep of (mod.dependsOn || [])) {
        this.dependencyGraph.get(mod.name).add(dep);
      }
    }

    // Compute depth per module (longest path from root)
    const depths = new Map();
    for (const mod of modules) {
      depths.set(mod.name, this._computeDepth(mod.name, new Set()));
    }

    const maxDepth = Math.max(0, ...depths.values());
    const circular = this._detectCircularDeps(modules);

    this.atlasMetrics.graphsMapped++;
    this.metrics.requestsHandled++;
    this.logger.info({ modules: modules.length, maxDepth, circular: circular.length }, 'Dependencies mapped');

    return {
      modules: modules.length,
      graph: Object.fromEntries([...this.dependencyGraph].map(([k, v]) => [k, [...v]])),
      depths: Object.fromEntries(depths),
      maxDepth,
      circular,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // API DOCUMENTATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate API documentation from endpoint descriptors.
   * @param {Object[]} endpoints - Endpoint descriptors
   * @param {string} endpoints[].method - HTTP method
   * @param {string} endpoints[].path - Endpoint path
   * @param {string} [endpoints[].description] - Description
   * @returns {Object} API documentation
   */
  documentAPI(endpoints) {
    const grouped = {};
    for (const ep of endpoints) {
      const tag = ep.tag || ep.path.split('/')[1] || 'general';
      if (!grouped[tag]) grouped[tag] = [];
      grouped[tag].push({ method: ep.method, path: ep.path, description: ep.description || '' });
    }

    const doc = {
      id: `api_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      endpointCount: endpoints.length,
      groups: grouped,
      timestamp: new Date().toISOString(),
    };

    this._cacheDocument(`api:${doc.id}`, doc);
    this.atlasMetrics.apisDocumented++;
    this.metrics.requestsHandled++;
    this.logger.info({ endpoints: endpoints.length, groups: Object.keys(grouped).length }, 'API documented');
    return doc;
  }

  // ─────────────────────────────────────────────────────────────
  // TOPOLOGY VISUALIZATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate topology description from node descriptors.
   * @param {Object[]} nodes - Node descriptors with ring and pool
   * @returns {Object} Topology visualization descriptor
   */
  visualizeTopology(nodes) {
    const rings = this._groupByRing(nodes);
    const pools = this._groupByPool(nodes);
    const connectionCount = nodes.reduce((s, n) => s + ((n.connections || []).length), 0);

    this.atlasMetrics.topologiesVisualized++;
    this.metrics.requestsHandled++;
    this.logger.info({ nodes: nodes.length, rings: Object.keys(rings).length }, 'Topology visualized');

    return { totalNodes: nodes.length, rings, pools, connectionCount, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  _cacheDocument(key, doc) {
    this.documentCache.set(key, doc);
    while (this.documentCache.size > SIZING.CACHE_SIZE) {
      const oldest = this.documentCache.keys().next().value;
      this.documentCache.delete(oldest);
    }
  }

  _groupByRing(components) {
    const groups = {};
    for (const c of components) {
      const ring = c.ring || 'unknown';
      if (!groups[ring]) groups[ring] = [];
      groups[ring].push(c.name || c);
    }
    return groups;
  }

  _groupByPool(components) {
    const groups = {};
    for (const c of components) {
      const pool = c.pool || 'unknown';
      if (!groups[pool]) groups[pool] = [];
      groups[pool].push(c.name || c);
    }
    return groups;
  }

  _computeDepth(name, visited) {
    if (visited.has(name)) return 0;
    visited.add(name);
    const deps = this.dependencyGraph.get(name);
    if (!deps || deps.size === 0) return 0;
    let maxChildDepth = 0;
    for (const dep of deps) {
      maxChildDepth = Math.max(maxChildDepth, this._computeDepth(dep, visited));
    }
    return maxChildDepth + 1;
  }

  _detectCircularDeps(modules) {
    const circular = [];
    for (const mod of modules) {
      const visited = new Set();
      if (this._hasCycle(mod.name, visited, new Set())) {
        circular.push(mod.name);
      }
    }
    return circular;
  }

  _hasCycle(name, visited, stack) {
    if (stack.has(name)) return true;
    if (visited.has(name)) return false;
    visited.add(name);
    stack.add(name);
    const deps = this.dependencyGraph.get(name);
    if (deps) {
      for (const dep of deps) {
        if (this._hasCycle(dep, visited, stack)) return true;
      }
    }
    stack.delete(name);
    return false;
  }
}

export { AtlasNode, AtlasNode as Atlas };
