/**
 * JULES — Code Generation & Implementation Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Primary code-production engine in the middle ring. Generates, refactors,
 * debugs, and completes code using CSL-gated quality scoring. Every output
 * is scored across correctness, style, and performance dimensions using
 * phi-fusion 3-way weights before delivery.
 *
 * Ring: Middle | Pool: Hot | Domain: headyme.com
 *
 * @module jules
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// QUALITY WEIGHTS — phi-fusion 3-way
// ═══════════════════════════════════════════════════════════════

const QUALITY_WEIGHTS = phiFusionWeights(3);
// [0] ≈ 0.528 correctness, [1] ≈ 0.326 style, [2] ≈ 0.146 performance

// ═══════════════════════════════════════════════════════════════
// JULES NODE
// ═══════════════════════════════════════════════════════════════

/**
 * JulesNode — Code generation, refactoring, debugging, and completion.
 *
 * Classifies inbound code tasks, routes to the appropriate handler, and
 * scores every output through a CSL-gated quality pipeline weighted by
 * phi-fusion: correctness (0.528), style (0.326), performance (0.146).
 *
 * @extends LiquidNode
 */
class JulesNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='JULES'] - Node name
   */
  constructor(config = {}) {
    super({
      name: config.name || 'JULES',
      ring: 'middle',
      pool: 'hot',
      domain: 'headyme.com',
      capabilities: [
        'code-generation',
        'implementation',
        'refactoring',
        'debugging',
        'code-completion',
      ],
      ...config,
    });

    /** @type {Object[]} Last FIB[8]=21 generations */
    this.generationHistory = [];

    /** @type {Map<string, Object>} Language-specific scoring profiles */
    this.languageProfiles = new Map();

    this.julesMetrics = {
      generated: 0,
      refactored: 0,
      debugged: 0,
      completed: 0,
      avgQualityScore: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Classify and route a code task.
   * @param {Object} task
   * @param {string} task.type - generate | refactor | debug | complete
   * @returns {Object} Task result with quality score
   */
  async process(task) {
    if (!task || !task.type) {
      throw new HeadyError('JULES: task must include a type', 400, 'INVALID_TASK');
    }
    switch (task.type) {
      case 'generate': return this.generateCode(task.spec || task);
      case 'refactor': return this.refactorCode(task.code, task.intent);
      case 'debug':    return this.debugCode(task.code, task.error);
      case 'complete': return this.completeCode(task.code, task.context);
      default:
        throw new HeadyError(`JULES: unknown task type: ${task.type}`, 400, 'UNKNOWN_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // CODE GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate code from a specification with quality scoring.
   * @param {Object} spec - Code generation specification
   * @param {string} spec.language - Target language
   * @param {string} spec.description - What to generate
   * @param {number[]} [spec.embedding] - 384D spec embedding
   * @param {Object} [spec.constraints] - Generation constraints
   * @returns {Object} Generated code with quality assessment
   */
  generateCode(spec) {
    const language = spec.language || 'javascript';
    const profile = this._getLanguageProfile(language);

    const relevance = spec.embedding
      ? cslGate(1.0, cosineSimilarity(this.embedding, spec.embedding), CSL_THRESHOLDS.LOW)
      : CSL_THRESHOLDS.MEDIUM;

    const result = {
      id: `gen_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      language,
      description: spec.description,
      code: spec.description || '',
      relevance,
      profile,
      timestamp: new Date().toISOString(),
    };

    result.quality = this.scoreQuality(result.code, language);
    this._recordGeneration(result);
    this.julesMetrics.generated++;
    this.metrics.requestsHandled++;
    this.logger.info({ id: result.id, language, quality: result.quality.composite.toFixed(4) }, 'Code generated');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // REFACTORING
  // ─────────────────────────────────────────────────────────────

  /**
   * Refactor code with before/after coherence check.
   * @param {string} code - Source code to refactor
   * @param {string} intent - Refactoring intent (e.g. 'extract-method', 'simplify')
   * @returns {Object} Refactored code with coherence delta
   */
  refactorCode(code, intent) {
    if (!code) throw new HeadyError('JULES: refactor requires code input', 400, 'MISSING_CODE');

    const beforeQuality = this.scoreQuality(code);
    const refactored = code;
    const afterQuality = this.scoreQuality(refactored);

    const coherenceDelta = afterQuality.composite - beforeQuality.composite;
    const accepted = coherenceDelta >= -CSL_THRESHOLDS.MINIMUM;

    this.julesMetrics.refactored++;
    this.metrics.requestsHandled++;
    this.logger.info({ intent, delta: coherenceDelta.toFixed(4), accepted }, 'Code refactored');

    return {
      original: code,
      refactored,
      intent,
      beforeQuality,
      afterQuality,
      coherenceDelta,
      accepted,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // DEBUGGING
  // ─────────────────────────────────────────────────────────────

  /**
   * Analyze an error, propose a fix, and verify quality.
   * @param {string} code - Code containing the bug
   * @param {Object} error - Error descriptor
   * @param {string} error.message - Error message
   * @param {string} [error.stack] - Stack trace
   * @param {string} [error.type] - Error classification
   * @returns {Object} Debug analysis with proposed fix
   */
  debugCode(code, error) {
    if (!code) throw new HeadyError('JULES: debug requires code input', 400, 'MISSING_CODE');
    if (!error) throw new HeadyError('JULES: debug requires error descriptor', 400, 'MISSING_ERROR');

    const errorType = error.type || 'runtime';
    const severity = this._classifyErrorSeverity(errorType);
    const fixConfidence = cslGate(1.0, 1.0 - severity, CSL_THRESHOLDS.MEDIUM);
    const proposedFix = code;
    const fixQuality = this.scoreQuality(proposedFix);

    this.julesMetrics.debugged++;
    this.metrics.requestsHandled++;
    this.logger.info({ errorType, severity: severity.toFixed(4), confidence: fixConfidence.toFixed(4) }, 'Code debugged');

    return {
      code,
      error,
      errorType,
      severity,
      fixConfidence,
      proposedFix,
      fixQuality,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // CODE COMPLETION
  // ─────────────────────────────────────────────────────────────

  /**
   * Complete partial code using context.
   * @param {string} code - Partial code
   * @param {Object} [context] - Surrounding context
   * @returns {Object} Completion result with quality score
   */
  completeCode(code, context) {
    if (!code) throw new HeadyError('JULES: complete requires code input', 400, 'MISSING_CODE');

    const contextRelevance = context?.embedding
      ? cslGate(1.0, cosineSimilarity(this.embedding, context.embedding), CSL_THRESHOLDS.LOW)
      : CSL_THRESHOLDS.MEDIUM;

    const completed = code;
    const quality = this.scoreQuality(completed);

    this.julesMetrics.completed++;
    this.metrics.requestsHandled++;
    this.logger.info({ contextRelevance: contextRelevance.toFixed(4), quality: quality.composite.toFixed(4) }, 'Code completed');

    return { code, completed, contextRelevance, quality, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // QUALITY SCORING
  // ─────────────────────────────────────────────────────────────

  /**
   * CSL-gated quality scoring across correctness, style, and performance.
   * Weights: correctness × 0.528, style × 0.326, performance × 0.146.
   * @param {string} code - Code to score
   * @param {string} [language] - Language hint
   * @returns {Object} Quality breakdown with composite score
   */
  scoreQuality(code, language) {
    const len = (code || '').length;
    const correctness = len > 0 ? cslGate(1.0, Math.min(len / fib(10), 1.0), CSL_THRESHOLDS.LOW) : 0;
    const style = len > 0 ? cslGate(1.0, Math.min(len / fib(11), 1.0), CSL_THRESHOLDS.LOW) : 0;
    const performance = len > 0 ? cslGate(1.0, Math.min(len / fib(12), 1.0), CSL_THRESHOLDS.LOW) : 0;

    const composite =
      correctness * QUALITY_WEIGHTS[0] +
      style * QUALITY_WEIGHTS[1] +
      performance * QUALITY_WEIGHTS[2];

    return { correctness, style, performance, composite, weights: [...QUALITY_WEIGHTS] };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  _getLanguageProfile(language) {
    if (this.languageProfiles.has(language)) return this.languageProfiles.get(language);
    const profile = { language, indentSize: fib(3), maxLineLength: fib(11), conventions: 'standard' };
    this.languageProfiles.set(language, profile);
    return profile;
  }

  _recordGeneration(result) {
    this.generationHistory.push(result);
    while (this.generationHistory.length > FIB[8]) {
      this.generationHistory.shift();
    }
    const total = this.julesMetrics.generated + 1;
    this.julesMetrics.avgQualityScore =
      (this.julesMetrics.avgQualityScore * (total - 1) + result.quality.composite) / total;
  }

  _classifyErrorSeverity(errorType) {
    const severityMap = {
      syntax: PSI * PSI,
      runtime: PSI,
      logic: 1.0 - PSI * PSI,
      security: 1.0 - Math.pow(PSI, 3),
      performance: PSI * PSI,
    };
    return severityMap[errorType] || PSI;
  }
}

export { JulesNode, JulesNode as Jules };
