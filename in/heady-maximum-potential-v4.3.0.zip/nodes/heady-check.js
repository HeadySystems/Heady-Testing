/**
 * HeadyCheck — Output Validation & Quality Gate
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Every artifact leaving the Heady pipeline passes through HeadyCheck for
 * schema validation, content verification, and CSL-gated quality scoring.
 * The quality gate enforces strict phi-derived thresholds — pass, warn,
 * or fail — with full audit trail.
 *
 * Ring: Governance | Pool: Governance | Domain: headyme.com
 *
 * @module heady-check
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD,
  phiFusionWeights, cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// HEADY CHECK NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyCheckNode — Output validation and quality gate for the governance shell.
 *
 * Validates outputs against registered schemas, scores artifact quality
 * through CSL-gated fusion, and enforces phi-derived pass/warn/fail
 * thresholds before any artifact exits the pipeline.
 *
 * @extends LiquidNode
 */
class HeadyCheckNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HeadyCheck']
   */
  constructor(config = {}) {
    super({
      name: 'HeadyCheck',
      ring: 'governance',
      pool: 'governance',
      domain: 'headyme.com',
      capabilities: [
        'output-validation',
        'quality-gate',
        'schema-validation',
        'content-verification',
        'compliance-check',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Schema registry keyed by schema name */
    this.schemaRegistry = new Map();

    /** @type {Map<string, Function>} Validation rule registry */
    this.validationRules = new Map();

    /** @type {Object[]} Bounded gate history — FIB[9] = 34 max */
    this.gateHistory = [];

    /** @type {number} */
    this.maxGateHistory = FIB[9];

    this.gateMetrics = {
      totalValidations: 0,
      passed: 0,
      warned: 0,
      failed: 0,
      schemaErrors: 0,
    };

    this._registerDefaultRules();
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a validation task.
   * @param {Object} task
   * @param {string} task.type - validateOutput | qualityGate | checkSchema | verifyContent
   * @returns {Object} Validation result
   */
  async process(task) {
    this.metrics.requestsHandled++;
    switch (task.type) {
      case 'validateOutput': return this.validateOutput(task.output, task.schema);
      case 'qualityGate':    return this.qualityGate(task.artifact, task.thresholds);
      case 'checkSchema':    return this.checkSchema(task.data, task.schema);
      case 'verifyContent':  return this.verifyContent(task.content, task.expectations);
      default:
        throw new HeadyError(`HeadyCheck: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
  }

  // ─────────────────────────────────────────────────────────────
  // OUTPUT VALIDATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Validate an output artifact against a named schema.
   * @param {Object} output - Output data to validate
   * @param {string|Object} schema - Schema name or inline schema object
   * @returns {Object} Validation result with issues and score
   */
  validateOutput(output, schema) {
    if (!output) throw new HeadyError('HeadyCheck: output is required', 400, 'MISSING_OUTPUT');

    const resolved = typeof schema === 'string' ? this.schemaRegistry.get(schema) : schema;
    const issues = [];

    if (resolved) {
      const schemaResult = this._validateAgainstSchema(output, resolved);
      issues.push(...schemaResult.issues);
    }

    for (const [ruleName, ruleFn] of this.validationRules) {
      const ruleResult = ruleFn(output);
      if (!ruleResult.valid) {
        issues.push({ rule: ruleName, message: ruleResult.message, severity: ruleResult.severity || 'error' });
      }
    }

    const errorCount = issues.filter(i => i.severity === 'error').length;
    const warnCount = issues.filter(i => i.severity === 'warning').length;
    const score = issues.length === 0 ? 1.0
      : Math.max(0, 1.0 - errorCount * PSI - warnCount * Math.pow(PSI, 3));

    this.gateMetrics.totalValidations++;
    this.logger.info({ issues: issues.length, score: score.toFixed(4) }, 'Output validated');

    return { valid: errorCount === 0, score, issues };
  }

  // ─────────────────────────────────────────────────────────────
  // QUALITY GATE
  // ─────────────────────────────────────────────────────────────

  /**
   * Run an artifact through the quality gate using CSL thresholds.
   *
   * Pass if score >= CSL_THRESHOLDS.MEDIUM (~0.809).
   * Warn if score >= CSL_THRESHOLDS.LOW (~0.691).
   * Fail below CSL_THRESHOLDS.LOW.
   *
   * @param {Object} artifact - Artifact with scores and metadata
   * @param {Object} [thresholds] - Optional custom thresholds
   * @returns {Object} Gate result: { passed, score, level, issues, recommendations }
   */
  qualityGate(artifact, thresholds = {}) {
    const passThreshold = thresholds.pass || CSL_THRESHOLDS.MEDIUM;
    const warnThreshold = thresholds.warn || CSL_THRESHOLDS.LOW;

    const factors = [];
    if (artifact.accuracy != null) factors.push(artifact.accuracy);
    if (artifact.completeness != null) factors.push(artifact.completeness);
    if (artifact.coherence != null) factors.push(artifact.coherence);
    if (artifact.compliance != null) factors.push(artifact.compliance);
    if (factors.length === 0 && artifact.score != null) factors.push(artifact.score);
    if (factors.length === 0) factors.push(CSL_THRESHOLDS.MINIMUM);

    const weights = phiFusionWeights(factors.length);
    const score = factors.reduce((sum, f, i) => sum + f * weights[i], 0);

    const issues = [];
    const recommendations = [];

    if (score < warnThreshold) {
      issues.push({ severity: 'error', message: `Quality score ${score.toFixed(4)} below warn threshold ${warnThreshold.toFixed(4)}` });
      recommendations.push('Review and revise artifact before release');
    } else if (score < passThreshold) {
      issues.push({ severity: 'warning', message: `Quality score ${score.toFixed(4)} below pass threshold ${passThreshold.toFixed(4)}` });
      recommendations.push('Consider additional review before release');
    }

    const passed = score >= passThreshold;
    const level = passed ? 'pass' : score >= warnThreshold ? 'warn' : 'fail';

    if (passed) this.gateMetrics.passed++;
    else if (level === 'warn') this.gateMetrics.warned++;
    else this.gateMetrics.failed++;

    const result = { passed, score, level, issues, recommendations, timestamp: new Date().toISOString() };

    this.gateHistory.push(result);
    if (this.gateHistory.length > this.maxGateHistory) this.gateHistory.shift();

    this.logger.info({ level, score: score.toFixed(4) }, 'Quality gate evaluated');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // SCHEMA VALIDATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Check data against a schema definition.
   * @param {Object} data - Data to validate
   * @param {Object} schema - Schema with required fields and types
   * @returns {Object} Schema check result
   */
  checkSchema(data, schema) {
    if (!data || !schema) {
      throw new HeadyError('HeadyCheck: data and schema are required', 400, 'MISSING_PARAMS');
    }
    const result = this._validateAgainstSchema(data, schema);
    if (result.issues.length > 0) this.gateMetrics.schemaErrors++;
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // CONTENT VERIFICATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Verify content meets expectations using CSL-gated cosine similarity.
   * @param {Object} content - Content with text and optional embedding
   * @param {Object} expectations - Expected attributes (embedding, minLength, keywords)
   * @returns {Object} Verification result
   */
  verifyContent(content, expectations) {
    if (!content) throw new HeadyError('HeadyCheck: content is required', 400, 'MISSING_CONTENT');

    const checks = [];

    if (expectations.embedding && content.embedding) {
      const sim = cosineSimilarity(content.embedding, expectations.embedding);
      const gated = cslGate(1.0, sim, CSL_THRESHOLDS.LOW);
      checks.push({ check: 'semantic-similarity', score: gated, passed: gated >= CSL_THRESHOLDS.MINIMUM });
    }

    if (expectations.minLength && content.text) {
      const lengthOk = content.text.length >= expectations.minLength;
      checks.push({ check: 'min-length', score: lengthOk ? 1.0 : content.text.length / expectations.minLength, passed: lengthOk });
    }

    if (expectations.keywords && content.text) {
      const textLower = content.text.toLowerCase();
      const matched = expectations.keywords.filter(k => textLower.includes(k.toLowerCase()));
      const keywordScore = expectations.keywords.length > 0 ? matched.length / expectations.keywords.length : 1.0;
      checks.push({ check: 'keywords', score: keywordScore, passed: keywordScore >= CSL_THRESHOLDS.MINIMUM });
    }

    const weights = phiFusionWeights(Math.max(checks.length, 1));
    const overallScore = checks.length > 0
      ? checks.reduce((sum, c, i) => sum + c.score * weights[i], 0)
      : 0;

    return {
      verified: checks.every(c => c.passed),
      score: overallScore,
      checks,
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────────────────

  _validateAgainstSchema(data, schema) {
    const issues = [];
    if (schema.required) {
      for (const field of schema.required) {
        if (data[field] === undefined || data[field] === null) {
          issues.push({ severity: 'error', field, message: `Missing required field: ${field}` });
        }
      }
    }
    if (schema.types) {
      for (const [field, expectedType] of Object.entries(schema.types)) {
        if (data[field] !== undefined && typeof data[field] !== expectedType) {
          issues.push({ severity: 'error', field, message: `Expected ${expectedType}, got ${typeof data[field]}` });
        }
      }
    }
    return { valid: issues.length === 0, issues };
  }

  _registerDefaultRules() {
    this.validationRules.set('non-empty', (output) => {
      const keys = Object.keys(output || {});
      return { valid: keys.length > 0, message: 'Output must not be empty', severity: 'error' };
    });
  }
}

export { HeadyCheckNode, HeadyCheckNode as HeadyCheck };
