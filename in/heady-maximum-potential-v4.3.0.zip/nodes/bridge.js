/**
 * BRIDGE — Translation & Cross-Domain Communication
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Translates content between domains, converts data formats, and bridges
 * communication protocols across the Sacred Geometry topology. All translation
 * scoring uses CSL-gated cosine similarity for fidelity measurement.
 *
 * Ring: Outer | Pool: Warm | Domain: headyme.com
 *
 * @module bridge
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD,
  phiFusionWeights, cslGate, cosineSimilarity, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// BRIDGE NODE
// ═══════════════════════════════════════════════════════════════

/**
 * BridgeNode — Translates content across domains, converts formats,
 * and bridges communication protocols with CSL fidelity scoring.
 *
 * @extends LiquidNode
 */
class BridgeNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='BRIDGE'] - Node name
   */
  constructor(config = {}) {
    super({
      name: 'BRIDGE',
      ring: 'outer',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: ['translation', 'cross-domain', 'protocol-bridging', 'format-conversion', 'i18n'],
      ...config,
    });

    /** @type {Map<string, Object>} Translation result cache, LRU bounded */
    this.translationCache = new Map();
    /** @type {number} Max cache entries — fib(16) = 987 */
    this.maxCacheSize = FIB[16];

    /** @type {Map<string, Function>} Protocol handler registry */
    this.protocolHandlers = new Map();

    /** @type {Map<string, Object>} Domain mapping rules */
    this.domainMappings = new Map();

    this.bridgeMetrics = {
      translations: 0,
      formatConversions: 0,
      protocolBridges: 0,
      cacheHits: 0,
      fidelitySum: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a bridge task.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - translate | convert | bridge | stats
   * @returns {Object} Task result
   */
  async process(task) {
    this.transition('thinking');
    let result;
    switch (task.type) {
      case 'translate': result = this.translate(task.content, task.sourceDomain, task.targetDomain); break;
      case 'convert':   result = this.convertFormat(task.data, task.from, task.to); break;
      case 'bridge':    result = this.bridgeProtocol(task.message, task.sourceProtocol, task.targetProtocol); break;
      case 'stats':     result = this.stats(); break;
      default: throw new HeadyError(`BRIDGE: unknown task type: ${task.type}`, 400, 'INVALID_TASK');
    }
    this.metrics.requestsHandled++;
    this.transition('responding');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // TRANSLATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Translate content from one domain to another with fidelity scoring.
   *
   * @param {Object} content - Content to translate (text, embedding, metadata)
   * @param {string} sourceDomain - Origin domain
   * @param {string} targetDomain - Destination domain
   * @returns {Object} Translated content with fidelity score
   */
  translate(content, sourceDomain, targetDomain) {
    if (!content || !sourceDomain || !targetDomain) {
      throw new HeadyError('BRIDGE: translate requires content, sourceDomain, targetDomain', 400, 'MISSING_PARAMS');
    }

    const cacheKey = `${sourceDomain}:${targetDomain}:${JSON.stringify(content.text || content.id || '')}`;
    const cached = this._cacheGet(cacheKey);
    if (cached) {
      this.bridgeMetrics.cacheHits++;
      return cached;
    }

    const mapping = this.domainMappings.get(`${sourceDomain}->${targetDomain}`);
    const translated = {
      text: content.text || '',
      sourceDomain,
      targetDomain,
      mapping: mapping || null,
      metadata: { ...content.metadata, bridgedAt: new Date().toISOString() },
    };

    let fidelity = CSL_THRESHOLDS.MEDIUM;
    if (content.embedding) {
      const sourceNorm = Math.sqrt(content.embedding.reduce((s, v) => s + v * v, 0));
      fidelity = sourceNorm > 0 ? cslGate(1.0, sourceNorm, CSL_THRESHOLDS.LOW) : CSL_THRESHOLDS.LOW;
      translated.embedding = content.embedding;
    }

    translated.fidelity = fidelity;
    this.bridgeMetrics.translations++;
    this.bridgeMetrics.fidelitySum += fidelity;

    this._cacheSet(cacheKey, translated);
    this.logger.info({ sourceDomain, targetDomain, fidelity: fidelity.toFixed(4) }, 'Content translated');
    return translated;
  }

  // ─────────────────────────────────────────────────────────────
  // FORMAT CONVERSION
  // ─────────────────────────────────────────────────────────────

  /**
   * Convert data between formats with structure preservation scoring.
   *
   * @param {*} data - Source data
   * @param {string} from - Source format (json, yaml, csv, xml, text)
   * @param {string} to - Target format
   * @returns {Object} Converted data with fidelity metrics
   */
  convertFormat(data, from, to) {
    if (data === undefined || !from || !to) {
      throw new HeadyError('BRIDGE: convertFormat requires data, from, to', 400, 'MISSING_PARAMS');
    }

    const lossless = from === to;
    const structureScore = lossless ? 1.0 : CSL_THRESHOLDS.HIGH;
    const weights = phiFusionWeights(2);
    const fidelity = structureScore * weights[0] + (lossless ? 1.0 : CSL_THRESHOLDS.MEDIUM) * weights[1];

    const result = {
      data: lossless ? data : (typeof data === 'object' ? JSON.parse(JSON.stringify(data)) : String(data)),
      from,
      to,
      lossless,
      fidelity,
      timestamp: new Date().toISOString(),
    };

    this.bridgeMetrics.formatConversions++;
    this.logger.info({ from, to, fidelity: fidelity.toFixed(4) }, 'Format converted');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // PROTOCOL BRIDGING
  // ─────────────────────────────────────────────────────────────

  /**
   * Bridge a message between protocols with delivery scoring.
   *
   * @param {Object} message - Message payload
   * @param {string} sourceProtocol - Origin protocol identifier
   * @param {string} targetProtocol - Destination protocol identifier
   * @returns {Object} Bridged message with delivery metadata
   */
  bridgeProtocol(message, sourceProtocol, targetProtocol) {
    if (!message || !sourceProtocol || !targetProtocol) {
      throw new HeadyError('BRIDGE: bridgeProtocol requires message, sourceProtocol, targetProtocol', 400, 'MISSING_PARAMS');
    }

    const handler = this.protocolHandlers.get(targetProtocol);
    const bridged = {
      payload: message,
      sourceProtocol,
      targetProtocol,
      handlerAvailable: !!handler,
      deliveryScore: handler ? CSL_THRESHOLDS.HIGH : CSL_THRESHOLDS.LOW,
      bridgedAt: new Date().toISOString(),
    };

    if (handler) {
      try {
        bridged.payload = handler(message, sourceProtocol);
      } catch (err) {
        bridged.deliveryScore = CSL_THRESHOLDS.MINIMUM;
        bridged.error = err.message;
        this.logger.warn({ sourceProtocol, targetProtocol, error: err.message }, 'Protocol handler error');
      }
    }

    this.bridgeMetrics.protocolBridges++;
    this.logger.info({ sourceProtocol, targetProtocol, score: bridged.deliveryScore.toFixed(4) }, 'Protocol bridged');
    return bridged;
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & INTERNALS
  // ─────────────────────────────────────────────────────────────

  /** @returns {Object} Bridge operational statistics */
  stats() {
    const avgFidelity = this.bridgeMetrics.translations > 0
      ? this.bridgeMetrics.fidelitySum / this.bridgeMetrics.translations : 0;
    return {
      ...this.bridgeMetrics,
      avgFidelity,
      cacheSize: this.translationCache.size,
      maxCacheSize: this.maxCacheSize,
      protocolHandlers: this.protocolHandlers.size,
      domainMappings: this.domainMappings.size,
    };
  }

  /** LRU cache get with promotion. */
  _cacheGet(key) {
    if (!this.translationCache.has(key)) return undefined;
    const val = this.translationCache.get(key);
    this.translationCache.delete(key);
    this.translationCache.set(key, val);
    return val;
  }

  /** LRU cache set with eviction. */
  _cacheSet(key, value) {
    if (this.translationCache.has(key)) this.translationCache.delete(key);
    this.translationCache.set(key, value);
    if (this.translationCache.size > this.maxCacheSize) {
      const oldest = this.translationCache.keys().next().value;
      this.translationCache.delete(oldest);
    }
  }
}

export { BridgeNode, BridgeNode as Bridge };
