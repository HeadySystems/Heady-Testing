/**
 * Backpressure — SRE Adaptive Throttling, Semantic Dedup & Priority Scoring
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Implements Google-SRE-style adaptive throttling with phi-derived parameters,
 * embedding-based semantic deduplication, and phi-weighted priority scoring.
 * BackpressureManager orchestrates all three into a single evaluate() call
 * that every inbound request passes through.
 *
 * @module backpressure
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD, PRESSURE_LEVELS,
  phiBackoff, phiFusionWeights,
  cslGate, cosineSimilarity,
} from './phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// ADAPTIVE THROTTLER (Google SRE Algorithm)
// ═══════════════════════════════════════════════════════════════

/**
 * AdaptiveThrottler — Google SRE rejection algorithm.
 *
 * Tracks requests and accepts over a sliding window. Rejects with
 * probability: max(0, (requests − 2 × accepts) / (requests + 1)).
 * The factor of 2 is the SRE "K" parameter — the aggressiveness ratio.
 */
class AdaptiveThrottler {
  /**
   * @param {number} [windowMs] - Sliding window duration (default fib(9) * 1000 = 34000ms)
   */
  constructor(windowMs = fib(9) * 1000) {
    /** @type {number} Window duration in milliseconds */
    this.windowMs = windowMs;

    /** @type {Array<{time: number, accepted: boolean}>} Request log */
    this._log = [];

    /** @type {number} SRE K parameter — ratio of accepts to allow */
    this._sreK = fib(3);
  }

  /**
   * Record a request outcome.
   * @param {boolean} accepted - Whether the request was accepted by backend
   */
  record(accepted) {
    this._log.push({ time: Date.now(), accepted });
    this._prune();
  }

  /**
   * Compute current rejection probability using the SRE formula.
   * P(reject) = max(0, (requests − K × accepts) / (requests + 1))
   *
   * @returns {number} Probability in [0, 1)
   */
  rejectProbability() {
    this._prune();
    const requests = this._log.length;
    if (requests === 0) return 0;
    const accepts = this._log.filter(e => e.accepted).length;
    return Math.max(0, (requests - this._sreK * accepts) / (requests + 1));
  }

  /**
   * Determine if the current request should be rejected.
   * @returns {boolean} true if the request should be rejected
   */
  shouldReject() {
    return Math.random() < this.rejectProbability();
  }

  /**
   * Remove entries outside the sliding window.
   */
  _prune() {
    const cutoff = Date.now() - this.windowMs;
    while (this._log.length > 0 && this._log[0].time < cutoff) {
      this._log.shift();
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// SEMANTIC DEDUPLICATOR
// ═══════════════════════════════════════════════════════════════

/**
 * SemanticDeduplicator — Embedding-based duplicate detection.
 *
 * Caches recent task embeddings and checks inbound tasks against
 * them using cosine similarity. If similarity exceeds the
 * DEDUP_THRESHOLD, returns the cached result instead of re-executing.
 */
class SemanticDeduplicator {
  /**
   * @param {number} [maxSize] - Maximum cache entries (default FIB[16] = 987)
   * @param {number} [threshold] - Cosine similarity threshold for dedup
   */
  constructor(maxSize = FIB[16], threshold = DEDUP_THRESHOLD) {
    /** @type {number} Max cache size */
    this.maxSize = maxSize;

    /** @type {number} Dedup cosine threshold */
    this.threshold = threshold;

    /** @type {Array<{embedding: number[], result: *, timestamp: number}>} Cache */
    this._cache = [];

    /** @type {number} Total checks performed */
    this._checks = 0;

    /** @type {number} Duplicates found */
    this._hits = 0;
  }

  /**
   * Check if an embedding is a duplicate of a recently cached entry.
   *
   * @param {number[]} embedding - Task embedding to check
   * @returns {{isDuplicate: boolean, cachedResult: *, similarity: number}|null}
   *   Match result, or null if no cache entries exist
   */
  check(embedding) {
    this._checks++;
    if (this._cache.length === 0) return null;

    let bestSim = -1;
    let bestEntry = null;

    for (const entry of this._cache) {
      const sim = cosineSimilarity(embedding, entry.embedding);
      if (sim > bestSim) {
        bestSim = sim;
        bestEntry = entry;
      }
    }

    if (bestSim >= this.threshold) {
      this._hits++;
      return {
        isDuplicate: true,
        cachedResult: bestEntry.result,
        similarity: bestSim,
      };
    }

    return {
      isDuplicate: false,
      cachedResult: null,
      similarity: bestSim,
    };
  }

  /**
   * Store a task embedding and its result in the cache.
   *
   * @param {number[]} embedding - Task embedding
   * @param {*} result - Task execution result
   */
  store(embedding, result) {
    this._cache.push({ embedding, result, timestamp: Date.now() });
    if (this._cache.length > this.maxSize) {
      this.prune();
    }
  }

  /**
   * Remove oldest entries to bring cache within capacity.
   * Evicts fib(6) = 8 entries at a time to amortize overhead.
   */
  prune() {
    if (this._cache.length <= this.maxSize) return;
    const evictCount = Math.min(fib(6), this._cache.length - this.maxSize + fib(6));
    this._cache = this._cache.slice(evictCount);
  }

  /**
   * Return deduplication statistics.
   * @returns {{checks: number, hits: number, hitRate: number, cacheSize: number}}
   */
  stats() {
    return {
      checks: this._checks,
      hits: this._hits,
      hitRate: this._checks > 0 ? this._hits / this._checks : 0,
      cacheSize: this._cache.length,
      maxSize: this.maxSize,
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// PRIORITY SCORER
// ═══════════════════════════════════════════════════════════════

/**
 * PriorityScorer — Phi-weighted multi-factor priority scoring.
 *
 * Computes a composite priority score from three factors using
 * phiFusionWeights(3): criticality, urgency, impact.
 * Weights: [~0.528, ~0.326, ~0.146] (φ-decay).
 */
class PriorityScorer {
  constructor() {
    /** @type {number[]} Phi-derived weights for [criticality, urgency, impact] */
    this.weights = phiFusionWeights(3);
  }

  /**
   * Compute a priority score from task factors.
   *
   * @param {Object} factors
   * @param {number} factors.criticality - How critical (0-1)
   * @param {number} factors.urgency - How urgent (0-1)
   * @param {number} factors.impact - Scope of impact (0-1)
   * @returns {number} Composite score in [0, 1]
   */
  score(factors) {
    const { criticality = 0, urgency = 0, impact = 0 } = factors;
    return (
      criticality * this.weights[0] +
      urgency * this.weights[1] +
      impact * this.weights[2]
    );
  }

  /**
   * Classify a priority score into a pressure level name.
   *
   * @param {number} score - Priority score (0-1)
   * @returns {string} Pressure level: NOMINAL | ELEVATED | HIGH | CRITICAL
   */
  classify(score) {
    for (const [name, range] of Object.entries(PRESSURE_LEVELS)) {
      if (score >= range.min && score < range.max) return name;
    }
    return 'CRITICAL';
  }
}

// ═══════════════════════════════════════════════════════════════
// BACKPRESSURE MANAGER
// ═══════════════════════════════════════════════════════════════

/**
 * BackpressureManager — Orchestrates throttling, dedup, and priority.
 *
 * Single evaluate() entry point that every inbound request passes through.
 * Combines AdaptiveThrottler, SemanticDeduplicator, and PriorityScorer
 * to produce a holistic admission decision.
 */
class BackpressureManager {
  /**
   * @param {Object} [config={}]
   * @param {number} [config.windowMs] - Throttler window duration
   * @param {number} [config.dedupMaxSize] - Dedup cache size
   * @param {number} [config.dedupThreshold] - Cosine dedup threshold
   */
  constructor(config = {}) {
    /** @type {AdaptiveThrottler} */
    this.throttler = new AdaptiveThrottler(config.windowMs);

    /** @type {SemanticDeduplicator} */
    this.deduplicator = new SemanticDeduplicator(
      config.dedupMaxSize,
      config.dedupThreshold
    );

    /** @type {PriorityScorer} */
    this.scorer = new PriorityScorer();

    /** Total evaluations performed */
    this._evaluations = 0;

    /** Requests allowed through */
    this._allowed = 0;

    /** Requests rejected */
    this._rejected = 0;

    /** Duplicates short-circuited */
    this._deduplicated = 0;
  }

  /**
   * Evaluate a task for admission.
   *
   * Pipeline:
   *   1. Score priority via PriorityScorer
   *   2. Check semantic dedup via SemanticDeduplicator
   *   3. Check throttle via AdaptiveThrottler
   *   4. Return composite decision
   *
   * @param {Object} task
   * @param {number} [task.criticality=0.5] - Criticality factor (0-1)
   * @param {number} [task.urgency=0.5] - Urgency factor (0-1)
   * @param {number} [task.impact=0.5] - Impact factor (0-1)
   * @param {number[]} [task.embedding] - Task embedding for dedup
   * @returns {Object} Admission decision
   */
  evaluate(task) {
    this._evaluations++;

    // 1. Priority scoring
    const score = this.scorer.score({
      criticality: task.criticality ?? PSI,
      urgency: task.urgency ?? PSI,
      impact: task.impact ?? PSI,
    });
    const pressure = this.scorer.classify(score);

    // 2. Semantic deduplication
    let isDuplicate = false;
    let cachedResult = null;
    let similarity = 0;

    if (task.embedding) {
      const dedupResult = this.deduplicator.check(task.embedding);
      if (dedupResult && dedupResult.isDuplicate) {
        isDuplicate = true;
        cachedResult = dedupResult.cachedResult;
        similarity = dedupResult.similarity;
        this._deduplicated++;
      }
    }

    // 3. Throttle check — high-priority tasks bypass throttling
    const rejectProbability = this.throttler.rejectProbability();
    let throttled = false;
    if (score < CSL_THRESHOLDS.HIGH) {
      throttled = this.throttler.shouldReject();
    }

    // 4. Composite decision
    const allowed = !throttled && !isDuplicate;
    if (allowed) {
      this._allowed++;
    } else {
      this._rejected++;
    }

    return {
      allowed,
      score,
      pressure,
      isDuplicate,
      cachedResult,
      similarity,
      throttled,
      rejectProbability,
    };
  }

  /**
   * Record a task outcome for the throttler.
   *
   * @param {string} taskId - Task identifier
   * @param {boolean} accepted - Whether the backend accepted the request
   */
  record(taskId, accepted) {
    this.throttler.record(accepted);
  }

  /**
   * Return current backpressure statistics.
   *
   * @returns {Object} Combined stats from all subsystems
   */
  stats() {
    return {
      evaluations: this._evaluations,
      allowed: this._allowed,
      rejected: this._rejected,
      deduplicated: this._deduplicated,
      rejectProbability: this.throttler.rejectProbability(),
      dedup: this.deduplicator.stats(),
      weights: this.scorer.weights,
    };
  }
}

export {
  AdaptiveThrottler,
  SemanticDeduplicator,
  PriorityScorer,
  BackpressureManager,
};
