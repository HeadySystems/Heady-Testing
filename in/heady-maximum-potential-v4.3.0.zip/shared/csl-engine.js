/**
 * CSL Engine — Continuous Semantic Logic Gate Implementation
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Heady's core geometric AI innovation: vector operations as logical gates.
 * Every decision in the ecosystem flows through CSL — a complete logical
 * algebra over 384D embedding space where cosine similarity replaces
 * boolean truth values and projections replace set operations.
 *
 * @module csl-engine
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, PHI_TEMPERATURE,
  cslGate, cosineSimilarity, phiFusionWeights,
} from './phi-constants.js';

/** Standard embedding dimensionality — fib(14) + fib(5) + fib(3) = 377 + 5 + 2 = 384 */
const EMBEDDING_DIM = FIB[14] + FIB[5] + FIB[3];

// ═══════════════════════════════════════════════════════════════
// VECTOR UTILITIES
// ═══════════════════════════════════════════════════════════════

/**
 * Compute the dot product of two vectors.
 * @param {number[]|Float64Array} a
 * @param {number[]|Float64Array} b
 * @returns {number} Scalar dot product Σ(aᵢ·bᵢ)
 */
function dotProduct(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i] * b[i];
  return sum;
}

/**
 * Compute the magnitude (L2 norm) of a vector.
 * @param {number[]|Float64Array} v
 * @returns {number} √(Σ(vᵢ²))
 */
function magnitude(v) {
  let sum = 0;
  for (let i = 0; i < v.length; i++) sum += v[i] * v[i];
  return Math.sqrt(sum);
}

/**
 * Normalize a vector to unit length.
 * Returns the zero vector unchanged.
 * @param {number[]|Float64Array} v
 * @returns {number[]} Unit vector v / ‖v‖
 */
function normalize(v) {
  const mag = magnitude(v);
  if (mag === 0) return Array.isArray(v) ? v.slice() : Array.from(v);
  const result = new Array(v.length);
  for (let i = 0; i < v.length; i++) result[i] = v[i] / mag;
  return result;
}

/**
 * Element-wise addition of two vectors.
 * @param {number[]|Float64Array} a
 * @param {number[]|Float64Array} b
 * @returns {number[]} a + b
 */
function addVectors(a, b) {
  const result = new Array(a.length);
  for (let i = 0; i < a.length; i++) result[i] = a[i] + b[i];
  return result;
}

/**
 * Scale a vector by a scalar.
 * @param {number[]|Float64Array} v
 * @param {number} s - Scalar multiplier
 * @returns {number[]} s · v
 */
function scaleVector(v, s) {
  const result = new Array(v.length);
  for (let i = 0; i < v.length; i++) result[i] = v[i] * s;
  return result;
}

/**
 * Generate a random unit vector of given dimension.
 * Uses the Gaussian method for uniform spherical distribution.
 * @param {number} [dim=384] - Vector dimensionality
 * @returns {number[]} Random unit vector
 */
function randomUnitVector(dim = EMBEDDING_DIM) {
  const vec = new Array(dim);
  // Box-Muller transform for Gaussian samples
  for (let i = 0; i < dim; i += 2) {
    const u1 = Math.random() || 1e-15;
    const u2 = Math.random();
    const r = Math.sqrt(-2 * Math.log(u1));
    vec[i] = r * Math.cos(2 * Math.PI * u2);
    if (i + 1 < dim) vec[i + 1] = r * Math.sin(2 * Math.PI * u2);
  }
  return normalize(vec);
}

// ═══════════════════════════════════════════════════════════════
// CSL CORE GATES
// ═══════════════════════════════════════════════════════════════

/**
 * CSL AND — Semantic alignment via cosine similarity.
 * Returns a scalar in [-1, 1] measuring how aligned two vectors are.
 *
 * @param {number[]|Float64Array} a - First vector
 * @param {number[]|Float64Array} b - Second vector
 * @returns {number} Cosine similarity (a·b)/(‖a‖·‖b‖)
 */
function cslAND(a, b) {
  const dot = dotProduct(a, b);
  const denom = magnitude(a) * magnitude(b);
  return denom > 0 ? dot / denom : 0;
}

/**
 * CSL OR — Soft union via superposition.
 * Returns the normalized sum of two vectors — the semantic blend.
 *
 * @param {number[]|Float64Array} a - First vector
 * @param {number[]|Float64Array} b - Second vector
 * @returns {number[]} normalize(a + b)
 */
function cslOR(a, b) {
  return normalize(addVectors(a, b));
}

/**
 * CSL NOT — Semantic negation via orthogonal projection.
 * Removes from a its component along b, leaving only the part
 * of a that is orthogonal to b.
 *
 * Properties:
 *   - Idempotent: NOT(NOT(a,b), b) = NOT(a,b)
 *   - Orthogonality: NOT(a,b) · b = 0
 *
 * @param {number[]|Float64Array} a - Vector to project
 * @param {number[]|Float64Array} b - Direction to negate
 * @returns {number[]} a − (a·b/‖b‖²)·b
 */
function cslNOT(a, b) {
  const dot = dotProduct(a, b);
  const normB2 = dotProduct(b, b);
  const proj = normB2 > 0 ? dot / normB2 : 0;
  const result = new Array(a.length);
  for (let i = 0; i < a.length; i++) result[i] = a[i] - proj * b[i];
  return result;
}

/**
 * CSL IMPLY — Projection of a onto b.
 * Returns the component of a in the direction of b.
 * Complementary to NOT: a = IMPLY(a,b) + NOT(a,b).
 *
 * @param {number[]|Float64Array} a - Source vector
 * @param {number[]|Float64Array} b - Direction to project onto
 * @returns {number[]} (a·b/‖b‖²)·b
 */
function cslIMPLY(a, b) {
  const dot = dotProduct(a, b);
  const normB2 = dotProduct(b, b);
  const proj = normB2 > 0 ? dot / normB2 : 0;
  return scaleVector(b, proj);
}

/**
 * CSL XOR — Exclusive semantic components.
 * Returns the part of the superposition (a+b) that is not shared between a and b.
 * Computes: normalize(a+b) minus the mutual projection.
 *
 * @param {number[]|Float64Array} a - First vector
 * @param {number[]|Float64Array} b - Second vector
 * @returns {number[]} Exclusive components vector
 */
function cslXOR(a, b) {
  const orVec = cslOR(a, b);
  const andScore = cslAND(a, b);
  const mutual = scaleVector(cslIMPLY(orVec, a), andScore);
  return cslNOT(orVec, mutual);
}

/**
 * CSL CONSENSUS — Weighted centroid for agent agreement voting.
 * Computes the phi-weighted (or custom-weighted) sum of vectors,
 * then normalizes to produce a unit direction of consensus.
 *
 * @param {Array<number[]|Float64Array>} vectors - Array of vote vectors
 * @param {number[]} [weights] - Optional weights (defaults to phiFusionWeights)
 * @returns {number[]} Normalized consensus direction
 */
function cslCONSENSUS(vectors, weights) {
  const w = weights || phiFusionWeights(vectors.length);
  const dim = vectors[0].length;
  const sum = new Array(dim).fill(0);
  for (let i = 0; i < vectors.length; i++) {
    for (let d = 0; d < dim; d++) sum[d] += w[i] * vectors[i][d];
  }
  return normalize(sum);
}

// ═══════════════════════════════════════════════════════════════
// SOFT GATING
// ═══════════════════════════════════════════════════════════════

/**
 * CSL Soft Gate — Sigmoid-gated value based on cosine score.
 * value × σ((cosScore − τ) / temp)
 *
 * @param {number} value - Raw value to gate
 * @param {number} cosScore - Cosine similarity score
 * @param {number} tau - Activation threshold
 * @param {number} [temp=PHI_TEMPERATURE] - Temperature (lower = sharper cutoff)
 * @returns {number} Gated value
 */
function cslGateSoft(value, cosScore, tau, temp = PHI_TEMPERATURE) {
  const sigmoid = 1 / (1 + Math.exp(-(cosScore - tau) / temp));
  return value * sigmoid;
}

/**
 * CSL Blend — Smooth weight interpolation replacing if/else branching.
 * Blends between weightLow and weightHigh based on sigmoid(cosScore − τ).
 *
 * @param {number} weightHigh - Weight when cosScore >> tau
 * @param {number} weightLow - Weight when cosScore << tau
 * @param {number} cosScore - Cosine similarity score
 * @param {number} tau - Crossover threshold
 * @returns {number} Interpolated weight
 */
function cslBlend(weightHigh, weightLow, cosScore, tau) {
  const sigmoid = 1 / (1 + Math.exp(-(cosScore - tau) / PHI_TEMPERATURE));
  return weightLow + (weightHigh - weightLow) * sigmoid;
}

// ═══════════════════════════════════════════════════════════════
// MoE ROUTER
// ═══════════════════════════════════════════════════════════════

/**
 * Mixture-of-Experts Router — CSL-based expert selection.
 *
 * Scores input against each expert gate vector via cosine similarity,
 * applies softmax with phi-derived temperature, and returns the top-K
 * experts with their normalized weights.
 *
 * @param {number[]|Float64Array} input - Input embedding
 * @param {Array<number[]|Float64Array>} expertGates - Expert gate vectors
 * @param {number} [k=2] - Number of experts to select
 * @param {number} [temperature] - Softmax temperature (default PSI³)
 * @returns {Array<{index: number, weight: number, score: number}>} Top-K experts
 */
function moeRoute(input, expertGates, k = fib(3), temperature = Math.pow(PSI, 3)) {
  const scores = expertGates.map((gate, i) => ({
    index: i,
    score: cslAND(input, gate),
  }));

  // Softmax with temperature scaling
  const maxScore = Math.max(...scores.map(s => s.score));
  const exps = scores.map(s => ({
    ...s,
    exp: Math.exp((s.score - maxScore) / temperature),
  }));
  const sumExp = exps.reduce((s, e) => s + e.exp, 0);

  // Assign weights and sort descending
  const weighted = exps
    .map(e => ({
      index: e.index,
      weight: sumExp > 0 ? e.exp / sumExp : 1 / expertGates.length,
      score: e.score,
    }))
    .sort((a, b) => b.weight - a.weight);

  // Return top-K with re-normalized weights
  const topK = weighted.slice(0, k);
  const topKSum = topK.reduce((s, e) => s + e.weight, 0);
  return topK.map(e => ({
    index: e.index,
    weight: topKSum > 0 ? e.weight / topKSum : 1 / k,
    score: e.score,
  }));
}

// ═══════════════════════════════════════════════════════════════
// TERNARY LOGIC MAPPING
// ═══════════════════════════════════════════════════════════════

/**
 * Map a cosine similarity score to ternary logic.
 *
 * - TRUE:    cosScore > +CSL_THRESHOLDS.MINIMUM  (> 0.5)
 * - UNKNOWN: cosScore is between ±MINIMUM
 * - FALSE:   cosScore < −CSL_THRESHOLDS.MINIMUM  (< -0.5)
 *
 * @param {number} cosScore - Cosine similarity in [-1, 1]
 * @returns {'TRUE'|'UNKNOWN'|'FALSE'} Ternary label
 */
function ternaryLabel(cosScore) {
  if (cosScore > CSL_THRESHOLDS.MINIMUM) return 'TRUE';
  if (cosScore > -CSL_THRESHOLDS.MINIMUM) return 'UNKNOWN';
  return 'FALSE';
}

// ═══════════════════════════════════════════════════════════════
// NAMESPACE EXPORT
// ═══════════════════════════════════════════════════════════════

/**
 * CSLEngine namespace — all CSL functions bundled for convenience.
 */
const CSLEngine = Object.freeze({
  // Vector utilities
  dotProduct,
  magnitude,
  normalize,
  addVectors,
  scaleVector,
  randomUnitVector,
  // Core gates
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslXOR,
  cslCONSENSUS,
  // Soft gating
  cslGateSoft,
  cslBlend,
  // Routing
  moeRoute,
  // Ternary
  ternaryLabel,
});

export {
  // Vector utilities
  dotProduct,
  magnitude,
  normalize,
  addVectors,
  scaleVector,
  randomUnitVector,
  // Core gates
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslXOR,
  cslCONSENSUS,
  // Soft gating
  cslGateSoft,
  cslBlend,
  // Routing
  moeRoute,
  // Ternary
  ternaryLabel,
  // Namespace
  CSLEngine,
};
