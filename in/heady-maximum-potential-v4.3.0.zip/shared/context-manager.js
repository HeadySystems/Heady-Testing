/**
 * ContextWindowManager — Tiered Context Window with Phi-Geometric Token Budgets
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Manages a four-tier context hierarchy (working → session → memory → artifacts)
 * where each tier's token budget scales by PHI². Entries flow between tiers
 * via promote/demote. Eviction uses phi-weighted scoring; compression triggers
 * at 1 − PSI⁴ ≈ 91% utilization.
 *
 * @module context-manager
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  phiFusionWeights, phiTokenBudgets,
  CSL_THRESHOLDS, COMPRESSION_TRIGGER,
  cslGate, cosineSimilarity,
} from './phi-constants.js';

// ═══════════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════════

/** Tier ordering (lowest → highest capacity) */
const TIER_ORDER = ['working', 'session', 'memory', 'artifacts'];

/** Number of entries to evict per pass — fib(6) = 8 */
const EVICTION_BATCH = fib(6);

/** Eviction weights: [importance, recency, relevance] from phiFusionWeights(3) */
const EVICTION_WEIGHTS = phiFusionWeights(3);

// ═══════════════════════════════════════════════════════════════
// CONTEXT ENTRY
// ═══════════════════════════════════════════════════════════════

/**
 * A single context entry stored within a tier.
 */
class ContextEntry {
  /**
   * @param {Object} config
   * @param {string} config.content - Text content
   * @param {number} config.tokens - Token count
   * @param {number} config.importance - Importance score (0-1)
   * @param {string} [config.tier='working'] - Assigned tier
   */
  constructor(config) {
    this.id = `ctx_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.content = config.content;
    this.tokens = config.tokens;
    this.importance = config.importance;
    this.tier = config.tier || 'working';
    this.timestamp = Date.now();
    this.lastAccessed = Date.now();
    this.accessCount = 0;
  }

  /**
   * Compute eviction score using phi-weighted factors.
   * Higher score = more valuable = keep.
   *
   * @param {number} now - Current timestamp for recency calculation
   * @returns {number} Eviction score
   */
  evictionScore(now) {
    const maxAge = fib(11) * 86400000;
    const recency = 1 - Math.min((now - this.lastAccessed) / maxAge, 1);
    const relevance = Math.min(this.accessCount / fib(8), 1);
    return (
      this.importance * EVICTION_WEIGHTS[0] +
      recency * EVICTION_WEIGHTS[1] +
      relevance * EVICTION_WEIGHTS[2]
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// CONTEXT WINDOW MANAGER
// ═══════════════════════════════════════════════════════════════

/**
 * ContextWindowManager — Four-tier context hierarchy with phi-geometric budgets.
 *
 * Tiers (default base = 8192):
 *   - working:   8192 tokens   (immediate context)
 *   - session:   21450 tokens  (session-level context)
 *   - memory:    56131 tokens  (long-term memory)
 *   - artifacts: 146920 tokens (persistent artifacts)
 *
 * Each tier is an array of ContextEntry objects. Entries flow between
 * tiers via promote() and demote(). Eviction and compression are
 * triggered automatically when budgets are exceeded.
 */
class ContextWindowManager {
  /**
   * @param {number} [base=8192] - Base token budget for working tier
   */
  constructor(base) {
    const budgets = phiTokenBudgets(base);

    /** @type {Object<string, number>} Token budget per tier */
    this.budgets = budgets;

    /** @type {Object<string, ContextEntry[]>} Entry storage per tier */
    this.tiers = {
      working:   [],
      session:   [],
      memory:    [],
      artifacts: [],
    };

    /** @type {number} Compression trigger ratio — 1 - PSI⁴ ≈ 0.854 */
    this.compressionTrigger = COMPRESSION_TRIGGER;

    /** Metrics */
    this._metrics = {
      totalAdded: 0,
      totalEvicted: 0,
      totalPromoted: 0,
      totalDemoted: 0,
      totalCompressed: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // ADD
  // ─────────────────────────────────────────────────────────────

  /**
   * Add content to a tier with automatic eviction if over budget.
   *
   * @param {string} content - Text content
   * @param {number} tokens - Token count
   * @param {number} importance - Importance score (0-1)
   * @param {string} [tier='working'] - Target tier
   * @returns {ContextEntry} The created entry
   */
  add(content, tokens, importance, tier = 'working') {
    if (!this.tiers[tier]) {
      throw new Error(`ContextWindowManager: unknown tier "${tier}"`);
    }

    const entry = new ContextEntry({ content, tokens, importance, tier });

    // Auto-evict if adding would exceed budget
    while (this._tierTokens(tier) + tokens > this.budgets[tier]) {
      const evicted = this.evict(tier);
      if (evicted === 0) break;
    }

    this.tiers[tier].push(entry);
    this._metrics.totalAdded++;
    return entry;
  }

  // ─────────────────────────────────────────────────────────────
  // PROMOTE / DEMOTE
  // ─────────────────────────────────────────────────────────────

  /**
   * Promote an entry to a higher-capacity tier.
   *
   * @param {string} entryId - Entry identifier
   * @param {string} targetTier - Destination tier
   * @returns {boolean} Whether promotion succeeded
   */
  promote(entryId, targetTier) {
    const targetIdx = TIER_ORDER.indexOf(targetTier);
    if (targetIdx < 0) return false;

    for (const tier of TIER_ORDER) {
      const idx = this.tiers[tier].findIndex(e => e.id === entryId);
      if (idx === -1) continue;

      const currentIdx = TIER_ORDER.indexOf(tier);
      if (targetIdx <= currentIdx) return false;

      const [entry] = this.tiers[tier].splice(idx, 1);
      entry.tier = targetTier;

      // Evict in target if necessary
      while (this._tierTokens(targetTier) + entry.tokens > this.budgets[targetTier]) {
        const evicted = this.evict(targetTier);
        if (evicted === 0) break;
      }

      this.tiers[targetTier].push(entry);
      this._metrics.totalPromoted++;
      return true;
    }
    return false;
  }

  /**
   * Demote an entry to the next lower tier.
   *
   * @param {string} entryId - Entry identifier
   * @returns {boolean} Whether demotion succeeded
   */
  demote(entryId) {
    for (const tier of TIER_ORDER) {
      const idx = this.tiers[tier].findIndex(e => e.id === entryId);
      if (idx === -1) continue;

      const currentIdx = TIER_ORDER.indexOf(tier);
      if (currentIdx === 0) return false;

      const lowerTier = TIER_ORDER[currentIdx - 1];
      const [entry] = this.tiers[tier].splice(idx, 1);
      entry.tier = lowerTier;

      while (this._tierTokens(lowerTier) + entry.tokens > this.budgets[lowerTier]) {
        const evicted = this.evict(lowerTier);
        if (evicted === 0) break;
      }

      this.tiers[lowerTier].push(entry);
      this._metrics.totalDemoted++;
      return true;
    }
    return false;
  }

  // ─────────────────────────────────────────────────────────────
  // EVICT
  // ─────────────────────────────────────────────────────────────

  /**
   * Evict the lowest-scoring entries from a tier.
   *
   * Scores each entry using phi-weighted eviction:
   *   score = importance × w₀ + recency × w₁ + relevance × w₂
   * Removes the bottom EVICTION_BATCH (fib(6) = 8) entries.
   *
   * @param {string} tier - Tier to evict from
   * @returns {number} Number of entries evicted
   */
  evict(tier) {
    const entries = this.tiers[tier];
    if (entries.length === 0) return 0;

    const now = Date.now();
    entries.sort((a, b) => a.evictionScore(now) - b.evictionScore(now));

    const count = Math.min(EVICTION_BATCH, entries.length);
    this.tiers[tier] = entries.slice(count);
    this._metrics.totalEvicted += count;
    return count;
  }

  // ─────────────────────────────────────────────────────────────
  // COMPRESS
  // ─────────────────────────────────────────────────────────────

  /**
   * Compress a tier when usage exceeds the compression trigger (~91%).
   *
   * Removes lowest-importance entries until usage drops below the trigger.
   * Returns a summary of removed entries for audit purposes.
   *
   * @param {string} tier - Tier to compress
   * @returns {Object} Compression summary
   */
  compress(tier) {
    const budget = this.budgets[tier];
    const used = this._tierTokens(tier);
    const trigger = budget * this.compressionTrigger;

    if (used <= trigger) {
      return { compressed: false, tier, used, trigger, removed: 0 };
    }

    const entries = this.tiers[tier];
    const now = Date.now();
    entries.sort((a, b) => a.evictionScore(now) - b.evictionScore(now));

    const removed = [];
    let currentTokens = used;

    while (currentTokens > trigger && entries.length > 0) {
      const entry = entries.shift();
      currentTokens -= entry.tokens;
      removed.push({
        id: entry.id,
        tokens: entry.tokens,
        importance: entry.importance,
      });
    }

    this.tiers[tier] = entries;
    this._metrics.totalCompressed += removed.length;

    return {
      compressed: true,
      tier,
      tokensBefore: used,
      tokensAfter: this._tierTokens(tier),
      trigger,
      removed: removed.length,
      removedEntries: removed,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // RETRIEVAL
  // ─────────────────────────────────────────────────────────────

  /**
   * Retrieve all entries for a tier, updating access metadata.
   *
   * @param {string} tier - Tier to retrieve from
   * @returns {ContextEntry[]} Entries sorted by importance descending
   */
  getContext(tier) {
    const entries = this.tiers[tier] || [];
    const now = Date.now();
    for (const entry of entries) {
      entry.lastAccessed = now;
      entry.accessCount++;
    }
    return entries.slice().sort((a, b) => b.importance - a.importance);
  }

  // ─────────────────────────────────────────────────────────────
  // USAGE & STATS
  // ─────────────────────────────────────────────────────────────

  /**
   * Return token usage for all tiers.
   *
   * @returns {Object<string, {used: number, budget: number, pct: number}>}
   */
  usage() {
    const report = {};
    for (const tier of TIER_ORDER) {
      const used = this._tierTokens(tier);
      const budget = this.budgets[tier];
      report[tier] = {
        used,
        budget,
        pct: budget > 0 ? used / budget : 0,
      };
    }
    return report;
  }

  // ─────────────────────────────────────────────────────────────
  // CONTEXT CAPSULE
  // ─────────────────────────────────────────────────────────────

  /**
   * Create a context capsule for inter-agent transfer.
   *
   * Packages system context, working entries, and memory entries
   * into a structured capsule with metadata for downstream consumers.
   *
   * @param {ContextEntry[]} [entries] - Optional explicit entries (defaults to working + memory)
   * @returns {Object} Context capsule
   */
  createCapsule(entries) {
    const workingEntries = entries || this.getContext('working');
    const memoryEntries = entries ? [] : this.getContext('memory');

    const totalTokens = [...workingEntries, ...memoryEntries]
      .reduce((sum, e) => sum + e.tokens, 0);

    return {
      id: `cap_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      systemContext: {
        tierBudgets: { ...this.budgets },
        usage: this.usage(),
        compressionTrigger: this.compressionTrigger,
      },
      workingEntries: workingEntries.map(e => ({
        id: e.id,
        content: e.content,
        tokens: e.tokens,
        importance: e.importance,
      })),
      memoryEntries: memoryEntries.map(e => ({
        id: e.id,
        content: e.content,
        tokens: e.tokens,
        importance: e.importance,
      })),
      metadata: {
        totalTokens,
        workingCount: workingEntries.length,
        memoryCount: memoryEntries.length,
        createdAt: new Date().toISOString(),
      },
    };
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL
  // ─────────────────────────────────────────────────────────────

  /**
   * Compute total tokens used in a tier.
   * @param {string} tier
   * @returns {number}
   */
  _tierTokens(tier) {
    return this.tiers[tier].reduce((sum, e) => sum + e.tokens, 0);
  }
}

export { ContextWindowManager };
