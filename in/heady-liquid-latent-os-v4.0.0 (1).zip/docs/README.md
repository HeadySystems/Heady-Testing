# Heady™ Documentation Hub v4.0.0

**Author:** Eric Haywood / HeadySystems Inc. — 51 Provisional Patents
**Architecture:** Liquid Latent Operating System in 3D Vector Space

---

## Quick Navigation

| Document | Description |
|----------|-------------|
| [Architecture Overview](architecture/ARCHITECTURE.md) | System topology, layers, data flow |
| [API Reference](api/API_COMPLETE_REFERENCE.md) | All service endpoints, schemas, auth |
| [Deployment Guide](deployment/DEPLOYMENT.md) | Docker, Cloud Run, Cloudflare setup |
| [Service Catalog](services/SERVICE_CATALOG.md) | All 12 services with ports, health, deps |
| [φ-Math Foundation](phi-math/PHI_MATH.md) | Golden ratio constants, formulas, usage |
| [CSL Engine](csl/CSL_ENGINE.md) | Continuous Semantic Logic gates, proofs |
| [Colab Orchestration](colab/COLAB_ORCHESTRATION.md) | 3-runtime GPU coordination |
| [Auth & Security](security/AUTH_SECURITY.md) | OAuth, session, zero-trust, OWASP |
| [Website Portfolio](websites/WEBSITES.md) | 9 ecosystem sites, design system |
| [Error Catalog](errors/ERROR_CATALOG.md) | All error codes by service |
| [ADR Log](adr/) | Architecture Decision Records |
| [Runbooks](runbooks/) | Operational procedures |

---

## System Architecture

```
┌─────────────────────────────────────────────────────┐
│                   Client Layer                       │
│   9 Websites │ Admin Dashboard │ API Consumers       │
├─────────────────────────────────────────────────────┤
│                   Edge Layer                         │
│   Cloudflare Pages │ Workers │ Vectorize             │
├─────────────────────────────────────────────────────┤
│               API Gateway (:3316)                    │
│   Rate Limiting │ Auth │ Routing │ Circuit Breaker   │
├─────────────────────────────────────────────────────┤
│                 Service Mesh                         │
│ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌─────────┐│
│ │Conductor │ │  Vector  │ │   CSL    │ │  Auth   ││
│ │  :3324   │ │  Memory  │ │  Engine  │ │ Session ││
│ │          │ │  :3320   │ │  :3322   │ │  :3338  ││
│ ├──────────┤ ├──────────┤ ├──────────┤ ├─────────┤│
│ │ Search   │ │Analytics │ │ Billing  │ │Notifier ││
│ │  :3326   │ │  :3352   │ │  :3353   │ │  :3345  ││
│ ├──────────┤ ├──────────┤ ├──────────┤ ├─────────┤│
│ │Scheduler │ │Migration │ │  Asset   │ │         ││
│ │  :3363   │ │  :3364   │ │ Pipeline │ │         ││
│ │          │ │          │ │  :3365   │ │         ││
│ └──────────┘ └──────────┘ └──────────┘ └─────────┘│
├─────────────────────────────────────────────────────┤
│              Persistence Layer                       │
│   PostgreSQL + pgvector │ NATS │ Redis │ Consul     │
├─────────────────────────────────────────────────────┤
│               GPU Layer (Colab Pro+)                 │
│   Alpha: Embeddings │ Beta: Inference │ Gamma: Train │
└─────────────────────────────────────────────────────┘
```

---

## φ-Math Foundation

Every numeric constant in Heady derives from φ (1.618...) or Fibonacci:

- **φ** = 1.618033988749895 (golden ratio)
- **ψ** = 1/φ ≈ 0.618 (conjugate)
- **Fibonacci**: 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987
- **CSL Thresholds**: MINIMUM(0.500), LOW(0.691), MEDIUM(0.809), HIGH(0.882), CRITICAL(0.927)
- **No magic numbers. Ever.**

---

## Services at a Glance

| Service | Port | Pool | Role |
|---------|------|------|------|
| API Gateway | 3316 | Hot | Request routing, rate limiting, auth |
| Vector Memory | 3320 | Hot | 384D embedding storage + search |
| CSL Engine | 3322 | Hot | Geometric logic gates |
| Conductor | 3324 | Hot | Pipeline orchestration |
| Search | 3326 | Warm | Full-text + vector hybrid search |
| Auth Session | 3338 | Hot | OAuth 2.1, sessions, tokens |
| Notification | 3345 | Warm | Multi-channel notifications |
| Analytics | 3352 | Cold | Metrics, events, dashboards |
| Billing | 3353 | Warm | Stripe, usage metering |
| Scheduler | 3363 | Cold | Cron, φ-interval scheduling |
| Migration | 3364 | Cold | Schema evolution |
| Asset Pipeline | 3365 | Cold | File processing, CDN upload |

---

## Getting Started

```bash
# Clone the repository
git clone https://github.com/HeadyMe/heady-max.git
cd heady-max

# Environment setup
cp .env.example .env
# Edit .env with your credentials

# Start all services
docker-compose up -d

# Verify health
curl http://localhost:3316/health
```

---

© 2026 Eric Haywood / HeadySystems Inc. — All rights reserved.
51 Provisional Patents pending.
