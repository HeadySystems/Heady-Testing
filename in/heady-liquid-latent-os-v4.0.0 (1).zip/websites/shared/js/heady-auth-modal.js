/**
 * Heady™ Auth Modal v4.0.0
 * Drop-in authentication modal with Sacred Geometry styling
 * Author: Eric Haywood / HeadySystems Inc.
 */

const HeadyAuthModal = (() => {
  'use strict';

  const PHI = 1.618033988749895;
  const PSI = 1 / PHI;

  let modalEl = null;
  let currentMode = 'login';

  function createModal() {
    if (modalEl) return modalEl;

    modalEl = document.createElement('div');
    modalEl.id = 'heady-auth-modal';
    modalEl.innerHTML = `
      <div class="auth-overlay" data-close-modal></div>
      <div class="auth-container">
        <button class="auth-close" data-close-modal aria-label="Close">&times;</button>
        <div class="auth-header">
          <div class="auth-logo">
            <svg viewBox="0 0 40 40" width="40" height="40" fill="none">
              <circle cx="20" cy="20" r="18" stroke="currentColor" stroke-width="1.5" opacity="0.3"/>
              <circle cx="20" cy="20" r="11.13" stroke="currentColor" stroke-width="1.5" opacity="0.5"/>
              <circle cx="20" cy="20" r="6.88" stroke="currentColor" stroke-width="1.5"/>
              <circle cx="20" cy="20" r="3" fill="currentColor"/>
            </svg>
          </div>
          <h2 class="auth-title" data-mode-title>Sign In</h2>
          <p class="auth-subtitle">Access the Heady ecosystem</p>
        </div>

        <form id="login-form" class="auth-form" data-auth-form="login">
          <div class="auth-field">
            <label for="login-email">Email</label>
            <input type="email" id="login-email" name="email" required autocomplete="email" placeholder="you@example.com"/>
          </div>
          <div class="auth-field">
            <label for="login-password">Password</label>
            <input type="password" id="login-password" name="password" required autocomplete="current-password" placeholder="Your password"/>
          </div>
          <div class="auth-error" role="alert"></div>
          <button type="submit" class="auth-submit">Sign In</button>
        </form>

        <form id="signup-form" class="auth-form" data-auth-form="signup" style="display:none">
          <div class="auth-field">
            <label for="signup-name">Full Name</label>
            <input type="text" id="signup-name" name="name" required autocomplete="name" placeholder="Eric Haywood"/>
          </div>
          <div class="auth-field">
            <label for="signup-email">Email</label>
            <input type="email" id="signup-email" name="email" required autocomplete="email" placeholder="you@example.com"/>
          </div>
          <div class="auth-field">
            <label for="signup-password">Password</label>
            <input type="password" id="signup-password" name="password" required autocomplete="new-password" minlength="8" placeholder="Min 8 characters"/>
          </div>
          <div class="auth-error" role="alert"></div>
          <button type="submit" class="auth-submit">Create Account</button>
        </form>

        <div class="auth-divider"><span>or continue with</span></div>

        <div class="auth-oauth">
          <button class="auth-oauth-btn" data-oauth="google">
            <svg viewBox="0 0 24 24" width="20" height="20"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 01-2.2 3.32v2.77h3.57c2.08-1.92 3.27-4.74 3.27-8.1z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Google
          </button>
          <button class="auth-oauth-btn" data-oauth="github">
            <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor"><path d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z"/></svg>
            GitHub
          </button>
        </div>

        <div class="auth-footer">
          <span data-auth-form="login">Don't have an account? <a href="#" data-switch-mode="signup">Sign up</a></span>
          <span data-auth-form="signup" style="display:none">Already have an account? <a href="#" data-switch-mode="login">Sign in</a></span>
        </div>
      </div>
    `;

    // Inject styles
    if (!document.getElementById('heady-auth-styles')) {
      const style = document.createElement('style');
      style.id = 'heady-auth-styles';
      style.textContent = getAuthStyles();
      document.head.appendChild(style);
    }

    document.body.appendChild(modalEl);
    bindEvents();
    return modalEl;
  }

  function bindEvents() {
    // Close buttons
    modalEl.querySelectorAll('[data-close-modal]').forEach(el => {
      el.addEventListener('click', close);
    });

    // Mode switching
    modalEl.querySelectorAll('[data-switch-mode]').forEach(el => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        switchMode(el.dataset.switchMode);
      });
    });

    // OAuth buttons
    modalEl.querySelectorAll('[data-oauth]').forEach(btn => {
      btn.addEventListener('click', () => {
        if (typeof HeadyAuth !== 'undefined') {
          HeadyAuth.oauthLogin(btn.dataset.oauth);
        }
      });
    });

    // Close on Escape
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modalEl.classList.contains('active')) close();
    });

    // Auth events
    if (typeof HeadyAuth !== 'undefined') {
      HeadyAuth.on('auth:login', close);
      HeadyAuth.on('auth:signup', close);
    }
  }

  function switchMode(mode) {
    currentMode = mode;
    const title = modalEl.querySelector('[data-mode-title]');
    title.textContent = mode === 'login' ? 'Sign In' : 'Create Account';

    modalEl.querySelectorAll('[data-auth-form]').forEach(el => {
      const isMatch = el.dataset.authForm === mode;
      el.style.display = isMatch ? '' : 'none';
    });

    // Clear errors
    modalEl.querySelectorAll('.auth-error').forEach(el => el.textContent = '');
  }

  function open(mode) {
    createModal();
    if (mode) switchMode(mode);
    modalEl.classList.add('active');
    document.body.style.overflow = 'hidden';

    // Focus first input
    requestAnimationFrame(() => {
      const input = modalEl.querySelector('.auth-form:not([style*="display:none"]) input');
      if (input) input.focus();
    });
  }

  function close() {
    if (modalEl) {
      modalEl.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  function getAuthStyles() {
    return `
      #heady-auth-modal { display:none; position:fixed; top:0; left:0; width:100%; height:100%; z-index:10000; }
      #heady-auth-modal.active { display:flex; align-items:center; justify-content:center; }
      .auth-overlay { position:absolute; inset:0; background:rgba(0,0,0,0.618); backdrop-filter:blur(8px); }
      .auth-container {
        position:relative; width:min(420px,90vw); max-height:90vh; overflow-y:auto;
        background:rgba(20,20,30,0.95); border:1px solid rgba(255,255,255,0.1);
        border-radius:13px; padding:34px;
        box-shadow: 0 21px 55px rgba(0,0,0,0.5);
        animation: authSlideUp 0.382s cubic-bezier(0.22,1,0.36,1);
      }
      @keyframes authSlideUp {
        from { opacity:0; transform:translateY(21px); }
        to { opacity:1; transform:translateY(0); }
      }
      .auth-close { position:absolute; top:13px; right:13px; background:none; border:none;
        color:rgba(255,255,255,0.5); font-size:24px; cursor:pointer; padding:5px;
        transition:color 0.236s; }
      .auth-close:hover { color:white; }
      .auth-header { text-align:center; margin-bottom:21px; }
      .auth-logo { margin-bottom:13px; color:rgba(92,224,210,0.8); }
      .auth-logo svg { margin:0 auto; display:block; }
      .auth-title { font-size:21px; font-weight:600; margin:0 0 5px; color:white; }
      .auth-subtitle { font-size:13px; color:rgba(255,255,255,0.5); margin:0; }
      .auth-field { margin-bottom:13px; }
      .auth-field label { display:block; font-size:13px; color:rgba(255,255,255,0.7);
        margin-bottom:5px; font-weight:500; }
      .auth-field input {
        width:100%; padding:10px 13px; background:rgba(255,255,255,0.05);
        border:1px solid rgba(255,255,255,0.15); border-radius:8px;
        color:white; font-size:14px; outline:none;
        transition:border-color 0.236s, box-shadow 0.236s;
        box-sizing:border-box;
      }
      .auth-field input:focus { border-color:rgba(92,224,210,0.5);
        box-shadow:0 0 0 3px rgba(92,224,210,0.1); }
      .auth-field input::placeholder { color:rgba(255,255,255,0.25); }
      .auth-error { color:#ff6b6b; font-size:13px; min-height:18px; margin-bottom:8px; }
      .auth-submit {
        width:100%; padding:11px; background:linear-gradient(135deg,#5ce0d2,#3db8ac);
        color:#0a0a14; border:none; border-radius:8px; font-size:14px;
        font-weight:600; cursor:pointer; transition:opacity 0.236s, transform 0.236s;
      }
      .auth-submit:hover { opacity:0.9; transform:translateY(-1px); }
      .auth-submit:disabled { opacity:0.5; cursor:not-allowed; transform:none; }
      .auth-divider { display:flex; align-items:center; gap:13px; margin:21px 0;
        color:rgba(255,255,255,0.3); font-size:12px; }
      .auth-divider::before, .auth-divider::after { content:''; flex:1; height:1px;
        background:rgba(255,255,255,0.1); }
      .auth-oauth { display:grid; grid-template-columns:1fr 1fr; gap:8px; }
      .auth-oauth-btn {
        display:flex; align-items:center; justify-content:center; gap:8px;
        padding:10px; background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.1);
        border-radius:8px; color:white; font-size:13px; cursor:pointer;
        transition:background 0.236s, border-color 0.236s;
      }
      .auth-oauth-btn:hover { background:rgba(255,255,255,0.1); border-color:rgba(255,255,255,0.2); }
      .auth-footer { text-align:center; margin-top:21px; font-size:13px; color:rgba(255,255,255,0.5); }
      .auth-footer a { color:#5ce0d2; text-decoration:none; }
      .auth-footer a:hover { text-decoration:underline; }
    `;
  }

  // Auto-bind any login/signup links
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-auth-open]').forEach(el => {
      el.addEventListener('click', (e) => {
        e.preventDefault();
        open(el.dataset.authOpen || 'login');
      });
    });
  });

  return { open, close, switchMode };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = HeadyAuthModal;
}
