/**
 * Heady™ Authentication Module v4.0.0
 * Wires login/signup/logout to auth-session-server
 * Author: Eric Haywood / HeadySystems Inc.
 * ZERO localStorage for tokens — httpOnly cookies ONLY
 */

const HeadyAuth = (() => {
  'use strict';

  // φ-derived constants
  const PHI = 1.618033988749895;
  const PSI = 1 / PHI;
  const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];

  // Auth service endpoint — env-driven, never localhost
  const AUTH_BASE = window.__HEADY_CONFIG__?.authUrl
    || document.querySelector('meta[name="heady-auth-url"]')?.content
    || '/api/auth';

  // Session check interval: Fibonacci-scaled (34 seconds)
  const SESSION_CHECK_MS = FIB[8] * 1000;

  // φ-backoff for retries
  function phiBackoff(attempt, baseMs) {
    const base = baseMs || 1000;
    const delay = base * Math.pow(PHI, attempt);
    const jitter = 1 + (Math.random() - 0.5) * 2 * Math.pow(PSI, 2);
    return Math.min(delay * jitter, FIB[10] * 1000);
  }

  // State
  let currentUser = null;
  let sessionCheckTimer = null;
  const listeners = new Map();

  function emit(event, data) {
    const handlers = listeners.get(event) || [];
    handlers.forEach(fn => fn(data));
  }

  function on(event, handler) {
    if (!listeners.has(event)) listeners.set(event, []);
    listeners.get(event).push(handler);
  }

  function off(event, handler) {
    const handlers = listeners.get(event) || [];
    listeners.set(event, handlers.filter(fn => fn !== handler));
  }

  // ═══ Core API Calls ═══

  async function apiFetch(path, options) {
    const url = `${AUTH_BASE}${path}`;
    const defaults = {
      credentials: 'include', // httpOnly cookies
      headers: { 'Content-Type': 'application/json' },
    };
    const merged = { ...defaults, ...options };
    if (options?.headers) {
      merged.headers = { ...defaults.headers, ...options.headers };
    }
    const response = await fetch(url, merged);
    if (!response.ok) {
      const body = await response.json().catch(() => ({ error: 'Request failed' }));
      throw new AuthError(body.error || `HTTP ${response.status}`, response.status, body.code);
    }
    return response.json();
  }

  class AuthError extends Error {
    constructor(message, status, code) {
      super(message);
      this.name = 'AuthError';
      this.status = status;
      this.code = code;
    }
  }

  // ═══ Auth Operations ═══

  async function login(email, password) {
    const data = await apiFetch('/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    currentUser = data.user;
    emit('auth:login', currentUser);
    startSessionCheck();
    return currentUser;
  }

  async function signup(email, password, name) {
    const data = await apiFetch('/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, name }),
    });
    currentUser = data.user;
    emit('auth:signup', currentUser);
    startSessionCheck();
    return currentUser;
  }

  async function logout() {
    await apiFetch('/logout', { method: 'POST' });
    currentUser = null;
    stopSessionCheck();
    emit('auth:logout', null);
  }

  async function checkSession() {
    try {
      const data = await apiFetch('/session', { method: 'GET' });
      currentUser = data.user || null;
      emit('auth:session', currentUser);
      return currentUser;
    } catch (err) {
      currentUser = null;
      emit('auth:session', null);
      return null;
    }
  }

  async function refreshToken() {
    try {
      const data = await apiFetch('/refresh', { method: 'POST' });
      currentUser = data.user;
      emit('auth:refresh', currentUser);
      return currentUser;
    } catch (err) {
      currentUser = null;
      emit('auth:expired', null);
      return null;
    }
  }

  // ═══ OAuth Flows ═══

  function oauthLogin(provider) {
    const redirectUri = encodeURIComponent(window.location.origin + '/auth/callback');
    window.location.href = `${AUTH_BASE}/oauth/${provider}?redirect_uri=${redirectUri}`;
  }

  async function handleOAuthCallback() {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const state = params.get('state');
    if (!code) return null;

    const data = await apiFetch('/oauth/callback', {
      method: 'POST',
      body: JSON.stringify({ code, state }),
    });
    currentUser = data.user;
    emit('auth:login', currentUser);
    startSessionCheck();

    // Clean URL
    window.history.replaceState({}, '', window.location.pathname);
    return currentUser;
  }

  // ═══ Session Monitoring ═══

  function startSessionCheck() {
    stopSessionCheck();
    sessionCheckTimer = setInterval(async () => {
      const user = await checkSession();
      if (!user) {
        stopSessionCheck();
        emit('auth:expired', null);
      }
    }, SESSION_CHECK_MS);
  }

  function stopSessionCheck() {
    if (sessionCheckTimer) {
      clearInterval(sessionCheckTimer);
      sessionCheckTimer = null;
    }
  }

  // ═══ UI Binding ═══

  function bindLoginForm(formSelector) {
    const form = document.querySelector(formSelector);
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = form.querySelector('[name="email"]')?.value;
      const password = form.querySelector('[name="password"]')?.value;
      const submitBtn = form.querySelector('[type="submit"]');
      const errorEl = form.querySelector('.auth-error');

      if (submitBtn) submitBtn.disabled = true;
      if (errorEl) errorEl.textContent = '';

      try {
        await login(email, password);
      } catch (err) {
        if (errorEl) errorEl.textContent = err.message;
      } finally {
        if (submitBtn) submitBtn.disabled = false;
      }
    });
  }

  function bindSignupForm(formSelector) {
    const form = document.querySelector(formSelector);
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = form.querySelector('[name="email"]')?.value;
      const password = form.querySelector('[name="password"]')?.value;
      const name = form.querySelector('[name="name"]')?.value;
      const submitBtn = form.querySelector('[type="submit"]');
      const errorEl = form.querySelector('.auth-error');

      if (submitBtn) submitBtn.disabled = true;
      if (errorEl) errorEl.textContent = '';

      try {
        await signup(email, password, name);
      } catch (err) {
        if (errorEl) errorEl.textContent = err.message;
      } finally {
        if (submitBtn) submitBtn.disabled = false;
      }
    });
  }

  function bindLogoutButton(selector) {
    const btn = document.querySelector(selector);
    if (!btn) return;
    btn.addEventListener('click', async (e) => {
      e.preventDefault();
      await logout();
    });
  }

  function updateUI(user) {
    // Toggle visibility based on auth state
    document.querySelectorAll('[data-auth="logged-in"]').forEach(el => {
      el.style.display = user ? '' : 'none';
    });
    document.querySelectorAll('[data-auth="logged-out"]').forEach(el => {
      el.style.display = user ? 'none' : '';
    });
    // Populate user info
    document.querySelectorAll('[data-auth-field="name"]').forEach(el => {
      el.textContent = user?.name || '';
    });
    document.querySelectorAll('[data-auth-field="email"]').forEach(el => {
      el.textContent = user?.email || '';
    });
    document.querySelectorAll('[data-auth-field="avatar"]').forEach(el => {
      if (user?.avatar) el.src = user.avatar;
    });
  }

  // ═══ Initialization ═══

  async function init() {
    // Check for OAuth callback
    if (window.location.pathname === '/auth/callback') {
      await handleOAuthCallback();
      return;
    }

    // Check existing session
    await checkSession();

    // Auto-bind common selectors
    bindLoginForm('#login-form');
    bindSignupForm('#signup-form');
    bindLogoutButton('[data-auth-logout]');

    // Update UI on any auth event
    on('auth:login', updateUI);
    on('auth:signup', updateUI);
    on('auth:logout', updateUI);
    on('auth:session', updateUI);
    on('auth:expired', updateUI);

    // Initial UI state
    updateUI(currentUser);
  }

  // Auto-init on DOMContentLoaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  return {
    login, signup, logout, checkSession, refreshToken,
    oauthLogin, handleOAuthCallback,
    bindLoginForm, bindSignupForm, bindLogoutButton,
    on, off, emit,
    getUser: () => currentUser,
    isAuthenticated: () => currentUser !== null,
    AuthError,
  };
})();

if (typeof module !== 'undefined' && module.exports) {
  module.exports = HeadyAuth;
}
