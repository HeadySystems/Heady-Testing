/**
 * heady-auth-widget.js — Unified Firebase Authentication Widget
 * Embeds in ALL Heady sites. Handles Google OAuth, Email/Password, Anonymous.
 * Cross-site persistence via localStorage JWT.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
(function() {
  const FIREBASE_CONFIG = {
    apiKey: "AIzaSyDg0NQgbHXTJGSp6_8IlP4YcnJfWV4RNTU",
    authDomain: "gen-lang-client-0920560496.firebaseapp.com",
    projectId: "gen-lang-client-0920560496",
    storageBucket: "gen-lang-client-0920560496.firebasestorage.app",
    messagingSenderId: "920560496",
    appId: "1:920560496:web:heady-auth-widget"
  };

  const AUTH_KEY = 'heady_auth_token';
  const USER_KEY = 'heady_user';
  const AUTH_PAGE = 'https://headyme.com/auth.html';

  class HeadyAuthWidget {
    constructor() {
      this.user = null;
      this.listeners = [];
      this.init();
    }

    async init() {
      this.loadCachedUser();
      this.renderWidget();
      this.setupEventListeners();
      try {
        if (window.firebase && firebase.apps.length === 0) {
          firebase.initializeApp(FIREBASE_CONFIG);
        }
        if (window.firebase && firebase.auth) {
          firebase.auth().setPersistence(firebase.auth.Auth.Persistence.LOCAL);
          firebase.auth().onAuthStateChanged((user) => this.handleAuthChange(user));
        }
      } catch (e) {
        console.warn('[HeadyAuth] Firebase not loaded, using cached state');
      }
    }

    loadCachedUser() {
      try {
        const cached = localStorage.getItem(USER_KEY);
        if (cached) this.user = JSON.parse(cached);
      } catch (e) { /* no cached user */ }
    }

    handleAuthChange(firebaseUser) {
      if (firebaseUser) {
        this.user = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
          photoURL: firebaseUser.photoURL,
          provider: firebaseUser.providerData[0]?.providerId || 'anonymous',
        };
        firebaseUser.getIdToken().then(token => {
          localStorage.setItem(AUTH_KEY, token);
          localStorage.setItem(USER_KEY, JSON.stringify(this.user));
        });
      } else {
        this.user = null;
        localStorage.removeItem(AUTH_KEY);
        localStorage.removeItem(USER_KEY);
      }
      this.renderWidget();
      this.emit('heady:auth:changed', this.user);
      if (this.user && window.HeadyAutoContext) {
        window.HeadyAutoContext.indexUserContext(this.user);
      }
    }

    emit(eventName, detail) {
      window.dispatchEvent(new CustomEvent(eventName, { detail }));
      this.listeners.forEach(fn => fn(detail));
    }

    onAuthChange(fn) { this.listeners.push(fn); }

    renderWidget() {
      let widget = document.getElementById('heady-auth-widget');
      if (!widget) {
        widget = document.createElement('div');
        widget.id = 'heady-auth-widget';
        widget.style.cssText = `
          position:fixed; top:13px; right:21px; z-index:10000;
          display:flex; align-items:center; gap:8px;
          font-family:'Inter',system-ui,sans-serif; font-size:0.875rem;
        `;
        document.body.appendChild(widget);
      }
      if (this.user) {
        const initials = (this.user.displayName || 'U').split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
        widget.innerHTML = `
          <div style="display:flex;align-items:center;gap:8px;padding:5px 13px;
            background:rgba(255,255,255,0.05);backdrop-filter:blur(20px);
            border:1px solid rgba(255,255,255,0.08);border-radius:34px;cursor:pointer;"
            id="heady-auth-profile">
            ${this.user.photoURL
              ? `<img src="${this.user.photoURL}" style="width:28px;height:28px;border-radius:50%;border:1px solid rgba(255,255,255,0.15);" alt="avatar">`
              : `<div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,#00d4aa,#8b5cf6);display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:600;color:#fff;">${initials}</div>`
            }
            <span style="color:#e8e8f0;font-weight:500;">${this.user.displayName}</span>
          </div>
        `;
        widget.querySelector('#heady-auth-profile').addEventListener('click', () => this.showProfileMenu());
      } else {
        widget.innerHTML = `
          <button id="heady-auth-signin" style="
            padding:8px 21px;background:linear-gradient(135deg,rgba(0,212,170,0.15),rgba(139,92,246,0.15));
            border:1px solid rgba(0,212,170,0.3);border-radius:34px;color:#00d4aa;
            font-size:0.875rem;font-weight:600;cursor:pointer;backdrop-filter:blur(20px);
            transition:all 0.3s cubic-bezier(0.618,0,0.382,1);"
            onmouseover="this.style.background='linear-gradient(135deg,rgba(0,212,170,0.25),rgba(139,92,246,0.25))'"
            onmouseout="this.style.background='linear-gradient(135deg,rgba(0,212,170,0.15),rgba(139,92,246,0.15))'">
            Sign In
          </button>
        `;
        widget.querySelector('#heady-auth-signin').addEventListener('click', () => this.signIn());
      }
    }

    signIn() {
      const currentUrl = encodeURIComponent(window.location.href);
      window.location.href = `${AUTH_PAGE}?redirect=${currentUrl}`;
    }

    async signOut() {
      try {
        if (window.firebase && firebase.auth) await firebase.auth().signOut();
      } catch (e) { /* continue */ }
      this.user = null;
      localStorage.removeItem(AUTH_KEY);
      localStorage.removeItem(USER_KEY);
      this.renderWidget();
      this.emit('heady:auth:changed', null);
      this.hideProfileMenu();
    }

    showProfileMenu() {
      let menu = document.getElementById('heady-auth-menu');
      if (menu) { menu.remove(); return; }
      menu = document.createElement('div');
      menu.id = 'heady-auth-menu';
      menu.style.cssText = `
        position:fixed; top:55px; right:21px; z-index:10001;
        background:rgba(18,18,26,0.95); backdrop-filter:blur(20px);
        border:1px solid rgba(255,255,255,0.08); border-radius:13px;
        padding:13px; min-width:200px;
      `;
      menu.innerHTML = `
        <div style="padding:8px 5px;border-bottom:1px solid rgba(255,255,255,0.06);margin-bottom:8px;">
          <div style="color:#e8e8f0;font-weight:600;font-size:0.875rem;">${this.user?.displayName || 'User'}</div>
          <div style="color:#9898a8;font-size:0.75rem;margin-top:3px;">${this.user?.email || ''}</div>
        </div>
        <button id="heady-auth-signout" style="
          width:100%;padding:8px;background:rgba(255,255,255,0.05);border:none;
          border-radius:8px;color:#e8e8f0;font-size:0.813rem;cursor:pointer;text-align:left;
          transition:background 0.2s;"
          onmouseover="this.style.background='rgba(255,255,255,0.1)'"
          onmouseout="this.style.background='rgba(255,255,255,0.05)'">
          Sign Out
        </button>
      `;
      document.body.appendChild(menu);
      menu.querySelector('#heady-auth-signout').addEventListener('click', () => this.signOut());
      setTimeout(() => {
        const close = (e) => {
          if (!menu.contains(e.target) && e.target.id !== 'heady-auth-profile') {
            menu.remove(); document.removeEventListener('click', close);
          }
        };
        document.addEventListener('click', close);
      }, 100);
    }

    hideProfileMenu() {
      const menu = document.getElementById('heady-auth-menu');
      if (menu) menu.remove();
    }

    getToken() { return localStorage.getItem(AUTH_KEY); }
    getUser() { return this.user; }
    isAuthenticated() { return !!this.user; }
  }

  window.HeadyAuth = new HeadyAuthWidget();
})();
