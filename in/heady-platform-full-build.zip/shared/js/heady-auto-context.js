/**
 * heady-auto-context.js — HeadyAutoContext Bridge (Browser Edition)
 * Central nervous system injected into every page.
 * Continuously monitors page state, indexes content into vector memory,
 * and enriches every AI interaction with optimal context.
 * CSL relevance gates: 0.382 include, 0.618 boost, 0.718 inject.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
(function() {
  const PHI = (1 + Math.sqrt(5)) / 2;
  const PSI = 1 / PHI;
  const PSI2 = PSI * PSI;
  const VECTOR_DIM = 384;
  const CSL_GATES = { include: PSI2, boost: PSI, inject: PSI + 0.1 };
  const API_BASE = 'https://api.headysystems.com';

  class HeadyAutoContext {
    constructor() {
      this.contextCache = new Map();
      this.pageContext = null;
      this.userContext = null;
      this.siteId = this.detectSiteId();
      this.sessionId = this.generateSessionId();
      this.enrichmentQueue = [];
      this.init();
    }

    detectSiteId() {
      const host = window.location.hostname;
      const siteMap = {
        'headyme.com': 'headyme', 'www.headyme.com': 'headyme',
        'headysystems.com': 'headysystems', 'www.headysystems.com': 'headysystems',
        'heady-ai.com': 'heady-ai', 'www.heady-ai.com': 'heady-ai',
        'headyos.com': 'headyos', 'www.headyos.com': 'headyos',
        'headyconnection.org': 'headyconnection-org', 'www.headyconnection.org': 'headyconnection-org',
        'headyconnection.com': 'headyconnection-com', 'www.headyconnection.com': 'headyconnection-com',
        'headyex.com': 'headyex', 'www.headyex.com': 'headyex',
        'headyfinance.com': 'headyfinance', 'www.headyfinance.com': 'headyfinance',
        'admin.headysystems.com': 'admin',
      };
      return siteMap[host] || 'unknown';
    }

    generateSessionId() {
      return 'hctx_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    }

    async init() {
      this.pageContext = this.extractPageContext();
      this.indexPageContent();
      this.observeMutations();
      this.setupEventBridge();
      window.addEventListener('heady:auth:changed', (e) => {
        if (e.detail) this.indexUserContext(e.detail);
      });
      console.log(`[HeadyAutoContext] Initialized for ${this.siteId} | Session: ${this.sessionId}`);
    }

    extractPageContext() {
      const meta = {};
      document.querySelectorAll('meta').forEach(m => {
        const name = m.getAttribute('name') || m.getAttribute('property');
        if (name) meta[name] = m.getAttribute('content');
      });
      return {
        siteId: this.siteId,
        url: window.location.href,
        path: window.location.pathname,
        title: document.title,
        description: meta.description || '',
        headings: Array.from(document.querySelectorAll('h1,h2,h3')).map(h => h.textContent.trim()).slice(0, 21),
        meta,
        timestamp: Date.now(),
      };
    }

    async indexPageContent() {
      const content = this.extractTextContent();
      const context = {
        type: 'page_content',
        siteId: this.siteId,
        url: window.location.href,
        title: document.title,
        content: content.slice(0, 8000),
        headings: this.pageContext.headings,
        wordCount: content.split(/\s+/).length,
        timestamp: Date.now(),
      };
      this.contextCache.set('page:' + window.location.pathname, context);
      this.enqueueEnrichment(context);
    }

    extractTextContent() {
      const clone = document.body.cloneNode(true);
      clone.querySelectorAll('script,style,nav,footer,svg,canvas').forEach(el => el.remove());
      return clone.textContent.replace(/\s+/g, ' ').trim();
    }

    async indexUserContext(user) {
      this.userContext = {
        type: 'user_context',
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        provider: user.provider,
        siteId: this.siteId,
        sessionId: this.sessionId,
        timestamp: Date.now(),
      };
      this.contextCache.set('user:' + user.uid, this.userContext);
      this.enqueueEnrichment(this.userContext);
    }

    enqueueEnrichment(context) {
      this.enrichmentQueue.push(context);
      if (this.enrichmentQueue.length === 1) {
        setTimeout(() => this.flushEnrichmentQueue(), 1618);
      }
    }

    async flushEnrichmentQueue() {
      const batch = this.enrichmentQueue.splice(0, 13);
      if (batch.length === 0) return;
      try {
        const token = localStorage.getItem('heady_auth_token');
        await fetch(`${API_BASE}/v1/context/enrich`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({
            sessionId: this.sessionId,
            siteId: this.siteId,
            contexts: batch,
          }),
        });
      } catch (e) {
        console.warn('[HeadyAutoContext] Enrichment flush failed, will retry');
        this.enrichmentQueue.unshift(...batch);
      }
      if (this.enrichmentQueue.length > 0) {
        setTimeout(() => this.flushEnrichmentQueue(), 2618);
      }
    }

    observeMutations() {
      if (!window.MutationObserver) return;
      const observer = new MutationObserver((mutations) => {
        let hasContentChange = false;
        mutations.forEach(m => {
          if (m.type === 'childList' && m.addedNodes.length > 0) hasContentChange = true;
        });
        if (hasContentChange) {
          clearTimeout(this._reindexTimer);
          this._reindexTimer = setTimeout(() => this.indexPageContent(), 4236);
        }
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }

    setupEventBridge() {
      window.addEventListener('heady:context:request', (e) => {
        const response = {
          pageContext: this.pageContext,
          userContext: this.userContext,
          siteId: this.siteId,
          sessionId: this.sessionId,
          cacheSize: this.contextCache.size,
        };
        window.dispatchEvent(new CustomEvent('heady:context:response', { detail: response }));
      });
    }

    async search(query, limit) {
      try {
        const token = localStorage.getItem('heady_auth_token');
        const res = await fetch(`${API_BASE}/v1/context/search`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
          },
          body: JSON.stringify({ query, limit: limit || 5, siteId: this.siteId }),
        });
        return await res.json();
      } catch (e) {
        console.warn('[HeadyAutoContext] Search failed:', e.message);
        return { results: [] };
      }
    }

    getContext() {
      return {
        page: this.pageContext,
        user: this.userContext,
        site: this.siteId,
        session: this.sessionId,
        cached: this.contextCache.size,
      };
    }

    getPageWordCount() {
      return this.extractTextContent().split(/\s+/).length;
    }
  }

  window.HeadyAutoContext = new HeadyAutoContext();
})();
