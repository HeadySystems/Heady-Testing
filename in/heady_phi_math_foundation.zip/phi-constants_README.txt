Heady Phi-Math Foundation bundle

Files:
- phi-constants.js

Validation:
- node -c phi-constants.js passed

Notes:
- Canonical phi/golden-ratio and Fibonacci-derived constants and utility functions for the Heady ecosystem.
