# Heady Ecosystem Map v2 — Complete Reference

> © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
> Updated: 2026-03-11 — Reflects current GitHub state + 2026 model research

---

## Domain Map

| Domain | Role | Stack | Repo |
|--------|------|-------|------|
| headyme.com | Command center — main orchestration dashboard | Next.js + Cloudflare Pages | HeadyMe/headyme-core |
| headysystems.com | Core architecture engine — technical docs & API reference | Next.js + Cloud Run | HeadyMe/headysystems-core |
| headyconnection.org | 501(c)(3) nonprofit — community programs, grants, equity | Drupal 11 | HeadyMe/headyconnection-core |
| headybuddy.org | AI companion experience — conversational interface | Next.js + WebSocket | HeadyMe/headybuddy-core |
| headymcp.com | MCP layer — tool routing, transport, zero-trust gateway | Cloudflare Workers | HeadyMe/headymcp-core |
| headyio.com | Developer platform — SDKs, APIs, integration guides | Next.js + Cloud Run | HeadyMe/headyio-core |
| headybot.com | Automation and agents — bot management, swarm dashboard | Next.js + Cloud Run | HeadyMe/headybot-core |
| headyapi.com | Public intelligence interface — API gateway, rate limiting | Cloudflare Workers + Cloud Run | HeadyMe/headyapi-core |
| headyai.com | Intelligence routing hub — model selection, liquid gateway | Cloudflare Workers | HeadyMe/headyos-core |

---

## GitHub Repository Map (Current State)

### HeadyMe Account (13 repos)

| Repo | Role | Last Push |
|------|------|-----------|
| Heady-Testing | Full-stack integration repo (v3.0.0) — THE active monorepo | 2026-03-10 |
| headyos-core | Latent OS projection target | 2026-03-10 |
| headyme-core | Command center projection | 2026-03-10 |
| headyconnection-core | Nonprofit projection | 2026-03-10 |
| headysystems-core | Infrastructure projection | 2026-03-07 |
| headybuddy-core | AI companion projection | 2026-03-07 |
| headymcp-core | MCP gateway projection (31 tools) | 2026-03-07 |
| headyapi-core | API gateway projection | 2026-03-07 |
| headybot-core | Bot framework projection | 2026-03-07 |
| headyio-core | Developer SDK projection | 2026-03-07 |
| heady-docs | Documentation hub (patents, API, strategic) | 2026-03-10 |
| headysystems-production | Static deploy target | 2026-03-07 |
| headymcp-production | Static deploy target | 2026-03-07 |

### HeadySystems Org (7 repos)

| Repo | Role | Last Push |
|------|------|-----------|
| sandbox | Experimental features | 2026-03-10 |
| Heady | Sacred Geometry Architecture v3.0.0 | 2026-02-19 |
| Heady-pre-production | Upstream source (v2.0.0) | 2026-02-06 |
| ai-workflow-engine | Cloudflare Workers + Render orchestration | 2026-01-31 |
| sandbox-pre-production | File dumps + checkpoints | 2026-02-04 |
| headybuddy-web | HeadyBuddy web interface | 2026-02-20 |
| main | Main coordination repo | 2026-01-26 |

### Active Monorepo: HeadyMe/Heady-Testing

```
src/
├── agents/             ← Agent definitions (claude-code-agent, pipeline-handlers)
├── bees/               ← 11 files: bee-factory, swarm-coordinator, trading-bee-csl
├── bees-memory/        ← Memory layer for bees
├── colab/              ← Colab gateway integration
├── core/               ← Core modules
├── heady_project/      ← Python services (api, conductor, economy, nlp, audit)
├── intelligence/       ← Intelligence layer
├── latent/             ← Latent OS layer
├── mcp/                ← MCP integrations
├── memory/             ← Memory subsystem
├── monitoring/         ← Monitoring
├── orchestration/      ← Orchestration layer
├── pipeline/           ← pipeline-core.js + pipeline-stages.js
├── security/           ← Security middleware
├── services/           ← Service definitions
├── trading/            ← Trading bee support
└── (40+ total subdirectories)

Key root files:
├── heady-manager.js    ← MCP server + HTTP orchestration
├── docker-compose.yml  ← Local dev orchestration
├── mcp_config.json     ← MCP Docker stack (filesystem, postgres, memory, fetch)
├── .env.example        ← 28+ env vars (feature flags, endpoints, auth)
├── package.json        ← v3.0.0, Express 5.x, @anthropic-ai/sdk, pg, pino
└── render.yaml         ← Render deployment config
```

---

## Node Registry — Sacred Geometry Topology

### Center (HeadySoul)

| Node | Role | Pool | Class |
|------|------|------|-------|
| HeadySoul | Awareness layer, values arbiter, coherence guardian | Governance | SoulNode |

### Inner Ring (Processing Core)

| Node | Role | Pool | Class |
|------|------|------|-------|
| HeadyBrains | Computational pre-processor, context gathering | Hot | BrainsNode |
| HeadyConductor | Central orchestration, task classification & routing | Hot | ConductorNode |
| HeadyVinci | Session planner, topology maintainer, multi-step planning | Hot | VinciNode |

### Middle Ring (Execution Layer)

| Node | Role | Pool | Class |
|------|------|------|-------|
| JULES | Code generation, implementation | Hot | JulesNode |
| BUILDER | Full-stack system building | Hot | BuilderNode |
| OBSERVER | Code review, monitoring, quality assessment | Hot | ObserverNode |
| MURPHY | Security analysis, vulnerability detection | Hot | MurphyNode |
| ATLAS | Architecture documentation, system mapping | Warm | AtlasNode |
| PYTHIA | Predictive analysis, forecasting | Warm | PythiaNode |

### Outer Ring (Specialized Capabilities)

| Node | Role | Pool | Class |
|------|------|------|-------|
| BRIDGE | Translation, cross-domain communication | Warm | BridgeNode |
| MUSE | Creative content generation, UX design | Warm | MuseNode |
| SENTINEL | Real-time security monitoring, threat detection | Warm | SentinelNode |
| NOVA | Innovation, experimental approaches | Warm | NovaNode |
| JANITOR | Code cleanup, technical debt reduction | Cold | JanitorNode |
| SOPHIA | Research, wisdom synthesis, deep analysis | Warm | SophiaNode |
| CIPHER | Encryption, PQC, cryptographic operations | Warm | CipherNode |
| LENS | System observation, detailed inspection | Warm | LensNode |

### Governance Shell (Quality & Oversight)

| Node | Role | Pool | Class |
|------|------|------|-------|
| HeadyCheck | Output validation, quality gate | Governance | CheckNode |
| HeadyAssure | Deployment certification, assurance gate | Governance | AssureNode |
| HeadyAware | Ethics monitoring, bias detection | Governance | AwareNode |
| HeadyPatterns | Pattern detection, drift classification, learning | Cold | PatternsNode |
| HeadyMC | Monte Carlo simulation for optimization | Cold | MCNode |
| HeadyRisks | Risk assessment, security audit | Governance | RisksNode |

### Memory & Intelligence Nodes

| Node | Role | Pool | Class |
|------|------|------|-------|
| HeadyMemory | Vector memory read/write (384D, RAM-first) | Hot | MemoryNode |
| HeadyEmbed | Embedding generation (multi-provider routing) | Hot | EmbedNode |
| HeadyAutobiographer | Event logging, narrative construction | Cold | AutobiographerNode |
| HeadyResearch | Deep research with web citations | Warm | ResearchNode |
| HeadyCodex | Code documentation generation | Warm | CodexNode |
| HeadyMaid | Cleanup scheduling, cache management | Cold | MaidNode |
| HeadyMaintenance | Backup, update, restore operations | Cold | MaintenanceNode |

**Total: 34 nodes across 5 topology rings**

---

## Bee Registry — 33 HeadyBee Types

Every bee follows the BaseHeadyBee lifecycle: `spawn() → execute() → report() → retire()`

| Bee Type | Module | Role | Pool |
|----------|--------|------|------|
| agents-bee | src/bees/agents-bee.js | Agent creation and routing | Hot |
| auth-provider-bee | src/bees/auth-provider-bee.js | Authentication provider orchestration | Hot |
| auto-success-bee | src/bees/auto-success-bee.js | Automated success pipeline execution | Hot |
| brain-bee | src/bees/brain-bee.js | LLM provider routing and model selection | Hot |
| config-bee | src/bees/config-bee.js | Configuration management and validation | Hot |
| connectors-bee | src/bees/connectors-bee.js | External service connector management | Hot |
| creative-bee | src/bees/creative-bee.js | Creative content generation | Warm |
| deployment-bee | src/bees/deployment-bee.js | Cloud deployment automation | Hot |
| device-provisioner-bee | src/bees/device-provisioner-bee.js | Device onboarding and provisioning | Warm |
| documentation-bee | src/bees/documentation-bee.js | Auto-documentation generation | Warm |
| engines-bee | src/bees/engines-bee.js | Engine orchestration and lifecycle | Warm |
| governance-bee | src/bees/governance-bee.js | Policy enforcement and compliance | Governance |
| health-bee | src/bees/health-bee.js | Health probe execution and reporting | Hot |
| intelligence-bee | src/bees/intelligence-bee.js | Intelligence gathering and analysis | Warm |
| lifecycle-bee | src/bees/lifecycle-bee.js | Service lifecycle management | Warm |
| mcp-bee | src/bees/mcp-bee.js | MCP protocol tool execution | Hot |
| memory-bee | src/bees/memory-bee.js | Memory operations (store, retrieve, embed) | Hot |
| middleware-bee | src/bees/middleware-bee.js | Middleware chain management | Warm |
| midi-bee | src/bees/midi-bee.js | MIDI event processing | Cold |
| ops-bee | src/bees/ops-bee.js | Operations automation | Warm |
| orchestration-bee | src/bees/orchestration-bee.js | Multi-bee orchestration coordination | Hot |
| pipeline-bee | src/bees/pipeline-bee.js | Pipeline stage execution | Hot |
| providers-bee | src/bees/providers-bee.js | Provider health and failover | Warm |
| refactor-bee | src/bees/refactor-bee.js | Code refactoring automation | Warm |
| resilience-bee | src/bees/resilience-bee.js | Resilience pattern enforcement | Warm |
| routes-bee | src/bees/routes-bee.js | API route management | Warm |
| security-bee | src/bees/security-bee.js | Security scanning and enforcement | Governance |
| services-bee | src/bees/services-bee.js | Service catalog management | Warm |
| sync-projection-bee | src/bees/sync-projection-bee.js | Repo projection synchronization | Cold |
| telemetry-bee | src/bees/telemetry-bee.js | Telemetry collection and export | Warm |
| trading-bee | src/bees/trading-bee.js | Financial trading operations | Warm |
| vector-ops-bee | src/bees/vector-ops-bee.js | Vector space operations | Hot |
| vector-template-bee | src/bees/vector-template-bee.js | Vector template management | Warm |

---

## Conductor Routing Matrix

| Task Type | Primary Node | Fallback 1 | Fallback 2 | Pool |
|-----------|-------------|------------|------------|------|
| Code Generation | JULES | BUILDER | Groq (edge) | Hot |
| Code Review | OBSERVER | Gemini Pro | Claude Sonnet | Hot |
| Security Audit | MURPHY | CIPHER | HeadyRisks | Hot |
| Architecture | ATLAS/PYTHIA | HeadyVinci | Claude Sonnet | Hot |
| Research | SOPHIA | HeadyResearch | Perplexity Sonar | Warm |
| Documentation | HeadyCodex | ATLAS | GPT-4o | Warm |
| Quick Tasks | Groq (edge) | Phi-4-mini | Gemini Flash | Hot |
| Creative | MUSE | NOVA | Claude Opus | Warm |
| Cleanup | JANITOR | HeadyMaid | HeadyMaintenance | Cold |
| Analytics | HeadyPatterns | HeadyMC | DuckDB local | Cold |
| Embeddings | Cloudflare Edge | Nomic v2 MoE | BAAI/bge-m3 | Hot |

### LLM Provider Routing (Updated March 2026)

```
Task Type        → Primary                    → Fallback 1              → Fallback 2
──────────────────────────────────────────────────────────────────────────────────────
Code Generation  → Qwen2.5-Coder-32B (R2)    → Claude Sonnet           → GPT-4o
Deep Reasoning   → DeepSeek-R1-Distill-32B   → Claude Opus             → GPT-4o
Multimodal       → Mistral-Small-3.1-24B     → GPT-4o                  → Gemini Pro
Quick Tasks      → Phi-4-mini (R2)           → Groq Llama (edge)       → Gemini Flash
General          → Llama-3.3-70B-INT4 (R2)   → Claude Sonnet           → GPT-4o
Research         → Perplexity Sonar Pro       → Claude Sonnet           → GPT-4o
Embeddings       → Qwen3-Embedding-8B (R1)   → nomic-v2-moe (R1/edge) → BAAI/bge-m3
```

---

## Resource Pool Allocation (Fibonacci Ratios)

| Pool | % Resources | Fibonacci Basis | Timeout | Use For |
|------|------------|----------------|---------|---------|
| Hot | 34% | fib(9)/Σ | < 30s | User-facing, latency-critical |
| Warm | 21% | fib(8)/Σ | < 5 min | Background processing |
| Cold | 13% | fib(7)/Σ | < 30 min | Batch, analytics, ingestion |
| Reserve | 8% | fib(6)/Σ | — | Burst capacity for traffic spikes |
| Governance | 5% | fib(5)/Σ | — | HeadyCheck, HeadyAssure, HeadyAware |

---

## Infrastructure Topology

```
                    ┌─────────────────────────────────┐
                    │         CLOUDFLARE EDGE          │
                    │  Workers │ Pages │ KV │ Vectorize│
                    │  Durable Objects │ Workers AI    │
                    └─────────────┬───────────────────┘
                                  │
                    ┌─────────────┴───────────────────┐
                    │        LIQUID GATEWAY            │
                    │  Auth │ Routing │ Cache │ Stream │
                    └─────────────┬───────────────────┘
                                  │
              ┌───────────────────┼───────────────────┐
              │                   │                   │
    ┌─────────┴─────────┐ ┌──────┴──────┐ ┌─────────┴─────────┐
    │   CLOUD RUN        │ │  FIREBASE   │ │    COLAB PRO+     │
    │   (Origin)         │ │  Auth + DB  │ │  3 GPU Runtimes   │
    │   HeadyManager     │ │  Firestore  │ │  R1: Vector Ops   │
    │   HCFullPipeline   │ │  Storage    │ │  R2: LLM Inf.     │
    └─────────┬─────────┘ └──────┬──────┘ │  R3: Training      │
              │                   │        └─────────┬─────────┘
              └───────────────────┼───────────────────┘
                                  │
                    ┌─────────────┴───────────────────┐
                    │     POSTGRESQL + PGVECTOR        │
                    │  Source of truth │ HNSW indexes  │
                    │  Graph RAG │ BM25 │ Audit logs   │
                    └─────────────────────────────────┘
```

### 3 Colab Pro+ Runtimes (Latent Space Compute)

| Runtime | Role | GPU | Port | Tunnel | Models (2026) |
|---------|------|-----|------|--------|---------------|
| R1 | Vector Memory & Embeddings | A100/V100 | 3301 | vector.headyos.com | Qwen3-Embedding-8B, nomic-v2-moe, bge-m3 |
| R2 | LLM Inference & Agents | A100 80GB | 3302 | llm.headyos.com | Qwen2.5-Coder-32B, DeepSeek-R1-32B, Mistral-Small-3.1-24B |
| R3 | Training & Analytics | TPU v2-8 | 3303 | train.headyos.com | Gemma-3-12B, Qwen2.5-7B, bge-m3 (finetune) |

### Edge-Origin Routing (Phi-Scored Complexity)

| Complexity Score | Route | Examples |
|-----------------|-------|---------|
| < ψ² (0.382) | Edge-only | Simple lookups, embeddings, classification |
| ψ² – ψ (0.382–0.618) | Edge-preferred | Moderate queries with edge fallback |
| > ψ (0.618) | Origin-required | Complex reasoning, multi-step, code gen |

---

## HCFullPipeline (HCFP) — 8-Stage Sequence

```
1. Context Assembly    → HeadyBrains gathers all relevant context
2. Intent Classification → HeadyConductor determines task type + domain
3. Node Selection      → CSL-scored capability routing picks optimal nodes
4. Execution           → Parallel or sequential node activation
5. Quality Gate        → HeadyCheck validates output
6. Assurance Gate      → HeadyAssure certifies for deployment
7. Pattern Capture     → HeadyPatterns logs the workflow for learning
8. Story Update        → HeadyAutobiographer records the narrative
```

---

## Self-Healing Cycle

```
1. Monitor  → Continuous embedding comparison (cosine similarity)
2. Detect   → Semantic drift when similarity < 0.809 (MEDIUM threshold)
3. Alert    → HeadySoul notified of coherence violation
4. Diagnose → HeadyAnalyze + HeadyPatterns identify root cause
5. Heal     → HeadyMaintenance + HeadyMaid apply corrective action
6. Verify   → HeadyCheck + HeadyAssure confirm restoration
7. Learn    → HeadyPatterns + HeadyMC record for future prevention
```

---

## 3 Unbreakable Laws

Every code mutation must satisfy:

1. **Structural Integrity**: Code compiles, passes type checks, respects module boundaries
2. **Semantic Coherence**: The change's embedding stays within tolerance of the intended design
3. **Mission Alignment**: The change serves HeadyConnection's mission (community, equity, empowerment)

---

## Phi-Math Quick Reference

| Constant | Value | Use |
|----------|-------|-----|
| φ (PHI) | 1.618 | Scaling ratio, typography, layout |
| ψ (PSI) | 0.618 | Conjugate, weights, thresholds |
| φ² | 2.618 | Token budget scaling |
| φ³ | 4.236 | Timing multipliers |
| fib(5) | 5 | Circuit breaker threshold |
| fib(6) | 8 | Batch sizes, max concurrent |
| fib(7) | 13 | Small limits, trial days |
| fib(8) | 21 | HNSW m, rerankTopK |
| fib(9) | 34 | Sliding windows |
| fib(10) | 55 | Max entities |
| fib(11) | 89 | efSearch, retention days |
| fib(12) | 144 | ef_construction |
| fib(13) | 233 | Queue depth |
| fib(16) | 987 | Cache sizes |
| fib(20) | 6765 | Large LRU caches |

---

*This ecosystem map is the canonical reference for all Heady development.*
*Φ ≈ 1.618 · Sacred Geometry v4.0 · Alive Software Architecture · 60+ Provisional Patents*
