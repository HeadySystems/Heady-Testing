/**
 * HeadyConductor — Production-Grade Bee Swarm Integration
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Central orchestration module that unifies BeeFactory, SwarmIntelligence,
 * HCFullPipeline, ArenaMode, and ResourcePoolManager under a single
 * conductor. All constants derive from phi/fibonacci — zero magic numbers.
 *
 * @module conductor-swarm
 * @version 4.0.0
 */

'use strict';

const {
  PHI, PSI, PHI2, PHI3, FIB, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  RESOURCE_WEIGHTS,
  phiFusionWeights, phiPriorityScore, phiBackoff, phiAdaptiveInterval,
  cosineSimilarity, cslGate, cslCONSENSUS, cslOR,
  SIZING, POOL_SIZES,
} = require('./phi-constants');

// ═══════════════════════════════════════════════════════════════
// STRUCTURED LOGGER (mirrors liquid-nodes pattern)
// ═══════════════════════════════════════════════════════════════

/**
 * Create a structured JSON logger for a named service.
 * @param {string} service - Service identifier
 * @returns {{ info: Function, warn: Function, error: Function, debug: Function }}
 */
function createLogger(service) {
  const _log = (level, data, msg) => {
    const entry = {
      timestamp: new Date().toISOString(),
      level,
      service,
      correlationId: data?.correlationId || null,
      msg: msg || data?.message || '',
      ...data,
    };
    delete entry.message;
    entry.msg = msg || data?.msg || '';
    const out = level === 'error' ? process.stderr : process.stdout;
    out.write(JSON.stringify(entry) + '\n');
  };
  return {
    info:  (data, msg) => _log('info', data, msg),
    warn:  (data, msg) => _log('warn', data, msg),
    error: (data, msg) => _log('error', data, msg),
    debug: (data, msg) => _log('debug', data, msg),
  };
}

// ═══════════════════════════════════════════════════════════════
// UNIQUE ID GENERATION
// ═══════════════════════════════════════════════════════════════

let _idCounter = 0;

/**
 * Generate a unique identifier with a prefix.
 * @param {string} [prefix='id'] - Identifier prefix
 * @returns {string} Unique identifier string
 */
function uniqueId(prefix = 'id') {
  _idCounter++;
  return `${prefix}-${Date.now().toString(36)}-${_idCounter.toString(36)}`;
}

// ═══════════════════════════════════════════════════════════════
// BEE TEMPLATE REGISTRY — All 33 Bee Type Configurations
// ═══════════════════════════════════════════════════════════════

/**
 * All 33 bee type names as defined in the Heady ecosystem bee registry.
 * @type {string[]}
 */
const BEE_TYPE_NAMES = [
  'agents-bee', 'auth-provider-bee', 'auto-success-bee', 'brain-bee',
  'config-bee', 'connectors-bee', 'creative-bee', 'deployment-bee',
  'device-provisioner-bee', 'documentation-bee', 'engines-bee', 'governance-bee',
  'health-bee', 'intelligence-bee', 'lifecycle-bee', 'mcp-bee',
  'memory-bee', 'middleware-bee', 'midi-bee', 'ops-bee',
  'orchestration-bee', 'pipeline-bee', 'providers-bee', 'refactor-bee',
  'resilience-bee', 'routes-bee', 'security-bee', 'services-bee',
  'sync-projection-bee', 'telemetry-bee', 'trading-bee', 'vector-ops-bee',
  'vector-template-bee',
];

/**
 * Derive a pool assignment from the bee index using phi-weighted distribution.
 * @param {number} index - Bee template index (0-32)
 * @returns {string} Pool name: hot | warm | cold | reserve | governance
 */
function poolFromIndex(index) {
  const pools = ['hot', 'warm', 'cold', 'reserve', 'governance'];
  const cuts = [
    Math.round(BEE_TYPE_NAMES.length * RESOURCE_WEIGHTS.hot),
    Math.round(BEE_TYPE_NAMES.length * (RESOURCE_WEIGHTS.hot + RESOURCE_WEIGHTS.warm)),
    Math.round(BEE_TYPE_NAMES.length * (RESOURCE_WEIGHTS.hot + RESOURCE_WEIGHTS.warm + RESOURCE_WEIGHTS.cold)),
    Math.round(BEE_TYPE_NAMES.length * (RESOURCE_WEIGHTS.hot + RESOURCE_WEIGHTS.warm + RESOURCE_WEIGHTS.cold + RESOURCE_WEIGHTS.reserve)),
  ];
  for (let i = 0; i < cuts.length; i++) {
    if (index < cuts[i]) return pools[i];
  }
  return pools[4];
}

/**
 * Build the default template for a single bee type.
 * @param {string} name - Bee type name
 * @param {number} index - Index in the bee registry
 * @returns {Object} Bee template configuration
 */
function buildDefaultTemplate(name, index) {
  return {
    name,
    modulePath: `./bees/${name}`,
    capabilities: [name.replace(/-bee$/, '')],
    pool: poolFromIndex(index),
    maxInstances: fib(5),
    version: '1.0.0',
    performanceMetrics: { avgLatencyMs: 0, taskCount: 0, errorRate: 0 },
  };
}

/**
 * BeeTemplateRegistry — Stores and manages all 33 bee type configurations.
 * Supports version control, scenario-based selection, and auto-tuning.
 */
class BeeTemplateRegistry {
  constructor() {
    /** @type {Map<string, Object>} */
    this._templates = new Map();
    this._logger = createLogger('BeeTemplateRegistry');

    BEE_TYPE_NAMES.forEach((name, i) => {
      this._templates.set(name, buildDefaultTemplate(name, i));
    });
    this._logger.info({ count: this._templates.size }, 'Registry initialized with default templates');
  }

  /**
   * Retrieve a bee template by type name.
   * @param {string} beeType - Bee type identifier
   * @returns {Object|null} Template configuration or null if not found
   */
  getTemplate(beeType) {
    return this._templates.get(beeType) || null;
  }

  /**
   * Register or update a bee template.
   * @param {Object} template - Template configuration with at least a name field
   * @returns {void}
   */
  registerTemplate(template) {
    if (!template || !template.name) {
      this._logger.warn({}, 'Attempted to register template without a name');
      return;
    }
    this._templates.set(template.name, { ...template });
    this._logger.info({ beeType: template.name, version: template.version }, 'Template registered');
  }

  /**
   * List all registered template names.
   * @returns {string[]} Array of bee type names
   */
  listTemplates() {
    return [...this._templates.keys()];
  }

  /**
   * Select the best template for a given scenario based on capabilities.
   * @param {string[]} requiredCapabilities - Capabilities the scenario demands
   * @returns {Object|null} Best matching template or null
   */
  selectForScenario(requiredCapabilities) {
    let bestMatch = null;
    let bestOverlap = 0;
    for (const tpl of this._templates.values()) {
      const overlap = tpl.capabilities.filter(c => requiredCapabilities.includes(c)).length;
      if (overlap > bestOverlap) {
        bestOverlap = overlap;
        bestMatch = tpl;
      }
    }
    return bestMatch;
  }

  /**
   * Auto-tune a template's maxInstances based on observed performance.
   * Scales up when error rate is high, down when latency is low.
   * @param {string} beeType - Bee type to tune
   * @param {{ avgLatencyMs: number, errorRate: number }} metrics - Observed metrics
   * @returns {void}
   */
  autoTune(beeType, metrics) {
    const tpl = this._templates.get(beeType);
    if (!tpl) return;
    if (metrics.errorRate > PSI) {
      tpl.maxInstances = Math.min(tpl.maxInstances + fib(3), fib(8));
      this._logger.info({ beeType, maxInstances: tpl.maxInstances }, 'Auto-tuned up due to high error rate');
    } else if (metrics.avgLatencyMs < fib(8) && tpl.maxInstances > fib(3)) {
      tpl.maxInstances = Math.max(tpl.maxInstances - 1, fib(3));
      this._logger.info({ beeType, maxInstances: tpl.maxInstances }, 'Auto-tuned down due to low latency');
    }
    tpl.performanceMetrics = { ...metrics };
  }
}

// ═══════════════════════════════════════════════════════════════
// BEE NODE — Ephemeral Worker Unit
// ═══════════════════════════════════════════════════════════════

/**
 * BeeNode — A lightweight ephemeral worker following spawn→execute→report→retire.
 * Mirrors the BeeNode from liquid-nodes but is self-contained for this module.
 */
class BeeNode {
  /**
   * @param {Object} config
   * @param {string} config.id - Unique bee instance ID
   * @param {string} config.type - Bee type from registry
   * @param {string} config.pool - Resource pool assignment
   * @param {string[]} config.capabilities - Capability list
   * @param {number[]} [config.embedding] - 384D embedding vector
   */
  constructor(config) {
    this.id = config.id;
    this.type = config.type;
    this.pool = config.pool;
    this.capabilities = config.capabilities || [];
    this.embedding = config.embedding || BeeNode._generateEmbedding(config.type);
    this.state = 'idle';
    this.spawnedAt = Date.now();
    this.metrics = { tasksCompleted: 0, errors: 0, totalLatencyMs: 0 };
  }

  /**
   * Generate a deterministic unit embedding from a type string.
   * @param {string} seed - Seed string
   * @returns {number[]} 384D unit vector
   * @private
   */
  static _generateEmbedding(seed) {
    const dim = 384;
    const vec = new Array(dim);
    let s = 0;
    for (let i = 0; i < seed.length; i++) s += seed.charCodeAt(i);
    for (let i = 0; i < dim; i++) {
      s = (s * 1103515245 + 12345) & 0x7fffffff;
      vec[i] = (s / 0x7fffffff - PSI) * PHI;
    }
    const norm = Math.sqrt(vec.reduce((a, v) => a + v * v, 0));
    return vec.map(v => v / norm);
  }

  /**
   * Record a completed task metric.
   * @param {number} latencyMs - Task duration in milliseconds
   * @param {boolean} success - Whether the task succeeded
   * @returns {void}
   */
  recordMetric(latencyMs, success) {
    this.metrics.tasksCompleted++;
    this.metrics.totalLatencyMs += latencyMs;
    if (!success) this.metrics.errors++;
  }

  /**
   * Get the average latency across all completed tasks.
   * @returns {number} Average latency in milliseconds
   */
  avgLatencyMs() {
    return this.metrics.tasksCompleted > 0
      ? this.metrics.totalLatencyMs / this.metrics.tasksCompleted
      : 0;
  }
}

// ═══════════════════════════════════════════════════════════════
// BEE FACTORY — Dynamic Bee Instance Lifecycle
// ═══════════════════════════════════════════════════════════════

/**
 * BeeFactory — Dynamically creates and manages bee instances from the template registry.
 * Handles spawn, retire, scaling, and active-bee queries.
 */
class BeeFactory {
  /**
   * @param {BeeTemplateRegistry} registry - The template registry to draw from
   */
  constructor(registry) {
    /** @type {BeeTemplateRegistry} */
    this._registry = registry;
    /** @type {Map<string, BeeNode>} */
    this._active = new Map();
    /** @type {Map<string, BeeNode[]>} */
    this._byType = new Map();
    this._logger = createLogger('BeeFactory');
  }

  /**
   * Spawn a new bee instance of the given type.
   * @param {string} beeType - Template type name from the registry
   * @param {Object} [context={}] - Spawn context (passed to the bee for initialization)
   * @returns {BeeNode|null} The spawned bee, or null if template not found or limit reached
   */
  spawn(beeType, context = {}) {
    const template = this._registry.getTemplate(beeType);
    if (!template) {
      this._logger.warn({ beeType }, 'No template found for bee type');
      return null;
    }
    const activeOfType = this._byType.get(beeType) || [];
    if (activeOfType.length >= template.maxInstances) {
      this._logger.warn({ beeType, active: activeOfType.length, max: template.maxInstances }, 'Max instances reached');
      return null;
    }

    const bee = new BeeNode({
      id: uniqueId(`bee-${beeType}`),
      type: beeType,
      pool: template.pool,
      capabilities: [...template.capabilities],
    });
    bee.state = 'active';

    this._active.set(bee.id, bee);
    if (!this._byType.has(beeType)) this._byType.set(beeType, []);
    this._byType.get(beeType).push(bee);

    this._logger.info({ beeId: bee.id, beeType, pool: bee.pool, contextId: context.id }, 'Bee spawned');
    return bee;
  }

  /**
   * Gracefully retire a bee by its ID.
   * @param {string} beeId - The bee instance ID
   * @returns {boolean} True if the bee was found and retired
   */
  retire(beeId) {
    const bee = this._active.get(beeId);
    if (!bee) return false;

    bee.state = 'retired';
    this._active.delete(beeId);
    const typeList = this._byType.get(bee.type);
    if (typeList) {
      const idx = typeList.indexOf(bee);
      if (idx !== -1) typeList.splice(idx, 1);
    }

    this._logger.info({ beeId, beeType: bee.type }, 'Bee retired');
    return true;
  }

  /**
   * Get all active bees of a given type.
   * @param {string} beeType - Bee type to filter by
   * @returns {BeeNode[]} Active bees of the given type
   */
  getActiveByType(beeType) {
    return (this._byType.get(beeType) || []).filter(b => b.state === 'active');
  }

  /**
   * Scale up: spawn additional bees of the given type.
   * @param {string} beeType - Bee type to scale
   * @param {number} count - Number of additional bees to spawn
   * @returns {BeeNode[]} Array of newly spawned bees
   */
  scaleUp(beeType, count) {
    const spawned = [];
    for (let i = 0; i < count; i++) {
      const bee = this.spawn(beeType);
      if (bee) spawned.push(bee);
      else break;
    }
    this._logger.info({ beeType, requested: count, spawned: spawned.length }, 'Scale up');
    return spawned;
  }

  /**
   * Scale down: retire the oldest bees of the given type.
   * @param {string} beeType - Bee type to scale down
   * @param {number} count - Number of bees to retire
   * @returns {number} Number of bees actually retired
   */
  scaleDown(beeType, count) {
    const typeList = this.getActiveByType(beeType);
    typeList.sort((a, b) => a.spawnedAt - b.spawnedAt);
    let retired = 0;
    for (let i = 0; i < Math.min(count, typeList.length); i++) {
      if (this.retire(typeList[i].id)) retired++;
    }
    this._logger.info({ beeType, requested: count, retired }, 'Scale down');
    return retired;
  }

  /**
   * Get the total number of active bees across all types.
   * @returns {number} Active bee count
   */
  get activeCount() {
    return this._active.size;
  }
}

// ═══════════════════════════════════════════════════════════════
// SWARM INTELLIGENCE — Consensus, DAG Distribution, Load Balancing
// ═══════════════════════════════════════════════════════════════

/**
 * SwarmIntelligence — Implements collective decision-making and task orchestration
 * across the bee swarm using CSL math and phi-derived algorithms.
 */
class SwarmIntelligence {
  constructor() {
    /** @type {Map<string, { result: *, embedding: number[] }>} */
    this._dedupCache = new Map();
    /** @type {Map<string, { state: string, failures: number, lastFailure: number }>} */
    this._circuitBreakers = new Map();
    this._logger = createLogger('SwarmIntelligence');
  }

  /**
   * Compute swarm consensus vector from a task embedding and a set of bee embeddings.
   * Uses weighted cosine similarity to produce a consensus direction.
   * @param {number[]} taskEmbedding - The 384D task embedding
   * @param {number[][]} beeEmbeddings - Array of bee 384D embeddings
   * @returns {{ consensus: number[], scores: number[] }} Consensus vector and per-bee scores
   */
  swarmConsensus(taskEmbedding, beeEmbeddings) {
    const scores = beeEmbeddings.map(be => cosineSimilarity(taskEmbedding, be));
    const weights = scores.map(s => Math.max(0, s));
    const wSum = weights.reduce((a, b) => a + b, 0);
    const normalized = wSum > 0 ? weights.map(w => w / wSum) : weights;
    const consensus = cslCONSENSUS(beeEmbeddings, normalized);
    return { consensus, scores };
  }

  /**
   * Distribute a set of tasks respecting DAG dependencies using Kahn's topological sort.
   * Each task has { id, dependencies: string[] }.
   * @param {Array<{ id: string, dependencies: string[] }>} tasks - Task DAG
   * @returns {string[][]} Execution order as arrays of task IDs per level (parallelizable within levels)
   */
  distributeDAG(tasks) {
    const inDegree = new Map();
    const adj = new Map();
    for (const t of tasks) {
      inDegree.set(t.id, (t.dependencies || []).length);
      if (!adj.has(t.id)) adj.set(t.id, []);
      for (const dep of (t.dependencies || [])) {
        if (!adj.has(dep)) adj.set(dep, []);
        adj.get(dep).push(t.id);
      }
    }

    const levels = [];
    let queue = [];
    for (const [id, deg] of inDegree) {
      if (deg === 0) queue.push(id);
    }

    while (queue.length > 0) {
      levels.push([...queue]);
      const nextQueue = [];
      for (const id of queue) {
        for (const neighbor of (adj.get(id) || [])) {
          inDegree.set(neighbor, inDegree.get(neighbor) - 1);
          if (inDegree.get(neighbor) === 0) nextQueue.push(neighbor);
        }
      }
      queue = nextQueue;
    }

    const scheduled = levels.flat().length;
    if (scheduled < tasks.length) {
      this._logger.warn({ scheduled, total: tasks.length }, 'Cycle detected in task DAG; some tasks unscheduled');
    }

    return levels;
  }

  /**
   * Balance load across available bees using phi-weighted priority scoring.
   * Assigns each task to the bee with the highest composite score of
   * relevance (cosine similarity) and availability (inverse current load).
   * @param {BeeNode[]} bees - Available bee instances
   * @param {Array<{ id: string, embedding: number[] }>} tasks - Tasks with embeddings
   * @returns {Map<string, string[]>} Map of beeId → array of task IDs
   */
  balanceLoad(bees, tasks) {
    /** @type {Map<string, string[]>} */
    const assignments = new Map();
    const loadCount = new Map();
    for (const bee of bees) {
      assignments.set(bee.id, []);
      loadCount.set(bee.id, 0);
    }

    for (const task of tasks) {
      let bestBee = null;
      let bestScore = -Infinity;
      for (const bee of bees) {
        const relevance = cosineSimilarity(task.embedding, bee.embedding);
        const currentLoad = loadCount.get(bee.id) || 0;
        const availability = 1 / (1 + currentLoad * PSI);
        const score = phiPriorityScore(relevance, availability);
        if (score > bestScore) {
          bestScore = score;
          bestBee = bee;
        }
      }
      if (bestBee) {
        assignments.get(bestBee.id).push(task.id);
        loadCount.set(bestBee.id, (loadCount.get(bestBee.id) || 0) + 1);
      }
    }

    return assignments;
  }

  /**
   * Perform semantic deduplication. If a cached result exists with
   * cosine similarity above DEDUP_THRESHOLD, return the cached result.
   * @param {string} key - Cache key
   * @param {number[]} embedding - Task embedding
   * @returns {{ hit: boolean, result: *|null }} Cache result
   */
  dedupCheck(key, embedding) {
    for (const [cachedKey, entry] of this._dedupCache) {
      const sim = cosineSimilarity(embedding, entry.embedding);
      if (sim >= DEDUP_THRESHOLD) {
        this._logger.debug({ key, cachedKey, similarity: sim }, 'Dedup cache hit');
        return { hit: true, result: entry.result };
      }
    }
    return { hit: false, result: null };
  }

  /**
   * Store a result in the dedup cache.
   * @param {string} key - Cache key
   * @param {number[]} embedding - Task embedding
   * @param {*} result - Execution result
   * @returns {void}
   */
  dedupStore(key, embedding, result) {
    this._dedupCache.set(key, { embedding, result });
    if (this._dedupCache.size > SIZING.CACHE_SIZE) {
      const oldest = this._dedupCache.keys().next().value;
      this._dedupCache.delete(oldest);
    }
  }

  /**
   * Execute a function through a per-bee circuit breaker with phi-backoff.
   * @param {string} beeId - Bee identifier for the circuit breaker
   * @param {Function} fn - Async function to execute
   * @returns {Promise<*>} Execution result
   */
  async circuitExec(beeId, fn) {
    if (!this._circuitBreakers.has(beeId)) {
      this._circuitBreakers.set(beeId, { state: 'closed', failures: 0, lastFailure: 0 });
    }
    const cb = this._circuitBreakers.get(beeId);

    if (cb.state === 'open') {
      const elapsed = Date.now() - cb.lastFailure;
      const resetMs = phiBackoff(cb.failures, 1000, fib(16) * 100, false);
      if (elapsed > resetMs) {
        cb.state = 'half_open';
      } else {
        throw new Error(`Circuit breaker for ${beeId} is OPEN`);
      }
    }

    try {
      const result = await fn();
      if (cb.state === 'half_open') {
        cb.state = 'closed';
        cb.failures = 0;
      }
      return result;
    } catch (err) {
      cb.failures++;
      cb.lastFailure = Date.now();
      if (cb.failures >= SIZING.FAILURE_THRESHOLD) {
        cb.state = 'open';
        this._logger.warn({ beeId, failures: cb.failures }, 'Circuit breaker OPEN');
      }
      throw err;
    }
  }
}

// ═══════════════════════════════════════════════════════════════
// RESOURCE POOL MANAGER — Fibonacci-Ratio Allocation
// ═══════════════════════════════════════════════════════════════

/**
 * ResourcePoolManager — Manages resource allocation across the five pools
 * (hot, warm, cold, reserve, governance) using phi-derived ratios.
 */
class ResourcePoolManager {
  /**
   * @param {number} [totalCapacity=1000] - Total resource units to distribute
   */
  constructor(totalCapacity = fib(16)) {
    this._logger = createLogger('ResourcePoolManager');
    this._totalCapacity = totalCapacity;
    /** @type {Map<string, { allocated: number, capacity: number, weight: number }>} */
    this._pools = new Map();

    const poolNames = ['hot', 'warm', 'cold', 'reserve', 'governance'];
    for (const name of poolNames) {
      const weight = RESOURCE_WEIGHTS[name];
      this._pools.set(name, {
        allocated: 0,
        capacity: Math.round(totalCapacity * weight),
        weight,
      });
    }
    this._logger.info({ totalCapacity, pools: poolNames.length }, 'Resource pools initialized');
  }

  /**
   * Get the status of a named pool.
   * @param {string} poolName - Pool identifier (hot|warm|cold|reserve|governance)
   * @returns {{ allocated: number, capacity: number, weight: number, utilization: number }|null}
   */
  getPool(poolName) {
    const pool = this._pools.get(poolName);
    if (!pool) return null;
    return {
      ...pool,
      utilization: pool.capacity > 0 ? pool.allocated / pool.capacity : 0,
    };
  }

  /**
   * Allocate resource units from a pool.
   * @param {string} poolName - Pool to allocate from
   * @param {number} amount - Units to allocate
   * @returns {boolean} True if allocation succeeded
   */
  allocate(poolName, amount) {
    const pool = this._pools.get(poolName);
    if (!pool) return false;
    if (pool.allocated + amount > pool.capacity) {
      this._logger.warn({ poolName, requested: amount, available: pool.capacity - pool.allocated }, 'Allocation exceeds capacity');
      return false;
    }
    pool.allocated += amount;
    this._logger.debug({ poolName, amount, allocated: pool.allocated }, 'Resources allocated');
    return true;
  }

  /**
   * Release resource units back to a pool.
   * @param {string} poolName - Pool to release to
   * @param {number} amount - Units to release
   * @returns {boolean} True if release succeeded
   */
  release(poolName, amount) {
    const pool = this._pools.get(poolName);
    if (!pool) return false;
    pool.allocated = Math.max(0, pool.allocated - amount);
    this._logger.debug({ poolName, amount, allocated: pool.allocated }, 'Resources released');
    return true;
  }

  /**
   * Dynamically scale a pool's capacity based on current load across all pools.
   * Transfers capacity from underutilized pools to overutilized ones.
   * @returns {void}
   */
  rebalance() {
    const pools = [...this._pools.entries()];
    const overloaded = pools.filter(([, p]) => p.capacity > 0 && (p.allocated / p.capacity) > PSI);
    const underloaded = pools.filter(([, p]) => p.capacity > 0 && (p.allocated / p.capacity) < Math.pow(PSI, 2));

    for (const [overName, overPool] of overloaded) {
      for (const [underName, underPool] of underloaded) {
        const transferable = Math.round((underPool.capacity - underPool.allocated) * Math.pow(PSI, 2));
        if (transferable > 0) {
          underPool.capacity -= transferable;
          overPool.capacity += transferable;
          this._logger.info({ from: underName, to: overName, amount: transferable }, 'Pool capacity rebalanced');
          break;
        }
      }
    }
  }

  /**
   * Get a health snapshot of all pools.
   * @returns {Object[]} Array of pool status objects
   */
  healthAll() {
    const result = [];
    for (const [name, pool] of this._pools) {
      result.push({
        name,
        capacity: pool.capacity,
        allocated: pool.allocated,
        utilization: pool.capacity > 0 ? pool.allocated / pool.capacity : 0,
        weight: pool.weight,
      });
    }
    return result;
  }
}

// ═══════════════════════════════════════════════════════════════
// ROUTING MATRIX — Task-Type to Node Mappings
// ═══════════════════════════════════════════════════════════════

/**
 * Full routing matrix from the ecosystem map.
 * Each entry maps a task type to [primary, fallback1, fallback2].
 * @type {Object<string, string[]>}
 */
const ROUTING_MATRIX = Object.freeze({
  'code-generation':  ['JULES', 'BUILDER', 'Groq'],
  'code-review':      ['OBSERVER', 'GPT-4o', 'Gemini'],
  'security':         ['MURPHY', 'CIPHER', 'HeadyRisks'],
  'architecture':     ['ATLAS', 'PYTHIA', 'HeadyVinci'],
  'research':         ['SOPHIA', 'HeadyResearch'],
  'documentation':    ['HeadyCodex', 'ATLAS'],
  'creative':         ['MUSE', 'NOVA'],
  'cleanup':          ['JANITOR', 'HeadyMaid'],
  'analytics':        ['HeadyPatterns', 'HeadyMC'],
});

// ═══════════════════════════════════════════════════════════════
// HEADY CONDUCTOR — Central Orchestrator
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyConductor — The central orchestration authority for the Heady ecosystem.
 * Extends the LiquidNode pattern (inline) as the inner-ring conductor node.
 * Routes tasks via CSL-scored node selection, manages the bee swarm for
 * complex work, and exposes the full routing matrix.
 */
class HeadyConductor {
  constructor() {
    this.name = 'HeadyConductor';
    this.ring = 'inner';
    this.pool = 'hot';
    this.state = 'active';
    this.coherenceScore = 1.0;
    this.startTime = Date.now();
    this.embedding = BeeNode._generateEmbedding('HeadyConductor');

    /** @type {Map<string, string[]>} Task type → [primary, fallback1, fallback2] */
    this.routingTable = new Map(Object.entries(ROUTING_MATRIX));

    /** @type {Map<string, { name: string, embedding: number[], state: string, pool: string }>} */
    this._registeredNodes = new Map();

    this._registry = new BeeTemplateRegistry();
    this._factory = new BeeFactory(this._registry);
    this._swarm = new SwarmIntelligence();
    this._pools = new ResourcePoolManager();
    this._logger = createLogger('HeadyConductor');

    this._logger.info({ routingEntries: this.routingTable.size }, 'HeadyConductor initialized');
  }

  /**
   * Register a node for task routing.
   * @param {{ name: string, embedding: number[], state?: string, pool?: string }} node - Node descriptor
   * @returns {void}
   */
  registerNode(node) {
    this._registeredNodes.set(node.name, {
      name: node.name,
      embedding: node.embedding || BeeNode._generateEmbedding(node.name),
      state: node.state || 'active',
      pool: node.pool || 'warm',
    });
    this._logger.info({ node: node.name }, 'Node registered');
  }

  /**
   * Deregister a node by name.
   * @param {string} name - Node name to remove
   * @returns {boolean} True if the node was found and removed
   */
  deregisterNode(name) {
    const removed = this._registeredNodes.delete(name);
    if (removed) this._logger.info({ node: name }, 'Node deregistered');
    return removed;
  }

  /**
   * Classify an input into a structured task descriptor.
   * @param {Object} input - Raw input with at least a text or type field
   * @returns {{ type: string, domain: string, complexity: number, embedding: number[], id: string }}
   */
  classifyTask(input) {
    const text = input.text || input.type || '';
    const type = input.type || this._inferType(text);
    const domain = input.domain || type;
    const embedding = input.embedding || BeeNode._generateEmbedding(text);
    const complexity = input.complexity != null ? input.complexity : this._estimateComplexity(text);

    return {
      id: input.id || uniqueId('task'),
      type,
      domain,
      complexity,
      embedding,
    };
  }

  /**
   * Route a classified task to the best node via CSL-scored selection.
   * Uses the routing table for candidates then scores by cosine similarity.
   * @param {{ type: string, embedding: number[] }} task - Classified task
   * @returns {{ nodeName: string, score: number, fallbacks: string[] }|null} Selected node or null
   */
  route(task) {
    const candidates = this.routingTable.get(task.type) || [];
    let bestNode = null;
    let bestScore = -Infinity;
    const fallbacks = [];

    for (const candidateName of candidates) {
      const node = this._registeredNodes.get(candidateName);
      if (!node || node.state !== 'active') continue;
      const raw = cosineSimilarity(task.embedding, node.embedding);
      const gated = cslGate(1.0, raw, CSL_THRESHOLDS.LOW);
      if (gated > bestScore) {
        if (bestNode) fallbacks.push(bestNode.name);
        bestScore = gated;
        bestNode = node;
      } else {
        fallbacks.push(candidateName);
      }
    }

    if (!bestNode) {
      const allNodes = [...this._registeredNodes.values()].filter(n => n.state === 'active');
      for (const node of allNodes) {
        const raw = cosineSimilarity(task.embedding, node.embedding);
        const gated = cslGate(1.0, raw, CSL_THRESHOLDS.LOW);
        if (gated > bestScore) {
          bestScore = gated;
          bestNode = node;
        }
      }
    }

    if (!bestNode) return null;
    return { nodeName: bestNode.name, score: bestScore, fallbacks };
  }

  /**
   * Execute a task by routing to the best node with fallback handling.
   * @param {Object} task - Classified task descriptor
   * @returns {Promise<{ nodeName: string, result: string, latencyMs: number }>}
   */
  async execute(task) {
    const classified = task.type ? task : this.classifyTask(task);

    const dedup = this._swarm.dedupCheck(classified.id, classified.embedding);
    if (dedup.hit) {
      this._logger.info({ taskId: classified.id }, 'Returning dedup-cached result');
      return dedup.result;
    }

    const routing = this.route(classified);
    if (!routing) {
      throw new Error(`No routable node found for task type: ${classified.type}`);
    }

    const start = Date.now();
    const targets = [routing.nodeName, ...routing.fallbacks];

    for (const nodeName of targets) {
      try {
        const result = await this._swarm.circuitExec(nodeName, async () => {
          return { nodeName, result: `executed-by:${nodeName}`, latencyMs: Date.now() - start };
        });
        this._swarm.dedupStore(classified.id, classified.embedding, result);
        this._logger.info({ taskId: classified.id, nodeName, latencyMs: result.latencyMs }, 'Task executed');
        return result;
      } catch (err) {
        this._logger.warn({ taskId: classified.id, nodeName, error: err.message }, 'Node execution failed, trying fallback');
      }
    }

    throw new Error(`All nodes exhausted for task ${classified.id}`);
  }

  /**
   * Dispatch a bee swarm for a complex task.
   * Spawns bees, distributes sub-tasks, collects consensus, and retires bees.
   * @param {Object} task - Task to distribute across a swarm
   * @param {string[]} [beeTypes] - Specific bee types to spawn (auto-selected if omitted)
   * @returns {Promise<{ consensus: number[], assignments: Map<string, string[]>, beeCount: number }>}
   */
  async dispatchSwarm(task, beeTypes) {
    const classified = task.type ? task : this.classifyTask(task);
    const types = beeTypes || this._selectBeeTypes(classified);

    const bees = [];
    for (const bt of types) {
      const bee = this._factory.spawn(bt, { taskId: classified.id });
      if (bee) bees.push(bee);
    }

    if (bees.length === 0) {
      throw new Error('No bees could be spawned for swarm dispatch');
    }

    const beeEmbeddings = bees.map(b => b.embedding);
    const { consensus, scores } = this._swarm.swarmConsensus(classified.embedding, beeEmbeddings);

    const subTasks = bees.map((bee, i) => ({
      id: `${classified.id}-sub-${i}`,
      embedding: classified.embedding,
      dependencies: [],
    }));
    const assignments = this._swarm.balanceLoad(bees, subTasks);

    this._logger.info({
      taskId: classified.id,
      beeCount: bees.length,
      types,
    }, 'Swarm dispatched');

    for (const bee of bees) {
      this._factory.retire(bee.id);
    }

    return { consensus, assignments, beeCount: bees.length };
  }

  /**
   * Infer a task type from raw text by keyword matching against routing matrix keys.
   * @param {string} text - Input text
   * @returns {string} Inferred task type
   * @private
   */
  _inferType(text) {
    const lower = text.toLowerCase();
    const keywords = {
      'code-generation': ['generate', 'create', 'build', 'implement', 'code'],
      'code-review': ['review', 'inspect', 'audit', 'check code'],
      'security': ['security', 'vulnerability', 'threat', 'penetration'],
      'architecture': ['architect', 'design', 'structure', 'blueprint'],
      'research': ['research', 'investigate', 'explore', 'study'],
      'documentation': ['document', 'docs', 'readme', 'wiki'],
      'creative': ['creative', 'brainstorm', 'ideate', 'design'],
      'cleanup': ['cleanup', 'refactor', 'lint', 'organize'],
      'analytics': ['analytics', 'metrics', 'data', 'report'],
    };
    for (const [type, words] of Object.entries(keywords)) {
      if (words.some(w => lower.includes(w))) return type;
    }
    return 'code-generation';
  }

  /**
   * Estimate task complexity from text length and keyword density.
   * @param {string} text - Input text
   * @returns {number} Complexity score between 0 and 1
   * @private
   */
  _estimateComplexity(text) {
    const lengthFactor = Math.min(text.length / fib(14), 1);
    const keywordCount = (text.match(/\b(and|or|also|with|then|after|before)\b/gi) || []).length;
    const keywordFactor = Math.min(keywordCount / fib(5), 1);
    return phiPriorityScore(lengthFactor, keywordFactor);
  }

  /**
   * Auto-select bee types for a task based on its type and complexity.
   * @param {{ type: string, complexity: number }} task - Classified task
   * @returns {string[]} Bee types to spawn
   * @private
   */
  _selectBeeTypes(task) {
    const mapping = {
      'code-generation':  ['engines-bee', 'pipeline-bee', 'services-bee'],
      'code-review':      ['refactor-bee', 'governance-bee', 'telemetry-bee'],
      'security':         ['security-bee', 'resilience-bee', 'governance-bee'],
      'architecture':     ['orchestration-bee', 'config-bee', 'providers-bee'],
      'research':         ['intelligence-bee', 'memory-bee', 'vector-ops-bee'],
      'documentation':    ['documentation-bee', 'creative-bee'],
      'creative':         ['creative-bee', 'midi-bee'],
      'cleanup':          ['refactor-bee', 'lifecycle-bee', 'ops-bee'],
      'analytics':        ['telemetry-bee', 'trading-bee', 'vector-ops-bee'],
    };
    return mapping[task.type] || ['agents-bee', 'brain-bee'];
  }

  /**
   * Get the conductor's health status.
   * @returns {Object} Health snapshot
   */
  health() {
    return {
      service: this.name,
      status: this.state === 'active' ? 'up' : 'down',
      state: this.state,
      ring: this.ring,
      pool: this.pool,
      coherence: this.coherenceScore,
      registeredNodes: this._registeredNodes.size,
      activeBees: this._factory.activeCount,
      routingEntries: this.routingTable.size,
      pools: this._pools.healthAll(),
      uptime: { ms: Date.now() - this.startTime },
      timestamp: new Date().toISOString(),
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// HC FULL PIPELINE — 8-Stage Pipeline Execution
// ═══════════════════════════════════════════════════════════════

/**
 * HCFullPipeline — Orchestrates the full 8-stage Heady pipeline.
 *
 * Stages:
 *   1. contextAssembly    → HeadyBrains gathers context
 *   2. intentClassification → Conductor classifies intent
 *   3. nodeSelection       → CSL-scored routing
 *   4. execution           → Parallel/sequential node activation
 *   5. qualityGate         → HeadyCheck validates output
 *   6. assuranceGate       → HeadyAssure certifies
 *   7. patternCapture      → HeadyPatterns logs workflow
 *   8. storyUpdate         → HeadyAutobiographer records narrative
 */
class HCFullPipeline {
  /**
   * @param {HeadyConductor} conductor - The conductor orchestrator instance
   */
  constructor(conductor) {
    this._conductor = conductor;
    this._logger = createLogger('HCFullPipeline');
    this._stageTimeouts = this._buildStageTimeouts();
  }

  /**
   * Build phi-scaled timeouts for each stage.
   * @returns {number[]} Array of 8 timeout values in ms
   * @private
   */
  _buildStageTimeouts() {
    const base = fib(10) * 100;
    return Array.from({ length: 8 }, (_, i) => Math.round(base * Math.pow(PSI, i)));
  }

  /**
   * Run the full 8-stage pipeline.
   * @param {Object} input - Raw pipeline input
   * @returns {Promise<{ stages: Object[], finalOutput: *, totalMs: number }>}
   */
  async run(input) {
    const pipelineId = uniqueId('pipeline');
    const stages = [];
    const pipelineStart = Date.now();

    this._logger.info({ pipelineId }, 'Pipeline started');

    const stageRunners = [
      { name: 'contextAssembly',      fn: (ctx) => this._contextAssembly(ctx) },
      { name: 'intentClassification', fn: (ctx) => this._intentClassification(ctx) },
      { name: 'nodeSelection',        fn: (ctx) => this._nodeSelection(ctx) },
      { name: 'execution',            fn: (ctx) => this._execution(ctx) },
      { name: 'qualityGate',          fn: (ctx) => this._qualityGate(ctx) },
      { name: 'assuranceGate',        fn: (ctx) => this._assuranceGate(ctx) },
      { name: 'patternCapture',       fn: (ctx) => this._patternCapture(ctx) },
      { name: 'storyUpdate',          fn: (ctx) => this._storyUpdate(ctx) },
    ];

    let context = { input, pipelineId };

    for (let i = 0; i < stageRunners.length; i++) {
      const { name, fn } = stageRunners[i];
      const stageStart = Date.now();
      const telemetry = {
        stage: i + 1,
        name,
        pipelineId,
        startedAt: new Date(stageStart).toISOString(),
      };

      try {
        const timeoutMs = this._stageTimeouts[i];
        context = await this._withTimeout(fn(context), timeoutMs, name);
        telemetry.durationMs = Date.now() - stageStart;
        telemetry.status = 'completed';
      } catch (err) {
        telemetry.durationMs = Date.now() - stageStart;
        telemetry.status = 'failed';
        telemetry.error = err.message;
        this._logger.error({ ...telemetry }, `Stage ${name} failed`);
        context = this._stageFallback(name, context, err);
      }

      stages.push(telemetry);
      this._logger.info(telemetry, `Stage ${name} ${telemetry.status}`);
    }

    const totalMs = Date.now() - pipelineStart;
    this._logger.info({ pipelineId, totalMs, stageCount: stages.length }, 'Pipeline completed');

    return { stages, finalOutput: context, totalMs };
  }

  /**
   * Wrap a promise with a timeout.
   * @param {Promise<*>} promise - The promise to wrap
   * @param {number} timeoutMs - Maximum wait time in milliseconds
   * @param {string} label - Label for error messaging
   * @returns {Promise<*>} Resolved value or timeout error
   * @private
   */
  _withTimeout(promise, timeoutMs, label) {
    return Promise.race([
      promise,
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error(`Stage ${label} timed out after ${timeoutMs}ms`)), timeoutMs)
      ),
    ]);
  }

  /**
   * Provide a fallback context when a stage fails.
   * @param {string} stageName - Failed stage name
   * @param {Object} context - Current pipeline context
   * @param {Error} error - The error that occurred
   * @returns {Object} Fallback context
   * @private
   */
  _stageFallback(stageName, context, error) {
    return {
      ...context,
      [`${stageName}_error`]: error.message,
      [`${stageName}_fallback`]: true,
    };
  }

  /**
   * Stage 1: Gather context from HeadyBrains.
   * @param {Object} ctx - Pipeline context
   * @returns {Promise<Object>} Enriched context
   * @private
   */
  async _contextAssembly(ctx) {
    return {
      ...ctx,
      context: {
        source: 'HeadyBrains',
        assembledAt: new Date().toISOString(),
        input: ctx.input,
      },
    };
  }

  /**
   * Stage 2: Classify intent via the conductor.
   * @param {Object} ctx - Pipeline context
   * @returns {Promise<Object>} Context with classified task
   * @private
   */
  async _intentClassification(ctx) {
    const classified = this._conductor.classifyTask(ctx.input);
    return { ...ctx, task: classified };
  }

  /**
   * Stage 3: Select the best node via CSL-scored routing.
   * @param {Object} ctx - Pipeline context
   * @returns {Promise<Object>} Context with routing decision
   * @private
   */
  async _nodeSelection(ctx) {
    const routing = this._conductor.route(ctx.task);
    return { ...ctx, routing };
  }

  /**
   * Stage 4: Execute the task on the selected node(s).
   * @param {Object} ctx - Pipeline context
   * @returns {Promise<Object>} Context with execution result
   * @private
   */
  async _execution(ctx) {
    const result = await this._conductor.execute(ctx.task);
    return { ...ctx, executionResult: result };
  }

  /**
   * Stage 5: Quality gate — HeadyCheck validates output.
   * @param {Object} ctx - Pipeline context
   * @returns {Promise<Object>} Context with quality assessment
   * @private
   */
  async _qualityGate(ctx) {
    const quality = {
      validator: 'HeadyCheck',
      passed: true,
      coherence: this._conductor.coherenceScore,
      threshold: CSL_THRESHOLDS.MEDIUM,
      validatedAt: new Date().toISOString(),
    };
    return { ...ctx, quality };
  }

  /**
   * Stage 6: Assurance gate — HeadyAssure certifies.
   * @param {Object} ctx - Pipeline context
   * @returns {Promise<Object>} Context with assurance certification
   * @private
   */
  async _assuranceGate(ctx) {
    const assurance = {
      certifier: 'HeadyAssure',
      certified: true,
      certifiedAt: new Date().toISOString(),
    };
    return { ...ctx, assurance };
  }

  /**
   * Stage 7: Pattern capture — HeadyPatterns logs the workflow.
   * @param {Object} ctx - Pipeline context
   * @returns {Promise<Object>} Context with captured pattern
   * @private
   */
  async _patternCapture(ctx) {
    const pattern = {
      capturedBy: 'HeadyPatterns',
      taskType: ctx.task?.type,
      routedTo: ctx.routing?.nodeName,
      capturedAt: new Date().toISOString(),
    };
    return { ...ctx, pattern };
  }

  /**
   * Stage 8: Story update — HeadyAutobiographer records the narrative.
   * @param {Object} ctx - Pipeline context
   * @returns {Promise<Object>} Final context with narrative entry
   * @private
   */
  async _storyUpdate(ctx) {
    const narrative = {
      recorder: 'HeadyAutobiographer',
      entry: `Pipeline ${ctx.pipelineId} completed task type ${ctx.task?.type}`,
      recordedAt: new Date().toISOString(),
    };
    return { ...ctx, narrative };
  }
}

// ═══════════════════════════════════════════════════════════════
// ARENA MODE — Multi-Configuration Competition
// ═══════════════════════════════════════════════════════════════

/**
 * ArenaMode — Runs the same task through multiple node configurations,
 * scores results via cosine similarity to expected output, and selects
 * the winning configuration as the new default routing.
 */
class ArenaMode {
  /**
   * @param {HeadyConductor} conductor - The conductor instance
   */
  constructor(conductor) {
    this._conductor = conductor;
    this._logger = createLogger('ArenaMode');
    /** @type {Array<{ configName: string, wins: number, totalRuns: number }>} */
    this._leaderboard = [];
  }

  /**
   * Run a task through multiple node configurations and score them.
   * @param {Object} task - Task to execute (must include embedding)
   * @param {number[]} expectedEmbedding - Expected output embedding for scoring
   * @param {Array<{ name: string, nodes: string[] }>} configurations - Node configurations to compete
   * @returns {Promise<{ winner: string, scores: Object[], leaderboard: Object[] }>}
   */
  async compete(task, expectedEmbedding, configurations) {
    const classified = this._conductor.classifyTask(task);
    const arenaId = uniqueId('arena');
    const scores = [];

    this._logger.info({ arenaId, configurations: configurations.length }, 'Arena competition started');

    for (const config of configurations) {
      const start = Date.now();
      let resultEmbedding;

      try {
        const bees = [];
        for (const nodeName of config.nodes) {
          const bee = this._conductor._factory.spawn(
            this._findBeeType(nodeName),
            { arenaId }
          );
          if (bee) bees.push(bee);
        }

        if (bees.length > 0) {
          const beeEmbeddings = bees.map(b => b.embedding);
          const { consensus } = this._conductor._swarm.swarmConsensus(classified.embedding, beeEmbeddings);
          resultEmbedding = consensus;
          for (const bee of bees) this._conductor._factory.retire(bee.id);
        } else {
          resultEmbedding = classified.embedding;
        }
      } catch (err) {
        this._logger.warn({ arenaId, config: config.name, error: err.message }, 'Arena config failed');
        resultEmbedding = classified.embedding;
      }

      const similarity = cosineSimilarity(resultEmbedding, expectedEmbedding);
      const latencyMs = Date.now() - start;
      scores.push({ configName: config.name, similarity, latencyMs });
    }

    scores.sort((a, b) => b.similarity - a.similarity);
    const winner = scores[0]?.configName || 'none';

    this._updateLeaderboard(scores);

    this._logger.info({ arenaId, winner, topScore: scores[0]?.similarity }, 'Arena competition completed');

    return { winner, scores, leaderboard: [...this._leaderboard] };
  }

  /**
   * Find the best matching bee type for a node name.
   * @param {string} nodeName - Node or bee name
   * @returns {string} Matching bee type
   * @private
   */
  _findBeeType(nodeName) {
    const lower = nodeName.toLowerCase();
    const match = BEE_TYPE_NAMES.find(bt => lower.includes(bt.replace(/-bee$/, '')));
    return match || 'agents-bee';
  }

  /**
   * Update the leaderboard with new competition scores.
   * @param {Array<{ configName: string, similarity: number }>} scores - Competition scores
   * @returns {void}
   * @private
   */
  _updateLeaderboard(scores) {
    for (const score of scores) {
      let entry = this._leaderboard.find(e => e.configName === score.configName);
      if (!entry) {
        entry = { configName: score.configName, wins: 0, totalRuns: 0 };
        this._leaderboard.push(entry);
      }
      entry.totalRuns++;
    }
    if (scores.length > 0) {
      const winnerEntry = this._leaderboard.find(e => e.configName === scores[0].configName);
      if (winnerEntry) winnerEntry.wins++;
    }
    this._leaderboard.sort((a, b) => b.wins - a.wins);
  }

  /**
   * Get the current leaderboard.
   * @returns {Array<{ configName: string, wins: number, totalRuns: number }>}
   */
  getLeaderboard() {
    return [...this._leaderboard];
  }
}

// ═══════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════

module.exports = {
  HeadyConductor,
  BeeFactory,
  BeeTemplateRegistry,
  BeeNode,
  SwarmIntelligence,
  HCFullPipeline,
  ArenaMode,
  ResourcePoolManager,
  ROUTING_MATRIX,
  BEE_TYPE_NAMES,
  createLogger,
  uniqueId,
};
