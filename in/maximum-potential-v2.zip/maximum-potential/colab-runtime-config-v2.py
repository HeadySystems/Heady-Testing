"""
Heady Colab Pro+ Runtime Configuration v2 — 3-Runtime Latent Space Operations
© 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents

Three Colab Pro+ runtimes form the latent space compute layer of the Heady OS:
  Runtime 1: Vector Memory & Embedding Operations (GPU: A100/V100)
  Runtime 2: LLM Inference & Agent Execution (GPU: A100 80GB)
  Runtime 3: Training, Fine-tuning & Analytics (TPU v2-8)

v2: Updated 2026 models, fallback/quantization configs, AsyncTaskRouter with
phi-weighted load balancing + circuit breaker, async health monitor, task-to-model
routing. All parameters use phi-scaled constants — zero magic numbers.
"""

import math
import os
import time
import json
import hashlib
import logging
import asyncio
from dataclasses import dataclass, field
from typing import Optional, Dict, List, Any, Tuple
from enum import Enum
from collections import deque

# ═══════════════════════════════════════════════════════════════
# PHI-MATH FOUNDATION
# ═══════════════════════════════════════════════════════════════

PHI: float = (1 + math.sqrt(5)) / 2      # ≈ 1.618033988749895
PSI: float = 1 / PHI                      # ≈ 0.618033988749895
PHI2: float = PHI + 1                     # ≈ 2.618
PHI3: float = 2 * PHI + 1                 # ≈ 4.236

FIB: List[int] = [
    0, 1, 1, 2, 3, 5, 8, 13, 21, 34,
    55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765,
]

def fib(n: int) -> int:
    """Get Fibonacci number by index; lookup table with iterative fallback."""
    if n < len(FIB):
        return FIB[n]
    a, b = FIB[-2], FIB[-1]
    for _ in range(len(FIB), n + 1):
        a, b = b, a + b
    return b

def phi_threshold(level: int, spread: float = 0.5) -> float:
    """Phi-harmonic threshold: 1 - psi^level * spread.
    L0=0.500, L1=0.691, L2=0.809, L3=0.882, L4=0.927."""
    return 1 - (PSI ** level) * spread

def phi_backoff(attempt: int, base_s: float = 1.0, max_s: float = 60.0) -> float:
    """Phi-exponential backoff: min(base * PHI^attempt, max_s)."""
    return min(base_s * (PHI ** attempt), max_s)

CSL_THRESHOLDS: Dict[str, float] = {
    "MINIMUM":  phi_threshold(0),   # ≈ 0.500
    "LOW":      phi_threshold(1),   # ≈ 0.691
    "MEDIUM":   phi_threshold(2),   # ≈ 0.809
    "HIGH":     phi_threshold(3),   # ≈ 0.882
    "CRITICAL": phi_threshold(4),   # ≈ 0.927
}
DEDUP_THRESHOLD: float = phi_threshold(6)  # ≈ 0.972

def _create_logger(name: str) -> logging.Logger:
    """Create a structured JSON logger."""
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    if not logger.handlers:
        h = logging.StreamHandler()
        h.setFormatter(logging.Formatter(
            '{"timestamp":"%(asctime)s","level":"%(levelname)s",'
            '"service":"%(name)s","msg":"%(message)s"}'
        ))
        logger.addHandler(h)
    return logger

# ═══════════════════════════════════════════════════════════════
# RUNTIME CONFIGURATION
# ═══════════════════════════════════════════════════════════════

class RuntimeRole(Enum):
    """The three Colab Pro+ runtime roles."""
    VECTOR_OPS = "vector_ops"
    LLM_INFERENCE = "llm_inference"
    TRAINING = "training"

@dataclass
class RuntimeConfig:
    """Configuration for a single Colab Pro+ runtime.
    v2 adds fallback_models, quantization_config, and all_models property."""
    role: RuntimeRole
    runtime_id: str
    gpu_type: str
    gpu_count: int
    ram_gb: int
    disk_gb: int
    port: int
    health_port: int
    models: List[str] = field(default_factory=list)
    fallback_models: List[str] = field(default_factory=list)
    quantization_config: Dict[str, Any] = field(default_factory=dict)
    env_vars: Dict[str, str] = field(default_factory=dict)

    @property
    def health_endpoint(self) -> str:
        """Health check URL for this runtime."""
        return f"http://localhost:{self.health_port}/health"

    @property
    def resource_weight(self) -> float:
        """Phi-scaled resource weight: LLM=PSI, Vector=PSI^2, Training=PSI^3."""
        return {
            RuntimeRole.VECTOR_OPS: PSI ** 2,
            RuntimeRole.LLM_INFERENCE: PSI,
            RuntimeRole.TRAINING: PSI ** 3,
        }[self.role]

    @property
    def all_models(self) -> List[str]:
        """Primary + fallback models in priority order."""
        return self.models + self.fallback_models

# ─── RUNTIME 1: VECTOR MEMORY & EMBEDDING OPERATIONS ─────────

RUNTIME_1_VECTOR = RuntimeConfig(
    role=RuntimeRole.VECTOR_OPS,
    runtime_id="heady-vector-runtime",
    gpu_type="A100",
    gpu_count=1,
    ram_gb=fib(9),              # 34 GB
    disk_gb=fib(12),            # 144 GB
    port=3301,
    health_port=3311,
    models=[
        "Qwen/Qwen3-Embedding-8B",           # MTEB 70.58, MRL 32-4096D, 32K ctx
        "nomic-ai/nomic-embed-text-v2-moe",  # MoE 305M, MRL 256-768D, ~1GB
        "BAAI/bge-m3",                        # Dense+sparse+ColBERT, 1024D
    ],
    fallback_models=[
        "jinaai/jina-embeddings-v3",          # MRL 32-1024D, 8K ctx
        "Alibaba-NLP/gte-Qwen2-7B-instruct", # 3584D, 131K ctx
    ],
    quantization_config={
        "default_precision": "fp16",
        "qwen3_embedding": "fp16",    # ~16GB on A100
        "nomic_v2_moe": "fp16",       # ~1GB
        "bge_m3": "fp16",             # ~2GB
    },
    env_vars={
        "HEADY_ROLE": "vector_ops",
        "EMBEDDING_DIM": "384",
        "HNSW_M": str(fib(8)),                     # 21
        "HNSW_EF_CONSTRUCTION": str(fib(11)),       # 89
        "HNSW_EF_SEARCH": str(fib(11)),             # 89
        "LRU_CACHE_SIZE": str(fib(16)),             # 987
        "BATCH_SIZE": str(fib(11)),                 # 89
        "VECTOR_MEMORY_MODE": "ram_first",
        "PGVECTOR_SYNC_INTERVAL_MS": str(round(PHI * 1000 * fib(5))),
    },
)

# ─── RUNTIME 2: LLM INFERENCE & AGENT EXECUTION ──────────────

RUNTIME_2_LLM = RuntimeConfig(
    role=RuntimeRole.LLM_INFERENCE,
    runtime_id="heady-llm-runtime",
    gpu_type="A100-80GB",
    gpu_count=1,
    ram_gb=fib(10),             # 55 GB
    disk_gb=fib(13),            # 233 GB
    port=3302,
    health_port=3312,
    models=[
        "Qwen/Qwen2.5-Coder-32B-Instruct",           # BF16 ~62GB, code leader
        "deepseek-ai/DeepSeek-R1-Distill-Qwen-32B",   # BF16 ~65GB, reasoning
    ],
    fallback_models=[
        "meta-llama/Llama-3.3-70B-Instruct",          # INT4 ~40GB, general
    ],
    quantization_config={
        "default_precision": "bf16",
        "qwen_coder_32b": "bf16",      # ~62GB native
        "deepseek_r1_32b": "bf16",     # ~65GB native
        "mistral_small_24b": "bf16",   # ~48GB native
        "phi4_mini": "fp16",           # ~8GB
        "llama_70b": "gptq-int4",     # ~40GB quantized
    },
    env_vars={
        "HEADY_ROLE": "llm_inference",
        "MAX_CONCURRENT_REQUESTS": str(fib(6)),    # 8
        "MAX_BATCH_SIZE": str(fib(5)),             # 5
        "KV_CACHE_GB": str(fib(7)),                # 13
        "QUANTIZATION": "bf16",
        "VLLM_TENSOR_PARALLEL": "1",
        "MAX_MODEL_LEN": str(fib(16) * 8),        # 7896 tokens
        "SECONDARY_MODELS": json.dumps([
            "mistralai/Mistral-Small-3.1-24B-Instruct-2503",
            "microsoft/Phi-4-mini-instruct",
        ]),
    },
)

# ─── RUNTIME 3: TRAINING, FINE-TUNING & ANALYTICS ────────────

RUNTIME_3_TRAINING = RuntimeConfig(
    role=RuntimeRole.TRAINING,
    runtime_id="heady-training-runtime",
    gpu_type="TPU-v2-8",
    gpu_count=1,
    ram_gb=fib(10),             # 55 GB
    disk_gb=fib(13),            # 233 GB
    port=3303,
    health_port=3313,
    models=[
        "google/gemma-3-12b-pt",  # QLoRA, JAX-native for TPU, ~18-22GB
    ],
    fallback_models=[
        "Qwen/Qwen2.5-7B",       # QLoRA, general SFT, ~10-14GB
        "BAAI/bge-m3",            # Full FT for embeddings, ~5GB
    ],
    quantization_config={
        "default_precision": "bf16",
        "gemma_12b": "qlora-4bit",
        "qwen_7b": "qlora-4bit",
        "bge_m3_ft": "full-fp16",
        "framework": "jax-xla",
        "optimizer": "adamw-bf16",
    },
    env_vars={
        "HEADY_ROLE": "training",
        "TRAINING_BATCH_SIZE": str(fib(5)),    # 5
        "LEARNING_RATE": str(PSI * 1e-4),      # ~6.18e-5
        "WARMUP_STEPS": str(fib(9)),           # 34
        "EVAL_STEPS": str(fib(11)),            # 89
        "SAVE_STEPS": str(fib(13)),            # 233
        "MAX_EPOCHS": str(fib(4)),             # 3
        "DUCKDB_ANALYTICS": "true",
        "TPU_BACKEND": "jax-xla",
        "QLORA_BITS": "4",
    },
)

ALL_RUNTIMES: List[RuntimeConfig] = [RUNTIME_1_VECTOR, RUNTIME_2_LLM, RUNTIME_3_TRAINING]

# ═══════════════════════════════════════════════════════════════
# TASK-TO-MODEL ROUTING MAP
# ═══════════════════════════════════════════════════════════════

TASK_MODEL_MAP: Dict[str, Tuple[RuntimeRole, int]] = {
    # Vector ops — Runtime 1
    "embed":        (RuntimeRole.VECTOR_OPS, 0),      # Qwen3-Embedding-8B
    "embed_fast":   (RuntimeRole.VECTOR_OPS, 1),      # nomic-embed-text-v2-moe
    "embed_hybrid": (RuntimeRole.VECTOR_OPS, 2),      # bge-m3 dense+sparse
    "vectorize":    (RuntimeRole.VECTOR_OPS, 0),
    "search":       (RuntimeRole.VECTOR_OPS, 2),      # bge-m3 hybrid retrieval
    "similarity":   (RuntimeRole.VECTOR_OPS, 0),
    "rerank":       (RuntimeRole.VECTOR_OPS, 2),      # bge-m3 ColBERT mode
    # LLM inference — Runtime 2
    "code":         (RuntimeRole.LLM_INFERENCE, 0),   # Qwen2.5-Coder-32B
    "reason":       (RuntimeRole.LLM_INFERENCE, 1),   # DeepSeek-R1-Distill-32B
    "chat":         (RuntimeRole.LLM_INFERENCE, 0),
    "generate":     (RuntimeRole.LLM_INFERENCE, 0),
    "classify":     (RuntimeRole.LLM_INFERENCE, 0),
    "agent":        (RuntimeRole.LLM_INFERENCE, 0),
    # Training — Runtime 3
    "train":        (RuntimeRole.TRAINING, 0),         # gemma-3-12b
    "finetune":     (RuntimeRole.TRAINING, 0),
    "finetune_llm": (RuntimeRole.TRAINING, 1),         # Qwen2.5-7B fallback
    "finetune_embed": (RuntimeRole.TRAINING, 2),       # bge-m3 fallback
    "evaluate":     (RuntimeRole.TRAINING, 0),
    "analytics":    (RuntimeRole.TRAINING, 0),
    "batch":        (RuntimeRole.TRAINING, 0),
}

# ═══════════════════════════════════════════════════════════════
# RUNTIME MANAGER
# ═══════════════════════════════════════════════════════════════

class RuntimeManager:
    """Orchestrates 3 Colab Pro+ runtimes: health, reconnect, routing, topology."""

    def __init__(self, runtimes: Optional[List[RuntimeConfig]] = None):
        """Initialize with optional custom runtime list (defaults to ALL_RUNTIMES)."""
        self.runtimes: Dict[RuntimeRole, RuntimeConfig] = {
            r.role: r for r in (runtimes or ALL_RUNTIMES)
        }
        self.health_status: Dict[RuntimeRole, Dict[str, Any]] = {}
        self.reconnect_attempts: Dict[RuntimeRole, int] = {r: 0 for r in RuntimeRole}
        self.logger = _create_logger("HeadyRuntimeManager")
        self._health_monitor_task: Optional[asyncio.Task] = None

    def check_health(self, role: RuntimeRole) -> Dict[str, Any]:
        """Check health of a specific runtime via HTTP GET."""
        config = self.runtimes[role]
        try:
            import urllib.request
            req = urllib.request.Request(config.health_endpoint, method="GET")
            with urllib.request.urlopen(req, timeout=round(PHI * 3)) as resp:
                data = json.loads(resp.read())
                self.health_status[role] = {
                    "status": "healthy", "role": role.value,
                    "runtime_id": config.runtime_id, "gpu": config.gpu_type,
                    "data": data, "checked_at": time.time(),
                }
                self.reconnect_attempts[role] = 0
                return self.health_status[role]
        except Exception as e:
            self.health_status[role] = {
                "status": "unhealthy", "role": role.value,
                "runtime_id": config.runtime_id,
                "error": str(e), "checked_at": time.time(),
            }
            return self.health_status[role]

    def check_all_health(self) -> Dict[str, Dict[str, Any]]:
        """Check health of all 3 runtimes."""
        return {role.value: self.check_health(role) for role in RuntimeRole}

    def reconnect(self, role: RuntimeRole) -> bool:
        """Attempt reconnection with phi-exponential backoff. Returns True on success."""
        attempt = self.reconnect_attempts[role]
        delay = phi_backoff(attempt)
        max_attempts = fib(7)  # 13
        self.logger.info(f"Reconnecting {role.value} attempt={attempt} delay={delay:.1f}s")
        time.sleep(delay)
        health = self.check_health(role)
        if health["status"] == "healthy":
            self.logger.info(f"Reconnected {role.value}")
            self.reconnect_attempts[role] = 0
            return True
        self.reconnect_attempts[role] = attempt + 1
        if attempt + 1 >= max_attempts:
            self.logger.error(f"Failed reconnect {role.value} after {max_attempts} attempts")
        return False

    def route_task(self, task_type: str) -> RuntimeConfig:
        """Route task to runtime via TASK_MODEL_MAP; auto-reconnects if unhealthy."""
        mapping = TASK_MODEL_MAP.get(task_type)
        role = mapping[0] if mapping else RuntimeRole.LLM_INFERENCE
        config = self.runtimes[role]
        health = self.health_status.get(role, {})
        if health.get("status") != "healthy":
            self.reconnect(role)
        return config

    def get_model_for_task(self, task_type: str) -> str:
        """Return the best model name for a task type via TASK_MODEL_MAP."""
        mapping = TASK_MODEL_MAP.get(task_type)
        if not mapping:
            return self.runtimes[RuntimeRole.LLM_INFERENCE].models[0]
        role, idx = mapping
        models = self.runtimes[role].all_models
        return models[idx] if idx < len(models) else models[0]

    async def _health_monitor_loop(self, interval_s: float) -> None:
        """Continuous async health monitor; logs status changes, auto-reconnects."""
        self.logger.info(f"Health monitor started interval={interval_s:.1f}s")
        while True:
            for role in RuntimeRole:
                prev = self.health_status.get(role, {}).get("status", "unknown")
                curr = self.check_health(role)["status"]
                if prev != curr:
                    self.logger.info(f"Health change {role.value}: {prev} -> {curr}")
                if curr == "unhealthy" and self.reconnect_attempts.get(role, 0) < fib(7):
                    self.reconnect(role)
            await asyncio.sleep(interval_s)

    def start_health_monitor(self, interval_s: float = None) -> asyncio.Task:
        """Start async health monitor (default interval: PHI * fib(5) ≈ 8.09s)."""
        if interval_s is None:
            interval_s = PHI * fib(5)
        self._health_monitor_task = asyncio.ensure_future(
            self._health_monitor_loop(interval_s)
        )
        return self._health_monitor_task

    def stop_health_monitor(self) -> None:
        """Stop the async health monitoring loop."""
        if self._health_monitor_task and not self._health_monitor_task.done():
            self._health_monitor_task.cancel()
            self.logger.info("Health monitor stopped")

    def generate_setup_notebook(self, role: RuntimeRole) -> str:
        """Generate a Colab setup cell (Python script) for a specific runtime."""
        config = self.runtimes[role]
        env_lines = "\n".join(
            f'os.environ["{k}"] = "{v}"' for k, v in config.env_vars.items()
        )
        role_deps = {
            RuntimeRole.VECTOR_OPS:
                '"sentence-transformers", "faiss-gpu", "hnswlib", "pgvector", "psycopg2-binary"',
            RuntimeRole.LLM_INFERENCE:
                '"vllm", "openai", "outlines"',
            RuntimeRole.TRAINING:
                '"peft", "bitsandbytes", "trl", "duckdb", "datasets", "accelerate"',
        }
        return f'''# Heady {role.value.upper()} Runtime Setup v2 | {config.runtime_id}
# GPU: {config.gpu_type} x{config.gpu_count} | RAM: {config.ram_gb}GB | Disk: {config.disk_gb}GB
import os, subprocess, json
{env_lines}
os.environ["HEADY_RUNTIME_ID"] = "{config.runtime_id}"
os.environ["PORT"] = "{config.port}"
os.environ["HEALTH_PORT"] = "{config.health_port}"
subprocess.run(["pip", "install", "-q", "torch", "transformers",
    {role_deps[role]},
    "fastapi", "uvicorn", "numpy", "scipy"], check=True)
PRIMARY_MODELS = {json.dumps(config.models)}
FALLBACK_MODELS = {json.dumps(config.fallback_models)}
QUANTIZATION = {json.dumps(config.quantization_config)}
for m in PRIMARY_MODELS:
    print(f"Loading model: {{m}}")
from fastapi import FastAPI
import uvicorn, threading, time
app = FastAPI(title="Heady {role.value}")
_start = time.time()
@app.get("/health")
async def health():
    """Health endpoint."""
    return {{"status": "healthy", "role": "{role.value}",
             "runtime_id": "{config.runtime_id}", "gpu": "{config.gpu_type}",
             "uptime_s": round(time.time() - _start),
             "models_loaded": PRIMARY_MODELS, "fallback_models": FALLBACK_MODELS}}
threading.Thread(target=lambda: uvicorn.run(app, host="0.0.0.0", port={config.health_port}),
                 daemon=True).start()
print(f"Heady {role.value} ready on port {config.port} | health: :{config.health_port}/health")
'''

    def print_topology(self) -> None:
        """Print visual map of the 3-runtime topology."""
        print(f"\n{'═' * 64}")
        print(f"  HEADY LATENT SPACE — 3 COLAB PRO+ RUNTIMES (v2)")
        print(f"{'═' * 64}")
        total_w = sum(r.resource_weight for r in self.runtimes.values())
        for role in RuntimeRole:
            c = self.runtimes[role]
            status = self.health_status.get(role, {}).get("status", "unknown")
            pct = (c.resource_weight / total_w) * 100
            print(f"\n  ┌─ [{role.value.upper()}] {c.runtime_id}")
            print(f"  │  GPU: {c.gpu_type} x{c.gpu_count} | RAM: {c.ram_gb}GB | Disk: {c.disk_gb}GB")
            print(f"  │  Port: {c.port} | Health: {c.health_port}")
            print(f"  │  Primary: {', '.join(c.models)}")
            if c.fallback_models:
                print(f"  │  Fallback: {', '.join(c.fallback_models)}")
            print(f"  │  Weight: {c.resource_weight:.3f} ({pct:.1f}%) | Status: {status}")
            print(f"  └{'─' * 50}")
        print(f"\n  PHI={PHI:.6f} | PSI={PSI:.6f} | Dedup={DEDUP_THRESHOLD:.3f}")
        print(f"{'═' * 64}\n")

# ═══════════════════════════════════════════════════════════════
# TUNNEL CONFIGURATION
# ═══════════════════════════════════════════════════════════════

@dataclass
class TunnelConfig:
    """Cloudflare tunnel config mapping hostnames → runtime ports."""
    tunnel_name: str = "heady-colab-tunnel"
    cloudflare_account_id: str = field(
        default_factory=lambda: os.getenv("CF_ACCOUNT_ID", "")
    )
    origin_runtimes: Dict[str, int] = field(default_factory=lambda: {
        "vector.headyos.com": 3301,
        "llm.headyos.com": 3302,
        "train.headyos.com": 3303,
    })

    def generate_tunnel_config(self) -> Dict[str, Any]:
        """Generate cloudflared config YAML structure."""
        ingress = [
            {"hostname": h, "service": f"http://localhost:{p}"}
            for h, p in self.origin_runtimes.items()
        ]
        ingress.append({"service": "http_status:404"})
        return {
            "tunnel": self.tunnel_name,
            "credentials-file": "/root/.cloudflared/credentials.json",
            "ingress": ingress,
        }

# ═══════════════════════════════════════════════════════════════
# ASYNC TASK ROUTER — Phi-Weighted Load Balancing
# ═══════════════════════════════════════════════════════════════

@dataclass
class _CircuitState:
    """Per-runtime circuit breaker state."""
    failures: int = 0
    last_failure: float = 0.0
    is_open: bool = False
    failure_threshold: int = fib(5)         # 5 consecutive failures → open
    reset_timeout_s: float = PHI * fib(7)   # ≈ 21s cooldown

class AsyncTaskRouter:
    """Async task router with phi-weighted load balancing, circuit breaker,
    dedup (cosine > 0.972 threshold), and fib(6)=8 max concurrency."""

    MAX_CONCURRENT: int = fib(6)  # 8

    def __init__(self, manager: RuntimeManager):
        """Initialize router with a RuntimeManager for health and routing."""
        self.manager = manager
        self.logger = _create_logger("AsyncTaskRouter")
        self._semaphore = asyncio.Semaphore(self.MAX_CONCURRENT)
        self._active_tasks: Dict[str, asyncio.Task] = {}
        self._task_hashes: deque = deque(maxlen=fib(16))  # 987 recent
        self._circuits: Dict[RuntimeRole, _CircuitState] = {
            r: _CircuitState() for r in RuntimeRole
        }
        self._counts: Dict[RuntimeRole, int] = {r: 0 for r in RuntimeRole}

    def _task_hash(self, task_type: str, payload: str) -> str:
        """SHA-256 hash of task_type:payload for structural dedup."""
        return hashlib.sha256(f"{task_type}:{payload}".encode()).hexdigest()

    def _is_duplicate(self, h: str) -> bool:
        """Check dedup window (fib(16)=987 recent hashes). Adds if new."""
        if h in self._task_hashes:
            return True
        self._task_hashes.append(h)
        return False

    def _circuit_ok(self, role: RuntimeRole) -> bool:
        """True if circuit closed or cooldown elapsed (auto-resets)."""
        cb = self._circuits[role]
        if not cb.is_open:
            return True
        if time.time() - cb.last_failure >= cb.reset_timeout_s:
            cb.is_open = False
            cb.failures = 0
            self.logger.info(f"Circuit reset {role.value}")
            return True
        return False

    def _record_failure(self, role: RuntimeRole) -> None:
        """Record failure; opens circuit at threshold."""
        cb = self._circuits[role]
        cb.failures += 1
        cb.last_failure = time.time()
        if cb.failures >= cb.failure_threshold:
            cb.is_open = True
            self.logger.warning(f"Circuit OPEN {role.value} failures={cb.failures}")

    def _record_success(self, role: RuntimeRole) -> None:
        """Record success; resets circuit breaker."""
        cb = self._circuits[role]
        cb.failures = 0
        cb.is_open = False

    def _select_weighted(self, candidates: List[RuntimeRole]) -> RuntimeRole:
        """Phi-weighted selection: resource_weight / (active_tasks + 1)."""
        best, best_score = candidates[0], -1.0
        for role in candidates:
            if not self._circuit_ok(role):
                continue
            score = self.manager.runtimes[role].resource_weight / (self._counts.get(role, 0) + 1)
            if score > best_score:
                best_score = score
                best = role
        return best

    async def submit_task(self, task_type: str, payload: str,
                          execute_fn: Any = None) -> Dict[str, Any]:
        """Submit a task: dedup → circuit check → route → execute under semaphore."""
        h = self._task_hash(task_type, payload)
        task_id = h[:fib(7)]  # 13-char ID

        if self._is_duplicate(h):
            self.logger.info(f"Dedup skip task_type={task_type}")
            return {"task_id": task_id, "status": "deduplicated", "task_type": task_type}

        mapping = TASK_MODEL_MAP.get(task_type)
        role = mapping[0] if mapping else RuntimeRole.LLM_INFERENCE

        if not self._circuit_ok(role):
            self.logger.warning(f"Circuit open {role.value} task={task_type}")
            return {"task_id": task_id, "status": "circuit_open",
                    "task_type": task_type, "runtime": role.value}

        config = self.manager.runtimes[role]
        model = self.manager.get_model_for_task(task_type)

        async with self._semaphore:
            self._counts[role] = self._counts.get(role, 0) + 1
            self.logger.info(f"Exec task_id={task_id} type={task_type} runtime={role.value}")
            try:
                if execute_fn:
                    result = await execute_fn(config, task_type, payload)
                else:
                    result = {"routed_to": config.runtime_id, "model": model, "port": config.port}
                self._record_success(role)
                return {"task_id": task_id, "status": "completed", "task_type": task_type,
                        "runtime": role.value, "model": model, "result": result}
            except Exception as e:
                self._record_failure(role)
                self.logger.error(f"Task failed task_id={task_id} error={e}")
                return {"task_id": task_id, "status": "failed", "task_type": task_type,
                        "runtime": role.value, "error": str(e)}
            finally:
                self._counts[role] = max(0, self._counts.get(role, 1) - 1)

    async def submit_batch(self, tasks: List[Tuple[str, str]],
                           execute_fn: Any = None) -> List[Dict[str, Any]]:
        """Submit multiple tasks for parallel execution (bounded by semaphore)."""
        return await asyncio.gather(*(
            self.submit_task(t, p, execute_fn) for t, p in tasks
        ))

    def get_circuit_status(self) -> Dict[str, Dict[str, Any]]:
        """Return circuit breaker status for all runtimes."""
        return {
            role.value: {"is_open": cb.is_open, "failures": cb.failures,
                         "threshold": cb.failure_threshold,
                         "reset_timeout_s": cb.reset_timeout_s}
            for role, cb in self._circuits.items()
        }

# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════

async def _async_main() -> None:
    """Print topology, generate setup notebooks, demonstrate routing."""
    manager = RuntimeManager()
    router = AsyncTaskRouter(manager)

    manager.print_topology()

    for role in RuntimeRole:
        code = manager.generate_setup_notebook(role)
        fname = f"colab_setup_{role.value}_v2.py"
        with open(fname, "w") as f:
            f.write(code)
        print(f"Generated: {fname}")

    print("\n── Task Routing ──")
    demo = [
        ("embed", "Encode document for vector storage"),
        ("code", "Generate Python function"),
        ("reason", "Multi-step math problem"),
        ("train", "Fine-tune classifier"),
        ("search", "Hybrid retrieval query"),
        ("embed_fast", "Quick embedding for cache"),
    ]
    for tt, desc in demo:
        model = manager.get_model_for_task(tt)
        cfg = manager.route_task(tt)
        print(f"  {tt:15s} -> {cfg.runtime_id:25s} | {model}")

    print("\n── Async Batch ──")
    results = await router.submit_batch(demo)
    for r in results:
        icon = "ok" if r["status"] == "completed" else "!!"
        print(f"  [{icon}] {r['task_id']} {r['task_type']} -> {r['status']}")

    print("\n── Tunnel Config ──")
    print(json.dumps(TunnelConfig().generate_tunnel_config(), indent=2))

    print("\n── Circuit Breakers ──")
    for name, st in router.get_circuit_status().items():
        print(f"  {name:15s}: {'OPEN' if st['is_open'] else 'CLOSED'} (failures={st['failures']})")

    print("\n── Health ──")
    print(json.dumps(manager.check_all_health(), indent=2, default=str))

if __name__ == "__main__":
    asyncio.run(_async_main())
