/**
 * Heady Liquid Node Architecture v2 — Production Implementation
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Every component in the Heady ecosystem is a LiquidNode — a self-aware,
 * self-healing unit that operates in 384D vector space with phi-scaled
 * parameters and CSL-gated decision logic.
 *
 * v2 enhancements: full Sacred Geometry topology, SwarmCoordinator,
 * HCFullPipeline, capabilities routing, inter-node dependencies, BeeNode
 * circuit breakers, and bootHeadyOS() orchestration.
 *
 * @module liquid-nodes-v2
 * @version 5.0.0
 */

'use strict';

const EventEmitter = require('events');
const {
  PHI, PSI, PHI2, PHI3, FIB, fib,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD, DEDUP_THRESHOLD,
  phiBackoff, phiAdaptiveInterval, phiFusionWeights, phiPriorityScore,
  cslGate, cslBlend, cosineSimilarity, cslCONSENSUS,
  SIZING, POOL_SIZES, RESOURCE_WEIGHTS,
  PHI_TEMPERATURE,
} = require('./phi-constants');

// ═══════════════════════════════════════════════════════════════
// EVENT BUS — Inter-node Communication
// ═══════════════════════════════════════════════════════════════

/** @type {EventEmitter} Global event bus for inter-node communication */
const nodeBus = new EventEmitter();
nodeBus.setMaxListeners(fib(10)); // 55

// ═══════════════════════════════════════════════════════════════
// STRUCTURED LOGGER
// ═══════════════════════════════════════════════════════════════

/**
 * Create a structured JSON logger bound to a service name.
 * @param {string} service - Service/node identifier
 * @returns {{ info: Function, warn: Function, error: Function, debug: Function }}
 */
function createLogger(service) {
  const _log = (level, data, msg) => {
    const entry = {
      timestamp: new Date().toISOString(),
      level,
      service,
      correlationId: data?.correlationId || null,
      msg: msg || data?.message || '',
      ...(typeof data === 'object' && data !== null ? data : {}),
    };
    delete entry.message;
    const out = level === 'error' ? process.stderr : process.stdout;
    out.write(JSON.stringify(entry) + '\n');
  };
  return {
    info:  (data, msg) => _log('info', data, msg),
    warn:  (data, msg) => _log('warn', data, msg),
    error: (data, msg) => _log('error', data, msg),
    debug: (data, msg) => _log('debug', data, msg),
  };
}

// ═══════════════════════════════════════════════════════════════
// NODE LIFECYCLE STATE MACHINE
// ═══════════════════════════════════════════════════════════════

/**
 * Valid lifecycle states.
 * Flow: init → active → thinking → responding → idle → hibernating → expired
 * @enum {string}
 */
const LIFECYCLE_STATES = Object.freeze({
  INIT:        'init',
  ACTIVE:      'active',
  THINKING:    'thinking',
  RESPONDING:  'responding',
  IDLE:        'idle',
  HIBERNATING: 'hibernating',
  EXPIRED:     'expired',
});

/** @type {Record<string, string[]>} Valid state transitions */
const VALID_TRANSITIONS = Object.freeze({
  init:        ['active', 'expired'],
  active:      ['thinking', 'idle', 'expired'],
  thinking:    ['responding', 'active', 'expired'],
  responding:  ['active', 'idle', 'expired'],
  idle:        ['active', 'hibernating', 'expired'],
  hibernating: ['active', 'expired'],
  expired:     [],
});

// ═══════════════════════════════════════════════════════════════
// LIQUID NODE BASE CLASS
// ═══════════════════════════════════════════════════════════════

/**
 * LiquidNode — The foundational unit of the Heady ecosystem.
 * Every service, agent, bee, and component extends this class.
 *
 * Features:
 * - 384D embedding space with deterministic seeding
 * - Heartbeat with semantic drift detection
 * - CSL-gated task evaluation
 * - LIFO cleanup stack for graceful shutdown
 * - Structured JSON logging
 * - Health endpoint generation
 * - Metrics tracking
 * - Capabilities array for CSL-scored routing
 * - Dependencies map for inter-node data flow
 * - Async event-driven task handling via nodeBus
 */
class LiquidNode {
  /**
   * @param {Object} config
   * @param {string} config.name - Node identifier
   * @param {string} config.ring - Topology ring (center|inner|middle|outer|governance|memory)
   * @param {string} config.pool - Resource pool (hot|warm|cold|reserve|governance)
   * @param {string} [config.domain='headyme.com'] - Primary domain affiliation
   * @param {number[]} [config.embedding] - Initial 384D embedding vector
   * @param {string[]} [config.capabilities=[]] - Capability tags for CSL-scored routing
   * @param {Object<string,string>} [config.dependencies={}] - Inter-node data flow dependencies
   */
  constructor(config) {
    this.name = config.name;
    this.ring = config.ring;
    this.pool = config.pool;
    this.domain = config.domain || 'headyme.com';
    this.embedding = config.embedding || this._generateInitialEmbedding();
    this.capabilities = config.capabilities || [];
    this.dependencies = config.dependencies || {};
    this.state = LIFECYCLE_STATES.INIT;
    this.coherenceScore = 1.0;
    this.logger = createLogger(this.name);
    this.startTime = Date.now();
    this.lastHeartbeat = Date.now();
    this.heartbeatInterval = null;
    this.cleanupStack = [];
    this.metrics = {
      requestsHandled: 0,
      errorsEncountered: 0,
      avgResponseMs: 0,
      uptimeMs: 0,
      driftEvents: 0,
    };

    nodeBus.on(`${this.name}:task`, (task) => this._handleTask(task));
    this.cleanupStack.push(() => nodeBus.removeAllListeners(`${this.name}:task`));
  }

  // ─────────────────────────────────────────────────────────────
  // LIFECYCLE MANAGEMENT
  // ─────────────────────────────────────────────────────────────

  /**
   * Transition to a new lifecycle state.
   * @param {string} newState - Target state from LIFECYCLE_STATES
   * @throws {Error} If the transition is not permitted
   */
  transition(newState) {
    const valid = VALID_TRANSITIONS[this.state];
    if (!valid || !valid.includes(newState)) {
      throw new Error(`Invalid transition: ${this.state} → ${newState} for node ${this.name}`);
    }
    const oldState = this.state;
    this.state = newState;
    this.logger.info({ oldState, newState }, 'State transition');
    nodeBus.emit('node:transition', { node: this.name, from: oldState, to: newState });
  }

  /**
   * Initialize the node — register embedding, start heartbeat, go active.
   * @returns {Promise<void>}
   */
  async init() {
    this.logger.info({ ring: this.ring, pool: this.pool, capabilities: this.capabilities }, 'Initializing node');
    await this._registerEmbedding();
    const heartbeatMs = Math.round(PHI * 1000 * fib(5)); // ~8090ms
    this.heartbeatInterval = setInterval(() => this.heartbeat(), heartbeatMs);
    this.cleanupStack.push(() => clearInterval(this.heartbeatInterval));
    this.transition(LIFECYCLE_STATES.ACTIVE);
    this.logger.info({}, 'Node initialized and active');
  }

  /**
   * Heartbeat — re-embed, check drift, emit health telemetry.
   * @returns {Promise<void>}
   */
  async heartbeat() {
    this.lastHeartbeat = Date.now();
    this.metrics.uptimeMs = Date.now() - this.startTime;
    const currentEmbedding = await this._computeCurrentEmbedding();
    const similarity = cosineSimilarity(this.embedding, currentEmbedding);
    this.coherenceScore = similarity;

    if (similarity < COHERENCE_DRIFT_THRESHOLD) {
      this.metrics.driftEvents++;
      this.logger.warn({ coherence: similarity, threshold: COHERENCE_DRIFT_THRESHOLD, driftEvents: this.metrics.driftEvents }, 'Semantic drift detected');
      nodeBus.emit('node:drift', { node: this.name, coherence: similarity, threshold: COHERENCE_DRIFT_THRESHOLD });
    }

    nodeBus.emit('node:heartbeat', { node: this.name, state: this.state, coherence: this.coherenceScore, metrics: this.metrics });
  }

  /**
   * Generate health check data for this node.
   * @returns {Object} Health status object
   */
  health() {
    const uptimeMs = Date.now() - this.startTime;
    return {
      service: this.name,
      status: this.state === LIFECYCLE_STATES.EXPIRED ? 'down' : 'up',
      state: this.state,
      ring: this.ring,
      pool: this.pool,
      capabilities: this.capabilities,
      coherence: this.coherenceScore,
      coherenceThreshold: COHERENCE_DRIFT_THRESHOLD,
      driftDetected: this.coherenceScore < COHERENCE_DRIFT_THRESHOLD,
      uptime: { ms: uptimeMs, human: this._formatUptime(uptimeMs) },
      lastHeartbeat: new Date(this.lastHeartbeat).toISOString(),
      metrics: { ...this.metrics },
      version: process.env.npm_package_version || '5.0.0',
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Graceful shutdown — LIFO cleanup of all registered resources.
   * @param {string} [signal='SIGTERM'] - Signal that triggered shutdown
   * @returns {Promise<void>}
   */
  async shutdown(signal = 'SIGTERM') {
    this.logger.info({ signal }, 'Graceful shutdown initiated');
    while (this.cleanupStack.length > 0) {
      const cleanup = this.cleanupStack.pop();
      try { await cleanup(); } catch (err) {
        this.logger.error({ error: err.message }, 'Cleanup step failed');
      }
    }
    this.transition(LIFECYCLE_STATES.EXPIRED);
    this.logger.info({}, 'Shutdown complete');
  }

  // ─────────────────────────────────────────────────────────────
  // CSL-GATED DECISION MAKING
  // ─────────────────────────────────────────────────────────────

  /**
   * Evaluate whether this node should handle a given task.
   * @param {number[]} taskEmbedding - 384D task embedding
   * @returns {number} Gated relevance score (0 to 1)
   */
  evaluateTask(taskEmbedding) {
    const similarity = cosineSimilarity(this.embedding, taskEmbedding);
    return cslGate(1.0, similarity, CSL_THRESHOLDS.LOW);
  }

  /**
   * Score this node against a specific capability query.
   * @param {number[]} capabilityEmbedding - Embedding of the desired capability
   * @returns {number} CSL-gated capability match score
   */
  evaluateCapability(capabilityEmbedding) {
    const similarity = cosineSimilarity(this.embedding, capabilityEmbedding);
    return cslGate(1.0, similarity, CSL_THRESHOLDS.MEDIUM);
  }

  /**
   * Check if this node is healthy enough to accept work.
   * @returns {boolean}
   */
  canAcceptWork() {
    return this.state === LIFECYCLE_STATES.ACTIVE && this.coherenceScore >= CSL_THRESHOLDS.MINIMUM;
  }

  // ─────────────────────────────────────────────────────────────
  // INTERNAL METHODS
  // ─────────────────────────────────────────────────────────────

  /** @private Generate deterministic 384D embedding from node name */
  _generateInitialEmbedding() {
    const dim = 384;
    const vec = new Array(dim);
    let seed = 0;
    for (let i = 0; i < this.name.length; i++) seed += this.name.charCodeAt(i);
    for (let i = 0; i < dim; i++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      vec[i] = (seed / 0x7fffffff - PSI) * PHI;
    }
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    return vec.map(v => v / norm);
  }

  /** @private Register embedding in vector memory */
  async _registerEmbedding() {
    this.logger.info({ dimensions: this.embedding.length }, 'Embedding registered');
  }

  /** @private Re-embed current state for drift detection */
  async _computeCurrentEmbedding() {
    return this.embedding;
  }

  /** @private Handle an incoming task via the event bus */
  async _handleTask(task) {
    if (!this.canAcceptWork()) {
      this.logger.warn({ task: task?.id }, 'Cannot accept work in current state');
      return null;
    }
    const start = Date.now();
    try {
      this.transition(LIFECYCLE_STATES.THINKING);
      const result = await this.execute(task);
      this.transition(LIFECYCLE_STATES.RESPONDING);
      this.metrics.requestsHandled++;
      const elapsed = Date.now() - start;
      this.metrics.avgResponseMs =
        (this.metrics.avgResponseMs * (this.metrics.requestsHandled - 1) + elapsed) /
        this.metrics.requestsHandled;
      this.transition(LIFECYCLE_STATES.ACTIVE);
      return result;
    } catch (err) {
      this.metrics.errorsEncountered++;
      this.logger.error({ error: err.message, task: task?.id }, 'Task execution failed');
      if (this.state !== LIFECYCLE_STATES.ACTIVE) {
        this.state = LIFECYCLE_STATES.ACTIVE; // force recovery
      }
      throw err;
    }
  }

  /**
   * Override in subclasses to implement task execution.
   * @param {Object} task - Task to execute
   * @returns {Promise<*>} Task result
   */
  async execute(task) {
    throw new Error(`${this.name}: execute() not implemented`);
  }

  /** @private Format milliseconds to human-readable uptime string */
  _formatUptime(ms) {
    const s = Math.floor(ms / 1000);
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    return `${d}d ${h}h ${m}m`;
  }
}

// ═══════════════════════════════════════════════════════════════
// CIRCUIT BREAKER — Phi-scaled failure protection
// ═══════════════════════════════════════════════════════════════

/** @enum {string} Circuit breaker states */
const CB_STATES = Object.freeze({ CLOSED: 'closed', OPEN: 'open', HALF_OPEN: 'half_open' });

/**
 * CircuitBreaker — Phi-scaled failure protection wrapper.
 * Trips after fib(5)=5 failures, probes with fib(3)=2 requests in half-open,
 * and uses phi-backoff for reset timing.
 */
class CircuitBreaker {
  /**
   * @param {Object} config
   * @param {string} config.name - Breaker identifier
   * @param {number} [config.failureThreshold=5] - Failures to trip (fib(5))
   * @param {number} [config.resetTimeoutMs] - Open duration before half-open probe
   * @param {number} [config.halfOpenProbes=2] - Successful probes to close (fib(3))
   */
  constructor(config) {
    this.name = config.name;
    this.failureThreshold = config.failureThreshold || SIZING.FAILURE_THRESHOLD;
    this.resetTimeoutMs = config.resetTimeoutMs || Math.round(1000 * PSI * fib(8));
    this.halfOpenProbes = config.halfOpenProbes || fib(3);
    this.state = CB_STATES.CLOSED;
    this.failures = 0;
    this.successes = 0;
    this.lastFailure = 0;
    this.retryAttempt = 0;
    this.logger = createLogger(`CB:${this.name}`);
  }

  /**
   * Execute a function through the circuit breaker.
   * @param {Function} fn - Async function to protect
   * @returns {Promise<*>} Function result
   * @throws {Error} If circuit is open and reset timeout has not elapsed
   */
  async exec(fn) {
    if (this.state === CB_STATES.OPEN) {
      const elapsed = Date.now() - this.lastFailure;
      const timeout = phiBackoff(this.retryAttempt, this.resetTimeoutMs, this.resetTimeoutMs * fib(5), false);
      if (elapsed > timeout) {
        this.state = CB_STATES.HALF_OPEN;
        this.successes = 0;
        this.retryAttempt++;
        this.logger.info({ retryAttempt: this.retryAttempt }, 'Transitioning to half-open');
      } else {
        throw new Error(`Circuit breaker ${this.name} is OPEN`);
      }
    }

    try {
      const result = await fn();
      if (this.state === CB_STATES.HALF_OPEN) {
        this.successes++;
        if (this.successes >= this.halfOpenProbes) {
          this.state = CB_STATES.CLOSED;
          this.failures = 0;
          this.retryAttempt = 0;
          this.logger.info({}, 'Circuit closed (recovered)');
        }
      } else {
        this.failures = 0;
      }
      return result;
    } catch (err) {
      this.failures++;
      this.lastFailure = Date.now();
      if (this.failures >= this.failureThreshold) {
        this.state = CB_STATES.OPEN;
        this.logger.warn({ failures: this.failures }, 'Circuit OPEN');
      }
      throw err;
    }
  }

  /**
   * Get circuit breaker health status.
   * @returns {{ name: string, state: string, failures: number, retryAttempt: number }}
   */
  health() {
    return { name: this.name, state: this.state, failures: this.failures, retryAttempt: this.retryAttempt };
  }
}

// ═══════════════════════════════════════════════════════════════
// NODE REGISTRY — Tracks all active nodes
// ═══════════════════════════════════════════════════════════════

/**
 * NodeRegistry — Central registry for all active LiquidNodes.
 * Supports lookup by ring, pool, and capability, plus CSL-scored routing.
 */
class NodeRegistry {
  constructor() {
    /** @type {Map<string, LiquidNode>} */
    this.nodes = new Map();
    this.logger = createLogger('NodeRegistry');
  }

  /**
   * Register a node in the registry.
   * @param {LiquidNode} node - Node to register
   */
  register(node) {
    this.nodes.set(node.name, node);
    this.logger.info({ node: node.name, ring: node.ring, pool: node.pool, total: this.nodes.size }, 'Registered');
  }

  /**
   * Deregister a node by name.
   * @param {string} name - Node name to remove
   */
  deregister(name) {
    this.nodes.delete(name);
    this.logger.info({ node: name, total: this.nodes.size }, 'Deregistered');
  }

  /**
   * Get a node by name.
   * @param {string} name - Node name
   * @returns {LiquidNode|undefined}
   */
  get(name) { return this.nodes.get(name); }

  /**
   * Get all nodes on a given topology ring.
   * @param {string} ring - Ring name (center|inner|middle|outer|governance|memory)
   * @returns {LiquidNode[]}
   */
  getByRing(ring) {
    return [...this.nodes.values()].filter(n => n.ring === ring);
  }

  /**
   * Get all nodes in a given resource pool.
   * @param {string} pool - Pool name (hot|warm|cold|reserve|governance)
   * @returns {LiquidNode[]}
   */
  getByPool(pool) {
    return [...this.nodes.values()].filter(n => n.pool === pool);
  }

  /**
   * Get all nodes possessing a given capability tag.
   * @param {string} capability - Capability string to match
   * @returns {LiquidNode[]}
   */
  getByCapability(capability) {
    return [...this.nodes.values()].filter(n => n.capabilities.includes(capability));
  }

  /**
   * Aggregate health of all registered nodes.
   * @returns {Object[]} Array of health objects
   */
  healthAll() {
    return [...this.nodes.values()].map(n => n.health());
  }

  /**
   * Route a task embedding to nodes, returning CSL-scored results.
   * @param {number[]} taskEmbedding - 384D task embedding vector
   * @returns {{ node: LiquidNode, score: number }[]} Nodes sorted by descending relevance
   */
  routeByCSL(taskEmbedding) {
    const scores = [];
    for (const node of this.nodes.values()) {
      if (!node.canAcceptWork()) continue;
      const score = node.evaluateTask(taskEmbedding);
      if (score > 0) scores.push({ node, score });
    }
    scores.sort((a, b) => b.score - a.score);
    return scores;
  }

  /** @returns {number} Total registered nodes */
  get size() { return this.nodes.size; }
}

// ═══════════════════════════════════════════════════════════════
// CENTER — SoulNode
// ═══════════════════════════════════════════════════════════════

/**
 * SoulNode (HeadySoul) — The awareness and values arbiter at the center.
 * Validates all mutations against the 3 Unbreakable Laws.
 */
class SoulNode extends LiquidNode {
  /**
   * @param {Object} [config={}] - Optional overrides
   */
  constructor(config = {}) {
    super({
      name: 'HeadySoul', ring: 'center', pool: 'governance',
      capabilities: ['validation', 'coherence-guardian', 'mission-alignment'],
      dependencies: {},
      ...config,
    });
    /** @type {string[]} The 3 Unbreakable Laws */
    this.laws = [
      'Structural Integrity: Code compiles, passes type checks, respects module boundaries',
      'Semantic Coherence: Changes stay within embedding tolerance of intended design',
      'Mission Alignment: Changes serve HeadyConnection mission (community, equity, empowerment)',
    ];
  }

  /**
   * Validate a mutation against the 3 Unbreakable Laws.
   * @param {Object} mutation - Proposed change with structurallyValid, semanticallyCoherent, missionAligned flags
   * @returns {{ valid: boolean, violations: string[] }}
   */
  validateMutation(mutation) {
    const violations = [];
    if (!mutation.structurallyValid) violations.push(this.laws[0]);
    if (!mutation.semanticallyCoherent) violations.push(this.laws[1]);
    if (!mutation.missionAligned) violations.push(this.laws[2]);
    return { valid: violations.length === 0, violations };
  }

  /** @override */
  async execute(task) {
    if (task.type === 'validate') return this.validateMutation(task.mutation);
    if (task.type === 'coherenceReview') return { reviewed: true, timestamp: new Date().toISOString() };
    throw new Error(`Unknown soul task type: ${task.type}`);
  }
}

// ═══════════════════════════════════════════════════════════════
// INNER RING — Hot Pool
// ═══════════════════════════════════════════════════════════════

/**
 * BrainsNode (HeadyBrains) — Context assembly and pre-processing.
 * Gathers relevant context from memory, session, and environment
 * before handing off to the conductor for routing.
 */
class BrainsNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'HeadyBrains', ring: 'inner', pool: 'hot',
      capabilities: ['context-assembly', 'pre-processing', 'intent-extraction'],
      dependencies: { memory: 'HeadyMemory', embed: 'HeadyEmbed' },
      ...config,
    });
  }

  /** @override */
  async execute(task) {
    const context = {
      taskId: task.id,
      assembledAt: new Date().toISOString(),
      inputTokens: task.input ? task.input.length : 0,
      contextLayers: ['session', 'memory', 'environment'],
    };
    this.logger.info({ taskId: task.id }, 'Context assembled');
    return context;
  }
}

/**
 * ConductorNode (HeadyConductor) — Central orchestration authority.
 * Classifies tasks, maintains the node registry, and routes via CSL scoring.
 */
class ConductorNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'HeadyConductor', ring: 'inner', pool: 'hot',
      capabilities: ['orchestration', 'routing', 'task-classification', 'node-registry'],
      dependencies: { soul: 'HeadySoul', brains: 'HeadyBrains' },
      ...config,
    });
    /** @type {Map<string, LiquidNode>} Registered worker nodes */
    this.registeredNodes = new Map();
  }

  /**
   * Register a node for task routing.
   * @param {LiquidNode} node - Node to register
   */
  registerNode(node) {
    this.registeredNodes.set(node.name, node);
    this.logger.info({ node: node.name, ring: node.ring, pool: node.pool }, 'Node registered');
  }

  /**
   * Route a task to the best matching nodes via CSL-gated scoring.
   * @param {Object} task - Task with an embedding field
   * @returns {LiquidNode[]} Matched nodes sorted by descending relevance
   */
  route(task) {
    const scores = [];
    for (const [, node] of this.registeredNodes) {
      if (!node.canAcceptWork()) continue;
      const score = node.evaluateTask(task.embedding);
      if (score > 0) scores.push({ node, score });
    }
    scores.sort((a, b) => b.score - a.score);
    return scores.map(s => s.node);
  }

  /** @override */
  async execute(task) {
    const targets = this.route(task);
    if (targets.length === 0) throw new Error('No available nodes match this task');
    this.logger.info({ task: task.id, routed: targets[0].name, candidates: targets.length }, 'Task routed');
    return targets[0]._handleTask(task);
  }
}

/**
 * VinciNode (HeadyVinci) — Session planning and topology maintenance.
 * Creates execution plans and monitors Sacred Geometry health.
 */
class VinciNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'HeadyVinci', ring: 'inner', pool: 'hot',
      capabilities: ['session-planning', 'topology-maintenance', 'strategy'],
      dependencies: { conductor: 'HeadyConductor', soul: 'HeadySoul' },
      ...config,
    });
  }

  /** @override */
  async execute(task) {
    const plan = {
      taskId: task.id,
      steps: task.steps || [],
      topology: { rings: ['center', 'inner', 'middle', 'outer', 'governance', 'memory'] },
      createdAt: new Date().toISOString(),
    };
    this.logger.info({ taskId: task.id, steps: plan.steps.length }, 'Session plan created');
    return plan;
  }
}

// ═══════════════════════════════════════════════════════════════
// MIDDLE RING — Hot & Warm Pools
// ═══════════════════════════════════════════════════════════════

/**
 * JulesNode — Code generation specialist (hot pool).
 */
class JulesNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'JULES', ring: 'middle', pool: 'hot',
      capabilities: ['code-generation', 'refactoring', 'code-completion'],
      dependencies: { brains: 'HeadyBrains', observer: 'OBSERVER' },
      ...config,
    });
  }

  /** @override */
  async execute(task) {
    this.logger.info({ taskId: task.id, lang: task.language || 'unknown' }, 'Generating code');
    return { taskId: task.id, type: 'code-generation', generatedAt: new Date().toISOString() };
  }
}

/**
 * BuilderNode — Full-stack system building (hot pool).
 */
class BuilderNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'BUILDER', ring: 'middle', pool: 'hot',
      capabilities: ['system-building', 'scaffolding', 'integration', 'deployment'],
      dependencies: { jules: 'JULES', conductor: 'HeadyConductor' },
      ...config,
    });
  }

  /** @override */
  async execute(task) {
    this.logger.info({ taskId: task.id }, 'Building system component');
    return { taskId: task.id, type: 'system-build', builtAt: new Date().toISOString() };
  }
}

/**
 * ObserverNode — Code review and monitoring (hot pool).
 */
class ObserverNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'OBSERVER', ring: 'middle', pool: 'hot',
      capabilities: ['code-review', 'monitoring', 'quality-analysis'],
      dependencies: { soul: 'HeadySoul', patterns: 'HeadyPatterns' },
      ...config,
    });
  }

  /** @override */
  async execute(task) {
    this.logger.info({ taskId: task.id }, 'Reviewing code');
    return { taskId: task.id, type: 'code-review', reviewedAt: new Date().toISOString(), issues: [] };
  }
}

/**
 * MurphyNode — Security analysis specialist (hot pool).
 */
class MurphyNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'MURPHY', ring: 'middle', pool: 'hot',
      capabilities: ['security-analysis', 'threat-modeling', 'vulnerability-scan'],
      dependencies: { soul: 'HeadySoul', risks: 'HeadyRisks' },
      ...config,
    });
  }

  /** @override */
  async execute(task) {
    this.logger.info({ taskId: task.id }, 'Running security analysis');
    return { taskId: task.id, type: 'security-analysis', analysedAt: new Date().toISOString(), threats: [] };
  }
}

/**
 * AtlasNode — Architecture documentation (warm pool).
 */
class AtlasNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'ATLAS', ring: 'middle', pool: 'warm',
      capabilities: ['architecture-docs', 'system-mapping', 'dependency-graph'],
      dependencies: { vinci: 'HeadyVinci' },
      ...config,
    });
  }

  /** @override */
  async execute(task) {
    this.logger.info({ taskId: task.id }, 'Generating architecture documentation');
    return { taskId: task.id, type: 'architecture-docs', generatedAt: new Date().toISOString() };
  }
}

/**
 * PythiaNode — Predictive analysis and forecasting (warm pool).
 */
class PythiaNode extends LiquidNode {
  constructor(config = {}) {
    super({
      name: 'PYTHIA', ring: 'middle', pool: 'warm',
      capabilities: ['predictive-analysis', 'forecasting', 'trend-detection'],
      dependencies: { memory: 'HeadyMemory', embed: 'HeadyEmbed' },
      ...config,
    });
  }

  /** @override */
  async execute(task) {
    this.logger.info({ taskId: task.id }, 'Running predictive analysis');
    return { taskId: task.id, type: 'prediction', predictedAt: new Date().toISOString() };
  }
}

// ═══════════════════════════════════════════════════════════════
// OUTER RING — Warm & Cold Pools
// ═══════════════════════════════════════════════════════════════

/**
 * BridgeNode — Cross-system integration and API bridging.
 */
class BridgeNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'BRIDGE', ring: 'outer', pool: 'warm', capabilities: ['integration', 'api-bridge', 'protocol-translation'], ...config });
  }
  /** @override */
  async execute(task) { return { taskId: task.id, type: 'bridge', processedAt: new Date().toISOString() }; }
}

/**
 * MuseNode — Creative content generation and ideation.
 */
class MuseNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'MUSE', ring: 'outer', pool: 'warm', capabilities: ['creative-content', 'ideation', 'copywriting'], ...config });
  }
  /** @override */
  async execute(task) { return { taskId: task.id, type: 'creative', processedAt: new Date().toISOString() }; }
}

/**
 * SentinelNode — Runtime security monitoring and intrusion detection.
 */
class SentinelNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'SENTINEL', ring: 'outer', pool: 'warm', capabilities: ['runtime-security', 'intrusion-detection', 'audit'], ...config });
  }
  /** @override */
  async execute(task) { return { taskId: task.id, type: 'sentinel-scan', processedAt: new Date().toISOString() }; }
}

/**
 * NovaNode — Experimental features and innovation sandbox.
 */
class NovaNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'NOVA', ring: 'outer', pool: 'warm', capabilities: ['experimentation', 'innovation', 'prototype'], ...config });
  }
  /** @override */
  async execute(task) { return { taskId: task.id, type: 'experiment', processedAt: new Date().toISOString() }; }
}

/**
 * JanitorNode — Cleanup, garbage collection, and resource reclamation.
 */
class JanitorNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'JANITOR', ring: 'outer', pool: 'cold', capabilities: ['cleanup', 'garbage-collection', 'resource-reclaim'], ...config });
  }
  /** @override */
  async execute(task) { return { taskId: task.id, type: 'cleanup', processedAt: new Date().toISOString() }; }
}

/**
 * SophiaNode — Knowledge synthesis and philosophical reasoning.
 */
class SophiaNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'SOPHIA', ring: 'outer', pool: 'warm', capabilities: ['knowledge-synthesis', 'reasoning', 'philosophy'], ...config });
  }
  /** @override */
  async execute(task) { return { taskId: task.id, type: 'synthesis', processedAt: new Date().toISOString() }; }
}

/**
 * CipherNode — Encryption, decryption, and cryptographic operations.
 */
class CipherNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'CIPHER', ring: 'outer', pool: 'cold', capabilities: ['encryption', 'decryption', 'key-management'], ...config });
  }
  /** @override */
  async execute(task) { return { taskId: task.id, type: 'crypto-op', processedAt: new Date().toISOString() }; }
}

/**
 * LensNode — Data visualization and insight extraction.
 */
class LensNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'LENS', ring: 'outer', pool: 'cold', capabilities: ['visualization', 'insight-extraction', 'reporting'], ...config });
  }
  /** @override */
  async execute(task) { return { taskId: task.id, type: 'visualization', processedAt: new Date().toISOString() }; }
}

// ═══════════════════════════════════════════════════════════════
// GOVERNANCE SHELL
// ═══════════════════════════════════════════════════════════════

/**
 * CheckNode (HeadyCheck) — Pre-execution validation gate.
 */
class CheckNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyCheck', ring: 'governance', pool: 'governance', capabilities: ['pre-validation', 'input-check', 'constraint-enforcement'], ...config });
  }
  /** @override */
  async execute(task) {
    const passed = task.input !== undefined && task.input !== null;
    this.logger.info({ taskId: task.id, passed }, 'Pre-execution check');
    return { taskId: task.id, type: 'check', passed, checkedAt: new Date().toISOString() };
  }
}

/**
 * AssureNode (HeadyAssure) — Post-execution quality assurance gate.
 */
class AssureNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyAssure', ring: 'governance', pool: 'governance', capabilities: ['quality-assurance', 'output-validation', 'post-check'], ...config });
  }
  /** @override */
  async execute(task) {
    const quality = task.result ? 'pass' : 'fail';
    this.logger.info({ taskId: task.id, quality }, 'Quality assurance');
    return { taskId: task.id, type: 'assurance', quality, assuredAt: new Date().toISOString() };
  }
}

/**
 * AwareNode (HeadyAware) — System-wide awareness and observability.
 */
class AwareNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyAware', ring: 'governance', pool: 'governance', capabilities: ['observability', 'awareness', 'telemetry-aggregation'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'awareness', snapshot: { timestamp: new Date().toISOString() } };
  }
}

/**
 * PatternsNode (HeadyPatterns) — Pattern detection and cataloguing.
 */
class PatternsNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyPatterns', ring: 'governance', pool: 'governance', capabilities: ['pattern-detection', 'anti-pattern-detection', 'catalogue'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'pattern-capture', capturedAt: new Date().toISOString(), patterns: [] };
  }
}

/**
 * MCNode (HeadyMC) — Mission Control dashboard and system coordination.
 */
class MCNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyMC', ring: 'governance', pool: 'governance', capabilities: ['mission-control', 'dashboard', 'system-coordination'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'mission-control', status: 'nominal', reportedAt: new Date().toISOString() };
  }
}

/**
 * RisksNode (HeadyRisks) — Risk assessment and mitigation tracking.
 */
class RisksNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyRisks', ring: 'governance', pool: 'governance', capabilities: ['risk-assessment', 'mitigation-tracking', 'compliance'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'risk-assessment', risks: [], assessedAt: new Date().toISOString() };
  }
}

// ═══════════════════════════════════════════════════════════════
// MEMORY / INTELLIGENCE LAYER
// ═══════════════════════════════════════════════════════════════

/**
 * MemoryNode (HeadyMemory) — Long-term memory storage and retrieval.
 */
class MemoryNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyMemory', ring: 'memory', pool: 'warm', capabilities: ['memory-storage', 'memory-retrieval', 'context-recall'], ...config });
  }
  /** @override */
  async execute(task) {
    if (task.type === 'store') return { stored: true, key: task.key, timestamp: new Date().toISOString() };
    if (task.type === 'retrieve') return { found: false, key: task.key, timestamp: new Date().toISOString() };
    return { taskId: task.id, type: 'memory-op', timestamp: new Date().toISOString() };
  }
}

/**
 * EmbedNode (HeadyEmbed) — Embedding generation and management.
 */
class EmbedNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyEmbed', ring: 'memory', pool: 'hot', capabilities: ['embedding-generation', 'vector-ops', 'similarity-search'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'embedding', dimensions: 384, generatedAt: new Date().toISOString() };
  }
}

/**
 * AutobiographerNode (HeadyAutobiographer) — Session story and narrative tracking.
 */
class AutobiographerNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyAutobiographer', ring: 'memory', pool: 'warm', capabilities: ['narrative-tracking', 'session-story', 'history'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'story-update', updatedAt: new Date().toISOString() };
  }
}

/**
 * ResearchNode (HeadyResearch) — Deep research and information gathering.
 */
class ResearchNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyResearch', ring: 'memory', pool: 'warm', capabilities: ['research', 'information-gathering', 'deep-search'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'research', researchedAt: new Date().toISOString() };
  }
}

/**
 * CodexNode (HeadyCodex) — Codebase knowledge index and lookup.
 */
class CodexNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyCodex', ring: 'memory', pool: 'warm', capabilities: ['codex', 'code-index', 'symbol-lookup'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'codex-lookup', foundAt: new Date().toISOString() };
  }
}

/**
 * MaidNode (HeadyMaid) — Data cleaning and normalization.
 */
class MaidNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyMaid', ring: 'memory', pool: 'cold', capabilities: ['data-cleaning', 'normalization', 'dedup'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'data-clean', cleanedAt: new Date().toISOString() };
  }
}

/**
 * MaintenanceNode (HeadyMaintenance) — System maintenance and health upkeep.
 */
class MaintenanceNode extends LiquidNode {
  constructor(config = {}) {
    super({ name: 'HeadyMaintenance', ring: 'memory', pool: 'cold', capabilities: ['maintenance', 'health-upkeep', 'scheduled-tasks'], ...config });
  }
  /** @override */
  async execute(task) {
    return { taskId: task.id, type: 'maintenance', maintainedAt: new Date().toISOString() };
  }
}

// ═══════════════════════════════════════════════════════════════
// BEE NODE — Ephemeral Worker Base Class
// ═══════════════════════════════════════════════════════════════

/**
 * BeeNode — Ephemeral worker with spawn→execute→report→retire lifecycle.
 * Each bee has its own circuit breaker and auto-reports to orchestration.
 *
 * maxRetries = Math.round(PHI * fib(5)) = 8
 * timeoutMs  = Math.round(PHI * 1000)   = 1618
 */
class BeeNode extends LiquidNode {
  /**
   * @param {Object} config
   * @param {string} config.name - Bee identifier
   * @param {string} [config.ring='outer'] - Topology ring
   * @param {string} [config.pool='warm'] - Resource pool
   */
  constructor(config) {
    super({ ring: 'outer', pool: 'warm', capabilities: ['bee-worker'], ...config });
    /** @type {number} Maximum retry attempts: Math.round(PHI * fib(5)) */
    this.maxRetries = Math.round(PHI * fib(5)); // 8
    /** @type {number} Execution timeout in ms: Math.round(PHI * 1000) */
    this.timeoutMs = Math.round(PHI * 1000);     // 1618
    this.retired = false;
    this.breaker = new CircuitBreaker({ name: `bee:${this.name}` });
  }

  /**
   * Spawn the bee — initialize resources and register.
   * @param {Object} [context] - Spawn context
   * @returns {Promise<void>}
   */
  async spawn(context) {
    await this.init();
    this.logger.info({ context: context?.id }, 'Bee spawned');
  }

  /**
   * Execute task through circuit breaker with timeout.
   * @param {Object} task - Task to execute
   * @returns {Promise<*>} Task result
   */
  async executeWithProtection(task) {
    return this.breaker.exec(() => {
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error(`Bee ${this.name} timed out after ${this.timeoutMs}ms`)), this.timeoutMs);
        this.execute(task)
          .then(result => { clearTimeout(timer); resolve(result); })
          .catch(err => { clearTimeout(timer); reject(err); });
      });
    });
  }

  /**
   * Report results to orchestration-bee via nodeBus.
   * @param {*} result - Execution result
   * @returns {Promise<void>}
   */
  async report(result) {
    nodeBus.emit('bee:report', { bee: this.name, result, reportedAt: new Date().toISOString() });
    this.logger.info({}, 'Report submitted to orchestration');
  }

  /**
   * Retire — cleanup, deregister, and mark as expired.
   * @returns {Promise<void>}
   */
  async retire() {
    this.retired = true;
    await this.shutdown('RETIRE');
    this.logger.info({}, 'Bee retired');
  }

  /** @override */
  async execute(task) {
    throw new Error(`${this.name}: bee execute() not implemented`);
  }
}

// ═══════════════════════════════════════════════════════════════
// SWARM COORDINATOR — Manages BeeNode Swarms
// ═══════════════════════════════════════════════════════════════

/**
 * SwarmCoordinator — Manages dynamic BeeNode swarms.
 * Provides consensus voting, DAG-based task distribution,
 * and phi-weighted load balancing.
 */
class SwarmCoordinator {
  /**
   * @param {Object} config
   * @param {string} config.name - Swarm identifier
   * @param {number} [config.maxBees] - Maximum concurrent bees (default: fib(7)=13)
   */
  constructor(config) {
    this.name = config.name;
    this.maxBees = config.maxBees || fib(7);
    /** @type {Map<string, BeeNode>} Active bees */
    this.bees = new Map();
    this.logger = createLogger(`Swarm:${this.name}`);
    this.beeCounter = 0;
  }

  /**
   * Spawn a new bee into the swarm.
   * @param {Function} BeeClass - BeeNode subclass constructor
   * @param {Object} [context] - Spawn context
   * @returns {Promise<BeeNode>} The spawned bee
   */
  async spawnBee(BeeClass, context) {
    if (this.bees.size >= this.maxBees) {
      this.logger.warn({ max: this.maxBees, current: this.bees.size }, 'Swarm at capacity');
      throw new Error(`Swarm ${this.name} at maximum capacity (${this.maxBees})`);
    }
    this.beeCounter++;
    const beeName = `${this.name}-bee-${this.beeCounter}`;
    const bee = new BeeClass({ name: beeName });
    await bee.spawn(context);
    this.bees.set(beeName, bee);
    this.logger.info({ bee: beeName, total: this.bees.size }, 'Bee spawned into swarm');
    return bee;
  }

  /**
   * Retire a specific bee from the swarm.
   * @param {string} beeName - Name of bee to retire
   * @returns {Promise<void>}
   */
  async retireBee(beeName) {
    const bee = this.bees.get(beeName);
    if (!bee) return;
    await bee.retire();
    this.bees.delete(beeName);
    this.logger.info({ bee: beeName, remaining: this.bees.size }, 'Bee retired from swarm');
  }

  /**
   * Retire all bees in the swarm.
   * @returns {Promise<void>}
   */
  async retireAll() {
    const names = [...this.bees.keys()];
    for (const name of names) { await this.retireBee(name); }
    this.logger.info({}, 'All bees retired');
  }

  /**
   * Consensus voting via cosine similarity across bee embeddings.
   * Returns the centroid of all active bee embeddings.
   * @returns {number[]} Consensus embedding vector
   */
  consensus() {
    const embeddings = [...this.bees.values()]
      .filter(b => b.canAcceptWork())
      .map(b => b.embedding);
    if (embeddings.length === 0) return [];
    return cslCONSENSUS(embeddings);
  }

  /**
   * Distribute tasks across bees using phi-weighted load balancing.
   * Tasks are assigned proportionally using golden-ratio weights.
   * @param {Object[]} tasks - Array of tasks to distribute
   * @returns {Map<string, Object[]>} Map of bee name to assigned tasks
   */
  distributeDAG(tasks) {
    const activeBees = [...this.bees.values()].filter(b => b.canAcceptWork());
    if (activeBees.length === 0) return new Map();

    const weights = phiFusionWeights(activeBees.length);
    const assignment = new Map();

    for (const bee of activeBees) {
      assignment.set(bee.name, []);
    }

    for (let i = 0; i < tasks.length; i++) {
      const beeIndex = i % activeBees.length;
      assignment.get(activeBees[beeIndex].name).push(tasks[i]);
    }

    this.logger.info({ tasks: tasks.length, bees: activeBees.length }, 'Tasks distributed');
    return assignment;
  }

  /**
   * Get aggregate health of the swarm.
   * @returns {Object} Swarm health summary
   */
  health() {
    const beeHealth = [...this.bees.values()].map(b => b.health());
    const active = beeHealth.filter(h => h.status === 'up').length;
    return {
      swarm: this.name,
      totalBees: this.bees.size,
      activeBees: active,
      maxBees: this.maxBees,
      utilization: this.bees.size / this.maxBees,
      bees: beeHealth,
      timestamp: new Date().toISOString(),
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// HC FULL PIPELINE — 8-Stage Processing Pipeline
// ═══════════════════════════════════════════════════════════════

/**
 * HCFullPipeline — The complete 8-stage Heady processing pipeline.
 *
 * Stages:
 * 1. Context Assembly (BrainsNode)
 * 2. Intent Classification (ConductorNode)
 * 3. Node Selection (ConductorNode routing)
 * 4. Execution (target node)
 * 5. Quality Gate (CheckNode)
 * 6. Assurance Gate (AssureNode)
 * 7. Pattern Capture (PatternsNode)
 * 8. Story Update (AutobiographerNode)
 */
class HCFullPipeline {
  /**
   * @param {Object} nodes - Named references to pipeline participant nodes
   * @param {BrainsNode} nodes.brains - Context assembly
   * @param {ConductorNode} nodes.conductor - Routing and classification
   * @param {CheckNode} nodes.check - Pre-execution validation
   * @param {AssureNode} nodes.assure - Post-execution assurance
   * @param {PatternsNode} nodes.patterns - Pattern capture
   * @param {AutobiographerNode} nodes.autobiographer - Story update
   * @param {SoulNode} nodes.soul - Coherence validation
   */
  constructor(nodes) {
    this.nodes = nodes;
    this.logger = createLogger('HCFullPipeline');
    this.pipelineRuns = 0;
  }

  /**
   * Run a task through the complete 8-stage pipeline.
   * @param {Object} task - Task to process (must have id, input, embedding fields)
   * @returns {Promise<Object>} Pipeline result with all stage outputs
   */
  async run(task) {
    this.pipelineRuns++;
    const pipelineId = `pipeline-${this.pipelineRuns}-${Date.now()}`;
    const stages = {};
    const startTime = Date.now();

    this.logger.info({ pipelineId, taskId: task.id }, 'Pipeline started');

    try {
      // Stage 1: Context Assembly
      stages.contextAssembly = await this.nodes.brains._handleTask({ ...task, type: 'assemble' });

      // Stage 2: Intent Classification
      stages.intentClassification = { intent: task.intent || 'general', classified: true };

      // Stage 3: Node Selection
      const targets = this.nodes.conductor.route(task);
      stages.nodeSelection = { selected: targets.length > 0 ? targets[0].name : null, candidates: targets.length };

      // Stage 4: Execution
      if (targets.length > 0) {
        stages.execution = await targets[0]._handleTask(task);
      } else {
        stages.execution = { error: 'No matching nodes' };
      }

      // Stage 5: Quality Gate
      stages.qualityGate = await this.nodes.check._handleTask({ ...task, type: 'check' });

      // Stage 6: Assurance Gate
      stages.assuranceGate = await this.nodes.assure._handleTask({ ...task, result: stages.execution, type: 'assure' });

      // Stage 7: Pattern Capture
      stages.patternCapture = await this.nodes.patterns._handleTask({ ...task, type: 'capture' });

      // Stage 8: Story Update
      stages.storyUpdate = await this.nodes.autobiographer._handleTask({ ...task, type: 'story-update' });

    } catch (err) {
      this.logger.error({ pipelineId, error: err.message }, 'Pipeline stage failed');
      stages.error = err.message;
    }

    const elapsed = Date.now() - startTime;
    this.logger.info({ pipelineId, elapsed, taskId: task.id }, 'Pipeline completed');

    return {
      pipelineId,
      taskId: task.id,
      stages,
      elapsed,
      completedAt: new Date().toISOString(),
    };
  }

  /**
   * Get pipeline health and statistics.
   * @returns {Object} Pipeline health summary
   */
  health() {
    return {
      pipeline: 'HCFullPipeline',
      totalRuns: this.pipelineRuns,
      nodeHealth: Object.fromEntries(
        Object.entries(this.nodes).map(([key, node]) => [key, node.health()])
      ),
      timestamp: new Date().toISOString(),
    };
  }
}

// ═══════════════════════════════════════════════════════════════
// EXPRESS HEALTH MIDDLEWARE FACTORY
// ═══════════════════════════════════════════════════════════════

/**
 * Create Express-compatible health check middleware for a node or registry.
 * @param {LiquidNode|NodeRegistry} target - Node or registry to report health for
 * @returns {Function} Express route handler (req, res) => void
 */
function createHealthMiddleware(target) {
  return (req, res) => {
    const h = typeof target.healthAll === 'function'
      ? { status: 'up', nodes: target.healthAll(), timestamp: new Date().toISOString() }
      : target.health();
    const status = h.status === 'up' || h.status === undefined ? 200 : 503;
    res.status(status).json(h);
  };
}

// ═══════════════════════════════════════════════════════════════
// BOOT SEQUENCE — bootHeadyOS()
// ═══════════════════════════════════════════════════════════════

/**
 * Boot the complete HeadyOS system.
 * Creates NodeRegistry, instantiates ALL nodes in Sacred Geometry order,
 * registers with ConductorNode, starts heartbeats, and returns the running system.
 *
 * @returns {Promise<Object>} The running HeadyOS system with registry, conductor, pipeline, and swarm
 */
async function bootHeadyOS() {
  const bootLogger = createLogger('HeadyOS:Boot');
  const bootStart = Date.now();
  bootLogger.info({}, 'HeadyOS boot sequence initiated');

  // 1. Create the registry
  const registry = new NodeRegistry();

  // 2. Instantiate all nodes in Sacred Geometry order

  // Center
  const soul = new SoulNode();

  // Inner Ring (hot)
  const brains = new BrainsNode();
  const conductor = new ConductorNode();
  const vinci = new VinciNode();

  // Middle Ring (hot)
  const jules = new JulesNode();
  const builder = new BuilderNode();
  const observer = new ObserverNode();
  const murphy = new MurphyNode();

  // Middle Ring (warm)
  const atlas = new AtlasNode();
  const pythia = new PythiaNode();

  // Outer Ring
  const bridge = new BridgeNode();
  const muse = new MuseNode();
  const sentinel = new SentinelNode();
  const nova = new NovaNode();
  const janitor = new JanitorNode();
  const sophia = new SophiaNode();
  const cipher = new CipherNode();
  const lens = new LensNode();

  // Governance Shell
  const check = new CheckNode();
  const assure = new AssureNode();
  const aware = new AwareNode();
  const patterns = new PatternsNode();
  const mc = new MCNode();
  const risks = new RisksNode();

  // Memory / Intelligence
  const memory = new MemoryNode();
  const embed = new EmbedNode();
  const autobiographer = new AutobiographerNode();
  const research = new ResearchNode();
  const codex = new CodexNode();
  const maid = new MaidNode();
  const maintenance = new MaintenanceNode();

  // Collect all nodes in boot order
  const allNodes = [
    soul,
    brains, conductor, vinci,
    jules, builder, observer, murphy, atlas, pythia,
    bridge, muse, sentinel, nova, janitor, sophia, cipher, lens,
    check, assure, aware, patterns, mc, risks,
    memory, embed, autobiographer, research, codex, maid, maintenance,
  ];

  // 3. Initialize all nodes
  for (const node of allNodes) {
    await node.init();
    registry.register(node);
    conductor.registerNode(node);
  }

  // 4. Create the full pipeline
  const pipeline = new HCFullPipeline({
    brains, conductor, check, assure, patterns, autobiographer, soul,
  });

  // 5. Create a default swarm coordinator
  const swarm = new SwarmCoordinator({ name: 'default' });

  const bootElapsed = Date.now() - bootStart;
  bootLogger.info({ nodesBooted: allNodes.length, elapsed: bootElapsed }, 'HeadyOS boot complete');

  return {
    registry,
    conductor,
    soul,
    brains,
    vinci,
    pipeline,
    swarm,
    nodeBus,
    nodes: Object.fromEntries(allNodes.map(n => [n.name, n])),

    /**
     * Graceful shutdown of the entire system.
     * @returns {Promise<void>}
     */
    async shutdown() {
      bootLogger.info({}, 'HeadyOS shutdown initiated');
      await swarm.retireAll();
      for (let i = allNodes.length - 1; i >= 0; i--) {
        await allNodes[i].shutdown();
      }
      bootLogger.info({}, 'HeadyOS shutdown complete');
    },

    /**
     * Get system-wide health.
     * @returns {Object} Aggregate health report
     */
    health() {
      return {
        system: 'HeadyOS',
        status: 'up',
        nodesTotal: registry.size,
        nodeHealth: registry.healthAll(),
        pipeline: pipeline.health(),
        swarm: swarm.health(),
        uptime: { ms: Date.now() - bootStart, human: soul._formatUptime(Date.now() - bootStart) },
        timestamp: new Date().toISOString(),
      };
    },
  };
}

// ═══════════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════════

module.exports = {
  // Base classes
  LiquidNode,
  BeeNode,

  // Center
  SoulNode,

  // Inner Ring
  BrainsNode,
  ConductorNode,
  VinciNode,

  // Middle Ring
  JulesNode,
  BuilderNode,
  ObserverNode,
  MurphyNode,
  AtlasNode,
  PythiaNode,

  // Outer Ring
  BridgeNode,
  MuseNode,
  SentinelNode,
  NovaNode,
  JanitorNode,
  SophiaNode,
  CipherNode,
  LensNode,

  // Governance Shell
  CheckNode,
  AssureNode,
  AwareNode,
  PatternsNode,
  MCNode,
  RisksNode,

  // Memory / Intelligence
  MemoryNode,
  EmbedNode,
  AutobiographerNode,
  ResearchNode,
  CodexNode,
  MaidNode,
  MaintenanceNode,

  // Infrastructure
  NodeRegistry,
  CircuitBreaker,
  SwarmCoordinator,
  HCFullPipeline,

  // Lifecycle
  LIFECYCLE_STATES,
  VALID_TRANSITIONS,
  CB_STATES,

  // Utilities
  createLogger,
  createHealthMiddleware,
  nodeBus,

  // Boot
  bootHeadyOS,
};
