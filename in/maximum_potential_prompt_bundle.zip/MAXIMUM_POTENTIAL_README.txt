MAXIMUM POTENTIAL prompt bundle

Files:
- MAXIMUM_POTENTIAL_PROMPT.md

Notes:
- Clean reusable markdown version of the universal coding agent system prompt.
- Includes the appended Heady-specific operating directives from your message.
