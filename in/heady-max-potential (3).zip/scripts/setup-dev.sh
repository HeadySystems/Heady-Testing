#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Heady™ Developer Setup Script
# Founded by Eric Haywood — HeadySystems Inc.
#
# ALL numeric constants from Fibonacci:
#   FIB = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597,2584]
#
# Target: zero to running in < 5 minutes
# Validates: Node.js 22+, Docker, gcloud CLI, .env file
# Actions: npm install, docker-compose up in dev mode
#
# GCP Project: gen-lang-client-0920560496
# Region: us-east1
# Cloudflare Account: 8b1fa38f282c691423c6399247d53323
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

# ─── Constants (Fibonacci) ───────────────────────────────────────────────────

readonly PHI="1.6180339887498948"
readonly SEED="42"
readonly TEMPERATURE="0"
readonly FOUNDER="Eric Haywood"
readonly GCP_PROJECT="gen-lang-client-0920560496"
readonly GCP_REGION="us-east1"
readonly CLOUDFLARE_ACCOUNT="8b1fa38f282c691423c6399247d53323"
readonly AUTH_DOMAIN="auth.headysystems.com"

readonly REQUIRED_NODE_MAJOR=22            # Node LTS
readonly FIB_4=5
readonly FIB_5=8
readonly FIB_7=21
readonly FIB_8=34
readonly FIB_9=55
readonly FIB_10=89

readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
readonly INFRA_DIR="$PROJECT_ROOT/infra"
readonly ENV_FILE="$PROJECT_ROOT/.env"
readonly ENV_EXAMPLE="$PROJECT_ROOT/.env.example"

# ─── Colors ──────────────────────────────────────────────────────────────────

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# ─── Helper Functions ────────────────────────────────────────────────────────

log_info()    { echo -e "${BLUE}[INFO]${NC} $*"; }
log_success() { echo -e "${GREEN}[OK]${NC} $*"; }
log_warn()    { echo -e "${YELLOW}[WARN]${NC} $*"; }
log_error()   { echo -e "${RED}[ERROR]${NC} $*"; }
log_step()    { echo -e "${PURPLE}[STEP]${NC} $*"; }

fail() {
  log_error "$*"
  exit 1
}

check_command() {
  command -v "$1" &>/dev/null || fail "$1 is not installed. Please install it first."
  log_success "$1 found: $(command -v "$1")"
}

# ─── Banner ──────────────────────────────────────────────────────────────────

echo ""
echo -e "${PURPLE}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${PURPLE}  Heady™ Maximum Potential — Developer Setup${NC}"
echo -e "${PURPLE}  Founded by ${FOUNDER}${NC}"
echo -e "${PURPLE}  φ = ${PHI} | seed = ${SEED} | temperature = ${TEMPERATURE}${NC}"
echo -e "${PURPLE}═══════════════════════════════════════════════════════════════${NC}"
echo ""

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1: Validate Prerequisites
# ═══════════════════════════════════════════════════════════════════════════════

log_step "1/8 — Validating prerequisites..."

# Node.js 22+
check_command node
NODE_VERSION=$(node -v | sed 's/v//' | cut -d. -f1)
if [ "$NODE_VERSION" -lt "$REQUIRED_NODE_MAJOR" ]; then
  fail "Node.js >= ${REQUIRED_NODE_MAJOR} required. Found: v${NODE_VERSION}"
fi
log_success "Node.js v$(node -v | sed 's/v//') (>= ${REQUIRED_NODE_MAJOR} required)"

# npm
check_command npm
log_success "npm v$(npm -v)"

# Docker
check_command docker
if ! docker info &>/dev/null; then
  fail "Docker daemon is not running. Please start Docker first."
fi
log_success "Docker daemon is running"

# Docker Compose
if docker compose version &>/dev/null; then
  log_success "Docker Compose v$(docker compose version --short)"
elif command -v docker-compose &>/dev/null; then
  log_success "docker-compose found (legacy)"
else
  fail "Docker Compose is not installed."
fi

# gcloud CLI (optional but recommended)
if command -v gcloud &>/dev/null; then
  log_success "gcloud CLI found: $(gcloud version 2>/dev/null | head -1)"
  GCLOUD_PROJECT=$(gcloud config get-value project 2>/dev/null || echo "")
  if [ "$GCLOUD_PROJECT" != "$GCP_PROJECT" ]; then
    log_warn "gcloud project is '${GCLOUD_PROJECT}', expected '${GCP_PROJECT}'"
    log_info "Run: gcloud config set project ${GCP_PROJECT}"
  fi
else
  log_warn "gcloud CLI not found — GCP features will be unavailable"
fi

echo ""

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2: Verify Project Structure
# ═══════════════════════════════════════════════════════════════════════════════

log_step "2/8 — Verifying project structure..."

cd "$PROJECT_ROOT"

REQUIRED_DIRS=(
  "config" "orchestration" "websites" "core" "agents" "auth"
  "deploy" "docs" "memory" "monitoring" "scaling" "security"
  "services" "infra" "ci" "scripts"
)

MISSING_DIRS=()
for dir in "${REQUIRED_DIRS[@]}"; do
  if [ ! -d "$dir" ]; then
    MISSING_DIRS+=("$dir")
  fi
done

if [ ${#MISSING_DIRS[@]} -gt 0 ]; then
  log_warn "Missing directories: ${MISSING_DIRS[*]}"
  log_info "Creating missing directories..."
  for dir in "${MISSING_DIRS[@]}"; do
    mkdir -p "$dir"
  done
fi

log_success "Project structure verified (${#REQUIRED_DIRS[@]} directories)"
echo ""

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3: Environment Configuration
# ═══════════════════════════════════════════════════════════════════════════════

log_step "3/8 — Setting up environment..."

if [ ! -f "$ENV_FILE" ]; then
  log_info "Creating .env from template..."
  cat > "$ENV_FILE" << ENVFILE
# ─────────────────────────────────────────────────────────────────────────────
# Heady™ Environment Configuration — Development
# Founded by Eric Haywood — HeadySystems Inc.
# Generated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")
# ─────────────────────────────────────────────────────────────────────────────

NODE_ENV=development
FOUNDER=Eric Haywood

# φ-math constants
PHI=${PHI}
SEED=${SEED}
TEMPERATURE=${TEMPERATURE}

# Platform
GCP_PROJECT=${GCP_PROJECT}
GCP_REGION=${GCP_REGION}
CLOUDFLARE_ACCOUNT=${CLOUDFLARE_ACCOUNT}
AUTH_DOMAIN=${AUTH_DOMAIN}
GITHUB_ORG=https://github.com/HeadyMe

# Database
POSTGRES_DB=heady
POSTGRES_USER=heady
POSTGRES_PASSWORD=heady_dev_${SEED}

# NATS
NATS_URL=nats://localhost:4222
NATS_INFERENCE_PASSWORD=dev_inference_${SEED}
NATS_MEMORY_PASSWORD=dev_memory_${SEED}
NATS_AGENTS_PASSWORD=dev_agents_${SEED}
NATS_ORCHESTRATION_PASSWORD=dev_orchestration_${SEED}
NATS_SECURITY_PASSWORD=dev_security_${SEED}
NATS_WEB_PASSWORD=dev_web_${SEED}
NATS_MONITORING_PASSWORD=dev_monitoring_${SEED}
NATS_DATA_PASSWORD=dev_data_${SEED}
NATS_INTEGRATION_PASSWORD=dev_integration_${SEED}
NATS_SPECIALIZED_PASSWORD=dev_specialized_${SEED}

# Redis
REDIS_URL=redis://localhost:6379

# Consul
CONSUL_HTTP_ADDR=http://localhost:8500
CONSUL_MANAGEMENT_TOKEN=dev_consul_token_${SEED}

# Grafana
GRAFANA_ADMIN_PASSWORD=heady_grafana_${SEED}
ENVFILE
  log_success ".env file created"
else
  log_success ".env file exists"
fi

# Validate critical env vars
source "$ENV_FILE"
REQUIRED_VARS=(PHI SEED TEMPERATURE GCP_PROJECT GCP_REGION)
for var in "${REQUIRED_VARS[@]}"; do
  if [ -z "${!var:-}" ]; then
    fail "Required env var ${var} is not set in .env"
  fi
done
log_success "Environment variables validated (${#REQUIRED_VARS[@]} critical vars)"
echo ""

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 4: Install Node.js Dependencies
# ═══════════════════════════════════════════════════════════════════════════════

log_step "4/8 — Installing Node.js dependencies..."

if [ -f "package.json" ]; then
  npm install --prefer-offline --no-audit
  log_success "Dependencies installed"
else
  log_warn "No package.json found — skipping npm install"
fi
echo ""

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 5: Setup Git Hooks
# ═══════════════════════════════════════════════════════════════════════════════

log_step "5/8 — Setting up Git hooks..."

if [ -d ".husky" ]; then
  if command -v npx &>/dev/null && [ -f "node_modules/.bin/husky" ]; then
    npx husky install 2>/dev/null || true
    log_success "Husky hooks installed"
  else
    # Make hooks executable directly
    chmod +x .husky/pre-commit 2>/dev/null || true
    log_success "Git hooks made executable"
  fi
else
  log_warn "No .husky directory found — skipping hooks setup"
fi
echo ""

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 6: Verify Infrastructure Config Files
# ═══════════════════════════════════════════════════════════════════════════════

log_step "6/8 — Verifying infrastructure configs..."

INFRA_FILES=(
  "docker-compose.yml"
  "Dockerfile.universal"
  "envoy.yaml"
  "nats.conf"
  "pgbouncer.ini"
  "consul.hcl"
  "otel-collector.yaml"
  "prometheus.yml"
)

MISSING_INFRA=()
for f in "${INFRA_FILES[@]}"; do
  if [ -f "$INFRA_DIR/$f" ]; then
    log_success "  $f ($(wc -l < "$INFRA_DIR/$f") lines)"
  else
    MISSING_INFRA+=("$f")
    log_warn "  $f — MISSING"
  fi
done

if [ ${#MISSING_INFRA[@]} -gt 0 ]; then
  log_warn "${#MISSING_INFRA[@]} infra config(s) missing"
fi
echo ""

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 7: Start Docker Compose (Dev Mode)
# ═══════════════════════════════════════════════════════════════════════════════

log_step "7/8 — Starting infrastructure services..."

cd "$INFRA_DIR"

if docker compose version &>/dev/null; then
  COMPOSE_CMD="docker compose"
else
  COMPOSE_CMD="docker-compose"
fi

log_info "Starting infrastructure services (postgres, redis, nats, consul)..."
$COMPOSE_CMD up -d \
  pgvector pgbouncer nats redis consul envoy \
  prometheus grafana otel-collector jaeger \
  2>/dev/null || log_warn "Some infrastructure services failed to start"

# Fibonacci-backoff health wait
log_info "Waiting for services to become healthy (Fibonacci backoff)..."
for WAIT in 1 1 2 3 5 8 13; do
  HEALTHY=$($COMPOSE_CMD ps --format json 2>/dev/null | grep -c '"healthy"' || echo 0)
  TOTAL=$($COMPOSE_CMD ps --format json 2>/dev/null | wc -l || echo 0)
  log_info "  Healthy: ${HEALTHY}/${TOTAL} (waiting ${WAIT}s)"
  sleep "$WAIT"
  if [ "$HEALTHY" -ge "$FIB_5" ]; then
    break
  fi
done

log_success "Infrastructure services started"
echo ""

# ═══════════════════════════════════════════════════════════════════════════════
# STEP 8: Summary
# ═══════════════════════════════════════════════════════════════════════════════

log_step "8/8 — Setup complete!"

cd "$PROJECT_ROOT"

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  Heady™ Development Environment Ready${NC}"
echo -e "${GREEN}  Founded by ${FOUNDER}${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${BLUE}Services:${NC}"
echo -e "    PostgreSQL/pgvector: localhost:5432"
echo -e "    PgBouncer:          localhost:6432"
echo -e "    NATS JetStream:     localhost:4222 (monitor: 8222)"
echo -e "    Redis:              localhost:6379"
echo -e "    Consul UI:          http://localhost:8500"
echo -e "    Envoy Admin:        http://localhost:9901"
echo -e "    Prometheus:         http://localhost:9090"
echo -e "    Grafana:            http://localhost:3000"
echo -e "    Jaeger UI:          http://localhost:16686"
echo -e "    OTEL Collector:     localhost:4317 (gRPC) / 4318 (HTTP)"
echo ""
echo -e "  ${BLUE}Quick Commands:${NC}"
echo -e "    Start all 50 services:  cd infra && docker compose up -d"
echo -e "    View logs:              cd infra && docker compose logs -f"
echo -e "    Stop all:               cd infra && docker compose down"
echo -e "    Run tests:              npm test"
echo ""
echo -e "  ${BLUE}φ Constants:${NC}"
echo -e "    PHI = ${PHI}"
echo -e "    Seed = ${SEED}"
echo -e "    Temperature = ${TEMPERATURE}"
echo ""
