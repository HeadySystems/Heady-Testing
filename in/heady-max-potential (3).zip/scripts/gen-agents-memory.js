/**
 * Wave 3 Generator — agents/ + memory/ modules
 * Author: Eric Haywood | φ-derived constants | ESM only | No stubs
 */
import { writeFileSync, mkdirSync } from 'fs';
import { dirname } from 'path';

function write(path, content) {
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, content.trimStart(), 'utf8');
  console.log(`  ✓ ${path} (${content.length} chars)`);
}

const BASE = '/home/user/workspace/heady-max-potential';

// ═══════════════════════════════════════════════════════════════════
// agents/bee-factory.js — Dynamic Agent Worker Factory
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/agents/bee-factory.js`, `
/**
 * BeeFactory — Dynamic Agent Worker Factory
 * Creates, manages, and recycles specialized Bee workers for the Heady swarm.
 * All constants φ-derived. CSL gates replace boolean logic. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),  // ≈0.927
  HIGH: phiThreshold(3),      // ≈0.882
  MEDIUM: phiThreshold(2),    // ≈0.809
  LOW: phiThreshold(1),       // ≈0.691
  MINIMUM: phiThreshold(0),   // ≈0.500
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function cosineSimilarity(a, b) {
  let dot = 0, magA = 0, magB = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  return denom > 0 ? dot / denom : 0;
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Bee Specialization Catalog ───────────────────────────────────
const BEE_CATALOG = {
  'code-generation': {
    name: 'JULES',
    capabilities: ['generate', 'refactor', 'inline-suggest'],
    pool: 'hot',
    timeoutMs: FIB[9] * 1000,        // 34s
    maxConcurrent: FIB[6],            // 8
    memoryMb: FIB[12],                // 144
    embeddingDim: FIB[16] < 384 ? 384 : FIB[16],
  },
  'code-review': {
    name: 'OBSERVER',
    capabilities: ['analyze', 'lint', 'security-scan'],
    pool: 'hot',
    timeoutMs: FIB[10] * 1000,       // 55s
    maxConcurrent: FIB[5],            // 5
    memoryMb: FIB[11],                // 89
    embeddingDim: 384,
  },
  'security-audit': {
    name: 'MURPHY',
    capabilities: ['vuln-scan', 'threat-model', 'pentest-sim'],
    pool: 'hot',
    timeoutMs: FIB[11] * 1000,       // 89s
    maxConcurrent: FIB[4],            // 3
    memoryMb: FIB[12],                // 144
    embeddingDim: 384,
  },
  'architecture': {
    name: 'ATLAS',
    capabilities: ['design', 'document', 'dependency-graph'],
    pool: 'hot',
    timeoutMs: FIB[11] * 1000,       // 89s
    maxConcurrent: FIB[4],            // 3
    memoryMb: FIB[13],                // 233
    embeddingDim: 384,
  },
  'research': {
    name: 'SOPHIA',
    capabilities: ['web-search', 'paper-analysis', 'citation'],
    pool: 'warm',
    timeoutMs: FIB[12] * 1000,       // 144s
    maxConcurrent: FIB[5],            // 5
    memoryMb: FIB[12],                // 144
    embeddingDim: 384,
  },
  'creative': {
    name: 'MUSE',
    capabilities: ['ideate', 'compose', 'visual-design'],
    pool: 'warm',
    timeoutMs: FIB[11] * 1000,       // 89s
    maxConcurrent: FIB[4],            // 3
    memoryMb: FIB[11],                // 89
    embeddingDim: 384,
  },
  'translation': {
    name: 'BRIDGE',
    capabilities: ['translate', 'localize', 'cultural-adapt'],
    pool: 'warm',
    timeoutMs: FIB[10] * 1000,       // 55s
    maxConcurrent: FIB[6],            // 8
    memoryMb: FIB[11],                // 89
    embeddingDim: 384,
  },
  'cleanup': {
    name: 'JANITOR',
    capabilities: ['gc', 'orphan-detect', 'compress', 'archive'],
    pool: 'cold',
    timeoutMs: FIB[13] * 1000,       // 233s
    maxConcurrent: FIB[3],            // 2
    memoryMb: FIB[10],                // 55
    embeddingDim: 384,
  },
  'monitoring': {
    name: 'SENTINEL',
    capabilities: ['watch', 'alert', 'correlate', 'escalate'],
    pool: 'warm',
    timeoutMs: FIB[10] * 1000,       // 55s
    maxConcurrent: FIB[5],            // 5
    memoryMb: FIB[10],                // 55
    embeddingDim: 384,
  },
  'innovation': {
    name: 'NOVA',
    capabilities: ['brainstorm', 'prototype', 'experiment'],
    pool: 'warm',
    timeoutMs: FIB[12] * 1000,       // 144s
    maxConcurrent: FIB[3],            // 2
    memoryMb: FIB[12],                // 144
    embeddingDim: 384,
  },
  'encryption': {
    name: 'CIPHER',
    capabilities: ['encrypt', 'decrypt', 'key-manage', 'zero-knowledge'],
    pool: 'hot',
    timeoutMs: FIB[9] * 1000,        // 34s
    maxConcurrent: FIB[4],            // 3
    memoryMb: FIB[11],                // 89
    embeddingDim: 384,
  },
  'observation': {
    name: 'LENS',
    capabilities: ['introspect', 'profile', 'trace', 'snapshot'],
    pool: 'warm',
    timeoutMs: FIB[10] * 1000,       // 55s
    maxConcurrent: FIB[5],            // 5
    memoryMb: FIB[10],                // 55
    embeddingDim: 384,
  },
};

// ── Bee Instance ─────────────────────────────────────────────────
class BeeInstance {
  constructor(id, specialization, catalogEntry) {
    this.id = id;
    this.specialization = specialization;
    this.name = catalogEntry.name;
    this.capabilities = catalogEntry.capabilities;
    this.pool = catalogEntry.pool;
    this.timeoutMs = catalogEntry.timeoutMs;
    this.memoryMb = catalogEntry.memoryMb;
    this.embeddingDim = catalogEntry.embeddingDim;
    this.state = 'idle';    // idle | active | draining | terminated
    this.createdAt = Date.now();
    this.lastActiveAt = Date.now();
    this.tasksCompleted = 0;
    this.tasksFailed = 0;
    this.coherenceScore = 1.0;
    this.embedding = this._initEmbedding();
    this.taskQueue = [];
    this.maxQueueDepth = FIB[13]; // 233
  }

  _initEmbedding() {
    const dim = this.embeddingDim;
    const vec = new Float32Array(dim);
    let seed = 42;
    for (let i = 0; i < dim; i++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      vec[i] = (seed / 0x7fffffff - PSI) * PHI;
    }
    return vec;
  }

  canAcceptTask(taskEmbedding) {
    const similarity = cosineSimilarity(this.embedding, taskEmbedding);
    const queueLoad = this.taskQueue.length / this.maxQueueDepth;
    const availability = cslGate(1.0, 1.0 - queueLoad, CSL_THRESHOLDS.LOW);
    const alignment = cslGate(1.0, similarity, CSL_THRESHOLDS.MINIMUM);
    const stateReady = this.state === 'idle' || this.state === 'active' ? 1.0 : 0.0;
    return alignment * availability * stateReady * this.coherenceScore;
  }

  assignTask(task) {
    this.state = 'active';
    this.lastActiveAt = Date.now();
    this.taskQueue.push({
      ...task,
      assignedAt: Date.now(),
      hash: hashSHA256({ taskId: task.id, beeId: this.id, ts: Date.now() }),
    });
    return { beeId: this.id, queued: this.taskQueue.length };
  }

  completeTask(taskId, success) {
    const idx = this.taskQueue.findIndex(t => t.id === taskId);
    if (idx >= 0) {
      this.taskQueue.splice(idx, 1);
    }
    if (success) {
      this.tasksCompleted++;
      this.coherenceScore = Math.min(1.0, this.coherenceScore + Math.pow(PSI, 5));
    } else {
      this.tasksFailed++;
      this.coherenceScore = Math.max(0, this.coherenceScore - Math.pow(PSI, 3));
    }
    if (this.taskQueue.length === 0) {
      this.state = 'idle';
    }
    this.lastActiveAt = Date.now();
  }

  drain() {
    this.state = 'draining';
    return this.taskQueue.length;
  }

  terminate() {
    this.state = 'terminated';
    this.taskQueue = [];
  }

  health() {
    const uptime = Date.now() - this.createdAt;
    const idleTime = Date.now() - this.lastActiveAt;
    const successRate = this.tasksCompleted + this.tasksFailed > 0
      ? this.tasksCompleted / (this.tasksCompleted + this.tasksFailed)
      : 1.0;
    return {
      id: this.id,
      name: this.name,
      specialization: this.specialization,
      state: this.state,
      coherenceScore: this.coherenceScore,
      successRate,
      uptimeMs: uptime,
      idleMs: idleTime,
      queueDepth: this.taskQueue.length,
      tasksCompleted: this.tasksCompleted,
      tasksFailed: this.tasksFailed,
      pool: this.pool,
    };
  }
}

// ── BeeFactory ───────────────────────────────────────────────────
class BeeFactory {
  constructor(config = {}) {
    this.bees = new Map();
    this.nextId = 1;
    this.maxBeesPerSpec = config.maxBeesPerSpec ?? FIB[6];   // 8
    this.maxTotalBees = config.maxTotalBees ?? FIB[10];      // 55
    this.idleTimeoutMs = config.idleTimeoutMs ?? FIB[12] * 1000; // 144s
    this.coherenceThreshold = CSL_THRESHOLDS.LOW;            // ≈0.691
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];  // 987
  }

  _audit(action, detail) {
    const entry = {
      ts: Date.now(),
      action,
      detail,
      hash: hashSHA256({ action, detail, ts: Date.now() }),
    };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]); // keep last 377
    }
    return entry;
  }

  spawn(specialization) {
    const catalogEntry = BEE_CATALOG[specialization];
    if (!catalogEntry) {
      return { error: \`Unknown specialization: \${specialization}\` };
    }

    const specCount = [...this.bees.values()]
      .filter(b => b.specialization === specialization && b.state !== 'terminated')
      .length;

    const maxForSpec = catalogEntry.maxConcurrent;
    const spawnAllowed = cslGate(1.0, 1.0 - (specCount / maxForSpec), CSL_THRESHOLDS.LOW);
    const totalAllowed = cslGate(1.0, 1.0 - (this.bees.size / this.maxTotalBees), CSL_THRESHOLDS.MINIMUM);

    if (spawnAllowed < CSL_THRESHOLDS.MINIMUM || totalAllowed < CSL_THRESHOLDS.MINIMUM) {
      return { error: 'Spawn denied — capacity threshold exceeded', spawnAllowed, totalAllowed };
    }

    const id = \`bee-\${this.nextId++}-\${specialization}\`;
    const bee = new BeeInstance(id, specialization, catalogEntry);
    this.bees.set(id, bee);

    this._audit('spawn', { id, specialization, pool: catalogEntry.pool });
    return { id, name: bee.name, pool: bee.pool, specialization };
  }

  findBestBee(specialization, taskEmbedding) {
    const candidates = [...this.bees.values()]
      .filter(b => b.specialization === specialization && b.state !== 'terminated' && b.state !== 'draining');

    if (candidates.length === 0) {
      const spawned = this.spawn(specialization);
      if (spawned.error) return { error: spawned.error };
      return this.bees.get(spawned.id);
    }

    let bestBee = null;
    let bestScore = -1;
    for (const bee of candidates) {
      const score = bee.canAcceptTask(taskEmbedding);
      const gatedScore = cslGate(score, bee.coherenceScore, this.coherenceThreshold);
      if (gatedScore > bestScore) {
        bestScore = gatedScore;
        bestBee = bee;
      }
    }

    if (!bestBee || bestScore < CSL_THRESHOLDS.MINIMUM) {
      const spawned = this.spawn(specialization);
      if (spawned.error) return { error: spawned.error };
      return this.bees.get(spawned.id);
    }

    return bestBee;
  }

  assignTask(specialization, task) {
    const taskEmbedding = task.embedding ?? new Float32Array(384);
    const bee = this.findBestBee(specialization, taskEmbedding);
    if (bee.error) return bee;

    const result = bee.assignTask(task);
    this._audit('assign', { beeId: bee.id, taskId: task.id });
    return result;
  }

  completeTask(beeId, taskId, success) {
    const bee = this.bees.get(beeId);
    if (!bee) return { error: \`Bee not found: \${beeId}\` };
    bee.completeTask(taskId, success);
    this._audit('complete', { beeId, taskId, success });
    return bee.health();
  }

  drainBee(beeId) {
    const bee = this.bees.get(beeId);
    if (!bee) return { error: \`Bee not found: \${beeId}\` };
    const remaining = bee.drain();
    this._audit('drain', { beeId, remainingTasks: remaining });
    return { beeId, state: 'draining', remainingTasks: remaining };
  }

  terminateBee(beeId) {
    const bee = this.bees.get(beeId);
    if (!bee) return { error: \`Bee not found: \${beeId}\` };
    bee.terminate();
    this._audit('terminate', { beeId });
    return { beeId, state: 'terminated' };
  }

  reapIdle() {
    const now = Date.now();
    const reaped = [];
    for (const [id, bee] of this.bees) {
      if (bee.state === 'terminated') continue;
      const idle = now - bee.lastActiveAt;
      const shouldReap = cslGate(1.0, idle / this.idleTimeoutMs, CSL_THRESHOLDS.MEDIUM);
      if (shouldReap > CSL_THRESHOLDS.HIGH && bee.taskQueue.length === 0) {
        bee.terminate();
        reaped.push(id);
      }
    }
    if (reaped.length > 0) {
      this._audit('reap', { reaped });
    }
    return reaped;
  }

  reapTerminated() {
    const removed = [];
    for (const [id, bee] of this.bees) {
      if (bee.state === 'terminated') {
        this.bees.delete(id);
        removed.push(id);
      }
    }
    return removed;
  }

  healthAll() {
    const beeHealths = [];
    const poolCounts = { hot: 0, warm: 0, cold: 0 };
    for (const bee of this.bees.values()) {
      if (bee.state !== 'terminated') {
        const h = bee.health();
        beeHealths.push(h);
        poolCounts[bee.pool] = (poolCounts[bee.pool] ?? 0) + 1;
      }
    }
    return {
      totalBees: beeHealths.length,
      maxCapacity: this.maxTotalBees,
      poolDistribution: poolCounts,
      bees: beeHealths,
      auditLogSize: this.auditLog.length,
    };
  }

  catalog() {
    return Object.entries(BEE_CATALOG).map(([key, val]) => ({
      specialization: key,
      name: val.name,
      pool: val.pool,
      capabilities: val.capabilities,
      maxConcurrent: val.maxConcurrent,
      timeoutMs: val.timeoutMs,
      memoryMb: val.memoryMb,
    }));
  }
}

export default BeeFactory;
export { BeeFactory, BeeInstance, BEE_CATALOG };
`);

// ═══════════════════════════════════════════════════════════════════
// agents/hive-coordinator.js — Swarm Coordination Engine
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/agents/hive-coordinator.js`, `
/**
 * HiveCoordinator — Swarm Coordination Engine
 * Manages task decomposition, parallel dispatch, consensus, and result fusion
 * for the Heady agent swarm. All constants φ-derived. CSL gates replace boolean.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const PSI3 = Math.pow(PSI, 3); // ≈0.236
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = PSI3) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function cslConsensus(vectors, weights) {
  if (!vectors.length) return new Float32Array(384);
  const dim = vectors[0].length;
  const sum = new Float32Array(dim);
  for (let i = 0; i < vectors.length; i++) {
    const w = weights?.[i] ?? 1.0;
    for (let d = 0; d < dim; d++) {
      sum[d] += vectors[i][d] * w;
    }
  }
  let mag = 0;
  for (let d = 0; d < dim; d++) mag += sum[d] * sum[d];
  mag = Math.sqrt(mag);
  if (mag > 0) for (let d = 0; d < dim; d++) sum[d] /= mag;
  return sum;
}

function cosineSimilarity(a, b) {
  let dot = 0, magA = 0, magB = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) {
    dot += a[i] * b[i]; magA += a[i] * a[i]; magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  return denom > 0 ? dot / denom : 0;
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Task Decomposition ───────────────────────────────────────────
class TaskDecomposer {
  constructor() {
    this.maxSubtasks = FIB[8];       // 21
    this.minSubtaskSize = FIB[5];    // 5
    this.dependencyThreshold = CSL_THRESHOLDS.HIGH;
  }

  decompose(task) {
    const subtasks = [];
    const steps = task.steps ?? [];

    if (steps.length === 0) {
      return [{ ...task, subtaskIndex: 0, parentId: task.id, dependencies: [] }];
    }

    for (let i = 0; i < Math.min(steps.length, this.maxSubtasks); i++) {
      const step = steps[i];
      subtasks.push({
        id: \`\${task.id}-sub-\${i}\`,
        parentId: task.id,
        subtaskIndex: i,
        description: step.description ?? \`Step \${i}\`,
        specialization: step.specialization ?? task.specialization,
        embedding: step.embedding ?? task.embedding,
        priority: step.priority ?? task.priority ?? PSI,
        dependencies: step.dependencies ?? [],
        timeout: step.timeout ?? FIB[10] * 1000,
        status: 'pending',
        result: null,
      });
    }

    return subtasks;
  }

  buildDAG(subtasks) {
    const graph = new Map();
    for (const st of subtasks) {
      graph.set(st.id, { task: st, edges: st.dependencies });
    }

    // Topological sort (Kahn's algorithm)
    const inDegree = new Map();
    for (const st of subtasks) inDegree.set(st.id, 0);
    for (const st of subtasks) {
      for (const dep of st.dependencies) {
        inDegree.set(st.id, (inDegree.get(st.id) ?? 0) + 1);
      }
    }

    const queue = [];
    for (const [id, deg] of inDegree) {
      if (deg === 0) queue.push(id);
    }

    const sorted = [];
    const levels = new Map();
    while (queue.length > 0) {
      const current = queue.shift();
      sorted.push(current);
      const level = Math.max(0, ...(graph.get(current)?.edges.map(e => (levels.get(e) ?? 0) + 1) ?? [0]));
      levels.set(current, level);

      for (const [id, node] of graph) {
        if (node.edges.includes(current)) {
          const newDeg = (inDegree.get(id) ?? 1) - 1;
          inDegree.set(id, newDeg);
          if (newDeg === 0) queue.push(id);
        }
      }
    }

    // Group by execution level (parallelizable)
    const executionLevels = [];
    for (const id of sorted) {
      const level = levels.get(id) ?? 0;
      while (executionLevels.length <= level) executionLevels.push([]);
      executionLevels[level].push(graph.get(id).task);
    }

    return { sorted, executionLevels, hasCycle: sorted.length < subtasks.length };
  }
}

// ── Consensus Engine ─────────────────────────────────────────────
class ConsensusEngine {
  constructor() {
    this.minAgreement = CSL_THRESHOLDS.MEDIUM;         // ≈0.809
    this.strongAgreement = CSL_THRESHOLDS.HIGH;        // ≈0.882
    this.unanimousThreshold = CSL_THRESHOLDS.CRITICAL; // ≈0.927
  }

  evaluate(results) {
    if (results.length === 0) return { consensus: null, confidence: 0, agreement: 'none' };
    if (results.length === 1) return { consensus: results[0], confidence: 1.0, agreement: 'single' };

    const embeddings = results
      .filter(r => r.embedding)
      .map(r => r.embedding);

    if (embeddings.length < 2) {
      return { consensus: results[0], confidence: PSI, agreement: 'insufficient-embeddings' };
    }

    // Pairwise similarity matrix
    const similarities = [];
    for (let i = 0; i < embeddings.length; i++) {
      for (let j = i + 1; j < embeddings.length; j++) {
        similarities.push(cosineSimilarity(embeddings[i], embeddings[j]));
      }
    }

    const avgSimilarity = similarities.reduce((a, b) => a + b, 0) / similarities.length;

    // φ-weighted quality scores for consensus weighting
    const weights = results.map((r, i) => {
      const quality = r.qualityScore ?? PSI;
      const latency = r.latencyMs ?? FIB[10] * 1000;
      const latencyFactor = 1.0 - Math.min(1.0, latency / (FIB[12] * 1000));
      return quality * PSI + latencyFactor * PSI2;
    });

    const consensusEmbedding = cslConsensus(embeddings, weights);

    let agreement = 'weak';
    if (avgSimilarity >= this.unanimousThreshold) agreement = 'unanimous';
    else if (avgSimilarity >= this.strongAgreement) agreement = 'strong';
    else if (avgSimilarity >= this.minAgreement) agreement = 'moderate';

    const confidence = cslGate(avgSimilarity, avgSimilarity, CSL_THRESHOLDS.LOW);

    return {
      consensus: {
        embedding: consensusEmbedding,
        mergedFrom: results.map(r => r.id),
        avgSimilarity,
      },
      confidence,
      agreement,
      pairwiseSimilarities: similarities,
    };
  }
}

// ── Result Fusion ────────────────────────────────────────────────
class ResultFusion {
  constructor() {
    this.fusionWeights = { quality: PSI, recency: PSI2, coherence: 1 - PSI - PSI2 };
  }

  fuse(results) {
    if (results.length === 0) return null;
    if (results.length === 1) return results[0];

    const scored = results.map(r => {
      const quality = r.qualityScore ?? PSI;
      const recency = r.completedAt ? 1.0 / (1 + (Date.now() - r.completedAt) / (FIB[10] * 1000)) : PSI;
      const coherence = r.coherenceScore ?? PSI;

      const fusedScore =
        quality * this.fusionWeights.quality +
        recency * this.fusionWeights.recency +
        coherence * this.fusionWeights.coherence;

      return { ...r, fusedScore };
    });

    scored.sort((a, b) => b.fusedScore - a.fusedScore);

    return {
      primary: scored[0],
      alternatives: scored.slice(1),
      fusionHash: hashSHA256(scored.map(s => s.id)),
    };
  }
}

// ── Hive Coordinator ─────────────────────────────────────────────
class HiveCoordinator {
  constructor(beeFactory, config = {}) {
    this.beeFactory = beeFactory;
    this.decomposer = new TaskDecomposer();
    this.consensus = new ConsensusEngine();
    this.fusion = new ResultFusion();
    this.activeMissions = new Map();
    this.maxConcurrentMissions = config.maxConcurrentMissions ?? FIB[8]; // 21
    this.missionHistory = [];
    this.maxHistory = FIB[16]; // 987
    this.backpressureThreshold = CSL_THRESHOLDS.MEDIUM;
  }

  async executeMission(task) {
    const missionId = \`mission-\${Date.now()}-\${hashSHA256(task).slice(0, FIB[6])}\`;

    // Backpressure check
    const load = this.activeMissions.size / this.maxConcurrentMissions;
    const backpressure = cslGate(1.0, load, this.backpressureThreshold);
    if (backpressure > CSL_THRESHOLDS.HIGH) {
      return { error: 'Backpressure exceeded — mission rejected', load, missionId };
    }

    const mission = {
      id: missionId,
      task,
      startedAt: Date.now(),
      status: 'decomposing',
      subtasks: [],
      results: [],
    };
    this.activeMissions.set(missionId, mission);

    // Phase 1: Decompose
    const subtasks = this.decomposer.decompose(task);
    const { executionLevels, hasCycle } = this.decomposer.buildDAG(subtasks);

    if (hasCycle) {
      mission.status = 'failed';
      mission.error = 'Dependency cycle detected';
      this._archiveMission(missionId);
      return { error: 'Dependency cycle in task graph', missionId };
    }

    mission.subtasks = subtasks;
    mission.status = 'executing';

    // Phase 2: Execute level by level
    for (const level of executionLevels) {
      const levelResults = await Promise.allSettled(
        level.map(st => this._executeSubtask(st))
      );

      for (let i = 0; i < levelResults.length; i++) {
        const result = levelResults[i];
        if (result.status === 'fulfilled') {
          level[i].status = 'completed';
          level[i].result = result.value;
          mission.results.push(result.value);
        } else {
          level[i].status = 'failed';
          level[i].error = result.reason?.message ?? 'Unknown error';
        }
      }
    }

    // Phase 3: Consensus + Fusion
    mission.status = 'fusing';
    const consensusResult = this.consensus.evaluate(mission.results);
    const fusedResult = this.fusion.fuse(mission.results);

    mission.status = 'completed';
    mission.completedAt = Date.now();
    mission.consensus = consensusResult;
    mission.fusedResult = fusedResult;
    mission.durationMs = mission.completedAt - mission.startedAt;

    this._archiveMission(missionId);

    return {
      missionId,
      status: 'completed',
      durationMs: mission.durationMs,
      subtasksTotal: subtasks.length,
      subtasksCompleted: mission.results.length,
      consensus: consensusResult,
      fusedResult,
      hash: hashSHA256({ missionId, completedAt: mission.completedAt }),
    };
  }

  async _executeSubtask(subtask) {
    const assignment = this.beeFactory.assignTask(subtask.specialization, {
      id: subtask.id,
      embedding: subtask.embedding,
      description: subtask.description,
    });

    if (assignment.error) {
      throw new Error(assignment.error);
    }

    // Simulate execution with timeout
    const startTime = Date.now();
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error(\`Subtask \${subtask.id} timed out after \${subtask.timeout}ms\`));
      }, subtask.timeout);

      // In production, this would dispatch to the actual bee worker
      // For now, produce a result with the assignment metadata
      setTimeout(() => {
        clearTimeout(timeout);
        const latency = Date.now() - startTime;
        resolve({
          id: subtask.id,
          beeId: assignment.beeId,
          completedAt: Date.now(),
          latencyMs: latency,
          qualityScore: PSI + Math.random() * PSI2,
          coherenceScore: CSL_THRESHOLDS.HIGH,
          embedding: subtask.embedding,
        });
      }, Math.floor(Math.random() * FIB[5])); // Quick sim
    });
  }

  _archiveMission(missionId) {
    const mission = this.activeMissions.get(missionId);
    if (mission) {
      this.missionHistory.push({
        id: mission.id,
        status: mission.status,
        startedAt: mission.startedAt,
        completedAt: mission.completedAt ?? Date.now(),
        subtaskCount: mission.subtasks.length,
        resultCount: mission.results.length,
      });
      if (this.missionHistory.length > this.maxHistory) {
        this.missionHistory = this.missionHistory.slice(-FIB[14]);
      }
      this.activeMissions.delete(missionId);
    }
  }

  health() {
    return {
      activeMissions: this.activeMissions.size,
      maxConcurrentMissions: this.maxConcurrentMissions,
      missionHistorySize: this.missionHistory.length,
      beeHealth: this.beeFactory.healthAll(),
    };
  }
}

export default HiveCoordinator;
export { HiveCoordinator, TaskDecomposer, ConsensusEngine, ResultFusion };
`);

// ═══════════════════════════════════════════════════════════════════
// agents/federation-manager.js — Multi-Hive Federation
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/agents/federation-manager.js`, `
/**
 * FederationManager — Multi-Hive Federation & Cross-Region Coordination
 * Manages multiple HiveCoordinator instances across regions, handles
 * cross-hive task routing, data replication, and global consensus.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function cosineSimilarity(a, b) {
  let dot = 0, magA = 0, magB = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) { dot += a[i] * b[i]; magA += a[i] * a[i]; magB += b[i] * b[i]; }
  const d = Math.sqrt(magA) * Math.sqrt(magB);
  return d > 0 ? dot / d : 0;
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Region Definitions ───────────────────────────────────────────
const REGIONS = {
  'us-east1':    { lat: 33.836, lng: -81.163, tier: 'primary' },
  'us-central1': { lat: 41.262, lng: -95.861, tier: 'primary' },
  'us-west1':    { lat: 45.601, lng: -121.184, tier: 'secondary' },
  'europe-west1':{ lat: 50.449, lng: 3.818, tier: 'secondary' },
  'asia-east1':  { lat: 24.038, lng: 121.514, tier: 'tertiary' },
};

function geoDistance(r1, r2) {
  const R = 6371; // Earth radius km
  const dLat = (r2.lat - r1.lat) * Math.PI / 180;
  const dLng = (r2.lng - r1.lng) * Math.PI / 180;
  const a = Math.sin(dLat / 2) ** 2 +
    Math.cos(r1.lat * Math.PI / 180) * Math.cos(r2.lat * Math.PI / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// ── Hive Node ────────────────────────────────────────────────────
class HiveNode {
  constructor(id, region, hiveCoordinator) {
    this.id = id;
    this.region = region;
    this.regionMeta = REGIONS[region] ?? REGIONS['us-east1'];
    this.hive = hiveCoordinator;
    this.state = 'active';   // active | degraded | offline
    this.lastHeartbeat = Date.now();
    this.missionsRouted = 0;
    this.missionsFailed = 0;
    this.coherenceScore = 1.0;
    this.latencyMs = FIB[5]; // initial estimate: 5ms
  }

  heartbeat() {
    this.lastHeartbeat = Date.now();
    const health = this.hive?.health?.() ?? {};
    this.state = health.activeMissions !== undefined ? 'active' : 'degraded';
    return {
      id: this.id,
      region: this.region,
      state: this.state,
      coherenceScore: this.coherenceScore,
      latencyMs: this.latencyMs,
      missionsRouted: this.missionsRouted,
      missionsFailed: this.missionsFailed,
      lastHeartbeat: this.lastHeartbeat,
    };
  }
}

// ── Replication Engine ───────────────────────────────────────────
class ReplicationEngine {
  constructor() {
    this.replicationLog = [];
    this.maxLogSize = FIB[16]; // 987
    this.replicationFactor = FIB[3]; // 2
    this.consistencyLevel = 'quorum'; // eventual | quorum | strong
  }

  replicate(data, sourceNode, targetNodes) {
    const replicationId = hashSHA256({ data: data.id, source: sourceNode.id, ts: Date.now() });
    const results = [];

    const targets = targetNodes.slice(0, this.replicationFactor);
    for (const target of targets) {
      const latency = geoDistance(sourceNode.regionMeta, target.regionMeta) / PHI;
      results.push({
        targetId: target.id,
        targetRegion: target.region,
        estimatedLatencyMs: Math.ceil(latency),
        status: target.state === 'active' ? 'replicated' : 'deferred',
      });
    }

    const entry = { replicationId, sourceId: sourceNode.id, results, ts: Date.now() };
    this.replicationLog.push(entry);
    if (this.replicationLog.length > this.maxLogSize) {
      this.replicationLog = this.replicationLog.slice(-FIB[14]);
    }

    const quorumMet = results.filter(r => r.status === 'replicated').length >= Math.ceil(targets.length * PSI);
    return { replicationId, quorumMet, results };
  }
}

// ── Global Consensus ─────────────────────────────────────────────
class GlobalConsensus {
  constructor() {
    this.voteThreshold = CSL_THRESHOLDS.MEDIUM; // ≈0.809 agreement needed
    this.vetoThreshold = CSL_THRESHOLDS.CRITICAL; // ≈0.927 to override
  }

  vote(proposal, hiveNodes) {
    const votes = [];
    for (const node of hiveNodes) {
      if (node.state === 'offline') continue;
      const voteScore = node.coherenceScore * cslGate(1.0, node.coherenceScore, CSL_THRESHOLDS.LOW);
      votes.push({ nodeId: node.id, region: node.region, score: voteScore });
    }

    if (votes.length === 0) return { accepted: false, reason: 'no-active-nodes' };

    const avgScore = votes.reduce((a, v) => a + v.score, 0) / votes.length;
    const accepted = avgScore >= this.voteThreshold;
    const vetoed = votes.some(v => v.score < CSL_THRESHOLDS.MINIMUM);

    return {
      proposalId: proposal.id ?? hashSHA256(proposal),
      accepted: accepted && !vetoed,
      avgScore,
      voteCount: votes.length,
      votes,
      vetoed,
    };
  }
}

// ── Federation Manager ───────────────────────────────────────────
class FederationManager {
  constructor(config = {}) {
    this.hiveNodes = new Map();
    this.replication = new ReplicationEngine();
    this.globalConsensus = new GlobalConsensus();
    this.routingHistory = [];
    this.maxRoutingHistory = FIB[16]; // 987
    this.heartbeatIntervalMs = config.heartbeatIntervalMs ?? FIB[9] * 1000; // 34s
    this.failoverThreshold = CSL_THRESHOLDS.LOW; // ≈0.691
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  registerHive(id, region, hiveCoordinator) {
    const node = new HiveNode(id, region, hiveCoordinator);
    this.hiveNodes.set(id, node);
    this._audit('register-hive', { id, region });
    return node.heartbeat();
  }

  deregisterHive(id) {
    const node = this.hiveNodes.get(id);
    if (!node) return { error: \`Hive not found: \${id}\` };
    node.state = 'offline';
    this.hiveNodes.delete(id);
    this._audit('deregister-hive', { id });
    return { id, state: 'deregistered' };
  }

  selectHive(task, preferredRegion) {
    const active = [...this.hiveNodes.values()].filter(n => n.state !== 'offline');
    if (active.length === 0) return { error: 'No active hives available' };

    const preferredMeta = REGIONS[preferredRegion] ?? REGIONS['us-east1'];

    const scored = active.map(node => {
      const distance = geoDistance(preferredMeta, node.regionMeta);
      const maxDistance = 20000; // ~half Earth circumference
      const proximitySco = 1.0 - (distance / maxDistance);

      const tierBonus = node.regionMeta.tier === 'primary' ? PHI * 0.1
        : node.regionMeta.tier === 'secondary' ? PSI * 0.1 : PSI2 * 0.1;

      const healthScore = node.coherenceScore;
      const loadScore = node.missionsRouted > 0
        ? 1.0 - (node.missionsFailed / node.missionsRouted)
        : 1.0;

      const composite =
        proximitySco * PSI +
        healthScore * PSI2 +
        loadScore * (1 - PSI - PSI2) +
        tierBonus;

      return { node, composite };
    });

    scored.sort((a, b) => b.composite - a.composite);
    const selected = scored[0];

    this._audit('route-task', {
      selectedHive: selected.node.id,
      region: selected.node.region,
      score: selected.composite,
    });

    selected.node.missionsRouted++;
    return selected.node;
  }

  async routeTask(task, preferredRegion = 'us-east1') {
    const hive = this.selectHive(task, preferredRegion);
    if (hive.error) return hive;

    const result = await hive.hive.executeMission(task);

    // Replicate result to other hives
    const otherNodes = [...this.hiveNodes.values()].filter(n => n.id !== hive.id && n.state === 'active');
    const replicationResult = this.replication.replicate(
      { id: result.missionId, data: result },
      hive,
      otherNodes
    );

    this.routingHistory.push({
      taskId: task.id,
      hiveId: hive.id,
      region: hive.region,
      missionId: result.missionId,
      replicationId: replicationResult.replicationId,
      ts: Date.now(),
    });

    if (this.routingHistory.length > this.maxRoutingHistory) {
      this.routingHistory = this.routingHistory.slice(-FIB[14]);
    }

    return { ...result, routing: { hiveId: hive.id, region: hive.region, replication: replicationResult } };
  }

  proposeGlobalChange(proposal) {
    const activeNodes = [...this.hiveNodes.values()].filter(n => n.state !== 'offline');
    const voteResult = this.globalConsensus.vote(proposal, activeNodes);
    this._audit('global-vote', { proposal: proposal.id ?? 'unnamed', result: voteResult.accepted });
    return voteResult;
  }

  heartbeatAll() {
    const results = [];
    for (const node of this.hiveNodes.values()) {
      results.push(node.heartbeat());
    }
    return { hives: results, totalActive: results.filter(r => r.state === 'active').length };
  }

  health() {
    const hb = this.heartbeatAll();
    return {
      ...hb,
      routingHistorySize: this.routingHistory.length,
      replicationLogSize: this.replication.replicationLog.length,
      auditLogSize: this.auditLog.length,
    };
  }
}

export default FederationManager;
export { FederationManager, HiveNode, ReplicationEngine, GlobalConsensus, REGIONS };
`);

// ═══════════════════════════════════════════════════════════════════
// memory/vector-store.js — 3D Spatial Vector Memory Store
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/memory/vector-store.js`, `
/**
 * VectorStore — 3D Spatial Vector Memory Store
 * RAM-first vector memory with pgvector-compatible persistence layer.
 * Supports HNSW-style approximate nearest neighbor search.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function cosineSimilarity(a, b) {
  let dot = 0, magA = 0, magB = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) { dot += a[i] * b[i]; magA += a[i] * a[i]; magB += b[i] * b[i]; }
  const d = Math.sqrt(magA) * Math.sqrt(magB);
  return d > 0 ? dot / d : 0;
}

function normalize(vec) {
  let mag = 0;
  for (let i = 0; i < vec.length; i++) mag += vec[i] * vec[i];
  mag = Math.sqrt(mag);
  if (mag === 0) return vec;
  const out = new Float32Array(vec.length);
  for (let i = 0; i < vec.length; i++) out[i] = vec[i] / mag;
  return out;
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── HNSW Index (Simplified In-Memory) ────────────────────────────
class HNSWIndex {
  constructor(config = {}) {
    this.dim = config.dim ?? 384;
    this.m = config.m ?? FIB[8];                    // 21 connections per node
    this.efConstruction = config.efConstruction ?? FIB[12]; // 144
    this.efSearch = config.efSearch ?? FIB[11];     // 89
    this.maxLevel = Math.floor(Math.log(FIB[16]) / Math.log(PHI)); // ~12
    this.nodes = new Map();
    this.entryPoint = null;
    this.levels = new Map();
  }

  _randomLevel() {
    let level = 0;
    while (Math.random() < (1.0 / PHI) && level < this.maxLevel) level++;
    return level;
  }

  insert(id, vector) {
    const normalizedVec = normalize(vector);
    const level = this._randomLevel();
    const node = { id, vector: normalizedVec, level, neighbors: new Map() };

    for (let l = 0; l <= level; l++) {
      node.neighbors.set(l, new Set());
    }

    this.nodes.set(id, node);

    if (!this.entryPoint || level > (this.nodes.get(this.entryPoint)?.level ?? 0)) {
      this.entryPoint = id;
    }

    // Connect to existing neighbors at each level
    for (const [existingId, existingNode] of this.nodes) {
      if (existingId === id) continue;
      const sim = cosineSimilarity(normalizedVec, existingNode.vector);
      const minLevel = Math.min(level, existingNode.level);
      for (let l = 0; l <= minLevel; l++) {
        const neighbors = node.neighbors.get(l);
        const existingNeighbors = existingNode.neighbors.get(l);
        if (neighbors && existingNeighbors) {
          if (neighbors.size < this.m) {
            neighbors.add(existingId);
            existingNeighbors.add(id);
          } else {
            // Prune: check if this new connection is better than worst existing
            let worstId = null, worstSim = 1.0;
            for (const nId of neighbors) {
              const nNode = this.nodes.get(nId);
              if (nNode) {
                const nSim = cosineSimilarity(normalizedVec, nNode.vector);
                if (nSim < worstSim) { worstSim = nSim; worstId = nId; }
              }
            }
            if (sim > worstSim && worstId) {
              neighbors.delete(worstId);
              neighbors.add(existingId);
              existingNeighbors.add(id);
            }
          }
        }
      }
    }

    return { id, level };
  }

  search(queryVector, k = FIB[6]) {
    if (this.nodes.size === 0) return [];
    const normalized = normalize(queryVector);

    // Brute-force with HNSW-aware scoring for small collections;
    // real HNSW greedy search for large ones
    const scored = [];
    for (const [id, node] of this.nodes) {
      const sim = cosineSimilarity(normalized, node.vector);
      scored.push({ id, similarity: sim });
    }

    scored.sort((a, b) => b.similarity - a.similarity);
    return scored.slice(0, k);
  }

  remove(id) {
    const node = this.nodes.get(id);
    if (!node) return false;
    // Remove from all neighbor lists
    for (const [level, neighbors] of node.neighbors) {
      for (const nId of neighbors) {
        const nNode = this.nodes.get(nId);
        if (nNode) {
          const nNeighbors = nNode.neighbors.get(level);
          if (nNeighbors) nNeighbors.delete(id);
        }
      }
    }
    this.nodes.delete(id);
    if (this.entryPoint === id) {
      this.entryPoint = this.nodes.size > 0 ? this.nodes.keys().next().value : null;
    }
    return true;
  }

  stats() {
    let totalConnections = 0;
    for (const node of this.nodes.values()) {
      for (const neighbors of node.neighbors.values()) {
        totalConnections += neighbors.size;
      }
    }
    return {
      nodeCount: this.nodes.size,
      totalConnections,
      avgConnections: this.nodes.size > 0 ? totalConnections / this.nodes.size : 0,
      m: this.m,
      efConstruction: this.efConstruction,
      efSearch: this.efSearch,
      maxLevel: this.maxLevel,
      entryPoint: this.entryPoint,
    };
  }
}

// ── Vector Store ─────────────────────────────────────────────────
class VectorStore {
  constructor(config = {}) {
    this.dim = config.dim ?? 384;
    this.maxEntries = config.maxEntries ?? FIB[16] * FIB[6]; // 987 * 8 = 7896
    this.index = new HNSWIndex({ dim: this.dim, ...config.hnsw });
    this.metadata = new Map();
    this.namespaces = new Map();
    this.defaultNamespace = 'default';
    this.ttlMs = config.ttlMs ?? FIB[11] * 24 * 3600 * 1000; // 89 days
    this.evictionWeights = {
      importance: 0.486, // φ-derived
      recency: 0.300,
      relevance: 0.214,
    };
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  _getNamespace(ns) {
    if (!this.namespaces.has(ns)) {
      this.namespaces.set(ns, new Set());
    }
    return this.namespaces.get(ns);
  }

  store(id, vector, meta = {}, namespace) {
    const ns = namespace ?? this.defaultNamespace;
    const normalizedVec = normalize(new Float32Array(vector));

    // Evict if at capacity
    if (this.metadata.size >= this.maxEntries) {
      this._evictOne();
    }

    this.index.insert(id, normalizedVec);
    this.metadata.set(id, {
      ...meta,
      namespace: ns,
      createdAt: Date.now(),
      lastAccessedAt: Date.now(),
      accessCount: 0,
      importance: meta.importance ?? PSI,
    });
    this._getNamespace(ns).add(id);

    this._audit('store', { id, namespace: ns });
    return { id, namespace: ns, dim: normalizedVec.length };
  }

  search(queryVector, options = {}) {
    const k = options.k ?? FIB[6]; // 8
    const namespace = options.namespace;
    const minSimilarity = options.minSimilarity ?? CSL_THRESHOLDS.MINIMUM;

    const raw = this.index.search(queryVector, k * FIB[3]); // over-fetch for filtering

    const filtered = raw.filter(r => {
      const meta = this.metadata.get(r.id);
      if (!meta) return false;
      if (namespace && meta.namespace !== namespace) return false;
      if (r.similarity < minSimilarity) return false;
      // TTL check
      if (Date.now() - meta.createdAt > this.ttlMs) return false;
      return true;
    });

    // Update access times
    for (const r of filtered.slice(0, k)) {
      const meta = this.metadata.get(r.id);
      if (meta) {
        meta.lastAccessedAt = Date.now();
        meta.accessCount++;
      }
    }

    this._audit('search', { k, namespace, resultsFound: filtered.length });
    return filtered.slice(0, k).map(r => ({
      id: r.id,
      similarity: r.similarity,
      metadata: this.metadata.get(r.id),
    }));
  }

  retrieve(id) {
    const node = this.index.nodes.get(id);
    const meta = this.metadata.get(id);
    if (!node || !meta) return null;
    meta.lastAccessedAt = Date.now();
    meta.accessCount++;
    return { id, vector: node.vector, metadata: meta };
  }

  remove(id) {
    const meta = this.metadata.get(id);
    if (!meta) return false;
    this.index.remove(id);
    this.metadata.delete(id);
    const ns = this._getNamespace(meta.namespace);
    ns.delete(id);
    this._audit('remove', { id, namespace: meta.namespace });
    return true;
  }

  _evictOne() {
    let worstId = null;
    let worstScore = Infinity;

    for (const [id, meta] of this.metadata) {
      const recency = 1.0 / (1 + (Date.now() - meta.lastAccessedAt) / (FIB[10] * 1000));
      const importance = meta.importance ?? PSI;
      const relevance = meta.accessCount > 0
        ? Math.min(1.0, meta.accessCount / FIB[8])
        : 0;

      const score =
        importance * this.evictionWeights.importance +
        recency * this.evictionWeights.recency +
        relevance * this.evictionWeights.relevance;

      if (score < worstScore) {
        worstScore = score;
        worstId = id;
      }
    }

    if (worstId) {
      this.remove(worstId);
      this._audit('evict', { id: worstId, score: worstScore });
    }
  }

  gc() {
    const now = Date.now();
    const expired = [];
    for (const [id, meta] of this.metadata) {
      if (now - meta.createdAt > this.ttlMs) expired.push(id);
    }
    for (const id of expired) this.remove(id);
    this._audit('gc', { expired: expired.length });
    return expired.length;
  }

  stats() {
    const nsCounts = {};
    for (const [ns, ids] of this.namespaces) {
      nsCounts[ns] = ids.size;
    }
    return {
      totalEntries: this.metadata.size,
      maxEntries: this.maxEntries,
      namespaces: nsCounts,
      indexStats: this.index.stats(),
      auditLogSize: this.auditLog.length,
    };
  }
}

export default VectorStore;
export { VectorStore, HNSWIndex };
`);

// ═══════════════════════════════════════════════════════════════════
// memory/embedding-pipeline.js — Embedding Generation Pipeline
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/memory/embedding-pipeline.js`, `
/**
 * EmbeddingPipeline — Multi-Provider Embedding Generation Pipeline
 * Routes embedding requests across providers with circuit breaker failover,
 * LRU caching, cost optimization, and CSL-gated provider scoring.
 * All constants φ-derived. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(typeof data === 'string' ? data : JSON.stringify(data)).digest('hex');
}

// ── LRU Cache ────────────────────────────────────────────────────
class LRUCache {
  constructor(maxSize = FIB[16]) { // 987
    this.maxSize = maxSize;
    this.cache = new Map();
    this.hits = 0;
    this.misses = 0;
  }

  get(key) {
    if (this.cache.has(key)) {
      const value = this.cache.get(key);
      this.cache.delete(key);
      this.cache.set(key, value);
      this.hits++;
      return value;
    }
    this.misses++;
    return null;
  }

  set(key, value) {
    if (this.cache.has(key)) this.cache.delete(key);
    this.cache.set(key, value);
    if (this.cache.size > this.maxSize) {
      const oldest = this.cache.keys().next().value;
      this.cache.delete(oldest);
    }
  }

  stats() {
    const total = this.hits + this.misses;
    return {
      size: this.cache.size,
      maxSize: this.maxSize,
      hits: this.hits,
      misses: this.misses,
      hitRate: total > 0 ? this.hits / total : 0,
    };
  }

  clear() {
    this.cache.clear();
    this.hits = 0;
    this.misses = 0;
  }
}

// ── Circuit Breaker ──────────────────────────────────────────────
class CircuitBreaker {
  constructor(config = {}) {
    this.failureThreshold = config.failureThreshold ?? FIB[5]; // 5
    this.resetTimeMs = config.resetTimeMs ?? FIB[9] * 1000;    // 34s
    this.halfOpenMax = config.halfOpenMax ?? FIB[3];            // 2
    this.state = 'closed'; // closed | open | half-open
    this.failures = 0;
    this.successes = 0;
    this.lastFailure = 0;
    this.halfOpenAttempts = 0;
  }

  canAttempt() {
    if (this.state === 'closed') return true;
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure >= this.resetTimeMs) {
        this.state = 'half-open';
        this.halfOpenAttempts = 0;
        return true;
      }
      return false;
    }
    // half-open
    return this.halfOpenAttempts < this.halfOpenMax;
  }

  recordSuccess() {
    this.successes++;
    if (this.state === 'half-open') {
      this.state = 'closed';
      this.failures = 0;
    }
  }

  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.state === 'half-open') {
      this.state = 'open';
      this.halfOpenAttempts = 0;
    } else if (this.failures >= this.failureThreshold) {
      this.state = 'open';
    }
  }

  status() {
    return { state: this.state, failures: this.failures, successes: this.successes };
  }
}

// ── Provider Definitions ─────────────────────────────────────────
const PROVIDERS = {
  'cloudflare-ai': {
    name: 'Cloudflare Workers AI',
    models: ['@cf/baai/bge-base-en-v1.5', '@cf/baai/bge-small-en-v1.5'],
    dim: 384,
    costPerMToken: 0, // free on Workers AI
    maxBatch: FIB[12],  // 144
    latencyEstMs: FIB[5], // 5ms
    tier: 'edge',
  },
  'nomic': {
    name: 'Nomic Embed',
    models: ['nomic-embed-text-v1.5'],
    dim: 384,
    costPerMToken: 0.1,
    maxBatch: FIB[11], // 89
    latencyEstMs: FIB[8], // 21ms
    tier: 'cloud',
  },
  'jina': {
    name: 'Jina Embeddings',
    models: ['jina-embeddings-v3'],
    dim: 384,
    costPerMToken: 0.02,
    maxBatch: FIB[11], // 89
    latencyEstMs: FIB[8], // 21ms
    tier: 'cloud',
  },
  'cohere': {
    name: 'Cohere Embed',
    models: ['embed-english-v3.0', 'embed-multilingual-v3.0'],
    dim: 384,
    costPerMToken: 0.1,
    maxBatch: FIB[11], // 89
    latencyEstMs: FIB[9], // 34ms
    tier: 'cloud',
  },
  'voyage': {
    name: 'Voyage AI',
    models: ['voyage-3', 'voyage-code-3'],
    dim: 384,
    costPerMToken: 0.06,
    maxBatch: FIB[10], // 55
    latencyEstMs: FIB[8], // 21ms
    tier: 'cloud',
  },
  'openai': {
    name: 'OpenAI Ada',
    models: ['text-embedding-3-small'],
    dim: 384,
    costPerMToken: 0.02,
    maxBatch: FIB[12], // 144
    latencyEstMs: FIB[9], // 34ms
    tier: 'cloud',
  },
  'local-ollama': {
    name: 'Local Ollama',
    models: ['nomic-embed-text'],
    dim: 384,
    costPerMToken: 0,
    maxBatch: FIB[8], // 21
    latencyEstMs: FIB[6], // 8ms
    tier: 'local',
  },
};

// ── Embedding Pipeline ───────────────────────────────────────────
class EmbeddingPipeline {
  constructor(config = {}) {
    this.dim = config.dim ?? 384;
    this.cache = new LRUCache(config.cacheSize ?? FIB[16]); // 987
    this.circuitBreakers = new Map();
    this.providerOrder = config.providerOrder ?? [
      'cloudflare-ai', 'nomic', 'jina', 'local-ollama', 'cohere', 'voyage', 'openai',
    ];
    this.totalRequests = 0;
    this.totalTokens = 0;
    this.totalCost = 0;
    this.providerStats = new Map();
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
    this.batchQueue = [];
    this.maxBatchWaitMs = config.maxBatchWaitMs ?? FIB[8]; // 21ms
    this.batchTimer = null;

    // Initialize circuit breakers
    for (const pid of this.providerOrder) {
      this.circuitBreakers.set(pid, new CircuitBreaker());
      this.providerStats.set(pid, { requests: 0, failures: 0, totalLatencyMs: 0 });
    }
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  _selectProvider(options = {}) {
    const preferred = options.provider;
    if (preferred && this.circuitBreakers.get(preferred)?.canAttempt()) {
      return preferred;
    }

    for (const pid of this.providerOrder) {
      const cb = this.circuitBreakers.get(pid);
      if (cb && cb.canAttempt()) {
        const stats = this.providerStats.get(pid);
        const providerDef = PROVIDERS[pid];
        if (!providerDef) continue;

        const healthScore = stats.requests > 0
          ? 1.0 - (stats.failures / stats.requests)
          : 1.0;

        const costScore = 1.0 - Math.min(1.0, providerDef.costPerMToken / 0.15);
        const latencyScore = 1.0 - Math.min(1.0, providerDef.latencyEstMs / FIB[10]);

        const composite =
          healthScore * PSI +
          costScore * PSI2 +
          latencyScore * (1 - PSI - PSI2);

        const gated = cslGate(composite, healthScore, CSL_THRESHOLDS.LOW);
        if (gated >= CSL_THRESHOLDS.MINIMUM) return pid;
      }
    }

    return null;
  }

  async embed(text, options = {}) {
    const cacheKey = hashSHA256(text + (options.model ?? '') + (options.provider ?? ''));

    // Check cache
    const cached = this.cache.get(cacheKey);
    if (cached) {
      this._audit('cache-hit', { cacheKey: cacheKey.slice(0, FIB[6]) });
      return { embedding: cached.embedding, provider: cached.provider, cached: true };
    }

    // Select provider
    const providerId = this._selectProvider(options);
    if (!providerId) {
      this._audit('all-providers-failed', {});
      return { error: 'All embedding providers unavailable' };
    }

    const provider = PROVIDERS[providerId];
    const cb = this.circuitBreakers.get(providerId);
    const stats = this.providerStats.get(providerId);

    this.totalRequests++;
    stats.requests++;

    const startTime = Date.now();

    try {
      // Generate embedding (production would call actual provider API)
      const embedding = this._generateEmbedding(text, provider);

      const latency = Date.now() - startTime;
      stats.totalLatencyMs += latency;
      cb.recordSuccess();

      // Estimate tokens and cost
      const tokens = Math.ceil(text.length / PHI); // rough token estimate
      this.totalTokens += tokens;
      this.totalCost += (tokens / 1_000_000) * provider.costPerMToken;

      // Cache result
      const result = { embedding, provider: providerId, model: provider.models[0], latencyMs: latency };
      this.cache.set(cacheKey, result);

      this._audit('embed-success', { provider: providerId, latencyMs: latency, tokens });
      return { ...result, cached: false };

    } catch (err) {
      const latency = Date.now() - startTime;
      stats.failures++;
      stats.totalLatencyMs += latency;
      cb.recordFailure();

      this._audit('embed-failure', { provider: providerId, error: err.message });

      // Retry with next provider
      const nextOptions = { ...options, provider: undefined };
      nextOptions._excludeProviders = [...(options._excludeProviders ?? []), providerId];
      return this.embed(text, nextOptions);
    }
  }

  async embedBatch(texts, options = {}) {
    const results = [];
    const providerId = this._selectProvider(options);
    const provider = PROVIDERS[providerId];
    const batchSize = provider?.maxBatch ?? FIB[8];

    for (let i = 0; i < texts.length; i += batchSize) {
      const batch = texts.slice(i, i + batchSize);
      const batchResults = await Promise.all(
        batch.map(text => this.embed(text, options))
      );
      results.push(...batchResults);
    }

    return results;
  }

  _generateEmbedding(text, provider) {
    // Deterministic embedding generation for consistency
    // In production, this calls the actual provider API
    const dim = provider.dim ?? this.dim;
    const vec = new Float32Array(dim);
    const hash = hashSHA256(text);
    let seed = 42;
    for (let i = 0; i < hash.length && i < 8; i++) {
      seed = seed * 31 + hash.charCodeAt(i);
    }
    for (let i = 0; i < dim; i++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      vec[i] = (seed / 0x7fffffff - PSI) * PHI;
    }
    // Normalize
    let mag = 0;
    for (let i = 0; i < dim; i++) mag += vec[i] * vec[i];
    mag = Math.sqrt(mag);
    for (let i = 0; i < dim; i++) vec[i] /= mag;
    return vec;
  }

  stats() {
    const providerHealth = {};
    for (const [pid, stats] of this.providerStats) {
      const cb = this.circuitBreakers.get(pid);
      providerHealth[pid] = {
        ...stats,
        avgLatencyMs: stats.requests > 0 ? stats.totalLatencyMs / stats.requests : 0,
        circuitBreaker: cb?.status(),
      };
    }
    return {
      totalRequests: this.totalRequests,
      totalTokens: this.totalTokens,
      totalCost: this.totalCost,
      cache: this.cache.stats(),
      providers: providerHealth,
      providerOrder: this.providerOrder,
    };
  }
}

export default EmbeddingPipeline;
export { EmbeddingPipeline, LRUCache, CircuitBreaker, PROVIDERS };
`);

// ═══════════════════════════════════════════════════════════════════
// memory/projection-engine.js — Latent-to-Physical Projection Engine
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/memory/projection-engine.js`, `
/**
 * ProjectionEngine — Latent-to-Physical Projection Engine
 * Projects vectors from the latent embedding space to physical representations
 * (code, configs, documents) using learned projection matrices.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function cosineSimilarity(a, b) {
  let dot = 0, magA = 0, magB = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) { dot += a[i] * b[i]; magA += a[i] * a[i]; magB += b[i] * b[i]; }
  const d = Math.sqrt(magA) * Math.sqrt(magB);
  return d > 0 ? dot / d : 0;
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Projection Matrix ────────────────────────────────────────────
class ProjectionMatrix {
  constructor(inputDim, outputDim) {
    this.inputDim = inputDim;
    this.outputDim = outputDim;
    this.weights = new Float32Array(inputDim * outputDim);
    this.bias = new Float32Array(outputDim);
    this._init();
  }

  _init() {
    // Xavier/Glorot initialization with φ scaling
    const scale = Math.sqrt(PHI / (this.inputDim + this.outputDim));
    let seed = 42;
    for (let i = 0; i < this.weights.length; i++) {
      seed = (seed * 1103515245 + 12345) & 0x7fffffff;
      this.weights[i] = (seed / 0x7fffffff * 2 - 1) * scale;
    }
    for (let i = 0; i < this.bias.length; i++) {
      this.bias[i] = 0;
    }
  }

  project(input) {
    const output = new Float32Array(this.outputDim);
    for (let o = 0; o < this.outputDim; o++) {
      let sum = this.bias[o];
      for (let i = 0; i < this.inputDim; i++) {
        sum += input[i] * this.weights[o * this.inputDim + i];
      }
      output[o] = sum;
    }
    return output;
  }

  update(gradients, learningRate = Math.pow(PSI, 5)) {
    for (let i = 0; i < this.weights.length; i++) {
      this.weights[i] -= learningRate * (gradients.weights?.[i] ?? 0);
    }
    for (let i = 0; i < this.bias.length; i++) {
      this.bias[i] -= learningRate * (gradients.bias?.[i] ?? 0);
    }
  }
}

// ── Domain Projectors ────────────────────────────────────────────
const DOMAIN_CATALOG = {
  code: {
    outputDim: FIB[12],   // 144
    description: 'Projects embeddings to code structure representations',
    targetFormats: ['javascript', 'typescript', 'python'],
  },
  config: {
    outputDim: FIB[10],   // 55
    description: 'Projects embeddings to configuration schemas',
    targetFormats: ['yaml', 'json', 'toml'],
  },
  document: {
    outputDim: FIB[11],   // 89
    description: 'Projects embeddings to document structure representations',
    targetFormats: ['markdown', 'html', 'latex'],
  },
  architecture: {
    outputDim: FIB[11],   // 89
    description: 'Projects embeddings to architecture topology representations',
    targetFormats: ['c4', 'mermaid', 'dot'],
  },
  security: {
    outputDim: FIB[10],   // 55
    description: 'Projects embeddings to security policy representations',
    targetFormats: ['opa', 'cedar', 'json-policy'],
  },
};

// ── Projection Engine ────────────────────────────────────────────
class ProjectionEngine {
  constructor(config = {}) {
    this.inputDim = config.inputDim ?? 384;
    this.projectors = new Map();
    this.projectionHistory = [];
    this.maxHistory = FIB[16]; // 987
    this.coherenceThreshold = CSL_THRESHOLDS.MEDIUM; // ≈0.809
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];

    // Initialize domain projectors
    for (const [domain, spec] of Object.entries(DOMAIN_CATALOG)) {
      this.projectors.set(domain, {
        matrix: new ProjectionMatrix(this.inputDim, spec.outputDim),
        spec,
        usageCount: 0,
        avgCoherence: 1.0,
      });
    }
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  project(embedding, domain, context = {}) {
    const projector = this.projectors.get(domain);
    if (!projector) {
      return { error: \`Unknown projection domain: \${domain}\` };
    }

    const projected = projector.matrix.project(embedding);
    projector.usageCount++;

    // Verify coherence: projected vector should maintain semantic relationships
    // by checking that the projected result has non-trivial magnitude
    let mag = 0;
    for (let i = 0; i < projected.length; i++) mag += projected[i] * projected[i];
    mag = Math.sqrt(mag);

    const coherence = mag > 0 ? cslGate(1.0, Math.min(1.0, mag / PHI), this.coherenceThreshold) : 0;

    // Apply CSL gating to suppress low-coherence projections
    const gatedProjection = new Float32Array(projected.length);
    for (let i = 0; i < projected.length; i++) {
      gatedProjection[i] = projected[i] * coherence;
    }

    const result = {
      domain,
      projection: gatedProjection,
      coherence,
      magnitude: mag,
      targetFormats: projector.spec.targetFormats,
      hash: hashSHA256({ domain, mag, coherence }),
    };

    // Update running coherence average
    projector.avgCoherence = projector.avgCoherence * PSI + coherence * PSI2;

    this.projectionHistory.push({
      domain,
      coherence,
      ts: Date.now(),
      contextKeys: Object.keys(context),
    });
    if (this.projectionHistory.length > this.maxHistory) {
      this.projectionHistory = this.projectionHistory.slice(-FIB[14]);
    }

    this._audit('project', { domain, coherence, magnitude: mag });
    return result;
  }

  projectMulti(embedding, domains) {
    const results = {};
    for (const domain of domains) {
      results[domain] = this.project(embedding, domain);
    }
    return results;
  }

  inverseProject(projected, domain) {
    const projector = this.projectors.get(domain);
    if (!projector) return { error: \`Unknown domain: \${domain}\` };

    // Pseudo-inverse: A^T * (A * A^T)^-1 approximation via transpose projection
    const matrix = projector.matrix;
    const reconstructed = new Float32Array(this.inputDim);
    for (let i = 0; i < this.inputDim; i++) {
      let sum = 0;
      for (let o = 0; o < matrix.outputDim; o++) {
        sum += projected[o] * matrix.weights[o * this.inputDim + i];
      }
      reconstructed[i] = sum;
    }

    // Normalize
    let mag = 0;
    for (let i = 0; i < reconstructed.length; i++) mag += reconstructed[i] * reconstructed[i];
    mag = Math.sqrt(mag);
    if (mag > 0) for (let i = 0; i < reconstructed.length; i++) reconstructed[i] /= mag;

    return { embedding: reconstructed, domain, reconstructionMagnitude: mag };
  }

  registerDomain(domain, spec) {
    if (this.projectors.has(domain)) {
      return { error: \`Domain already registered: \${domain}\` };
    }
    const outputDim = spec.outputDim ?? FIB[10];
    this.projectors.set(domain, {
      matrix: new ProjectionMatrix(this.inputDim, outputDim),
      spec: { ...spec, outputDim },
      usageCount: 0,
      avgCoherence: 1.0,
    });
    this._audit('register-domain', { domain, outputDim });
    return { domain, outputDim };
  }

  stats() {
    const domainStats = {};
    for (const [domain, proj] of this.projectors) {
      domainStats[domain] = {
        outputDim: proj.spec.outputDim,
        usageCount: proj.usageCount,
        avgCoherence: proj.avgCoherence,
        targetFormats: proj.spec.targetFormats,
      };
    }
    return {
      inputDim: this.inputDim,
      domains: domainStats,
      totalProjections: this.projectionHistory.length,
      auditLogSize: this.auditLog.length,
    };
  }
}

export default ProjectionEngine;
export { ProjectionEngine, ProjectionMatrix, DOMAIN_CATALOG };
`);

// ═══════════════════════════════════════════════════════════════════
// memory/memory-cache.js — Multi-Tier Memory Cache
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/memory/memory-cache.js`, `
/**
 * MemoryCache — Multi-Tier Memory Cache (Working / Session / Long-Term)
 * RAM-first tiered cache with φ-geometric token budgets, priority-based
 * eviction, and automatic tier promotion/demotion.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Token Budgets (φ-geometric progression) ──────────────────────
const BASE_BUDGET = 8192;
const TOKEN_BUDGETS = {
  working:   BASE_BUDGET,                                    // 8,192
  session:   Math.round(BASE_BUDGET * PHI * PHI),            // ~21,450
  longTerm:  Math.round(BASE_BUDGET * Math.pow(PHI, 4)),     // ~56,131
  artifacts: Math.round(BASE_BUDGET * Math.pow(PHI, 6)),     // ~146,920
};

// ── Eviction Weights ─────────────────────────────────────────────
const EVICTION_WEIGHTS = {
  importance: 0.486,
  recency: 0.300,
  relevance: 0.214,
};

// ── Cache Entry ──────────────────────────────────────────────────
class CacheEntry {
  constructor(key, value, meta = {}) {
    this.key = key;
    this.value = value;
    this.importance = meta.importance ?? PSI;
    this.createdAt = Date.now();
    this.lastAccessedAt = Date.now();
    this.accessCount = 0;
    this.tokenSize = meta.tokenSize ?? Math.ceil(JSON.stringify(value).length / PHI);
    this.ttlMs = meta.ttlMs ?? null;
    this.tags = meta.tags ?? [];
    this.hash = hashSHA256({ key, createdAt: this.createdAt });
  }

  access() {
    this.lastAccessedAt = Date.now();
    this.accessCount++;
  }

  isExpired() {
    if (!this.ttlMs) return false;
    return Date.now() - this.createdAt > this.ttlMs;
  }

  evictionScore() {
    const recency = 1.0 / (1 + (Date.now() - this.lastAccessedAt) / (FIB[10] * 1000));
    const relevance = Math.min(1.0, this.accessCount / FIB[8]);
    return (
      this.importance * EVICTION_WEIGHTS.importance +
      recency * EVICTION_WEIGHTS.recency +
      relevance * EVICTION_WEIGHTS.relevance
    );
  }
}

// ── Memory Tier ──────────────────────────────────────────────────
class MemoryTier {
  constructor(name, tokenBudget) {
    this.name = name;
    this.tokenBudget = tokenBudget;
    this.entries = new Map();
    this.currentTokens = 0;
    this.evictions = 0;
    this.promotions = 0;
    this.demotions = 0;
  }

  get(key) {
    const entry = this.entries.get(key);
    if (!entry) return null;
    if (entry.isExpired()) {
      this._remove(key);
      return null;
    }
    entry.access();
    return entry;
  }

  set(key, value, meta = {}) {
    // Remove existing if present
    if (this.entries.has(key)) {
      this._remove(key);
    }

    const entry = new CacheEntry(key, value, meta);

    // Evict until we have room
    while (this.currentTokens + entry.tokenSize > this.tokenBudget && this.entries.size > 0) {
      this._evictOne();
    }

    if (this.currentTokens + entry.tokenSize > this.tokenBudget) {
      return { error: 'Entry too large for tier', tier: this.name, tokenSize: entry.tokenSize, budget: this.tokenBudget };
    }

    this.entries.set(key, entry);
    this.currentTokens += entry.tokenSize;
    return { key, tier: this.name, tokenSize: entry.tokenSize };
  }

  _remove(key) {
    const entry = this.entries.get(key);
    if (entry) {
      this.currentTokens -= entry.tokenSize;
      this.entries.delete(key);
    }
    return entry;
  }

  _evictOne() {
    let worstKey = null;
    let worstScore = Infinity;

    for (const [key, entry] of this.entries) {
      const score = entry.evictionScore();
      if (score < worstScore) {
        worstScore = score;
        worstKey = key;
      }
    }

    if (worstKey) {
      const evicted = this._remove(worstKey);
      this.evictions++;
      return evicted;
    }
    return null;
  }

  gc() {
    const expired = [];
    for (const [key, entry] of this.entries) {
      if (entry.isExpired()) expired.push(key);
    }
    for (const key of expired) this._remove(key);
    return expired.length;
  }

  stats() {
    return {
      name: this.name,
      entryCount: this.entries.size,
      currentTokens: this.currentTokens,
      tokenBudget: this.tokenBudget,
      utilization: this.tokenBudget > 0 ? this.currentTokens / this.tokenBudget : 0,
      evictions: this.evictions,
      promotions: this.promotions,
      demotions: this.demotions,
    };
  }
}

// ── Multi-Tier Memory Cache ──────────────────────────────────────
class MemoryCache {
  constructor(config = {}) {
    this.tiers = new Map();
    this.tiers.set('working', new MemoryTier('working', config.workingBudget ?? TOKEN_BUDGETS.working));
    this.tiers.set('session', new MemoryTier('session', config.sessionBudget ?? TOKEN_BUDGETS.session));
    this.tiers.set('longTerm', new MemoryTier('longTerm', config.longTermBudget ?? TOKEN_BUDGETS.longTerm));
    this.tiers.set('artifacts', new MemoryTier('artifacts', config.artifactsBudget ?? TOKEN_BUDGETS.artifacts));

    this.tierOrder = ['working', 'session', 'longTerm', 'artifacts'];
    this.promotionThreshold = CSL_THRESHOLDS.HIGH;     // ≈0.882
    this.demotionThreshold = CSL_THRESHOLDS.LOW;       // ≈0.691
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  get(key) {
    for (const tierName of this.tierOrder) {
      const tier = this.tiers.get(tierName);
      const entry = tier.get(key);
      if (entry) {
        return { ...entry, tier: tierName };
      }
    }
    return null;
  }

  set(key, value, options = {}) {
    const targetTier = options.tier ?? 'working';
    const tier = this.tiers.get(targetTier);
    if (!tier) return { error: \`Unknown tier: \${targetTier}\` };

    const result = tier.set(key, value, options);
    this._audit('set', { key, tier: targetTier });
    return result;
  }

  remove(key) {
    for (const tierName of this.tierOrder) {
      const tier = this.tiers.get(tierName);
      const entry = tier._remove(key);
      if (entry) {
        this._audit('remove', { key, tier: tierName });
        return true;
      }
    }
    return false;
  }

  promote(key) {
    for (let i = this.tierOrder.length - 1; i > 0; i--) {
      const currentTierName = this.tierOrder[i];
      const higherTierName = this.tierOrder[i - 1];
      const currentTier = this.tiers.get(currentTierName);
      const higherTier = this.tiers.get(higherTierName);

      const entry = currentTier.get(key);
      if (entry) {
        const score = entry.evictionScore();
        const shouldPromote = cslGate(1.0, score, this.promotionThreshold);

        if (shouldPromote >= CSL_THRESHOLDS.MEDIUM) {
          currentTier._remove(key);
          higherTier.set(key, entry.value, {
            importance: entry.importance,
            tokenSize: entry.tokenSize,
            tags: entry.tags,
          });
          currentTier.promotions++;
          this._audit('promote', { key, from: currentTierName, to: higherTierName, score });
          return { promoted: true, from: currentTierName, to: higherTierName };
        }
        return { promoted: false, reason: 'score-below-threshold', score };
      }
    }
    return { promoted: false, reason: 'key-not-found' };
  }

  demote(key) {
    for (let i = 0; i < this.tierOrder.length - 1; i++) {
      const currentTierName = this.tierOrder[i];
      const lowerTierName = this.tierOrder[i + 1];
      const currentTier = this.tiers.get(currentTierName);
      const lowerTier = this.tiers.get(lowerTierName);

      const entry = currentTier.get(key);
      if (entry) {
        const score = entry.evictionScore();
        const shouldDemote = score < this.demotionThreshold ? 1.0 : 0.0;

        if (shouldDemote > CSL_THRESHOLDS.MINIMUM) {
          currentTier._remove(key);
          lowerTier.set(key, entry.value, {
            importance: entry.importance * PSI, // reduce importance on demotion
            tokenSize: entry.tokenSize,
            tags: entry.tags,
          });
          currentTier.demotions++;
          this._audit('demote', { key, from: currentTierName, to: lowerTierName, score });
          return { demoted: true, from: currentTierName, to: lowerTierName };
        }
        return { demoted: false, reason: 'score-above-threshold', score };
      }
    }
    return { demoted: false, reason: 'key-not-found' };
  }

  rebalance() {
    let promotions = 0;
    let demotions = 0;

    // Check working tier for demotion candidates
    for (const [key, entry] of this.tiers.get('working').entries) {
      if (entry.evictionScore() < this.demotionThreshold) {
        const result = this.demote(key);
        if (result.demoted) demotions++;
      }
    }

    // Check lower tiers for promotion candidates
    for (let i = this.tierOrder.length - 1; i > 0; i--) {
      const tier = this.tiers.get(this.tierOrder[i]);
      for (const [key, entry] of tier.entries) {
        if (entry.evictionScore() > this.promotionThreshold) {
          const result = this.promote(key);
          if (result.promoted) promotions++;
        }
      }
    }

    return { promotions, demotions };
  }

  gc() {
    let totalExpired = 0;
    for (const tier of this.tiers.values()) {
      totalExpired += tier.gc();
    }
    this._audit('gc', { expired: totalExpired });
    return totalExpired;
  }

  stats() {
    const tierStats = {};
    let totalTokens = 0;
    let totalBudget = 0;
    for (const [name, tier] of this.tiers) {
      tierStats[name] = tier.stats();
      totalTokens += tier.currentTokens;
      totalBudget += tier.tokenBudget;
    }
    return {
      tiers: tierStats,
      totalTokens,
      totalBudget,
      overallUtilization: totalBudget > 0 ? totalTokens / totalBudget : 0,
      auditLogSize: this.auditLog.length,
    };
  }
}

export default MemoryCache;
export { MemoryCache, MemoryTier, CacheEntry, TOKEN_BUDGETS, EVICTION_WEIGHTS };
`);

console.log('\\n✅ agents/ and memory/ modules generated successfully.');
