/**
 * gen-wave4-part2.js — Wave 4 Part 2 Generator
 * 
 * Generates:
 *   security/html-sanitizer.js, security/ip-anomaly-detector.js, security/session-binder.js
 *   web/seo-engine.js, web/openapi-generator.js
 *   tests/load-test-k6.js, tests/chaos-engineering.js
 *   docs/postman-collection.json, docs/backup-strategy.md
 *
 * Eric Haywood — HeadySystems — All φ-derived constants, ESM, CSL gates, no stubs
 */

import { writeFileSync, mkdirSync } from 'fs';
import { dirname } from 'path';

const BASE = '/home/user/workspace/heady-max-potential';

function emit(rel, content) {
  const full = `${BASE}/${rel}`;
  mkdirSync(dirname(full), { recursive: true });
  writeFileSync(full, content, 'utf8');
  console.log(`  ✓ ${full} (${content.length} chars)`);
}

// ─────────────────────────────────────────────────────────────
// security/html-sanitizer.js
// ─────────────────────────────────────────────────────────────
emit('security/html-sanitizer.js', `/**
 * html-sanitizer.js — CSL-Gated HTML Sanitization Engine
 *
 * φ-scaled tag whitelist scoring, attribute filtering, and
 * deep-nested content sanitization using CSL gates instead of boolean allow/deny.
 *
 * Eric Haywood — HeadySystems
 * License: PROPRIETARY
 */

import { PHI, PSI, phiThreshold } from '../shared/phi-math.js';
import { createHash } from 'crypto';

// ── φ-Derived Constants ──────────────────────────────────
const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),  // ≈ 0.927
  HIGH:     phiThreshold(3),  // ≈ 0.882
  MEDIUM:   phiThreshold(2),  // ≈ 0.809
  LOW:      phiThreshold(1),  // ≈ 0.691
  MINIMUM:  phiThreshold(0),  // ≈ 0.500
};

const MAX_NESTING_DEPTH = 13;          // fib(7)
const MAX_ATTR_LENGTH   = 987;         // fib(16)
const MAX_INPUT_LENGTH  = 1597 * 100;  // fib(17) × 100 = 159700 chars
const CACHE_SIZE        = 233;         // fib(13)

// ── Tag Safety Scores (0..1, φ-scaled) ──────────────────
const TAG_SAFETY = new Map([
  // Safe content tags (HIGH+)
  ['p', 0.95], ['span', 0.95], ['div', 0.92], ['br', 0.98],
  ['strong', 0.95], ['em', 0.95], ['b', 0.95], ['i', 0.95],
  ['h1', 0.93], ['h2', 0.93], ['h3', 0.93], ['h4', 0.93], ['h5', 0.93], ['h6', 0.93],
  ['ul', 0.92], ['ol', 0.92], ['li', 0.92],
  ['blockquote', 0.90], ['pre', 0.90], ['code', 0.90],
  ['table', 0.88], ['thead', 0.88], ['tbody', 0.88], ['tr', 0.88], ['th', 0.88], ['td', 0.88],
  ['a', 0.82], ['img', 0.78],
  // Risky tags (below MEDIUM)
  ['form', 0.45], ['input', 0.40], ['textarea', 0.42],
  ['iframe', 0.15], ['script', 0.0], ['style', 0.10],
  ['object', 0.08], ['embed', 0.08], ['link', 0.20],
  ['meta', 0.25], ['base', 0.05],
]);

const SAFE_ATTRS = new Map([
  ['href', 0.80], ['src', 0.75], ['alt', 0.95], ['title', 0.95],
  ['class', 0.90], ['id', 0.85], ['width', 0.88], ['height', 0.88],
  ['colspan', 0.90], ['rowspan', 0.90], ['target', 0.70],
  ['rel', 0.82], ['aria-label', 0.95], ['role', 0.90],
  ['data-id', 0.85], ['data-type', 0.85],
]);

const DANGEROUS_PROTOCOLS = ['javascript:', 'vbscript:', 'data:text/html'];

// ── CSL Gate ────────────────────────────────────────────
function cslGate(value, score, threshold, temperature = PSI * PSI * PSI) {
  const sigmoid = 1 / (1 + Math.exp(-(score - threshold) / temperature));
  return value * sigmoid;
}

function isAllowed(score, threshold) {
  return cslGate(1, score, threshold) > CSL_THRESHOLDS.MINIMUM;
}

// ── Sanitization Cache (LRU, fib-sized) ──────────────────
const cache = new Map();
function cacheGet(key) {
  const v = cache.get(key);
  if (v !== undefined) { cache.delete(key); cache.set(key, v); }
  return v;
}
function cacheSet(key, val) {
  if (cache.size >= CACHE_SIZE) {
    const oldest = cache.keys().next().value;
    cache.delete(oldest);
  }
  cache.set(key, val);
}

// ── Core Sanitizer ──────────────────────────────────────
function escapeHtml(str) {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;');
}

function sanitizeAttrValue(name, value) {
  if (typeof value !== 'string') return '';
  const trimmed = value.slice(0, MAX_ATTR_LENGTH).trim();
  if (name === 'href' || name === 'src') {
    const lower = trimmed.toLowerCase().replace(/\\s+/g, '');
    for (const proto of DANGEROUS_PROTOCOLS) {
      if (lower.startsWith(proto)) return '';
    }
  }
  // Strip event handlers embedded in attr values
  return trimmed.replace(/javascript:/gi, '').replace(/on\\w+\\s*=/gi, '');
}

function sanitizeTag(tag, attrs, threshold = CSL_THRESHOLDS.MEDIUM) {
  const tagLower = tag.toLowerCase();
  const tagScore = TAG_SAFETY.get(tagLower) ?? 0;

  if (!isAllowed(tagScore, threshold)) return null;

  const safeAttrs = {};
  for (const [name, value] of Object.entries(attrs)) {
    const nameLower = name.toLowerCase();
    // Block event handlers unconditionally
    if (nameLower.startsWith('on')) continue;
    if (nameLower === 'style') continue; // XSS vector
    
    const attrScore = SAFE_ATTRS.get(nameLower) ?? (nameLower.startsWith('data-') ? 0.80 : 0.20);
    if (isAllowed(attrScore, CSL_THRESHOLDS.LOW)) {
      const sanitized = sanitizeAttrValue(nameLower, value);
      if (sanitized || sanitized === '') safeAttrs[nameLower] = sanitized;
    }
  }
  
  return { tag: tagLower, attrs: safeAttrs };
}

/**
 * Sanitize an HTML string, returning safe markup.
 * Uses regex-based parsing (no DOM dependency for server-side).
 */
export function sanitize(html, options = {}) {
  if (typeof html !== 'string') return '';
  if (html.length > MAX_INPUT_LENGTH) {
    html = html.slice(0, MAX_INPUT_LENGTH);
  }

  const threshold = options.threshold ?? CSL_THRESHOLDS.MEDIUM;
  const stripAll = options.stripAll ?? false;

  // Check cache
  const hashInput = createHash('sha256').update(html + threshold).digest('hex').slice(0, 21);
  const cached = cacheGet(hashInput);
  if (cached !== undefined) return cached;

  if (stripAll) {
    const result = html.replace(/<[^>]*>/g, '').trim();
    cacheSet(hashInput, result);
    return result;
  }

  // Parse and sanitize
  let result = '';
  let depth = 0;
  const tagRegex = /<(\\/?)([a-zA-Z][a-zA-Z0-9]*)([^>]*?)(\\/?)>/g;
  let lastIndex = 0;
  let match;

  while ((match = tagRegex.exec(html)) !== null) {
    // Add text between tags (escaped)
    if (match.index > lastIndex) {
      result += escapeHtml(html.slice(lastIndex, match.index));
    }
    lastIndex = match.index + match[0].length;

    const [, isClosing, tagName, attrStr, selfClosing] = match;

    if (isClosing) {
      depth = Math.max(0, depth - 1);
      const tagScore = TAG_SAFETY.get(tagName.toLowerCase()) ?? 0;
      if (isAllowed(tagScore, threshold)) {
        result += \`</\${tagName.toLowerCase()}>\`;
      }
      continue;
    }

    if (depth >= MAX_NESTING_DEPTH) continue;

    // Parse attributes
    const attrs = {};
    const attrRegex = /([a-zA-Z][a-zA-Z0-9-]*)\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s>]+))/g;
    let attrMatch;
    while ((attrMatch = attrRegex.exec(attrStr)) !== null) {
      attrs[attrMatch[1]] = attrMatch[2] ?? attrMatch[3] ?? attrMatch[4] ?? '';
    }

    const sanitized = sanitizeTag(tagName, attrs, threshold);
    if (!sanitized) continue;

    const attrString = Object.entries(sanitized.attrs)
      .map(([k, v]) => v ? \`\${k}="\${escapeHtml(v)}"\` : k)
      .join(' ');

    result += \`<\${sanitized.tag}\${attrString ? ' ' + attrString : ''}\${selfClosing ? ' /' : ''}>\`;
    if (!selfClosing) depth++;
  }

  // Remaining text
  if (lastIndex < html.length) {
    result += escapeHtml(html.slice(lastIndex));
  }

  cacheSet(hashInput, result);
  return result;
}

/**
 * Validate that a string contains no dangerous HTML
 */
export function isClean(html) {
  const sanitized = sanitize(html);
  return sanitized === html;
}

export { TAG_SAFETY, SAFE_ATTRS, CSL_THRESHOLDS, sanitizeTag };
export default { sanitize, isClean, sanitizeTag, TAG_SAFETY, SAFE_ATTRS };
`);

// ─────────────────────────────────────────────────────────────
// security/ip-anomaly-detector.js
// ─────────────────────────────────────────────────────────────
emit('security/ip-anomaly-detector.js', `/**
 * ip-anomaly-detector.js — CSL-Gated IP Anomaly Detection
 *
 * Detects anomalous IP patterns using φ-scaled sliding windows,
 * exponential decay scoring, and CSL gate thresholds for threat classification.
 *
 * Eric Haywood — HeadySystems
 * License: PROPRIETARY
 */

import { PHI, PSI, phiThreshold, fibSequence } from '../shared/phi-math.js';
import { createHash } from 'crypto';

// ── φ-Derived Constants ──────────────────────────────────
const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH:     phiThreshold(3),
  MEDIUM:   phiThreshold(2),
  LOW:      phiThreshold(1),
  MINIMUM:  phiThreshold(0),
};

const WINDOW_SIZE_MS    = 34 * 1000;     // fib(9) = 34s sliding window
const MAX_REQUESTS      = 89;            // fib(11) per window
const BURST_THRESHOLD   = 13;            // fib(7) requests in 1s = burst
const HISTORY_SIZE      = 987;           // fib(16) tracked IPs
const DECAY_RATE        = PSI;           // ≈ 0.618 exponential decay factor
const BAN_DURATION_MS   = 233 * 1000;   // fib(13) = 233s ban
const FINGERPRINT_CACHE = 377;           // fib(14)

// ── IP Tracking Store ────────────────────────────────────
const ipStore = new Map();
const banList = new Map();

function hashIP(ip) {
  return createHash('sha256').update(ip + 'heady-anomaly-salt').digest('hex').slice(0, 21);
}

function getIPRecord(ip) {
  const hash = hashIP(ip);
  let record = ipStore.get(hash);
  if (!record) {
    record = {
      hash,
      requests: [],
      anomalyScore: 0,
      threatLevel: 'NOMINAL',
      firstSeen: Date.now(),
      lastSeen: Date.now(),
      totalRequests: 0,
      blockedCount: 0,
      patterns: { methods: {}, paths: {}, userAgents: new Set() },
    };
    // Evict oldest if over limit
    if (ipStore.size >= HISTORY_SIZE) {
      let oldestKey = null;
      let oldestTime = Infinity;
      for (const [k, v] of ipStore) {
        if (v.lastSeen < oldestTime) { oldestTime = v.lastSeen; oldestKey = k; }
      }
      if (oldestKey) ipStore.delete(oldestKey);
    }
    ipStore.set(hash, record);
  }
  return record;
}

// ── CSL Gate ────────────────────────────────────────────
function cslGate(value, score, threshold, temperature = PSI * PSI * PSI) {
  const sigmoid = 1 / (1 + Math.exp(-(score - threshold) / temperature));
  return value * sigmoid;
}

// ── Anomaly Scoring ──────────────────────────────────────
function computeAnomalyScore(record) {
  const now = Date.now();
  
  // Clean old requests outside window
  record.requests = record.requests.filter(r => now - r.time < WINDOW_SIZE_MS);
  
  const requestCount = record.requests.length;
  
  // Factor 1: Request rate (φ-weighted: 0.486)
  const rateScore = Math.min(1, requestCount / MAX_REQUESTS);
  
  // Factor 2: Burst detection (φ-weighted: 0.300)
  const lastSecond = record.requests.filter(r => now - r.time < 1000).length;
  const burstScore = Math.min(1, lastSecond / BURST_THRESHOLD);
  
  // Factor 3: Path diversity — many unique paths = scanner (φ-weighted: 0.214)
  const uniquePaths = Object.keys(record.patterns.paths).length;
  const diversityScore = Math.min(1, uniquePaths / 55); // fib(10)
  
  // φ-weighted fusion
  const anomaly = (rateScore * 0.486) + (burstScore * 0.300) + (diversityScore * 0.214);
  
  // Exponential decay blending with previous score
  record.anomalyScore = (record.anomalyScore * DECAY_RATE) + (anomaly * (1 - DECAY_RATE));
  
  return record.anomalyScore;
}

function classifyThreat(anomalyScore) {
  if (cslGate(1, anomalyScore, CSL_THRESHOLDS.CRITICAL) > CSL_THRESHOLDS.MINIMUM) return 'CRITICAL';
  if (cslGate(1, anomalyScore, CSL_THRESHOLDS.HIGH) > CSL_THRESHOLDS.MINIMUM) return 'HIGH';
  if (cslGate(1, anomalyScore, CSL_THRESHOLDS.MEDIUM) > CSL_THRESHOLDS.MINIMUM) return 'ELEVATED';
  if (cslGate(1, anomalyScore, CSL_THRESHOLDS.LOW) > CSL_THRESHOLDS.MINIMUM) return 'WATCHING';
  return 'NOMINAL';
}

// ── Public API ──────────────────────────────────────────
/**
 * Record a request from an IP and return threat assessment
 */
export function recordRequest(ip, meta = {}) {
  const now = Date.now();
  
  // Check ban list
  const banned = banList.get(hashIP(ip));
  if (banned && now < banned.expiresAt) {
    return {
      allowed: false,
      reason: 'IP_BANNED',
      threatLevel: 'CRITICAL',
      expiresIn: banned.expiresAt - now,
    };
  } else if (banned) {
    banList.delete(hashIP(ip));
  }

  const record = getIPRecord(ip);
  record.lastSeen = now;
  record.totalRequests++;
  record.requests.push({ time: now });
  
  // Update patterns
  if (meta.method) record.patterns.methods[meta.method] = (record.patterns.methods[meta.method] || 0) + 1;
  if (meta.path) record.patterns.paths[meta.path] = (record.patterns.paths[meta.path] || 0) + 1;
  if (meta.userAgent) record.patterns.userAgents.add(meta.userAgent.slice(0, 144)); // fib(12) char limit
  
  const anomalyScore = computeAnomalyScore(record);
  const threatLevel = classifyThreat(anomalyScore);
  record.threatLevel = threatLevel;
  
  // Auto-ban at CRITICAL
  if (threatLevel === 'CRITICAL') {
    banList.set(record.hash, { expiresAt: now + BAN_DURATION_MS, reason: 'ANOMALY_CRITICAL' });
    record.blockedCount++;
    return {
      allowed: false,
      reason: 'ANOMALY_DETECTED',
      threatLevel,
      anomalyScore,
      bannedFor: BAN_DURATION_MS,
    };
  }

  return {
    allowed: true,
    threatLevel,
    anomalyScore,
    requestsInWindow: record.requests.length,
    totalRequests: record.totalRequests,
  };
}

/**
 * Get current threat status for an IP
 */
export function getStatus(ip) {
  const hash = hashIP(ip);
  const record = ipStore.get(hash);
  if (!record) return { threatLevel: 'UNKNOWN', anomalyScore: 0 };
  return {
    threatLevel: record.threatLevel,
    anomalyScore: record.anomalyScore,
    totalRequests: record.totalRequests,
    blockedCount: record.blockedCount,
    firstSeen: record.firstSeen,
    lastSeen: record.lastSeen,
    isBanned: banList.has(hash) && Date.now() < (banList.get(hash)?.expiresAt || 0),
  };
}

/**
 * Manually ban an IP
 */
export function banIP(ip, durationMs = BAN_DURATION_MS, reason = 'MANUAL') {
  const hash = hashIP(ip);
  banList.set(hash, { expiresAt: Date.now() + durationMs, reason });
}

/**
 * Unban an IP
 */
export function unbanIP(ip) {
  banList.delete(hashIP(ip));
}

/**
 * Get summary statistics
 */
export function getSummary() {
  const threats = { NOMINAL: 0, WATCHING: 0, ELEVATED: 0, HIGH: 0, CRITICAL: 0 };
  for (const [, record] of ipStore) {
    threats[record.threatLevel] = (threats[record.threatLevel] || 0) + 1;
  }
  return {
    trackedIPs: ipStore.size,
    bannedIPs: banList.size,
    threatDistribution: threats,
  };
}

/**
 * Express/Connect middleware
 */
export function middleware(options = {}) {
  const getIP = options.getIP || ((req) => req.ip || req.connection?.remoteAddress || '0.0.0.0');
  
  return (req, res, next) => {
    const ip = getIP(req);
    const result = recordRequest(ip, {
      method: req.method,
      path: req.path || req.url,
      userAgent: req.headers?.['user-agent'],
    });
    
    if (!result.allowed) {
      res.setHeader('Retry-After', Math.ceil((result.bannedFor || BAN_DURATION_MS) / 1000));
      res.statusCode = 429;
      res.end(JSON.stringify({ error: 'Too many requests', retryAfter: Math.ceil((result.bannedFor || BAN_DURATION_MS) / 1000) }));
      return;
    }
    
    res.setHeader('X-Heady-Threat-Level', result.threatLevel);
    next();
  };
}

export default { recordRequest, getStatus, banIP, unbanIP, getSummary, middleware };
`);

// ─────────────────────────────────────────────────────────────
// security/session-binder.js
// ─────────────────────────────────────────────────────────────
emit('security/session-binder.js', `/**
 * session-binder.js — CSL-Gated Session Binding & Fingerprint Validation
 *
 * Binds sessions to device fingerprints using SHA-256 hashing,
 * φ-scaled trust scoring, and CSL gates for anomaly detection.
 * httpOnly cookies ONLY — NO localStorage.
 *
 * Eric Haywood — HeadySystems
 * License: PROPRIETARY
 */

import { PHI, PSI, phiThreshold } from '../shared/phi-math.js';
import { createHash, randomBytes } from 'crypto';

// ── φ-Derived Constants ──────────────────────────────────
const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH:     phiThreshold(3),
  MEDIUM:   phiThreshold(2),
  LOW:      phiThreshold(1),
  MINIMUM:  phiThreshold(0),
};

const SESSION_TTL_MS   = 1597 * 1000;   // fib(17) = 1597s ≈ 26.6 min
const MAX_SESSIONS     = 987;           // fib(16) concurrent sessions
const FINGERPRINT_DIMS = 8;             // fib(6) fingerprint components
const TRUST_DECAY      = PSI;           // ≈ 0.618 decay per validation
const REBIND_COOLDOWN  = 34 * 1000;     // fib(9) = 34s between rebinds
const TOKEN_BYTES      = 34;            // fib(9) bytes of entropy

// ── Session Store ────────────────────────────────────────
const sessions = new Map();

function cslGate(value, score, threshold, temperature = PSI * PSI * PSI) {
  const sigmoid = 1 / (1 + Math.exp(-(score - threshold) / temperature));
  return value * sigmoid;
}

// ── Fingerprint Generation ──────────────────────────────
function generateFingerprint(req) {
  const components = [
    req.headers?.['user-agent'] || '',
    req.headers?.['accept-language'] || '',
    req.headers?.['accept-encoding'] || '',
    req.headers?.['accept'] || '',
    req.ip || req.connection?.remoteAddress || '',
    req.headers?.['sec-ch-ua'] || '',
    req.headers?.['sec-ch-ua-platform'] || '',
    req.headers?.['sec-ch-ua-mobile'] || '',
  ];
  return createHash('sha256')
    .update(components.join('|'))
    .digest('hex');
}

function generateToken() {
  return randomBytes(TOKEN_BYTES).toString('hex');
}

// ── Fingerprint Similarity ──────────────────────────────
function fingerprintSimilarity(fp1, fp2) {
  if (fp1 === fp2) return 1.0;
  if (!fp1 || !fp2) return 0.0;
  // Compare character-by-character (hex digest)
  let matches = 0;
  const len = Math.min(fp1.length, fp2.length);
  for (let i = 0; i < len; i++) {
    if (fp1[i] === fp2[i]) matches++;
  }
  return matches / len;
}

// ── Session Lifecycle ────────────────────────────────────
/**
 * Create a new session bound to the request fingerprint.
 * Returns session token (to be set as httpOnly cookie).
 */
export function createSession(req, userId, metadata = {}) {
  // Evict expired sessions
  evictExpired();
  
  // Enforce max sessions
  if (sessions.size >= MAX_SESSIONS) {
    let oldestKey = null;
    let oldestTime = Infinity;
    for (const [k, s] of sessions) {
      if (s.lastValidated < oldestTime) { oldestTime = s.lastValidated; oldestKey = k; }
    }
    if (oldestKey) sessions.delete(oldestKey);
  }

  const token = generateToken();
  const fingerprint = generateFingerprint(req);
  const now = Date.now();
  
  const tokenHash = createHash('sha256').update(token).digest('hex');
  
  sessions.set(tokenHash, {
    userId,
    fingerprint,
    trustScore: 1.0,
    createdAt: now,
    lastValidated: now,
    lastRebind: now,
    expiresAt: now + SESSION_TTL_MS,
    validationCount: 0,
    anomalyCount: 0,
    metadata,
  });

  return {
    token,
    expiresAt: now + SESSION_TTL_MS,
    cookieOptions: {
      httpOnly: true,
      secure: true,
      sameSite: 'strict',
      maxAge: SESSION_TTL_MS,
      path: '/',
    },
  };
}

/**
 * Validate a session token against the current request fingerprint.
 * Returns validation result with trust assessment.
 */
export function validateSession(token, req) {
  if (!token) return { valid: false, reason: 'NO_TOKEN' };
  
  const tokenHash = createHash('sha256').update(token).digest('hex');
  const session = sessions.get(tokenHash);
  
  if (!session) return { valid: false, reason: 'SESSION_NOT_FOUND' };
  
  const now = Date.now();
  if (now > session.expiresAt) {
    sessions.delete(tokenHash);
    return { valid: false, reason: 'SESSION_EXPIRED' };
  }

  const currentFP = generateFingerprint(req);
  const similarity = fingerprintSimilarity(session.fingerprint, currentFP);
  
  // Update trust score with φ-decay blending
  session.trustScore = (session.trustScore * TRUST_DECAY) + (similarity * (1 - TRUST_DECAY));
  session.lastValidated = now;
  session.validationCount++;
  
  // CSL gate: is trust above MEDIUM threshold?
  const trustGated = cslGate(1, session.trustScore, CSL_THRESHOLDS.MEDIUM);
  
  if (trustGated < CSL_THRESHOLDS.MINIMUM) {
    session.anomalyCount++;
    // If too many anomalies, terminate session
    if (session.anomalyCount >= 5) { // fib(5)
      sessions.delete(tokenHash);
      return { valid: false, reason: 'SESSION_HIJACK_DETECTED', anomalyCount: session.anomalyCount };
    }
    return {
      valid: false,
      reason: 'FINGERPRINT_MISMATCH',
      trustScore: session.trustScore,
      similarity,
      anomalyCount: session.anomalyCount,
    };
  }

  // Refresh expiry on successful validation
  session.expiresAt = now + SESSION_TTL_MS;
  
  return {
    valid: true,
    userId: session.userId,
    trustScore: session.trustScore,
    similarity,
    validationCount: session.validationCount,
  };
}

/**
 * Rebind session to new fingerprint (e.g., after network change).
 * Requires recent validation and cooldown period.
 */
export function rebindSession(token, req) {
  if (!token) return { success: false, reason: 'NO_TOKEN' };
  
  const tokenHash = createHash('sha256').update(token).digest('hex');
  const session = sessions.get(tokenHash);
  
  if (!session) return { success: false, reason: 'SESSION_NOT_FOUND' };
  
  const now = Date.now();
  if (now - session.lastRebind < REBIND_COOLDOWN) {
    return { success: false, reason: 'REBIND_COOLDOWN', retryAfter: REBIND_COOLDOWN - (now - session.lastRebind) };
  }
  
  session.fingerprint = generateFingerprint(req);
  session.lastRebind = now;
  session.trustScore = CSL_THRESHOLDS.MEDIUM; // Reset to MEDIUM trust
  session.anomalyCount = 0;
  
  return { success: true, trustScore: session.trustScore };
}

/**
 * Destroy a session
 */
export function destroySession(token) {
  if (!token) return false;
  const tokenHash = createHash('sha256').update(token).digest('hex');
  return sessions.delete(tokenHash);
}

/**
 * Get session statistics
 */
export function getStats() {
  evictExpired();
  let trustDistribution = { high: 0, medium: 0, low: 0, critical: 0 };
  for (const [, s] of sessions) {
    if (s.trustScore >= CSL_THRESHOLDS.HIGH) trustDistribution.high++;
    else if (s.trustScore >= CSL_THRESHOLDS.MEDIUM) trustDistribution.medium++;
    else if (s.trustScore >= CSL_THRESHOLDS.LOW) trustDistribution.low++;
    else trustDistribution.critical++;
  }
  return { activeSessions: sessions.size, maxSessions: MAX_SESSIONS, trustDistribution };
}

function evictExpired() {
  const now = Date.now();
  for (const [k, s] of sessions) {
    if (now > s.expiresAt) sessions.delete(k);
  }
}

/**
 * Express/Connect middleware
 */
export function middleware(options = {}) {
  const cookieName = options.cookieName || 'heady_session';
  
  return (req, res, next) => {
    const token = req.cookies?.[cookieName];
    if (!token) { req.session = null; return next(); }
    
    const result = validateSession(token, req);
    if (result.valid) {
      req.session = { userId: result.userId, trustScore: result.trustScore };
    } else {
      req.session = null;
      if (result.reason === 'SESSION_HIJACK_DETECTED') {
        res.clearCookie(cookieName, { httpOnly: true, secure: true, sameSite: 'strict', path: '/' });
      }
    }
    next();
  };
}

export default { createSession, validateSession, rebindSession, destroySession, getStats, middleware };
`);

// ─────────────────────────────────────────────────────────────
// web/seo-engine.js
// ─────────────────────────────────────────────────────────────
emit('web/seo-engine.js', `/**
 * seo-engine.js — Comprehensive SEO Engine for Heady Platform
 *
 * JSON-LD structured data, sitemap.xml, robots.txt, Open Graph,
 * Twitter Cards, canonical URLs, and meta tag generation.
 * All sizing via Fibonacci, all thresholds φ-derived.
 *
 * Eric Haywood — HeadySystems
 * License: PROPRIETARY
 */

import { PHI, PSI, phiThreshold, fibSequence } from '../shared/phi-math.js';

// ── φ-Derived Constants ──────────────────────────────────
const MAX_TITLE_LEN    = 55;           // fib(10)
const MAX_DESC_LEN     = 233;          // fib(13)
const MAX_SITEMAP_URLS = 6765;         // fib(20)
const CACHE_SIZE       = 377;          // fib(14)
const SITEMAP_PRIORITY_DECAY = PSI;    // ≈ 0.618 per depth level

// ── Heady Domain Registry ────────────────────────────────
const HEADY_DOMAINS = [
  { domain: 'headyme.com',            role: 'Command center',                 priority: 1.0 },
  { domain: 'headysystems.com',       role: 'Core architecture engine',       priority: PSI + PSI * PSI },   // ≈ 1.0
  { domain: 'heady-ai.com',           role: 'Intelligence routing hub',       priority: PSI + PSI * PSI },
  { domain: 'headyos.com',            role: 'Operating system interface',     priority: PSI },               // ≈ 0.618
  { domain: 'headyconnection.org',    role: 'Nonprofit and community',        priority: PSI },
  { domain: 'headyconnection.com',    role: 'Community (commercial)',         priority: PSI * PSI },         // ≈ 0.382
  { domain: 'headyex.com',            role: 'Exchange platform',              priority: PSI * PSI },
  { domain: 'headyfinance.com',       role: 'Financial services',             priority: PSI * PSI },
  { domain: 'admin.headysystems.com', role: 'Admin panel',                    priority: 0.0 },              // noindex
];

// ── JSON-LD Generator ────────────────────────────────────
export function generateJsonLd(options = {}) {
  const {
    type = 'WebApplication',
    name = 'Heady',
    description = 'Sovereign AI Platform — Alive Software Architecture',
    url = 'https://headyme.com',
    author = 'Eric Haywood',
    organization = 'HeadySystems',
    orgUrl = 'https://headysystems.com',
    logo = 'https://headyme.com/logo.png',
    datePublished,
    dateModified,
    extra = {},
  } = options;

  const ld = {
    '@context': 'https://schema.org',
    '@type': type,
    name,
    description: description.slice(0, MAX_DESC_LEN),
    url,
    author: {
      '@type': 'Person',
      name: author,
    },
    publisher: {
      '@type': 'Organization',
      name: organization,
      url: orgUrl,
      logo: {
        '@type': 'ImageObject',
        url: logo,
      },
    },
    ...(datePublished && { datePublished }),
    ...(dateModified && { dateModified }),
    ...extra,
  };

  return \`<script type="application/ld+json">\${JSON.stringify(ld, null, 2)}</script>\`;
}

// ── Open Graph & Twitter Card Meta ──────────────────────
export function generateMetaTags(options = {}) {
  const {
    title = 'Heady — Sovereign AI Platform',
    description = 'Alive Software Architecture by Eric Haywood',
    url = 'https://headyme.com',
    image = 'https://headyme.com/og-image.png',
    type = 'website',
    siteName = 'Heady',
    twitterHandle = '@HeadySystems',
    locale = 'en_US',
    canonical,
    noindex = false,
    extra = [],
  } = options;

  const tags = [];
  
  // Basic meta
  tags.push(\`<meta charset="utf-8">\`);
  tags.push(\`<meta name="viewport" content="width=device-width, initial-scale=1">\`);
  tags.push(\`<title>\${title.slice(0, MAX_TITLE_LEN)}</title>\`);
  tags.push(\`<meta name="description" content="\${description.slice(0, MAX_DESC_LEN)}">\`);
  
  if (noindex) {
    tags.push(\`<meta name="robots" content="noindex, nofollow">\`);
  }
  
  if (canonical || url) {
    tags.push(\`<link rel="canonical" href="\${canonical || url}">\`);
  }
  
  // Open Graph
  tags.push(\`<meta property="og:type" content="\${type}">\`);
  tags.push(\`<meta property="og:title" content="\${title.slice(0, MAX_TITLE_LEN)}">\`);
  tags.push(\`<meta property="og:description" content="\${description.slice(0, MAX_DESC_LEN)}">\`);
  tags.push(\`<meta property="og:url" content="\${url}">\`);
  tags.push(\`<meta property="og:image" content="\${image}">\`);
  tags.push(\`<meta property="og:site_name" content="\${siteName}">\`);
  tags.push(\`<meta property="og:locale" content="\${locale}">\`);
  
  // Twitter Card
  tags.push(\`<meta name="twitter:card" content="summary_large_image">\`);
  tags.push(\`<meta name="twitter:title" content="\${title.slice(0, MAX_TITLE_LEN)}">\`);
  tags.push(\`<meta name="twitter:description" content="\${description.slice(0, MAX_DESC_LEN)}">\`);
  tags.push(\`<meta name="twitter:image" content="\${image}">\`);
  tags.push(\`<meta name="twitter:site" content="\${twitterHandle}">\`);
  
  // Extra tags
  for (const tag of extra) {
    tags.push(tag);
  }
  
  return tags.join('\\n    ');
}

// ── Sitemap Generator ────────────────────────────────────
export function generateSitemap(pages = [], options = {}) {
  const {
    baseUrl = 'https://headyme.com',
    defaultChangefreq = 'weekly',
    defaultPriority = PSI,   // ≈ 0.618
  } = options;

  const urls = pages.slice(0, MAX_SITEMAP_URLS).map(page => {
    const loc = page.url.startsWith('http') ? page.url : \`\${baseUrl}\${page.url}\`;
    const priority = page.priority ?? Math.max(0.1, defaultPriority * Math.pow(SITEMAP_PRIORITY_DECAY, page.depth || 0));
    const lastmod = page.lastmod || new Date().toISOString().split('T')[0];
    const changefreq = page.changefreq || defaultChangefreq;
    
    return \`  <url>
    <loc>\${loc}</loc>
    <lastmod>\${lastmod}</lastmod>
    <changefreq>\${changefreq}</changefreq>
    <priority>\${priority.toFixed(2)}</priority>
  </url>\`;
  });

  return \`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
\${urls.join('\\n')}
</urlset>\`;
}

// ── Robots.txt Generator ─────────────────────────────────
export function generateRobotsTxt(options = {}) {
  const {
    sitemapUrl = 'https://headyme.com/sitemap.xml',
    disallowPaths = ['/api/', '/admin/', '/internal/', '/_next/'],
    allowPaths = ['/'],
    crawlDelay = 1,
    additionalRules = [],
  } = options;

  const lines = [
    'User-agent: *',
    ...allowPaths.map(p => \`Allow: \${p}\`),
    ...disallowPaths.map(p => \`Disallow: \${p}\`),
    \`Crawl-delay: \${crawlDelay}\`,
    '',
    ...additionalRules,
    '',
    \`Sitemap: \${sitemapUrl}\`,
  ];

  return lines.join('\\n');
}

// ── Heady Multi-Domain SEO Config ────────────────────────
export function getHeadyDomainSEO(domain) {
  const found = HEADY_DOMAINS.find(d => d.domain === domain);
  if (!found) return null;
  
  return {
    domain: found.domain,
    role: found.role,
    priority: found.priority,
    noindex: found.priority === 0.0,
    canonical: \`https://\${found.domain}\`,
    jsonLd: generateJsonLd({
      name: \`Heady — \${found.role}\`,
      url: \`https://\${found.domain}\`,
    }),
  };
}

/**
 * Generate full SEO head section for a Heady page
 */
export function generateSEOHead(pageOptions = {}) {
  const meta = generateMetaTags(pageOptions);
  const jsonLd = generateJsonLd(pageOptions);
  
  return \`\${meta}
    \${jsonLd}\`;
}

export { HEADY_DOMAINS };
export default { generateJsonLd, generateMetaTags, generateSitemap, generateRobotsTxt, getHeadyDomainSEO, generateSEOHead };
`);

// ─────────────────────────────────────────────────────────────
// web/openapi-generator.js
// ─────────────────────────────────────────────────────────────
emit('web/openapi-generator.js', `/**
 * openapi-generator.js — Auto-Generate OpenAPI 3.1 Spec from Heady Routes
 *
 * Scans route definitions to build a complete OpenAPI specification
 * with φ-scaled rate limit documentation, security schemes, and examples.
 *
 * Eric Haywood — HeadySystems
 * License: PROPRIETARY
 */

import { PHI, PSI, phiThreshold, fibSequence } from '../shared/phi-math.js';

// ── φ-Derived Constants ──────────────────────────────────
const MAX_ENDPOINTS     = 233;          // fib(13)
const MAX_PARAMS        = 21;           // fib(8)
const MAX_EXAMPLES      = 8;            // fib(6)
const RATE_LIMITS = {
  standard: 89,                         // fib(11) req/min
  burst:    144,                        // fib(12) req/min
  limited:  34,                         // fib(9) req/min
};

// ── Base Spec ────────────────────────────────────────────
function createBaseSpec(options = {}) {
  const {
    title = 'Heady API',
    description = 'Sovereign AI Platform API — Alive Software Architecture',
    version = '1.0.0',
    baseUrl = 'https://api.headyme.com',
    contactName = 'Eric Haywood',
    contactEmail = 'eric@headysystems.com',
    license = 'PROPRIETARY',
  } = options;

  return {
    openapi: '3.1.0',
    info: {
      title,
      description,
      version,
      contact: {
        name: contactName,
        email: contactEmail,
        url: 'https://headysystems.com',
      },
      license: { name: license },
      'x-phi-constants': {
        PHI: PHI,
        PSI: PSI,
        NOTE: 'All rate limits and sizing use Fibonacci numbers; all thresholds are phi-derived.',
      },
    },
    servers: [
      { url: baseUrl, description: 'Production' },
      { url: 'https://staging-api.headyme.com', description: 'Staging' },
    ],
    paths: {},
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'JWT token delivered via httpOnly cookie. Bearer auth for API clients.',
        },
        cookieAuth: {
          type: 'apiKey',
          in: 'cookie',
          name: 'heady_session',
          description: 'httpOnly session cookie (primary auth method — NO localStorage)',
        },
      },
      schemas: {},
      responses: {
        UnauthorizedError: {
          description: 'Authentication required',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  error: { type: 'string', example: 'Authentication required' },
                  code: { type: 'string', example: 'AUTH_REQUIRED' },
                },
              },
            },
          },
        },
        RateLimitError: {
          description: 'Rate limit exceeded',
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  error: { type: 'string', example: 'Rate limit exceeded' },
                  retryAfter: { type: 'integer', example: 34, description: 'Seconds until retry (fib(9))' },
                },
              },
            },
          },
          headers: {
            'Retry-After': { schema: { type: 'integer' }, description: 'Seconds until rate limit resets' },
            'X-RateLimit-Limit': { schema: { type: 'integer' }, description: 'Request limit per window (Fibonacci-sized)' },
            'X-RateLimit-Remaining': { schema: { type: 'integer' } },
          },
        },
      },
    },
    security: [{ cookieAuth: [] }],
  };
}

// ── Route-to-Endpoint Converter ──────────────────────────
function routeToEndpoint(route) {
  const {
    method = 'get',
    path,
    summary,
    description,
    tags = [],
    parameters = [],
    requestBody,
    responses = {},
    security,
    rateLimit = 'standard',
    deprecated = false,
  } = route;

  const endpoint = {
    summary,
    description,
    tags,
    deprecated,
    'x-rate-limit': RATE_LIMITS[rateLimit] || RATE_LIMITS.standard,
  };

  if (parameters.length > 0) {
    endpoint.parameters = parameters.slice(0, MAX_PARAMS).map(p => ({
      name: p.name,
      in: p.in || 'query',
      required: p.required ?? false,
      schema: p.schema || { type: 'string' },
      description: p.description || '',
    }));
  }

  if (requestBody) {
    endpoint.requestBody = {
      required: requestBody.required ?? true,
      content: {
        'application/json': {
          schema: requestBody.schema || { type: 'object' },
          ...(requestBody.example && { example: requestBody.example }),
        },
      },
    };
  }

  // Default responses
  endpoint.responses = {
    '200': responses['200'] || { description: 'Success' },
    '401': { '$ref': '#/components/responses/UnauthorizedError' },
    '429': { '$ref': '#/components/responses/RateLimitError' },
    ...responses,
  };

  if (security !== undefined) {
    endpoint.security = security;
  }

  return { path, method: method.toLowerCase(), endpoint };
}

// ── Schema Helpers ───────────────────────────────────────
function paginatedSchema(itemSchema, itemName = 'items') {
  return {
    type: 'object',
    properties: {
      [itemName]: { type: 'array', items: itemSchema },
      total: { type: 'integer' },
      page: { type: 'integer' },
      perPage: { type: 'integer', description: \`Items per page (Fibonacci-sized: \${fibSequence?.slice(5, 10).join(', ') || '5,8,13,21,34'})\` },
      hasMore: { type: 'boolean' },
    },
  };
}

function errorSchema() {
  return {
    type: 'object',
    properties: {
      error: { type: 'string' },
      code: { type: 'string' },
      details: { type: 'object', additionalProperties: true },
      requestId: { type: 'string', format: 'uuid' },
      timestamp: { type: 'string', format: 'date-time' },
    },
    required: ['error', 'code'],
  };
}

// ── Main Generator ───────────────────────────────────────
/**
 * Generate a complete OpenAPI 3.1 specification from route definitions
 */
export function generateSpec(routes = [], options = {}) {
  const spec = createBaseSpec(options);
  
  // Add common schemas
  spec.components.schemas.Error = errorSchema();
  spec.components.schemas.HealthCheck = {
    type: 'object',
    properties: {
      status: { type: 'string', enum: ['healthy', 'degraded', 'unhealthy'] },
      uptime: { type: 'number' },
      version: { type: 'string' },
      phi: { type: 'number', example: PHI, description: 'Golden ratio constant' },
      services: { type: 'object', additionalProperties: { type: 'string' } },
    },
  };
  
  // Add custom schemas from options
  if (options.schemas) {
    Object.assign(spec.components.schemas, options.schemas);
  }

  // Process routes
  for (const route of routes.slice(0, MAX_ENDPOINTS)) {
    const { path, method, endpoint } = routeToEndpoint(route);
    if (!spec.paths[path]) spec.paths[path] = {};
    spec.paths[path][method] = endpoint;
  }

  return spec;
}

/**
 * Serialize spec to YAML-like format (JSON with comments)
 */
export function specToJson(spec, pretty = true) {
  return JSON.stringify(spec, null, pretty ? 2 : 0);
}

/**
 * Generate Heady-standard health endpoint
 */
export function healthEndpoint() {
  return {
    method: 'get',
    path: '/health',
    summary: 'Health check',
    description: 'Returns service health with φ-scaled metrics',
    tags: ['System'],
    security: [],
    responses: {
      '200': {
        description: 'Service is healthy',
        content: { 'application/json': { schema: { '$ref': '#/components/schemas/HealthCheck' } } },
      },
    },
  };
}

export { createBaseSpec, routeToEndpoint, paginatedSchema, errorSchema, RATE_LIMITS };
export default { generateSpec, specToJson, healthEndpoint, createBaseSpec, RATE_LIMITS };
`);

// ─────────────────────────────────────────────────────────────
// tests/load-test-k6.js
// ─────────────────────────────────────────────────────────────
emit('tests/load-test-k6.js', `/**
 * load-test-k6.js — k6 Load Testing Framework for Heady Platform
 *
 * φ-scaled ramp stages, Fibonacci-sized virtual user counts,
 * CSL-gated threshold assertions, and multi-service targeting.
 *
 * Run: k6 run tests/load-test-k6.js
 * 
 * Eric Haywood — HeadySystems
 * License: PROPRIETARY
 */

// k6 imports (k6 runtime provides these)
import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Rate, Trend, Counter } from 'k6/metrics';

// ── φ-Derived Constants ──────────────────────────────────
const PHI = 1.6180339887;
const PSI = 1 / PHI;                    // ≈ 0.618
const PSI2 = PSI * PSI;                 // ≈ 0.382
const PSI3 = PSI * PSI * PSI;           // ≈ 0.236

// φ-threshold levels
function phiThreshold(level, spread = 0.5) {
  return 1 - Math.pow(PSI, level) * spread;
}

const THRESHOLDS = {
  CRITICAL: phiThreshold(4),             // ≈ 0.927
  HIGH:     phiThreshold(3),             // ≈ 0.882
  MEDIUM:   phiThreshold(2),             // ≈ 0.809
  LOW:      phiThreshold(1),             // ≈ 0.691
};

// Fibonacci VU stages: [1, 2, 3, 5, 8, 13, 21, 34, 55, 89]
const FIB_VUS = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89];

// ── Custom Metrics ───────────────────────────────────────
const errorRate = new Rate('heady_errors');
const latencyP95 = new Trend('heady_latency_p95');
const healthyResponses = new Counter('heady_healthy');

// ── k6 Options ───────────────────────────────────────────
export const options = {
  // φ-scaled ramp stages using Fibonacci VU counts
  stages: [
    { duration: '34s',  target: FIB_VUS[3] },   // Warm-up: 5 VUs
    { duration: '55s',  target: FIB_VUS[5] },   // Ramp: 13 VUs
    { duration: '89s',  target: FIB_VUS[7] },   // Sustain: 34 VUs
    { duration: '55s',  target: FIB_VUS[8] },   // Peak: 55 VUs
    { duration: '34s',  target: FIB_VUS[5] },   // Cool-down: 13 VUs
    { duration: '21s',  target: 0 },             // Drain
  ],
  
  thresholds: {
    // φ-derived pass/fail thresholds
    http_req_duration: [
      \`p(95)<\${Math.round(1000 * PSI)}\`,          // p95 < 618ms
      \`p(99)<\${Math.round(1000 * PHI)}\`,          // p99 < 1618ms
    ],
    http_req_failed: [\`rate<\${(1 - THRESHOLDS.HIGH).toFixed(3)}\`],  // < 11.8% error rate
    heady_errors: [\`rate<\${(1 - THRESHOLDS.CRITICAL).toFixed(3)}\`], // < 7.3% anomaly rate
    http_reqs: ['count>100'],
  },
};

// ── Heady Service Endpoints ──────────────────────────────
const BASE_URL = __ENV.HEADY_BASE_URL || 'http://localhost:3310';
const ENDPOINTS = {
  health:   \`\${BASE_URL}/health\`,
  memory:   \`\${BASE_URL}/api/memory/search\`,
  agents:   \`\${BASE_URL}/api/agents/status\`,
  csl:      \`\${BASE_URL}/api/csl/gate\`,
  auth:     \`\${BASE_URL}/api/auth/validate\`,
};

const HEADERS = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
  'User-Agent': 'HeadyK6LoadTest/1.0',
};

// ── Test Scenarios ───────────────────────────────────────
export default function () {
  group('Health Check', () => {
    const res = http.get(ENDPOINTS.health, { headers: HEADERS, timeout: \`\${Math.round(1000 * PHI)}ms\` });
    
    const passed = check(res, {
      'health: status 200': (r) => r.status === 200,
      'health: has status field': (r) => {
        try { return JSON.parse(r.body).status !== undefined; }
        catch { return false; }
      },
      [\`health: latency < \${Math.round(1000 * PSI2)}ms\`]: (r) => r.timings.duration < 1000 * PSI2,
    });
    
    errorRate.add(!passed);
    latencyP95.add(res.timings.duration);
    if (passed) healthyResponses.add(1);
  });

  group('Memory Search', () => {
    const payload = JSON.stringify({
      query: 'system health status',
      limit: 8,        // fib(6)
      threshold: PSI,  // ≈ 0.618
    });
    
    const res = http.post(ENDPOINTS.memory, payload, { headers: HEADERS, timeout: \`\${Math.round(1000 * PHI * PHI)}ms\` });
    
    const passed = check(res, {
      'memory: status 200 or 401': (r) => r.status === 200 || r.status === 401,
      [\`memory: latency < \${Math.round(1000 * PHI)}ms\`]: (r) => r.timings.duration < 1000 * PHI,
    });
    
    errorRate.add(!passed);
    latencyP95.add(res.timings.duration);
  });

  group('CSL Gate', () => {
    const payload = JSON.stringify({
      input: [0.5, 0.3, 0.8, 0.1],
      gate: [0.9, 0.1, 0.7, 0.3],
      threshold: THRESHOLDS.MEDIUM,
    });
    
    const res = http.post(ENDPOINTS.csl, payload, { headers: HEADERS, timeout: \`\${Math.round(1000 * PSI)}ms\` });
    
    const passed = check(res, {
      'csl: status 200 or 401': (r) => r.status === 200 || r.status === 401,
      [\`csl: latency < \${Math.round(1000 * PSI2)}ms\`]: (r) => r.timings.duration < 1000 * PSI2,
    });
    
    errorRate.add(!passed);
  });

  group('Agent Status', () => {
    const res = http.get(ENDPOINTS.agents, { headers: HEADERS, timeout: \`\${Math.round(1000 * PHI)}ms\` });
    
    check(res, {
      'agents: status 200 or 401': (r) => r.status === 200 || r.status === 401,
    });
    
    latencyP95.add(res.timings.duration);
  });

  // φ-scaled think time between iterations
  sleep(PSI + Math.random() * PSI2);  // 0.618 – 1.0s
}

// ── Summary Handler ──────────────────────────────────────
export function handleSummary(data) {
  const summary = {
    timestamp: new Date().toISOString(),
    phi: PHI,
    stages: options.stages,
    thresholds: options.thresholds,
    metrics: {
      http_reqs: data.metrics?.http_reqs?.values?.count || 0,
      http_req_duration_p95: data.metrics?.http_req_duration?.values?.['p(95)'] || 0,
      http_req_failed: data.metrics?.http_req_failed?.values?.rate || 0,
      heady_errors: data.metrics?.heady_errors?.values?.rate || 0,
      heady_healthy: data.metrics?.heady_healthy?.values?.count || 0,
    },
    passed: Object.entries(data.root_group?.checks || {}).every(([, v]) => v.passes > 0),
  };

  return {
    'stdout': JSON.stringify(summary, null, 2),
    'tests/load-test-results.json': JSON.stringify(summary, null, 2),
  };
}
`);

// ─────────────────────────────────────────────────────────────
// tests/chaos-engineering.js
// ─────────────────────────────────────────────────────────────
emit('tests/chaos-engineering.js', `/**
 * chaos-engineering.js — CSL-Gated Chaos Engineering Framework
 *
 * Injects controlled failures into the Heady platform to test resilience.
 * φ-scaled blast radius, Fibonacci-timed experiments, CSL gates for safety.
 *
 * Eric Haywood — HeadySystems
 * License: PROPRIETARY
 */

import { PHI, PSI, phiThreshold, fibSequence } from '../shared/phi-math.js';
import { createHash } from 'crypto';

// ── φ-Derived Constants ──────────────────────────────────
const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH:     phiThreshold(3),
  MEDIUM:   phiThreshold(2),
  LOW:      phiThreshold(1),
  MINIMUM:  phiThreshold(0),
};

const MAX_BLAST_RADIUS    = PSI;           // Max 61.8% of services
const EXPERIMENT_TTL_MS   = 89 * 1000;     // fib(11) = 89s max experiment duration
const COOLDOWN_MS         = 55 * 1000;     // fib(10) = 55s between experiments
const MAX_CONCURRENT      = 3;             // fib(4) concurrent experiments
const ABORT_THRESHOLD     = CSL_THRESHOLDS.HIGH; // Abort if health < 0.882
const SAFETY_CHECK_INTERVAL = 5 * 1000;    // fib(5) = 5s health checks during chaos

// ── Experiment Registry ──────────────────────────────────
const experiments = new Map();
let activeCount = 0;
let lastExperimentEnd = 0;

function cslGate(value, score, threshold, temperature = PSI * PSI * PSI) {
  const sigmoid = 1 / (1 + Math.exp(-(score - threshold) / temperature));
  return value * sigmoid;
}

// ── Experiment Types ─────────────────────────────────────
const EXPERIMENT_TYPES = {
  LATENCY_INJECTION: {
    name: 'Latency Injection',
    description: 'Adds artificial delay to service responses',
    safetyLevel: CSL_THRESHOLDS.LOW,
    apply: (target, params) => ({
      type: 'LATENCY_INJECTION',
      target,
      delayMs: params.delayMs || Math.round(1000 * PSI),  // 618ms default
      probability: params.probability || PSI2,              // 38.2% of requests
    }),
  },
  
  ERROR_INJECTION: {
    name: 'Error Injection',
    description: 'Forces services to return error responses',
    safetyLevel: CSL_THRESHOLDS.MEDIUM,
    apply: (target, params) => ({
      type: 'ERROR_INJECTION',
      target,
      statusCode: params.statusCode || 503,
      probability: params.probability || PSI * PSI2,        // 23.6%
    }),
  },
  
  RESOURCE_EXHAUSTION: {
    name: 'Resource Exhaustion',
    description: 'Simulates memory/CPU pressure',
    safetyLevel: CSL_THRESHOLDS.HIGH,
    apply: (target, params) => ({
      type: 'RESOURCE_EXHAUSTION',
      target,
      cpuLoad: params.cpuLoad || PSI,                       // 61.8% CPU
      memoryPressure: params.memoryPressure || PSI2,         // 38.2% memory
    }),
  },
  
  NETWORK_PARTITION: {
    name: 'Network Partition',
    description: 'Simulates network isolation between services',
    safetyLevel: CSL_THRESHOLDS.CRITICAL,
    apply: (target, params) => ({
      type: 'NETWORK_PARTITION',
      target,
      isolateFrom: params.isolateFrom || [],
      dropRate: params.dropRate || PSI,                      // 61.8% packet loss
    }),
  },
  
  DEPENDENCY_FAILURE: {
    name: 'Dependency Failure',
    description: 'Simulates downstream service failures',
    safetyLevel: CSL_THRESHOLDS.MEDIUM,
    apply: (target, params) => ({
      type: 'DEPENDENCY_FAILURE',
      target,
      dependency: params.dependency || 'database',
      failureMode: params.failureMode || 'timeout',
      timeoutMs: params.timeoutMs || Math.round(1000 * PHI), // 1618ms
    }),
  },
};

// ── Safety Checks ────────────────────────────────────────
async function checkSystemHealth(healthFn) {
  if (typeof healthFn !== 'function') return 1.0;
  try {
    const health = await healthFn();
    return typeof health === 'number' ? health : (health?.score ?? 1.0);
  } catch {
    return 0.0; // Can't check health = assume worst
  }
}

function isExperimentSafe(type, currentHealth) {
  const expType = EXPERIMENT_TYPES[type];
  if (!expType) return false;
  
  // CSL gate: current health must exceed experiment's safety level
  const safetyGated = cslGate(1, currentHealth, expType.safetyLevel);
  return safetyGated > CSL_THRESHOLDS.MINIMUM;
}

// ── Experiment Lifecycle ─────────────────────────────────
/**
 * Create and start a chaos experiment
 */
export async function runExperiment(options = {}) {
  const {
    type,
    target,
    params = {},
    durationMs = EXPERIMENT_TTL_MS,
    healthFn = null,
    onStart = null,
    onEnd = null,
    onAbort = null,
  } = options;

  // Pre-flight checks
  if (!EXPERIMENT_TYPES[type]) {
    return { success: false, reason: \`Unknown experiment type: \${type}\` };
  }
  
  if (activeCount >= MAX_CONCURRENT) {
    return { success: false, reason: \`Max concurrent experiments (\${MAX_CONCURRENT}) reached\` };
  }
  
  const now = Date.now();
  if (now - lastExperimentEnd < COOLDOWN_MS) {
    return { 
      success: false, 
      reason: 'Cooldown period active',
      retryAfter: COOLDOWN_MS - (now - lastExperimentEnd),
    };
  }

  // Health check before starting
  const currentHealth = await checkSystemHealth(healthFn);
  if (!isExperimentSafe(type, currentHealth)) {
    return {
      success: false,
      reason: \`System health (\${currentHealth.toFixed(3)}) too low for \${type}\`,
      requiredHealth: EXPERIMENT_TYPES[type].safetyLevel,
    };
  }

  // Create experiment
  const id = createHash('sha256')
    .update(\`\${type}-\${target}-\${now}-\${Math.random()}\`)
    .digest('hex')
    .slice(0, 21);
  
  const experiment = {
    id,
    ...EXPERIMENT_TYPES[type].apply(target, params),
    name: EXPERIMENT_TYPES[type].name,
    startedAt: now,
    expiresAt: now + Math.min(durationMs, EXPERIMENT_TTL_MS),
    status: 'RUNNING',
    healthSnapshots: [{ time: now, health: currentHealth }],
    abortReason: null,
  };

  experiments.set(id, experiment);
  activeCount++;
  
  if (typeof onStart === 'function') await onStart(experiment);

  // Safety monitor loop
  const monitor = setInterval(async () => {
    const health = await checkSystemHealth(healthFn);
    experiment.healthSnapshots.push({ time: Date.now(), health });
    
    // Abort if health drops below threshold
    if (health < (1 - ABORT_THRESHOLD)) {
      experiment.status = 'ABORTED';
      experiment.abortReason = \`Health dropped to \${health.toFixed(3)}\`;
      clearInterval(monitor);
      activeCount--;
      lastExperimentEnd = Date.now();
      if (typeof onAbort === 'function') await onAbort(experiment);
    }
  }, SAFETY_CHECK_INTERVAL);

  // Auto-expire
  setTimeout(async () => {
    clearInterval(monitor);
    if (experiment.status === 'RUNNING') {
      experiment.status = 'COMPLETED';
      activeCount--;
      lastExperimentEnd = Date.now();
      if (typeof onEnd === 'function') await onEnd(experiment);
    }
  }, Math.min(durationMs, EXPERIMENT_TTL_MS));

  return { success: true, experimentId: id, experiment };
}

/**
 * Abort a running experiment
 */
export function abortExperiment(id) {
  const exp = experiments.get(id);
  if (!exp || exp.status !== 'RUNNING') return false;
  exp.status = 'ABORTED';
  exp.abortReason = 'MANUAL';
  activeCount--;
  lastExperimentEnd = Date.now();
  return true;
}

/**
 * Get experiment results
 */
export function getExperiment(id) {
  return experiments.get(id) || null;
}

/**
 * List all experiments
 */
export function listExperiments(filter = {}) {
  const results = [];
  for (const [, exp] of experiments) {
    if (filter.status && exp.status !== filter.status) continue;
    if (filter.type && exp.type !== filter.type) continue;
    results.push(exp);
  }
  return results;
}

/**
 * Get chaos engineering summary
 */
export function getSummary() {
  let byStatus = { RUNNING: 0, COMPLETED: 0, ABORTED: 0 };
  let byType = {};
  for (const [, exp] of experiments) {
    byStatus[exp.status] = (byStatus[exp.status] || 0) + 1;
    byType[exp.type] = (byType[exp.type] || 0) + 1;
  }
  return {
    totalExperiments: experiments.size,
    activeCount,
    byStatus,
    byType,
    safetyThresholds: {
      maxBlastRadius: MAX_BLAST_RADIUS,
      abortThreshold: ABORT_THRESHOLD,
      maxConcurrent: MAX_CONCURRENT,
    },
  };
}

export { EXPERIMENT_TYPES, CSL_THRESHOLDS };
export default { runExperiment, abortExperiment, getExperiment, listExperiments, getSummary, EXPERIMENT_TYPES };
`);

// ─────────────────────────────────────────────────────────────
// docs/postman-collection.json
// ─────────────────────────────────────────────────────────────
emit('docs/postman-collection.json', JSON.stringify({
  info: {
    name: 'Heady API — Sovereign AI Platform',
    description: 'Complete API collection for the Heady Latent OS. All rate limits use Fibonacci numbers, all thresholds are φ-derived. Author: Eric Haywood — HeadySystems.',
    schema: 'https://schema.getpostman.com/json/collection/v2.1.0/collection.json',
    version: '4.0.0',
  },
  auth: {
    type: 'bearer',
    bearer: [{ key: 'token', value: '{{heady_token}}', type: 'string' }],
  },
  variable: [
    { key: 'base_url', value: 'http://localhost:3310', type: 'string' },
    { key: 'heady_token', value: '', type: 'string' },
    { key: 'phi', value: '1.6180339887', type: 'string' },
  ],
  item: [
    {
      name: 'System',
      description: 'Health, status, and system-level endpoints',
      item: [
        {
          name: 'Health Check',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/health', host: ['{{base_url}}'], path: ['health'] },
            description: 'Returns system health with φ-scaled metrics',
          },
        },
        {
          name: 'System Status',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/api/status', host: ['{{base_url}}'], path: ['api', 'status'] },
            description: 'Full system status including all 50 services',
          },
        },
        {
          name: 'Metrics',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/api/metrics', host: ['{{base_url}}'], path: ['api', 'metrics'] },
            description: 'Prometheus-compatible metrics export',
          },
        },
      ],
    },
    {
      name: 'Authentication',
      description: 'Auth endpoints — httpOnly cookies ONLY, NO localStorage',
      item: [
        {
          name: 'Login',
          request: {
            method: 'POST',
            url: { raw: '{{base_url}}/api/auth/login', host: ['{{base_url}}'], path: ['api', 'auth', 'login'] },
            header: [{ key: 'Content-Type', value: 'application/json' }],
            body: {
              mode: 'raw',
              raw: JSON.stringify({ email: 'user@example.com', password: 'secure_password' }, null, 2),
            },
            description: 'Authenticate and receive httpOnly session cookie',
          },
        },
        {
          name: 'Validate Session',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/api/auth/validate', host: ['{{base_url}}'], path: ['api', 'auth', 'validate'] },
            description: 'Validate current session (reads httpOnly cookie)',
          },
        },
        {
          name: 'Logout',
          request: {
            method: 'POST',
            url: { raw: '{{base_url}}/api/auth/logout', host: ['{{base_url}}'], path: ['api', 'auth', 'logout'] },
            description: 'Destroy session and clear httpOnly cookie',
          },
        },
      ],
    },
    {
      name: 'Memory',
      description: '3D Vector Memory — 384D embedding space',
      item: [
        {
          name: 'Search Memory',
          request: {
            method: 'POST',
            url: { raw: '{{base_url}}/api/memory/search', host: ['{{base_url}}'], path: ['api', 'memory', 'search'] },
            header: [{ key: 'Content-Type', value: 'application/json' }],
            body: {
              mode: 'raw',
              raw: JSON.stringify({ query: 'system architecture decisions', limit: 8, threshold: 0.618 }, null, 2),
            },
            description: 'Semantic vector search with φ-derived similarity threshold',
          },
        },
        {
          name: 'Store Memory',
          request: {
            method: 'POST',
            url: { raw: '{{base_url}}/api/memory/store', host: ['{{base_url}}'], path: ['api', 'memory', 'store'] },
            header: [{ key: 'Content-Type', value: 'application/json' }],
            body: {
              mode: 'raw',
              raw: JSON.stringify({ content: 'Architecture decision: using CSL gates for all routing', tags: ['architecture', 'csl'], importance: 0.882 }, null, 2),
            },
            description: 'Store new memory with 384D embedding',
          },
        },
        {
          name: 'Memory Stats',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/api/memory/stats', host: ['{{base_url}}'], path: ['api', 'memory', 'stats'] },
            description: 'Vector memory statistics and coherence scores',
          },
        },
      ],
    },
    {
      name: 'Agents',
      description: 'Multi-agent orchestration and node management',
      item: [
        {
          name: 'Agent Status',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/api/agents/status', host: ['{{base_url}}'], path: ['api', 'agents', 'status'] },
            description: 'Status of all agent nodes across Hot/Warm/Cold pools',
          },
        },
        {
          name: 'Dispatch Task',
          request: {
            method: 'POST',
            url: { raw: '{{base_url}}/api/agents/dispatch', host: ['{{base_url}}'], path: ['api', 'agents', 'dispatch'] },
            header: [{ key: 'Content-Type', value: 'application/json' }],
            body: {
              mode: 'raw',
              raw: JSON.stringify({ task: 'Analyze security configuration', priority: 'hot', nodes: ['MURPHY', 'CIPHER'] }, null, 2),
            },
            description: 'Dispatch a task to specific agent nodes via HeadyConductor',
          },
        },
        {
          name: 'Pipeline Status',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/api/agents/pipeline', host: ['{{base_url}}'], path: ['api', 'agents', 'pipeline'] },
            description: 'HCFullPipeline execution status',
          },
        },
      ],
    },
    {
      name: 'CSL Engine',
      description: 'Continuous Semantic Logic gates and operations',
      item: [
        {
          name: 'CSL Gate',
          request: {
            method: 'POST',
            url: { raw: '{{base_url}}/api/csl/gate', host: ['{{base_url}}'], path: ['api', 'csl', 'gate'] },
            header: [{ key: 'Content-Type', value: 'application/json' }],
            body: {
              mode: 'raw',
              raw: JSON.stringify({ input: [0.5, 0.3, 0.8], gate: [0.9, 0.1, 0.7], threshold: 0.809, temperature: 0.236 }, null, 2),
            },
            description: 'Apply CSL sigmoid gate with φ-derived parameters',
          },
        },
        {
          name: 'CSL Cosine AND',
          request: {
            method: 'POST',
            url: { raw: '{{base_url}}/api/csl/and', host: ['{{base_url}}'], path: ['api', 'csl', 'and'] },
            header: [{ key: 'Content-Type', value: 'application/json' }],
            body: {
              mode: 'raw',
              raw: JSON.stringify({ vectorA: [0.5, 0.3, 0.8], vectorB: [0.9, 0.1, 0.7] }, null, 2),
            },
            description: 'Compute CSL AND (cosine similarity)',
          },
        },
      ],
    },
    {
      name: 'Monitoring',
      description: 'Self-healing, coherence, and drift detection',
      item: [
        {
          name: 'Coherence Score',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/api/monitoring/coherence', host: ['{{base_url}}'], path: ['api', 'monitoring', 'coherence'] },
            description: 'Current system coherence score (cosine similarity of state vectors)',
          },
        },
        {
          name: 'Drift Alerts',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/api/monitoring/drift', host: ['{{base_url}}'], path: ['api', 'monitoring', 'drift'] },
            description: 'Active semantic drift alerts',
          },
        },
        {
          name: 'Self-Healing Log',
          request: {
            method: 'GET',
            url: { raw: '{{base_url}}/api/monitoring/healing', host: ['{{base_url}}'], path: ['api', 'monitoring', 'healing'] },
            description: 'Self-healing cycle history',
          },
        },
      ],
    },
  ],
}, null, 2));

// ─────────────────────────────────────────────────────────────
// docs/backup-strategy.md
// ─────────────────────────────────────────────────────────────
emit('docs/backup-strategy.md', `# Heady Platform — Backup & Disaster Recovery Strategy

**Author:** Eric Haywood — HeadySystems  
**License:** PROPRIETARY  
**Last Updated:** ${new Date().toISOString().split('T')[0]}

---

## Overview

All backup schedules, retention periods, and sizing use **φ-derived constants** and **Fibonacci numbers**. No magic numbers.

| Constant | Value | Usage |
|----------|-------|-------|
| φ (PHI) | 1.6180339887 | Scaling ratios |
| ψ (PSI) | 0.6180339887 | Decay/retention factor |
| Fibonacci | 1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597 | Scheduling & sizing |

---

## Backup Tiers

### Tier 1 — Critical Data (Hot)
**What:** PostgreSQL + pgvector (3D vector memory), auth tokens, session state  
**Schedule:** Every **8 hours** (fib(6))  
**Retention:** **89 days** (fib(11))  
**Method:** pg_dump with WAL archiving, encrypted at rest (AES-256)  
**Storage:** GCS bucket \`heady-backups-critical\`, region us-east1  
**RPO:** 8 hours  
**RTO:** 34 minutes (fib(9))

### Tier 2 — Important Data (Warm)
**What:** Application configs, deployment manifests, CI/CD state, monitoring data  
**Schedule:** Every **13 hours** (fib(7))  
**Retention:** **55 days** (fib(10))  
**Method:** Tarball snapshots, compressed with zstd  
**Storage:** GCS bucket \`heady-backups-warm\`, region us-east1  
**RPO:** 13 hours  
**RTO:** 55 minutes (fib(10))

### Tier 3 — Archival Data (Cold)
**What:** Logs, audit trails, historical metrics, experiment data  
**Schedule:** Every **34 hours** (fib(9))  
**Retention:** **233 days** (fib(13))  
**Method:** Incremental snapshots, Coldline storage class  
**Storage:** GCS bucket \`heady-backups-archive\`, region us-east1  
**RPO:** 34 hours  
**RTO:** 144 minutes (fib(12))

---

## Backup Components

### PostgreSQL + pgvector
\`\`\`bash
# Full backup with custom format for parallel restore
pg_dump -Fc -Z 5 -j 8 -f /backups/heady-pg-$(date +%Y%m%d-%H%M).dump heady_production

# WAL archiving for point-in-time recovery
archive_command = 'gcloud storage cp %p gs://heady-backups-critical/wal/%f'
\`\`\`

### Vector Memory (384D Embeddings)
\`\`\`bash
# Export vector data with metadata
psql -c "COPY (SELECT id, embedding::text, metadata, created_at FROM vector_memory) TO STDOUT WITH CSV HEADER" > /backups/vectors-$(date +%Y%m%d).csv

# Binary export for faster restore (pgvector native format)
pg_dump -t vector_memory --data-only -Fc -f /backups/vectors-native-$(date +%Y%m%d).dump heady_production
\`\`\`

### Configuration & Secrets
- **1Password**: Source of truth for all secrets (API keys, certificates)
- **Config backup**: \`tar czf /backups/config-$(date +%Y%m%d).tar.gz /app/config/ /app/.env.vault\`
- **Kubernetes secrets**: Backed up via Velero with encryption

### GitHub Repository (Genetic Code)
- **HeadyMe/Heady-pre-production**: GitHub's own redundancy + mirror to GCS
- **Schedule**: Real-time (push-based mirroring)
- **Retention:** Infinite (Git history is append-only)
- **Method:** \`git clone --mirror\` to GCS every fib(6)=8 hours

---

## Disaster Recovery Procedures

### Scenario 1: Database Corruption
1. Stop application services (graceful shutdown via lifecycle-bee.js)
2. Restore from latest pg_dump: \`pg_restore -j 8 -d heady_production /backups/latest.dump\`
3. Apply WAL logs for point-in-time recovery
4. Verify vector memory integrity: run coherence check across all embeddings
5. Restart services in dependency order (shared → core → services → agents)
6. Run self-healing cycle to detect any drift
7. **Target RTO:** 34 minutes (fib(9))

### Scenario 2: Full Region Failure (us-east1)
1. DNS failover to us-west1 standby (Cloudflare)
2. Promote read replica to primary
3. Restore application from latest container images (Cloud Run)
4. Verify all 50 services on ports 3310-3396
5. Run HCFullPipeline health gate
6. **Target RTO:** 89 minutes (fib(11))

### Scenario 3: Ransomware / Security Breach
1. **Isolate:** Network quarantine all compromised services
2. **Assess:** Run security-bee.js full audit
3. **Rotate:** All credentials via 1Password + HeadySecretService
4. **Restore:** From last known-clean backup (verify SHA-256 checksums)
5. **Harden:** Apply ip-anomaly-detector.js blocks, review WAF rules
6. **Report:** Generate incident report via documentation-bee.js
7. **Target RTO:** 144 minutes (fib(12))

---

## Verification & Testing

### Backup Verification Schedule
| Test | Frequency | Description |
|------|-----------|-------------|
| Backup integrity | Every **8 hours** (fib(6)) | SHA-256 checksum verification |
| Restore test (sample) | Every **13 days** (fib(7)) | Restore to staging environment |
| Full DR drill | Every **89 days** (fib(11)) | Complete disaster recovery simulation |
| Chaos experiment | Every **34 days** (fib(9)) | chaos-engineering.js dependency failure test |

### Automated Monitoring
- **Alert threshold:** Backup age > fib(n+1) × schedule interval → WARNING
- **Critical alert:** Backup age > fib(n+2) × schedule interval → PAGE
- **Health probe:** \`/api/monitoring/backup-health\` returns last backup timestamps

---

## Cost Estimation (φ-scaled)

| Tier | Monthly Storage | Monthly Transfer | Total |
|------|----------------|-----------------|-------|
| Critical (Hot) | ~$13/mo (fib(7)) | ~$5/mo (fib(5)) | ~$18/mo |
| Important (Warm) | ~$8/mo (fib(6)) | ~$3/mo (fib(4)) | ~$11/mo |
| Archival (Cold) | ~$5/mo (fib(5)) | ~$1/mo (fib(1)) | ~$6/mo |
| **Total** | | | **~$35/mo** |

---

## Compliance

- All backups encrypted at rest (AES-256) and in transit (TLS 1.3)
- Access logged to immutable audit trail
- Retention policies enforced automatically (GCS lifecycle rules)
- Deletion requires dual approval (HeadySoul governance gate)
- SOC 2 Type II aligned backup procedures
`);

console.log(`\n✅ Wave 4 Part 2 complete: security/ (3) + web/ (2) + tests/ (2) + docs/ (2)`);
