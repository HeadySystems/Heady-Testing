#!/usr/bin/env bash
# health-check-all.sh — Health Check All 50 Heady Services
#
# Checks /health endpoint on all services (ports 3310-3396).
# φ-scaled timeout (1.618s), color-coded output, summary report.
#
# Usage: bash scripts/health-check-all.sh [base_url]
#
# Eric Haywood — HeadySystems
# License: PROPRIETARY

set -euo pipefail

BASE_URL="${1:-http://localhost}"
TIMEOUT="1.618"  # φ-scaled timeout in seconds
PASSED=0
FAILED=0
SKIPPED=0
TOTAL=0

# ANSI colors
GREEN="\033[0;32m"
RED="\033[0;31m"
YELLOW="\033[0;33m"
BLUE="\033[0;34m"
NC="\033[0m" # No Color

echo -e "${BLUE}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   Heady Platform — Service Health Check              ║${NC}"
echo -e "${BLUE}║   Author: Eric Haywood — HeadySystems                ║${NC}"
echo -e "${BLUE}║   φ-scaled timeout: ${TIMEOUT}s                           ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════════════╝${NC}"
echo ""

# Service definitions: name port
SERVICES=(
  "heady-brain:3310"
  "heady-brains:3311"
  "heady-infer:3312"
  "ai-router:3313"
  "model-gateway:3314"
  "heady-embed:3315"
  "heady-memory:3316"
  "heady-vector:3317"
  "heady-projection:3318"
  "heady-bee-factory:3319"
  "heady-hive:3320"
  "heady-federation:3321"
  "heady-soul:3322"
  "heady-conductor:3323"
  "heady-orchestration:3324"
  "auto-success-engine:3325"
  "hcfullpipeline-executor:3326"
  "heady-chain:3327"
  "prompt-manager:3328"
  "heady-guard:3329"
  "heady-security:3330"
  "heady-governance:3331"
  "secret-gateway:3332"
  "heady-health:3333"
  "heady-eval:3334"
  "heady-maintenance:3335"
  "heady-testing:3336"
  "heady-web:3337"
  "heady-buddy:3338"
  "heady-ui:3339"
  "heady-onboarding:3340"
  "heady-pilot-onboarding:3341"
  "heady-task-browser:3342"
  "heady-cache:3343"
  "api-gateway:3344"
  "domain-router:3345"
  "mcp-server:3346"
  "google-mcp:3347"
  "memory-mcp:3348"
  "perplexity-mcp:3349"
  "jules-mcp:3350"
  "huggingface-gateway:3351"
  "colab-gateway:3352"
  "silicon-bridge:3353"
  "discord-bot:3354"
  "heady-vinci:3355"
  "heady-autobiographer:3356"
  "heady-midi:3357"
  "budget-tracker:3358"
  "cli-service:3359"
)

check_service() {
  local name="${1%%:*}"
  local port="${1##*:}"
  local url="${BASE_URL}:${port}/health"
  TOTAL=$((TOTAL + 1))

  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout "${TIMEOUT}" --max-time "${TIMEOUT}" "${url}" 2>/dev/null || echo "000")

  if [ "${HTTP_CODE}" = "200" ]; then
    PASSED=$((PASSED + 1))
    printf "  ${GREEN}✓${NC} %-30s ${GREEN}%s${NC} (port %s)\n" "${name}" "UP" "${port}"
  elif [ "${HTTP_CODE}" = "000" ]; then
    SKIPPED=$((SKIPPED + 1))
    printf "  ${YELLOW}○${NC} %-30s ${YELLOW}%s${NC} (port %s)\n" "${name}" "UNREACHABLE" "${port}"
  else
    FAILED=$((FAILED + 1))
    printf "  ${RED}✗${NC} %-30s ${RED}%s${NC} (port %s, HTTP %s)\n" "${name}" "DOWN" "${port}" "${HTTP_CODE}"
  fi
}

echo "Checking ${#SERVICES[@]} services..."
echo ""

for service in "${SERVICES[@]}"; do
  check_service "${service}"
done

echo ""
echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"
echo -e "  Total:       ${TOTAL}"
echo -e "  ${GREEN}Passed:      ${PASSED}${NC}"
echo -e "  ${RED}Failed:      ${FAILED}${NC}"
echo -e "  ${YELLOW}Unreachable: ${SKIPPED}${NC}"

# φ-derived uptime percentage
if [ "${TOTAL}" -gt 0 ]; then
  UPTIME=$(echo "scale=3; ${PASSED} * 100 / ${TOTAL}" | bc 2>/dev/null || echo "N/A")
  echo -e "  Uptime:      ${UPTIME}%"
fi

echo -e "${BLUE}═══════════════════════════════════════════════════════${NC}"

# Exit code: 0 if no failures, 1 if any failed
if [ "${FAILED}" -gt 0 ]; then
  exit 1
fi
exit 0
