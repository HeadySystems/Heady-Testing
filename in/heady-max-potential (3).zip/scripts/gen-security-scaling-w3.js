/**
 * Wave 3 Generator — 4 Security + 5 Scaling modules
 * Author: Eric Haywood | φ-derived constants | ESM only | No stubs
 */
import { writeFileSync, mkdirSync } from 'fs';
import { dirname } from 'path';

function write(path, content) {
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, content.trimStart(), 'utf8');
  console.log(`  ✓ ${path} (${content.length} chars)`);
}

const BASE = '/home/user/workspace/heady-max-potential';

// ═══════════════════════════════════════════════════════════════════
// security/owasp-ai-defense.js — OWASP AI Top 10 Defense Layer
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/security/owasp-ai-defense.js`, `
/**
 * OWASPAIDefense — OWASP AI/ML Top 10 Defense Implementation
 * Covers: ML01-Prompt Injection, ML02-Training Data Poisoning,
 * ML03-Model Inversion, ML04-Membership Inference, ML05-Model Stealing,
 * ML06-Supply Chain, ML07-Transfer Learning Attack, ML08-Model Skewing,
 * ML09-Output Integrity, ML10-Neural Net Reprogramming.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash, randomBytes } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(typeof data === 'string' ? data : JSON.stringify(data)).digest('hex');
}

// ── ML01: Prompt Injection Defense ───────────────────────────────
class PromptInjectionShield {
  constructor() {
    this.patterns = [
      /ignore\\s+(all\\s+)?previous\\s+(instructions|prompts)/i,
      /you\\s+are\\s+now\\s+(?:a|an|the)\\s+/i,
      /system:\\s*override/i,
      /\\[INST\\]/i,
      /<<SYS>>|<\\/SYS>/i,
      /\x60\x60\x60\\s*system/i,
      /\\bDAN\\b.*\\bmode\\b/i,
      /do\\s+anything\\s+now/i,
      /jailbreak/i,
      /bypass\\s+(safety|filter|guard|restriction)/i,
      /pretend\\s+(you\\s+are|to\\s+be)/i,
      /role\\s*:\\s*(system|admin|root)/i,
      /\\bact\\s+as\\s+(root|admin|god)/i,
      /reveal\\s+(your|the)\\s+(system|initial)\\s+prompt/i,
    ];
    this.canaryToken = randomBytes(FIB[8]).toString('hex');
    this.maxInputLength = FIB[16] * FIB[6]; // 7896 chars
    this.detectionLog = [];
    this.maxLogSize = FIB[16];
  }

  scan(input) {
    if (typeof input !== 'string') return { safe: false, reason: 'non-string-input' };
    if (input.length > this.maxInputLength) return { safe: false, reason: 'input-too-long' };

    const threats = [];
    for (const pattern of this.patterns) {
      if (pattern.test(input)) {
        threats.push({ pattern: pattern.source, severity: 'high' });
      }
    }

    // Check for canary token leakage
    if (input.includes(this.canaryToken)) {
      threats.push({ pattern: 'canary-leak', severity: 'critical' });
    }

    // Unicode obfuscation check
    const suspiciousUnicode = /[\\u200B-\\u200F\\u2028-\\u202F\\u2060-\\u2064\\uFEFF]/g;
    if (suspiciousUnicode.test(input)) {
      threats.push({ pattern: 'unicode-obfuscation', severity: 'medium' });
    }

    const threatScore = threats.length > 0
      ? Math.min(1.0, threats.length / FIB[5])
      : 0;

    const blocked = cslGate(1.0, threatScore, CSL_THRESHOLDS.LOW) > CSL_THRESHOLDS.MEDIUM;

    const result = {
      safe: !blocked,
      threatScore,
      threats,
      inputHash: hashSHA256(input),
      canaryIntact: !input.includes(this.canaryToken),
    };

    this.detectionLog.push({ ts: Date.now(), ...result });
    if (this.detectionLog.length > this.maxLogSize) {
      this.detectionLog = this.detectionLog.slice(-FIB[14]);
    }

    return result;
  }
}

// ── ML02: Training Data Poisoning Defense ────────────────────────
class DataPoisoningGuard {
  constructor() {
    this.anomalyThreshold = CSL_THRESHOLDS.HIGH;
    this.maxDeviationZ = PHI * 2;
    this.sampleSize = FIB[12]; // 144
  }

  validateBatch(dataPoints) {
    if (!Array.isArray(dataPoints) || dataPoints.length === 0) {
      return { valid: false, reason: 'empty-batch' };
    }

    // Statistical outlier detection
    const values = dataPoints.map(d => typeof d === 'number' ? d : (d.value ?? 0));
    const mean = values.reduce((a, b) => a + b, 0) / values.length;
    const variance = values.reduce((a, v) => a + (v - mean) ** 2, 0) / values.length;
    const stdDev = Math.sqrt(variance);

    const outliers = [];
    for (let i = 0; i < values.length; i++) {
      const z = stdDev > 0 ? Math.abs(values[i] - mean) / stdDev : 0;
      if (z > this.maxDeviationZ) {
        outliers.push({ index: i, zScore: z, value: values[i] });
      }
    }

    const poisonScore = outliers.length / values.length;
    const safe = cslGate(1.0, 1.0 - poisonScore, this.anomalyThreshold) > CSL_THRESHOLDS.MEDIUM;

    return {
      valid: safe,
      batchSize: dataPoints.length,
      mean,
      stdDev,
      outlierCount: outliers.length,
      poisonScore,
      outliers: outliers.slice(0, FIB[6]),
    };
  }
}

// ── ML03/04: Model Inversion & Membership Inference Defense ──────
class PrivacyShield {
  constructor() {
    this.noiseScale = PSI2; // Differential privacy noise magnitude
    this.queryBudget = FIB[12]; // 144 queries per session
    this.queryCounts = new Map();
    this.resetIntervalMs = FIB[10] * 60 * 1000; // 55 minutes
  }

  addNoise(output) {
    if (typeof output === 'number') {
      const noise = (Math.random() - PSI) * this.noiseScale;
      return output + noise;
    }
    if (Array.isArray(output)) {
      return output.map(v => this.addNoise(v));
    }
    return output;
  }

  checkQueryBudget(sessionId) {
    const now = Date.now();
    const session = this.queryCounts.get(sessionId);

    if (!session || now - session.startedAt > this.resetIntervalMs) {
      this.queryCounts.set(sessionId, { count: 1, startedAt: now });
      return { allowed: true, remaining: this.queryBudget - 1 };
    }

    session.count++;
    const remaining = this.queryBudget - session.count;
    const allowed = remaining >= 0;
    return { allowed, remaining: Math.max(0, remaining), count: session.count };
  }

  truncateConfidence(scores) {
    // Round to Fibonacci-step precision to prevent precise confidence extraction
    const step = 1.0 / FIB[8]; // 1/21 ≈ 0.0476
    return scores.map(s => Math.round(s / step) * step);
  }
}

// ── ML05: Model Stealing Defense ─────────────────────────────────
class ModelStealingGuard {
  constructor() {
    this.rateLimits = new Map();
    this.maxQueriesPerWindow = FIB[11]; // 89
    this.windowMs = FIB[10] * 60 * 1000; // 55 minutes
    this.suspicionThreshold = CSL_THRESHOLDS.MEDIUM;
    this.suspiciousPatterns = [];
  }

  trackQuery(clientId, query) {
    const now = Date.now();
    let client = this.rateLimits.get(clientId);

    if (!client || now - client.windowStart > this.windowMs) {
      client = { windowStart: now, queries: [], totalQueries: 0 };
      this.rateLimits.set(clientId, client);
    }

    client.queries.push({ ts: now, hash: hashSHA256(query) });
    client.totalQueries++;

    // Prune old queries
    client.queries = client.queries.filter(q => now - q.ts < this.windowMs);

    // Detect systematic probing
    const queryRate = client.queries.length / (this.windowMs / 1000);
    const isSystematic = queryRate > (this.maxQueriesPerWindow / (this.windowMs / 1000));

    // Check for near-duplicate queries (boundary probing)
    const uniqueHashes = new Set(client.queries.map(q => q.hash));
    const duplicationRatio = 1.0 - (uniqueHashes.size / client.queries.length);

    const suspicionScore =
      (isSystematic ? PSI : 0) +
      (duplicationRatio > PSI ? PSI2 : 0);

    const blocked = cslGate(1.0, suspicionScore, this.suspicionThreshold) > CSL_THRESHOLDS.HIGH;

    return {
      allowed: !blocked,
      queryCount: client.queries.length,
      suspicionScore,
      isSystematic,
      duplicationRatio,
    };
  }
}

// ── ML09: Output Integrity Verification ──────────────────────────
class OutputIntegrity {
  constructor() {
    this.outputLog = [];
    this.maxLogSize = FIB[16];
    this.seed = 42;
    this.temperature = 0;
  }

  verify(output) {
    const hash = hashSHA256({
      output,
      seed: this.seed,
      temperature: this.temperature,
      ts: Date.now(),
    });

    const entry = {
      hash,
      outputType: typeof output,
      outputLength: typeof output === 'string' ? output.length : JSON.stringify(output).length,
      ts: Date.now(),
      seed: this.seed,
      temperature: this.temperature,
    };

    this.outputLog.push(entry);
    if (this.outputLog.length > this.maxLogSize) {
      this.outputLog = this.outputLog.slice(-FIB[14]);
    }

    return { verified: true, hash, seed: this.seed, temperature: this.temperature };
  }

  checkDrift(recentOutputs) {
    if (recentOutputs.length < FIB[3]) return { drift: false };

    // Check if outputs with same inputs produce different hashes
    const hashGroups = {};
    for (const out of recentOutputs) {
      const inputHash = out.inputHash ?? 'unknown';
      if (!hashGroups[inputHash]) hashGroups[inputHash] = new Set();
      hashGroups[inputHash].add(out.outputHash);
    }

    const inconsistencies = Object.values(hashGroups).filter(s => s.size > 1).length;
    const driftScore = inconsistencies / Object.keys(hashGroups).length;

    return {
      drift: driftScore > PSI2,
      driftScore,
      inconsistencies,
      totalInputGroups: Object.keys(hashGroups).length,
    };
  }
}

// ── OWASP AI Defense Coordinator ─────────────────────────────────
class OWASPAIDefense {
  constructor(config = {}) {
    this.promptShield = new PromptInjectionShield();
    this.poisoningGuard = new DataPoisoningGuard();
    this.privacyShield = new PrivacyShield();
    this.stealingGuard = new ModelStealingGuard();
    this.outputIntegrity = new OutputIntegrity();
    this.enabled = {
      ML01: config.ML01 ?? true,
      ML02: config.ML02 ?? true,
      ML03: config.ML03 ?? true,
      ML04: config.ML04 ?? true,
      ML05: config.ML05 ?? true,
      ML09: config.ML09 ?? true,
    };
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  async scanRequest(request) {
    const results = {};

    if (this.enabled.ML01 && request.prompt) {
      results.promptInjection = this.promptShield.scan(request.prompt);
    }

    if (this.enabled.ML05 && request.clientId) {
      results.modelStealing = this.stealingGuard.trackQuery(request.clientId, request.prompt ?? '');
    }

    if (this.enabled.ML03 && request.sessionId) {
      results.privacy = this.privacyShield.checkQueryBudget(request.sessionId);
    }

    const blocked = Object.values(results).some(r =>
      r.safe === false || r.allowed === false
    );

    this._audit('scan-request', { blocked, checks: Object.keys(results) });

    return {
      allowed: !blocked,
      checks: results,
      requestHash: hashSHA256(request),
    };
  }

  async scanOutput(output, request = {}) {
    const results = {};

    if (this.enabled.ML09) {
      results.integrity = this.outputIntegrity.verify(output);
    }

    if (this.enabled.ML03) {
      results.privacyProtected = this.privacyShield.addNoise(output);
    }

    this._audit('scan-output', { checks: Object.keys(results) });
    return results;
  }

  validateTrainingData(data) {
    if (!this.enabled.ML02) return { valid: true, skipped: true };
    return this.poisoningGuard.validateBatch(data);
  }

  health() {
    return {
      shields: Object.entries(this.enabled).map(([k, v]) => ({ id: k, enabled: v })),
      promptDetectionLogSize: this.promptShield.detectionLog.length,
      outputLogSize: this.outputIntegrity.outputLog.length,
      auditLogSize: this.auditLog.length,
    };
  }
}

export default OWASPAIDefense;
export { OWASPAIDefense, PromptInjectionShield, DataPoisoningGuard, PrivacyShield, ModelStealingGuard, OutputIntegrity };
`);

// ═══════════════════════════════════════════════════════════════════
// security/structured-logger.js — Structured Security Logger
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/security/structured-logger.js`, `
/**
 * StructuredLogger — Security-Auditable Structured Logger
 * Produces JSON-formatted, tamper-evident log entries with SHA-256 chain hashing,
 * log level gating via CSL, and φ-sized ring buffer.
 * All constants φ-derived. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(typeof data === 'string' ? data : JSON.stringify(data)).digest('hex');
}

// ── Log Levels (CSL-scored) ──────────────────────────────────────
const LOG_LEVELS = {
  TRACE:    { score: 0.1, numeric: 0 },
  DEBUG:    { score: 0.3, numeric: 1 },
  INFO:     { score: CSL_THRESHOLDS.MINIMUM, numeric: 2 },
  WARN:     { score: CSL_THRESHOLDS.LOW, numeric: 3 },
  ERROR:    { score: CSL_THRESHOLDS.MEDIUM, numeric: 4 },
  FATAL:    { score: CSL_THRESHOLDS.CRITICAL, numeric: 5 },
  SECURITY: { score: 1.0, numeric: 6 },
};

// ── Ring Buffer ──────────────────────────────────────────────────
class RingBuffer {
  constructor(capacity = FIB[17]) { // 1597
    this.capacity = capacity;
    this.buffer = new Array(capacity);
    this.head = 0;
    this.size = 0;
  }

  push(item) {
    this.buffer[this.head] = item;
    this.head = (this.head + 1) % this.capacity;
    if (this.size < this.capacity) this.size++;
    return this.size;
  }

  toArray() {
    if (this.size < this.capacity) {
      return this.buffer.slice(0, this.size);
    }
    return [
      ...this.buffer.slice(this.head),
      ...this.buffer.slice(0, this.head),
    ];
  }

  last(n = FIB[8]) {
    const arr = this.toArray();
    return arr.slice(-n);
  }
}

// ── Transport Interface ──────────────────────────────────────────
class ConsoleTransport {
  write(entry) {
    const level = entry.level;
    const formatted = JSON.stringify(entry, null, 0);
    if (level === 'ERROR' || level === 'FATAL' || level === 'SECURITY') {
      process.stderr.write(formatted + '\\n');
    } else {
      process.stdout.write(formatted + '\\n');
    }
  }
}

class FileTransport {
  constructor(config = {}) {
    this.path = config.path ?? '/tmp/heady-security.log';
    this.buffer = [];
    this.flushSize = config.flushSize ?? FIB[8]; // 21
  }

  write(entry) {
    this.buffer.push(JSON.stringify(entry));
    if (this.buffer.length >= this.flushSize) {
      this.flush();
    }
  }

  flush() {
    // In production, write to file system
    const batch = this.buffer.splice(0);
    return batch.length;
  }
}

// ── Structured Logger ────────────────────────────────────────────
class StructuredLogger {
  constructor(config = {}) {
    this.serviceName = config.serviceName ?? 'heady-os';
    this.version = config.version ?? '3.0.0';
    this.environment = config.environment ?? 'production';
    this.minLevel = config.minLevel ?? 'INFO';
    this.minLevelScore = LOG_LEVELS[this.minLevel]?.score ?? CSL_THRESHOLDS.MINIMUM;

    // Transports
    this.transports = config.transports ?? [new ConsoleTransport()];

    // Ring buffer for in-memory log retention
    this.ringBuffer = new RingBuffer(config.bufferSize ?? FIB[17]);

    // Hash chain for tamper evidence
    this.lastHash = hashSHA256({ genesis: true, service: this.serviceName, ts: Date.now() });
    this.entryCount = 0;

    // Sensitive field redaction
    this.redactFields = new Set(config.redactFields ?? [
      'password', 'token', 'secret', 'apiKey', 'api_key',
      'authorization', 'cookie', 'session', 'credential',
    ]);

    // Correlation context
    this.defaultContext = {
      service: this.serviceName,
      version: this.version,
      environment: this.environment,
    };
  }

  _shouldLog(level) {
    const levelDef = LOG_LEVELS[level];
    if (!levelDef) return false;
    return cslGate(1.0, levelDef.score, this.minLevelScore) > CSL_THRESHOLDS.MINIMUM;
  }

  _redact(obj) {
    if (typeof obj !== 'object' || obj === null) return obj;
    const redacted = Array.isArray(obj) ? [] : {};
    for (const [key, value] of Object.entries(obj)) {
      if (this.redactFields.has(key.toLowerCase())) {
        redacted[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        redacted[key] = this._redact(value);
      } else {
        redacted[key] = value;
      }
    }
    return redacted;
  }

  _buildEntry(level, message, data = {}, context = {}) {
    this.entryCount++;

    const entry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      ...this.defaultContext,
      ...context,
      data: this._redact(data),
      sequence: this.entryCount,
      chainHash: this.lastHash,
    };

    // Compute hash chain
    entry.hash = hashSHA256({ ...entry });
    this.lastHash = entry.hash;

    return entry;
  }

  log(level, message, data = {}, context = {}) {
    if (!this._shouldLog(level)) return null;

    const entry = this._buildEntry(level, message, data, context);

    // Write to all transports
    for (const transport of this.transports) {
      try { transport.write(entry); } catch (_) { /* transport failure should not crash */ }
    }

    // Store in ring buffer
    this.ringBuffer.push(entry);

    return entry;
  }

  trace(message, data, context) { return this.log('TRACE', message, data, context); }
  debug(message, data, context) { return this.log('DEBUG', message, data, context); }
  info(message, data, context) { return this.log('INFO', message, data, context); }
  warn(message, data, context) { return this.log('WARN', message, data, context); }
  error(message, data, context) { return this.log('ERROR', message, data, context); }
  fatal(message, data, context) { return this.log('FATAL', message, data, context); }
  security(message, data, context) { return this.log('SECURITY', message, data, context); }

  // Create child logger with additional context
  child(context) {
    const child = Object.create(this);
    child.defaultContext = { ...this.defaultContext, ...context };
    return child;
  }

  // Verify hash chain integrity
  verifyChain(entries) {
    for (let i = 1; i < entries.length; i++) {
      if (entries[i].chainHash !== entries[i - 1].hash) {
        return { valid: false, brokenAt: i, entry: entries[i] };
      }
    }
    return { valid: true, entriesChecked: entries.length };
  }

  recentEntries(count = FIB[8]) {
    return this.ringBuffer.last(count);
  }

  stats() {
    return {
      service: this.serviceName,
      totalEntries: this.entryCount,
      bufferSize: this.ringBuffer.size,
      bufferCapacity: this.ringBuffer.capacity,
      minLevel: this.minLevel,
      transports: this.transports.length,
    };
  }
}

export default StructuredLogger;
export { StructuredLogger, RingBuffer, ConsoleTransport, FileTransport, LOG_LEVELS };
`);

// ═══════════════════════════════════════════════════════════════════
// security/request-signer.js — HMAC Request Signing & Verification
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/security/request-signer.js`, `
/**
 * RequestSigner — HMAC-SHA256 Request Signing & Verification
 * Signs outgoing requests and verifies incoming ones using rotating secrets,
 * timestamp validation, and replay protection via nonce cache.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHmac, createHash, randomBytes, timingSafeEqual } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function hashSHA256(data) {
  return createHash('sha256').update(typeof data === 'string' ? data : JSON.stringify(data)).digest('hex');
}

// ── Nonce Cache (replay protection) ──────────────────────────────
class NonceCache {
  constructor(maxSize = FIB[16], ttlMs = FIB[10] * 60 * 1000) { // 987 entries, 55min TTL
    this.cache = new Map();
    this.maxSize = maxSize;
    this.ttlMs = ttlMs;
  }

  add(nonce) {
    this.gc();
    if (this.cache.has(nonce)) return false; // replay detected
    this.cache.set(nonce, Date.now());
    return true;
  }

  has(nonce) {
    this.gc();
    return this.cache.has(nonce);
  }

  gc() {
    const now = Date.now();
    for (const [nonce, ts] of this.cache) {
      if (now - ts > this.ttlMs) this.cache.delete(nonce);
    }
    // Trim if still over max
    while (this.cache.size > this.maxSize) {
      const oldest = this.cache.keys().next().value;
      this.cache.delete(oldest);
    }
  }

  stats() {
    return { size: this.cache.size, maxSize: this.maxSize, ttlMs: this.ttlMs };
  }
}

// ── Key Rotation ─────────────────────────────────────────────────
class KeyRotator {
  constructor(config = {}) {
    this.keys = new Map();
    this.rotationIntervalMs = config.rotationIntervalMs ?? FIB[13] * 60 * 1000; // 233 minutes
    this.maxKeys = config.maxKeys ?? FIB[5]; // 5 concurrent keys
    this.currentKeyId = null;
  }

  addKey(keyId, secret) {
    this.keys.set(keyId, { secret, createdAt: Date.now(), usageCount: 0 });
    this.currentKeyId = keyId;

    // Prune old keys
    while (this.keys.size > this.maxKeys) {
      const oldest = [...this.keys.entries()]
        .sort((a, b) => a[1].createdAt - b[1].createdAt)[0];
      if (oldest[0] !== this.currentKeyId) {
        this.keys.delete(oldest[0]);
      }
    }
  }

  getKey(keyId) {
    const key = this.keys.get(keyId ?? this.currentKeyId);
    if (key) key.usageCount++;
    return key;
  }

  getCurrentKeyId() {
    return this.currentKeyId;
  }

  shouldRotate() {
    if (!this.currentKeyId) return true;
    const current = this.keys.get(this.currentKeyId);
    if (!current) return true;
    return Date.now() - current.createdAt > this.rotationIntervalMs;
  }

  rotate() {
    const newKeyId = \`key-\${Date.now()}-\${randomBytes(FIB[6]).toString('hex')}\`;
    const newSecret = randomBytes(FIB[9]).toString('base64'); // 34 bytes
    this.addKey(newKeyId, newSecret);
    return { keyId: newKeyId };
  }

  stats() {
    return {
      currentKeyId: this.currentKeyId,
      totalKeys: this.keys.size,
      maxKeys: this.maxKeys,
      shouldRotate: this.shouldRotate(),
    };
  }
}

// ── Request Signer ───────────────────────────────────────────────
class RequestSigner {
  constructor(config = {}) {
    this.keyRotator = new KeyRotator(config);
    this.nonceCache = new NonceCache();
    this.algorithm = 'sha256';
    this.timestampToleranceMs = config.timestampToleranceMs ?? FIB[10] * 1000; // 55s
    this.headerPrefix = config.headerPrefix ?? 'X-Heady';
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];

    // Initialize with default key if provided
    if (config.secret) {
      this.keyRotator.addKey('default', config.secret);
    }
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  _buildSigningString(method, path, timestamp, nonce, bodyHash) {
    return [method.toUpperCase(), path, timestamp, nonce, bodyHash].join('\\n');
  }

  sign(request) {
    // Auto-rotate if needed
    if (this.keyRotator.shouldRotate()) {
      this.keyRotator.rotate();
    }

    const keyId = this.keyRotator.getCurrentKeyId();
    const keyData = this.keyRotator.getKey(keyId);
    if (!keyData) return { error: 'No signing key available' };

    const timestamp = Date.now().toString();
    const nonce = randomBytes(FIB[8]).toString('hex'); // 21 bytes
    const body = request.body ? JSON.stringify(request.body) : '';
    const bodyHash = hashSHA256(body);

    const signingString = this._buildSigningString(
      request.method ?? 'GET',
      request.path ?? '/',
      timestamp,
      nonce,
      bodyHash
    );

    const signature = createHmac(this.algorithm, keyData.secret)
      .update(signingString)
      .digest('hex');

    this._audit('sign', { method: request.method, path: request.path, keyId });

    return {
      headers: {
        [\`\${this.headerPrefix}-Signature\`]: signature,
        [\`\${this.headerPrefix}-Timestamp\`]: timestamp,
        [\`\${this.headerPrefix}-Nonce\`]: nonce,
        [\`\${this.headerPrefix}-KeyId\`]: keyId,
        [\`\${this.headerPrefix}-BodyHash\`]: bodyHash,
      },
      signature,
      keyId,
    };
  }

  verify(request, headers) {
    const signature = headers[\`\${this.headerPrefix}-Signature\`];
    const timestamp = headers[\`\${this.headerPrefix}-Timestamp\`];
    const nonce = headers[\`\${this.headerPrefix}-Nonce\`];
    const keyId = headers[\`\${this.headerPrefix}-KeyId\`];
    const bodyHash = headers[\`\${this.headerPrefix}-BodyHash\`];

    if (!signature || !timestamp || !nonce || !keyId) {
      this._audit('verify-fail', { reason: 'missing-headers' });
      return { valid: false, reason: 'missing-required-headers' };
    }

    // Timestamp check
    const ts = parseInt(timestamp, 10);
    if (Math.abs(Date.now() - ts) > this.timestampToleranceMs) {
      this._audit('verify-fail', { reason: 'timestamp-expired' });
      return { valid: false, reason: 'timestamp-outside-tolerance' };
    }

    // Replay check
    if (this.nonceCache.has(nonce)) {
      this._audit('verify-fail', { reason: 'replay-detected' });
      return { valid: false, reason: 'nonce-replay-detected' };
    }

    // Key lookup
    const keyData = this.keyRotator.getKey(keyId);
    if (!keyData) {
      this._audit('verify-fail', { reason: 'unknown-key' });
      return { valid: false, reason: 'unknown-key-id' };
    }

    // Body hash verification
    const body = request.body ? JSON.stringify(request.body) : '';
    const computedBodyHash = hashSHA256(body);
    if (bodyHash !== computedBodyHash) {
      this._audit('verify-fail', { reason: 'body-tampered' });
      return { valid: false, reason: 'body-hash-mismatch' };
    }

    // Signature verification
    const signingString = this._buildSigningString(
      request.method ?? 'GET',
      request.path ?? '/',
      timestamp,
      nonce,
      bodyHash
    );

    const expected = createHmac(this.algorithm, keyData.secret)
      .update(signingString)
      .digest('hex');

    const sigBuffer = Buffer.from(signature, 'hex');
    const expBuffer = Buffer.from(expected, 'hex');

    if (sigBuffer.length !== expBuffer.length || !timingSafeEqual(sigBuffer, expBuffer)) {
      this._audit('verify-fail', { reason: 'signature-mismatch' });
      return { valid: false, reason: 'signature-mismatch' };
    }

    // Mark nonce as used
    this.nonceCache.add(nonce);

    this._audit('verify-success', { keyId, method: request.method });
    return { valid: true, keyId };
  }

  health() {
    return {
      keys: this.keyRotator.stats(),
      nonceCache: this.nonceCache.stats(),
      auditLogSize: this.auditLog.length,
    };
  }
}

export default RequestSigner;
export { RequestSigner, NonceCache, KeyRotator };
`);

// ═══════════════════════════════════════════════════════════════════
// security/cors-strict.js — Strict CORS Middleware
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/security/cors-strict.js`, `
/**
 * CorsStrict — Strict CORS Middleware with Origin Allowlisting
 * Enforces tight CORS policy for all Heady domains, with CSL-gated
 * origin matching, preflight caching, and credential handling.
 * All constants φ-derived. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Heady Domain Allowlist ───────────────────────────────────────
const HEADY_DOMAINS = [
  'headyme.com',
  'headysystems.com',
  'heady-ai.com',
  'headyos.com',
  'headyconnection.org',
  'headyconnection.com',
  'headyex.com',
  'headyfinance.com',
  'admin.headysystems.com',
  'headybuddy.org',
  'headymcp.com',
  'headyio.com',
  'headybot.com',
  'headyapi.com',
  'headyai.com',
];

function buildAllowedOrigins(domains, includeLocalDev = false) {
  const origins = new Set();
  for (const domain of domains) {
    origins.add(\`https://\${domain}\`);
    origins.add(\`https://www.\${domain}\`);
  }
  if (includeLocalDev) {
    // Fibonacci ports for local development
    for (const port of [3000, 3310, 3311, 3312, 3313, 3314, 3315, 3316, 3317, 5173, 8080]) {
      origins.add(\`http://localhost:\${port}\`);
      origins.add(\`http://127.0.0.1:\${port}\`);
    }
  }
  return origins;
}

// ── CORS Configuration ───────────────────────────────────────────
class CorsStrict {
  constructor(config = {}) {
    this.allowedOrigins = buildAllowedOrigins(
      config.domains ?? HEADY_DOMAINS,
      config.includeLocalDev ?? (config.environment !== 'production')
    );
    this.customOrigins = new Set(config.customOrigins ?? []);

    this.allowedMethods = config.methods ?? ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'];
    this.allowedHeaders = config.headers ?? [
      'Content-Type',
      'Authorization',
      'X-Heady-Signature',
      'X-Heady-Timestamp',
      'X-Heady-Nonce',
      'X-Heady-KeyId',
      'X-Heady-BodyHash',
      'X-Request-ID',
      'X-Correlation-ID',
    ];
    this.exposedHeaders = config.exposedHeaders ?? [
      'X-Request-ID',
      'X-RateLimit-Remaining',
      'X-RateLimit-Reset',
    ];
    this.maxAge = config.maxAge ?? FIB[11] * 60; // 89 minutes (in seconds)
    this.credentials = config.credentials ?? true;

    // Violation tracking
    this.violations = [];
    this.maxViolations = FIB[16]; // 987
    this.blockThreshold = FIB[6]; // 8 violations before enhanced blocking
    this.violationCounts = new Map();
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  isOriginAllowed(origin) {
    if (!origin) return false;
    if (this.allowedOrigins.has(origin)) return true;
    if (this.customOrigins.has(origin)) return true;

    // Wildcard subdomain matching for Heady domains
    try {
      const url = new URL(origin);
      const hostname = url.hostname;
      for (const domain of HEADY_DOMAINS) {
        if (hostname === domain || hostname.endsWith(\`.\${domain}\`)) {
          return true;
        }
      }
    } catch (_) {
      return false;
    }

    return false;
  }

  handlePreflight(origin) {
    if (!this.isOriginAllowed(origin)) {
      this._recordViolation(origin, 'preflight-blocked');
      return { allowed: false, headers: {} };
    }

    const headers = {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Methods': this.allowedMethods.join(', '),
      'Access-Control-Allow-Headers': this.allowedHeaders.join(', '),
      'Access-Control-Max-Age': this.maxAge.toString(),
      'Access-Control-Allow-Credentials': this.credentials.toString(),
      'Vary': 'Origin',
    };

    this._audit('preflight-allowed', { origin });
    return { allowed: true, headers, status: 204 };
  }

  handleRequest(origin) {
    if (!this.isOriginAllowed(origin)) {
      this._recordViolation(origin, 'request-blocked');
      return { allowed: false, headers: {} };
    }

    const headers = {
      'Access-Control-Allow-Origin': origin,
      'Access-Control-Allow-Credentials': this.credentials.toString(),
      'Access-Control-Expose-Headers': this.exposedHeaders.join(', '),
      'Vary': 'Origin',
    };

    return { allowed: true, headers };
  }

  middleware() {
    return (req, res, next) => {
      const origin = req.headers?.origin ?? req.headers?.Origin;

      if (req.method === 'OPTIONS') {
        const preflight = this.handlePreflight(origin);
        if (!preflight.allowed) {
          res.writeHead(403, { 'Content-Type': 'text/plain' });
          res.end('CORS: Origin not allowed');
          return;
        }
        for (const [key, value] of Object.entries(preflight.headers)) {
          res.setHeader(key, value);
        }
        res.writeHead(204);
        res.end();
        return;
      }

      const result = this.handleRequest(origin);
      if (!result.allowed && origin) {
        res.writeHead(403, { 'Content-Type': 'text/plain' });
        res.end('CORS: Origin not allowed');
        return;
      }

      for (const [key, value] of Object.entries(result.headers)) {
        res.setHeader(key, value);
      }

      next?.();
    };
  }

  _recordViolation(origin, type) {
    const entry = { ts: Date.now(), origin: origin ?? 'null', type };
    this.violations.push(entry);
    if (this.violations.length > this.maxViolations) {
      this.violations = this.violations.slice(-FIB[14]);
    }

    const key = origin ?? 'null';
    const count = (this.violationCounts.get(key) ?? 0) + 1;
    this.violationCounts.set(key, count);

    this._audit('cors-violation', { origin, type, violationCount: count });
  }

  addOrigin(origin) {
    this.customOrigins.add(origin);
    this._audit('add-origin', { origin });
  }

  removeOrigin(origin) {
    this.customOrigins.delete(origin);
    this._audit('remove-origin', { origin });
  }

  health() {
    return {
      allowedOriginsCount: this.allowedOrigins.size + this.customOrigins.size,
      violationCount: this.violations.length,
      topViolators: [...this.violationCounts.entries()]
        .sort((a, b) => b[1] - a[1])
        .slice(0, FIB[5]),
      auditLogSize: this.auditLog.length,
    };
  }
}

export default CorsStrict;
export { CorsStrict, HEADY_DOMAINS, buildAllowedOrigins };
`);

// ═══════════════════════════════════════════════════════════════════
// scaling/event-bus-nats.js — NATS Event Bus Client
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/scaling/event-bus-nats.js`, `
/**
 * EventBusNATS — NATS JetStream Event Bus Client
 * Provides pub/sub, request/reply, streaming, and durable consumers
 * for Heady's distributed event architecture.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

function phiBackoff(attempt, baseMs = 1000, maxMs = 60000) {
  const delay = baseMs * Math.pow(PHI, attempt);
  const jitter = (Math.random() - PSI) * PSI2 * delay;
  return Math.min(maxMs, delay + jitter);
}

// ── Event Schemas ────────────────────────────────────────────────
const EVENT_SUBJECTS = {
  'heady.agent.spawned':       { retention: 'limits', maxAge: FIB[11] * 3600, maxMsgs: FIB[16] },
  'heady.agent.completed':     { retention: 'limits', maxAge: FIB[11] * 3600, maxMsgs: FIB[16] },
  'heady.agent.failed':        { retention: 'limits', maxAge: FIB[13] * 3600, maxMsgs: FIB[16] },
  'heady.memory.stored':       { retention: 'limits', maxAge: FIB[12] * 3600, maxMsgs: FIB[16] },
  'heady.memory.evicted':      { retention: 'limits', maxAge: FIB[11] * 3600, maxMsgs: FIB[14] },
  'heady.security.alert':      { retention: 'limits', maxAge: FIB[14] * 3600, maxMsgs: FIB[16] },
  'heady.security.violation':  { retention: 'limits', maxAge: FIB[14] * 3600, maxMsgs: FIB[16] },
  'heady.health.heartbeat':    { retention: 'limits', maxAge: FIB[9] * 3600, maxMsgs: FIB[14] },
  'heady.health.drift':        { retention: 'limits', maxAge: FIB[12] * 3600, maxMsgs: FIB[16] },
  'heady.deploy.started':      { retention: 'limits', maxAge: FIB[11] * 3600, maxMsgs: FIB[14] },
  'heady.deploy.completed':    { retention: 'limits', maxAge: FIB[11] * 3600, maxMsgs: FIB[14] },
  'heady.billing.event':       { retention: 'limits', maxAge: FIB[14] * 3600, maxMsgs: FIB[16] },
  'heady.analytics.event':     { retention: 'limits', maxAge: FIB[12] * 3600, maxMsgs: FIB[16] },
};

// ── In-Memory Message Store (NATS-compatible interface) ──────────
class MessageStore {
  constructor(config = {}) {
    this.maxMsgs = config.maxMsgs ?? FIB[16];
    this.maxAge = config.maxAge ?? FIB[12] * 3600 * 1000;
    this.messages = [];
    this.sequence = 0;
  }

  publish(subject, data) {
    this.sequence++;
    const msg = {
      sequence: this.sequence,
      subject,
      data,
      timestamp: Date.now(),
      hash: hashSHA256({ sequence: this.sequence, subject, data }),
    };
    this.messages.push(msg);

    // Enforce limits
    while (this.messages.length > this.maxMsgs) {
      this.messages.shift();
    }
    const cutoff = Date.now() - this.maxAge;
    while (this.messages.length > 0 && this.messages[0].timestamp < cutoff) {
      this.messages.shift();
    }

    return msg;
  }

  getFromSequence(startSeq, limit = FIB[8]) {
    return this.messages
      .filter(m => m.sequence >= startSeq)
      .slice(0, limit);
  }

  stats() {
    return { messageCount: this.messages.length, sequence: this.sequence, maxMsgs: this.maxMsgs };
  }
}

// ── Consumer ─────────────────────────────────────────────────────
class Consumer {
  constructor(name, subjects, config = {}) {
    this.name = name;
    this.subjects = subjects;
    this.durable = config.durable ?? true;
    this.ackPolicy = config.ackPolicy ?? 'explicit';
    this.maxDeliver = config.maxDeliver ?? FIB[5]; // 5 retries
    this.ackWaitMs = config.ackWaitMs ?? FIB[9] * 1000; // 34s
    this.lastSequence = 0;
    this.pendingAcks = new Map();
    this.handlers = new Map();
    this.deliveryCount = 0;
    this.ackCount = 0;
    this.nakCount = 0;
  }

  subscribe(subject, handler) {
    this.handlers.set(subject, handler);
  }

  async deliver(msg) {
    const handler = this.handlers.get(msg.subject);
    if (!handler) return { delivered: false, reason: 'no-handler' };

    this.deliveryCount++;
    const ackId = \`\${this.name}-\${msg.sequence}\`;
    this.pendingAcks.set(ackId, { msg, deliveredAt: Date.now(), attempts: 1 });

    try {
      await handler(msg);
      this.ack(ackId);
      return { delivered: true, ackId };
    } catch (err) {
      this.nak(ackId);
      return { delivered: false, error: err.message, ackId };
    }
  }

  ack(ackId) {
    this.pendingAcks.delete(ackId);
    this.ackCount++;
  }

  nak(ackId) {
    const pending = this.pendingAcks.get(ackId);
    if (pending && pending.attempts < this.maxDeliver) {
      pending.attempts++;
    } else {
      this.pendingAcks.delete(ackId);
    }
    this.nakCount++;
  }

  stats() {
    return {
      name: this.name,
      durable: this.durable,
      subjects: this.subjects,
      lastSequence: this.lastSequence,
      pendingAcks: this.pendingAcks.size,
      deliveryCount: this.deliveryCount,
      ackCount: this.ackCount,
      nakCount: this.nakCount,
    };
  }
}

// ── Event Bus ────────────────────────────────────────────────────
class EventBusNATS {
  constructor(config = {}) {
    this.url = config.url ?? 'nats://localhost:4222';
    this.streams = new Map();
    this.consumers = new Map();
    this.subscriptions = new Map();
    this.connected = false;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = FIB[8]; // 21
    this.totalPublished = 0;
    this.totalConsumed = 0;
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];

    // Initialize default streams
    this._initStreams();
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  _initStreams() {
    for (const [subject, config] of Object.entries(EVENT_SUBJECTS)) {
      const streamName = subject.replace(/\\./g, '-');
      this.streams.set(streamName, new MessageStore(config));
    }
  }

  async connect() {
    // In production, connect to NATS server
    this.connected = true;
    this.reconnectAttempts = 0;
    this._audit('connected', { url: this.url });
    return { connected: true, url: this.url };
  }

  async disconnect() {
    this.connected = false;
    this._audit('disconnected', {});
    return { connected: false };
  }

  async publish(subject, data) {
    const streamName = subject.replace(/\\./g, '-');
    let store = this.streams.get(streamName);
    if (!store) {
      store = new MessageStore();
      this.streams.set(streamName, store);
    }

    const msg = store.publish(subject, data);
    this.totalPublished++;

    // Deliver to subscribers
    for (const consumer of this.consumers.values()) {
      if (consumer.subjects.includes(subject) || consumer.subjects.some(s => subject.startsWith(s.replace('.*', '')))) {
        await consumer.deliver(msg);
        this.totalConsumed++;
      }
    }

    this._audit('publish', { subject, sequence: msg.sequence });
    return msg;
  }

  createConsumer(name, subjects, config = {}) {
    const consumer = new Consumer(name, subjects, config);
    this.consumers.set(name, consumer);
    this._audit('create-consumer', { name, subjects });
    return consumer;
  }

  subscribe(consumerName, subject, handler) {
    const consumer = this.consumers.get(consumerName);
    if (!consumer) return { error: \`Consumer not found: \${consumerName}\` };
    consumer.subscribe(subject, handler);
    this._audit('subscribe', { consumer: consumerName, subject });
    return { subscribed: true, consumer: consumerName, subject };
  }

  async request(subject, data, timeoutMs = FIB[9] * 1000) {
    const msg = await this.publish(subject, data);
    // Request/reply pattern — in production, NATS handles this natively
    return { request: msg, timeout: timeoutMs };
  }

  health() {
    const streamStats = {};
    for (const [name, store] of this.streams) {
      streamStats[name] = store.stats();
    }
    const consumerStats = {};
    for (const [name, consumer] of this.consumers) {
      consumerStats[name] = consumer.stats();
    }
    return {
      connected: this.connected,
      url: this.url,
      totalPublished: this.totalPublished,
      totalConsumed: this.totalConsumed,
      streams: streamStats,
      consumers: consumerStats,
      auditLogSize: this.auditLog.length,
    };
  }
}

export default EventBusNATS;
export { EventBusNATS, Consumer, MessageStore, EVENT_SUBJECTS };
`);

// ═══════════════════════════════════════════════════════════════════
// scaling/pgbouncer-pool.js — PgBouncer Connection Pool Manager
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/scaling/pgbouncer-pool.js`, `
/**
 * PgBouncerPool — PostgreSQL Connection Pool Manager
 * Manages connection pooling via PgBouncer with φ-scaled pool sizes,
 * health monitoring, query routing, and automatic failover.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

function phiBackoff(attempt, baseMs = 1000, maxMs = 60000) {
  const delay = baseMs * Math.pow(PHI, attempt);
  const jitter = (Math.random() - PSI) * PSI2 * delay;
  return Math.min(maxMs, delay + jitter);
}

// ── Connection Pool Tiers ────────────────────────────────────────
const POOL_TIERS = {
  primary: {
    mode: 'transaction',
    maxConnections: FIB[10],    // 55
    minConnections: FIB[5],     // 5
    reservePool: FIB[4],        // 3
    idleTimeout: FIB[10] * 1000,// 55s
    queryTimeout: FIB[9] * 1000,// 34s
    role: 'read-write',
  },
  replica: {
    mode: 'transaction',
    maxConnections: FIB[11],    // 89
    minConnections: FIB[6],     // 8
    reservePool: FIB[5],        // 5
    idleTimeout: FIB[11] * 1000,// 89s
    queryTimeout: FIB[10] * 1000,// 55s
    role: 'read-only',
  },
  analytics: {
    mode: 'session',
    maxConnections: FIB[8],     // 21
    minConnections: FIB[3],     // 2
    reservePool: FIB[3],        // 2
    idleTimeout: FIB[12] * 1000,// 144s
    queryTimeout: FIB[12] * 1000,// 144s
    role: 'read-only',
  },
};

// ── Connection ───────────────────────────────────────────────────
class PooledConnection {
  constructor(id, tier, config) {
    this.id = id;
    this.tier = tier;
    this.state = 'idle'; // idle | active | draining | closed
    this.createdAt = Date.now();
    this.lastUsedAt = Date.now();
    this.queryCount = 0;
    this.errorCount = 0;
    this.totalLatencyMs = 0;
    this.host = config.host ?? 'localhost';
    this.port = config.port ?? 6432; // PgBouncer default
    this.database = config.database ?? 'heady';
  }

  acquire() {
    this.state = 'active';
    this.lastUsedAt = Date.now();
    return this;
  }

  release() {
    this.state = 'idle';
    this.lastUsedAt = Date.now();
  }

  recordQuery(latencyMs, success) {
    this.queryCount++;
    this.totalLatencyMs += latencyMs;
    if (!success) this.errorCount++;
  }

  isStale(idleTimeout) {
    return this.state === 'idle' && (Date.now() - this.lastUsedAt) > idleTimeout;
  }

  close() {
    this.state = 'closed';
  }

  stats() {
    return {
      id: this.id,
      tier: this.tier,
      state: this.state,
      queryCount: this.queryCount,
      errorCount: this.errorCount,
      avgLatencyMs: this.queryCount > 0 ? this.totalLatencyMs / this.queryCount : 0,
      uptimeMs: Date.now() - this.createdAt,
      idleMs: Date.now() - this.lastUsedAt,
    };
  }
}

// ── Connection Pool ──────────────────────────────────────────────
class ConnectionPool {
  constructor(tier, config) {
    this.tier = tier;
    this.config = { ...POOL_TIERS[tier], ...config };
    this.connections = new Map();
    this.nextId = 1;
    this.waitQueue = [];
    this.totalAcquired = 0;
    this.totalReleased = 0;
    this.totalTimeouts = 0;
  }

  _createConnection() {
    const id = \`conn-\${this.tier}-\${this.nextId++}\`;
    const conn = new PooledConnection(id, this.tier, this.config);
    this.connections.set(id, conn);
    return conn;
  }

  acquire() {
    // Find idle connection
    for (const conn of this.connections.values()) {
      if (conn.state === 'idle') {
        this.totalAcquired++;
        return conn.acquire();
      }
    }

    // Create new if under max
    if (this.connections.size < this.config.maxConnections) {
      const conn = this._createConnection();
      this.totalAcquired++;
      return conn.acquire();
    }

    // Check reserve pool
    const activeCount = [...this.connections.values()].filter(c => c.state === 'active').length;
    const reserveAvailable = this.config.maxConnections + this.config.reservePool - activeCount;
    if (reserveAvailable > 0 && this.connections.size < this.config.maxConnections + this.config.reservePool) {
      const conn = this._createConnection();
      this.totalAcquired++;
      return conn.acquire();
    }

    this.totalTimeouts++;
    return null; // Pool exhausted
  }

  release(connId) {
    const conn = this.connections.get(connId);
    if (conn) {
      conn.release();
      this.totalReleased++;

      // Serve waiting requests
      if (this.waitQueue.length > 0) {
        const waiter = this.waitQueue.shift();
        const acquired = conn.acquire();
        waiter.resolve(acquired);
      }
    }
  }

  reapStale() {
    const reaped = [];
    for (const [id, conn] of this.connections) {
      if (conn.isStale(this.config.idleTimeout) && this.connections.size > this.config.minConnections) {
        conn.close();
        this.connections.delete(id);
        reaped.push(id);
      }
    }
    return reaped;
  }

  drain() {
    for (const conn of this.connections.values()) {
      if (conn.state === 'idle') {
        conn.close();
      } else {
        conn.state = 'draining';
      }
    }
  }

  stats() {
    const states = { idle: 0, active: 0, draining: 0, closed: 0 };
    for (const conn of this.connections.values()) {
      states[conn.state] = (states[conn.state] ?? 0) + 1;
    }
    return {
      tier: this.tier,
      role: this.config.role,
      mode: this.config.mode,
      totalConnections: this.connections.size,
      maxConnections: this.config.maxConnections,
      states,
      totalAcquired: this.totalAcquired,
      totalReleased: this.totalReleased,
      totalTimeouts: this.totalTimeouts,
      waitQueueSize: this.waitQueue.length,
    };
  }
}

// ── PgBouncer Pool Manager ───────────────────────────────────────
class PgBouncerPool {
  constructor(config = {}) {
    this.pools = new Map();
    this.pools.set('primary', new ConnectionPool('primary', config.primary));
    this.pools.set('replica', new ConnectionPool('replica', config.replica));
    this.pools.set('analytics', new ConnectionPool('analytics', config.analytics));
    this.queryRouter = new QueryRouter();
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
    this.healthCheckIntervalMs = config.healthCheckIntervalMs ?? FIB[9] * 1000; // 34s
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  acquire(queryType = 'read') {
    const tier = this.queryRouter.route(queryType);
    const pool = this.pools.get(tier);
    if (!pool) return { error: \`Unknown pool tier: \${tier}\` };

    const conn = pool.acquire();
    if (!conn) {
      this._audit('pool-exhausted', { tier, queryType });
      // Fallback to primary if replica exhausted
      if (tier !== 'primary') {
        const fallback = this.pools.get('primary').acquire();
        if (fallback) {
          this._audit('fallback-primary', { originalTier: tier });
          return fallback;
        }
      }
      return { error: \`Pool \${tier} exhausted\` };
    }

    this._audit('acquire', { tier, connId: conn.id });
    return conn;
  }

  release(connId) {
    for (const pool of this.pools.values()) {
      if (pool.connections.has(connId)) {
        pool.release(connId);
        return true;
      }
    }
    return false;
  }

  reapAll() {
    const results = {};
    for (const [tier, pool] of this.pools) {
      results[tier] = pool.reapStale();
    }
    this._audit('reap', results);
    return results;
  }

  health() {
    const poolStats = {};
    for (const [tier, pool] of this.pools) {
      poolStats[tier] = pool.stats();
    }
    return {
      pools: poolStats,
      auditLogSize: this.auditLog.length,
    };
  }
}

// ── Query Router ─────────────────────────────────────────────────
class QueryRouter {
  route(queryType) {
    const routing = {
      'write': 'primary',
      'read': 'replica',
      'read-write': 'primary',
      'analytics': 'analytics',
      'batch': 'analytics',
      'migration': 'primary',
      'vector-search': 'replica',
    };
    return routing[queryType] ?? 'primary';
  }
}

export default PgBouncerPool;
export { PgBouncerPool, ConnectionPool, PooledConnection, QueryRouter, POOL_TIERS };
`);

// ═══════════════════════════════════════════════════════════════════
// scaling/hnsw-tuner.js — HNSW Index Auto-Tuner
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/scaling/hnsw-tuner.js`, `
/**
 * HNSWTuner — pgvector HNSW Index Auto-Tuner
 * Dynamically adjusts HNSW parameters (m, efConstruction, efSearch)
 * based on workload analysis, recall measurements, and latency targets.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── HNSW Parameter Profiles ──────────────────────────────────────
const PROFILES = {
  'low-latency': {
    m: FIB[8],                 // 21
    efConstruction: FIB[11],   // 89
    efSearch: FIB[10],         // 55
    description: 'Optimized for fast queries at cost of recall',
    targetLatencyMs: FIB[5],   // 5ms
    targetRecall: CSL_THRESHOLDS.MEDIUM, // ≈0.809
  },
  'balanced': {
    m: FIB[8],                 // 21
    efConstruction: FIB[12],   // 144
    efSearch: FIB[11],         // 89
    description: 'Balance between latency and recall',
    targetLatencyMs: FIB[8],   // 21ms
    targetRecall: CSL_THRESHOLDS.HIGH,   // ≈0.882
  },
  'high-recall': {
    m: FIB[9],                 // 34
    efConstruction: FIB[13],   // 233
    efSearch: FIB[12],         // 144
    description: 'Maximum recall for critical queries',
    targetLatencyMs: FIB[10],  // 55ms
    targetRecall: CSL_THRESHOLDS.CRITICAL, // ≈0.927
  },
  'bulk-ingestion': {
    m: FIB[7],                 // 13
    efConstruction: FIB[10],   // 55
    efSearch: FIB[9],          // 34
    description: 'Fast ingestion with acceptable recall',
    targetLatencyMs: FIB[6],   // 8ms
    targetRecall: CSL_THRESHOLDS.LOW,    // ≈0.691
  },
};

// ── Workload Analyzer ────────────────────────────────────────────
class WorkloadAnalyzer {
  constructor() {
    this.querySamples = [];
    this.maxSamples = FIB[16];     // 987
    this.windowMs = FIB[10] * 60 * 1000; // 55 minutes
  }

  recordQuery(sample) {
    this.querySamples.push({
      latencyMs: sample.latencyMs,
      recall: sample.recall ?? null,
      vectorCount: sample.vectorCount,
      k: sample.k,
      ts: Date.now(),
    });
    if (this.querySamples.length > this.maxSamples) {
      this.querySamples = this.querySamples.slice(-FIB[14]);
    }
  }

  analyze() {
    const now = Date.now();
    const recent = this.querySamples.filter(s => now - s.ts < this.windowMs);

    if (recent.length < FIB[5]) {
      return { insufficient: true, sampleCount: recent.length };
    }

    const latencies = recent.map(s => s.latencyMs);
    const recalls = recent.filter(s => s.recall !== null).map(s => s.recall);
    const ks = recent.map(s => s.k);

    const avgLatency = latencies.reduce((a, b) => a + b, 0) / latencies.length;
    const p50Latency = this._percentile(latencies, PSI2); // ≈38th percentile
    const p95Latency = this._percentile(latencies, CSL_THRESHOLDS.CRITICAL);
    const p99Latency = this._percentile(latencies, 0.99);
    const avgRecall = recalls.length > 0 ? recalls.reduce((a, b) => a + b, 0) / recalls.length : null;
    const avgK = ks.reduce((a, b) => a + b, 0) / ks.length;

    const avgVectorCount = recent.reduce((a, s) => a + s.vectorCount, 0) / recent.length;

    return {
      insufficient: false,
      sampleCount: recent.length,
      latency: { avg: avgLatency, p50: p50Latency, p95: p95Latency, p99: p99Latency },
      recall: avgRecall,
      avgK,
      avgVectorCount,
      qps: recent.length / (this.windowMs / 1000),
    };
  }

  _percentile(arr, pct) {
    const sorted = [...arr].sort((a, b) => a - b);
    const idx = Math.ceil(sorted.length * pct) - 1;
    return sorted[Math.max(0, idx)];
  }
}

// ── HNSW Tuner ───────────────────────────────────────────────────
class HNSWTuner {
  constructor(config = {}) {
    this.workloadAnalyzer = new WorkloadAnalyzer();
    this.currentProfile = config.profile ?? 'balanced';
    this.currentParams = { ...PROFILES[this.currentProfile] };
    this.tuningHistory = [];
    this.maxHistory = FIB[16];
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
    this.autoTuneEnabled = config.autoTune ?? true;
    this.tuneIntervalMs = config.tuneIntervalMs ?? FIB[10] * 60 * 1000; // 55 min
    this.lastTuneAt = 0;
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  recordQuery(sample) {
    this.workloadAnalyzer.recordQuery(sample);

    // Auto-tune check
    if (this.autoTuneEnabled && Date.now() - this.lastTuneAt > this.tuneIntervalMs) {
      return this.autoTune();
    }
    return null;
  }

  autoTune() {
    const analysis = this.workloadAnalyzer.analyze();
    if (analysis.insufficient) return { tuned: false, reason: 'insufficient-data' };

    this.lastTuneAt = Date.now();
    const recommendation = this._recommend(analysis);

    if (recommendation.profileChange) {
      const oldProfile = this.currentProfile;
      this.currentProfile = recommendation.newProfile;
      this.currentParams = { ...PROFILES[this.currentProfile] };

      this.tuningHistory.push({
        ts: Date.now(),
        from: oldProfile,
        to: this.currentProfile,
        analysis,
        reason: recommendation.reason,
      });
      if (this.tuningHistory.length > this.maxHistory) {
        this.tuningHistory = this.tuningHistory.slice(-FIB[14]);
      }

      this._audit('auto-tune', { from: oldProfile, to: this.currentProfile, reason: recommendation.reason });
      return { tuned: true, ...recommendation };
    }

    // Fine-tune within profile
    if (recommendation.paramAdjust) {
      Object.assign(this.currentParams, recommendation.params);
      this._audit('fine-tune', recommendation.params);
      return { tuned: true, finetuned: true, params: this.currentParams };
    }

    return { tuned: false, reason: 'no-change-needed' };
  }

  _recommend(analysis) {
    const lat = analysis.latency;
    const recall = analysis.recall;
    const vectorCount = analysis.avgVectorCount;

    // High latency, need to optimize for speed
    if (lat.p95 > FIB[10] && recall > CSL_THRESHOLDS.HIGH) {
      return { profileChange: true, newProfile: 'low-latency', reason: 'p95-latency-high' };
    }

    // Low recall, need more accuracy
    if (recall !== null && recall < CSL_THRESHOLDS.LOW) {
      return { profileChange: true, newProfile: 'high-recall', reason: 'recall-below-low' };
    }

    // Large dataset, consider adjusting m
    if (vectorCount > FIB[16] * FIB[8]) {
      const newM = Math.min(FIB[9], this.currentParams.m + FIB[3]);
      if (newM !== this.currentParams.m) {
        return { paramAdjust: true, params: { m: newM }, reason: 'large-dataset-m-increase' };
      }
    }

    // Adjust efSearch based on latency/recall balance
    if (lat.avg < this.currentParams.targetLatencyMs * PSI && (recall === null || recall < this.currentParams.targetRecall)) {
      const newEfSearch = Math.min(FIB[13], this.currentParams.efSearch + FIB[6]);
      return { paramAdjust: true, params: { efSearch: newEfSearch }, reason: 'headroom-increase-ef' };
    }

    return { profileChange: false, paramAdjust: false };
  }

  setProfile(profileName) {
    const profile = PROFILES[profileName];
    if (!profile) return { error: \`Unknown profile: \${profileName}\` };
    this.currentProfile = profileName;
    this.currentParams = { ...profile };
    this._audit('set-profile', { profile: profileName });
    return { profile: profileName, params: this.currentParams };
  }

  generateSQL() {
    const params = this.currentParams;
    return {
      createIndex: \`CREATE INDEX CONCURRENTLY IF NOT EXISTS idx_heady_vectors_hnsw
  ON heady_vectors USING hnsw (embedding vector_cosine_ops)
  WITH (m = \${params.m}, ef_construction = \${params.efConstruction});\`,
      setSearchParam: \`SET hnsw.ef_search = \${params.efSearch};\`,
      profile: this.currentProfile,
      params,
    };
  }

  health() {
    return {
      currentProfile: this.currentProfile,
      currentParams: this.currentParams,
      autoTuneEnabled: this.autoTuneEnabled,
      lastTuneAt: this.lastTuneAt,
      tuningHistorySize: this.tuningHistory.length,
      workloadSamples: this.workloadAnalyzer.querySamples.length,
      auditLogSize: this.auditLog.length,
    };
  }
}

export default HNSWTuner;
export { HNSWTuner, WorkloadAnalyzer, PROFILES };
`);

// ═══════════════════════════════════════════════════════════════════
// scaling/cloud-run-optimizer.js — Cloud Run Auto-Optimization
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/scaling/cloud-run-optimizer.js`, `
/**
 * CloudRunOptimizer — Cloud Run Service Auto-Optimization
 * Analyzes Cloud Run metrics and recommends/applies optimizations for
 * concurrency, CPU/memory, min/max instances, cold start mitigation.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Service Profiles ─────────────────────────────────────────────
const SERVICE_PROFILES = {
  'inference': {
    cpu: '2',
    memory: '2Gi',
    concurrency: FIB[8],          // 21
    minInstances: FIB[3],         // 2
    maxInstances: FIB[8],         // 21
    timeoutSeconds: FIB[10],      // 55
    cpuThrottle: false,
    startupCpuBoost: true,
  },
  'api': {
    cpu: '1',
    memory: '512Mi',
    concurrency: FIB[11],         // 89
    minInstances: FIB[3],         // 2
    maxInstances: FIB[9],         // 34
    timeoutSeconds: FIB[9],       // 34
    cpuThrottle: true,
    startupCpuBoost: true,
  },
  'worker': {
    cpu: '1',
    memory: '1Gi',
    concurrency: FIB[6],          // 8
    minInstances: FIB[1],         // 1
    maxInstances: FIB[7],         // 13
    timeoutSeconds: FIB[12],      // 144
    cpuThrottle: true,
    startupCpuBoost: false,
  },
  'web': {
    cpu: '1',
    memory: '256Mi',
    concurrency: FIB[12],         // 144
    minInstances: FIB[3],         // 2
    maxInstances: FIB[10],        // 55
    timeoutSeconds: FIB[9],       // 34
    cpuThrottle: true,
    startupCpuBoost: true,
  },
  'batch': {
    cpu: '4',
    memory: '4Gi',
    concurrency: FIB[4],          // 3
    minInstances: 0,
    maxInstances: FIB[5],         // 5
    timeoutSeconds: FIB[14],      // 377
    cpuThrottle: false,
    startupCpuBoost: false,
  },
};

// ── Metrics Collector ────────────────────────────────────────────
class MetricsWindow {
  constructor(windowMs = FIB[10] * 60 * 1000) { // 55 min window
    this.samples = [];
    this.windowMs = windowMs;
    this.maxSamples = FIB[16]; // 987
  }

  record(sample) {
    this.samples.push({ ...sample, ts: Date.now() });
    if (this.samples.length > this.maxSamples) {
      this.samples = this.samples.slice(-FIB[14]);
    }
  }

  getRecent() {
    const cutoff = Date.now() - this.windowMs;
    return this.samples.filter(s => s.ts > cutoff);
  }

  aggregate() {
    const recent = this.getRecent();
    if (recent.length === 0) return null;

    const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length;
    const max = (arr) => Math.max(...arr);
    const p95 = (arr) => {
      const sorted = [...arr].sort((a, b) => a - b);
      return sorted[Math.ceil(sorted.length * CSL_THRESHOLDS.CRITICAL) - 1];
    };

    return {
      cpuUtilization: { avg: avg(recent.map(s => s.cpu ?? 0)), max: max(recent.map(s => s.cpu ?? 0)) },
      memoryUtilization: { avg: avg(recent.map(s => s.memory ?? 0)), max: max(recent.map(s => s.memory ?? 0)) },
      requestLatency: { avg: avg(recent.map(s => s.latencyMs ?? 0)), p95: p95(recent.map(s => s.latencyMs ?? 0)) },
      instanceCount: { avg: avg(recent.map(s => s.instances ?? 1)), max: max(recent.map(s => s.instances ?? 1)) },
      concurrentRequests: { avg: avg(recent.map(s => s.concurrent ?? 0)), max: max(recent.map(s => s.concurrent ?? 0)) },
      coldStarts: recent.filter(s => s.coldStart).length,
      errorRate: recent.filter(s => s.error).length / recent.length,
      sampleCount: recent.length,
    };
  }
}

// ── Cloud Run Optimizer ──────────────────────────────────────────
class CloudRunOptimizer {
  constructor(config = {}) {
    this.projectId = config.projectId ?? 'gen-lang-client-0920560496';
    this.region = config.region ?? 'us-east1';
    this.services = new Map();
    this.metricsWindows = new Map();
    this.recommendations = [];
    this.maxRecommendations = FIB[16];
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  registerService(name, profile, currentConfig = {}) {
    const baseProfile = SERVICE_PROFILES[profile] ?? SERVICE_PROFILES['api'];
    this.services.set(name, { profile, config: { ...baseProfile, ...currentConfig } });
    this.metricsWindows.set(name, new MetricsWindow());
    this._audit('register-service', { name, profile });
    return { name, profile, config: this.services.get(name).config };
  }

  recordMetrics(serviceName, sample) {
    const window = this.metricsWindows.get(serviceName);
    if (!window) return { error: \`Service not registered: \${serviceName}\` };
    window.record(sample);
  }

  analyze(serviceName) {
    const service = this.services.get(serviceName);
    const window = this.metricsWindows.get(serviceName);
    if (!service || !window) return { error: \`Service not found: \${serviceName}\` };

    const metrics = window.aggregate();
    if (!metrics) return { serviceName, recommendations: [], reason: 'insufficient-data' };

    const recs = [];
    const config = service.config;

    // Concurrency optimization
    if (metrics.concurrentRequests.max > config.concurrency * CSL_THRESHOLDS.HIGH) {
      const newConcurrency = Math.ceil(metrics.concurrentRequests.max / PSI);
      recs.push({
        type: 'concurrency',
        current: config.concurrency,
        recommended: Math.min(newConcurrency, FIB[12]),
        reason: 'concurrent-requests-near-limit',
        impact: 'high',
      });
    } else if (metrics.concurrentRequests.avg < config.concurrency * PSI2) {
      const newConcurrency = Math.max(FIB[3], Math.ceil(metrics.concurrentRequests.avg * PHI));
      recs.push({
        type: 'concurrency',
        current: config.concurrency,
        recommended: newConcurrency,
        reason: 'concurrent-requests-underutilized',
        impact: 'medium',
      });
    }

    // Memory optimization
    if (metrics.memoryUtilization.max > CSL_THRESHOLDS.HIGH) {
      recs.push({
        type: 'memory',
        current: config.memory,
        recommended: this._nextMemoryTier(config.memory),
        reason: 'memory-utilization-high',
        impact: 'high',
      });
    }

    // Cold start mitigation
    if (metrics.coldStarts > FIB[4] && config.minInstances === 0) {
      recs.push({
        type: 'min-instances',
        current: 0,
        recommended: FIB[3],
        reason: 'frequent-cold-starts',
        impact: 'high',
      });
    }

    // Scale-up trigger
    if (metrics.cpuUtilization.avg > CSL_THRESHOLDS.MEDIUM && metrics.instanceCount.max >= config.maxInstances * CSL_THRESHOLDS.HIGH) {
      const newMax = Math.ceil(config.maxInstances * PHI);
      recs.push({
        type: 'max-instances',
        current: config.maxInstances,
        recommended: newMax,
        reason: 'scaling-ceiling-reached',
        impact: 'medium',
      });
    }

    // Error rate check
    if (metrics.errorRate > PSI2) {
      recs.push({
        type: 'error-rate',
        current: metrics.errorRate,
        recommended: 'investigate',
        reason: 'error-rate-above-threshold',
        impact: 'critical',
      });
    }

    const recommendation = {
      serviceName,
      profile: service.profile,
      metrics,
      recommendations: recs,
      ts: Date.now(),
      hash: hashSHA256({ serviceName, recs, ts: Date.now() }),
    };

    this.recommendations.push(recommendation);
    if (this.recommendations.length > this.maxRecommendations) {
      this.recommendations = this.recommendations.slice(-FIB[14]);
    }

    this._audit('analyze', { serviceName, recommendationCount: recs.length });
    return recommendation;
  }

  _nextMemoryTier(current) {
    const tiers = ['128Mi', '256Mi', '512Mi', '1Gi', '2Gi', '4Gi', '8Gi'];
    const idx = tiers.indexOf(current);
    return idx >= 0 && idx < tiers.length - 1 ? tiers[idx + 1] : current;
  }

  generateYAML(serviceName) {
    const service = this.services.get(serviceName);
    if (!service) return { error: \`Service not found: \${serviceName}\` };

    const c = service.config;
    return \`apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: \${serviceName}
  annotations:
    run.googleapis.com/launch-stage: BETA
spec:
  template:
    metadata:
      annotations:
        autoscaling.knative.dev/minScale: "\${c.minInstances}"
        autoscaling.knative.dev/maxScale: "\${c.maxInstances}"
        run.googleapis.com/cpu-throttling: "\${c.cpuThrottle}"
        run.googleapis.com/startup-cpu-boost: "\${c.startupCpuBoost}"
    spec:
      containerConcurrency: \${c.concurrency}
      timeoutSeconds: \${c.timeoutSeconds}
      containers:
        - resources:
            limits:
              cpu: "\${c.cpu}"
              memory: "\${c.memory}"\`;
  }

  analyzeAll() {
    const results = {};
    for (const name of this.services.keys()) {
      results[name] = this.analyze(name);
    }
    return results;
  }

  health() {
    return {
      registeredServices: this.services.size,
      recommendationCount: this.recommendations.length,
      auditLogSize: this.auditLog.length,
      projectId: this.projectId,
      region: this.region,
    };
  }
}

export default CloudRunOptimizer;
export { CloudRunOptimizer, MetricsWindow, SERVICE_PROFILES };
`);

// ═══════════════════════════════════════════════════════════════════
// scaling/grpc-bridge.js — gRPC-to-REST Bridge
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/scaling/grpc-bridge.js`, `
/**
 * GrpcBridge — gRPC-to-REST Bidirectional Bridge
 * Translates between gRPC service definitions and REST/JSON,
 * with streaming support, deadline propagation, and error mapping.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

// ── φ-Math Foundation ────────────────────────────────────────────
const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── gRPC Status Code Mapping ─────────────────────────────────────
const GRPC_TO_HTTP = {
  0:  { http: 200, name: 'OK' },
  1:  { http: 499, name: 'CANCELLED' },
  2:  { http: 500, name: 'UNKNOWN' },
  3:  { http: 400, name: 'INVALID_ARGUMENT' },
  4:  { http: 504, name: 'DEADLINE_EXCEEDED' },
  5:  { http: 404, name: 'NOT_FOUND' },
  6:  { http: 409, name: 'ALREADY_EXISTS' },
  7:  { http: 403, name: 'PERMISSION_DENIED' },
  8:  { http: 429, name: 'RESOURCE_EXHAUSTED' },
  9:  { http: 400, name: 'FAILED_PRECONDITION' },
  10: { http: 409, name: 'ABORTED' },
  11: { http: 400, name: 'OUT_OF_RANGE' },
  12: { http: 501, name: 'UNIMPLEMENTED' },
  13: { http: 500, name: 'INTERNAL' },
  14: { http: 503, name: 'UNAVAILABLE' },
  15: { http: 500, name: 'DATA_LOSS' },
  16: { http: 401, name: 'UNAUTHENTICATED' },
};

const HTTP_TO_GRPC = {};
for (const [grpcCode, mapping] of Object.entries(GRPC_TO_HTTP)) {
  if (!HTTP_TO_GRPC[mapping.http]) HTTP_TO_GRPC[mapping.http] = parseInt(grpcCode);
}

// ── Service Registry ─────────────────────────────────────────────
class ServiceDefinition {
  constructor(name, config = {}) {
    this.name = name;
    this.methods = new Map();
    this.package = config.package ?? 'heady.services';
    this.version = config.version ?? '1.0.0';
  }

  addMethod(name, config) {
    this.methods.set(name, {
      name,
      inputType: config.inputType ?? 'object',
      outputType: config.outputType ?? 'object',
      httpMethod: config.httpMethod ?? 'POST',
      httpPath: config.httpPath ?? \`/api/v1/\${this.name}/\${name}\`,
      streaming: config.streaming ?? false,
      deadlineMs: config.deadlineMs ?? FIB[9] * 1000, // 34s
    });
    return this;
  }

  toProto() {
    const methods = [...this.methods.values()].map(m => {
      const streamPrefix = m.streaming ? 'stream ' : '';
      return \`  rpc \${m.name} (\${m.inputType}) returns (\${streamPrefix}\${m.outputType});\`;
    }).join('\\n');
    return \`service \${this.name} {\\n\${methods}\\n}\`;
  }
}

// ── Request/Response Transformer ─────────────────────────────────
class MessageTransformer {
  constructor() {
    this.transformers = new Map();
  }

  register(typeName, transform) {
    this.transformers.set(typeName, transform);
  }

  toGrpc(httpBody, typeName) {
    const transformer = this.transformers.get(typeName);
    if (transformer?.toGrpc) return transformer.toGrpc(httpBody);
    // Default: pass through with snake_case conversion
    return this._toSnakeCase(httpBody);
  }

  toHttp(grpcMessage, typeName) {
    const transformer = this.transformers.get(typeName);
    if (transformer?.toHttp) return transformer.toHttp(grpcMessage);
    // Default: pass through with camelCase conversion
    return this._toCamelCase(grpcMessage);
  }

  _toSnakeCase(obj) {
    if (typeof obj !== 'object' || obj === null) return obj;
    if (Array.isArray(obj)) return obj.map(v => this._toSnakeCase(v));
    const result = {};
    for (const [key, value] of Object.entries(obj)) {
      const snakeKey = key.replace(/[A-Z]/g, m => '_' + m.toLowerCase());
      result[snakeKey] = this._toSnakeCase(value);
    }
    return result;
  }

  _toCamelCase(obj) {
    if (typeof obj !== 'object' || obj === null) return obj;
    if (Array.isArray(obj)) return obj.map(v => this._toCamelCase(v));
    const result = {};
    for (const [key, value] of Object.entries(obj)) {
      const camelKey = key.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
      result[camelKey] = this._toCamelCase(value);
    }
    return result;
  }
}

// ── Deadline Propagator ──────────────────────────────────────────
class DeadlinePropagator {
  constructor() {
    this.defaultDeadlineMs = FIB[9] * 1000; // 34s
    this.maxDeadlineMs = FIB[13] * 1000;    // 233s
  }

  extract(headers) {
    const grpcTimeout = headers['grpc-timeout'];
    if (grpcTimeout) {
      return this._parseGrpcTimeout(grpcTimeout);
    }
    const httpDeadline = headers['x-deadline-ms'];
    if (httpDeadline) {
      return Math.min(parseInt(httpDeadline, 10), this.maxDeadlineMs);
    }
    return this.defaultDeadlineMs;
  }

  propagate(deadlineMs) {
    const remaining = Math.max(0, deadlineMs - FIB[3]); // subtract 2ms overhead
    return {
      'grpc-timeout': \`\${remaining}m\`,
      'x-deadline-ms': remaining.toString(),
    };
  }

  _parseGrpcTimeout(timeout) {
    const match = timeout.match(/^(\\d+)([HMSmun])$/);
    if (!match) return this.defaultDeadlineMs;
    const value = parseInt(match[1], 10);
    const unit = match[2];
    const multipliers = { H: 3600000, M: 60000, S: 1000, m: 1, u: 0.001, n: 0.000001 };
    return Math.min(value * (multipliers[unit] ?? 1), this.maxDeadlineMs);
  }
}

// ── gRPC Bridge ──────────────────────────────────────────────────
class GrpcBridge {
  constructor(config = {}) {
    this.services = new Map();
    this.transformer = new MessageTransformer();
    this.deadline = new DeadlinePropagator();
    this.handlers = new Map();
    this.totalRequests = 0;
    this.totalErrors = 0;
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
    this.interceptors = [];
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  registerService(name, config = {}) {
    const def = new ServiceDefinition(name, config);
    this.services.set(name, def);
    return def;
  }

  addInterceptor(interceptor) {
    this.interceptors.push(interceptor);
  }

  registerHandler(serviceName, methodName, handler) {
    const key = \`\${serviceName}/\${methodName}\`;
    this.handlers.set(key, handler);
    this._audit('register-handler', { service: serviceName, method: methodName });
  }

  async handleHttpToGrpc(req) {
    this.totalRequests++;
    const startTime = Date.now();

    // Route: find matching service/method by path
    let matchedService = null;
    let matchedMethod = null;
    for (const [svcName, svc] of this.services) {
      for (const [methName, meth] of svc.methods) {
        if (req.path === meth.httpPath && req.method === meth.httpMethod) {
          matchedService = svcName;
          matchedMethod = meth;
          break;
        }
      }
      if (matchedService) break;
    }

    if (!matchedService || !matchedMethod) {
      this.totalErrors++;
      return { grpcStatus: 12, httpStatus: 501, error: 'Method not found' };
    }

    // Extract deadline
    const deadlineMs = this.deadline.extract(req.headers ?? {});

    // Transform request
    const grpcRequest = this.transformer.toGrpc(req.body, matchedMethod.inputType);

    // Apply interceptors
    let context = { service: matchedService, method: matchedMethod.name, deadline: deadlineMs };
    for (const interceptor of this.interceptors) {
      const result = await interceptor(context, grpcRequest);
      if (result?.abort) {
        this.totalErrors++;
        return result;
      }
      context = { ...context, ...result };
    }

    // Execute handler
    const handlerKey = \`\${matchedService}/\${matchedMethod.name}\`;
    const handler = this.handlers.get(handlerKey);

    if (!handler) {
      this.totalErrors++;
      return { grpcStatus: 12, httpStatus: 501, error: 'Handler not implemented' };
    }

    try {
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Deadline exceeded')), deadlineMs)
      );

      const result = await Promise.race([handler(grpcRequest, context), timeoutPromise]);
      const httpResponse = this.transformer.toHttp(result, matchedMethod.outputType);

      this._audit('http-to-grpc', {
        service: matchedService,
        method: matchedMethod.name,
        latencyMs: Date.now() - startTime,
      });

      return {
        grpcStatus: 0,
        httpStatus: 200,
        body: httpResponse,
        latencyMs: Date.now() - startTime,
      };
    } catch (err) {
      this.totalErrors++;
      const grpcStatus = err.message === 'Deadline exceeded' ? 4 : 13;
      const httpMapping = GRPC_TO_HTTP[grpcStatus];

      return {
        grpcStatus,
        httpStatus: httpMapping.http,
        error: err.message,
        latencyMs: Date.now() - startTime,
      };
    }
  }

  generateRoutes() {
    const routes = [];
    for (const [svcName, svc] of this.services) {
      for (const [methName, meth] of svc.methods) {
        routes.push({
          service: svcName,
          method: methName,
          httpMethod: meth.httpMethod,
          httpPath: meth.httpPath,
          streaming: meth.streaming,
          deadlineMs: meth.deadlineMs,
        });
      }
    }
    return routes;
  }

  health() {
    return {
      registeredServices: this.services.size,
      registeredHandlers: this.handlers.size,
      totalRequests: this.totalRequests,
      totalErrors: this.totalErrors,
      errorRate: this.totalRequests > 0 ? this.totalErrors / this.totalRequests : 0,
      interceptorCount: this.interceptors.length,
      auditLogSize: this.auditLog.length,
    };
  }
}

export default GrpcBridge;
export { GrpcBridge, ServiceDefinition, MessageTransformer, DeadlinePropagator, GRPC_TO_HTTP };
`);

console.log('\\n✅ Security + Scaling modules generated successfully.');
