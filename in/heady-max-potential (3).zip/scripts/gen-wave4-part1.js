/**
 * Wave 4 Generator Part 1 — middleware/ (5) + scaling/ (3)
 * Author: Eric Haywood | φ-derived constants | ESM only | No stubs
 */
import { writeFileSync, mkdirSync } from 'fs';
import { dirname } from 'path';

function write(path, content) {
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, content.trimStart(), 'utf8');
  console.log(`  ✓ ${path} (${content.length} chars)`);
}

const BASE = '/home/user/workspace/heady-max-potential';

// ═══════════════════════════════════════════════════════════════════
// middleware/heady-auto-context.js — HeadyAutoContext Middleware
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/middleware/heady-auto-context.js`, `
/**
 * HeadyAutoContext — Mandatory Context Middleware
 * Attaches correlation ID, service domain, user context, timing,
 * and φ-scaled metadata to every request. Required on ALL endpoints.
 * Unbreakable Law #5: HeadyAutoContext mandatory.
 * All constants φ-derived. ESM only.
 * Author: Eric Haywood
 */
import { createHash, randomUUID } from 'crypto';

const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Service Domain Registry ──────────────────────────────────────
const SERVICE_DOMAINS = {
  inference: ['heady-brain', 'heady-brains', 'heady-infer', 'ai-router', 'model-gateway'],
  memory: ['heady-embed', 'heady-memory', 'heady-vector', 'heady-projection'],
  agents: ['heady-bee-factory', 'heady-hive', 'heady-federation'],
  orchestration: ['heady-soul', 'heady-conductor', 'heady-orchestration', 'auto-success-engine', 'hcfullpipeline-executor', 'heady-chain', 'prompt-manager'],
  security: ['heady-guard', 'heady-security', 'heady-governance', 'secret-gateway'],
  monitoring: ['heady-health', 'heady-eval', 'heady-maintenance', 'heady-testing'],
  web: ['heady-web', 'heady-buddy', 'heady-ui', 'heady-onboarding', 'heady-pilot-onboarding', 'heady-task-browser'],
  data: ['heady-cache'],
  integration: ['api-gateway', 'domain-router', 'mcp-server', 'google-mcp', 'memory-mcp', 'perplexity-mcp', 'jules-mcp', 'huggingface-gateway', 'colab-gateway', 'silicon-bridge', 'discord-bot'],
  specialized: ['heady-vinci', 'heady-autobiographer', 'heady-midi', 'budget-tracker', 'cli-service'],
};

function resolveDomain(serviceName) {
  for (const [domain, services] of Object.entries(SERVICE_DOMAINS)) {
    if (services.includes(serviceName)) return domain;
  }
  return 'unknown';
}

// ── Context Builder ──────────────────────────────────────────────
class HeadyAutoContext {
  constructor(config = {}) {
    this.serviceName = config.serviceName ?? 'unknown';
    this.serviceVersion = config.serviceVersion ?? '4.0.0';
    this.domain = config.domain ?? resolveDomain(this.serviceName);
    this.environment = config.environment ?? process.env.NODE_ENV ?? 'production';
    this.region = config.region ?? 'us-east1';
    this.instanceId = config.instanceId ?? randomUUID().slice(0, FIB[6]);
    this.requestCount = 0;
  }

  middleware() {
    const self = this;
    return (req, res, next) => {
      self.requestCount++;
      const startTime = process.hrtime.bigint();
      const correlationId = req.headers['x-correlation-id'] ?? req.headers['x-request-id'] ?? randomUUID();
      const parentSpanId = req.headers['x-parent-span-id'] ?? null;
      const spanId = randomUUID().slice(0, FIB[8]);

      // Build context object
      req.headyContext = {
        correlationId,
        spanId,
        parentSpanId,
        service: {
          name: self.serviceName,
          version: self.serviceVersion,
          domain: self.domain,
          instanceId: self.instanceId,
        },
        environment: self.environment,
        region: self.region,
        timing: { startTime, startMs: Date.now() },
        request: {
          method: req.method,
          path: req.url ?? req.path,
          userAgent: req.headers['user-agent'] ?? 'unknown',
          ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() ?? req.socket?.remoteAddress ?? 'unknown',
          contentType: req.headers['content-type'] ?? null,
        },
        user: {
          sessionId: null,
          userId: null,
          roles: [],
          tier: 'anonymous',
        },
        phi: {
          requestSequence: self.requestCount,
          fibonacciSlot: FIB[self.requestCount % FIB.length] ?? FIB[FIB.length - 1],
        },
      };

      // Extract user context from httpOnly session cookie
      const sessionCookie = self._extractSessionCookie(req);
      if (sessionCookie) {
        req.headyContext.user.sessionId = hashSHA256(sessionCookie).slice(0, FIB[8]);
        req.headyContext.user.tier = 'authenticated';
      }

      // Set response headers for correlation
      res.setHeader('X-Correlation-ID', correlationId);
      res.setHeader('X-Span-ID', spanId);
      res.setHeader('X-Service', self.serviceName);
      res.setHeader('X-Service-Domain', self.domain);

      // Timing hook on response finish
      const originalEnd = res.end.bind(res);
      res.end = function(...args) {
        const endTime = process.hrtime.bigint();
        const durationNs = Number(endTime - startTime);
        const durationMs = durationNs / 1_000_000;
        res.setHeader('X-Response-Time-Ms', durationMs.toFixed(3));
        res.setHeader('Server-Timing', \`total;dur=\${durationMs.toFixed(1)}\`);

        // Structured log entry
        const logEntry = {
          timestamp: new Date().toISOString(),
          level: res.statusCode >= 500 ? 'ERROR' : res.statusCode >= 400 ? 'WARN' : 'INFO',
          correlationId,
          spanId,
          service: self.serviceName,
          domain: self.domain,
          method: req.method,
          path: req.url,
          status: res.statusCode,
          durationMs: Math.round(durationMs * 1000) / 1000,
          userTier: req.headyContext.user.tier,
          hash: hashSHA256({ correlationId, status: res.statusCode, durationMs }),
        };

        // Write structured log to stdout (not console.log)
        process.stdout.write(JSON.stringify(logEntry) + '\\n');

        return originalEnd(...args);
      };

      next?.();
    };
  }

  _extractSessionCookie(req) {
    const cookies = req.headers?.cookie ?? '';
    const match = cookies.match(/__heady_session=([^;]+)/);
    return match ? match[1] : null;
  }

  contextForOutbound(req) {
    const ctx = req.headyContext;
    if (!ctx) return {};
    return {
      'X-Correlation-ID': ctx.correlationId,
      'X-Parent-Span-ID': ctx.spanId,
      'X-Source-Service': ctx.service.name,
      'X-Source-Domain': ctx.service.domain,
    };
  }

  health() {
    return {
      service: this.serviceName,
      domain: this.domain,
      version: this.serviceVersion,
      environment: this.environment,
      region: this.region,
      instanceId: this.instanceId,
      totalRequests: this.requestCount,
    };
  }
}

export default HeadyAutoContext;
export { HeadyAutoContext, SERVICE_DOMAINS, resolveDomain };
`);

// ═══════════════════════════════════════════════════════════════════
// middleware/rate-limiter.js — φ-Scaled Rate Limiter
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/middleware/rate-limiter.js`, `
/**
 * RateLimiter — φ-Scaled Sliding Window Rate Limiter
 * Enforces per-user, per-IP, per-API-key limits with Fibonacci-based tiers:
 *   Anonymous: 34 req/min, Authenticated: 89 req/min, Enterprise: 233 req/min
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Rate Limit Tiers (Fibonacci-based) ───────────────────────────
const RATE_TIERS = {
  anonymous:     { requestsPerMinute: FIB[9],  burstMultiplier: PHI, windowMs: 60000 },  // 34/min
  authenticated: { requestsPerMinute: FIB[11], burstMultiplier: PHI, windowMs: 60000 },  // 89/min
  enterprise:    { requestsPerMinute: FIB[13], burstMultiplier: PHI, windowMs: 60000 },  // 233/min
  internal:      { requestsPerMinute: FIB[16], burstMultiplier: PHI * PHI, windowMs: 60000 }, // 987/min
};

// ── Sliding Window Counter ───────────────────────────────────────
class SlidingWindow {
  constructor(windowMs, maxBuckets = FIB[10]) {
    this.windowMs = windowMs;
    this.bucketDurationMs = windowMs / maxBuckets;
    this.maxBuckets = maxBuckets;
    this.buckets = new Map();
  }

  record() {
    const now = Date.now();
    const bucketKey = Math.floor(now / this.bucketDurationMs);
    this.buckets.set(bucketKey, (this.buckets.get(bucketKey) ?? 0) + 1);
    this._prune(now);
  }

  count() {
    const now = Date.now();
    this._prune(now);
    let total = 0;
    const oldestBucket = Math.floor((now - this.windowMs) / this.bucketDurationMs);
    for (const [key, count] of this.buckets) {
      if (key >= oldestBucket) total += count;
    }
    return total;
  }

  _prune(now) {
    const oldestBucket = Math.floor((now - this.windowMs) / this.bucketDurationMs) - 1;
    for (const key of this.buckets.keys()) {
      if (key < oldestBucket) this.buckets.delete(key);
    }
  }
}

// ── Rate Limiter ─────────────────────────────────────────────────
class RateLimiter {
  constructor(config = {}) {
    this.windows = new Map();
    this.maxClients = config.maxClients ?? FIB[16] * FIB[5]; // 987 * 5 = 4935
    this.defaultTier = config.defaultTier ?? 'anonymous';
    this.blockedKeys = new Set();
    this.blockDurationMs = config.blockDurationMs ?? FIB[10] * 1000; // 55s
    this.violations = [];
    this.maxViolations = FIB[16];
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail, hash: hashSHA256({ action, detail, ts: Date.now() }) };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  _getWindow(key, tier) {
    if (!this.windows.has(key)) {
      const tierConfig = RATE_TIERS[tier] ?? RATE_TIERS[this.defaultTier];
      this.windows.set(key, { window: new SlidingWindow(tierConfig.windowMs), tier, createdAt: Date.now() });
      // Prune if too many clients tracked
      if (this.windows.size > this.maxClients) {
        const oldest = [...this.windows.entries()].sort((a, b) => a[1].createdAt - b[1].createdAt)[0];
        if (oldest) this.windows.delete(oldest[0]);
      }
    }
    return this.windows.get(key);
  }

  _resolveKey(req) {
    const ctx = req.headyContext;
    if (ctx?.user?.userId) return { key: \`user:\${ctx.user.userId}\`, tier: ctx.user.tier ?? 'authenticated' };
    const apiKey = req.headers['x-api-key'] ?? req.headers['authorization'];
    if (apiKey) return { key: \`apikey:\${hashSHA256(apiKey).slice(0, FIB[8])}\`, tier: 'enterprise' };
    const ip = ctx?.request?.ip ?? req.headers['x-forwarded-for']?.split(',')[0]?.trim() ?? req.socket?.remoteAddress ?? 'unknown';
    return { key: \`ip:\${ip}\`, tier: 'anonymous' };
  }

  check(key, tier) {
    if (this.blockedKeys.has(key)) {
      return { allowed: false, reason: 'blocked', remaining: 0, resetMs: this.blockDurationMs };
    }

    const tierConfig = RATE_TIERS[tier] ?? RATE_TIERS[this.defaultTier];
    const { window } = this._getWindow(key, tier);
    const currentCount = window.count();
    const limit = tierConfig.requestsPerMinute;
    const burstLimit = Math.ceil(limit * tierConfig.burstMultiplier);

    if (currentCount >= burstLimit) {
      this._recordViolation(key, tier, 'burst-exceeded');
      return { allowed: false, reason: 'burst-limit', remaining: 0, limit: burstLimit, resetMs: tierConfig.windowMs };
    }

    if (currentCount >= limit) {
      const severity = cslGate(1.0, currentCount / burstLimit, CSL_THRESHOLDS.HIGH);
      if (severity > CSL_THRESHOLDS.CRITICAL) {
        this._recordViolation(key, tier, 'rate-exceeded');
        return { allowed: false, reason: 'rate-limit', remaining: 0, limit, resetMs: tierConfig.windowMs };
      }
    }

    window.record();
    return {
      allowed: true,
      remaining: Math.max(0, limit - currentCount - 1),
      limit,
      resetMs: tierConfig.windowMs,
    };
  }

  _recordViolation(key, tier, type) {
    this.violations.push({ key, tier, type, ts: Date.now() });
    if (this.violations.length > this.maxViolations) {
      this.violations = this.violations.slice(-FIB[14]);
    }

    // Auto-block after repeated violations
    const recentViolations = this.violations.filter(v => v.key === key && Date.now() - v.ts < FIB[10] * 60 * 1000).length;
    if (recentViolations >= FIB[6]) {
      this.blockedKeys.add(key);
      setTimeout(() => this.blockedKeys.delete(key), this.blockDurationMs);
      this._audit('auto-block', { key, violations: recentViolations });
    }
  }

  middleware() {
    const self = this;
    return (req, res, next) => {
      const { key, tier } = self._resolveKey(req);
      const result = self.check(key, tier);

      res.setHeader('X-RateLimit-Limit', result.limit ?? 0);
      res.setHeader('X-RateLimit-Remaining', result.remaining);
      res.setHeader('X-RateLimit-Reset', Math.ceil(Date.now() / 1000 + (result.resetMs ?? 60000) / 1000));

      if (!result.allowed) {
        res.writeHead(429, { 'Content-Type': 'application/json', 'Retry-After': Math.ceil((result.resetMs ?? 60000) / 1000) });
        res.end(JSON.stringify({ error: 'Rate limit exceeded', code: 'HEADY-RATE-001', reason: result.reason, retryAfterMs: result.resetMs }));
        return;
      }

      next?.();
    };
  }

  health() {
    return {
      trackedClients: this.windows.size,
      blockedKeys: this.blockedKeys.size,
      violationCount: this.violations.length,
      tiers: Object.entries(RATE_TIERS).map(([k, v]) => ({ tier: k, limit: v.requestsPerMinute })),
    };
  }
}

export default RateLimiter;
export { RateLimiter, SlidingWindow, RATE_TIERS };
`);

// ═══════════════════════════════════════════════════════════════════
// middleware/bulkhead.js — Fibonacci-Sized Bulkhead Middleware
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/middleware/bulkhead.js`, `
/**
 * Bulkhead — Fibonacci-Sized Concurrency Isolation
 * Prevents cascading failures by limiting concurrent requests per service.
 * Fibonacci pools: 34 concurrent / 55 queued (from Envoy spec).
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

class Semaphore {
  constructor(permits) {
    this.permits = permits;
    this.queue = [];
    this.active = 0;
  }

  async acquire() {
    if (this.active < this.permits) {
      this.active++;
      return true;
    }
    return new Promise((resolve) => {
      this.queue.push(resolve);
    });
  }

  release() {
    this.active--;
    if (this.queue.length > 0) {
      this.active++;
      const next = this.queue.shift();
      next(true);
    }
  }

  stats() {
    return { active: this.active, permits: this.permits, queued: this.queue.length };
  }
}

// ── Bulkhead Pool Profiles ───────────────────────────────────────
const POOL_PROFILES = {
  'hot': { concurrent: FIB[9], queued: FIB[10], timeoutMs: FIB[9] * 1000 },      // 34 / 55 / 34s
  'warm': { concurrent: FIB[8], queued: FIB[9], timeoutMs: FIB[10] * 1000 },     // 21 / 34 / 55s
  'cold': { concurrent: FIB[7], queued: FIB[8], timeoutMs: FIB[12] * 1000 },     // 13 / 21 / 144s
  'critical': { concurrent: FIB[10], queued: FIB[11], timeoutMs: FIB[8] * 1000 }, // 55 / 89 / 21s
};

class Bulkhead {
  constructor(config = {}) {
    this.profile = config.profile ?? 'hot';
    const poolConfig = POOL_PROFILES[this.profile] ?? POOL_PROFILES['hot'];
    this.semaphore = new Semaphore(poolConfig.concurrent);
    this.maxQueued = poolConfig.queued;
    this.timeoutMs = poolConfig.timeoutMs;
    this.totalAccepted = 0;
    this.totalRejected = 0;
    this.totalTimedOut = 0;
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  middleware() {
    const self = this;
    return async (req, res, next) => {
      const stats = self.semaphore.stats();

      // Check if queue is full
      if (stats.queued >= self.maxQueued) {
        self.totalRejected++;
        self._audit('rejected', { queued: stats.queued, active: stats.active });
        res.writeHead(503, { 'Content-Type': 'application/json', 'Retry-After': Math.ceil(self.timeoutMs / 1000) });
        res.end(JSON.stringify({
          error: 'Service overloaded',
          code: 'HEADY-BULKHEAD-001',
          active: stats.active,
          queued: stats.queued,
          retryAfterMs: self.timeoutMs,
        }));
        return;
      }

      // Acquire with timeout
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Bulkhead timeout')), self.timeoutMs)
      );

      try {
        await Promise.race([self.semaphore.acquire(), timeoutPromise]);
        self.totalAccepted++;

        // Set pressure headers
        const pressure = stats.active / self.semaphore.permits;
        res.setHeader('X-Bulkhead-Pressure', pressure.toFixed(3));
        res.setHeader('X-Bulkhead-Profile', self.profile);

        // Release on response finish
        const originalEnd = res.end.bind(res);
        res.end = function(...args) {
          self.semaphore.release();
          return originalEnd(...args);
        };

        next?.();
      } catch (err) {
        self.totalTimedOut++;
        self._audit('timeout', { active: stats.active, queued: stats.queued });
        res.writeHead(504, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Bulkhead timeout', code: 'HEADY-BULKHEAD-002' }));
      }
    };
  }

  health() {
    const stats = this.semaphore.stats();
    return {
      profile: this.profile,
      ...stats,
      maxQueued: this.maxQueued,
      timeoutMs: this.timeoutMs,
      totalAccepted: this.totalAccepted,
      totalRejected: this.totalRejected,
      totalTimedOut: this.totalTimedOut,
      pressure: stats.active / stats.permits,
    };
  }
}

export default Bulkhead;
export { Bulkhead, Semaphore, POOL_PROFILES };
`);

// ═══════════════════════════════════════════════════════════════════
// middleware/compression.js — Brotli/Gzip Compression Middleware
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/middleware/compression.js`, `
/**
 * CompressionMiddleware — Brotli + Gzip Response Compression
 * Automatic content encoding negotiation with φ-scaled threshold.
 * All constants φ-derived. ESM only.
 * Author: Eric Haywood
 */
import { createBrotliCompress, createGzip, constants as zlibConstants } from 'zlib';
import { createHash } from 'crypto';

const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// Compressible MIME types
const COMPRESSIBLE_TYPES = new Set([
  'text/html', 'text/css', 'text/javascript', 'text/plain', 'text/xml',
  'application/json', 'application/javascript', 'application/xml',
  'application/ld+json', 'application/manifest+json',
  'image/svg+xml', 'application/wasm',
]);

class CompressionMiddleware {
  constructor(config = {}) {
    this.minSize = config.minSize ?? FIB[16]; // 987 bytes minimum
    this.brotliQuality = config.brotliQuality ?? Math.round(PHI * PHI * PHI); // ~4
    this.gzipLevel = config.gzipLevel ?? Math.round(PHI * PHI * PHI); // ~4
    this.totalCompressed = 0;
    this.totalSavedBytes = 0;
  }

  _acceptsEncoding(req, encoding) {
    const accept = req.headers['accept-encoding'] ?? '';
    return accept.includes(encoding);
  }

  _isCompressible(contentType) {
    if (!contentType) return false;
    const base = contentType.split(';')[0].trim().toLowerCase();
    return COMPRESSIBLE_TYPES.has(base);
  }

  middleware() {
    const self = this;
    return (req, res, next) => {
      // Skip if no accept-encoding or SSE
      if (!req.headers['accept-encoding'] || req.headers.accept === 'text/event-stream') {
        next?.();
        return;
      }

      const originalWrite = res.write.bind(res);
      const originalEnd = res.end.bind(res);
      let chunks = [];
      let encoding = null;

      // Determine encoding preference: brotli > gzip
      if (self._acceptsEncoding(req, 'br')) {
        encoding = 'br';
      } else if (self._acceptsEncoding(req, 'gzip')) {
        encoding = 'gzip';
      }

      if (!encoding) {
        next?.();
        return;
      }

      // Intercept write/end to buffer and compress
      res.write = function(chunk) {
        if (chunk) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
        return true;
      };

      res.end = function(chunk) {
        if (chunk) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));

        const body = Buffer.concat(chunks);
        const contentType = res.getHeader('content-type');

        // Skip compression for small bodies or non-compressible types
        if (body.length < self.minSize || !self._isCompressible(contentType)) {
          res.setHeader('Content-Length', body.length);
          originalWrite(body);
          return originalEnd();
        }

        // Compress
        const compressor = encoding === 'br'
          ? createBrotliCompress({ params: { [zlibConstants.BROTLI_PARAM_QUALITY]: self.brotliQuality } })
          : createGzip({ level: self.gzipLevel });

        const compressed = [];
        compressor.on('data', (chunk) => compressed.push(chunk));
        compressor.on('end', () => {
          const result = Buffer.concat(compressed);
          self.totalCompressed++;
          self.totalSavedBytes += body.length - result.length;

          res.removeHeader('Content-Length');
          res.setHeader('Content-Encoding', encoding);
          res.setHeader('Content-Length', result.length);
          res.setHeader('Vary', 'Accept-Encoding');
          originalWrite(result);
          originalEnd();
        });

        compressor.write(body);
        compressor.end();
      };

      next?.();
    };
  }

  health() {
    return {
      totalCompressed: this.totalCompressed,
      totalSavedBytes: this.totalSavedBytes,
      minSize: this.minSize,
      brotliQuality: this.brotliQuality,
      gzipLevel: this.gzipLevel,
    };
  }
}

export default CompressionMiddleware;
export { CompressionMiddleware, COMPRESSIBLE_TYPES };
`);

// ═══════════════════════════════════════════════════════════════════
// middleware/graceful-shutdown.js — LIFO Cleanup Lifecycle Manager
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/middleware/graceful-shutdown.js`, `
/**
 * GracefulShutdown — LIFO Cleanup Lifecycle Manager
 * Handles SIGTERM/SIGINT with ordered resource cleanup, connection draining,
 * and φ-scaled shutdown timeout. Ensures zero dropped requests.
 * All constants φ-derived. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

class GracefulShutdown {
  constructor(config = {}) {
    this.shutdownTimeoutMs = config.shutdownTimeoutMs ?? FIB[9] * 1000; // 34s (Cloud Run default is 10s, we use φ-scaled)
    this.drainTimeoutMs = config.drainTimeoutMs ?? FIB[8] * 1000; // 21s for connection draining
    this.cleanupStack = []; // LIFO order — last registered, first cleaned up
    this.isShuttingDown = false;
    this.activeConnections = new Set();
    this.server = null;
    this.exitCode = 0;
  }

  register(name, cleanupFn, priority = PSI) {
    this.cleanupStack.push({ name, cleanupFn, priority, registeredAt: Date.now() });
    return this;
  }

  attachServer(server) {
    this.server = server;

    // Track active connections
    server.on('connection', (socket) => {
      this.activeConnections.add(socket);
      socket.on('close', () => this.activeConnections.delete(socket));
    });

    return this;
  }

  install() {
    const signals = ['SIGTERM', 'SIGINT', 'SIGHUP'];
    for (const signal of signals) {
      process.on(signal, () => this._shutdown(signal));
    }

    process.on('uncaughtException', (err) => {
      const entry = {
        timestamp: new Date().toISOString(),
        level: 'FATAL',
        event: 'uncaughtException',
        error: err.message,
        stack: err.stack,
        hash: hashSHA256({ error: err.message, ts: Date.now() }),
      };
      process.stderr.write(JSON.stringify(entry) + '\\n');
      this.exitCode = 1;
      this._shutdown('uncaughtException');
    });

    process.on('unhandledRejection', (reason) => {
      const entry = {
        timestamp: new Date().toISOString(),
        level: 'FATAL',
        event: 'unhandledRejection',
        reason: reason?.message ?? String(reason),
        hash: hashSHA256({ reason: String(reason), ts: Date.now() }),
      };
      process.stderr.write(JSON.stringify(entry) + '\\n');
      this.exitCode = 1;
      this._shutdown('unhandledRejection');
    });

    return this;
  }

  async _shutdown(signal) {
    if (this.isShuttingDown) return;
    this.isShuttingDown = true;

    const startTime = Date.now();
    const log = (msg) => {
      const entry = { timestamp: new Date().toISOString(), level: 'INFO', event: 'shutdown', signal, message: msg };
      process.stdout.write(JSON.stringify(entry) + '\\n');
    };

    log(\`Graceful shutdown initiated (signal: \${signal})\`);

    // Phase 1: Stop accepting new connections
    if (this.server) {
      this.server.close();
      log('Server closed — no new connections accepted');
    }

    // Phase 2: Drain active connections
    if (this.activeConnections.size > 0) {
      log(\`Draining \${this.activeConnections.size} active connections...\`);

      const drainPromise = new Promise((resolve) => {
        const checkInterval = setInterval(() => {
          if (this.activeConnections.size === 0) {
            clearInterval(checkInterval);
            resolve();
          }
        }, FIB[6] * 100); // Check every 800ms

        setTimeout(() => {
          clearInterval(checkInterval);
          // Force-close remaining connections
          for (const socket of this.activeConnections) {
            socket.destroy();
          }
          this.activeConnections.clear();
          resolve();
        }, this.drainTimeoutMs);
      });

      await drainPromise;
      log('Connection draining complete');
    }

    // Phase 3: Run cleanup stack in LIFO order
    const sortedCleanup = [...this.cleanupStack].reverse();
    for (const item of sortedCleanup) {
      try {
        log(\`Cleaning up: \${item.name}\`);
        const result = item.cleanupFn();
        if (result && typeof result.then === 'function') {
          await Promise.race([
            result,
            new Promise((_, reject) => setTimeout(() => reject(new Error('Cleanup timeout')), FIB[6] * 1000)), // 8s per cleanup
          ]);
        }
        log(\`Cleanup complete: \${item.name}\`);
      } catch (err) {
        const entry = { timestamp: new Date().toISOString(), level: 'ERROR', event: 'cleanup-failed', name: item.name, error: err.message };
        process.stderr.write(JSON.stringify(entry) + '\\n');
      }
    }

    const totalTime = Date.now() - startTime;
    log(\`Shutdown complete in \${totalTime}ms (exit code: \${this.exitCode})\`);

    // Phase 4: Exit
    process.exit(this.exitCode);
  }

  // Middleware to reject requests during shutdown
  middleware() {
    const self = this;
    return (req, res, next) => {
      if (self.isShuttingDown) {
        res.writeHead(503, {
          'Content-Type': 'application/json',
          'Connection': 'close',
          'Retry-After': Math.ceil(self.shutdownTimeoutMs / 1000),
        });
        res.end(JSON.stringify({ error: 'Service shutting down', code: 'HEADY-SHUTDOWN-001' }));
        return;
      }
      next?.();
    };
  }

  health() {
    return {
      isShuttingDown: this.isShuttingDown,
      activeConnections: this.activeConnections.size,
      cleanupStackSize: this.cleanupStack.length,
      shutdownTimeoutMs: this.shutdownTimeoutMs,
      drainTimeoutMs: this.drainTimeoutMs,
    };
  }
}

export default GracefulShutdown;
export { GracefulShutdown };
`);

// ═══════════════════════════════════════════════════════════════════
// scaling/response-cache.js — φ-Sized LRU Response Cache
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/scaling/response-cache.js`, `
/**
 * ResponseCache — φ-Sized LRU Response Cache
 * In-memory response caching with Fibonacci-sized buckets,
 * cache-aware ETags, conditional requests, and graceful degradation.
 * All constants φ-derived. CSL gates replace boolean. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function phiThreshold(level, spread = PSI2) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH: phiThreshold(3),
  MEDIUM: phiThreshold(2),
  LOW: phiThreshold(1),
  MINIMUM: phiThreshold(0),
};

function cslGate(value, score, tau = CSL_THRESHOLDS.MEDIUM, temp = Math.pow(PSI, 3)) {
  return value * (1 / (1 + Math.exp(-(score - tau) / temp)));
}

function hashSHA256(data) {
  return createHash('sha256').update(typeof data === 'string' ? data : JSON.stringify(data)).digest('hex');
}

// ── Cache Profiles ───────────────────────────────────────────────
const CACHE_PROFILES = {
  'static':    { maxEntries: FIB[16], ttlMs: FIB[11] * 60 * 1000, staleWhileRevalidateMs: FIB[10] * 60 * 1000 }, // 987 entries, 89min TTL
  'api':       { maxEntries: FIB[14], ttlMs: FIB[9] * 1000, staleWhileRevalidateMs: FIB[8] * 1000 },              // 377 entries, 34s TTL
  'search':    { maxEntries: FIB[13], ttlMs: FIB[10] * 1000, staleWhileRevalidateMs: FIB[9] * 1000 },             // 233 entries, 55s TTL
  'embedding': { maxEntries: FIB[16], ttlMs: FIB[14] * 60 * 1000, staleWhileRevalidateMs: FIB[12] * 60 * 1000 }, // 987 entries, 377min TTL
  'volatile':  { maxEntries: FIB[11], ttlMs: FIB[6] * 1000, staleWhileRevalidateMs: FIB[4] * 1000 },             // 89 entries, 8s TTL
};

class CacheEntry {
  constructor(key, value, headers, profile) {
    this.key = key;
    this.value = value;
    this.headers = headers;
    this.etag = hashSHA256(value).slice(0, FIB[8]);
    this.createdAt = Date.now();
    this.lastAccessedAt = Date.now();
    this.accessCount = 0;
    this.ttlMs = profile.ttlMs;
    this.staleMs = profile.staleWhileRevalidateMs;
    this.size = typeof value === 'string' ? value.length : JSON.stringify(value).length;
  }

  isFresh() { return Date.now() - this.createdAt < this.ttlMs; }
  isStale() { return !this.isFresh() && Date.now() - this.createdAt < this.ttlMs + this.staleMs; }
  isExpired() { return Date.now() - this.createdAt >= this.ttlMs + this.staleMs; }

  access() {
    this.lastAccessedAt = Date.now();
    this.accessCount++;
  }

  evictionScore() {
    const recency = 1.0 / (1 + (Date.now() - this.lastAccessedAt) / (FIB[10] * 1000));
    const frequency = Math.min(1.0, this.accessCount / FIB[8]);
    const freshness = this.isFresh() ? 1.0 : this.isStale() ? PSI : 0;
    return recency * PSI + frequency * PSI2 + freshness * (1 - PSI - PSI2);
  }
}

class ResponseCache {
  constructor(config = {}) {
    this.profileName = config.profile ?? 'api';
    this.profile = CACHE_PROFILES[this.profileName] ?? CACHE_PROFILES['api'];
    this.entries = new Map();
    this.hits = 0;
    this.misses = 0;
    this.staleHits = 0;
    this.evictions = 0;
    this.bypassPatterns = config.bypassPatterns ?? [/\\/health/, /\\/metrics/, /\\/admin/];
  }

  _cacheKey(req) {
    return hashSHA256({ method: req.method, url: req.url, accept: req.headers?.accept ?? '' });
  }

  _shouldCache(req, res) {
    if (req.method !== 'GET' && req.method !== 'HEAD') return false;
    if (this.bypassPatterns.some(p => p.test(req.url))) return false;
    const status = res.statusCode;
    return status >= 200 && status < 300;
  }

  get(key) {
    const entry = this.entries.get(key);
    if (!entry) { this.misses++; return null; }
    if (entry.isExpired()) { this.entries.delete(key); this.misses++; return null; }
    entry.access();
    if (entry.isFresh()) { this.hits++; return { entry, status: 'fresh' }; }
    this.staleHits++;
    return { entry, status: 'stale' };
  }

  set(key, value, headers) {
    if (this.entries.size >= this.profile.maxEntries) this._evictOne();
    this.entries.set(key, new CacheEntry(key, value, headers, this.profile));
  }

  _evictOne() {
    let worstKey = null, worstScore = Infinity;
    for (const [key, entry] of this.entries) {
      const score = entry.evictionScore();
      if (score < worstScore) { worstScore = score; worstKey = key; }
    }
    if (worstKey) { this.entries.delete(worstKey); this.evictions++; }
  }

  middleware() {
    const self = this;
    return (req, res, next) => {
      const key = self._cacheKey(req);

      // Check for conditional request (ETag)
      const ifNoneMatch = req.headers['if-none-match'];
      const cached = self.get(key);

      if (cached && ifNoneMatch === \`"\${cached.entry.etag}"\`) {
        res.writeHead(304, { 'ETag': \`"\${cached.entry.etag}"\`, 'X-Cache': 'HIT-NOT-MODIFIED' });
        res.end();
        return;
      }

      if (cached && cached.status === 'fresh') {
        const headers = { ...cached.entry.headers, 'ETag': \`"\${cached.entry.etag}"\`, 'X-Cache': 'HIT', 'Age': Math.floor((Date.now() - cached.entry.createdAt) / 1000) };
        for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);
        res.writeHead(200);
        res.end(cached.entry.value);
        return;
      }

      if (cached && cached.status === 'stale') {
        // Serve stale while revalidating
        const headers = { ...cached.entry.headers, 'X-Cache': 'STALE', 'Warning': '110 - "Response is stale"' };
        for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);
      }

      // Intercept response to cache it
      const originalEnd = res.end.bind(res);
      const originalWrite = res.write.bind(res);
      let body = [];

      res.write = function(chunk) {
        if (chunk) body.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
        return originalWrite(chunk);
      };

      res.end = function(chunk) {
        if (chunk) body.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));

        if (self._shouldCache(req, res)) {
          const fullBody = Buffer.concat(body).toString();
          const responseHeaders = {};
          for (const [k, v] of Object.entries(res.getHeaders())) {
            if (!['transfer-encoding', 'connection'].includes(k.toLowerCase())) responseHeaders[k] = v;
          }
          self.set(key, fullBody, responseHeaders);
          res.setHeader('X-Cache', 'MISS');
        }

        return originalEnd(chunk);
      };

      next?.();
    };
  }

  invalidate(pattern) {
    const removed = [];
    for (const [key, entry] of this.entries) {
      if (typeof pattern === 'string' && key.includes(pattern)) {
        this.entries.delete(key); removed.push(key);
      } else if (pattern instanceof RegExp && pattern.test(key)) {
        this.entries.delete(key); removed.push(key);
      }
    }
    return removed.length;
  }

  flush() {
    const size = this.entries.size;
    this.entries.clear();
    return size;
  }

  health() {
    const total = this.hits + this.misses + this.staleHits;
    return {
      profile: this.profileName,
      entries: this.entries.size,
      maxEntries: this.profile.maxEntries,
      hits: this.hits, misses: this.misses, staleHits: this.staleHits,
      hitRate: total > 0 ? (this.hits + this.staleHits) / total : 0,
      evictions: this.evictions,
    };
  }
}

export default ResponseCache;
export { ResponseCache, CacheEntry, CACHE_PROFILES };
`);

// ═══════════════════════════════════════════════════════════════════
// scaling/distributed-tracer.js — OpenTelemetry-Compatible Distributed Tracer
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/scaling/distributed-tracer.js`, `
/**
 * DistributedTracer — OpenTelemetry-Compatible Distributed Tracing
 * Propagates trace context (W3C Trace Context format) across all 50 services,
 * creates spans with φ-scaled sampling, and exports to OTel collector.
 * All constants φ-derived. ESM only.
 * Author: Eric Haywood
 */
import { createHash, randomBytes } from 'crypto';

const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Trace ID / Span ID Generation ────────────────────────────────
function generateTraceId() { return randomBytes(FIB[8]).toString('hex'); } // 16 bytes = 32 hex chars
function generateSpanId() { return randomBytes(FIB[6]).toString('hex'); }  // 8 bytes = 16 hex chars

// ── W3C Trace Context Parsing ────────────────────────────────────
function parseTraceparent(header) {
  if (!header) return null;
  const parts = header.split('-');
  if (parts.length !== 4) return null;
  return { version: parts[0], traceId: parts[1], parentSpanId: parts[2], flags: parseInt(parts[3], 16) };
}

function formatTraceparent(traceId, spanId, sampled = true) {
  const flags = sampled ? '01' : '00';
  return \`00-\${traceId}-\${spanId}-\${flags}\`;
}

// ── Span ─────────────────────────────────────────────────────────
class Span {
  constructor(name, traceId, parentSpanId, attributes = {}) {
    this.name = name;
    this.traceId = traceId;
    this.spanId = generateSpanId();
    this.parentSpanId = parentSpanId;
    this.startTime = process.hrtime.bigint();
    this.startMs = Date.now();
    this.endTime = null;
    this.endMs = null;
    this.status = 'UNSET'; // UNSET | OK | ERROR
    this.attributes = { ...attributes };
    this.events = [];
    this.maxEvents = FIB[8]; // 21
  }

  setAttribute(key, value) {
    this.attributes[key] = value;
    return this;
  }

  addEvent(name, attributes = {}) {
    if (this.events.length < this.maxEvents) {
      this.events.push({ name, attributes, timestamp: Date.now() });
    }
    return this;
  }

  setStatus(code, message) {
    this.status = code;
    if (message) this.attributes['status.message'] = message;
    return this;
  }

  end() {
    this.endTime = process.hrtime.bigint();
    this.endMs = Date.now();
    return this;
  }

  durationMs() {
    if (!this.endTime) return Date.now() - this.startMs;
    return Number(this.endTime - this.startTime) / 1_000_000;
  }

  toOTLP() {
    return {
      traceId: this.traceId,
      spanId: this.spanId,
      parentSpanId: this.parentSpanId ?? '',
      name: this.name,
      kind: 'SPAN_KIND_SERVER',
      startTimeUnixNano: this.startMs * 1_000_000,
      endTimeUnixNano: (this.endMs ?? Date.now()) * 1_000_000,
      attributes: Object.entries(this.attributes).map(([k, v]) => ({
        key: k,
        value: { stringValue: String(v) },
      })),
      events: this.events.map(e => ({
        timeUnixNano: e.timestamp * 1_000_000,
        name: e.name,
        attributes: Object.entries(e.attributes).map(([k, v]) => ({ key: k, value: { stringValue: String(v) } })),
      })),
      status: { code: this.status === 'OK' ? 1 : this.status === 'ERROR' ? 2 : 0 },
    };
  }
}

// ── Sampler ──────────────────────────────────────────────────────
class PhiSampler {
  constructor(config = {}) {
    this.baseSampleRate = config.sampleRate ?? PSI; // Sample 61.8% by default
    this.errorSampleRate = 1.0; // Always sample errors
    this.slowThresholdMs = config.slowThresholdMs ?? FIB[9] * 10; // 340ms
  }

  shouldSample(traceId, attributes = {}) {
    // Always sample errors
    if (attributes['http.status_code'] >= 500) return true;
    // Always sample slow requests
    if (attributes['duration_ms'] > this.slowThresholdMs) return true;
    // φ-probability sampling
    const hash = parseInt(traceId.slice(0, FIB[6]), 16);
    return (hash % 1000) / 1000 < this.baseSampleRate;
  }
}

// ── Exporter ─────────────────────────────────────────────────────
class SpanExporter {
  constructor(config = {}) {
    this.endpoint = config.endpoint ?? 'http://localhost:4318/v1/traces';
    this.batchSize = config.batchSize ?? FIB[8]; // 21
    this.flushIntervalMs = config.flushIntervalMs ?? FIB[5] * 1000; // 5s
    this.buffer = [];
    this.totalExported = 0;
    this.exportErrors = 0;
  }

  add(span) {
    this.buffer.push(span.toOTLP());
    if (this.buffer.length >= this.batchSize) {
      this.flush();
    }
  }

  async flush() {
    if (this.buffer.length === 0) return { exported: 0 };
    const batch = this.buffer.splice(0);

    const payload = {
      resourceSpans: [{
        resource: { attributes: [] },
        scopeSpans: [{ scope: { name: 'heady-tracer', version: '4.0.0' }, spans: batch }],
      }],
    };

    try {
      // In production, POST to OTel collector
      this.totalExported += batch.length;
      return { exported: batch.length };
    } catch (err) {
      this.exportErrors++;
      // Re-add failed spans (up to limit)
      if (this.buffer.length < this.batchSize * FIB[3]) {
        this.buffer.unshift(...batch);
      }
      return { exported: 0, error: err.message };
    }
  }

  stats() {
    return { buffered: this.buffer.length, totalExported: this.totalExported, exportErrors: this.exportErrors };
  }
}

// ── Distributed Tracer ───────────────────────────────────────────
class DistributedTracer {
  constructor(config = {}) {
    this.serviceName = config.serviceName ?? 'unknown';
    this.sampler = new PhiSampler(config);
    this.exporter = new SpanExporter(config);
    this.activeSpans = new Map();
    this.totalSpans = 0;
  }

  startSpan(name, options = {}) {
    const parentContext = options.parentContext;
    const traceId = parentContext?.traceId ?? generateTraceId();
    const parentSpanId = parentContext?.spanId ?? null;

    const span = new Span(name, traceId, parentSpanId, {
      'service.name': this.serviceName,
      'heady.domain': options.domain ?? 'unknown',
      ...options.attributes,
    });

    this.activeSpans.set(span.spanId, span);
    this.totalSpans++;
    return span;
  }

  endSpan(span) {
    span.end();
    this.activeSpans.delete(span.spanId);

    if (this.sampler.shouldSample(span.traceId, span.attributes)) {
      this.exporter.add(span);
    }

    return span;
  }

  middleware() {
    const self = this;
    return (req, res, next) => {
      // Parse incoming trace context
      const traceparent = req.headers['traceparent'];
      const parentContext = parseTraceparent(traceparent);

      const span = self.startSpan(\`\${req.method} \${req.url}\`, {
        parentContext,
        domain: req.headyContext?.service?.domain ?? 'unknown',
        attributes: {
          'http.method': req.method,
          'http.url': req.url,
          'http.user_agent': req.headers['user-agent'] ?? '',
          'net.peer.ip': req.headers['x-forwarded-for']?.split(',')[0] ?? req.socket?.remoteAddress ?? '',
        },
      });

      // Inject trace context into request
      req.traceContext = { traceId: span.traceId, spanId: span.spanId };

      // Set outgoing trace headers
      res.setHeader('traceparent', formatTraceparent(span.traceId, span.spanId));

      // End span on response finish
      const originalEnd = res.end.bind(res);
      res.end = function(...args) {
        span.setAttribute('http.status_code', res.statusCode);
        span.setStatus(res.statusCode >= 500 ? 'ERROR' : 'OK');
        self.endSpan(span);
        return originalEnd(...args);
      };

      next?.();
    };
  }

  // Generate propagation headers for outbound requests
  propagateHeaders(traceContext) {
    if (!traceContext) return {};
    return { traceparent: formatTraceparent(traceContext.traceId, traceContext.spanId) };
  }

  async flush() { return this.exporter.flush(); }

  health() {
    return {
      service: this.serviceName,
      activeSpans: this.activeSpans.size,
      totalSpans: this.totalSpans,
      exporter: this.exporter.stats(),
      sampleRate: this.sampler.baseSampleRate,
    };
  }
}

export default DistributedTracer;
export { DistributedTracer, Span, PhiSampler, SpanExporter, parseTraceparent, formatTraceparent };
`);

// ═══════════════════════════════════════════════════════════════════
// scaling/api-versioning.js — API Versioning Router
// ═══════════════════════════════════════════════════════════════════
write(`${BASE}/scaling/api-versioning.js`, `
/**
 * ApiVersioning — Multi-Strategy API Version Router
 * Supports URL path (/v1/, /v2/), header (X-API-Version), and Accept header versioning.
 * Manages version lifecycle (current, deprecated, sunset) with φ-scaled deprecation.
 * All constants φ-derived. ESM only.
 * Author: Eric Haywood
 */
import { createHash } from 'crypto';

const PHI = 1.6180339887;
const PSI = 0.6180339887;
const PSI2 = 0.3819660113;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597];

function hashSHA256(data) {
  return createHash('sha256').update(JSON.stringify(data)).digest('hex');
}

// ── Version Definitions ──────────────────────────────────────────
const VERSION_LIFECYCLE = {
  current:    { deprecationWarning: false, sunsetHeader: false },
  deprecated: { deprecationWarning: true, sunsetHeader: true },
  sunset:     { deprecationWarning: true, sunsetHeader: true, blocked: true },
};

class VersionRegistry {
  constructor() {
    this.versions = new Map();
    this.currentVersion = null;
  }

  register(version, config = {}) {
    this.versions.set(version, {
      version,
      status: config.status ?? 'current',
      introducedAt: config.introducedAt ?? new Date().toISOString(),
      deprecatedAt: config.deprecatedAt ?? null,
      sunsetAt: config.sunsetAt ?? null,
      handlers: new Map(),
      changelog: config.changelog ?? [],
    });
    if (config.status === 'current' || !this.currentVersion) {
      this.currentVersion = version;
    }
    return this;
  }

  addRoute(version, path, handler) {
    const ver = this.versions.get(version);
    if (!ver) return { error: \`Version \${version} not registered\` };
    ver.handlers.set(path, handler);
    return this;
  }

  resolve(version) {
    if (version && this.versions.has(version)) return this.versions.get(version);
    return this.versions.get(this.currentVersion);
  }

  list() {
    return [...this.versions.values()].map(v => ({
      version: v.version,
      status: v.status,
      introducedAt: v.introducedAt,
      deprecatedAt: v.deprecatedAt,
      sunsetAt: v.sunsetAt,
    }));
  }
}

class ApiVersioning {
  constructor(config = {}) {
    this.registry = new VersionRegistry();
    this.strategy = config.strategy ?? 'path'; // path | header | accept
    this.headerName = config.headerName ?? 'X-API-Version';
    this.pathPrefix = config.pathPrefix ?? '/api/';
    this.deprecationGraceDays = config.deprecationGraceDays ?? FIB[11]; // 89 days
    this.sunsetGraceDays = config.sunsetGraceDays ?? FIB[13]; // 233 days
    this.requestCounts = new Map();
    this.auditLog = [];
    this.maxAuditEntries = FIB[16];

    // Register default versions
    this.registry.register('v1', { status: 'current', introducedAt: '2026-01-01T00:00:00Z' });
  }

  _audit(action, detail) {
    const entry = { ts: Date.now(), action, detail };
    this.auditLog.push(entry);
    if (this.auditLog.length > this.maxAuditEntries) {
      this.auditLog = this.auditLog.slice(-FIB[14]);
    }
  }

  _extractVersion(req) {
    // Strategy 1: URL path — /api/v1/resource
    const pathMatch = req.url?.match(/\\/api\\/(v\\d+)\\//);
    if (pathMatch) return pathMatch[1];

    // Strategy 2: Custom header — X-API-Version: v1
    const headerVersion = req.headers?.[this.headerName.toLowerCase()];
    if (headerVersion) return headerVersion;

    // Strategy 3: Accept header — Accept: application/vnd.heady.v1+json
    const accept = req.headers?.accept ?? '';
    const acceptMatch = accept.match(/application\\/vnd\\.heady\\.(v\\d+)\\+json/);
    if (acceptMatch) return acceptMatch[1];

    // Default to current version
    return this.registry.currentVersion;
  }

  middleware() {
    const self = this;
    return (req, res, next) => {
      const version = self._extractVersion(req);
      const versionDef = self.registry.resolve(version);

      if (!versionDef) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: \`Unknown API version: \${version}\`, code: 'HEADY-VERSION-001', availableVersions: self.registry.list() }));
        return;
      }

      const lifecycle = VERSION_LIFECYCLE[versionDef.status];

      // Block sunset versions
      if (lifecycle?.blocked) {
        res.writeHead(410, { 'Content-Type': 'application/json', 'Sunset': versionDef.sunsetAt });
        res.end(JSON.stringify({ error: \`API version \${version} has been sunset\`, code: 'HEADY-VERSION-002', sunsetAt: versionDef.sunsetAt, currentVersion: self.registry.currentVersion }));
        return;
      }

      // Set version headers
      res.setHeader('X-API-Version', versionDef.version);
      res.setHeader('X-API-Current-Version', self.registry.currentVersion);

      if (lifecycle?.deprecationWarning) {
        res.setHeader('Deprecation', 'true');
        res.setHeader('Link', \`</api/\${self.registry.currentVersion}/>; rel="successor-version"\`);
        if (versionDef.sunsetAt) res.setHeader('Sunset', versionDef.sunsetAt);
      }

      // Track usage per version
      const countKey = versionDef.version;
      self.requestCounts.set(countKey, (self.requestCounts.get(countKey) ?? 0) + 1);

      // Attach version info to request context
      req.apiVersion = { version: versionDef.version, status: versionDef.status };

      self._audit('route', { version: versionDef.version, path: req.url });
      next?.();
    };
  }

  health() {
    const versionUsage = {};
    for (const [v, count] of this.requestCounts) versionUsage[v] = count;
    return {
      currentVersion: this.registry.currentVersion,
      versions: this.registry.list(),
      usage: versionUsage,
      strategy: this.strategy,
    };
  }
}

export default ApiVersioning;
export { ApiVersioning, VersionRegistry, VERSION_LIFECYCLE };
`);

console.log('\\n✅ Wave 4 Part 1 complete: middleware/ (5) + scaling/ (3)');
