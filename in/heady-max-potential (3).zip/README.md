# Heady Latent OS — Maximum Potential Build

> The complete autonomous operating system for the Heady AI platform.

## Stats
- **102 files** | **~20,252 lines** | **64 JavaScript modules** | **20 services**
- **12 ADRs** | **24 error codes** | **6 test suites** | **14 prompt injection patterns**
- **φ = 1.6180339887** — zero magic numbers

## Author
Eric Haywood — [HeadyConnection.org](https://headyconnection.org)

## Quick Start
```bash
npm install
docker compose -f infra/docker-compose.yml up -d
node index.js
```

## Documentation
- [Onboarding Guide](docs/ONBOARDING.md)
- [Security Model](docs/SECURITY_MODEL.md)
- [Error Codes](docs/ERROR_CODES.md)
- [Debug Guide](docs/guides/DEBUG.md)
- [Architecture Decisions](docs/adrs/)
- [Operational Runbooks](docs/runbooks/)

## Build History
- [Changes Log](docs/CHANGES.md)
- [Gaps Found & Resolved](docs/GAPS_FOUND.md)
- [Improvements Made](docs/IMPROVEMENTS.md)

## License
Proprietary — HeadySystems / HeadyConnection
