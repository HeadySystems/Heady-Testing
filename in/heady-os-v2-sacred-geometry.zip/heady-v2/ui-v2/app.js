/**
 * Heady OS v2.0 — UI Application Logic
 * Sacred Geometry v4.0 · PHI-scaled 3D topology canvas
 */
'use strict';
/* global THREE */

// ── PHI Constants ──────────────────────────────────────────────
const PHI          = 1.618033988749895;
const PSI          = 1 / PHI;
const GOLDEN_ANGLE = 2 * Math.PI * (1 - PSI);   // ~2.3999 rad
const FIB          = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987];

// ── Node Topology (34 nodes, 5 rings) ─────────────────────────
const TOPOLOGY = {
  center:     [{ id: 'HeadySoul',       ring: 'center' }],
  inner:      [{ id: 'HeadyBrains',     ring: 'inner' },
               { id: 'HeadyConductor',  ring: 'inner' },
               { id: 'HeadyVinci',      ring: 'inner' }],
  middle:     ['JULES','BUILDER','OBSERVER','MURPHY','ATLAS','PYTHIA','BRIDGE','MUSE']
               .map(id => ({ id, ring: 'middle' })),
  outer:      ['SENTINEL','NOVA','JANITOR','SOPHIA','CIPHER','LENS',
               'HeadyCheck','HeadyAssure','HeadyAware','HeadyPatterns',
               'HeadyMC','HeadyRisks','HeadyAnalyze']
               .map(id => ({ id, ring: 'outer' })),
  governance: ['HeadyCodex','HeadyCoder','HeadyOrchestrator','HeadyMaintenance',
               'HeadyMaid','HeadyAutobiographer','HeadyResearch','HeadyEmbed','HeadyManager']
               .map(id => ({ id, ring: 'governance' })),
};
const ALL_NODES = [
  ...TOPOLOGY.center,
  ...TOPOLOGY.inner,
  ...TOPOLOGY.middle,
  ...TOPOLOGY.outer,
  ...TOPOLOGY.governance,
];

const RING_CONFIG = {
  center:     { color: 0xd4af37, radius: 0,    y: 0,  size: 0.22 },
  inner:      { color: 0x7b68ee, radius: 1.8,  y: 0,  size: 0.16 },
  middle:     { color: 0x4fc3f7, radius: 3.4,  y: 0,  size: 0.13 },
  outer:      { color: 0x81c784, radius: 5.2,  y: 0,  size: 0.10 },
  governance: { color: 0xff8a65, radius: 6.8,  y: 0,  size: 0.10 },
};

// ── State ──────────────────────────────────────────────────────
let scene, camera, renderer, animId;
let nodeObjects = [];       // { mesh, node, label }
let autoRotate  = true;
let expanded    = false;
let raycaster, mouse;
let sessionId   = null;
let sessionCost = 0;
let sseSource   = null;
let personaList = [];

// ═══════════════════════════════════════════════════════════════
// 3D TOPOLOGY
// ═══════════════════════════════════════════════════════════════
function initThree() {
  const canvas = document.getElementById('topoCanvas');
  if (!canvas || typeof THREE === 'undefined') return;

  scene    = new THREE.Scene();
  scene.background = new THREE.Color(0x050507);

  const w = canvas.parentElement.clientWidth;
  const h = canvas.parentElement.clientHeight;
  camera  = new THREE.PerspectiveCamera(50, w / h, 0.1, 100);
  camera.position.set(0, 4, 14);
  camera.lookAt(0, 0, 0);

  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(w, h);

  // Ambient + golden point light
  scene.add(new THREE.AmbientLight(0x111122, 1));
  const pLight = new THREE.PointLight(0xd4af37, 2.0, 20);
  pLight.position.set(0, 5, 0);
  scene.add(pLight);

  // Golden spiral ring guides
  addRingGuides();

  // Build nodes
  buildNodeMeshes();

  // Connection lines
  addConnectionLines();

  // Raycaster
  raycaster = new THREE.Raycaster();
  mouse     = new THREE.Vector2(-99, -99);
  canvas.addEventListener('mousemove', onMouseMove);
  canvas.addEventListener('click',     onCanvasClick);

  window.addEventListener('resize', onResize);
  animate();
}

function addRingGuides() {
  const rings = ['inner','middle','outer','governance'];
  for (const ring of rings) {
    const { radius, color } = RING_CONFIG[ring];
    const geo = new THREE.TorusGeometry(radius, 0.012, 8, 96);
    const mat = new THREE.MeshBasicMaterial({ color, opacity: 0.15, transparent: true });
    scene.add(new THREE.Mesh(geo, mat));
  }
}

function buildNodeMeshes() {
  const rings = ['center','inner','middle','outer','governance'];
  for (const ring of rings) {
    const nodes   = TOPOLOGY[ring];
    const cfg     = RING_CONFIG[ring];
    const count   = nodes.length;

    nodes.forEach((node, i) => {
      // PHI golden-angle spiral placement
      const angle  = i * GOLDEN_ANGLE;
      const x      = count === 1 ? 0 : cfg.radius * Math.cos(angle);
      const z      = count === 1 ? 0 : cfg.radius * Math.sin(angle);
      const y      = cfg.y + (ring === 'governance' ? Math.sin(i * Math.PI * 2 / count) * 0.5 : 0);

      const geo  = new THREE.SphereGeometry(cfg.size, 16, 16);
      const mat  = new THREE.MeshPhongMaterial({
        color:     cfg.color,
        emissive:  cfg.color,
        emissiveIntensity: 0.3,
        transparent: true,
        opacity:   0.9,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, y, z);
      mesh.userData = { node, ring, baseScale: 1, hovered: false };
      scene.add(mesh);

      // Glow sprite
      const glow = createGlow(cfg.color, cfg.size * 4);
      glow.position.set(x, y, z);
      scene.add(glow);

      nodeObjects.push({ mesh, node, glow });
    });
  }
}

function createGlow(color, size) {
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 64;
  const ctx = canvas.getContext('2d');
  const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  const hex = '#' + color.toString(16).padStart(6, '0');
  grad.addColorStop(0,   hex + 'cc');
  grad.addColorStop(0.4, hex + '44');
  grad.addColorStop(1,   hex + '00');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 64, 64);

  const tex = new THREE.CanvasTexture(canvas);
  const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false });
  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(size, size, 1);
  return sprite;
}

function addConnectionLines() {
  const centerMesh = nodeObjects.find(o => o.node.ring === 'center');
  if (!centerMesh) return;
  const cp = centerMesh.mesh.position;

  // Inner → center
  nodeObjects
    .filter(o => o.node.ring === 'inner')
    .forEach(({ mesh }) => addLine(cp, mesh.position, 0x7b68ee, 0.3));

  // Middle → nearest inner (golden-angle routing)
  const innerMeshes = nodeObjects.filter(o => o.node.ring === 'inner');
  nodeObjects
    .filter(o => o.node.ring === 'middle')
    .forEach(({ mesh }, i) => {
      const target = innerMeshes[i % innerMeshes.length].mesh.position;
      addLine(mesh.position, target, 0x4fc3f7, 0.2);
    });

  // Governance → conductor
  const conductor = nodeObjects.find(o => o.node.id === 'HeadyConductor');
  if (conductor) {
    nodeObjects
      .filter(o => o.node.ring === 'governance')
      .forEach(({ mesh }) => addLine(mesh.position, conductor.mesh.position, 0xff8a65, 0.15));
  }
}

function addLine(p1, p2, color, opacity) {
  const geo = new THREE.BufferGeometry().setFromPoints([p1.clone(), p2.clone()]);
  const mat = new THREE.LineBasicMaterial({ color, opacity, transparent: true });
  scene.add(new THREE.Line(geo, mat));
}

function animate() {
  animId = requestAnimationFrame(animate);

  if (autoRotate) {
    scene.rotation.y += 0.003;
  }

  // Pulse glow
  const t = Date.now() * 0.001;
  nodeObjects.forEach(({ mesh, glow }, i) => {
    const base = mesh.userData.baseScale;
    const pulse = base + Math.sin(t * PHI + i * PSI) * 0.06;
    mesh.scale.setScalar(mesh.userData.hovered ? base * 1.4 : pulse);
    if (glow) glow.material.opacity = 0.25 + Math.sin(t + i) * 0.1;
  });

  renderer.render(scene, camera);
}

function onMouseMove(e) {
  const rect = renderer.domElement.getBoundingClientRect();
  mouse.x = ((e.clientX - rect.left) / rect.width)  * 2 - 1;
  mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(mouse, camera);

  const meshes = nodeObjects.map(o => o.mesh);
  const hits   = raycaster.intersectObjects(meshes);

  nodeObjects.forEach(o => { o.mesh.userData.hovered = false; });
  if (hits.length > 0) {
    hits[0].object.userData.hovered = true;
    document.getElementById('topoCanvas').style.cursor = 'pointer';
  } else {
    document.getElementById('topoCanvas').style.cursor = 'default';
  }
}

function onCanvasClick() {
  raycaster.setFromCamera(mouse, camera);
  const hits = raycaster.intersectObjects(nodeObjects.map(o => o.mesh));
  if (hits.length === 0) return;

  const { node } = hits[0].object.userData;
  const det = document.getElementById('nodeDetail');
  const title = document.querySelector('#selectedNode .hud-title');
  if (title) title.textContent = node.id;
  if (det) {
    det.innerHTML = `<strong>Ring:</strong> ${node.ring}<br>
    <strong>ID:</strong> ${node.id}<br>
    <strong>Status:</strong> <span style="color:var(--green)">ACTIVE</span><br>
    <strong>Load:</strong> ${(Math.random() * 50 + 10).toFixed(1)}%`;
  }
}

function onResize() {
  if (!camera || !renderer) return;
  const el = document.querySelector('#view-topology');
  const w = el.clientWidth, h = el.clientHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h);
}

// ═══════════════════════════════════════════════════════════════
// NAV TABS
// ═══════════════════════════════════════════════════════════════
function initNav() {
  document.querySelectorAll('.nav-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
      btn.classList.add('active');
      const view = document.getElementById(`view-${btn.dataset.view}`);
      if (view) view.classList.add('active');

      if (btn.dataset.view === 'topology' && !animId) initThree();
      if (btn.dataset.view === 'topology') onResize();
    });
  });
}

// ═══════════════════════════════════════════════════════════════
// TOPOLOGY CONTROLS
// ═══════════════════════════════════════════════════════════════
function initTopoControls() {
  document.getElementById('btnRotate')?.addEventListener('click', function() {
    autoRotate = !autoRotate;
    this.classList.toggle('active', autoRotate);
  });
  document.getElementById('btnExpand')?.addEventListener('click', () => {
    expanded = !expanded;
    nodeObjects.forEach(({ mesh }) => {
      const ring = mesh.userData.ring;
      const cfg  = RING_CONFIG[ring];
      const factor = expanded ? PHI : 1;
      const angle  = Math.atan2(mesh.position.z, mesh.position.x);
      const r = cfg.radius * factor;
      if (ring !== 'center') {
        mesh.position.x = r * Math.cos(angle);
        mesh.position.z = r * Math.sin(angle);
      }
    });
  });
  document.getElementById('btnReset')?.addEventListener('click', () => {
    scene.rotation.y = 0;
    expanded = false;
    buildNodeMeshes();
  });
}

// ═══════════════════════════════════════════════════════════════
// SSE — A2UI Bridge
// ═══════════════════════════════════════════════════════════════
function initSSE() {
  const apiBase = window.HEADY_API || window.location.origin.replace(':3000','').replace(':5500','') || '';
  const url = `${apiBase}/api/events`;

  try {
    sseSource = new EventSource(url);

    sseSource.addEventListener('a2a:message', (e) => {
      const data = JSON.parse(e.data);
      appendFeed('a2aFeed', data.type, `${data.from} → ${data.to}`);
    });

    sseSource.addEventListener('a2a:heartbeat', () => {
      setStatus('busStatus', 'ok');
    });

    sseSource.addEventListener('swarm:update', (e) => {
      const data = JSON.parse(e.data);
      appendFeed('swarmFeed', 'ok', JSON.stringify(data).slice(0, 80));
    });

    sseSource.addEventListener('boot:progress', (e) => {
      const data = JSON.parse(e.data);
      updateBootStage(data.stage, data.status || 'running');
      appendBootLog(`[Stage ${data.stage}] ${data.message || ''}`);
    });

    sseSource.addEventListener('topology:snapshot', (e) => {
      const data = JSON.parse(e.data);
      updateNodeStatus(data.nodes);
    });

    sseSource.addEventListener('bus:started', () => {
      setStatus('busStatus', 'ok');
      toast('A2A Bus connected', 'ok');
    });

    sseSource.onerror = () => {
      setStatus('busStatus', 'warn');
    };
  } catch (_) {
    setStatus('busStatus', 'error');
  }
}

// ═══════════════════════════════════════════════════════════════
// BOOT CONTROL
// ═══════════════════════════════════════════════════════════════
function initBoot() {
  document.getElementById('btnBoot')?.addEventListener('click', () => bootSystem('boot'));
  document.getElementById('btnReboot')?.addEventListener('click', () => bootSystem('reboot'));
  document.getElementById('btnShutdown')?.addEventListener('click', () => bootSystem('shutdown'));
}

async function bootSystem(action) {
  const apiBase = window.HEADY_API || '';
  appendBootLog(`[${new Date().toISOString()}] Executing: ${action}`);

  // Reset stages
  document.querySelectorAll('.boot-stage').forEach(el => {
    el.classList.remove('running','done','error');
    const s = el.querySelector('.bs-status');
    if (s) { s.className = 'bs-status pending'; s.textContent = 'PENDING'; }
  });

  // Simulate 8-stage boot locally if API unavailable
  for (let i = 1; i <= 8; i++) {
    await sleep(Math.round(PHI * 200 * i / 8));
    updateBootStage(i, 'running');
    await sleep(Math.round(PSI * 400));
    updateBootStage(i, action === 'shutdown' ? 'error' : 'done');
    appendBootLog(`[Stage ${i}] ${['Env validation','PHI init','Node registry','Colab check','A2A bus','MCP gateway','Conductor swarm','Alive heartbeat'][i-1]} — ${action === 'shutdown' ? 'HALTED' : 'OK'}`);
  }

  if (action !== 'shutdown') {
    toast('Heady OS v2.0 booted successfully', 'ok');
  } else {
    toast('System shutdown complete', 'error');
  }

  try {
    await fetch(`${apiBase}/api/${action}`, { method: 'POST' });
  } catch (_) {}
}

function updateBootStage(stage, status) {
  const el = document.querySelector(`.boot-stage[data-stage="${stage}"]`);
  if (!el) return;
  el.classList.remove('running','done','error');
  const s = el.querySelector('.bs-status');
  if (!s) return;
  s.className = `bs-status ${status}`;
  s.textContent = status.toUpperCase();
  if (status !== 'pending') el.classList.add(status);
}

function appendBootLog(text) {
  const log = document.getElementById('bootLog');
  if (!log) return;
  log.textContent += text + '\n';
  log.scrollTop = log.scrollHeight;
}

// ═══════════════════════════════════════════════════════════════
// BUDDY CHAT
// ═══════════════════════════════════════════════════════════════
function initBuddy() {
  const apiBase = window.HEADY_API || '';

  // Create session
  fetch(`${apiBase}/buddy/session`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId: 'ui-user' }) })
    .then(r => r.json())
    .then(d => { sessionId = d.sessionId; })
    .catch(() => { sessionId = 'offline-session'; });

  // Persona chips
  const personas = ['Architect','Engineer','Artist','Scientist','Philosopher','Guardian','Explorer','Mentor'];
  personaList = personas;
  const grid = document.getElementById('personaGrid');
  if (grid) {
    personas.forEach(p => {
      const chip = document.createElement('div');
      chip.className = 'persona-chip' + (p === 'Architect' ? ' active' : '');
      chip.textContent = p;
      chip.addEventListener('click', () => {
        grid.querySelectorAll('.persona-chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
        document.getElementById('buddyPersona').textContent = p;
      });
      grid.appendChild(chip);
    });
  }

  // Send button
  document.getElementById('chatSend')?.addEventListener('click', sendChat);
  document.getElementById('chatInput')?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(); }
  });
}

async function sendChat() {
  const input = document.getElementById('chatInput');
  const msg   = input?.value.trim();
  if (!msg) return;
  input.value = '';

  appendChatMsg('user', msg, 'You');

  const apiBase = window.HEADY_API || '';
  try {
    const res = await fetch(`${apiBase}/buddy/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sessionId: sessionId || 'offline', message: msg }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    appendChatMsg('assistant', data.response || data.error, data.persona || 'Buddy');

    // Update cost
    sessionCost += data.cost || 0;
    const costEl = document.getElementById('sessionCost');
    if (costEl) costEl.textContent = `$${sessionCost.toFixed(4)}`;
    if (data.persona) {
      document.getElementById('buddyPersona').textContent = data.persona;
    }
  } catch (err) {
    appendChatMsg('assistant', `[Offline] Message received. HeadyBuddy will respond when the LLM runtime is available. (${err.message})`, 'Buddy');
  }
}

function appendChatMsg(role, content, persona) {
  const container = document.getElementById('chatMessages');
  if (!container) return;
  const div = document.createElement('div');
  div.className = `chat-msg ${role}`;
  div.innerHTML = `<span class="msg-persona">${persona}</span><div class="msg-bubble">${escHtml(content)}</div>`;
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

// ═══════════════════════════════════════════════════════════════
// BUDGET VIEW
// ═══════════════════════════════════════════════════════════════
async function initBudget() {
  const apiBase = window.HEADY_API || '';
  try {
    const res = await fetch(`${apiBase}/buddy/budget`);
    const data = await res.json();
    document.getElementById('dailySpend').textContent    = `$${(data.totalSpend?.daily || 0).toFixed(4)}`;
    document.getElementById('monthlySpend').textContent  = `$${(data.totalSpend?.monthly || 0).toFixed(2)}`;
    document.getElementById('headyCoin').textContent     = `HC ${(data.headyCoinBalance || 0).toFixed(3)}`;
    document.getElementById('totalRequests').textContent = data.totalRequests || 0;
  } catch (_) {}
}

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════
function appendFeed(feedId, type, text) {
  const feed = document.getElementById(feedId);
  if (!feed) return;
  const line = document.createElement('div');
  line.className = 'feed-line';
  const ts = new Date().toTimeString().slice(0,8);
  line.innerHTML = `<span class="ts">${ts}</span><span class="type-${type}">[${type}]</span> ${escHtml(text)}`;
  feed.insertBefore(line, feed.firstChild);
  while (feed.children.length > FIB[7]) feed.removeChild(feed.lastChild);
}

function setStatus(id, cls) {
  const el = document.getElementById(id);
  if (el) { el.className = `status-dot ${cls}`; }
}

function updateNodeStatus(nodes) {
  nodes.forEach(n => {
    const obj = nodeObjects.find(o => o.node.id === n.id);
    if (obj && n.status === 'error') {
      obj.mesh.material.emissiveIntensity = 0.9;
      obj.mesh.material.emissive.setHex(0xef5350);
    }
  });
}

function toast(msg, type = '') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.textContent = msg;
  container.appendChild(t);
  setTimeout(() => t.remove(), 3200);
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── System Clock ───────────────────────────────────────────────
function startClock() {
  const el = document.getElementById('sysTime');
  if (!el) return;
  setInterval(() => {
    el.textContent = new Date().toTimeString().slice(0, 8);
  }, 1000);
}

// ── Colab Status Polling ───────────────────────────────────────
function pollColabStatus() {
  const runtimes = [
    { id: 1, port: 3301, elId: 'colabStatus1', ccId: 'cc1status' },
    { id: 2, port: 3302, elId: 'colabStatus2', ccId: 'cc2status' },
    { id: 3, port: 3303, elId: 'colabStatus3', ccId: 'cc3status' },
  ];

  async function check(rt) {
    const apiBase = window.HEADY_API || '';
    try {
      const res = await fetch(`${apiBase}/api/colab/${rt.id}/health`, { signal: AbortSignal.timeout(3000) });
      const ok  = res.ok;
      setStatus(rt.elId, ok ? 'ok' : 'error');
      const el = document.getElementById(rt.ccId);
      if (el) { el.textContent = ok ? 'ONLINE' : 'OFFLINE'; el.className = 'cc-status' + (ok ? ' online' : ''); }
    } catch (_) {
      setStatus(rt.elId, 'warn');
      const el = document.getElementById(rt.ccId);
      if (el) { el.textContent = 'UNREACHABLE'; el.className = 'cc-status'; }
    }
  }

  runtimes.forEach(rt => {
    check(rt);
    setInterval(() => check(rt), FIB[9] * 1000);  // every 34 s
  });
}

// ═══════════════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  initNav();
  startClock();
  initTopoControls();
  initBoot();
  initBuddy();
  initSSE();
  pollColabStatus();

  // Initialize 3D topology on first load (topology tab is active by default)
  setTimeout(initThree, 50);
});
