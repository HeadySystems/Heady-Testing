/**
 * Heady OS v2.0 — HeadyBuddy Express Server (port 8082)
 */
'use strict';

const express    = require('express');
const cors       = require('cors');
const { HeadyBuddy } = require('./heady-buddy');
const { bridge }     = require('../a2a/a2ui-bridge');

const FIB = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987];

const ALLOWED_ORIGINS = (process.env.CORS_ORIGINS || [
  'https://headyme.com',
  'https://headysystems.com',
  'https://headyconnection.org',
  'https://headyos.com',
  'https://headymcp.com',
  'https://headybuddy.org',
]).toString().split(',');

function createBuddyServer(buddyInstance = null) {
  const buddy = buddyInstance || new HeadyBuddy();
  buddy.start();

  const app = express();
  app.use(express.json({ limit: `${FIB[9]}mb` }));   // 34 MB
  app.use(cors({ origin: ALLOWED_ORIGINS, credentials: true }));

  // ── Health ──────────────────────────────────────────────
  app.get('/buddy/health', (req, res) => {
    res.json({ status: 'ok', service: 'HeadyBuddy', ...buddy.status() });
  });

  // ── Create Session ───────────────────────────────────────
  app.post('/buddy/session', (req, res) => {
    try {
      const { userId = 'anonymous', persona } = req.body;
      const session = buddy.createSession(userId, persona);
      res.json({ sessionId: session.sessionId, persona: session.persona, createdAt: session.createdAt });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── End Session ──────────────────────────────────────────
  app.delete('/buddy/session/:sessionId', (req, res) => {
    buddy.endSession(req.params.sessionId);
    res.json({ ended: true, sessionId: req.params.sessionId });
  });

  // ── Chat ─────────────────────────────────────────────────
  app.post('/buddy/chat', async (req, res) => {
    const { sessionId, message, opts = {} } = req.body;
    if (!sessionId || !message) {
      return res.status(400).json({ error: 'sessionId and message required' });
    }
    try {
      const result = await buddy.chat(sessionId, message, opts);
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── Chat Stream (SSE) ────────────────────────────────────
  app.get('/buddy/stream/:sessionId', (req, res) => {
    const { sessionId } = req.params;
    const session = buddy.getSession(sessionId);
    if (!session) return res.status(404).json({ error: 'Session not found' });

    // Wire this response to A2UI bridge for real-time buddy events
    const clientId = bridge.connect(req, res, ['buddy:typing', 'buddy:response', 'a2a:message']);

    buddy.on('chat:turn', (data) => {
      if (data.sessionId === sessionId) {
        bridge.sendTo(clientId, 'buddy:turn', data);
      }
    });
  });

  // ── Session Status ───────────────────────────────────────
  app.get('/buddy/session/:sessionId', (req, res) => {
    const session = buddy.getSession(req.params.sessionId);
    if (!session) return res.status(404).json({ error: 'Session not found' });
    res.json(session.toJSON());
  });

  // ── Wisdom Search ────────────────────────────────────────
  app.post('/buddy/wisdom/search', async (req, res) => {
    const { query, k = 5 } = req.body;
    if (!query) return res.status(400).json({ error: 'query required' });
    try {
      const results = await buddy.wisdomStore.search(query, k);
      res.json({ results });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── Budget Status ────────────────────────────────────────
  app.get('/buddy/budget', (req, res) => {
    res.json(buddy.budgetTracker.status());
  });

  // ── Persona List ─────────────────────────────────────────
  app.get('/buddy/personas', (req, res) => {
    res.json({ personas: buddy.personaRouter.listPersonas() });
  });

  return { app, buddy };
}

module.exports = { createBuddyServer };
