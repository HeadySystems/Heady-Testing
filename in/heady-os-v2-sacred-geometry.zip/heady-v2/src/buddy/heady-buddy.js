/**
 * Heady OS v2.0 — HeadyBuddy Companion
 * Conversational AI companion with PersonaRouter + WisdomStore + BudgetTracker
 */
'use strict';

const { EventEmitter } = require('events');
const crypto = require('crypto');

const { PersonaRouter } = require('../engines/persona-router');
const { WisdomStore }   = require('../engines/wisdom-store');
const { BudgetTracker } = require('../engines/budget-tracker');
const { bus, PRIORITY } = require('../a2a/a2a-protocol');

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const FIB  = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987];

const BUDDY_CONFIG = {
  MAX_HISTORY:         FIB[10],         // 89 turns per session
  MAX_SESSIONS:        FIB[8],          // 21 concurrent sessions
  SESSION_TTL_MS:      FIB[11] * 60000, // 144 minutes
  WISDOM_SEARCH_K:     FIB[5],          // 5 results
  CONFIDENCE_FLOOR:    PSI,             // 0.618 — minimum response confidence
  CONTEXT_WINDOW:      FIB[9],          // 34 turns of rolling context
  HEARTBEAT_MS:        FIB[9] * 1000,   // 34 s
  DEFAULT_MODEL:       'qwen2.5-coder-32b',
  VERSION:             '2.0.0',
};

// ── Session ───────────────────────────────────────────────────
class BuddySession {
  constructor(sessionId, userId, persona) {
    this.sessionId   = sessionId;
    this.userId      = userId;
    this.persona     = persona;
    this.history     = [];          // { role, content, ts, tokens }
    this.metadata    = {};
    this.createdAt   = Date.now();
    this.lastActiveAt = Date.now();
    this.turnCount   = 0;
    this.totalTokens = 0;
  }

  addTurn(role, content, tokens = 0) {
    this.history.push({ role, content, tokens, ts: Date.now() });
    if (this.history.length > BUDDY_CONFIG.MAX_HISTORY) this.history.shift();
    this.lastActiveAt = Date.now();
    this.turnCount++;
    this.totalTokens += tokens;
  }

  contextWindow() {
    return this.history.slice(-BUDDY_CONFIG.CONTEXT_WINDOW);
  }

  isExpired() {
    return Date.now() - this.lastActiveAt > BUDDY_CONFIG.SESSION_TTL_MS;
  }

  toJSON() {
    return {
      sessionId:    this.sessionId,
      userId:       this.userId,
      persona:      this.persona,
      turnCount:    this.turnCount,
      totalTokens:  this.totalTokens,
      createdAt:    this.createdAt,
      lastActiveAt: this.lastActiveAt,
    };
  }
}

// ── HeadyBuddy ────────────────────────────────────────────────
class HeadyBuddy extends EventEmitter {
  constructor(options = {}) {
    super();
    this.setMaxListeners(FIB[7]);

    this.config        = { ...BUDDY_CONFIG, ...options };
    this.personaRouter = new PersonaRouter();
    this.wisdomStore   = new WisdomStore();
    this.budgetTracker = new BudgetTracker();
    this._sessions     = new Map();   // sessionId → BuddySession
    this._hbTimer      = null;
    this._running      = false;

    // Register self on A2A bus
    bus.registerAgent('HeadyBuddy', (msg) => this._handleA2AMessage(msg));
  }

  // ── Lifecycle ─────────────────────────────────────────────
  start() {
    if (this._running) return;
    this._running = true;
    this._hbTimer = setInterval(() => this._housekeep(), this.config.HEARTBEAT_MS);
    this.personaRouter.start();
    this.emit('started');
  }

  stop() {
    this._running = false;
    clearInterval(this._hbTimer);
    this.personaRouter.stop();
    this.emit('stopped');
  }

  // ── Session Management ────────────────────────────────────
  createSession(userId, personaHint = null) {
    if (this._sessions.size >= this.config.MAX_SESSIONS) {
      this._evictOldestSession();
    }
    const sessionId = crypto.randomUUID();
    const persona = personaHint
      ? this.personaRouter.setPersona(personaHint)
      : this.personaRouter.autoDetect('');

    const session = new BuddySession(sessionId, userId, persona?.name || 'Architect');
    this._sessions.set(sessionId, session);
    this.emit('session:created', { sessionId, userId, persona: session.persona });
    return session;
  }

  getSession(sessionId) {
    return this._sessions.get(sessionId) || null;
  }

  endSession(sessionId) {
    const session = this._sessions.get(sessionId);
    if (session) {
      this._sessions.delete(sessionId);
      this.emit('session:ended', session.toJSON());
    }
  }

  // ── Core Chat ─────────────────────────────────────────────
  async chat(sessionId, userMessage, opts = {}) {
    const session = this._sessions.get(sessionId);
    if (!session) throw new Error(`Unknown session: ${sessionId}`);

    // Adapt persona to message
    const persona = this.personaRouter.autoDetect(userMessage);
    session.persona = persona.name;

    // Retrieve wisdom context
    const wisdom = await this._retrieveWisdom(userMessage);

    // Build prompt
    const systemPrompt = this._buildSystemPrompt(persona, wisdom, opts);
    const messages = [
      { role: 'system', content: systemPrompt },
      ...session.contextWindow(),
      { role: 'user',   content: userMessage },
    ];

    // Track budget
    const estimatedTokens = Math.round(JSON.stringify(messages).length / 4);
    const model = opts.model || this.config.DEFAULT_MODEL;

    const budgetCheck = await this.budgetTracker.checkBudget(model, estimatedTokens, estimatedTokens * 2);
    if (!budgetCheck.allowed) {
      const fallback = this.budgetTracker.cheaperAlternative(model);
      this.emit('budget:throttled', { model, fallback });
      if (!fallback) throw new Error('Budget exceeded and no fallback model available');
    }

    // Dispatch to Colab LLM runtime via A2A
    let response;
    try {
      const result = await bus.handoff('HeadyBuddy', 'HeadyBrains', {
        messages,
        model:       model,
        temperature: persona.temperature || PHI - 1,  // ~0.618
        maxTokens:   opts.maxTokens || FIB[11] * 2,   // 288
        stream:      opts.stream || false,
      }, { priority: PRIORITY.HIGH });

      response = result?.content || result?.text || String(result);
    } catch (err) {
      // Graceful degradation — Brains unreachable
      this.emit('llm:fallback', { error: err.message });
      response = this._offlineResponse(session, userMessage, persona);
    }

    // Record exchange
    session.addTurn('user',      userMessage,    estimatedTokens);
    session.addTurn('assistant', response,       Math.round(response.length / 4));

    // Store in WisdomStore
    await this.wisdomStore.store({
      content:   `${userMessage}\n\n${response}`,
      source:    `buddy:${sessionId}`,
      persona:   session.persona,
      userId:    session.userId,
    });

    // Track spend
    const inputCost  = this.budgetTracker._costFor(model, 'input',  estimatedTokens);
    const outputCost = this.budgetTracker._costFor(model, 'output', Math.round(response.length / 4));
    this.budgetTracker.recordSpend(model, estimatedTokens, Math.round(response.length / 4));

    this.emit('chat:turn', {
      sessionId,
      persona:    session.persona,
      userTokens: estimatedTokens,
      cost:       inputCost + outputCost,
    });

    return {
      response,
      persona:   session.persona,
      sessionId,
      turnCount: session.turnCount,
      model,
    };
  }

  // ── Wisdom Retrieval ──────────────────────────────────────
  async _retrieveWisdom(query) {
    const results = await this.wisdomStore.search(query, this.config.WISDOM_SEARCH_K);
    return results
      .filter(r => r.score >= this.config.CONFIDENCE_FLOOR)
      .map(r => r.content)
      .join('\n\n---\n\n');
  }

  // ── System Prompt Builder ─────────────────────────────────
  _buildSystemPrompt(persona, wisdom, opts) {
    const base = `You are HeadyBuddy, the AI companion of the Heady OS v2.0 Sacred Geometry system.
Persona: ${persona.name} — ${persona.description || ''}
Traits: ${(persona.traits || []).join(', ')}

You operate within a distributed system of 34 Sacred Geometry nodes arranged in concentric rings (center, inner, middle, outer, governance). You assist developers, architects, and operators who work with the Heady platform.

Core principles:
- PHI (${PHI.toFixed(6)}) governs all numeric constants
- Fibonacci scaling: [${[1,2,3,5,8,13,21,34,55,89].join(',')}]
- Zero placeholders — every answer is complete and production-ready
- Vector space thinking — semantic similarity over keyword matching`;

    const wisdomSection = wisdom
      ? `\n\nRelevant context from WisdomStore:\n${wisdom}`
      : '';

    const contextSection = opts.systemExtra
      ? `\n\nAdditional context:\n${opts.systemExtra}`
      : '';

    return base + wisdomSection + contextSection;
  }

  // ── Offline Response ──────────────────────────────────────
  _offlineResponse(session, message, persona) {
    return `[HeadyBuddy — Offline Mode | Persona: ${persona.name}]

I'm operating in degraded mode — the LLM runtime (HeadyBrains) is currently unreachable. Your message has been recorded in this session and will be processed when connectivity is restored.

Session: ${session.sessionId}
Turn: ${session.turnCount + 1}
Query length: ${message.length} chars

To restore full capability, ensure the Colab Runtime 2 (LLM inference, port 3302) is active and the A2A bus is connected.`;
  }

  // ── A2A Message Handler ───────────────────────────────────
  async _handleA2AMessage(msg) {
    switch (msg.payload?.action) {
      case 'chat':
        return this.chat(msg.payload.sessionId, msg.payload.message, msg.payload.opts);
      case 'create_session':
        return this.createSession(msg.payload.userId, msg.payload.persona);
      case 'end_session':
        return this.endSession(msg.payload.sessionId);
      case 'status':
        return this.status();
      default:
        return { received: true, msgId: msg.id };
    }
  }

  // ── Housekeeping ──────────────────────────────────────────
  _housekeep() {
    for (const [id, session] of this._sessions) {
      if (session.isExpired()) {
        this._sessions.delete(id);
        this.emit('session:expired', id);
      }
    }
  }

  _evictOldestSession() {
    let oldest = null;
    let oldestTs = Infinity;
    for (const [id, s] of this._sessions) {
      if (s.lastActiveAt < oldestTs) { oldestTs = s.lastActiveAt; oldest = id; }
    }
    if (oldest) this.endSession(oldest);
  }

  // ── Status ────────────────────────────────────────────────
  status() {
    return {
      running:   this._running,
      sessions:  this._sessions.size,
      maxSessions: this.config.MAX_SESSIONS,
      persona:   this.personaRouter.status(),
      wisdom:    this.wisdomStore.status(),
      budget:    this.budgetTracker.status(),
      config:    this.config,
      version:   this.config.VERSION,
    };
  }
}

module.exports = { HeadyBuddy, BuddySession, BUDDY_CONFIG };
