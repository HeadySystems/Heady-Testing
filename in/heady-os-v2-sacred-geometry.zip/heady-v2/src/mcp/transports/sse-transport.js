import express from 'express';
const PHI=1.618033988749895, FIB=[0,1,1,2,3,5,8,13,21,34,55,89];
export class SSETransport {
  constructor(gateway) { this.gateway=gateway; this.connections=new Map(); this.router=express.Router(); this._wire(); }
  _wire() {
    this.router.get('/connect',(req,res)=>{
      const cid=crypto.randomUUID?.()??Math.random().toString(36).slice(2);
      res.setHeader('Content-Type','text/event-stream'); res.setHeader('Cache-Control','no-cache'); res.setHeader('Connection','keep-alive'); res.setHeader('X-Accel-Buffering','no');
      res.write(`data: ${JSON.stringify({type:'connection',connectionId:cid,server_info:{name:'Heady MCP',version:'2.0.0'}})}\n\n`);
      this.connections.set(cid,res);
      const ping=setInterval(()=>res.write(`:ping\n\n`),Math.round(FIB[6]*PHI*1000));
      req.on('close',()=>{clearInterval(ping);this.connections.delete(cid);});
    });
    this.router.post('/message',express.json(),async(req,res)=>{
      const {method,params,id}=req.body||{};
      try {
        let result;
        if(method==='tools/list') result=this.gateway.listTools();
        else if(method==='tools/call') result=(await this.gateway.executeTool(params.name,params.arguments,req.headers['x-user-id']||'sse','SSE')).result;
        else result={error:'unknown method'};
        res.json({jsonrpc:'2.0',id,result});
      } catch(e){res.json({jsonrpc:'2.0',id,error:{code:e.code||-32603,message:e.message}});}
    });
    this.router.delete('/disconnect',(req,res)=>res.json({disconnected:true}));
  }
  getRouter() { return this.router; }
}
