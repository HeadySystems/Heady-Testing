import express from 'express';
export class HTTPTransport {
  constructor(gateway) { this.gateway=gateway; this.router=express.Router(); this._wire(); }
  _wire() {
    this.router.post('/',express.json(),async(req,res)=>{
      const {method,params,id,jsonrpc}=req.body||{};
      if(jsonrpc!=='2.0') return res.status(400).json({jsonrpc:'2.0',id:null,error:{code:-32600,message:'Invalid Request'}});
      try {
        let result;
        if(method==='initialize') result={protocolVersion:'2024-11-05',serverInfo:{name:'Heady MCP Gateway',version:'2.0.0'},capabilities:{tools:{}}};
        else if(method==='tools/list') result={tools:this.gateway.listTools()};
        else if(method==='tools/call'){ const r=await this.gateway.executeTool(params.name,params.arguments,req.headers['x-user-id']||'http','HTTP'); result={content:[{type:'text',text:JSON.stringify(r.result)}]}; }
        else return res.json({jsonrpc:'2.0',id,error:{code:-32601,message:`Method not found: ${method}`}});
        res.json({jsonrpc:'2.0',id,result});
      } catch(e){res.json({jsonrpc:'2.0',id,error:{code:e.code||-32603,message:e.message}});}
    });
  }
  getRouter() { return this.router; }
}
