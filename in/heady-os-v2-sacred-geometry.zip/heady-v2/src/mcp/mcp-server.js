import express from 'express';
import { MCPGateway } from './mcp-gateway.js';
import { SSETransport } from './transports/sse-transport.js';
import { HTTPTransport } from './transports/http-transport.js';
import { registerHeadyTools } from './heady-tools.js';
const ALLOWED_ORIGINS=['https://headymcp.com','https://headysystems.com','https://headyos.com','https://headyme.com','https://headyconnection.org'];
export function createMCPServer(config={}) {
  const gateway=new MCPGateway();
  registerHeadyTools(gateway);
  const app=express();
  app.use((req,res,next)=>{ const o=req.headers.origin||''; if(ALLOWED_ORIGINS.includes(o)){res.setHeader('Access-Control-Allow-Origin',o); res.setHeader('Access-Control-Allow-Credentials','true');} res.setHeader('Access-Control-Allow-Methods','GET,POST,DELETE,OPTIONS'); res.setHeader('Access-Control-Allow-Headers','Content-Type,Authorization,X-User-Id'); res.setHeader('X-Frame-Options','DENY'); res.setHeader('X-Content-Type-Options','nosniff'); if(req.method==='OPTIONS'){res.writeHead(204);return res.end();} next(); });
  app.use('/sse',new SSETransport(gateway).getRouter());
  app.use('/mcp',new HTTPTransport(gateway).getRouter());
  app.get('/health',(_,res)=>res.json({status:'healthy',tools:gateway.listTools().length,connections:gateway.connections.size,version:'2.0.0'}));
  app.get('/tools',(_,res)=>res.json({tools:gateway.listTools()}));
  app.get('/audit',(_,res)=>res.json({entries:gateway.getAuditLog()}));
  return { app, gateway, start(port){ const p=parseInt(process.env.MCP_PORT||String(port||8081),10); return app.listen(p,()=>process.stdout.write(JSON.stringify({timestamp:new Date().toISOString(),level:'info',service:'heady-mcp',port:p,tools:gateway.tools.size})+'\n')); } };
}
