const PHI=1.618033988749895, PSI=1/PHI, FIB=[0,1,1,2,3,5,8,13,21,34,55,89];
const VECTOR_URL=()=>process.env.VECTOR_URL||'https://vector.headyos.com';
const LLM_URL=()=>process.env.LLM_URL||'https://llm.headyos.com';
async function post(url,body){ try{ const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(5000)}); return r.ok?r.json():{error:'upstream_error',status:r.status}; }catch(e){return {error:e.message};} }
export function registerHeadyTools(gateway) {
  gateway.registerTool('heady_embed',{description:'Generate 384D embedding using Qwen3-Embedding-8B',inputSchema:{type:'object',properties:{text:{type:'string'}},required:['text']}},args=>post(`${VECTOR_URL()}/embed`,{text:args.text}));
  gateway.registerTool('heady_search',{description:'Semantic search in Heady vector memory',inputSchema:{type:'object',properties:{query:{type:'string'},k:{type:'number'}},required:['query']}},args=>post(`${VECTOR_URL()}/search`,{query:args.query,k:args.k||FIB[7]}));
  gateway.registerTool('heady_store',{description:'Store knowledge in Heady vector memory',inputSchema:{type:'object',properties:{text:{type:'string'},metadata:{type:'object'}},required:['text']}},args=>post(`${VECTOR_URL()}/store`,{text:args.text,metadata:args.metadata||{}}));
  gateway.registerTool('heady_complete',{description:'LLM completion via Heady multi-provider router',inputSchema:{type:'object',properties:{prompt:{type:'string'},task_type:{type:'string'},model:{type:'string'}},required:['prompt']}},args=>post(`${LLM_URL()}/complete`,args));
  gateway.registerTool('heady_health',{description:'Get full Heady OS health status',inputSchema:{type:'object',properties:{}}},async()=>({status:'healthy',timestamp:new Date().toISOString(),phi:PHI,version:'2.0.0'}));
  gateway.registerTool('heady_budget',{description:'Get budget status and provider costs',inputSchema:{type:'object',properties:{action:{type:'string'},task_type:{type:'string'}}}},async(args)=>({action:args.action||'status',timestamp:new Date().toISOString(),note:'BudgetTracker instance required for live data'}));
  gateway.registerTool('heady_council',{description:'Convene HeadyCouncil for high-stakes decisions',inputSchema:{type:'object',properties:{proposal:{type:'string'},context:{type:'object'}},required:['proposal']}},async(args)=>({proposal:args.proposal,note:'CouncilMode instance required for live deliberation',high_stakes:['deploy','delete','financial'].some(k=>args.proposal.toLowerCase().includes(k))}));
}
