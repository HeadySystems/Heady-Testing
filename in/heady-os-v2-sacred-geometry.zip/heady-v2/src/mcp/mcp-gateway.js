/**
 * @fileoverview MCPGateway — headymcp.com zero-trust tool execution gateway
 */
import { randomUUID, createHash } from 'crypto';
const PHI=1.618033988749895, PSI=1/PHI;
const FIB=[0,1,1,2,3,5,8,13,21,34,55,89,144,233];
const CSL={DEDUP:0.972};
const INJECTION_PATTERNS=[/('|--|;\s*DROP|UNION\s+SELECT)/i,/\.\.\//,/169\.254\.169\.254|metadata\.google/i,/file:\/\//i];
const SENSITIVE_PATTERNS=[{r:/AKIA[A-Z0-9]{16}/g,r2:'[AWS_KEY_REDACTED]'},{r:/Bearer\s+[A-Za-z0-9\-_\.]{20,}/g,r2:'[JWT_REDACTED]'},{r:/\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/g,r2:'[CARD_REDACTED]'}];

export class MCPGateway {
  constructor() { this.tools=new Map(); this.connections=new Map(); this.auditLog=[]; this.rateLimiters=new Map(); this._prevHash='0'.repeat(64); this.MAX_CONNECTIONS=FIB[8]; this.RATE_WINDOW_MS=FIB[7]*1000; this.MAX_REQ_PER_WINDOW=FIB[6]; }
  registerTool(name,schema,handler) { this.tools.set(name,{name,schema,handler}); }
  unregisterTool(name) { this.tools.delete(name); }
  listTools() { return [...this.tools.values()].map(({name,schema})=>({name,...schema})); }
  checkRateLimit(userId) {
    const now=Date.now(); let r=this.rateLimiters.get(userId)||{requests:0,accepts:0,window:now};
    if(now-r.window>this.RATE_WINDOW_MS) r={requests:0,accepts:0,window:now};
    r.requests++; const P=Math.max(0,(r.requests-2*r.accepts)/(r.requests+1));
    const allowed=Math.random()>P; if(allowed) r.accepts++;
    this.rateLimiters.set(userId,r); return {allowed,P_reject:+P.toFixed(3)};
  }
  validateInput(args) {
    const str=JSON.stringify(args||'');
    for(const p of INJECTION_PATTERNS) { if(p.test(str)) return {valid:false,blocked_patterns:[p.toString()]}; }
    return {valid:true,blocked_patterns:[]};
  }
  sanitizeOutput(result) {
    let s=typeof result==='string'?result:JSON.stringify(result);
    for(const {r,r2} of SENSITIVE_PATTERNS) s=s.replace(r,r2);
    try { return JSON.parse(s); } catch { return s; }
  }
  addAuditEntry(entry) {
    const record={...entry,id:randomUUID(),timestamp:new Date().toISOString(),prev_hash:this._prevHash};
    record.record_hash=createHash('sha256').update(JSON.stringify(record)).digest('hex');
    this._prevHash=record.record_hash;
    this.auditLog.push(record); if(this.auditLog.length>FIB[13]) this.auditLog.shift();
    return record;
  }
  async executeTool(toolName,args,userId='anon',transport='HTTP') {
    const rl=this.checkRateLimit(userId); if(!rl.allowed) throw Object.assign(new Error('Rate limited'),{code:-32603,statusCode:429});
    const tool=this.tools.get(toolName); if(!tool) throw Object.assign(new Error(`Tool not found: ${toolName}`),{code:-32601,statusCode:404});
    const iv=this.validateInput(args); if(!iv.valid) throw Object.assign(new Error('Input blocked: '+iv.blocked_patterns.join()),{code:-32602,statusCode:400});
    const start=Date.now();
    const timeoutMs=Math.round(FIB[7]*PHI*1000);
    let raw;
    try { raw=await Promise.race([tool.handler(args),new Promise((_,r)=>setTimeout(()=>r(new Error('Tool timeout')),timeoutMs))]); }
    catch(e) { this.addAuditEntry({tool:toolName,userId,status:'error',error:e.message,duration_ms:Date.now()-start,transport}); throw e; }
    const result=this.sanitizeOutput(raw);
    this.addAuditEntry({tool:toolName,userId,input_hash:createHash('sha256').update(JSON.stringify(args)).digest('hex').slice(0,16),output_hash:createHash('sha256').update(JSON.stringify(result)).digest('hex').slice(0,16),duration_ms:Date.now()-start,transport,status:'ok'});
    return {result,execution_id:randomUUID(),latency_ms:Date.now()-start,transport};
  }
  getAuditLog(limit=FIB[7]) { return this.auditLog.slice(-limit); }
  getGatewayHealth() { return {tools_registered:this.tools.size,active_connections:this.connections.size,audit_entries:this.auditLog.length,rate_limiters:this.rateLimiters.size}; }
}
