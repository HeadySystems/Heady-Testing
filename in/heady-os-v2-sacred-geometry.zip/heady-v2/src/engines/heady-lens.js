/**
 * @fileoverview HeadyLens — system-wide observation and transparency layer
 */
const PHI=1.618033988749895, PSI=1/PHI;
const FIB=[0,1,1,2,3,5,8,13,21,34,55,89,144,233];
const CSL={LOW:0.691,MEDIUM:0.809};
const SNAPSHOT_INTERVAL_MS=Math.round(PHI*FIB[8]*1000);
export class HeadyLens {
  constructor() { this.observations=[]; this.component_registry=new Map(); this._handle=null; }
  registerComponent(id,name,type,metadata={}) { this.component_registry.set(id,{id,name,type,metadata,state:'active',metrics:{},anomaly:null}); }
  unregisterComponent(id) { this.component_registry.delete(id); }
  detectAnomaly(metrics) {
    if(!metrics) return {anomaly:false};
    if(metrics.latency_ms>FIB[9]*PHI*100) return {anomaly:true,type:'high_latency',severity:'HIGH'};
    if((metrics.error_rate||0)>PSI*PSI) return {anomaly:true,type:'high_error_rate',severity:'HIGH'};
    if((metrics.coherence||1)<CSL.LOW) return {anomaly:true,type:'low_coherence',severity:'CRITICAL'};
    return {anomaly:false};
  }
  async observe(componentId,metrics) { const c=this.component_registry.get(componentId); if(c){c.metrics=metrics; c.anomaly=this.detectAnomaly(metrics); c.last_observed=new Date().toISOString();} const obs={componentId,metrics,timestamp:new Date().toISOString(),anomaly:this.detectAnomaly(metrics)}; this.observations.push(obs); if(this.observations.length>FIB[9]) this.observations.shift(); return obs; }
  async snapshot() { const snap={timestamp:new Date().toISOString(),components:[...this.component_registry.values()].map(c=>({...c}))}; this.observations.push(snap); if(this.observations.length>FIB[9]) this.observations.shift(); return snap; }
  getObservation(componentId) { return [...this.observations].reverse().find(o=>o.componentId===componentId)||null; }
  getSystemView() { const comps=[...this.component_registry.values()]; return {components:comps,recent_anomalies:comps.filter(c=>c.anomaly?.anomaly),health_summary:{total:comps.length,healthy:comps.filter(c=>!c.anomaly?.anomaly).length,anomalous:comps.filter(c=>c.anomaly?.anomaly).length}}; }
  getAnomalyReport() { return [...this.component_registry.values()].filter(c=>c.anomaly?.anomaly).sort((a,b)=>(b.anomaly.severity==='CRITICAL'?2:1)-(a.anomaly.severity==='CRITICAL'?2:1)); }
  getPerformanceTrend(componentId,samples=FIB[7]) { const obs=this.observations.filter(o=>o.componentId===componentId).slice(-samples); if(obs.length<2) return 'stable'; const first=obs[0]?.metrics?.latency_ms||0, last=obs[obs.length-1]?.metrics?.latency_ms||0; return last<first*PSI?'improving':last>first*PHI?'degrading':'stable'; }
  startAutoSnapshot() { if(!this._handle) this._handle=setInterval(()=>this.snapshot().catch(()=>{}),SNAPSHOT_INTERVAL_MS); }
  stopAutoSnapshot() { if(this._handle){clearInterval(this._handle);this._handle=null;} }
  exportTelemetry() { return {observations:this.observations,registry:[...this.component_registry.values()],exported_at:new Date().toISOString()}; }
}
