/**
 * @fileoverview CouncilMode — multi-agent deliberation for high-stakes decisions
 */
import { randomUUID } from 'crypto';
const PHI=1.618033988749895, PSI=1/PHI;
const FIB=[0,1,1,2,3,5,8,13,21,34,55,89,144,233];
const CONSENSUS_THRESHOLD=0.882, QUORUM=3;
const DEFAULT_COUNCIL=[
  {name:'HeadySoul',   domain:'ethics_governance',   vote_weight:PHI},
  {name:'MURPHY',      domain:'security',             vote_weight:1.0},
  {name:'ATLAS',       domain:'architecture',         vote_weight:1.0},
  {name:'SOPHIA',      domain:'research_wisdom',      vote_weight:1.0},
  {name:'HeadyRisks',  domain:'risk_assessment',      vote_weight:1.0},
  {name:'HeadyCheck',  domain:'quality',              vote_weight:PHI*PSI},
  {name:'HeadyAnalyze',domain:'analysis',             vote_weight:PHI*PSI},
];
const HIGH_STAKES_PATTERNS=['deploy','delete','drop','irreversible','financial','secret','credential','production'];
export class CouncilMode {
  constructor() { this.council_members=[...DEFAULT_COUNCIL]; this.active_deliberations=new Map(); this.history=[]; }
  async convene(proposal,context={}) { const d={deliberationId:randomUUID(),proposal,context,votes:[],started_at:new Date().toISOString(),status:'deliberating'}; this.active_deliberations.set(d.deliberationId,d); return d; }
  async castVote(deliberationId,memberName,vote,rationale='') { const d=this.active_deliberations.get(deliberationId); if(!d) throw new Error('Deliberation not found'); d.votes.push({memberName,vote,rationale,timestamp:new Date().toISOString()}); return d; }
  async deliberate(deliberationId) {
    const d=this.active_deliberations.get(deliberationId); if(!d) throw new Error('Deliberation not found');
    const text=d.proposal.toLowerCase();
    for(const m of this.council_members) {
      let vote='approve', rationale='Aligned with system goals';
      if(m.domain==='security'&&text.match(/public|expose|open|wildcard/)) { vote='reject'; rationale='Security concern: public exposure risk'; }
      else if(m.domain==='ethics_governance'&&!text.match(/community|equit|empower|connect|help/)) { vote='abstain'; rationale='Mission alignment unclear'; }
      else if(m.domain==='risk_assessment'&&text.match(/delete|drop|irreversible/)) { vote='reject'; rationale='High irreversibility risk'; }
      d.votes.push({memberName:m.name,vote,rationale,timestamp:new Date().toISOString()});
    }
    return d.votes;
  }
  async reach_verdict(deliberationId) {
    const d=this.active_deliberations.get(deliberationId); if(!d) throw new Error('Deliberation not found');
    if(d.votes.length<QUORUM) throw new Error(`Quorum not reached (${d.votes.length}/${QUORUM})`);
    const total_weight=this.council_members.reduce((s,m)=>s+m.vote_weight,0);
    let approve_w=0, reject_w=0;
    for(const v of d.votes) { const m=this.council_members.find(c=>c.name===v.memberName); const w=m?.vote_weight||1; if(v.vote==='approve') approve_w+=w; else if(v.vote==='reject') reject_w+=w; }
    const ratio=approve_w/total_weight;
    const verdict=ratio>=CONSENSUS_THRESHOLD?'APPROVED':ratio>=0.5?'CONDITIONAL_APPROVAL':'REJECTED';
    const result={verdict,approve_ratio:+ratio.toFixed(3),vote_summary:d.votes,conditions:verdict==='CONDITIONAL_APPROVAL'?['Requires monitoring','Review in 7 days']:[],deliberation_id:deliberationId};
    d.status='completed'; d.verdict=verdict; this.active_deliberations.delete(deliberationId);
    this.history.push({...d,...result}); if(this.history.length>FIB[7]) this.history.shift();
    return result;
  }
  async fullDeliberation(proposal,context={}) { const d=await this.convene(proposal,context); await this.deliberate(d.deliberationId); return this.reach_verdict(d.deliberationId); }
  getDeliberation(id) { return this.active_deliberations.get(id)||null; }
  getHistory() { return this.history.slice(-FIB[7]); }
  isHighStakes(proposal) { return HIGH_STAKES_PATTERNS.some(p=>proposal.toLowerCase().includes(p)); }
}
