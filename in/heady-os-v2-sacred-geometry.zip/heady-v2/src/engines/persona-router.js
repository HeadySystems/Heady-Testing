/**
 * @fileoverview PersonaRouter — stateful persona switching for HeadyBuddy
 */
const PHI=1.618033988749895, PSI=1/PHI;
const FIB=[0,1,1,2,3,5,8,13,21,34,55,89,144,233];
const CSL_HIGH=0.882;
const PERSONAS={
  heady:    { name:'Heady',    style:'technical_sovereign',  temp:PSI*PSI*PSI, context_weight:PHI, desc:'The sovereign AI architect — precise, technical, complete.' },
  buddy:    { name:'Buddy',    style:'friendly_companion',   temp:PSI,         context_weight:1.0, desc:'A warm, encouraging companion focused on your success.' },
  expert:   { name:'Expert',   style:'domain_specialist',    temp:PSI*PSI,     context_weight:PHI*PHI, desc:'A deep domain expert — rigorous, evidence-based.' },
  analyst:  { name:'Analyst',  style:'data_driven',          temp:PSI*PSI*PSI, context_weight:PHI, desc:'Data and metrics driven — pattern recognition at the core.' },
  builder:  { name:'Builder',  style:'construction_focused', temp:PSI*PSI,     context_weight:PHI, desc:'Shipping-focused — build complete systems, verify everything.' },
  guardian: { name:'Guardian', style:'security_ethics',      temp:PSI*PSI*PSI*PSI, context_weight:PHI*PHI, desc:'Security and ethics guardian — cautious, thorough.' },
  sage:     { name:'Sage',     style:'wisdom_philosophy',    temp:PSI,         context_weight:PHI*PHI*PHI, desc:'Philosophical and reflective — wisdom over speed.' },
  innovator:{ name:'Innovator',style:'creative_lateral',     temp:PSI+0.2,     context_weight:1.0, desc:'Creative and laterally thinking — finds novel paths.' },
};
const KEYWORD_MAP={
  builder  :['implement','build','create','code','function','deploy','ship'],
  guardian :['security','vulnerability','hack','inject','auth','protect','encrypt'],
  innovator:['creative','design','art','ui','visual','imagine','novel'],
  analyst  :['analyze','data','metric','measure','chart','report','pattern'],
  expert   :['research','deep dive','expert','domain','technical','advanced'],
  sage     :['why','meaning','philosophy','wisdom','reflect','understand','think'],
  heady    :['architect','system','os','vector','phi','sacred','heady'],
};
export class PersonaRouter {
  constructor() { this.currentPersona='heady'; this.personaHistory=[]; this.switchThreshold=CSL_HIGH; }
  switchTo(personaName,reason='') {
    if(!PERSONAS[personaName]) throw new Error(`Unknown persona: ${personaName}`);
    const prev=this.currentPersona; this.currentPersona=personaName;
    this.personaHistory.push({from:prev,to:personaName,reason,timestamp:new Date().toISOString()});
    if(this.personaHistory.length>FIB[7]) this.personaHistory.shift();
    return PERSONAS[personaName];
  }
  autoDetect(taskText='') {
    const text=taskText.toLowerCase(); const scores={};
    for(const [persona,kws] of Object.entries(KEYWORD_MAP)) { const hits=kws.filter(k=>text.includes(k)).length; scores[persona]=hits/kws.length; }
    const best=Object.entries(scores).sort((a,b)=>b[1]-a[1])[0];
    return { suggested:best[0]||'heady', confidence:+best[1].toFixed(3), scores };
  }
  async adaptiveSwitch(task) {
    const det=this.autoDetect(task.text||task.prompt||'');
    if(det.confidence>=(this.switchThreshold-0.5) && det.suggested!==this.currentPersona) this.switchTo(det.suggested,'auto_detected');
    return { persona:this.currentPersona, switched:det.suggested!==this.currentPersona, detection:det };
  }
  getSystemPromptForPersona(name) { const p=PERSONAS[name]||PERSONAS.heady; return `You are ${p.name}, HeadyBuddy's ${p.style} mode. ${p.desc} Operate with φ=${PHI} precision. Zero placeholders. Build complete systems.`; }
  getPersonaConfig(name) { return PERSONAS[name]||PERSONAS.heady; }
  getCurrentPersona() { return { name:this.currentPersona, ...PERSONAS[this.currentPersona] }; }
  getHistory() { return this.personaHistory.slice(-FIB[7]); }
}
