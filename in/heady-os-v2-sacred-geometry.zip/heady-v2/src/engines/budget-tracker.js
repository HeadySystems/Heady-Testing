/**
 * @fileoverview BudgetTracker — per-provider cost tracking + HeadyCoin balance
 */
const PHI=1.618033988749895, PSI=1/PHI;
const FIB=[0,1,1,2,3,5,8,13,21,34,55,89,144,233];
const PROVIDER_COSTS={ claude_opus:{input:15.00,output:75.00}, claude_sonnet:{input:3.00,output:15.00}, gpt4o:{input:2.50,output:10.00}, gpt4o_mini:{input:0.15,output:0.60}, gemini_pro:{input:1.25,output:5.00}, gemini_flash:{input:0.075,output:0.30}, groq_llama:{input:0.05,output:0.08}, perplexity_sonar:{input:1.00,output:1.00}, 'Qwen2.5-Coder-32B':{input:0.20,output:0.60}, 'DeepSeek-R1-Distill-32B':{input:0.14,output:0.28}, 'Qwen3-Embedding-8B':{input:0.02,output:0.02}, local:{input:0,output:0} };
export class BudgetTracker {
  constructor() {
    this.budget_limit_usd=parseFloat(process.env.HEADY_BUDGET_LIMIT_USD||'100');
    this.alert_threshold=parseFloat(process.env.HEADY_COST_ALERT_THRESHOLD||String(PSI));
    this.spent_usd=0; this.tokens_used={input:0,output:0,total:0};
    this.session_log=[]; this.provider_totals=new Map();
    this.headycoin_balance=FIB[10]*PHI;
  }
  recordUsage(provider, input_tokens, output_tokens, task_type='') {
    const costs=PROVIDER_COSTS[provider]||PROVIDER_COSTS.gpt4o_mini;
    const cost_usd=(input_tokens/1e6)*costs.input+(output_tokens/1e6)*costs.output;
    this.spent_usd+=cost_usd; this.tokens_used.input+=input_tokens; this.tokens_used.output+=output_tokens; this.tokens_used.total+=input_tokens+output_tokens;
    const prev=this.provider_totals.get(provider)||{cost_usd:0,tokens:0,calls:0};
    this.provider_totals.set(provider,{cost_usd:prev.cost_usd+cost_usd,tokens:prev.tokens+input_tokens+output_tokens,calls:prev.calls+1});
    const event={timestamp:new Date().toISOString(),provider,input_tokens,output_tokens,cost_usd:+cost_usd.toFixed(6),task_type,cumulative_usd:+this.spent_usd.toFixed(6)};
    this.session_log.push(event); if(this.session_log.length>FIB[11]) this.session_log.shift();
    const alert=this.spent_usd/this.budget_limit_usd>this.alert_threshold;
    return { cost_usd:+cost_usd.toFixed(6), cumulative_usd:+this.spent_usd.toFixed(4), budget_remaining:+(this.budget_limit_usd-this.spent_usd).toFixed(4), alert };
  }
  getBudgetStatus() { return { spent_usd:+this.spent_usd.toFixed(4), budget_limit_usd:this.budget_limit_usd, percent_used:+(this.spent_usd/this.budget_limit_usd*100).toFixed(2), alert_threshold_pct:+(this.alert_threshold*100).toFixed(0), remaining_usd:+(this.budget_limit_usd-this.spent_usd).toFixed(4), headycoin_balance:+this.headycoin_balance.toFixed(2) }; }
  getProviderBreakdown() { return [...this.provider_totals.entries()].sort((a,b)=>b[1].cost_usd-a[1].cost_usd).map(([p,v])=>({provider:p,...v,cost_usd:+v.cost_usd.toFixed(6)})); }
  getCheapestProvider(task_type='') { const map={code:'Qwen2.5-Coder-32B',research:'perplexity_sonar',creative:'claude_sonnet',security:'claude_sonnet',critical:'claude_sonnet',embed:'Qwen3-Embedding-8B'}; return map[task_type]||'gpt4o_mini'; }
  getSessionSummary() { return { total_cost:+this.spent_usd.toFixed(4), total_tokens:this.tokens_used.total, calls:this.session_log.length, providers_used:[...this.provider_totals.keys()] }; }
  resetDailyBudget() { this.spent_usd=0; this.tokens_used={input:0,output:0,total:0}; }
  exportLog() { return [...this.session_log]; }
}
