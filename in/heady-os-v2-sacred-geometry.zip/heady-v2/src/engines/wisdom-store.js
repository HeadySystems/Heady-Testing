/**
 * @fileoverview WisdomStore — long-term wisdom accumulation with LRU + semantic dedup
 */
import { randomUUID } from 'crypto';
const PHI=1.618033988749895, PSI=1/PHI;
const FIB=[0,1,1,2,3,5,8,13,21,34,55,89,144,233];
const DEDUP=0.972, MAX_SIZE=FIB[12];
function simple_sim(a,b) { const wa=new Set(a.split(' ')), wb=new Set(b.split(' ')); const inter=[...wa].filter(w=>wb.has(w)).length; return inter/Math.max(wa.size,wb.size,1); }
export class WisdomStore {
  constructor() { this.wisdom=new Map(); this.domain_indices=new Map(); this.access_counts=new Map(); }
  async store(domain, insight, source_task='', confidence=PSI) {
    for(const [id,e] of this.wisdom) { if(e.domain===domain && simple_sim(e.insight,insight)>=DEDUP) { e.confidence=Math.min(1,e.confidence+PSI*PSI); e.reinforcements=(e.reinforcements||0)+1; return { stored:false, id, reinforced:true }; } }
    if(this.wisdom.size>=MAX_SIZE) { let worst=null,wScore=Infinity; for(const [id,e] of this.wisdom) { const s=(this.access_counts.get(id)||0)*e.confidence; if(s<wScore){wScore=s;worst=id;} } if(worst) { this.wisdom.delete(worst); this.access_counts.delete(worst); } }
    const id=randomUUID(); const entry={id,domain,insight,source_task,confidence,created_at:new Date().toISOString(),reinforcements:0};
    this.wisdom.set(id,entry); this.access_counts.set(id,0);
    if(!this.domain_indices.has(domain)) this.domain_indices.set(domain,new Set());
    this.domain_indices.get(domain).add(id);
    return { stored:true, id, reinforced:false };
  }
  async retrieve(query_domain, k=FIB[4]) {
    const ids=[...(this.domain_indices.get(query_domain)||[])];
    const scored=ids.map(id=>{ const e=this.wisdom.get(id); const score=(this.access_counts.get(id)||0)*e.confidence; return {e,score}; }).sort((a,b)=>b.score-a.score).slice(0,k);
    return scored.map(({e})=>{ this.access_counts.set(e.id,(this.access_counts.get(e.id)||0)+1); return e; });
  }
  async search(query_text, k=FIB[4]) {
    const all=[...this.wisdom.values()].map(e=>({e,score:simple_sim(query_text,e.insight)*e.confidence})).sort((a,b)=>b.score-a.score).slice(0,k);
    return all.map(({e})=>e);
  }
  reinforce(wisdomId, delta=PSI*PSI) { const e=this.wisdom.get(wisdomId); if(e){e.confidence=Math.min(1,e.confidence+delta); e.reinforcements=(e.reinforcements||0)+1;} }
  getWisdomByDomain(domain) { return [...(this.domain_indices.get(domain)||[])].map(id=>this.wisdom.get(id)).filter(Boolean); }
  getDomainSummary() { const s={}; for(const [d,ids] of this.domain_indices){ const entries=[...ids].map(id=>this.wisdom.get(id)).filter(Boolean); s[d]={count:entries.length,avg_confidence:+(entries.reduce((x,e)=>x+e.confidence,0)/Math.max(entries.length,1)).toFixed(3),top_insight:entries.sort((a,b)=>b.confidence-a.confidence)[0]?.insight||''}; } return s; }
  getStats() { return { total:this.wisdom.size, domains:this.domain_indices.size, avg_confidence:+(([...this.wisdom.values()].reduce((s,e)=>s+e.confidence,0)/Math.max(this.wisdom.size,1))).toFixed(3), most_accessed:[...this.access_counts.entries()].sort((a,b)=>b[1]-a[1])[0]?.[0]||null }; }
  exportWisdom() { return [...this.wisdom.values()]; }
}
