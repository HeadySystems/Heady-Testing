/**
 * @fileoverview EvolutionEngine — organic agent spawn/prune/evolve using Fibonacci population targets
 */
import { randomUUID } from 'crypto';
const PHI = 1.618033988749895, PSI = 1/PHI;
const FIB = [0,1,1,2,3,5,8,13,21,34,55,89,144,233];
const GOLDEN_ANGLE = 2*Math.PI*(1-PSI);
const FIB_TARGETS = FIB.slice(0,12);
export class EvolutionEngine {
  constructor() { this.generation=0; this.population=[]; this.evolutionLog=[]; this._handle=null; this.HEARTBEAT_MS=Math.round(PHI*FIB[9]*1000); }
  async initialize(seeds=[]) {
    for(const s of seeds) this.population.push(this._newAgent(s.type||'generic',null));
    this._handle = setInterval(()=>this.heartbeat().catch(()=>{}), this.HEARTBEAT_MS);
  }
  _newAgent(type,parentId) { const idx=this.population.length; return { id:randomUUID(), type, fitness:0, age:0, successes:0, tasks:0, parentId, position_angle:idx*GOLDEN_ANGLE, created_at:Date.now() }; }
  computeFitness(agent) { const d=(Date.now()-agent.created_at)/(1000*86400)||0.01; return (agent.successes/Math.max(agent.tasks,1))*(1+(agent.successes*PSI/d))*PHI; }
  async spawn(type,parentId=null) { const a=this._newAgent(type,parentId); this.population.push(a); return a; }
  async prune(agentId) { this.population=this.population.filter(a=>a.id!==agentId); }
  async evolve() {
    const target=FIB_TARGETS[Math.min(this.generation,11)];
    if(this.population.length<target) { for(let i=this.population.length;i<target;i++) await this.spawn('generic'); }
    if(this.population.length>Math.round(target*PHI)) {
      const sorted=[...this.population].sort((a,b)=>this.computeFitness(a)-this.computeFitness(b));
      await this.prune(sorted[0].id);
    }
  }
  async heartbeat() {
    for(const a of this.population) { a.age++; a.fitness=this.computeFitness(a); a.position_angle=this.population.indexOf(a)*GOLDEN_ANGLE; }
    await this.evolve();
    this.generation++;
    this.evolutionLog.push({generation:this.generation,population:this.population.length,avg_fitness:this.getPopulationStats().avg_fitness,timestamp:new Date().toISOString()});
    if(this.evolutionLog.length>FIB[7]) this.evolutionLog.shift();
  }
  getGeneration() { return this.generation; }
  getPopulationStats() { const n=this.population.length||1; return { size:n, avg_fitness:+(this.population.reduce((s,a)=>s+a.fitness,0)/n).toFixed(4), top_performer:this.population.sort((a,b)=>b.fitness-a.fitness)[0]||null, generation:this.generation, fib_target:FIB_TARGETS[Math.min(this.generation,11)] }; }
  exportGenePool() { return this.population.map(({id,type,fitness,age,position_angle})=>({id,type,fitness:+fitness.toFixed(4),age,position_angle:+position_angle.toFixed(4)})); }
  stop() { if(this._handle) clearInterval(this._handle); }
}
