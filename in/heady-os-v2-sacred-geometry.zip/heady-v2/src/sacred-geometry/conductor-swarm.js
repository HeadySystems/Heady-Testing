/**
 * @fileoverview ConductorSwarm — coordinates all 34 Sacred Geometry nodes
 * Uses golden-angle task distribution for optimal load balancing
 */
import { NodeRegistryV2 } from './node-registry-v2.js';
import { PHI, PSI, FIB, GOLDEN_ANGLE, CSL_THRESHOLDS } from './node-base.js';

export class ConductorSwarm {
  constructor() {
    this.registry = new NodeRegistryV2();
    this._booted = false;
    this._taskCount = 0;
    this._heartbeatHandle = null;
    this.HEARTBEAT_MS = Math.round(PHI * FIB[7] * 1000); // ~34s
  }

  async boot() {
    await this.registry.activateAll();
    this._booted = true;
    this._heartbeatHandle = setInterval(() => this.heartbeat(), this.HEARTBEAT_MS);
    return { booted: true, nodes: this.registry.allNodes.size, coherence: this.registry.getSystemCoherence() };
  }

  async shutdown() {
    if (this._heartbeatHandle) clearInterval(this._heartbeatHandle);
    await this.registry.deactivateAll();
    this._booted = false;
  }

  async route(task) {
    if (!this._booted) throw new Error('ConductorSwarm not booted');
    const start = Date.now();
    this._taskCount++;

    // Stage 1: context assembly via HeadyBrains
    const brainsNode = this.registry.getNode('HeadyBrains');
    const ctx = brainsNode ? await brainsNode.process(task) : { result: {} };

    // Stage 2: classify + route via HeadyConductor
    const condNode = this.registry.getNode('HeadyConductor');
    const routing = condNode ? await condNode.process({ ...task, context: ctx.result }) : { result: { routed_to: 'BRIDGE' } };

    // Stage 3: execute on target node
    const targetName = routing.result?.routed_to || 'BRIDGE';
    const targetNode = this.registry.getNode(targetName);
    let execResult = { result: { fallback: true, message: `Node ${targetName} not found` } };
    if (targetNode && targetNode.state === 'active') {
      try { execResult = await targetNode.process(task); }
      catch (e) {
        const fb = this.registry.getNode(routing.result?.fallback || 'BUILDER');
        if (fb?.state === 'active') execResult = await fb.process(task);
      }
    }

    // Stage 4: quality gate
    const checkNode = this.registry.getNode('HeadyCheck');
    const quality = checkNode ? await checkNode.process({ result: execResult.result }) : { result: { passed: true } };

    // Stage 5: pattern capture
    const patNode = this.registry.getNode('HeadyPatterns');
    if (patNode) patNode.process({ task_type: routing.result?.domain, latency_ms: Date.now()-start, success: quality.result?.passed }).catch(()=>{});

    return {
      result: execResult.result,
      path: ['HeadyBrains','HeadyConductor', targetName,'HeadyCheck'],
      domain: routing.result?.domain,
      quality_score: quality.result?.score,
      latency_ms: Date.now() - start,
      coherence: this.registry.getSystemCoherence(),
    };
  }

  async broadcastToRing(ring, task) {
    const nodes = this.registry.getByRing(ring).filter(n=>n.state==='active');
    return Promise.all(nodes.map(n => n.process(task).catch(e=>({ node:n.name, error:e.message }))));
  }

  async phi_concurrent(tasks) {
    const allNodes = this.registry.getHealthyNodes();
    if (!allNodes.length) throw new Error('No healthy nodes available');
    return Promise.all(tasks.map((task, i) => {
      const nodeIndex = Math.floor(i * PHI) % allNodes.length;
      return allNodes[nodeIndex].process(task).catch(e=>({ error:e.message, task_index:i }));
    }));
  }

  async heartbeat() {
    const health = this.registry.getFullHealth();
    const degraded = [...this.registry.allNodes.values()].filter(n=>n.state==='degraded');
    for (const node of degraded) {
      node.coherenceScore = Math.min(1, node.coherenceScore + PSI * 0.1);
      if (node.coherenceScore >= CSL_THRESHOLDS.MEDIUM) await node.activate();
    }
    return health;
  }

  getSwarmTopology() { return { nodes: this.registry.getTopology(), total: this.registry.allNodes.size, system_coherence: this.registry.getSystemCoherence(), golden_angle_rad: GOLDEN_ANGLE }; }
  getSwarmHealth() { const h = this.registry.getFullHealth(); const nodes = [...this.registry.allNodes.values()]; return { nodes_total: nodes.length, active: nodes.filter(n=>n.state==='active').length, degraded: nodes.filter(n=>n.state==='degraded').length, dormant: nodes.filter(n=>n.state==='dormant').length, system_coherence: h.system_coherence, tasks_routed: this._taskCount }; }
}
