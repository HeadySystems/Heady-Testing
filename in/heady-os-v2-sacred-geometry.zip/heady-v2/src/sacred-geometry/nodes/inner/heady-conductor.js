/**
 * @fileoverview HeadyConductor — INNER ring node (index 1).
 * Central orchestration node that classifies tasks and routes them
 * to the appropriate specialized node using a routing matrix.
 * @module sacred-geometry/nodes/inner/heady-conductor
 */

import { SacredGeometryNode, PHI, PSI, FIB } from '../../node-base.js';

/**
 * Routing matrix mapping task types to target node names.
 * @type {Record<string, string>}
 */
const ROUTING_MATRIX = {
  code: 'JULES',
  review: 'OBSERVER',
  security: 'MURPHY',
  architecture: 'ATLAS',
  research: 'SOPHIA',
  docs: 'HeadyCodex',
  creative: 'MUSE',
  embed: 'HeadyEmbed',
  quick: 'BRIDGE',
  predict: 'PYTHIA',
  build: 'BUILDER',
  encrypt: 'CIPHER',
  monitor: 'LENS',
  cleanup: 'JANITOR',
  innovate: 'NOVA',
  risk: 'HeadyRisks',
  analyze: 'HeadyAnalyze',
  orchestrate: 'HeadyOrchestrator',
  maintain: 'HeadyMaintenance'
};

/**
 * Keyword → type mapping for auto-classification from task text.
 * @type {Record<string, string>}
 */
const KEYWORD_TYPE_MAP = {
  'implement': 'code', 'function': 'code', 'class': 'code', 'code': 'code', 'write': 'code',
  'review': 'review', 'check': 'review', 'lint': 'review',
  'security': 'security', 'vulnerability': 'security', 'audit': 'security',
  'architecture': 'architecture', 'design': 'architecture', 'diagram': 'architecture',
  'research': 'research', 'search': 'research', 'find': 'research',
  'document': 'docs', 'readme': 'docs', 'jsdoc': 'docs',
  'creative': 'creative', 'ui': 'creative', 'ux': 'creative',
  'embed': 'embed', 'vector': 'embed', 'embedding': 'embed',
  'translate': 'quick', 'convert': 'quick', 'format': 'quick',
  'predict': 'predict', 'forecast': 'predict', 'simulate': 'predict',
  'build': 'build', 'scaffold': 'build', 'generate': 'build',
  'encrypt': 'encrypt', 'decrypt': 'encrypt', 'cipher': 'encrypt',
  'risk': 'risk', 'assess': 'risk', 'danger': 'risk',
  'analyze': 'analyze', 'deep': 'analyze', 'investigate': 'analyze'
};

/**
 * HeadyConductor is the central routing node on the INNER ring.
 * It classifies incoming tasks by type and routes them to the optimal
 * specialized node using golden-ratio weighted confidence scoring.
 */
class HeadyConductor extends SacredGeometryNode {
  constructor() {
    super({
      name: 'HeadyConductor',
      ring: 'inner',
      ringIndex: 1,
      domain: 'orchestration',
      capabilities: ['classify', 'route', 'dispatch', 'fallback'],
      poolTier: 'hot'
    });

    /** @type {Record<string, string>} The routing matrix */
    this.routingMatrix = { ...ROUTING_MATRIX };
  }

  /**
   * Classify and route a task to the appropriate node.
   * @param {Object} task - The task to route
   * @param {string} [task.type] - Explicit type override
   * @param {string} [task.text] - Task text for auto-classification
   * @returns {Promise<Object>} Routing decision
   */
  async _execute(task) {
    const detectedType = task.type || this._classifyFromText(task.text || task.description || '');
    const targetNode = this.routingMatrix[detectedType] || 'BUILDER';
    const confidence = task.type ? PSI + 0.2 : PSI + 0.1;

    // Determine pool tier based on target ring
    const poolTier = this._inferPoolTier(targetNode);

    return {
      routed_to: targetNode,
      domain: detectedType,
      poolTier,
      confidence: Math.min(1, confidence),
      fallback: 'BUILDER',
      classification: detectedType,
      timestamp: new Date().toISOString()
    };
  }

  /**
   * Classify task type from text using keyword matching.
   * @param {string} text - Task text
   * @returns {string} Detected type
   * @private
   */
  _classifyFromText(text) {
    const lower = text.toLowerCase();
    const tokens = lower.split(/\s+/);
    const scores = {};

    for (const token of tokens) {
      const type = KEYWORD_TYPE_MAP[token];
      if (type) {
        scores[type] = (scores[type] || 0) + 1;
      }
    }

    // Return highest-scoring type, or 'code' as default
    let bestType = 'code';
    let bestScore = 0;
    for (const [type, score] of Object.entries(scores)) {
      if (score > bestScore) {
        bestScore = score;
        bestType = type;
      }
    }

    return bestType;
  }

  /**
   * Infer pool tier from target node name.
   * @param {string} nodeName - Target node
   * @returns {string} Pool tier
   * @private
   */
  _inferPoolTier(nodeName) {
    const hotNodes = new Set(['HeadySoul', 'HeadyBrains', 'HeadyConductor', 'HeadyVinci']);
    const coldNodes = new Set(['PYTHIA', 'HeadyMC', 'HeadyResearch']);
    if (hotNodes.has(nodeName)) return 'hot';
    if (coldNodes.has(nodeName)) return 'cold';
    return 'warm';
  }
}

export { HeadyConductor, ROUTING_MATRIX, KEYWORD_TYPE_MAP };
export default HeadyConductor;
