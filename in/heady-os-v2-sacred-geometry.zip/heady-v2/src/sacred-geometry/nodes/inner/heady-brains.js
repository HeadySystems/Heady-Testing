import { SacredGeometryNode, PHI, PSI, FIB } from '../../node-base.js';
export class HeadyBrainsNode extends SacredGeometryNode {
  constructor() { super({ name:'HeadyBrains', ring:'inner', ringIndex:0, domain:'context_assembly', capabilities:['context_gather','token_estimate','semantic_search'], poolTier:'hot' }); }
  async _execute(task) {
    const text = task.text || task.prompt || JSON.stringify(task);
    const token_estimate = Math.round(text.length / 4 * PHI);
    const sources = ['vector_memory'];
    if (task.include_history !== false) sources.push('task_history');
    if (task.include_wisdom !== false) sources.push('wisdom_store');
    return { context_gathered: true, sources, token_estimate, relevant_nodes: ['HeadyConductor','HeadyVinci'], vector_url: process.env.VECTOR_URL||'https://vector.headyos.com', context_window_remaining: Math.round(8192*PHI*PHI - token_estimate) };
  }
}
