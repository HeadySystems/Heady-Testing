/**
 * @fileoverview Sacred Geometry Node Base Class — Heady OS v2.0
 * All 34 nodes extend this class. Positions use golden-angle placement.
 * © 2026 HeadySystems Inc. — Sacred Geometry v4.0
 */
import { randomUUID } from 'crypto';

export const PHI   = 1.618033988749895;
export const PSI   = 1 / PHI;                                  // ≈ 0.618
export const GOLDEN_ANGLE = 2 * Math.PI * (1 - PSI);           // ≈ 2.3999 rad (137.508°)
export const FIB   = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987];
export const CSL_THRESHOLDS = {
  MINIMUM : 0.500,
  LOW     : 0.691,
  MEDIUM  : 0.809,
  HIGH    : 0.882,
  CRITICAL: 0.927,
  DEDUP   : 0.972,
};

const RING_RADII = {
  center    : 0,
  inner     : FIB[5] * PHI,    // ≈ 13.0
  middle    : FIB[7] * PHI,    // ≈ 34.0
  outer     : FIB[9] * PHI,    // ≈ 89.0
  governance: FIB[10] * PHI,   // ≈ 144.0
};

/**
 * @class SacredGeometryNode
 * Base for all 34 Sacred Geometry nodes. Each has a 3D golden-angle position.
 */
export class SacredGeometryNode {
  /**
   * @param {object} opts
   * @param {string} opts.name - Node name e.g. 'JULES'
   * @param {'center'|'inner'|'middle'|'outer'|'governance'} opts.ring
   * @param {number} opts.ringIndex - Zero-based index within ring
   * @param {string} opts.domain - Functional domain
   * @param {string[]} [opts.capabilities]
   * @param {'hot'|'warm'|'cold'} [opts.poolTier]
   */
  constructor({ name, ring, ringIndex, domain, capabilities = [], poolTier = 'warm' }) {
    this.id           = randomUUID();
    this.name         = name;
    this.ring         = ring;
    this.ringIndex    = ringIndex;
    this.domain       = domain;
    this.capabilities = capabilities;
    this.poolTier     = poolTier;

    // Sacred Geometry 3D position via golden-angle spiral
    this.angle  = ringIndex * GOLDEN_ANGLE;
    this.radius = RING_RADII[ring] ?? FIB[6] * PHI;
    this.position = {
      x: this.radius * Math.cos(this.angle),
      y: this.radius * Math.sin(this.angle),
      z: ring === 'center' ? 0 : Math.sin(this.angle * PHI) * this.radius * PSI,
    };

    this.state          = 'dormant';   // dormant|active|processing|degraded|healing
    this.coherenceScore = 1.0;
    this.embedding      = new Float32Array(384);
    this.metrics        = { tasks: 0, successes: 0, failures: 0, avgLatencyMs: 0, lastActive: null };
    this._startTime     = Date.now();
  }

  /** Activate node — transition dormant→active */
  async activate() {
    this.state = 'active';
    this.metrics.lastActive = new Date().toISOString();
  }

  /** Deactivate node — transition to dormant */
  async deactivate() {
    this.state = 'dormant';
  }

  /**
   * Process a task through this node.
   * @param {object} task
   * @returns {Promise<{node:string, result:any, latency_ms:number}>}
   */
  async process(task) {
    if (this.state !== 'active') {
      throw new Error(`Node ${this.name} is not active (state=${this.state})`);
    }
    this.state = 'processing';
    const start = Date.now();
    try {
      const result = await this._execute(task);
      const latency = Date.now() - start;
      this.metrics.tasks++;
      this.metrics.successes++;
      this.metrics.avgLatencyMs =
        (this.metrics.avgLatencyMs * (this.metrics.tasks - 1) + latency) / this.metrics.tasks;
      this.state = 'active';
      return { node: this.name, result, latency_ms: latency };
    } catch (err) {
      this.metrics.tasks++;
      this.metrics.failures++;
      this.state = 'degraded';
      throw err;
    }
  }

  /**
   * Override in each node subclass.
   * @param {object} task
   * @returns {Promise<any>}
   */
  async _execute(task) { // eslint-disable-line no-unused-vars
    throw new Error(`${this.name}._execute() must be implemented`);
  }

  /**
   * Update coherence score; marks node degraded if below MEDIUM threshold.
   * @param {number} score - Cosine similarity 0–1
   */
  updateCoherence(score) {
    this.coherenceScore = score;
    if (score < CSL_THRESHOLDS.MEDIUM && this.state === 'active') {
      this.state = 'degraded';
    }
  }

  /** @returns {{x,y,z,angle,radius,ring}} */
  getPosition() {
    return { ...this.position, angle: this.angle, radius: this.radius, ring: this.ring };
  }

  /** @returns {object} Full health snapshot */
  getHealth() {
    return {
      id             : this.id,
      name           : this.name,
      ring           : this.ring,
      domain         : this.domain,
      state          : this.state,
      coherenceScore : this.coherenceScore,
      metrics        : { ...this.metrics },
      position       : this.getPosition(),
      uptime_ms      : Date.now() - this._startTime,
    };
  }

  toJSON() {
    return {
      name           : this.name,
      ring           : this.ring,
      domain         : this.domain,
      state          : this.state,
      coherenceScore : this.coherenceScore,
      position       : this.position,
    };
  }
}
