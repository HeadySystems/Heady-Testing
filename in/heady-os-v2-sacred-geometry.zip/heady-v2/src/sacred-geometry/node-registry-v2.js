/**
 * @fileoverview NodeRegistryV2 — manages all 34 Sacred Geometry nodes in their ring topology
 */
import { PHI, PSI, FIB, CSL_THRESHOLDS } from './node-base.js';
import { HeadySoulNode } from './nodes/center/heady-soul.js';
import { HeadyBrainsNode } from './nodes/inner/heady-brains.js';
import { HeadyConductorNode } from './nodes/inner/heady-conductor-node.js';
import { HeadyVinciNode } from './nodes/inner/heady-vinci.js';
import { JULESNode } from './nodes/middle/jules.js';
import { BUILDERNode } from './nodes/middle/builder.js';
import { OBSERVERNode } from './nodes/middle/observer.js';
import { MURPHYNode } from './nodes/middle/murphy.js';
import { ATLASNode } from './nodes/middle/atlas.js';
import { PYTHIANode } from './nodes/middle/pythia.js';
import { BRIDGENode } from './nodes/middle/bridge.js';
import { MUSENode } from './nodes/middle/muse.js';
import { SENTINELNode } from './nodes/outer/sentinel.js';
import { NOVANode } from './nodes/outer/nova.js';
import { JANITORNode } from './nodes/outer/janitor.js';
import { SOPHIANode } from './nodes/outer/sophia.js';
import { CIPHERNode } from './nodes/outer/cipher.js';
import { LENSNode } from './nodes/outer/lens.js';
import { HeadyCheckNode } from './nodes/outer/heady-check.js';
import { HeadyAssureNode } from './nodes/outer/heady-assure.js';
import { HeadyAwareNode } from './nodes/outer/heady-aware.js';
import { HeadyPatternsNode } from './nodes/outer/heady-patterns.js';
import { HeadyMCNode } from './nodes/outer/heady-mc.js';
import { HeadyRisksNode } from './nodes/outer/heady-risks.js';
import { HeadyAnalyzeNode } from './nodes/outer/heady-analyze.js';
import { HeadyCodexNode } from './nodes/governance/heady-codex.js';
import { HeadyCoderNode } from './nodes/governance/heady-coder.js';
import { HeadyOrchestratorNode } from './nodes/governance/heady-orchestrator.js';
import { HeadyMaintenanceNode } from './nodes/governance/heady-maintenance.js';
import { HeadyMaidNode } from './nodes/governance/heady-maid.js';
import { HeadyAutobiographerNode } from './nodes/governance/heady-autobiographer.js';
import { HeadyResearchNode } from './nodes/governance/heady-research.js';
import { HeadyEmbedNode } from './nodes/governance/heady-embed.js';
import { HeadyManagerNode } from './nodes/governance/heady-manager.js';

const ACTIVATION_ORDER = ['inner','middle','outer','governance','center'];

export class NodeRegistryV2 {
  constructor() {
    this.rings = { center: new Map(), inner: new Map(), middle: new Map(), outer: new Map(), governance: new Map() };
    this.allNodes = new Map();
    this._buildNodes();
  }

  _buildNodes() {
    const nodes = [
      new HeadySoulNode(),
      new HeadyBrainsNode(), new HeadyConductorNode(), new HeadyVinciNode(),
      new JULESNode(), new BUILDERNode(), new OBSERVERNode(), new MURPHYNode(),
      new ATLASNode(), new PYTHIANode(), new BRIDGENode(), new MUSENode(),
      new SENTINELNode(), new NOVANode(), new JANITORNode(), new SOPHIANode(),
      new CIPHERNode(), new LENSNode(), new HeadyCheckNode(), new HeadyAssureNode(),
      new HeadyAwareNode(), new HeadyPatternsNode(), new HeadyMCNode(),
      new HeadyRisksNode(), new HeadyAnalyzeNode(),
      new HeadyCodexNode(), new HeadyCoderNode(), new HeadyOrchestratorNode(),
      new HeadyMaintenanceNode(), new HeadyMaidNode(), new HeadyAutobiographerNode(),
      new HeadyResearchNode(), new HeadyEmbedNode(), new HeadyManagerNode(),
    ];
    for (const n of nodes) { this.rings[n.ring].set(n.name, n); this.allNodes.set(n.name, n); }
  }

  register(node) { this.rings[node.ring]?.set(node.name, node); this.allNodes.set(node.name, node); }
  getNode(name) { return this.allNodes.get(name) || null; }
  getByRing(ring) { return [...(this.rings[ring]?.values()||[])]; }
  getByDomain(domain) { return [...this.allNodes.values()].filter(n=>n.domain===domain); }
  getHealthyNodes() { return [...this.allNodes.values()].filter(n=>n.state==='active'&&n.coherenceScore>=CSL_THRESHOLDS.MEDIUM); }
  getTopology() { return [...this.allNodes.values()].map(n=>n.toJSON()); }

  async activateAll() {
    for (const ring of ACTIVATION_ORDER) {
      await Promise.all([...this.rings[ring].values()].map(n=>n.activate()));
    }
  }

  async deactivateAll() {
    for (const ring of [...ACTIVATION_ORDER].reverse()) {
      for (const n of this.rings[ring].values()) await n.deactivate();
    }
  }

  getSystemCoherence() {
    const active = [...this.allNodes.values()].filter(n=>n.state!=='dormant');
    if (!active.length) return 1;
    return +(active.reduce((s,n)=>s+n.coherenceScore,0)/active.length).toFixed(4);
  }

  getRingHealth(ring) {
    const nodes = this.getByRing(ring);
    return { ring, total:nodes.length, active:nodes.filter(n=>n.state==='active').length, degraded:nodes.filter(n=>n.state==='degraded').length, avg_coherence:+(nodes.reduce((s,n)=>s+n.coherenceScore,0)/Math.max(nodes.length,1)).toFixed(4) };
  }

  getFullHealth() {
    return { total_nodes:this.allNodes.size, system_coherence:this.getSystemCoherence(), rings:Object.keys(this.rings).map(r=>this.getRingHealth(r)) };
  }
}
