/**
 * Heady OS v2.0 — Main Server
 * Wires: Sacred Geometry, Engines, MCP Gateway, A2A Bus, HeadyBuddy, Alive, Conductor Swarm
 * Ports: 8080 (main) · 8081 (MCP) · 8082 (Buddy)
 */
'use strict';

const express     = require('express');
const cors        = require('cors');
const http        = require('http');
const path        = require('path');
const crypto      = require('crypto');

// ── PHI Constants ──────────────────────────────────────────────
const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const FIB  = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987];

// ── Config ─────────────────────────────────────────────────────
const PORT      = parseInt(process.env.PORT     || '8080', 10);
const MCP_PORT  = parseInt(process.env.MCP_PORT || '8081', 10);
const BUDDY_PORT= parseInt(process.env.BUDDY_PORT|| '8082', 10);
const NODE_ENV  = process.env.NODE_ENV || 'development';
const LOG_LEVEL = process.env.LOG_LEVEL || 'info';

const ALLOWED_ORIGINS = (process.env.CORS_ORIGINS ||
  'https://headyme.com,https://headysystems.com,https://headyconnection.org,https://headyos.com,https://headymcp.com,https://headybuddy.org'
).split(',').map(s => s.trim());

// ── Module Imports ─────────────────────────────────────────────
const { bootHeadyOS, shutdownHeadyOS }  = require('./sacred-geometry/boot-heady-os');
const { ConductorSwarm }                = require('./sacred-geometry/conductor-swarm');
const { NodeRegistryV2 }               = require('./sacred-geometry/node-registry-v2');
const { TOPOLOGY_MANIFEST }            = require('./sacred-geometry/index');
const engines                          = require('./engines/index');
const { createMCPServer }              = require('./mcp/mcp-server');
const { bus }                          = require('./a2a/a2a-protocol');
const { bridge }                       = require('./a2a/a2ui-bridge');
const { createBuddyServer }            = require('./buddy/buddy-server');

// ── Logger ─────────────────────────────────────────────────────
function log(level, msg, data = '') {
  const ts = new Date().toISOString();
  const levels = { debug: 0, info: 1, warn: 2, error: 3 };
  if (levels[level] >= (levels[LOG_LEVEL] || 1)) {
    const line = `[${ts}] [${level.toUpperCase()}] ${msg}${data ? ' ' + JSON.stringify(data) : ''}`;
    if (level === 'error') console.error(line);
    else console.log(line);
  }
}

// ── Main Application ───────────────────────────────────────────
const app = express();
app.use(express.json({ limit: `${FIB[9]}mb` }));    // 34 MB
app.use(cors({ origin: ALLOWED_ORIGINS, credentials: true }));
app.use((req, _res, next) => {
  req.requestId = crypto.randomUUID();
  log('debug', `${req.method} ${req.path}`, { id: req.requestId });
  next();
});

// ── Static UI ──────────────────────────────────────────────────
app.use('/', express.static(path.join(__dirname, '..', 'ui-v2')));

// ── Health ─────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status:  'ok',
    service: 'heady-os-v2',
    version: '2.0.0',
    uptime:  process.uptime(),
    ts:      Date.now(),
    env:     NODE_ENV,
  });
});

// ── System Status ──────────────────────────────────────────────
app.get('/api/status', async (req, res) => {
  try {
    const [conductorStatus, busStatus] = await Promise.allSettled([
      Promise.resolve(conductor?.status?.() || {}),
      Promise.resolve(bus.status()),
    ]);
    res.json({
      sacred:    TOPOLOGY_MANIFEST,
      conductor: conductorStatus.value || {},
      bus:       busStatus.value || {},
      engines:   {
        evolution: engines.evolutionEngine?.status?.() || {},
        wisdom:    engines.wisdomStore?.status?.() || {},
        budget:    engines.budgetTracker?.status?.() || {},
        council:   engines.councilMode?.status?.() || {},
      },
      ts: Date.now(),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── SSE Event Stream (A2UI Bridge) ────────────────────────────
app.get('/api/events', (req, res) => {
  bridge.connect(req, res);
});

// ── Boot / Reboot / Shutdown ───────────────────────────────────
app.post('/api/boot',     async (req, res) => {
  try {
    await bootHeadyOS({ bridge });
    res.json({ booted: true, ts: Date.now() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/reboot', async (req, res) => {
  try {
    await shutdownHeadyOS();
    setTimeout(async () => { await bootHeadyOS({ bridge }); }, FIB[7] * 100);
    res.json({ rebooting: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/shutdown', async (req, res) => {
  res.json({ shutting_down: true });
  setTimeout(async () => {
    await shutdownHeadyOS();
    process.exit(0);
  }, FIB[5] * 100);
});

// ── Colab Runtime Health Proxy ────────────────────────────────
const https_fetch = require('node-fetch').default || require('node-fetch');
app.get('/api/colab/:runtime/health', async (req, res) => {
  const portMap = { '1': 3301, '2': 3302, '3': 3303 };
  const port    = portMap[req.params.runtime];
  if (!port) return res.status(400).json({ error: 'Unknown runtime' });
  const colabBase = process.env[`COLAB_URL_${req.params.runtime}`] ||
                    `http://localhost:${port}`;
  try {
    const r   = await https_fetch(`${colabBase}/health`, { timeout: 3000 });
    const txt = await r.text();
    res.status(r.status).send(txt);
  } catch (err) {
    res.status(503).json({ error: 'Colab unreachable', detail: err.message });
  }
});

// ── A2A Bus REST API ──────────────────────────────────────────
app.get('/api/a2a/status',  (req, res) => res.json(bus.status()));
app.get('/api/a2a/audit',   (req, res) => res.json({ audit: bus.audit.tail(FIB[8]) }));
app.post('/api/a2a/send',   async (req, res) => {
  const { from, to, payload, opts } = req.body;
  try {
    const r = await bus.send(from, to, payload, opts);
    res.json(r);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Conductor Dispatch ────────────────────────────────────────
app.post('/api/conductor/route', async (req, res) => {
  const { task, context } = req.body;
  try {
    const result = await conductor.route(task, context);
    res.json({ result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── Node Topology ─────────────────────────────────────────────
app.get('/api/nodes', (req, res) => res.json({ nodes: TOPOLOGY_MANIFEST }));

// ── Engines API ───────────────────────────────────────────────
app.post('/api/engines/council', async (req, res) => {
  const { topic, context } = req.body;
  try {
    const result = await engines.councilMode.deliberate(topic, context);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/engines/budget',   (req, res) => res.json(engines.budgetTracker.status()));
app.get('/api/engines/wisdom',   (req, res) => res.json(engines.wisdomStore.status()));
app.get('/api/engines/evolution',(req, res) => res.json(engines.evolutionEngine.status()));

// ── 404 ──────────────────────────────────────────────────────
app.use((_req, res) => res.status(404).json({ error: 'Not Found' }));

// ── Error Handler ──────────────────────────────────────────────
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  log('error', err.message, { stack: err.stack?.slice(0, 200) });
  res.status(500).json({ error: err.message });
});

// ── Globals ────────────────────────────────────────────────────
let conductor;
let mcpApp;
let buddyApp;

// ═══════════════════════════════════════════════════════════════
// STARTUP
// ═══════════════════════════════════════════════════════════════
async function start() {
  log('info', '════════════════════════════════════════');
  log('info', '  Heady OS v2.0 — Sacred Geometry v4.0 ');
  log('info', `  PHI = ${PHI.toFixed(9)}`);
  log('info', '════════════════════════════════════════');

  // 1. Start A2A bus
  bus.start();
  log('info', 'A2A protocol bus started');

  // 2. Boot Sacred Geometry nodes
  await bootHeadyOS({ bridge, quiet: false });
  log('info', `34 Sacred Geometry nodes activated`);

  // 3. Start Conductor Swarm
  conductor = new ConductorSwarm();
  conductor.start();
  log('info', 'ConductorSwarm started');

  // 4. Start Engines
  engines.evolutionEngine.start();
  engines.councilMode.start();
  log('info', 'Engines started (Evolution, Council, Persona, Wisdom, Budget, Lens)');

  // 5. Main server
  const mainServer = http.createServer(app);
  await new Promise((resolve, reject) => {
    mainServer.listen(PORT, err => err ? reject(err) : resolve());
  });
  log('info', `Main server listening on :${PORT}`);

  // 6. MCP Gateway
  try {
    const { app: mcpExpress } = createMCPServer();
    mcpApp = http.createServer(mcpExpress);
    await new Promise((resolve, reject) => {
      mcpApp.listen(MCP_PORT, err => err ? reject(err) : resolve());
    });
    log('info', `MCP gateway listening on :${MCP_PORT}`);
  } catch (err) {
    log('warn', `MCP gateway failed to start: ${err.message}`);
  }

  // 7. HeadyBuddy server
  try {
    const { app: buddyExpress } = createBuddyServer();
    buddyApp = http.createServer(buddyExpress);
    await new Promise((resolve, reject) => {
      buddyApp.listen(BUDDY_PORT, err => err ? reject(err) : resolve());
    });
    log('info', `HeadyBuddy listening on :${BUDDY_PORT}`);
  } catch (err) {
    log('warn', `HeadyBuddy failed to start: ${err.message}`);
  }

  // 8. Emit topology snapshot to UI
  bridge.emitTopology(TOPOLOGY_MANIFEST);
  bridge.emitBootProgress(8, { message: 'Alive heartbeat active' });

  log('info', '════════════════════════════════════════');
  log('info', '  Heady OS v2.0 — FULLY OPERATIONAL     ');
  log('info', `  Main:  http://localhost:${PORT}`);
  log('info', `  MCP:   http://localhost:${MCP_PORT}`);
  log('info', `  Buddy: http://localhost:${BUDDY_PORT}`);
  log('info', '════════════════════════════════════════');
}

// ── Graceful Shutdown ──────────────────────────────────────────
async function shutdown(signal) {
  log('info', `Received ${signal} — graceful shutdown initiated`);
  try {
    await shutdownHeadyOS();
    bus.stop();
    conductor?.stop?.();
    engines.evolutionEngine.stop?.();
    log('info', 'Shutdown complete');
  } catch (err) {
    log('error', `Shutdown error: ${err.message}`);
  } finally {
    process.exit(0);
  }
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('uncaughtException',  err => { log('error', `UncaughtException: ${err.message}`); });
process.on('unhandledRejection', reason => { log('error', `UnhandledRejection: ${reason}`); });

start().catch(err => { log('error', `Startup failed: ${err.message}`); process.exit(1); });

module.exports = { app };
