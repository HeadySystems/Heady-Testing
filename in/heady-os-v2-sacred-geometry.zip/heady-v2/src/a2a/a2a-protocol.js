/**
 * Heady OS v2.0 — A2A Protocol (Agent-to-Agent)
 * Sacred Geometry v4.0 — PHI-scaled message routing
 */
'use strict';

const { EventEmitter } = require('events');
const crypto = require('crypto');

// ── PHI Constants ──────────────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const FIB = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987];

const A2A_CONFIG = {
  MAX_MESSAGE_SIZE:   FIB[13] * 1024,       // 233 KB
  MAX_QUEUE_DEPTH:    FIB[10],              // 89 messages
  HANDOFF_TIMEOUT_MS: FIB[9] * 1000,        // 34 s
  RETRY_MAX:          FIB[4],               // 5 retries
  RETRY_BASE_MS:      FIB[7] * 10,          // 130 ms
  HEARTBEAT_MS:       FIB[9] * 1000,        // 34 s
  AUDIT_BUFFER:       FIB[11],              // 144 entries
  VERSION:            '2.0.0',
};

// ── Message Types ──────────────────────────────────────────────
const MSG_TYPE = Object.freeze({
  TASK:       'TASK',
  RESULT:     'RESULT',
  HANDOFF:    'HANDOFF',
  BROADCAST:  'BROADCAST',
  SUBSCRIBE:  'SUBSCRIBE',
  UNSUBSCRIBE:'UNSUBSCRIBE',
  HEARTBEAT:  'HEARTBEAT',
  ERROR:      'ERROR',
  ACK:        'ACK',
});

// ── Priority Levels (PHI-scaled) ───────────────────────────────
const PRIORITY = Object.freeze({
  CRITICAL: Math.round(PHI * PHI * PHI * 10),   // ~42
  HIGH:     Math.round(PHI * PHI * 10),          // ~26
  NORMAL:   Math.round(PHI * 10),                // ~16
  LOW:      10,
  IDLE:     Math.round(PSI * 10),                // ~6
});

// ── A2A Message Factory ────────────────────────────────────────
function createMessage({ from, to, type, payload = {}, priority = PRIORITY.NORMAL, correlationId = null }) {
  return {
    id:            crypto.randomUUID(),
    correlationId: correlationId || crypto.randomUUID(),
    version:       A2A_CONFIG.VERSION,
    type,
    from,
    to,
    priority,
    payload,
    timestamp:     Date.now(),
    ttl:           A2A_CONFIG.HANDOFF_TIMEOUT_MS,
    signature:     null, // set by sign()
  };
}

function signMessage(msg, secret = process.env.A2A_SECRET || 'heady-sacred') {
  const body = JSON.stringify({ id: msg.id, from: msg.from, to: msg.to, type: msg.type, timestamp: msg.timestamp });
  msg.signature = crypto.createHmac('sha256', secret).update(body).digest('hex');
  return msg;
}

function verifyMessage(msg, secret = process.env.A2A_SECRET || 'heady-sacred') {
  const body = JSON.stringify({ id: msg.id, from: msg.from, to: msg.to, type: msg.type, timestamp: msg.timestamp });
  const expected = crypto.createHmac('sha256', secret).update(body).digest('hex');
  return crypto.timingSafeEqual(Buffer.from(msg.signature || '', 'hex'), Buffer.from(expected, 'hex'));
}

// ── Audit Ring Buffer ──────────────────────────────────────────
class AuditLog {
  constructor(maxSize = A2A_CONFIG.AUDIT_BUFFER) {
    this._buf = [];
    this._max = maxSize;
  }
  record(entry) {
    this._buf.push({ ...entry, ts: Date.now() });
    if (this._buf.length > this._max) this._buf.shift();
  }
  tail(n = FIB[7]) { return this._buf.slice(-n); }
  toJSON() { return this._buf; }
}

// ── Agent Registry ─────────────────────────────────────────────
class AgentRegistry {
  constructor() {
    this._agents = new Map();   // agentId → { handler, meta, subscriptions }
    this._topics = new Map();   // topic → Set<agentId>
  }

  register(agentId, handler, meta = {}) {
    this._agents.set(agentId, { handler, meta, subscriptions: new Set(), registeredAt: Date.now() });
  }

  unregister(agentId) {
    const agent = this._agents.get(agentId);
    if (agent) {
      for (const topic of agent.subscriptions) {
        const subs = this._topics.get(topic);
        if (subs) subs.delete(agentId);
      }
    }
    this._agents.delete(agentId);
  }

  subscribe(agentId, topic) {
    const agent = this._agents.get(agentId);
    if (!agent) throw new Error(`Unknown agent: ${agentId}`);
    agent.subscriptions.add(topic);
    if (!this._topics.has(topic)) this._topics.set(topic, new Set());
    this._topics.get(topic).add(agentId);
  }

  unsubscribe(agentId, topic) {
    const agent = this._agents.get(agentId);
    if (agent) agent.subscriptions.delete(topic);
    const subs = this._topics.get(topic);
    if (subs) subs.delete(agentId);
  }

  get(agentId) { return this._agents.get(agentId); }
  has(agentId) { return this._agents.has(agentId); }
  subscribersOf(topic) { return [...(this._topics.get(topic) || [])]; }
  list() { return [...this._agents.entries()].map(([id, a]) => ({ id, meta: a.meta, subscriptions: [...a.subscriptions] })); }
}

// ── Priority Queue ─────────────────────────────────────────────
class PriorityQueue {
  constructor(maxDepth = A2A_CONFIG.MAX_QUEUE_DEPTH) {
    this._q = [];
    this._max = maxDepth;
  }
  enqueue(msg) {
    if (this._q.length >= this._max) {
      // Shed lowest priority
      this._q.sort((a, b) => b.priority - a.priority);
      this._q.pop();
    }
    this._q.push(msg);
    this._q.sort((a, b) => b.priority - a.priority);
  }
  dequeue() { return this._q.shift(); }
  get size() { return this._q.length; }
  isEmpty() { return this._q.length === 0; }
}

// ── A2A Protocol Bus ───────────────────────────────────────────
class A2AProtocol extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(FIB[8]);   // 21
    this.registry  = new AgentRegistry();
    this.audit     = new AuditLog();
    this._queues   = new Map();     // agentId → PriorityQueue
    this._inflight = new Map();     // msgId → { msg, timer, resolve, reject }
    this._hbTimer  = null;
    this._running  = false;
  }

  // ── Lifecycle ─────────────────────────────────────────────
  start() {
    if (this._running) return;
    this._running = true;
    this._hbTimer = setInterval(() => this._heartbeat(), A2A_CONFIG.HEARTBEAT_MS);
    this.emit('started');
  }

  stop() {
    this._running = false;
    clearInterval(this._hbTimer);
    for (const { timer } of this._inflight.values()) clearTimeout(timer);
    this._inflight.clear();
    this.emit('stopped');
  }

  // ── Agent Management ──────────────────────────────────────
  registerAgent(agentId, handler, meta = {}) {
    this.registry.register(agentId, handler, meta);
    this._queues.set(agentId, new PriorityQueue());
    this.audit.record({ event: 'register', agentId });
    this.emit('agent:registered', agentId);
  }

  unregisterAgent(agentId) {
    this.registry.unregister(agentId);
    this._queues.delete(agentId);
    this.audit.record({ event: 'unregister', agentId });
    this.emit('agent:unregistered', agentId);
  }

  subscribe(agentId, topic) {
    this.registry.subscribe(agentId, topic);
    this.audit.record({ event: 'subscribe', agentId, topic });
  }

  unsubscribe(agentId, topic) {
    this.registry.unsubscribe(agentId, topic);
  }

  // ── Core Send ─────────────────────────────────────────────
  async send(from, to, payload, opts = {}) {
    const msg = signMessage(createMessage({
      from, to,
      type:     opts.type || MSG_TYPE.TASK,
      payload,
      priority: opts.priority || PRIORITY.NORMAL,
      correlationId: opts.correlationId,
    }));
    return this._dispatch(msg);
  }

  // ── Handoff (blocking round-trip) ─────────────────────────
  async handoff(from, to, payload, opts = {}) {
    const msg = signMessage(createMessage({
      from, to, payload,
      type:     MSG_TYPE.HANDOFF,
      priority: opts.priority || PRIORITY.HIGH,
    }));

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this._inflight.delete(msg.id);
        reject(new Error(`Handoff timeout: ${from} → ${to} [${msg.id}]`));
      }, A2A_CONFIG.HANDOFF_TIMEOUT_MS);

      this._inflight.set(msg.id, { msg, timer, resolve, reject });
      this._dispatch(msg).catch(reject);
    });
  }

  // ── Broadcast to topic ────────────────────────────────────
  async broadcast(from, topic, payload, opts = {}) {
    const subscribers = this.registry.subscribersOf(topic);
    const results = await Promise.allSettled(
      subscribers.map(agentId =>
        this.send(from, agentId, payload, { ...opts, type: MSG_TYPE.BROADCAST })
      )
    );
    this.audit.record({ event: 'broadcast', from, topic, recipients: subscribers.length });
    return results;
  }

  // ── Internal Dispatch ─────────────────────────────────────
  async _dispatch(msg) {
    if (!verifyMessage(msg)) {
      this.audit.record({ event: 'sig_fail', msgId: msg.id, from: msg.from });
      throw new Error('A2A signature verification failed');
    }

    const size = JSON.stringify(msg).length;
    if (size > A2A_CONFIG.MAX_MESSAGE_SIZE) {
      throw new Error(`Message too large: ${size} bytes`);
    }

    const now = Date.now();
    if (now - msg.timestamp > msg.ttl) {
      this.audit.record({ event: 'expired', msgId: msg.id });
      return { status: 'expired', msgId: msg.id };
    }

    const agent = this.registry.get(msg.to);
    if (!agent) {
      this.audit.record({ event: 'no_agent', to: msg.to, msgId: msg.id });
      // Queue for late registration
      if (!this._queues.has(msg.to)) this._queues.set(msg.to, new PriorityQueue());
      this._queues.get(msg.to).enqueue(msg);
      return { status: 'queued', msgId: msg.id };
    }

    this.audit.record({ event: 'dispatch', from: msg.from, to: msg.to, type: msg.type, msgId: msg.id });
    this.emit('message', msg);

    try {
      const result = await agent.handler(msg);
      // Resolve handoff if waiting
      if (msg.type === MSG_TYPE.HANDOFF) {
        const inflight = this._inflight.get(msg.id);
        if (inflight) {
          clearTimeout(inflight.timer);
          this._inflight.delete(msg.id);
          inflight.resolve(result);
        }
      }
      this.audit.record({ event: 'delivered', msgId: msg.id, to: msg.to });
      return { status: 'delivered', msgId: msg.id, result };
    } catch (err) {
      this.audit.record({ event: 'handler_error', msgId: msg.id, error: err.message });
      this.emit('error', { msg, error: err });
      throw err;
    }
  }

  // ── Drain queued messages when agent registers ─────────────
  async drainQueue(agentId) {
    const q = this._queues.get(agentId);
    if (!q || q.isEmpty()) return 0;
    let count = 0;
    while (!q.isEmpty()) {
      const msg = q.dequeue();
      await this._dispatch(msg).catch(e => this.emit('error', { msg, error: e }));
      count++;
    }
    return count;
  }

  // ── Heartbeat ─────────────────────────────────────────────
  _heartbeat() {
    const agents = this.registry.list();
    for (const { id } of agents) {
      const hb = createMessage({ from: 'A2AProtocol', to: id, type: MSG_TYPE.HEARTBEAT, payload: { ts: Date.now() } });
      this._dispatch(hb).catch(() => {});
    }
    this.emit('heartbeat', { agents: agents.length, ts: Date.now() });
  }

  // ── Status ────────────────────────────────────────────────
  status() {
    const agents = this.registry.list();
    return {
      running:      this._running,
      agents:       agents.length,
      inflight:     this._inflight.size,
      auditTail:    this.audit.tail(FIB[5]),
      agentList:    agents,
      config:       A2A_CONFIG,
      ts:           Date.now(),
    };
  }
}

// ── Singleton ──────────────────────────────────────────────────
const bus = new A2AProtocol();

module.exports = {
  A2AProtocol,
  bus,
  createMessage,
  signMessage,
  verifyMessage,
  MSG_TYPE,
  PRIORITY,
  A2A_CONFIG,
};
