/**
 * Heady OS v2.0 — A2A Module Index
 */
'use strict';

const { A2AProtocol, bus, createMessage, signMessage, verifyMessage, MSG_TYPE, PRIORITY, A2A_CONFIG } = require('./a2a-protocol');
const { A2UIBridge, bridge, BRIDGE_CONFIG } = require('./a2ui-bridge');

module.exports = {
  // Protocol
  A2AProtocol,
  bus,
  createMessage,
  signMessage,
  verifyMessage,
  MSG_TYPE,
  PRIORITY,
  A2A_CONFIG,
  // Bridge
  A2UIBridge,
  bridge,
  BRIDGE_CONFIG,
};
