/**
 * Heady OS v2.0 — A2UI Bridge (Agent-to-UI)
 * Streams A2A bus events to all connected browser dashboards via SSE
 */
'use strict';

const { EventEmitter } = require('events');
const { bus, MSG_TYPE } = require('./a2a-protocol');

const PHI = 1.618033988749895;
const FIB = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987];

const BRIDGE_CONFIG = {
  MAX_CLIENTS:        FIB[8],          // 21 concurrent UI clients
  PING_INTERVAL_MS:   FIB[8] * 1000,   // 21 s
  BUFFER_SIZE:        FIB[10],         // 89 recent events per client
  RECONNECT_DELAY_MS: Math.round(PHI * 1000), // ~1618 ms hint
};

// ── SSE Client ────────────────────────────────────────────────
class SSEClient {
  constructor(res, clientId, filters = []) {
    this.id      = clientId;
    this.res     = res;
    this.filters = new Set(filters);
    this.buffer  = [];
    this.connectedAt = Date.now();
    this._pingTimer  = null;

    // SSE headers
    res.writeHead(200, {
      'Content-Type':  'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection':    'keep-alive',
      'X-Accel-Buffering': 'no',
      'Access-Control-Allow-Origin': '*',
    });

    this._startPing();
  }

  send(event, data) {
    if (this.filters.size > 0 && !this.filters.has(event)) return;
    const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\nid: ${Date.now()}\n\n`;
    try {
      this.res.write(payload);
      this.buffer.push({ event, data, ts: Date.now() });
      if (this.buffer.length > BRIDGE_CONFIG.BUFFER_SIZE) this.buffer.shift();
    } catch (_) {
      // Client disconnected
    }
  }

  ping() {
    try { this.res.write(`: ping ${Date.now()}\n\n`); } catch (_) {}
  }

  close() {
    clearInterval(this._pingTimer);
    try { this.res.end(); } catch (_) {}
  }

  _startPing() {
    this._pingTimer = setInterval(() => this.ping(), BRIDGE_CONFIG.PING_INTERVAL_MS);
  }
}

// ── A2UI Bridge ───────────────────────────────────────────────
class A2UIBridge extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(FIB[7]);   // 13
    this._clients   = new Map();    // clientId → SSEClient
    this._sequence  = 0;

    this._attachBusListeners();
  }

  // ── Connect HTTP response as SSE client ───────────────────
  connect(req, res, filters = []) {
    if (this._clients.size >= BRIDGE_CONFIG.MAX_CLIENTS) {
      res.status(503).json({ error: 'Max UI clients reached', max: BRIDGE_CONFIG.MAX_CLIENTS });
      return null;
    }
    const clientId = `ui-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const client = new SSEClient(res, clientId, filters);
    this._clients.set(clientId, client);

    // Send buffered boot state
    client.send('connected', { clientId, config: BRIDGE_CONFIG, ts: Date.now() });

    req.on('close', () => this._disconnect(clientId));
    req.on('error', () => this._disconnect(clientId));

    this.emit('client:connected', clientId);
    return clientId;
  }

  // ── Broadcast to all UI clients ───────────────────────────
  broadcast(event, data) {
    const seq = ++this._sequence;
    const enriched = { ...data, seq, ts: Date.now() };
    for (const client of this._clients.values()) {
      client.send(event, enriched);
    }
    return seq;
  }

  // ── Send to specific client ───────────────────────────────
  sendTo(clientId, event, data) {
    const client = this._clients.get(clientId);
    if (client) client.send(event, { ...data, ts: Date.now() });
  }

  // ── Disconnect ────────────────────────────────────────────
  _disconnect(clientId) {
    const client = this._clients.get(clientId);
    if (client) {
      client.close();
      this._clients.delete(clientId);
      this.emit('client:disconnected', clientId);
    }
  }

  // ── Wire A2A bus events → UI ──────────────────────────────
  _attachBusListeners() {
    bus.on('message', (msg) => {
      if (msg.type === MSG_TYPE.HEARTBEAT) return; // skip noise
      this.broadcast('a2a:message', {
        id:   msg.id,
        from: msg.from,
        to:   msg.to,
        type: msg.type,
        priority: msg.priority,
        payloadSize: JSON.stringify(msg.payload).length,
      });
    });

    bus.on('agent:registered', (agentId) => {
      this.broadcast('a2a:agent_registered', { agentId });
    });

    bus.on('agent:unregistered', (agentId) => {
      this.broadcast('a2a:agent_unregistered', { agentId });
    });

    bus.on('heartbeat', (info) => {
      this.broadcast('a2a:heartbeat', info);
    });

    bus.on('error', ({ msg, error }) => {
      this.broadcast('a2a:error', {
        msgId: msg?.id,
        from:  msg?.from,
        to:    msg?.to,
        error: error?.message,
      });
    });

    bus.on('started', () => this.broadcast('bus:started', { ts: Date.now() }));
    bus.on('stopped', () => this.broadcast('bus:stopped', { ts: Date.now() }));
  }

  // ── Emit topology snapshot ────────────────────────────────
  emitTopology(nodes) {
    this.broadcast('topology:snapshot', {
      nodes: nodes.map(n => ({
        id:     n.id,
        ring:   n.ring,
        status: n.status,
        angle:  n.angle,
        load:   n.load || 0,
      })),
    });
  }

  // ── Emit swarm update ─────────────────────────────────────
  emitSwarmUpdate(swarmData) {
    this.broadcast('swarm:update', swarmData);
  }

  // ── Emit boot progress ────────────────────────────────────
  emitBootProgress(stage, data = {}) {
    this.broadcast('boot:progress', { stage, ...data });
  }

  // ── Status ────────────────────────────────────────────────
  status() {
    return {
      clients:   this._clients.size,
      sequence:  this._sequence,
      config:    BRIDGE_CONFIG,
      clientIds: [...this._clients.keys()],
    };
  }
}

const bridge = new A2UIBridge();

module.exports = { A2UIBridge, bridge, BRIDGE_CONFIG };
