# Heady OS v2.0 — Sacred Geometry v4.0

> **PHI-scaled distributed AI operating system with 34 Sacred Geometry nodes, 6 engines, MCP gateway, A2A/A2UI protocol, HeadyBuddy companion, and 3 Colab Pro+ latent space runtimes.**

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│  Heady OS v2.0 — Sacred Geometry v4.0                          │
│                                                                  │
│  φ = 1.618033988749895  |  FIB = [1,1,2,3,5,8,13,21,34,55...]  │
│                                                                  │
│  ╔═══ 34 SACRED GEOMETRY NODES ═══════════════════════════════╗ │
│  ║  Center (1):     HeadySoul                                 ║ │
│  ║  Inner  (3):     HeadyBrains · HeadyConductor · HeadyVinci ║ │
│  ║  Middle (8):     JULES · BUILDER · OBSERVER · MURPHY       ║ │
│  ║                  ATLAS · PYTHIA · BRIDGE · MUSE             ║ │
│  ║  Outer  (13):    SENTINEL · NOVA · JANITOR · SOPHIA         ║ │
│  ║                  CIPHER · LENS · HeadyCheck · HeadyAssure   ║ │
│  ║                  HeadyAware · HeadyPatterns · HeadyMC        ║ │
│  ║                  HeadyRisks · HeadyAnalyze                  ║ │
│  ║  Governance (9): HeadyCodex · HeadyCoder · HeadyOrchestrator ║ │
│  ║                  HeadyMaintenance · HeadyMaid               ║ │
│  ║                  HeadyAutobiographer · HeadyResearch        ║ │
│  ║                  HeadyEmbed · HeadyManager                  ║ │
│  ╚════════════════════════════════════════════════════════════╝ │
│                                                                  │
│  ╔═══ ENGINES ════════════════════════════════════════════════╗ │
│  ║  EvolutionEngine · PersonaRouter · WisdomStore             ║ │
│  ║  BudgetTracker · HeadyLens · CouncilMode (7-member)        ║ │
│  ╚════════════════════════════════════════════════════════════╝ │
│                                                                  │
│  ╔═══ SERVICES ═══════════════════════════════════════════════╗ │
│  ║  MCP Gateway  :8081  (zero-trust · SHA-256 audit chain)    ║ │
│  ║  A2A Bus             (agent-to-agent · signed messages)    ║ │
│  ║  A2UI Bridge         (SSE → browser dashboards)            ║ │
│  ║  HeadyBuddy   :8082  (companion · PersonaRouter · Wisdom)  ║ │
│  ╚════════════════════════════════════════════════════════════╝ │
│                                                                  │
│  ╔═══ COLAB PRO+ LATENT SPACE ════════════════════════════════╗ │
│  ║  Runtime 1: Qwen3-Embedding-8B     · A100/V100 · :3301     ║ │
│  ║  Runtime 2: Qwen2.5-Coder-32B      · A100      · :3302     ║ │
│  ║             DeepSeek-R1-Distill-32B                         ║ │
│  ║  Runtime 3: Gemma-3-12B (TPU v2-8) · JAX/Flax  · :3303     ║ │
│  ╚════════════════════════════════════════════════════════════╝ │
└─────────────────────────────────────────────────────────────────┘
```

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your API keys, Colab tunnel URLs, secrets

# 3. Start server
npm start
# → Main:  http://localhost:8080
# → MCP:   http://localhost:8081
# → Buddy: http://localhost:8082

# 4. Docker
docker-compose up -d
```

## Services

| Service       | Port  | Description                                        |
|---------------|-------|----------------------------------------------------|
| Main          | 8080  | Heady OS core + UI dashboard                       |
| MCP Gateway   | 8081  | Model Context Protocol with zero-trust execution   |
| HeadyBuddy    | 8082  | Conversational AI companion                        |
| Colab R1      | 3301  | Vector ops (Qwen3-Embedding-8B, FAISS GPU)         |
| Colab R2      | 3302  | LLM inference (Qwen2.5-Coder-32B, DeepSeek-R1)    |
| Colab R3      | 3303  | Training & analytics (Gemma-3-12B TPU, DuckDB)     |

## UI Dashboards

- **Command Center** — `http://localhost:8080/` — 3D golden-spiral topology canvas, boot control
- **Swarm Monitor** — `http://localhost:8080/swarm-monitor.html` — real-time A2A bus, node status, load

## API Reference

```
GET  /health                  → System health
GET  /api/status              → Full system status
GET  /api/events              → SSE event stream (A2UI bridge)
GET  /api/nodes               → 34-node topology manifest
POST /api/boot                → Boot Heady OS (8-stage sequence)
POST /api/reboot              → Graceful reboot
POST /api/shutdown            → Graceful shutdown
GET  /api/colab/:n/health     → Colab runtime n health proxy
GET  /api/a2a/status          → A2A bus status + agent list
GET  /api/a2a/audit           → Recent message audit log
POST /api/a2a/send            → Send A2A message
POST /api/conductor/route     → Route task via ConductorSwarm
GET  /api/engines/budget      → BudgetTracker status
GET  /api/engines/wisdom      → WisdomStore status
POST /api/engines/council     → CouncilMode deliberation
POST /buddy/session           → Create HeadyBuddy session
POST /buddy/chat              → Chat turn
GET  /buddy/stream/:id        → SSE chat stream
GET  /buddy/personas          → Available personas
GET  /buddy/budget            → Budget snapshot
```

## PHI Constants

| Constant      | Value                    | Usage                            |
|---------------|--------------------------|----------------------------------|
| PHI           | 1.618033988749895        | Scaling factor everywhere        |
| PSI           | 0.618033988749895        | Inverse PHI                      |
| GOLDEN_ANGLE  | 2.3999 rad (137.508°)    | Node placement in topology       |
| FIB[9]=34     | 34                       | Node count, timeouts             |
| FIB[10]=89    | 89                       | Queue depths                     |
| FIB[11]=144   | 144                      | WisdomStore max entries          |

## 2026 Model Pricing

| Model                    | Input $/M  | Output $/M | Role        |
|--------------------------|------------|------------|-------------|
| Qwen2.5-Coder-32B        | $0.20      | $0.60      | Hot (code)  |
| DeepSeek-R1-Distill-32B  | $0.14      | $0.28      | Hot (reason)|
| Qwen3-Embedding-8B       | $0.02      | —          | Embedding   |
| Gemma-3-12B (TPU)        | $0.08      | $0.16      | Training    |
| Claude 3.7 Sonnet        | $3.00      | $15.00     | Reserve     |
| GPT-4o mini              | $0.15      | $0.60      | Fallback    |

## License

UNLICENSED — Proprietary. © 2026 HeadyConnection.org / HeadySystems.com

Contact: eric@headyconnection.org
