// ═══════════════════════════════════════════════════════════════════════════════
// HEADY™ Maximum Potential — Master Index
// © 2026 HeadySystems Inc. — Eric Haywood, Founder
// Liquid Latent OS — Sacred Geometry :: Organic Systems :: Breathing Interfaces
// ═══════════════════════════════════════════════════════════════════════════════

// ─── SHARED FOUNDATION ──────────────────────────────────────────────────────
export * as PhiMath from './shared/phi-math-v2.js';
export * as CSLEngine from './shared/csl-engine-v2.js';
export * as SacredGeometry from './shared/sacred-geometry-v2.js';

// ─── CORE ───────────────────────────────────────────────────────────────────
export { EvolutionEngine } from './core/evolution-engine.js';
export { PersonaRouter, SWARM_PERSONAS } from './core/persona-router.js';
export { WisdomStore } from './core/wisdom-store.js';
export { BudgetTracker, BUDGET_TIERS, PROVIDER_COSTS } from './core/budget-tracker.js';
export { HeadyLens } from './core/heady-lens.js';
export { CouncilMode, COUNCIL_MODELS } from './core/council-mode.js';
export { AutoSuccessEngine, PIPELINE_STAGES } from './core/auto-success-engine.js';
export { HeadyBrains, CONTEXT_SOURCES } from './core/heady-brains.js';
export { HeadyAutobiographer, EVENT_TYPES } from './core/heady-autobiographer.js';
export { HeadyManagerKernel, MODULE_STATES } from './core/heady-manager-kernel.js';

// ─── SECURITY ───────────────────────────────────────────────────────────────
export { RBACEngine, ROLES, PERMISSIONS } from './security/rbac-engine.js';
export { CryptoAuditTrail } from './security/crypto-audit-trail.js';
export { SecretManager } from './security/secret-manager.js';

// ─── AUTH ───────────────────────────────────────────────────────────────────
export { AuthGateway, SESSION_CONFIG } from './auth/auth-gateway.js';

// ─── MONITORING ─────────────────────────────────────────────────────────────
export { HealthProbeSystem, PORT_RANGES } from './monitoring/health-probe-system.js';
export { DriftDetector } from './monitoring/drift-detector.js';
export { TelemetryCollector } from './monitoring/telemetry-collector.js';
export { IncidentResponder, SEVERITY_LEVELS } from './monitoring/incident-responder.js';

// ─── SCALING ────────────────────────────────────────────────────────────────
export { AutoScaler } from './scaling/auto-scaler.js';
export { ResourceAllocator } from './scaling/resource-allocator.js';
export { JITLoader } from './scaling/jit-loader.js';

// ─── DEPLOY ─────────────────────────────────────────────────────────────────
export { UniversalContainer } from './deploy/universal-container.js';
export { CloudRunDeployer, GCP_CONFIG } from './deploy/cloud-run-deployer.js';
export { CloudflareDeployer, CF_CONFIG } from './deploy/cloudflare-deployer.js';

// ─── SERVICES ───────────────────────────────────────────────────────────────
export { ServiceRegistry, SERVICE_GROUPS } from './services/service-registry.js';
export { ServiceMesh } from './services/service-mesh.js';

// ─── CONFIG ─────────────────────────────────────────────────────────────────
export { default as HeadyConfig } from './config/heady-config.js';
export { default as PipelineCanonical } from './config/pipeline-canonical.js';
export { default as EnvironmentConfig } from './config/environment-config.js';

// ─── WEBSITES ───────────────────────────────────────────────────────────────
export { default as WebsiteRegistry } from './websites/website-registry.js';

// ─── ORCHESTRATION ──────────────────────────────────────────────────────────
export { HCFPRunner, HCFP_STAGES } from './orchestration/hcfp-runner.js';
export { ArenaMode } from './orchestration/arena-mode-enhanced.js';
export { SWARM_DEFINITIONS } from './orchestration/swarm-definitions.js';
export { SocraticLoop } from './orchestration/socratic-loop.js';
