// ═══════════════════════════════════════════════════════════════════════════════
// HEADY™ Socratic Loop — Reasoning Validation Engine
// © 2026 HeadySystems Inc. — Eric Haywood, Founder
// ═══════════════════════════════════════════════════════════════════════════════

import {
  PHI, PSI, PSI3, FIB, CSL_THRESHOLDS,
  cosineSimilarity, sha256, cslGate
} from '../shared/phi-math-v2.js';
import { textToEmbedding } from '../shared/csl-engine-v2.js';

class SocraticLoop {
  #sessions;
  #maxSessions;

  constructor() {
    this.#sessions = new Map();
    this.#maxSessions = FIB[12];
  }

  async question(proposition, context = '') {
    const sessionId = await sha256('socratic:' + proposition.slice(0, FIB[8]) + ':' + Date.now());
    const propEmb = textToEmbedding(proposition);
    const ctxEmb = context ? textToEmbedding(context) : propEmb;

    const alignment = cosineSimilarity(propEmb, ctxEmb);
    const questions = [
      { q: 'Does this serve the mission?', answer: alignment > CSL_THRESHOLDS.MEDIUM },
      { q: 'Is this structurally sound?', answer: alignment > CSL_THRESHOLDS.LOW },
      { q: 'Does it preserve coherence?', answer: alignment > CSL_THRESHOLDS.HIGH * PSI },
      { q: 'Is the change magnitude bounded?', answer: true },
      { q: 'Are there unintended consequences?', answer: alignment > CSL_THRESHOLDS.MINIMUM },
    ];

    const session = { id: sessionId, proposition, questions, alignment, timestamp: Date.now() };
    this.#sessions.set(sessionId, session);
    return session;
  }

  validate(sessionId) {
    const session = this.#sessions.get(sessionId);
    if (!session) throw new Error('Session not found');
    const passes = session.questions.every(q => q.answer);
    const confidence = session.questions.filter(q => q.answer).length / session.questions.length;
    return { valid: passes, confidence, alignment: session.alignment };
  }

  challenge(sessionId, challengeText) {
    const session = this.#sessions.get(sessionId);
    if (!session) throw new Error('Session not found');
    const challengeEmb = textToEmbedding(challengeText);
    const propEmb = textToEmbedding(session.proposition);
    const counterScore = cosineSimilarity(challengeEmb, propEmb);
    return { challenged: true, counterScore, withstands: counterScore < CSL_THRESHOLDS.HIGH };
  }

  approve(sessionId) {
    const validation = this.validate(sessionId);
    return { approved: validation.valid, confidence: validation.confidence };
  }

  getReasoningChain(sessionId) {
    const session = this.#sessions.get(sessionId);
    if (!session) return null;
    return {
      proposition: session.proposition,
      questions: session.questions,
      validation: this.validate(sessionId),
    };
  }
}

export { SocraticLoop };
export default SocraticLoop;
