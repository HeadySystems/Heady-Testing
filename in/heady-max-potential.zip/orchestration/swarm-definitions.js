// ═══════════════════════════════════════════════════════════════════════════════
// HEADY™ Swarm Definitions — Complete 17-Swarm Topology
// © 2026 HeadySystems Inc. — Eric Haywood, Founder
// ═══════════════════════════════════════════════════════════════════════════════

import { FIB, CSL_THRESHOLDS } from '../shared/phi-math-v2.js';

const SWARM_DEFINITIONS = Object.freeze([
  { id: 'soul-swarm',        ring: 'central', layer: 'strategic',   fibIdx: 0, domain: 'awareness',     cslThreshold: CSL_THRESHOLDS.CRITICAL, model: 'claude-opus',    beeTypes: ['soul-bee', 'values-bee'] },
  { id: 'brains-swarm',      ring: 'inner',   layer: 'strategic',   fibIdx: 1, domain: 'context',       cslThreshold: CSL_THRESHOLDS.HIGH,     model: 'claude-sonnet',  beeTypes: ['context-bee', 'memory-bee'] },
  { id: 'conductor-swarm',   ring: 'inner',   layer: 'strategic',   fibIdx: 2, domain: 'orchestration', cslThreshold: CSL_THRESHOLDS.HIGH,     model: 'claude-sonnet',  beeTypes: ['dispatch-bee', 'route-bee'] },
  { id: 'vinci-swarm',       ring: 'inner',   layer: 'strategic',   fibIdx: 3, domain: 'planning',      cslThreshold: CSL_THRESHOLDS.HIGH,     model: 'claude-opus',    beeTypes: ['plan-bee', 'schedule-bee'] },
  { id: 'jules-swarm',       ring: 'middle',  layer: 'tactical',    fibIdx: 4, domain: 'code-gen',      cslThreshold: CSL_THRESHOLDS.MEDIUM,   model: 'claude-sonnet',  beeTypes: ['coder-bee', 'refactor-bee', 'test-bee'] },
  { id: 'builder-swarm',     ring: 'middle',  layer: 'tactical',    fibIdx: 5, domain: 'construction',  cslThreshold: CSL_THRESHOLDS.MEDIUM,   model: 'claude-sonnet',  beeTypes: ['build-bee', 'deploy-bee'] },
  { id: 'observer-swarm',    ring: 'middle',  layer: 'tactical',    fibIdx: 6, domain: 'monitoring',    cslThreshold: CSL_THRESHOLDS.MEDIUM,   model: 'gemini-pro',     beeTypes: ['watch-bee', 'alert-bee'] },
  { id: 'murphy-swarm',      ring: 'middle',  layer: 'tactical',    fibIdx: 7, domain: 'security',      cslThreshold: CSL_THRESHOLDS.MEDIUM,   model: 'claude-sonnet',  beeTypes: ['scan-bee', 'patch-bee', 'audit-bee'] },
  { id: 'atlas-swarm',       ring: 'middle',  layer: 'tactical',    fibIdx: 8, domain: 'architecture',  cslThreshold: CSL_THRESHOLDS.MEDIUM,   model: 'claude-opus',    beeTypes: ['design-bee', 'review-bee'] },
  { id: 'pythia-swarm',      ring: 'middle',  layer: 'tactical',    fibIdx: 9, domain: 'analysis',      cslThreshold: CSL_THRESHOLDS.MEDIUM,   model: 'gpt-4o',         beeTypes: ['analyze-bee', 'predict-bee'] },
  { id: 'bridge-swarm',      ring: 'outer',   layer: 'operational', fibIdx: 10, domain: 'translation',  cslThreshold: CSL_THRESHOLDS.LOW,      model: 'gemini-flash',   beeTypes: ['translate-bee'] },
  { id: 'muse-swarm',        ring: 'outer',   layer: 'operational', fibIdx: 11, domain: 'creative',     cslThreshold: CSL_THRESHOLDS.LOW,      model: 'claude-opus',    beeTypes: ['create-bee', 'design-bee'] },
  { id: 'sentinel-swarm',    ring: 'outer',   layer: 'operational', fibIdx: 12, domain: 'defense',      cslThreshold: CSL_THRESHOLDS.LOW,      model: 'claude-sonnet',  beeTypes: ['guard-bee', 'detect-bee'] },
  { id: 'nova-swarm',        ring: 'outer',   layer: 'operational', fibIdx: 13, domain: 'innovation',   cslThreshold: CSL_THRESHOLDS.LOW,      model: 'gpt-4o',         beeTypes: ['explore-bee', 'prototype-bee'] },
  { id: 'janitor-swarm',     ring: 'outer',   layer: 'operational', fibIdx: 14, domain: 'cleanup',      cslThreshold: CSL_THRESHOLDS.LOW,      model: 'gemini-flash',   beeTypes: ['clean-bee', 'prune-bee'] },
  { id: 'sophia-swarm',      ring: 'outer',   layer: 'operational', fibIdx: 15, domain: 'wisdom',       cslThreshold: CSL_THRESHOLDS.LOW,      model: 'sonar-pro',      beeTypes: ['research-bee', 'wisdom-bee'] },
  { id: 'cipher-swarm',      ring: 'outer',   layer: 'operational', fibIdx: 16, domain: 'encryption',   cslThreshold: CSL_THRESHOLDS.LOW,      model: 'claude-sonnet',  beeTypes: ['encrypt-bee', 'key-bee'] },
]);

function getSwarm(id) { return SWARM_DEFINITIONS.find(s => s.id === id) || null; }
function getSwarmsByRing(ring) { return SWARM_DEFINITIONS.filter(s => s.ring === ring); }
function getSwarmsByLayer(layer) { return SWARM_DEFINITIONS.filter(s => s.layer === layer); }
function getAllBeeTypes() { return SWARM_DEFINITIONS.flatMap(s => s.beeTypes); }

export { SWARM_DEFINITIONS, getSwarm, getSwarmsByRing, getSwarmsByLayer, getAllBeeTypes };
export default SWARM_DEFINITIONS;
