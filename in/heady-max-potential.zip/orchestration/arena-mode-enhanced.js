// ═══════════════════════════════════════════════════════════════════════════════
// HEADY™ Arena Mode Enhanced — Intelligent Squash Merging
// © 2026 HeadySystems Inc. — Eric Haywood, Founder
// ═══════════════════════════════════════════════════════════════════════════════

import {
  PHI, PSI, PSI2, PSI3, FIB, CSL_THRESHOLDS,
  cosineSimilarity, sha256, cslGate, phiFusionWeights
} from '../shared/phi-math-v2.js';
import { textToEmbedding, cslCONSENSUS, DIM } from '../shared/csl-engine-v2.js';

class ArenaMode {
  #competitions;
  #maxCompetitions;

  constructor() {
    this.#competitions = new Map();
    this.#maxCompetitions = FIB[12];
  }

  async compete(task, candidateCount = FIB[5]) {
    const arenaId = await sha256('arena:' + task.slice(0, FIB[8]) + ':' + Date.now());
    const taskEmb = textToEmbedding(task);
    const candidates = Array.from({ length: candidateCount }, (_, i) => ({
      id: 'candidate-' + i,
      embedding: textToEmbedding(task + ':solution:' + i),
      score: 0,
    }));

    for (const c of candidates) {
      c.score = cosineSimilarity(c.embedding, taskEmb);
    }

    const competition = { id: arenaId, task, candidates, startedAt: Date.now() };
    this.#competitions.set(arenaId, competition);
    return competition;
  }

  score(arenaId) {
    const comp = this.#competitions.get(arenaId);
    if (!comp) throw new Error('Competition not found');
    return comp.candidates.map(c => ({ id: c.id, score: c.score })).sort((a, b) => b.score - a.score);
  }

  selectWinner(arenaId) {
    const scores = this.score(arenaId);
    return { winner: scores[0], runnerUp: scores[1], total: scores.length };
  }

  async squashMerge(arenaId) {
    const winner = this.selectWinner(arenaId);
    const comp = this.#competitions.get(arenaId);
    return {
      merged: true,
      arenaId,
      winner: winner.winner.id,
      score: winner.winner.score,
      hash: await sha256('merge:' + arenaId + ':' + winner.winner.id),
      task: comp.task,
    };
  }

  getHistory(limit = FIB[8]) {
    return Array.from(this.#competitions.values()).slice(-limit).map(c => ({
      id: c.id, task: c.task, candidates: c.candidates.length,
    }));
  }
}

export { ArenaMode };
export default ArenaMode;
