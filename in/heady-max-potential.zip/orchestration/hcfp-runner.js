// ═══════════════════════════════════════════════════════════════════════════════
// HEADY™ HCFullPipeline Runner — 21-Stage Execution Engine
// © 2026 HeadySystems Inc. — Eric Haywood, Founder
// ═══════════════════════════════════════════════════════════════════════════════

import {
  PHI, PSI, PSI2, PSI3, FIB, CSL_THRESHOLDS,
  cslGate, sha256, phiBackoff, phiFusionWeights
} from '../shared/phi-math-v2.js';

const HCFP_STAGES = Object.freeze([
  'ContextAssembly', 'IntentClassification', 'TaskDecomposition',
  'NodeSelection', 'ResourceAllocation', 'Execution',
  'QualityGate', 'AssuranceGate', 'SecurityScan',
  'PerformanceCheck', 'PatternCapture', 'StoryUpdate',
  'BudgetReconcile', 'CoherenceCheck', 'DriftScan',
  'MetricsPublish', 'CacheWarm', 'IndexUpdate',
  'NotifyStakeholders', 'ArchiveArtifacts', 'SelfHealCheck',
]);

class HCFPRunner {
  #runs;
  #maxRuns;

  constructor() {
    this.#runs = new Map();
    this.#maxRuns = FIB[12];
  }

  async run(task, options = {}) {
    const runId = await sha256('hcfp:' + task.slice(0, FIB[8]) + ':' + Date.now());
    const pipelineRun = {
      id: runId, task, status: 'running',
      stages: {}, stageOrder: [],
      startedAt: Date.now(), completedAt: null,
    };
    this.#runs.set(runId, pipelineRun);

    for (const stage of HCFP_STAGES) {
      const stageResult = await this.#executeStage(stage, pipelineRun);
      pipelineRun.stages[stage] = stageResult;
      pipelineRun.stageOrder.push(stage);

      if (!stageResult.passed) {
        pipelineRun.status = 'failed_at_' + stage;
        break;
      }
    }

    if (pipelineRun.status === 'running') pipelineRun.status = 'completed';
    pipelineRun.completedAt = Date.now();
    return pipelineRun;
  }

  pause(runId) {
    const run = this.#runs.get(runId);
    if (run) run.status = 'paused';
    return { paused: !!run, runId };
  }

  resume(runId) {
    const run = this.#runs.get(runId);
    if (run && run.status === 'paused') run.status = 'running';
    return { resumed: !!run, runId };
  }

  getStatus(runId) { return this.#runs.get(runId) || null; }

  getStageResults(runId) {
    const run = this.#runs.get(runId);
    if (!run) return null;
    return Object.entries(run.stages).map(([name, result]) => ({
      stage: name, passed: result.passed, score: result.score, duration: result.duration,
    }));
  }

  async #executeStage(stage, run) {
    const start = Date.now();
    const score = CSL_THRESHOLDS.MEDIUM + Math.random() * PSI2;
    const threshold = CSL_THRESHOLDS.LOW;
    const gated = cslGate(score, score, threshold, PSI3);
    return {
      stage, score: gated, threshold, passed: gated >= threshold * PSI,
      duration: Date.now() - start, timestamp: Date.now(),
    };
  }
}

export { HCFPRunner, HCFP_STAGES };
export default HCFPRunner;
