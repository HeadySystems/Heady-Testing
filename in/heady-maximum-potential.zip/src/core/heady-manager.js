/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ MANAGER — System Entry Point & Service Wiring            ║
 * ║  Boots all subsystems, wires dependencies, starts HTTP/MCP       ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib, PHI_TIMING } from '../../shared/phi-math.js';
import { TelemetryEmitter } from '../telemetry/telemetry-emitter.js';
import { GracefulShutdown } from '../lifecycle/graceful-shutdown.js';
import { BeeFactory } from '../bees/bee-factory.js';
import { HeadyConductor } from '../orchestration/heady-conductor.js';
import { PipelineEngine } from '../pipeline/pipeline-engine.js';
import { LiquidGateway } from '../orchestration/liquid-gateway.js';
import { VectorMemory } from '../memory/vector-memory.js';
import { EmbeddingRouter } from '../memory/embedding-router.js';
import { MCPGateway } from '../mcp/mcp-gateway.js';
import { SelfHealingMesh } from '../resilience/self-healing.js';
import { AutoSuccessEngine } from '../lifecycle/auto-success-engine.js';
import { PersonaRouter } from '../personas/persona-router.js';
import { Ed25519ReceiptSigner } from '../security/ed25519-signer.js';
import { ZeroTrustGate } from '../security/zero-trust-gate.js';

import http from 'http';

/**
 * HeadyManager — the master orchestrator that boots and wires the entire system.
 */
export class HeadyManager {
  constructor() {
    // Core subsystems
    this.telemetry = new TelemetryEmitter();
    this.shutdown = new GracefulShutdown({ telemetry: this.telemetry });
    this.embeddingRouter = new EmbeddingRouter({
      apiKeys: {
        nomic: process.env.NOMIC_API_KEY,
        jina: process.env.JINA_API_KEY,
        cohere: process.env.COHERE_API_KEY,
        voyage: process.env.VOYAGE_API_KEY,
      },
      telemetry: this.telemetry,
    });
    this.vectorMemory = new VectorMemory({
      embedFn: (text) => this.embeddingRouter.embed(text),
      telemetry: this.telemetry,
    });
    this.beeFactory = new BeeFactory({ telemetry: this.telemetry });
    this.liquidGateway = new LiquidGateway({
      apiKeys: {
        anthropic: process.env.ANTHROPIC_API_KEY,
        openai: process.env.OPENAI_API_KEY,
        google: process.env.GOOGLE_API_KEY,
        groq: process.env.GROQ_API_KEY,
        perplexity: process.env.PERPLEXITY_API_KEY,
      },
      telemetry: this.telemetry,
    });
    this.conductor = new HeadyConductor({
      soul: null,  // Wired after HeadySoul boots
      brains: { assembleContext: async () => ({}) },
      vinci: null,
      telemetry: this.telemetry,
    });
    this.pipeline = new PipelineEngine({ telemetry: this.telemetry });
    this.mcpGateway = new MCPGateway({ telemetry: this.telemetry });
    this.selfHealing = new SelfHealingMesh({
      respawnFn: async (id, config) => { /* respawn logic */ },
      telemetry: this.telemetry,
    });
    this.autoSuccess = new AutoSuccessEngine({ telemetry: this.telemetry });
    this.personaRouter = new PersonaRouter({ telemetry: this.telemetry });
    this.receiptSigner = new Ed25519ReceiptSigner();
    this.zeroTrust = new ZeroTrustGate({ telemetry: this.telemetry });

    this._server = null;
  }

  /**
   * Boot the entire Heady system.
   */
  async boot() {
    const bootStart = Date.now();
    this.telemetry.emit('system.booting', { version: '4.0.0' });

    // Initialize receipt signer
    await this.receiptSigner.initialize();

    // Register MCP tools
    this._registerMCPTools();

    // Register shutdown hooks (LIFO)
    this.shutdown.register('http-server', () => this._server?.close());
    this.shutdown.register('auto-success', () => this.autoSuccess.stop());
    this.shutdown.register('self-healing', () => this.selfHealing.stop());
    this.shutdown.register('bee-factory', () => this.beeFactory.shutdown());
    this.shutdown.registerSignalHandlers();

    // Start background services
    this.selfHealing.start();
    this.autoSuccess.start();

    // Start HTTP server
    const port = parseInt(process.env.PORT || '8080', 10);
    this._server = http.createServer((req, res) => this._handleHTTP(req, res));
    this._server.listen(port, () => {
      const bootMs = Date.now() - bootStart;
      this.telemetry.emit('system.booted', { port, bootMs });
      console.log(`[HEADY] Latent OS v4.0.0 booted in ${bootMs}ms on port ${port}`);
      console.log(`[HEADY] φ = ${PHI.toFixed(13)} | ψ = ${PSI.toFixed(13)}`);
      console.log(`[HEADY] MCP tools: ${this.mcpGateway.getStatus().registeredTools}`);
      console.log(`[HEADY] Bee factory capacity: 10,000`);
    });
  }

  /**
   * Handle HTTP requests.
   * @private
   */
  _handleHTTP(req, res) {
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (url.pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        status: 'healthy',
        version: '4.0.0',
        uptime: process.uptime(),
        bees: this.beeFactory.getStats(),
        memory: this.vectorMemory.getStats(),
        gateway: this.liquidGateway.getHealth(),
        pipeline: { state: this.pipeline.state },
      }));
      return;
    }

    if (url.pathname === '/mcp' && req.method === 'POST') {
      let body = '';
      req.on('data', chunk => body += chunk);
      req.on('end', async () => {
        try {
          const request = JSON.parse(body);
          const response = await this.mcpGateway.handleRequest(request);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify(response));
        } catch (err) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: err.message }));
        }
      });
      return;
    }

    res.writeHead(404);
    res.end('Not Found');
  }

  /**
   * Register core MCP tools.
   * @private
   */
  _registerMCPTools() {
    this.mcpGateway.registerTool({
      name: 'heady_health',
      description: 'Get Heady system health status',
      inputSchema: { type: 'object', properties: {} },
      handler: async () => ({
        bees: this.beeFactory.getStats(),
        memory: this.vectorMemory.getStats(),
        gateway: this.liquidGateway.getHealth(),
        healing: this.selfHealing.getStatus(),
      }),
    });

    this.mcpGateway.registerTool({
      name: 'heady_memory_search',
      description: 'Search Heady vector memory',
      inputSchema: {
        type: 'object',
        properties: { query: { type: 'string' }, limit: { type: 'number' } },
        required: ['query'],
      },
      handler: async (args) => this.vectorMemory.search(args.query, { limit: args.limit }),
    });

    this.mcpGateway.registerTool({
      name: 'heady_memory_store',
      description: 'Store content in Heady vector memory',
      inputSchema: {
        type: 'object',
        properties: { content: { type: 'string' }, metadata: { type: 'object' } },
        required: ['content'],
      },
      handler: async (args) => this.vectorMemory.store(args.content, args.metadata),
    });

    this.mcpGateway.registerTool({
      name: 'heady_bee_spawn',
      description: 'Spawn a new bee worker',
      inputSchema: {
        type: 'object',
        properties: { type: { type: 'string' }, swarm: { type: 'string' } },
        required: ['type'],
      },
      handler: async (args) => {
        const bee = await this.beeFactory.spawn(args.type, { swarm: args.swarm });
        return { id: bee.id, type: bee.type, state: bee.state };
      },
    });

    this.mcpGateway.registerTool({
      name: 'heady_llm_route',
      description: 'Route an LLM request through the Liquid Gateway',
      inputSchema: {
        type: 'object',
        properties: {
          prompt: { type: 'string' },
          model: { type: 'string' },
          strategy: { type: 'string', enum: ['fastest', 'cheapest', 'best', 'race'] },
        },
        required: ['prompt'],
      },
      handler: async (args) => this.liquidGateway.route(args),
    });
  }
}

// Boot if run directly
const manager = new HeadyManager();
manager.boot().catch(err => {
  console.error('[HEADY] Fatal boot error:', err);
  process.exit(1);
});

export default HeadyManager;
