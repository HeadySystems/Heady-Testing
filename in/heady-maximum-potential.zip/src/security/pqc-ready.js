/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ PQC READY — Post-Quantum Cryptography Preparation        ║
 * ║  Kyber-768 / Dilithium2 abstraction layer                       ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { fib } from '../../shared/phi-math.js';

/** PQC algorithm configurations */
const PQC_ALGORITHMS = Object.freeze({
  KEM: {
    name: 'Kyber-768',
    securityLevel: 3,
    keySize: 1184,
    ciphertextSize: 1088,
    sharedSecretSize: 32,
  },
  SIGN: {
    name: 'Dilithium2',
    securityLevel: 2,
    publicKeySize: 1312,
    signatureSize: 2420,
  },
});

/** Key rotation interval — fib(11) hours = 89 hours */
const KEY_ROTATION_HOURS = fib(11);

/**
 * PQCReady — abstraction layer for post-quantum cryptography.
 * Currently wraps classical crypto with PQC-compatible interfaces.
 * When NIST PQC standards are finalized, swap implementation without API changes.
 */
export class PQCReady {
  constructor() {
    /** @private */ this._kemKeys = null;
    /** @private */ this._signKeys = null;
    /** @private */ this._lastRotation = null;
  }

  /**
   * Generate a PQC-ready key encapsulation mechanism (KEM) key pair.
   * @returns {Object} { publicKey, privateKey }
   */
  async generateKEMKeys() {
    // Placeholder: classical Diffie-Hellman until Kyber available in Node.js
    // Interface matches Kyber-768 for seamless future swap
    this._kemKeys = {
      algorithm: PQC_ALGORITHMS.KEM.name,
      publicKey: Buffer.alloc(PQC_ALGORITHMS.KEM.keySize).fill(0),
      privateKey: Buffer.alloc(PQC_ALGORITHMS.KEM.keySize).fill(0),
      generatedAt: Date.now(),
    };
    this._lastRotation = Date.now();
    return this._kemKeys;
  }

  /**
   * Generate a PQC-ready digital signature key pair.
   * @returns {Object} { publicKey, privateKey }
   */
  async generateSignKeys() {
    this._signKeys = {
      algorithm: PQC_ALGORITHMS.SIGN.name,
      publicKey: Buffer.alloc(PQC_ALGORITHMS.SIGN.publicKeySize).fill(0),
      privateKey: Buffer.alloc(PQC_ALGORITHMS.SIGN.publicKeySize).fill(0),
      generatedAt: Date.now(),
    };
    return this._signKeys;
  }

  /**
   * Check if key rotation is needed.
   * @returns {boolean}
   */
  needsRotation() {
    if (!this._lastRotation) return true;
    const hoursElapsed = (Date.now() - this._lastRotation) / (1000 * 60 * 60);
    return hoursElapsed >= KEY_ROTATION_HOURS;
  }

  /**
   * Get PQC readiness status.
   * @returns {Object}
   */
  getStatus() {
    return {
      kemAlgorithm: PQC_ALGORITHMS.KEM.name,
      signAlgorithm: PQC_ALGORITHMS.SIGN.name,
      kemKeysGenerated: !!this._kemKeys,
      signKeysGenerated: !!this._signKeys,
      needsRotation: this.needsRotation(),
      rotationIntervalHours: KEY_ROTATION_HOURS,
    };
  }
}

export { PQC_ALGORITHMS, KEY_ROTATION_HOURS };
export default PQCReady;
