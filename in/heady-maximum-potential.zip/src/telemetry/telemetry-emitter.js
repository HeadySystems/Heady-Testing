/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  HEADY™ TELEMETRY — Structured Logging & OpenTelemetry            ║
 * ║  Centralized observability for all Heady components               ║
 * ║  © 2024-2026 HeadySystems Inc. All Rights Reserved.              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */

'use strict';

import { PHI, PSI, fib } from '../../shared/phi-math.js';

/** Log ring buffer size — fib(17) = 1597 */
const RING_BUFFER_SIZE = fib(17);

/** Log levels */
const LEVEL = Object.freeze({
  DEBUG: 0,
  INFO:  1,
  WARN:  2,
  ERROR: 3,
  FATAL: 4,
});

/**
 * TelemetryEmitter — centralized structured logging and event emission.
 * All Heady components emit telemetry through this interface.
 */
export class TelemetryEmitter {
  constructor({ minLevel = LEVEL.INFO, sinks = [] } = {}) {
    /** @private */ this._minLevel = minLevel;
    /** @private */ this._sinks = sinks;
    /** @private */ this._buffer = [];
    /** @private */ this._listeners = new Map();
    /** @private */ this._totalEvents = 0;
  }

  /**
   * Emit a telemetry event.
   * @param {string} event - Event name (e.g., 'bee.spawned', 'pipeline.completed')
   * @param {Object} data - Event data
   * @param {number} [level] - Log level
   */
  emit(event, data = {}, level = LEVEL.INFO) {
    if (level < this._minLevel) return;

    const entry = {
      event,
      level,
      timestamp: new Date().toISOString(),
      epochMs: Date.now(),
      ...data,
    };

    // Ring buffer
    this._buffer.push(entry);
    if (this._buffer.length > RING_BUFFER_SIZE) {
      this._buffer.shift();
    }

    this._totalEvents++;

    // Notify listeners
    const listeners = this._listeners.get(event) || [];
    for (const fn of listeners) {
      try { fn(entry); } catch (_) {}
    }

    // Push to sinks
    for (const sink of this._sinks) {
      try { sink.write(entry); } catch (_) {}
    }
  }

  /**
   * Subscribe to a specific event.
   * @param {string} event
   * @param {Function} callback
   */
  on(event, callback) {
    if (!this._listeners.has(event)) this._listeners.set(event, []);
    this._listeners.get(event).push(callback);
  }

  /**
   * Get recent log entries.
   * @param {number} [count]
   * @returns {Object[]}
   */
  getRecent(count = fib(8)) {
    return this._buffer.slice(-count);
  }

  /**
   * Get telemetry statistics.
   * @returns {Object}
   */
  getStats() {
    return {
      totalEvents: this._totalEvents,
      bufferSize: this._buffer.length,
      maxBufferSize: RING_BUFFER_SIZE,
      sinkCount: this._sinks.length,
      listenerCount: [...this._listeners.values()].reduce((sum, l) => sum + l.length, 0),
    };
  }
}

export { LEVEL, RING_BUFFER_SIZE };
export default TelemetryEmitter;
