#!/usr/bin/env bash
# Heady Systems — Developer Environment Setup
# Eric Haywood — Sacred Geometry v4.0
# Target: Zero to running system in < 5 minutes

set -euo pipefail

BOLD="\033[1m"
GREEN="\033[32m"
RED="\033[31m"
YELLOW="\033[33m"
NC="\033[0m"

log() { echo -e "${GREEN}[HEADY]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
fail() { echo -e "${RED}[FAIL]${NC} $1"; exit 1; }

log "Heady Systems — Developer Setup"
log "Sacred Geometry v4.0 — φ = 1.618033988749895"
echo ""

# Check Node.js 20+
if ! command -v node &> /dev/null; then
  fail "Node.js not found. Install Node.js 20+ from https://nodejs.org"
fi
NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
  fail "Node.js 20+ required. Current: $(node -v)"
fi
log "Node.js $(node -v) ✓"

# Check Docker
if ! command -v docker &> /dev/null; then
  fail "Docker not found. Install from https://docker.com"
fi
log "Docker $(docker --version | cut -d' ' -f3) ✓"

# Check docker-compose
if ! command -v docker compose &> /dev/null && ! command -v docker-compose &> /dev/null; then
  warn "docker-compose not found — needed for full stack"
else
  log "Docker Compose ✓"
fi

# Check gcloud CLI
if command -v gcloud &> /dev/null; then
  log "gcloud CLI $(gcloud --version 2>/dev/null | head -1 | awk '{print $NF}') ✓"
else
  warn "gcloud CLI not found — optional for local dev"
fi

# Check .env file
if [ ! -f .env ]; then
  if [ -f .env.template ]; then
    cp .env.template .env
    log "Created .env from template — fill in secrets before running"
  else
    warn "No .env file found — create from .env.template"
  fi
else
  log ".env exists ✓"
fi

# Install dependencies
log "Installing root dependencies..."
npm ci 2>/dev/null || npm install

# Install service dependencies (parallel, Fibonacci batch size of 8)
log "Installing service dependencies (parallel batches of 8)..."
BATCH=0
PIDS=()
for svc_dir in services/*/; do
  if [ -f "$svc_dir/package.json" ]; then
    (cd "$svc_dir" && npm ci 2>/dev/null || npm install) &
    PIDS+=($!)
    BATCH=$((BATCH + 1))
    if [ "$BATCH" -ge 8 ]; then
      for pid in "${PIDS[@]}"; do
        wait "$pid" 2>/dev/null || true
      done
      PIDS=()
      BATCH=0
    fi
  fi
done
# Wait for remaining
for pid in "${PIDS[@]}"; do
  wait "$pid" 2>/dev/null || true
done
log "Dependencies installed ✓"

# Pull Docker images
log "Pulling infrastructure images..."
docker pull pgvector/pgvector:pg16 &
docker pull nats:2.10-alpine &
docker pull redis:7-alpine &
docker pull hashicorp/consul:1.18 &
wait
log "Images pulled ✓"

# Start infrastructure
log "Starting infrastructure (pgvector, NATS, Redis, Consul)..."
docker compose up -d pgvector nats redis consul

# Wait for pgvector
log "Waiting for pgvector to be ready..."
RETRIES=0
MAX_RETRIES=13  # fib(7)
until docker compose exec -T pgvector pg_isready -U heady 2>/dev/null; do
  RETRIES=$((RETRIES + 1))
  if [ "$RETRIES" -ge "$MAX_RETRIES" ]; then
    fail "pgvector failed to start after $MAX_RETRIES attempts"
  fi
  sleep 2
done
log "pgvector ready ✓"

echo ""
log "${BOLD}Setup complete!${NC}"
log ""
log "Next steps:"
log "  1. Fill in secrets in .env"
log "  2. docker compose up           — Start all 59 services"
log "  3. docker compose up -d        — Start in background"
log "  4. curl http://0.0.0.0:3345/health — Test API gateway"
log ""
log "Sacred Geometry v4.0 — φ = 1.618 | ψ = 0.618 | FIB = [1,1,2,3,5,8,13,21,34,55,89,144,233]"
