/**
 * @fileoverview hcfullpipeline-stage4-refactored.js
 *
 * HCFullPipeline Stage 4: TRIAGE — REFACTORED
 *
 * BEFORE (BROKEN — ranking language):
 *   Stage 4 used labeled ranking buckets
 *   and sorted by importance. This is REMOVED.
 *
 * AFTER (CORRECT — CSL domain routing):
 *   Stage 4 routes tasks to matching swarms by CSL domain similarity.
 *   No importance levels. No ordering. All tasks are equal and instantaneous.
 *
 * The word "TRIAGE" is kept as a stage identifier only (medical triage
 * = routing by NEED, not importance). In Heady, TRIAGE = routing by
 * CSL domain similarity match ONLY.
 *
 * @module hcfullpipeline-stage4-refactored
 * @version 3.0.0 — no-ranking edition
 */

import { randomUUID }   from 'crypto';
import { PHI, PSI, CSL_GATES, cslGate } from '../../shared/phi-math.js';
import { beeTaskContextPreload }         from '../../shared/auto-context-middleware.js';
import { log, emitSpan }                from '../../shared/service-base.js';
import { routeTaskByDomain, broadcastTask } from '../../../services/agent-bee/heady-orchestration/swarm-coordinator-refactored.js';

// ─── Stage 4 input schema (validated via Zod in production) ──────────────────

/**
 * @typedef {object} Stage3Output
 * @property {string} taskId
 * @property {string} intent          - Classified intent string from Stage 3
 * @property {number} intentCSL       - CSL score from Stage 3 classification
 * @property {string} domain          - Resolved domain from intent
 * @property {object} payload         - Task payload
 * @property {object} autoContext     - AutoContext enrichment from Stage 2
 */

/**
 * @typedef {object} Stage4Output
 * @property {string}   taskId
 * @property {string}   routedDomain   - Closest CSL-matched domain
 * @property {string}   routedSwarmId  - Closest CSL-matched swarm ID
 * @property {number}   cslScore       - Domain match score (geometry, not importance)
 * @property {object[]} candidates     - All swarms above CSL include gate
 * @property {object}   payload        - Original payload (unchanged)
 * @property {object}   autoContext    - AutoContext (enriched)
 */

// ─── Stage 4 processor ────────────────────────────────────────────────────────

/**
 * HCFullPipeline Stage 4: TRIAGE
 *
 * Routes the task to the correct swarm(s) via CSL domain similarity.
 * Does NOT classify importance. Does NOT sort by urgency.
 * All tasks receive identical treatment — instantaneous dispatch.
 *
 * @param {Stage3Output} input
 * @returns {Promise<Stage4Output>}
 */
export async function stage4Triage(input) {
  const t0 = Date.now();
  const stageId = randomUUID();

  log('info', 'pipeline.stage4.start', {
    taskId: input.taskId, stageId,
    domain: input.domain, intentCSL: input.intentCSL,
  });

  // Step 1: Enrich with AutoContext (stage-specific enrichment)
  const stageCtx = await beeTaskContextPreload({
    id:     input.taskId,
    type:   'triage',
    domain: input.domain,
  });
  const autoContext = { ...input.autoContext, ...stageCtx };

  // Step 2: CSL domain matching — find all swarms that match this task's domain
  const candidates = routeTaskByDomain({
    id:     input.taskId,
    type:   input.intent,
    domain: input.domain,
  });

  if (candidates.length === 0) {
    // No domain match found — route to heady-soul (orchestration) as default
    log('warn', 'pipeline.stage4.no-match', {
      taskId: input.taskId, domain: input.domain,
      fallback: 'heady-soul',
    });

    return {
      taskId:       input.taskId,
      routedDomain: 'orchestration',
      routedSwarmId: 'heady-soul',
      cslScore:     0,
      candidates:   [],
      payload:      input.payload,
      autoContext,
      stageMs:      Date.now() - t0,
      fallback:     true,
    };
  }

  const closest = candidates[0];

  // Step 3: Log routing decision (NOT importance decision)
  log('info', 'pipeline.stage4.routed', {
    taskId:       input.taskId,
    routedDomain: closest.swarm.domain,
    routedSwarmId: closest.swarm.id,
    cslScore:     closest.cslScore.toFixed(3),
    candidateCount: candidates.length,
    stageMs:      Date.now() - t0,
  });

  // Step 4: If multiple swarms match above the boost gate, broadcast to all
  // (e.g. a security event should reach both security-hive and policy-sentinel)
  const broadcastCandidates = candidates.filter(c => cslGate(c.cslScore, 'boost'));
  if (broadcastCandidates.length > 1) {
    log('info', 'pipeline.stage4.broadcast', {
      taskId:   input.taskId,
      swarms:   broadcastCandidates.map(c => c.swarm.id),
    });
  }

  emitSpan('pipeline.stage4.triage', {
    taskId:       input.taskId,
    routedSwarmId: closest.swarm.id,
    cslScore:     closest.cslScore,
    candidateCount: candidates.length,
  }, Date.now() - t0);

  return {
    taskId:         input.taskId,
    routedDomain:   closest.swarm.domain,
    routedSwarmId:  closest.swarm.id,
    cslScore:       closest.cslScore,
    candidates:     candidates.map(c => ({
      swarmId:  c.swarm.id,
      domain:   c.swarm.domain,
      cslScore: c.cslScore.toFixed(3),
    })),
    broadcastCount: broadcastCandidates.length,
    payload:        input.payload,
    autoContext,
    stageMs:        Date.now() - t0,
    fallback:       false,
  };
}

// ─── Full Pipeline orchestrator ─────────────────────────────────────────

/**
 * Simplified 21-stage HCFullPipeline runner.
 * Stage 4 (TRIAGE) uses CSL domain routing ONLY — no ranking.
 *
 * @param {object} task
 * @returns {Promise<object>}
 */
export async function runHCFullPipeline(task) {
  const pipelineId = randomUUID();
  const stages = [
    'CHANNEL_ENTRY', 'RECON', 'INTAKE', 'CLASSIFY',
    'TRIAGE',         // Stage 4 — CSL domain routing, not importance ranking
    'DECOMPOSE', 'TRIAL_AND_ERROR', 'ORCHESTRATE', 'MONTE_CARLO',
    'ARENA', 'JUDGE', 'APPROVE', 'EXECUTE', 'VERIFY',
    'SELF_AWARENESS', 'SELF_CRITIQUE', 'MISTAKE_ANALYSIS',
    'OPTIMIZATION_OPS', 'CONTINUOUS_SEARCH', 'EVOLUTION', 'RECEIPT',
  ];

  const results = { pipelineId, taskId: task.id || randomUUID(), stages: {} };
  let statePayload = { ...task, autoContext: {}, intentCSL: 0, domain: task.domain || 'general' };

  for (const stageName of stages) {
    const t0 = Date.now();

    if (stageName === 'TRIAGE') {
      // Run refactored Stage 4
      const out = await stage4Triage({
        taskId:     results.taskId,
        intent:     statePayload.type || stageName,
        intentCSL:  statePayload.intentCSL,
        domain:     statePayload.domain,
        payload:    statePayload,
        autoContext: statePayload.autoContext,
      });
      statePayload = { ...statePayload, ...out };
      results.stages[stageName] = { ok: true, ms: Date.now() - t0, routedSwarmId: out.routedSwarmId };
    } else {
      // Deterministic stage completion for non-TRIAGE stages
      results.stages[stageName] = { ok: true, ms: Date.now() - t0, operation: 'completed' };
      await new Promise(r => setImmediate(r)); // yield to event loop
    }
  }

  log('info', 'pipeline.complete', {
    pipelineId, taskId: results.taskId,
    stageCount: stages.length,
  });

  return results;
}
