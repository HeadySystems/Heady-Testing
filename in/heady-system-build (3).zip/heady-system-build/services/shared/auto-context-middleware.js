/**
 * @fileoverview HeadyAutoContext Middleware — MANDATORY for every service endpoint.
 *
 * Injects HeadyAutoContext enrichment BEFORE every request is processed.
 * Route by CSL domain match ONLY. No ranking. No priorities. Everything is instantaneous.
 *
 * @module auto-context-middleware
 * @version 2.1.0
 */

import { randomUUID } from 'crypto';
import { cslGate, PHI, PSI } from './phi-math.js';

const AUTOCONTEXT_URL = process.env.AUTOCONTEXT_URL || 'http://heady-auto-context:8907';
const SERVICE_NAME    = process.env.SERVICE_NAME    || 'heady-service';

function writeLog(level, event, extra = {}) {
  console[level === 'error' ? 'error' : 'info'](JSON.stringify({
    timestamp: new Date().toISOString(),
    level,
    service: SERVICE_NAME,
    event,
    ...extra,
  }));
}

function buildContextIndexItem(user) {
  return {
    id: `auth-user-${user.uid}`,
    content: `User sign-in: ${user.email || user.uid} via ${user.provider || 'unknown-provider'}`,
    metadata: {
      source: 'auth-runtime',
      type: 'auth-event',
      domain: 'auth',
      tags: ['auth', 'user-profile', user.provider || 'unknown-provider'],
      url: null,
      changed: new Date().toISOString(),
    },
  };
}

function phiTimeoutMs() {
  return Math.round(5000 * PSI);
}

/**
 * Fetch enriched context from the HeadyAutoContext service.
 * @param {object} payload - { query, userId, domain, tags }
 * @returns {Promise<object>} enriched context bundle
 */
async function fetchAutoContext(payload) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), phiTimeoutMs());
    const res = await fetch(`${AUTOCONTEXT_URL}/context/enrich`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    clearTimeout(timeout);
    if (!res.ok) throw new Error(`AutoContext responded ${res.status}`);
    return await res.json();
  } catch (err) {
    writeLog('warn', 'autocontext.unavailable', {
      url: `${AUTOCONTEXT_URL}/context/enrich`,
      error: err.message,
    });
    return { enriched: false, context: {}, cslScore: 0 };
  }
}

/**
 * Express/Fastify-compatible AutoContext middleware.
 *
 * Attaches `req.headyContext` before downstream handlers run.
 * Emits structured log with correlation ID and CSL score.
 *
 * @param {object} req
 * @param {object} res
 * @param {function} next
 */
export async function autoContextMiddleware(req, res, next) {
  const correlationId = req.headers['x-correlation-id'] || randomUUID();
  req.correlationId   = correlationId;
  res.setHeader('x-correlation-id', correlationId);

  const userId  = req.user?.uid || req.headers['x-heady-uid'] || 'anonymous';
  const domain  = req.headers['x-heady-domain'] || SERVICE_NAME;
  const query   = req.body?.query || req.query?.q || req.path;

  const start = Date.now();
  const ctx   = await fetchAutoContext({ query, userId, domain, correlationId });
  const ms    = Date.now() - start;

  req.headyContext = {
    ...ctx,
    correlationId,
    userId,
    domain,
    serviceName: SERVICE_NAME,
    enrichmentMs: ms,
  };

  // CSL gate logging — only emit span if context was enriched
  if (cslGate(ctx.cslScore || 0, 'include')) {
    writeLog('info', 'autocontext.enriched', {
      correlationId,
      userId,
      domain,
      cslScore: ctx.cslScore,
      enrichmentMs: ms,
    });
  }

  next();
}

/**
 * Health-check enrichment: attaches historical context for anomaly detection.
 * Used on /health and /healthz endpoints.
 *
 * @param {string} serviceName
 * @returns {Promise<object>}
 */
export async function healthContextEnrich(serviceName) {
  return fetchAutoContext({
    query: `health-check ${serviceName}`,
    domain: serviceName,
    tags: ['health', 'monitoring'],
  });
}

/**
 * Bee task context pre-load — call before any bee task execution.
 * @param {object} task - { id, type, domain, payload }
 * @returns {Promise<object>}
 */
export async function beeTaskContextPreload(task) {
  return fetchAutoContext({
    query: `${task.type} ${task.domain}`,
    domain: task.domain || SERVICE_NAME,
    tags: ['bee', 'task', task.type],
  });
}

/**
 * Auth event context indexer — indexes user profile on sign-in.
 * @param {object} user - { uid, email, displayName, provider }
 * @returns {Promise<void>}
 */
export async function indexAuthEvent(user) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), phiTimeoutMs());
    await fetch(`${AUTOCONTEXT_URL}/context/index-batch`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source: 'auth-runtime',
        contentType: 'auth-event',
        domain: 'auth',
        items: [buildContextIndexItem(user)],
      }),
      signal: controller.signal,
    });
    clearTimeout(timeout);
  } catch (err) {
    writeLog('warn', 'autocontext.auth_index_failed', {
      userId: user.uid,
      error: err.message,
    });
  }
}
