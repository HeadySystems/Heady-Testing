/**
 * @fileoverview phi-math.js — Sacred Geometry constants and math utilities.
 * All thresholds, weights, timings, and queue limits derive from φ and Fibonacci.
 * NO priority constants exist here. Everything is equal. Everything is instantaneous.
 *
 * @module phi-math
 * @version 2.1.0
 */

export const PHI = 1.618033988749895;       // Golden Ratio φ
export const PSI = 1 / PHI;                 // ≈ 0.618 (φ conjugate)
export const PHI_SQ = PHI * PHI;            // ≈ 2.618
export const PSI_SQ = PSI * PSI;            // ≈ 0.382

export const VECTOR_DIM = 384;              // Embedding dimensions (all-MiniLM-L6-v2)

/**
 * CSL gate thresholds — geometric relevance matching ONLY, NOT importance scoring.
 * include: minimum cosine similarity to include in context
 * boost:   threshold to amplify/weight in context injection
 * inject:  threshold for automatic deep injection
 */
export const CSL_GATES = {
  include: PSI_SQ,                          // ≈ 0.382
  boost:   PSI,                             // ≈ 0.618
  inject:  PSI + 0.1,                       // ≈ 0.718
};

/** CSL routing bands for domain matching only. */
export const CSL_ROUTING_ZONES = {
  includeBand: 1 - PSI * 0.5,               // ≈ 0.691
  boostBand:   1 - Math.pow(PSI, 2) * 0.5, // ≈ 0.809
  injectBand:  1 - Math.pow(PSI, 3) * 0.5, // ≈ 0.882
};

/** Deduplication threshold for swarm tasks */
export const DEDUP_THRESHOLD = PSI;         // ≈ 0.618

/** Pressure levels for adaptive throttling (NOT priority ranking) */
export const PRESSURE_LEVELS = {
  NOMINAL: 'nominal',
  ELEVATED: 'elevated',
  SATURATED: 'saturated',
};

/**
 * Generate Fibonacci sequence up to n terms.
 * @param {number} n
 * @returns {number[]}
 */
export function fibSequence(n) {
  const seq = [0, 1];
  for (let i = 2; i < n; i++) seq.push(seq[i - 1] + seq[i - 2]);
  return seq.slice(0, n);
}

export const FIB = fibSequence(16); // [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610]

/**
 * Phi-exponential backoff in milliseconds.
 * @param {number} attempt - 0-based attempt index
 * @param {number} [baseMs=1000]
 * @returns {number}
 */
export function phiBackoff(attempt, baseMs = 1000) {
  return Math.round(baseMs * Math.pow(PHI, attempt));
}

/**
 * Evaluate a CSL gate: returns true if cosine similarity passes the threshold.
 * @param {number} cosineSimilarity
 * @param {'include'|'boost'|'inject'} gate
 * @returns {boolean}
 */
export function cslGate(cosineSimilarity, gate = 'include') {
  return cosineSimilarity >= CSL_GATES[gate];
}

/**
 * Blend two scores using phi-harmonic weights.
 * @param {number} a
 * @param {number} b
 * @returns {number}
 */
export function cslBlend(a, b) {
  return a * PSI + b * (1 - PSI);
}

/**
 * Classify system pressure level (for adaptive throttling — NOT for ranking work).
 * @param {number} load - 0..1 normalized load factor
 * @returns {string}
 */
export function classifyPressure(load) {
  if (load >= PSI) return PRESSURE_LEVELS.SATURATED;
  if (load >= PSI_SQ) return PRESSURE_LEVELS.ELEVATED;
  return PRESSURE_LEVELS.NOMINAL;
}

/**
 * Phi-scaled resource weights for N items (Fibonacci ratios, normalized to 1).
 * @param {number} n
 * @returns {number[]}
 */
export function phiResourceWeights(n) {
  const seq = fibSequence(n + 2).slice(2); // start from fib(2)=1
  const total = seq.reduce((a, b) => a + b, 0);
  return seq.map(v => v / total);
}

/**
 * Fusion weights array [PSI, PSI^2, PSI^3, ...] normalized.
 * @param {number} n
 * @returns {number[]}
 */
export function phiFusionWeights(n) {
  const w = Array.from({ length: n }, (_, i) => Math.pow(PSI, i + 1));
  const total = w.reduce((a, b) => a + b, 0);
  return w.map(v => v / total);
}

/**
 * Phi-adaptive interval that scales with load.
 * @param {number} baseMs
 * @param {number} load - 0..1
 * @returns {number}
 */
export function phiAdaptiveInterval(baseMs, load) {
  return Math.round(baseMs * (1 + load * PSI));
}

/**
 * Nth Fibonacci number (memoized).
 * @param {number} n
 * @returns {number}
 */
const _fibCache = new Map();
export function fib(n) {
  if (n <= 1) return n;
  if (_fibCache.has(n)) return _fibCache.get(n);
  const result = fib(n - 1) + fib(n - 2);
  _fibCache.set(n, result);
  return result;
}
