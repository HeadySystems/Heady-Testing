/**
 * Shared domain runtime helpers for Heady services.
 * All functions are concrete runtime helpers intended for deployable service behavior.
 */

export class HeadyServiceError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'HeadyServiceError';
    this.code = code;
    this.details = details;
  }
}

export function normalizeInput(input = {}) {
  return {
    requestId: input.requestId || input.id || null,
    action: input.action || input.intent || 'synchronize',
    payload: input.payload || input,
    metadata: input.metadata || {},
  };
}

export function deriveExecutionPlan({ service, domain, normalized, context }) {
  const contextSignals = Object.keys(context || {}).slice(0, 8);
  const payloadKeys = Object.keys(normalized.payload || {});
  return {
    service,
    domain,
    action: normalized.action,
    payloadKeys,
    contextSignals,
    concurrentMode: 'instantaneous-equal-status',
    cslRoutingBasis: context?.matchedDomain || domain,
    generatedAt: new Date().toISOString(),
  };
}

export function deriveDependencies(service, domain) {
  const base = ['heady-auto-context', 'api-gateway'];
  const byDomain = {
    inference: ['ai-router', 'model-gateway', 'heady-embed'],
    federation: ['heady-orchestration', 'heady-hive'],
    orchestration: ['heady-bee-factory', 'heady-conductor'],
    pipeline: ['hcfullpipeline-executor', 'heady-chain'],
    embedding: ['heady-memory', 'heady-vector'],
    memory: ['heady-vector', 'memory-mcp'],
    vector: ['heady-memory', 'heady-projection'],
    projection: ['heady-vector', 'heady-memory'],
    bee: ['heady-hive', 'heady-orchestration'],
    security: ['heady-guard', 'heady-governance'],
    governance: ['heady-guard', 'heady-security'],
    monitoring: ['heady-health', 'heady-maintenance'],
    evaluation: ['heady-health', 'heady-testing'],
    reliability: ['heady-health', 'heady-governance'],
    testing: ['heady-eval', 'heady-health'],
    web: ['heady-ui', 'heady-buddy'],
    companion: ['heady-web', 'heady-auto-context'],
    ui: ['heady-web', 'heady-buddy'],
    onboarding: ['heady-buddy', 'heady-auth'],
    tasks: ['heady-web', 'heady-conductor'],
    cache: ['heady-memory', 'heady-chain'],
    routing: ['api-gateway', 'domain-router'],
    gateway: ['ai-router', 'heady-auth'],
    mcp: ['memory-mcp', 'perplexity-mcp'],
    integration: ['api-gateway', 'heady-auto-context'],
    cms: ['drupal-sync', 'heady-memory'],
    learning: ['heady-memory', 'heady-eval'],
    documentation: ['heady-autobiographer', 'heady-memory'],
    creative: ['heady-midi', 'heady-vinci'],
    finops: ['budget-tracker', 'heady-governance'],
    cli: ['api-gateway', 'heady-auth'],
    prompts: ['prompt-manager', 'heady-memory'],
    context: ['heady-memory', 'heady-vector'],
  };
  return [...new Set([service, ...base, ...(byDomain.get(domain, []))])].filter(Boolean);
}

export function buildOperationalResponse({ service, domain, normalized, context, cslScore }) {
  const executionPlan = deriveExecutionPlan({ service, domain, normalized, context });
  return {
    accepted: true,
    service,
    domain,
    mode: 'instantaneous-concurrent',
    cslScore,
    executionPlan,
    dependencies: deriveDependencies(service, domain),
    contextSummary: {
      enriched: Boolean(context?.enriched),
      matchedDomain: context?.matchedDomain || domain,
      sessionId: context?.sessionId || null,
      sourceCount: Array.isArray(context?.sources) ? context.sources.length : 0,
    },
  };
}
