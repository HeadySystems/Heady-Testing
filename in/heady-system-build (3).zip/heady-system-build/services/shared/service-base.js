/**
 * @fileoverview service-base.js — Base factory for all Heady microservices.
 *
 * Every service created with this factory gets:
 *   - /health and /healthz endpoints
 *   - HeadyAutoContext middleware on every route
 *   - Structured logging with correlation IDs
 *   - Phi-exponential backoff error handling
 *   - OpenTelemetry span emission
 *   - Graceful shutdown (SIGTERM → drain → SIGKILL)
 *   - Consul service registration
 *   - Bulkhead pattern via semaphore pool
 *
 * NO priority-based routing. Route by CSL domain match ONLY.
 *
 * @module service-base
 * @version 2.1.0
 */

import { createServer } from 'http';
import { randomUUID }   from 'crypto';
import { PHI, PSI, phiBackoff, fibSequence } from './phi-math.js';
import { autoContextMiddleware, healthContextEnrich } from './auto-context-middleware.js';

const SERVICE_NAME    = process.env.SERVICE_NAME    || 'heady-service';
const SERVICE_PORT    = parseInt(process.env.PORT   || '8080', 10);
const CONSUL_URL      = process.env.CONSUL_URL      || 'http://consul:8500';
const OTEL_ENDPOINT   = process.env.OTEL_ENDPOINT   || 'http://otel-collector:4318';
const BULKHEAD_SLOTS  = parseInt(process.env.BULKHEAD_SLOTS || String(fibSequence(8)[7]), 10); // 13

/** Simple in-memory semaphore for bulkhead pattern */
class Bulkhead {
  constructor(maxConcurrent = BULKHEAD_SLOTS) {
    this.max     = maxConcurrent;
    this.running = 0;
    this.queue   = [];
  }

  async acquire() {
    return new Promise((resolve, reject) => {
      const tryAcquire = () => {
        if (this.running < this.max) { this.running++; resolve(); }
        else this.queue.push({ resolve, reject });
      };
      tryAcquire();
    });
  }

  release() {
    this.running = Math.max(0, this.running - 1);
    const next = this.queue.shift();
    if (next) { this.running++; next.resolve(); }
  }
}

export const bulkhead = new Bulkhead();

/** Structured logger */
export function log(level, event, extra = {}) {
  console[level === 'error' ? 'error' : 'info'](JSON.stringify({
    timestamp: new Date().toISOString(),
    level,
    service: SERVICE_NAME,
    event,
    ...extra,
  }));
}

/** Emit a minimal OpenTelemetry-compatible JSON span to stdout (collector picks up via log pipeline) */
export function emitSpan(name, attributes = {}, durationMs = 0) {
  console.info(JSON.stringify({
    'otel.span': true,
    traceId:     randomUUID().replace(/-/g, ''),
    spanId:      randomUUID().replace(/-/g, '').slice(0, 16),
    name:        `${SERVICE_NAME}/${name}`,
    durationMs,
    attributes:  { 'service.name': SERVICE_NAME, ...attributes },
    timestamp:   Date.now(),
  }));
}

/** Register with Consul */
async function consulRegister() {
  try {
    await fetch(`${CONSUL_URL}/v1/agent/service/register`, {
      method:  'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ID:      `${SERVICE_NAME}-${randomUUID().slice(0, 8)}`,
        Name:    SERVICE_NAME,
        Port:    SERVICE_PORT,
        Tags:    ['heady', 'autocontext'],
        Check:   {
          HTTP:                          process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:${SERVICE_PORT}/health`,
          Interval:                      `${Math.round(30 * PHI)}s`, // phi-scaled 48s
          DeregisterCriticalServiceAfter: '89s',                     // fib(11)
        },
      }),
    });
    log('info', 'consul.registered', { port: SERVICE_PORT });
  } catch (err) {
    log('warn', 'consul.registration.failed', { error: err.message });
  }
}

/** Parse route/body from raw request (minimal router for services without Express) */
function parseRequest(req, body) {
  return {
    path:    req.url?.split('?')[0] || '/',
    query:   Object.fromEntries(new URLSearchParams(req.url?.split('?')[1] || '')),
    method:  req.method || 'GET',
    headers: req.headers,
    body,
    user:    null, // populated by auth middleware
    headyContext: null, // populated by autoContextMiddleware
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
  };
}

/**
 * Create and start a Heady microservice.
 *
 * @param {object} options
 * @param {string}   options.name          - Service name (overrides SERVICE_NAME env)
 * @param {number}   [options.port]        - Port (overrides PORT env)
 * @param {object[]} options.routes        - Array of { method, path, handler(req,res) }
 * @param {function} [options.onStart]     - Called after server starts
 * @param {function} [options.onShutdown]  - Called before server stops
 * @returns {object} { server, start, stop }
 */
export function createHeadyService({ name, port, routes = [], onStart, onShutdown }) {
  const svcName = name || SERVICE_NAME;
  const svcPort = port || SERVICE_PORT;
  const startTime = Date.now();
  let activeRequests = 0;
  let shuttingDown   = false;

  // Route map: { 'GET /path': handler }
  const routeMap = {};
  for (const r of routes) {
    routeMap[`${r.method.toUpperCase()} ${r.path}`] = r.handler;
  }

  const server = createServer(async (rawReq, rawRes) => {
    if (shuttingDown) {
      rawRes.writeHead(503, { 'Content-Type': 'application/json' });
      rawRes.end(JSON.stringify({ status: 'draining' }));
      return;
    }

    activeRequests++;
    let body = '';
    rawReq.on('data', chunk => { body += chunk; });

    rawReq.on('end', async () => {
      let parsed;
      try { parsed = JSON.parse(body); } catch { parsed = {}; }

      const req = parseRequest(rawReq, parsed);
      const res = {
        statusCode: 200,
        headers: { 'Content-Type': 'application/json' },
        setHeader(k, v) { this.headers[k] = v; },
        json(data, status = 200) {
          this.statusCode = status;
          rawRes.writeHead(this.statusCode, this.headers);
          rawRes.end(JSON.stringify(data));
        },
        send(text, status = 200) {
          this.statusCode = status;
          rawRes.writeHead(this.statusCode, { 'Content-Type': 'text/plain' });
          rawRes.end(text);
        },
      };

      const key = `${req.method} ${req.path}`;

      // ─── Health endpoints — bypass autocontext for latency ─────────────────
      if (req.path === '/health' || req.path === '/healthz') {
        const hCtx = await healthContextEnrich(svcName);
        activeRequests--;
        res.json({
          status:     'ok',
          service:    svcName,
          uptime:     Date.now() - startTime,
          activeRequests,
          contextEnriched: hCtx.enriched || false,
          version:    process.env.SERVICE_VERSION || '2.1.0',
          timestamp:  new Date().toISOString(),
        });
        return;
      }

      // ─── AutoContext middleware ──────────────────────────────────────────────
      let middlewareDone = false;
      const next = () => { middlewareDone = true; };
      await autoContextMiddleware(req, res, next);
      if (!middlewareDone) { activeRequests--; return; }

      // ─── Bulkhead acquire ───────────────────────────────────────────────────
      await bulkhead.acquire();

      try {
        const handler = routeMap[key] || routeMap[`ALL ${req.path}`];
        if (handler) {
          const t0 = Date.now();
          await handler(req, res);
          emitSpan(key, { correlationId: req.correlationId }, Date.now() - t0);
        } else {
          res.json({ error: 'Not Found', path: req.path }, 404);
        }
      } catch (err) {
        log('error', 'request.error', { path: req.path, error: err.message, stack: err.stack });
        res.json({ error: 'Internal Server Error', correlationId: req.correlationId }, 500);
      } finally {
        bulkhead.release();
        activeRequests--;
      }
    });
  });

  async function start() {
    await new Promise(resolve => server.listen(svcPort, resolve));
    log('info', 'service.started', { service: svcName, port: svcPort });
    await consulRegister();
    if (onStart) await onStart();
  }

  async function stop() {
    shuttingDown = true;
    log('info', 'service.draining', { activeRequests });

    // Wait for active requests to complete (max 34s — fib(9))
    const deadline = Date.now() + 34000;
    while (activeRequests > 0 && Date.now() < deadline) {
      await new Promise(r => setTimeout(r, 100));
    }

    if (onShutdown) await onShutdown();
    server.close();
    log('info', 'service.stopped', { service: svcName });
  }

  process.on('SIGTERM', () => stop().then(() => process.exit(0)));
  process.on('SIGINT',  () => stop().then(() => process.exit(0)));

  return { server, start, stop };
}
