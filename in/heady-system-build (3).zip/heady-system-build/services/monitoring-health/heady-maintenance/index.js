/**
 * @fileoverview heady-maintenance — Self-healing maintenance — quarantine, respawn, drift recovery, phi-heartbeat
 *
 * Service: heady-maintenance
 * Domain:  reliability
 * Port:    8402
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO priority-based routing. CSL domain match only. Everything is instantaneous.
 *
 * @module heady-maintenance
 * @version 2.1.0
 */

import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, CSL_GATES, cslGate } from '../../shared/phi-math.js';
import { HeadyServiceError, normalizeInput, buildOperationalResponse, deriveDependencies } from '../../shared/domain-runtime.js';

const SERVICE_NAME = 'heady-maintenance';
process.env.SERVICE_NAME = SERVICE_NAME;
process.env.SERVICE_HEALTH_URL = process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:8402/health`;

const state = {
  initialized: false,
  domain: 'reliability',
  startTime: Date.now(),
  processedCount: 0,
};

async function processDomainOperation({ input, context, domain, correlationId }) {
  const normalized = normalizeInput(input);
  if (!normalized.action) {
    throw new HeadyServiceError('invalid-action', 'A service action is required.', { correlationId });
  }

  const response = buildOperationalResponse({
    service: SERVICE_NAME,
    domain,
    normalized,
    context,
    cslScore: context?.cslScore || 0,
  });

  state.processedCount += 1;
  return {
    ...response,
    processedCount: state.processedCount,
    dependencyFanout: deriveDependencies(SERVICE_NAME, domain).length,
    serviceSummary: 'Self-healing maintenance — quarantine, respawn, drift recovery, phi-heartbeat',
  };
}

async function handleDomainRequest(req, res) {
  const { headyContext, correlationId, body } = req;
  const t0 = Date.now();
  const cslScore = headyContext?.cslScore || 0;

  if (!cslGate(cslScore, 'include') && body?.strict !== false) {
    log('info', 'csl.gate.miss', { domain: 'reliability', cslScore, correlationId });
  }

  try {
    const result = await processDomainOperation({
      input: body,
      context: headyContext,
      domain: 'reliability',
      correlationId,
    });

    emitSpan('domain-request', {
      domain: 'reliability',
      cslScore,
      correlationId,
      durationMs: Date.now() - t0,
    });

    res.json({
      service: SERVICE_NAME,
      domain: 'reliability',
      result,
      cslScore,
      correlationId,
      durationMs: Date.now() - t0,
    });
  } catch (err) {
    const status = err instanceof HeadyServiceError ? 400 : 500;
    log('error', 'domain-request.error', { error: err.message, correlationId, code: err.code || 'internal-error' });
    res.json({ error: err.message, code: err.code || 'internal-error', correlationId }, status);
  }
}

async function handleStatus(req, res) {
  res.json({
    service: SERVICE_NAME,
    domain: 'reliability',
    state,
    uptime: Date.now() - state.startTime,
    phi: PHI,
    cslGates: CSL_GATES,
    version: '2.1.0',
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8402,
  routes: [
    { method: 'POST', path: '/', handler: handleDomainRequest },
    { method: 'POST', path: '/process', handler: handleDomainRequest },
    { method: 'GET', path: '/status', handler: handleStatus },
  ],
  onStart: async () => {
    state.initialized = true;
    log('info', 'service.init', { service: SERVICE_NAME, domain: 'reliability', port: 8402 });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
