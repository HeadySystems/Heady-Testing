/**
 * @fileoverview heady-auto-context — HeadyAutoContext primary service — 384-dim vector indexing, CSL gates, enrichment API
 *
 * Service: heady-auto-context
 * Domain:  context
 * Port:    8907
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO priority-based routing. CSL domain match only. Everything is instantaneous.
 *
 * @module heady-auto-context
 * @version 2.2.0
 */

import { randomUUID, createHash } from 'crypto';
import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, CSL_GATES, cslGate } from '../../shared/phi-math.js';

const SERVICE_NAME = 'heady-auto-context';
process.env.SERVICE_NAME = SERVICE_NAME;
process.env.SERVICE_HEALTH_URL = process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:8907/health`;

const VECTOR_DIMENSION = 384;
const MAX_SOURCE_COUNT = 8;
const sourceIndex = new Map();

const state = {
  initialized: false,
  domain: 'context',
  startTime: Date.now(),
  processedCount: 0,
  indexedCount: 0,
  removedCount: 0,
  enrichCount: 0,
  lastMutationAt: null,
};

function normalizeText(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, ' ')
    .split(/\s+/)
    .map(token => token.trim())
    .filter(Boolean);
}

function unique(items) {
  return [...new Set(items.filter(Boolean))];
}

function toVectorSeed(text) {
  const digest = createHash('sha256').update(text).digest();
  return Array.from({ length: 12 }, (_, index) => digest[index] / 255);
}

function scoreSource({ tokens, domain }, queryTokens, requestedDomain) {
  const tokenSet = new Set(tokens);
  const overlap = queryTokens.filter(token => tokenSet.has(token)).length;
  const overlapScore = queryTokens.length ? overlap / queryTokens.length : 0;
  const domainScore = requestedDomain && domain === requestedDomain ? 0.236 : 0;
  return Math.min(1, overlapScore + domainScore);
}

function summarizeSource(entry, score) {
  return {
    id: entry.id,
    domain: entry.domain,
    score: Number(score.toFixed(3)),
    metadata: entry.metadata,
    excerpt: entry.content.slice(0, 280),
  };
}

function buildEnrichmentResponse({ query, userId, domain, correlationId, tags = [] }) {
  const queryTokens = unique([
    ...normalizeText(query),
    ...normalizeText(domain),
    ...normalizeText(tags.join(' ')),
  ]);

  const ranked = [...sourceIndex.values()]
    .map(entry => ({ entry, score: scoreSource(entry, queryTokens, domain) }))
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, MAX_SOURCE_COUNT);

  const topScore = ranked[0]?.score || 0;
  const matchedDomain = ranked[0]?.entry.domain || domain || 'general';

  return {
    enriched: ranked.length > 0,
    sessionId: correlationId || randomUUID(),
    userId: userId || 'anonymous',
    matchedDomain,
    cslScore: Number(topScore.toFixed(3)),
    sources: ranked.map(item => summarizeSource(item.entry, item.score)),
    vectorProfile: {
      dimension: VECTOR_DIMENSION,
      seed: toVectorSeed(`${query || ''}:${matchedDomain}`),
    },
    context: {
      queryTokens,
      sourceCount: ranked.length,
      lastMutationAt: state.lastMutationAt,
    },
  };
}

function upsertItem(item, batchContext = {}) {
  const content = String(item.content || '').trim();
  const id = String(item.id || randomUUID());
  const metadata = item.metadata || {};
  const domain = String(metadata.domain || batchContext.domain || batchContext.contentType || 'general');
  const tokens = unique([
    ...normalizeText(content),
    ...normalizeText(domain),
    ...normalizeText((metadata.tags || []).join(' ')),
    ...normalizeText(metadata.type || ''),
  ]);

  const entry = {
    id,
    content,
    tokens,
    domain,
    metadata: {
      source: metadata.source || batchContext.source || 'unknown',
      type: metadata.type || batchContext.contentType || 'document',
      url: metadata.url || null,
      changed: metadata.changed || new Date().toISOString(),
      tags: metadata.tags || [],
    },
    updatedAt: new Date().toISOString(),
  };

  sourceIndex.set(id, entry);
  state.indexedCount += 1;
  state.lastMutationAt = entry.updatedAt;
  return entry;
}

async function handleEnrich(req, res) {
  const { query = '', userId = 'anonymous', domain = 'general', correlationId, tags = [] } = req.body || {};
  const response = buildEnrichmentResponse({ query, userId, domain, correlationId, tags });
  state.processedCount += 1;
  state.enrichCount += 1;
  emitSpan('context.enrich', {
    domain,
    cslScore: response.cslScore,
    sourceCount: response.sources.length,
    correlationId: correlationId || req.correlationId,
  });
  res.json(response);
}

async function handleIndexBatch(req, res) {
  const { items = [], source = 'unknown', contentType = 'document', domain = contentType } = req.body || {};
  const indexed = [];
  for (const item of items) {
    if (!item?.content) continue;
    indexed.push(upsertItem(item, { source, contentType, domain }));
  }
  emitSpan('context.index-batch', {
    source,
    contentType,
    indexed: indexed.length,
    correlationId: req.correlationId,
  });
  res.json({ ok: true, indexed: indexed.length, ids: indexed.map(item => item.id) });
}

async function handleRemove(req, res) {
  const { id } = req.body || {};
  const existed = Boolean(id && sourceIndex.delete(id));
  if (existed) {
    state.removedCount += 1;
    state.lastMutationAt = new Date().toISOString();
  }
  emitSpan('context.remove', { id: id || 'unknown', removed: existed, correlationId: req.correlationId });
  res.json({ ok: true, removed: existed, id: id || null });
}

async function handleQuery(req, res) {
  const { q = '', domain = 'general' } = req.query || {};
  const response = buildEnrichmentResponse({ query: q, domain, correlationId: req.correlationId });
  res.json(response);
}

async function handleStatus(req, res) {
  res.json({
    service: SERVICE_NAME,
    domain: 'context',
    state,
    uptime: Date.now() - state.startTime,
    phi: PHI,
    cslGates: CSL_GATES,
    indexedDocuments: sourceIndex.size,
    version: '2.2.0',
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8907,
  routes: [
    { method: 'POST', path: '/', handler: handleEnrich },
    { method: 'POST', path: '/process', handler: handleEnrich },
    { method: 'POST', path: '/context/enrich', handler: handleEnrich },
    { method: 'POST', path: '/context/index-batch', handler: handleIndexBatch },
    { method: 'DELETE', path: '/context/remove', handler: handleRemove },
    { method: 'GET', path: '/context/query', handler: handleQuery },
    { method: 'GET', path: '/status', handler: handleStatus },
  ],
  onStart: async () => {
    state.initialized = true;
    upsertItem({
      id: 'seed:heady-topology',
      content: 'HeadyAutoContext enriches requests with vector memory, CSL gates, sacred geometry, and cross-domain ecosystem links.',
      metadata: { source: 'bootstrap', type: 'seed', domain: 'context', tags: ['autocontext', 'vector-memory', 'csl'] },
    }, { source: 'bootstrap', contentType: 'seed', domain: 'context' });
    log('info', 'service.init', { service: SERVICE_NAME, domain: 'context', port: 8907 });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
