/**
 * @fileoverview analytics-service — event intake, session rollups,
 * product metrics slices, and dashboard queries.
 *
 * Service: analytics-service
 * Domain:  analytics
 * Port:    8911
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking-based routing. CSL domain match only.
 */

import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, FIB, cslGate, CSL_GATES, fibSequence } from '../../shared/phi-math.js';
import { randomUUID } from 'crypto';

const SERVICE_NAME = 'analytics-service';
process.env.SERVICE_NAME = SERVICE_NAME;

const eventBus      = [];          // in-memory event store (wire DuckDB/BigQuery for production)
const sessionIndex  = new Map();   // sessionId → { userId, events[], startedAt }
const MAX_EVENTS    = FIB[15];     // 610

const state = {
  initialized: false, domain: 'analytics', startTime: Date.now(),
  totalEvents: 0, activeSessions: 0,
};

function ensureSession(sessionId, userId) {
  if (!sessionIndex.has(sessionId)) {
    sessionIndex.set(sessionId, { sessionId, userId, events: [], startedAt: Date.now() });
    state.activeSessions++;
  }
  return sessionIndex.get(sessionId);
}

async function handleIngest(req, res) {
  const { body, correlationId, headyContext } = req;
  const { sessionId = randomUUID(), userId, event, properties = {} } = body || {};
  if (!event) return res.json({ error: 'event name required', correlationId }, 400);

  const record = {
    id: randomUUID(), sessionId, userId: userId || 'anonymous',
    event, properties, correlationId,
    receivedAt: new Date().toISOString(),
    cslScore: headyContext?.cslScore || 0,
  };

  eventBus.push(record);
  if (eventBus.length > MAX_EVENTS) eventBus.shift();
  state.totalEvents++;

  const session = ensureSession(sessionId, record.userId);
  session.events.push(record.id);

  emitSpan('analytics.ingest', { event, sessionId, correlationId });
  res.json({ ok: true, eventId: record.id, sessionId, correlationId });
}

async function handleSessionRollup(req, res) {
  const { body, correlationId } = req;
  const { sessionId } = body || {};
  if (!sessionId) return res.json({ error: 'sessionId required', correlationId }, 400);

  const session = sessionIndex.get(sessionId);
  if (!session) return res.json({ error: 'session not found', correlationId }, 404);

  const events = eventBus.filter(e => session.events.includes(e.id));
  const durationMs = Date.now() - session.startedAt;

  res.json({
    ok: true, sessionId, userId: session.userId,
    eventCount: events.length, durationMs,
    events: events.slice(-FIB[8]), // last 21
    correlationId,
  });
}

async function handleMetrics(req, res) {
  const { correlationId } = req;
  const eventCounts = {};
  for (const e of eventBus) {
    eventCounts[e.event] = (eventCounts[e.event] || 0) + 1;
  }
  const topEvents = Object.entries(eventCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, FIB[7]) // top 13
    .map(([event, count]) => ({ event, count }));

  res.json({
    ok: true,
    totalEvents: state.totalEvents,
    activeSessions: state.activeSessions,
    topEvents,
    windowSize: eventBus.length,
    correlationId,
  });
}

async function handleStatus(req, res) {
  res.json({ service: SERVICE_NAME, domain: 'analytics', state,
    uptime: Date.now() - state.startTime, phi: PHI, cslGates: CSL_GATES, version: '2.2.0' });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME, port: 8911,
  routes: [
    { method: 'POST', path: '/events/ingest',   handler: handleIngest        },
    { method: 'POST', path: '/session/rollup',  handler: handleSessionRollup },
    { method: 'GET',  path: '/metrics',         handler: handleMetrics       },
    { method: 'GET',  path: '/status',          handler: handleStatus        },
  ],
  onStart: async () => { state.initialized = true; log('info', 'service.init', { service: SERVICE_NAME, port: 8911 }); },
  onShutdown: async () => { state.initialized = false; log('info', 'service.shutdown', { service: SERVICE_NAME }); },
});

start().catch(err => { log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message }); process.exit(1); });
export { start, stop };
