/**
 * @fileoverview auth-session-server — session introspection, refresh relay, cookie-bound audience checks, and revoke flows.
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking logic. Route by CSL domain match only.
 */
import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, CSL_GATES } from '../../shared/phi-math.js';

const SERVICE_NAME = 'auth-session-server';
process.env.SERVICE_NAME = SERVICE_NAME;
process.env.SERVICE_HEALTH_URL = process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:8917/health`;

const state = {
  initialized: false,
  domain: 'sessions',
  startTime: Date.now(),
  sessions: 0,
};


    const sessions = [];

    async function handleIntrospect(req, res) {
      const sessionId = req.query?.sessionId || 'missing-session';
      const session = sessions.find(item => item.id === sessionId) || null;
      res.json({ ok: true, sessionId, active: Boolean(session), session });
    }

    async function handleRefresh(req, res) {
      const session = {
        id: req.body?.sessionId || `${SERVICE_NAME}-${sessions.length + 1}`,
        audience: req.body?.audience || 'heady-ecosystem',
        refreshedAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString(),
      };
      sessions.push(session);
      state.sessions = sessions.length;
      res.json({ ok: true, session });
    }

    async function handleRevoke(req, res) {
      const sessionId = req.body?.sessionId;
      const before = sessions.length;
      for (let index = sessions.length - 1; index >= 0; index -= 1) {
        if (sessions[index].id === sessionId) sessions.splice(index, 1);
      }
      state.sessions = sessions.length;
      res.json({ ok: true, revoked: before !== sessions.length, sessionId });
    }


async function handleStatus(req, res) {
  res.json({
    ok: true,
    service: SERVICE_NAME,
    domain: 'sessions',
    uptime: Date.now() - state.startTime,
    phi: PHI,
    cslGates: CSL_GATES,
    state,
    version: '2.3.0',
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8917,
  routes: [
    { method: 'GET', path: '/session/introspect', handler: handleIntrospect },
{ method: 'POST', path: '/session/refresh', handler: handleRefresh },
{ method: 'POST', path: '/session/revoke', handler: handleRevoke },
    { method: 'GET', path: '/status', handler: handleStatus },
  ],
  onStart: async () => {
    state.initialized = true;
    log('info', 'service.init', { service: SERVICE_NAME, domain: 'sessions', port: 8917 });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
