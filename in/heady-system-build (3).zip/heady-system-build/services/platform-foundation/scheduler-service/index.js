/**
 * @fileoverview scheduler-service — recurrence registry, due-work release, and cadence-aware orchestration windows.
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking logic. Route by CSL domain match only.
 */
import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, CSL_GATES } from '../../shared/phi-math.js';

const SERVICE_NAME = 'scheduler-service';
process.env.SERVICE_NAME = SERVICE_NAME;
process.env.SERVICE_HEALTH_URL = process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:8914/health`;

const state = {
  initialized: false,
  domain: 'scheduling',
  startTime: Date.now(),
  schedules: 0,
};


    const schedules = [];

    async function handleRegister(req, res) {
      const schedule = {
        id: req.body?.id || `${SERVICE_NAME}-${schedules.length + 1}`,
        name: req.body?.name || 'unnamed-schedule',
        cadence: req.body?.cadence || '0 * * * *',
        nextRunAt: req.body?.nextRunAt || new Date(Date.now() + 60 * 60 * 1000).toISOString(),
        targetService: req.body?.targetService || 'heady-orchestration',
      };
      schedules.push(schedule);
      state.schedules = schedules.length;
      res.json({ ok: true, schedule });
    }

    async function handleDue(req, res) {
      const now = Date.now();
      const due = schedules.filter(item => Date.parse(item.nextRunAt) <= now);
      res.json({ ok: true, dueCount: due.length, due });
    }

    async function handleList(req, res) {
      res.json({ ok: true, schedules });
    }


async function handleStatus(req, res) {
  res.json({
    ok: true,
    service: SERVICE_NAME,
    domain: 'scheduling',
    uptime: Date.now() - state.startTime,
    phi: PHI,
    cslGates: CSL_GATES,
    state,
    version: '2.3.0',
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8914,
  routes: [
    { method: 'POST', path: '/schedules/register', handler: handleRegister },
{ method: 'GET', path: '/schedules/due', handler: handleDue },
{ method: 'GET', path: '/schedules/list', handler: handleList },
    { method: 'GET', path: '/status', handler: handleStatus },
  ],
  onStart: async () => {
    state.initialized = true;
    log('info', 'service.init', { service: SERVICE_NAME, domain: 'scheduling', port: 8914 });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
