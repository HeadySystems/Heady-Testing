/**
 * @fileoverview search-service — hybrid lexical and vector query routing
 * across docs, services, and public pages.
 *
 * Service: search-service
 * Domain:  search
 * Port:    8913
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking-based routing. CSL domain match only.
 */

import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, PSI, FIB, cslGate, CSL_GATES, fibSequence, phiBackoff } from '../../shared/phi-math.js';
import { randomUUID } from 'crypto';

const SERVICE_NAME = 'search-service';
process.env.SERVICE_NAME = SERVICE_NAME;

// In-memory document index (wire pgvector full-text + HNSW for production)
const docIndex = [];
const MAX_DOCS = FIB[14]; // 377

const state = {
  initialized: false, domain: 'search', startTime: Date.now(),
  indexed: 0, queries: 0,
};

function tokenize(text) {
  return text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(Boolean);
}

function bm25Score(query, doc) {
  // Simplified BM25 — wire to pg full-text for production
  const k1 = PHI; const b = PSI;
  const qTokens = tokenize(query);
  const dTokens = tokenize(doc.content);
  const dLen = dTokens.length;
  const avgDocLen = Math.max(1, docIndex.reduce((s, d) => s + tokenize(d.content).length, 0) / Math.max(1, docIndex.length));
  let score = 0;
  for (const token of qTokens) {
    const tf = dTokens.filter(t => t === token).length;
    const numerator = tf * (k1 + 1);
    const denominator = tf + k1 * (1 - b + b * (dLen / avgDocLen));
    score += numerator / denominator;
  }
  return score;
}

async function handleIndex(req, res) {
  const { body, correlationId } = req;
  const { docId = randomUUID(), title, content, domain = 'general', metadata = {} } = body || {};
  if (!content) return res.json({ error: 'content required', correlationId }, 400);

  const existing = docIndex.findIndex(d => d.docId === docId);
  const entry = { docId, title: title || docId, content, domain, metadata, indexedAt: new Date().toISOString() };
  if (existing >= 0) docIndex[existing] = entry;
  else {
    docIndex.push(entry);
    if (docIndex.length > MAX_DOCS) docIndex.shift();
  }
  state.indexed++;
  log('info', 'search.indexed', { docId, domain, correlationId });
  res.json({ ok: true, docId, correlationId });
}

async function handleQuery(req, res) {
  const { body, correlationId, headyContext } = req;
  const { query, domain, limit = FIB[7] } = body || {}; // default limit = 13
  if (!query) return res.json({ error: 'query required', correlationId }, 400);

  state.queries++;
  const pool = domain ? docIndex.filter(d => d.domain === domain) : docIndex;

  const scored = pool
    .map(doc => ({ doc, score: bm25Score(query, doc) }))
    .filter(r => r.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);

  emitSpan('search.query', { query: query.slice(0, 50), resultCount: scored.length, correlationId });
  res.json({
    ok: true,
    query,
    results: scored.map(r => ({ docId: r.doc.docId, title: r.doc.title, domain: r.doc.domain, score: r.score })),
    total: scored.length,
    correlationId,
  });
}

async function handleStatus(req, res) {
  res.json({ service: SERVICE_NAME, domain: 'search', state,
    uptime: Date.now() - state.startTime, phi: PHI, cslGates: CSL_GATES, version: '2.2.0',
    indexSize: docIndex.length });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME, port: 8913,
  routes: [
    { method: 'POST', path: '/search/index',  handler: handleIndex  },
    { method: 'POST', path: '/search/query',  handler: handleQuery  },
    { method: 'GET',  path: '/status',        handler: handleStatus },
  ],
  onStart: async () => { state.initialized = true; log('info', 'service.init', { service: SERVICE_NAME, port: 8913 }); },
  onShutdown: async () => { state.initialized = false; log('info', 'service.shutdown', { service: SERVICE_NAME }); },
});

start().catch(err => { log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message }); process.exit(1); });
export { start, stop };
