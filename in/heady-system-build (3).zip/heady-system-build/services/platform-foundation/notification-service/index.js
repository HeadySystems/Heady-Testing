/**
 * @fileoverview notification-service — fan-out, channel preferences,
 * digest batching, and delivery audit trails.
 *
 * Service: notification-service
 * Domain:  notifications
 * Port:    8910
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking-based routing. CSL domain match only. Everything is instantaneous.
 */

import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, FIB, phiBackoff, cslGate, CSL_GATES, fibSequence } from '../../shared/phi-math.js';
import { randomUUID } from 'crypto';

const SERVICE_NAME = 'notification-service';
process.env.SERVICE_NAME = SERVICE_NAME;

// In-memory notification store (replace with Postgres + NATS for production)
const notificationLog = [];
const channelPrefs = new Map();   // userId → { email, sms, webhook, digest }
const digestQueue   = new Map();  // userId → pending[]
const MAX_LOG       = fibSequence(16)[14]; // fib(14) = 377

const state = {
  initialized: false,
  domain: 'notifications',
  startTime: Date.now(),
  sent: 0,
  digests: 0,
  failed: 0,
};

// Channel types — capability labels, NOT ranked levels
const CHANNELS = { EMAIL: 'email', SMS: 'sms', WEBHOOK: 'webhook', IN_APP: 'in-app', DIGEST: 'digest' };

function recordNotification(entry) {
  notificationLog.push(entry);
  if (notificationLog.length > MAX_LOG) notificationLog.shift();
}

async function handleSend(req, res) {
  const { headyContext, correlationId, body } = req;
  const { userId, channel = CHANNELS.IN_APP, subject, message, metadata = {} } = body || {};

  if (!userId || !message) {
    return res.json({ error: 'userId and message are required', correlationId }, 400);
  }

  const prefs = channelPrefs.get(userId) || { [CHANNELS.IN_APP]: true };
  const targetChannel = prefs[channel] !== false ? channel : CHANNELS.IN_APP;

  const entry = {
    id: randomUUID(),
    userId,
    channel: targetChannel,
    subject: subject || '(no subject)',
    message,
    metadata,
    correlationId,
    sentAt: new Date().toISOString(),
    cslScore: headyContext?.cslScore || 0,
    delivered: true,
  };

  try {
    // Simulate delivery — wire real provider (SendGrid/Twilio/webhook) here
    recordNotification(entry);
    state.sent++;

    // Add to digest queue if user prefers digest mode
    if (prefs.digest) {
      const q = digestQueue.get(userId) || [];
      q.push(entry);
      digestQueue.set(userId, q);
    }

    emitSpan('notification.sent', { userId, channel: targetChannel, correlationId });
    log('info', 'notification.sent', { notificationId: entry.id, userId, channel: targetChannel });

    res.json({ ok: true, notificationId: entry.id, channel: targetChannel, correlationId });
  } catch (err) {
    state.failed++;
    log('error', 'notification.send.failed', { error: err.message, correlationId });
    res.json({ error: err.message, correlationId }, 500);
  }
}

async function handlePrefs(req, res) {
  const { headyContext, correlationId, body } = req;
  const { userId, prefs } = body || {};
  if (!userId || !prefs) return res.json({ error: 'userId and prefs required', correlationId }, 400);
  channelPrefs.set(userId, prefs);
  log('info', 'notification.prefs.updated', { userId, correlationId });
  res.json({ ok: true, userId, prefs, correlationId });
}

async function handleDigest(req, res) {
  const { headyContext, correlationId, body } = req;
  const { userId } = body || {};
  if (!userId) return res.json({ error: 'userId required', correlationId }, 400);
  const pending = digestQueue.get(userId) || [];
  digestQueue.delete(userId);
  state.digests++;
  log('info', 'notification.digest.flushed', { userId, count: pending.length, correlationId });
  res.json({ ok: true, userId, count: pending.length, notifications: pending, correlationId });
}

async function handleHistory(req, res) {
  const { correlationId, query } = req;
  const userId = query.userId;
  const entries = userId
    ? notificationLog.filter(n => n.userId === userId)
    : notificationLog.slice(-FIB[8]); // last fib(8)=21 entries
  res.json({ ok: true, count: entries.length, entries, correlationId });
}

async function handleStatus(req, res) {
  res.json({ service: SERVICE_NAME, domain: 'notifications', state,
    uptime: Date.now() - state.startTime, phi: PHI, cslGates: CSL_GATES, version: '2.2.0' });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME, port: 8910,
  routes: [
    { method: 'POST', path: '/notifications/send',    handler: handleSend    },
    { method: 'POST', path: '/notifications/prefs',   handler: handlePrefs   },
    { method: 'POST', path: '/notifications/digest',  handler: handleDigest  },
    { method: 'GET',  path: '/notifications/history', handler: handleHistory },
    { method: 'GET',  path: '/status',                handler: handleStatus  },
  ],
  onStart: async () => { state.initialized = true; log('info', 'service.init', { service: SERVICE_NAME, port: 8910 }); },
  onShutdown: async () => { state.initialized = false; log('info', 'service.shutdown', { service: SERVICE_NAME }); },
});

start().catch(err => { log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message }); process.exit(1); });
export { start, stop };
