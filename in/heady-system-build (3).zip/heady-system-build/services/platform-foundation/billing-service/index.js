/**
 * @fileoverview billing-service — plan catalog, usage metering, invoice previews,
 * and subscription state relay.
 *
 * Service: billing-service
 * Domain:  billing
 * Port:    8912
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking-based routing. CSL domain match only.
 */

import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, PSI, FIB, cslGate, CSL_GATES, phiResourceWeights } from '../../shared/phi-math.js';
import { randomUUID } from 'crypto';

const SERVICE_NAME = 'billing-service';
process.env.SERVICE_NAME = SERVICE_NAME;

// Plan catalog — flat capability tiers, all treated equally in routing
const PLANS = {
  sovereign: {
    id: 'sovereign', name: 'Sovereign', monthlyUsd: 0,
    limits: { beesPerHour: 13, vectorDims: 10000, sites: 1 },
    description: 'Full self-hosted deployment, no usage fees',
  },
  navigator: {
    id: 'navigator', name: 'Navigator', monthlyUsd: 89,
    limits: { beesPerHour: 144, vectorDims: 1000000, sites: 3 },
    description: 'Hosted with managed Cloudflare + Cloud Run',
  },
  architect: {
    id: 'architect', name: 'Architect', monthlyUsd: 377,
    limits: { beesPerHour: 610, vectorDims: 10000000, sites: 9 },
    description: 'Full 9-site ecosystem with all 53 services',
  },
};

// In-memory subscription ledger (replace with Stripe + Postgres for production)
const subscriptions = new Map();   // userId → { planId, startedAt, usageThisHour }
const usageRecords  = [];
const MAX_USAGE     = FIB[13];     // 233 records in memory

const state = {
  initialized: false, domain: 'billing', startTime: Date.now(),
  invoicesPreviewed: 0, metersRecorded: 0,
};

async function handlePlans(req, res) {
  res.json({ ok: true, plans: Object.values(PLANS), correlationId: req.correlationId });
}

async function handleSubscribe(req, res) {
  const { body, correlationId, headyContext } = req;
  const { userId, planId } = body || {};
  if (!userId || !PLANS[planId]) return res.json({ error: 'userId and valid planId required', correlationId }, 400);

  const sub = { planId, startedAt: new Date().toISOString(), usageThisHour: 0, userId };
  subscriptions.set(userId, sub);
  log('info', 'billing.subscribed', { userId, planId, correlationId });
  emitSpan('billing.subscribe', { userId, planId, correlationId });
  res.json({ ok: true, subscription: sub, plan: PLANS[planId], correlationId });
}

async function handleMeter(req, res) {
  const { body, correlationId, headyContext } = req;
  const { userId, metric, quantity = 1 } = body || {};
  if (!userId || !metric) return res.json({ error: 'userId and metric required', correlationId }, 400);

  const record = { id: randomUUID(), userId, metric, quantity, recordedAt: new Date().toISOString(), correlationId };
  usageRecords.push(record);
  if (usageRecords.length > MAX_USAGE) usageRecords.shift();

  const sub = subscriptions.get(userId);
  if (sub && metric === 'bees') {
    sub.usageThisHour = (sub.usageThisHour || 0) + quantity;
    const plan = PLANS[sub.planId];
    if (plan && sub.usageThisHour > plan.limits.beesPerHour) {
      log('warn', 'billing.limit.approached', { userId, metric, usage: sub.usageThisHour, limit: plan.limits.beesPerHour });
    }
  }

  state.metersRecorded++;
  res.json({ ok: true, recordId: record.id, correlationId });
}

async function handleInvoicePreview(req, res) {
  const { body, correlationId } = req;
  const { userId } = body || {};
  if (!userId) return res.json({ error: 'userId required', correlationId }, 400);

  const sub = subscriptions.get(userId);
  const plan = sub ? PLANS[sub.planId] : null;
  const records = usageRecords.filter(r => r.userId === userId);
  state.invoicesPreviewed++;

  res.json({
    ok: true, userId,
    subscription: sub || null,
    plan: plan || null,
    usageRecords: records.slice(-FIB[8]), // last 21
    totalRecords: records.length,
    correlationId,
  });
}

async function handleStatus(req, res) {
  res.json({ service: SERVICE_NAME, domain: 'billing', state,
    uptime: Date.now() - state.startTime, phi: PHI, cslGates: CSL_GATES, version: '2.2.0' });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME, port: 8912,
  routes: [
    { method: 'GET',  path: '/plans',            handler: handlePlans         },
    { method: 'POST', path: '/subscribe',        handler: handleSubscribe     },
    { method: 'POST', path: '/meter',            handler: handleMeter         },
    { method: 'POST', path: '/invoice/preview',  handler: handleInvoicePreview},
    { method: 'GET',  path: '/status',           handler: handleStatus        },
  ],
  onStart: async () => { state.initialized = true; log('info', 'service.init', { service: SERVICE_NAME, port: 8912 }); },
  onShutdown: async () => { state.initialized = false; log('info', 'service.shutdown', { service: SERVICE_NAME }); },
});

start().catch(err => { log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message }); process.exit(1); });
export { start, stop };
