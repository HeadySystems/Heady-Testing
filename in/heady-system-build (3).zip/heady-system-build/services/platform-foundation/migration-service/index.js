/**
 * @fileoverview migration-service — schema release plans, migration journals, and dry-run execution manifests.
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking logic. Route by CSL domain match only.
 */
import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, CSL_GATES } from '../../shared/phi-math.js';

const SERVICE_NAME = 'migration-service';
process.env.SERVICE_NAME = SERVICE_NAME;
process.env.SERVICE_HEALTH_URL = process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:8915/health`;

const state = {
  initialized: false,
  domain: 'migrations',
  startTime: Date.now(),
  runs: 0,
};


    const runs = [];

    async function handleStatusView(req, res) {
      res.json({ ok: true, lastRun: runs[runs.length - 1] || null, totalRuns: runs.length });
    }

    async function handleRun(req, res) {
      const run = {
        id: `${SERVICE_NAME}-${runs.length + 1}`,
        target: req.body?.target || 'platform',
        dryRun: req.body?.dryRun !== false,
        statements: req.body?.statements || ['ALTER TABLE example ADD COLUMN context_id text;'],
        timestamp: new Date().toISOString(),
      };
      runs.push(run);
      state.runs = runs.length;
      res.json({ ok: true, run });
    }

    async function handleHistory(req, res) {
      res.json({ ok: true, history: runs.slice(-20) });
    }


async function handleStatus(req, res) {
  res.json({
    ok: true,
    service: SERVICE_NAME,
    domain: 'migrations',
    uptime: Date.now() - state.startTime,
    phi: PHI,
    cslGates: CSL_GATES,
    state,
    version: '2.3.0',
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8915,
  routes: [
    { method: 'GET', path: '/migrations/status', handler: handleStatusView },
{ method: 'POST', path: '/migrations/run', handler: handleRun },
{ method: 'GET', path: '/migrations/history', handler: handleHistory },
    { method: 'GET', path: '/status', handler: handleStatus },
  ],
  onStart: async () => {
    state.initialized = true;
    log('info', 'service.init', { service: SERVICE_NAME, domain: 'migrations', port: 8915 });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
