import { start, stop, pollDrupalChanges, handleDrupalWebhook } from './drupal-vector-sync.js';

export { start, stop, pollDrupalChanges, handleDrupalWebhook };

export const drupalSyncService = {
  name: 'drupal-sync',
  routes: ['/webhook/drupal', '/status'],
  capabilities: ['webhook-ingest', 'jsonapi-polling', 'vector-index-sync'],
  recommendedEnv: ['DRUPAL_BASE_URL', 'DRUPAL_WEBHOOK_SECRET', 'AUTOCONTEXT_URL'],
};
