/**
 * @fileoverview drupal-vector-sync.js
 *
 * Drupal → HeadyAutoContext Vector Memory Sync Service.
 *
 * Implements TWO complementary sync paths:
 *
 *   1. WEBHOOK path (preferred, real-time):
 *      Drupal hook_entity_update → POST /webhook/drupal
 *      → Validates HMAC-SHA256 signature
 *      → Fetches full content via JSON:API
 *      → Indexes into vector memory via AutoContext
 *
 *   2. POLLING path (fallback, 5-15 min interval):
 *      Scheduled timer → GET /jsonapi/node/{type}?filter[changed][>]=lastPoll
 *      → Compares with last-seen timestamps
 *      → Indexes new/updated content
 *
 * Reference: https://www.drupal.org/docs/core-modules-and-themes/core-modules/jsonapi-module
 *
 * @module drupal-vector-sync
 * @version 2.1.0
 */

import { createHmac, randomUUID, timingSafeEqual } from 'crypto';
import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, PSI, FIB, phiBackoff, phiAdaptiveInterval } from '../../shared/phi-math.js';

// ─── Configuration ────────────────────────────────────────────────────────────

const DRUPAL_BASE_URL      = process.env.DRUPAL_BASE_URL   || 'https://cms.headysystems.com';
const DRUPAL_WEBHOOK_SECRET = process.env.DRUPAL_WEBHOOK_SECRET;
if (!DRUPAL_WEBHOOK_SECRET) throw new Error('DRUPAL_WEBHOOK_SECRET is required for drupal-vector-sync.');
const AUTOCONTEXT_URL      = process.env.AUTOCONTEXT_URL   || 'http://heady-auto-context:8907';
const VECTOR_MEMORY_URL    = process.env.VECTOR_MEMORY_URL || 'http://heady-memory:8106';
const SERVICE_NAME         = 'drupal-sync';

// Polling interval: phi-adaptive between 5min (300s) and 15min (900s)
const POLL_INTERVAL_MS_MIN = 300_000;   // 5 min
const POLL_INTERVAL_MS_MAX = 900_000;   // 15 min

// Drupal content types to sync (from 00-THIS-PROMPT.md requirements)
const CONTENT_TYPES = [
  'article', 'documentation', 'case_study', 'patent', 'event',
  'grant_program', 'agent_listing', 'investor_update', 'testimonial',
  'faq', 'product_catalog', 'news_release', 'media_asset',
];

// ─── State ────────────────────────────────────────────────────────────────────

const syncState = {
  lastPollTime:    new Map(), // contentType → ISO timestamp
  indexedCount:    0,
  webhookCount:    0,
  pollingActive:   false,
  errors:          0,
  startTime:       Date.now(),
};

// ─── HMAC Signature Verification ─────────────────────────────────────────────

/**
 * Verify Drupal webhook HMAC-SHA256 signature.
 * Timing-safe comparison to prevent timing attacks.
 *
 * @param {string} payload   - Raw request body string
 * @param {string} signature - X-Drupal-Signature header value
 * @returns {boolean}
 */
function verifyWebhookSignature(payload, signature) {
  try {
    const expected = createHmac('sha256', DRUPAL_WEBHOOK_SECRET)
      .update(payload, 'utf8')
      .digest('hex');
    const sigBuf  = Buffer.from(signature.replace(/^sha256=/, ''), 'hex');
    const expBuf  = Buffer.from(expected, 'hex');
    return sigBuf.length === expBuf.length && timingSafeEqual(sigBuf, expBuf);
  } catch {
    return false;
  }
}

// ─── JSON:API Client ──────────────────────────────────────────────────────────

/**
 * Fetch content from Drupal JSON:API with phi-exponential retry.
 *
 * @param {string} contentType
 * @param {object} [filters] - JSON:API filter params
 * @param {number} [attempt]
 * @returns {Promise<object[]>} array of Drupal node items
 */
async function fetchDrupalContent(contentType, filters = {}, attempt = 0) {
  const params = new URLSearchParams(filters);
  const url    = `${DRUPAL_BASE_URL}/jsonapi/node/${contentType}?${params}&include=field_image,field_tags`;

  try {
    const controller = new AbortController();
    const timeout    = setTimeout(() => controller.abort(), 30_000);

    const res = await fetch(url, {
      headers: {
        'Accept':        'application/vnd.api+json',
        'X-Heady-Sync':  'drupal-vector-sync/2.1.0',
      },
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!res.ok) {
      throw new Error(`Drupal JSON:API responded ${res.status} for ${contentType}`);
    }

    const data = await res.json();
    return data.data || [];
  } catch (err) {
    if (attempt < 3) {
      const backoffMs = phiBackoff(attempt, 2000);
      log('warn', 'drupal.fetch.retry', { contentType, attempt, backoffMs, error: err.message });
      await new Promise(r => setTimeout(r, backoffMs));
      return fetchDrupalContent(contentType, filters, attempt + 1);
    }
    syncState.errors++;
    log('error', 'drupal.fetch.failed', { contentType, error: err.message });
    return [];
  }
}

// ─── Vector Indexing ──────────────────────────────────────────────────────────

/**
 * Extract indexable text from a Drupal JSON:API node.
 *
 * @param {object} node - Drupal JSON:API node resource object
 * @returns {object} { id, type, title, body, tags, url, changed }
 */
function extractNodeContent(node) {
  const attrs = node.attributes || {};
  const rels  = node.relationships || {};

  return {
    id:      node.id,
    type:    node.type?.replace('node--', '') || 'unknown',
    title:   attrs.title || '',
    body:    attrs.body?.value || attrs.field_summary?.value || '',
    summary: attrs.body?.summary || '',
    tags:    (rels.field_tags?.data || []).map(t => t.id),
    url:     `${DRUPAL_BASE_URL}/node/${attrs.drupal_internal__nid}`,
    changed: attrs.changed || new Date().toISOString(),
    langcode: attrs.langcode || 'en',
  };
}

/**
 * Index a batch of Drupal nodes into HeadyAutoContext vector memory.
 * Content is fed through AutoContext for 384-dim embedding and CSL indexing.
 *
 * @param {object[]} nodes
 * @param {string}   contentType
 * @returns {Promise<number>} number successfully indexed
 */
async function indexNodesIntoVectorMemory(nodes, contentType) {
  if (nodes.length === 0) return 0;

  const items = nodes.map(extractNodeContent);
  let indexed = 0;

  // Batch in groups of fib(8)=13 for phi-scaled throughput
  const batchSize = FIB[7]; // 13
  for (let i = 0; i < items.length; i += batchSize) {
    const batch = items.slice(i, i + batchSize);

    try {
      // Index via AutoContext (embeddings + CSL gates)
      const autoCtxRes = await fetch(`${AUTOCONTEXT_URL}/context/index-batch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          source: 'drupal',
          contentType,
          items: batch.map(item => ({
            id:      `drupal:${item.type}:${item.id}`,
            content: [item.title, item.body, item.summary].filter(Boolean).join('\n'),
            metadata: {
              source:   'drupal',
              type:     item.type,
              url:      item.url,
              changed:  item.changed,
              tags:     item.tags,
            },
          })),
        }),
      });

      if (autoCtxRes.ok) {
        const result = await autoCtxRes.json();
        indexed += result.indexed || batch.length;
      }
    } catch (err) {
      log('error', 'drupal.index.batch.error', { contentType, batchStart: i, error: err.message });
    }
  }

  syncState.indexedCount += indexed;
  emitSpan('drupal.index', { contentType, nodeCount: nodes.length, indexed });
  return indexed;
}

// ─── Webhook Handler ──────────────────────────────────────────────────────────

/**
 * Handle incoming Drupal webhook (hook_entity_update → POST /webhook/drupal).
 *
 * Drupal sends:
 *   POST /webhook/drupal
 *   X-Drupal-Signature: sha256=<hmac>
 *   Content-Type: application/json
 *   Body: { entity_type, bundle, uuid, operation: 'insert'|'update'|'delete' }
 */
async function handleDrupalWebhook(req, res) {
  const rawBody  = JSON.stringify(req.body);
  const sig      = req.headers['x-drupal-signature'] || '';

  if (!verifyWebhookSignature(rawBody, sig)) {
    log('warn', 'drupal.webhook.invalid-signature', {
      correlationId: req.correlationId,
    });
    res.json({ error: 'Invalid signature' }, 401);
    return;
  }

  const { entity_type, bundle, uuid, operation } = req.body;

  if (entity_type !== 'node' || !CONTENT_TYPES.includes(bundle)) {
    res.json({ skipped: true, reason: 'not-a-tracked-content-type' });
    return;
  }

  if (operation === 'delete') {
    // Remove from vector memory
    try {
      await fetch(`${AUTOCONTEXT_URL}/context/remove`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: `drupal:${bundle}:${uuid}` }),
      });
      log('info', 'drupal.webhook.deleted', { uuid, bundle });
    } catch (err) {
      log('error', 'drupal.webhook.delete.error', { uuid, error: err.message });
    }
    res.json({ received: true, operation: 'delete', uuid });
    return;
  }

  // Fetch full content via JSON:API and index
  const nodes = await fetchDrupalContent(bundle, { 'filter[id]': uuid });
  const indexed = await indexNodesIntoVectorMemory(nodes, bundle);

  syncState.webhookCount++;

  log('info', 'drupal.webhook.processed', {
    uuid, bundle, operation, indexed,
    correlationId: req.correlationId,
  });

  res.json({ received: true, uuid, bundle, operation, indexed });
}

// ─── Polling Loop ─────────────────────────────────────────────────────────────

/**
 * Poll all content types for changes since last poll.
 * Runs every POLL_INTERVAL_MS_MIN to POLL_INTERVAL_MS_MAX (phi-adaptive).
 */
async function pollDrupalChanges() {
  if (syncState.pollingActive) return;
  syncState.pollingActive = true;

  log('info', 'drupal.poll.start', { contentTypes: CONTENT_TYPES });

  for (const contentType of CONTENT_TYPES) {
    try {
      const lastPoll = syncState.lastPollTime.get(contentType) || '1970-01-01T00:00:00Z';
      const nodes    = await fetchDrupalContent(contentType, {
        'filter[changed][condition][path]':     'changed',
        'filter[changed][condition][operator]': '>',
        'filter[changed][condition][value]':    lastPoll,
        'sort':                                  'changed',
        'page[limit]':                          '50',
      });

      if (nodes.length > 0) {
        const indexed = await indexNodesIntoVectorMemory(nodes, contentType);
        log('info', 'drupal.poll.indexed', { contentType, nodeCount: nodes.length, indexed });
        syncState.lastPollTime.set(contentType, new Date().toISOString());
      }
    } catch (err) {
      log('error', 'drupal.poll.error', { contentType, error: err.message });
    }

    // Small yield between content types (phi-scaled: ~618ms)
    await new Promise(r => setTimeout(r, Math.round(1000 * PSI)));
  }

  syncState.pollingActive = false;
  log('info', 'drupal.poll.complete', {
    totalIndexed: syncState.indexedCount,
    contentTypes: CONTENT_TYPES.length,
  });
}

// ─── Status handler ───────────────────────────────────────────────────────────

async function handleStatus(req, res) {
  res.json({
    service:       SERVICE_NAME,
    status:        'ok',
    uptime:        Date.now() - syncState.startTime,
    webhookCount:  syncState.webhookCount,
    pollingActive: syncState.pollingActive,
    indexedCount:  syncState.indexedCount,
    errors:        syncState.errors,
    lastPollTimes: Object.fromEntries(syncState.lastPollTime),
    contentTypes:  CONTENT_TYPES,
    drupalBase:    DRUPAL_BASE_URL,
  });
}

// ─── Service bootstrap ────────────────────────────────────────────────────────

process.env.SERVICE_NAME = SERVICE_NAME;

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8809,
  routes: [
    { method: 'POST', path: '/webhook/drupal', handler: handleDrupalWebhook },
    { method: 'GET',  path: '/status',         handler: handleStatus },
  ],
  onStart: async () => {
    log('info', 'drupal-sync.started', {
      drupalBase: DRUPAL_BASE_URL,
      pollIntervalMs: POLL_INTERVAL_MS_MIN,
    });

    // Initial full sync on startup
    await pollDrupalChanges();

    // Schedule recurring polls (phi-adaptive interval)
    const scheduleNextPoll = () => {
      const load  = syncState.errors > 0 ? Math.min(syncState.errors / 10, 1) : 0;
      const delay = phiAdaptiveInterval(POLL_INTERVAL_MS_MIN, load);
      const capped = Math.min(delay, POLL_INTERVAL_MS_MAX);
      setTimeout(async () => {
        await pollDrupalChanges();
        scheduleNextPoll();
      }, capped);
    };

    scheduleNextPoll();
  },
  onShutdown: async () => {
    log('info', 'drupal-sync.shutdown', {
      totalIndexed: syncState.indexedCount,
      webhooks: syncState.webhookCount,
    });
  },
});

start().catch(err => {
  log('error', 'drupal-sync.start.failed', { error: err.message });
  process.exit(1);
});

export { start, stop, pollDrupalChanges, handleDrupalWebhook };
