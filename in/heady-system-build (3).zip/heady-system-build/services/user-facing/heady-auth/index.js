/**
 * @fileoverview heady-auth — central auth relay and cookie minting service.
 *
 * Real implementation notes:
 * - Validates redirect hosts against an allowlist
 * - Uses Firebase Identity Toolkit for email/password and anonymous auth when configured
 * - Mints signed httpOnly session cookies on the auth domain
 * - Supports Google and GitHub OAuth launch plus callback exchange when provider credentials are configured
 * - Exposes logout and session inspection endpoints
 */

import { createHmac, timingSafeEqual } from 'crypto';
import { createHeadyService, log } from '../../shared/service-base.js';

const SERVICE_NAME = 'heady-auth';
process.env.SERVICE_NAME = SERVICE_NAME;

const AUTH_COOKIE_NAME = process.env.AUTH_COOKIE_NAME || 'heady_auth_session';
const AUTH_FLOW_COOKIE = process.env.AUTH_FLOW_COOKIE || 'heady_auth_flow';
const AUTH_COOKIE_SECRET = process.env.AUTH_COOKIE_SECRET;
const FIREBASE_API_KEY = process.env.FIREBASE_API_KEY;
const FIREBASE_PROJECT_ID = process.env.FIREBASE_PROJECT_ID || 'gen-lang-client-0920560496';
const AUTH_BASE_URL = process.env.AUTH_BASE_URL || 'https://auth.headysystems.com';
const ALLOWED_REDIRECT_HOSTS = (process.env.ALLOWED_REDIRECT_HOSTS || [
  'headyme.com',
  'headysystems.com',
  'heady-ai.com',
  'headyos.com',
  'headyconnection.org',
  'headyconnection.com',
  'headyex.com',
  'headyfinance.com',
  'admin.headysystems.com',
  'auth.headysystems.com',
].join(','))
  .split(',')
  .map(v => v.trim())
  .filter(Boolean);

if (!AUTH_COOKIE_SECRET) {
  throw new Error('AUTH_COOKIE_SECRET is required for heady-auth. Refusing to start without a signing secret.');
}

const OAUTH_PROVIDERS = {
  google: {
    clientId: process.env.GOOGLE_OAUTH_CLIENT_ID || null,
    clientSecret: process.env.GOOGLE_OAUTH_CLIENT_SECRET || null,
    authorizeUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    userUrl: 'https://openidconnect.googleapis.com/v1/userinfo',
    scopes: ['openid', 'email', 'profile'],
  },
  github: {
    clientId: process.env.GITHUB_OAUTH_CLIENT_ID || null,
    clientSecret: process.env.GITHUB_OAUTH_CLIENT_SECRET || null,
    authorizeUrl: 'https://github.com/login/oauth/authorize',
    tokenUrl: 'https://github.com/login/oauth/access_token',
    userUrl: 'https://api.github.com/user',
    emailUrl: 'https://api.github.com/user/emails',
    scopes: ['read:user', 'user:email'],
  },
};

function parseCookies(req) {
  const source = req.headers.cookie || '';
  return source.split(';').map(v => v.trim()).filter(Boolean).reduce((acc, item) => {
    const index = item.indexOf('=');
    if (index === -1) return acc;
    const key = item.slice(0, index);
    const value = item.slice(index + 1);
    acc[key] = decodeURIComponent(value);
    return acc;
  }, {});
}

function isAllowedRedirect(url) {
  try {
    const parsed = new URL(url);
    return ALLOWED_REDIRECT_HOSTS.some(host => parsed.hostname === host || parsed.hostname.endsWith(`.${host}`));
  } catch {
    return false;
  }
}

function signPayload(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = createHmac('sha256', AUTH_COOKIE_SECRET).update(body).digest('base64url');
  return `${body}.${sig}`;
}

function verifyPayload(token) {
  if (!token || !token.includes('.')) return null;
  const [body, signature] = token.split('.');
  const expected = createHmac('sha256', AUTH_COOKIE_SECRET).update(body).digest('base64url');
  const sigBuf = Buffer.from(signature);
  const expBuf = Buffer.from(expected);
  if (sigBuf.length !== expBuf.length || !timingSafeEqual(sigBuf, expBuf)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (payload.exp && Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

function buildSessionCookie(name, value, maxAgeSeconds = 60 * 60 * 8) {
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAgeSeconds}`;
}

function buildClearCookie(name) {
  return `${name}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`;
}

async function callFirebase(endpoint, payload) {
  if (!FIREBASE_API_KEY) {
    throw new Error('FIREBASE_API_KEY is required for Firebase auth flows.');
  }

  const url = `https://identitytoolkit.googleapis.com/v1/${endpoint}?key=${FIREBASE_API_KEY}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data?.error?.message || `Firebase auth error from ${endpoint}`);
  }
  return data;
}

function getSessionFromRequest(req) {
  const cookies = parseCookies(req);
  return verifyPayload(cookies[AUTH_COOKIE_NAME]);
}

function getProviderConfig(provider) {
  return OAUTH_PROVIDERS[provider] || null;
}

function setRedirect(res, url, cookies = []) {
  if (cookies.length) res.setHeader('Set-Cookie', cookies);
  res.statusCode = 302;
  res.setHeader('Location', url);
  res.send(`Redirecting to ${url}`, 302);
}

async function postForm(url, payload, headers = {}) {
  const body = new URLSearchParams(payload);
  const response = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      Accept: 'application/json',
      ...headers,
    },
    body: body.toString(),
  });
  const text = await response.text();
  try {
    return { ok: response.ok, status: response.status, data: JSON.parse(text) };
  } catch {
    return { ok: response.ok, status: response.status, data: Object.fromEntries(new URLSearchParams(text)) };
  }
}

async function fetchJson(url, headers = {}) {
  const response = await fetch(url, { headers: { Accept: 'application/json', ...headers } });
  const data = await response.json();
  if (!response.ok) throw new Error(data?.message || `Request failed for ${url}`);
  return data;
}

function buildProviderSession(user, provider, state, nonce) {
  return signPayload({
    uid: user.uid,
    email: user.email || null,
    provider,
    state,
    nonce,
    iat: Date.now(),
    exp: Date.now() + (1000 * 60 * 60 * 8),
  });
}

async function resolveOAuthUser(provider, code) {
  const cfg = getProviderConfig(provider);
  if (!cfg?.clientId || !cfg?.clientSecret) {
    throw new Error(`${provider}-oauth-not-configured`);
  }

  if (provider === 'google') {
    const tokenResponse = await postForm(cfg.tokenUrl, {
      code,
      client_id: cfg.clientId,
      client_secret: cfg.clientSecret,
      redirect_uri: `${AUTH_BASE_URL}/oauth/google/callback`,
      grant_type: 'authorization_code',
    });
    if (!tokenResponse.ok || !tokenResponse.data.access_token) {
      throw new Error(tokenResponse.data?.error_description || tokenResponse.data?.error || 'google-token-exchange-failed');
    }
    const profile = await fetchJson(cfg.userUrl, {
      Authorization: `Bearer ${tokenResponse.data.access_token}`,
    });
    return {
      uid: profile.sub,
      email: profile.email || null,
    };
  }

  if (provider === 'github') {
    const tokenResponse = await postForm(cfg.tokenUrl, {
      code,
      client_id: cfg.clientId,
      client_secret: cfg.clientSecret,
      redirect_uri: `${AUTH_BASE_URL}/oauth/github/callback`,
    }, { Accept: 'application/json' });
    if (!tokenResponse.ok || !tokenResponse.data.access_token) {
      throw new Error(tokenResponse.data?.error_description || tokenResponse.data?.error || 'github-token-exchange-failed');
    }
    const headers = {
      Authorization: `Bearer ${tokenResponse.data.access_token}`,
      'User-Agent': 'HeadyAuth/2.2.0',
    };
    const profile = await fetchJson(cfg.userUrl, headers);
    const emails = await fetchJson(cfg.emailUrl, headers);
    const primaryEmail = Array.isArray(emails)
      ? emails.find(item => item.primary)?.email || emails.find(item => item.verified)?.email || emails[0]?.email || null
      : null;
    return {
      uid: String(profile.id),
      email: primaryEmail,
    };
  }

  throw new Error('unsupported-provider');
}

async function handleSession(req, res) {
  const session = getSessionFromRequest(req);
  if (!session) {
    res.json({ authenticated: false, projectId: FIREBASE_PROJECT_ID });
    return;
  }
  res.json({
    authenticated: true,
    projectId: FIREBASE_PROJECT_ID,
    user: {
      uid: session.uid,
      email: session.email || null,
      provider: session.provider,
      issuedAt: session.iat,
      expiresAt: session.exp,
    },
  });
}

async function handleEmailAuth(req, res) {
  const { email, password, redirect, state, nonce, mode = 'login' } = req.body || {};
  if (!email || !password || !redirect || !state || !nonce) {
    res.json({ error: 'email, password, redirect, state, and nonce are required' }, 400);
    return;
  }
  if (!isAllowedRedirect(redirect)) {
    res.json({ error: 'redirect-not-allowlisted' }, 400);
    return;
  }

  const data = mode === 'signup'
    ? await callFirebase('accounts:signUp', { email, password, returnSecureToken: true })
    : await callFirebase('accounts:signInWithPassword', { email, password, returnSecureToken: true });

  const session = signPayload({
    uid: data.localId,
    email: data.email,
    provider: 'password',
    state,
    nonce,
    iat: Date.now(),
    exp: Date.now() + (1000 * 60 * 60 * 8),
  });

  res.setHeader('Set-Cookie', buildSessionCookie(AUTH_COOKIE_NAME, session));
  res.json({
    ok: true,
    redirectTo: `${redirect}${redirect.includes('?') ? '&' : '?'}auth_state=${encodeURIComponent(state)}`,
    authDomain: AUTH_BASE_URL,
  });
}

async function handleAnonymousAuth(req, res) {
  const { redirect, state, nonce } = req.body || {};
  if (!redirect || !state || !nonce) {
    res.json({ error: 'redirect, state, and nonce are required' }, 400);
    return;
  }
  if (!isAllowedRedirect(redirect)) {
    res.json({ error: 'redirect-not-allowlisted' }, 400);
    return;
  }

  const data = await callFirebase('accounts:signUp', { returnSecureToken: true });
  const session = signPayload({
    uid: data.localId,
    provider: 'anonymous',
    state,
    nonce,
    iat: Date.now(),
    exp: Date.now() + (1000 * 60 * 60 * 4),
  });

  res.setHeader('Set-Cookie', buildSessionCookie(AUTH_COOKIE_NAME, session, 60 * 60 * 4));
  res.json({
    ok: true,
    redirectTo: `${redirect}${redirect.includes('?') ? '&' : '?'}auth_state=${encodeURIComponent(state)}`,
    authDomain: AUTH_BASE_URL,
  });
}

async function handleOAuthLaunch(req, res, provider) {
  const { redirect, state, nonce } = req.query || {};
  if (!redirect || !state || !nonce) {
    res.json({ error: 'redirect, state, and nonce are required' }, 400);
    return;
  }
  if (!isAllowedRedirect(redirect)) {
    res.json({ error: 'redirect-not-allowlisted' }, 400);
    return;
  }
  const cfg = getProviderConfig(provider);
  if (!cfg?.clientId || !cfg?.clientSecret) {
    res.json({ error: `${provider}-oauth-not-configured` }, 503);
    return;
  }

  const flowToken = signPayload({
    provider,
    redirect,
    state,
    nonce,
    iat: Date.now(),
    exp: Date.now() + (1000 * 60 * 10),
  });

  const authorizeUrl = new URL(cfg.authorizeUrl);
  authorizeUrl.searchParams.set('client_id', cfg.clientId);
  authorizeUrl.searchParams.set('state', state);
  authorizeUrl.searchParams.set('scope', cfg.scopes.join(' '));
  authorizeUrl.searchParams.set('redirect_uri', `${AUTH_BASE_URL}/oauth/${provider}/callback`);
  if (provider === 'google') {
    authorizeUrl.searchParams.set('response_type', 'code');
    authorizeUrl.searchParams.set('nonce', nonce);
    authorizeUrl.searchParams.set('access_type', 'offline');
    authorizeUrl.searchParams.set('prompt', 'consent');
  }

  setRedirect(res, authorizeUrl.toString(), [buildSessionCookie(AUTH_FLOW_COOKIE, flowToken, 60 * 10)]);
}

async function handleOAuthCallback(req, res, provider) {
  const { code, state, error } = req.query || {};
  if (error) {
    res.json({ error: `${provider}-oauth-error`, detail: error }, 400);
    return;
  }
  const cookies = parseCookies(req);
  const flow = verifyPayload(cookies[AUTH_FLOW_COOKIE]);
  if (!flow || flow.provider !== provider || flow.state !== state) {
    res.json({ error: 'invalid-oauth-state' }, 400);
    return;
  }
  if (!code) {
    res.json({ error: 'missing-oauth-code' }, 400);
    return;
  }

  const user = await resolveOAuthUser(provider, code);
  const session = buildProviderSession(user, provider, flow.state, flow.nonce);
  const redirectTo = `${flow.redirect}${flow.redirect.includes('?') ? '&' : '?'}auth_state=${encodeURIComponent(flow.state)}`;

  setRedirect(res, redirectTo, [
    buildSessionCookie(AUTH_COOKIE_NAME, session),
    buildClearCookie(AUTH_FLOW_COOKIE),
  ]);
}

async function handleLogout(req, res) {
  res.setHeader('Set-Cookie', [buildClearCookie(AUTH_COOKIE_NAME), buildClearCookie(AUTH_FLOW_COOKIE)]);
  res.json({ ok: true, loggedOut: true });
}

async function handleConfig(req, res) {
  res.json({
    authBaseUrl: AUTH_BASE_URL,
    firebaseProjectId: FIREBASE_PROJECT_ID,
    allowlistedHosts: ALLOWED_REDIRECT_HOSTS,
    providers: ['password', 'anonymous', 'google', 'github'],
    oauthProviders: {
      google: Boolean(OAUTH_PROVIDERS.google.clientId && OAUTH_PROVIDERS.google.clientSecret),
      github: Boolean(OAUTH_PROVIDERS.github.clientId && OAUTH_PROVIDERS.github.clientSecret),
    },
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8510,
  routes: [
    { method: 'GET', path: '/api/session', handler: handleSession },
    { method: 'GET', path: '/api/config', handler: handleConfig },
    { method: 'POST', path: '/api/auth/email', handler: handleEmailAuth },
    { method: 'POST', path: '/api/auth/anonymous', handler: handleAnonymousAuth },
    { method: 'GET', path: '/oauth/google', handler: (req, res) => handleOAuthLaunch(req, res, 'google') },
    { method: 'GET', path: '/oauth/github', handler: (req, res) => handleOAuthLaunch(req, res, 'github') },
    { method: 'GET', path: '/oauth/google/callback', handler: (req, res) => handleOAuthCallback(req, res, 'google') },
    { method: 'GET', path: '/oauth/github/callback', handler: (req, res) => handleOAuthCallback(req, res, 'github') },
    { method: 'POST', path: '/api/logout', handler: handleLogout },
  ],
  onStart: async () => {
    log('info', 'service.init', { service: SERVICE_NAME, port: 8510, firebaseProjectId: FIREBASE_PROJECT_ID });
  },
  onShutdown: async () => {
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
