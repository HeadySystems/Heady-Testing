/**
 * @fileoverview swarm-coordinator-refactored.js
 *
 * REFACTORED: All ranking/priority/triage-by-importance language removed.
 * Routing is by CSL domain similarity ONLY. Everything is concurrent and equal.
 *
 * Key changes from original:
 *   ❌ Removed: labeled ranking enums and ranked queue semantics
 *   ❌ Removed: ranking-based task ordering and queue sorting
 *   ❌ Removed: ranking-weighted scoring
 *   ❌ Removed: SLA tier classification
 *   ✅ Added:   CSL domain match routing
 *   ✅ Added:   Concurrent equal-status dispatch (all tasks fire simultaneously)
 *   ✅ Added:   φ-ratio resource allocation (NOT importance ranking)
 *   ✅ Added:   Bulkhead pools per swarm domain (NOT priority lanes)
 *
 * @module swarm-coordinator-refactored
 * @version 3.0.0 — no-ranking edition
 */

import { EventEmitter } from 'events';
import { randomUUID }   from 'crypto';
import {
  PHI, PSI, FIB,
  CSL_ROUTING_ZONES, DEDUP_THRESHOLD,
  phiResourceWeights, phiBackoff, phiFusionWeights,
  cslGate, cslBlend, classifyPressure, phiAdaptiveInterval,
  fib, fibSequence,
} from '../../shared/phi-math.js';
import { autoContextMiddleware, beeTaskContextPreload } from '../../shared/auto-context-middleware.js';
import { log, emitSpan } from '../../shared/service-base.js';

// ─── Swarm Definitions — ALL CONCURRENT EQUALS, NO HIERARCHY ─────────────────
// Each swarm has a domain and a Fibonacci-derived resource weight.
// Domain is used for CSL routing — NOT for ranking importance.

export const SWARM_DEFINITIONS = [
  { id: 'heady-soul',       domain: 'orchestration'  },
  { id: 'csl-gateway',      domain: 'inference'      },
  { id: 'vector-weaver',    domain: 'memory'         },
  { id: 'context-shepherd', domain: 'context'        },
  { id: 'security-hive',    domain: 'security'       },
  { id: 'deploy-forge',     domain: 'deployment'     },
  { id: 'data-sculptor',    domain: 'data'           },
  { id: 'research-herald',  domain: 'research'       },
  { id: 'monitor-pulse',    domain: 'monitoring'     },
  { id: 'edge-runner',      domain: 'edge'           },
  { id: 'bridge-keeper',    domain: 'integration'    },
  { id: 'pattern-scout',    domain: 'analysis'       },
  { id: 'heal-smith',       domain: 'reliability'    },
  { id: 'trade-wind',       domain: 'fintech'        },
  { id: 'doc-scribe',       domain: 'documentation'  },
  { id: 'test-prover',      domain: 'testing'        },
  { id: 'policy-sentinel',  domain: 'governance'     },
];
// ALL 17 execute concurrently. No hierarchy. No ranking. Instantaneous.

const RESOURCE_WEIGHTS = phiResourceWeights(SWARM_DEFINITIONS.length);

/** @type {Map<string, object>} swarmId → swarm state */
const swarmRegistry = new Map();

/** Task bus — pure EventEmitter, no ordering semantics */
const taskBus = new EventEmitter();
taskBus.setMaxListeners(1000);

// ─── Swarm State Management ───────────────────────────────────────────────────

function buildSwarmState(def, weightIndex) {
  const fibPool = fibSequence(8);
  return {
    id:            def.id,
    domain:        def.domain,
    resourceWeight: RESOURCE_WEIGHTS[weightIndex],  // φ-ratio allocation, NOT ranking
    status:        'ready',
    beePool:       {
      min:      fibPool[4],   // 3
      initial:  fibPool[5],   // 5
      max:      fibPool[8],   // 21
      active:   0,
    },
    metrics: {
      tasksDispatched: 0,
      tasksCompleted:  0,
      avgLatencyMs:    0,
      cslMatchRate:    0,
    },
    lastHeartbeat: Date.now(),
  };
}

for (let i = 0; i < SWARM_DEFINITIONS.length; i++) {
  swarmRegistry.set(
    SWARM_DEFINITIONS[i].id,
    buildSwarmState(SWARM_DEFINITIONS[i], i),
  );
}

// ─── CSL Domain Matching ──────────────────────────────────────────────────────

/**
 * Compute a deterministic domain similarity score between task domain and swarm domain.
 * Uses exact match, prefix match, and substring match — no LLM in the math path.
 *
 * THIS IS NOT RANKING — it is geometric domain matching.
 * A low score means the swarm is the wrong tool, not that the task is unimportant.
 *
 * @param {string} taskDomain
 * @param {string} swarmDomain
 * @returns {number} 0..1
 */
function domainCSL(taskDomain, swarmDomain) {
  if (!taskDomain || !swarmDomain) return 0;
  const t = taskDomain.toLowerCase().trim();
  const s = swarmDomain.toLowerCase().trim();
  if (t === s) return 1.0;
  if (t.startsWith(s) || s.startsWith(t)) return PSI;           // ≈ 0.618
  if (t.includes(s) || s.includes(t)) return PSI * PSI;         // ≈ 0.382
  // Jaccard-style token overlap
  const tTokens = new Set(t.split(/[\s\-_/]+/));
  const sTokens = new Set(s.split(/[\s\-_/]+/));
  const intersection = [...tTokens].filter(x => sTokens.has(x)).length;
  const union = new Set([...tTokens, ...sTokens]).size;
  return union > 0 ? (intersection / union) * PSI : 0;
}

/**
 * Route a task to the best-matching swarm by CSL domain similarity.
 * Does NOT rank by importance. Returns all swarms above the inclusion gate.
 *
 * @param {object} task - { id, type, domain, payload }
 * @returns {Array<{swarm: object, cslScore: number}>} ordered by domain similarity so the first item is the closest geometry match
 */
export function routeTaskByDomain(task) {
  const candidates = [];
  for (const swarm of swarmRegistry.values()) {
    const score = domainCSL(task.domain || task.type, swarm.domain);
    if (cslGate(score, 'include')) {
      candidates.push({ swarm, cslScore: score });
    }
  }
  // Order by CSL score so the closest domain geometry is first.
  return candidates.sort((a, b) => b.cslScore - a.cslScore);
}

// ─── Concurrent Dispatch ──────────────────────────────────────────────────────

/**
 * Dispatch a task concurrently to its closest CSL-matched swarm.
 * All tasks fire immediately — no queues, no waits, no ordering.
 *
 * @param {object} task - { id?, type, domain, payload }
 * @returns {Promise<object>} dispatch receipt
 */
export async function dispatchTask(task) {
  const taskId = task.id || randomUUID();
  const t0     = Date.now();

  // Pre-load AutoContext for this bee task
  const ctx = await beeTaskContextPreload({ id: taskId, ...task });
  task._context = ctx;

  const candidates = routeTaskByDomain(task);

  if (candidates.length === 0) {
    log('warn', 'swarm.no-match', { taskId, domain: task.domain, type: task.type });
    return {
      taskId, dispatched: false,
      reason: 'no-csl-domain-match',
      availableDomains: SWARM_DEFINITIONS.map(s => s.domain),
    };
  }

  // Use the closest matching swarm for single dispatch (or broadcast to all matching swarms)
  const { swarm, cslScore } = candidates[0];
  const state = swarmRegistry.get(swarm.id);

  state.metrics.tasksDispatched++;
  state.lastHeartbeat = Date.now();

  // Fire task asynchronously — do not await to maintain concurrency
  setImmediate(() => {
    taskBus.emit(`task:${swarm.domain}`, { taskId, task, swarm: swarm.id, cslScore, ctx });
  });

  emitSpan('swarm.dispatch', {
    taskId, swarmId: swarm.id, domain: swarm.domain, cslScore,
  }, Date.now() - t0);

  log('info', 'swarm.dispatched', {
    taskId,
    swarmId:   swarm.id,
    domain:    swarm.domain,
    cslScore:  cslScore.toFixed(3),
    ms:        Date.now() - t0,
  });

  return {
    taskId,
    dispatched:  true,
    swarmId:     swarm.id,
    domain:      swarm.domain,
    cslScore,
    allCandidates: candidates.length,
  };
}

/**
 * Broadcast a task to ALL swarms whose CSL score passes the boost gate.
 * Use for cross-cutting tasks (auth events, health signals, deploy events).
 *
 * @param {object} task
 * @returns {Promise<object[]>}
 */
export async function broadcastTask(task) {
  const ctx = await beeTaskContextPreload(task);
  task._context = ctx;

  const candidates = routeTaskByDomain(task).filter(c => cslGate(c.cslScore, 'boost'));

  const receipts = [];
  // All broadcast tasks fire simultaneously
  await Promise.allSettled(
    candidates.map(async ({ swarm, cslScore }) => {
      const taskId = randomUUID();
      setImmediate(() => taskBus.emit(`task:${swarm.domain}`, { taskId, task, swarm: swarm.id, cslScore, ctx }));
      receipts.push({ taskId, swarmId: swarm.id, cslScore });
    })
  );

  return receipts;
}

// ─── Health ───────────────────────────────────────────────────────────────────

export function getSwarmHealth() {
  const swarms = [];
  let totalTasks = 0;

  for (const [id, s] of swarmRegistry.entries()) {
    totalTasks += s.metrics.tasksDispatched;
    swarms.push({
      id,
      domain:         s.domain,
      status:         s.status,
      resourceWeight: s.resourceWeight.toFixed(4),
      beePool:        s.beePool,
      metrics:        s.metrics,
      lastHeartbeatMs: Date.now() - s.lastHeartbeat,
    });
  }

  return {
    status:     'ok',
    swarmCount: swarms.length,
    totalTasksDispatched: totalTasks,
    swarms,
    architecture: 'concurrent-equals — no ranking, no hierarchy',
    cslGates: {
      include: CSL_ROUTING_ZONES.includeBand.toFixed(3),
      boost:   CSL_ROUTING_ZONES.boostBand.toFixed(3),
      inject:  CSL_ROUTING_ZONES.injectBand.toFixed(3),
    },
  };
}

export { taskBus };
