# Threat model

## Main attack surfaces
- Browser auth flows and redirect handling
- Cookie session integrity
- service-to-service request forgery
- schema drift between publishers and consumers
- asset publishing tampering

## Mitigations in bundle
- signed auth flow cookies with state and nonce
- redirect allowlists on the auth boundary
- AutoContext enrichment before handlers run
- service health endpoints and correlation IDs for traceability
- event schema files and proto contracts to reduce silent drift
