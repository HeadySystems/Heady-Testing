# Error codes

| Code | Meaning | Surface |
|---|---|---|
| AUTH_REDIRECT_REJECTED | redirect target failed allowlist validation | heady-auth |
| AUTH_STATE_MISMATCH | callback state did not match signed flow record | heady-auth |
| SESSION_NOT_FOUND | session introspection had no active session | auth-session-server |
| SEARCH_EMPTY | search query returned no documents | search-service |
| MIGRATION_DRY_RUN_ONLY | migration request executed in dry-run mode only | migration-service |
| ASSET_NOT_PUBLISHED | asset manifest exists but was not published | asset-pipeline |
