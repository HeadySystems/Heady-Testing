# Heady docs

This knowledge base is the operator-facing map for the current Heady system bundle.

## Sections
- `architecture/` — topology, service roles, and integration boundaries
- `adr/` — architectural decisions that govern the bundle
- `runbooks/` — local validation and auth operations
- `security/` — zero-trust posture and auth boundary notes
- `onboarding/` — developer onboarding path
- `operations/` — error catalog and response guidance
## Expanded bundle content
- `docs/architecture/` now includes C4 views, dependency notes, and an SVG overview.
- `docs/debug/` includes per-service debug guides for the added platform foundation services.
- `docs/platform/` covers CI/CD, event mesh, feature flags, and gRPC contracts.
