# C4 container

## Containers
- Web surfaces under `apps/` for marketing, operations, auth, and developer support.
- Shared browser packages under `packages/` for design, sacred geometry, auth launch, navigation, AutoContext, and content injection.
- Microservices under `services/` grouped by intelligence, routing, user-facing, security, monitoring, integration, specialized runtime, and platform foundation.
- Infrastructure manifests under `infra/` for Compose, Kubernetes, Envoy, Consul, OpenTelemetry, NATS, and PgBouncer.

## Container relationships
- Browser surfaces delegate identity to `heady-auth` and `auth-session-server`.
- Services receive AutoContext enrichment through shared middleware before domain handlers execute.
- Search, analytics, notifications, scheduler, billing, migrations, and assets provide the missing support layer for docs, status, commerce, and operator workflows.
