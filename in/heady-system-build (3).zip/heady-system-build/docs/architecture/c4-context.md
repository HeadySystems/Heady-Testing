# C4 context

Updated: 2026-03-10T02:12:48+00:00

## System boundary
- Public and protected web surfaces: 10 original app surfaces plus support surfaces for pricing, developer portal, status, API docs, and build journal.
- Service boundary: 53 original services plus added platform foundation services for notifications, analytics, billing, search, scheduling, migrations, assets, and sessions.
- Data boundary: PostgreSQL with pgvector, auth cookies on the auth domain, event schemas, and generated assets.

## External systems
- Cloudflare edge for static delivery, Workers, DNS, and edge policy.
- Google Cloud for Cloud Run and project-level managed services.
- Firebase Identity Toolkit for auth flows when environment keys are present.
- Drupal JSON:API as structured content source feeding AutoContext and site publishing.
