# ADR-003 session boundary

## Decision
Split the auth concern into `heady-auth` for login, cookie minting, and OAuth orchestration, plus `auth-session-server` for runtime introspection, refresh, and revoke operations.

## Why
The original bundle had central auth but no dedicated runtime session relay surface. The split reduces coupling between login-time actions and every-request session checks.
