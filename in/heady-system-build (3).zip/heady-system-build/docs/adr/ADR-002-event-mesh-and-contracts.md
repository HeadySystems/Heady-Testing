# ADR-002 event mesh and contracts

## Decision
Add an explicit event-contract layer with schema files, proto definitions, and a JetStream-ready configuration so service-to-service coordination is documented and can evolve safely.

## Why
The original bundle had service shells and telemetry, but it lacked a concrete contract boundary for event-driven expansion. This made notifications, scheduling, analytics rollups, and asset publishing harder to connect.

## Outcome
Event schemas now live under `schemas/events/`, proto files under `proto/`, and NATS configuration under `infra/nats/`.
