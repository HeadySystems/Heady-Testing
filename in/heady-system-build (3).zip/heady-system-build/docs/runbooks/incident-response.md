# Incident response

## Trigger
Use this when a user-facing surface, auth flow, or service family stops responding or produces incorrect results.

## Steps
1. Confirm the affected boundary: browser, gateway, auth, AutoContext, or service family.
2. Check `/health` and `/status` for the relevant services.
3. Inspect correlated logs using the request correlation ID.
4. If the break sits at the edge, compare DNS, TLS, and gateway routing assumptions.
5. If the break sits in stateful services, review session, database, and event-mesh dependencies.
6. Publish a status update through the status surface and notifications service.
7. Capture the fix path in the build journal and debug guides.
