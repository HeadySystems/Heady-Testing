#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/user/workspace/heady-system-build"

command -v node >/dev/null 2>&1 || { echo "Node.js is required"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "npm is required"; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "Docker is required for full stack validation"; exit 1; }

NODE_MAJOR=$(node -p "process.versions.node.split('.')[0]")
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "Node.js 20 or newer is required"
  exit 1
fi

if [ ! -f "$ROOT/.env" ]; then
  echo "Create $ROOT/.env before running the full local stack"
fi

chmod +x "$ROOT"/scripts/*.sh || true
npm --prefix "$ROOT" run validate
npm --prefix "$ROOT" test

echo "Bundle checks complete. Add deploy-time secrets, then use docker compose for the wider stack."
