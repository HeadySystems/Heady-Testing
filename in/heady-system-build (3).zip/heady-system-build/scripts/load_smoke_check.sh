#!/usr/bin/env bash
set -euo pipefail

echo "Load smoke check plan"
echo "1. Start heady-auto-context"
echo "2. Start notification-service, analytics-service, search-service, scheduler-service"
echo "3. Hit /health across services"
echo "4. Replay sample API calls from docs/api-docs"
