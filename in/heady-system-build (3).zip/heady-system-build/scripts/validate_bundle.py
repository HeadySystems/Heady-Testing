from pathlib import Path
import sys

root = Path('/home/user/workspace/heady-system-build')

required_files = [
    root / 'CHANGES.md',
    root / 'GAPS_FOUND.md',
    root / 'IMPROVEMENTS.md',
    root / 'docs/architecture/system-topology.md',
    root / 'docs/runbooks/local-validation.md',
    root / 'docs/security/zero-trust-posture.md',
    root / 'docs/onboarding/developer-onboarding.md',
    root / 'docs/operations/error-catalog.md',
    root / 'docs/operations/ERROR_CODES.md',
    root / 'docs/architecture/c4-context.md',
    root / 'docs/architecture/c4-container.md',
    root / 'docs/architecture/dependency-graph.md',
    root / 'docs/architecture/architecture.svg',
    root / 'docs/runbooks/incident-response.md',
    root / 'docs/security/threat-model.md',
    root / 'apps/pricing/index.html',
    root / 'apps/developer-portal/index.html',
    root / 'apps/status/index.html',
    root / 'apps/api-docs/index.html',
    root / 'apps/blog/index.html',
]

failures = []
for file_path in required_files:
    if not file_path.exists():
        failures.append(f'missing: {file_path}')

service_packages = list(root.glob('services/**/package.json'))
if len(service_packages) < 58:
    failures.append(f'expected at least 58 service package.json files, found {len(service_packages)}')

auth_text = (root / 'services/user-facing/heady-auth/index.js').read_text(encoding='utf-8')
for required in ['/oauth/google', '/oauth/github', '/oauth/google/callback', '/oauth/github/callback']:
    if required not in auth_text:
        failures.append(f'auth route missing: {required}')

auto_text = (root / 'services/specialized/heady-auto-context/index.js').read_text(encoding='utf-8')
for required in ['/context/enrich', '/context/index-batch', '/context/remove', '/context/query']:
    if required not in auto_text:
        failures.append(f'autocontext route missing: {required}')


expanded_services = [
    root / 'services/platform-foundation/notification-service/index.js',
    root / 'services/platform-foundation/analytics-service/index.js',
    root / 'services/platform-foundation/billing-service/index.js',
    root / 'services/platform-foundation/search-service/index.js',
    root / 'services/platform-foundation/scheduler-service/index.js',
    root / 'services/platform-foundation/migration-service/index.js',
    root / 'services/platform-foundation/asset-pipeline/index.js',
    root / 'services/platform-foundation/auth-session-server/index.js',
]
for file_path in expanded_services:
    if not file_path.exists():
        failures.append(f'missing expanded service: {file_path}')

bridge_text = (root / 'packages/auto-context/auto-context-bridge.js').read_text(encoding='utf-8')
if 'sessionStorage' in bridge_text or 'localStorage' in bridge_text:
    failures.append('browser storage reference remains in auto-context bridge')

if failures:
    print('VALIDATION FAILED')
    for failure in failures:
        print('-', failure)
    sys.exit(1)

print('VALIDATION PASSED')
print(f'services={len(service_packages)}')
