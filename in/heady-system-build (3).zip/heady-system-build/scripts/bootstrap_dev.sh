#!/usr/bin/env bash
set -euo pipefail

echo "Preparing Heady local development bundle"
test -f /home/user/workspace/heady-system-build/package.json
chmod +x /home/user/workspace/heady-system-build/scripts/*.sh || true
npm --prefix /home/user/workspace/heady-system-build run validate
npm --prefix /home/user/workspace/heady-system-build test
echo "Bundle checks complete. Configure env secrets before docker compose usage."
