#!/usr/bin/env bash
set -euo pipefail

echo "Suggested manual fault injection"
echo "- stop consul and confirm services keep serving /health"
echo "- stop heady-auto-context and confirm middleware degrades gracefully"
echo "- send stale session ids to auth-session-server and verify revocation behavior"
