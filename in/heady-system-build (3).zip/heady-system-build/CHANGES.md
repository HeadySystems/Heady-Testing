# CHANGES

## Maximum-potential pass
- Implemented concrete HeadyAutoContext enrichment endpoints: `/context/enrich`, `/context/index-batch`, `/context/remove`, and `/context/query`.
- Added in-memory vector source indexing with deterministic seed vectors, CSL-style scoring, and source summaries for downstream services.
- Expanded `heady-auth` with Google and GitHub OAuth launch plus callback routes guarded by signed flow cookies, redirect allowlists, and nonce/state preservation.
- Removed browser storage dependence from the client AutoContext bridge. Context now stays in memory and syncs across active tabs/windows via `BroadcastChannel` and `postMessage`.
- Cleaned the site generator so future auth surfaces do not reintroduce browser storage or alert-based OAuth placeholders.
- Added a root documentation tree for architecture, ADRs, security posture, onboarding, runbooks, and error catalog material.
- Added validation tests and a local validation script for auth, AutoContext, bundle structure, and storage-policy enforcement.
## Expansion pass
- Added eight platform foundation services for notifications, analytics, billing, search, scheduling, migrations, assets, and session runtime checks.
- Added support app surfaces for pricing, developer portal, status, API docs, and build journal.
- Added event schemas, gRPC contracts, C4 architecture notes, SVG system diagram, additional ADRs, and recovery documentation.
- Added local bootstrap scripts, chaos/load guidance, NATS and PgBouncer configuration, and a GitHub Actions validation workflow.

## Hardening follow-up
- Expanded core and support surfaces again so every major public/support page now carries materially deeper long-form narrative and clearer operational framing.
- Reworded legacy generated copy and page text to align more closely with concurrent-equals vocabulary across the bundle.
- Replaced leftover generator console output with structured JSON output and strengthened the drupal-sync service export surface.
- Rebuilt the five support pages into complete multi-section surfaces with long-form content, stats, process guidance, ecosystem maps, use cases, FAQ sections, and structured metadata.
- Added `scripts/setup-dev.sh`, `.env`, and `.env.example` so the local validation path is easier to follow without guessing required secrets.
- Corrected AutoContext middleware defaults so services target port `8907`, emit structured JSON logs for degraded enrichment, and index auth events through `/context/index-batch` instead of a missing route.
- Recorded the remaining gaps explicitly: the full all-services Docker run is still not verified, several support pages remain below the literal 2000-word target, and older generator content still contains legacy concurrent-equals cleanup work.

## Round 4 — final maximum-potential pass
- Fixed two isolated `HIGH` word appearances in status and blog support pages (changed to `full` where contextually appropriate).
- Cleaned self-referential forbidden-language shortcuts inside orchestration refactoring comments (bee-factory, swarm-coordinator, hcfullpipeline-stage4) — replaced `PRIORITY.HIGH/MEDIUM/LOW/CRITICAL` shorthand placeholders with `CONCURRENT.EQUAL`.
- Hardened four platform-foundation services from thin in-memory shells to production-pattern implementations:
  - `notification-service`: fan-out delivery, channel preferences, digest queue, audit log, delivery history endpoint.
  - `billing-service`: flat plan catalog, subscription management, usage metering, invoice preview, Fibonacci-bounded usage records.
  - `analytics-service`: event ingestion, session rollup, top-events metrics slice, phi-scaled event bus.
  - `search-service`: BM25 lexical scoring, hybrid domain filtering, document index, configurable result limits using Fibonacci values.
- Extended `apps/auth/index.html` with a second deep-dive section covering cookie architecture, OAuth normalization, guest sessions, AutoContext integration at the auth layer, session lifecycle, and revocation — page word count now above 2000.
- Updated `docs/architecture/system-topology.md`: renamed `Critical boundaries` section to `Key boundaries` to remove classification language from architecture docs.
- Note: `DeregisterCriticalServiceAfter` in `infra/consul/consul.hcl` is a required Consul API field name — retained as-is because it is an external API term, not a Heady classification.
