# Heady External Skills Research
**Date:** 2026-03-09 | **Author:** Perplexity Computer Research Agent  
**Scope:** MCP Server Skills, Vector DB Optimization, Cloudflare Workers AI, Firebase Extensions, Drupal JSON:API, SEO, WCAG 2.1  
**Aligned to:** Heady™ v4.0.0 "Sacred Genesis" — headymcp.com, Cloudflare edge layer, Google Cloud Run backend, pgvector 3D memory, 21-agent swarm matrix

---

## 1. MCP Server Skills & Packages

### 1.1 `@modelcontextprotocol/sdk` (Official TypeScript SDK)
- **URL:** https://www.npmjs.com/package/@modelcontextprotocol/sdk  
- **GitHub:** https://github.com/modelcontextprotocol/typescript-sdk  
- **Version:** v2 (pre-alpha on main branch; stable v1.x on npm); stable v2 anticipated Q1 2026  
- **Why it matters:** The canonical, Anthropic-maintained SDK for building MCP servers — implements the full MCP specification including `McpServer`, `ResourceTemplate`, `StdioServerTransport`, and `StreamableHTTPServerTransport`. Zod v3.25+ required for schema validation.  
- **Heady fit:** `headymcp-core` already houses 31 MCP tools. This SDK governs every tool declaration, `registerTool()` / `registerResource()` / `registerPrompt()` call, and bidirectional streaming. The WIRING_GUIDE.md already references `packages/mcp-server/src/index.ts` as the gateway; this SDK is the engine inside that package. Adopt `StreamableHTTPServerTransport` for headymcp.com; keep `StdioServerTransport` as fallback for IDE integrations (Windsurf, Cursor).

### 1.2 `fastmcp` (Rapid MCP Framework)
- **URL:** https://fastmcp.me  
- **npm:** https://www.npmjs.com/package/fastmcp  
- **Why it matters:** Opinionated, batteries-included MCP framework that drastically reduces boilerplate for wrapping existing APIs as MCP servers. Community consensus favors it over the raw Python SDK for most projects; TypeScript port available.  
- **Heady fit:** Use for rapid MCP tool prototyping when adding new HeadyMCP tools (currently 31; target expansion). Low-friction path to expose any Heady REST endpoint as an MCP resource without re-implementing transport, error envelopes, or session management.

### 1.3 Official MCP Registry
- **URL:** https://registry.modelcontextprotocol.io  
- **GitHub MCP Registry:** https://github.blog/ai-and-ml/github-copilot/meet-the-github-mcp-registry-the-fastest-way-to-discover-mcp-servers/  
- **Awesome list:** https://github.com/punkpeye/awesome-mcp-servers  
- **Why it matters:** Anthropic + GitHub jointly operate the official MCP registry (launched September 2025). Servers published here gain one-click install in VS Code Copilot and are auto-indexed into the GitHub MCP Registry. The registry requires a Dockerfile for submission.  
- **Heady fit:** Publishing `headymcp-core` to the official registry positions Heady as a first-class MCP platform. The 31-tool server is already feature-complete; packaging with Docker + `stdio` transport is the only gap for submission. Visibility to the developer community directly supports the heady.io SDK mission.

### 1.4 MCP Security Best Practices
- **URL:** https://modelcontextprotocol.io/docs/tutorials/security/security_best_practices  
- **Why it matters:** Specifies that MCP servers MUST use secure, non-deterministic session IDs (UUIDs from `crypto.randomUUID()`), per-client consent storage, and DNS rebinding protection when running locally.  
- **Heady fit:** Heady's UNBREAKABLE_LAWS.md requires typed error handling and auth on every endpoint. Session ID generation should be wired to `crypto.randomUUID()` (already available in Cloudflare Workers). DNS rebinding protection via `enableDnsRebindingProtection: true` + `allowedHosts` is required for local dev builds.

### 1.5 Cloudflare Official MCP Server
- **MCP Registry listing:** `Cloudflare` (official)  
- **URL:** https://mcpservers.org (search "Cloudflare")  
- **Why it matters:** Official Cloudflare MCP server lets agents deploy, configure, and interrogate Workers/KV/R2/D1 resources directly. This is a pre-built integration, not a build artifact.  
- **Heady fit:** Install as a tool dependency in the HeadyMCP gateway to give Heady agents direct read/write access to all 9 Cloudflare domain configurations, KV namespaces, and Vectorize indexes — without custom API wrapper code.

---

## 2. Vector Database Optimization

### 2.1 pgvector 0.8.0 — Iterative Index Scans
- **URL:** https://aws.amazon.com/blogs/database/supercharging-vector-search-performance-and-relevance-with-pgvector-0-8-0-on-amazon-aurora-postgresql/  
- **Docs:** https://github.com/pgvector/pgvector  
- **Why it matters:** pgvector 0.8.0 introduces `iterative_scan` mode (`relaxed_order` or `strict_order`), resolving a long-standing issue where HNSW indexes with filtered queries returned incomplete results. Up to 9× faster query processing and 100× more relevant results under filtered searches. `hnsw.max_scan_tuples` (default 20,000) controls recall vs. performance trade-off.  
- **Heady fit:** Heady's 3D Vector Space memory uses pgvector as its backing store on Google Cloud SQL. The DEEP-SCAN-AUDIT-REPORT confirms `minScore: 0.7` → `0.618` (ψ) is the CSL gate threshold. With iterative scan enabled, filtered queries combining `tenant_id`, persona archetype, or `phi_scale` metadata with semantic similarity will no longer silently under-return — critical for HeadyBrain → HeadySoul pipeline fidelity. Recommended migration:
  ```sql
  SET hnsw.iterative_scan = 'relaxed_order';
  SET hnsw.max_scan_tuples = 20000; -- F(12) = 144 × ~138 ≈ phi-closest at 21000
  CREATE INDEX ON memory_vectors USING hnsw (embedding vector_cosine_ops)
    WITH (m = 13, ef_construction = 89); -- Fibonacci m=13, ef=F(11)=89
  ```

### 2.2 HNSW vs IVFFlat Decision Matrix
- **URL:** https://www.instaclustr.com/education/vector-database/pgvector-key-features-tutorial-and-pros-and-cons-2026-guide/  
- **Why it matters:** HNSW delivers higher recall and lower latency for real-time workloads but consumes significantly more RAM during index builds; IVFFlat is better for large batch-updated datasets.  
- **Heady fit:** Heady's 10,000-bee scale with continuous memory writes favors HNSW for the hot query path but requires careful memory budgeting on the Ryzen 9 / 32GB workstation. Use `HNSW` with `m=13` (Fibonacci), `ef_construction=89` (Fibonacci). Monitor build RAM; schedule HNSW builds off-peak using the self-healing scheduler.

### 2.3 Cloudflare Vectorize
- **URL:** https://developers.cloudflare.com/vectorize/  
- **Pricing:** https://developers.cloudflare.com/vectorize/platform/pricing/  
- **Why it matters:** Globally distributed vector database native to Cloudflare Workers — no separate infrastructure. Supports cosine, Euclidean, and dot-product metrics. Metadata indexing and filtering available. Billing by queried + stored vector dimensions (very low cost at Heady scale). Free tier: 30M queried dimensions/month.  
- **Heady fit:** Cloudflare Vectorize is the edge-layer complement to pgvector on Cloud SQL. Pattern: generate embeddings via `@cf/baai/bge-m3` (Workers AI), write to Vectorize for sub-millisecond edge lookup, and promote high-confidence memories to pgvector for durable 3D storage. This two-tier vector architecture maps cleanly to the hot/cold router pattern flagged as unimplemented in the UNIMPLEMENTED_SERVICES_AUDIT. Vectorize serves as the "hot" vector store at the Cloudflare edge; pgvector is the "cold" authoritative store.

---

## 3. Cloudflare Workers AI

### 3.1 Workers AI Overview & Model Catalog
- **URL:** https://developers.cloudflare.com/workers-ai/  
- **Models catalog:** https://developers.cloudflare.com/workers-ai/models/  
- **Why it matters:** 50+ open-source and partner models available serverlessly via `env.AI.run()` from any Worker. No GPU provisioning. Supports batch inference, function calling, LoRA fine-tuning, and real-time streaming.  
- **Key models for Heady:**
  | Model | ID | Use in Heady |
  |---|---|---|
  | Llama 4 Scout 17B (MoE) | `@cf/meta/llama-4-scout-17b-16e-instruct` | Primary reasoning agent |
  | Llama 3.3 70B (fp8) | `@cf/meta/llama-3.3-70b-instruct-fp8-fast` | High-stakes pipeline stages |
  | EmbeddingGemma 300M | `@cf/google/embedding-gemma-2-300m` | Edge-layer embedding generation |
  | BGE-M3 multilingual | `@cf/baai/bge-m3` | Vectorize ingestion + retrieval |
  | BGE Reranker Base | `@cf/baai/bge-reranker-base` | Post-ANN re-ranking pass |
  | Whisper Large v3 Turbo | `@cf/openai/whisper-large-v3-turbo` | HeadyBuddy voice ingestion |
  | MeloTTS | `@cf/myshell-ai/melotts` | Text-to-speech output |
  | Deepgram Nova-3 | `@cf/deepgram/nova-3` | Real-time STT, voice agents |
  | FLUX.2 [klein] | `@cf/flux/flux-2-klein` | Image generation |

### 3.2 AI Gateway Binding
- **URL:** https://developers.cloudflare.com/ai-gateway/integrations/worker-binding-methods/  
- **Why it matters:** The AI Gateway provides unified logging, caching, rate limiting, and `patchLog` feedback injection across all AI providers (Workers AI, OpenAI, Anthropic, Vertex AI) through a single `env.AI` binding. `getUrl()` generates provider-specific base URLs for drop-in SDK compatibility.  
- **Heady fit:** HeadyAPI (`headyapi.com`) is the "unified API layer with rate limiting, auth, intelligent routing." AI Gateway IS this layer for all AI traffic. Route all model calls through `env.GATEWAY.run()` to centralize cost tracking, implement the phi-exponential retry policy (1618ms/2618ms/4236ms), and capture telemetry aligned with the SLO definitions in `slo-definitions.yaml`.

### 3.3 `@cloudflare/workers-types` + Wrangler
- **URL:** https://developers.cloudflare.com/workers-ai/configuration/bindings/  
- **Why it matters:** `wrangler types` auto-generates TypeScript types for all `env` bindings including `env.AI`, `env.VECTORIZE`, `env.KV`, and `env.DO` from `wrangler.jsonc`. Eliminates runtime type mismatches.  
- **Heady fit:** Heady's LAW 1 (thoroughness) and TypeScript enforcement mandate typed bindings. Run `wrangler types` as a pre-commit hook to keep `env` types synchronized with `wrangler.jsonc` across all 9 Cloudflare-deployed domains.

---

## 4. Firebase Extensions

### 4.1 Vector Search with Firestore (Google Cloud Extension)
- **URL:** https://extensions.dev/extensions/googlecloud/firestore-vector-search  
- **Version:** 0.1.2 | **Publisher:** Google Cloud  
- **Why it matters:** One-install extension that auto-embeds specified Firestore document fields using Gemini (Google AI or Vertex AI) via Genkit, writes embeddings back to the same document, and exposes a callable Cloud Function `ext-firestore-vector-search-queryCallable` for KNN queries. Supports pre-filtering with composite vector indexes.  
- **Heady fit:** If Heady uses Firestore as an intermediate event store or community data layer (headyconnection.com), this extension provides zero-code RAG on that data. Wire `ext-firestore-vector-search-queryCallable` as an MCP tool in headymcp-core to give agents semantic search over community content without a custom embedding pipeline.

### 4.2 Firebase Genkit (`@genkit-ai/firebase`)
- **URL:** https://www.npmjs.com/package/@genkit-ai/firebase  
- **GitHub:** https://github.com/firebase/genkit  
- **Version:** 1.29.0 (active, published every 6 days)  
- **Why it matters:** Open-source AI framework by Firebase/Google. Provides: Firestore trace/state stores, Cloud Functions deployment helpers, Gemini/Vertex AI plugin, RAG retriever abstractions, streaming flows, and MCP tool integrations. Designed for production server-side AI pipelines with Node.js + Next.js.  
- **Heady fit:** Genkit's `flow` abstraction maps naturally to Heady's 21-stage HCFullPipeline. Genkit flows support configurable retries, structured output schemas, and telemetry — all aligned with Heady's phi-compliance requirements. The `@genkit-ai/firebase` plugin bridges to Google Cloud Firestore for state persistence, complementing the existing Cloud SQL / pgvector setup. Use for burst compute tasks offloaded to Colab nodes via Vertex AI.

### 4.3 Firestore BigQuery Export Extension
- **URL:** https://extensions.dev/extensions/firebase/firestore-bigquery-export  
- **Why it matters:** Streams Firestore document mutations to BigQuery in real-time via CDC (Change Data Capture). Enables SQL analytics, dashboards, and audit trails on Firestore data without custom pipelines.  
- **Heady fit:** The UNIMPLEMENTED_SERVICES_AUDIT flags the Event Store (immutable event history) as a critical gap. Firestore → BigQuery CDC is a viable implementation of the event sourcing pattern without building a custom event store from scratch. Use for HeadyOps audit trails and pipeline telemetry analytics.

### 4.4 Native Firestore Vector Search
- **URL:** https://firebase.google.com/docs/firestore/vector-search  
- **Why it matters:** Native KNN search in Cloud Firestore (GA as of 2026) using `findNearest()` with EUCLIDEAN, COSINE, or DOT_PRODUCT metrics. Max 2048 dimensions; max 1000 results per query. Flat index only (no HNSW). Supports pre-filtering with composite indexes.  
- **Heady fit:** Performance limitation — Firestore vector search is [reported as prohibitively slow for large collections](https://www.reddit.com/r/Firebase/comments/1kkiayv/firestore_vector_search_is_prohibitively_slow_for/). Not recommended as the primary vector store at Heady's 10K-bee scale. Best used for lower-volume community/social features on headyconnection.com where latency tolerance is higher.

---

## 5. Drupal JSON:API Integration

### 5.1 `next-drupal` (Official Drupal Next.js SDK)
- **URL:** https://next-drupal.org  
- **npm:** `npm install next-drupal`  
- **Why it matters:** The official, maintained JavaScript SDK for consuming Drupal's JSON:API from Next.js. Provides `DrupalClient` with methods for `getResourceCollection()`, `getResourceFromPath()`, `getStaticPaths()`, and authenticated fetch. Handles nested includes (`?include=field_image`) and field filtering (`?fields[node--article]=title,field_image`) out of the box.  
- **Heady fit:** If headyconnection.com or any Heady domain uses Drupal as a headless CMS backend (common for nonprofit + community platforms), `next-drupal` is the canonical client. It integrates with Heady's Cloudflare CDN caching layer — SSG pages can be configured to rebuild via Drupal webhooks, keeping edge-cached content fresh.

### 5.2 `drupal-jsonapi-params`
- **URL:** https://www.npmjs.com/package/drupal-jsonapi-params  
- **Drupal.org docs:** https://www.drupal.org/docs/develop/decoupled-drupal/frontend-libraries  
- **Why it matters:** Essential helper library for building complex JSON:API query strings with filtering, sorting, includes, pagination, and sparse fieldsets in a type-safe, programmatic way. Avoids manual URL string construction.  
- **Heady fit:** When Heady agents need to query Drupal content programmatically (e.g., HeadyBuddy fetching community articles, HeadyCoder reading documentation nodes), `drupal-jsonapi-params` provides the query builder layer. Integrate as a utility in `headyconnection-core` or `headyapi-core`.

### 5.3 Drupal JSON:API Ecosystem Modules
- **Reference:** https://github.com/d34dman/awesome-drupal-jsonapi (archived but comprehensive reference)  
- **Key modules:**
  | Module | Purpose | Heady Relevance |
  |---|---|---|
  | JSON:API Extras | Customize field exposure and route aliases | Fine-tune which content fields agents can read |
  | JSON:API Boost | Cache-warm resource types on deploy | Reduces cold-start latency for edge-fetched content |
  | Simple OAuth | OAuth 2.0 auth for Drupal API | Required for authenticated agent access to draft content |
  | JSON:API Search API | Expose Drupal Search API indexes via JSON:API | Full-text + faceted search from Heady agents |
  | JSON:API Views | Expose Drupal Views as JSON:API resources | Pre-built content feeds without custom endpoints |

### 5.4 Contenta CMS
- **URL:** https://github.com/contentacms/contenta_jsonapi  
- **Why it matters:** API-first Drupal distribution with JSON:API, OAuth, and decoupled-optimized configuration pre-wired. Eliminates manual Drupal setup for headless deployments.  
- **Heady fit:** If a new Drupal instance is needed for a Heady content domain, Contenta provides a production-ready starting point with zero-configuration JSON:API and OAuth, compatible with `next-drupal`.

---

## 6. SEO Optimization

### 6.1 Next.js Metadata API (Built-in, v15/v16)
- **URL:** https://dev.to/vrushikvisavadiya/nextjs-15-seo-checklist-for-developers-in-2025-with-code-examples-57i1  
- **Next.js docs:** https://nextjs.org/docs/app/building-your-application/optimizing/metadata  
- **Why it matters:** Next.js App Router's `metadata` export provides server-side Open Graph, Twitter Card, canonical URL, and robots directives with zero external dependencies. Dynamic metadata via `generateMetadata()` enables per-page SEO for all 9 Heady domains.  
- **Heady fit:** All 9 Heady Next.js frontends (headyme.com through headybot.com) should implement `generateMetadata()` for dynamic pages. Each domain has a distinct purpose (SDK docs, AI companion, infrastructure dashboard) — tailored metadata increases organic discoverability for developer and enterprise audiences.

### 6.2 `schema-dts` — Schema.org JSON-LD TypeScript Types
- **URL:** https://github.com/google/schema-dts  
- **npm:** `npm install --save-dev schema-dts`  
- **Version:** v1.1.5 (March 2025); used by 26,200+ projects  
- **Why it matters:** Google-maintained TypeScript types for all Schema.org vocabulary. Enables type-safe construction of JSON-LD structured data (Organization, SoftwareApplication, FAQPage, HowTo, Article) that directly feeds Google rich results and AI overview citations. JSON-LD is the recommended format, now used by 45M+ domains.  
- **Heady fit:** Heady's 9 domains each warrant `Organization`, `SoftwareApplication`, and `WebSite` schemas at minimum. `headymcp.com` and `heady.io` (developer docs) benefit from `TechArticle` and `APIReference` schemas. In 2026, AI search engines (Perplexity, ChatGPT, Gemini) cite structured entities directly — schema markup is now an AI visibility signal, not just a Google SEO tactic.

### 6.3 Core Web Vitals + INP Optimization
- **URL:** https://strapi.io/blog/nextjs-seo  
- **Why it matters:** Google's 2025 ranking algorithm uses Core Web Vitals as table stakes: LCP < 2.5s, INP < 200ms, CLS < 0.1. Next.js 16's Turbopack, layout deduplication, and incremental prefetching handle most of this automatically, but INP requires explicit event handler optimization in React components.  
- **Heady fit:** The 17-swarm React micro-frontend architecture (Module Federation template `template-heady-ui`) needs INP budget management. Heady's event-dense dashboards (HeadyMCP control panel, HeadyOps telemetry) are particularly INP-sensitive. Use `reportWebVitals()` + Cloudflare Analytics for real-time CWV monitoring.

### 6.4 `next-sitemap`
- **URL:** https://www.npmjs.com/package/next-sitemap  
- **Why it matters:** Generates `sitemap.xml` and `robots.txt` from Next.js routes with SSG/ISR support, `changefreq`, `priority`, and per-domain configuration.  
- **Heady fit:** Each of the 9 Heady domains requires a separately configured sitemap. `next-sitemap` can be configured with `siteUrl` per domain and integrated into the GitHub Actions CI pipeline to regenerate on each deployment.

---

## 7. WCAG 2.1 Accessibility

### 7.1 `axe-core` (Deque Systems)
- **URL:** https://www.npmjs.com/package/axe-core  
- **GitHub:** https://github.com/dequelabs/axe-core  
- **Version:** Latest 2026 release active  
- **Why it matters:** Industry-standard accessibility testing engine. Detects ~57% of WCAG 2.1 A/AA/AAA violations automatically. Rules cover WCAG 2.0, 2.1, and 2.2. Zero false-positive design philosophy. Integrates with Jest, Playwright, Cypress, and Puppeteer.  
- **Heady fit:** Heady's 9 public domains (especially headyconnection.com as a nonprofit community platform) face legal WCAG 2.1 AA obligations. `axe-core` should be installed as a dev dependency in every frontend repo and run in CI via `@axe-core/playwright` against WCAG 2.1 AA tags:
  ```typescript
  const results = await new AxeBuilder({ page })
    .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa'])
    .analyze();
  expect(results.violations).toEqual([]);
  ```

### 7.2 `jest-axe`
- **URL:** https://www.npmjs.com/package/jest-axe  
- **Why it matters:** Integrates axe-core with Jest + React Testing Library for unit-level accessibility assertions (`toHaveNoViolations()`). Catches component-level issues before integration.  
- **Heady fit:** Pair with React Testing Library in all UI component tests across `template-heady-ui` and the 9 domain frontends. Catches ARIA attribute errors, missing labels, and invalid roles at the component level — the cheapest point in the development cycle to fix them.

### 7.3 `@axe-core/playwright`
- **URL:** https://www.npmjs.com/package/@axe-core/playwright  
- **Why it matters:** Playwright integration for axe-core. Enables full-page WCAG scans in E2E test suites, with selector-scoped analysis for complex SPA components like modals, data grids, and real-time dashboards.  
- **Heady fit:** Wire into the existing GitHub Actions CI pipeline alongside the quality gate checks already described in WIRING_GUIDE.md. Generates accessibility reports as CI artifacts on every PR, blocking merges with violations above a configurable threshold.

### 7.4 Adobe React Aria
- **URL:** https://react-spectrum.adobe.com/react-aria/  
- **npm:** `npm install react-aria`  
- **Why it matters:** Adobe-maintained collection of React hooks implementing WAI-ARIA patterns for complex interactive components (combobox, date picker, drag-and-drop, table). State-machine-driven, cross-platform (web, mobile, desktop), and extensively tested for accessibility. Internationalization built in.  
- **Heady fit:** Heady's AI companion interfaces (HeadyBuddy), command dashboards (headyme.com), and developer SDK portal (heady.io) use non-standard interactive patterns (real-time swarm status, live log streams, agent control panels) that require custom ARIA implementations. React Aria provides the accessible primitives without prescribing visual design, compatible with Heady's Sacred Geometry styling system.

### 7.5 `pa11y-ci`
- **URL:** https://github.com/pa11y/pa11y-ci  
- **npm:** `npm install -g pa11y-ci`  
- **Why it matters:** CLI accessibility scanner supporting WCAG2AA standard, multiple test runners (axe + HTMLCS), and URL batch configuration. Output as JSON for CI parsing. Native GitHub Actions + GitLab CI integration.  
- **Heady fit:** Standalone CLI gate for the GitHub Actions quality pipeline. Configure `pa11yci.json` with all 9 Heady domain staging URLs to run a full WCAG 2.1 AA scan on every deployment before production promotion.

---

## 8. Summary Alignment Matrix

| Area | Top Package/Resource | Heady Component | Priority |
|---|---|---|---|
| MCP Server SDK | `@modelcontextprotocol/sdk` v2 | `headymcp-core` / `packages/mcp-server` | 🔴 Critical |
| MCP Registry Publication | Official MCP Registry + Docker | `headymcp-core` → registry submission | 🟡 High |
| MCP Framework | `fastmcp` | New MCP tool rapid prototyping | 🟢 Medium |
| pgvector Optimization | pgvector 0.8.0 iterative scan | Cloud SQL vector memory (3D space) | 🔴 Critical |
| Edge Vector Store | Cloudflare Vectorize | Hot/cold vector router (unimplemented) | 🟡 High |
| CF Workers AI Models | BGE-M3 + BGE-Reranker + Llama 4 Scout | Edge-layer inference / embedding | 🔴 Critical |
| CF AI Gateway | AI Gateway binding (`env.GATEWAY`) | `headyapi-core` unified AI routing | 🟡 High |
| Firebase Vector Search Ext. | `googlecloud/firestore-vector-search` | `headyconnection-core` community RAG | 🟢 Medium |
| Firebase Genkit | `@genkit-ai/firebase` v1.29 | Vertex AI burst compute + flows | 🟢 Medium |
| Drupal JSON:API Client | `next-drupal` + `drupal-jsonapi-params` | `headyconnection-core` CMS layer | 🟢 Medium |
| SEO Structured Data | `schema-dts` + Next.js Metadata API | All 9 domain frontends | 🟡 High |
| WCAG 2.1 Testing | `axe-core` + `@axe-core/playwright` | All 9 domain frontends + CI pipeline | 🟡 High |
| WCAG 2.1 Components | Adobe React Aria | `template-heady-ui` component library | 🟡 High |

---

## 9. Phi-Compliance Notes

All package integrations must respect Heady's mathematical constants:
- Retry delays: `[1618, 2618, 4236]` ms (φ¹×1000, φ²×1000, φ³×1000)
- Connection pools: Fibonacci sizes — F(6)=8, F(8)=21, F(10)=55
- Rate limits: F(16)=987 req/hour (already in `heady.config.yaml`)
- MCP burst limit: F(10)=55 (already configured)
- axe-core violation threshold for CI gate: 0 (LAW 1 — thoroughness over speed)
- HNSW index params: `m=13` (F(7)), `ef_construction=89` (F(11))
- Vectorize query batch size: 89 vectors (F(11))
