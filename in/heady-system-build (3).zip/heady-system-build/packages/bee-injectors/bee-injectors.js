/**
 * HEADY™ Bee Content Injectors
 * Dynamic content injection modules for populating site sections.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 *
 * Each injector takes a container element and populates it with
 * contextually-appropriate content based on the site and section type.
 */

const PHI = 1.6180339887;

/**
 * Inject ecosystem map showing all 9 Heady sites and their relationships.
 */
function injectEcosystemMap(container, currentSiteId) {
  const sites = [
    { id: 'headyme', label: 'HeadyMe', url: 'https://headyme.com', icon: '◎', desc: 'Personal AI Cloud', ring: 'center', accent: '#00d4aa' },
    { id: 'headysystems', label: 'HeadySystems', url: 'https://headysystems.com', icon: '⬡', desc: 'Enterprise Infrastructure', ring: 'inner', accent: '#00d4aa' },
    { id: 'heady-ai', label: 'HeadyAI', url: 'https://heady-ai.com', icon: '△', desc: 'Research & Science', ring: 'inner', accent: '#8b5cf6' },
    { id: 'headyos', label: 'HeadyOS', url: 'https://headyos.com', icon: '◇', desc: 'Developer OS', ring: 'inner', accent: '#14b8a6' },
    { id: 'headyconnection-org', label: 'HeadyConnection.org', url: 'https://headyconnection.org', icon: '⊛', desc: 'Non-Profit 501(c)(3)', ring: 'middle', accent: '#f59e0b' },
    { id: 'headyconnection-com', label: 'HeadyConnection.com', url: 'https://headyconnection.com', icon: '⊕', desc: 'Community Portal', ring: 'middle', accent: '#06b6d4' },
    { id: 'headyex', label: 'HeadyEX', url: 'https://headyex.com', icon: '⟁', desc: 'Agent Marketplace', ring: 'middle', accent: '#10b981' },
    { id: 'headyfinance', label: 'HeadyFinance', url: 'https://headyfinance.com', icon: '⬢', desc: 'Investor Relations', ring: 'outer', accent: '#a855f7' },
    { id: 'admin-portal', label: 'Admin Portal', url: 'https://admin.headysystems.com', icon: '⊞', desc: 'Internal Ops', ring: 'outer', accent: '#06b6d4' },
  ];

  const html = `
    <div class="eco-map">
      ${sites.map(s => `
        <a href="${s.url}" class="eco-node ${s.id === currentSiteId ? 'eco-node--current' : ''}" style="--node-accent:${s.accent}" ${s.id === currentSiteId ? '' : 'target="_blank" rel="noopener"'}>
          <span class="eco-icon">${s.icon}</span>
          <span class="eco-label">${s.label}</span>
          <span class="eco-desc">${s.desc}</span>
        </a>
      `).join('')}
    </div>
  `;
  container.innerHTML = html;
}

/**
 * Inject tech stack display with animated cards.
 */
function injectTechStack(container, stack) {
  const items = stack || [
    { name: 'Cloudflare', category: 'Edge', desc: 'Workers, KV, Pages, Vectorize, Durable Objects' },
    { name: 'Google Cloud', category: 'Cloud', desc: 'Cloud Run, Cloud SQL, Vertex AI' },
    { name: 'pgvector', category: 'Memory', desc: '384-dimensional vector space for semantic memory' },
    { name: 'MCP Protocol', category: 'Protocol', desc: '31 tools via JSON-RPC 2.0 over SSE/stdio' },
    { name: 'Sacred Geometry', category: 'Foundation', desc: 'φ-scaled constants govern every parameter' },
    { name: 'CSL Engine', category: 'Logic', desc: 'Continuous Semantic Logic geometric gates' },
    { name: 'Multi-Model', category: 'AI', desc: 'Claude, GPT, Gemini, Groq, Perplexity' },
    { name: 'Ed25519', category: 'Security', desc: 'Cryptographic receipt signing, zero-trust' },
  ];

  container.innerHTML = `
    <div class="tech-grid">
      ${items.map(item => `
        <div class="glass-card tech-item">
          <span class="tag">${item.category}</span>
          <h4>${item.name}</h4>
          <p>${item.desc}</p>
        </div>
      `).join('')}
    </div>
  `;
}

/**
 * Inject cross-links footer for ecosystem navigation.
 */
function injectFooterCrossLinks(container, currentSiteId) {
  const sites = [
    { id: 'headyme', label: 'HeadyMe', url: 'https://headyme.com' },
    { id: 'headysystems', label: 'HeadySystems', url: 'https://headysystems.com' },
    { id: 'heady-ai', label: 'HeadyAI', url: 'https://heady-ai.com' },
    { id: 'headyos', label: 'HeadyOS', url: 'https://headyos.com' },
    { id: 'headyconnection-org', label: 'HeadyConnection.org', url: 'https://headyconnection.org' },
    { id: 'headyconnection-com', label: 'HeadyConnection.com', url: 'https://headyconnection.com' },
    { id: 'headyex', label: 'HeadyEX', url: 'https://headyex.com' },
    { id: 'headyfinance', label: 'HeadyFinance', url: 'https://headyfinance.com' },
    { id: 'admin-portal', label: 'Admin Portal', url: 'https://admin.headysystems.com' },
  ];

  container.innerHTML = sites
    .filter(s => s.id !== currentSiteId)
    .map(s => `<a href="${s.url}" target="_blank" rel="noopener">${s.label}</a>`)
    .join(' · ');
}

/**
 * Inject FAQ section with accordion behavior.
 */
function injectFAQ(container, faqs) {
  container.innerHTML = faqs.map((faq, i) => `
    <div class="faq-item" data-index="${i}">
      <button class="faq-question">${faq.q}</button>
      <div class="faq-answer"><p>${faq.a}</p></div>
    </div>
  `).join('');

  container.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.parentElement;
      const wasActive = item.classList.contains('active');
      container.querySelectorAll('.faq-item').forEach(fi => fi.classList.remove('active'));
      if (!wasActive) item.classList.add('active');
    });
  });
}

/**
 * Inject use cases grid.
 */
function injectUseCases(container, cases) {
  container.innerHTML = `
    <div class="grid-3 use-cases">
      ${cases.map(c => `
        <div class="glass-card">
          <span style="font-size:1.618rem;display:block;margin-bottom:0.8rem">${c.icon}</span>
          <h4>${c.title}</h4>
          <p>${c.desc}</p>
        </div>
      `).join('')}
    </div>
  `;
}

/**
 * Inject how-it-works timeline.
 */
function injectHowItWorks(container, steps) {
  container.innerHTML = `
    <div class="how-steps">
      ${steps.map((step, i) => `
        <div class="how-step glass-card">
          <div class="how-step-num">${String(i + 1).padStart(2, '0')}</div>
          <h4>${step.title}</h4>
          <p>${step.desc}</p>
        </div>
      `).join('')}
    </div>
  `;
}

// Eco-map styles
const beeStyles = document.createElement('style');
beeStyles.textContent = `
.eco-map{display:grid;grid-template-columns:repeat(3,1fr);gap:1.3125rem;max-width:900px;margin:0 auto}
.eco-node{display:flex;flex-direction:column;align-items:center;text-align:center;padding:2.125rem 1.3125rem;background:rgba(13,13,26,.65);backdrop-filter:blur(24px);border:1px solid rgba(255,255,255,.06);border-radius:1.3125rem;text-decoration:none;transition:all .382s cubic-bezier(.16,1,.3,1)}
.eco-node:hover{transform:translateY(-3px);border-color:var(--node-accent,#7c5eff);box-shadow:0 0 21px rgba(124,94,255,.15);opacity:1}
.eco-node--current{border-color:var(--node-accent,#7c5eff);background:rgba(124,94,255,.06)}
.eco-icon{font-size:2rem;margin-bottom:.5rem}
.eco-label{font-weight:600;color:#e8e8f0;font-size:.95rem;margin-bottom:.25rem}
.eco-desc{font-size:.75rem;color:#9898b0}
.tech-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:1.3125rem}
.tech-item h4{margin:.5rem 0 .3rem;color:#e8e8f0}
.tech-item p{font-size:.85rem}
.how-steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:1.3125rem;counter-reset:step}
.how-step{text-align:center;padding:2.125rem 1.3125rem}
.how-step-num{font-family:'JetBrains Mono',monospace;font-size:2rem;font-weight:700;color:rgba(124,94,255,.3);margin-bottom:.5rem}
.how-step h4{color:#e8e8f0;margin-bottom:.5rem}
.how-step p{font-size:.85rem;color:#9898b0}
.use-cases h4{color:#e8e8f0;margin-bottom:.3rem;font-size:1rem}
.use-cases p{font-size:.85rem}
@media(max-width:768px){.eco-map{grid-template-columns:1fr 1fr}.how-steps{grid-template-columns:1fr}}
@media(max-width:480px){.eco-map{grid-template-columns:1fr}}
`;
document.head.appendChild(beeStyles);

if (typeof window !== 'undefined') {
  window.HeadyBeeInjectors = {
    injectEcosystemMap, injectTechStack, injectFooterCrossLinks,
    injectFAQ, injectUseCases, injectHowItWorks
  };
}

export {
  injectEcosystemMap, injectTechStack, injectFooterCrossLinks,
  injectFAQ, injectUseCases, injectHowItWorks
};
