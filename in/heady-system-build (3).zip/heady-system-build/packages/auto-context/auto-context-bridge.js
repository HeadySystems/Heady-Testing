/**
 * HEADY™ Auto-Context Bridge
 * Client-side context enrichment module for Heady ecosystem sites.
 *
 * Security model:
 * - No browser storage usage
 * - Context stays in memory and is synchronized across active tabs via BroadcastChannel/postMessage
 * - Auth remains central and cookie-backed on the auth domain
 */

const HEADY_DOMAINS = [
  'headyme.com',
  'headysystems.com',
  'heady-ai.com',
  'headyos.com',
  'headyconnection.org',
  'headyconnection.com',
  'headyex.com',
  'headyfinance.com',
  'admin.headysystems.com',
  'auth.headysystems.com',
];

const PHI_HEARTBEAT = 29034;

function safeJsonParse(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

class AutoContextBridge {
  constructor(options = {}) {
    this.siteId = options.siteId || this.detectSiteId();
    this.context = this.loadContext();
    this.listeners = [];
    this.heartbeatTimer = null;
    this.channel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('heady-autocontext') : null;
    this.init();
  }

  detectSiteId() {
    const host = window.location.hostname;
    const match = HEADY_DOMAINS.find(domain => host === domain || host.endsWith(`.${domain}`) || host.includes(domain.split('.')[0]));
    return match ? match.split('.')[0] : 'unknown';
  }

  init() {
    window.addEventListener('message', event => this.handleMessage(event));

    if (this.channel) {
      this.channel.addEventListener('message', event => {
        if (event.data?.type === 'heady:context:sync') {
          this.context = { ...this.context, ...event.data.payload };
          this.saveContext();
          this.notifyListeners();
        }
      });
    }

    this.updateContext({
      lastSite: this.siteId,
      lastVisit: new Date().toISOString(),
      visitCount: Number(this.context.visitCount || 0) + 1,
      currentPath: window.location.pathname,
    });

    this.startHeartbeat();
  }

  loadContext() {
    return safeJsonParse(window.__HEADY_CONTEXT_RUNTIME || '{}', {});
  }

  saveContext() {
    window.__HEADY_CONTEXT_RUNTIME = JSON.stringify(this.context);
  }

  updateContext(data) {
    this.context = { ...this.context, ...data, updatedAt: Date.now() };
    this.saveContext();
    this.broadcastContext();
    this.notifyListeners();
  }

  getContext() {
    return { ...this.context };
  }

  onContextChange(fn) {
    this.listeners.push(fn);
    return () => {
      this.listeners = this.listeners.filter(listener => listener !== fn);
    };
  }

  notifyListeners() {
    this.listeners.forEach(fn => fn(this.getContext()));
  }

  handleMessage(event) {
    const origin = event.origin || '';
    const isHeadyOrigin = HEADY_DOMAINS.some(domain => {
      try {
        const hostname = new URL(origin).hostname;
        return hostname === domain || hostname.endsWith(`.${domain}`) || hostname.includes(domain.split('.')[0]);
      } catch {
        return false;
      }
    });

    if (!isHeadyOrigin) return;

    const { type, payload } = event.data || {};
    if (type === 'heady:context:sync' && payload && typeof payload === 'object') {
      this.context = { ...this.context, ...payload };
      this.saveContext();
      this.notifyListeners();
    }
  }

  broadcastContext() {
    const message = { type: 'heady:context:sync', payload: this.getContext() };
    if (this.channel) this.channel.postMessage(message);
    try {
      if (window.opener) window.opener.postMessage(message, '*');
      if (window.parent && window.parent !== window) window.parent.postMessage(message, '*');
    } catch {
      // Intentionally ignore cross-origin window exceptions.
    }
  }

  startHeartbeat() {
    this.heartbeatTimer = setInterval(() => {
      this.updateContext({ heartbeat: Date.now() });
    }, PHI_HEARTBEAT);
  }

  getEcosystemLinks() {
    const sites = [
      { siteId: 'headyme', label: 'HeadyMe', url: 'https://headyme.com', tagline: 'Personal AI Cloud' },
      { siteId: 'headysystems', label: 'HeadySystems', url: 'https://headysystems.com', tagline: 'Enterprise Infrastructure' },
      { siteId: 'heady-ai', label: 'HeadyAI', url: 'https://heady-ai.com', tagline: 'Research & Science' },
      { siteId: 'headyos', label: 'HeadyOS', url: 'https://headyos.com', tagline: 'Developer OS' },
      { siteId: 'headyconnection-org', label: 'HeadyConnection.org', url: 'https://headyconnection.org', tagline: 'Non-Profit 501(c)(3)' },
      { siteId: 'headyconnection-com', label: 'HeadyConnection.com', url: 'https://headyconnection.com', tagline: 'Community Portal' },
      { siteId: 'headyex', label: 'HeadyEX', url: 'https://headyex.com', tagline: 'Agent Marketplace' },
      { siteId: 'headyfinance', label: 'HeadyFinance', url: 'https://headyfinance.com', tagline: 'Investor Relations' },
      { siteId: 'admin-portal', label: 'Admin Portal', url: 'https://admin.headysystems.com', tagline: 'Internal Ops' },
    ];
    return sites.map(site => ({ ...site, isCurrent: site.siteId === this.siteId }));
  }

  destroy() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer);
    if (this.channel) this.channel.close();
  }
}

if (typeof window !== 'undefined') {
  window.AutoContextBridge = AutoContextBridge;
}

export { AutoContextBridge, HEADY_DOMAINS };
