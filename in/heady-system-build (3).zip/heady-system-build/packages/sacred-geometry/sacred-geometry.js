/**
 * HEADY™ Sacred Geometry Animation
 * Canvas-based golden spiral, ring topology, and particle system.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 *
 * Renders a living sacred geometry background with:
 * - 5-ring concentric topology (CENTER, INNER, MIDDLE, OUTER, GOVERNANCE)
 * - Golden spiral overlay
 * - Fibonacci-distributed nodes on golden angle spacing
 * - Particle connections with CSL-threshold-based opacity
 * - Phi-pulsing animation cycle
 */

const PHI = (1 + Math.sqrt(5)) / 2;
const PSI = 1 / PHI;
const GOLDEN_ANGLE = Math.PI * 2 * PSI * PSI; // ≈ 137.5° in radians
const FIB = [1,1,2,3,5,8,13,21,34,55,89,144];

class SacredGeometryCanvas {
  constructor(canvasId, options = {}) {
    this.canvas = typeof canvasId === 'string'
      ? document.getElementById(canvasId)
      : canvasId;
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.opts = {
      accentColor: options.accentColor || '#7c5eff',
      secondaryColor: options.secondaryColor || '#40e0d0',
      goldColor: options.goldColor || '#f0c040',
      opacity: options.opacity || 0.35,
      nodeCount: options.nodeCount || 34,       // fib(9)
      connectionDistance: options.connectionDistance || 120,
      animationSpeed: options.animationSpeed || 0.0005,
      showSpiral: options.showSpiral !== false,
      showRings: options.showRings !== false,
      showNodes: options.showNodes !== false,
      showConnections: options.showConnections !== false,
      interactive: options.interactive !== false,
      ...options
    };
    this.nodes = [];
    this.mouse = { x: -1000, y: -1000 };
    this.time = 0;
    this.animFrame = null;
    this.init();
  }

  init() {
    this.resize();
    this.createNodes();
    if (this.opts.interactive) {
      this.canvas.addEventListener('mousemove', e => {
        const rect = this.canvas.getBoundingClientRect();
        this.mouse.x = e.clientX - rect.left;
        this.mouse.y = e.clientY - rect.top;
      });
      this.canvas.addEventListener('mouseleave', () => {
        this.mouse.x = -1000;
        this.mouse.y = -1000;
      });
    }
    window.addEventListener('resize', () => this.resize());
    this.animate();
  }

  resize() {
    const dpr = window.devicePixelRatio || 1;
    const rect = this.canvas.parentElement.getBoundingClientRect();
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
    this.canvas.style.width = rect.width + 'px';
    this.canvas.style.height = rect.height + 'px';
    this.ctx.scale(dpr, dpr);
    this.w = rect.width;
    this.h = rect.height;
    this.cx = this.w / 2;
    this.cy = this.h / 2;
    this.maxRadius = Math.min(this.w, this.h) * 0.4;
  }

  createNodes() {
    this.nodes = [];
    const rings = [
      { r: 0,               count: 1,  color: this.opts.goldColor },      // CENTER
      { r: this.maxRadius * PSI * PSI, count: 5, color: this.opts.accentColor },  // INNER
      { r: this.maxRadius * PSI, count: 8, color: this.opts.accentColor },        // MIDDLE
      { r: this.maxRadius * 0.78, count: 13, color: this.opts.secondaryColor },   // OUTER
      { r: this.maxRadius,   count: 8,  color: this.opts.goldColor },             // GOVERNANCE
    ];

    rings.forEach((ring, ri) => {
      for (let i = 0; i < ring.count; i++) {
        const angle = (i * GOLDEN_ANGLE) + (ri * Math.PI / 5);
        this.nodes.push({
          baseAngle: angle,
          radius: ring.r,
          ring: ri,
          color: ring.color,
          size: ri === 0 ? 4 : (3 - ri * 0.3),
          pulsePhase: Math.random() * Math.PI * 2,
          orbitSpeed: (0.0003 + Math.random() * 0.0002) * (ri % 2 === 0 ? 1 : -1),
        });
      }
    });
  }

  drawSpiral(t) {
    if (!this.opts.showSpiral) return;
    const ctx = this.ctx;
    ctx.beginPath();
    ctx.strokeStyle = this.opts.accentColor;
    ctx.globalAlpha = 0.06 * this.opts.opacity / 0.35;
    ctx.lineWidth = 1;
    for (let i = 0; i < 600; i++) {
      const angle = i * 0.05 + t * 0.2;
      const r = Math.pow(PHI, angle / (Math.PI * 2)) * 2;
      if (r > this.maxRadius * 1.2) break;
      const x = this.cx + r * Math.cos(angle);
      const y = this.cy + r * Math.sin(angle);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  drawRings(t) {
    if (!this.opts.showRings) return;
    const ctx = this.ctx;
    const radii = [
      this.maxRadius * PSI * PSI,
      this.maxRadius * PSI,
      this.maxRadius * 0.78,
      this.maxRadius,
    ];
    radii.forEach((r, i) => {
      ctx.beginPath();
      ctx.arc(this.cx, this.cy, r, 0, Math.PI * 2);
      ctx.strokeStyle = this.opts.accentColor;
      ctx.globalAlpha = (0.04 + Math.sin(t + i) * 0.02) * this.opts.opacity / 0.35;
      ctx.lineWidth = 0.5;
      ctx.stroke();
    });
    ctx.globalAlpha = 1;
  }

  getNodePos(node, t) {
    const angle = node.baseAngle + t * node.orbitSpeed * 1000;
    const pulseFactor = 1 + Math.sin(t * 2 + node.pulsePhase) * 0.03;
    const r = node.radius * pulseFactor;
    return {
      x: this.cx + r * Math.cos(angle),
      y: this.cy + r * Math.sin(angle),
    };
  }

  drawConnections(t) {
    if (!this.opts.showConnections) return;
    const ctx = this.ctx;
    const positions = this.nodes.map(n => this.getNodePos(n, t));
    const dist = this.opts.connectionDistance;

    for (let i = 0; i < positions.length; i++) {
      for (let j = i + 1; j < positions.length; j++) {
        const dx = positions[i].x - positions[j].x;
        const dy = positions[i].y - positions[j].y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < dist) {
          const alpha = (1 - d / dist) * 0.15 * this.opts.opacity / 0.35;
          ctx.beginPath();
          ctx.moveTo(positions[i].x, positions[i].y);
          ctx.lineTo(positions[j].x, positions[j].y);
          ctx.strokeStyle = this.opts.accentColor;
          ctx.globalAlpha = alpha;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }

    // Mouse connections
    if (this.mouse.x > 0) {
      positions.forEach((p, i) => {
        const dx = p.x - this.mouse.x;
        const dy = p.y - this.mouse.y;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < dist * 1.5) {
          const alpha = (1 - d / (dist * 1.5)) * 0.3;
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(this.mouse.x, this.mouse.y);
          ctx.strokeStyle = this.opts.goldColor;
          ctx.globalAlpha = alpha;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      });
    }

    ctx.globalAlpha = 1;
  }

  drawNodes(t) {
    if (!this.opts.showNodes) return;
    const ctx = this.ctx;
    this.nodes.forEach(node => {
      const pos = this.getNodePos(node, t);
      const pulse = 1 + Math.sin(t * 3 + node.pulsePhase) * 0.3;
      const size = node.size * pulse;

      // Glow
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, size * 3, 0, Math.PI * 2);
      const grad = ctx.createRadialGradient(pos.x, pos.y, 0, pos.x, pos.y, size * 3);
      grad.addColorStop(0, node.color + '40');
      grad.addColorStop(1, node.color + '00');
      ctx.fillStyle = grad;
      ctx.globalAlpha = 0.6 * this.opts.opacity / 0.35;
      ctx.fill();

      // Core
      ctx.beginPath();
      ctx.arc(pos.x, pos.y, size, 0, Math.PI * 2);
      ctx.fillStyle = node.color;
      ctx.globalAlpha = 0.8 * this.opts.opacity / 0.35;
      ctx.fill();
    });
    ctx.globalAlpha = 1;
  }

  animate() {
    this.time += this.opts.animationSpeed;
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.w, this.h);

    this.drawSpiral(this.time * 1000);
    this.drawRings(this.time * 1000);
    this.drawConnections(this.time * 1000);
    this.drawNodes(this.time * 1000);

    this.animFrame = requestAnimationFrame(() => this.animate());
  }

  destroy() {
    if (this.animFrame) cancelAnimationFrame(this.animFrame);
  }
}

// Export for module or global use
if (typeof window !== 'undefined') {
  window.SacredGeometryCanvas = SacredGeometryCanvas;
}

export { SacredGeometryCanvas, PHI, PSI, GOLDEN_ANGLE, FIB };
