/**
 * HEADY™ Cross-Site Navigation
 * Ecosystem-wide navigation bar injected into all Heady sites.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 *
 * Renders a top banner + dropdown mega-menu linking all 9 Heady domains.
 * Zero ranking — all sites are concurrent equals in the navigation.
 */

const HEADY_SITES = [
  { id: 'headyme', label: 'HeadyMe', url: 'https://headyme.com', desc: 'Personal AI Cloud', accent: '#00d4aa', icon: '◎' },
  { id: 'headysystems', label: 'HeadySystems', url: 'https://headysystems.com', desc: 'Enterprise Infrastructure', accent: '#00d4aa', icon: '⬡' },
  { id: 'heady-ai', label: 'HeadyAI', url: 'https://heady-ai.com', desc: 'Research & Science', accent: '#8b5cf6', icon: '△' },
  { id: 'headyos', label: 'HeadyOS', url: 'https://headyos.com', desc: 'Developer OS', accent: '#14b8a6', icon: '◇' },
  { id: 'headyconnection-org', label: 'HeadyConnection.org', url: 'https://headyconnection.org', desc: 'Non-Profit 501(c)(3)', accent: '#f59e0b', icon: '⊛' },
  { id: 'headyconnection-com', label: 'HeadyConnection.com', url: 'https://headyconnection.com', desc: 'Community Portal', accent: '#06b6d4', icon: '⊕' },
  { id: 'headyex', label: 'HeadyEX', url: 'https://headyex.com', desc: 'Agent Marketplace', accent: '#10b981', icon: '⟁' },
  { id: 'headyfinance', label: 'HeadyFinance', url: 'https://headyfinance.com', desc: 'Investor Relations', accent: '#a855f7', icon: '⬢' },
  { id: 'admin-portal', label: 'Admin Portal', url: 'https://admin.headysystems.com', desc: 'Internal Ops', accent: '#06b6d4', icon: '⊞' },
];

class HeadyCrossNav {
  constructor(options = {}) {
    this.currentSiteId = options.siteId || '';
    this.isOpen = false;
    this.render();
  }

  render() {
    const el = document.createElement('div');
    el.className = 'heady-crossnav';
    el.innerHTML = `
      <div class="heady-crossnav-bar">
        <span class="heady-crossnav-brand">HEADY™ ECOSYSTEM</span>
        <button class="heady-crossnav-toggle" aria-label="Toggle ecosystem navigation">
          <span>Explore All Sites</span>
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.5"><polyline points="2 4 6 8 10 4"/></svg>
        </button>
      </div>
      <div class="heady-crossnav-dropdown">
        <div class="heady-crossnav-grid">
          ${HEADY_SITES.map(s => `
            <a href="${s.url}" class="heady-crossnav-item ${s.id === this.currentSiteId ? 'heady-crossnav-item--current' : ''}" style="--item-accent:${s.accent}" ${s.id === this.currentSiteId ? '' : 'target="_blank" rel="noopener"'}>
              <span class="heady-crossnav-icon">${s.icon}</span>
              <div class="heady-crossnav-meta">
                <span class="heady-crossnav-name">${s.label}</span>
                <span class="heady-crossnav-desc">${s.desc}</span>
              </div>
              ${s.id === this.currentSiteId ? '<span class="heady-crossnav-current-badge">Current</span>' : ''}
            </a>
          `).join('')}
        </div>
      </div>
    `;

    const toggle = el.querySelector('.heady-crossnav-toggle');
    const dropdown = el.querySelector('.heady-crossnav-dropdown');
    toggle.addEventListener('click', () => {
      this.isOpen = !this.isOpen;
      dropdown.classList.toggle('open', this.isOpen);
      toggle.classList.toggle('open', this.isOpen);
    });

    document.body.prepend(el);
    this.injectStyles();
  }

  injectStyles() {
    if (document.getElementById('heady-crossnav-styles')) return;
    const style = document.createElement('style');
    style.id = 'heady-crossnav-styles';
    style.textContent = `
.heady-crossnav{position:fixed;top:0;left:0;right:0;z-index:9999;font-family:'Inter',-apple-system,sans-serif}
.heady-crossnav-bar{display:flex;align-items:center;justify-content:space-between;height:32px;padding:0 21px;background:rgba(6,6,12,.92);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,.04);font-size:11px}
.heady-crossnav-brand{font-family:'JetBrains Mono',monospace;color:rgba(255,255,255,.3);letter-spacing:.15em;font-size:9px;font-weight:600}
.heady-crossnav-toggle{display:flex;align-items:center;gap:6px;background:none;border:none;color:rgba(255,255,255,.5);cursor:pointer;font-size:11px;font-family:inherit;padding:4px 8px;border-radius:4px;transition:all .2s}
.heady-crossnav-toggle:hover{color:#e8e8f0;background:rgba(255,255,255,.05)}
.heady-crossnav-toggle.open svg{transform:rotate(180deg)}
.heady-crossnav-toggle svg{transition:transform .3s}
.heady-crossnav-dropdown{position:absolute;top:32px;left:0;right:0;background:rgba(10,10,20,.95);backdrop-filter:blur(40px);border-bottom:1px solid rgba(255,255,255,.06);padding:21px;display:none;animation:crossnav-slide .3s ease-out}
.heady-crossnav-dropdown.open{display:block}
@keyframes crossnav-slide{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
.heady-crossnav-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:900px;margin:0 auto}
.heady-crossnav-item{display:flex;align-items:center;gap:10px;padding:10px 14px;border-radius:10px;text-decoration:none;border:1px solid transparent;transition:all .25s;color:#e8e8f0}
.heady-crossnav-item:hover{background:rgba(255,255,255,.04);border-color:var(--item-accent,rgba(255,255,255,.08));opacity:1}
.heady-crossnav-item--current{background:rgba(255,255,255,.03);border-color:var(--item-accent)}
.heady-crossnav-icon{font-size:18px;width:34px;height:34px;display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.03);border-radius:8px;color:var(--item-accent)}
.heady-crossnav-meta{display:flex;flex-direction:column;min-width:0}
.heady-crossnav-name{font-weight:600;font-size:12px;white-space:nowrap}
.heady-crossnav-desc{font-size:10px;color:rgba(255,255,255,.4);white-space:nowrap}
.heady-crossnav-current-badge{margin-left:auto;font-size:9px;padding:2px 6px;border-radius:99px;background:var(--item-accent);color:#000;font-weight:600;flex-shrink:0}
@media(max-width:768px){.heady-crossnav-grid{grid-template-columns:1fr 1fr}.heady-crossnav-bar{padding:0 13px}}
@media(max-width:480px){.heady-crossnav-grid{grid-template-columns:1fr}}
    `;
    document.head.appendChild(style);
  }
}

if (typeof window !== 'undefined') {
  window.HeadyCrossNav = HeadyCrossNav;
  window.HEADY_SITES = HEADY_SITES;
}

export { HeadyCrossNav, HEADY_SITES };
