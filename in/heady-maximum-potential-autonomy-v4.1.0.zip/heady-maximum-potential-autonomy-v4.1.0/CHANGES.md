# CHANGES

## v4.1.0 autonomous improvement pass

- added `auth-session-server` with signed session cookies, relay origin verification, anonymous quota controls, and client binding
- added `notification-service` with SSE channels, WebSocket upgrades, push subscription registry, and per-frame session revalidation
- added `analytics-service` with privacy-first event ingestion, funnel summaries, and JSONL durability
- added `billing-service` with phi-scaled plans, internal ledgering, Stripe-compatible webhook signature verification, and customer subscription intents
- added `search-service` with deterministic 384-dimensional embeddings, lexical plus vector hybrid retrieval, and contract schemas
- added `scheduler-service` with phi-scaled interval execution and job inspection endpoints
- added `migration-service` with checksum-based SQL application and rollback state tracking
- added `asset-pipeline` with manifest generation, digests, responsive variants, CDN key planning, and immutable cache metadata
- added `docker-compose.autonomy.yml` with NATS JetStream, PgBouncer, Prometheus, Grafana, Vector, OTEL collector, and the new service set
- added `SECURITY_MODEL.md`, ADRs, runbooks, onboarding, error codes, patent mapping, and validation docs
- added static production pages for pricing, status, API docs, developer portal, and blog/changelog
- added CI workflow, pre-commit hook, architecture SVG, C4 diagrams, and local health matrix tooling
