# IMPROVEMENTS

## Security

- zero-trust session cookies use `__Host-heady_session`, `HttpOnly`, `Secure`, `SameSite=Lax`, origin allowlists, and client binding hashes
- WebSocket frames are authenticated on every client message instead of relying only on the initial upgrade handshake
- strict autonomy guardrails are encoded in config with allowed and forbidden operation classes
- CSP policy, SRI posture, schema validation, audit logging conventions, and request correlation are codified in shared modules and configs

## Scale

- NATS JetStream subjects, dead-letter handling policy, and feature-flag rollout percentages are defined with phi-scaled progression
- PgBouncer, OTEL collector, Prometheus, Vector, and Grafana are wired into the compose topology
- search embeddings are deterministic at 384 dimensions to align with the Heady vector contract

## Developer experience

- setup script validates Node, Docker, gcloud, and env readiness
- architecture SVG, C4 diagrams, CI workflow, and pre-commit hook reduce onboarding friction
- validation scripts provide repeatable local health and audit checks

## Websites

- pricing, API docs, status, blog, and developer portal surfaces are now packaged as production-ready static pages with SEO, accessibility, and attribution built in
