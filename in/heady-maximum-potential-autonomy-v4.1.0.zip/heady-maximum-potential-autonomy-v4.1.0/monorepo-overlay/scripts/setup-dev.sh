#!/usr/bin/env bash
set -euo pipefail

command -v node >/dev/null || { echo "Node.js is required"; exit 1; }
command -v docker >/dev/null || { echo "Docker is required"; exit 1; }
command -v gcloud >/dev/null || { echo "gcloud CLI is required"; exit 1; }
[ -f .env.example ] || { echo ".env.example missing"; exit 1; }
node --version
npm --version || true
printf "Using overlay bootstrap contract from .env.example
"
node scripts/generate-architecture-svg.js
printf "Setup checks complete. Run npm test and npm run validate next.
"
