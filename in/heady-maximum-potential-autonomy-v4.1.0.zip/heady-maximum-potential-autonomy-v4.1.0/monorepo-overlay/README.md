# Monorepo Overlay

This overlay is designed to drop into the Heady monorepo as a governed improvement pass. It adds missing service surfaces, static site pages, infra configs, docs, tests, and local validation scripts without depending on third-party runtime packages.
