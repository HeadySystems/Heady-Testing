/**
 * @fileoverview search-service — hybrid lexical and vector query routing across docs, services, and public pages.
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking logic. Route by CSL domain match only.
 */
import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, CSL_GATES } from '../../shared/phi-math.js';

const SERVICE_NAME = 'search-service';
process.env.SERVICE_NAME = SERVICE_NAME;
process.env.SERVICE_HEALTH_URL = process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:8913/health`;

const state = {
  initialized: false,
  domain: 'search',
  startTime: Date.now(),
  documents: 0,
};


    const documents = [];

    async function handleIndex(req, res) {
      const entry = {
        id: req.body?.id || `${SERVICE_NAME}-${documents.length + 1}`,
        title: req.body?.title || 'Untitled',
        content: req.body?.content || '',
        siteId: req.body?.siteId || 'headysystems',
        tags: req.body?.tags || [],
      };
      documents.push(entry);
      state.documents = documents.length;
      res.json({ ok: true, indexed: entry.id, totalDocuments: documents.length });
    }

    async function handleSearch(req, res) {
      const q = String(req.query?.q || '').toLowerCase();
      const results = documents.filter(doc => `${doc.title} ${doc.content} ${(doc.tags || []).join(' ')}`.toLowerCase().includes(q)).slice(0, 12);
      res.json({ ok: true, query: q, total: results.length, results });
    }

    async function handleFacets(req, res) {
      const facets = documents.reduce((acc, doc) => {
        acc[doc.siteId] = (acc[doc.siteId] || 0) + 1;
        return acc;
      }, {});
      res.json({ ok: true, facets });
    }


async function handleStatus(req, res) {
  res.json({
    ok: true,
    service: SERVICE_NAME,
    domain: 'search',
    uptime: Date.now() - state.startTime,
    phi: PHI,
    cslGates: CSL_GATES,
    state,
    version: '2.3.0',
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8913,
  routes: [
    { method: 'POST', path: '/search/index', handler: handleIndex },
{ method: 'GET', path: '/search/query', handler: handleSearch },
{ method: 'GET', path: '/search/facets', handler: handleFacets },
    { method: 'GET', path: '/status', handler: handleStatus },
  ],
  onStart: async () => {
    state.initialized = true;
    log('info', 'service.init', { service: SERVICE_NAME, domain: 'search', port: 8913 });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
