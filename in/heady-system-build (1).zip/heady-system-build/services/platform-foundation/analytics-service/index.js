/**
 * @fileoverview analytics-service — event intake, session rollups, product metrics slices, and dashboard queries.
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking logic. Route by CSL domain match only.
 */
import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, CSL_GATES } from '../../shared/phi-math.js';

const SERVICE_NAME = 'analytics-service';
process.env.SERVICE_NAME = SERVICE_NAME;
process.env.SERVICE_HEALTH_URL = process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:8911/health`;

const state = {
  initialized: false,
  domain: 'analytics',
  startTime: Date.now(),
  events: 0,
};


    const events = [];

    async function handleIngest(req, res) {
      const payload = req.body || {};
      const event = {
        id: `${SERVICE_NAME}-${events.length + 1}`,
        name: payload.name || 'unnamed-event',
        sessionId: payload.sessionId || req.correlationId,
        siteId: payload.siteId || req.headyContext?.domain || 'unknown',
        timestamp: new Date().toISOString(),
        properties: payload.properties || {},
      };
      events.push(event);
      state.events = events.length;
      emitSpan('analytics.ingest', { eventName: event.name, correlationId: req.correlationId });
      res.json({ ok: true, accepted: true, totalEvents: events.length, event });
    }

    async function handleMetrics(req, res) {
      const siteId = req.query?.siteId;
      const filtered = siteId ? events.filter(event => event.siteId === siteId) : events;
      const byName = filtered.reduce((acc, event) => {
        acc[event.name] = (acc[event.name] || 0) + 1;
        return acc;
      }, {});
      res.json({ ok: true, totalEvents: filtered.length, byName, sample: filtered.slice(-10) });
    }

    async function handleOverview(req, res) {
      const sessions = new Set(events.map(event => event.sessionId));
      res.json({ ok: true, overview: { events: events.length, sessions: sessions.size, servicesObserved: 1 } });
    }


async function handleStatus(req, res) {
  res.json({
    ok: true,
    service: SERVICE_NAME,
    domain: 'analytics',
    uptime: Date.now() - state.startTime,
    phi: PHI,
    cslGates: CSL_GATES,
    state,
    version: '2.3.0',
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8911,
  routes: [
    { method: 'POST', path: '/events/ingest', handler: handleIngest },
{ method: 'GET', path: '/metrics/query', handler: handleMetrics },
{ method: 'GET', path: '/dashboards/overview', handler: handleOverview },
    { method: 'GET', path: '/status', handler: handleStatus },
  ],
  onStart: async () => {
    state.initialized = true;
    log('info', 'service.init', { service: SERVICE_NAME, domain: 'analytics', port: 8911 });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
