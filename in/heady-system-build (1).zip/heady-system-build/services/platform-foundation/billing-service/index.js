/**
 * @fileoverview billing-service — plan catalog, usage metering, invoice previews, and subscription state relay.
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking logic. Route by CSL domain match only.
 */
import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, CSL_GATES } from '../../shared/phi-math.js';

const SERVICE_NAME = 'billing-service';
process.env.SERVICE_NAME = SERVICE_NAME;
process.env.SERVICE_HEALTH_URL = process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:8912/health`;

const state = {
  initialized: false,
  domain: 'billing',
  startTime: Date.now(),
  meters: 0,
};


    const meters = [];
    const plans = [
      { id: 'starter', monthlyUsd: 0, vectorMemoryGb: 1, seats: 1 },
      { id: 'pro', monthlyUsd: 49, vectorMemoryGb: 25, seats: 3 },
      { id: 'sovereign', monthlyUsd: 249, vectorMemoryGb: 250, seats: 20 },
    ];

    async function handlePlans(req, res) {
      res.json({ ok: true, plans });
    }

    async function handleMeter(req, res) {
      const record = {
        id: `${SERVICE_NAME}-${meters.length + 1}`,
        accountId: req.body?.accountId || 'demo-account',
        dimension: req.body?.dimension || 'requests',
        units: Number(req.body?.units || 0),
        timestamp: new Date().toISOString(),
      };
      meters.push(record);
      state.meters = meters.length;
      res.json({ ok: true, record, totalRecords: meters.length });
    }

    async function handlePreview(req, res) {
      const accountId = req.body?.accountId || 'demo-account';
      const usage = meters.filter(item => item.accountId === accountId).reduce((sum, item) => sum + item.units, 0);
      res.json({
        ok: true,
        accountId,
        preview: {
          subtotalUsd: Number((usage * 0.02).toFixed(2)),
          usageUnits: usage,
          generatedAt: new Date().toISOString(),
        },
      });
    }


async function handleStatus(req, res) {
  res.json({
    ok: true,
    service: SERVICE_NAME,
    domain: 'billing',
    uptime: Date.now() - state.startTime,
    phi: PHI,
    cslGates: CSL_GATES,
    state,
    version: '2.3.0',
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8912,
  routes: [
    { method: 'GET', path: '/plans', handler: handlePlans },
{ method: 'POST', path: '/usage/meter', handler: handleMeter },
{ method: 'POST', path: '/invoices/preview', handler: handlePreview },
    { method: 'GET', path: '/status', handler: handleStatus },
  ],
  onStart: async () => {
    state.initialized = true;
    log('info', 'service.init', { service: SERVICE_NAME, domain: 'billing', port: 8912 });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
