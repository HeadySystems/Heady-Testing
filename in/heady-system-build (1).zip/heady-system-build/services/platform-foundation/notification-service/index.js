/**
 * @fileoverview notification-service — notification fan-out, channel preferences, digest batching, and delivery audit trails.
 *
 * MANDATORY: HeadyAutoContext enrichment on every request.
 * NO ranking logic. Route by CSL domain match only.
 */
import { createHeadyService, log, emitSpan } from '../../shared/service-base.js';
import { PHI, CSL_GATES } from '../../shared/phi-math.js';

const SERVICE_NAME = 'notification-service';
process.env.SERVICE_NAME = SERVICE_NAME;
process.env.SERVICE_HEALTH_URL = process.env.SERVICE_HEALTH_URL || `http://${SERVICE_NAME}:8910/health`;

const state = {
  initialized: false,
  domain: 'notifications',
  startTime: Date.now(),
  notifications: 0,
};


    const queue = [];
    const preferences = new Map();

    async function handleSend(req, res) {
      const payload = req.body || {};
      const delivery = {
        id: `${SERVICE_NAME}-${queue.length + 1}`,
        userId: payload.userId || 'anonymous',
        channel: payload.channel || 'in-app',
        message: payload.message || 'No message provided',
        scheduledFor: payload.scheduledFor || null,
        createdAt: new Date().toISOString(),
      };
      queue.push(delivery);
      state.notifications = queue.length;
      emitSpan('notifications.send', { channel: delivery.channel, correlationId: req.correlationId });
      res.json({ ok: true, delivery, queued: queue.length });
    }

    async function handlePreferences(req, res) {
      const userId = req.query?.userId || 'anonymous';
      const current = preferences.get(userId) || { inApp: true, email: true, digest: 'daily' };
      res.json({ ok: true, userId, preferences: current });
    }

    async function handlePreferencesUpdate(req, res) {
      const userId = req.body?.userId || 'anonymous';
      const current = {
        inApp: req.body?.inApp ?? true,
        email: req.body?.email ?? true,
        digest: req.body?.digest || 'daily',
      };
      preferences.set(userId, current);
      res.json({ ok: true, userId, preferences: current });
    }

    async function handleQueue(req, res) {
      res.json({ ok: true, queued: queue.length, items: queue.slice(-12) });
    }


async function handleStatus(req, res) {
  res.json({
    ok: true,
    service: SERVICE_NAME,
    domain: 'notifications',
    uptime: Date.now() - state.startTime,
    phi: PHI,
    cslGates: CSL_GATES,
    state,
    version: '2.3.0',
  });
}

const { start, stop } = createHeadyService({
  name: SERVICE_NAME,
  port: 8910,
  routes: [
    { method: 'POST', path: '/notifications/send', handler: handleSend },
{ method: 'GET', path: '/notifications/preferences', handler: handlePreferences },
{ method: 'POST', path: '/notifications/preferences', handler: handlePreferencesUpdate },
{ method: 'GET', path: '/notifications/queue', handler: handleQueue },
    { method: 'GET', path: '/status', handler: handleStatus },
  ],
  onStart: async () => {
    state.initialized = true;
    log('info', 'service.init', { service: SERVICE_NAME, domain: 'notifications', port: 8910 });
  },
  onShutdown: async () => {
    state.initialized = false;
    log('info', 'service.shutdown', { service: SERVICE_NAME });
  },
});

start().catch(err => {
  log('error', 'service.start.failed', { service: SERVICE_NAME, error: err.message });
  process.exit(1);
});

export { start, stop };
