terraform {
  required_version = ">= 1.8.0"
}

provider "google" {
  project = var.project_id
  region  = var.region
}

resource "google_project_service" "cloud_run" {
  service = "run.googleapis.com"
}
