import React from 'react';

export interface ShellCard {
  title: string;
  description: string;
  href: string;
}

export interface ShellConfig {
  brand: string;
  subtitle: string;
  cards: ShellCard[];
}

export function createShellConfig(brand: string, subtitle: string, cards: ShellCard[]): ShellConfig {
  return { brand, subtitle, cards };
}

export function ShellPage({ config }: { config: ShellConfig }) {
  return (
    <main style={{ fontFamily: 'Inter, system-ui, sans-serif', padding: 32, background: '#070B14', color: '#F5F7FA', minHeight: '100vh' }}>
      <h1>{config.brand}</h1>
      <p>{config.subtitle}</p>
      <section style={{ display: 'grid', gap: 16, gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))' }}>
        {config.cards.map((card) => (
          <a key={card.href} href={card.href} style={{ border: '1px solid #263247', borderRadius: 16, padding: 16, color: 'inherit', textDecoration: 'none' }}>
            <h2 style={{ marginTop: 0 }}>{card.title}</h2>
            <p>{card.description}</p>
          </a>
        ))}
      </section>
    </main>
  );
}
