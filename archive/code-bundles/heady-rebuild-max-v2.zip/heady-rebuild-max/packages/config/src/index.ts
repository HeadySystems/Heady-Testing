import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import YAML from 'yaml';

export function loadYamlFile<T>(filePath: string): T {
  const absolute = resolve(process.cwd(), filePath);
  return YAML.parse(readFileSync(absolute, 'utf8')) as T;
}
