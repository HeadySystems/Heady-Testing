import { z } from 'zod';

export const ServiceHealthSchema = z.object({
  ok: z.boolean(),
  service: z.string(),
  timestamp: z.string().optional(),
});

export const WorkflowPlanSchema = z.object({
  profile: z.string(),
  objective: z.string(),
  stages: z.array(z.string()),
  lane: z.enum(['interactive', 'background', 'critical']).default('interactive'),
});

export type ServiceHealth = z.infer<typeof ServiceHealthSchema>;
export type WorkflowPlan = z.infer<typeof WorkflowPlanSchema>;
