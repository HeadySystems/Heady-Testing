export interface CircuitState {
  failures: number;
  threshold: number;
  open: boolean;
}

export function nextCircuitState(state: CircuitState, ok: boolean): CircuitState {
  if (ok) {
    return { ...state, failures: 0, open: false };
  }
  const failures = state.failures + 1;
  return { ...state, failures, open: failures >= state.threshold };
}
