export interface VectorPoint {
  id: string;
  namespace: string;
  coordinates: [number, number, number];
  embedding: number[];
  summary: string;
}

export class InMemoryVectorStore {
  private readonly points = new Map<string, VectorPoint>();

  upsert(point: VectorPoint): void {
    this.points.set(point.id, point);
  }

  list(namespace?: string): VectorPoint[] {
    return [...this.points.values()].filter((point) => !namespace || point.namespace === namespace);
  }
}
