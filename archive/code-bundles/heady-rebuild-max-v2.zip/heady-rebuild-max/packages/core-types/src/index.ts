export type HeadyLayer = 'edge' | 'gateway' | 'orchestration' | 'intelligence' | 'memory' | 'persistence';

export interface HeadyServiceDefinition {
  id: string;
  layer: HeadyLayer;
  port: number;
  description: string;
}

export interface HeadyProfile {
  id: string;
  label: string;
  defaultDomain: string;
  memoryNamespace: string;
}

export interface WorkflowRequest {
  id: string;
  profile: string;
  objective: string;
  priority: 'interactive' | 'background' | 'critical';
}
