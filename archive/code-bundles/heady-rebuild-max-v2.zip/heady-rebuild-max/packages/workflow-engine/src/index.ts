import type { WorkflowRequest } from '@heady/core-types';

export interface PlannedStage {
  id: string;
  service: string;
  reason: string;
}

export interface PlannedWorkflow {
  request: WorkflowRequest;
  stages: PlannedStage[];
}

export function planWorkflow(request: WorkflowRequest): PlannedWorkflow {
  const shared = [
    { id: 'intake', service: 'gateway-api', reason: 'normalize request and profile context' },
    { id: 'plan', service: 'conductor', reason: 'build the execution graph' },
    { id: 'memory', service: 'memory-service', reason: 'persist relevant durable context' },
  ];

  const tail = request.priority === 'background'
    ? [{ id: 'background', service: 'worker-fabric', reason: 'execute queued background work' }]
    : [{ id: 'respond', service: 'buddy-service', reason: 'deliver a user-facing outcome' }];

  return {
    request,
    stages: [...shared, ...tail],
  };
}
