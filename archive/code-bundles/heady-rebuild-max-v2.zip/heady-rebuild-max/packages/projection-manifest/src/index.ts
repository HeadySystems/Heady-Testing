export interface ProjectionTarget {
  repo: string;
  sourceAppOrService: string;
  domain: string;
  purpose: string;
}

export function buildProjectionTargets(): ProjectionTarget[] {
  return [
    { repo: 'headyme-core', sourceAppOrService: 'apps/headyme-web', domain: 'headyme.com', purpose: 'personal cloud command center' },
    { repo: 'headyos-core', sourceAppOrService: 'services/conductor', domain: 'headyai.com', purpose: 'latent OS kernel and orchestration contracts' },
    { repo: 'headymcp-core', sourceAppOrService: 'services/mcp-gateway', domain: 'headymcp.com', purpose: 'MCP control plane and tool contracts' },
    { repo: 'headysystems-core', sourceAppOrService: 'apps/headysystems-web', domain: 'headysystems.com', purpose: 'systems platform surface' },
    { repo: 'headyapi-core', sourceAppOrService: 'services/gateway-api', domain: 'headyapi.com', purpose: 'public API and routing contracts' },
    { repo: 'headyconnection-core', sourceAppOrService: 'apps/headyconnection-web', domain: 'headyconnection.org', purpose: 'community and nonprofit workspace' },
    { repo: 'headybuddy-core', sourceAppOrService: 'apps/headybuddy-web', domain: 'headybuddy.org', purpose: 'companion experience' },
  ];
}
