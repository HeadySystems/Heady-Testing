export interface SacredNode {
  id: string;
  x: number;
  y: number;
  z: number;
}

export function buildMetatronRing(count = 13): SacredNode[] {
  return Array.from({ length: count }, (_, index) => ({
    id: `node-${index + 1}`,
    x: Number(Math.cos((Math.PI * 2 * index) / count).toFixed(4)),
    y: Number(Math.sin((Math.PI * 2 * index) / count).toFixed(4)),
    z: Number((((index % 3) - 1) * 0.618).toFixed(4)),
  }));
}
