import { EventEmitter } from 'node:events';

export const headyBus = new EventEmitter();

export function publish(event: string, payload: unknown): void {
  headyBus.emit(event, payload);
}

export function subscribe(event: string, handler: (payload: unknown) => void): void {
  headyBus.on(event, handler);
}
