import React from 'react';
import { createShellConfig, ShellPage } from '@heady/ui-shell';

const config = createShellConfig(
  'Heady Admin',
  'Mission control across domains, services, and memory.',
  [
    { title: 'Services', description: 'Services surface for Heady Admin.', href: '/services' },
    { title: 'Projections', description: 'Projections surface for Heady Admin.', href: '/projections' },
    { title: 'Telemetry', description: 'Telemetry surface for Heady Admin.', href: '/telemetry' }
  ]
);

export default function App() {
  return <ShellPage config={config} />;
}
