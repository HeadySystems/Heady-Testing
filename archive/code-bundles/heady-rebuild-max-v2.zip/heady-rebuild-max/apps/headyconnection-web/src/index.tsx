import React from 'react';
import { createShellConfig, ShellPage } from '@heady/ui-shell';

const config = createShellConfig(
  'HeadyConnection',
  'Community, nonprofit, and collaboration layer.',
  [
    { title: 'Programs', description: 'Programs surface for HeadyConnection.', href: '/programs' },
    { title: 'Partners', description: 'Partners surface for HeadyConnection.', href: '/partners' },
    { title: 'Impact', description: 'Impact surface for HeadyConnection.', href: '/impact' }
  ]
);

export default function App() {
  return <ShellPage config={config} />;
}
