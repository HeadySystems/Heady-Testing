import React from 'react';
import { createShellConfig, ShellPage } from '@heady/ui-shell';

const config = createShellConfig(
  'HeadyBuddy',
  'Persistent companion experience.',
  [
    { title: 'Chat', description: 'Chat surface for HeadyBuddy.', href: '/chat' },
    { title: 'Memory', description: 'Memory surface for HeadyBuddy.', href: '/memory' },
    { title: 'Preferences', description: 'Preferences surface for HeadyBuddy.', href: '/preferences' }
  ]
);

export default function App() {
  return <ShellPage config={config} />;
}
