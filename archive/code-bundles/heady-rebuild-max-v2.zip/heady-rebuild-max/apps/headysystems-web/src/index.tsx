import React from 'react';
import { createShellConfig, ShellPage } from '@heady/ui-shell';

const config = createShellConfig(
  'HeadySystems',
  'Core platform, infrastructure, and orchestration.',
  [
    { title: 'Gateway', description: 'Gateway surface for HeadySystems.', href: '/api' },
    { title: 'Conductor', description: 'Conductor surface for HeadySystems.', href: '/conductor' },
    { title: 'Registry', description: 'Registry surface for HeadySystems.', href: '/registry' }
  ]
);

export default function App() {
  return <ShellPage config={config} />;
}
