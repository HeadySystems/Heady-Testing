import React from 'react';
import { createShellConfig, ShellPage } from '@heady/ui-shell';

const config = createShellConfig(
  'HeadyMe',
  'Your personal cloud command center.',
  [
    { title: 'Memory', description: 'Memory surface for HeadyMe.', href: '/memory' },
    { title: 'Buddy', description: 'Buddy surface for HeadyMe.', href: '/buddy' },
    { title: 'Admin', description: 'Admin surface for HeadyMe.', href: 'https://headyio.com' }
  ]
);

export default function App() {
  return <ShellPage config={config} />;
}
