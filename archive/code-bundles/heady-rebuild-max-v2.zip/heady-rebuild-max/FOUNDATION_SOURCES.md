# Foundation sources

Primary source repositories and documents used for this rebuild:

- [HeadyMe organization](https://github.com/HeadyMe)
- [Heady documentation hub](https://github.com/HeadyMe/heady-docs)
- [Heady architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md)
- [Heady pre-production monorepo](https://github.com/HeadyMe/Heady-pre-production-9f2f0642)
- [Heady pre-production thin orchestrator](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/heady-manager.js)
- [Heady registry](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/heady-registry.json)
- [Latent OS blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/strategic/latent-os-blueprint.md)
- [Buddy orchestrator blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/strategic/architectural-blueprint-buddy-orchestrator.md)
- [Cloud-first pipeline source](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/configs/infrastructure/cloud/cloud-first-pipeline.yaml)
- [headyme-core README](https://github.com/HeadyMe/headyme-core/blob/main/README.md)
- [headyos-core README](https://github.com/HeadyMe/headyos-core/blob/main/README.md)
- [headymcp-core README](https://github.com/HeadyMe/headymcp-core/blob/main/README.md)
- [headysystems-core README](https://github.com/HeadyMe/headysystems-core/blob/main/README.md)
- [headyapi-core README](https://github.com/HeadyMe/headyapi-core/blob/main/README.md)
- [headyconnection-core README](https://github.com/HeadyMe/headyconnection-core/blob/main/README.md)
- [headybuddy-core README](https://github.com/HeadyMe/headybuddy-core/blob/main/README.md)
