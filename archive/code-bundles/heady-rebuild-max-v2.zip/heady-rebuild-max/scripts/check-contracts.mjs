import { readFileSync } from 'node:fs';

const files = [
  '../configs/contracts/service-contracts.json',
  '../configs/contracts/memory-contract.json',
  '../configs/contracts/projection-contract.json',
];

for (const relative of files) {
  JSON.parse(readFileSync(new URL(relative, import.meta.url), 'utf8'));
}

console.log(JSON.stringify({ ok: true, checked: files.length }, null, 2));
