import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const registry = JSON.parse(readFileSync(new URL('../configs/registry/heady-registry.json', import.meta.url), 'utf8'));
const projectionContract = JSON.parse(readFileSync(new URL('../configs/contracts/projection-contract.json', import.meta.url), 'utf8'));
const serviceContracts = JSON.parse(readFileSync(new URL('../configs/contracts/service-contracts.json', import.meta.url), 'utf8'));

const targets = [
  { repo: 'headyme-core', source: 'apps/headyme-web', domain: 'headyme.com', purpose: 'personal cloud command center' },
  { repo: 'headyos-core', source: 'services/conductor', domain: 'headyai.com', purpose: 'latent OS kernel and orchestration contracts' },
  { repo: 'headymcp-core', source: 'services/mcp-gateway', domain: 'headymcp.com', purpose: 'MCP control plane and tool contracts' },
  { repo: 'headysystems-core', source: 'apps/headysystems-web', domain: 'headysystems.com', purpose: 'systems platform surface' },
  { repo: 'headyapi-core', source: 'services/gateway-api', domain: 'headyapi.com', purpose: 'public API and routing contracts' },
  { repo: 'headyconnection-core', source: 'apps/headyconnection-web', domain: 'headyconnection.org', purpose: 'community and nonprofit workspace' },
  { repo: 'headybuddy-core', source: 'apps/headybuddy-web', domain: 'headybuddy.org', purpose: 'companion experience' },
];

const outDir = new URL('../dist/projections/', import.meta.url);
mkdirSync(outDir, { recursive: true });

for (const target of targets) {
  const repoDir = join(outDir.pathname, target.repo);
  mkdirSync(repoDir, { recursive: true });

  const readme = `# ${target.repo}

Generated from the Heady rebuild monorepo.

- Source: ${target.source}
- Domain: ${target.domain}
- Purpose: ${target.purpose}
`;
  const manifest = {
    repo: target.repo,
    source: target.source,
    domain: target.domain,
    purpose: target.purpose,
    generatedFrom: 'heady-rebuild-max',
    requiredFiles: projectionContract.requiredFiles,
  };
  const pkg = {
    name: target.repo,
    private: true,
    version: '0.1.0-projected',
    description: `Projected output for ${target.repo}`,
  };
  const sourceMap = `# Source map

This repo projects from \`${target.source}\` for domain \`${target.domain}\`.

Service contract keys: ${Object.keys(serviceContracts.services).join(', ')}
`;

  writeFileSync(join(repoDir, 'README.md'), readme);
  writeFileSync(join(repoDir, 'PROJECTION_MANIFEST.json'), JSON.stringify(manifest, null, 2));
  writeFileSync(join(repoDir, 'package.json'), JSON.stringify(pkg, null, 2));
  writeFileSync(join(repoDir, 'SOURCE_MAP.md'), sourceMap);
}

writeFileSync(join(outDir.pathname, 'projection-index.json'), JSON.stringify({
  repos: targets.map((target) => target.repo),
  services: Object.keys(registry.services),
}, null, 2));

console.log(`Projected ${targets.length} repos`);
