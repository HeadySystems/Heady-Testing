import { readFileSync } from 'node:fs';

const registry = JSON.parse(readFileSync(new URL('../configs/registry/heady-registry.json', import.meta.url), 'utf8'));
if (!registry.services || !registry.domains) {
  throw new Error('Registry must include services and domains');
}
console.log(JSON.stringify({ ok: true, services: Object.keys(registry.services).length, domains: Object.keys(registry.domains).length }, null, 2));
