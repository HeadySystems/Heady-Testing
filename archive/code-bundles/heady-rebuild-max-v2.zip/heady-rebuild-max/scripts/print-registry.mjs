import { readFileSync } from 'node:fs';

const registry = JSON.parse(readFileSync(new URL('../configs/registry/heady-registry.json', import.meta.url), 'utf8'));
console.log(JSON.stringify(registry, null, 2));
