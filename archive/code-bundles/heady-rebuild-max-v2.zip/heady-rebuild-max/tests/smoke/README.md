# Smoke tests

Use this folder for deployment-time probes that confirm gateway, conductor, memory, MCP, and buddy health endpoints before promotions.
