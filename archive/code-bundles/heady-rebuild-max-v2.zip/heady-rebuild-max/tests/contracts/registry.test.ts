import { describe, expect, it } from 'vitest';
import registry from '../../configs/registry/heady-registry.json' with { type: 'json' };

describe('heady registry', () => {
  it('defines domains and services', () => {
    expect(Object.keys(registry.domains).length).toBeGreaterThan(3);
    expect(Object.keys(registry.services).length).toBeGreaterThan(5);
  });
});
