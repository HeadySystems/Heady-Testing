import Fastify from 'fastify';
import registry from '../../../configs/registry/heady-registry.json' with { type: 'json' };
import { publish } from '@heady/event-bus';
import { InMemoryVectorStore, type VectorPoint } from '@heady/vector-memory';

const app = Fastify({ logger: true });
const store = new InMemoryVectorStore();

app.get('/health', async () => ({ ok: true, service: 'memory-service' }));
app.get('/', async () => ({
  id: 'memory-service',
  summary: 'Persistent and ephemeral vector memory entry point.',
  port: 4030,
}));

app.get('/memory', async (request) => {
  const namespace = (request.query as { namespace?: string } | undefined)?.namespace;
  return {
    namespaces: Object.keys(registry.domains),
    points: store.list(namespace),
  };
});

app.post('/memory', async (request) => {
  const point = request.body as VectorPoint;
  store.upsert(point);
  publish('memory.upserted', point);
  return { ok: true, count: store.list(point.namespace).length };
});

app.post('/consolidate', async () => ({
  ok: true,
  consolidated: store.list().length,
  mode: 'durable-summary',
}));

const port = Number(process.env.PORT || 4030);
app.listen({ port, host: '0.0.0.0' }).catch((error) => {
  app.log.error(error);
  process.exit(1);
});
