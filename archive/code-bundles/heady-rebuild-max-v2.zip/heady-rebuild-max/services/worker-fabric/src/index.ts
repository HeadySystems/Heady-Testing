import Fastify from 'fastify';
import registry from '../../../configs/registry/heady-registry.json' with { type: 'json' };

const app = Fastify({ logger: true });

app.get('/health', async () => ({ ok: true, service: 'worker-fabric' }));
app.get('/', async () => ({
  id: 'worker-fabric',
  summary: 'Background workflows, queues, and self-healing workers.',
  port: 4070,
}));

app.get('/workers', async () => ({
  profiles: ['projection', 'memory', 'telemetry'],
  workers: [
    { id: 'projection-pruner', state: 'ready' },
    { id: 'memory-consolidator', state: 'ready' },
    { id: 'telemetry-summarizer', state: 'ready' },
  ],
  services: Object.keys(registry.services),
}));

app.post('/jobs', async (request) => ({
  ok: true,
  accepted: true,
  job: request.body ?? {},
}));

const port = Number(process.env.PORT || 4070);
app.listen({ port, host: '0.0.0.0' }).catch((error) => {
  app.log.error(error);
  process.exit(1);
});
