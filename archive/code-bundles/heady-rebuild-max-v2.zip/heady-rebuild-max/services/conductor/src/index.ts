import Fastify from 'fastify';
import registry from '../../../configs/registry/heady-registry.json' with { type: 'json' };
import { publish } from '@heady/event-bus';
import { planWorkflow } from '@heady/workflow-engine';
import type { WorkflowRequest } from '@heady/core-types';

const app = Fastify({ logger: true });

app.get('/health', async () => ({ ok: true, service: 'conductor' }));
app.get('/', async () => ({
  id: 'conductor',
  summary: 'Thin orchestration shell for workflow planning and service routing.',
  port: 4020,
}));

app.post('/plan', async (request) => {
  const body = (request.body ?? {}) as Partial<WorkflowRequest>;
  const workflow: WorkflowRequest = {
    id: body.id ?? `wf-${Date.now()}`,
    profile: body.profile ?? 'personal',
    objective: body.objective ?? 'unspecified',
    priority: body.priority ?? 'interactive',
  };
  const plan = planWorkflow(workflow);
  publish('workflow.requested', plan);
  return {
    registryServices: Object.keys(registry.services),
    ...plan,
  };
});

app.get('/routing-table', async () => ({
  hot: ['gateway-api', 'conductor', 'buddy-service'],
  warm: ['memory-service', 'mcp-gateway'],
  cold: ['projection-service', 'worker-fabric'],
}));

const port = Number(process.env.PORT || 4020);
app.listen({ port, host: '0.0.0.0' }).catch((error) => {
  app.log.error(error);
  process.exit(1);
});
