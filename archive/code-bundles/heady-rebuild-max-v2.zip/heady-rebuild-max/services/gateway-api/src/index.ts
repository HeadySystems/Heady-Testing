import Fastify from 'fastify';
import registry from '../../../configs/registry/heady-registry.json' with { type: 'json' };
import { publish } from '@heady/event-bus';

const app = Fastify({ logger: true });

app.get('/health', async () => ({ ok: true, service: 'gateway-api' }));
app.get('/', async () => ({
  id: 'gateway-api',
  summary: 'Public ingress, auth context, rate limits, and domain dispatch.',
  port: 4010,
}));


app.get('/routes', async () => ({
  domains: Object.keys(registry.domains),
  upstreams: Object.keys(registry.services),
}));


const port = Number(process.env.PORT || 4010);
app.listen({ port, host: '0.0.0.0' }).catch((error) => {
  app.log.error(error);
  process.exit(1);
});
