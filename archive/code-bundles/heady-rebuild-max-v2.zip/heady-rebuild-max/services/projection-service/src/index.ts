import Fastify from 'fastify';
import registry from '../../../configs/registry/heady-registry.json' with { type: 'json' };
import { buildProjectionTargets } from '@heady/projection-manifest';

const app = Fastify({ logger: true });

app.get('/health', async () => ({ ok: true, service: 'projection-service' }));
app.get('/', async () => ({
  id: 'projection-service',
  summary: 'Projection builder for public vertical repos and deploy artifacts.',
  port: 4060,
}));

app.get('/targets', async () => ({ projections: registry.projections.publicRepos, manifests: buildProjectionTargets() }));
app.post('/project', async () => ({
  ok: true,
  projected: buildProjectionTargets().map((target) => target.repo),
}));

const port = Number(process.env.PORT || 4060);
app.listen({ port, host: '0.0.0.0' }).catch((error) => {
  app.log.error(error);
  process.exit(1);
});
