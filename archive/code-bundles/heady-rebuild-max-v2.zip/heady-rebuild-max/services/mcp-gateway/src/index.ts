import Fastify from 'fastify';
import registry from '../../../configs/registry/heady-registry.json' with { type: 'json' };

const app = Fastify({ logger: true });

app.get('/health', async () => ({ ok: true, service: 'mcp-gateway' }));
app.get('/', async () => ({
  id: 'mcp-gateway',
  summary: 'Tool and connector metadata plane for HeadyMCP.',
  port: 4040,
}));

app.get('/tools', async () => ({
  domains: Object.keys(registry.domains),
  tools: [
    { id: 'memory.search', layer: 'memory', owner: 'memory-service' },
    { id: 'projection.generate', layer: 'orchestration', owner: 'projection-service' },
    { id: 'buddy.chat', layer: 'intelligence', owner: 'buddy-service' },
    { id: 'workflow.plan', layer: 'orchestration', owner: 'conductor' },
  ],
}));

app.get('/connectors', async () => ({
  connectors: ['github', 'notion', 'slack', 'gmail', 'cloudflare', 'google-cloud'],
}));

const port = Number(process.env.PORT || 4040);
app.listen({ port, host: '0.0.0.0' }).catch((error) => {
  app.log.error(error);
  process.exit(1);
});
