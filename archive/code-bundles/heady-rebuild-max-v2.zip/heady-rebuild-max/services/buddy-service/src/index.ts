import Fastify from 'fastify';
import registry from '../../../configs/registry/heady-registry.json' with { type: 'json' };

const app = Fastify({ logger: true });

app.get('/health', async () => ({ ok: true, service: 'buddy-service' }));
app.get('/', async () => ({
  id: 'buddy-service',
  summary: 'Persistent companion workflows and memory-aware chat service.',
  port: 4050,
}));

app.post('/chat', async (request) => {
  const body = request.body as { message?: string; profile?: string; memoryNamespace?: string };
  const profile = body.profile ?? 'personal';
  return {
    reply: `HeadyBuddy received: ${body.message ?? 'empty message'}`,
    profile,
    memoryNamespace: body.memoryNamespace ?? `${profile}-default`,
    routedDomains: Object.keys(registry.domains),
  };
});

app.get('/personas', async () => ({
  personas: ['eric-companion', 'community-guide', 'systems-operator'],
}));

const port = Number(process.env.PORT || 4050);
app.listen({ port, host: '0.0.0.0' }).catch((error) => {
  app.log.error(error);
  process.exit(1);
});
