/**
 * Heady Conductor Service — Cloud Run HTTP API
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 *
 * The main orchestration endpoint for the Heady ecosystem.
 * Exposes HCFullPipeline execution, task routing, swarm status,
 * engine orchestration, and health probes.
 *
 * Uses Node.js built-in http (zero dependencies for Cloud Run cold start).
 * All constants from canonical phi-math v4.1.0.
 */

import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';

import {
  PHI, PSI, PHI2, PHI3, FIB, fib,
  CSL_THRESHOLDS, RESOURCE_WEIGHTS, SIZING,
  phiFusionWeights, phiBackoff, phiTokenBudgets,
  cosineSimilarity, cslAND, cslCONSENSUS,
  PRESSURE_LEVELS, ALERT_THRESHOLDS,
} from '../shared/phi-math.js';

import {
  detectDrift, DRIFT_STATE, MoERouter, cslGATE,
} from '../shared/csl-engine.js';

// ── Configuration ───────────────────────────────────────────────

const PORT = parseInt(process.env.PORT ?? '8080', 10);
const NODE_ENV = process.env.NODE_ENV ?? 'development';

// ── Pool Allocations (phi-weighted) ─────────────────────────────

const POOLS = Object.freeze({
  hot:        { weight: RESOURCE_WEIGHTS.hot,        timeout: fib(9) * 1000 },   // 34s
  warm:       { weight: RESOURCE_WEIGHTS.warm,       timeout: fib(11) * 1000 },  // 89s
  cold:       { weight: RESOURCE_WEIGHTS.cold,       timeout: fib(12) * 1000 },  // 144s
  reserve:    { weight: RESOURCE_WEIGHTS.reserve,    timeout: fib(10) * 1000 },  // 55s
  governance: { weight: RESOURCE_WEIGHTS.governance, timeout: fib(8) * 1000 },   // 21s
});

// ── HCFullPipeline Stages ───────────────────────────────────────

const HCFP_STAGES = Object.freeze([
  { id: 'context_assembly',   pool: 'hot',   description: 'Gather all relevant context via HeadyBrains' },
  { id: 'intent_classify',    pool: 'hot',   description: 'Conductor classifies task type + urgency' },
  { id: 'node_selection',     pool: 'hot',   description: 'CSL-based routing picks optimal nodes' },
  { id: 'execution',          pool: 'hot',   description: 'Parallel or sequential node activation' },
  { id: 'quality_gate',       pool: 'governance', description: 'HeadyCheck validates output' },
  { id: 'assurance_gate',     pool: 'governance', description: 'HeadyAssure certifies for deployment' },
  { id: 'pattern_capture',    pool: 'warm',  description: 'HeadyPatterns logs workflow for learning' },
  { id: 'story_update',       pool: 'cold',  description: 'HeadyAutobiographer records narrative' },
]);

// ── Task Domain Classification ──────────────────────────────────

const DOMAIN_KEYWORDS = Object.freeze({
  code:       ['code', 'implement', 'build', 'fix', 'debug', 'refactor', 'compile'],
  security:   ['security', 'vulnerability', 'audit', 'risk', 'encrypt', 'auth'],
  research:   ['research', 'find', 'search', 'investigate', 'discover', 'explore'],
  creative:   ['create', 'design', 'generate', 'write', 'compose', 'style'],
  analysis:   ['analyze', 'compare', 'evaluate', 'assess', 'measure', 'benchmark'],
  operations: ['deploy', 'monitor', 'scale', 'maintain', 'configure', 'migrate'],
});

const DOMAIN_POOL_MAP = Object.freeze({
  code:       'hot',
  security:   'hot',
  research:   'warm',
  creative:   'warm',
  analysis:   'cold',
  operations: 'cold',
});

function classifyTask(text) {
  const lower = text.toLowerCase();
  let bestDomain = 'operations';
  let bestScore = 0;

  for (const [domain, keywords] of Object.entries(DOMAIN_KEYWORDS)) {
    const matches = keywords.filter(k => lower.includes(k)).length;
    const score = matches / keywords.length;
    if (score > bestScore) {
      bestScore = score;
      bestDomain = domain;
    }
  }

  return {
    domain: bestDomain,
    pool: DOMAIN_POOL_MAP[bestDomain] ?? 'warm',
    confidence: bestScore > 0 ? Math.min(bestScore * PHI, 1.0) : PSI,
  };
}

// ── Pipeline Execution ──────────────────────────────────────────

const activePipelines = new Map();
const completedPipelines = [];
const MAX_HISTORY = SIZING.RERANK_TOP_K;  // fib(8) = 21

async function executePipeline(task) {
  const pipelineId = `hcfp-${randomUUID().slice(0, 8)}`;
  const classification = classifyTask(task.text ?? task.objective ?? '');
  const startedAt = Date.now();

  const state = {
    id: pipelineId,
    task,
    classification,
    stages: {},
    status: 'running',
    startedAt,
  };
  activePipelines.set(pipelineId, state);

  for (const stage of HCFP_STAGES) {
    const stageStart = Date.now();
    const timeout = POOLS[stage.pool]?.timeout ?? fib(10) * 1000;

    try {
      const result = await Promise.race([
        executeStage(stage, state),
        new Promise((_, rej) => setTimeout(() => rej(new Error(`Stage ${stage.id} timed out`)), timeout)),
      ]);

      state.stages[stage.id] = {
        status: 'completed',
        duration: Date.now() - stageStart,
        result,
      };
    } catch (err) {
      state.stages[stage.id] = {
        status: 'failed',
        duration: Date.now() - stageStart,
        error: err.message,
      };
      state.status = 'failed';
      state.failedAt = stage.id;
      break;
    }
  }

  if (state.status === 'running') state.status = 'completed';
  state.completedAt = Date.now();
  state.duration = state.completedAt - state.startedAt;

  activePipelines.delete(pipelineId);
  completedPipelines.push({ id: pipelineId, status: state.status, duration: state.duration, classification });
  if (completedPipelines.length > MAX_HISTORY) completedPipelines.shift();

  return state;
}

async function executeStage(stage, pipelineState) {
  // Each stage returns structured result (extensible per stage)
  switch (stage.id) {
    case 'context_assembly':
      return { context: `Assembled for: ${pipelineState.task.text?.slice(0, 100) ?? 'unknown'}` };
    case 'intent_classify':
      return pipelineState.classification;
    case 'node_selection':
      return { nodes: [`heady-${pipelineState.classification.domain}-primary`], pool: pipelineState.classification.pool };
    case 'execution':
      return { output: 'Executed via selected nodes', pool: pipelineState.classification.pool };
    case 'quality_gate':
      return { passed: true, score: CSL_THRESHOLDS.MEDIUM };
    case 'assurance_gate':
      return { assured: true, confidence: CSL_THRESHOLDS.LOW };
    case 'pattern_capture':
      return { captured: true, patterns: 1 };
    case 'story_update':
      return { recorded: true };
    default:
      return {};
  }
}

// ── System Status ───────────────────────────────────────────────

function getSystemStatus() {
  return {
    status: 'healthy',
    version: '4.1.0',
    environment: NODE_ENV,
    uptime: Math.round(process.uptime()),
    memory: {
      rss: Math.round(process.memoryUsage().rss / 1024 / 1024),
      heap: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
    },
    pipelines: {
      active: activePipelines.size,
      completed: completedPipelines.length,
      history: completedPipelines.slice(-fib(5)),
    },
    pools: POOLS,
    stages: HCFP_STAGES.map(s => s.id),
    phi: { PHI, PSI, PHI2, PHI3 },
    thresholds: CSL_THRESHOLDS,
    sizing: SIZING,
    tokenBudgets: phiTokenBudgets(),
    timestamp: new Date().toISOString(),
  };
}

// ── HTTP Router ─────────────────────────────────────────────────

function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString()));
      } catch {
        resolve({});
      }
    });
    req.on('error', reject);
  });
}

function json(res, status, data) {
  const body = JSON.stringify(data, null, 2);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'X-Heady-Version': '4.1.0',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'SAMEORIGIN',
  });
  res.end(body);
}

async function handleRequest(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.pathname;
  const method = req.method;

  // Health check (Cloud Run requirement)
  if (path === '/health' || path === '/_health') {
    return json(res, 200, {
      status: 'healthy',
      service: 'heady-conductor',
      version: '4.1.0',
      uptime: Math.round(process.uptime()),
      timestamp: new Date().toISOString(),
    });
  }

  // System status
  if (path === '/status' && method === 'GET') {
    return json(res, 200, getSystemStatus());
  }

  // Execute pipeline
  if (path === '/execute' && method === 'POST') {
    const body = await parseBody(req);
    if (!body.text && !body.objective) {
      return json(res, 400, { error: 'missing_field', message: 'Provide "text" or "objective" in request body' });
    }
    const result = await executePipeline(body);
    return json(res, 200, {
      id: result.id,
      status: result.status,
      duration: result.duration,
      classification: result.classification,
      stages: Object.fromEntries(
        Object.entries(result.stages).map(([k, v]) => [k, { status: v.status, duration: v.duration }])
      ),
    });
  }

  // Classify task (without executing)
  if (path === '/classify' && method === 'POST') {
    const body = await parseBody(req);
    return json(res, 200, classifyTask(body.text ?? ''));
  }

  // Pipeline history
  if (path === '/pipelines' && method === 'GET') {
    return json(res, 200, {
      active: activePipelines.size,
      completed: completedPipelines.length,
      recent: completedPipelines.slice(-fib(6)),
    });
  }

  // CSL constants reference
  if (path === '/constants' && method === 'GET') {
    return json(res, 200, {
      phi: { PHI, PSI, PHI2, PHI3 },
      thresholds: CSL_THRESHOLDS,
      pressure: PRESSURE_LEVELS,
      alerts: ALERT_THRESHOLDS,
      sizing: SIZING,
      resources: RESOURCE_WEIGHTS,
      tokenBudgets: phiTokenBudgets(),
    });
  }

  // 404
  json(res, 404, {
    error: 'not_found',
    message: `No route: ${method} ${path}`,
    available: ['GET /health', 'GET /status', 'POST /execute', 'POST /classify', 'GET /pipelines', 'GET /constants'],
  });
}

// ── Server ──────────────────────────────────────────────────────

const server = createServer(async (req, res) => {
  try {
    await handleRequest(req, res);
  } catch (err) {
    console.error(`[Conductor] Error: ${err.message}`, err.stack);
    json(res, 500, { error: 'internal', message: err.message, requestId: randomUUID() });
  }
});

server.listen(PORT, () => {
  console.log(`[HeadyConductor] v4.1.0 listening on :${PORT} (${NODE_ENV})`);
  console.log(`[HeadyConductor] PHI=${PHI.toFixed(6)} | Pools: ${Object.keys(POOLS).join(', ')}`);
  console.log(`[HeadyConductor] Pipeline stages: ${HCFP_STAGES.length} | Token budget: ${JSON.stringify(phiTokenBudgets())}`);
});

// Graceful shutdown (LIFO)
const shutdownHandlers = [];
function onShutdown(handler) { shutdownHandlers.unshift(handler); }

async function gracefulShutdown(signal) {
  console.log(`[HeadyConductor] ${signal} received, shutting down...`);
  for (const handler of shutdownHandlers) {
    try { await handler(); } catch (err) { console.error(`Shutdown error: ${err.message}`); }
  }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), fib(5) * 1000);  // 5s hard timeout
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

export { server, executePipeline, classifyTask, getSystemStatus };
export default server;
