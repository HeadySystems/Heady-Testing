/**
 * Heady MCP Service — Model Context Protocol Gateway (Cloud Run)
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * MCP 2025-03-26 spec compliant server exposing Heady tools via:
 *   - Streamable HTTP (POST for JSON-RPC, GET for SSE streaming)
 *   - JSON-RPC 2.0 message framing
 *   - CSL-gated tool routing (namespace prefix → cosine fallback)
 *   - Zero-trust sandbox (capability bitmask, input validation)
 *   - Semantic rate limiting (token bucket + sliding window + dedup)
 *   - Tamper-evident audit logging (SHA-256 chain)
 *
 * Zero dependencies HTTP server for fast Cloud Run cold start.
 * All constants from canonical phi-math v4.1.0.
 */

import { createServer } from 'node:http';
import { createHash, randomUUID } from 'node:crypto';

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD, SIZING,
  cosineSimilarity, cslAND, cslGATE,
  phiBackoff, phiAdaptiveInterval, fibRetryBackoff,
} from '../shared/phi-math.js';

// ═══════════════════════════════════════════════════════════════
// CONFIG — All phi-derived
// ═══════════════════════════════════════════════════════════════

const PORT = parseInt(process.env.PORT || '8083', 10);
const CONDUCTOR_URL = process.env.CONDUCTOR_URL || 'http://localhost:8082';
const MEMORY_URL = process.env.MEMORY_URL || 'http://localhost:8084';
const MCP_VERSION = '2025-03-26';

// Connection pool sizing (Fibonacci)
const POOL_MIN = fib(3);            // 2
const POOL_MAX = fib(7);            // 13
const POOL_IDLE_MS = fib(14) * 1000; // 377s

// Rate limiting (phi-scaled)
const RATE_BUCKET_SIZE = fib(8);     // 21 burst
const RATE_WINDOW_MS = fib(11) * 1000; // 89s sliding window
const RATE_REFILL_PER_S = fib(5);   // 5 per second

// Audit log rotation
const AUDIT_MAX_ENTRIES = fib(13) * 100; // 23300 entries per rotation
const AUDIT_RETENTION_DAYS = fib(11);     // 89 days

// Semantic dedup cache
const DEDUP_CACHE_SIZE = fib(16);    // 987 entries
const DEDUP_COSINE = DEDUP_THRESHOLD; // ≈0.972

// ═══════════════════════════════════════════════════════════════
// CAPABILITY BITMASK ACL — Zero-Trust Permissions
// ═══════════════════════════════════════════════════════════════

const CAPS = {
  FILE_READ:     1 << 0,
  FILE_WRITE:    1 << 1,
  NETWORK:       1 << 2,
  DATABASE_READ: 1 << 3,
  DATABASE_WRITE:1 << 4,
  MEMORY_READ:   1 << 5,
  MEMORY_WRITE:  1 << 6,
  CONDUCTOR:     1 << 7,
  ADMIN:         1 << 8,
};

// ═══════════════════════════════════════════════════════════════
// TOOL REGISTRY — Heady MCP Tools
// ═══════════════════════════════════════════════════════════════

const toolRegistry = new Map();

function registerTool(name, description, inputSchema, handler, capabilities = 0) {
  toolRegistry.set(name, { name, description, inputSchema, handler, capabilities });
}

// ── Memory Tools ──
registerTool('heady.memory.store', 'Store a vector in Heady 384D memory', {
  type: 'object',
  properties: {
    content:  { type: 'string', description: 'Text content to embed and store' },
    metadata: { type: 'object', description: 'Optional metadata for the entry' },
    namespace:{ type: 'string', description: 'Memory namespace (default: general)' },
  },
  required: ['content'],
}, async (args) => proxyToService(MEMORY_URL, '/store', args),
  CAPS.MEMORY_WRITE
);

registerTool('heady.memory.search', 'Search Heady vector memory via CSL gates', {
  type: 'object',
  properties: {
    query:     { type: 'string', description: 'Natural language search query' },
    topK:      { type: 'number', description: 'Number of results (default: fib(8)=21)' },
    threshold: { type: 'number', description: 'Cosine similarity threshold (default: CSL MEDIUM ≈0.809)' },
    gates:     { type: 'array', items: { type: 'string' }, description: 'CSL gate ops: AND, OR, NOT' },
    namespace: { type: 'string', description: 'Memory namespace filter' },
  },
  required: ['query'],
}, async (args) => proxyToService(MEMORY_URL, '/search', args),
  CAPS.MEMORY_READ
);

registerTool('heady.memory.drift', 'Check semantic drift against a reference vector', {
  type: 'object',
  properties: {
    id: { type: 'string', description: 'Memory entry ID to check drift for' },
  },
  required: ['id'],
}, async (args) => proxyToService(MEMORY_URL, '/drift', args),
  CAPS.MEMORY_READ
);

// ── Conductor Tools ──
registerTool('heady.conductor.route', 'Route a task through Heady Conductor (HCFullPipeline)', {
  type: 'object',
  properties: {
    task:      { type: 'string', description: 'Task description to route' },
    domain:    { type: 'string', description: 'Target domain (code, security, research, creative, etc.)' },
    priority:  { type: 'string', enum: ['hot', 'warm', 'cold'], description: 'Priority pool' },
    context:   { type: 'object', description: 'Additional task context' },
  },
  required: ['task'],
}, async (args) => proxyToService(CONDUCTOR_URL, '/route', args),
  CAPS.CONDUCTOR
);

registerTool('heady.conductor.pipeline', 'Execute the full HCFullPipeline for a task', {
  type: 'object',
  properties: {
    task:     { type: 'string', description: 'Task to run through HCFP' },
    stages:   { type: 'array', items: { type: 'string' }, description: 'Pipeline stages to execute' },
    dryRun:   { type: 'boolean', description: 'Simulate without executing' },
  },
  required: ['task'],
}, async (args) => proxyToService(CONDUCTOR_URL, '/pipeline', args),
  CAPS.CONDUCTOR
);

registerTool('heady.conductor.status', 'Get Heady Conductor swarm status', {
  type: 'object',
  properties: {
    detail: { type: 'string', enum: ['summary', 'health', 'full'], description: 'Detail level' },
  },
}, async (args) => proxyToService(CONDUCTOR_URL, '/status', args),
  CAPS.MEMORY_READ
);

// ── System Tools ──
registerTool('heady.system.health', 'Get overall Heady system health', {
  type: 'object',
  properties: {},
}, async () => ({
  status: 'healthy',
  services: {
    mcp: { status: 'healthy', uptime: process.uptime() },
    conductor: await pingService(CONDUCTOR_URL),
    memory: await pingService(MEMORY_URL),
  },
  timestamp: new Date().toISOString(),
}),
  0 // no special capabilities needed
);

registerTool('heady.system.phi', 'Get phi-math constants and Fibonacci reference', {
  type: 'object',
  properties: {
    category: { type: 'string', enum: ['core', 'thresholds', 'sizing', 'all'] },
  },
}, async (args) => {
  const cat = args.category || 'all';
  const result = {};
  if (cat === 'core' || cat === 'all') {
    result.core = { PHI, PSI, PHI2: PHI + 1, PHI3: 2 * PHI + 1, FIB: FIB.slice(0, 13) };
  }
  if (cat === 'thresholds' || cat === 'all') {
    result.thresholds = CSL_THRESHOLDS;
  }
  if (cat === 'sizing' || cat === 'all') {
    result.sizing = SIZING;
  }
  return result;
},
  0
);

// ═══════════════════════════════════════════════════════════════
// RATE LIMITER — Token Bucket + Sliding Window + Semantic Dedup
// ═══════════════════════════════════════════════════════════════

class PhiRateLimiter {
  constructor() {
    // Token bucket per client
    this.buckets = new Map();
    // Sliding window counters
    this.windows = new Map();
    // Semantic dedup cache (LRU)
    this.dedupCache = new Map();
  }

  /** Check rate limit, return { allowed, retryAfterMs, cached? } */
  check(clientId, inputHash) {
    // 1) Semantic dedup check
    if (inputHash && this.dedupCache.has(inputHash)) {
      const cached = this.dedupCache.get(inputHash);
      if (Date.now() - cached.ts < POOL_IDLE_MS) {
        return { allowed: true, cached: true, result: cached.result };
      }
      this.dedupCache.delete(inputHash);
    }

    // 2) Token bucket
    const now = Date.now();
    let bucket = this.buckets.get(clientId);
    if (!bucket) {
      bucket = { tokens: RATE_BUCKET_SIZE, lastRefill: now };
      this.buckets.set(clientId, bucket);
    }

    // Refill
    const elapsed = (now - bucket.lastRefill) / 1000;
    bucket.tokens = Math.min(RATE_BUCKET_SIZE, bucket.tokens + elapsed * RATE_REFILL_PER_S);
    bucket.lastRefill = now;

    if (bucket.tokens < 1) {
      const waitMs = Math.ceil((1 - bucket.tokens) / RATE_REFILL_PER_S * 1000);
      return { allowed: false, retryAfterMs: waitMs };
    }

    // 3) Sliding window
    let window = this.windows.get(clientId);
    if (!window) {
      window = { count: 0, start: now };
      this.windows.set(clientId, window);
    }

    if (now - window.start > RATE_WINDOW_MS) {
      window.count = 0;
      window.start = now;
    }

    const maxWindowReqs = RATE_BUCKET_SIZE * Math.ceil(RATE_WINDOW_MS / 1000) * RATE_REFILL_PER_S / fib(7);
    if (window.count >= maxWindowReqs) {
      const waitMs = RATE_WINDOW_MS - (now - window.start);
      return { allowed: false, retryAfterMs: waitMs };
    }

    bucket.tokens -= 1;
    window.count += 1;
    return { allowed: true };
  }

  /** Cache result for semantic dedup */
  cacheResult(inputHash, result) {
    if (!inputHash) return;
    if (this.dedupCache.size >= DEDUP_CACHE_SIZE) {
      // Evict oldest
      const oldest = this.dedupCache.keys().next().value;
      this.dedupCache.delete(oldest);
    }
    this.dedupCache.set(inputHash, { result, ts: Date.now() });
  }
}

const rateLimiter = new PhiRateLimiter();

// ═══════════════════════════════════════════════════════════════
// AUDIT LOGGER — SHA-256 Tamper-Evident Chain
// ═══════════════════════════════════════════════════════════════

class AuditLogger {
  constructor() {
    this.entries = [];
    this.prevHash = '0'.repeat(64);
  }

  log(record) {
    const entry = {
      seq: this.entries.length,
      timestamp: new Date().toISOString(),
      tool: record.tool,
      user: record.user || 'anonymous',
      input_hash: this._hash(JSON.stringify(record.input || {})),
      output_hash: this._hash(JSON.stringify(record.output || {})),
      duration_ms: record.duration_ms || 0,
      status: record.status || 'ok',
    };

    // Chain hash
    const recordHash = this._hash(JSON.stringify(entry));
    entry.chain_hash = this._hash(this.prevHash + recordHash);
    this.prevHash = entry.chain_hash;
    this.entries.push(entry);

    // Rotate if needed
    if (this.entries.length > AUDIT_MAX_ENTRIES) {
      this.entries = this.entries.slice(-fib(12)); // keep last 144
      // Re-chain
      this.prevHash = '0'.repeat(64);
      for (const e of this.entries) {
        const h = this._hash(JSON.stringify({ ...e, chain_hash: undefined }));
        e.chain_hash = this._hash(this.prevHash + h);
        this.prevHash = e.chain_hash;
      }
    }
  }

  verify() {
    let prev = '0'.repeat(64);
    for (const entry of this.entries) {
      const { chain_hash, ...rest } = entry;
      const h = this._hash(JSON.stringify(rest));
      const expected = this._hash(prev + h);
      if (expected !== chain_hash) {
        return { valid: false, failedAt: entry.seq };
      }
      prev = chain_hash;
    }
    return { valid: true, count: this.entries.length };
  }

  _hash(str) {
    return createHash('sha256').update(str).digest('hex');
  }
}

const auditLog = new AuditLogger();

// ═══════════════════════════════════════════════════════════════
// INPUT VALIDATION — Zero-Trust Sandbox
// ═══════════════════════════════════════════════════════════════

const DANGEROUS_PATTERNS = [
  /(\b(DROP|DELETE|ALTER|INSERT|UPDATE)\s+)/i,      // SQL injection
  /\.\.\//,                                          // Path traversal
  /(https?:\/\/(127\.|10\.|172\.(1[6-9]|2|3[01])\.|192\.168\.))/i, // SSRF to internal
  /(\$\{|`.*`|\$\()/,                               // Template injection
];

const SENSITIVE_PATTERNS = [
  /AKIA[0-9A-Z]{16}/,                               // AWS key
  /eyJ[a-zA-Z0-9_-]{10,}\.[a-zA-Z0-9_-]{10,}/,     // JWT
  /\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b/,       // Credit card
  /\b\d{3}-\d{2}-\d{4}\b/,                          // SSN
];

function validateInput(input) {
  const str = JSON.stringify(input);
  for (const p of DANGEROUS_PATTERNS) {
    if (p.test(str)) {
      return { valid: false, reason: `Input blocked: matches dangerous pattern` };
    }
  }
  return { valid: true };
}

function redactOutput(output) {
  let str = JSON.stringify(output);
  for (const p of SENSITIVE_PATTERNS) {
    str = str.replace(p, '[REDACTED]');
  }
  try { return JSON.parse(str); }
  catch { return output; }
}

function checkCapabilities(tool, userCaps = 0) {
  if (tool.capabilities === 0) return true; // no caps required
  return (userCaps & tool.capabilities) === tool.capabilities;
}

// ═══════════════════════════════════════════════════════════════
// SSE STREAM MANAGER — For tools/list_changed notifications
// ═══════════════════════════════════════════════════════════════

class SSEManager {
  constructor() {
    this.clients = new Map(); // sessionId → response
  }

  add(sessionId, res) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Session-Id': sessionId,
    });
    res.write(`event: endpoint\ndata: /mcp\n\n`);
    this.clients.set(sessionId, res);

    res.on('close', () => {
      this.clients.delete(sessionId);
    });
  }

  broadcast(event, data) {
    const payload = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const [, res] of this.clients) {
      res.write(payload);
    }
  }

  notify(sessionId, event, data) {
    const res = this.clients.get(sessionId);
    if (res) {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    }
  }
}

const sseManager = new SSEManager();

// ═══════════════════════════════════════════════════════════════
// JSON-RPC 2.0 HANDLER
// ═══════════════════════════════════════════════════════════════

function jsonRpcError(id, code, message, data) {
  return { jsonrpc: '2.0', id, error: { code, message, ...(data && { data }) } };
}

function jsonRpcResult(id, result) {
  return { jsonrpc: '2.0', id, result };
}

const RPC_CODES = {
  PARSE_ERROR:     -32700,
  INVALID_REQUEST: -32600,
  METHOD_NOT_FOUND:-32601,
  INVALID_PARAMS:  -32602,
  INTERNAL_ERROR:  -32603,
  RATE_LIMITED:    -32000,
  UNAUTHORIZED:    -32001,
  INPUT_BLOCKED:   -32002,
};

async function handleJsonRpc(message, sessionId) {
  // Parse
  if (!message || typeof message !== 'object' || message.jsonrpc !== '2.0') {
    return jsonRpcError(message?.id ?? null, RPC_CODES.INVALID_REQUEST, 'Invalid JSON-RPC 2.0 request');
  }

  const { id, method, params } = message;

  // ── MCP Protocol Methods ──────────────────────────────────

  // initialize
  if (method === 'initialize') {
    return jsonRpcResult(id, {
      protocolVersion: MCP_VERSION,
      serverInfo: {
        name: 'heady-mcp-server',
        version: '4.1.0',
      },
      capabilities: {
        tools: { listChanged: true },
        logging: {},
      },
    });
  }

  // notifications/initialized (notification, no response)
  if (method === 'notifications/initialized') {
    return null; // notification — no response
  }

  // ping
  if (method === 'ping') {
    return jsonRpcResult(id, {});
  }

  // tools/list
  if (method === 'tools/list') {
    const cursor = params?.cursor;
    const tools = [...toolRegistry.values()].map(t => ({
      name: t.name,
      description: t.description,
      inputSchema: t.inputSchema,
    }));

    // Paginate with Fibonacci page size
    const pageSize = fib(7); // 13
    const start = cursor ? parseInt(cursor, 10) : 0;
    const slice = tools.slice(start, start + pageSize);
    const nextCursor = start + pageSize < tools.length ? String(start + pageSize) : undefined;

    return jsonRpcResult(id, {
      tools: slice,
      ...(nextCursor && { nextCursor }),
    });
  }

  // tools/call
  if (method === 'tools/call') {
    const toolName = params?.name;
    const toolArgs = params?.arguments || {};

    const tool = toolRegistry.get(toolName);
    if (!tool) {
      return jsonRpcError(id, RPC_CODES.METHOD_NOT_FOUND, `Tool not found: ${toolName}`);
    }

    // Rate limit check
    const clientId = sessionId || 'default';
    const inputHash = createHash('sha256').update(JSON.stringify({ tool: toolName, args: toolArgs })).digest('hex');
    const rateCheck = rateLimiter.check(clientId, inputHash);

    if (!rateCheck.allowed) {
      return jsonRpcError(id, RPC_CODES.RATE_LIMITED, 'Rate limit exceeded', {
        retryAfterMs: rateCheck.retryAfterMs,
      });
    }

    if (rateCheck.cached) {
      return jsonRpcResult(id, rateCheck.result);
    }

    // Capability check
    const userCaps = CAPS.MEMORY_READ | CAPS.MEMORY_WRITE | CAPS.CONDUCTOR; // TODO: derive from JWT
    if (!checkCapabilities(tool, userCaps)) {
      return jsonRpcError(id, RPC_CODES.UNAUTHORIZED, `Insufficient capabilities for ${toolName}`);
    }

    // Input validation
    const validation = validateInput(toolArgs);
    if (!validation.valid) {
      auditLog.log({ tool: toolName, user: clientId, input: toolArgs, status: 'blocked', duration_ms: 0 });
      return jsonRpcError(id, RPC_CODES.INPUT_BLOCKED, validation.reason);
    }

    // Execute
    const startTime = Date.now();
    try {
      let result = await tool.handler(toolArgs);
      const durationMs = Date.now() - startTime;

      // Redact sensitive data
      result = redactOutput(result);

      // Audit
      auditLog.log({ tool: toolName, user: clientId, input: toolArgs, output: result, duration_ms: durationMs, status: 'ok' });

      // Cache for dedup
      const mcpResult = {
        content: [{ type: 'text', text: JSON.stringify(result, null, 2) }],
      };
      rateLimiter.cacheResult(inputHash, mcpResult);

      return jsonRpcResult(id, mcpResult);
    } catch (err) {
      const durationMs = Date.now() - startTime;
      auditLog.log({ tool: toolName, user: clientId, input: toolArgs, status: 'error', duration_ms: durationMs });
      return jsonRpcResult(id, {
        content: [{ type: 'text', text: `Error: ${err.message}` }],
        isError: true,
      });
    }
  }

  // logging/setLevel
  if (method === 'logging/setLevel') {
    return jsonRpcResult(id, {});
  }

  // Unknown method
  return jsonRpcError(id, RPC_CODES.METHOD_NOT_FOUND, `Unknown method: ${method}`);
}

// ═══════════════════════════════════════════════════════════════
// HTTP HELPERS
// ═══════════════════════════════════════════════════════════════

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks).toString();
}

function sendJson(res, status, data, headers = {}) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'X-Heady-Version': '4.1.0',
    ...headers,
  });
  res.end(body);
}

async function proxyToService(baseUrl, path, body) {
  const url = `${baseUrl}${path}`;
  const payload = JSON.stringify(body);
  const http = await import('node:http');
  const https = await import('node:https');
  const proto = url.startsWith('https') ? https : http;

  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const req = proto.request(parsed, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      timeout: fib(8) * 1000, // 21s
    }, (resp) => {
      const chunks = [];
      resp.on('data', c => chunks.push(c));
      resp.on('end', () => {
        try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
        catch { resolve({ raw: Buffer.concat(chunks).toString() }); }
      });
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('Service timeout')); });
    req.write(payload);
    req.end();
  });
}

async function pingService(baseUrl) {
  try {
    const result = await proxyToService(baseUrl, '/health', {});
    return { status: 'healthy', ...result };
  } catch {
    return { status: 'unreachable' };
  }
}

// ═══════════════════════════════════════════════════════════════
// HTTP SERVER — Streamable HTTP Transport
// ═══════════════════════════════════════════════════════════════

const server = createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;

  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Mcp-Session-Id');
  res.setHeader('Access-Control-Expose-Headers', 'Mcp-Session-Id, X-RateLimit-Remaining, X-RateLimit-Reset');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    return res.end();
  }

  // ── Health ──
  if (path === '/health') {
    return sendJson(res, 200, {
      status: 'healthy',
      service: 'heady-mcp',
      version: '4.1.0',
      protocol: MCP_VERSION,
      tools: toolRegistry.size,
      sseClients: sseManager.clients.size,
      auditEntries: auditLog.entries.length,
      auditIntegrity: auditLog.verify(),
      uptime: process.uptime(),
      phi: PHI,
    });
  }

  // ── Readiness ──
  if (path === '/ready') {
    return sendJson(res, 200, { ready: true });
  }

  // ── Audit endpoint (admin) ──
  if (path === '/audit') {
    return sendJson(res, 200, {
      integrity: auditLog.verify(),
      recentEntries: auditLog.entries.slice(-fib(7)), // last 13
      totalEntries: auditLog.entries.length,
    });
  }

  // ── MCP Endpoint — POST (JSON-RPC) ──
  if (path === '/mcp' && req.method === 'POST') {
    try {
      const body = await readBody(req);
      const parsed = JSON.parse(body);
      const sessionId = req.headers['mcp-session-id'] || randomUUID();

      // Handle batch requests
      if (Array.isArray(parsed)) {
        const results = [];
        for (const msg of parsed) {
          const result = await handleJsonRpc(msg, sessionId);
          if (result) results.push(result);
        }
        return sendJson(res, 200, results, { 'Mcp-Session-Id': sessionId });
      }

      const result = await handleJsonRpc(parsed, sessionId);
      if (result === null) {
        // Notification — no content
        res.writeHead(204);
        return res.end();
      }
      return sendJson(res, 200, result, { 'Mcp-Session-Id': sessionId });
    } catch (err) {
      return sendJson(res, 200, jsonRpcError(null, RPC_CODES.PARSE_ERROR, 'Parse error'));
    }
  }

  // ── MCP Endpoint — GET (SSE stream) ──
  if (path === '/mcp' && req.method === 'GET') {
    const sessionId = req.headers['mcp-session-id'] || randomUUID();
    sseManager.add(sessionId, res);
    return; // Keep connection open
  }

  // ── Tool listing (REST convenience) ──
  if (path === '/tools') {
    const tools = [...toolRegistry.values()].map(t => ({
      name: t.name,
      description: t.description,
      inputSchema: t.inputSchema,
    }));
    return sendJson(res, 200, { tools, count: tools.length });
  }

  // ── 404 ──
  sendJson(res, 404, { error: 'Not found', hint: 'Use POST /mcp for JSON-RPC or GET /mcp for SSE' });
});

// ═══════════════════════════════════════════════════════════════
// GRACEFUL SHUTDOWN (phi-timed)
// ═══════════════════════════════════════════════════════════════

let isShuttingDown = false;
const SHUTDOWN_TIMEOUT_MS = Math.round(PHI * 10000); // ~16.18s

async function shutdown(signal) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  console.log(`[mcp-service] ${signal} received, draining ${sseManager.clients.size} SSE clients...`);

  // Close SSE connections
  for (const [id, client] of sseManager.clients) {
    client.write(`event: shutdown\ndata: {"reason":"${signal}"}\n\n`);
    client.end();
  }
  sseManager.clients.clear();

  // Close HTTP server
  server.close(() => {
    console.log(`[mcp-service] Audit log integrity: ${JSON.stringify(auditLog.verify())}`);
    console.log('[mcp-service] Shutdown complete.');
    process.exit(0);
  });

  setTimeout(() => {
    console.warn('[mcp-service] Forced shutdown after timeout');
    process.exit(1);
  }, SHUTDOWN_TIMEOUT_MS);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// ═══════════════════════════════════════════════════════════════
// START
// ═══════════════════════════════════════════════════════════════

server.listen(PORT, '0.0.0.0', () => {
  console.log(`[heady-mcp-service] Listening on :${PORT}`);
  console.log(`[heady-mcp-service] Protocol: MCP ${MCP_VERSION}`);
  console.log(`[heady-mcp-service] Tools: ${toolRegistry.size} registered`);
  console.log(`[heady-mcp-service] Rate limit: ${RATE_BUCKET_SIZE} burst / ${RATE_REFILL_PER_S}/s refill`);
  console.log(`[heady-mcp-service] Audit: SHA-256 chain, max ${AUDIT_MAX_ENTRIES} entries`);
  console.log(`[heady-mcp-service] Dedup cache: ${DEDUP_CACHE_SIZE} entries, cosine ≥ ${DEDUP_COSINE.toFixed(3)}`);
  console.log(`[heady-mcp-service] φ = ${PHI.toFixed(10)} ψ = ${PSI.toFixed(10)}`);
});
