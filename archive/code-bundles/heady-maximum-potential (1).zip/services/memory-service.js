/**
 * Heady Memory Service — Vector Memory API (Cloud Run)
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 *
 * RAM-first 384D vector memory with pgvector persistence.
 * Provides embed, store, search, drift-check, and prune operations.
 * This is the "brain" — all reasoning reads from vector memory first.
 *
 * Zero dependencies HTTP server for fast Cloud Run cold start.
 * All constants from canonical phi-math v4.1.0.
 */

import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  SIZING, RELEVANCE_GATES,
  cosineSimilarity, cslAND, cslOR, cslNOT,
  phiFusionWeights,
} from '../shared/phi-math.js';

import { detectDrift, DRIFT_STATE } from '../shared/csl-engine.js';

// ── Configuration ───────────────────────────────────────────────

const PORT = parseInt(process.env.PORT ?? '8081', 10);
const DIMENSION = 384;

// ── In-Memory Vector Store (RAM-first) ──────────────────────────
// In production, this syncs to pgvector. RAM is source of truth.

class VectorMemory {
  constructor(config = {}) {
    this.dimension = config.dimension ?? DIMENSION;
    this.maxEntries = config.maxEntries ?? SIZING.LARGE_CACHE;     // fib(20) = 6765
    this.cacheSize = config.cacheSize ?? SIZING.CACHE_SIZE;         // fib(16) = 987
    
    this.entries = new Map();         // id → { embedding, content, metadata, createdAt, accessCount }
    this.embeddingCache = new Map();  // hash(text) → embedding (LRU)
    this.stats = { stores: 0, searches: 0, hits: 0, misses: 0, prunes: 0 };
  }

  /**
   * Store a vector in memory
   */
  store(entry) {
    const id = entry.id ?? randomUUID();
    const embedding = entry.embedding;

    if (!embedding || embedding.length !== this.dimension) {
      throw new Error(`Embedding must be ${this.dimension}D, got ${embedding?.length ?? 0}`);
    }

    // Deduplication check — if near-identical entry exists, merge
    for (const [existingId, existing] of this.entries) {
      const sim = cosineSimilarity(embedding, existing.embedding);
      if (sim >= DEDUP_THRESHOLD) {
        // Merge: keep higher confidence, update access
        existing.accessCount++;
        existing.content = entry.content ?? existing.content;
        existing.metadata = { ...existing.metadata, ...entry.metadata };
        existing.updatedAt = Date.now();
        this.stats.stores++;
        return { id: existingId, deduplicated: true, similarity: sim };
      }
    }

    // Store new entry
    this.entries.set(id, {
      embedding,
      content: entry.content ?? '',
      metadata: entry.metadata ?? {},
      createdAt: Date.now(),
      updatedAt: Date.now(),
      accessCount: 0,
    });

    this.stats.stores++;

    // Evict if over capacity
    if (this.entries.size > this.maxEntries) {
      this._evict();
    }

    return { id, deduplicated: false };
  }

  /**
   * Search for nearest vectors using CSL AND (cosine similarity)
   */
  search(queryEmbedding, options = {}) {
    const topK = options.topK ?? SIZING.FAILURE_THRESHOLD;  // fib(5) = 5
    const threshold = options.threshold ?? RELEVANCE_GATES.include;  // PSI² ≈ 0.382

    this.stats.searches++;

    const results = [];
    for (const [id, entry] of this.entries) {
      const similarity = cslAND(queryEmbedding, entry.embedding);
      if (similarity >= threshold) {
        results.push({
          id,
          similarity,
          content: entry.content,
          metadata: entry.metadata,
          accessCount: entry.accessCount,
        });
        entry.accessCount++;
      }
    }

    results.sort((a, b) => b.similarity - a.similarity);
    const hits = results.slice(0, topK);

    if (hits.length > 0) this.stats.hits++;
    else this.stats.misses++;

    return {
      results: hits,
      total: results.length,
      topK,
      threshold,
    };
  }

  /**
   * Check drift between two entries
   */
  checkDrift(id, newEmbedding) {
    const entry = this.entries.get(id);
    if (!entry) return { error: 'not_found' };
    return detectDrift(newEmbedding, entry.embedding);
  }

  /**
   * Semantic NOT — find entries that are dissimilar to a concept
   */
  searchNOT(queryEmbedding, excludeEmbedding, options = {}) {
    const topK = options.topK ?? SIZING.FAILURE_THRESHOLD;
    const filtered = cslNOT(queryEmbedding, excludeEmbedding);
    return this.search(filtered, { ...options, topK });
  }

  /**
   * Semantic OR — find entries similar to either of two concepts
   */
  searchOR(embeddingA, embeddingB, options = {}) {
    const combined = cslOR(embeddingA, embeddingB);
    return this.search(combined, options);
  }

  /**
   * Get entry by ID
   */
  get(id) {
    const entry = this.entries.get(id);
    if (!entry) return null;
    entry.accessCount++;
    return { id, ...entry };
  }

  /**
   * Delete entry
   */
  delete(id) {
    return this.entries.delete(id);
  }

  /**
   * Prune stale entries using phi-weighted eviction scoring
   */
  prune(maxAge = SIZING.RETENTION_DAYS * 24 * 60 * 60 * 1000) {
    const now = Date.now();
    const weights = phiFusionWeights(3);  // importance, recency, relevance
    let pruned = 0;

    for (const [id, entry] of this.entries) {
      const age = now - entry.createdAt;
      if (age > maxAge && entry.accessCount < SIZING.FAILURE_THRESHOLD) {
        this.entries.delete(id);
        pruned++;
      }
    }

    this.stats.prunes += pruned;
    return { pruned, remaining: this.entries.size };
  }

  /**
   * Evict lowest-scored entries when over capacity
   * Score = phi-weighted(importance, recency, relevance)
   */
  _evict() {
    const now = Date.now();
    const weights = phiFusionWeights(3);
    const maxAccess = Math.max(1, ...Array.from(this.entries.values()).map(e => e.accessCount));
    const maxAge = Math.max(1, ...Array.from(this.entries.values()).map(e => now - e.createdAt));

    const scored = Array.from(this.entries.entries()).map(([id, entry]) => {
      const importance = entry.accessCount / maxAccess;
      const recency = 1 - (now - entry.updatedAt) / maxAge;
      const relevance = entry.metadata?.relevance ?? PSI;

      const score = weights[0] * importance + weights[1] * recency + weights[2] * relevance;
      return { id, score };
    });

    scored.sort((a, b) => a.score - b.score);

    // Evict bottom batch
    const evictCount = SIZING.BATCH_EVICTION;  // fib(6) = 8
    for (let i = 0; i < evictCount && i < scored.length; i++) {
      this.entries.delete(scored[i].id);
    }
  }

  /**
   * Get memory stats
   */
  getStats() {
    return {
      entries: this.entries.size,
      maxEntries: this.maxEntries,
      dimension: this.dimension,
      ...this.stats,
      utilization: this.entries.size / this.maxEntries,
    };
  }
}

// ── Service Instance ────────────────────────────────────────────

const memory = new VectorMemory();

// ── HTTP Router ─────────────────────────────────────────────────

function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
      catch { resolve({}); }
    });
    req.on('error', reject);
  });
}

function json(res, status, data) {
  const body = JSON.stringify(data, null, 2);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'X-Heady-Service': 'memory',
    'X-Heady-Version': '4.1.0',
  });
  res.end(body);
}

async function handleRequest(req, res) {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const path = url.pathname;
  const method = req.method;

  // Health
  if (path === '/health' || path === '/_health') {
    return json(res, 200, {
      status: 'healthy',
      service: 'heady-memory',
      entries: memory.entries.size,
      timestamp: new Date().toISOString(),
    });
  }

  // Stats
  if (path === '/stats' && method === 'GET') {
    return json(res, 200, memory.getStats());
  }

  // Store
  if (path === '/store' && method === 'POST') {
    const body = await parseBody(req);
    if (!body.embedding) {
      return json(res, 400, { error: 'missing_embedding', message: 'Provide "embedding" (384D array)' });
    }
    try {
      const result = memory.store(body);
      return json(res, 201, result);
    } catch (err) {
      return json(res, 400, { error: 'store_failed', message: err.message });
    }
  }

  // Search
  if (path === '/search' && method === 'POST') {
    const body = await parseBody(req);
    if (!body.embedding) {
      return json(res, 400, { error: 'missing_embedding', message: 'Provide query "embedding"' });
    }
    const results = memory.search(body.embedding, {
      topK: body.topK,
      threshold: body.threshold,
    });
    return json(res, 200, results);
  }

  // Semantic NOT search
  if (path === '/search/not' && method === 'POST') {
    const body = await parseBody(req);
    if (!body.query || !body.exclude) {
      return json(res, 400, { error: 'missing_fields', message: 'Provide "query" and "exclude" embeddings' });
    }
    const results = memory.searchNOT(body.query, body.exclude, { topK: body.topK });
    return json(res, 200, results);
  }

  // Semantic OR search
  if (path === '/search/or' && method === 'POST') {
    const body = await parseBody(req);
    if (!body.a || !body.b) {
      return json(res, 400, { error: 'missing_fields', message: 'Provide "a" and "b" embeddings' });
    }
    const results = memory.searchOR(body.a, body.b, { topK: body.topK });
    return json(res, 200, results);
  }

  // Get by ID
  if (path.startsWith('/entry/') && method === 'GET') {
    const id = path.slice(7);
    const entry = memory.get(id);
    if (!entry) return json(res, 404, { error: 'not_found' });
    return json(res, 200, entry);
  }

  // Delete by ID
  if (path.startsWith('/entry/') && method === 'DELETE') {
    const id = path.slice(7);
    const deleted = memory.delete(id);
    return json(res, deleted ? 200 : 404, { deleted });
  }

  // Drift check
  if (path === '/drift' && method === 'POST') {
    const body = await parseBody(req);
    if (!body.id || !body.embedding) {
      return json(res, 400, { error: 'missing_fields', message: 'Provide "id" and new "embedding"' });
    }
    const result = memory.checkDrift(body.id, body.embedding);
    return json(res, result.error ? 404 : 200, result);
  }

  // Prune
  if (path === '/prune' && method === 'POST') {
    const body = await parseBody(req);
    const result = memory.prune(body.maxAge);
    return json(res, 200, result);
  }

  json(res, 404, {
    error: 'not_found',
    available: [
      'GET /health', 'GET /stats',
      'POST /store', 'POST /search', 'POST /search/not', 'POST /search/or',
      'GET /entry/:id', 'DELETE /entry/:id',
      'POST /drift', 'POST /prune',
    ],
  });
}

// ── Server ──────────────────────────────────────────────────────

const server = createServer(async (req, res) => {
  try {
    await handleRequest(req, res);
  } catch (err) {
    console.error(`[Memory] Error: ${err.message}`);
    json(res, 500, { error: 'internal', message: err.message });
  }
});

server.listen(PORT, () => {
  console.log(`[HeadyMemory] v4.1.0 listening on :${PORT}`);
  console.log(`[HeadyMemory] Dimension=${DIMENSION} | MaxEntries=${SIZING.LARGE_CACHE} | CacheSize=${SIZING.CACHE_SIZE}`);
});

process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
process.on('SIGINT', () => { server.close(() => process.exit(0)); });

export { server, memory, VectorMemory };
export default server;
