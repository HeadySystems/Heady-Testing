/**
 * Tests for shared/phi-math.js — Canonical v4.1.0
 *
 * Verifies all phi constants, Fibonacci generation,
 * threshold calculations, backoff timing, fusion weights,
 * CSL gates, sizing, and token budgets.
 * Uses Node.js built-in assert (no external dependencies).
 */

import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import {
  PHI, PSI, PHI2, PHI3, PHI_SQ, PHI_CUBE,
  FIB, fib, fibArray,
  phiThreshold, CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  phiBackoff, BACKOFF_CONFIG, fibRetryBackoff, phiAdaptiveInterval,
  phiFusionWeights, phiPriorityScore, phiResourceWeights,
  phiTokenBudgets, COMPRESSION_TRIGGER,
  PRESSURE_LEVELS, ALERT_THRESHOLDS,
  EVICTION_WEIGHTS, RESOURCE_WEIGHTS,
  SIZING, POOL_SIZES, RELEVANCE_GATES,
  PHI_TEMPERATURE, cslGate, cslBlend, adaptiveTemperature,
  cosineSimilarity, cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS, cslXOR,
  DEFAULT_DIM, normalize384, randomUnitVector,
} from '../shared/phi-math.js';

// ── Core Constants ──────────────────────────────────────────────

describe('Phi Constants', () => {
  it('PHI ≈ 1.618', () => {
    assert.ok(Math.abs(PHI - 1.618033988749895) < 1e-10);
  });

  it('PSI = 1/PHI ≈ 0.618', () => {
    assert.ok(Math.abs(PSI - 1 / PHI) < 1e-10);
  });

  it('PHI2 = PHI + 1 (and PHI_SQ alias)', () => {
    assert.ok(Math.abs(PHI2 - (PHI + 1)) < 1e-10);
    assert.equal(PHI_SQ, PHI2);
  });

  it('PHI3 = 2*PHI + 1 (and PHI_CUBE alias)', () => {
    assert.ok(Math.abs(PHI3 - (2 * PHI + 1)) < 1e-10);
    assert.equal(PHI_CUBE, PHI3);
  });

  it('PHI * PSI = 1', () => {
    assert.ok(Math.abs(PHI * PSI - 1) < 1e-10);
  });

  it('DEFAULT_DIM = 384', () => {
    assert.equal(DEFAULT_DIM, 384);
  });
});

// ── Fibonacci ───────────────────────────────────────────────────

describe('Fibonacci', () => {
  it('FIB array has known values', () => {
    assert.equal(FIB[0], 0);
    assert.equal(FIB[1], 1);
    assert.equal(FIB[5], 5);
    assert.equal(FIB[10], 55);
    assert.equal(FIB[12], 144);
    assert.equal(FIB[20], 6765);
  });

  it('fib(n) matches FIB[n] for n <= 20', () => {
    for (let n = 0; n <= 20; n++) {
      assert.equal(fib(n), FIB[n], `fib(${n}) should be ${FIB[n]}`);
    }
  });

  it('fib(n) works beyond FIB array', () => {
    assert.equal(fib(21), 10946);
  });

  it('each fib = sum of previous two', () => {
    for (let n = 2; n < FIB.length; n++) {
      assert.equal(FIB[n], FIB[n-1] + FIB[n-2], `FIB[${n}] should be FIB[${n-1}] + FIB[${n-2}]`);
    }
  });

  it('fibArray generates correct length', () => {
    const arr = fibArray(8);
    assert.equal(arr.length, 8);
    assert.deepEqual(arr, [0, 1, 1, 2, 3, 5, 8, 13]);
  });

  it('fibRetryBackoff returns Fibonacci-scaled delays', () => {
    const delays = fibRetryBackoff(5, 100);
    assert.deepEqual(delays, [300, 500, 800, 1300, 2100]);
  });
});

// ── Thresholds ──────────────────────────────────────────────────

describe('Phi Thresholds', () => {
  it('phiThreshold(0) = 0.500', () => {
    assert.ok(Math.abs(phiThreshold(0) - 0.5) < 0.001);
  });

  it('thresholds are monotonically increasing', () => {
    let prev = 0;
    for (let level = 0; level <= 5; level++) {
      const t = phiThreshold(level);
      assert.ok(t > prev, `level ${level} (${t}) should be > level ${level-1} (${prev})`);
      prev = t;
    }
  });

  it('CSL_THRESHOLDS match hierarchy', () => {
    assert.ok(CSL_THRESHOLDS.MINIMUM < CSL_THRESHOLDS.LOW);
    assert.ok(CSL_THRESHOLDS.LOW < CSL_THRESHOLDS.MEDIUM);
    assert.ok(CSL_THRESHOLDS.MEDIUM < CSL_THRESHOLDS.HIGH);
    assert.ok(CSL_THRESHOLDS.HIGH < CSL_THRESHOLDS.CRITICAL);
    assert.ok(CSL_THRESHOLDS.CRITICAL < 1.0);
  });

  it('DEDUP_THRESHOLD > CRITICAL', () => {
    assert.ok(DEDUP_THRESHOLD > CSL_THRESHOLDS.CRITICAL);
  });

  it('COHERENCE_DRIFT_THRESHOLD = MEDIUM', () => {
    assert.equal(COHERENCE_DRIFT_THRESHOLD, CSL_THRESHOLDS.MEDIUM);
  });
});

// ── Backoff ─────────────────────────────────────────────────────

describe('Phi Backoff', () => {
  it('attempt 0 returns ~base delay (no jitter)', () => {
    const delay = phiBackoff(0, 1000, 60000, false);
    assert.equal(delay, 1000);
  });

  it('delays increase with phi ratio', () => {
    let prev = phiBackoff(0, 1000, 60000, false);
    for (let i = 1; i <= 4; i++) {
      const delay = phiBackoff(i, 1000, 60000, false);
      assert.ok(delay > prev, `attempt ${i} (${delay}) should be > attempt ${i-1} (${prev})`);
      prev = delay;
    }
  });

  it('delays are capped at max', () => {
    const delay = phiBackoff(20, 1000, 5000, false);
    assert.ok(delay <= 5000, `delay ${delay} should be <= 5000`);
  });

  it('BACKOFF_CONFIG has expected fields', () => {
    assert.ok(BACKOFF_CONFIG.baseMs > 0);
    assert.ok(BACKOFF_CONFIG.maxMs > BACKOFF_CONFIG.baseMs);
    assert.ok(Math.abs(BACKOFF_CONFIG.multiplier - PHI) < 1e-10);
  });

  it('phiAdaptiveInterval increases when healthy', () => {
    const next = phiAdaptiveInterval(1000, true, 2000);
    assert.ok(next > 2000);
  });

  it('phiAdaptiveInterval decreases when unhealthy', () => {
    const next = phiAdaptiveInterval(1000, false, 2000);
    assert.ok(next < 2000);
  });
});

// ── Fusion Weights ──────────────────────────────────────────────

describe('Phi Fusion Weights', () => {
  it('weights for 2 factors sum to ~1', () => {
    const w = phiFusionWeights(2);
    assert.equal(w.length, 2);
    assert.ok(Math.abs(w.reduce((a, b) => a + b) - 1) < 0.001);
  });

  it('weights for 3 factors sum to ~1', () => {
    const w = phiFusionWeights(3);
    assert.equal(w.length, 3);
    assert.ok(Math.abs(w.reduce((a, b) => a + b) - 1) < 0.001);
  });

  it('weights are descending', () => {
    const w = phiFusionWeights(5);
    for (let i = 1; i < w.length; i++) {
      assert.ok(w[i] <= w[i-1], `weight[${i}] should be <= weight[${i-1}]`);
    }
  });

  it('phiPriorityScore produces weighted sum', () => {
    const score = phiPriorityScore(1.0, 0.5, 0.0);
    assert.ok(score > 0 && score < 1);
  });
});

// ── Resource Weights ────────────────────────────────────────────

describe('Resource Weights', () => {
  it('5-way phiResourceWeights sums to ~1', () => {
    const w = phiResourceWeights(5);
    assert.equal(w.length, 5);
    assert.ok(Math.abs(w.reduce((a, b) => a + b) - 1) < 0.02);
  });

  it('RESOURCE_WEIGHTS has canonical pool names', () => {
    assert.ok(RESOURCE_WEIGHTS.hot > 0);
    assert.ok(RESOURCE_WEIGHTS.warm > 0);
    assert.ok(RESOURCE_WEIGHTS.cold > 0);
    assert.ok(RESOURCE_WEIGHTS.reserve > 0);
    assert.ok(RESOURCE_WEIGHTS.governance > 0);
  });
});

// ── Token Budgets ───────────────────────────────────────────────

describe('Token Budgets', () => {
  it('budgets form phi-geometric progression', () => {
    const b = phiTokenBudgets(8192);
    assert.ok(b.working < b.session);
    assert.ok(b.session < b.memory);
    assert.ok(b.memory < b.artifacts);
  });

  it('base budget matches working', () => {
    const b = phiTokenBudgets(4096);
    assert.equal(b.working, 4096);
  });

  it('COMPRESSION_TRIGGER is phi-derived', () => {
    const expected = 1 - Math.pow(PSI, 4);
    assert.ok(Math.abs(COMPRESSION_TRIGGER - expected) < 1e-10);
  });
});

// ── Pressure & Alert Levels ─────────────────────────────────────

describe('Pressure Levels', () => {
  it('levels are ordered', () => {
    assert.ok(PRESSURE_LEVELS.NOMINAL.max < PRESSURE_LEVELS.ELEVATED.max);
    assert.ok(PRESSURE_LEVELS.ELEVATED.max < PRESSURE_LEVELS.HIGH.max);
  });

  it('ALERT_THRESHOLDS are ordered', () => {
    assert.ok(ALERT_THRESHOLDS.warning < ALERT_THRESHOLDS.caution);
    assert.ok(ALERT_THRESHOLDS.caution < ALERT_THRESHOLDS.critical);
    assert.ok(ALERT_THRESHOLDS.critical < ALERT_THRESHOLDS.exceeded);
    assert.ok(ALERT_THRESHOLDS.exceeded < ALERT_THRESHOLDS.hard_max);
  });
});

// ── Eviction Weights ────────────────────────────────────────────

describe('Eviction Weights', () => {
  it('eviction weights sum to ~1', () => {
    const sum = EVICTION_WEIGHTS.importance + EVICTION_WEIGHTS.recency + EVICTION_WEIGHTS.relevance;
    assert.ok(Math.abs(sum - 1) < 0.001);
  });
});

// ── Sizing ──────────────────────────────────────────────────────

describe('Sizing', () => {
  it('all SIZING values are Fibonacci', () => {
    const fibSet = new Set(FIB);
    for (const [key, value] of Object.entries(SIZING)) {
      assert.ok(fibSet.has(value), `SIZING.${key}=${value} should be Fibonacci`);
    }
  });

  it('POOL_SIZES has min and max', () => {
    assert.ok(POOL_SIZES.min < POOL_SIZES.max);
  });

  it('RELEVANCE_GATES has phi-derived values', () => {
    assert.ok(Math.abs(RELEVANCE_GATES.include - Math.pow(PSI, 2)) < 1e-10);
    assert.ok(Math.abs(RELEVANCE_GATES.boost - PSI) < 1e-10);
  });
});

// ── CSL Gates (canonical) ───────────────────────────────────────

describe('CSL Gates (canonical)', () => {
  it('cslAND: identical vectors → 1.0', () => {
    const a = randomUnitVector();
    assert.ok(Math.abs(cslAND(a, a) - 1.0) < 1e-6);
  });

  it('cslAND: commutative', () => {
    const a = randomUnitVector();
    const b = randomUnitVector();
    assert.ok(Math.abs(cslAND(a, b) - cslAND(b, a)) < 1e-10);
  });

  it('cslOR: produces unit vector', () => {
    const a = randomUnitVector();
    const b = randomUnitVector();
    const result = cslOR(a, b);
    const norm = Math.sqrt(result.reduce((s, v) => s + v * v, 0));
    assert.ok(Math.abs(norm - 1.0) < 1e-6);
  });

  it('cslNOT: orthogonal to b', () => {
    const a = randomUnitVector();
    const b = randomUnitVector();
    const result = cslNOT(a, b);
    const dot = result.reduce((s, v, i) => s + v * b[i], 0);
    assert.ok(Math.abs(dot) < 1e-6, `NOT(a,b)·b should be ~0, got ${dot}`);
  });

  it('cslIMPLY: parallel to b', () => {
    const a = randomUnitVector();
    const b = randomUnitVector();
    const result = cslIMPLY(a, b);
    const bNormed = normalize384(b);
    const sim = Math.abs(cosineSimilarity(result, bNormed));
    assert.ok(sim > 0.999, `Expected parallel to b, sim = ${sim}`);
  });

  it('cslCONSENSUS: unit vector', () => {
    const vecs = [randomUnitVector(), randomUnitVector(), randomUnitVector()];
    const result = cslCONSENSUS(vecs, [0.5, 0.3, 0.2]);
    const norm = Math.sqrt(result.reduce((s, v) => s + v * v, 0));
    assert.ok(Math.abs(norm - 1.0) < 1e-6);
  });

  it('cslXOR: produces a vector', () => {
    const a = randomUnitVector();
    const b = randomUnitVector();
    const result = cslXOR(a, b);
    assert.equal(result.length, DEFAULT_DIM);
  });

  it('cslGate: high score passes value', () => {
    const gated = cslGate(1.0, 0.99, 0.5, 0.1);
    assert.ok(gated > 0.9);
  });

  it('cslGate: low score blocks value', () => {
    const gated = cslGate(1.0, -0.99, 0.5, 0.1);
    assert.ok(gated < 0.1);
  });

  it('cslBlend: interpolates between weights', () => {
    const high = cslBlend(1.0, 0.0, 0.99, 0.5);
    const low = cslBlend(1.0, 0.0, -0.99, 0.5);
    assert.ok(high > 0.9);
    assert.ok(low < 0.1);
  });

  it('PHI_TEMPERATURE = ψ³', () => {
    assert.ok(Math.abs(PHI_TEMPERATURE - Math.pow(PSI, 3)) < 1e-10);
  });

  it('adaptiveTemperature increases with entropy', () => {
    const lowEntropy = adaptiveTemperature(0.1, 1.0);
    const highEntropy = adaptiveTemperature(0.9, 1.0);
    assert.ok(highEntropy > lowEntropy);
  });
});
