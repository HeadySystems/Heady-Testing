/**
 * Tests for shared/csl-engine.js — Extended CSL Operations
 *
 * Verifies MoE routing, HDC operations, ternary logic,
 * drift detection, and the cslGATE vector wrapper.
 * Canonical CSL gates are tested in phi-math.test.js.
 */

import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import {
  cosineSimilarity, normalize384, randomUnitVector, DEFAULT_DIM,
  cslAND, cslOR, cslNOT, cslIMPLY, cslXOR, cslCONSENSUS,
} from '../shared/phi-math.js';

import {
  cslGATE,
  MoERouter, moeRoute,
  hdcBIND, hdcBUNDLE, hdcPERMUTE,
  ternaryEval, TERNARY_MODES,
  detectDrift, DRIFT_STATE,
} from '../shared/csl-engine.js';

// ── Helpers ─────────────────────────────────────────────────────

function randomVec(dim = 384) {
  const v = new Array(dim);
  for (let i = 0; i < dim; i++) v[i] = Math.random() * 2 - 1;
  return v;
}

// ── cslGATE (vector-level wrapper) ──────────────────────────────

describe('cslGATE (vector wrapper)', () => {
  it('high similarity → passes value through', () => {
    const a = randomUnitVector();
    const gated = cslGATE(1.0, a, a, 0.5, 0.1);
    assert.ok(gated > 0.9, `Expected ~1.0, got ${gated}`);
  });

  it('low similarity → blocks value', () => {
    const a = randomUnitVector();
    const b = a.map(v => -v);
    const gated = cslGATE(1.0, a, b, 0.5, 0.1);
    assert.ok(gated < 0.1, `Expected ~0, got ${gated}`);
  });

  it('output is bounded [0, value]', () => {
    const a = randomVec();
    const b = randomVec();
    const gated = cslGATE(5.0, a, b, 0.5, 0.2);
    assert.ok(gated >= 0 && gated <= 5.0, `Expected 0 <= ${gated} <= 5.0`);
  });
});

// ── MoE Router ──────────────────────────────────────────────────

describe('MoE Router', () => {
  it('routes to experts and returns scores', () => {
    const router = new MoERouter(3, 384, 2);
    const input = randomUnitVector();
    const result = router.route(input);
    assert.ok(result.selected.length === 2, 'Should select top-2 experts');
    assert.ok(result.scores.length === 3, 'Should have 3 scores');
  });

  it('selected indices are within range', () => {
    const router = new MoERouter(5, 384, 2);
    const input = randomUnitVector();
    const result = router.route(input);
    for (const idx of result.selected) {
      assert.ok(idx >= 0 && idx < 5, `Expert index ${idx} out of range`);
    }
  });

  it('probs sum to ~1', () => {
    const router = new MoERouter(4, 384, 2);
    const input = randomUnitVector();
    const result = router.route(input);
    const sum = result.probs.reduce((a, b) => a + b, 0);
    assert.ok(Math.abs(sum - 1.0) < 1e-6, `Probs sum ${sum} should be ~1`);
  });

  it('legacy moeRoute works', () => {
    const gates = [randomUnitVector(), randomUnitVector(), randomUnitVector()];
    const input = randomUnitVector();
    const result = moeRoute(input, gates, 2);
    assert.ok(result.selected.length === 2);
  });
});

// ── HDC Operations ──────────────────────────────────────────────

describe('HDC Operations', () => {
  it('BIND produces a vector of same dimension', () => {
    const a = randomVec();
    const b = randomVec();
    const bound = hdcBIND(a, b);
    assert.equal(bound.length, 384);
  });

  it('BUNDLE produces a unit vector', () => {
    const vecs = [randomVec(), randomVec(), randomVec()];
    const bundled = hdcBUNDLE(vecs);
    const norm = Math.sqrt(bundled.reduce((s, v) => s + v * v, 0));
    assert.ok(Math.abs(norm - 1.0) < 1e-6);
  });

  it('PERMUTE shifts elements', () => {
    const a = randomVec();
    const permuted = hdcPERMUTE(a, 1);
    // First element of permuted should be last element of original
    assert.ok(Math.abs(permuted[0] - a[383]) < 1e-10);
  });

  it('PERMUTE(a, 0) returns same vector', () => {
    const a = randomVec();
    const same = hdcPERMUTE(a, 0);
    for (let i = 0; i < a.length; i++) {
      assert.ok(Math.abs(same[i] - a[i]) < 1e-10);
    }
  });
});

// ── Ternary Logic ───────────────────────────────────────────────

describe('Ternary Logic', () => {
  it('aligned vectors → TRUE', () => {
    const a = randomUnitVector();
    const result = ternaryEval(a, a, TERNARY_MODES.KLEENE);
    assert.equal(result.label, 'TRUE');
  });

  it('antipodal vectors → FALSE', () => {
    const a = randomUnitVector();
    const neg = a.map(v => -v);
    const result = ternaryEval(a, neg, TERNARY_MODES.KLEENE);
    assert.equal(result.label, 'FALSE');
  });

  it('all modes return valid structure', () => {
    const a = randomUnitVector();
    const b = randomUnitVector();
    for (const mode of Object.values(TERNARY_MODES)) {
      const result = ternaryEval(a, b, mode);
      assert.ok(['TRUE', 'UNKNOWN', 'FALSE'].includes(result.label));
      assert.ok(typeof result.value === 'number');
      assert.ok(typeof result.cosine === 'number');
      assert.equal(result.mode, mode);
    }
  });
});

// ── Drift Detection ─────────────────────────────────────────────

describe('Drift Detection', () => {
  it('identical vectors → STABLE', () => {
    const v = randomUnitVector();
    const result = detectDrift(v, v);
    assert.equal(result.state, DRIFT_STATE.STABLE);
    assert.ok(!result.needsHeal);
  });

  it('negated vector → CRITICAL', () => {
    const v = randomUnitVector();
    const neg = v.map(x => -x);
    const result = detectDrift(v, neg);
    assert.equal(result.state, DRIFT_STATE.CRITICAL);
    assert.ok(result.needsHeal);
  });

  it('returns correct structure', () => {
    const a = randomUnitVector();
    const b = randomUnitVector();
    const result = detectDrift(a, b);
    assert.ok(typeof result.similarity === 'number');
    assert.ok(typeof result.drift === 'number');
    assert.ok(typeof result.needsHeal === 'boolean');
    assert.ok(typeof result.threshold === 'number');
    assert.ok(Object.values(DRIFT_STATE).includes(result.state));
  });
});
