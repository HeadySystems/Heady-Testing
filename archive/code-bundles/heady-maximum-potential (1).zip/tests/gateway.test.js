/**
 * Tests for liquid-gateway/ modules
 * 
 * Verifies domain routing, rate limiter tiers,
 * and cache key generation.
 * (Cannot test the Cloudflare Worker fetch handler directly
 * without miniflare, but we can test the pure logic modules.)
 */

import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import {
  resolveRoute, requiresAuth, getCacheTTL,
  getAllDomains, DOMAINS
} from '../liquid-gateway/domain-router.js';

import { RATE_TIERS } from '../liquid-gateway/rate-limiter.js';
import { CACHE_CONFIG } from '../liquid-gateway/edge-cache.js';

// ── Domain Router ───────────────────────────────────────────────

describe('Domain Router', () => {
  it('resolves known domain', () => {
    const request = new Request('https://headyapi.com/v1/chat');
    const route = resolveRoute(request);
    assert.equal(route.domain, 'headyapi.com');
    assert.equal(route.config.service, 'public-api');
    assert.equal(route.path, '/v1/chat');
  });

  it('resolves headyme.com', () => {
    const request = new Request('https://headyme.com/dashboard');
    const route = resolveRoute(request);
    assert.equal(route.config.service, 'command-center');
    assert.equal(route.config.authLevel, 'authenticated');
  });

  it('returns null config for unknown domain', () => {
    const request = new Request('https://example.com/test');
    const route = resolveRoute(request);
    assert.equal(route.config, null);
  });

  it('strips www prefix', () => {
    const request = new Request('https://www.headyio.com/docs');
    const route = resolveRoute(request);
    assert.equal(route.domain, 'headyio.com');
    assert.equal(route.config.service, 'developer-platform');
  });

  it('public domains do not require auth', () => {
    const request = new Request('https://headyconnection.org/about');
    const route = resolveRoute(request);
    assert.equal(requiresAuth(route.config), false);
  });

  it('token domains require auth', () => {
    const request = new Request('https://headymcp.com/tools');
    const route = resolveRoute(request);
    assert.equal(requiresAuth(route.config), true);
  });

  it('getAllDomains returns 11 domains', () => {
    const domains = getAllDomains();
    assert.equal(domains.length, 11);
  });
});

// ── Cache TTL ───────────────────────────────────────────────────

describe('Cache TTL', () => {
  it('POST requests are not cached', () => {
    const config = DOMAINS['headyapi.com'];
    const request = new Request('https://headyapi.com/v1/chat', { method: 'POST' });
    assert.equal(getCacheTTL(config, request), 0);
  });

  it('GET requests use domain TTL', () => {
    const config = DOMAINS['headyio.com'];
    const request = new Request('https://headyio.com/docs', { method: 'GET' });
    const ttl = getCacheTTL(config, request);
    assert.equal(ttl, 144);  // FIB[12]
  });

  it('MCP has no cache', () => {
    const config = DOMAINS['headymcp.com'];
    const request = new Request('https://headymcp.com/tools', { method: 'GET' });
    assert.equal(getCacheTTL(config, request), 0);
  });
});

// ── Rate Tiers ──────────────────────────────────────────────────

describe('Rate Tiers', () => {
  it('anonymous has lowest limit', () => {
    assert.ok(RATE_TIERS.anonymous.limit < RATE_TIERS.authenticated.limit);
    assert.ok(RATE_TIERS.authenticated.limit < RATE_TIERS.token.limit);
    assert.ok(RATE_TIERS.token.limit < RATE_TIERS.internal.limit);
  });

  it('all tiers have Fibonacci limits', () => {
    const fibs = new Set([0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597]);
    for (const [name, tier] of Object.entries(RATE_TIERS)) {
      assert.ok(fibs.has(tier.limit), `${name} limit ${tier.limit} should be Fibonacci`);
      assert.ok(fibs.has(tier.burstLimit), `${name} burst ${tier.burstLimit} should be Fibonacci`);
    }
  });
});

// ── Cache Config ────────────────────────────────────────────────

describe('Cache Config', () => {
  it('default TTL is Fibonacci', () => {
    const fibs = new Set([0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597]);
    assert.ok(fibs.has(CACHE_CONFIG.defaultTTL));
    assert.ok(fibs.has(CACHE_CONFIG.staleWhileRevalidate));
    assert.ok(fibs.has(CACHE_CONFIG.maxAge));
  });
});
