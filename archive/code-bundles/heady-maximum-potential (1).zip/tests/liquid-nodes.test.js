/**
 * Tests for liquid-nodes/ core modules
 *
 * Verifies constants alignment with canonical phi-math v4.1.0,
 * Fibonacci sizing, pool weights, and import smoke tests.
 */

import assert from 'node:assert/strict';
import { describe, it } from 'node:test';

import {
  PHI, PSI, PHI2, PHI3, FIB, fib,
  DIMENSIONS, POOL_WEIGHTS, BEE_TYPES,
  SIZING, POOL_SIZES, RESOURCE_WEIGHTS,
  CSL_THRESHOLDS,
  POOL_ALLOCATIONS,
  MAX_CONCURRENT_TASKS, MAX_BEES,
} from '../liquid-nodes/constants.js';

// ── Constants ───────────────────────────────────────────────────

describe('Liquid Node Constants', () => {
  it('PHI ≈ 1.618', () => {
    assert.ok(Math.abs(PHI - 1.618033988749895) < 1e-10);
  });

  it('PHI2 = PHI + 1', () => {
    assert.ok(Math.abs(PHI2 - (PHI + 1)) < 1e-10);
  });

  it('PHI3 = 2*PHI + 1', () => {
    assert.ok(Math.abs(PHI3 - (2 * PHI + 1)) < 1e-10);
  });

  it('DIMENSIONS includes 384', () => {
    assert.ok(DIMENSIONS.includes(384), 'Should include 384D');
  });

  it('FIB[12] = 144', () => {
    assert.equal(FIB[12], 144);
  });

  it('FIB starts with 0', () => {
    assert.equal(FIB[0], 0);
  });

  it('BEE_TYPES has 33 types', () => {
    assert.equal(BEE_TYPES.length, 33);
  });
});

// ── Pool & Resource Weights ─────────────────────────────────────

describe('Pool & Resource Weights', () => {
  it('POOL_ALLOCATIONS matches RESOURCE_WEIGHTS', () => {
    assert.equal(POOL_ALLOCATIONS.HOT, RESOURCE_WEIGHTS.hot);
    assert.equal(POOL_ALLOCATIONS.WARM, RESOURCE_WEIGHTS.warm);
    assert.equal(POOL_ALLOCATIONS.COLD, RESOURCE_WEIGHTS.cold);
  });

  it('POOL_WEIGHTS is alias for POOL_ALLOCATIONS', () => {
    assert.equal(POOL_WEIGHTS, POOL_ALLOCATIONS);
  });
});

// ── Sizing from Canonical ───────────────────────────────────────

describe('Canonical Sizing', () => {
  it('MAX_CONCURRENT_TASKS = fib(7) = 13', () => {
    assert.equal(MAX_CONCURRENT_TASKS, 13);
  });

  it('MAX_BEES = fib(9) = 34', () => {
    assert.equal(MAX_BEES, 34);
  });

  it('SIZING.CACHE_SIZE = fib(16) = 987', () => {
    assert.equal(SIZING.CACHE_SIZE, 987);
  });

  it('CSL_THRESHOLDS cascade from canonical', () => {
    assert.ok(CSL_THRESHOLDS.MINIMUM < CSL_THRESHOLDS.LOW);
    assert.ok(CSL_THRESHOLDS.LOW < CSL_THRESHOLDS.MEDIUM);
  });
});
