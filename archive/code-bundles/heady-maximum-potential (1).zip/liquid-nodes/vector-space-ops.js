/**
 * vector-space-ops.js — Vector memory operations for Heady liquid node system.
 *
 * 384-dimensional embedding operations with CSL (Cosine Similarity Logic) gates,
 * relevance scoring, and drift detection. All thresholds phi-scaled.
 */

const PHI = 1.618033988749895;
const INV_PHI = 1 / PHI; // 0.618...
const EMBEDDING_DIM = 384;
const DRIFT_THRESHOLD = 1 - (1 / (PHI * PHI)); // ~0.618 — phi-derived
const RELEVANCE_FLOOR = INV_PHI * INV_PHI; // ~0.382
const SUPERPOSITION_SCALE = INV_PHI; // weighting for OR superposition

/**
 * Create a zero vector of the standard dimension.
 * @param {number} [dim=EMBEDDING_DIM]
 * @returns {Float64Array}
 */
export function zeroVector(dim = EMBEDDING_DIM) {
  return new Float64Array(dim);
}

/**
 * Create a random unit vector (uniform on the hypersphere via Gaussian projection).
 * @param {number} [dim=EMBEDDING_DIM]
 * @returns {Float64Array}
 */
export function randomUnitVector(dim = EMBEDDING_DIM) {
  const v = new Float64Array(dim);
  let norm = 0;
  for (let i = 0; i < dim; i++) {
    // Box-Muller transform for Gaussian samples
    const u1 = Math.random() || 1e-12;
    const u2 = Math.random();
    const g = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    v[i] = g;
    norm += g * g;
  }
  norm = Math.sqrt(norm);
  if (norm > 0) {
    for (let i = 0; i < dim; i++) v[i] /= norm;
  }
  return v;
}

/**
 * L2 norm of a vector.
 * @param {Float64Array} a
 * @returns {number}
 */
export function magnitude(a) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i] * a[i];
  return Math.sqrt(sum);
}

/**
 * Normalize a vector in-place; returns the same buffer.
 * @param {Float64Array} a
 * @returns {Float64Array}
 */
export function normalize(a) {
  const mag = magnitude(a);
  if (mag > 0) {
    for (let i = 0; i < a.length; i++) a[i] /= mag;
  }
  return a;
}

/**
 * Dot product of two vectors.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {number}
 */
export function dot(a, b) {
  let sum = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) sum += a[i] * b[i];
  return sum;
}

/**
 * Cosine similarity between two vectors.
 * Returns 0 if either vector is zero.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {number}
 */
export function cosineSimilarity(a, b) {
  const magA = magnitude(a);
  const magB = magnitude(b);
  if (magA === 0 || magB === 0) return 0;
  return dot(a, b) / (magA * magB);
}

/**
 * Add two vectors, returning a new Float64Array.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {Float64Array}
 */
export function add(a, b) {
  const dim = Math.max(a.length, b.length);
  const result = new Float64Array(dim);
  for (let i = 0; i < dim; i++) {
    result[i] = (i < a.length ? a[i] : 0) + (i < b.length ? b[i] : 0);
  }
  return result;
}

/**
 * Subtract b from a, returning a new Float64Array.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {Float64Array}
 */
export function subtract(a, b) {
  const dim = Math.max(a.length, b.length);
  const result = new Float64Array(dim);
  for (let i = 0; i < dim; i++) {
    result[i] = (i < a.length ? a[i] : 0) - (i < b.length ? b[i] : 0);
  }
  return result;
}

/**
 * Scale a vector by a scalar, returning a new Float64Array.
 * @param {Float64Array} a
 * @param {number} s
 * @returns {Float64Array}
 */
export function scale(a, s) {
  const result = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) result[i] = a[i] * s;
  return result;
}

// ---------------------------------------------------------------------------
// CSL Gates — Cosine Similarity Logic
// ---------------------------------------------------------------------------

/**
 * CSL AND: intersection of two concept vectors via element-wise cosine weighting.
 * Returns the component of b projected onto a, scaled by their cosine similarity.
 * High similarity → result close to both; low → near-zero.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {Float64Array}
 */
export function cslAnd(a, b) {
  const sim = cosineSimilarity(a, b);
  // weight = sim clamped to [0,1] (negative similarity = no intersection)
  const weight = Math.max(0, sim);
  // project b onto a's direction, scaled by similarity
  const magA = magnitude(a);
  if (magA === 0) return zeroVector(a.length);
  const projScale = (dot(a, b) / (magA * magA)) * weight;
  return scale(a, projScale);
}

/**
 * CSL OR: superposition of two concept vectors.
 * Combines both vectors with phi-scaled weighting, then normalizes.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {Float64Array}
 */
export function cslOr(a, b) {
  const combined = add(scale(a, SUPERPOSITION_SCALE), scale(b, SUPERPOSITION_SCALE));
  const mag = magnitude(combined);
  if (mag === 0) return zeroVector(Math.max(a.length, b.length));
  // Restore to average magnitude of inputs
  const targetMag = (magnitude(a) + magnitude(b)) * SUPERPOSITION_SCALE;
  return scale(combined, targetMag / mag);
}

/**
 * CSL NOT: orthogonal projection — removes the component of b from a.
 * The result is the part of a that is orthogonal to b.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {Float64Array}
 */
export function cslNot(a, b) {
  const magB = magnitude(b);
  if (magB === 0) return new Float64Array(a);
  const projScalar = dot(a, b) / (magB * magB);
  const projection = scale(b, projScalar);
  return subtract(a, projection);
}

/**
 * CSL IMPLY: a → b. Conceptually if-a-then-b.
 * Returns OR(NOT(a, b_context), b) — either a is not relevant, or b holds.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {Float64Array}
 */
export function cslImply(a, b) {
  const notA = cslNot(randomUnitVector(a.length), a);
  return cslOr(notA, b);
}

/**
 * CSL XOR: exclusive-or in vector space.
 * Returns the component that is unique to each vector (removes shared component).
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {Float64Array}
 */
export function cslXor(a, b) {
  const uniqueA = cslNot(a, b);
  const uniqueB = cslNot(b, a);
  return add(uniqueA, uniqueB);
}

// ---------------------------------------------------------------------------
// Relevance scoring and drift detection
// ---------------------------------------------------------------------------

/**
 * Score the relevance of a candidate vector against a query vector.
 * Returns a value in [0, 1] where 1 = perfect match.
 * Applies phi-scaled floor — anything below RELEVANCE_FLOOR maps to 0.
 * @param {Float64Array} query
 * @param {Float64Array} candidate
 * @returns {number}
 */
export function relevanceScore(query, candidate) {
  const raw = cosineSimilarity(query, candidate);
  if (raw < RELEVANCE_FLOOR) return 0;
  // rescale [RELEVANCE_FLOOR, 1] → [0, 1]
  return (raw - RELEVANCE_FLOOR) / (1 - RELEVANCE_FLOOR);
}

/**
 * Rank an array of candidate vectors by relevance to a query.
 * @param {Float64Array} query
 * @param {{ id: string, vector: Float64Array }[]} candidates
 * @param {number} [topK=0] — 0 returns all above floor
 * @returns {{ id: string, score: number }[]}
 */
export function rankByRelevance(query, candidates, topK = 0) {
  const scored = candidates
    .map(c => ({ id: c.id, score: relevanceScore(query, c.vector) }))
    .filter(c => c.score > 0)
    .sort((a, b) => b.score - a.score);
  if (topK > 0) return scored.slice(0, topK);
  return scored;
}

/**
 * Detect semantic drift between a reference embedding and a current embedding.
 * @param {Float64Array} reference — the baseline embedding
 * @param {Float64Array} current — the current embedding to check
 * @returns {{ drifted: boolean, similarity: number, threshold: number }}
 */
export function detectDrift(reference, current) {
  const sim = cosineSimilarity(reference, current);
  return {
    drifted: sim < DRIFT_THRESHOLD,
    similarity: sim,
    threshold: DRIFT_THRESHOLD,
  };
}

/**
 * Compute a centroid (mean) vector from an array of vectors.
 * @param {Float64Array[]} vectors
 * @returns {Float64Array}
 */
export function centroid(vectors) {
  if (vectors.length === 0) return zeroVector();
  const dim = vectors[0].length;
  const sum = new Float64Array(dim);
  for (const v of vectors) {
    for (let i = 0; i < dim; i++) sum[i] += v[i];
  }
  for (let i = 0; i < dim; i++) sum[i] /= vectors.length;
  return sum;
}

/**
 * Simple in-memory vector store for embedding lookups.
 */
export class VectorMemory {
  constructor(dim = EMBEDDING_DIM) {
    this.dim = dim;
    /** @type {Map<string, { vector: Float64Array, metadata: object, timestamp: number }>} */
    this.store = new Map();
    /** @type {Float64Array|null} centroid tracking */
    this._centroid = null;
    this._centroidDirty = true;
  }

  /**
   * Store an embedding with metadata.
   * @param {string} id
   * @param {Float64Array} vector
   * @param {object} [metadata={}]
   */
  upsert(id, vector, metadata = {}) {
    this.store.set(id, { vector, metadata, timestamp: Date.now() });
    this._centroidDirty = true;
  }

  /**
   * Retrieve by ID.
   * @param {string} id
   * @returns {{ vector: Float64Array, metadata: object, timestamp: number }|null}
   */
  get(id) {
    return this.store.get(id) || null;
  }

  /**
   * Remove by ID.
   * @param {string} id
   * @returns {boolean}
   */
  remove(id) {
    const deleted = this.store.delete(id);
    if (deleted) this._centroidDirty = true;
    return deleted;
  }

  /**
   * Search for the top-k most relevant vectors.
   * @param {Float64Array} query
   * @param {number} [topK=5]
   * @returns {{ id: string, score: number, metadata: object }[]}
   */
  search(query, topK = 5) {
    const candidates = [];
    for (const [id, entry] of this.store) {
      candidates.push({ id, vector: entry.vector });
    }
    const ranked = rankByRelevance(query, candidates, topK);
    return ranked.map(r => ({
      id: r.id,
      score: r.score,
      metadata: this.store.get(r.id).metadata,
    }));
  }

  /**
   * Get the centroid of all stored vectors (cached).
   * @returns {Float64Array}
   */
  getCentroid() {
    if (!this._centroidDirty && this._centroid) return this._centroid;
    const vectors = [];
    for (const entry of this.store.values()) vectors.push(entry.vector);
    this._centroid = centroid(vectors);
    this._centroidDirty = false;
    return this._centroid;
  }

  /**
   * Detect drift of a given vector against the store centroid.
   * @param {Float64Array} current
   * @returns {{ drifted: boolean, similarity: number, threshold: number }}
   */
  detectDriftFromCentroid(current) {
    return detectDrift(this.getCentroid(), current);
  }

  /** Number of stored vectors. */
  get size() {
    return this.store.size;
  }

  /** Clear all stored vectors. */
  clear() {
    this.store.clear();
    this._centroid = null;
    this._centroidDirty = true;
  }
}

export const constants = {
  PHI,
  INV_PHI,
  EMBEDDING_DIM,
  DRIFT_THRESHOLD,
  RELEVANCE_FLOOR,
  SUPERPOSITION_SCALE,
};
