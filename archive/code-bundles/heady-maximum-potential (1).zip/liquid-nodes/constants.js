/**
 * constants.js — Sacred constants for Heady liquid node system.
 *
 * Imports core phi/Fibonacci constants from the canonical phi-math.js,
 * then adds liquid-node-specific configuration. Every numeric constant
 * derives from PHI (1.618) or Fibonacci. Zero magic numbers.
 *
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

import {
  PHI, PSI, PHI2, PHI3, FIB, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  PRESSURE_LEVELS, ALERT_THRESHOLDS,
  RESOURCE_WEIGHTS, SIZING, POOL_SIZES, RELEVANCE_GATES,
  phiBackoff, phiFusionWeights, phiResourceWeights,
} from '../shared/phi-math.js';

// Re-export canonical constants for consumers in liquid-nodes/
export {
  PHI, PSI, PHI2, PHI3, FIB, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  PRESSURE_LEVELS, ALERT_THRESHOLDS,
  RESOURCE_WEIGHTS, SIZING, POOL_SIZES, RELEVANCE_GATES,
  phiBackoff, phiFusionWeights, phiResourceWeights,
};

// Legacy aliases
export const PHI_SQ = PHI2;
export const PSI_SQ = PSI * PSI;

// ---------------------------------------------------------------------------
// Embedding dimensions
// ---------------------------------------------------------------------------

export const EMBEDDING_DIM = 384;
export const DIMENSIONS = [384, 1536];

// ---------------------------------------------------------------------------
// Pool allocations — aligned with canonical RESOURCE_WEIGHTS
// (Hot / Warm / Cold / Reserve / Governance)
// ---------------------------------------------------------------------------

export const POOL_ALLOCATIONS = Object.freeze({
  HOT:        RESOURCE_WEIGHTS.hot,        // 0.387 → ~34%
  WARM:       RESOURCE_WEIGHTS.warm,       // 0.239 → ~21%
  COLD:       RESOURCE_WEIGHTS.cold,       // 0.148 → ~13%
  RESERVE:    RESOURCE_WEIGHTS.reserve,    // 0.092 → ~8%
  GOVERNANCE: RESOURCE_WEIGHTS.governance, // 0.057 → ~5%
});

// Alias for backward compat
export const POOL_WEIGHTS = POOL_ALLOCATIONS;

// ---------------------------------------------------------------------------
// Concurrency and pool limits (all Fibonacci via SIZING)
// ---------------------------------------------------------------------------

export const MAX_CONCURRENT_TASKS = SIZING.SMALL_LIMIT;     // fib(7) = 13
export const MAX_BEES = SIZING.SLIDING_WINDOW;               // fib(9) = 34
export const MAX_SUBTASK_DEPTH = SIZING.FAILURE_THRESHOLD;   // fib(5) = 5
export const MAX_SUBTASKS_PER_LEVEL = SIZING.SMALL_LIMIT;    // fib(7) = 13
export const PARALLEL_BATCH_SIZE = SIZING.MAX_CONCURRENT;    // fib(6) = 8

// ---------------------------------------------------------------------------
// Timing constants (phi-scaled milliseconds)
// ---------------------------------------------------------------------------

export const CONSENSUS_TIMEOUT_MS = Math.round(fib(5) * 1000 * PHI);      // ~8090
export const LOAD_REBALANCE_INTERVAL_MS = Math.round(fib(6) * 1000 * PHI); // ~12944
export const HEALTH_CHECK_INTERVAL_MS = Math.round(fib(5) * 1000 * PHI);  // ~8090
export const CIRCUIT_BREAKER_RESET_MS = Math.round(fib(4) * 1000 * PHI);  // ~4854
export const RETRY_BASE_DELAY_MS = Math.round(1000 * PSI);                 // ~618
export const BACKOFF_MAX_MS = Math.round(1000 * PHI3);                     // ~4236

// ---------------------------------------------------------------------------
// Circuit breaker thresholds (Fibonacci)
// ---------------------------------------------------------------------------

export const CIRCUIT_BREAKER_THRESHOLD = fib(5);        // 5
export const CIRCUIT_BREAKER_HALF_OPEN_MAX = fib(4);    // 3

// ---------------------------------------------------------------------------
// Consensus
// ---------------------------------------------------------------------------

export const CONSENSUS_QUORUM_RATIO = PSI; // ~0.618 — need 61.8% agreement

// ---------------------------------------------------------------------------
// Bee types (canonical registry — all 33 from bee-registry)
// ---------------------------------------------------------------------------

export const BEE_TYPES = Object.freeze([
  'agents', 'auth-provider', 'auto-success', 'brain', 'config',
  'connectors', 'creative', 'deployment', 'device-provisioner',
  'documentation', 'engines', 'governance', 'health', 'intelligence',
  'lifecycle', 'mcp', 'memory', 'middleware', 'midi', 'ops',
  'orchestration', 'pipeline', 'providers', 'refactor', 'resilience',
  'routes', 'security', 'services', 'sync-projection', 'telemetry',
  'trading', 'vector-ops', 'vector-template',
]);

// ---------------------------------------------------------------------------
// Server
// ---------------------------------------------------------------------------

export const DEFAULT_PORT = 3300;

// ---------------------------------------------------------------------------
// HCFullPipeline stages
// ---------------------------------------------------------------------------

export const PIPELINE_STAGES = Object.freeze([
  'intake',
  'memory_recall',
  'context_assembly',
  'inference',
  'csl_gating',
  'refinement',
  'memory_write',
  'delivery',
]);

// ---------------------------------------------------------------------------
// Aggregate export
// ---------------------------------------------------------------------------

export const constants = Object.freeze({
  PHI, PSI, PHI2, PHI3,
  FIB, EMBEDDING_DIM, DIMENSIONS,
  CSL_THRESHOLDS, RELEVANCE_GATES, POOL_ALLOCATIONS, POOL_WEIGHTS,
  RESOURCE_WEIGHTS, SIZING, POOL_SIZES,
  MAX_CONCURRENT_TASKS, MAX_BEES, MAX_SUBTASK_DEPTH,
  MAX_SUBTASKS_PER_LEVEL, PARALLEL_BATCH_SIZE,
  CONSENSUS_TIMEOUT_MS, LOAD_REBALANCE_INTERVAL_MS,
  HEALTH_CHECK_INTERVAL_MS, CIRCUIT_BREAKER_RESET_MS,
  RETRY_BASE_DELAY_MS, BACKOFF_MAX_MS,
  CIRCUIT_BREAKER_THRESHOLD, CIRCUIT_BREAKER_HALF_OPEN_MAX,
  CONSENSUS_QUORUM_RATIO,
  BEE_TYPES, DEFAULT_PORT, PIPELINE_STAGES,
});
