/**
 * index.js — Express HTTP server for Heady liquid node system.
 *
 * Routes: /health, /status, /task, /task/batch, /task/complex,
 * /pipeline, /arena, /consensus, /bees, /bees/spawn.
 * Graceful shutdown on SIGTERM/SIGINT. Port 3300.
 */

import 'dotenv/config';
import express from 'express';
import { DEFAULT_PORT, PHI } from './constants.js';
import { TelemetryBus } from './telemetry-bus.js';
import { LiquidConductor } from './liquid-conductor.js';

const PORT = parseInt(process.env.PORT, 10) || DEFAULT_PORT;
const app = express();
app.use(express.json());

// ---------------------------------------------------------------------------
// Initialize system
// ---------------------------------------------------------------------------

const telemetry = new TelemetryBus({
  service: 'liquid-nodes',
  level: process.env.LOG_LEVEL || 'info',
  pretty: process.env.NODE_ENV !== 'production',
});

const conductor = new LiquidConductor({ telemetry });

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

app.get('/health', (_req, res) => {
  const health = telemetry.getHealthReport();
  const status = health.overall === 'healthy' ? 200 : 503;
  res.status(status).json({ status: health.overall, components: health.components, uptime: process.uptime() });
});

app.get('/status', (_req, res) => {
  res.json(conductor.getStatus());
});

app.post('/task', async (req, res) => {
  try {
    const result = await conductor.route(req.body);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/task/batch', async (req, res) => {
  try {
    const { tasks } = req.body;
    if (!Array.isArray(tasks)) return res.status(400).json({ error: 'tasks must be an array' });
    const results = await conductor.swarm.submitBatch(tasks);
    res.json({ results });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/task/complex', async (req, res) => {
  try {
    const result = await conductor.swarm.submitComplex(req.body);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/pipeline', async (req, res) => {
  try {
    const result = await conductor.executePipeline(req.body);
    res.json({ result: result.result, durationMs: result.durationMs });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/arena', async (req, res) => {
  try {
    const { task, contestants } = req.body;
    const result = await conductor.runArena(task, contestants);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/consensus', async (req, res) => {
  try {
    const { question } = req.body;
    const result = await conductor.swarm.consensus(question, async (bee, q) => {
      const exec = await bee.execute({ id: 'consensus-vote', prompt: q.prompt, options: q.options });
      return exec.success ? (exec.result?.vote || q.options?.[0] || 'abstain') : 'abstain';
    });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/bees', (_req, res) => {
  res.json({
    bees: conductor.factory.getActiveBees().map(b => b.report()),
    status: conductor.factory.getStatus(),
  });
});

app.post('/bees/spawn', async (req, res) => {
  try {
    const { type } = req.body;
    if (!type) return res.status(400).json({ error: 'type is required' });
    const bee = await conductor.factory.spawn(type);
    res.json({ beeId: bee.id, type: bee.type, state: bee.state });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ---------------------------------------------------------------------------
// Startup and graceful shutdown
// ---------------------------------------------------------------------------

let server;

async function startup() {
  telemetry.start();
  await conductor.start();

  server = app.listen(PORT, () => {
    telemetry.info('server.started', { port: PORT, pid: process.pid });
  });

  server.keepAliveTimeout = Math.round(5000 * PHI); // ~8090ms
}

async function shutdown(signal) {
  telemetry.info('server.shutting_down', { signal });

  if (server) {
    await new Promise((resolve) => server.close(resolve));
  }

  await conductor.stop();
  telemetry.stop();
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

startup().catch((err) => {
  telemetry.error('server.startupFailed', { error: err.message });
  process.exit(1);
});

export { app, conductor, telemetry };
