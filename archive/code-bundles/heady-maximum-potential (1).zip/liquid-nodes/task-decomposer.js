/**
 * task-decomposer.js — Task decomposition engine.
 *
 * LLM-based subtask generation, cosine similarity scoring against swarm capabilities,
 * topological sort with cycle detection, adaptive parallel execution, and progress tracking.
 * All constants phi-scaled and Fibonacci-derived.
 */

import { randomUUID } from 'crypto';
import {
  PHI, PSI, EMBEDDING_DIM,
  MAX_SUBTASK_DEPTH, MAX_SUBTASKS_PER_LEVEL, PARALLEL_BATCH_SIZE,
} from './constants.js';
import { cosineSimilarity, randomUnitVector } from './vector-space-ops.js';

const CAPABILITY_MATCH_THRESHOLD = PSI * PSI; // ~0.382

// ---------------------------------------------------------------------------
// Topological sort with cycle detection (Kahn's algorithm)
// ---------------------------------------------------------------------------

/**
 * @param {Map<string, string[]>} adjacency — node -> dependencies (predecessors)
 * @param {Set<string>} nodeIds
 * @returns {{ sorted: string[], levels: string[][], hasCycle: boolean, cycleNodes: string[] }}
 */
export function topologicalSort(adjacency, nodeIds) {
  const inDegree = new Map();
  const successors = new Map();

  for (const id of nodeIds) {
    inDegree.set(id, 0);
    successors.set(id, []);
  }

  for (const [id, deps] of adjacency) {
    const validDeps = deps.filter(d => nodeIds.has(d));
    inDegree.set(id, validDeps.length);
    for (const dep of validDeps) {
      successors.get(dep).push(id);
    }
  }

  const sorted = [];
  const levels = [];
  let currentLevel = [];

  for (const [id, deg] of inDegree) {
    if (deg === 0) currentLevel.push(id);
  }

  while (currentLevel.length > 0) {
    levels.push([...currentLevel]);
    sorted.push(...currentLevel);

    const nextLevel = [];
    for (const id of currentLevel) {
      for (const successor of successors.get(id)) {
        const newDeg = inDegree.get(successor) - 1;
        inDegree.set(successor, newDeg);
        if (newDeg === 0) nextLevel.push(successor);
      }
    }
    currentLevel = nextLevel;
  }

  const hasCycle = sorted.length < nodeIds.size;
  const cycleNodes = hasCycle
    ? Array.from(nodeIds).filter(id => !sorted.includes(id))
    : [];

  return { sorted, levels, hasCycle, cycleNodes };
}

// ---------------------------------------------------------------------------
// Capability matching via cosine similarity
// ---------------------------------------------------------------------------

/**
 * Score how well a bee's capabilities match a task's requirements.
 * @param {object} task — .embedding, .requiredCapabilities
 * @param {object} bee — .capabilityVector, .capabilities
 * @returns {{ score: number, semanticScore: number, tagOverlap: number }}
 */
export function scoreCapabilityMatch(task, bee) {
  let semanticScore = 0;
  if (task.embedding && bee.capabilityVector) {
    semanticScore = cosineSimilarity(task.embedding, bee.capabilityVector);
  }

  let tagOverlap = 0;
  if (task.requiredCapabilities?.length > 0 && bee.capabilities) {
    const taskSet = new Set(task.requiredCapabilities);
    const matched = bee.capabilities.filter(c => taskSet.has(c)).length;
    tagOverlap = matched / task.requiredCapabilities.length;
  }

  // Phi-weighted blend: semantic gets the golden ratio weight
  const score = semanticScore * PSI + tagOverlap * (1 - PSI);
  return { score, semanticScore, tagOverlap };
}

/**
 * Find best-matching bees for a task.
 * @param {object} task
 * @param {import('./base-bee.js').BaseHeadyBee[]} bees
 * @param {number} [topK=3]
 * @returns {{ bee: object, score: number }[]}
 */
export function findBestMatches(task, bees, topK = 3) {
  return bees
    .filter(b => b.state === 'READY')
    .map(bee => ({ bee, score: scoreCapabilityMatch(task, bee).score }))
    .filter(m => m.score >= CAPABILITY_MATCH_THRESHOLD)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK);
}

// ---------------------------------------------------------------------------
// Keyword-to-embedding approximation
// ---------------------------------------------------------------------------

function keywordsToEmbedding(keywords) {
  const vec = new Float64Array(EMBEDDING_DIM);
  for (const kw of keywords) {
    let hash = 0;
    for (let i = 0; i < kw.length; i++) {
      hash = ((hash << 5) - hash + kw.charCodeAt(i)) | 0;
    }
    const seed = Math.abs(hash);
    for (let i = 0; i < EMBEDDING_DIM; i++) {
      const angle = (seed * (i + 1) * PHI) % (2 * Math.PI);
      vec[i] += Math.cos(angle) / keywords.length;
    }
  }
  let norm = 0;
  for (let i = 0; i < EMBEDDING_DIM; i++) norm += vec[i] * vec[i];
  norm = Math.sqrt(norm);
  if (norm > 0) {
    for (let i = 0; i < EMBEDDING_DIM; i++) vec[i] /= norm;
  }
  return vec;
}

// ---------------------------------------------------------------------------
// TaskDecomposer
// ---------------------------------------------------------------------------

export class TaskDecomposer {
  /**
   * @param {object} [opts={}]
   * @param {import('./telemetry-bus.js').TelemetryBus} [opts.telemetry]
   * @param {number} [opts.maxDepth=MAX_SUBTASK_DEPTH]
   * @param {number} [opts.maxSubtasks=MAX_SUBTASKS_PER_LEVEL]
   */
  constructor(opts = {}) {
    this.telemetry = opts.telemetry || null;
    this.maxDepth = opts.maxDepth || MAX_SUBTASK_DEPTH;
    this.maxSubtasks = opts.maxSubtasks || MAX_SUBTASKS_PER_LEVEL;
    this._taskMap = new Map();
    this._progressMap = new Map();
  }

  /**
   * Decompose a task into a DAG of subtasks.
   * @param {object} taskSpec
   * @param {(spec: object) => Promise<object[]>} [decomposeFn]
   * @returns {Promise<{ tasks: object[], executionLevels: string[][], adjacency: Map }>}
   */
  async decompose(taskSpec, decomposeFn) {
    const rootId = taskSpec.id || randomUUID();
    this._taskMap.clear();

    let subtaskSpecs;
    if (taskSpec.subtasks?.length > 0) {
      subtaskSpecs = taskSpec.subtasks;
    } else if (typeof decomposeFn === 'function') {
      subtaskSpecs = await decomposeFn(taskSpec);
    } else {
      subtaskSpecs = [{
        description: taskSpec.description,
        capabilities: taskSpec.capabilities || [],
        dependencies: [],
      }];
    }

    subtaskSpecs = subtaskSpecs.slice(0, this.maxSubtasks);

    const tasks = [];
    const idByIndex = new Map();

    for (let i = 0; i < subtaskSpecs.length; i++) {
      const spec = subtaskSpecs[i];
      const id = spec.id || randomUUID();
      idByIndex.set(i, id);

      const capabilities = spec.capabilities || [];
      const embedding = spec.embedding ||
        keywordsToEmbedding(capabilities.length > 0 ? capabilities : [spec.description || 'task']);

      const subtask = {
        id, parentId: rootId,
        description: spec.description || `Subtask ${i}`,
        dependencies: [],
        requiredCapabilities: capabilities,
        embedding, status: 'pending', result: null,
        depth: spec.depth || 0,
        estimatedComplexity: spec.complexity ?? (PSI * Math.random() + PSI * PSI),
      };

      tasks.push(subtask);
      this._taskMap.set(id, subtask);
    }

    // Resolve dependencies
    for (let i = 0; i < subtaskSpecs.length; i++) {
      const deps = subtaskSpecs[i].dependencies || [];
      tasks[i].dependencies = deps
        .map(d => typeof d === 'number' ? idByIndex.get(d) || d : d)
        .filter(d => this._taskMap.has(d));
    }

    // Build adjacency and sort
    const adjacency = new Map();
    const nodeIds = new Set();
    for (const task of tasks) {
      nodeIds.add(task.id);
      adjacency.set(task.id, task.dependencies);
    }

    let { sorted, levels, hasCycle, cycleNodes } = topologicalSort(adjacency, nodeIds);

    if (hasCycle) {
      if (this.telemetry) this.telemetry.warn('decomposer.cycleDetected', { rootId, cycleNodes });
      for (const nodeId of cycleNodes) {
        const task = this._taskMap.get(nodeId);
        if (task) task.dependencies = task.dependencies.filter(d => !cycleNodes.includes(d));
        adjacency.set(nodeId, this._taskMap.get(nodeId)?.dependencies || []);
      }
      const fixed = topologicalSort(adjacency, nodeIds);
      sorted = fixed.sorted;
      levels = fixed.levels;
    }

    const sortedTasks = sorted.map(id => this._taskMap.get(id)).filter(Boolean);
    this._progressMap.set(rootId, { completed: 0, total: sortedTasks.length, failed: 0 });

    if (this.telemetry) {
      this.telemetry.info('decomposer.decomposed', {
        rootId, totalSubtasks: sortedTasks.length, parallelLevels: levels.length,
      });
    }

    return { tasks: sortedTasks, executionLevels: levels, adjacency };
  }

  /**
   * Execute a decomposed task graph with adaptive parallelism.
   * @param {object} decomposition
   * @param {(task: object) => Promise<*>} executeFn
   * @param {object} [opts={}]
   * @returns {Promise<{ results: Map, failed: string[], completed: string[] }>}
   */
  async executeGraph(decomposition, executeFn, opts = {}) {
    const concurrency = opts.concurrency || PARALLEL_BATCH_SIZE;
    const failFast = opts.failFast || false;
    const results = new Map();
    const failed = [];
    const completed = [];
    const rootId = decomposition.tasks[0]?.parentId;

    for (const level of decomposition.executionLevels) {
      if (failFast && failed.length > 0) break;

      for (let i = 0; i < level.length; i += concurrency) {
        const batch = level.slice(i, i + concurrency);
        const promises = batch.map(async (taskId) => {
          const task = this._taskMap.get(taskId);
          if (!task) return;

          if (failFast && task.dependencies.some(d => failed.includes(d))) {
            task.status = 'skipped';
            return;
          }

          task.status = 'in_progress';
          this._updateProgress(rootId, 'in_progress');

          try {
            const result = await executeFn(task);
            task.status = 'completed';
            task.result = result;
            results.set(taskId, result);
            completed.push(taskId);
            this._updateProgress(rootId, 'completed');
          } catch (err) {
            task.status = 'failed';
            task.result = { error: err.message };
            failed.push(taskId);
            this._updateProgress(rootId, 'failed');
          }
        });
        await Promise.allSettled(promises);
      }
    }

    return { results, failed, completed };
  }

  _updateProgress(rootId, event) {
    const p = this._progressMap.get(rootId);
    if (!p) return;
    if (event === 'completed') p.completed++;
    else if (event === 'failed') p.failed++;
  }

  getProgress(rootId) {
    const p = this._progressMap.get(rootId);
    if (!p) return null;
    return { ...p, pct: p.total > 0 ? Math.round((p.completed / p.total) * 100) : 0 };
  }

  getTask(taskId) { return this._taskMap.get(taskId) || null; }
  getAllTasks() { return Array.from(this._taskMap.values()); }
}

export const constants = {
  PHI, PSI, MAX_SUBTASK_DEPTH, MAX_SUBTASKS_PER_LEVEL,
  CAPABILITY_MATCH_THRESHOLD, PARALLEL_BATCH_SIZE,
};
