/**
 * swarm-coordinator.js — Swarm intelligence for Heady liquid node system.
 *
 * Concurrent execution pools, semantic relevance gates for task routing,
 * DAG-based task distribution with topological sort, phi-weighted load
 * balancing, consensus protocol, and equal-status workers.
 *
 * NO priority enums. Routing is by capability matching (cosine similarity).
 */

import { randomUUID } from 'crypto';
import {
  PHI, PSI,
  MAX_CONCURRENT_TASKS, CONSENSUS_QUORUM_RATIO,
  CONSENSUS_TIMEOUT_MS, LOAD_REBALANCE_INTERVAL_MS,
} from './constants.js';
import { cosineSimilarity } from './vector-space-ops.js';
import { BackpressureManager, retryWithBackoff } from './resilience-layer.js';
import { TaskDecomposer, scoreCapabilityMatch, findBestMatches } from './task-decomposer.js';

const RELEVANCE_GATE_THRESHOLD = PSI * PSI; // ~0.382

// ---------------------------------------------------------------------------
// Execution Pool
// ---------------------------------------------------------------------------

class ExecutionPool {
  constructor(opts = {}) {
    this.maxConcurrent = opts.maxConcurrent || MAX_CONCURRENT_TASKS;
    this._active = new Map();
    this._backpressure = new BackpressureManager({ maxQueueDepth: this.maxConcurrent * 2 });
  }

  get activeCount() { return this._active.size; }
  get hasCapacity() { return this._active.size < this.maxConcurrent; }

  async submit(taskId, executeFn) {
    const admission = this._backpressure.admit();
    if (!admission.admitted) {
      throw new Error(`Execution pool at capacity (pressure: ${admission.levelName})`);
    }

    const promise = executeFn().finally(() => {
      this._active.delete(taskId);
      this._backpressure.release();
    });

    this._active.set(taskId, promise);
    return promise;
  }

  async drain() {
    await Promise.allSettled(Array.from(this._active.values()));
  }

  getStatus() {
    return {
      active: this._active.size,
      maxConcurrent: this.maxConcurrent,
      backpressure: this._backpressure.getStatus(),
    };
  }
}

// ---------------------------------------------------------------------------
// SwarmCoordinator
// ---------------------------------------------------------------------------

export class SwarmCoordinator {
  /**
   * @param {object} [opts={}]
   * @param {import('./bee-factory.js').BeeFactory} opts.factory
   * @param {import('./telemetry-bus.js').TelemetryBus} [opts.telemetry]
   * @param {number} [opts.maxConcurrent=MAX_CONCURRENT_TASKS]
   */
  constructor(opts = {}) {
    this.factory = opts.factory;
    this.telemetry = opts.telemetry || null;
    this.decomposer = new TaskDecomposer({ telemetry: this.telemetry });
    this._pool = new ExecutionPool({ maxConcurrent: opts.maxConcurrent || MAX_CONCURRENT_TASKS });
    this._taskLog = new Map();
    this._loadMap = new Map();
    this._rebalanceInterval = null;
    this._running = false;
  }

  // -------------------------------------------------------------------------
  // Lifecycle
  // -------------------------------------------------------------------------

  start() {
    if (this._running) return;
    this._running = true;
    this._rebalanceInterval = setInterval(() => this._rebalanceLoad(), LOAD_REBALANCE_INTERVAL_MS);
    this._rebalanceInterval.unref();
    if (this.telemetry) this.telemetry.info('swarm.started', { maxConcurrent: this._pool.maxConcurrent });
  }

  async stop() {
    if (!this._running) return;
    this._running = false;
    if (this._rebalanceInterval) {
      clearInterval(this._rebalanceInterval);
      this._rebalanceInterval = null;
    }
    await this._pool.drain();
    if (this.telemetry) this.telemetry.info('swarm.stopped');
  }

  // -------------------------------------------------------------------------
  // Semantic relevance gate
  // -------------------------------------------------------------------------

  relevanceGate(task) {
    const bees = this.factory.getActiveBees();
    if (bees.length === 0) return { passesGate: false, bestMatch: null };

    const matches = findBestMatches(task, bees, 1);
    if (matches.length === 0 || matches[0].score < RELEVANCE_GATE_THRESHOLD) {
      return { passesGate: false, bestMatch: null };
    }
    return { passesGate: true, bestMatch: matches[0] };
  }

  // -------------------------------------------------------------------------
  // Task routing via capability matching
  // -------------------------------------------------------------------------

  routeTask(task) {
    const bees = this.factory.getActiveBees().filter(b => b.state === 'READY');
    if (bees.length === 0) return null;

    const scored = bees.map(bee => {
      const { score } = scoreCapabilityMatch(task, bee);
      const load = this._loadMap.get(bee.id) || 0;
      const maxLoad = this._pool.maxConcurrent;
      const loadRatio = load / Math.max(maxLoad, 1);
      const loadPenalty = loadRatio * PSI;
      const adjustedScore = Math.max(0, score - loadPenalty);
      return { bee, score: adjustedScore, rawScore: score, load };
    });

    scored.sort((a, b) => b.score - a.score);
    if (scored.length === 0 || scored[0].score < RELEVANCE_GATE_THRESHOLD) return null;
    return { beeId: scored[0].bee.id, score: scored[0].score };
  }

  // -------------------------------------------------------------------------
  // Task submission
  // -------------------------------------------------------------------------

  async submitTask(taskSpec) {
    const taskId = taskSpec.id || randomUUID();
    const task = {
      id: taskId,
      description: taskSpec.description || '',
      requiredCapabilities: taskSpec.requiredCapabilities || [],
      embedding: taskSpec.embedding || null,
      payload: taskSpec.payload || {},
      assignedBeeId: null,
      status: 'queued',
      result: null,
      submittedAt: Date.now(),
    };

    this._taskLog.set(taskId, task);

    const route = this.routeTask(task);
    if (!route) {
      task.status = 'failed';
      task.result = { error: 'No suitable bee found for task' };
      if (this.telemetry) this.telemetry.warn('swarm.routeFailed', { taskId });
      return { taskId, beeId: null, result: task.result, durationMs: 0, success: false };
    }

    task.assignedBeeId = route.beeId;
    task.status = 'routed';

    const bee = this.factory.getBee(route.beeId);
    if (!bee) {
      task.status = 'failed';
      task.result = { error: `Bee ${route.beeId} no longer available` };
      return { taskId, beeId: route.beeId, result: task.result, durationMs: 0, success: false };
    }

    this._loadMap.set(bee.id, (this._loadMap.get(bee.id) || 0) + 1);

    try {
      task.status = 'executing';
      task.startedAt = Date.now();

      const executionResult = await this._pool.submit(taskId, () =>
        bee.execute({ id: taskId, ...task.payload, executor: taskSpec.executor })
      );

      task.completedAt = Date.now();
      const durationMs = task.completedAt - task.startedAt;

      if (executionResult.success) {
        task.status = 'completed';
        task.result = executionResult.result;
      } else {
        task.status = 'failed';
        task.result = executionResult;
      }

      if (this.telemetry) this.telemetry.recordMetric('swarm.taskDurationMs', durationMs);
      return { taskId, beeId: bee.id, result: task.result, durationMs, success: executionResult.success };
    } catch (err) {
      task.status = 'failed';
      task.completedAt = Date.now();
      task.result = { error: err.message };
      return { taskId, beeId: bee.id, result: task.result, durationMs: Date.now() - task.startedAt, success: false };
    } finally {
      const currentLoad = this._loadMap.get(bee.id) || 1;
      this._loadMap.set(bee.id, Math.max(0, currentLoad - 1));
    }
  }

  async submitBatch(taskSpecs) {
    return Promise.all(taskSpecs.map(spec => this.submitTask(spec)));
  }

  async submitComplex(taskSpec, decomposeFn) {
    const rootId = taskSpec.id || randomUUID();
    taskSpec.id = rootId;

    const decomposition = await this.decomposer.decompose(taskSpec, decomposeFn);
    const graphResult = await this.decomposer.executeGraph(decomposition, async (subtask) => {
      const result = await this.submitTask({
        id: subtask.id,
        description: subtask.description,
        requiredCapabilities: subtask.requiredCapabilities,
        embedding: subtask.embedding,
        payload: { subtask: true, parentId: rootId },
      });
      if (!result.success) throw new Error(result.result?.error || 'Subtask failed');
      return result.result;
    });

    return {
      rootId,
      results: graphResult.results,
      completed: graphResult.completed,
      failed: graphResult.failed,
    };
  }

  // -------------------------------------------------------------------------
  // Consensus protocol
  // -------------------------------------------------------------------------

  async consensus(question, voteFn) {
    const bees = this.factory.getActiveBees().filter(b => b.state === 'READY');
    if (bees.length === 0) return { reached: false, value: null, agreement: 0, totalVoters: 0 };

    const quorum = Math.ceil(bees.length * CONSENSUS_QUORUM_RATIO);

    const votes = await Promise.all(bees.map(async (bee) => {
      try {
        const vote = await Promise.race([
          voteFn(bee, question),
          new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), CONSENSUS_TIMEOUT_MS)),
        ]);
        return { beeId: bee.id, vote, valid: true };
      } catch {
        return { beeId: bee.id, vote: null, valid: false };
      }
    }));

    const validVotes = votes.filter(v => v.valid);
    const tally = new Map();
    for (const v of validVotes) tally.set(v.vote, (tally.get(v.vote) || 0) + 1);

    let bestOption = null, bestCount = 0;
    for (const [option, count] of tally) {
      if (count > bestCount) { bestCount = count; bestOption = option; }
    }

    const agreement = validVotes.length > 0 ? bestCount / validVotes.length : 0;
    return { reached: bestCount >= quorum, value: bestOption, agreement, totalVoters: validVotes.length };
  }

  // -------------------------------------------------------------------------
  // Load balancing
  // -------------------------------------------------------------------------

  _rebalanceLoad() {
    const bees = this.factory.getActiveBees();
    if (bees.length === 0) return;

    let totalLoad = 0;
    for (const [, load] of this._loadMap) totalLoad += load;
    const idealLoad = totalLoad / bees.length;

    let maxDeviation = 0;
    for (const bee of bees) {
      const deviation = Math.abs((this._loadMap.get(bee.id) || 0) - idealLoad);
      if (deviation > maxDeviation) maxDeviation = deviation;
    }

    if (this.telemetry && maxDeviation > idealLoad * PHI) {
      this.telemetry.warn('swarm.loadImbalance', { totalLoad, beeCount: bees.length, maxDeviation });
    }
  }

  // -------------------------------------------------------------------------
  // Status
  // -------------------------------------------------------------------------

  getStatus() {
    const bees = this.factory.getActiveBees();
    let queued = 0, executing = 0, completed = 0, failed = 0;
    for (const task of this._taskLog.values()) {
      if (task.status === 'queued' || task.status === 'routed') queued++;
      else if (task.status === 'executing') executing++;
      else if (task.status === 'completed') completed++;
      else if (task.status === 'failed') failed++;
    }

    return {
      running: this._running,
      bees: {
        total: bees.length,
        ready: bees.filter(b => b.state === 'READY').length,
        executing: bees.filter(b => b.state === 'EXECUTING').length,
      },
      tasks: { queued, executing, completed, failed, total: this._taskLog.size },
      pool: this._pool.getStatus(),
    };
  }

  getTask(taskId) { return this._taskLog.get(taskId); }
  getAllTasks() { return Array.from(this._taskLog.values()); }

  clearHistory() {
    let cleared = 0;
    for (const [id, task] of this._taskLog) {
      if (task.status === 'completed' || task.status === 'failed') {
        this._taskLog.delete(id);
        cleared++;
      }
    }
    return cleared;
  }
}

export const constants = {
  PHI, PSI, MAX_CONCURRENT_TASKS, CONSENSUS_QUORUM_RATIO,
  CONSENSUS_TIMEOUT_MS, LOAD_REBALANCE_INTERVAL_MS, RELEVANCE_GATE_THRESHOLD,
};
