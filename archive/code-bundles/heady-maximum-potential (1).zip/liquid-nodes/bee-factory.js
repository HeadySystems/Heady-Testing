/**
 * bee-factory.js — Dynamic bee creation from the 33-type registry.
 *
 * Creates any bee type with versioned configurations, phi-scaled resource allocation,
 * and full lifecycle management: spawn() -> execute() -> report() -> retire().
 */

import { randomUUID } from 'crypto';
import { PHI, PSI, FIB, EMBEDDING_DIM, BEE_TYPES, MAX_BEES } from './constants.js';
import { BaseHeadyBee, STATES } from './base-bee.js';
import { randomUnitVector } from './vector-space-ops.js';

/**
 * HeadyBee — Concrete bee spawned by the factory.
 * Extends BaseHeadyBee with type-specific capability vectors.
 */
export class HeadyBee extends BaseHeadyBee {
  /**
   * @param {object} opts
   * @param {string} opts.type
   * @param {string[]} opts.capabilities
   * @param {object} opts.config
   * @param {import('./telemetry-bus.js').TelemetryBus} [opts.telemetry]
   */
  constructor(opts) {
    super({
      type: opts.type,
      capabilities: opts.capabilities,
      capabilityVector: opts.capabilityVector || buildCapabilityVector(opts.capabilities),
      telemetry: opts.telemetry,
    });
    this.config = opts.config || {};
    this.version = opts.config?.version || '1.0.0';
  }
}

/**
 * Deterministic capability vector from keyword hashes.
 * @param {string[]} capabilities
 * @returns {Float64Array}
 */
function buildCapabilityVector(capabilities) {
  if (!capabilities || capabilities.length === 0) return randomUnitVector(EMBEDDING_DIM);

  const vec = new Float64Array(EMBEDDING_DIM);
  for (const kw of capabilities) {
    let hash = 0;
    for (let i = 0; i < kw.length; i++) {
      hash = ((hash << 5) - hash + kw.charCodeAt(i)) | 0;
    }
    const seed = Math.abs(hash);
    for (let i = 0; i < EMBEDDING_DIM; i++) {
      const angle = (seed * (i + 1) * PHI) % (2 * Math.PI);
      vec[i] += Math.cos(angle) / capabilities.length;
    }
  }
  // Normalize
  let norm = 0;
  for (let i = 0; i < EMBEDDING_DIM; i++) norm += vec[i] * vec[i];
  norm = Math.sqrt(norm);
  if (norm > 0) {
    for (let i = 0; i < EMBEDDING_DIM; i++) vec[i] /= norm;
  }
  return vec;
}

/**
 * Default bee type configurations — capabilities, resource weight, version.
 */
function buildTypeRegistry() {
  const registry = new Map();

  const typeConfigs = [
    { type: 'research', capabilities: ['research', 'search', 'analysis'], weight: PHI },
    { type: 'analysis', capabilities: ['analysis', 'data', 'statistics'], weight: PHI },
    { type: 'creative', capabilities: ['creative', 'generation', 'writing'], weight: PSI },
    { type: 'technical', capabilities: ['technical', 'coding', 'engineering'], weight: PHI },
    { type: 'memory', capabilities: ['memory', 'storage', 'recall'], weight: PSI },
    { type: 'planning', capabilities: ['planning', 'strategy', 'scheduling'], weight: PSI },
    { type: 'coding', capabilities: ['coding', 'programming', 'development'], weight: PHI },
    { type: 'review', capabilities: ['review', 'quality', 'validation'], weight: PSI },
    { type: 'testing', capabilities: ['testing', 'qa', 'verification'], weight: PSI },
    { type: 'documentation', capabilities: ['documentation', 'writing', 'explanation'], weight: PSI * PSI },
    { type: 'refactor', capabilities: ['refactor', 'optimization', 'simplification'], weight: PSI },
    { type: 'debug', capabilities: ['debug', 'troubleshoot', 'diagnosis'], weight: PHI },
    { type: 'architecture', capabilities: ['architecture', 'design', 'patterns'], weight: PHI },
    { type: 'integration', capabilities: ['integration', 'api', 'connectivity'], weight: PSI },
    { type: 'monitoring', capabilities: ['monitoring', 'observability', 'alerting'], weight: PSI },
    { type: 'security', capabilities: ['security', 'auth', 'encryption'], weight: PHI },
    { type: 'performance', capabilities: ['performance', 'optimization', 'profiling'], weight: PHI },
    { type: 'data', capabilities: ['data', 'pipeline', 'transformation'], weight: PSI },
    { type: 'visualization', capabilities: ['visualization', 'charts', 'display'], weight: PSI * PSI },
    { type: 'deployment', capabilities: ['deployment', 'ci', 'infrastructure'], weight: PSI },
    { type: 'communication', capabilities: ['communication', 'messaging', 'notification'], weight: PSI * PSI },
    { type: 'synthesis', capabilities: ['synthesis', 'aggregation', 'combination'], weight: PSI },
    { type: 'evaluation', capabilities: ['evaluation', 'scoring', 'assessment'], weight: PSI },
    { type: 'optimization', capabilities: ['optimization', 'tuning', 'improvement'], weight: PHI },
    { type: 'governance', capabilities: ['governance', 'policy', 'compliance'], weight: PSI * PSI },
    { type: 'learning', capabilities: ['learning', 'training', 'adaptation'], weight: PSI },
    { type: 'teaching', capabilities: ['teaching', 'explanation', 'tutorial'], weight: PSI * PSI },
    { type: 'translation', capabilities: ['translation', 'conversion', 'mapping'], weight: PSI },
    { type: 'summarization', capabilities: ['summarization', 'compression', 'extraction'], weight: PSI },
    { type: 'extraction', capabilities: ['extraction', 'parsing', 'mining'], weight: PSI },
    { type: 'classification', capabilities: ['classification', 'categorization', 'labeling'], weight: PSI },
    { type: 'generation', capabilities: ['generation', 'creation', 'synthesis'], weight: PHI },
    { type: 'validation', capabilities: ['validation', 'verification', 'checking'], weight: PSI },
  ];

  for (const cfg of typeConfigs) {
    registry.set(cfg.type, {
      type: cfg.type,
      capabilities: cfg.capabilities,
      weight: cfg.weight,
      version: '1.0.0',
    });
  }

  return registry;
}

/**
 * BeeFactory — Creates, tracks, and manages bees from the type registry.
 */
export class BeeFactory {
  /**
   * @param {object} [opts={}]
   * @param {import('./telemetry-bus.js').TelemetryBus} [opts.telemetry]
   * @param {number} [opts.maxBees=MAX_BEES]
   */
  constructor(opts = {}) {
    this.telemetry = opts.telemetry || null;
    this.maxBees = opts.maxBees || MAX_BEES;

    /** @type {Map<string, object>} type -> config */
    this._registry = buildTypeRegistry();

    /** @type {Map<string, HeadyBee>} beeId -> bee */
    this._bees = new Map();
  }

  /**
   * Create and spawn a bee of the given type.
   * @param {string} type
   * @param {object} [overrides={}]
   * @returns {Promise<HeadyBee>}
   */
  async spawn(type, overrides = {}) {
    const config = this._registry.get(type);
    if (!config) {
      throw new Error(`Unknown bee type: ${type}. Available: ${Array.from(this._registry.keys()).join(', ')}`);
    }
    if (this._bees.size >= this.maxBees) {
      throw new Error(`Max bees reached (${this.maxBees})`);
    }

    const bee = new HeadyBee({
      type: config.type,
      capabilities: overrides.capabilities || config.capabilities,
      config: { ...config, ...overrides },
      telemetry: this.telemetry,
    });

    await bee.spawn();
    this._bees.set(bee.id, bee);

    if (this.telemetry) {
      this.telemetry.info('factory.beeSpawned', { beeId: bee.id, type, total: this._bees.size });
    }

    return bee;
  }

  /**
   * Get a bee by ID.
   * @param {string} beeId
   * @returns {HeadyBee|undefined}
   */
  getBee(beeId) {
    return this._bees.get(beeId);
  }

  /**
   * Get all active (non-retired) bees.
   * @returns {HeadyBee[]}
   */
  getActiveBees() {
    return Array.from(this._bees.values()).filter(b => b.state !== 'RETIRED');
  }

  /**
   * Get bees of a specific type.
   * @param {string} type
   * @returns {HeadyBee[]}
   */
  getBeesByType(type) {
    return this.getActiveBees().filter(b => b.type === type);
  }

  /**
   * Retire a bee by ID.
   * @param {string} beeId
   */
  async retire(beeId) {
    const bee = this._bees.get(beeId);
    if (!bee) return;
    await bee.retire();
    this._bees.delete(beeId);
  }

  /**
   * Retire all bees.
   */
  async retireAll() {
    const promises = [];
    for (const bee of this._bees.values()) {
      promises.push(bee.retire());
    }
    await Promise.allSettled(promises);
    this._bees.clear();
  }

  /**
   * Get health reports from all active bees.
   * @returns {object[]}
   */
  getAllHealthReports() {
    return this.getActiveBees().map(b => b.report());
  }

  /**
   * Get registered bee types.
   * @returns {string[]}
   */
  getRegisteredTypes() {
    return Array.from(this._registry.keys());
  }

  /**
   * Get factory status.
   * @returns {object}
   */
  getStatus() {
    const active = this.getActiveBees();
    return {
      totalBees: this._bees.size,
      activeBees: active.length,
      maxBees: this.maxBees,
      registeredTypes: this._registry.size,
      byType: Object.fromEntries(
        Array.from(this._registry.keys()).map(t => [t, this.getBeesByType(t).length])
      ),
    };
  }
}
