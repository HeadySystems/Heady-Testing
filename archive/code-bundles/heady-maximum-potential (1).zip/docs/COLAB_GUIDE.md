# Colab Pro+ Setup Guide

> Three-Runtime Partition for Heady Sovereign AI Compute

---

## Overview

Heady uses Google Colab Pro+ to host its three core compute runtimes. Each runtime runs in a dedicated notebook session with a GPU allocation and a persistent ngrok (or Cloudflare Tunnel) endpoint that the Auth Gateway uses for internal routing.

**Prerequisites:**
- Google Colab Pro+ subscription (required for concurrent runtimes)
- ngrok account (or Cloudflare Tunnel) for stable tunnel URLs
- `HEADY_SECRET` — shared HMAC secret (generated during setup)
- `RUNTIME_TOKEN` — per-runtime RS256 JWT issued by Auth Gateway

---

## Runtime 1 — Vector Brain

### Purpose

Runtime 1 hosts the embedding engine and vector memory layer. It handles:
- Text → embedding conversion (sentence-transformers)
- FAISS vector similarity search
- CSL (Cognitive Semantic Logic) gate operations
- Semantic drift detection
- Graph topology services

### Hardware Requirements

| Requirement | Minimum | Recommended |
|---|---|---|
| GPU | T4 (16 GB VRAM) | A100 (40 GB VRAM) |
| RAM | 13 GB | 26 GB |
| Storage | 20 GB | 50 GB |

### Setup Steps

**Step 1: Install dependencies**

```python
!pip install -q \
  sentence-transformers==2.7.0 \
  faiss-gpu==1.7.4 \
  fastapi==0.110.0 \
  uvicorn[standard]==0.29.0 \
  pyngrok==7.0.5 \
  httpx==0.27.0 \
  numpy==1.26.4
```

**Step 2: Configure environment**

```python
import os

os.environ["RUNTIME_ID"]         = "runtime-1-vector-brain"
os.environ["HEADY_SECRET"]       = "YOUR_HEADY_SECRET"        # set via Colab Secrets
os.environ["RUNTIME_TOKEN"]      = "YOUR_RUNTIME_1_JWT"       # set via Colab Secrets
os.environ["EMBEDDING_MODEL"]    = "all-MiniLM-L6-v2"
os.environ["FAISS_INDEX_PATH"]   = "/content/heady_index.faiss"
os.environ["FAISS_DIM"]          = "384"
os.environ["CSL_INCLUDE_GATE"]   = "0.382"
os.environ["CSL_BOOST_GATE"]     = "0.618"
os.environ["CSL_INJECT_GATE"]    = "0.718"
os.environ["CONDUCTOR_URL"]      = ""  # filled after Runtime 3 starts
os.environ["PORT"]               = "7860"
```

**Step 3: Load or create FAISS index**

```python
import faiss, numpy as np

dim = int(os.environ["FAISS_DIM"])
index_path = os.environ["FAISS_INDEX_PATH"]

if os.path.exists(index_path):
    index = faiss.read_index(index_path)
    print(f"Loaded index: {index.ntotal} vectors")
else:
    index = faiss.IndexHNSWFlat(dim, 32)  # 32 = Fibonacci(10)
    print("Created fresh FAISS index")
```

**Step 4: Start server and tunnel**

```python
from pyngrok import ngrok
import subprocess, threading

# Start FastAPI server (vector_brain/server.py loaded from repo)
server = subprocess.Popen(["uvicorn", "vector_brain.server:app",
                           "--host", "0.0.0.0", "--port", "7860"])

# Open tunnel
tunnel = ngrok.connect(7860, "http")
runtime1_url = tunnel.public_url

print(f"Runtime 1 URL: {runtime1_url}")
# → Register this URL with the Auth Gateway:
# POST /admin/runtimes  { "id": "runtime-1", "url": runtime1_url }
```

### Environment Variables Reference

| Variable | Description |
|---|---|
| `RUNTIME_ID` | `runtime-1-vector-brain` |
| `HEADY_SECRET` | Shared HMAC secret for inter-runtime auth |
| `RUNTIME_TOKEN` | RS256 JWT for this runtime |
| `EMBEDDING_MODEL` | sentence-transformers model name |
| `FAISS_INDEX_PATH` | Path to FAISS .faiss file |
| `FAISS_DIM` | Embedding dimension (384 for MiniLM) |
| `CSL_INCLUDE_GATE` | Minimum cosine similarity to include (0.382) |
| `CSL_BOOST_GATE` | Similarity threshold to boost rank (0.618) |
| `CSL_INJECT_GATE` | Threshold to inject result as primary (0.718) |
| `DRIFT_THRESHOLD` | Centroid shift to flag drift (default: 0.05) |

---

## Runtime 2 — Model Forge

### Purpose

Runtime 2 handles all LLM inference. It acts as a multi-provider proxy with:
- OpenAI API integration (GPT-4o, GPT-4o-mini)
- Anthropic API integration (Claude 3.5/3.7)
- Google Gemini integration
- Fibonacci-batched request scheduling
- Provider health monitoring and automatic failover

### Hardware Requirements

| Requirement | Minimum | Recommended |
|---|---|---|
| GPU | A100 (40 GB VRAM) | A100 (80 GB VRAM) |
| RAM | 26 GB | 52 GB |
| Storage | 10 GB | 20 GB |

### Setup Steps

**Step 1: Install dependencies**

```python
!pip install -q \
  openai==1.30.0 \
  anthropic==0.25.0 \
  google-generativeai==0.5.0 \
  fastapi==0.110.0 \
  uvicorn[standard]==0.29.0 \
  pyngrok==7.0.5 \
  tiktoken==0.7.0 \
  httpx==0.27.0
```

**Step 2: Configure environment**

```python
os.environ["RUNTIME_ID"]         = "runtime-2-model-forge"
os.environ["HEADY_SECRET"]       = "YOUR_HEADY_SECRET"
os.environ["RUNTIME_TOKEN"]      = "YOUR_RUNTIME_2_JWT"
os.environ["OPENAI_API_KEY"]     = "sk-..."          # Colab Secret
os.environ["ANTHROPIC_API_KEY"]  = "sk-ant-..."      # Colab Secret
os.environ["GEMINI_API_KEY"]     = "AIza..."         # Colab Secret
os.environ["DEFAULT_PROVIDER"]   = "anthropic"
os.environ["BATCH_SIZE_HOT"]     = "8"               # Fibonacci(6)
os.environ["BATCH_SIZE_WARM"]    = "5"               # Fibonacci(5)
os.environ["MAX_TOKENS_DEFAULT"] = "1024"
os.environ["PORT"]               = "7861"
```

**Step 3: Start server and tunnel**

```python
server = subprocess.Popen(["uvicorn", "model_forge.server:app",
                           "--host", "0.0.0.0", "--port", "7861"])

tunnel = ngrok.connect(7861, "http")
runtime2_url = tunnel.public_url
print(f"Runtime 2 URL: {runtime2_url}")
```

### Environment Variables Reference

| Variable | Description |
|---|---|
| `RUNTIME_ID` | `runtime-2-model-forge` |
| `OPENAI_API_KEY` | OpenAI API key |
| `ANTHROPIC_API_KEY` | Anthropic API key |
| `GEMINI_API_KEY` | Google Gemini API key |
| `DEFAULT_PROVIDER` | Primary inference provider |
| `BATCH_SIZE_HOT` | Batch size for hot queue (8) |
| `BATCH_SIZE_WARM` | Batch size for warm queue (5) |
| `MAX_TOKENS_DEFAULT` | Default max output tokens |
| `PROVIDER_TIMEOUT_MS` | Per-provider timeout (default: 30000) |
| `CONSENSUS_MIN_PROVIDERS` | Min providers for consensus (default: 2) |

---

## Runtime 3 — Conductor

### Purpose

Runtime 3 is the orchestration brain. It hosts:
- LiquidConductor (task routing)
- TaskDecomposer (DAG generation)
- BeeFactory + SwarmCoordinator (bee fleet management)
- Pipeline management
- Consensus aggregation

### Hardware Requirements

| Requirement | Minimum | Recommended |
|---|---|---|
| GPU | T4 (16 GB VRAM) | T4 (16 GB VRAM) |
| RAM | 13 GB | 26 GB |
| Storage | 10 GB | 20 GB |

### Setup Steps

**Step 1: Install dependencies**

```python
!pip install -q \
  fastapi==0.110.0 \
  uvicorn[standard]==0.29.0 \
  pyngrok==7.0.5 \
  httpx==0.27.0 \
  networkx==3.3        # DAG operations
```

**Step 2: Configure environment (requires Runtime 1 and 2 URLs)**

```python
os.environ["RUNTIME_ID"]        = "runtime-3-conductor"
os.environ["HEADY_SECRET"]      = "YOUR_HEADY_SECRET"
os.environ["RUNTIME_TOKEN"]     = "YOUR_RUNTIME_3_JWT"
os.environ["VECTOR_BRAIN_URL"]  = runtime1_url    # from Runtime 1 output
os.environ["MODEL_FORGE_URL"]   = runtime2_url    # from Runtime 2 output
os.environ["MAX_BEES"]          = "50"
os.environ["MAX_CONCURRENT"]    = "21"            # Fibonacci(8)
os.environ["DAG_MAX_DEPTH"]     = "13"            # Fibonacci(7)
os.environ["PHI_LOAD_THRESHOLD"]= "0.618"
os.environ["PORT"]              = "7862"
```

**Step 3: Start server and tunnel**

```python
server = subprocess.Popen(["uvicorn", "conductor.server:app",
                           "--host", "0.0.0.0", "--port", "7862"])

tunnel = ngrok.connect(7862, "http")
runtime3_url = tunnel.public_url
print(f"Runtime 3 URL: {runtime3_url}")

# Final step: register all runtime URLs with Auth Gateway
import httpx
httpx.post(f"{AUTH_GATEWAY_URL}/admin/runtimes", json={
    "runtime-1": runtime1_url,
    "runtime-2": runtime2_url,
    "runtime-3": runtime3_url,
}, headers={"Authorization": f"Bearer {ADMIN_TOKEN}"})
```

---

## Inter-Runtime Communication

All runtimes call each other over HTTPS via their tunnel URLs. Requests are signed with the shared `HEADY_SECRET` using HMAC-SHA256:

```python
import hmac, hashlib, time

def sign_request(payload: dict, secret: str) -> str:
    ts = str(int(time.time()))
    body = json.dumps(payload, sort_keys=True)
    sig = hmac.new(secret.encode(), f"{ts}.{body}".encode(),
                   hashlib.sha256).hexdigest()
    return f"t={ts},v1={sig}"

headers = {
    "X-Heady-Signature": sign_request(payload, HEADY_SECRET),
    "X-Runtime-ID": os.environ["RUNTIME_ID"],
    "Authorization": f"Bearer {RUNTIME_TOKEN}",
}
```

---

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---|---|---|
| `502 Bad Gateway` from Auth Gateway | Runtime tunnel expired | Re-run tunnel cell in Colab; re-register URL |
| FAISS `ValueError: Index dimension mismatch` | Wrong embedding model | Ensure `FAISS_DIM` matches model output dim |
| `HMAC verification failed` | Clock skew > 5 minutes | Sync Colab runtime clock: `!hwclock --hctosys` |
| `429 Too Many Requests` from provider | Rate limit hit | Reduce `BATCH_SIZE_HOT` or rotate API keys |
| Conductor sees stale Runtime URLs | URL registered before tunnel ready | Wait for tunnel output, then re-register |
| Memory error in Vector Brain | FAISS index too large for RAM | Switch to IVF index with `nlist=1597` |

---

## Failover Matrix

| Failure | Detection | Action |
|---|---|---|
| Runtime 1 (Vector Brain) down | Health check timeout (5s) | Degrade to keyword search; alert operator |
| Runtime 2 (Model Forge) down | Health check timeout (5s) | Switch to backup provider; queue requests |
| Runtime 3 (Conductor) down | Health check timeout (5s) | Auth Gateway returns 503; queued tasks held |
| OpenAI API error | HTTP 5xx from provider | Failover to Anthropic → Gemini in sequence |
| Anthropic API error | HTTP 5xx from provider | Failover to OpenAI → Gemini |
| Redis down | Connection refused | Degrade to in-process cache (13% capacity) |
| PostgreSQL down | Connection refused | Read from Redis only; writes queued locally |
| ngrok tunnel expired | URL unreachable | Auto-reconnect + re-register (5 retries, phi-backoff) |
