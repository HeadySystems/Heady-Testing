# Deployment Guide

> Production deployment for the Heady Sovereign AI Platform

---

## Overview

Heady can be deployed in three complementary tiers:

| Tier | Components | Where |
|---|---|---|
| Edge | Cloudflare Workers + Pages | Cloudflare global network |
| Gateway | Auth Gateway + Liquid Nodes | Docker / GCP Cloud Run |
| Compute | Vector Brain, Model Forge, Conductor | Google Colab Pro+ / GCP |

For development: Docker Compose (single machine).
For production: Cloudflare Edge + Cloud Run + Colab Pro+.

---

## Docker Deployment

### Prerequisites

- Docker 24.x
- Docker Compose 2.x
- `.env` file configured (see [Environment Variables](#environment-variables-master-list))

### `docker-compose.yml`

```yaml
version: "3.9"

services:

  auth-gateway:
    build: ./services/auth-gateway
    ports:
      - "8000:8000"
    env_file: .env
    depends_on:
      - postgres
      - redis
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 21s      # Fibonacci
      timeout: 13s
      retries: 3

  liquid-nodes:
    build: ./services/liquid-nodes
    ports:
      - "3000:3000"
    env_file: .env
    depends_on:
      - auth-gateway
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000/health"]
      interval: 21s
      timeout: 8s
      retries: 3

  postgres:
    image: postgres:15-alpine
    environment:
      POSTGRES_USER: heady
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: heady
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    command: redis-server --appendonly yes --maxmemory 512mb --maxmemory-policy allkeys-lru
    volumes:
      - redis_data:/data
    ports:
      - "6379:6379"

  prometheus:
    image: prom/prometheus:v2.51.0
    volumes:
      - ./infra/prometheus.yml:/etc/prometheus/prometheus.yml
    ports:
      - "9090:9090"

volumes:
  postgres_data:
  redis_data:
```

### Start all services

```bash
# Development
docker compose up -d

# Production (with resource limits)
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# View logs
docker compose logs -f auth-gateway liquid-nodes

# Health check
curl http://localhost:8000/health
curl http://localhost:3000/health
```

---

## Cloudflare Workers + Pages

### Edge Router Worker

The edge router handles rate limiting, CORS, and request routing before anything hits the Auth Gateway.

```bash
cd workers/edge-router
npm install -g wrangler
wrangler login
```

**`wrangler.toml`:**

```toml
name = "heady-edge-router"
main = "src/index.js"
compatibility_date = "2024-09-23"
workers_dev = false

[vars]
HEADY_GATEWAY_URL = "https://auth-gateway.headyme.com"
PHI = "1.618033988749895"
RATE_LIMIT_TIER_1 = "89"
RATE_LIMIT_TIER_2 = "144"

[[routes]]
pattern = "headyme.com/*"
zone_name = "headyme.com"

[[routes]]
pattern = "headyapi.com/*"
zone_name = "headyapi.com"

[[kv_namespaces]]
binding = "RATE_LIMITS"
id = "YOUR_KV_NAMESPACE_ID"
```

```bash
# Deploy to production
wrangler deploy

# Test locally
wrangler dev
```

### Cloudflare Pages (Frontend)

```bash
cd frontend
npm run build

# Deploy
wrangler pages deploy dist --project-name heady-frontend
```

---

## Google Cloud Run

### Auth Gateway

```bash
# Build and push image
docker build -t gcr.io/YOUR_PROJECT/heady-auth-gateway:v4.0 ./services/auth-gateway
docker push gcr.io/YOUR_PROJECT/heady-auth-gateway:v4.0

# Deploy
gcloud run deploy heady-auth-gateway \
  --image gcr.io/YOUR_PROJECT/heady-auth-gateway:v4.0 \
  --region us-central1 \
  --platform managed \
  --allow-unauthenticated \
  --min-instances 1 \
  --max-instances 13 \
  --memory 1Gi \
  --cpu 1 \
  --port 8000 \
  --set-env-vars "$(cat .env | tr '\n' ',')"
```

### Liquid Nodes

```bash
docker build -t gcr.io/YOUR_PROJECT/heady-liquid-nodes:v4.0 ./services/liquid-nodes
docker push gcr.io/YOUR_PROJECT/heady-liquid-nodes:v4.0

gcloud run deploy heady-liquid-nodes \
  --image gcr.io/YOUR_PROJECT/heady-liquid-nodes:v4.0 \
  --region us-central1 \
  --platform managed \
  --no-allow-unauthenticated \
  --min-instances 1 \
  --max-instances 8 \
  --memory 2Gi \
  --cpu 2 \
  --port 3000
```

### Cloud Run YAML (GitOps)

```yaml
# infra/gcp/auth-gateway.yaml
apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: heady-auth-gateway
  annotations:
    run.googleapis.com/ingress: all
spec:
  template:
    metadata:
      annotations:
        autoscaling.knative.dev/minScale: "1"
        autoscaling.knative.dev/maxScale: "13"   # Fibonacci(7)
    spec:
      containers:
        - image: gcr.io/YOUR_PROJECT/heady-auth-gateway:v4.0
          ports:
            - containerPort: 8000
          resources:
            limits:
              cpu: "1"
              memory: 1Gi
          livenessProbe:
            httpGet:
              path: /health
            initialDelaySeconds: 8
            periodSeconds: 21
```

---

## Colab Pro+ Setup

See the dedicated [COLAB_GUIDE.md](./COLAB_GUIDE.md) for full step-by-step setup of all three runtimes.

**Quick summary:**

1. Open `notebooks/runtime1_vector_brain.ipynb` → Run all cells → Copy tunnel URL
2. Open `notebooks/runtime2_model_forge.ipynb` → Run all cells → Copy tunnel URL
3. Open `notebooks/runtime3_conductor.ipynb` → Set `VECTOR_BRAIN_URL` and `MODEL_FORGE_URL` → Run all cells
4. Register all three URLs via `POST /admin/runtimes` on the Auth Gateway

---

## Environment Variables Master List

### Auth Gateway

| Variable | Required | Example |
|---|---|---|
| `JWT_PRIVATE_KEY` | Yes | `base64:<pem>` |
| `JWT_PUBLIC_KEY` | Yes | `base64:<pem>` |
| `JWT_ISSUER` | Yes | `https://auth.headyme.com` |
| `JWT_ACCESS_EXPIRY` | No | `900` |
| `JWT_REFRESH_EXPIRY` | No | `604800` |
| `AUTH_DB_URL` | Yes | `postgresql://...` |
| `REDIS_URL` | Yes | `redis://...` |
| `CORS_ORIGINS` | Yes | `https://headyme.com,...` |
| `RATE_LIMIT_ENABLED` | No | `true` |

### Liquid Nodes

| Variable | Required | Example |
|---|---|---|
| `AUTH_GATEWAY_URL` | Yes | `https://auth.headyme.com` |
| `VECTOR_BRAIN_URL` | Yes | `https://xxxx.ngrok.io` |
| `MODEL_FORGE_URL` | Yes | `https://yyyy.ngrok.io` |
| `CONDUCTOR_URL` | Yes | `https://zzzz.ngrok.io` |
| `HEADY_SECRET` | Yes | `<32-byte hex>` |
| `NODE_ENV` | No | `production` |
| `PORT` | No | `3000` |
| `MAX_BEES` | No | `50` |

### Colab Runtimes

| Variable | Runtime | Example |
|---|---|---|
| `HEADY_SECRET` | All | `<32-byte hex>` |
| `RUNTIME_TOKEN` | All | `<JWT>` |
| `OPENAI_API_KEY` | R2 | `sk-...` |
| `ANTHROPIC_API_KEY` | R2 | `sk-ant-...` |
| `GEMINI_API_KEY` | R2 | `AIza...` |
| `EMBEDDING_MODEL` | R1 | `all-MiniLM-L6-v2` |
| `FAISS_DIM` | R1 | `384` |

---

## Health Check Verification

Run this script after deployment to verify all services are healthy:

```bash
#!/bin/bash
# scripts/health-check.sh

GATEWAY="https://auth.headyme.com"
NODES="https://nodes.headyme.com"

echo "=== Heady Health Check ==="

check() {
  local name=$1; local url=$2
  status=$(curl -s -o /dev/null -w "%{http_code}" "$url")
  if [ "$status" = "200" ]; then
    echo "✓ $name ($url)"
  else
    echo "✗ $name ($url) → HTTP $status"
  fi
}

check "Auth Gateway"   "$GATEWAY/health"
check "Liquid Nodes"   "$NODES/health"
check "OIDC Config"    "$GATEWAY/auth/.well-known/openid-configuration"
check "JWKS Endpoint"  "$GATEWAY/auth/.well-known/jwks.json"
check "Vector Brain"   "$GATEWAY/proxy/runtime-1/health"
check "Model Forge"    "$GATEWAY/proxy/runtime-2/health"
check "Conductor"      "$GATEWAY/proxy/runtime-3/health"
```

---

## Monitoring Setup

### Prometheus Configuration

```yaml
# infra/prometheus.yml
global:
  scrape_interval: 21s     # Fibonacci
  evaluation_interval: 34s

scrape_configs:
  - job_name: 'heady-auth-gateway'
    static_configs:
      - targets: ['auth-gateway:8000']
    metrics_path: '/metrics'

  - job_name: 'heady-liquid-nodes'
    static_configs:
      - targets: ['liquid-nodes:3000']
    metrics_path: '/metrics'
```

### Key Metrics to Alert On

| Metric | Alert Threshold | Severity |
|---|---|---|
| `heady_auth_errors_total` | > 5/min | Warning |
| `heady_runtime_health` | < 1 | Critical |
| `heady_phi_load` | > 0.89 | Warning |
| `heady_bee_queue_depth` | > 34 | Warning |
| `heady_token_refresh_failures` | > 3/min | Critical |
| `heady_drift_detected` | == 1 | Info |
| `heady_provider_latency_p99_ms` | > 10000 | Warning |
