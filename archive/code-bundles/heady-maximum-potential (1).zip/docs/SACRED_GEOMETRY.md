# Sacred Geometry Constants

> The mathematical foundation of the Heady v4.0 architecture

---

## Philosophy: No Magic Numbers

Every numeric constant in the Heady platform is mathematically derived from the golden ratio (PHI) or its companion (PSI), expressed through the Fibonacci sequence. This is not aesthetic choice — it is engineering discipline.

**Why it matters:**

1. **Auditability** — Every constant can be traced to a formula. When a threshold is questioned, the answer is always "because PHI."
2. **Harmony** — Constants derived from the same root value interact predictably. A 61.8% load threshold and a 38.2% gate cutoff are complementary by construction.
3. **Natural fit** — Fibonacci sequences model exponential growth in the same way real-world request loads, memory pressure, and batch sizes actually grow.
4. **Patent protection** — The specific application of these constants to AI infrastructure is covered by HeadySystems Inc. provisional patents.

---

## Core Constants

### PHI — The Golden Ratio

```
PHI = (1 + √5) / 2 = 1.618033988749895
```

PHI is the fundamental constant. It defines the ratio between any two consecutive Fibonacci numbers as the sequence grows toward infinity. It appears in the spiral of galaxies, the branching of trees, the proportions of the human body — and now in AI infrastructure.

```javascript
// geometry.js
const PHI = 1.618033988749895;
const PSI = 1 / PHI;          // 0.6180339887498949 (PHI - 1 = 1/PHI)
const PHI_SQUARED = PHI * PHI; // 2.6180339887498953
const PHI_INVERSE = 1 - PSI;   // 0.3819660112501051  (= 1/PHI^2)
```

### PSI — The Reciprocal

```
PSI = 1 / PHI = PHI - 1 = 0.618033988749895
```

PSI governs the "smaller portion" in any PHI-ratio split. When a resource pool is divided, the primary portion is PSI (61.8%) and the secondary is PHI_INVERSE (38.2%). These two always sum to exactly 1.

---

## Fibonacci Sequence in Heady

The Fibonacci sequence (1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181...) governs discrete sizing decisions throughout the platform.

### Batch Sizes

| Queue | Size | Fibonacci Index |
|---|---|---|
| Hot batch | 8 | F(6) |
| Warm batch | 5 | F(5) |
| Cold batch | 3 | F(4) |
| Micro batch | 2 | F(3) |
| Max concurrency | 21 | F(8) |
| Max bee pool | 50 | F(5)+F(6)+F(4)+F(3) (composite) |

### Memory Pool Sizes (Redis)

| Tier | Size | Derived From |
|---|---|---|
| Hot buffer | 144 MB | F(12) |
| Warm buffer | 89 MB | F(11) |
| Cold buffer | 55 MB | F(10) |
| Emergency reserve | 34 MB | F(9) |

### Retry Delays (milliseconds)

Phi-backoff produces a naturally expanding retry ladder that avoids thundering-herd effects:

| Attempt | Delay (ms) | Formula |
|---|---|---|
| 1st retry | 1,000 | base |
| 2nd retry | 1,618 | base × PHI |
| 3rd retry | 2,618 | base × PHI² |
| 4th retry | 4,236 | base × PHI³ |
| 5th retry | 6,854 | base × PHI⁴ |
| Max backoff | 10,946 | F(21) ms ≈ PHI⁵ × base |

```javascript
function phiBackoffMs(attempt, baseMs = 1000) {
  return Math.round(baseMs * Math.pow(PHI, attempt - 1));
}
```

### Cache TTLs (seconds)

| Cache Level | TTL | Fibonacci |
|---|---|---|
| Hot (in-request) | 55 s | F(10) |
| Warm (session) | 233 s | F(13) |
| Cold (persistent) | 1,597 s | F(17) |
| CORS preflight | 86,400 s | (daily — external standard) |

### Rate Limit Windows and Caps

| Tier | Requests/min | Fibonacci |
|---|---|---|
| Public | 21 | F(8) |
| Free | 55 | F(10) |
| Pro | 144 | F(12) |
| Enterprise | 377 | F(14) |
| Service | 987 | F(16) |

---

## CSL Gates — Cognitive Semantic Logic

CSL gates apply semantic logic to vector similarity scores. Each gate type corresponds to a classical logic operation, adapted for continuous (0.0–1.0) similarity space rather than binary true/false.

### Gate Definitions

| Gate | Type | Formula | Behavior |
|---|---|---|---|
| `AND` | Cosine intersection | `min(sim_A, sim_B)` | Both queries must match |
| `OR` | Superposition | `max(sim_A, sim_B)` | Either query can match |
| `NOT` | Orthogonal exclusion | `1 - sim` | Invert similarity; exclude close matches |
| `IMPLY` | Conditional gate | `max(1 - sim_A, sim_B)` | If A then B |
| `XOR` | Exclusive relevance | `abs(sim_A - sim_B)` | Matches one but not both |
| `CONSENSUS` | Agreement gate | `mean(sims) × agreement_factor` | Average across multiple queries |

### Threshold Constants

```python
# csl_gates.py
CSL_INCLUDE_THRESHOLD  = 0.382   # PHI_INVERSE — minimum to include in results
CSL_BOOST_THRESHOLD    = 0.618   # PSI — boost ranking above this score
CSL_INJECT_THRESHOLD   = 0.718   # Empirically derived: PSI + 0.1 — inject as primary
CSL_EXCLUDE_THRESHOLD  = 0.200   # Below this, always exclude

# Gate behavior by threshold
def apply_and_gate(sim_a: float, sim_b: float) -> float:
    combined = min(sim_a, sim_b)
    if combined < CSL_EXCLUDE_THRESHOLD:  return 0.0
    if combined < CSL_INCLUDE_THRESHOLD:  return combined * PSI      # dampen
    if combined < CSL_BOOST_THRESHOLD:    return combined            # include
    if combined < CSL_INJECT_THRESHOLD:   return combined * PHI      # boost
    return combined * PHI_SQUARED                                     # inject
```

### Relevance Gate Summary

| Gate Level | Threshold | Action |
|---|---|---|
| Exclude | < 0.200 | Drop from results entirely |
| Dampen | 0.200 – 0.382 | Include at reduced weight |
| Include | 0.382 – 0.618 | Include at face value |
| Boost | 0.618 – 0.718 | Elevate in ranking |
| Inject | > 0.718 | Insert as primary context |

---

## Pool Allocation

Memory and resource pools follow a PHI-derived percentage ladder. Every tier percentage is a Fibonacci-sequence ratio:

| Pool | % Allocation | Fibonacci Basis | Purpose |
|---|---|---|---|
| Hot | 34% | F(9)/F(total) | Active working set, Redis in-memory |
| Warm | 21% | F(8)/F(total) | Recent history, Redis persisted |
| Cold | 13% | F(7)/F(total) | Vector index + PostgreSQL |
| Reserve | 8% | F(6)/F(total) | Failover and emergency buffer |
| Governance | 5% | F(5)/F(total) | Audit trail, compliance logs |
| OS/Runtime | 19% | Remainder | Operating system + service overhead |

```
100% = 34 + 21 + 13 + 8 + 5 + 19
     = F(9) + F(8) + F(7) + F(6) + F(5) + overhead
```

Note that 34 + 21 + 13 + 8 + 5 = 81, which is 3⁴ — another naturally occurring constant. The 19% overhead rounds the total to 100% while preserving the Fibonacci ratios in the managed allocation.

---

## PHI in Structural Decisions

### HNSW Graph Construction (Vector Brain)

```python
M = 32        # F(10) = number of connections per HNSW node
ef_construction = 200   # ≈ F(13+) search width during index build
ef_search = 50          # F(10) = search width during query
```

### JWT Expiry Ratios

```
access_token_ttl  = 900s     (15 min)
refresh_token_ttl = 604800s  (7 days)
ratio = 604800 / 900 ≈ 672 ≈ PHI^12 ≈ 32× (approximately)
```

The large ratio between access and refresh token lifetimes mirrors a PHI-scaled amplification, ensuring that refresh token reuse attacks are detectable within a predictable window.

### FAISS Index Parameters

```python
nlist = 1597    # F(17) — number of IVF cells
nprobe = 21     # F(8)  — cells to probe at search time
```

The ratio `nprobe / nlist = 21 / 1597 ≈ 0.01315 ≈ 1/PHI^7` — a naturally harmonious probe fraction that balances recall against search latency.

---

## Deriving New Constants

When adding a new parameter to Heady, follow this decision tree:

```
1. Is it a count or size?
   → Use the nearest Fibonacci number

2. Is it a ratio or probability?
   → Use PHI_INVERSE (0.382), PSI (0.618), or their products

3. Is it a time duration?
   → Anchor to 1000ms base, scale by PHI^n

4. Is it a pool percentage?
   → Assign the next available Fibonacci tier

5. Is it a threshold?
   → Use CSL gate thresholds (0.200, 0.382, 0.618, 0.718)
      or derive from PHI: PHI/n for some integer n

6. None of the above?
   → Document the derivation formula explicitly in a comment
      Never use an unexplained literal number
```

---

## Quick Reference Card

```
PHI           = 1.618033988749895
PSI           = 0.618033988749895
PHI_INVERSE   = 0.381966011250105
PHI_SQUARED   = 2.618033988749895

Fibonacci:    1  1  2  3  5  8  13  21  34  55  89  144  233  377  610  987  1597

CSL gates:    EXCLUDE < 0.200
              DAMPEN  0.200–0.382
              INCLUDE 0.382–0.618
              BOOST   0.618–0.718
              INJECT  > 0.718

Pools:        HOT 34% · WARM 21% · COLD 13% · RESERVE 8% · GOVERNANCE 5%

Retry (ms):   1000 → 1618 → 2618 → 4236 → 6854 → 10946

Rate limits:  21 · 55 · 144 · 377 · 987 req/min

Batch sizes:  2 · 3 · 5 · 8 · 13 · 21
```
