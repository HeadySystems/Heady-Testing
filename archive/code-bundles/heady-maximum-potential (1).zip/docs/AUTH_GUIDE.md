# Auth Guide

> OAuth 2.1 + OIDC Authentication System for the Heady Platform

---

## Overview

The Heady Auth Gateway provides enterprise-grade authentication using OAuth 2.1 with PKCE, OpenID Connect (OIDC) for identity federation, and RS256-signed JWTs for stateless session management. All 11 Heady domains share a unified auth fabric with domain-aware routing and per-origin policy enforcement.

---

## OAuth 2.1 + OIDC Flow

### Authorization Code + PKCE (Recommended for web clients)

```
1. Client generates code_verifier (random 43–128 char string)
   code_challenge = BASE64URL(SHA256(code_verifier))

2. Client redirects to:
   GET /auth/authorize
     ?response_type=code
     &client_id=<client_id>
     &redirect_uri=https://headyme.com/callback
     &scope=openid profile email
     &code_challenge=<code_challenge>
     &code_challenge_method=S256
     &state=<csrf_token>

3. User authenticates → Auth Gateway issues authorization_code

4. Client exchanges code:
   POST /auth/token
   {
     "grant_type": "authorization_code",
     "code": "<authorization_code>",
     "redirect_uri": "https://headyme.com/callback",
     "client_id": "<client_id>",
     "code_verifier": "<code_verifier>"
   }

5. Gateway responds:
   {
     "access_token":  "<JWT, 15min>",
     "id_token":      "<OIDC JWT>",
     "refresh_token": "<JWT, 7d>",
     "token_type":    "Bearer",
     "expires_in":    900
   }
```

### Client Credentials (Machine-to-machine)

```
POST /auth/token
{
  "grant_type": "client_credentials",
  "client_id": "<service_client_id>",
  "client_secret": "<service_secret>",
  "scope": "api:read api:write"
}
```

---

## JWT Token Lifecycle

### Token Specifications

| Property | Access Token | Refresh Token | ID Token |
|---|---|---|---|
| Algorithm | RS256 | RS256 | RS256 |
| Expiry | 15 minutes | 7 days | 15 minutes |
| Key size | 2048-bit RSA | 2048-bit RSA | 2048-bit RSA |
| Storage | Memory only | HTTP-only cookie | Memory only |
| Revocable | Via allowlist | Immediate blacklist | N/A |

### Access Token Payload

```json
{
  "iss": "https://auth.headyme.com",
  "sub": "usr_abc123def456",
  "aud": ["headyme.com", "headyapi.com"],
  "exp": 1741650320,
  "iat": 1741649420,
  "jti": "jwt_phi_8f3a2b1c9d",
  "scope": "openid profile email api:read api:write",
  "roles": ["user"],
  "domain": "headyme.com",
  "phi_tier": 2
}
```

### Refresh Token Rotation

Every use of a refresh token triggers rotation: a new pair (access + refresh) is issued, and the consumed refresh token is immediately added to the blacklist. Detecting reuse of a blacklisted refresh token triggers a full session revocation for that user.

```
POST /auth/refresh
Authorization: (none — token is HTTP-only cookie)

→ {
    "access_token":  "<new JWT>",
    "refresh_token": "<new JWT — set as cookie>",
    "expires_in": 900
  }
```

### Key Rotation

RSA key pairs rotate every 30 days. The JWKS endpoint always serves the active key plus the previous key to allow graceful token drain:

```
GET /auth/.well-known/jwks.json
→ { "keys": [ { "kid": "k1", ... }, { "kid": "k0", ... } ] }
```

---

## Domain-Aware CORS Configuration

The Auth Gateway enforces per-domain CORS policies. Each origin maps to a policy tier:

```python
CORS_POLICY = {
    # Tier 1 — full access (primary platforms)
    "https://headyme.com":         {"methods": ["GET","POST","PUT","DELETE","PATCH"], "credentials": True},
    "https://headyapi.com":        {"methods": ["GET","POST","PUT","DELETE","PATCH"], "credentials": True},
    "https://headyai.com":         {"methods": ["GET","POST","PUT","DELETE","PATCH"], "credentials": True},

    # Tier 2 — standard access (portals and apps)
    "https://headysystems.com":    {"methods": ["GET","POST","PUT","DELETE"],        "credentials": True},
    "https://headyconnection.org": {"methods": ["GET","POST","PUT","DELETE"],        "credentials": True},
    "https://headybuddy.org":      {"methods": ["GET","POST"],                       "credentials": True},
    "https://headymcp.com":        {"methods": ["GET","POST"],                       "credentials": True},
    "https://headyio.com":         {"methods": ["GET","POST","PUT"],                 "credentials": True},
    "https://headybot.com":        {"methods": ["GET","POST"],                       "credentials": True},

    # Tier 3 — read + webhook (external integrations)
    "https://headycloud.com":      {"methods": ["GET","POST"],                       "credentials": False},
    "https://headyos.com":         {"methods": ["GET","POST"],                       "credentials": False},
}

CORS_EXPOSED_HEADERS = ["X-Heady-Request-ID", "X-RateLimit-Remaining", "X-Phi-Load"]
CORS_MAX_AGE = 86400  # 24h preflight cache
```

Requests from unlisted origins receive `403 Forbidden` at the Cloudflare edge before reaching the gateway.

---

## Rate Limiting

Rate limits are enforced at two layers: Cloudflare edge (per-IP) and Auth Gateway (per-user/API key).

### Fibonacci Rate Tiers

| Tier | Identifier | Requests / minute | Burst |
|---|---|---|---|
| Public (unauthenticated) | IP | 21 | 34 |
| Free user | `sub` claim | 55 | 89 |
| Pro user | `sub` + tier=2 | 144 | 233 |
| Enterprise | `sub` + tier=3 | 377 | 610 |
| Service account | `client_id` | 987 | 1597 |

Window algorithm: **sliding window log** (exact per-user request history in Redis, TTL = 60s).

### Rate Limit Headers

```
X-RateLimit-Limit:     144
X-RateLimit-Remaining: 97
X-RateLimit-Reset:     1741649480
Retry-After:           13          (on 429 response, Fibonacci seconds)
```

---

## API Key Management

API keys are an alternative to OAuth flows for server-side clients that cannot use interactive auth.

### Creating an API Key

```
POST /auth/api-keys
Authorization: Bearer <access_token>
{
  "name": "My Integration",
  "scopes": ["api:read", "api:write"],
  "expires_in_days": 90,
  "domain_restrictions": ["headyapi.com"]
}

→ {
    "key_id": "kid_abc123",
    "key": "hdy_live_xxxxxxxxxxxxxxxxxxxx",   ← shown ONCE
    "created_at": "2026-03-10T20:37:00Z",
    "expires_at": "2026-06-08T20:37:00Z"
  }
```

Keys are stored as bcrypt hashes. The plaintext value is never stored after creation.

### Using an API Key

```
GET /api/resource
X-API-Key: hdy_live_xxxxxxxxxxxxxxxxxxxx
```

### Key Scopes

| Scope | Access |
|---|---|
| `api:read` | GET endpoints only |
| `api:write` | POST, PUT, PATCH |
| `api:delete` | DELETE endpoints |
| `admin:users` | User management |
| `admin:keys` | Key management |
| `vector:read` | Vector Brain read |
| `vector:write` | Vector Brain write |
| `model:infer` | Model Forge inference |

---

## Setup Instructions

### 1. Generate RSA key pair

```bash
# Generate private key
openssl genrsa -out private.pem 2048

# Extract public key
openssl rsa -in private.pem -pubout -out public.pem

# Convert to single-line for environment variable
PRIVATE_KEY=$(cat private.pem | tr '\n' '|')
```

### 2. Configure environment variables

```bash
# Core auth settings
JWT_PRIVATE_KEY="<base64-encoded PEM>"
JWT_PUBLIC_KEY="<base64-encoded PEM>"
JWT_ISSUER="https://auth.headyme.com"
JWT_ACCESS_EXPIRY=900        # 15 minutes in seconds
JWT_REFRESH_EXPIRY=604800    # 7 days in seconds

# Database
AUTH_DB_URL="postgresql://heady:secret@localhost:5432/heady_auth"
REDIS_URL="redis://localhost:6379/0"

# OAuth clients (comma-separated JSON)
OAUTH_CLIENTS='[{"id":"web","secret":"...","redirect_uris":["https://headyme.com/callback"]}]'

# Rate limiting
RATE_LIMIT_ENABLED=true
RATE_LIMIT_REDIS_DB=1

# CORS
CORS_ORIGINS="https://headyme.com,https://headyapi.com,..."
```

### 3. Initialize the database

```bash
cd services/auth-gateway
alembic upgrade head
python scripts/seed_clients.py
```

### 4. Start the service

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 \
  --ssl-keyfile /certs/key.pem \
  --ssl-certfile /certs/cert.pem
```

---

## Environment Variables Reference

| Variable | Required | Default | Description |
|---|---|---|---|
| `JWT_PRIVATE_KEY` | Yes | — | Base64 PEM RS256 private key |
| `JWT_PUBLIC_KEY` | Yes | — | Base64 PEM RS256 public key |
| `JWT_ISSUER` | Yes | — | Token issuer URI |
| `JWT_ACCESS_EXPIRY` | No | `900` | Access token TTL (seconds) |
| `JWT_REFRESH_EXPIRY` | No | `604800` | Refresh token TTL (seconds) |
| `AUTH_DB_URL` | Yes | — | PostgreSQL connection string |
| `REDIS_URL` | Yes | — | Redis connection string |
| `OAUTH_CLIENTS` | Yes | — | JSON array of OAuth client configs |
| `CORS_ORIGINS` | Yes | — | Comma-separated allowed origins |
| `RATE_LIMIT_ENABLED` | No | `true` | Enable rate limiting |
| `RATE_LIMIT_REDIS_DB` | No | `1` | Redis DB index for rate limit data |
| `KEY_ROTATION_DAYS` | No | `30` | RSA key rotation interval |
| `BCRYPT_ROUNDS` | No | `13` | bcrypt work factor for API keys |
| `LOG_LEVEL` | No | `info` | Logging verbosity |
| `TELEMETRY_ENDPOINT` | No | — | TelemetryBus endpoint URL |
