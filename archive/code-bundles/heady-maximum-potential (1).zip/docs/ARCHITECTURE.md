# Heady System Architecture

> Sacred Geometry v4.0 — 5-Layer Sovereign AI Platform

---

## Overview

Heady's architecture is organized into five discrete, composable layers. Each layer has a single responsibility and communicates with adjacent layers through well-defined interfaces. No layer reaches across two boundaries. This discipline enables independent scaling, hot-patching, and fault isolation.

```
┌─────────────────────────────────────────────────────────────────────┐
│  LAYER 1 — INTERFACE / EDGE                                         │
│  Cloudflare Workers · CDN · WAF · Rate Limiting · CORS Guard        │
└───────────────────────────────┬─────────────────────────────────────┘
                                │  HTTPS (TLS 1.3)
┌───────────────────────────────▼─────────────────────────────────────┐
│  LAYER 2 — GATEWAY / ROUTING                                        │
│  Auth Gateway · OAuth 2.1 · JWT · API Keys · Domain Router          │
└───────────────────────────────┬─────────────────────────────────────┘
                                │  Internal JWT-signed requests
┌───────────────────────────────▼─────────────────────────────────────┐
│  LAYER 3 — EXECUTION / MODEL                                        │
│  Conductor (DAG) · Model Forge (LLM) · Liquid Nodes (JS) · Swarms  │
└───────────────────────────────┬─────────────────────────────────────┘
                                │  Protobuf / JSON over HTTP/2
┌───────────────────────────────▼─────────────────────────────────────┐
│  LAYER 4 — MEMORY / PERSISTENCE                                     │
│  Vector Brain · FAISS Index · Redis Hot Cache · PostgreSQL Cold     │
└───────────────────────────────┬─────────────────────────────────────┘
                                │  Metrics / Traces / Logs
┌───────────────────────────────▼─────────────────────────────────────┐
│  LAYER 5 — OBSERVABILITY / CONTROL                                  │
│  TelemetryBus · Prometheus · Drift Detector · ResilienceLayer       │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Layer 1 — Interface / Edge

### Components

| Component | Technology | Function |
|---|---|---|
| Global CDN | Cloudflare Network | Route requests to nearest PoP |
| WAF | Cloudflare WAF | Block malicious patterns |
| Rate Limiter | Workers KV | Fibonacci-based per-IP throttling |
| CORS Guard | Workers Script | Domain allowlist enforcement (11 domains) |
| TLS Terminator | Cloudflare SSL | TLS 1.3 termination, mTLS-ready |

### Rate Limiting Policy

Fibonacci-derived windows prevent request storms while allowing natural burst patterns:

```
Tier 1 (public):    89  req / 60s
Tier 2 (auth):     144  req / 60s
Tier 3 (pro):      233  req / 60s
Tier 4 (admin):    610  req / 60s
Burst allowance:   PHI × tier_limit (rounded to nearest Fibonacci)
```

---

## Layer 2 — Gateway / Routing

### Components

| Component | Technology | Function |
|---|---|---|
| Auth Gateway | FastAPI (Python 3.11) | JWT issuance, validation, refresh |
| OAuth 2.1 Server | authlib | Authorization code + PKCE flows |
| OIDC Provider | authlib | ID token issuance |
| Domain Router | FastAPI middleware | Route by subdomain / origin |
| API Key Store | PostgreSQL + bcrypt | Hashed API key management |
| Session Cache | Redis | JWT allowlist + revocation list |

### Auth Flow Diagram

```
Client                    Cloudflare Edge           Auth Gateway
  │                             │                        │
  ├──── POST /auth/login ───────►                        │
  │                             ├──── forward ──────────►│
  │                             │                        ├─ validate credentials
  │                             │                        ├─ issue access_token (15min, RS256)
  │                             │                        ├─ issue refresh_token (7d, RS256)
  │                             │◄─── 200 {tokens} ──────┤
  │◄─── 200 {tokens} ───────────┤                        │
  │                             │                        │
  ├──── GET /api/resource ──────►                        │
  │     Authorization: Bearer <access_token>             │
  │                             ├──── introspect ────────►│
  │                             │◄─── {valid: true} ──────┤
  │                             ├──── proxy to service    │
  │◄─── 200 {resource} ─────────┤                        │
  │                             │                        │
  ├──── POST /auth/refresh ──────►                       │
  │     {refresh_token}         ├──── forward ──────────►│
  │                             │                        ├─ validate refresh_token
  │                             │                        ├─ rotate: issue new pair
  │                             │                        ├─ blacklist old refresh_token
  │◄─── 200 {new_tokens} ───────┤◄─── 200 {new_tokens} ─┤
```

---

## Layer 3 — Execution / Model

### 3-Runtime Colab Pro+ Partition

The compute layer runs across three isolated Colab Pro+ runtimes, each with a dedicated GPU allocation:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    COLAB PRO+ RUNTIME PARTITION                     │
│                                                                     │
│  ┌───────────────────┐         ┌───────────────────┐               │
│  │   Runtime 1       │         │   Runtime 2        │               │
│  │   Vector Brain    │◄───────►│   Model Forge      │               │
│  │                   │         │                    │               │
│  │  • FAISS index    │         │  • OpenAI proxy    │               │
│  │  • sentence-xfmr  │         │  • Anthropic proxy │               │
│  │  • CSL gates      │         │  • Gemini proxy    │               │
│  │  • Drift detect   │         │  • Batch infer     │               │
│  │  • Topology srv   │         │  • Provider select │               │
│  │                   │         │                    │               │
│  │  GPU: T4 (16GB)   │         │  GPU: A100 (40GB)  │               │
│  └───────────────────┘         └──────────┬─────────┘               │
│            ▲                              │                         │
│            │                   ┌──────────▼─────────┐               │
│            │                   │   Runtime 3         │               │
│            └───────────────────┤   Conductor         │               │
│                                │                    │               │
│                                │  • DAG executor    │               │
│                                │  • BeeFactory      │               │
│                                │  • SwarmCoordinator│               │
│                                │  • LiquidConductor │               │
│                                │  • TaskDecomposer  │               │
│                                │                    │               │
│                                │  GPU: T4 (16GB)    │               │
│                                └────────────────────┘               │
└─────────────────────────────────────────────────────────────────────┘
```

### Inter-Runtime Communication Protocol

Runtimes communicate via HTTP/2 over ngrok tunnels (Colab) or internal VPC (production). All messages are JWT-signed with runtime-specific service tokens.

```json
// Runtime message envelope
{
  "runtime_id": "runtime-2-model-forge",
  "timestamp": "2026-03-10T20:37:00Z",
  "correlation_id": "crr_phi_8f3a2b1c",
  "payload_type": "infer_request",
  "payload": { ... },
  "signature": "RS256:<jwt>"
}
```

**Timeout ladder (Fibonacci ms):**

| Step | Timeout |
|---|---|
| Initial attempt | 1,597 ms |
| Retry 1 | 2,584 ms |
| Retry 2 | 4,181 ms |
| Retry 3 | 6,765 ms |
| Max backoff | 10,946 ms |

---

## Layer 4 — Memory / Persistence

### Data Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                     MEMORY / PERSISTENCE LAYER                      │
│                                                                     │
│  Pool Allocation (PHI-derived percentages of total memory budget)   │
│                                                                     │
│  ████████████████████████████████  34% — HOT   (Redis, in-memory)  │
│  █████████████████████            21% — WARM  (Redis, persisted)   │
│  █████████████                    13% — COLD  (PostgreSQL + FAISS) │
│  ████████                          8% — RESERVE (failover buffer)  │
│  █████                             5% — GOVERNANCE (audit trail)   │
│                                                                     │
│  Remaining 19% — OS, runtime overhead, safety margin               │
└─────────────────────────────────────────────────────────────────────┘
```

### Vector Brain Storage

| Store | Technology | Content |
|---|---|---|
| Active index | FAISS (IVF + HNSW) | Current embedding space |
| Snapshot store | PostgreSQL (pgvector) | Versioned index snapshots |
| Metadata cache | Redis | Document metadata + ACL tags |
| Drift log | PostgreSQL | Centroid shift history |

---

## Layer 5 — Observability / Control

### TelemetryBus

All services emit structured events to the TelemetryBus using a common schema:

```json
{
  "event_type": "task.completed",
  "service": "conductor",
  "runtime": "runtime-3",
  "phi_ratio": 1.618,
  "duration_ms": 843,
  "bee_id": "bee_worker_0021",
  "dag_node": "summarize",
  "tokens_in": 1024,
  "tokens_out": 233,
  "geometry_score": 0.618,
  "timestamp": "2026-03-10T20:37:00.000Z"
}
```

### ResilienceLayer

The ResilienceLayer wraps all external calls with a phi-backoff circuit breaker:

```
State machine:
  CLOSED ──(failures ≥ 5)──► HALF_OPEN ──(probe fails)──► OPEN
    ▲                              │
    └──────(probe succeeds)────────┘

Reset timer: PHI^n seconds where n = consecutive open periods
```

---

## Component Dependency Map

```
headyme.com / headyapi.com
        │
        ▼
 [Cloudflare Edge] ──── rate-limit, CORS, WAF
        │
        ▼
 [Auth Gateway]  ──── JWT validate / issue
        │
        ├─────────────────────────────────────────┐
        ▼                                         ▼
 [Conductor / Runtime 3]               [Vector Brain / Runtime 1]
   ├── BeeFactory                         ├── Embed endpoint
   ├── SwarmCoordinator                   ├── Search endpoint
   ├── LiquidConductor                    ├── CSL gates
   └── TaskDecomposer                     └── Drift detector
        │
        ▼
 [Model Forge / Runtime 2]
   ├── OpenAI adapter
   ├── Anthropic adapter
   ├── Gemini adapter
   └── Batch scheduler
        │
        ▼
 [TelemetryBus] ──── Prometheus metrics ──── Grafana / alerts
```
