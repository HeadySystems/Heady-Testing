# Liquid Nodes

> Dynamic, composable execution units for the Heady sovereign AI platform

---

## What Are Liquid Nodes?

Liquid Nodes are JavaScript execution units that run in the Heady Conductor environment. Unlike static microservices, they are "liquid" because they reconfigure dynamically based on task topology, available resources, and phi-derived load balancing signals. A liquid node can act as a router, a worker, a gatherer, or a circuit breaker — often within the same request lifecycle.

The 10 core modules form a complete execution stack:

```
┌─────────────────────────────────────────────────────────┐
│                    LIQUID NODE STACK                    │
│                                                         │
│  ┌─────────────────┐   ┌─────────────────┐             │
│  │  LiquidConductor│   │  TaskDecomposer │             │
│  │  (routing layer)│   │  (DAG builder)  │             │
│  └────────┬────────┘   └────────┬────────┘             │
│           │                     │                       │
│           ▼                     ▼                       │
│  ┌─────────────────────────────────────────┐           │
│  │            SwarmCoordinator             │           │
│  │    (concurrent bee-fleet management)    │           │
│  └──────────────────┬──────────────────────┘           │
│                     │                                   │
│                     ▼                                   │
│  ┌─────────────────────────────────────────┐           │
│  │            BeeFactory                   │           │
│  │    (bee lifecycle + pool management)    │           │
│  └──────────────────┬──────────────────────┘           │
│                     │                                   │
│           ┌─────────┴──────────┐                       │
│           ▼                    ▼                        │
│  ┌────────────────┐   ┌────────────────┐               │
│  │ ResilienceLayer│   │  TelemetryBus  │               │
│  │ (circuit break)│   │  (observ.)     │               │
│  └────────────────┘   └────────────────┘               │
│                                                         │
│  Supporting modules:                                    │
│  VectorBridgeClient · ModelForgeClient                  │
│  AuthMiddleware · GeometryUtils · ConfigLoader          │
└─────────────────────────────────────────────────────────┘
```

---

## The 10 JavaScript Modules

| # | Module | File | Responsibility |
|---|---|---|---|
| 1 | `LiquidConductor` | `conductor.js` | Task routing and pipeline orchestration |
| 2 | `TaskDecomposer` | `decomposer.js` | Break complex tasks into DAG nodes |
| 3 | `SwarmCoordinator` | `swarm.js` | Manage concurrent bee execution |
| 4 | `BeeFactory` | `factory.js` | Create, pool, and recycle bee instances |
| 5 | `ResilienceLayer` | `resilience.js` | Circuit breakers and phi-backoff |
| 6 | `TelemetryBus` | `telemetry.js` | Structured event emission |
| 7 | `VectorBridgeClient` | `vector.js` | HTTP client for Vector Brain Runtime 1 |
| 8 | `ModelForgeClient` | `model.js` | HTTP client for Model Forge Runtime 2 |
| 9 | `AuthMiddleware` | `auth.js` | JWT validation and RBAC enforcement |
| 10 | `GeometryUtils` | `geometry.js` | PHI constants and Fibonacci helpers |

---

## BeeFactory and the 33 Bee Types

BeeFactory manages a pool of specialized worker agents called **bees**. Each bee type handles a specific sub-task within a larger workflow. The pool sizes follow Fibonacci numbers.

### Bee Categories

#### Query & Retrieval Bees (1–8)
| ID | Bee Type | Function |
|---|---|---|
| 1 | `EmbedBee` | Convert text to vector embeddings |
| 2 | `SearchBee` | Execute vector similarity searches |
| 3 | `FetchBee` | Retrieve documents from cold storage |
| 4 | `FilterBee` | Apply CSL gate filters to result sets |
| 5 | `RankBee` | Rerank results by phi-weighted relevance |
| 6 | `DeduplicateBee` | Remove near-duplicate results |
| 7 | `HydrateBee` | Enrich sparse results with metadata |
| 8 | `CacheBee` | Read/write hot cache entries |

#### Reasoning & Generation Bees (9–19)
| ID | Bee Type | Function |
|---|---|---|
| 9 | `InferBee` | Single-turn LLM inference |
| 10 | `StreamBee` | Streaming LLM response relay |
| 11 | `BatchInferBee` | Batched multi-prompt inference |
| 12 | `SummarizeBee` | Summarization with compression ratio |
| 13 | `ExtractBee` | Structured data extraction |
| 14 | `ClassifyBee` | Label classification tasks |
| 15 | `TranslateBee` | Multi-language translation |
| 16 | `CodeBee` | Code generation and review |
| 17 | `PlanBee` | Multi-step plan generation |
| 18 | `CritiqueBee` | Self-critique and revision |
| 19 | `ConsensusBee` | Multi-model consensus voting |

#### Orchestration Bees (20–26)
| ID | Bee Type | Function |
|---|---|---|
| 20 | `RouterBee` | Dynamic request routing |
| 21 | `SplitterBee` | Task fan-out to parallel workers |
| 22 | `MergerBee` | Aggregate parallel results |
| 23 | `LoopBee` | Iterative refinement loops |
| 24 | `ConditionBee` | Conditional branching in DAGs |
| 25 | `TimeoutBee` | Enforce execution time budgets |
| 26 | `RetryBee` | Managed retry with phi-backoff |

#### Persistence & IO Bees (27–33)
| ID | Bee Type | Function |
|---|---|---|
| 27 | `PersistBee` | Write results to PostgreSQL |
| 28 | `IndexBee` | Update FAISS vector index |
| 29 | `AuditBee` | Write governance audit trail |
| 30 | `WebhookBee` | Fire outbound webhook events |
| 31 | `StreamWriteBee` | Write to streaming output channels |
| 32 | `NotifyBee` | Send notifications (email, Slack) |
| 33 | `CleanupBee` | Release resources and recycle |

### Pool Configuration

```javascript
// geometry.js — Fibonacci pool sizes
const POOL_SIZES = {
  query:         13,  // Fibonacci(7)
  reasoning:     21,  // Fibonacci(8)
  orchestration:  8,  // Fibonacci(6)
  persistence:    5,  // Fibonacci(5)
  reserve:        3,  // Fibonacci(4) — emergency overflow
};

// Total: 50 concurrent bees maximum
// Hot pool: 34% = 17 bees active at any time
```

---

## SwarmCoordinator

SwarmCoordinator manages the bee fleet, distributing tasks across available bees and enforcing concurrency limits.

```javascript
class SwarmCoordinator {
  constructor(beeFactory, options = {}) {
    this.factory = beeFactory;
    this.maxConcurrent = options.maxConcurrent || 21; // Fibonacci(8)
    this.phiLoadThreshold = 0.618; // Trigger rebalance above 61.8% utilization
  }

  async executeSwarm(tasks) {
    // Split tasks into phi-sized chunks
    const chunkSize = Math.round(tasks.length * PHI_INVERSE); // ~61.8%
    const primary = tasks.slice(0, chunkSize);
    const secondary = tasks.slice(chunkSize);

    const results = await Promise.allSettled([
      ...primary.map(t => this.dispatch(t, 'primary')),
      ...secondary.map(t => this.dispatch(t, 'secondary')),
    ]);

    return this.mergeResults(results);
  }
}
```

---

## LiquidConductor

LiquidConductor is the top-level task router. It receives raw requests from the Auth Gateway and determines the optimal execution path.

```javascript
// Example: route a complex query
const result = await conductor.route({
  type: 'research_query',
  input: 'Explain phi-based memory allocation',
  context_window: 8192,
  providers: ['anthropic', 'openai'],
  mode: 'consensus',
});
```

Routing decisions:

| Request Type | Route |
|---|---|
| Simple Q&A | `InferBee` → direct |
| Research query | `TaskDecomposer` → DAG |
| Embedding only | `EmbedBee` → `VectorBridgeClient` |
| Batch tasks | `SplitterBee` → `SwarmCoordinator` |
| Multi-model vote | `ConsensusBee` × N providers |

---

## TaskDecomposer and DAG Execution

TaskDecomposer converts a natural language or structured task into a directed acyclic graph (DAG) of bee operations.

```javascript
// Input
const task = {
  goal: "Research and summarize PHI in architecture",
  context: [...],
  max_steps: 8,  // Fibonacci(6)
};

// Output DAG
const dag = {
  nodes: [
    { id: "embed",   type: "EmbedBee",    deps: [] },
    { id: "search",  type: "SearchBee",   deps: ["embed"] },
    { id: "fetch",   type: "FetchBee",    deps: ["search"] },
    { id: "rank",    type: "RankBee",     deps: ["fetch"] },
    { id: "infer",   type: "InferBee",    deps: ["rank"] },
    { id: "critique",type: "CritiqueBee", deps: ["infer"] },
    { id: "revise",  type: "InferBee",    deps: ["critique"] },
    { id: "persist", type: "PersistBee",  deps: ["revise"] },
  ],
  max_parallel: 3,  // Fibonacci(4)
};
```

DAG execution respects dependency order and maximizes parallel execution where the dependency graph allows.

---

## ResilienceLayer

The ResilienceLayer wraps every external call with phi-backoff retries and a state-machine circuit breaker.

```javascript
const resilience = new ResilienceLayer({
  maxRetries: 5,           // Fibonacci(5)
  baseDelayMs: 1000,
  backoffFactor: PHI,      // 1.618 — each retry delay × PHI
  circuitOpenThreshold: 5, // failures before OPEN
  halfOpenProbeInterval: Math.round(PHI * 10000), // ~16.18s
});

const result = await resilience.call(() => modelForge.infer(req));
```

**Backoff sequence (ms):** 1000 → 1618 → 2618 → 4236 → 6854

---

## TelemetryBus

TelemetryBus provides structured, real-time observability for all liquid node activity.

```javascript
telemetry.emit('bee.completed', {
  bee_type: 'InferBee',
  bee_id: 'bee_0021',
  duration_ms: 843,
  tokens_in: 1024,
  tokens_out: 233,
  provider: 'anthropic',
  phi_ratio: (1024 / 233).toFixed(4), // actual I/O ratio
  dag_node: 'infer',
  pipeline_id: 'pip_8f3a2b',
});
```

Events are forwarded to Prometheus (counter/histogram metrics) and PostgreSQL (audit log).

---

## API Reference

All liquid node endpoints are served at `http://localhost:3000` (default) or the configured `LIQUID_NODES_URL`.

### Health

```
GET /health
→ { status: "ok", bees_active: 12, bees_pool: 50, phi_load: 0.382 }
```

### Submit Task

```
POST /task
Content-Type: application/json
Authorization: Bearer <jwt>

{
  "type": "infer",
  "input": "Summarize this document",
  "context": [...],
  "options": { "provider": "anthropic", "max_tokens": 1024 }
}

→ { "task_id": "tsk_abc123", "status": "queued", "eta_ms": 1618 }
```

### Pipeline

```
POST /pipeline
{
  "steps": [
    { "type": "embed", "input": "..." },
    { "type": "search", "top_k": 5 },
    { "type": "infer", "template": "summarize" }
  ]
}

→ { "pipeline_id": "pip_xyz789", "results": [...] }
```

### Stats

```
GET /stats
→ {
    "bees": { "active": 12, "idle": 38, "pool": 50 },
    "tasks": { "queued": 3, "completed_1h": 1597 },
    "phi_load": 0.382,
    "uptime_s": 86400
  }
```

### DAG Status

```
GET /dag/:pipeline_id
→ {
    "pipeline_id": "pip_xyz789",
    "nodes": [
      { "id": "embed",  "status": "completed", "duration_ms": 144 },
      { "id": "search", "status": "completed", "duration_ms": 233 },
      { "id": "infer",  "status": "running",   "started_at": "..." }
    ]
  }
```
