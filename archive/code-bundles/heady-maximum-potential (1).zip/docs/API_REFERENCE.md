# API Reference

> Complete endpoint documentation for the Heady Sovereign AI Platform — v4.0

---

## Base URLs

| Service | Base URL |
|---|---|
| Auth Gateway | `https://auth.headyme.com` |
| Unified API | `https://api.headyapi.com` |
| Vector Brain (internal) | `$VECTOR_BRAIN_URL` (Runtime 1) |
| Model Forge (internal) | `$MODEL_FORGE_URL` (Runtime 2) |
| Conductor (internal) | `$CONDUCTOR_URL` (Runtime 3) |
| Liquid Nodes | `$LIQUID_NODES_URL` (default: `http://localhost:3000`) |

All external requests require `Authorization: Bearer <access_token>` unless marked `(public)`.

---

## Vector Brain API

### `POST /embed`

Convert one or more texts to vector embeddings.

**Request:**
```json
{
  "texts": ["Sacred geometry and AI architecture", "PHI ratio in memory pools"],
  "model": "all-MiniLM-L6-v2",
  "normalize": true
}
```

**Response:**
```json
{
  "embeddings": [
    [0.021, -0.134, 0.782, ...],  // 384 dimensions
    [0.045,  0.219, 0.601, ...]
  ],
  "model": "all-MiniLM-L6-v2",
  "dimensions": 384,
  "duration_ms": 144
}
```

---

### `POST /search`

Search the FAISS index for nearest neighbors.

**Request:**
```json
{
  "query": "explain phi-based memory allocation",
  "top_k": 5,
  "csl_gate": "boost",
  "filter": { "domain": "headyme.com", "type": "document" },
  "include_metadata": true
}
```

**Response:**
```json
{
  "results": [
    {
      "id": "doc_abc123",
      "score": 0.892,
      "csl_gate_applied": "boost",
      "metadata": { "title": "Memory Architecture", "source": "headyme.com" },
      "text_preview": "Pool allocation follows Fibonacci percentages..."
    }
  ],
  "total_searched": 15234,
  "duration_ms": 89,
  "phi_score": 0.618
}
```

---

### `POST /csl-gate`

Apply a Cognitive Semantic Logic gate to a scored result set.

**Request:**
```json
{
  "results": [...],
  "gate": "AND",
  "threshold": 0.618,
  "secondary_query": "fibonacci memory"
}
```

**Gate types:** `AND`, `OR`, `NOT`, `IMPLY`, `XOR`, `CONSENSUS`

**Response:**
```json
{
  "filtered_results": [...],
  "gate": "AND",
  "input_count": 10,
  "output_count": 4,
  "threshold_applied": 0.618
}
```

---

### `GET /drift`

Check the current semantic drift status of the index.

**Response:**
```json
{
  "drift_detected": false,
  "centroid_shift": 0.012,
  "threshold": 0.05,
  "last_snapshot": "2026-03-09T08:00:00Z",
  "vectors_since_snapshot": 1597,
  "recommendation": "stable"
}
```

---

### `GET /topology`

Return the current graph topology of the vector space.

**Response:**
```json
{
  "clusters": 13,
  "avg_cluster_size": 1170,
  "density": 0.618,
  "outlier_count": 34,
  "phi_coherence": 0.891
}
```

---

## Model Forge API

### `POST /infer`

Single-turn LLM inference.

**Request:**
```json
{
  "prompt": "Explain the role of PHI in Fibonacci batch scheduling.",
  "system": "You are a Heady AI architecture expert.",
  "provider": "anthropic",
  "model": "claude-3-5-sonnet-20241022",
  "max_tokens": 1024,
  "temperature": 0.618,
  "stream": false
}
```

**Response:**
```json
{
  "content": "PHI (1.618...) governs batch sizes by...",
  "provider": "anthropic",
  "model": "claude-3-5-sonnet-20241022",
  "tokens_in": 89,
  "tokens_out": 233,
  "duration_ms": 1597,
  "finish_reason": "end_turn"
}
```

---

### `POST /infer/batch`

Batch multiple prompts in a single Fibonacci-sized dispatch.

**Request:**
```json
{
  "requests": [
    { "id": "r1", "prompt": "What is PHI?", "max_tokens": 256 },
    { "id": "r2", "prompt": "What is PSI?", "max_tokens": 256 },
    { "id": "r3", "prompt": "What is a CSL gate?", "max_tokens": 512 }
  ],
  "provider": "openai",
  "model": "gpt-4o-mini",
  "batch_size": 8
}
```

**Response:**
```json
{
  "results": [
    { "id": "r1", "content": "PHI is 1.618...", "tokens_out": 89 },
    { "id": "r2", "content": "PSI is 0.618...", "tokens_out": 76 },
    { "id": "r3", "content": "A CSL gate applies...", "tokens_out": 144 }
  ],
  "batch_id": "bat_phi_001",
  "total_duration_ms": 2584,
  "provider": "openai"
}
```

---

### `GET /providers`

List available inference providers and their current health.

**Response:**
```json
{
  "providers": [
    { "id": "anthropic", "status": "healthy", "latency_p50_ms": 1200, "models": ["claude-3-5-sonnet-20241022", "claude-3-haiku-20240307"] },
    { "id": "openai",    "status": "healthy", "latency_p50_ms": 980,  "models": ["gpt-4o", "gpt-4o-mini"] },
    { "id": "gemini",    "status": "healthy", "latency_p50_ms": 1100, "models": ["gemini-1.5-pro", "gemini-1.5-flash"] }
  ]
}
```

---

## Conductor API

### `POST /task`

Submit a task for DAG-based orchestration.

**Request:**
```json
{
  "goal": "Research PHI in architecture and produce a summary",
  "context": ["PHI = 1.618...", "Fibonacci sequence..."],
  "max_steps": 8,
  "mode": "auto",
  "priority": 2
}
```

**Response:**
```json
{
  "task_id": "tsk_phi_8f3a2b",
  "status": "queued",
  "dag_nodes": 6,
  "estimated_duration_ms": 8000,
  "bees_allocated": 3
}
```

---

### `POST /decompose`

Decompose a goal into a DAG without executing it.

**Request:**
```json
{
  "goal": "Summarize the key points from these documents",
  "context_length": 8192,
  "max_depth": 5
}
```

**Response:**
```json
{
  "dag": {
    "nodes": [
      { "id": "embed",     "type": "EmbedBee",    "deps": [] },
      { "id": "search",    "type": "SearchBee",   "deps": ["embed"] },
      { "id": "infer",     "type": "InferBee",    "deps": ["search"] },
      { "id": "critique",  "type": "CritiqueBee", "deps": ["infer"] },
      { "id": "revise",    "type": "InferBee",    "deps": ["critique"] }
    ],
    "critical_path": ["embed", "search", "infer", "critique", "revise"],
    "estimated_ms": 5500
  }
}
```

---

### `POST /pipeline`

Execute a predefined multi-step pipeline.

**Request:**
```json
{
  "pipeline": "research_and_summarize",
  "inputs": { "query": "Explain CSL gates", "top_k": 5 },
  "options": { "provider": "anthropic", "consensus": false }
}
```

**Response:**
```json
{
  "pipeline_id": "pip_abc789",
  "output": "CSL gates are semantic logic operators...",
  "steps_completed": 5,
  "duration_ms": 4181,
  "tokens_total": 2048
}
```

---

### `POST /consensus`

Run the same prompt across multiple providers and aggregate votes.

**Request:**
```json
{
  "prompt": "Is PHI = 1.618033988749895?",
  "providers": ["anthropic", "openai", "gemini"],
  "aggregation": "majority",
  "confidence_threshold": 0.618
}
```

**Response:**
```json
{
  "consensus": "Yes, PHI ≈ 1.618033988749895",
  "agreement_score": 1.0,
  "votes": [
    { "provider": "anthropic", "response": "Yes...", "confidence": 0.99 },
    { "provider": "openai",    "response": "Yes...", "confidence": 0.98 },
    { "provider": "gemini",    "response": "Yes...", "confidence": 0.97 }
  ]
}
```

---

### `POST /heal`

Trigger a self-healing sweep on a failed or stalled task.

**Request:**
```json
{ "task_id": "tsk_phi_8f3a2b", "strategy": "retry_failed_nodes" }
```

**Response:**
```json
{
  "task_id": "tsk_phi_8f3a2b",
  "healed": true,
  "nodes_retried": 2,
  "new_status": "running"
}
```

---

## Auth Gateway API

### `POST /auth/login`

```
POST /auth/login
Content-Type: application/json

{ "email": "user@headyme.com", "password": "..." }

→ 200 { "access_token": "...", "refresh_token": "...", "expires_in": 900 }
→ 401 { "error": "invalid_credentials" }
```

### `POST /auth/register`

```
POST /auth/register
{ "email": "user@headyme.com", "password": "...", "name": "..." }

→ 201 { "user_id": "usr_abc123", "email": "user@headyme.com" }
→ 409 { "error": "email_already_registered" }
```

### `POST /auth/refresh`

```
POST /auth/refresh
Cookie: refresh_token=<token>

→ 200 { "access_token": "...", "expires_in": 900 }
→ 401 { "error": "refresh_token_invalid_or_expired" }
```

### `POST /auth/logout`

```
POST /auth/logout
Authorization: Bearer <access_token>

→ 204 (No Content)
```

### `GET /auth/verify`

```
GET /auth/verify
Authorization: Bearer <access_token>

→ 200 { "valid": true, "sub": "usr_abc123", "exp": 1741650320 }
→ 401 { "valid": false, "reason": "token_expired" }
```

### `GET /auth/.well-known/openid-configuration`

```
GET /auth/.well-known/openid-configuration  (public)

→ 200 {
    "issuer": "https://auth.headyme.com",
    "authorization_endpoint": "/auth/authorize",
    "token_endpoint": "/auth/token",
    "jwks_uri": "/auth/.well-known/jwks.json",
    "response_types_supported": ["code"],
    "grant_types_supported": ["authorization_code", "refresh_token", "client_credentials"],
    "scopes_supported": ["openid", "profile", "email", "api:read", "api:write"]
  }
```

---

## Error Codes

| Code | HTTP | Meaning |
|---|---|---|
| `invalid_credentials` | 401 | Wrong email or password |
| `token_expired` | 401 | JWT past expiry |
| `token_invalid` | 401 | Malformed or tampered JWT |
| `refresh_token_reuse` | 401 | Replay attack detected — session revoked |
| `insufficient_scope` | 403 | Token lacks required scope |
| `rate_limit_exceeded` | 429 | Fibonacci tier limit hit |
| `runtime_unavailable` | 503 | Target Colab runtime unreachable |
| `dag_execution_failed` | 500 | One or more DAG nodes failed after retries |
| `consensus_failed` | 500 | Insufficient provider agreement |
