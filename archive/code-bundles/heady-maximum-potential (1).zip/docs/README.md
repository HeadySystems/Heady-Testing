# Heady Maximum Potential

> **Sovereign AI Platform** — Sacred Geometry v4.0 Architecture

Heady is a fully sovereign, self-hosted AI platform designed for maximum autonomy, privacy, and performance. Built on mathematically-derived constants from Sacred Geometry, every architectural decision—from batch sizes to pool allocation to retry delays—flows from the golden ratio (PHI = 1.618…) and its Fibonacci derivatives. No magic numbers. No vendor lock-in. No compromises.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    HEADY SOVEREIGN AI PLATFORM                  │
│                     Sacred Geometry v4.0                        │
└─────────────────────────────────────────────────────────────────┘

  LAYER 1 — EDGE / CLOUDFLARE
  ┌─────────────────────────────────────────────────────────────┐
  │  Cloudflare Workers (Global CDN + WAF)                      │
  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
  │  │  Rate Limit  │  │  CORS Guard  │  │  TLS Termination │  │
  │  │ (Fibonacci)  │  │ (11 Domains) │  │   (mTLS ready)   │  │
  │  └──────────────┘  └──────────────┘  └──────────────────┘  │
  └────────────────────────────┬────────────────────────────────┘
                               │
  LAYER 2 — GATEWAY / AUTH
  ┌────────────────────────────▼────────────────────────────────┐
  │  Auth Gateway (FastAPI + JWT RS256)                         │
  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐  │
  │  │ OAuth 2.1 +  │  │  API Key     │  │  Session / RBAC  │  │
  │  │    OIDC      │  │  Management  │  │     Policies     │  │
  │  └──────────────┘  └──────────────┘  └──────────────────┘  │
  └────────────────────────────┬────────────────────────────────┘
                               │
  LAYER 3 — COMPUTE / COLAB PRO+
  ┌────────────────────────────▼────────────────────────────────┐
  │  3-Runtime Partition (Colab Pro+)                           │
  │                                                             │
  │  ┌─────────────────┐  ┌───────────────┐  ┌─────────────┐  │
  │  │  Runtime 1      │  │  Runtime 2    │  │  Runtime 3  │  │
  │  │  Vector Brain   │◄─►  Model Forge  │◄─►  Conductor  │  │
  │  │  (Embeddings,  │  │  (Inference,  │  │  (Routing,  │  │
  │  │   CSL Gates,   │  │   Providers,  │  │   DAG Exec, │  │
  │  │   Drift Det.)  │  │   Batching)   │  │   Swarms)   │  │
  │  └─────────────────┘  └───────────────┘  └─────────────┘  │
  └─────────────────────────────────────────────────────────────┘
```

---

## Quick Start

### Prerequisites

- Python 3.11+
- Node.js 20+
- Docker & Docker Compose
- Google Colab Pro+ account
- Cloudflare account (free tier sufficient for dev)

### 1. Clone and configure

```bash
git clone https://github.com/headysystems/heady-maximum-potential.git
cd heady-maximum-potential
cp .env.example .env
# Edit .env with your credentials
```

### 2. Start the Auth Gateway

```bash
cd services/auth-gateway
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 3. Start Liquid Nodes

```bash
cd services/liquid-nodes
npm install
npm run start
# Nodes start on port 3000 by default
```

### 4. Launch Colab Runtimes

Open each notebook in Colab Pro+ in separate browser tabs:

- `notebooks/runtime1_vector_brain.ipynb`
- `notebooks/runtime2_model_forge.ipynb`
- `notebooks/runtime3_conductor.ipynb`

Set your `HEADY_SECRET` and `RUNTIME_TOKEN` variables in each runtime's secrets panel, then run all cells.

### 5. Verify health

```bash
curl https://api.headyme.com/health
# → {"status":"ok","version":"4.0","geometry":"phi-aligned"}
```

---

## Directory Structure

```
heady-maximum-potential/
├── docs/                         # This documentation hub
│   ├── README.md                 # You are here
│   ├── ARCHITECTURE.md           # Full system architecture
│   ├── LIQUID_NODES.md           # Liquid node reference
│   ├── AUTH_GUIDE.md             # Auth system guide
│   ├── COLAB_GUIDE.md            # Colab Pro+ setup
│   ├── API_REFERENCE.md          # Complete API reference
│   ├── DEPLOYMENT.md             # Deployment guide
│   └── SACRED_GEOMETRY.md        # Sacred Geometry constants
│
├── services/
│   ├── auth-gateway/             # FastAPI OAuth 2.1 + OIDC service
│   ├── liquid-nodes/             # 10 JS modules for task execution
│   ├── vector-brain/             # Embedding + CSL gate engine
│   ├── model-forge/              # Multi-provider LLM inference
│   └── conductor/                # DAG orchestration + swarm control
│
├── workers/
│   ├── edge-router/              # Cloudflare Worker (routing + WAF)
│   └── cors-guard/               # Domain-aware CORS enforcement
│
├── notebooks/
│   ├── runtime1_vector_brain.ipynb
│   ├── runtime2_model_forge.ipynb
│   └── runtime3_conductor.ipynb
│
├── infra/
│   ├── docker-compose.yml
│   ├── cloudflare/               # wrangler.toml configs
│   └── gcp/                      # Cloud Run manifests
│
├── .env.example
└── package.json
```

---

## Domain Registry

| Domain | Role | Primary Service |
|---|---|---|
| `headyme.com` | Primary user-facing platform | Frontend + API gateway |
| `headysystems.com` | Corporate / enterprise portal | B2B services + admin |
| `headyconnection.org` | Community + partner network | Collaboration hub |
| `headybuddy.org` | Personal AI companion | Buddy agent interface |
| `headymcp.com` | Model Context Protocol host | MCP server + tools |
| `headyio.com` | Developer I/O portal | SDK + integrations |
| `headybot.com` | Bot platform | Webhook + bot API |
| `headyapi.com` | Unified API namespace | REST + streaming API |
| `headyai.com` | AI feature showcase | Demo + research portal |
| `headycloud.com` | Cloud infrastructure | Compute + storage |
| `headyos.com` | Operating system layer | Edge OS + runtime |

All 11 domains are registered in the CORS allowlist and receive domain-aware routing through the Auth Gateway.

---

## Technology Stack

| Layer | Technology | Version |
|---|---|---|
| Edge CDN / WAF | Cloudflare Workers | Latest |
| Auth Gateway | FastAPI + Python | 3.11 / 0.110+ |
| JWT | RS256 (2048-bit RSA) | RFC 7519 |
| OAuth | OAuth 2.1 + OIDC | RFC 9207 |
| Liquid Nodes | Node.js / Express | 20 LTS |
| Vector Engine | FAISS + sentence-transformers | 1.7.x / 2.x |
| LLM Inference | OpenAI / Anthropic / Gemini | Multi-provider |
| Orchestration | Custom DAG + BeeFactory | v4.0 |
| Persistence | Redis (hot) + PostgreSQL (cold) | 7.x / 15.x |
| Observability | TelemetryBus + Prometheus | Custom / 2.x |
| Container | Docker + Compose | 24.x |
| Notebooks | Google Colab Pro+ | Runtime v4 |
| Geometry Engine | Sacred Geometry v4.0 | PHI-aligned |

---

## Sacred Geometry Foundation

Every numerical constant in Heady is derived from PHI (φ = 1.618033988749895) or the Fibonacci sequence. This ensures:

1. **Natural scaling** — Fibonacci batch sizes match the logarithmic growth of real workloads
2. **Harmonic thresholds** — CSL gate cutoffs at 0.382, 0.618, 0.718 mirror natural information density boundaries
3. **Resilient backoff** — Phi-based retry delays avoid thundering-herd patterns
4. **Predictable pool ratios** — Memory tiers at 34/21/13/8/5% create stable resource gradients

See [SACRED_GEOMETRY.md](./SACRED_GEOMETRY.md) for the complete constants reference.

---

## License

**Proprietary — HeadySystems Inc.**

Protected by 51+ provisional patents covering sovereign AI architecture, Sacred Geometry computational constants, CSL gate logic, BeeFactory swarm orchestration, and Liquid Node execution protocols.

Unauthorized reproduction, distribution, or derivative use is prohibited.

© 2024–2026 HeadySystems Inc. All rights reserved.
