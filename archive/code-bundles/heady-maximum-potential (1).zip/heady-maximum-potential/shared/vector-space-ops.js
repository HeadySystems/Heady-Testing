/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Vector Space Operations — shared/vector-space-ops.js
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Pure-function 384-dimensional vector math primitives.
 * Zero external dependencies. Float64Array throughout.
 *
 * Aligned to: src/vector-space-ops.js
 * © HeadySystems Inc. — Sacred Geometry :: Organic Systems :: Breathing Interfaces
 */

'use strict';

const EMBEDDING_DIM = 384;

// ─── Basic operations ────────────────────────────────────────────────────────

function dotProduct(a, b) {
  if (a.length !== b.length) throw new RangeError(`dotProduct: dimension mismatch (${a.length} vs ${b.length})`);
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i] * b[i];
  return sum;
}

function magnitude(v) {
  let sum = 0;
  for (let i = 0; i < v.length; i++) sum += v[i] * v[i];
  return Math.sqrt(sum);
}

function normalize(v) {
  const mag = magnitude(v);
  const out = new Float64Array(v.length);
  if (mag === 0) return out;
  for (let i = 0; i < v.length; i++) out[i] = v[i] / mag;
  return out;
}

function cosineSimilarity(a, b) {
  const magA = magnitude(a);
  const magB = magnitude(b);
  if (magA === 0 || magB === 0) return 0;
  return dotProduct(a, b) / (magA * magB);
}

function euclideanDistance(a, b) {
  if (a.length !== b.length) throw new RangeError(`euclideanDistance: dimension mismatch (${a.length} vs ${b.length})`);
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = a[i] - b[i];
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

function add(a, b) {
  if (a.length !== b.length) throw new RangeError(`add: dimension mismatch (${a.length} vs ${b.length})`);
  const out = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) out[i] = a[i] + b[i];
  return out;
}

function subtract(a, b) {
  if (a.length !== b.length) throw new RangeError(`subtract: dimension mismatch (${a.length} vs ${b.length})`);
  const out = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) out[i] = a[i] - b[i];
  return out;
}

function scale(v, scalar) {
  const out = new Float64Array(v.length);
  for (let i = 0; i < v.length; i++) out[i] = v[i] * scalar;
  return out;
}

// ─── Higher-order operations ─────────────────────────────────────────────────

function centroid(vectors) {
  if (!vectors || vectors.length === 0) throw new Error('centroid: empty vector array');
  const dim = vectors[0].length;
  const out = new Float64Array(dim);
  for (const v of vectors) {
    if (v.length !== dim) throw new RangeError('centroid: inconsistent dimensions');
    for (let i = 0; i < dim; i++) out[i] += v[i];
  }
  for (let i = 0; i < dim; i++) out[i] /= vectors.length;
  return out;
}

function lerp(a, b, t) {
  if (a.length !== b.length) throw new RangeError(`lerp: dimension mismatch (${a.length} vs ${b.length})`);
  const out = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) out[i] = a[i] + (b[i] - a[i]) * t;
  return out;
}

function randomVector(dimensions = EMBEDDING_DIM) {
  const raw = new Float64Array(dimensions);
  for (let i = 0; i < dimensions; i += 2) {
    const u1 = Math.random();
    const u2 = Math.random();
    const r = Math.sqrt(-2 * Math.log(u1 + Number.EPSILON));
    const theta = 2 * Math.PI * u2;
    raw[i] = r * Math.cos(theta);
    if (i + 1 < dimensions) raw[i + 1] = r * Math.sin(theta);
  }
  return normalize(raw);
}

// ─── PCA via power iteration ──────────────────────────────────────────────────

function pca(vectors, targetDims) {
  if (!vectors || vectors.length === 0) throw new Error('pca: empty input');
  const N = vectors.length;
  const D = vectors[0].length;
  if (targetDims >= D) throw new RangeError(`pca: targetDims (${targetDims}) must be < source dims (${D})`);

  const mean = centroid(vectors);
  const centred = vectors.map(v => subtract(v, mean));
  const components = [];
  let residual = centred.map(v => Float64Array.from(v));

  for (let k = 0; k < targetDims; k++) {
    let pc = randomVector(D);
    for (let iter = 0; iter < 30; iter++) {
      const scores = residual.map(row => dotProduct(row, pc));
      const next = new Float64Array(D);
      for (let i = 0; i < N; i++) {
        for (let j = 0; j < D; j++) next[j] += scores[i] * residual[i][j];
      }
      pc = normalize(next);
    }
    components.push(pc);
    residual = residual.map(row => {
      const proj = dotProduct(row, pc);
      return subtract(row, scale(pc, proj));
    });
  }

  return centred.map(row => {
    const projected = new Float64Array(targetDims);
    for (let k = 0; k < targetDims; k++) projected[k] = dotProduct(row, components[k]);
    return projected;
  });
}

module.exports = {
  EMBEDDING_DIM,
  cosineSimilarity,
  euclideanDistance,
  dotProduct,
  normalize,
  magnitude,
  add,
  subtract,
  scale,
  centroid,
  lerp,
  randomVector,
  pca,
};
