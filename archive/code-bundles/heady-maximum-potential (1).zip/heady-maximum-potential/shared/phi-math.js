/**
 * Heady™ Phi-Math Foundation — Sacred Geometry Constants & Utilities
 * The single source of truth for ALL scaling constants across the Heady™ ecosystem.
 *
 * NO MAGIC NUMBERS. Every constant derives from φ (golden ratio) or Fibonacci.
 *
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * CommonJS module — canonical format matching repo's src/shared/phi-math.js
 *
 * @module phi-math
 * @version 4.2.0
 */
'use strict';

// ─── CORE CONSTANTS ──────────────────────────────────────────────────────────

const PHI       = 1.6180339887498948;        // φ = (1 + √5) / 2
const PSI       = 0.6180339887498949;        // ψ = 1/φ = φ − 1
const PSI2      = 0.381966011250105;         // ψ² = 1 − ψ
const PHI_SQ    = 2.618033988749895;         // φ² = φ + 1
const PHI_CUBED = 4.23606797749979;          // φ³ = 2φ + 1

// ─── FIBONACCI SEQUENCE (first 21 terms, 0-indexed) ─────────────────────────

const FIB = [
  0, 1, 1, 2, 3, 5, 8, 13, 21, 34,
  55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765,
];

/**
 * Get the nth Fibonacci number (0-indexed).
 * Extends beyond the cached array via iterative computation.
 */
function fib(n) {
  if (n < 0) return 0;
  if (n < FIB.length) return FIB[n];
  let a = FIB[FIB.length - 2], b = FIB[FIB.length - 1];
  for (let i = FIB.length; i <= n; i++) [a, b] = [b, a + b];
  return b;
}

// ─── PHI-POWER TIMING (ms) ──────────────────────────────────────────────────

const PHI_TIMING = {
  PHI_1: Math.round(PHI * 1000),               // 1,618ms — quick retries
  PHI_2: Math.round(PHI_SQ * 1000),            // 2,618ms — short operations
  PHI_3: Math.round(PHI_CUBED * 1000),         // 4,236ms — standard operations
  PHI_4: Math.round(Math.pow(PHI, 4) * 1000),  // 6,854ms — API calls, webhooks
  PHI_5: Math.round(Math.pow(PHI, 5) * 1000),  // 11,090ms — complex operations
  PHI_6: Math.round(Math.pow(PHI, 6) * 1000),  // 17,944ms — trial execution
  PHI_7: Math.round(Math.pow(PHI, 7) * 1000),  // 29,034ms — heartbeat cycle
  PHI_8: Math.round(Math.pow(PHI, 8) * 1000),  // 46,979ms — long operations
  CYCLE: Math.round(Math.pow(PHI, 7) * 1000),  // alias for PHI_7
};

// ─── CSL GATE THRESHOLDS ────────────────────────────────────────────────────
// phiThreshold(level) = 1 − ψ^level × spread

function phiThreshold(level, spread = 0.5) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = {
  MINIMUM:  phiThreshold(0),    // ≈ 0.500
  LOW:      phiThreshold(1),    // ≈ 0.691
  MEDIUM:   phiThreshold(2),    // ≈ 0.809
  HIGH:     phiThreshold(3),    // ≈ 0.882
  CRITICAL: phiThreshold(4),    // ≈ 0.927
  DEFAULT:  PSI,                // 0.618 — standard CSL gate
};

// Relevance gates (from canonical phi-constants.js)
const RELEVANCE_GATES = {
  INCLUDE:  PSI2,               // ≈ 0.382 — minimum for consideration
  BOOST:    PSI,                // ≈ 0.618 — promoted
  INJECT:   PSI + 0.1,         // ≈ 0.718 — forced inject
  SUPPRESS: Math.pow(PSI, 3),  // ≈ 0.236 — below threshold
};

// Dedup and drift thresholds
const DEDUP_THRESHOLD           = 0.972;
const COHERENCE_DRIFT_THRESHOLD = CSL_THRESHOLDS.MEDIUM; // ≈ 0.809

// ─── PHI-BACKOFF ────────────────────────────────────────────────────────────

function phiBackoff(attempt, baseMs = 1000, maxMs = 60000) {
  const delay = Math.min(baseMs * Math.pow(PHI, attempt), maxMs);
  const jitter = delay * PSI2 * (Math.random() * 2 - 1); // ±38.2% jitter
  return Math.round(Math.max(0, delay + jitter));
}

const PHI_BACKOFF_SEQUENCE = [1000, 1618, 2618, 4236, 6854, 11090];

// Fibonacci retry backoff (deterministic, no jitter)
function fibRetryBackoff(attempt, baseMs = 100) {
  const idx = Math.min(attempt + 4, FIB.length - 1);
  return FIB[idx] * baseMs;
}

// ─── PHI-ADAPTIVE INTERVAL ─────────────────────────────────────────────────

function phiAdaptiveInterval(healthy, baseMs = 5000) {
  return healthy ? Math.round(baseMs * PHI) : Math.round(baseMs * PSI);
}

// ─── PHI-FUSION WEIGHTS ────────────────────────────────────────────────────

function phiFusionWeights(n) {
  const weights = [];
  let remaining = 1;
  for (let i = 0; i < n - 1; i++) {
    const w = remaining * PSI;
    weights.push(w);
    remaining -= w;
  }
  weights.push(remaining);
  return weights;
}

// ─── PHI-TOKEN BUDGETS ─────────────────────────────────────────────────────

function phiTokenBudgets(base = 8192) {
  return {
    working:   base,
    session:   Math.round(base * PHI_SQ),
    memory:    Math.round(base * Math.pow(PHI, 4)),
    artifacts: Math.round(base * Math.pow(PHI, 6)),
  };
}

// ─── PRESSURE LEVELS ────────────────────────────────────────────────────────

const PRESSURE_LEVELS = {
  NOMINAL:  { min: 0, max: PSI2 },                         // 0 – 0.382
  ELEVATED: { min: PSI2, max: PSI },                        // 0.382 – 0.618
  HIGH:     { min: PSI, max: 1 - Math.pow(PSI, 3) },       // 0.618 – 0.854
  CRITICAL: { min: 1 - Math.pow(PSI, 4) },                 // 0.910+
};

// ─── ALERT THRESHOLDS ───────────────────────────────────────────────────────

const ALERT_THRESHOLDS = {
  WARNING:  PSI,                        // 0.618
  CAUTION:  1 - PSI2,                   // 0.764  (1 − ψ²)
  CRITICAL: 1 - Math.pow(PSI, 3),      // 0.854
  EXCEEDED: 1 - Math.pow(PSI, 4),      // 0.910
  HARD_MAX: 1.0,
};

// ─── TIMEOUTS (seconds, from phi-constants.js) ──────────────────────────────

const TIMEOUTS = {
  CONNECT: PHI,                         // 1.618s
  REQUEST: PHI * PHI + 1,              // ~4.236s
  IDLE:    PHI * 8,                    // ~12.944s
  LONG:    PHI * 21,                   // ~33.978s
  MAX:     PHI * 55,                   // ~89.0s
};

// ─── RATE LIMITS (requests/window, from phi-constants.js) ───────────────────

const RATE_LIMITS = {
  ANONYMOUS:     fib(9),                // 34 req/min
  AUTHENTICATED: fib(10),               // 55 req/min
  PREMIUM:       fib(11),               // 89 req/min
  ENTERPRISE:    fib(12),               // 144 req/min
  INTERNAL:      fib(13),               // 233 req/min
};

// ─── SERVICE PORTS (from repo's phi-constants.js) ───────────────────────────

const PORTS = {
  MCP_SERVER:      3310,
  HEADY_BRAIN:     3311,
  HEADY_MEMORY:    3312,
  HEADY_MANAGER:   3313,
  AUTH_SESSION:     3314,
  API_GATEWAY:     3315,
  NOTIFICATION:    3316,
  BILLING:         3317,
  ANALYTICS:       3318,
  SEARCH:          3319,
  SCHEDULER:       3320,
  HEADY_SOUL:      3321,
  HEADY_VINCI:     3322,
  HEADY_CONDUCTOR: 3323,
  HEADY_CODER:     3324,
  HEADY_BATTLE:    3325,
  HEADY_BUDDY:     3326,
  HEADY_LENS:      3327,
  HEADY_MAID:      3328,
  HEADY_GUARD:     3329,
  HCFP:            3330,
  EDGE_AI:         3331,
};

// ─── AUTO-SUCCESS ENGINE CONSTANTS ──────────────────────────────────────────

const AUTO_SUCCESS = {
  CYCLE_MS:             PHI_TIMING.PHI_7,         // 29,034ms
  CATEGORIES:           fib(7),                    // 13 categories
  TASKS_TOTAL:          fib(12),                   // 144 tasks
  TASKS_PER_CATEGORY:   Math.floor(fib(12) / fib(7)), // 11 per category
  TASK_TIMEOUT_MS:      PHI_TIMING.PHI_3,         // 4,236ms
  MAX_RETRIES_PER_CYCLE:fib(4),                    // 3
  MAX_RETRIES_TOTAL:    fib(6),                    // 8
};

// ─── PIPELINE CONSTANTS ─────────────────────────────────────────────────────

const PIPELINE = {
  STAGES:               fib(8),                    // 21 stages
  MAX_CONCURRENT:       fib(6),                    // 8 concurrent tasks
  MAX_RETRIES:          fib(4),                    // 3 retries
  CONTEXT_COMPLETENESS: 0.92,                      // embedding density gate
  RECON_TIMEOUT_MS:     PHI_TIMING.PHI_4,         // 6,854ms
  TRIAL_TIMEOUT_MS:     PHI_TIMING.PHI_6,         // 17,944ms
  AWARENESS_TIMEOUT_MS: PHI_TIMING.PHI_5,         // 11,090ms
  SEARCH_TIMEOUT_MS:    PHI_TIMING.PHI_8,         // 46,979ms
  EVOLUTION_TIMEOUT_MS: PHI_TIMING.PHI_8,         // 46,979ms
};

// ─── BEE SCALING ────────────────────────────────────────────────────────────

const BEE_SCALING = {
  PRE_WARM_POOLS:    [fib(5), fib(6), fib(7), fib(8)], // [5, 8, 13, 21]
  SCALE_UP_FACTOR:   PHI,                                // queue > pool × φ
  SCALE_DOWN_FACTOR: 1 - 1 / PHI,                       // idle > pool × 0.382
  STALE_TIMEOUT_S:   fib(11),                            // 89s
  MAX_CONCURRENT:    fib(20),                            // 6765
};

// ─── RESOURCE ALLOCATION ────────────────────────────────────────────────────

const RESOURCE_POOLS = {
  HOT:        0.34,         // 34% — user-facing
  WARM:       0.21,         // 21% — important background
  COLD:       0.13,         // 13% — batch processing
  RESERVE:    0.08,         // 8%  — burst capacity
  GOVERNANCE: 0.05,         // 5%  — HeadyCheck/HeadyAssure always running
};

// ─── SCORING WEIGHTS ────────────────────────────────────────────────────────

const JUDGE_WEIGHTS = {
  CORRECTNESS: 0.34,
  SAFETY:      0.21,
  PERFORMANCE: 0.21,
  QUALITY:     0.13,
  ELEGANCE:    0.11,
};

const COST_WEIGHTS = {
  TIME:    PSI2,            // 0.382
  MONEY:   PSI2,            // 0.382
  QUALITY: Math.pow(PSI, 2), // 0.236
};

// ─── VECTOR MEMORY ──────────────────────────────────────────────────────────

const VECTOR = {
  DIMENSIONS:           384,
  PROJECTION_DIMS:      3,
  DRIFT_THRESHOLD:      PSI,                // 0.618
  COHERENCE_THRESHOLD:  phiThreshold(2),    // 0.809
  DEDUP_THRESHOLD:      DEDUP_THRESHOLD,    // 0.972
};

// ─── POOL SIZES (Fibonacci-based) ───────────────────────────────────────────

const POOL_SIZES = {
  min: fib(3),              // 2
  max: fib(7),              // 13
  idle_timeout_ms: fib(14) * 1000, // 377s
};

// ─── SIZING (Fibonacci) ─────────────────────────────────────────────────────

const SIZING = {
  BATCH_SMALL:   fib(6),   // 8
  BATCH_MEDIUM:  fib(8),   // 21
  BATCH_LARGE:   fib(10),  // 55
  CACHE_SMALL:   fib(12),  // 144
  CACHE_MEDIUM:  fib(14),  // 377
  CACHE_LARGE:   fib(16),  // 987
  HISTORY:       fib(17),  // 1597
  LRU_LARGE:     fib(20),  // 6765
};

// ─── VECTOR MATH FUNCTIONS ──────────────────────────────────────────────────

function cosineSimilarity(a, b) {
  let dot = 0, normA = 0, normB = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) {
    dot   += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

function normalize(vec) {
  let norm = 0;
  for (let i = 0; i < vec.length; i++) norm += vec[i] * vec[i];
  norm = Math.sqrt(norm);
  if (norm === 0) return vec;
  const result = new Float64Array(vec.length);
  for (let i = 0; i < vec.length; i++) result[i] = vec[i] / norm;
  return result;
}

// ─── CSL GATES (basic) ─────────────────────────────────────────────────────

/** CSL AND — cosine similarity as truth value */
function cslAND(a, b) { return cosineSimilarity(a, b); }

/** CSL OR — superposition (soft union) */
function cslOR(a, b) {
  const result = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) result[i] = a[i] + b[i];
  return normalize(result);
}

/** CSL NOT — orthogonal projection (semantic negation) */
function cslNOT(a, b) {
  const dot = cosineSimilarity(a, b);
  const result = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) result[i] = a[i] - dot * b[i];
  return normalize(result);
}

/** CSL CONSENSUS — weighted centroid */
function cslCONSENSUS(vectors, weights) {
  const dim = vectors[0].length;
  const result = new Float64Array(dim);
  const w = weights || vectors.map(() => 1 / vectors.length);
  for (let i = 0; i < vectors.length; i++) {
    for (let j = 0; j < dim; j++) result[j] += w[i] * vectors[i][j];
  }
  return normalize(result);
}

/** CSL GATE — soft sigmoid gating */
function cslGATE(value, cosScore, tau = CSL_THRESHOLDS.DEFAULT, temp = Math.pow(PSI, 3)) {
  const sig = 1 / (1 + Math.exp(-(cosScore - tau) / temp));
  return value * sig;
}

/** CSL XOR — exclusive components */
function cslXOR(a, b) {
  const or = cslOR(a, b);
  const proj = new Float64Array(a.length);
  const dot = cosineSimilarity(a, b);
  for (let i = 0; i < a.length; i++) proj[i] = or[i] - dot * (a[i] + b[i]) / 2;
  return normalize(proj);
}

// CSL gate function from phi-constants.js
function cslGate(signal, confidence, threshold = RELEVANCE_GATES.BOOST) {
  if (confidence < RELEVANCE_GATES.SUPPRESS) return 0;
  if (confidence < threshold) return signal * PSI2;
  if (confidence >= RELEVANCE_GATES.INJECT) return signal * PHI;
  return signal * confidence;
}

// ─── EXPORTS ────────────────────────────────────────────────────────────────

module.exports = {
  // Core
  PHI, PSI, PSI2, PHI_SQ, PHI_CUBED, FIB, fib,
  // Timing
  PHI_TIMING, TIMEOUTS,
  // Thresholds
  CSL_THRESHOLDS, RELEVANCE_GATES, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  phiThreshold,
  // Backoff
  phiBackoff, PHI_BACKOFF_SEQUENCE, fibRetryBackoff, phiAdaptiveInterval,
  // Fusion
  phiFusionWeights, phiTokenBudgets,
  // Pressure & alerts
  PRESSURE_LEVELS, ALERT_THRESHOLDS,
  // Domain constants
  AUTO_SUCCESS, PIPELINE, BEE_SCALING,
  // Resources
  RESOURCE_POOLS, POOL_SIZES, SIZING,
  JUDGE_WEIGHTS, COST_WEIGHTS,
  // Rate limits & ports
  RATE_LIMITS, PORTS,
  // Vector
  VECTOR,
  // Math functions
  cosineSimilarity, normalize,
  // CSL gates
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslGATE, cslXOR, cslGate,
};
