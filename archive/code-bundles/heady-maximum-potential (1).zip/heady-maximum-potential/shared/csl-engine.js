/**
 * Heady™ CSL Engine — Continuous Semantic Logic Gates
 * Aligned to repo's src/core/semantic-logic.js
 *
 * Gates: multi_resonance, route_gate, soft_gate, risk_gate,
 *        ternary_gate, orthogonal_gate, consensus_superposition,
 *        batch_orthogonal
 *
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 * @version 4.2.0
 */
'use strict';

const {
  PHI, PSI, PSI2, CSL_THRESHOLDS, RELEVANCE_GATES,
  cosineSimilarity, normalize,
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslGATE, cslXOR, cslGate,
} = require('./phi-math');

// ─── STATS TRACKING ─────────────────────────────────────────────────────────

const _stats = { gateInvocations: 0, routeDecisions: 0, riskEvaluations: 0 };

function getStats() { return { ..._stats }; }

// ─── NORMALIZE (typed array aware) ──────────────────────────────────────────

function _normalize(vec) {
  let norm = 0;
  for (let i = 0; i < vec.length; i++) norm += vec[i] * vec[i];
  norm = Math.sqrt(norm);
  if (norm === 0) return vec;
  const r = new Float32Array(vec.length);
  for (let i = 0; i < vec.length; i++) r[i] = vec[i] / norm;
  return r;
}

function _cosine(a, b) {
  let dot = 0, nA = 0, nB = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) { dot += a[i] * b[i]; nA += a[i] * a[i]; nB += b[i] * b[i]; }
  const d = Math.sqrt(nA) * Math.sqrt(nB);
  return d === 0 ? 0 : dot / d;
}

// ─── MULTI-RESONANCE ────────────────────────────────────────────────────────
/**
 * Score multiple candidate vectors against an intent vector.
 * Returns sorted scores with soft activation values.
 */
function multi_resonance(intentVec, candidates, threshold = 0.3) {
  _stats.gateInvocations++;
  const scores = candidates.map(c => {
    const sim = _cosine(intentVec, c.vector);
    // Soft activation: sigmoid around threshold
    const activation = 1 / (1 + Math.exp(-(sim - threshold) / (PSI * PSI)));
    return { id: c.id, score: +sim.toFixed(6), activation: +activation.toFixed(6) };
  });
  scores.sort((a, b) => b.score - a.score);
  return scores;
}

// ─── ROUTE GATE ─────────────────────────────────────────────────────────────
/**
 * Select the best candidate via multi-resonance + soft gate activation.
 * Returns the winning candidate, all scores, and fallback flag.
 */
function route_gate(intentVec, candidates, threshold = 0.3) {
  _stats.routeDecisions++;
  const scores = multi_resonance(intentVec, candidates, threshold);
  const best = scores[0];
  const fallback = best ? best.score < threshold : true;
  return { best, scores, fallback };
}

// ─── SOFT GATE ──────────────────────────────────────────────────────────────
/**
 * Continuous sigmoid gate — smooth transition instead of hard cutoff.
 * gate(x, tau, temp) = sigmoid((x - tau) / temp)
 */
function soft_gate(value, tau = 0.5, temperature = PSI * PSI) {
  _stats.gateInvocations++;
  const activation = 1 / (1 + Math.exp(-(value - tau) / temperature));
  return { value, activation: +activation.toFixed(6), gated: +(value * activation).toFixed(6) };
}

// ─── RISK GATE ──────────────────────────────────────────────────────────────
/**
 * Evaluate risk as a continuous function of proximity to a limit.
 * riskLevel ∈ [0, 1] — higher means closer to the limit.
 */
function risk_gate(current, limit, sensitivity = 0.8) {
  _stats.riskEvaluations++;
  if (limit <= 0) return { riskLevel: 0, proximity: 0 };
  const proximity = Math.min(current / limit, 1.0);
  // Apply sensitivity curve: risk = proximity^(1/sensitivity)
  const riskLevel = Math.pow(proximity, 1 / sensitivity);
  return {
    riskLevel: +riskLevel.toFixed(6),
    proximity: +proximity.toFixed(6),
    isRisky: riskLevel > PSI, // risk > 0.618 is concerning
  };
}

// ─── TERNARY GATE ───────────────────────────────────────────────────────────
/**
 * Classify a value into ternary state:
 *   +1 (resonant) if value >= upper
 *    0 (ephemeral) if lower <= value < upper
 *   -1 (repel) if value < lower
 */
function ternary_gate(value, upper = 0.7, lower = 0.3) {
  _stats.gateInvocations++;
  if (value >= upper) return { state: +1, label: 'resonant', value };
  if (value >= lower) return { state: 0, label: 'ephemeral', value };
  return { state: -1, label: 'repel', value };
}

// ─── ORTHOGONAL GATE ────────────────────────────────────────────────────────
/**
 * Strip influence of a blacklist vector from an intent vector.
 * Uses CSL NOT (orthogonal projection) to remove the component.
 */
function orthogonal_gate(intentVec, blacklistVec) {
  _stats.gateInvocations++;
  const dot = _cosine(intentVec, blacklistVec);
  const result = new Float32Array(intentVec.length);
  for (let i = 0; i < intentVec.length; i++) {
    result[i] = intentVec[i] - dot * blacklistVec[i];
  }
  return _normalize(result);
}

/**
 * Batch orthogonal projection — strip multiple blacklist vectors.
 */
function batch_orthogonal(intentVec, blacklistVecs) {
  let result = intentVec;
  for (const bv of blacklistVecs) {
    result = orthogonal_gate(result, bv);
  }
  return result;
}

// ─── CONSENSUS SUPERPOSITION ────────────────────────────────────────────────
/**
 * Create a composite vector from multiple vectors via superposition.
 * Equal-weighted sum, then normalized.
 */
function consensus_superposition(vectors, weights) {
  if (vectors.length === 0) return new Float32Array(0);
  const dim = vectors[0].length;
  const result = new Float32Array(dim);
  const w = weights || vectors.map(() => 1.0 / vectors.length);
  for (let i = 0; i < vectors.length; i++) {
    for (let j = 0; j < dim; j++) result[j] += w[i] * vectors[i][j];
  }
  return _normalize(result);
}

// ─── MoE COSINE ROUTER ─────────────────────────────────────────────────────
/**
 * Mixture-of-Experts router using cosine similarity instead of learned linear weights.
 */
function moeRoute(inputVec, expertGates, topK = 2, temperature = Math.pow(PSI, 3)) {
  _stats.gateInvocations++;
  const scores = expertGates.map((gate, idx) => ({
    index: idx,
    score: _cosine(inputVec, gate),
  }));

  // Softmax with temperature
  const maxScore = Math.max(...scores.map(s => s.score));
  const exps = scores.map(s => ({ ...s, exp: Math.exp((s.score - maxScore) / temperature) }));
  const sumExp = exps.reduce((s, e) => s + e.exp, 0);
  const probs = exps.map(e => ({ ...e, prob: e.exp / sumExp }));

  probs.sort((a, b) => b.prob - a.prob);
  return probs.slice(0, topK);
}

// ─── HDC/VSA OPERATIONS ─────────────────────────────────────────────────────

/** Bind (bipolar MAP): element-wise multiply */
function hdcBind(a, b) {
  const r = new Float32Array(a.length);
  for (let i = 0; i < a.length; i++) r[i] = a[i] * b[i];
  return r;
}

/** Bundle: majority-based combination */
function hdcBundle(vectors) {
  if (vectors.length === 0) return new Float32Array(0);
  const dim = vectors[0].length;
  const sum = new Float32Array(dim);
  for (const v of vectors) {
    for (let i = 0; i < dim; i++) sum[i] += v[i];
  }
  // Threshold: sign function
  const r = new Float32Array(dim);
  for (let i = 0; i < dim; i++) r[i] = sum[i] >= 0 ? 1 : -1;
  return r;
}

/** Permute: cyclic shift for sequence encoding */
function hdcPermute(vec, n = 1) {
  const dim = vec.length;
  const shift = ((n % dim) + dim) % dim;
  const r = new Float32Array(dim);
  for (let i = 0; i < dim; i++) r[(i + shift) % dim] = vec[i];
  return r;
}

// ─── EXPORTS ────────────────────────────────────────────────────────────────

module.exports = {
  // Re-export phi-math CSL gates
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslGATE, cslXOR, cslGate,
  // CSL engine gates (aligned to repo's semantic-logic.js)
  multi_resonance, route_gate, soft_gate, risk_gate,
  ternary_gate, orthogonal_gate, batch_orthogonal,
  consensus_superposition,
  // MoE router
  moeRoute,
  // HDC/VSA
  hdcBind, hdcBundle, hdcPermute,
  // Utils
  normalize: _normalize,
  cosine: _cosine,
  getStats,
};
