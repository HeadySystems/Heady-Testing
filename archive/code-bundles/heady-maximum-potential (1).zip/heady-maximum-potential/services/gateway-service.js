/**
 * Heady™ Gateway Service — API Gateway & Domain Router (Cloud Run)
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Aligned to repo's api-gateway + domain-router services.
 * Provides unified entry point, domain routing, CORS whitelisting,
 * rate limiting, structured logging, and health aggregation.
 *
 * Zero npm dependencies — Node.js built-in http only.
 * @version 4.2.0
 */
'use strict';

const http = require('node:http');
const { randomUUID } = require('node:crypto');

const {
  PHI, PSI, FIB, fib,
  RATE_LIMITS, PORTS, PHI_TIMING, CSL_THRESHOLDS,
  phiBackoff,
} = require('../shared/phi-math');

// ─── CONFIG ─────────────────────────────────────────────────────────────────

const PORT = parseInt(process.env.PORT || '4301', 10);
const CONDUCTOR_URL = process.env.CONDUCTOR_URL || `http://localhost:${PORTS.HEADY_CONDUCTOR}`;
const MEMORY_URL = process.env.MEMORY_URL || `http://localhost:${PORTS.HEADY_MEMORY}`;
const MCP_URL = process.env.MCP_URL || `http://localhost:${PORTS.MCP_SERVER}`;
const MANAGER_URL = process.env.HEADY_MANAGER_URL || `http://localhost:3301`;

// Domain registry (aligned to repo's workers/liquid-gateway-worker/src/site-registry.ts)
const DOMAIN_ROUTES = {
  'headyme.com':          { target: MANAGER_URL, label: 'Command Center' },
  'headysystems.com':     { target: CONDUCTOR_URL, label: 'Core Architecture' },
  'headyconnection.org':  { target: MANAGER_URL, label: 'Nonprofit & Community' },
  'headybuddy.org':       { target: MANAGER_URL, label: 'AI Companion' },
  'headymcp.com':         { target: MCP_URL, label: 'MCP Layer' },
  'headyio.com':          { target: MANAGER_URL, label: 'Developer Platform' },
  'headybot.com':         { target: CONDUCTOR_URL, label: 'Automation & Agents' },
  'headyapi.com':         { target: MANAGER_URL, label: 'Public Intelligence' },
  'headyai.com':          { target: CONDUCTOR_URL, label: 'Intelligence Hub' },
  'headycloud.com':       { target: CONDUCTOR_URL, label: 'Cloud Services' },
  'headyos.com':          { target: CONDUCTOR_URL, label: 'Latent OS' },
};

// CORS whitelist (explicit — no wildcards in production)
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || Object.keys(DOMAIN_ROUTES).map(d => `https://${d}`).join(','))
  .split(',').filter(Boolean).map(o => o.trim());

// Rate limiting per IP
const rateBuckets = new Map();

// ─── STRUCTURED LOGGER ──────────────────────────────────────────────────────

function log(level, msg, data = {}) {
  process.stdout.write(JSON.stringify({
    ts: new Date().toISOString(), service: 'heady-gateway', level, msg,
    correlationId: data.correlationId || undefined, ...data,
  }) + '\n');
}

// ─── RATE LIMITER (φ-scaled token bucket) ───────────────────────────────────

function checkRate(clientIp, tier = 'AUTHENTICATED') {
  const now = Date.now();
  const limit = RATE_LIMITS[tier] || RATE_LIMITS.AUTHENTICATED;

  let bucket = rateBuckets.get(clientIp);
  if (!bucket) { bucket = { tokens: limit, lastRefill: now }; rateBuckets.set(clientIp, bucket); }

  const elapsed = (now - bucket.lastRefill) / 60000; // minutes
  bucket.tokens = Math.min(limit, bucket.tokens + elapsed * limit);
  bucket.lastRefill = now;

  if (bucket.tokens < 1) {
    const waitMs = Math.ceil((1 - bucket.tokens) / limit * 60000);
    return { allowed: false, retryAfterMs: waitMs, remaining: 0 };
  }

  bucket.tokens -= 1;
  return { allowed: true, remaining: Math.floor(bucket.tokens) };
}

// Cleanup stale buckets every PHI_7 (~29s)
setInterval(() => {
  const cutoff = Date.now() - PHI_TIMING.PHI_8;
  for (const [ip, bucket] of rateBuckets) {
    if (bucket.lastRefill < cutoff) rateBuckets.delete(ip);
  }
}, PHI_TIMING.PHI_7);

// ─── PROXY (forward requests to internal services) ──────────────────────────

async function proxyRequest(targetUrl, req, body) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(targetUrl);
    const proxyReq = http.request(parsed, {
      method: req.method,
      headers: {
        'Content-Type': 'application/json',
        'X-Forwarded-For': req.socket.remoteAddress || 'unknown',
        'X-Correlation-Id': req.headers['x-correlation-id'] || randomUUID(),
      },
      timeout: PHI_TIMING.PHI_5, // 11s
    }, (proxyRes) => {
      const chunks = [];
      proxyRes.on('data', c => chunks.push(c));
      proxyRes.on('end', () => resolve({ status: proxyRes.statusCode, body: Buffer.concat(chunks).toString(), headers: proxyRes.headers }));
    });
    proxyReq.on('error', reject);
    proxyReq.on('timeout', () => { proxyReq.destroy(); reject(new Error('Proxy timeout')); });
    if (body) proxyReq.write(body);
    proxyReq.end();
  });
}

// ─── HTTP HELPERS ───────────────────────────────────────────────────────────

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString()));
    req.on('error', reject);
  });
}

function sendJson(res, status, data, extraHeaders = {}) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'X-Heady-Service': 'gateway',
    'X-Heady-Version': '4.2.0',
    ...extraHeaders,
  });
  res.end(body);
}

// ─── HEALTH AGGREGATION ─────────────────────────────────────────────────────

async function aggregateHealth() {
  const services = [
    { name: 'conductor', url: `${CONDUCTOR_URL}/health` },
    { name: 'memory', url: `${MEMORY_URL}/health` },
    { name: 'mcp', url: `${MCP_URL}/health` },
  ];

  const results = {};
  await Promise.allSettled(services.map(async (svc) => {
    try {
      const result = await proxyRequest(svc.url, { method: 'GET', headers: {}, socket: { remoteAddress: '127.0.0.1' } }, null);
      results[svc.name] = { status: result.status === 200 ? 'healthy' : 'degraded', code: result.status };
    } catch {
      results[svc.name] = { status: 'unreachable' };
    }
  }));

  return results;
}

// ─── HTTP SERVER ────────────────────────────────────────────────────────────

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;
  const correlationId = req.headers['x-correlation-id'] || randomUUID();
  const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';

  // CORS (explicit whitelist)
  const origin = req.headers.origin || '';
  if (ALLOWED_ORIGINS.includes(origin) || process.env.NODE_ENV !== 'production') {
    res.setHeader('Access-Control-Allow-Origin', origin || '*');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization,X-Correlation-Id');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('X-Correlation-Id', correlationId);
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  // Security headers
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  // Rate limiting
  const rateCheck = checkRate(clientIp);
  res.setHeader('X-RateLimit-Remaining', String(rateCheck.remaining || 0));
  if (!rateCheck.allowed) {
    res.setHeader('Retry-After', String(Math.ceil((rateCheck.retryAfterMs || 1000) / 1000)));
    return sendJson(res, 429, { error: 'Rate limit exceeded', retryAfterMs: rateCheck.retryAfterMs });
  }

  // Health
  if (path === '/health' || path === '/healthz') {
    return sendJson(res, 200, {
      status: 'healthy', service: 'heady-gateway', version: '4.2.0',
      domains: Object.keys(DOMAIN_ROUTES).length,
      uptime: process.uptime(), phi: PHI,
    });
  }

  if (path === '/ready') return sendJson(res, 200, { ready: true });

  // Health aggregation
  if (path === '/api/health' || path === '/api/health/aggregate') {
    return sendJson(res, 200, { ok: true, services: await aggregateHealth() });
  }

  // Domain registry
  if (path === '/api/domains') {
    return sendJson(res, 200, { ok: true, domains: DOMAIN_ROUTES });
  }

  // Route by host header (domain routing)
  const host = (req.headers.host || '').replace(/:\d+$/, '');
  const domainRoute = DOMAIN_ROUTES[host];

  // Proxy to internal services based on path prefix
  if (path.startsWith('/api/conductor')) {
    try {
      const body = req.method === 'POST' ? await readBody(req) : null;
      const result = await proxyRequest(`${CONDUCTOR_URL}${path}`, req, body);
      return sendJson(res, result.status, JSON.parse(result.body));
    } catch (err) {
      return sendJson(res, 502, { error: `Conductor proxy failed: ${err.message}` });
    }
  }

  if (path.startsWith('/api/memory') || path.startsWith('/store') || path.startsWith('/search')) {
    try {
      const body = req.method === 'POST' ? await readBody(req) : null;
      const result = await proxyRequest(`${MEMORY_URL}${path}`, req, body);
      return sendJson(res, result.status, JSON.parse(result.body));
    } catch (err) {
      return sendJson(res, 502, { error: `Memory proxy failed: ${err.message}` });
    }
  }

  if (path.startsWith('/api/mcp') || path === '/mcp') {
    try {
      const body = req.method === 'POST' ? await readBody(req) : null;
      const result = await proxyRequest(`${MCP_URL}${path}`, req, body);
      return sendJson(res, result.status, JSON.parse(result.body));
    } catch (err) {
      return sendJson(res, 502, { error: `MCP proxy failed: ${err.message}` });
    }
  }

  // Default: 404
  sendJson(res, 404, { error: 'Not found', gateway: 'heady-gateway', domains: Object.keys(DOMAIN_ROUTES) });
});

// ─── GRACEFUL SHUTDOWN ──────────────────────────────────────────────────────

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  log('info', `${signal} received, shutting down`);
  server.close(() => { log('info', 'Shutdown complete'); process.exit(0); });
  setTimeout(() => process.exit(1), Math.round(PHI * 10000));
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// ─── START ──────────────────────────────────────────────────────────────────

server.listen(PORT, '0.0.0.0', () => {
  log('info', `Gateway listening on :${PORT}`, {
    port: PORT, domains: Object.keys(DOMAIN_ROUTES).length,
    rateLimits: RATE_LIMITS,
  });
});
