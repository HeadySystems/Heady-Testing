/**
 * Heady™ Memory Service — RAM-First 384D Vector Memory (Cloud Run)
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Aligned to repo's src/vector-memory.js — VectorMemory class.
 * Stores 384D Float64Array embeddings in-memory Maps with namespace isolation,
 * cosine similarity search, drift detection, and JSONL persistence.
 *
 * Zero npm dependencies — Node.js built-in http only.
 * @version 4.2.0
 */
'use strict';

const http = require('node:http');
const { randomUUID } = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const readline = require('node:readline');

const {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, VECTOR, SIZING,
  cosineSimilarity, normalize,
  cslAND, cslOR, cslNOT,
  phiBackoff, phiAdaptiveInterval,
} = require('../shared/phi-math');

// ─── CONFIG ─────────────────────────────────────────────────────────────────

const PORT = parseInt(process.env.PORT || '4304', 10);
const EMBEDDING_DIM = VECTOR.DIMENSIONS;         // 384
const DRIFT_THRESHOLD = VECTOR.DRIFT_THRESHOLD;  // 0.618 (PSI)
const DEDUP_THRESHOLD = VECTOR.DEDUP_THRESHOLD;  // 0.972
const MAX_ENTRIES = SIZING.LRU_LARGE;            // 6765
const DATA_DIR = process.env.DATA_DIR || '/tmp/heady-memory';
const FLOAT64_BYTES = 8;

// ─── STRUCTURED LOGGER ──────────────────────────────────────────────────────

function log(level, msg, data = {}) {
  process.stdout.write(JSON.stringify({
    ts: new Date().toISOString(), service: 'heady-memory', level, msg, ...data,
  }) + '\n');
}

// ─── VECTOR MEMORY CLASS (aligned to repo) ──────────────────────────────────

class VectorMemory {
  constructor(opts = {}) {
    this._defaultNs = opts.defaultNamespace || 'default';
    /** @type {Map<string, Map<string, { vector: Float64Array, metadata: object, updatedAt: number }>>} */
    this._store = new Map();
    this._ensureNamespace(this._defaultNs);
    log('info', 'VectorMemory initialized', { dim: EMBEDDING_DIM, defaultNs: this._defaultNs });
  }

  _ensureNamespace(ns) {
    if (!this._store.has(ns)) this._store.set(ns, new Map());
  }

  _resolveKey(key, namespace) {
    const ns = namespace || this._defaultNs;
    this._ensureNamespace(ns);
    return { ns, map: this._store.get(ns) };
  }

  _toFloat64(v) {
    if (v instanceof Float64Array) return v;
    if (v instanceof Float32Array || Array.isArray(v)) return Float64Array.from(v);
    throw new TypeError('vector must be Array or Float32/64Array');
  }

  // ── CRUD ────────────────────────────────────────────────────────
  store(key, vector, metadata = {}, namespace) {
    const { ns, map } = this._resolveKey(key, namespace);
    const vec = this._toFloat64(vector);
    if (vec.length !== EMBEDDING_DIM) {
      log('warn', 'Non-standard embedding dimension', { key, dim: vec.length, expected: EMBEDDING_DIM });
    }

    // Dedup check
    for (const [k, entry] of map) {
      if (k !== key) {
        const sim = cosineSimilarity(vec, entry.vector);
        if (sim >= DEDUP_THRESHOLD) {
          log('debug', 'Dedup: near-identical vector exists', { key, existingKey: k, similarity: sim });
          // Update existing instead
          entry.metadata = { ...entry.metadata, ...metadata, _dedupFrom: key };
          entry.updatedAt = Date.now();
          return { stored: false, deduped: true, existingKey: k, similarity: sim };
        }
      }
    }

    // Eviction if at capacity (phi-weighted: oldest + least relevant)
    if (map.size >= MAX_ENTRIES) {
      const oldest = [...map.entries()].sort((a, b) => a[1].updatedAt - b[1].updatedAt)[0];
      if (oldest) { map.delete(oldest[0]); log('debug', 'Evicted entry', { key: oldest[0], ns }); }
    }

    map.set(key, { vector: vec, metadata: { ...metadata }, updatedAt: Date.now() });
    return { stored: true, key, ns };
  }

  get(key, namespace) {
    const { map } = this._resolveKey(key, namespace);
    const entry = map.get(key);
    if (!entry) return null;
    return { key, vector: Array.from(entry.vector), metadata: entry.metadata, updatedAt: entry.updatedAt };
  }

  update(key, vector, metadata = {}, namespace) {
    const existing = this.get(key, namespace);
    const mergedMeta = existing ? { ...existing.metadata, ...metadata } : metadata;
    return this.store(key, vector, mergedMeta, namespace);
  }

  delete(key, namespace) {
    const { map } = this._resolveKey(key, namespace);
    return map.delete(key);
  }

  clear(namespace) {
    const ns = namespace || this._defaultNs;
    if (this._store.has(ns)) { this._store.get(ns).clear(); }
  }

  // ── Search ──────────────────────────────────────────────────────
  search(queryVector, limit = fib(5), minScore = CSL_THRESHOLDS.DEFAULT, namespace) {
    const { map } = this._resolveKey(null, namespace);
    const query = this._toFloat64(queryVector);
    const results = [];

    for (const [key, entry] of map) {
      const score = cosineSimilarity(query, entry.vector);
      if (score >= minScore) results.push({ key, score, metadata: entry.metadata });
    }

    results.sort((a, b) => b.score - a.score);
    return results.slice(0, limit);
  }

  // CSL gate search — AND, OR, NOT operations
  cslSearch(queryVector, opts = {}) {
    const { andVectors = [], orVectors = [], notVectors = [], limit = fib(5), minScore = CSL_THRESHOLDS.DEFAULT, namespace } = opts;
    const { map } = this._resolveKey(null, namespace);
    let query = this._toFloat64(queryVector);

    // Apply NOT gates (strip unwanted directions)
    for (const nv of notVectors) query = normalize(cslNOT(query, this._toFloat64(nv)));

    // Apply OR gates (broaden search via superposition)
    for (const ov of orVectors) query = cslOR(query, this._toFloat64(ov));

    const results = [];
    for (const [key, entry] of map) {
      let score = cosineSimilarity(query, entry.vector);

      // Apply AND gates (require alignment with additional vectors)
      for (const av of andVectors) {
        const andScore = cosineSimilarity(entry.vector, this._toFloat64(av));
        score = Math.min(score, andScore);
      }

      if (score >= minScore) results.push({ key, score, metadata: entry.metadata });
    }

    results.sort((a, b) => b.score - a.score);
    return results.slice(0, limit);
  }

  // ── Drift Detection ─────────────────────────────────────────────
  detectDrift(vectorA, vectorB) {
    const similarity = cosineSimilarity(this._toFloat64(vectorA), this._toFloat64(vectorB));
    return { similarity, isDrifting: similarity < DRIFT_THRESHOLD, threshold: DRIFT_THRESHOLD };
  }

  // ── Stats ───────────────────────────────────────────────────────
  stats() {
    let totalVectors = 0;
    const namespaces = [];
    for (const [ns, map] of this._store) {
      totalVectors += map.size;
      namespaces.push({ name: ns, count: map.size });
    }
    return {
      totalVectors,
      namespaces,
      memoryEstimateBytes: totalVectors * (EMBEDDING_DIM * FLOAT64_BYTES + 200),
      maxEntries: MAX_ENTRIES,
      embeddingDim: EMBEDDING_DIM,
    };
  }

  // ── Persistence (JSONL) ─────────────────────────────────────────
  async persist(filePath) {
    const dir = path.dirname(filePath);
    await fs.promises.mkdir(dir, { recursive: true });
    const stream = fs.createWriteStream(filePath, { encoding: 'utf8' });
    for (const [ns, map] of this._store) {
      for (const [key, entry] of map) {
        stream.write(JSON.stringify({
          ns, key, vector: Array.from(entry.vector), metadata: entry.metadata, updatedAt: entry.updatedAt,
        }) + '\n');
      }
    }
    await new Promise((resolve, reject) => { stream.end(); stream.once('finish', resolve); stream.once('error', reject); });
    log('info', 'VectorMemory persisted', { filePath });
  }

  async load(filePath) {
    if (!fs.existsSync(filePath)) return 0;
    const fileStream = fs.createReadStream(filePath, { encoding: 'utf8' });
    const rl = readline.createInterface({ input: fileStream, crlfDelay: Infinity });
    let count = 0;
    for await (const line of rl) {
      if (!line.trim()) continue;
      try {
        const { ns, key, vector, metadata, updatedAt } = JSON.parse(line);
        this._ensureNamespace(ns);
        this._store.get(ns).set(key, {
          vector: Float64Array.from(vector),
          metadata: metadata || {},
          updatedAt: updatedAt || Date.now(),
        });
        count++;
      } catch { /* skip malformed */ }
    }
    log('info', 'VectorMemory loaded', { filePath, count });
    return count;
  }
}

// ─── SINGLETON ──────────────────────────────────────────────────────────────

const memory = new VectorMemory();

// ─── HTTP HELPERS ───────────────────────────────────────────────────────────

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString()));
    req.on('error', reject);
  });
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'X-Heady-Service': 'memory',
    'X-Heady-Version': '4.2.0',
  });
  res.end(body);
}

// ─── HTTP SERVER ────────────────────────────────────────────────────────────

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path_str = url.pathname;

  res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGINS || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  // Health
  if (path_str === '/health' || path_str === '/healthz') {
    return sendJson(res, 200, {
      status: 'healthy', service: 'heady-memory', version: '4.2.0',
      ...memory.stats(), uptime: process.uptime(), phi: PHI,
    });
  }

  if (path_str === '/ready') return sendJson(res, 200, { ready: true });

  // Store
  if (path_str === '/store' && req.method === 'POST') {
    try {
      const { key, vector, metadata, namespace } = JSON.parse(await readBody(req));
      const id = key || randomUUID();
      const result = memory.store(id, vector, metadata, namespace);
      return sendJson(res, 200, { ok: true, ...result });
    } catch (err) { return sendJson(res, 400, { ok: false, error: err.message }); }
  }

  // Get
  if (path_str === '/get' && req.method === 'POST') {
    const { key, namespace } = JSON.parse(await readBody(req));
    const entry = memory.get(key, namespace);
    return sendJson(res, entry ? 200 : 404, entry || { ok: false, error: 'Not found' });
  }

  // Search
  if (path_str === '/search' && req.method === 'POST') {
    try {
      const { query, vector, limit, minScore, threshold, namespace, gates } = JSON.parse(await readBody(req));
      const queryVec = vector || query; // accept either
      if (!queryVec) return sendJson(res, 400, { ok: false, error: 'query or vector required' });
      const results = memory.search(queryVec, limit, minScore || threshold, namespace);
      return sendJson(res, 200, { ok: true, results, count: results.length });
    } catch (err) { return sendJson(res, 400, { ok: false, error: err.message }); }
  }

  // CSL Search
  if (path_str === '/csl-search' && req.method === 'POST') {
    try {
      const opts = JSON.parse(await readBody(req));
      const results = memory.cslSearch(opts.query || opts.vector, opts);
      return sendJson(res, 200, { ok: true, results, count: results.length });
    } catch (err) { return sendJson(res, 400, { ok: false, error: err.message }); }
  }

  // Drift
  if (path_str === '/drift' && req.method === 'POST') {
    try {
      const { vectorA, vectorB, id, namespace } = JSON.parse(await readBody(req));
      if (id) {
        const entry = memory.get(id, namespace);
        if (!entry) return sendJson(res, 404, { ok: false, error: 'Entry not found' });
        return sendJson(res, 200, { ok: true, ...memory.detectDrift(entry.vector, vectorB || entry.vector) });
      }
      return sendJson(res, 200, { ok: true, ...memory.detectDrift(vectorA, vectorB) });
    } catch (err) { return sendJson(res, 400, { ok: false, error: err.message }); }
  }

  // Delete
  if (path_str === '/delete' && req.method === 'POST') {
    const { key, namespace } = JSON.parse(await readBody(req));
    return sendJson(res, 200, { ok: true, deleted: memory.delete(key, namespace) });
  }

  // Stats
  if (path_str === '/stats' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, ...memory.stats() });
  }

  // Persist
  if (path_str === '/persist' && req.method === 'POST') {
    try {
      const filePath = path.join(DATA_DIR, 'vectors.jsonl');
      await memory.persist(filePath);
      return sendJson(res, 200, { ok: true, filePath });
    } catch (err) { return sendJson(res, 500, { ok: false, error: err.message }); }
  }

  sendJson(res, 404, { error: 'Not found' });
});

// ─── GRACEFUL SHUTDOWN ──────────────────────────────────────────────────────

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  log('info', `${signal} received, persisting memory before shutdown`);
  try {
    await fs.promises.mkdir(DATA_DIR, { recursive: true });
    await memory.persist(path.join(DATA_DIR, 'vectors.jsonl'));
  } catch (err) { log('error', `Persist failed: ${err.message}`); }
  server.close(() => { log('info', 'Shutdown complete'); process.exit(0); });
  setTimeout(() => process.exit(1), Math.round(PHI * 10000));
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// ─── START ──────────────────────────────────────────────────────────────────

server.listen(PORT, '0.0.0.0', () => {
  log('info', `Memory service listening on :${PORT}`, {
    port: PORT, dim: EMBEDDING_DIM, maxEntries: MAX_ENTRIES,
    driftThreshold: DRIFT_THRESHOLD, dedupThreshold: DEDUP_THRESHOLD,
  });
});
