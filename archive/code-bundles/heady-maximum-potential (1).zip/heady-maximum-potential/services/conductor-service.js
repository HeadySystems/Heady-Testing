/**
 * Heady™ Conductor Service — Unified Orchestration API (Cloud Run)
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Central traffic controller for the multi-agent swarm.
 * Routes tasks to bees, manages heartbeats, tracks execution state,
 * and bridges local swarm to edge/cloud nodes.
 *
 * Aligned to repo's src/orchestration/heady-conductor.js
 * Patent: PPA #3 — Agentic Intelligence Network (AIN)
 *
 * Zero npm dependencies — Node.js built-in http only.
 * @version 4.2.0
 */
'use strict';

const http = require('node:http');
const { randomUUID } = require('node:crypto');
const EventEmitter = require('node:events');

const {
  PHI, PSI, PHI_SQ, PHI_CUBED, FIB, fib,
  PHI_TIMING, TIMEOUTS, CSL_THRESHOLDS, RESOURCE_POOLS,
  BEE_SCALING, PIPELINE, JUDGE_WEIGHTS,
  phiFusionWeights, phiBackoff, phiAdaptiveInterval,
  cosineSimilarity, cslGate,
} = require('../shared/phi-math');

// ─── CONFIG ─────────────────────────────────────────────────────────────────

const PORT = parseInt(process.env.PORT || '4306', 10);
const MEMORY_URL = process.env.MEMORY_URL || 'http://localhost:4304';
const HEARTBEAT_MS = PHI_TIMING.PHI_7; // ~29s — golden-ratio cadence
const ADMIN_TIMEOUT_MS = PHI_TIMING.PHI_8 * fib(7); // ~610s (10 min)
const STALE_THRESHOLD_MS = BEE_SCALING.STALE_TIMEOUT_S * 1000;
const MAX_EXECUTION_LOG = fib(12); // 144 entries

// ─── STRUCTURED LOGGER ──────────────────────────────────────────────────────

function log(level, msg, data = {}) {
  const entry = {
    ts: new Date().toISOString(),
    service: 'heady-conductor',
    level,
    msg,
    ...data,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── HEADY CONDUCTOR ────────────────────────────────────────────────────────

class HeadyConductor extends EventEmitter {
  constructor() {
    super();
    this.bees = new Map();            // beeId → { bee, status, lastHeartbeat, taskCount, category, domain }
    this.taskQueue = [];              // pending tasks
    this.activeExecutions = new Map(); // executionId → { beeId, taskType, payload, startTime }
    this.executionLog = [];           // completed executions
    this.heartbeatTimer = null;
    this.totalDispatched = 0;
    this.totalCompleted = 0;
    this.totalFailed = 0;
  }

  // ── Bee Registration ──────────────────────────────────────────
  registerBee(beeId, bee) {
    this.bees.set(beeId, {
      bee,
      status: 'idle',
      lastHeartbeat: Date.now(),
      taskCount: 0,
      registered: Date.now(),
      category: bee.category || beeId,
      domain: bee.domain || beeId,
    });
    this.emit('bee:registered', { beeId });
    log('info', `Registered bee: ${beeId}`, { beeId, category: bee.category });
  }

  unregisterBee(beeId) {
    this.bees.delete(beeId);
    this.emit('bee:unregistered', { beeId });
    log('info', `Unregistered bee: ${beeId}`);
  }

  // ── Task Dispatch ─────────────────────────────────────────────
  async dispatch(taskType, payload, opts = {}) {
    const executionId = `exec_${Date.now()}_${randomUUID().slice(0, 8)}`;

    // Route: explicit beeId > category match > domain match > first idle
    let targetBee = null;
    if (opts.beeId && this.bees.has(opts.beeId)) {
      targetBee = opts.beeId;
    } else {
      for (const [id, entry] of this.bees) {
        if (entry.bee.category === taskType || entry.bee.domain === taskType) {
          targetBee = id;
          break;
        }
      }
      if (!targetBee) {
        for (const [id, entry] of this.bees) {
          if (entry.status === 'idle') { targetBee = id; break; }
        }
      }
    }

    if (!targetBee) {
      this.totalFailed++;
      log('warn', `No available bee for task type: ${taskType}`, { taskType, executionId });
      return { ok: false, error: `No available bee for: ${taskType}`, executionId };
    }

    const entry = this.bees.get(targetBee);
    entry.status = 'busy';
    entry.taskCount++;
    this.totalDispatched++;

    this.activeExecutions.set(executionId, {
      beeId: targetBee,
      taskType,
      payload,
      startTime: Date.now(),
    });

    this.emit('task:dispatched', { executionId, beeId: targetBee, taskType });

    try {
      const timeout = opts.timeout || PHI_TIMING.CYCLE;
      const result = await Promise.race([
        this._executeBee(entry.bee, payload),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Execution timeout')), timeout)
        ),
      ]);

      const durationMs = Date.now() - this.activeExecutions.get(executionId)?.startTime || 0;
      entry.status = 'idle';
      this.totalCompleted++;
      this.activeExecutions.delete(executionId);

      const execution = { executionId, beeId: targetBee, taskType, result, durationMs, completedAt: Date.now() };
      this.executionLog.push(execution);
      if (this.executionLog.length > MAX_EXECUTION_LOG) this.executionLog.shift();

      this.emit('task:completed', execution);
      return { ok: true, executionId, result, durationMs };

    } catch (err) {
      entry.status = 'idle';
      this.totalFailed++;
      this.activeExecutions.delete(executionId);
      this.emit('task:failed', { executionId, beeId: targetBee, error: err.message });
      log('error', `Task failed: ${err.message}`, { executionId, beeId: targetBee });
      return { ok: false, executionId, error: err.message };
    }
  }

  async _executeBee(bee, payload) {
    if (typeof bee.getWork === 'function') {
      const workers = bee.getWork(payload);
      if (workers.length > 0) return workers[0]();
    }
    if (typeof bee.execute === 'function') return bee.execute(payload);
    return { error: 'Bee has no executable workers' };
  }

  // ── Admin Dispatch ────────────────────────────────────────────
  async adminDispatch(taskType, payload) {
    log('info', `ADMIN dispatch: ${taskType}`, { taskType });
    this.emit('admin:dispatch', { taskType, timestamp: Date.now() });
    return this.dispatch(taskType, payload, { priority: 'admin', timeout: ADMIN_TIMEOUT_MS });
  }

  // ── Heartbeat Monitor ─────────────────────────────────────────
  startHeartbeat() {
    if (this.heartbeatTimer) return;
    this.heartbeatTimer = setInterval(() => {
      const now = Date.now();
      for (const [id, entry] of this.bees) {
        entry.lastHeartbeat = now;
        for (const [execId, exec] of this.activeExecutions) {
          if (exec.beeId === id && (now - exec.startTime) > STALE_THRESHOLD_MS) {
            log('warn', `Stale execution: ${execId} on bee ${id}`);
            this.emit('execution:stale', { executionId: execId, beeId: id });
          }
        }
      }
      this.emit('heartbeat', { beeCount: this.bees.size, timestamp: now });
    }, HEARTBEAT_MS);
  }

  stopHeartbeat() {
    if (this.heartbeatTimer) { clearInterval(this.heartbeatTimer); this.heartbeatTimer = null; }
  }

  // ── Status ────────────────────────────────────────────────────
  getStatus() {
    const beeStatus = {};
    for (const [id, entry] of this.bees) {
      beeStatus[id] = {
        status: entry.status,
        taskCount: entry.taskCount,
        lastHeartbeat: entry.lastHeartbeat,
        category: entry.category,
        domain: entry.domain,
      };
    }
    return {
      bees: beeStatus,
      totalRegistered: this.bees.size,
      totalDispatched: this.totalDispatched,
      totalCompleted: this.totalCompleted,
      totalFailed: this.totalFailed,
      activeExecutions: this.activeExecutions.size,
      recentExecutions: this.executionLog.slice(-fib(5)),
      heartbeatActive: !!this.heartbeatTimer,
      heartbeatIntervalMs: HEARTBEAT_MS,
      resourcePools: RESOURCE_POOLS,
      pipeline: PIPELINE,
    };
  }
}

// ─── SINGLETON ──────────────────────────────────────────────────────────────

const conductor = new HeadyConductor();

// Register default bees (lightweight stubs for the swarm topology)
const DEFAULT_BEES = [
  'agents-bee', 'brain-bee', 'config-bee', 'creative-bee',
  'deployment-bee', 'documentation-bee', 'engines-bee',
  'governance-bee', 'health-bee', 'intelligence-bee',
  'lifecycle-bee', 'mcp-bee', 'memory-bee', 'middleware-bee',
  'ops-bee', 'orchestration-bee', 'pipeline-bee', 'providers-bee',
  'refactor-bee', 'resilience-bee', 'routes-bee', 'security-bee',
  'services-bee', 'telemetry-bee', 'vector-ops-bee',
];

for (const beeId of DEFAULT_BEES) {
  conductor.registerBee(beeId, {
    category: beeId.replace('-bee', ''),
    domain: beeId.replace('-bee', ''),
    execute: async (payload) => ({ status: 'stub', beeId, payload }),
    getWork: () => [],
  });
}

conductor.startHeartbeat();

// ─── HTTP HELPERS ───────────────────────────────────────────────────────────

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString()));
    req.on('error', reject);
  });
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(body),
    'X-Heady-Service': 'conductor',
    'X-Heady-Version': '4.2.0',
  });
  res.end(body);
}

// ─── HTTP SERVER ────────────────────────────────────────────────────────────

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;

  // CORS
  res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGINS || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  // Health
  if (path === '/health' || path === '/healthz') {
    return sendJson(res, 200, {
      status: 'healthy',
      service: 'heady-conductor',
      version: '4.2.0',
      bees: conductor.bees.size,
      active: conductor.activeExecutions.size,
      uptime: process.uptime(),
      phi: PHI,
    });
  }

  // Ready
  if (path === '/ready') {
    return sendJson(res, 200, { ready: true });
  }

  // Status
  if (path === '/api/conductor/status' && req.method === 'GET') {
    return sendJson(res, 200, { ok: true, ...conductor.getStatus() });
  }

  // Dispatch
  if (path === '/api/conductor/dispatch' && req.method === 'POST') {
    try {
      const { taskType, payload, opts } = JSON.parse(await readBody(req));
      const result = await conductor.dispatch(taskType, payload, opts);
      return sendJson(res, 200, result);
    } catch (err) {
      return sendJson(res, 500, { ok: false, error: err.message });
    }
  }

  // Register bee (external registration via HTTP)
  if (path === '/api/conductor/register' && req.method === 'POST') {
    const { beeId, category, domain } = JSON.parse(await readBody(req));
    conductor.registerBee(beeId, { domain: domain || beeId, category: category || beeId, getWork: () => [] });
    return sendJson(res, 200, { ok: true, registered: beeId });
  }

  // Admin priority dispatch
  if (path === '/api/conductor/priority' && req.method === 'POST') {
    try {
      const { taskType, payload } = JSON.parse(await readBody(req));
      if (!taskType) return sendJson(res, 400, { ok: false, error: 'taskType required' });
      const result = await conductor.adminDispatch(taskType, payload || {});
      return sendJson(res, 200, result);
    } catch (err) {
      return sendJson(res, 500, { ok: false, error: err.message });
    }
  }

  // Pipeline trigger (HCFP stub)
  if (path === '/api/pipeline/run' && req.method === 'POST') {
    const stages = ['ingest', 'plan', 'execute', 'recover', 'finalize'];
    return sendJson(res, 200, {
      ok: true,
      pipelineId: randomUUID(),
      stages,
      config: PIPELINE,
      status: 'initiated',
    });
  }

  sendJson(res, 404, { error: 'Not found' });
});

// ─── GRACEFUL SHUTDOWN ──────────────────────────────────────────────────────

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  log('info', `${signal} received, shutting down`, { signal });
  conductor.stopHeartbeat();
  server.close(() => {
    log('info', 'Shutdown complete');
    process.exit(0);
  });
  setTimeout(() => process.exit(1), Math.round(PHI * 10000));
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// ─── START ──────────────────────────────────────────────────────────────────

server.listen(PORT, '0.0.0.0', () => {
  log('info', `Conductor listening on :${PORT}`, {
    port: PORT,
    bees: conductor.bees.size,
    heartbeatMs: HEARTBEAT_MS,
    resourcePools: RESOURCE_POOLS,
  });
});
