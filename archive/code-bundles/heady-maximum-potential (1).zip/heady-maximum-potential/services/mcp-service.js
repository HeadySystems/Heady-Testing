/**
 * Heady™ MCP Service — Model Context Protocol Gateway (Cloud Run)
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Aligned to repo's src/mcp/mcp-router.js — MCPRouter class.
 * MCP 2025-03-26 spec: Streamable HTTP (POST JSON-RPC + GET SSE).
 * CSL-gated routing, multi-tenant, auto-discovery, zero-trust sandbox.
 *
 * Zero npm dependencies — Node.js built-in http only.
 * @version 4.2.0
 */
'use strict';

const http = require('node:http');
const { createHash, randomUUID } = require('node:crypto');
const EventEmitter = require('node:events');

const {
  PHI, PSI, PSI2, FIB, fib,
  CSL_THRESHOLDS, RELEVANCE_GATES, VECTOR, SIZING, RATE_LIMITS, PORTS,
  cosineSimilarity, normalize,
  phiBackoff,
} = require('../shared/phi-math');

const CSL = require('../shared/csl-engine');

// ─── CONFIG ─────────────────────────────────────────────────────────────────

const PORT = parseInt(process.env.PORT || String(PORTS.MCP_SERVER), 10);
const CONDUCTOR_URL = process.env.CONDUCTOR_URL || `http://localhost:${PORTS.HEADY_CONDUCTOR}`;
const MEMORY_URL = process.env.MEMORY_URL || `http://localhost:${PORTS.HEADY_MEMORY}`;
const MCP_VERSION = '2025-03-26';

const ROUTE_CACHE_SIZE = SIZING.CACHE_MEDIUM; // 377
const RATE_BUCKET = fib(8);                   // 21 burst
const RATE_REFILL_S = fib(5);                // 5/s

// ─── STRUCTURED LOGGER ──────────────────────────────────────────────────────

function log(level, msg, data = {}) {
  process.stdout.write(JSON.stringify({
    ts: new Date().toISOString(), service: 'heady-mcp', level, msg, ...data,
  }) + '\n');
}

// ─── TEXT-TO-VEC (deterministic pseudo-embeddings for routing) ───────────────

const _vecCache = new Map();
function textToVec(text, dim = 64) {
  if (_vecCache.has(text)) return _vecCache.get(text);
  const v = new Float32Array(dim);
  let hash = 5381;
  for (let i = 0; i < text.length; i++) hash = ((hash << 5) + hash + text.charCodeAt(i)) >>> 0;
  for (let i = 0; i < dim; i++) { hash = ((hash << 5) + hash + i) >>> 0; v[i] = ((hash % 2000) - 1000) / 1000; }
  const result = CSL.normalize(v);
  _vecCache.set(text, result);
  return result;
}

// ─── MCP ROUTER (aligned to repo's MCPRouter) ──────────────────────────────

class MCPRouter extends EventEmitter {
  constructor(config = {}) {
    super();
    this.servers = new Map();
    this.tenants = new Map();
    this.routeCache = new Map();
    this.blacklist = [];
    this.cslConfig = {
      resonanceThreshold: config.resonanceThreshold || 0.3,
      riskSensitivity: config.riskSensitivity || 0.8,
      staleTimeoutMs: config.staleTimeoutMs || fib(14) * 1000,
      latencyLimitMs: config.latencyLimitMs || fib(5) * 1000,
      ...config,
    };
    this.metrics = { routed: 0, cached: 0, discovered: 0, errors: 0, cslRouted: 0 };
  }

  registerServer(serverId, info) {
    const toolVecs = (info.tools || []).map(t => textToVec(t));
    const capVecs = (info.capabilities || []).map(c => textToVec(c));
    const allVecs = [...toolVecs, ...capVecs];
    const vector = allVecs.length > 0 ? CSL.consensus_superposition(allVecs) : textToVec(serverId);

    this.servers.set(serverId, {
      name: info.name || serverId, url: info.url,
      capabilities: info.capabilities || [], tools: info.tools || [],
      latency: info.latency || 0, lastSeen: Date.now(), healthy: true, vector,
    });
    this.metrics.discovered++;
    this.emit('server:registered', { serverId });
  }

  route(toolName, tenantId = 'default') {
    // Cache check
    if (this.routeCache.has(toolName)) {
      const cached = this.routeCache.get(toolName);
      const server = this.servers.get(cached);
      if (server && server.healthy) { this.metrics.cached++; return { serverId: cached, server, cached: true }; }
      this.routeCache.delete(toolName);
    }

    let intentVec = textToVec(toolName);
    if (this.blacklist.length > 0) intentVec = CSL.batch_orthogonal(intentVec, this.blacklist);

    const candidates = [];
    for (const [id, server] of this.servers) {
      if (server.healthy) candidates.push({ id, vector: server.vector, server });
    }
    if (candidates.length === 0) { this.metrics.errors++; return { serverId: null, error: `No server for: ${toolName}` }; }

    // Tenant filtering
    const tenant = this.tenants.get(tenantId);
    let filtered = candidates;
    if (tenant && tenant.allowedServers) {
      const tf = candidates.filter(c => tenant.allowedServers.includes(c.id));
      if (tf.length > 0) filtered = tf;
    }

    // CSL route_gate
    const routeResult = CSL.route_gate(intentVec, filtered, this.cslConfig.resonanceThreshold);

    // Latency risk scoring
    const scored = routeResult.scores.map(s => {
      const cand = filtered.find(c => c.id === s.id);
      const risk = CSL.risk_gate(cand.server.latency, this.cslConfig.latencyLimitMs, this.cslConfig.riskSensitivity);
      const composite = s.score * (1 - risk.riskLevel * 0.5);
      return { ...s, risk, composite: +composite.toFixed(6) };
    }).sort((a, b) => b.composite - a.composite);

    const best = scored[0];
    if (!best) { this.metrics.errors++; return { serverId: null, error: `CSL found no server for: ${toolName}` }; }

    this.routeCache.set(toolName, best.id);
    if (this.routeCache.size > ROUTE_CACHE_SIZE) {
      const firstKey = this.routeCache.keys().next().value;
      this.routeCache.delete(firstKey);
    }

    this.metrics.routed++;
    this.metrics.cslRouted++;
    return {
      serverId: best.id,
      server: filtered.find(c => c.id === best.id)?.server,
      cached: false,
      csl: { resonanceScore: best.score, activation: best.activation, composite: best.composite },
    };
  }

  healthCheck() {
    const results = [];
    for (const [id, server] of this.servers) {
      const staleRisk = CSL.risk_gate(Date.now() - server.lastSeen, this.cslConfig.staleTimeoutMs, this.cslConfig.riskSensitivity);
      const latencyRisk = CSL.risk_gate(server.latency, this.cslConfig.latencyLimitMs, this.cslConfig.riskSensitivity);
      const healthScore = 1 - (staleRisk.riskLevel + latencyRisk.riskLevel) / 2;
      const ternary = CSL.ternary_gate(healthScore, 0.7, 0.3);
      if (ternary.state === -1) server.healthy = false;
      else if (ternary.state === +1) server.healthy = true;
      results.push({ id, name: server.name, healthy: server.healthy, healthScore: +healthScore.toFixed(4), state: ternary.state });
    }
    return results;
  }

  getStatus() {
    return {
      ok: true, serverCount: this.servers.size, tenantCount: this.tenants.size,
      cacheSize: this.routeCache.size, metrics: { ...this.metrics }, cslStats: CSL.getStats(),
    };
  }
}

// ─── TOOL REGISTRY ──────────────────────────────────────────────────────────

const toolRegistry = new Map();

function registerTool(name, description, inputSchema, handler) {
  toolRegistry.set(name, { name, description, inputSchema, handler });
}

registerTool('heady.memory.store', 'Store vector in Heady 384D memory', {
  type: 'object',
  properties: { content: { type: 'string' }, metadata: { type: 'object' }, namespace: { type: 'string' } },
  required: ['content'],
}, async (args) => ({ status: 'routed', target: 'memory-service', endpoint: '/store', args }));

registerTool('heady.memory.search', 'Search Heady vector memory', {
  type: 'object',
  properties: { query: { type: 'string' }, topK: { type: 'number' }, threshold: { type: 'number' } },
  required: ['query'],
}, async (args) => ({ status: 'routed', target: 'memory-service', endpoint: '/search', args }));

registerTool('heady.conductor.dispatch', 'Dispatch task via Heady Conductor', {
  type: 'object',
  properties: { taskType: { type: 'string' }, payload: { type: 'object' } },
  required: ['taskType'],
}, async (args) => ({ status: 'routed', target: 'conductor-service', endpoint: '/api/conductor/dispatch', args }));

registerTool('heady.conductor.status', 'Get conductor swarm status', {
  type: 'object', properties: {},
}, async () => ({ status: 'routed', target: 'conductor-service', endpoint: '/api/conductor/status' }));

registerTool('heady.system.health', 'Get system health', {
  type: 'object', properties: {},
}, async () => ({ status: 'healthy', services: ['conductor', 'memory', 'mcp'], uptime: process.uptime() }));

registerTool('heady.system.phi', 'Get phi-math constants', {
  type: 'object', properties: { category: { type: 'string', enum: ['core', 'thresholds', 'all'] } },
}, async (args) => {
  const all = args.category === 'all' || !args.category;
  return {
    ...(all || args.category === 'core' ? { PHI, PSI, PSI2, PHI_SQ: PHI + 1, PHI_CUBED: 2 * PHI + 1 } : {}),
    ...(all || args.category === 'thresholds' ? { CSL_THRESHOLDS } : {}),
  };
});

// ─── AUDIT LOGGER (SHA-256 chain) ───────────────────────────────────────────

const auditEntries = [];
let prevHash = '0'.repeat(64);

function auditLog(record) {
  const entry = {
    seq: auditEntries.length, ts: new Date().toISOString(),
    tool: record.tool, user: record.user || 'anon',
    input_hash: createHash('sha256').update(JSON.stringify(record.input || {})).digest('hex').slice(0, 16),
    duration_ms: record.duration_ms || 0, status: record.status || 'ok',
  };
  const h = createHash('sha256').update(JSON.stringify(entry)).digest('hex');
  entry.chain_hash = createHash('sha256').update(prevHash + h).digest('hex');
  prevHash = entry.chain_hash;
  auditEntries.push(entry);
  if (auditEntries.length > SIZING.CACHE_LARGE) auditEntries.splice(0, auditEntries.length - SIZING.CACHE_MEDIUM);
}

// ─── JSON-RPC 2.0 ──────────────────────────────────────────────────────────

function rpcError(id, code, message) { return { jsonrpc: '2.0', id, error: { code, message } }; }
function rpcResult(id, result) { return { jsonrpc: '2.0', id, result }; }

async function handleRpc(msg, sessionId) {
  if (!msg || msg.jsonrpc !== '2.0') return rpcError(msg?.id, -32600, 'Invalid JSON-RPC');
  const { id, method, params } = msg;

  if (method === 'initialize') {
    return rpcResult(id, {
      protocolVersion: MCP_VERSION,
      serverInfo: { name: 'heady-mcp-server', version: '4.2.0' },
      capabilities: { tools: { listChanged: true }, logging: {} },
    });
  }
  if (method === 'notifications/initialized') return null;
  if (method === 'ping') return rpcResult(id, {});

  if (method === 'tools/list') {
    const tools = [...toolRegistry.values()].map(t => ({ name: t.name, description: t.description, inputSchema: t.inputSchema }));
    return rpcResult(id, { tools });
  }

  if (method === 'tools/call') {
    const tool = toolRegistry.get(params?.name);
    if (!tool) return rpcError(id, -32601, `Tool not found: ${params?.name}`);
    const start = Date.now();
    try {
      const result = await tool.handler(params?.arguments || {});
      auditLog({ tool: params.name, user: sessionId, input: params.arguments, duration_ms: Date.now() - start });
      return rpcResult(id, { content: [{ type: 'text', text: JSON.stringify(result, null, 2) }] });
    } catch (err) {
      auditLog({ tool: params.name, user: sessionId, status: 'error', duration_ms: Date.now() - start });
      return rpcResult(id, { content: [{ type: 'text', text: `Error: ${err.message}` }], isError: true });
    }
  }

  return rpcError(id, -32601, `Unknown method: ${method}`);
}

// ─── SSE MANAGER ────────────────────────────────────────────────────────────

const sseClients = new Map();

// ─── HTTP HELPERS ───────────────────────────────────────────────────────────

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => resolve(Buffer.concat(chunks).toString()));
    req.on('error', reject);
  });
}

function sendJson(res, status, data, headers = {}) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), ...headers });
  res.end(body);
}

// ─── MCP ROUTER SINGLETON ───────────────────────────────────────────────────

const mcpRouter = new MCPRouter();

// Register default MCP servers
mcpRouter.registerServer('heady-conductor', { name: 'Conductor', url: CONDUCTOR_URL, tools: ['dispatch', 'route', 'pipeline'], capabilities: ['orchestration'] });
mcpRouter.registerServer('heady-memory', { name: 'Memory', url: MEMORY_URL, tools: ['store', 'search', 'drift'], capabilities: ['memory', 'vector'] });

// ─── HTTP SERVER ────────────────────────────────────────────────────────────

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;

  res.setHeader('Access-Control-Allow-Origin', process.env.ALLOWED_ORIGINS || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization,Mcp-Session-Id');
  res.setHeader('Access-Control-Expose-Headers', 'Mcp-Session-Id');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  if (path === '/health' || path === '/healthz') {
    return sendJson(res, 200, {
      status: 'healthy', service: 'heady-mcp', version: '4.2.0', protocol: MCP_VERSION,
      tools: toolRegistry.size, sseClients: sseClients.size,
      router: mcpRouter.getStatus(), uptime: process.uptime(), phi: PHI,
    });
  }

  if (path === '/ready') return sendJson(res, 200, { ready: true });

  // MCP POST (JSON-RPC)
  if (path === '/mcp' && req.method === 'POST') {
    try {
      const body = JSON.parse(await readBody(req));
      const sessionId = req.headers['mcp-session-id'] || randomUUID();
      if (Array.isArray(body)) {
        const results = [];
        for (const msg of body) { const r = await handleRpc(msg, sessionId); if (r) results.push(r); }
        return sendJson(res, 200, results, { 'Mcp-Session-Id': sessionId });
      }
      const result = await handleRpc(body, sessionId);
      if (!result) { res.writeHead(204); return res.end(); }
      return sendJson(res, 200, result, { 'Mcp-Session-Id': sessionId });
    } catch { return sendJson(res, 200, rpcError(null, -32700, 'Parse error')); }
  }

  // MCP GET (SSE)
  if (path === '/mcp' && req.method === 'GET') {
    const sessionId = req.headers['mcp-session-id'] || randomUUID();
    res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
    res.write(`event: endpoint\ndata: /mcp\n\n`);
    sseClients.set(sessionId, res);
    res.on('close', () => sseClients.delete(sessionId));
    return;
  }

  // Router status
  if (path === '/api/mcp/router/status') return sendJson(res, 200, mcpRouter.getStatus());
  if (path === '/api/mcp/router/health') return sendJson(res, 200, { ok: true, servers: mcpRouter.healthCheck() });

  // Router route
  if (path === '/api/mcp/router/route' && req.method === 'POST') {
    const { tool, tenant } = JSON.parse(await readBody(req));
    if (!tool) return sendJson(res, 400, { error: 'tool required' });
    return sendJson(res, 200, mcpRouter.route(tool, tenant));
  }

  // Audit
  if (path === '/audit') return sendJson(res, 200, { entries: auditEntries.slice(-fib(7)), total: auditEntries.length });

  // Tools list (REST convenience)
  if (path === '/tools') {
    const tools = [...toolRegistry.values()].map(t => ({ name: t.name, description: t.description }));
    return sendJson(res, 200, { tools, count: tools.length });
  }

  sendJson(res, 404, { error: 'Not found', hint: 'POST /mcp for JSON-RPC, GET /mcp for SSE' });
});

// ─── GRACEFUL SHUTDOWN ──────────────────────────────────────────────────────

let shuttingDown = false;
async function shutdown(signal) {
  if (shuttingDown) return;
  shuttingDown = true;
  log('info', `${signal} received, draining SSE clients`);
  for (const [, client] of sseClients) { client.write(`event: shutdown\ndata: {}\n\n`); client.end(); }
  sseClients.clear();
  server.close(() => { log('info', 'Shutdown complete'); process.exit(0); });
  setTimeout(() => process.exit(1), Math.round(PHI * 10000));
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// ─── START ──────────────────────────────────────────────────────────────────

server.listen(PORT, '0.0.0.0', () => {
  log('info', `MCP service listening on :${PORT}`, {
    port: PORT, protocol: MCP_VERSION, tools: toolRegistry.size,
    servers: mcpRouter.servers.size, routeCacheMax: ROUTE_CACHE_SIZE,
  });
});
