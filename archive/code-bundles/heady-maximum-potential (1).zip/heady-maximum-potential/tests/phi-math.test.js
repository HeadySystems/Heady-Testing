/**
 * Heady™ phi-math.js Test Suite
 * Run: node --test tests/phi-math.test.js
 */

'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const {
  PHI, PSI, PHI_SQ, PHI_CUBED, FIB, fib,
  PHI_TIMING, CSL_THRESHOLDS, PRESSURE_LEVELS, ALERT_THRESHOLDS,
  AUTO_SUCCESS, PIPELINE, BEE_SCALING, RESOURCE_POOLS,
  JUDGE_WEIGHTS, COST_WEIGHTS, VECTOR,
  phiThreshold, phiBackoff, phiFusionWeights,
} = require('../shared/phi-math');

describe('Core Constants', () => {
  it('PHI is golden ratio', () => {
    assert.ok(Math.abs(PHI - (1 + Math.sqrt(5)) / 2) < 1e-10);
  });

  it('PSI = 1/PHI = PHI - 1', () => {
    assert.ok(Math.abs(PSI - 1 / PHI) < 1e-10);
    assert.ok(Math.abs(PSI - (PHI - 1)) < 1e-10);
  });

  it('PHI_SQ = PHI + 1', () => {
    assert.ok(Math.abs(PHI_SQ - (PHI + 1)) < 1e-10);
  });

  it('PHI_CUBED = 2*PHI + 1', () => {
    assert.ok(Math.abs(PHI_CUBED - (2 * PHI + 1)) < 1e-10);
  });

  it('FIB has 21 terms (0-indexed)', () => {
    assert.equal(FIB.length, 21);
    assert.equal(FIB[0], 0);
    assert.equal(FIB[1], 1);
    assert.equal(FIB[2], 1);
    assert.equal(FIB[20], 6765);
  });

  it('FIB follows Fibonacci rule', () => {
    for (let i = 2; i < FIB.length; i++) {
      assert.equal(FIB[i], FIB[i - 1] + FIB[i - 2], `FIB[${i}]: ${FIB[i]} != ${FIB[i-1]}+${FIB[i-2]}`);
    }
  });
});

describe('fib() accessor', () => {
  it('returns correct values for cached range', () => {
    assert.equal(fib(1), 1);
    assert.equal(fib(5), 5);
    assert.equal(fib(10), 55);
    assert.equal(fib(20), 6765);
  });

  it('extends beyond cache', () => {
    assert.equal(fib(21), 10946);
    assert.equal(fib(25), 75025);
  });

  it('returns 0 for n <= 0', () => {
    assert.equal(fib(0), 0);
    assert.equal(fib(-1), 0);
  });
});

describe('PHI_TIMING', () => {
  it('has all 8 timing levels', () => {
    assert.ok(PHI_TIMING.PHI_1 > 0);
    assert.ok(PHI_TIMING.PHI_8 > PHI_TIMING.PHI_1);
  });

  it('PHI_1 ≈ 1618ms', () => {
    assert.ok(Math.abs(PHI_TIMING.PHI_1 - 1618) <= 1);
  });
});

describe('CSL_THRESHOLDS', () => {
  it('MINIMUM < LOW < MEDIUM < HIGH < CRITICAL', () => {
    assert.ok(CSL_THRESHOLDS.MINIMUM < CSL_THRESHOLDS.LOW);
    assert.ok(CSL_THRESHOLDS.LOW < CSL_THRESHOLDS.MEDIUM);
    assert.ok(CSL_THRESHOLDS.MEDIUM < CSL_THRESHOLDS.HIGH);
    assert.ok(CSL_THRESHOLDS.HIGH < CSL_THRESHOLDS.CRITICAL);
  });

  it('DEFAULT = PSI', () => {
    assert.equal(CSL_THRESHOLDS.DEFAULT, PSI);
  });
});

describe('phiThreshold()', () => {
  it('level 0 = 0.5', () => {
    assert.ok(Math.abs(phiThreshold(0) - 0.5) < 1e-10);
  });

  it('increases with level', () => {
    for (let i = 0; i < 4; i++) {
      assert.ok(phiThreshold(i) < phiThreshold(i + 1));
    }
  });
});

describe('phiBackoff()', () => {
  it('attempt 0 returns value near base (with jitter ±38.2%)', () => {
    // phiBackoff has random jitter of ±PSI² (±38.2%), so base=1000 → range [618, 1382]
    const results = [];
    for (let i = 0; i < 20; i++) results.push(phiBackoff(0, 1000));
    const min = Math.min(...results);
    const max = Math.max(...results);
    // All results should be within jitter range of base 1000
    assert.ok(min >= 0, `min was ${min}`);
    assert.ok(max <= 1400, `max was ${max}`);
  });

  it('higher attempts produce larger average delays', () => {
    // Average over multiple samples to smooth jitter
    function avgBackoff(attempt) {
      let sum = 0;
      for (let i = 0; i < 50; i++) sum += phiBackoff(attempt, 1000);
      return sum / 50;
    }
    const avg0 = avgBackoff(0);
    const avg1 = avgBackoff(1);
    const avg2 = avgBackoff(2);
    assert.ok(avg1 > avg0, `avg1=${avg1} should be > avg0=${avg0}`);
    assert.ok(avg2 > avg1, `avg2=${avg2} should be > avg1=${avg1}`);
  });

  it('caps at maxMs', () => {
    assert.ok(phiBackoff(100, 1000, 5000) <= 5000);
  });
});

describe('phiFusionWeights()', () => {
  it('weights sum to 1', () => {
    for (let n = 2; n <= 5; n++) {
      const weights = phiFusionWeights(n);
      const sum = weights.reduce((a, b) => a + b, 0);
      assert.ok(Math.abs(sum - 1) < 1e-10, `n=${n}: sum=${sum}`);
    }
  });

  it('first weight is PSI fraction', () => {
    const weights = phiFusionWeights(3);
    assert.ok(Math.abs(weights[0] - PSI) < 1e-10);
  });
});

describe('Domain Constants', () => {
  it('VECTOR.DIMENSIONS = 384', () => {
    assert.equal(VECTOR.DIMENSIONS, 384);
  });

  it('VECTOR.PROJECTION_DIMS = 3', () => {
    assert.equal(VECTOR.PROJECTION_DIMS, 3);
  });

  it('AUTO_SUCCESS.TASKS_TOTAL = 144 (fib(12))', () => {
    assert.equal(AUTO_SUCCESS.TASKS_TOTAL, 144);
  });

  it('JUDGE_WEIGHTS sum to ~1', () => {
    const sum = Object.values(JUDGE_WEIGHTS).reduce((a, b) => a + b, 0);
    assert.ok(Math.abs(sum - 1) < 0.01);
  });

  it('RESOURCE_POOLS sum < 1 (reserve margin)', () => {
    const sum = Object.values(RESOURCE_POOLS).reduce((a, b) => a + b, 0);
    assert.ok(sum < 1);
    assert.ok(sum > 0.8);
  });
});
