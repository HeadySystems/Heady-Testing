/**
 * Heady™ vector-space-ops.js Test Suite
 * Run: node --test tests/vector-space-ops.test.js
 */

'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const {
  EMBEDDING_DIM, cosineSimilarity, euclideanDistance, dotProduct,
  normalize, magnitude, add, subtract, scale, centroid, lerp,
  randomVector, pca,
} = require('../shared/vector-space-ops');

describe('Basic Operations', () => {
  it('EMBEDDING_DIM = 384', () => {
    assert.equal(EMBEDDING_DIM, 384);
  });

  it('dotProduct of orthogonal vectors is 0', () => {
    const a = new Float64Array([1, 0, 0]);
    const b = new Float64Array([0, 1, 0]);
    assert.equal(dotProduct(a, b), 0);
  });

  it('magnitude of unit vector is 1', () => {
    const v = new Float64Array([0, 0, 1]);
    assert.ok(Math.abs(magnitude(v) - 1) < 1e-10);
  });

  it('normalize produces unit vector', () => {
    const v = new Float64Array([3, 4, 0]);
    const n = normalize(v);
    assert.ok(Math.abs(magnitude(n) - 1) < 1e-10);
  });

  it('cosineSimilarity of identical = 1', () => {
    const v = normalize(new Float64Array([1, 2, 3]));
    assert.ok(Math.abs(cosineSimilarity(v, v) - 1) < 1e-10);
  });

  it('cosineSimilarity of opposite = -1', () => {
    const a = normalize(new Float64Array([1, 0, 0]));
    const b = normalize(new Float64Array([-1, 0, 0]));
    assert.ok(Math.abs(cosineSimilarity(a, b) - (-1)) < 1e-10);
  });

  it('euclideanDistance is symmetric', () => {
    const a = new Float64Array([1, 2, 3]);
    const b = new Float64Array([4, 5, 6]);
    assert.equal(euclideanDistance(a, b), euclideanDistance(b, a));
  });

  it('add works', () => {
    const a = new Float64Array([1, 2]);
    const b = new Float64Array([3, 4]);
    const result = add(a, b);
    assert.equal(result[0], 4);
    assert.equal(result[1], 6);
  });

  it('subtract works', () => {
    const a = new Float64Array([5, 6]);
    const b = new Float64Array([2, 3]);
    const result = subtract(a, b);
    assert.equal(result[0], 3);
    assert.equal(result[1], 3);
  });

  it('scale works', () => {
    const v = new Float64Array([2, 3]);
    const result = scale(v, 2);
    assert.equal(result[0], 4);
    assert.equal(result[1], 6);
  });
});

describe('Higher-Order Operations', () => {
  it('centroid is mean vector', () => {
    const vecs = [new Float64Array([0, 0]), new Float64Array([2, 4])];
    const c = centroid(vecs);
    assert.equal(c[0], 1);
    assert.equal(c[1], 2);
  });

  it('lerp at t=0 returns a', () => {
    const a = new Float64Array([0, 0]);
    const b = new Float64Array([10, 10]);
    const result = lerp(a, b, 0);
    assert.equal(result[0], 0);
  });

  it('lerp at t=1 returns b', () => {
    const a = new Float64Array([0, 0]);
    const b = new Float64Array([10, 10]);
    const result = lerp(a, b, 1);
    assert.equal(result[0], 10);
  });

  it('randomVector is 384D unit vector', () => {
    const v = randomVector();
    assert.equal(v.length, EMBEDDING_DIM);
    assert.ok(Math.abs(magnitude(v) - 1) < 0.01);
  });
});

describe('PCA', () => {
  it('projects to lower dimensions', () => {
    const vecs = [];
    for (let i = 0; i < 10; i++) vecs.push(randomVector(20));
    const projected = pca(vecs, 3);
    assert.equal(projected.length, 10);
    assert.equal(projected[0].length, 3);
  });

  it('throws on targetDims >= sourceDims', () => {
    const vecs = [randomVector(5)];
    assert.throws(() => pca(vecs, 5));
  });
});
