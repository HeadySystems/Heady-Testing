/**
 * Heady™ circuit-breaker.js Test Suite
 * Run: node --test tests/circuit-breaker.test.js
 */

'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const { CircuitBreaker, CircuitBreakerError, STATES } = require('../shared/circuit-breaker');

describe('CircuitBreaker States', () => {
  it('starts CLOSED', () => {
    const cb = new CircuitBreaker({ name: 'test' });
    assert.equal(cb.state, STATES.CLOSED);
  });

  it('opens after consecutive failures', async () => {
    const cb = new CircuitBreaker({ name: 'test', failureThreshold: 3 });

    for (let i = 0; i < 3; i++) {
      try {
        await cb.execute(() => { throw new Error('fail'); });
      } catch { /* expected */ }
    }

    assert.equal(cb.state, STATES.OPEN);
  });

  it('rejects requests when OPEN', async () => {
    const cb = new CircuitBreaker({ name: 'test', failureThreshold: 1, resetTimeoutMs: 60000 });

    try {
      await cb.execute(() => { throw new Error('fail'); });
    } catch { /* trips circuit */ }

    assert.equal(cb.state, STATES.OPEN);

    try {
      await cb.execute(() => 'should not run');
      assert.fail('Should have thrown');
    } catch (err) {
      assert.ok(err instanceof CircuitBreakerError);
    }
  });

  it('reset() returns to CLOSED', () => {
    const cb = new CircuitBreaker({ name: 'test' });
    cb.state = STATES.OPEN;
    cb.reset();
    assert.equal(cb.state, STATES.CLOSED);
  });
});

describe('CircuitBreaker Success', () => {
  it('passes through successful calls', async () => {
    const cb = new CircuitBreaker({ name: 'test' });
    const result = await cb.execute(() => 42);
    assert.equal(result, 42);
  });

  it('tracks window stats', async () => {
    const cb = new CircuitBreaker({ name: 'test' });
    await cb.execute(() => 'ok');
    const status = cb.status();
    assert.equal(status.state, STATES.CLOSED);
    assert.equal(status.windowStats.successes, 1);
  });
});

describe('CircuitBreaker Status', () => {
  it('returns complete status object', () => {
    const cb = new CircuitBreaker({ name: 'test-status' });
    const status = cb.status();
    assert.equal(status.name, 'test-status');
    assert.equal(status.state, STATES.CLOSED);
    assert.ok('windowStats' in status);
    assert.ok('consecutiveFailures' in status);
  });
});
