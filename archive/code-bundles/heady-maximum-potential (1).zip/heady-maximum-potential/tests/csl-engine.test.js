/**
 * Heady™ csl-engine.js Test Suite
 * Run: node --test tests/csl-engine.test.js
 */

'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

const CSL = require('../shared/csl-engine');

describe('CSL Core Operations', () => {
  const dim = 8;

  function makeVec(seed) {
    const v = new Float64Array(dim);
    for (let i = 0; i < dim; i++) v[i] = Math.sin(seed * (i + 1));
    // normalize
    let mag = 0;
    for (let i = 0; i < dim; i++) mag += v[i] * v[i];
    mag = Math.sqrt(mag);
    for (let i = 0; i < dim; i++) v[i] /= mag;
    return v;
  }

  it('cosine returns 1 for identical vectors', () => {
    const v = makeVec(1);
    const sim = CSL.cosine(v, v);
    assert.ok(Math.abs(sim - 1) < 1e-6);
  });

  it('cosine returns value in [-1, 1]', () => {
    const a = makeVec(1);
    const b = makeVec(2);
    const sim = CSL.cosine(a, b);
    assert.ok(sim >= -1 && sim <= 1);
  });

  it('normalize produces unit vector', () => {
    // CSL engine normalize uses Float32Array, so allow Float32 precision (~1e-7)
    const v = new Float64Array([3, 4, 0, 0, 0, 0, 0, 0]);
    const n = CSL.normalize(v);
    let mag = 0;
    for (let i = 0; i < n.length; i++) mag += n[i] * n[i];
    assert.ok(Math.abs(Math.sqrt(mag) - 1) < 1e-4, `magnitude was ${Math.sqrt(mag)}`);
  });
});

describe('CSL Gates', () => {
  const dim = 8;

  function makeVec(seed) {
    const v = new Float64Array(dim);
    for (let i = 0; i < dim; i++) v[i] = Math.sin(seed * (i + 1));
    return CSL.normalize(v);
  }

  it('soft_gate returns object with activation near 0 for very low value', () => {
    // soft_gate returns { value, activation, gated }, not a scalar
    const result = CSL.soft_gate(-100, 0, 10);
    assert.ok(typeof result === 'object');
    assert.ok(typeof result.activation === 'number');
    assert.ok(result.activation < 0.01, `activation was ${result.activation}`);
  });

  it('soft_gate activation ≈ 0.5 at tau (midpoint)', () => {
    const result = CSL.soft_gate(0.5, 0.5); // value = tau
    assert.ok(Math.abs(result.activation - 0.5) < 0.01, `activation was ${result.activation}`);
  });

  it('ternary_gate classifies high/mid/low', () => {
    const high = CSL.ternary_gate(0.9, 0.7, 0.3);
    assert.equal(high.state, 1);

    const mid = CSL.ternary_gate(0.5, 0.7, 0.3);
    assert.equal(mid.state, 0);

    const low = CSL.ternary_gate(0.1, 0.7, 0.3);
    assert.equal(low.state, -1);
  });

  it('route_gate returns scores array', () => {
    const intent = makeVec(1);
    const candidates = [
      { id: 'a', vector: makeVec(1.1) },
      { id: 'b', vector: makeVec(5) },
    ];
    const result = CSL.route_gate(intent, candidates, 0.1);
    assert.ok(Array.isArray(result.scores));
    assert.equal(result.scores.length, 2);
    assert.ok(result.scores[0].score >= result.scores[1].score);
  });

  it('multi_resonance returns scored results', () => {
    const query = makeVec(1);
    // multi_resonance expects {id, vector} objects, not raw vectors
    const targets = [
      { id: 'a', vector: makeVec(1.1) },
      { id: 'b', vector: makeVec(2) },
      { id: 'c', vector: makeVec(3) },
    ];
    const scores = CSL.multi_resonance(query, targets, 0.0);
    assert.ok(Array.isArray(scores));
    assert.ok(scores.length > 0);
    assert.ok(typeof scores[0].score === 'number');
    assert.ok(typeof scores[0].activation === 'number');
    assert.ok(typeof scores[0].id === 'string');
  });

  it('risk_gate evaluates risk as continuous function', () => {
    // risk_gate returns { riskLevel, proximity, isRisky }, not { blocked, dampened }
    const result = CSL.risk_gate(0.95, 0.8);
    assert.ok(typeof result.riskLevel === 'number');
    assert.ok(typeof result.proximity === 'number');
    assert.ok(typeof result.isRisky === 'boolean');
    // 0.95 > 0.8 limit → proximity capped at 1.0, riskLevel should be high
    assert.ok(result.riskLevel > 0.5, `riskLevel was ${result.riskLevel}`);
    assert.ok(result.isRisky, 'should be risky when current > limit');
  });

  it('orthogonal_gate removes blacklist direction', () => {
    // orthogonal_gate uses _cosine (cosine similarity) and Float32Array
    // For unit vectors: cosine = dot product, so projection works correctly
    const v = new Float32Array([1, 1, 0, 0, 0, 0, 0, 0]);
    const exclude = new Float32Array([1, 0, 0, 0, 0, 0, 0, 0]);
    // Normalize inputs for proper cosine behavior
    let magV = Math.sqrt(2);
    const vn = new Float32Array(v.map(x => x / magV));
    const result = CSL.orthogonal_gate(vn, exclude);
    // After removing x-direction, x-component should be near 0
    // y-component should be preserved and dominant
    assert.ok(Math.abs(result[0]) < 0.1, `x-component was ${result[0]}`);
    assert.ok(result[1] > 0.5, `y-component was ${result[1]}`);
  });

  it('consensus_superposition returns normalized vector', () => {
    const vecs = [makeVec(1), makeVec(2), makeVec(3)];
    const result = CSL.consensus_superposition(vecs);
    let mag = 0;
    for (let i = 0; i < result.length; i++) mag += result[i] * result[i];
    assert.ok(Math.abs(Math.sqrt(mag) - 1) < 0.01);
  });
});

describe('CSL Stats', () => {
  it('getStats returns operation counts', () => {
    // getStats returns { gateInvocations, routeDecisions, riskEvaluations }
    const stats = CSL.getStats();
    assert.ok(typeof stats === 'object');
    assert.ok(typeof stats.gateInvocations === 'number');
    assert.ok(typeof stats.routeDecisions === 'number');
    assert.ok(typeof stats.riskEvaluations === 'number');
  });
});
