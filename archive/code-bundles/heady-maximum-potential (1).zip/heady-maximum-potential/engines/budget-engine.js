/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Budget Tracker Engine — engines/budget-engine.js
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * FinOps budget routing: phi-scaled usage metering, cost caps, provider-level
 * spend tracking, and CSL-gated budget alerts. Port 4303.
 *
 * Aligned to: docker-compose service "budget-tracker"
 * © HeadySystems Inc. — Sacred Geometry :: Organic Systems :: Breathing Interfaces
 */

'use strict';

const http = require('http');
const {
  PHI, PSI, FIB, COST_WEIGHTS, ALERT_THRESHOLDS,
  RESOURCE_POOLS, phiBackoff,
} = require('../shared/phi-math');
const { GracefulShutdown } = require('../shared/graceful-shutdown');

const PORT = parseInt(process.env.PORT, 10) || 4303;
const SERVICE = 'budget-tracker';

function log(level, msg, meta = {}) {
  const entry = { ts: new Date().toISOString(), level, service: SERVICE, msg, ...meta };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ── Budget Storage ───────────────────────────────────────────────────────────
const budgets = new Map();    // budgetId → { limit, spent, alerts, provider, createdAt }
const usageLog = [];          // ring buffer of usage records
const MAX_USAGE_LOG = FIB[14]; // 610

function createBudget(id, opts = {}) {
  const budget = {
    id,
    limit: opts.limit || 100,
    spent: 0,
    currency: opts.currency || 'USD',
    provider: opts.provider || 'all',
    alerts: [],
    createdAt: Date.now(),
    resetCycleMs: opts.resetCycleMs || 86400000, // daily
    lastReset: Date.now(),
  };
  budgets.set(id, budget);
  log('info', 'Budget created', { budgetId: id, limit: budget.limit });
  return budget;
}

function recordUsage(budgetId, amount, meta = {}) {
  let budget = budgets.get(budgetId);
  if (!budget) {
    budget = createBudget(budgetId, { limit: 100 });
  }

  // Auto-reset if cycle elapsed
  if (Date.now() - budget.lastReset > budget.resetCycleMs) {
    budget.spent = 0;
    budget.lastReset = Date.now();
    budget.alerts = [];
    log('info', 'Budget auto-reset', { budgetId });
  }

  budget.spent += amount;

  // Track in usage log
  usageLog.push({ budgetId, amount, ts: Date.now(), ...meta });
  if (usageLog.length > MAX_USAGE_LOG) usageLog.splice(0, usageLog.length - MAX_USAGE_LOG);

  // CSL-gated alerts at phi-derived thresholds
  const ratio = budget.spent / budget.limit;
  if (ratio >= ALERT_THRESHOLDS.EXCEEDED && !budget.alerts.includes('EXCEEDED')) {
    budget.alerts.push('EXCEEDED');
    log('warn', 'Budget EXCEEDED', { budgetId, ratio: ratio.toFixed(3), spent: budget.spent, limit: budget.limit });
  } else if (ratio >= ALERT_THRESHOLDS.CRITICAL && !budget.alerts.includes('CRITICAL')) {
    budget.alerts.push('CRITICAL');
    log('warn', 'Budget CRITICAL', { budgetId, ratio: ratio.toFixed(3) });
  } else if (ratio >= ALERT_THRESHOLDS.CAUTION && !budget.alerts.includes('CAUTION')) {
    budget.alerts.push('CAUTION');
    log('info', 'Budget CAUTION', { budgetId, ratio: ratio.toFixed(3) });
  } else if (ratio >= ALERT_THRESHOLDS.WARNING && !budget.alerts.includes('WARNING')) {
    budget.alerts.push('WARNING');
    log('info', 'Budget WARNING', { budgetId, ratio: ratio.toFixed(3) });
  }

  return {
    ok: true,
    budgetId,
    spent: budget.spent,
    limit: budget.limit,
    remaining: Math.max(0, budget.limit - budget.spent),
    ratio: +(budget.spent / budget.limit).toFixed(4),
    alerts: budget.alerts,
  };
}

function getBudgetStatus(budgetId) {
  const budget = budgets.get(budgetId);
  if (!budget) return { ok: false, error: 'Budget not found' };
  const ratio = budget.spent / budget.limit;
  return {
    ok: true,
    ...budget,
    remaining: Math.max(0, budget.limit - budget.spent),
    ratio: +ratio.toFixed(4),
    resourcePools: RESOURCE_POOLS,
    costWeights: COST_WEIGHTS,
  };
}

function getAllBudgets() {
  const result = [];
  for (const [id, budget] of budgets) {
    result.push({
      id,
      limit: budget.limit,
      spent: +budget.spent.toFixed(4),
      remaining: +Math.max(0, budget.limit - budget.spent).toFixed(4),
      ratio: +(budget.spent / budget.limit).toFixed(4),
      alerts: budget.alerts,
      provider: budget.provider,
    });
  }
  return result;
}

// ── HTTP server ──────────────────────────────────────────────────────────────
function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
      catch { resolve({}); }
    });
    req.on('error', reject);
  });
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;

  if (path === '/health' || path === '/healthz') {
    return json(res, 200, { status: 'ok', service: SERVICE, uptime: process.uptime() });
  }
  if (path === '/ready') {
    return json(res, 200, { ready: true, service: SERVICE });
  }

  // Create budget
  if (req.method === 'POST' && path === '/api/budgets') {
    const body = await parseBody(req);
    if (!body.id) return json(res, 400, { ok: false, error: 'id required' });
    const budget = createBudget(body.id, body);
    return json(res, 201, { ok: true, budget });
  }

  // Record usage
  if (req.method === 'POST' && path === '/api/usage') {
    const body = await parseBody(req);
    if (!body.budgetId || typeof body.amount !== 'number') {
      return json(res, 400, { ok: false, error: 'budgetId and amount required' });
    }
    const result = recordUsage(body.budgetId, body.amount, body.meta || {});
    return json(res, 200, result);
  }

  // Get specific budget
  if (req.method === 'GET' && path.startsWith('/api/budgets/')) {
    const budgetId = path.split('/')[3];
    return json(res, 200, getBudgetStatus(budgetId));
  }

  // List all budgets
  if (req.method === 'GET' && path === '/api/budgets') {
    return json(res, 200, { ok: true, budgets: getAllBudgets() });
  }

  // Usage log
  if (req.method === 'GET' && path === '/api/usage') {
    const limit = parseInt(url.searchParams.get('limit'), 10) || FIB[8]; // 34
    return json(res, 200, { ok: true, usage: usageLog.slice(-limit), total: usageLog.length });
  }

  // Resource pool allocation info
  if (req.method === 'GET' && path === '/api/pools') {
    return json(res, 200, {
      ok: true,
      resourcePools: RESOURCE_POOLS,
      costWeights: COST_WEIGHTS,
      alertThresholds: ALERT_THRESHOLDS,
    });
  }

  json(res, 404, { error: 'Not found' });
});

// ── Lifecycle ────────────────────────────────────────────────────────────────
const shutdown = new GracefulShutdown({ registerSignals: true });
shutdown.register('http-server', () => new Promise(r => server.close(r)), { critical: true });

server.listen(PORT, () => {
  log('info', `${SERVICE} listening`, { port: PORT });
});
