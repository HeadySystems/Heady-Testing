/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Health Engine — engines/health-engine.js
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * System health aggregation: probes all services, tracks uptime, detects drift,
 * computes ORS (Operational Readiness Score) via Monte Carlo sampling. Port 4305.
 *
 * Aligned to: docker-compose service "heady-health", repo's SelfAwareness pattern
 * © HeadySystems Inc. — Sacred Geometry :: Organic Systems :: Breathing Interfaces
 */

'use strict';

const http = require('http');
const os = require('os');
const {
  PHI, PSI, FIB, PHI_TIMING, PRESSURE_LEVELS, ALERT_THRESHOLDS,
  CSL_THRESHOLDS,
} = require('../shared/phi-math');
const { cosineSimilarity, randomVector, EMBEDDING_DIM } = require('../shared/vector-space-ops');
const { GracefulShutdown } = require('../shared/graceful-shutdown');

const PORT = parseInt(process.env.PORT, 10) || 4305;
const SERVICE = 'heady-health';

function log(level, msg, meta = {}) {
  const entry = { ts: new Date().toISOString(), level, service: SERVICE, msg, ...meta };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ── Service probe targets (aligned to docker-compose) ────────────────────────
const PROBE_TARGETS = [
  { name: 'heady-manager',       port: 3301 },
  { name: 'api-gateway',         port: 4301 },
  { name: 'observability-kernel', port: 4302 },
  { name: 'budget-tracker',      port: 4303 },
  { name: 'heady-memory',        port: 4304 },
  { name: 'heady-conductor',     port: 4306 },
  { name: 'heady-brains',        port: 4307 },
  { name: 'heady-soul',          port: 4308 },
  { name: 'mcp-server',          port: 3310 },
];

const probeResults = new Map(); // name → { status, latencyMs, lastCheck, consecutive }
const heartbeatLog = [];
const MAX_HEARTBEATS = FIB[11]; // 144

// ── Self-Awareness (384D system state embedding) ─────────────────────────────
let baselineEmbedding = null;
let currentEmbedding = null;
const COHERENCE_THRESHOLD = CSL_THRESHOLDS.MEDIUM; // 0.809

function systemStateText() {
  const mem = process.memoryUsage();
  return [
    `service:${SERVICE}`,
    `uptime:${Math.round(process.uptime())}`,
    `heapUsed:${Math.round(mem.heapUsed / 1024 / 1024)}MB`,
    `rss:${Math.round(mem.rss / 1024 / 1024)}MB`,
    `load:${os.loadavg()[0].toFixed(2)}`,
    `freeMem:${Math.round(os.freemem() / 1024 / 1024)}MB`,
    `probes:${probeResults.size}`,
    `ts:${Date.now()}`,
  ].join(' ');
}

function textToVec(text, dim = EMBEDDING_DIM) {
  const vec = new Float64Array(dim);
  let hash = 5381;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) + hash + text.charCodeAt(i)) >>> 0;
  }
  for (let i = 0; i < dim; i++) {
    hash = ((hash << 5) + hash + i) >>> 0;
    vec[i] = ((hash % 2000) - 1000) / 1000;
  }
  // normalize
  let mag = 0;
  for (let i = 0; i < dim; i++) mag += vec[i] * vec[i];
  mag = Math.sqrt(mag);
  if (mag > 0) for (let i = 0; i < dim; i++) vec[i] /= mag;
  return vec;
}

function heartbeat() {
  const stateText = systemStateText();
  currentEmbedding = textToVec(stateText);

  if (!baselineEmbedding) {
    baselineEmbedding = currentEmbedding;
    log('info', 'Baseline embedding set');
  }

  const coherence = cosineSimilarity(baselineEmbedding, currentEmbedding);
  const alert = coherence < COHERENCE_THRESHOLD;

  heartbeatLog.push({ ts: Date.now(), coherence: +coherence.toFixed(6), alert });
  if (heartbeatLog.length > MAX_HEARTBEATS) heartbeatLog.splice(0, heartbeatLog.length - MAX_HEARTBEATS);

  if (alert) {
    log('warn', 'Coherence below threshold', { coherence: +coherence.toFixed(6), threshold: COHERENCE_THRESHOLD });
  }

  return { coherence: +coherence.toFixed(6), alert };
}

// ── Probing ──────────────────────────────────────────────────────────────────
async function probeService(target) {
  const start = Date.now();
  const host = process.env[`${target.name.replace(/-/g, '_').toUpperCase()}_HOST`] || target.name;
  const url = `http://${host}:${target.port}/health`;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), PHI_TIMING.PHI_3); // 4.2s timeout

    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);

    const latencyMs = Date.now() - start;
    const prev = probeResults.get(target.name) || { consecutiveOk: 0, consecutiveFail: 0 };

    probeResults.set(target.name, {
      status: res.ok ? 'healthy' : 'degraded',
      statusCode: res.status,
      latencyMs,
      lastCheck: Date.now(),
      consecutiveOk: res.ok ? prev.consecutiveOk + 1 : 0,
      consecutiveFail: res.ok ? 0 : prev.consecutiveFail + 1,
    });
  } catch (err) {
    const latencyMs = Date.now() - start;
    const prev = probeResults.get(target.name) || { consecutiveOk: 0, consecutiveFail: 0 };

    probeResults.set(target.name, {
      status: 'down',
      error: err.message,
      latencyMs,
      lastCheck: Date.now(),
      consecutiveOk: 0,
      consecutiveFail: prev.consecutiveFail + 1,
    });
  }
}

async function probeAll() {
  await Promise.allSettled(PROBE_TARGETS.map(t => probeService(t)));
  heartbeat();
}

// ── ORS (Operational Readiness Score) via Monte Carlo ────────────────────────
function computeORS() {
  const healthyCount = Array.from(probeResults.values()).filter(p => p.status === 'healthy').length;
  const totalProbes = probeResults.size || 1;
  const serviceHealthRatio = healthyCount / totalProbes;

  const mem = process.memoryUsage();
  const cpuPressure = Math.min(1, os.loadavg()[0] / os.cpus().length);
  const memoryPressure = 1 - os.freemem() / os.totalmem();

  // Monte Carlo: 1000 samples with noise
  const SAMPLES = FIB[15]; // 987
  let totalScore = 0;
  for (let i = 0; i < SAMPLES; i++) {
    const noiseHealth = serviceHealthRatio + (Math.random() - 0.5) * 0.1;
    const noiseCpu = cpuPressure + (Math.random() - 0.5) * 0.1;
    const noiseMem = memoryPressure + (Math.random() - 0.5) * 0.1;

    const sample = Math.max(0, Math.min(1,
      noiseHealth * 0.5 +
      (1 - Math.min(1, noiseCpu)) * 0.25 +
      (1 - Math.min(1, noiseMem)) * 0.25
    ));
    totalScore += sample;
  }

  const score = +(totalScore / SAMPLES).toFixed(4);

  // Classify pressure level
  let pressureLevel = 'NOMINAL';
  if (score < PRESSURE_LEVELS.NOMINAL.max) pressureLevel = 'CRITICAL';
  else if (score < PRESSURE_LEVELS.ELEVATED.max) pressureLevel = 'HIGH';
  else if (score < PRESSURE_LEVELS.HIGH.max) pressureLevel = 'ELEVATED';

  return {
    score,
    pressureLevel,
    breakdown: {
      serviceHealthRatio: +serviceHealthRatio.toFixed(4),
      cpuPressure: +cpuPressure.toFixed(4),
      memoryPressure: +memoryPressure.toFixed(4),
      healthyServices: healthyCount,
      totalProbes,
      monteCarloSamples: SAMPLES,
    },
    coherence: heartbeatLog.length > 0 ? heartbeatLog[heartbeatLog.length - 1].coherence : null,
  };
}

// ── HTTP server ──────────────────────────────────────────────────────────────
function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;

  if (path === '/health' || path === '/healthz') {
    return json(res, 200, { status: 'ok', service: SERVICE, uptime: process.uptime() });
  }
  if (path === '/ready') {
    return json(res, 200, { ready: true, service: SERVICE });
  }

  // Full health dashboard
  if (req.method === 'GET' && path === '/api/health') {
    const probes = {};
    for (const [name, result] of probeResults) probes[name] = result;
    return json(res, 200, { ok: true, probes, ors: computeORS() });
  }

  // ORS only
  if (req.method === 'GET' && path === '/api/ors') {
    return json(res, 200, { ok: true, ...computeORS() });
  }

  // Self-awareness / coherence
  if (req.method === 'GET' && path === '/api/coherence') {
    const hb = heartbeat();
    return json(res, 200, {
      ok: true,
      ...hb,
      heartbeatLog: heartbeatLog.slice(-FIB[8]), // last 34
      threshold: COHERENCE_THRESHOLD,
    });
  }

  // Trigger probe cycle
  if (req.method === 'POST' && path === '/api/probe') {
    await probeAll();
    const probes = {};
    for (const [name, result] of probeResults) probes[name] = result;
    return json(res, 200, { ok: true, probes });
  }

  // Resource utilization
  if (req.method === 'GET' && path === '/api/resources') {
    const mem = process.memoryUsage();
    return json(res, 200, {
      ok: true,
      cpuCount: os.cpus().length,
      loadAvg: os.loadavg(),
      memTotalMB: Math.round(os.totalmem() / 1024 / 1024),
      memFreeMB: Math.round(os.freemem() / 1024 / 1024),
      heapUsedMB: Math.round(mem.heapUsed / 1024 / 1024),
      uptime: process.uptime(),
      pressureLevels: PRESSURE_LEVELS,
      alertThresholds: ALERT_THRESHOLDS,
    });
  }

  json(res, 404, { error: 'Not found' });
});

// ── Probe cycle (phi-scaled interval) ────────────────────────────────────────
const PROBE_INTERVAL = PHI_TIMING.PHI_7; // ~29s aligned to repo
setInterval(() => {
  probeAll().catch(err => log('error', 'Probe cycle failed', { error: err.message }));
}, PROBE_INTERVAL);

// Initial probe
setTimeout(() => probeAll().catch(() => {}), 2000);

// ── Lifecycle ────────────────────────────────────────────────────────────────
const shutdown = new GracefulShutdown({ registerSignals: true });
shutdown.register('http-server', () => new Promise(r => server.close(r)), { critical: true });

server.listen(PORT, () => {
  log('info', `${SERVICE} listening`, { port: PORT, probeInterval: PROBE_INTERVAL });
});
