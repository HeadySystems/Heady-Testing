/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Auto-Success Engine — engines/auto-success-engine.js
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Continuous self-improvement cycle: 13 categories × 11 tasks each = 144 total.
 * Runs at PHI_TIMING.PHI_7 (~29s) intervals, executing task batches, tracking
 * success/failure, and auto-escalating incidents.
 *
 * Aligned to: phi-math.js AUTO_SUCCESS constants
 * © HeadySystems Inc. — Sacred Geometry :: Organic Systems :: Breathing Interfaces
 */

'use strict';

const http = require('http');
const {
  PHI, PSI, FIB, PHI_TIMING, AUTO_SUCCESS, PIPELINE,
  phiBackoff,
} = require('../shared/phi-math');
const { GracefulShutdown } = require('../shared/graceful-shutdown');

const PORT = parseInt(process.env.PORT, 10) || 3341;
const SERVICE = 'auto-success';

function log(level, msg, meta = {}) {
  const entry = { ts: new Date().toISOString(), level, service: SERVICE, msg, ...meta };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ── Task Categories (13 categories aligned to fib(7)) ────────────────────────
const CATEGORIES = [
  'health-probes',
  'memory-integrity',
  'conductor-sync',
  'mcp-routing',
  'budget-audit',
  'soul-coherence',
  'bee-lifecycle',
  'circuit-health',
  'log-rotation',
  'drift-detection',
  'security-scan',
  'performance-profile',
  'backup-verify',
];

// ── Task registry ────────────────────────────────────────────────────────────
const tasks = new Map(); // taskId → { category, name, fn, lastRun, lastResult, retries, status }
const cycleLog = [];
const MAX_CYCLE_LOG = FIB[12]; // 233
let cycleCount = 0;
let running = false;

// ── Initialize tasks ─────────────────────────────────────────────────────────
function initTasks() {
  let taskIndex = 0;
  for (const category of CATEGORIES) {
    const perCategory = AUTO_SUCCESS.TASKS_PER_CATEGORY; // 11
    for (let i = 0; i < perCategory; i++) {
      const taskId = `${category}-${i}`;
      tasks.set(taskId, {
        id: taskId,
        category,
        name: `${category}:task-${i}`,
        lastRun: null,
        lastResult: null,
        retries: 0,
        totalRetries: 0,
        status: 'pending',
        consecutiveFailures: 0,
      });
      taskIndex++;
      if (taskIndex >= AUTO_SUCCESS.TASKS_TOTAL) break; // cap at 144
    }
    if (taskIndex >= AUTO_SUCCESS.TASKS_TOTAL) break;
  }
  log('info', 'Tasks initialized', { count: tasks.size, categories: CATEGORIES.length });
}

// ── Execute a single task ────────────────────────────────────────────────────
async function executeTask(taskId) {
  const task = tasks.get(taskId);
  if (!task) return { ok: false, error: 'Task not found' };

  task.status = 'running';
  task.lastRun = Date.now();

  try {
    // Simulated task execution — in production, these dispatch to actual service endpoints
    const result = await Promise.race([
      runTaskLogic(task),
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Task timeout')), AUTO_SUCCESS.TASK_TIMEOUT_MS)
      ),
    ]);

    task.status = 'success';
    task.lastResult = result;
    task.consecutiveFailures = 0;
    task.retries = 0;
    return { ok: true, taskId, result };
  } catch (err) {
    task.status = 'failed';
    task.consecutiveFailures++;
    task.retries++;
    task.totalRetries++;
    task.lastResult = { error: err.message };

    if (task.totalRetries >= AUTO_SUCCESS.MAX_RETRIES_TOTAL) {
      task.status = 'incident';
      log('error', 'Task escalated to incident', { taskId, totalRetries: task.totalRetries });
    }

    return { ok: false, taskId, error: err.message, retries: task.retries };
  }
}

async function runTaskLogic(task) {
  // Category-specific logic stubs — each would call actual service APIs
  switch (task.category) {
    case 'health-probes':
      return { action: 'probe', target: `service-${task.id}`, healthy: true };
    case 'memory-integrity':
      return { action: 'check-integrity', entries: FIB[8], consistent: true };
    case 'conductor-sync':
      return { action: 'sync-bees', synced: true, beeCount: FIB[5] };
    case 'mcp-routing':
      return { action: 'validate-routes', routes: FIB[6], valid: true };
    case 'budget-audit':
      return { action: 'audit', withinBudget: true, utilization: +(PSI * 100).toFixed(1) };
    case 'soul-coherence':
      return { action: 'coherence-check', coherent: true, score: +((0.85 + Math.random() * 0.1).toFixed(4)) };
    case 'bee-lifecycle':
      return { action: 'lifecycle-check', activeBees: FIB[7], stale: 0 };
    case 'circuit-health':
      return { action: 'circuit-status', allClosed: true, circuits: FIB[5] };
    case 'log-rotation':
      return { action: 'rotate', rotated: Math.random() > 0.5, entries: FIB[10] };
    case 'drift-detection':
      return { action: 'drift-scan', driftDetected: false, threshold: PSI };
    case 'security-scan':
      return { action: 'scan', vulnerabilities: 0, scannedFiles: FIB[12] };
    case 'performance-profile':
      return { action: 'profile', heapMB: Math.round(process.memoryUsage().heapUsed / 1048576), lagMs: 0 };
    case 'backup-verify':
      return { action: 'verify', backupsValid: true, lastBackup: Date.now() };
    default:
      return { action: 'noop', category: task.category };
  }
}

// ── Cycle execution ──────────────────────────────────────────────────────────
async function runCycle() {
  if (running) return;
  running = true;
  cycleCount++;

  const start = Date.now();
  const batchSize = PIPELINE.MAX_CONCURRENT; // 8

  // Select tasks needing execution (round-robin through categories)
  const pending = Array.from(tasks.values())
    .filter(t => t.status !== 'incident')
    .sort((a, b) => (a.lastRun || 0) - (b.lastRun || 0))
    .slice(0, batchSize);

  const results = await Promise.allSettled(
    pending.map(t => executeTask(t.id))
  );

  const succeeded = results.filter(r => r.status === 'fulfilled' && r.value.ok).length;
  const failed = results.filter(r => r.status === 'rejected' || (r.status === 'fulfilled' && !r.value.ok)).length;

  const cycleResult = {
    cycle: cycleCount,
    durationMs: Date.now() - start,
    executed: pending.length,
    succeeded,
    failed,
    ts: Date.now(),
  };

  cycleLog.push(cycleResult);
  if (cycleLog.length > MAX_CYCLE_LOG) cycleLog.splice(0, cycleLog.length - MAX_CYCLE_LOG);

  log('info', 'Cycle complete', cycleResult);
  running = false;
}

// ── HTTP server ──────────────────────────────────────────────────────────────
function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const p = url.pathname;

  if (p === '/health' || p === '/healthz') {
    return json(res, 200, { status: 'ok', service: SERVICE, uptime: process.uptime(), cycles: cycleCount });
  }
  if (p === '/ready') {
    return json(res, 200, { ready: true, service: SERVICE });
  }

  // Status
  if (req.method === 'GET' && p === '/api/status') {
    const taskStats = { total: tasks.size, pending: 0, success: 0, failed: 0, incident: 0, running: 0 };
    for (const [, t] of tasks) taskStats[t.status] = (taskStats[t.status] || 0) + 1;

    return json(res, 200, {
      ok: true,
      cycleCount,
      running,
      taskStats,
      constants: AUTO_SUCCESS,
      recentCycles: cycleLog.slice(-FIB[6]), // last 8
    });
  }

  // Trigger cycle manually
  if (req.method === 'POST' && p === '/api/cycle') {
    runCycle().catch(err => log('error', 'Manual cycle failed', { error: err.message }));
    return json(res, 200, { ok: true, triggered: true, cycle: cycleCount + 1 });
  }

  // List tasks
  if (req.method === 'GET' && p === '/api/tasks') {
    const category = url.searchParams.get('category');
    let taskList = Array.from(tasks.values());
    if (category) taskList = taskList.filter(t => t.category === category);
    return json(res, 200, { ok: true, tasks: taskList, total: taskList.length });
  }

  // Cycle log
  if (req.method === 'GET' && p === '/api/cycles') {
    const limit = parseInt(url.searchParams.get('limit'), 10) || FIB[8];
    return json(res, 200, { ok: true, cycles: cycleLog.slice(-limit), total: cycleLog.length });
  }

  json(res, 404, { error: 'Not found' });
});

// ── Initialize & start ──────────────────────────────────────────────────────
initTasks();

const CYCLE_INTERVAL = AUTO_SUCCESS.CYCLE_MS; // ~29s (PHI_TIMING.PHI_7)
const cycleTimer = setInterval(() => {
  runCycle().catch(err => log('error', 'Cycle error', { error: err.message }));
}, CYCLE_INTERVAL);

// Initial cycle after 3s
setTimeout(() => runCycle().catch(() => {}), 3000);

// ── Lifecycle ────────────────────────────────────────────────────────────────
const shutdown = new GracefulShutdown({ registerSignals: true });
shutdown.register('cycle-timer', () => { clearInterval(cycleTimer); return Promise.resolve(); });
shutdown.register('http-server', () => new Promise(r => server.close(r)), { critical: true });

server.listen(PORT, () => {
  log('info', `${SERVICE} listening`, { port: PORT, cycleInterval: CYCLE_INTERVAL, tasks: tasks.size });
});
