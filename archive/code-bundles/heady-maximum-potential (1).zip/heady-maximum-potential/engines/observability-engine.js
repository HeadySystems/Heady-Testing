/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Observability Kernel Engine — engines/observability-engine.js
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Centralized observability: structured logging, trace collection, metrics
 * aggregation, and OTel-compatible span forwarding. Port 4302.
 *
 * Aligned to: docker-compose service "observability-kernel"
 * © HeadySystems Inc. — Sacred Geometry :: Organic Systems :: Breathing Interfaces
 */

'use strict';

const http = require('http');
const { PHI, PSI, FIB, PHI_TIMING, phiBackoff, PORTS } = require('../shared/phi-math');
const { GracefulShutdown } = require('../shared/graceful-shutdown');

const PORT = parseInt(process.env.PORT, 10) || 4302;
const SERVICE = 'observability-kernel';

// ── Structured logger ────────────────────────────────────────────────────────
function log(level, msg, meta = {}) {
  const entry = { ts: new Date().toISOString(), level, service: SERVICE, msg, ...meta };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ── Trace & Metrics Storage (RAM-first, phi-bounded) ─────────────────────────
const MAX_TRACES = FIB[13];      // 377 traces in ring buffer
const MAX_METRICS = FIB[14];     // 610 metric points
const traces = [];
const metrics = [];
const serviceRegistry = new Map(); // service → { lastSeen, status, latency }

function addTrace(trace) {
  traces.push({ ...trace, receivedAt: Date.now() });
  if (traces.length > MAX_TRACES) traces.splice(0, traces.length - MAX_TRACES);
}

function addMetric(metric) {
  metrics.push({ ...metric, ts: Date.now() });
  if (metrics.length > MAX_METRICS) metrics.splice(0, metrics.length - MAX_METRICS);
}

function registerServicePing(serviceName, latencyMs, status) {
  serviceRegistry.set(serviceName, {
    lastSeen: Date.now(),
    status: status || 'healthy',
    latencyMs,
    pingCount: (serviceRegistry.get(serviceName)?.pingCount || 0) + 1,
  });
}

// ── OTel-compatible trace ingest ─────────────────────────────────────────────
function processOTelSpans(spans) {
  for (const span of spans) {
    addTrace({
      traceId: span.traceId || span.trace_id,
      spanId: span.spanId || span.span_id,
      service: span.service || span.serviceName,
      operation: span.name || span.operation,
      durationMs: span.durationMs || span.duration,
      status: span.status || 'OK',
      attributes: span.attributes || {},
    });
  }
  return spans.length;
}

// ── Dashboard aggregation ────────────────────────────────────────────────────
function getDashboard() {
  const now = Date.now();
  const recentTraces = traces.filter(t => now - t.receivedAt < PHI_TIMING.PHI_8); // last ~47s
  const recentMetrics = metrics.filter(m => now - m.ts < PHI_TIMING.PHI_8);

  const serviceStatuses = {};
  for (const [name, info] of serviceRegistry) {
    const stale = now - info.lastSeen > PHI_TIMING.PHI_7; // 29s stale threshold
    serviceStatuses[name] = {
      status: stale ? 'stale' : info.status,
      lastSeen: info.lastSeen,
      latencyMs: info.latencyMs,
      pingCount: info.pingCount,
      staleSince: stale ? now - info.lastSeen : null,
    };
  }

  return {
    traceCount: traces.length,
    recentTraceCount: recentTraces.length,
    metricCount: metrics.length,
    recentMetricCount: recentMetrics.length,
    services: serviceStatuses,
    serviceCount: serviceRegistry.size,
    uptime: process.uptime(),
    memory: process.memoryUsage(),
  };
}

// ── HTTP server ──────────────────────────────────────────────────────────────
function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
      catch { resolve({}); }
    });
    req.on('error', reject);
  });
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;

  // Health endpoints
  if (path === '/health' || path === '/healthz') {
    return json(res, 200, { status: 'ok', service: SERVICE, uptime: process.uptime() });
  }
  if (path === '/ready') {
    return json(res, 200, { ready: true, service: SERVICE });
  }

  // Trace ingest
  if (req.method === 'POST' && path === '/v1/traces') {
    const body = await parseBody(req);
    const spans = body.resourceSpans || body.spans || (Array.isArray(body) ? body : [body]);
    const count = processOTelSpans(spans);
    return json(res, 200, { ok: true, ingested: count });
  }

  // Metric ingest
  if (req.method === 'POST' && path === '/v1/metrics') {
    const body = await parseBody(req);
    const items = body.metrics || (Array.isArray(body) ? body : [body]);
    for (const m of items) addMetric(m);
    return json(res, 200, { ok: true, ingested: items.length });
  }

  // Service ping registration
  if (req.method === 'POST' && path === '/api/ping') {
    const body = await parseBody(req);
    registerServicePing(body.service, body.latencyMs, body.status);
    return json(res, 200, { ok: true });
  }

  // Dashboard
  if (req.method === 'GET' && path === '/api/dashboard') {
    return json(res, 200, { ok: true, ...getDashboard() });
  }

  // Query traces
  if (req.method === 'GET' && path === '/api/traces') {
    const limit = parseInt(url.searchParams.get('limit'), 10) || FIB[8]; // 34
    const service = url.searchParams.get('service');
    let filtered = traces;
    if (service) filtered = filtered.filter(t => t.service === service);
    return json(res, 200, { ok: true, traces: filtered.slice(-limit), total: filtered.length });
  }

  // Query metrics
  if (req.method === 'GET' && path === '/api/metrics') {
    const limit = parseInt(url.searchParams.get('limit'), 10) || FIB[8];
    return json(res, 200, { ok: true, metrics: metrics.slice(-limit), total: metrics.length });
  }

  json(res, 404, { error: 'Not found' });
});

// ── Lifecycle ────────────────────────────────────────────────────────────────
const shutdown = new GracefulShutdown({ registerSignals: true });
shutdown.register('http-server', () => new Promise(r => server.close(r)), { critical: true });

server.listen(PORT, () => {
  log('info', `${SERVICE} listening`, { port: PORT, phi: PHI.toFixed(6) });
});
