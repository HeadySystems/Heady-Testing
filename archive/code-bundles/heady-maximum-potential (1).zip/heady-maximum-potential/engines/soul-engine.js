/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Soul Engine — engines/soul-engine.js
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Self-awareness telemetry, personality persistence, system identity embedding,
 * drift detection, and ORS computation. The "consciousness" layer. Port 4308.
 *
 * Aligned to: docker-compose service "heady-soul", repo's SelfAwareness class
 * © HeadySystems Inc. — Sacred Geometry :: Organic Systems :: Breathing Interfaces
 */

'use strict';

const http = require('http');
const os = require('os');
const fs = require('fs');
const path = require('path');
const {
  PHI, PSI, FIB, PHI_TIMING, VECTOR,
  CSL_THRESHOLDS, PRESSURE_LEVELS, ALERT_THRESHOLDS,
} = require('../shared/phi-math');
const {
  cosineSimilarity, normalize, centroid, randomVector,
  EMBEDDING_DIM,
} = require('../shared/vector-space-ops');
const { GracefulShutdown } = require('../shared/graceful-shutdown');

const PORT = parseInt(process.env.PORT, 10) || 4308;
const SERVICE = 'heady-soul';
const DATA_DIR = process.env.SOUL_DATA_DIR || path.join(__dirname, '..', 'data', 'soul');

function log(level, msg, meta = {}) {
  const entry = { ts: new Date().toISOString(), level, service: SERVICE, msg, ...meta };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ── System Identity ──────────────────────────────────────────────────────────
const systemId = process.env.SYSTEM_ID || 'heady-soul-prime';
let baselineEmbedding = null;
let currentEmbedding = null;
const stateTransitions = [];
const heartbeatLog = [];
const MAX_HEARTBEATS = FIB[12]; // 233
const MAX_TRANSITIONS = FIB[11]; // 144

// ── Pseudo-embedding from text (deterministic hash → 384D) ──────────────────
function textToVec(text) {
  const dim = EMBEDDING_DIM;
  const vec = new Float64Array(dim);
  let hash = 5381;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) + hash + text.charCodeAt(i)) >>> 0;
  }
  for (let i = 0; i < dim; i++) {
    hash = ((hash << 5) + hash + i) >>> 0;
    vec[i] = ((hash % 2000) - 1000) / 1000;
  }
  return normalize(vec);
}

function systemStateText() {
  const mem = process.memoryUsage();
  return [
    `systemId:${systemId}`,
    `uptime:${Math.round(process.uptime())}`,
    `heapUsed:${Math.round(mem.heapUsed / 1024 / 1024)}MB`,
    `rss:${Math.round(mem.rss / 1024 / 1024)}MB`,
    `loadAvg:${os.loadavg()[0].toFixed(2)}`,
    `freeMem:${Math.round(os.freemem() / 1024 / 1024)}MB`,
    `transitions:${stateTransitions.length}`,
    `ts:${Date.now()}`,
  ].join(' ');
}

// ── Heartbeat cycle ──────────────────────────────────────────────────────────
function heartbeat() {
  currentEmbedding = textToVec(systemStateText());

  if (!baselineEmbedding) {
    baselineEmbedding = currentEmbedding;
    log('info', 'Soul baseline established', { dim: EMBEDDING_DIM });
  }

  const coherence = cosineSimilarity(baselineEmbedding, currentEmbedding);
  const driftDetected = coherence < VECTOR.DRIFT_THRESHOLD; // PSI ≈ 0.618
  const alert = coherence < CSL_THRESHOLDS.MEDIUM; // 0.809

  heartbeatLog.push({
    ts: Date.now(),
    coherence: +coherence.toFixed(6),
    driftDetected,
    alert,
  });
  if (heartbeatLog.length > MAX_HEARTBEATS) heartbeatLog.splice(0, heartbeatLog.length - MAX_HEARTBEATS);

  if (driftDetected) {
    log('warn', 'Semantic drift detected', { coherence: +coherence.toFixed(6), threshold: VECTOR.DRIFT_THRESHOLD });
    logTransition('coherent', 'drifting', `Coherence ${coherence.toFixed(4)} < ${VECTOR.DRIFT_THRESHOLD}`);
  }

  return { coherence: +coherence.toFixed(6), driftDetected, alert };
}

// ── State transitions ────────────────────────────────────────────────────────
function logTransition(from, to, reason) {
  const entry = { from, to, reason, ts: Date.now() };
  stateTransitions.push(entry);
  if (stateTransitions.length > MAX_TRANSITIONS) stateTransitions.splice(0, stateTransitions.length - MAX_TRANSITIONS);
  log('info', 'State transition', entry);
}

// ── System identity ──────────────────────────────────────────────────────────
function getIdentity() {
  const coherence = baselineEmbedding && currentEmbedding
    ? cosineSimilarity(baselineEmbedding, currentEmbedding)
    : null;

  return {
    systemId,
    embeddingDim: EMBEDDING_DIM,
    hasBaseline: !!baselineEmbedding,
    hasCurrent: !!currentEmbedding,
    coherence: coherence !== null ? +coherence.toFixed(6) : null,
    uptime: process.uptime(),
    transitions: stateTransitions.length,
    heartbeats: heartbeatLog.length,
    driftThreshold: VECTOR.DRIFT_THRESHOLD,
    coherenceThreshold: VECTOR.COHERENCE_THRESHOLD,
    dedupThreshold: VECTOR.DEDUP_THRESHOLD,
  };
}

// ── ORS (Operational Readiness Score) ────────────────────────────────────────
function computeORS() {
  const mem = process.memoryUsage();
  const cpuPressure = Math.min(1, os.loadavg()[0] / os.cpus().length);
  const memoryPressure = 1 - os.freemem() / os.totalmem();
  const coherence = baselineEmbedding && currentEmbedding
    ? cosineSimilarity(baselineEmbedding, currentEmbedding)
    : 1;

  const SAMPLES = FIB[14]; // 610
  let totalScore = 0;
  for (let i = 0; i < SAMPLES; i++) {
    const s =
      Math.max(0, Math.min(1, coherence + (Math.random() - 0.5) * 0.1)) * 0.4 +
      Math.max(0, Math.min(1, 1 - cpuPressure + (Math.random() - 0.5) * 0.1)) * 0.3 +
      Math.max(0, Math.min(1, 1 - memoryPressure + (Math.random() - 0.5) * 0.1)) * 0.3;
    totalScore += s;
  }

  const score = +(totalScore / SAMPLES).toFixed(4);
  const grade = score >= 0.9 ? 'A' : score >= 0.8 ? 'B' : score >= 0.7 ? 'C' : score >= 0.6 ? 'D' : 'F';

  return { score, grade, coherence: +coherence.toFixed(6), cpuPressure: +cpuPressure.toFixed(4), memoryPressure: +memoryPressure.toFixed(4), samples: SAMPLES };
}

// ── Persistence ──────────────────────────────────────────────────────────────
function saveSoulState() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const state = {
      systemId,
      savedAt: new Date().toISOString(),
      transitions: stateTransitions.slice(-FIB[8]),
      heartbeats: heartbeatLog.slice(-FIB[8]),
      identity: getIdentity(),
    };
    fs.writeFileSync(path.join(DATA_DIR, 'soul-state.json'), JSON.stringify(state, null, 2));
    log('info', 'Soul state persisted');
  } catch (err) {
    log('error', 'Failed to persist soul state', { error: err.message });
  }
}

// ── HTTP server ──────────────────────────────────────────────────────────────
function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
      catch { resolve({}); }
    });
    req.on('error', reject);
  });
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const p = url.pathname;

  if (p === '/health' || p === '/healthz') {
    return json(res, 200, { status: 'ok', service: SERVICE, uptime: process.uptime() });
  }
  if (p === '/ready') {
    return json(res, 200, { ready: true, service: SERVICE });
  }

  // Identity
  if (req.method === 'GET' && p === '/api/identity') {
    return json(res, 200, { ok: true, ...getIdentity() });
  }

  // Heartbeat
  if (req.method === 'POST' && p === '/api/heartbeat') {
    const result = heartbeat();
    return json(res, 200, { ok: true, ...result });
  }

  // ORS
  if (req.method === 'GET' && p === '/api/ors') {
    return json(res, 200, { ok: true, ...computeORS() });
  }

  // Coherence history
  if (req.method === 'GET' && p === '/api/coherence') {
    return json(res, 200, {
      ok: true,
      heartbeats: heartbeatLog.slice(-FIB[8]),
      driftThreshold: VECTOR.DRIFT_THRESHOLD,
      coherenceThreshold: VECTOR.COHERENCE_THRESHOLD,
    });
  }

  // State transitions
  if (req.method === 'GET' && p === '/api/transitions') {
    return json(res, 200, { ok: true, transitions: stateTransitions });
  }

  // Log a transition
  if (req.method === 'POST' && p === '/api/transitions') {
    const body = await parseBody(req);
    logTransition(body.from || 'unknown', body.to || 'unknown', body.reason || '');
    return json(res, 200, { ok: true });
  }

  // Save state
  if (req.method === 'POST' && p === '/api/save') {
    saveSoulState();
    return json(res, 200, { ok: true, saved: true });
  }

  // Resource utilization
  if (req.method === 'GET' && p === '/api/resources') {
    const mem = process.memoryUsage();
    return json(res, 200, {
      ok: true,
      cpuCount: os.cpus().length,
      loadAvg: os.loadavg(),
      memTotalMB: Math.round(os.totalmem() / 1024 / 1024),
      memFreeMB: Math.round(os.freemem() / 1024 / 1024),
      heapUsedMB: Math.round(mem.heapUsed / 1024 / 1024),
      heapTotalMB: Math.round(mem.heapTotal / 1024 / 1024),
      uptime: process.uptime(),
    });
  }

  json(res, 404, { error: 'Not found' });
});

// ── Heartbeat cycle ──────────────────────────────────────────────────────────
const HB_INTERVAL = PHI_TIMING.PHI_7; // ~29s aligned to repo SelfAwareness
setInterval(() => heartbeat(), HB_INTERVAL);
// Persist soul state every ~47s
setInterval(() => saveSoulState(), PHI_TIMING.PHI_8);

// Initial heartbeat
setTimeout(() => heartbeat(), 1000);

// ── Lifecycle ────────────────────────────────────────────────────────────────
const shutdown = new GracefulShutdown({ registerSignals: true });
shutdown.register('save-soul-state', () => { saveSoulState(); return Promise.resolve(); });
shutdown.register('http-server', () => new Promise(r => server.close(r)), { critical: true });

server.listen(PORT, () => {
  log('info', `${SERVICE} listening`, { port: PORT, systemId, hbInterval: HB_INTERVAL });
});
