/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Brains Engine — engines/brains-engine.js
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Multi-model LLM router with phi-scaled provider racing, circuit breaker
 * failover, CSL-gated model selection, and budget-aware cost caps. Port 4307.
 *
 * Aligned to: docker-compose service "heady-brains"
 * © HeadySystems Inc. — Sacred Geometry :: Organic Systems :: Breathing Interfaces
 */

'use strict';

const http = require('http');
const {
  PHI, PSI, FIB, PHI_TIMING, COST_WEIGHTS, JUDGE_WEIGHTS,
  phiBackoff, CSL_THRESHOLDS,
} = require('../shared/phi-math');
const { CircuitBreaker, STATES } = require('../shared/circuit-breaker');
const { GracefulShutdown } = require('../shared/graceful-shutdown');

const PORT = parseInt(process.env.PORT, 10) || 4307;
const SERVICE = 'heady-brains';

function log(level, msg, meta = {}) {
  const entry = { ts: new Date().toISOString(), level, service: SERVICE, msg, ...meta };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ── Provider Registry ────────────────────────────────────────────────────────
const PROVIDERS = {
  claude: {
    name: 'Claude',
    models: ['claude-sonnet-4-20250514', 'claude-opus-4-20250514', 'claude-3-5-haiku-20241022'],
    costPerToken: { input: 0.003, output: 0.015 },
    maxTokens: 200000,
    strengths: ['reasoning', 'code', 'analysis', 'safety'],
  },
  openai: {
    name: 'OpenAI',
    models: ['gpt-4o', 'gpt-4o-mini', 'o1', 'o1-mini'],
    costPerToken: { input: 0.005, output: 0.015 },
    maxTokens: 128000,
    strengths: ['general', 'creative', 'multimodal'],
  },
  gemini: {
    name: 'Gemini',
    models: ['gemini-2.5-pro', 'gemini-2.5-flash'],
    costPerToken: { input: 0.00125, output: 0.005 },
    maxTokens: 1000000,
    strengths: ['long-context', 'multimodal', 'speed'],
  },
  groq: {
    name: 'Groq',
    models: ['llama-3.3-70b-versatile', 'mixtral-8x7b-32768'],
    costPerToken: { input: 0.00059, output: 0.00079 },
    maxTokens: 32768,
    strengths: ['speed', 'cost'],
  },
  perplexity: {
    name: 'Perplexity Sonar',
    models: ['sonar-pro', 'sonar'],
    costPerToken: { input: 0.001, output: 0.001 },
    maxTokens: 127072,
    strengths: ['search', 'current-events', 'citations'],
  },
};

// ── Circuit breakers per provider ────────────────────────────────────────────
const breakers = {};
for (const [id, provider] of Object.entries(PROVIDERS)) {
  breakers[id] = new CircuitBreaker({
    name: `brains-${id}`,
    failureThreshold: FIB[5], // 5
    resetTimeoutMs: 5000,
    onStateChange: (name, from, to) => {
      log('info', 'Circuit state change', { provider: id, from, to });
    },
  });
}

// ── Request tracking ─────────────────────────────────────────────────────────
const requestLog = [];
const MAX_LOG = FIB[12]; // 233

// ── Routing logic ────────────────────────────────────────────────────────────
function routeRequest(task, opts = {}) {
  const { preferSpeed, preferCost, preferQuality, exclude = [] } = opts;

  // Score each provider using COST_WEIGHTS-style weighting
  const scored = Object.entries(PROVIDERS)
    .filter(([id]) => !exclude.includes(id))
    .filter(([id]) => breakers[id].state !== STATES.OPEN)
    .map(([id, provider]) => {
      let score = 0.5; // base

      // Task affinity
      if (task && provider.strengths.some(s => task.toLowerCase().includes(s))) {
        score += 0.2;
      }

      // Speed preference
      if (preferSpeed && (id === 'groq' || id === 'gemini')) score += 0.15;
      // Cost preference
      if (preferCost && provider.costPerToken.input < 0.002) score += 0.15;
      // Quality preference
      if (preferQuality && (id === 'claude' || id === 'openai')) score += 0.15;

      // Circuit breaker health bonus
      const cbStatus = breakers[id].status();
      if (cbStatus.state === STATES.CLOSED && cbStatus.consecutiveFailures === 0) {
        score += 0.1;
      }

      return { id, provider, score: +score.toFixed(4) };
    })
    .sort((a, b) => b.score - a.score);

  return scored;
}

// ── Completion proxy (structural — actual API calls require keys) ────────────
async function complete(providerId, model, messages, opts = {}) {
  const provider = PROVIDERS[providerId];
  if (!provider) throw new Error(`Unknown provider: ${providerId}`);

  const apiKey = process.env[`${providerId.toUpperCase()}_API_KEY`];
  if (!apiKey) {
    return {
      ok: false,
      error: `No API key for ${providerId}`,
      provider: providerId,
      model,
      hint: `Set ${providerId.toUpperCase()}_API_KEY environment variable`,
    };
  }

  const start = Date.now();

  // Execute through circuit breaker
  const result = await breakers[providerId].execute(async () => {
    // Provider-specific API call
    let url, headers, body;

    if (providerId === 'claude') {
      url = 'https://api.anthropic.com/v1/messages';
      headers = {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      };
      body = JSON.stringify({
        model: model || 'claude-sonnet-4-20250514',
        max_tokens: opts.maxTokens || 4096,
        messages,
      });
    } else if (providerId === 'openai' || providerId === 'groq' || providerId === 'perplexity') {
      const baseUrl = providerId === 'groq' ? 'https://api.groq.com/openai'
        : providerId === 'perplexity' ? 'https://api.perplexity.ai'
        : 'https://api.openai.com';
      url = `${baseUrl}/v1/chat/completions`;
      headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      };
      body = JSON.stringify({
        model: model || provider.models[0],
        messages,
        max_tokens: opts.maxTokens || 4096,
      });
    } else if (providerId === 'gemini') {
      url = `https://generativelanguage.googleapis.com/v1beta/models/${model || 'gemini-2.5-flash'}:generateContent?key=${apiKey}`;
      headers = { 'Content-Type': 'application/json' };
      body = JSON.stringify({
        contents: messages.map(m => ({
          role: m.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: m.content }],
        })),
      });
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), opts.timeoutMs || PHI_TIMING.PHI_6);

    const response = await fetch(url, {
      method: 'POST',
      headers,
      body,
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!response.ok) {
      const errorBody = await response.text().catch(() => '');
      throw new Error(`${providerId} API error: ${response.status} ${errorBody.slice(0, 200)}`);
    }

    return response.json();
  });

  const latencyMs = Date.now() - start;

  // Track request
  requestLog.push({ provider: providerId, model, latencyMs, ts: Date.now(), ok: true });
  if (requestLog.length > MAX_LOG) requestLog.splice(0, requestLog.length - MAX_LOG);

  return { ok: true, provider: providerId, model, latencyMs, result };
}

// ── HTTP server ──────────────────────────────────────────────────────────────
function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
      catch { resolve({}); }
    });
    req.on('error', reject);
  });
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const path = url.pathname;

  if (path === '/health' || path === '/healthz') {
    return json(res, 200, { status: 'ok', service: SERVICE, uptime: process.uptime() });
  }
  if (path === '/ready') {
    return json(res, 200, { ready: true, service: SERVICE });
  }

  // Route request to best provider
  if (req.method === 'POST' && path === '/api/route') {
    const body = await parseBody(req);
    const ranked = routeRequest(body.task, body);
    return json(res, 200, { ok: true, ranked });
  }

  // Completion
  if (req.method === 'POST' && path === '/api/complete') {
    const body = await parseBody(req);
    if (!body.messages) return json(res, 400, { ok: false, error: 'messages required' });

    // Auto-route if no provider specified
    let providerId = body.provider;
    let model = body.model;
    if (!providerId) {
      const ranked = routeRequest(body.task, body);
      if (ranked.length === 0) return json(res, 503, { ok: false, error: 'All providers unavailable' });
      providerId = ranked[0].id;
      model = model || ranked[0].provider.models[0];
    }

    try {
      const result = await complete(providerId, model, body.messages, body);
      return json(res, 200, result);
    } catch (err) {
      return json(res, 500, { ok: false, error: err.message, provider: providerId });
    }
  }

  // Provider status
  if (req.method === 'GET' && path === '/api/providers') {
    const status = {};
    for (const [id, provider] of Object.entries(PROVIDERS)) {
      status[id] = {
        ...provider,
        circuit: breakers[id].status(),
        hasKey: !!process.env[`${id.toUpperCase()}_API_KEY`],
      };
    }
    return json(res, 200, { ok: true, providers: status });
  }

  // Request log
  if (req.method === 'GET' && path === '/api/requests') {
    const limit = parseInt(url.searchParams.get('limit'), 10) || FIB[8];
    return json(res, 200, { ok: true, requests: requestLog.slice(-limit) });
  }

  json(res, 404, { error: 'Not found' });
});

// ── Lifecycle ────────────────────────────────────────────────────────────────
const shutdown = new GracefulShutdown({ registerSignals: true });
shutdown.register('http-server', () => new Promise(r => server.close(r)), { critical: true });

server.listen(PORT, () => {
  log('info', `${SERVICE} listening`, { port: PORT, providers: Object.keys(PROVIDERS) });
});
