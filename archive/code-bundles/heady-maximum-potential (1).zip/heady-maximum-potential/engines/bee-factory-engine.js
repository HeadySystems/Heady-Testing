/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Bee Factory Engine — engines/bee-factory-engine.js
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Dynamic bee creation, CSL-powered routing, swarm orchestration, template-based
 * spawning, and ephemeral worker lifecycle. HTTP service for bee operations.
 *
 * Aligned to: src/bees/bee-factory.js
 * © HeadySystems Inc. — Sacred Geometry :: Organic Systems :: Breathing Interfaces
 */

'use strict';

const http = require('http');
const crypto = require('crypto');
const {
  PHI, PSI, FIB, PHI_TIMING, BEE_SCALING,
} = require('../shared/phi-math');
const {
  cosineSimilarity, normalize, EMBEDDING_DIM,
} = require('../shared/vector-space-ops');
const CSL = require('../shared/csl-engine');
const { GracefulShutdown } = require('../shared/graceful-shutdown');

const PORT = parseInt(process.env.PORT, 10) || 3340;
const SERVICE = 'bee-factory';

function log(level, msg, meta = {}) {
  const entry = { ts: new Date().toISOString(), level, service: SERVICE, msg, ...meta };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ── Registries ───────────────────────────────────────────────────────────────
const dynamicRegistry = new Map();
const ephemeralBees = new Map();
const vecCache = new Map();

// ── Pseudo-embedding ─────────────────────────────────────────────────────────
function domainToVec(text, dim = 64) {
  if (vecCache.has(text)) return vecCache.get(text);
  const v = new Float32Array(dim);
  let hash = 5381;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) + hash + text.charCodeAt(i)) >>> 0;
  }
  for (let i = 0; i < dim; i++) {
    hash = ((hash << 5) + hash + i) >>> 0;
    v[i] = ((hash % 2000) - 1000) / 1000;
  }
  // normalize
  let mag = 0;
  for (let i = 0; i < dim; i++) mag += v[i] * v[i];
  mag = Math.sqrt(mag);
  const result = new Float32Array(dim);
  if (mag > 0) for (let i = 0; i < dim; i++) result[i] = v[i] / mag;
  vecCache.set(text, result);
  return result;
}

function buildBeeVector(domain, description) {
  const domainVec = domainToVec(domain);
  const descVec = domainToVec(description || domain);
  // Weighted superposition: 60% domain, 40% description
  const dim = domainVec.length;
  const result = new Float32Array(dim);
  for (let i = 0; i < dim; i++) result[i] = domainVec[i] * 0.6 + descVec[i] * 0.4;
  // normalize
  let mag = 0;
  for (let i = 0; i < dim; i++) mag += result[i] * result[i];
  mag = Math.sqrt(mag);
  if (mag > 0) for (let i = 0; i < dim; i++) result[i] /= mag;
  return result;
}

// ── Core bee operations ──────────────────────────────────────────────────────
function createBee(domain, config = {}) {
  const description = config.description || `Dynamic ${domain} bee`;
  const priority = config.priority || 0.5;
  const vector = buildBeeVector(domain, description);

  // CSL ternary classification
  const priorityClass = priority >= 0.7 ? 'critical' : priority >= 0.3 ? 'normal' : 'low';

  const entry = {
    domain,
    description,
    priority,
    priorityClass,
    createdAt: Date.now(),
    dynamic: true,
    vector,
    workerCount: config.workerCount || 1,
    status: 'active',
  };

  dynamicRegistry.set(domain, entry);
  log('info', 'Bee created', { domain, priority, priorityClass });
  return entry;
}

function spawnBee(name, priority = 0.8) {
  const id = `ephemeral-${name}-${crypto.randomBytes(3).toString('hex')}`;
  const vector = buildBeeVector(id, `Ephemeral bee: ${name}`);

  const entry = {
    domain: id,
    description: `Ephemeral bee: ${name}`,
    priority,
    priorityClass: priority >= 0.7 ? 'critical' : 'normal',
    ephemeral: true,
    createdAt: Date.now(),
    vector,
    status: 'active',
  };

  ephemeralBees.set(id, entry);
  log('info', 'Ephemeral bee spawned', { id, name, priority });
  return entry;
}

function routeBee(taskDescription, opts = {}) {
  const { threshold = 0.3, topK = 3 } = opts;
  const intentVec = domainToVec(taskDescription);

  const allBees = [];
  for (const [, entry] of dynamicRegistry) {
    if (entry.vector) allBees.push(entry);
  }
  for (const [, entry] of ephemeralBees) {
    if (entry.vector) allBees.push(entry);
  }

  if (allBees.length === 0) {
    return { best: null, ranked: [], error: 'No bees registered' };
  }

  // Score each bee by cosine similarity to intent
  const scored = allBees.map(bee => {
    let score = 0;
    const dim = Math.min(intentVec.length, bee.vector.length);
    let dotP = 0, magA = 0, magB = 0;
    for (let i = 0; i < dim; i++) {
      dotP += intentVec[i] * bee.vector[i];
      magA += intentVec[i] * intentVec[i];
      magB += bee.vector[i] * bee.vector[i];
    }
    magA = Math.sqrt(magA);
    magB = Math.sqrt(magB);
    score = (magA > 0 && magB > 0) ? dotP / (magA * magB) : 0;

    // Composite: 70% semantic + 30% priority
    const composite = score * 0.7 + bee.priority * 0.3;

    return {
      domain: bee.domain,
      description: bee.description,
      resonance: +score.toFixed(6),
      priority: bee.priority,
      composite: +composite.toFixed(6),
    };
  })
    .filter(s => s.resonance >= threshold)
    .sort((a, b) => b.composite - a.composite)
    .slice(0, topK);

  return {
    best: scored.length > 0 ? scored[0] : null,
    ranked: scored,
    candidatesScored: allBees.length,
  };
}

function dissolveBee(domain) {
  dynamicRegistry.delete(domain);
  ephemeralBees.delete(domain);
  vecCache.delete(domain);
  log('info', 'Bee dissolved', { domain });
}

function listBees() {
  const bees = [];
  for (const [, entry] of dynamicRegistry) {
    bees.push({ ...entry, vector: undefined, type: 'dynamic' });
  }
  for (const [, entry] of ephemeralBees) {
    bees.push({ ...entry, vector: undefined, type: 'ephemeral' });
  }
  return bees;
}

// ── HTTP server ──────────────────────────────────────────────────────────────
function parseBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', c => chunks.push(c));
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString())); }
      catch { resolve({}); }
    });
    req.on('error', reject);
  });
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const p = url.pathname;

  if (p === '/health' || p === '/healthz') {
    return json(res, 200, { status: 'ok', service: SERVICE, uptime: process.uptime() });
  }
  if (p === '/ready') {
    return json(res, 200, { ready: true, service: SERVICE });
  }

  // Create bee
  if (req.method === 'POST' && p === '/api/bees') {
    const body = await parseBody(req);
    if (!body.domain) return json(res, 400, { ok: false, error: 'domain required' });
    const bee = createBee(body.domain, body);
    return json(res, 201, { ok: true, bee: { ...bee, vector: undefined } });
  }

  // Spawn ephemeral
  if (req.method === 'POST' && p === '/api/bees/spawn') {
    const body = await parseBody(req);
    if (!body.name) return json(res, 400, { ok: false, error: 'name required' });
    const bee = spawnBee(body.name, body.priority);
    return json(res, 201, { ok: true, bee: { ...bee, vector: undefined } });
  }

  // Route task
  if (req.method === 'POST' && p === '/api/bees/route') {
    const body = await parseBody(req);
    if (!body.task) return json(res, 400, { ok: false, error: 'task required' });
    const result = routeBee(body.task, body);
    return json(res, 200, { ok: true, ...result });
  }

  // List all bees
  if (req.method === 'GET' && p === '/api/bees') {
    return json(res, 200, { ok: true, bees: listBees(), scaling: BEE_SCALING });
  }

  // Dissolve bee
  if (req.method === 'DELETE' && p.startsWith('/api/bees/')) {
    const domain = decodeURIComponent(p.split('/')[3]);
    dissolveBee(domain);
    return json(res, 200, { ok: true, dissolved: domain });
  }

  json(res, 404, { error: 'Not found' });
});

// ── Lifecycle ────────────────────────────────────────────────────────────────
const shutdown = new GracefulShutdown({ registerSignals: true });
shutdown.register('http-server', () => new Promise(r => server.close(r)), { critical: true });

server.listen(PORT, () => {
  log('info', `${SERVICE} listening`, { port: PORT });
});
