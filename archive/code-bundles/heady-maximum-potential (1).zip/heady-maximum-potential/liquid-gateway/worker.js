/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Liquid Gateway — Cloudflare Worker Edge Layer
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Ultra-low latency edge routing: CSL-gated domain dispatch, provider racing,
 * embedding cache, rate limiting, CORS, and hot/warm/cold pool scheduling.
 *
 * Deployed to Cloudflare Workers (account: 8b1fa38f282c691423c6399247d53323)
 * Bindings: KV (HEADY_CACHE), Vectorize (HEADY_VECTORS), AI (Workers AI)
 *
 * Aligned to: workers/liquid-gateway-worker
 * © HeadySystems Inc. — Sacred Geometry :: Organic Systems :: Breathing Interfaces
 */

// ── φ constants (inline for Worker compat — no require) ──────────────────────
const PHI = 1.6180339887498948;
const PSI = 0.6180339887498949;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];

// CSL thresholds
const CSL_INCLUDE = 1 - Math.pow(PSI, 0) * 0.5;  // 0.500
const CSL_BOOST = PSI;                              // 0.618
const CSL_HIGH = 1 - Math.pow(PSI, 3) * 0.5;       // 0.882

// Rate limits (Fibonacci-scaled)
const RATE_LIMITS = {
  anonymous: FIB[8],    // 34 req/min
  authenticated: FIB[9], // 55 req/min
  premium: FIB[10],      // 89 req/min
  internal: FIB[12],     // 233 req/min
};

// ── Domain routing table ─────────────────────────────────────────────────────
const DOMAINS = {
  'headyme.com':           { origin: 'https://heady-manager.headysystems.com', pool: 'hot' },
  'headysystems.com':      { origin: 'https://heady-manager.headysystems.com', pool: 'hot' },
  'headyconnection.org':   { origin: 'https://heady-manager.headysystems.com', pool: 'hot' },
  'headymcp.com':          { origin: 'https://mcp.headysystems.com',           pool: 'hot' },
  'headybuddy.org':        { origin: 'https://buddy.headysystems.com',         pool: 'warm' },
  'headyio.com':           { origin: 'https://api.headysystems.com',           pool: 'warm' },
  'headybot.com':          { origin: 'https://buddy.headysystems.com',         pool: 'warm' },
  'headyapi.com':          { origin: 'https://api.headysystems.com',           pool: 'hot' },
  'headyai.com':           { origin: 'https://ai.headysystems.com',            pool: 'hot' },
  'headycloud.com':        { origin: 'https://cloud.headysystems.com',         pool: 'warm' },
  'headyos.com':           { origin: 'https://os.headysystems.com',            pool: 'hot' },
};

// ── CORS configuration ──────────────────────────────────────────────────────
const CORS_ORIGINS = new Set(Object.keys(DOMAINS).flatMap(d => [
  `https://${d}`, `https://www.${d}`,
  `http://localhost:3000`, `http://localhost:5173`, `http://localhost:4321`,
]));

function corsHeaders(request) {
  const origin = request.headers.get('Origin') || '';
  const headers = {
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Heady-Tenant, X-Request-Id',
    'Access-Control-Max-Age': '86400',
  };
  if (CORS_ORIGINS.has(origin) || origin.endsWith('.headysystems.com')) {
    headers['Access-Control-Allow-Origin'] = origin;
    headers['Access-Control-Allow-Credentials'] = 'true';
  }
  return headers;
}

// ── Rate Limiter (sliding window via KV) ─────────────────────────────────────
async function checkRateLimit(request, env) {
  if (!env.HEADY_CACHE) return { allowed: true };

  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  const tier = request.headers.get('Authorization') ? 'authenticated' : 'anonymous';
  const limit = RATE_LIMITS[tier] || RATE_LIMITS.anonymous;
  const key = `rl:${ip}:${Math.floor(Date.now() / 60000)}`;

  try {
    const current = parseInt(await env.HEADY_CACHE.get(key) || '0', 10);
    if (current >= limit) {
      return {
        allowed: false,
        limit,
        remaining: 0,
        retryAfter: Math.ceil(60 - (Date.now() % 60000) / 1000),
      };
    }
    await env.HEADY_CACHE.put(key, String(current + 1), { expirationTtl: 120 });
    return { allowed: true, limit, remaining: limit - current - 1 };
  } catch {
    return { allowed: true }; // fail open
  }
}

// ── Edge embedding cache ─────────────────────────────────────────────────────
async function getCachedEmbedding(text, env) {
  if (!env.HEADY_CACHE) return null;
  const key = `emb:${text.slice(0, 100)}`;
  const cached = await env.HEADY_CACHE.get(key, 'json');
  return cached;
}

async function cacheEmbedding(text, embedding, env) {
  if (!env.HEADY_CACHE) return;
  const key = `emb:${text.slice(0, 100)}`;
  await env.HEADY_CACHE.put(key, JSON.stringify(embedding), {
    expirationTtl: Math.round(PHI * 3600), // ~1.6 hours
  });
}

// ── Workers AI edge inference ────────────────────────────────────────────────
async function edgeEmbed(text, env) {
  if (!env.AI) return null;
  try {
    const result = await env.AI.run('@cf/baai/bge-small-en-v1.5', { text: [text] });
    const embedding = result.data?.[0];
    if (embedding) await cacheEmbedding(text, embedding, env);
    return embedding;
  } catch {
    return null;
  }
}

async function edgeChat(messages, env) {
  if (!env.AI) return null;
  try {
    const result = await env.AI.run('@cf/meta/llama-3.1-8b-instruct', { messages });
    return result.response;
  } catch {
    return null;
  }
}

// ── Request handler ──────────────────────────────────────────────────────────
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    // CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders(request) });
    }

    // Rate limiting
    const rl = await checkRateLimit(request, env);
    if (!rl.allowed) {
      return new Response(JSON.stringify({ error: 'Rate limit exceeded', retryAfter: rl.retryAfter }), {
        status: 429,
        headers: {
          ...corsHeaders(request),
          'Content-Type': 'application/json',
          'Retry-After': String(rl.retryAfter),
          'X-RateLimit-Limit': String(rl.limit),
          'X-RateLimit-Remaining': '0',
        },
      });
    }

    // Health
    if (url.pathname === '/health' || url.pathname === '/healthz') {
      return new Response(JSON.stringify({
        status: 'ok',
        service: 'liquid-gateway',
        edge: true,
        colo: request.cf?.colo,
        phi: PHI,
      }), {
        headers: { ...corsHeaders(request), 'Content-Type': 'application/json' },
      });
    }

    // Edge AI endpoints
    if (url.pathname === '/v1/edge/embed' && request.method === 'POST') {
      const body = await request.json();
      const cached = await getCachedEmbedding(body.text, env);
      if (cached) {
        return new Response(JSON.stringify({ ok: true, embedding: cached, cached: true }), {
          headers: { ...corsHeaders(request), 'Content-Type': 'application/json' },
        });
      }
      const embedding = await edgeEmbed(body.text, env);
      if (!embedding) {
        return new Response(JSON.stringify({ ok: false, error: 'Edge AI unavailable' }), {
          status: 503, headers: { ...corsHeaders(request), 'Content-Type': 'application/json' },
        });
      }
      return new Response(JSON.stringify({ ok: true, embedding, cached: false }), {
        headers: { ...corsHeaders(request), 'Content-Type': 'application/json' },
      });
    }

    if (url.pathname === '/v1/edge/chat' && request.method === 'POST') {
      const body = await request.json();
      const response = await edgeChat(body.messages, env);
      return new Response(JSON.stringify({ ok: !!response, response }), {
        headers: { ...corsHeaders(request), 'Content-Type': 'application/json' },
      });
    }

    // Domain-based origin routing
    const hostname = url.hostname;
    const domainConfig = DOMAINS[hostname] || DOMAINS[hostname.replace(/^www\./, '')];

    if (domainConfig) {
      const originUrl = new URL(url.pathname + url.search, domainConfig.origin);
      const originRequest = new Request(originUrl, {
        method: request.method,
        headers: request.headers,
        body: request.method !== 'GET' && request.method !== 'HEAD' ? request.body : null,
      });

      try {
        const response = await fetch(originRequest);
        const newHeaders = new Headers(response.headers);
        for (const [k, v] of Object.entries(corsHeaders(request))) newHeaders.set(k, v);
        newHeaders.set('X-Heady-Pool', domainConfig.pool);
        newHeaders.set('X-Heady-Edge', request.cf?.colo || 'unknown');

        return new Response(response.body, {
          status: response.status,
          headers: newHeaders,
        });
      } catch (err) {
        return new Response(JSON.stringify({ error: 'Origin unreachable', detail: err.message }), {
          status: 502, headers: { ...corsHeaders(request), 'Content-Type': 'application/json' },
        });
      }
    }

    // Default: pass through to Cloud Run origin
    const defaultOrigin = 'https://heady-manager.headysystems.com';
    const defaultUrl = new URL(url.pathname + url.search, defaultOrigin);

    try {
      const response = await fetch(new Request(defaultUrl, {
        method: request.method,
        headers: request.headers,
        body: request.method !== 'GET' && request.method !== 'HEAD' ? request.body : null,
      }));
      const newHeaders = new Headers(response.headers);
      for (const [k, v] of Object.entries(corsHeaders(request))) newHeaders.set(k, v);
      newHeaders.set('X-Heady-Pool', 'cold');

      return new Response(response.body, { status: response.status, headers: newHeaders });
    } catch (err) {
      return new Response(JSON.stringify({ error: 'Service unavailable' }), {
        status: 503, headers: { ...corsHeaders(request), 'Content-Type': 'application/json' },
      });
    }
  },
};
