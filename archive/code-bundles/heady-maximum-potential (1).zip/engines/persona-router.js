/**
 * persona-router.js — Routes interactions to AI personas by semantic alignment.
 * Uses MoE-style cosine routing, not priority ranking.
 * © 2026 HeadySystems Inc.
 */

import { PSI, CSL_THRESHOLDS, fib } from '../shared/phi-math.js';
import { cslAND, moeRoute, randomUnitVector, DEFAULT_DIM } from '../shared/csl-engine.js';

/** @typedef {{name: string, description: string, embedding: Float32Array, domains: string[]}} Persona */

const PERSONA_DEFS = [
  { name: 'analyst',    description: 'Data analysis, metrics, reporting, dashboards', domains: ['data', 'analytics', 'metrics', 'report', 'statistics'] },
  { name: 'creative',   description: 'UI design, visual art, content creation, branding', domains: ['design', 'creative', 'ui', 'visual', 'art', 'brand'] },
  { name: 'engineer',   description: 'Code, architecture, infrastructure, deployment', domains: ['code', 'build', 'deploy', 'infrastructure', 'api', 'service'] },
  { name: 'researcher', description: 'Investigation, learning, papers, prior art', domains: ['research', 'investigate', 'learn', 'paper', 'study', 'find'] },
  { name: 'companion',  description: 'Friendly chat, emotional support, motivation', domains: ['help', 'chat', 'feel', 'motivate', 'friend', 'buddy'] },
  { name: 'security',   description: 'Vulnerability analysis, auth, encryption, compliance', domains: ['security', 'vulnerability', 'auth', 'encrypt', 'compliance'] },
  { name: 'ops',        description: 'Monitoring, deployment, scaling, incident response', domains: ['monitor', 'deploy', 'scale', 'incident', 'health', 'ops'] },
];

/**
 * PersonaRouter — Semantic persona routing via CSL cosine similarity.
 */
export class PersonaRouter {
  constructor(config = {}) {
    this.dim = config.dim || DEFAULT_DIM;
    /** @type {Persona[]} */
    this.personas = [];
    this._initPersonas();
  }

  /** Initialize personas with deterministic domain-seeded embeddings. */
  _initPersonas() {
    for (const def of PERSONA_DEFS) {
      // Create a deterministic embedding from domain keywords
      const embedding = this._domainEmbed(def.domains);
      this.personas.push({
        name: def.name,
        description: def.description,
        embedding,
        domains: def.domains,
      });
    }
  }

  /**
   * Create a deterministic embedding from domain keywords.
   * Uses hash-based seeding for reproducibility.
   */
  _domainEmbed(domains) {
    const vec = new Float32Array(this.dim);
    for (const word of domains) {
      let hash = 0;
      for (let i = 0; i < word.length; i++) {
        hash = ((hash << 5) - hash + word.charCodeAt(i)) | 0;
      }
      // Distribute hash energy across dimensions
      for (let d = 0; d < this.dim; d++) {
        const seed = ((hash * (d + 1) * 2654435761) >>> 0) / 4294967296;
        vec[d] += (seed - 0.5) * 2;
      }
    }
    // Normalize
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    if (norm > 0) for (let i = 0; i < this.dim; i++) vec[i] /= norm;
    return vec;
  }

  /**
   * Embed user input text into a vector using domain keyword matching.
   * @param {string} text - User input
   * @returns {Float32Array} Input embedding
   */
  embedInput(text) {
    const words = text.toLowerCase().split(/\s+/);
    return this._domainEmbed(words);
  }

  /**
   * Route user input to the best-matching personas.
   * @param {string} userInput - User text
   * @param {object} [context] - Additional routing context
   * @returns {{primary: {name: string, weight: number, score: number}, secondary: {name: string, weight: number, score: number}|null, confident: boolean}}
   */
  route(userInput, context = {}) {
    const inputVec = this.embedInput(userInput);
    const gateVectors = this.personas.map(p => p.embedding);

    // MoE routing: select top-2 personas
    const selected = moeRoute(inputVec, gateVectors, 2);

    const primary = selected[0] ? {
      name: this.personas[selected[0].index].name,
      weight: selected[0].weight,
      score: selected[0].score,
    } : null;

    const secondary = selected[1] ? {
      name: this.personas[selected[1].index].name,
      weight: selected[1].weight,
      score: selected[1].score,
    } : null;

    // Confidence: primary must exceed LOW threshold
    const confident = primary && primary.score >= CSL_THRESHOLDS.LOW;

    return { primary, secondary, confident };
  }

  /**
   * Get all personas with their similarity to a given input.
   * @param {string} userInput - User text
   * @returns {Array<{name: string, similarity: number, description: string}>}
   */
  scoreAll(userInput) {
    const inputVec = this.embedInput(userInput);
    return this.personas
      .map(p => ({
        name: p.name,
        description: p.description,
        similarity: cslAND(inputVec, p.embedding),
      }))
      .sort((a, b) => b.similarity - a.similarity);
  }

  /** Register a custom persona */
  addPersona(name, description, domains) {
    this.personas.push({
      name,
      description,
      embedding: this._domainEmbed(domains),
      domains,
    });
  }

  /** List all registered personas */
  listPersonas() {
    return this.personas.map(p => ({ name: p.name, description: p.description, domains: p.domains }));
  }
}
