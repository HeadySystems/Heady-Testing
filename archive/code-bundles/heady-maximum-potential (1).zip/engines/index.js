/**
 * Heady Engines — Barrel Export
 * 
 * All engines import from shared/phi-math.js and shared/csl-engine.js.
 * Each engine is a self-contained module with its own class and config.
 */

export { EvolutionEngine, EvolutionConfig } from './evolution-engine.js';
export { PersonaRouter } from './persona-router.js';
export { WisdomStore } from './wisdom-store.js';
export { BudgetTracker, ALERT_THRESHOLDS } from './budget-tracker.js';
export { HeadyLens } from './heady-lens.js';
export { CouncilMode } from './council-mode.js';
export {
  AutoSuccessEngine,
  AutoSuccessPipelineBuilder,
  STAGES,
  STAGE_LIST,
  QUALITY_GATES
} from './auto-success-engine.js';
