/**
 * heady-lens.js — System observability and introspection in vector space.
 * Captures snapshots, compares states, detects anomalies.
 * © 2026 HeadySystems Inc.
 */

import { PSI, CSL_THRESHOLDS, fib } from '../shared/phi-math.js';
import { cslAND, detectDrift, randomUnitVector, DEFAULT_DIM } from '../shared/csl-engine.js';

/** @typedef {{timestamp: number, components: Map<string, Float32Array>, metadata: object}} Snapshot */

/**
 * HeadyLens — Vector-space observability for the Heady system.
 */
export class HeadyLens {
  constructor(config = {}) {
    this.dim = config.dim || DEFAULT_DIM;
    /** @type {Map<string, Float32Array>} Current tracked components */
    this.components = new Map();
    /** @type {Snapshot[]} */
    this.snapshots = [];
    this.maxSnapshots = config.maxSnapshots || fib(8);  // 34
  }

  /**
   * Register a component with its current embedding.
   * @param {string} name - Component identifier
   * @param {Float32Array} embedding - Current state vector
   */
  track(name, embedding) {
    this.components.set(name, embedding);
  }

  /**
   * Remove a component from tracking.
   * @param {string} name - Component identifier
   */
  untrack(name) {
    this.components.delete(name);
  }

  /**
   * Capture full system state as a snapshot.
   * @param {object} metadata - Additional snapshot context
   * @returns {{id: number, componentCount: number, timestamp: number}}
   */
  snapshot(metadata = {}) {
    const snap = {
      timestamp: Date.now(),
      components: new Map(this.components),
      metadata,
    };
    this.snapshots.push(snap);
    if (this.snapshots.length > this.maxSnapshots) {
      this.snapshots.shift();
    }
    return {
      id: this.snapshots.length - 1,
      componentCount: snap.components.size,
      timestamp: snap.timestamp,
    };
  }

  /**
   * Compare two snapshots. Measures system evolution via pairwise CSL AND.
   * @param {number} idA - First snapshot index
   * @param {number} idB - Second snapshot index
   * @returns {{overallSimilarity: number, perComponent: Array<{name: string, similarity: number, drifted: boolean}>, added: string[], removed: string[]}}
   */
  compare(idA, idB) {
    const snapA = this.snapshots[idA];
    const snapB = this.snapshots[idB];
    if (!snapA || !snapB) return { error: 'Snapshot not found' };

    const keysA = new Set(snapA.components.keys());
    const keysB = new Set(snapB.components.keys());

    const commonKeys = [...keysA].filter(k => keysB.has(k));
    const added = [...keysB].filter(k => !keysA.has(k));
    const removed = [...keysA].filter(k => !keysB.has(k));

    const perComponent = commonKeys.map(name => {
      const sim = cslAND(snapA.components.get(name), snapB.components.get(name));
      return { name, similarity: sim, drifted: sim < CSL_THRESHOLDS.MEDIUM };
    });

    const avgSim = perComponent.length > 0
      ? perComponent.reduce((s, c) => s + c.similarity, 0) / perComponent.length
      : 0;

    return {
      overallSimilarity: avgSim,
      perComponent: perComponent.sort((a, b) => a.similarity - b.similarity),
      added,
      removed,
      snapshotA: { id: idA, timestamp: snapA.timestamp },
      snapshotB: { id: idB, timestamp: snapB.timestamp },
    };
  }

  /**
   * Deep inspection of a component's vector neighborhood.
   * @param {string} name - Component to inspect
   * @param {number} topK - Nearest neighbors (default fib(5)=8)
   * @returns {{component: string, neighbors: Array<{name: string, similarity: number}>, isolated: boolean}}
   */
  focusOn(name, topK = fib(5)) {
    const target = this.components.get(name);
    if (!target) return { error: `Component '${name}' not tracked` };

    const neighbors = [];
    for (const [otherName, otherVec] of this.components) {
      if (otherName === name) continue;
      neighbors.push({ name: otherName, similarity: cslAND(target, otherVec) });
    }
    neighbors.sort((a, b) => b.similarity - a.similarity);

    const topNeighbors = neighbors.slice(0, topK);
    const avgSim = topNeighbors.length > 0
      ? topNeighbors.reduce((s, n) => s + n.similarity, 0) / topNeighbors.length
      : 0;

    return {
      component: name,
      neighbors: topNeighbors,
      avgNeighborSimilarity: avgSim,
      isolated: avgSim < CSL_THRESHOLDS.LOW,  // Component is an outlier
    };
  }

  /**
   * Pairwise similarity heatmap for all tracked components.
   * @returns {{components: string[], matrix: number[][]}}
   */
  heatmap() {
    const names = Array.from(this.components.keys());
    const vecs = names.map(n => this.components.get(n));
    const matrix = [];

    for (let i = 0; i < vecs.length; i++) {
      const row = [];
      for (let j = 0; j < vecs.length; j++) {
        row.push(i === j ? 1.0 : cslAND(vecs[i], vecs[j]));
      }
      matrix.push(row);
    }

    return { components: names, matrix };
  }

  /**
   * Detect anomalous components that drifted beyond threshold.
   * Compares current state against the most recent snapshot.
   * @returns {Array<{name: string, similarity: number, severity: string}>}
   */
  anomalies() {
    if (this.snapshots.length === 0) return [];
    const lastSnap = this.snapshots[this.snapshots.length - 1];
    const results = [];

    for (const [name, currentVec] of this.components) {
      const snapVec = lastSnap.components.get(name);
      if (!snapVec) continue;
      const drift = detectDrift(snapVec, currentVec);
      if (drift.drifted) {
        results.push({ name, similarity: drift.similarity, severity: drift.severity });
      }
    }

    return results.sort((a, b) => a.similarity - b.similarity);
  }

  /** Summary statistics */
  stats() {
    return {
      trackedComponents: this.components.size,
      snapshotCount: this.snapshots.length,
      maxSnapshots: this.maxSnapshots,
    };
  }
}
