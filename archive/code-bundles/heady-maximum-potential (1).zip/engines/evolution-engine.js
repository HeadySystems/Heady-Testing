/**
 * evolution-engine.js — Evolutionary optimization for Heady components.
 * Tracks component versions as embeddings, applies mutations, selects by fitness.
 * © 2026 HeadySystems Inc.
 */

import {
  PHI, PSI, FIB, CSL_THRESHOLDS, phiFusionWeights, phiBackoff, fib,
} from '../shared/phi-math.js';
import { cslAND, cslOR, cslNOT, detectDrift, randomUnitVector } from '../shared/csl-engine.js';

const DIM = 384;

/** @typedef {{id: string, embedding: Float32Array, fitness: number, generation: number, parent: string|null, mutation: string}} Individual */

/**
 * EvolutionEngine — Evolutionary optimization in 384D vector space.
 * Components evolve through mutation, fitness scoring, and selection.
 */
export class EvolutionEngine {
  constructor(config = {}) {
    this.dim = config.dim || DIM;
    this.populationSize = config.populationSize || fib(6);  // 13
    this.mutationRate = config.mutationRate || PSI * 0.1;    // ≈ 0.0618
    this.eliteRatio = PSI;                                    // top 61.8% survive
    /** @type {Map<string, Individual>} */
    this.population = new Map();
    /** @type {Array<{parent: string, child: string, mutation: string, generation: number}>} */
    this.lineage = [];
    this.generation = 0;
  }

  /**
   * Register a component in the population.
   * @param {string} id - Component identifier
   * @param {Float32Array} [embedding] - Initial embedding (random if omitted)
   */
  register(id, embedding = null) {
    this.population.set(id, {
      id,
      embedding: embedding || randomUnitVector(this.dim),
      fitness: 0,
      generation: this.generation,
      parent: null,
      mutation: 'genesis',
    });
  }

  /**
   * Apply a mutation to a component. Re-embeds with noise proportional to change magnitude.
   * @param {string} id - Component to mutate
   * @param {string} description - What changed
   * @param {number} magnitude - Change magnitude 0-1 (default mutationRate)
   * @returns {Individual|null} Mutated individual
   */
  mutate(id, description, magnitude = this.mutationRate) {
    const parent = this.population.get(id);
    if (!parent) return null;

    const noise = randomUnitVector(this.dim);
    const mutated = new Float32Array(this.dim);
    for (let i = 0; i < this.dim; i++) {
      mutated[i] = parent.embedding[i] * (1 - magnitude) + noise[i] * magnitude;
    }
    // Normalize
    const norm = Math.sqrt(mutated.reduce((s, v) => s + v * v, 0));
    for (let i = 0; i < this.dim; i++) mutated[i] /= norm || 1;

    const childId = `${id}__gen${this.generation + 1}`;
    const child = {
      id: childId,
      embedding: mutated,
      fitness: 0,
      generation: this.generation + 1,
      parent: id,
      mutation: description,
    };

    // Drift check
    const drift = detectDrift(parent.embedding, mutated);
    if (drift.drifted) {
      child.driftAlert = { severity: drift.severity, similarity: drift.similarity };
    }

    this.population.set(childId, child);
    this.lineage.push({ parent: id, child: childId, mutation: description, generation: this.generation + 1 });

    return child;
  }

  /**
   * Score component fitness via CSL gates against a reference "ideal" vector.
   * @param {string} id - Component to score
   * @param {Float32Array} idealVector - Reference vector representing ideal state
   * @returns {number} Fitness score 0-1
   */
  fitness(id, idealVector) {
    const individual = this.population.get(id);
    if (!individual) return 0;

    const similarity = cslAND(individual.embedding, idealVector);
    const normalizedFitness = (similarity + 1) / 2;  // Map [-1,1] to [0,1]
    individual.fitness = normalizedFitness;
    return normalizedFitness;
  }

  /**
   * Tournament selection — pick best from random subset using phi-weighted scoring.
   * @param {Individual[]} candidates - Pool to select from
   * @param {number} tournamentSize - Competitors per round (default fib(3)=3)
   * @returns {Individual} Winner
   */
  select(candidates, tournamentSize = fib(3)) {
    if (candidates.length === 0) return null;
    const subset = [];
    for (let i = 0; i < Math.min(tournamentSize, candidates.length); i++) {
      const idx = Math.floor(Math.random() * candidates.length);
      subset.push(candidates[idx]);
    }
    subset.sort((a, b) => b.fitness - a.fitness);
    return subset[0];
  }

  /**
   * Run one generation of evolution.
   * @param {Float32Array} idealVector - Reference ideal
   * @returns {{generation: number, bestFitness: number, avgFitness: number, survivors: number}}
   */
  evolve(idealVector) {
    this.generation++;

    // Score all
    const individuals = Array.from(this.population.values());
    for (const ind of individuals) {
      this.fitness(ind.id, idealVector);
    }

    // Sort by fitness
    individuals.sort((a, b) => b.fitness - a.fitness);

    // Elite selection: top PSI (61.8%) survive
    const eliteCount = Math.max(1, Math.ceil(individuals.length * this.eliteRatio));
    const elites = individuals.slice(0, eliteCount);

    // Generate children from elites to fill population
    const newPop = new Map();
    for (const e of elites) {
      newPop.set(e.id, e);
    }

    while (newPop.size < this.populationSize) {
      const parent = this.select(elites);
      if (!parent) break;
      const child = this.mutate(parent.id, `gen${this.generation}_crossover`);
      if (child) newPop.set(child.id, child);
    }

    this.population = newPop;

    const allFitness = Array.from(newPop.values()).map(i => i.fitness);
    return {
      generation: this.generation,
      bestFitness: Math.max(...allFitness),
      avgFitness: allFitness.reduce((a, b) => a + b, 0) / allFitness.length,
      survivors: newPop.size,
    };
  }

  /** Get evolution history */
  getLineage() { return this.lineage; }

  /** Get current population summary */
  getPopulation() {
    return Array.from(this.population.values()).map(i => ({
      id: i.id, fitness: i.fitness, generation: i.generation, parent: i.parent, mutation: i.mutation,
    }));
  }
}
