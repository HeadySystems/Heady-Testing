/**
 * wisdom-store.js — Persistent knowledge repository using vector embeddings.
 * Stores insights, deduplicates, ages, and prunes.
 * © 2026 HeadySystems Inc.
 */

import { PSI, CSL_THRESHOLDS, RELEVANCE_GATES, DEDUP_THRESHOLD, fib } from '../shared/phi-math.js';
import { cslAND, cslOR, DEFAULT_DIM } from '../shared/csl-engine.js';

const PSI_SQ = PSI * PSI;  // ≈ 0.382 — local convenience

/** @typedef {{id: string, text: string, embedding: Float32Array, source: string, confidence: number, createdAt: number, accessCount: number}} WisdomEntry */

/**
 * WisdomStore — Semantic knowledge repository in 384D vector space.
 */
export class WisdomStore {
  constructor(config = {}) {
    this.dim = config.dim || DEFAULT_DIM;
    this.maxEntries = config.maxEntries || fib(12);  // 233
    /** @type {Map<string, WisdomEntry>} */
    this.entries = new Map();
    this._idCounter = 0;
  }

  /**
   * Embed text into a vector using deterministic hashing.
   * In production, replace with sentence-transformers.
   */
  _embed(text) {
    const vec = new Float32Array(this.dim);
    const words = text.toLowerCase().split(/\s+/);
    for (const word of words) {
      let hash = 0;
      for (let i = 0; i < word.length; i++) {
        hash = ((hash << 5) - hash + word.charCodeAt(i)) | 0;
      }
      for (let d = 0; d < this.dim; d++) {
        const seed = ((hash * (d + 1) * 2654435761) >>> 0) / 4294967296;
        vec[d] += (seed - 0.5);
      }
    }
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    if (norm > 0) for (let i = 0; i < this.dim; i++) vec[i] /= norm;
    return vec;
  }

  /**
   * Store an insight with source attribution and confidence.
   * @param {string} insight - The knowledge to store
   * @param {string} source - Where it came from
   * @param {number} confidence - Confidence level 0-1 (default PSI ≈ 0.618)
   * @returns {{id: string, deduplicated: boolean}}
   */
  store(insight, source, confidence = PSI) {
    const embedding = this._embed(insight);

    // Check for duplicates
    for (const [id, entry] of this.entries) {
      const sim = cslAND(embedding, entry.embedding);
      if (sim >= DEDUP_THRESHOLD) {
        // Merge: boost confidence, update source
        entry.confidence = Math.min(1.0, entry.confidence + confidence * PSI_SQ);
        entry.accessCount++;
        return { id, deduplicated: true };
      }
    }

    // Evict oldest if at capacity
    if (this.entries.size >= this.maxEntries) {
      this._evictLowest();
    }

    const id = `wisdom-${++this._idCounter}`;
    this.entries.set(id, {
      id,
      text: insight,
      embedding,
      source,
      confidence: Math.min(1.0, confidence),
      createdAt: Date.now(),
      accessCount: 0,
    });

    return { id, deduplicated: false };
  }

  /**
   * Semantic search for relevant wisdom.
   * @param {string} question - Query text
   * @param {number} topK - Max results (default fib(5)=8)
   * @returns {Array<{id: string, text: string, source: string, confidence: number, similarity: number}>}
   */
  query(question, topK = fib(5)) {
    const queryVec = this._embed(question);
    const results = [];

    for (const [id, entry] of this.entries) {
      const similarity = cslAND(queryVec, entry.embedding);
      if (similarity >= RELEVANCE_GATES.include) {
        results.push({
          id,
          text: entry.text,
          source: entry.source,
          confidence: entry.confidence,
          similarity,
        });
        entry.accessCount++;
      }
    }

    results.sort((a, b) => b.similarity - a.similarity);
    return results.slice(0, topK);
  }

  /**
   * Consolidate similar entries via CSL OR superposition.
   * @returns {number} Number of entries merged
   */
  consolidate() {
    const entries = Array.from(this.entries.values());
    const merged = new Set();
    let mergeCount = 0;

    for (let i = 0; i < entries.length; i++) {
      if (merged.has(entries[i].id)) continue;
      for (let j = i + 1; j < entries.length; j++) {
        if (merged.has(entries[j].id)) continue;
        const sim = cslAND(entries[i].embedding, entries[j].embedding);
        if (sim >= CSL_THRESHOLDS.HIGH) {
          // Merge j into i via superposition
          entries[i].embedding = cslOR(entries[i].embedding, entries[j].embedding);
          entries[i].confidence = Math.min(1.0, entries[i].confidence + entries[j].confidence * PSI_SQ);
          entries[i].text += ` | ${entries[j].text}`;
          entries[i].accessCount += entries[j].accessCount;
          merged.add(entries[j].id);
          mergeCount++;
        }
      }
    }

    for (const id of merged) this.entries.delete(id);
    return mergeCount;
  }

  /**
   * Apply time-based confidence decay (phi-decay).
   * @param {number} decayRate - Decay rate per day (default PSI³ ≈ 0.236)
   */
  age(decayRate = PSI * PSI * PSI) {
    const now = Date.now();
    const msPerDay = 86400000;
    for (const entry of this.entries.values()) {
      const daysOld = (now - entry.createdAt) / msPerDay;
      const decay = Math.pow(1 - decayRate, daysOld);
      entry.confidence *= decay;
    }
  }

  /**
   * Remove entries below minimum confidence.
   * @param {number} minConfidence - Threshold (default RELEVANCE_GATES.include ≈ 0.382)
   * @returns {number} Number of entries pruned
   */
  prune(minConfidence = RELEVANCE_GATES.include) {
    let pruned = 0;
    for (const [id, entry] of this.entries) {
      if (entry.confidence < minConfidence) {
        this.entries.delete(id);
        pruned++;
      }
    }
    return pruned;
  }

  /** Evict the entry with lowest composite score (confidence × recency × access) */
  _evictLowest() {
    let lowestId = null;
    let lowestScore = Infinity;
    const now = Date.now();

    for (const [id, entry] of this.entries) {
      const age = (now - entry.createdAt) / 86400000 + 1;
      const score = entry.confidence * (entry.accessCount + 1) / age;
      if (score < lowestScore) {
        lowestScore = score;
        lowestId = id;
      }
    }

    if (lowestId) this.entries.delete(lowestId);
  }

  /** Get store statistics */
  stats() {
    const entries = Array.from(this.entries.values());
    const confidences = entries.map(e => e.confidence);
    return {
      totalEntries: entries.length,
      maxEntries: this.maxEntries,
      avgConfidence: confidences.length > 0 ? confidences.reduce((a, b) => a + b, 0) / confidences.length : 0,
      minConfidence: confidences.length > 0 ? Math.min(...confidences) : 0,
      maxConfidence: confidences.length > 0 ? Math.max(...confidences) : 0,
    };
  }
}
