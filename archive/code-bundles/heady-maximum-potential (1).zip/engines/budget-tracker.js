/**
 * budget-tracker.js — Token usage, API costs, and compute budget tracking.
 * Uses phi-scaled alert thresholds and Fibonacci-window moving averages.
 * © 2026 HeadySystems Inc.
 */

import { PHI, PSI, FIB, ALERT_THRESHOLDS, fib, phiFusionWeights } from '../shared/phi-math.js';

/** @typedef {{provider: string, inputTokens: number, outputTokens: number, cost: number, timestamp: number}} UsageRecord */

/**
 * BudgetTracker — Tracks spend across all providers with phi-scaled alerting.
 */
export class BudgetTracker {
  /**
   * @param {object} config
   * @param {number} config.totalBudget - Total budget in dollars
   * @param {number} config.windowSize - Fibonacci-sized moving average window
   */
  constructor(config = {}) {
    this.totalBudget = config.totalBudget || 1000;
    this.windowSize = config.windowSize || fib(8);  // 34
    /** @type {UsageRecord[]} */
    this.records = [];
    /** @type {Map<string, {inputTokens: number, outputTokens: number, cost: number, requestCount: number}>} */
    this.providerTotals = new Map();
    this.startTime = Date.now();
  }

  /**
   * Record a usage event.
   * @param {string} provider - Provider name (claude, gpt4o, gemini, groq, etc.)
   * @param {number} inputTokens - Input tokens consumed
   * @param {number} outputTokens - Output tokens consumed
   * @param {number} cost - Cost in dollars
   */
  record(provider, inputTokens, outputTokens, cost) {
    const rec = { provider, inputTokens, outputTokens, cost, timestamp: Date.now() };
    this.records.push(rec);

    if (!this.providerTotals.has(provider)) {
      this.providerTotals.set(provider, { inputTokens: 0, outputTokens: 0, cost: 0, requestCount: 0 });
    }
    const totals = this.providerTotals.get(provider);
    totals.inputTokens += inputTokens;
    totals.outputTokens += outputTokens;
    totals.cost += cost;
    totals.requestCount++;
  }

  /** Total cost across all providers */
  get totalSpent() {
    let sum = 0;
    for (const t of this.providerTotals.values()) sum += t.cost;
    return sum;
  }

  /** Remaining budget */
  get remaining() {
    return Math.max(0, this.totalBudget - this.totalSpent);
  }

  /** Budget utilization ratio (0-1) */
  get utilization() {
    return this.totalBudget > 0 ? this.totalSpent / this.totalBudget : 0;
  }

  /**
   * Get full budget status.
   * @returns {{totalBudget: number, totalSpent: number, remaining: number, utilization: number, burnRate: number, projectedExhaustion: string, providers: object}}
   */
  getBudgetStatus() {
    const burnRate = this._burnRatePerHour();
    const hoursRemaining = burnRate > 0 ? this.remaining / burnRate : Infinity;
    const exhaustionDate = hoursRemaining === Infinity
      ? 'never'
      : new Date(Date.now() + hoursRemaining * 3600000).toISOString();

    return {
      totalBudget: this.totalBudget,
      totalSpent: Math.round(this.totalSpent * 1e6) / 1e6,
      remaining: Math.round(this.remaining * 1e6) / 1e6,
      utilization: Math.round(this.utilization * 1e4) / 1e4,
      burnRatePerHour: Math.round(burnRate * 1e6) / 1e6,
      projectedExhaustion: exhaustionDate,
      providers: Object.fromEntries(this.providerTotals),
      totalRequests: this.records.length,
    };
  }

  /**
   * Get alerts based on phi-scaled thresholds.
   * @returns {Array<{level: string, message: string, utilization: number}>}
   */
  alert() {
    const util = this.utilization;
    const alerts = [];

    if (util >= ALERT_THRESHOLDS.hard_max) {
      alerts.push({ level: 'exceeded', message: 'Budget fully exhausted', utilization: util });
    } else if (util >= ALERT_THRESHOLDS.exceeded) {
      alerts.push({ level: 'exceeded', message: `Budget ${Math.round(util * 100)}% consumed — approaching limit`, utilization: util });
    } else if (util >= ALERT_THRESHOLDS.critical) {
      alerts.push({ level: 'critical', message: `Budget ${Math.round(util * 100)}% consumed — critical threshold`, utilization: util });
    } else if (util >= ALERT_THRESHOLDS.caution) {
      alerts.push({ level: 'caution', message: `Budget ${Math.round(util * 100)}% consumed — caution`, utilization: util });
    } else if (util >= ALERT_THRESHOLDS.warning) {
      alerts.push({ level: 'warning', message: `Budget ${Math.round(util * 100)}% consumed — warning`, utilization: util });
    }

    // Check for cost acceleration
    const recentRate = this._burnRatePerHour(fib(5));   // Last 8 records
    const overallRate = this._burnRatePerHour();
    if (overallRate > 0 && recentRate > overallRate * PHI) {
      alerts.push({ level: 'warning', message: `Burn rate accelerating: ${(recentRate / overallRate).toFixed(2)}× baseline`, utilization: util });
    }

    return alerts;
  }

  /**
   * Project cost N hours ahead.
   * @param {number} hoursAhead - Hours to project
   * @returns {{projectedCost: number, projectedTotal: number, willExceedBudget: boolean, exceedAt: number|null}}
   */
  costProjection(hoursAhead) {
    const rate = this._burnRatePerHour();
    const projectedCost = rate * hoursAhead;
    const projectedTotal = this.totalSpent + projectedCost;
    const willExceed = projectedTotal > this.totalBudget;
    const exceedAt = willExceed && rate > 0 ? this.remaining / rate : null;

    return {
      projectedCost: Math.round(projectedCost * 1e6) / 1e6,
      projectedTotal: Math.round(projectedTotal * 1e6) / 1e6,
      willExceedBudget: willExceed,
      exceedAtHours: exceedAt ? Math.round(exceedAt * 100) / 100 : null,
    };
  }

  /**
   * Per-provider breakdown with moving averages.
   * @returns {Array<{provider: string, totalCost: number, avgCostPerRequest: number, movingAvgCost: number, requestCount: number}>}
   */
  providerBreakdown() {
    const result = [];
    for (const [name, totals] of this.providerTotals) {
      const providerRecords = this.records.filter(r => r.provider === name);
      const recentWindow = providerRecords.slice(-this.windowSize);
      const movingAvg = recentWindow.length > 0
        ? recentWindow.reduce((s, r) => s + r.cost, 0) / recentWindow.length
        : 0;

      result.push({
        provider: name,
        totalCost: Math.round(totals.cost * 1e6) / 1e6,
        avgCostPerRequest: totals.requestCount > 0 ? Math.round((totals.cost / totals.requestCount) * 1e6) / 1e6 : 0,
        movingAvgCost: Math.round(movingAvg * 1e6) / 1e6,
        requestCount: totals.requestCount,
        inputTokens: totals.inputTokens,
        outputTokens: totals.outputTokens,
      });
    }
    return result.sort((a, b) => b.totalCost - a.totalCost);
  }

  /** Calculate burn rate (cost per hour) from recent records. */
  _burnRatePerHour(windowSize = this.windowSize) {
    if (this.records.length < 2) return 0;
    const window = this.records.slice(-windowSize);
    const timeSpanMs = window[window.length - 1].timestamp - window[0].timestamp;
    if (timeSpanMs <= 0) return 0;
    const costInWindow = window.reduce((s, r) => s + r.cost, 0);
    return costInWindow / (timeSpanMs / 3600000);
  }
}
