/**
 * council-mode.js — Multi-model council for consensus-based reasoning.
 * Runs same query through multiple AI providers and synthesizes results.
 * © 2026 HeadySystems Inc.
 */

import { PSI, CSL_THRESHOLDS, phiFusionWeights, fib } from '../shared/phi-math.js';
import { cslAND, cslOR, cslXOR, cslCONSENSUS, DEFAULT_DIM } from '../shared/csl-engine.js';

/** @typedef {{model: string, response: string, embedding: Float32Array, latencyMs: number}} CouncilResponse */

/**
 * CouncilMode — Multi-model deliberation and consensus synthesis.
 */
export class CouncilMode {
  constructor(config = {}) {
    this.dim = config.dim || DEFAULT_DIM;
    /** @type {Array<{name: string, endpoint: string, apiKeyEnv: string}>} */
    this.models = config.models || [
      { name: 'claude', endpoint: '/infer', apiKeyEnv: 'ANTHROPIC_API_KEY' },
      { name: 'gpt4o', endpoint: '/infer', apiKeyEnv: 'OPENAI_API_KEY' },
      { name: 'gemini', endpoint: '/infer', apiKeyEnv: 'GOOGLE_API_KEY' },
    ];
    /** Minimum models for valid council */
    this.quorum = config.quorum || fib(3);  // 3
  }

  /**
   * Simple text-to-embedding for council use.
   * In production, use the Vector Brain runtime.
   */
  _embed(text) {
    const vec = new Float32Array(this.dim);
    const words = text.toLowerCase().split(/\s+/);
    for (const word of words) {
      let hash = 0;
      for (let i = 0; i < word.length; i++) {
        hash = ((hash << 5) - hash + word.charCodeAt(i)) | 0;
      }
      for (let d = 0; d < this.dim; d++) {
        const seed = ((hash * (d + 1) * 2654435761) >>> 0) / 4294967296;
        vec[d] += (seed - 0.5);
      }
    }
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
    if (norm > 0) for (let i = 0; i < this.dim; i++) vec[i] /= norm;
    return vec;
  }

  /**
   * Convene the council — send query to all models concurrently.
   * @param {string} query - The question to deliberate on
   * @param {Function} inferFn - async (modelName, query) => {response: string, latencyMs: number}
   * @returns {Promise<{responses: CouncilResponse[], quorumMet: boolean}>}
   */
  async convene(query, inferFn) {
    const promises = this.models.map(async (model) => {
      try {
        const start = Date.now();
        const result = await inferFn(model.name, query);
        return {
          model: model.name,
          response: result.response,
          embedding: this._embed(result.response),
          latencyMs: Date.now() - start,
          error: null,
        };
      } catch (err) {
        return { model: model.name, response: '', embedding: new Float32Array(this.dim), latencyMs: 0, error: err.message };
      }
    });

    const settled = await Promise.allSettled(promises);
    const responses = settled
      .filter(s => s.status === 'fulfilled' && !s.value.error)
      .map(s => s.value);

    return { responses, quorumMet: responses.length >= this.quorum };
  }

  /**
   * Synthesize council responses into consensus via CSL CONSENSUS.
   * @param {CouncilResponse[]} responses - Council responses
   * @returns {{consensusEmbedding: Float32Array, agreement: number, summary: object}}
   */
  synthesize(responses) {
    if (responses.length === 0) return { consensusEmbedding: new Float32Array(this.dim), agreement: 0, summary: {} };

    const inputs = responses.map(r => ({ vector: r.embedding, weight: 1.0 }));
    const consensusVec = cslCONSENSUS(inputs);

    // Calculate agreement: average pairwise similarity
    let pairCount = 0;
    let pairSum = 0;
    for (let i = 0; i < responses.length; i++) {
      for (let j = i + 1; j < responses.length; j++) {
        pairSum += cslAND(responses[i].embedding, responses[j].embedding);
        pairCount++;
      }
    }
    const agreement = pairCount > 0 ? pairSum / pairCount : 1.0;

    // Per-model alignment to consensus
    const modelAlignments = responses.map(r => ({
      model: r.model,
      alignmentToConsensus: cslAND(r.embedding, consensusVec),
      latencyMs: r.latencyMs,
    }));

    return {
      consensusEmbedding: consensusVec,
      agreement,
      modelAlignments: modelAlignments.sort((a, b) => b.alignmentToConsensus - a.alignmentToConsensus),
      strongConsensus: agreement >= CSL_THRESHOLDS.MEDIUM,
    };
  }

  /**
   * Council votes on a question with discrete options.
   * @param {string} question - The question
   * @param {string[]} options - Available choices
   * @param {Function} inferFn - async (modelName, prompt) => {response: string}
   * @returns {Promise<{winner: string, votes: object, agreement: number}>}
   */
  async vote(question, options, inferFn) {
    const prompt = `Question: ${question}\nOptions: ${options.join(', ')}\nAnswer with exactly one option.`;
    const { responses } = await this.convene(prompt, inferFn);

    const votes = {};
    for (const opt of options) votes[opt] = 0;

    for (const r of responses) {
      const responseLower = r.response.toLowerCase();
      let bestMatch = options[0];
      let bestScore = -1;
      for (const opt of options) {
        if (responseLower.includes(opt.toLowerCase())) {
          const score = cslAND(this._embed(r.response), this._embed(opt));
          if (score > bestScore) {
            bestScore = score;
            bestMatch = opt;
          }
        }
      }
      votes[bestMatch] = (votes[bestMatch] || 0) + 1;
    }

    const totalVotes = responses.length;
    const winner = Object.entries(votes).sort(([, a], [, b]) => b - a)[0][0];
    const agreement = totalVotes > 0 ? votes[winner] / totalVotes : 0;

    return { winner, votes, agreement, strongConsensus: agreement >= PSI, totalVoters: totalVotes };
  }

  /**
   * Identify divergence points using CSL XOR.
   * @param {CouncilResponse[]} responses - Council responses
   * @returns {Array<{modelA: string, modelB: string, divergence: Float32Array, similarity: number}>}
   */
  disagree(responses) {
    const divergences = [];

    for (let i = 0; i < responses.length; i++) {
      for (let j = i + 1; j < responses.length; j++) {
        const sim = cslAND(responses[i].embedding, responses[j].embedding);
        if (sim < CSL_THRESHOLDS.LOW) {
          divergences.push({
            modelA: responses[i].model,
            modelB: responses[j].model,
            divergence: cslXOR(responses[i].embedding, responses[j].embedding),
            similarity: sim,
          });
        }
      }
    }

    return divergences.sort((a, b) => a.similarity - b.similarity);
  }

  /**
   * Overall council confidence (agreement across all model pairs).
   * @param {CouncilResponse[]} responses
   * @returns {number} Confidence score 0-1
   */
  confidence(responses) {
    if (responses.length < 2) return responses.length === 1 ? PSI : 0;

    let sum = 0;
    let count = 0;
    for (let i = 0; i < responses.length; i++) {
      for (let j = i + 1; j < responses.length; j++) {
        sum += (cslAND(responses[i].embedding, responses[j].embedding) + 1) / 2;
        count++;
      }
    }
    return count > 0 ? sum / count : 0;
  }
}
