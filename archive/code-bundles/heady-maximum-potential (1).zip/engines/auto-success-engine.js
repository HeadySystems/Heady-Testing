/**
 * HeadyAutoSuccess Engine — Automated Success Pipeline
 * 
 * Chains five stages into a single autonomous workflow:
 *   Battle → Coder → Analyze → Risks → Patterns
 * 
 * Each stage produces artifacts consumed by the next. The pipeline
 * uses CSL-gated quality checks between stages and phi-scaled
 * timeouts, retries, and scoring throughout.
 * 
 * Patent-relevant: CSL-gated multi-stage pipeline with
 * phi-continuous scoring and automatic rollback.
 */

import {
  PHI, PSI, PHI2, PHI3,
  FIB, phiThreshold, phiBackoff,
  phiFusionWeights, CSL_THRESHOLDS,
  cosineSimilarity, normalize384
} from '../shared/phi-math.js';

import {
  cslAND, cslOR, cslGATE, cslCONSENSUS
} from '../shared/csl-engine.js';

// ── Pipeline Stage Definitions ──────────────────────────────────

const STAGES = Object.freeze({
  BATTLE:   { id: 'battle',   order: 0, timeout: FIB[10] * 1000,  description: 'Competitive evaluation — pit solutions against each other' },
  CODER:    { id: 'coder',    order: 1, timeout: FIB[11] * 1000,  description: 'Code generation — produce implementation from best candidate' },
  ANALYZE:  { id: 'analyze',  order: 2, timeout: FIB[10] * 1000,  description: 'Deep analysis — verify correctness, performance, security' },
  RISKS:    { id: 'risks',    order: 3, timeout: FIB[9] * 1000,   description: 'Risk assessment — identify vulnerabilities and edge cases' },
  PATTERNS: { id: 'patterns', order: 4, timeout: FIB[9] * 1000,   description: 'Pattern capture — extract reusable learnings for memory' }
});

const STAGE_LIST = Object.values(STAGES).sort((a, b) => a.order - b.order);

// Quality gate thresholds between stages (phi-harmonic)
const QUALITY_GATES = Object.freeze({
  battle_to_coder:    CSL_THRESHOLDS.LOW,       // ≈ 0.691 — need reasonable winner
  coder_to_analyze:   CSL_THRESHOLDS.MINIMUM,   // ≈ 0.500 — code must parse
  analyze_to_risks:   CSL_THRESHOLDS.MEDIUM,    // ≈ 0.809 — analysis must be solid
  risks_to_patterns:  CSL_THRESHOLDS.LOW         // ≈ 0.691 — risks identified
});

// ── AutoSuccess Pipeline ────────────────────────────────────────

export class AutoSuccessEngine {
  constructor(config = {}) {
    this.maxRetries = config.maxRetries ?? FIB[5];           // 5 retries per stage
    this.qualityVector = config.qualityVector ?? null;       // reference quality embedding
    this.llmProvider = config.llmProvider ?? null;           // LLM routing interface
    this.vectorMemory = config.vectorMemory ?? null;         // for pattern storage
    this.telemetry = config.telemetry ?? console;
    
    // Pipeline state
    this.runs = new Map();                                   // runId → RunState
    this.completedRuns = [];                                 // circular buffer
    this.maxHistory = FIB[8];                                // 21 completed runs
    
    // Stage handlers — pluggable
    this.handlers = new Map();
    this._registerDefaultHandlers();
  }

  // ── Public API ──────────────────────────────────────────────

  /**
   * Execute the full auto-success pipeline
   * @param {Object} task - { objective, context, constraints, embedding }
   * @returns {Object} Pipeline result with all stage artifacts
   */
  async execute(task) {
    const runId = `as-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const run = {
      id: runId,
      task,
      startedAt: Date.now(),
      stages: {},
      currentStage: null,
      status: 'running',
      qualityScores: {},
      artifacts: {},
      errors: []
    };
    this.runs.set(runId, run);

    this.telemetry.log?.(`[AutoSuccess] Pipeline ${runId} started`, {
      objective: task.objective?.slice(0, 100)
    });

    try {
      for (const stage of STAGE_LIST) {
        run.currentStage = stage.id;
        
        const stageResult = await this._executeStage(run, stage);
        run.stages[stage.id] = stageResult;
        run.artifacts[stage.id] = stageResult.artifacts;

        // Quality gate check (except after last stage)
        if (stage.order < STAGE_LIST.length - 1) {
          const gateKey = `${STAGE_LIST[stage.order].id}_to_${STAGE_LIST[stage.order + 1].id}`;
          const gateThreshold = QUALITY_GATES[gateKey] ?? CSL_THRESHOLDS.MINIMUM;
          const qualityScore = stageResult.qualityScore ?? 0;
          run.qualityScores[stage.id] = qualityScore;

          if (qualityScore < gateThreshold) {
            this.telemetry.warn?.(`[AutoSuccess] Quality gate failed at ${stage.id}`, {
              score: qualityScore, threshold: gateThreshold, runId
            });
            
            // Attempt retry with feedback
            const retryResult = await this._retryStage(run, stage, stageResult);
            if (retryResult.qualityScore < gateThreshold) {
              run.status = 'failed';
              run.failedAt = stage.id;
              run.error = `Quality gate failed: ${stage.id} score ${retryResult.qualityScore} < ${gateThreshold}`;
              this._archiveRun(run);
              return this._formatResult(run);
            }
            // Replace with retry result
            run.stages[stage.id] = retryResult;
            run.artifacts[stage.id] = retryResult.artifacts;
            run.qualityScores[stage.id] = retryResult.qualityScore;
          }
        }
      }

      run.status = 'completed';
      run.completedAt = Date.now();
      run.duration = run.completedAt - run.startedAt;
      
      // Store patterns in vector memory for future reference
      await this._storePatterns(run);
      
      this._archiveRun(run);
      
      this.telemetry.log?.(`[AutoSuccess] Pipeline ${runId} completed`, {
        duration: run.duration,
        scores: run.qualityScores
      });

      return this._formatResult(run);

    } catch (err) {
      run.status = 'error';
      run.error = err.message;
      run.errors.push({ stage: run.currentStage, error: err.message, at: Date.now() });
      this._archiveRun(run);
      throw err;
    }
  }

  /**
   * Get pipeline status
   */
  getStatus(runId) {
    return this.runs.get(runId) ?? null;
  }

  /**
   * Register a custom stage handler
   */
  registerHandler(stageId, handler) {
    if (typeof handler.execute !== 'function') {
      throw new Error(`Handler for ${stageId} must have an execute() method`);
    }
    this.handlers.set(stageId, handler);
  }

  // ── Stage Execution ─────────────────────────────────────────

  async _executeStage(run, stage) {
    const handler = this.handlers.get(stage.id);
    if (!handler) {
      throw new Error(`No handler registered for stage: ${stage.id}`);
    }

    const stageStart = Date.now();
    const previousArtifacts = this._gatherPreviousArtifacts(run, stage.order);

    const context = {
      task: run.task,
      previousArtifacts,
      qualityVector: this.qualityVector,
      stageConfig: stage,
      runId: run.id
    };

    // Execute with timeout
    const result = await Promise.race([
      handler.execute(context),
      this._timeout(stage.timeout, stage.id)
    ]);

    return {
      stageId: stage.id,
      startedAt: stageStart,
      completedAt: Date.now(),
      duration: Date.now() - stageStart,
      qualityScore: result.qualityScore ?? this._computeQuality(result, run.task),
      artifacts: result.artifacts ?? {},
      metadata: result.metadata ?? {}
    };
  }

  async _retryStage(run, stage, previousResult) {
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      const delay = phiBackoff(attempt);
      await new Promise(r => setTimeout(r, delay));

      this.telemetry.log?.(`[AutoSuccess] Retrying ${stage.id}, attempt ${attempt}/${this.maxRetries}`);

      try {
        const retryContext = {
          task: run.task,
          previousArtifacts: this._gatherPreviousArtifacts(run, stage.order),
          previousResult,
          qualityVector: this.qualityVector,
          stageConfig: stage,
          runId: run.id,
          retryAttempt: attempt,
          feedback: previousResult.metadata?.feedback ?? 'Improve quality score'
        };

        const handler = this.handlers.get(stage.id);
        const result = await Promise.race([
          handler.execute(retryContext),
          this._timeout(stage.timeout * PHI, stage.id)   // Phi-extended timeout on retry
        ]);

        const stageResult = {
          stageId: stage.id,
          startedAt: Date.now(),
          completedAt: Date.now(),
          qualityScore: result.qualityScore ?? this._computeQuality(result, run.task),
          artifacts: result.artifacts ?? {},
          metadata: { ...result.metadata, retryAttempt: attempt }
        };

        const gateKey = `${stage.id}_to_${STAGE_LIST[stage.order + 1]?.id}`;
        const gateThreshold = QUALITY_GATES[gateKey] ?? CSL_THRESHOLDS.MINIMUM;

        if (stageResult.qualityScore >= gateThreshold) {
          return stageResult;
        }

        previousResult = stageResult;
      } catch (err) {
        run.errors.push({ stage: stage.id, attempt, error: err.message, at: Date.now() });
      }
    }

    return previousResult;   // Return best attempt even if below threshold
  }

  // ── Quality Scoring ─────────────────────────────────────────

  _computeQuality(result, task) {
    const factors = [];

    // Factor 1: Completeness — did the stage produce expected artifacts?
    const expectedKeys = this._expectedArtifactKeys(result.stageId);
    const actualKeys = Object.keys(result.artifacts ?? {});
    const completeness = expectedKeys.length > 0
      ? actualKeys.filter(k => expectedKeys.includes(k)).length / expectedKeys.length
      : PSI;   // Default to ψ if no expectations defined
    factors.push(completeness);

    // Factor 2: Embedding alignment with task (if available)
    if (task.embedding && result.artifacts?.embedding) {
      const alignment = cosineSimilarity(task.embedding, result.artifacts.embedding);
      factors.push(Math.max(0, alignment));
    } else {
      factors.push(PSI);   // Neutral score
    }

    // Factor 3: Self-reported confidence
    const confidence = result.metadata?.confidence ?? PSI;
    factors.push(confidence);

    // Phi-weighted fusion
    const weights = phiFusionWeights(factors.length);
    return factors.reduce((sum, f, i) => sum + f * weights[i], 0);
  }

  _expectedArtifactKeys(stageId) {
    const expectations = {
      battle:   ['winner', 'candidates', 'scores'],
      coder:    ['code', 'language', 'tests'],
      analyze:  ['analysis', 'metrics', 'issues'],
      risks:    ['risks', 'mitigations', 'severity'],
      patterns: ['patterns', 'learnings', 'embedding']
    };
    return expectations[stageId] ?? [];
  }

  // ── Pattern Storage ─────────────────────────────────────────

  async _storePatterns(run) {
    if (!this.vectorMemory) return;

    const patternsArtifact = run.artifacts.patterns;
    if (!patternsArtifact?.patterns) return;

    try {
      for (const pattern of patternsArtifact.patterns) {
        await this.vectorMemory.store({
          content: JSON.stringify(pattern),
          embedding: pattern.embedding ?? patternsArtifact.embedding,
          metadata: {
            source: 'auto-success',
            runId: run.id,
            objective: run.task.objective?.slice(0, 200),
            qualityScores: run.qualityScores,
            timestamp: Date.now()
          }
        });
      }
      this.telemetry.log?.(`[AutoSuccess] Stored ${patternsArtifact.patterns.length} patterns`);
    } catch (err) {
      this.telemetry.warn?.(`[AutoSuccess] Pattern storage failed: ${err.message}`);
    }
  }

  // ── Helpers ─────────────────────────────────────────────────

  _gatherPreviousArtifacts(run, beforeOrder) {
    const artifacts = {};
    for (const stage of STAGE_LIST) {
      if (stage.order < beforeOrder && run.artifacts[stage.id]) {
        artifacts[stage.id] = run.artifacts[stage.id];
      }
    }
    return artifacts;
  }

  _timeout(ms, stageId) {
    return new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`Stage ${stageId} timed out after ${ms}ms`)), ms)
    );
  }

  _archiveRun(run) {
    this.completedRuns.push({
      id: run.id,
      status: run.status,
      duration: run.completedAt ? run.completedAt - run.startedAt : null,
      qualityScores: run.qualityScores,
      stageCount: Object.keys(run.stages).length,
      archivedAt: Date.now()
    });
    // Fibonacci-bounded circular buffer
    if (this.completedRuns.length > this.maxHistory) {
      this.completedRuns = this.completedRuns.slice(-this.maxHistory);
    }
    this.runs.delete(run.id);
  }

  _formatResult(run) {
    return {
      runId: run.id,
      status: run.status,
      duration: run.completedAt ? run.completedAt - run.startedAt : null,
      qualityScores: run.qualityScores,
      artifacts: run.artifacts,
      stages: Object.fromEntries(
        Object.entries(run.stages).map(([k, v]) => [k, {
          duration: v.duration,
          qualityScore: v.qualityScore,
          metadata: v.metadata
        }])
      ),
      errors: run.errors,
      failedAt: run.failedAt ?? null
    };
  }

  // ── Default Handlers ────────────────────────────────────────

  _registerDefaultHandlers() {
    // Battle: Competitive evaluation of multiple approaches
    this.handlers.set('battle', {
      execute: async (ctx) => {
        const candidates = ctx.task.candidates ?? [
          { id: 'approach-a', description: 'Primary approach', embedding: ctx.task.embedding },
          { id: 'approach-b', description: 'Alternative approach', embedding: ctx.task.embedding }
        ];

        // Score each candidate against task objective embedding
        const scores = candidates.map(c => ({
          ...c,
          score: c.embedding && ctx.task.embedding
            ? cosineSimilarity(c.embedding, ctx.task.embedding)
            : PSI
        }));

        scores.sort((a, b) => b.score - a.score);
        const winner = scores[0];

        return {
          qualityScore: winner.score,
          artifacts: { winner, candidates: scores, scores: scores.map(s => s.score) },
          metadata: { candidateCount: scores.length, winnerScore: winner.score }
        };
      }
    });

    // Coder: Generate implementation from winning approach
    this.handlers.set('coder', {
      execute: async (ctx) => {
        const winner = ctx.previousArtifacts?.battle?.winner;
        return {
          qualityScore: CSL_THRESHOLDS.MEDIUM,
          artifacts: {
            code: `// Auto-generated for: ${ctx.task.objective ?? 'unknown'}\n// Winner: ${winner?.id ?? 'default'}`,
            language: 'javascript',
            tests: []
          },
          metadata: { confidence: PSI, source: winner?.id ?? 'default' }
        };
      }
    });

    // Analyze: Deep verification
    this.handlers.set('analyze', {
      execute: async (ctx) => {
        const code = ctx.previousArtifacts?.coder?.code ?? '';
        const issues = [];
        
        // Basic static checks
        if (code.length < FIB[7]) issues.push({ type: 'warning', message: 'Code appears minimal' });
        if (!code.includes('export')) issues.push({ type: 'info', message: 'No exports detected' });

        const score = issues.length === 0
          ? CSL_THRESHOLDS.HIGH
          : CSL_THRESHOLDS.MEDIUM * (1 - issues.length * PSI * PSI * 0.1);

        return {
          qualityScore: score,
          artifacts: {
            analysis: { codeLength: code.length, issueCount: issues.length },
            metrics: { complexity: PSI, coverage: PSI },
            issues
          },
          metadata: { confidence: score }
        };
      }
    });

    // Risks: Vulnerability and edge-case identification
    this.handlers.set('risks', {
      execute: async (ctx) => {
        const analysis = ctx.previousArtifacts?.analyze?.analysis ?? {};
        const risks = [];

        if (analysis.issueCount > 0) {
          risks.push({
            id: 'open-issues',
            severity: 'medium',
            description: `${analysis.issueCount} unresolved issues from analysis`,
            mitigation: 'Address flagged issues before deployment'
          });
        }

        risks.push({
          id: 'auto-generated',
          severity: 'low',
          description: 'Code was auto-generated and may need human review',
          mitigation: 'Schedule code review with domain expert'
        });

        const score = risks.filter(r => r.severity === 'high').length === 0
          ? CSL_THRESHOLDS.MEDIUM
          : CSL_THRESHOLDS.LOW;

        return {
          qualityScore: score,
          artifacts: {
            risks,
            mitigations: risks.map(r => r.mitigation),
            severity: { high: 0, medium: risks.filter(r => r.severity === 'medium').length, low: risks.filter(r => r.severity === 'low').length }
          },
          metadata: { confidence: score, riskCount: risks.length }
        };
      }
    });

    // Patterns: Extract reusable learnings
    this.handlers.set('patterns', {
      execute: async (ctx) => {
        const allArtifacts = ctx.previousArtifacts;
        const patterns = [];

        // Extract workflow pattern
        patterns.push({
          type: 'workflow',
          name: `auto-success-${ctx.task.objective?.slice(0, 30) ?? 'unknown'}`,
          stages: Object.keys(allArtifacts),
          qualityScores: Object.fromEntries(
            Object.entries(allArtifacts).map(([k, v]) => [k, v?.qualityScore ?? null])
          ),
          timestamp: Date.now()
        });

        // Extract risk patterns for future avoidance
        const risks = allArtifacts.risks?.risks ?? [];
        for (const risk of risks) {
          patterns.push({
            type: 'risk-pattern',
            name: risk.id,
            severity: risk.severity,
            mitigation: risk.mitigation,
            context: ctx.task.objective?.slice(0, 100)
          });
        }

        return {
          qualityScore: CSL_THRESHOLDS.MEDIUM,
          artifacts: {
            patterns,
            learnings: patterns.map(p => p.name),
            embedding: ctx.task.embedding ?? null
          },
          metadata: { confidence: CSL_THRESHOLDS.MEDIUM, patternCount: patterns.length }
        };
      }
    });
  }
}

// ── Pipeline Builder (fluent API) ───────────────────────────────

export class AutoSuccessPipelineBuilder {
  constructor() {
    this.config = {};
    this.customHandlers = new Map();
  }

  withLLM(provider) { this.config.llmProvider = provider; return this; }
  withMemory(memory) { this.config.vectorMemory = memory; return this; }
  withQualityVector(vec) { this.config.qualityVector = vec; return this; }
  withTelemetry(tel) { this.config.telemetry = tel; return this; }
  withMaxRetries(n) { this.config.maxRetries = n; return this; }

  withHandler(stageId, handler) {
    this.customHandlers.set(stageId, handler);
    return this;
  }

  build() {
    const engine = new AutoSuccessEngine(this.config);
    for (const [id, handler] of this.customHandlers) {
      engine.registerHandler(id, handler);
    }
    return engine;
  }
}

// ── Exports ─────────────────────────────────────────────────────

export { STAGES, STAGE_LIST, QUALITY_GATES };

export default AutoSuccessEngine;
