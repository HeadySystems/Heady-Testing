"""
Heady Colab Notebook 02 — Model Forge Setup (Runtime 2)

Run this notebook in Google Colab Pro+ to initialize the Model Forge runtime.
This handles:
  - Multi-provider LLM routing (Anthropic, OpenAI, Google)
  - Provider health monitoring with circuit breakers
  - Phi-backoff retry logic
  - Health endpoint on port 8081

Prerequisites:
  - Colab Pro+ with GPU runtime
  - API keys in Colab secrets (ANTHROPIC_API_KEY, OPENAI_API_KEY, GOOGLE_AI_KEY)
  - ngrok authtoken in Colab secrets
"""

# !pip install -q aiohttp anthropic openai google-generativeai structlog pyngrok

import os
import asyncio
import json
import time
from datetime import datetime
from enum import Enum

# ── Configuration ──
PHI = 1.618033988749895
PSI = 1 / PHI
FIB = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597]

RUNTIME_CONFIG = {
    "id": "model-forge",
    "port": 8081,
    "max_retries": FIB[5],          # 5
    "circuit_break_threshold": FIB[5], # 5 failures to trip
    "circuit_reset_ms": FIB[10] * 1000, # 55 seconds
}

# ── Provider Registry ──
class ProviderState(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    CIRCUIT_OPEN = "circuit_open"

class Provider:
    def __init__(self, name, models, priority):
        self.name = name
        self.models = models
        self.priority = priority
        self.state = ProviderState.HEALTHY
        self.failures = 0
        self.last_failure = 0
        self.latency_ms = []
        self.max_latency_history = FIB[8]  # 21 samples
    
    def record_success(self, latency_ms):
        self.failures = 0
        self.state = ProviderState.HEALTHY
        self.latency_ms.append(latency_ms)
        if len(self.latency_ms) > self.max_latency_history:
            self.latency_ms = self.latency_ms[-self.max_latency_history:]
    
    def record_failure(self):
        self.failures += 1
        self.last_failure = time.time()
        if self.failures >= RUNTIME_CONFIG['circuit_break_threshold']:
            self.state = ProviderState.CIRCUIT_OPEN
        elif self.failures >= FIB[4]:  # 3
            self.state = ProviderState.DEGRADED
    
    @property
    def avg_latency(self):
        if not self.latency_ms:
            return float('inf')
        return sum(self.latency_ms) / len(self.latency_ms)
    
    @property
    def is_available(self):
        if self.state == ProviderState.CIRCUIT_OPEN:
            elapsed = time.time() - self.last_failure
            if elapsed > RUNTIME_CONFIG['circuit_reset_ms'] / 1000:
                self.state = ProviderState.DEGRADED  # Half-open
                return True
            return False
        return True

PROVIDERS = {
    "anthropic": Provider("anthropic", ["claude-sonnet-4-20250514", "claude-haiku-4-20250414"], priority=1),
    "openai": Provider("openai", ["gpt-4o", "gpt-4o-mini"], priority=2),
    "google": Provider("google", ["gemini-2.5-pro", "gemini-2.5-flash"], priority=3),
}

# ── Model Forge Router ──
class ModelForge:
    """Multi-provider LLM routing with circuit breakers and phi-backoff."""
    
    def __init__(self):
        self.providers = PROVIDERS
        self.request_count = 0
    
    def select_provider(self, task_type="general"):
        """Select best available provider using phi-weighted scoring."""
        available = [p for p in self.providers.values() if p.is_available]
        if not available:
            raise RuntimeError("All providers circuit-broken")
        
        # Score: priority_weight * (1/priority) + latency_weight * (1/latency)
        scored = []
        for p in available:
            priority_score = 1.0 / p.priority
            latency_score = 1.0 / max(p.avg_latency, 1)
            # Phi-weighted fusion: priority gets PSI weight, latency gets PSI² weight
            score = PSI * priority_score + (PSI * PSI) * latency_score
            scored.append((p, score))
        
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[0][0]
    
    async def generate(self, prompt, model=None, provider_name=None):
        """Generate completion with automatic routing and retry."""
        provider = (
            self.providers.get(provider_name)
            if provider_name
            else self.select_provider()
        )
        
        if not provider or not provider.is_available:
            provider = self.select_provider()
        
        self.request_count += 1
        start = time.time()
        
        try:
            # Dispatch to provider-specific client
            result = await self._call_provider(provider, prompt, model)
            latency = (time.time() - start) * 1000
            provider.record_success(latency)
            return {
                "text": result,
                "provider": provider.name,
                "latency_ms": round(latency, 2),
                "model": model or provider.models[0]
            }
        except Exception as e:
            provider.record_failure()
            # Retry with next provider
            fallback = self.select_provider()
            if fallback.name != provider.name:
                return await self.generate(prompt, model=None, provider_name=fallback.name)
            raise RuntimeError(f"All providers failed: {e}")
    
    async def _call_provider(self, provider, prompt, model):
        """Call the actual LLM provider API."""
        target_model = model or provider.models[0]
        
        if provider.name == "anthropic":
            import anthropic
            client = anthropic.AsyncAnthropic()
            response = await client.messages.create(
                model=target_model,
                max_tokens=FIB[16],  # 987
                messages=[{"role": "user", "content": prompt}]
            )
            return response.content[0].text
        
        elif provider.name == "openai":
            import openai
            client = openai.AsyncOpenAI()
            response = await client.chat.completions.create(
                model=target_model,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=FIB[16]
            )
            return response.choices[0].message.content
        
        elif provider.name == "google":
            import google.generativeai as genai
            model_instance = genai.GenerativeModel(target_model)
            response = await model_instance.generate_content_async(prompt)
            return response.text
        
        raise ValueError(f"Unknown provider: {provider.name}")
    
    def get_status(self):
        """Get health status of all providers."""
        return {
            name: {
                "state": p.state.value,
                "failures": p.failures,
                "avg_latency_ms": round(p.avg_latency, 2) if p.latency_ms else None,
                "models": p.models,
                "available": p.is_available
            }
            for name, p in self.providers.items()
        }

forge = ModelForge()
print("✓ ModelForge instance created")
print(f"  Providers: {list(PROVIDERS.keys())}")

# ── HTTP Server ──
async def start_server():
    from aiohttp import web
    
    async def health(request):
        return web.json_response({
            "status": "healthy",
            "runtime": "model-forge",
            "providers": forge.get_status(),
            "request_count": forge.request_count,
            "timestamp": datetime.utcnow().isoformat()
        })
    
    async def generate(request):
        data = await request.json()
        result = await forge.generate(
            prompt=data.get("prompt", ""),
            model=data.get("model"),
            provider_name=data.get("provider")
        )
        return web.json_response(result)
    
    async def status(request):
        return web.json_response(forge.get_status())
    
    app = web.Application()
    app.router.add_get("/health", health)
    app.router.add_post("/generate", generate)
    app.router.add_get("/status", status)
    
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", RUNTIME_CONFIG['port'])
    await site.start()
    print(f"✓ Model Forge server running on port {RUNTIME_CONFIG['port']}")
    
    while True:
        await asyncio.sleep(3600)

# Uncomment to run:
# await start_server()

print("\\n📋 Notebook ready. Run the server cell to start Model Forge.")
