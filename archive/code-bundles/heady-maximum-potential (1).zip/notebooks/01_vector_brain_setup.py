"""
Heady Colab Notebook 01 — Vector Brain Setup (Runtime 1)

Run this notebook in Google Colab Pro+ to initialize the Vector Brain runtime.
This handles:
  - pgvector connection and schema creation
  - 384D embedding pipeline with Nomic/Jina
  - Vector memory CRUD operations
  - Health endpoint on port 8080

Prerequisites:
  - Colab Pro+ with GPU runtime (T4 or better)
  - ngrok authtoken in Colab secrets
  - PostgreSQL connection string in Colab secrets
"""

# ── Cell 1: Install Dependencies ──
# !pip install -q aiohttp asyncpg pgvector sentence-transformers structlog pyngrok

import os
import asyncio
import json
import numpy as np
from datetime import datetime

# ── Cell 2: Configuration ──
PHI = 1.618033988749895
PSI = 1 / PHI
FIB = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597]

RUNTIME_CONFIG = {
    "id": "vector-brain",
    "port": 8080,
    "dimensions": 384,
    "model": "nomic-ai/nomic-embed-text-v1.5",
    "max_connections": FIB[8],     # 21
    "pool_size": FIB[7],           # 13
    "cache_size": FIB[16],         # 987
    "batch_size": FIB[6],          # 8
}

print(f"🧠 Vector Brain Configuration:")
print(f"   Dimensions: {RUNTIME_CONFIG['dimensions']}")
print(f"   Model: {RUNTIME_CONFIG['model']}")
print(f"   Cache size: {RUNTIME_CONFIG['cache_size']}")
print(f"   PHI = {PHI}")

# ── Cell 3: Embedding Pipeline ──
class VectorBrain:
    """384D embedding generation and vector memory operations."""
    
    def __init__(self, config):
        self.config = config
        self.dim = config['dimensions']
        self.cache = {}
        self.max_cache = config['cache_size']
        self._model = None
    
    async def init(self):
        """Initialize embedding model and database connection."""
        try:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer(self.config['model'])
            print(f"✓ Model loaded: {self.config['model']}")
        except Exception as e:
            print(f"⚠ Model load failed: {e}")
            print("  Using random embeddings for testing")
    
    def embed(self, text):
        """Generate 384D embedding for text."""
        # Check cache
        cache_key = hash(text)
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        if self._model:
            vec = self._model.encode(text, normalize_embeddings=True)
        else:
            # Deterministic random for testing
            np.random.seed(hash(text) % (2**32))
            vec = np.random.randn(self.dim).astype(np.float32)
            vec = vec / np.linalg.norm(vec)
        
        # Cache with LRU eviction
        if len(self.cache) >= self.max_cache:
            oldest = next(iter(self.cache))
            del self.cache[oldest]
        self.cache[cache_key] = vec
        
        return vec
    
    def cosine_similarity(self, a, b):
        """CSL AND gate — cosine similarity."""
        return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))
    
    def search(self, query_vec, vectors, top_k=None):
        """Find most similar vectors using CSL AND."""
        if top_k is None:
            top_k = FIB[5]  # 5
        
        scores = [(i, self.cosine_similarity(query_vec, v)) for i, v in enumerate(vectors)]
        scores.sort(key=lambda x: x[1], reverse=True)
        return scores[:top_k]

brain = VectorBrain(RUNTIME_CONFIG)

print("✓ VectorBrain instance created")
print(f"  To initialize model: await brain.init()")

# ── Cell 4: HTTP Server ──
async def start_server():
    """Start the Vector Brain HTTP server on port 8080."""
    from aiohttp import web
    
    await brain.init()
    
    async def health(request):
        return web.json_response({
            "status": "healthy",
            "runtime": "vector-brain",
            "dimensions": RUNTIME_CONFIG['dimensions'],
            "cache_size": len(brain.cache),
            "timestamp": datetime.utcnow().isoformat()
        })
    
    async def embed_handler(request):
        data = await request.json()
        text = data.get("text", "")
        vec = brain.embed(text)
        return web.json_response({
            "embedding": vec.tolist(),
            "dimensions": len(vec),
            "model": RUNTIME_CONFIG['model']
        })
    
    async def search_handler(request):
        data = await request.json()
        query = data.get("query", "")
        query_vec = brain.embed(query)
        # In production, search against pgvector
        return web.json_response({
            "query": query,
            "embedding": query_vec.tolist()[:5],  # Preview
            "message": "Connect pgvector for full search"
        })
    
    app = web.Application()
    app.router.add_get("/health", health)
    app.router.add_post("/embed", embed_handler)
    app.router.add_post("/search", search_handler)
    
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", RUNTIME_CONFIG['port'])
    await site.start()
    print(f"✓ Vector Brain server running on port {RUNTIME_CONFIG['port']}")
    
    # Keep alive
    while True:
        await asyncio.sleep(3600)

# Uncomment to run:
# await start_server()

# ── Cell 5: ngrok Tunnel ──
def setup_tunnel():
    """Expose the Vector Brain server via ngrok."""
    from pyngrok import ngrok
    
    # Set authtoken from Colab secrets
    # from google.colab import userdata
    # ngrok.set_auth_token(userdata.get('NGROK_TOKEN'))
    
    tunnel = ngrok.connect(RUNTIME_CONFIG['port'])
    print(f"✓ ngrok tunnel: {tunnel.public_url}")
    print(f"  Health: {tunnel.public_url}/health")
    print(f"  Embed:  {tunnel.public_url}/embed")
    return tunnel

# Uncomment to run:
# tunnel = setup_tunnel()

print("\\n📋 Notebook ready. Run cells 4 and 5 to start the server.")
