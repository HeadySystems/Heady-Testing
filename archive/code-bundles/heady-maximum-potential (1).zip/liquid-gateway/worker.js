/**
 * Heady Liquid Gateway — Cloudflare Worker Entry Point
 * 
 * The edge proxy that sits in front of all 11 Heady domains.
 * Handles domain routing, auth validation, rate limiting,
 * edge caching, CORS, security headers, and origin proxying.
 * 
 * Architecture:
 *   Client → Cloudflare Edge (this worker)
 *           → Domain Router (pick backend)
 *           → Rate Limiter (SRE adaptive throttle)
 *           → Edge Cache (KV + CF Cache API)
 *           → Origin (Cloud Run services in us-east1)
 *           → Response with security headers
 * 
 * All constants derive from PHI (1.618) and Fibonacci.
 */

import { resolveRoute, requiresAuth, getCacheTTL, DOMAINS } from './domain-router.js';
import { getFromCache, putInCache } from './edge-cache.js';
import {
  checkRateLimit, applyRateLimitHeaders, rateLimitResponse,
  determineTier, getIdentifier
} from './rate-limiter.js';

const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const FIB = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

// ── Security Headers ────────────────────────────────────────────

const SECURITY_HEADERS = Object.freeze({
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'SAMEORIGIN',
  'X-XSS-Protection': '1; mode=block',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(self)',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload'
});

// CORS — allow all Heady domains
const HEADY_ORIGINS = new Set(Object.keys(DOMAINS).flatMap(d => [
  `https://${d}`, `https://www.${d}`, `http://localhost:3000`, `http://localhost:8080`
]));

// ── Main Handler ────────────────────────────────────────────────

export default {
  async fetch(request, env, ctx) {
    const startTime = Date.now();

    try {
      // ── 1. CORS Preflight ──
      if (request.method === 'OPTIONS') {
        return handleCORS(request);
      }

      // ── 2. Domain Routing ──
      const route = resolveRoute(request);
      if (!route.config) {
        return jsonResponse(404, {
          error: 'unknown_domain',
          message: `Domain ${route.domain} is not registered in the Heady ecosystem`,
          domains: Object.keys(DOMAINS)
        });
      }

      // ── 3. Health Check (bypass auth/cache/ratelimit) ──
      if (route.path === '/health' || route.path === '/_health') {
        return jsonResponse(200, {
          status: 'healthy',
          domain: route.domain,
          service: route.config.service,
          edge: true,
          timestamp: new Date().toISOString()
        });
      }

      // ── 4. Auth Validation ──
      let authResult = { authenticated: false };
      if (requiresAuth(route.config)) {
        authResult = await validateAuth(request, env);
        if (!authResult.authenticated && route.config.authLevel !== 'public') {
          return jsonResponse(401, {
            error: 'unauthorized',
            message: 'Authentication required. Provide a valid Bearer token or API key.',
            domain: route.domain
          });
        }
      }

      // ── 5. Rate Limiting ──
      const tier = determineTier(request, authResult);
      const identifier = getIdentifier(request, authResult);
      const limitResult = await checkRateLimit(identifier, tier, env.RATE_LIMITS);

      if (!limitResult.allowed) {
        return rateLimitResponse(limitResult);
      }

      // ── 6. Edge Cache Check ──
      const cacheTTL = getCacheTTL(route.config, request);
      if (cacheTTL > 0) {
        const cached = await getFromCache(request, route.domain, env.EDGE_CACHE);
        if (cached) {
          const response = addHeaders(cached, startTime, route);
          return applyRateLimitHeaders(response, limitResult);
        }
      }

      // ── 7. Origin Fetch ──
      const originResponse = await fetchOrigin(request, route, authResult, env);

      // ── 8. Cache Store (async, non-blocking) ──
      if (cacheTTL > 0 && originResponse.status < 400) {
        ctx.waitUntil(
          putInCache(request, originResponse.clone(), route.domain, cacheTTL, env.EDGE_CACHE)
        );
      }

      // ── 9. Apply Headers & Return ──
      const response = addHeaders(originResponse, startTime, route);
      return applyRateLimitHeaders(response, limitResult);

    } catch (err) {
      console.error(`[Worker] Unhandled error: ${err.message}`, err.stack);
      return jsonResponse(502, {
        error: 'gateway_error',
        message: 'The Heady gateway encountered an unexpected error.',
        requestId: crypto.randomUUID()
      });
    }
  }
};

// ── Auth Validation ─────────────────────────────────────────────

async function validateAuth(request, env) {
  const authHeader = request.headers.get('Authorization') ?? '';

  // Bearer token
  if (authHeader.startsWith('Bearer ')) {
    const token = authHeader.slice(7);
    return validateBearerToken(token, env);
  }

  // API key in header
  const apiKey = request.headers.get('X-Heady-API-Key') ?? request.headers.get('X-API-Key');
  if (apiKey) {
    return validateAPIKey(apiKey, env);
  }

  return { authenticated: false };
}

async function validateBearerToken(token, env) {
  // JWT validation — verify signature with AUTH_SIGNING_KEY
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return { authenticated: false };

    // Decode payload (middle part)
    const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));

    // Check expiry
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
      return { authenticated: false, reason: 'token_expired' };
    }

    // In production, verify HMAC signature with env.AUTH_SIGNING_KEY
    // For now, trust the payload if it has required fields
    return {
      authenticated: true,
      userId: payload.sub,
      email: payload.email,
      roles: payload.roles ?? [],
      isInternal: payload.iss === 'heady-conductor',
      tokenType: 'bearer'
    };
  } catch (err) {
    return { authenticated: false, reason: 'invalid_token' };
  }
}

async function validateAPIKey(apiKey, env) {
  // Hash the key and check against stored hashes
  const encoder = new TextEncoder();
  const data = encoder.encode(apiKey);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

  // In production, check hash against KV or D1 store
  return {
    authenticated: true,
    apiKeyHash: hashHex.slice(0, 16),
    tokenType: 'api_key',
    isInternal: false
  };
}

// ── Origin Fetch ────────────────────────────────────────────────

async function fetchOrigin(request, route, authResult, env) {
  const originUrl = route.origin;

  // Forward request to origin with enriched headers
  const originHeaders = new Headers(request.headers);
  originHeaders.set('X-Heady-Domain', route.domain);
  originHeaders.set('X-Heady-Service', route.config.service);
  originHeaders.set('X-Forwarded-For', request.headers.get('CF-Connecting-IP') ?? 'unknown');
  originHeaders.set('X-Forwarded-Proto', 'https');

  if (authResult.authenticated) {
    originHeaders.set('X-Heady-User', authResult.userId ?? '');
    originHeaders.set('X-Heady-Roles', (authResult.roles ?? []).join(','));
  }

  // Stream-aware: preserve SSE and WebSocket connections
  const isStreaming = request.headers.get('Accept') === 'text/event-stream';
  const isWebSocket = request.headers.get('Upgrade') === 'websocket';

  const fetchOptions = {
    method: request.method,
    headers: originHeaders,
    redirect: 'follow'
  };

  // Include body for non-GET requests
  if (!['GET', 'HEAD'].includes(request.method)) {
    fetchOptions.body = request.body;
    fetchOptions.duplex = 'half';
  }

  try {
    const response = await fetch(originUrl, fetchOptions);
    return response;
  } catch (err) {
    console.error(`[Worker] Origin fetch failed: ${err.message}`, { origin: originUrl });
    return jsonResponse(503, {
      error: 'origin_unavailable',
      message: `Service ${route.config.service} is temporarily unavailable.`,
      domain: route.domain
    });
  }
}

// ── Response Helpers ────────────────────────────────────────────

function addHeaders(response, startTime, route) {
  const newResponse = new Response(response.body, response);

  // Security headers
  for (const [key, value] of Object.entries(SECURITY_HEADERS)) {
    newResponse.headers.set(key, value);
  }

  // CORS
  const origin = newResponse.headers.get('Origin');
  if (origin && HEADY_ORIGINS.has(origin)) {
    newResponse.headers.set('Access-Control-Allow-Origin', origin);
    newResponse.headers.set('Access-Control-Allow-Credentials', 'true');
  }

  // Diagnostic headers
  newResponse.headers.set('X-Heady-Edge', 'true');
  newResponse.headers.set('X-Heady-Service', route.config?.service ?? 'unknown');
  newResponse.headers.set('X-Heady-Latency', `${Date.now() - startTime}ms`);

  return newResponse;
}

function handleCORS(request) {
  const origin = request.headers.get('Origin') ?? '';
  const allowed = HEADY_ORIGINS.has(origin);

  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin': allowed ? origin : '',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, PATCH, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Heady-API-Key, X-API-Key, Accept',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Max-Age': String(FIB[12] * 60)  // 144 minutes
    }
  });
}

function jsonResponse(status, body) {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...SECURITY_HEADERS
    }
  });
}
