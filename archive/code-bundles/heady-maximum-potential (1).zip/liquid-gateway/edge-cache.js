/**
 * Heady Edge Cache — KV-backed response caching at the edge
 * 
 * Two-tier cache: Cloudflare Cache API (hot) → KV (warm).
 * All TTLs and sizes are phi/Fibonacci-derived.
 */

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;
const FIB  = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

// Cache config — Fibonacci-sized
const CACHE_CONFIG = Object.freeze({
  maxKVValueSize: FIB[17] * 1024,     // 1597 KB max KV value
  defaultTTL: FIB[8],                  // 21 seconds
  staleWhileRevalidate: FIB[10],       // 55 seconds
  maxAge: FIB[12],                     // 144 seconds
  varyHeaders: ['Accept', 'Accept-Encoding', 'Authorization']
});

/**
 * Generate a cache key from a request
 */
function cacheKey(request, domain) {
  const url = new URL(request.url);
  const accept = request.headers.get('Accept') ?? '*/*';
  const auth = request.headers.get('Authorization') ? 'auth' : 'anon';
  return `heady:${domain}:${auth}:${url.pathname}${url.search}:${accept}`;
}

/**
 * Try to serve from edge cache
 * @param {Request} request
 * @param {string} domain
 * @param {KVNamespace} kvCache — EDGE_CACHE KV binding
 * @returns {Response|null}
 */
export async function getFromCache(request, domain, kvCache) {
  // Only cache GET/HEAD
  if (!['GET', 'HEAD'].includes(request.method)) return null;

  const key = cacheKey(request, domain);

  // Tier 1: Cloudflare Cache API (in-memory, fastest)
  const cfCache = caches.default;
  const cfHit = await cfCache.match(request);
  if (cfHit) {
    const response = new Response(cfHit.body, cfHit);
    response.headers.set('X-Heady-Cache', 'HIT-CF');
    return response;
  }

  // Tier 2: KV (persistent, slower)
  if (kvCache) {
    try {
      const kvData = await kvCache.getWithMetadata(key, { type: 'arrayBuffer' });
      if (kvData?.value) {
        const meta = kvData.metadata ?? {};
        const age = Date.now() - (meta.storedAt ?? 0);
        const maxAgeMs = (meta.ttl ?? CACHE_CONFIG.defaultTTL) * 1000;

        if (age < maxAgeMs) {
          const response = new Response(kvData.value, {
            status: meta.status ?? 200,
            headers: new Headers(meta.headers ?? {})
          });
          response.headers.set('X-Heady-Cache', 'HIT-KV');
          response.headers.set('X-Heady-Age', String(Math.round(age / 1000)));
          return response;
        }
        // Stale — could serve stale-while-revalidate
        if (age < (maxAgeMs + CACHE_CONFIG.staleWhileRevalidate * 1000)) {
          const staleResponse = new Response(kvData.value, {
            status: meta.status ?? 200,
            headers: new Headers(meta.headers ?? {})
          });
          staleResponse.headers.set('X-Heady-Cache', 'STALE-KV');
          return staleResponse;
        }
      }
    } catch (err) {
      // KV read failure — fall through to origin
      console.error(`[EdgeCache] KV read error: ${err.message}`);
    }
  }

  return null;  // Cache miss
}

/**
 * Store a response in the edge cache
 * @param {Request} request
 * @param {Response} response
 * @param {string} domain
 * @param {number} ttl — seconds
 * @param {KVNamespace} kvCache
 */
export async function putInCache(request, response, domain, ttl, kvCache) {
  if (!['GET', 'HEAD'].includes(request.method)) return;
  if (response.status >= 400) return;  // Don't cache errors
  if (ttl <= 0) return;

  const key = cacheKey(request, domain);

  // Tier 1: Cloudflare Cache API
  const cfCache = caches.default;
  const cfResponse = new Response(response.clone().body, response);
  cfResponse.headers.set('Cache-Control', `s-maxage=${ttl}, stale-while-revalidate=${CACHE_CONFIG.staleWhileRevalidate}`);
  
  try {
    await cfCache.put(request, cfResponse);
  } catch (err) {
    console.error(`[EdgeCache] CF cache put error: ${err.message}`);
  }

  // Tier 2: KV (async, don't block response)
  if (kvCache) {
    try {
      const body = await response.clone().arrayBuffer();
      if (body.byteLength <= CACHE_CONFIG.maxKVValueSize) {
        const headers = {};
        for (const [k, v] of response.headers.entries()) {
          if (!k.startsWith('cf-') && k !== 'set-cookie') {
            headers[k] = v;
          }
        }

        await kvCache.put(key, body, {
          expirationTtl: ttl + CACHE_CONFIG.staleWhileRevalidate,
          metadata: {
            storedAt: Date.now(),
            ttl,
            status: response.status,
            headers,
            domain
          }
        });
      }
    } catch (err) {
      console.error(`[EdgeCache] KV put error: ${err.message}`);
    }
  }
}

/**
 * Invalidate cache for a specific path
 */
export async function invalidateCache(domain, path, kvCache) {
  const key = `heady:${domain}:*:${path}*`;
  // KV doesn't support wildcard delete — would need a list operation
  // For now, individual key invalidation
  if (kvCache) {
    const keys = [
      `heady:${domain}:anon:${path}:*/*`,
      `heady:${domain}:auth:${path}:*/*`,
      `heady:${domain}:anon:${path}:application/json`,
      `heady:${domain}:auth:${path}:application/json`
    ];
    await Promise.allSettled(keys.map(k => kvCache.delete(k)));
  }
}

export { CACHE_CONFIG, cacheKey };
export default { getFromCache, putInCache, invalidateCache, CACHE_CONFIG };
