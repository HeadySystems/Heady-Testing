/**
 * Heady Domain Router — Maps Heady domains to backend services
 * 
 * Each domain has a specific role in the ecosystem. The router
 * determines which Cloud Run service (origin) handles the request,
 * what auth level is required, and which cache policy applies.
 * 
 * All timing and sizing constants derive from PHI/Fibonacci.
 */

const PHI  = 1.618033988749895;
const PSI  = 1 / PHI;              // ≈ 0.618
const PSI2 = PSI * PSI;            // ≈ 0.382

// Fibonacci sequence for sizing
const FIB = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

// ── Domain Registry ─────────────────────────────────────────────

const DOMAINS = Object.freeze({
  'headyme.com': {
    service: 'command-center',
    origin: 'https://heady-conductor-us-east1.a.run.app',
    authLevel: 'authenticated',
    cacheTTL: FIB[8],              // 21s — dynamic dashboard
    description: 'Command center portal'
  },
  'headysystems.com': {
    service: 'core-engine',
    origin: 'https://heady-conductor-us-east1.a.run.app',
    authLevel: 'authenticated',
    cacheTTL: FIB[9],              // 34s
    description: 'Core architecture engine'
  },
  'headyconnection.org': {
    service: 'nonprofit',
    origin: 'https://heady-nonprofit-us-east1.a.run.app',
    authLevel: 'public',
    cacheTTL: FIB[11],             // 89s — mostly static
    description: 'Nonprofit & community'
  },
  'headybuddy.org': {
    service: 'companion',
    origin: 'https://heady-buddy-us-east1.a.run.app',
    authLevel: 'authenticated',
    cacheTTL: FIB[7],              // 13s — conversational
    description: 'AI companion experience'
  },
  'headymcp.com': {
    service: 'mcp-gateway',
    origin: 'https://heady-mcp-us-east1.a.run.app',
    authLevel: 'token',
    cacheTTL: 0,                   // No cache — tool execution
    description: 'MCP protocol layer'
  },
  'headyio.com': {
    service: 'developer-platform',
    origin: 'https://heady-devportal-us-east1.a.run.app',
    authLevel: 'public',
    cacheTTL: FIB[12],             // 144s — docs/reference
    description: 'Developer platform & docs'
  },
  'headybot.com': {
    service: 'automation',
    origin: 'https://heady-bots-us-east1.a.run.app',
    authLevel: 'token',
    cacheTTL: FIB[7],              // 13s
    description: 'Automation & agent bots'
  },
  'headyapi.com': {
    service: 'public-api',
    origin: 'https://heady-api-us-east1.a.run.app',
    authLevel: 'token',
    cacheTTL: FIB[8],              // 21s
    description: 'Public intelligence API'
  },
  'headyai.com': {
    service: 'intelligence-hub',
    origin: 'https://heady-ai-us-east1.a.run.app',
    authLevel: 'authenticated',
    cacheTTL: FIB[8],              // 21s
    description: 'Intelligence routing hub'
  },
  'headycloud.com': {
    service: 'cloud-dashboard',
    origin: 'https://heady-cloud-us-east1.a.run.app',
    authLevel: 'authenticated',
    cacheTTL: FIB[9],              // 34s
    description: 'Cloud infrastructure dashboard'
  },
  'headyos.com': {
    service: 'latent-os',
    origin: 'https://heady-os-us-east1.a.run.app',
    authLevel: 'authenticated',
    cacheTTL: FIB[7],              // 13s — live OS
    description: 'Latent operating system portal'
  }
});

// ── Router ──────────────────────────────────────────────────────

/**
 * Resolve a request to its domain config
 * @param {Request} request — incoming Cloudflare Worker request
 * @returns {{ domain, config, path }} — routing decision
 */
export function resolveRoute(request) {
  const url = new URL(request.url);
  const hostname = url.hostname.replace(/^www\./, '');
  
  const config = DOMAINS[hostname];
  if (!config) {
    return { domain: hostname, config: null, path: url.pathname };
  }

  return {
    domain: hostname,
    config,
    path: url.pathname,
    origin: `${config.origin}${url.pathname}${url.search}`
  };
}

/**
 * Check if the request requires authentication
 */
export function requiresAuth(config) {
  return config?.authLevel === 'authenticated' || config?.authLevel === 'token';
}

/**
 * Get cache TTL for the route (in seconds)
 */
export function getCacheTTL(config, request) {
  // Never cache mutations
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(request.method)) return 0;
  // Never cache WebSocket upgrades or SSE
  if (request.headers.get('Upgrade') === 'websocket') return 0;
  if (request.headers.get('Accept') === 'text/event-stream') return 0;
  
  return config?.cacheTTL ?? FIB[8];
}

/**
 * Get all registered domains
 */
export function getAllDomains() {
  return Object.entries(DOMAINS).map(([domain, config]) => ({
    domain,
    ...config
  }));
}

export { DOMAINS };
export default { resolveRoute, requiresAuth, getCacheTTL, getAllDomains, DOMAINS };
