/**
 * Heady Rate Limiter — Sliding window rate limiting at the edge
 * 
 * Uses KV-backed sliding window counters with phi-scaled limits.
 * Supports per-IP, per-token, and per-domain rate limiting.
 * 
 * Implements Google SRE adaptive throttling:
 *   P(reject) = max(0, (requests - K * accepts) / (requests + 1))
 *   where K = PHI (≈ 1.618)
 */

const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const FIB = [0,1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597];

// ── Rate Limit Tiers ────────────────────────────────────────────
// Fibonacci-scaled requests per window

const RATE_TIERS = Object.freeze({
  anonymous: {
    window: 60,                   // 1 minute
    limit: FIB[10],               // 55 requests/min
    burstLimit: FIB[11]           // 89 burst
  },
  authenticated: {
    window: 60,
    limit: FIB[12],               // 144 requests/min
    burstLimit: FIB[13]           // 233 burst
  },
  token: {
    window: 60,
    limit: FIB[13],               // 233 requests/min
    burstLimit: FIB[14]           // 377 burst
  },
  internal: {
    window: 60,
    limit: FIB[16],               // 987 requests/min
    burstLimit: FIB[17]           // 1597 burst
  }
});

// ── Sliding Window Counter ──────────────────────────────────────

/**
 * Check rate limit and return decision
 * @param {string} identifier — IP, token hash, or domain
 * @param {string} tier — anonymous|authenticated|token|internal
 * @param {KVNamespace} kvLimits — RATE_LIMITS KV binding
 * @returns {{ allowed, remaining, resetAt, retryAfter }}
 */
export async function checkRateLimit(identifier, tier, kvLimits) {
  const config = RATE_TIERS[tier] ?? RATE_TIERS.anonymous;
  const now = Math.floor(Date.now() / 1000);
  const windowStart = now - config.window;
  const key = `rl:${tier}:${identifier}`;

  let state = { requests: [], accepts: 0 };

  if (kvLimits) {
    try {
      const stored = await kvLimits.get(key, { type: 'json' });
      if (stored) state = stored;
    } catch (err) {
      // KV read failure — allow request (fail open)
      return { allowed: true, remaining: config.limit, resetAt: now + config.window, retryAfter: 0 };
    }
  }

  // Prune expired entries (sliding window)
  state.requests = (state.requests ?? []).filter(ts => ts > windowStart);

  const currentCount = state.requests.length;

  // Adaptive throttling (SRE algorithm with K = PHI)
  const rejectProbability = Math.max(0,
    (currentCount - PHI * (state.accepts ?? currentCount)) / (currentCount + 1)
  );

  // Probabilistic rejection for graceful degradation
  if (currentCount >= config.burstLimit) {
    return buildRejection(currentCount, config, now);
  }

  if (currentCount >= config.limit && Math.random() < rejectProbability) {
    return buildRejection(currentCount, config, now);
  }

  // Allow request
  state.requests.push(now);
  state.accepts = (state.accepts ?? 0) + 1;

  // Store updated state
  if (kvLimits) {
    try {
      await kvLimits.put(key, JSON.stringify(state), {
        expirationTtl: config.window * 2  // Keep for 2 windows
      });
    } catch (err) {
      console.error(`[RateLimiter] KV write error: ${err.message}`);
    }
  }

  return {
    allowed: true,
    remaining: Math.max(0, config.limit - currentCount - 1),
    resetAt: now + config.window,
    retryAfter: 0,
    tier
  };
}

/**
 * Build rejection response info
 */
function buildRejection(currentCount, config, now) {
  const oldest = config.window;
  const retryAfter = Math.ceil(oldest * PSI);  // Phi-scaled retry suggestion

  return {
    allowed: false,
    remaining: 0,
    resetAt: now + config.window,
    retryAfter,
    tier: config
  };
}

/**
 * Apply rate limit headers to a response
 * @param {Response} response
 * @param {Object} limitResult — from checkRateLimit
 * @returns {Response}
 */
export function applyRateLimitHeaders(response, limitResult) {
  const headers = new Headers(response.headers);
  headers.set('X-RateLimit-Limit', String(RATE_TIERS[limitResult.tier]?.limit ?? FIB[10]));
  headers.set('X-RateLimit-Remaining', String(limitResult.remaining));
  headers.set('X-RateLimit-Reset', String(limitResult.resetAt));

  if (!limitResult.allowed) {
    headers.set('Retry-After', String(limitResult.retryAfter));
  }

  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers
  });
}

/**
 * Build a 429 Too Many Requests response
 */
export function rateLimitResponse(limitResult) {
  return new Response(JSON.stringify({
    error: 'rate_limited',
    message: 'Too many requests. Please retry after the specified interval.',
    retryAfter: limitResult.retryAfter,
    resetAt: limitResult.resetAt
  }), {
    status: 429,
    headers: {
      'Content-Type': 'application/json',
      'Retry-After': String(limitResult.retryAfter),
      'X-RateLimit-Remaining': '0',
      'X-RateLimit-Reset': String(limitResult.resetAt)
    }
  });
}

/**
 * Determine rate limit tier from request
 */
export function determineTier(request, authResult) {
  if (authResult?.isInternal) return 'internal';
  if (authResult?.tokenType === 'api_key') return 'token';
  if (authResult?.authenticated) return 'authenticated';
  return 'anonymous';
}

/**
 * Get identifier for rate limiting
 */
export function getIdentifier(request, authResult) {
  if (authResult?.userId) return `user:${authResult.userId}`;
  if (authResult?.apiKeyHash) return `key:${authResult.apiKeyHash}`;
  return `ip:${request.headers.get('CF-Connecting-IP') ?? 'unknown'}`;
}

export { RATE_TIERS };
export default { checkRateLimit, applyRateLimitHeaders, rateLimitResponse, determineTier, getIdentifier };
