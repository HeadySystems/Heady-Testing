/**
 * Heady CSL Engine — Extended Continuous Semantic Logic Operations
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Re-exports all canonical CSL gates from phi-math.js, and adds:
 *   - MoE Router (cosine-based Mixture-of-Experts)
 *   - HDC/VSA operations (BIND, BUNDLE, PERMUTE)
 *   - Ternary logic (Kleene K3, Łukasiewicz, Gödel, Product, CSL-continuous)
 *   - Semantic drift detection
 *
 * @module csl-engine
 * @version 4.1.0
 */

// ── Re-export all canonical CSL gates and constants from phi-math ──

export {
  PHI, PSI, PHI2, PHI3, PHI_SQ, PHI_CUBE,
  FIB, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  PHI_TEMPERATURE,
  cosineSimilarity, normalize384, randomUnitVector, DEFAULT_DIM,
  cslAND, cslOR, cslNOT, cslIMPLY, cslXOR, cslCONSENSUS,
  cslGate, cslBlend, adaptiveTemperature,
  phiFusionWeights, phiThreshold, phiBackoff,
  SIZING, RELEVANCE_GATES
} from './phi-math.js';

import {
  PHI, PSI, FIB,
  CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD,
  PHI_TEMPERATURE,
  cosineSimilarity, normalize384, randomUnitVector, DEFAULT_DIM,
  cslAND, cslOR, cslNOT, cslIMPLY, cslGate,
  phiFusionWeights
} from './phi-math.js';


// ═══════════════════════════════════════════════════════════════
// MoE ROUTER — Cosine-Similarity Mixture-of-Experts
// ═══════════════════════════════════════════════════════════════

const MOE_DEFAULTS = Object.freeze({
  temperature: PHI_TEMPERATURE,              // ψ³ ≈ 0.236
  antiCollapseWeight: Math.pow(PSI, 8),      // ≈ 0.0131
  collapseThreshold: Math.pow(PSI, 9),       // ≈ 0.0081
});

export class MoERouter {
  constructor(numExperts, dim = DEFAULT_DIM, topK = 2, config = {}) {
    this.numExperts = numExperts;
    this.dim = dim;
    this.topK = topK;
    this.temperature = config.temperature ?? MOE_DEFAULTS.temperature;
    this.antiCollapseWeight = config.antiCollapseWeight ?? MOE_DEFAULTS.antiCollapseWeight;
    this.collapseThreshold = config.collapseThreshold ?? MOE_DEFAULTS.collapseThreshold;

    // Initialize expert gate vectors — phi-scaled random
    this.gates = Array.from({ length: numExperts }, () => {
      const v = new Array(dim);
      for (let i = 0; i < dim; i++) v[i] = (Math.random() - PSI) * PHI;
      const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
      return norm > 0 ? v.map(x => x / norm) : v;
    });
  }

  route(input) {
    const scores = this.gates.map(gate => cosineSimilarity(input, gate));

    // Softmax with phi-temperature
    const maxScore = Math.max(...scores);
    const exps = scores.map(s => Math.exp((s - maxScore) / this.temperature));
    const sumExp = exps.reduce((a, b) => a + b, 0);
    const probs = exps.map(e => e / sumExp);

    // Entropy-based collapse detection
    const entropy = -probs.reduce((s, p) => s + (p > 0 ? p * Math.log(p) : 0), 0);
    const maxEntropy = Math.log(this.numExperts);
    const isCollapsed = (entropy / maxEntropy) < this.collapseThreshold;

    // Top-K selection
    const indexed = probs.map((p, i) => ({ index: i, prob: p, score: scores[i] }));
    indexed.sort((a, b) => b.prob - a.prob);
    const selected = indexed.slice(0, this.topK).map(e => e.index);

    return {
      selected,
      scores,
      probs,
      entropy,
      isCollapsed,
      topExperts: indexed.slice(0, this.topK)
    };
  }
}

/**
 * cslGATE — Vector-level gate wrapper.
 * Computes cosine similarity between two vectors, then applies the canonical cslGate.
 * @param {number} value — value to gate
 * @param {number[]} a — first vector
 * @param {number[]} b — second vector (gate reference)
 * @param {number} tau — threshold
 * @param {number} temp — temperature
 */
export function cslGATE(value, a, b, tau, temp) {
  const cos = cosineSimilarity(a, b);
  return cslGate(cos >= -1 ? value : 0, cos, tau, temp);
}

// Legacy alias
export function moeRoute(input, gates, topK = 2) {
  const router = new MoERouter(gates.length, input.length, topK);
  router.gates = gates;
  return router.route(input);
}

// ═══════════════════════════════════════════════════════════════
// HDC / VSA OPERATIONS
// ═══════════════════════════════════════════════════════════════

/**
 * BIND — element-wise multiplication (real HRR-style)
 * Creates compositional representations: role-filler binding
 */
export function hdcBIND(a, b) {
  return a.map((v, i) => v * b[i]);
}

/**
 * BUNDLE — weighted sum + normalize (consensus/similarity aggregation)
 */
export function hdcBUNDLE(vectors, weights) {
  const w = weights ?? phiFusionWeights(vectors.length);
  const dim = vectors[0].length;
  const sum = new Array(dim).fill(0);
  for (let i = 0; i < vectors.length; i++) {
    for (let d = 0; d < dim; d++) sum[d] += w[i] * vectors[i][d];
  }
  return normalize384(sum);
}

/**
 * PERMUTE — cyclic shift for sequence encoding
 * @param {number[]} v — input vector
 * @param {number} n — positions to shift
 */
export function hdcPERMUTE(v, n = 1) {
  const len = v.length;
  const shift = ((n % len) + len) % len;
  const result = new Array(len);
  for (let i = 0; i < len; i++) {
    result[i] = v[(i - shift + len) % len];
  }
  return result;
}

// ═══════════════════════════════════════════════════════════════
// TERNARY LOGIC
// ═══════════════════════════════════════════════════════════════

export const TERNARY_MODES = Object.freeze({
  KLEENE:      'kleene',
  LUKASIEWICZ: 'lukasiewicz',
  GODEL:       'godel',
  PRODUCT:     'product',
  CSL:         'csl',
});

/**
 * Evaluate ternary truth value from cosine similarity
 * Maps continuous [-1, +1] cosine to {TRUE, UNKNOWN, FALSE}
 */
export function ternaryEval(a, b, mode = TERNARY_MODES.KLEENE) {
  const cos = cosineSimilarity(a, b);
  const tau = CSL_THRESHOLDS.MINIMUM;    // ≈ 0.500

  let value, label;

  switch (mode) {
    case TERNARY_MODES.KLEENE:
      if (cos >= tau) { value = 1; label = 'TRUE'; }
      else if (cos <= -tau) { value = -1; label = 'FALSE'; }
      else { value = 0; label = 'UNKNOWN'; }
      break;

    case TERNARY_MODES.LUKASIEWICZ:
      value = Math.min(1, Math.max(0, (cos + 1) / 2));
      label = value > tau ? 'TRUE' : value < (1 - tau) ? 'FALSE' : 'UNKNOWN';
      break;

    case TERNARY_MODES.GODEL:
      value = cos >= tau ? 1 : cos <= -tau ? 0 : cos;
      label = value >= tau ? 'TRUE' : value <= (1 - tau) ? 'FALSE' : 'UNKNOWN';
      break;

    case TERNARY_MODES.PRODUCT:
      value = Math.max(0, cos);
      label = value >= tau ? 'TRUE' : value <= 0.01 ? 'FALSE' : 'UNKNOWN';
      break;

    case TERNARY_MODES.CSL:
    default:
      value = cos;
      label = cos >= tau ? 'TRUE' : cos <= -tau ? 'FALSE' : 'UNKNOWN';
      break;
  }

  return { value, label, cosine: cos, mode };
}

// ═══════════════════════════════════════════════════════════════
// DRIFT DETECTION
// ═══════════════════════════════════════════════════════════════

export const DRIFT_STATE = Object.freeze({
  STABLE:   'stable',
  MINOR:    'minor',
  MODERATE: 'moderate',
  SEVERE:   'severe',
  CRITICAL: 'critical',
});

/**
 * Detect semantic drift between two embeddings
 * Uses CSL threshold hierarchy for severity classification
 */
export function detectDrift(current, baseline, thresholds = CSL_THRESHOLDS) {
  const similarity = cosineSimilarity(current, baseline);
  const drift = 1 - similarity;

  let state;
  if (similarity >= thresholds.HIGH)     state = DRIFT_STATE.STABLE;
  else if (similarity >= thresholds.MEDIUM) state = DRIFT_STATE.MINOR;
  else if (similarity >= thresholds.LOW)    state = DRIFT_STATE.MODERATE;
  else if (similarity >= thresholds.MINIMUM) state = DRIFT_STATE.SEVERE;
  else state = DRIFT_STATE.CRITICAL;

  return {
    state,
    similarity,
    drift,
    needsHeal: similarity < COHERENCE_DRIFT_THRESHOLD,
    threshold: COHERENCE_DRIFT_THRESHOLD,
  };
}
