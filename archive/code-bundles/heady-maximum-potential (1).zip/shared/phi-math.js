/**
 * Heady Phi-Math Foundation — Canonical Reference Implementation
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Every constant in the Heady ecosystem derives from the golden ratio (φ)
 * or Fibonacci numbers. Zero magic numbers. Zero arbitrary thresholds.
 *
 * ES Module port of the canonical phi-constants v4.1.0
 *
 * @module phi-constants
 * @version 4.1.0
 */

// ═══════════════════════════════════════════════════════════════
// CORE CONSTANTS
// ═══════════════════════════════════════════════════════════════

export const PHI = (1 + Math.sqrt(5)) / 2;
export const PSI = 1 / PHI;
export const PHI2 = PHI + 1;
export const PHI3 = 2 * PHI + 1;
export const FIB = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765];

// Legacy aliases for backward compat
export const PHI_SQ = PHI2;
export const PHI_CUBE = PHI3;

export function fib(n) {
  if (n < FIB.length) return FIB[n];
  let a = FIB[FIB.length - 2], b = FIB[FIB.length - 1];
  for (let i = FIB.length; i <= n; i++) { [a, b] = [b, a + b]; }
  return b;
}

export function fibArray(count) {
  return Array.from({ length: count }, (_, i) => fib(i));
}

// ═══════════════════════════════════════════════════════════════
// CSL THRESHOLDS
// ═══════════════════════════════════════════════════════════════

export function phiThreshold(level, spread = 0.5) {
  return 1 - Math.pow(PSI, level) * spread;
}

export const CSL_THRESHOLDS = Object.freeze({
  MINIMUM:  phiThreshold(0),
  LOW:      phiThreshold(1),
  MEDIUM:   phiThreshold(2),
  HIGH:     phiThreshold(3),
  CRITICAL: phiThreshold(4),
});

export const DEDUP_THRESHOLD = 1 - Math.pow(PSI, 6) * 0.5;
export const COHERENCE_DRIFT_THRESHOLD = CSL_THRESHOLDS.MEDIUM;

// ═══════════════════════════════════════════════════════════════
// PRESSURE & ALERTS
// ═══════════════════════════════════════════════════════════════

export const PRESSURE_LEVELS = Object.freeze({
  NOMINAL:  { min: 0, max: Math.pow(PSI, 2) },
  ELEVATED: { min: Math.pow(PSI, 2), max: PSI },
  HIGH:     { min: PSI, max: 1 - Math.pow(PSI, 3) },
  CRITICAL: { min: 1 - Math.pow(PSI, 4), max: 1.0 },
});

export const ALERT_THRESHOLDS = Object.freeze({
  warning:  PSI,
  caution:  1 - Math.pow(PSI, 2),
  critical: 1 - Math.pow(PSI, 3),
  exceeded: 1 - Math.pow(PSI, 4),
  hard_max: 1.0,
});

// ═══════════════════════════════════════════════════════════════
// FUSION & SCORING
// ═══════════════════════════════════════════════════════════════

export function phiFusionWeights(n) {
  const raw = Array.from({ length: n }, (_, i) => Math.pow(PSI, i));
  const sum = raw.reduce((a, b) => a + b, 0);
  return raw.map(w => w / sum);
}

export function phiPriorityScore(...factors) {
  const weights = phiFusionWeights(factors.length);
  return factors.reduce((sum, f, i) => sum + f * weights[i], 0);
}

export const EVICTION_WEIGHTS = Object.freeze({
  importance: phiFusionWeights(3)[0],
  recency:    phiFusionWeights(3)[1],
  relevance:  phiFusionWeights(3)[2],
});

export const RESOURCE_WEIGHTS = Object.freeze({
  hot:        0.387,
  warm:       0.239,
  cold:       0.148,
  reserve:    0.092,
  governance: 0.057,
});

export function phiResourceWeights(n) { return phiFusionWeights(n); }

// ═══════════════════════════════════════════════════════════════
// BACKOFF & TIMING
// ═══════════════════════════════════════════════════════════════

export function phiBackoff(attempt, baseMs = 1000, maxMs = 60000, jitter = true) {
  const delay = Math.min(baseMs * Math.pow(PHI, attempt), maxMs);
  if (!jitter) return Math.round(delay);
  const jitterRange = Math.pow(PSI, 2);
  const factor = 1 + (Math.random() * 2 - 1) * jitterRange;
  return Math.round(delay * factor);
}

export function fibRetryBackoff(count = 5, multiplier = 100) {
  return FIB.slice(4, 4 + count).map(n => n * multiplier);
}

export function phiAdaptiveInterval(baseMs, healthy, currentMs) {
  if (healthy) return Math.min(currentMs * PHI, baseMs * PHI3);
  return Math.max(currentMs * PSI, baseMs * PSI);
}

// Legacy alias
export const BACKOFF_CONFIG = Object.freeze({
  baseMs: 1000,
  maxMs: 60000,
  multiplier: PHI,
  jitterFactor: Math.pow(PSI, 2),
});

// ═══════════════════════════════════════════════════════════════
// TOKEN BUDGETS
// ═══════════════════════════════════════════════════════════════

export function phiTokenBudgets(base = 8192) {
  return {
    working:   base,
    session:   Math.round(base * PHI2),
    memory:    Math.round(base * PHI2 * PHI2),
    artifacts: Math.round(base * Math.pow(PHI, 6)),
  };
}

export const COMPRESSION_TRIGGER = 1 - Math.pow(PSI, 4);

// ═══════════════════════════════════════════════════════════════
// CSL GATES
// ═══════════════════════════════════════════════════════════════

export const PHI_TEMPERATURE = Math.pow(PSI, 3);

export function cslGate(value, cosScore, tau, temp = PHI_TEMPERATURE) {
  const sigmoid = 1 / (1 + Math.exp(-(cosScore - tau) / temp));
  return value * sigmoid;
}

export function cslBlend(weightHigh, weightLow, cosScore, tau) {
  const sigmoid = 1 / (1 + Math.exp(-(cosScore - tau) / PHI_TEMPERATURE));
  return weightLow + (weightHigh - weightLow) * sigmoid;
}

export function adaptiveTemperature(entropy, maxEntropy) {
  const ratio = entropy / maxEntropy;
  return PHI_TEMPERATURE * (1 + ratio * PHI);
}

export function cosineSimilarity(a, b) {
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom > 0 ? dot / denom : 0;
}

export function cslAND(a, b) { return cosineSimilarity(a, b); }

export function cslOR(a, b) {
  const sum = a.map((v, i) => v + b[i]);
  const norm = Math.sqrt(sum.reduce((s, v) => s + v * v, 0));
  return norm > 0 ? sum.map(v => v / norm) : sum;
}

export function cslNOT(a, b) {
  const dot = a.reduce((s, v, i) => s + v * b[i], 0);
  const normB2 = b.reduce((s, v) => s + v * v, 0);
  const proj = normB2 > 0 ? dot / normB2 : 0;
  return a.map((v, i) => v - proj * b[i]);
}

export function cslIMPLY(a, b) {
  const dot = a.reduce((s, v, i) => s + v * b[i], 0);
  const normB2 = b.reduce((s, v) => s + v * v, 0);
  const proj = normB2 > 0 ? dot / normB2 : 0;
  return b.map(v => proj * v);
}

export function cslCONSENSUS(vectors, weights) {
  const w = weights || phiFusionWeights(vectors.length);
  const dim = vectors[0].length;
  const sum = new Array(dim).fill(0);
  for (let i = 0; i < vectors.length; i++) {
    for (let d = 0; d < dim; d++) { sum[d] += w[i] * vectors[i][d]; }
  }
  const norm = Math.sqrt(sum.reduce((s, v) => s + v * v, 0));
  return norm > 0 ? sum.map(v => v / norm) : sum;
}

export function cslXOR(a, b) {
  const orVec = cslOR(a, b);
  const andScore = cslAND(a, b);
  const andProj = cslIMPLY(orVec, a).map((v, i) => v * andScore);
  return cslNOT(orVec, andProj);
}

// ═══════════════════════════════════════════════════════════════
// SIZING
// ═══════════════════════════════════════════════════════════════

export const SIZING = Object.freeze({
  FAILURE_THRESHOLD:  fib(5),
  BATCH_EVICTION:     fib(6),
  MAX_CONCURRENT:     fib(6),
  SMALL_LIMIT:        fib(7),
  HNSW_M:             fib(8),
  RERANK_TOP_K:       fib(8),
  SLIDING_WINDOW:     fib(9),
  MAX_ENTITIES:       fib(10),
  RETENTION_DAYS:     fib(11),
  EF_SEARCH:          fib(11),
  EF_CONSTRUCTION:    fib(12),
  QUEUE_DEPTH:        fib(13),
  PATTERN_STORE:      fib(14),
  CACHE_SIZE:         fib(16),
  HISTORY_BUFFER:     fib(17),
  LARGE_CACHE:        fib(20),
});

export const POOL_SIZES = Object.freeze({ min: fib(3), max: fib(7) });

export const RELEVANCE_GATES = Object.freeze({
  include: Math.pow(PSI, 2),
  boost:   PSI,
  inject:  PSI + 0.1,
});

// ═══════════════════════════════════════════════════════════════
// VECTOR UTILITIES (used by engines and csl-engine.js)
// ═══════════════════════════════════════════════════════════════

export const DEFAULT_DIM = 384;

export function normalize384(v) {
  const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
  return norm > 0 ? v.map(x => x / norm) : v;
}

export function randomUnitVector(dim = DEFAULT_DIM) {
  const v = new Array(dim);
  for (let i = 0; i < dim; i++) v[i] = Math.random() * 2 - 1;
  return normalize384(v);
}
