/**
 * Central auth gateway service.
 * OAuth 2.1 + OIDC flows, email/password auth, session management,
 * and service-to-service API key issuance.
 */

import crypto from 'node:crypto';
import bcrypt from 'bcrypt';
import config from './config.js';
import {
  issueTokenPair,
  refreshTokenPair,
  revokeToken,
  introspectToken,
  createApiKeyToken,
  verifyToken,
} from './token-manager.js';
import { isAllowedOrigin } from './domain-registry.js';
import { sendError } from './auth-middleware.js';

// ─── In-memory user store (replace with DB in production) ────────────────────

const users = new Map(); // email -> { id, email, passwordHash, roles, provider, createdAt }
const oauthStates = new Map(); // state -> { provider, redirectUri, expiresAt }

// ─── Helpers ─────────────────────────────────────────────────────────────────

function generateUserId() {
  return crypto.randomUUID();
}

function generateState() {
  return crypto.randomBytes(32).toString('hex');
}

function setAuthCookies(res, tokens) {
  const cookieOptions = {
    httpOnly: config.cookie.httpOnly,
    secure: config.cookie.secure,
    sameSite: config.cookie.sameSite,
    path: '/',
  };

  res.cookie('heady_refresh_token', tokens.refreshToken, {
    ...cookieOptions,
    maxAge: config.cookie.maxAge,
  });

  res.cookie('heady_access_token', tokens.accessToken, {
    ...cookieOptions,
    maxAge: config.jwt.accessTokenExpirySeconds * 1000,
  });
}

function clearAuthCookies(res) {
  const cookieOptions = {
    httpOnly: config.cookie.httpOnly,
    secure: config.cookie.secure,
    sameSite: config.cookie.sameSite,
    path: '/',
  };
  res.clearCookie('heady_refresh_token', cookieOptions);
  res.clearCookie('heady_access_token', cookieOptions);
}

function validateEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validatePassword(password) {
  return typeof password === 'string' && password.length >= 8 && password.length <= 128;
}

// ─── Route Handlers ──────────────────────────────────────────────────────────

/**
 * POST /auth/register
 * Email/password registration.
 */
async function handleRegister(req, res, logger) {
  const { email, password, name } = req.body;

  if (!email || !password) {
    return sendError(res, 400, 'MISSING_FIELDS', 'Email and password are required');
  }

  if (!validateEmail(email)) {
    return sendError(res, 400, 'INVALID_EMAIL', 'Invalid email format');
  }

  if (!validatePassword(password)) {
    return sendError(res, 400, 'INVALID_PASSWORD', 'Password must be between 8 and 128 characters');
  }

  if (users.has(email)) {
    return sendError(res, 409, 'USER_EXISTS', 'An account with this email already exists');
  }

  const passwordHash = await bcrypt.hash(password, config.bcryptRounds);
  const userId = generateUserId();

  const user = {
    id: userId,
    email,
    name: name || '',
    passwordHash,
    roles: ['user'],
    provider: 'email',
    createdAt: new Date().toISOString(),
  };

  users.set(email, user);

  const tokens = issueTokenPair({
    sub: userId,
    email,
    roles: user.roles,
  });

  setAuthCookies(res, tokens);

  logger.info({ userId, email }, 'user registered');

  return res.status(201).json({
    user: { id: userId, email, name: user.name, roles: user.roles },
    accessToken: tokens.accessToken,
    expiresIn: tokens.expiresIn,
    tokenType: tokens.tokenType,
  });
}

/**
 * POST /auth/login
 * Email/password login.
 */
async function handleLogin(req, res, logger) {
  const { email, password } = req.body;

  if (!email || !password) {
    return sendError(res, 400, 'MISSING_FIELDS', 'Email and password are required');
  }

  const user = users.get(email);

  if (!user || user.provider !== 'email') {
    return sendError(res, 401, 'INVALID_CREDENTIALS', 'Invalid email or password');
  }

  const isValid = await bcrypt.compare(password, user.passwordHash);

  if (!isValid) {
    logger.warn({ email }, 'failed login attempt');
    return sendError(res, 401, 'INVALID_CREDENTIALS', 'Invalid email or password');
  }

  const tokens = issueTokenPair({
    sub: user.id,
    email: user.email,
    roles: user.roles,
  });

  setAuthCookies(res, tokens);

  logger.info({ userId: user.id, email }, 'user logged in');

  return res.status(200).json({
    user: { id: user.id, email: user.email, name: user.name, roles: user.roles },
    accessToken: tokens.accessToken,
    expiresIn: tokens.expiresIn,
    tokenType: tokens.tokenType,
  });
}

/**
 * POST /auth/refresh
 * Refresh token rotation — issues new access + refresh token pair.
 */
function handleRefresh(req, res, logger) {
  const refreshTokenValue =
    req.cookies?.heady_refresh_token ||
    req.body?.refreshToken;

  if (!refreshTokenValue) {
    return sendError(res, 400, 'MISSING_REFRESH_TOKEN', 'Refresh token is required');
  }

  try {
    const tokens = refreshTokenPair(refreshTokenValue, logger);
    setAuthCookies(res, tokens);

    return res.status(200).json({
      accessToken: tokens.accessToken,
      expiresIn: tokens.expiresIn,
      tokenType: tokens.tokenType,
    });
  } catch (err) {
    if (err.code === 'TOKEN_REVOKED') {
      return sendError(res, 401, 'TOKEN_REVOKED', 'Refresh token has been revoked');
    }
    if (err.code === 'INVALID_TOKEN_TYPE') {
      return sendError(res, 400, 'INVALID_TOKEN_TYPE', 'Token is not a refresh token');
    }
    if (err.name === 'TokenExpiredError') {
      return sendError(res, 401, 'TOKEN_EXPIRED', 'Refresh token has expired');
    }
    return sendError(res, 401, 'REFRESH_FAILED', 'Token refresh failed');
  }
}

/**
 * POST /auth/logout
 * Revoke tokens and clear cookies.
 */
function handleLogout(req, res, logger) {
  // Revoke access token if present
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    try {
      const decoded = verifyToken(authHeader.slice(7));
      revokeToken(decoded.jti, decoded.exp);
    } catch {
      // Token may already be expired/invalid — that's fine
    }
  }

  // Revoke refresh token if present
  const refreshTokenValue = req.cookies?.heady_refresh_token;
  if (refreshTokenValue) {
    try {
      const decoded = verifyToken(refreshTokenValue);
      revokeToken(decoded.jti, decoded.exp);
    } catch {
      // Already expired/invalid
    }
  }

  clearAuthCookies(res);

  logger.info({ userId: req.user?.sub }, 'user logged out');

  return res.status(200).json({ message: 'Logged out successfully' });
}

/**
 * GET /auth/verify
 * Verify current access token and return user info.
 */
function handleVerify(req, res) {
  // req.user is set by jwtAuth middleware
  return res.status(200).json({
    valid: true,
    user: req.user,
  });
}

/**
 * POST /auth/introspect
 * RFC 7662 token introspection.
 */
function handleIntrospect(req, res) {
  const { token } = req.body;

  if (!token) {
    return sendError(res, 400, 'MISSING_TOKEN', 'Token is required');
  }

  const result = introspectToken(token);
  return res.status(200).json(result);
}

// ─── OAuth 2.1 Flows ────────────────────────────────────────────────────────

/**
 * GET /auth/oauth/google
 * Initiate Google OAuth 2.1 flow.
 */
function handleGoogleOAuthStart(req, res, logger) {
  if (!config.oauth.google.clientId) {
    return sendError(res, 503, 'PROVIDER_UNAVAILABLE', 'Google OAuth is not configured');
  }

  const state = generateState();
  const redirectUri = req.query.redirect_uri || config.oauth.google.callbackUrl;

  oauthStates.set(state, {
    provider: 'google',
    redirectUri,
    expiresAt: Date.now() + 10 * 60 * 1000, // 10 min
  });

  const params = new URLSearchParams({
    client_id: config.oauth.google.clientId,
    redirect_uri: `${config.jwt.issuer}${config.oauth.google.callbackUrl}`,
    response_type: 'code',
    scope: 'openid email profile',
    state,
    access_type: 'offline',
    prompt: 'consent',
  });

  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;

  logger.info({ provider: 'google' }, 'oauth flow initiated');

  return res.status(200).json({ authUrl, state });
}

/**
 * GET /auth/oauth/github
 * Initiate GitHub OAuth 2.1 flow.
 */
function handleGithubOAuthStart(req, res, logger) {
  if (!config.oauth.github.clientId) {
    return sendError(res, 503, 'PROVIDER_UNAVAILABLE', 'GitHub OAuth is not configured');
  }

  const state = generateState();
  const redirectUri = req.query.redirect_uri || config.oauth.github.callbackUrl;

  oauthStates.set(state, {
    provider: 'github',
    redirectUri,
    expiresAt: Date.now() + 10 * 60 * 1000,
  });

  const params = new URLSearchParams({
    client_id: config.oauth.github.clientId,
    redirect_uri: `${config.jwt.issuer}${config.oauth.github.callbackUrl}`,
    scope: 'read:user user:email',
    state,
  });

  const authUrl = `https://github.com/login/oauth/authorize?${params.toString()}`;

  logger.info({ provider: 'github' }, 'oauth flow initiated');

  return res.status(200).json({ authUrl, state });
}

/**
 * GET /auth/callback/google
 * Google OAuth callback — exchange code for tokens.
 */
async function handleGoogleCallback(req, res, logger) {
  const { code, state } = req.query;

  if (!code || !state) {
    return sendError(res, 400, 'MISSING_PARAMS', 'Authorization code and state are required');
  }

  const storedState = oauthStates.get(state);
  if (!storedState || storedState.provider !== 'google' || storedState.expiresAt < Date.now()) {
    oauthStates.delete(state);
    return sendError(res, 400, 'INVALID_STATE', 'Invalid or expired OAuth state');
  }
  oauthStates.delete(state);

  try {
    // Exchange code for tokens with Google
    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: config.oauth.google.clientId,
        client_secret: config.oauth.google.clientSecret,
        redirect_uri: `${config.jwt.issuer}${config.oauth.google.callbackUrl}`,
        grant_type: 'authorization_code',
      }),
    });

    if (!tokenResponse.ok) {
      logger.error({ status: tokenResponse.status }, 'google token exchange failed');
      return sendError(res, 502, 'PROVIDER_ERROR', 'Failed to exchange code with Google');
    }

    const tokenData = await tokenResponse.json();

    // Get user info from Google
    const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });

    if (!userInfoResponse.ok) {
      return sendError(res, 502, 'PROVIDER_ERROR', 'Failed to fetch user info from Google');
    }

    const userInfo = await userInfoResponse.json();
    const email = userInfo.email;

    // Find or create user
    let user = users.get(email);
    if (!user) {
      const userId = generateUserId();
      user = {
        id: userId,
        email,
        name: userInfo.name || '',
        passwordHash: null,
        roles: ['user'],
        provider: 'google',
        providerId: userInfo.sub,
        createdAt: new Date().toISOString(),
      };
      users.set(email, user);
      logger.info({ userId, email, provider: 'google' }, 'oauth user created');
    }

    const tokens = issueTokenPair({
      sub: user.id,
      email: user.email,
      roles: user.roles,
    });

    setAuthCookies(res, tokens);

    logger.info({ userId: user.id, email, provider: 'google' }, 'oauth login');

    return res.status(200).json({
      user: { id: user.id, email: user.email, name: user.name, roles: user.roles },
      accessToken: tokens.accessToken,
      expiresIn: tokens.expiresIn,
      tokenType: tokens.tokenType,
    });
  } catch (err) {
    logger.error({ err: err.message, provider: 'google' }, 'oauth callback error');
    return sendError(res, 500, 'OAUTH_ERROR', 'OAuth authentication failed');
  }
}

/**
 * GET /auth/callback/github
 * GitHub OAuth callback — exchange code for tokens.
 */
async function handleGithubCallback(req, res, logger) {
  const { code, state } = req.query;

  if (!code || !state) {
    return sendError(res, 400, 'MISSING_PARAMS', 'Authorization code and state are required');
  }

  const storedState = oauthStates.get(state);
  if (!storedState || storedState.provider !== 'github' || storedState.expiresAt < Date.now()) {
    oauthStates.delete(state);
    return sendError(res, 400, 'INVALID_STATE', 'Invalid or expired OAuth state');
  }
  oauthStates.delete(state);

  try {
    // Exchange code for access token with GitHub
    const tokenResponse = await fetch('https://github.com/login/oauth/access_token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({
        client_id: config.oauth.github.clientId,
        client_secret: config.oauth.github.clientSecret,
        code,
        redirect_uri: `${config.jwt.issuer}${config.oauth.github.callbackUrl}`,
      }),
    });

    if (!tokenResponse.ok) {
      logger.error({ status: tokenResponse.status }, 'github token exchange failed');
      return sendError(res, 502, 'PROVIDER_ERROR', 'Failed to exchange code with GitHub');
    }

    const tokenData = await tokenResponse.json();

    if (tokenData.error) {
      logger.error({ error: tokenData.error }, 'github token exchange error');
      return sendError(res, 502, 'PROVIDER_ERROR', tokenData.error_description || 'GitHub auth failed');
    }

    // Get user info from GitHub
    const userResponse = await fetch('https://api.github.com/user', {
      headers: {
        Authorization: `Bearer ${tokenData.access_token}`,
        Accept: 'application/vnd.github+json',
      },
    });

    if (!userResponse.ok) {
      return sendError(res, 502, 'PROVIDER_ERROR', 'Failed to fetch user info from GitHub');
    }

    const ghUser = await userResponse.json();

    // Get primary email if not public
    let email = ghUser.email;
    if (!email) {
      const emailsResponse = await fetch('https://api.github.com/user/emails', {
        headers: {
          Authorization: `Bearer ${tokenData.access_token}`,
          Accept: 'application/vnd.github+json',
        },
      });
      if (emailsResponse.ok) {
        const emails = await emailsResponse.json();
        const primary = emails.find((e) => e.primary && e.verified);
        email = primary?.email || emails[0]?.email;
      }
    }

    if (!email) {
      return sendError(res, 400, 'NO_EMAIL', 'Could not retrieve email from GitHub');
    }

    // Find or create user
    let user = users.get(email);
    if (!user) {
      const userId = generateUserId();
      user = {
        id: userId,
        email,
        name: ghUser.name || ghUser.login || '',
        passwordHash: null,
        roles: ['user'],
        provider: 'github',
        providerId: String(ghUser.id),
        createdAt: new Date().toISOString(),
      };
      users.set(email, user);
      logger.info({ userId, email, provider: 'github' }, 'oauth user created');
    }

    const tokens = issueTokenPair({
      sub: user.id,
      email: user.email,
      roles: user.roles,
    });

    setAuthCookies(res, tokens);

    logger.info({ userId: user.id, email, provider: 'github' }, 'oauth login');

    return res.status(200).json({
      user: { id: user.id, email: user.email, name: user.name, roles: user.roles },
      accessToken: tokens.accessToken,
      expiresIn: tokens.expiresIn,
      tokenType: tokens.tokenType,
    });
  } catch (err) {
    logger.error({ err: err.message, provider: 'github' }, 'oauth callback error');
    return sendError(res, 500, 'OAUTH_ERROR', 'OAuth authentication failed');
  }
}

/**
 * POST /auth/api-key
 * Issue a service-to-service API key (requires admin role).
 */
function handleCreateApiKey(req, res, logger) {
  if (!req.user || !req.user.roles?.includes('admin')) {
    return sendError(res, 403, 'FORBIDDEN', 'Admin role is required to create API keys');
  }

  const { serviceName, permissions } = req.body;

  if (!serviceName) {
    return sendError(res, 400, 'MISSING_FIELDS', 'serviceName is required');
  }

  const apiKey = createApiKeyToken({
    sub: `service:${serviceName}`,
    name: serviceName,
    permissions: permissions || ['read'],
    issuedBy: req.user.sub,
  });

  logger.info({ serviceName, issuedBy: req.user.sub }, 'api key created');

  return res.status(201).json({
    apiKey: apiKey.token,
    jti: apiKey.jti,
    expiresInDays: config.jwt.apiKeyExpiryDays,
  });
}

export {
  handleRegister,
  handleLogin,
  handleRefresh,
  handleLogout,
  handleVerify,
  handleIntrospect,
  handleGoogleOAuthStart,
  handleGithubOAuthStart,
  handleGoogleCallback,
  handleGithubCallback,
  handleCreateApiKey,
};
