/**
 * Security response headers middleware.
 * Applies defense-in-depth headers to every response.
 */

import { allowedOriginsArray } from './domain-registry.js';

// Build CSP connect-src from allowed origins
const connectSrcDirective = allowedOriginsArray.map((o) => o).join(' ');

const CSP_DIRECTIVES = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: https:",
  "font-src 'self'",
  `connect-src 'self' ${connectSrcDirective}`,
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "object-src 'none'",
  "upgrade-insecure-requests",
].join('; ');

function securityHeaders() {
  return function securityHeadersMiddleware(req, res, next) {
    // Content Security Policy
    res.setHeader('Content-Security-Policy', CSP_DIRECTIVES);

    // Prevent MIME-type sniffing
    res.setHeader('X-Content-Type-Options', 'nosniff');

    // Prevent framing (clickjacking protection)
    res.setHeader('X-Frame-Options', 'DENY');

    // HTTP Strict Transport Security — 1 year, include subdomains, preload
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');

    // XSS protection (legacy browsers)
    res.setHeader('X-XSS-Protection', '1; mode=block');

    // Referrer policy — send origin only for cross-origin
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

    // Permissions policy — restrict sensitive APIs
    res.setHeader(
      'Permissions-Policy',
      'camera=(), microphone=(), geolocation=(), payment=()'
    );

    // Prevent caching of auth responses
    res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');

    next();
  };
}

export default securityHeaders;
