/**
 * Express middleware for the Heady auth system.
 * JWT verification, API key verification, CORS, rate limiting,
 * correlation IDs, and structured error responses.
 */

import crypto from 'node:crypto';
import config from './config.js';
import { verifyToken, introspectToken } from './token-manager.js';
import { isAllowedOrigin, verifyDomain } from './domain-registry.js';

// ─── Rate Limiter (Fibonacci-based: 5/min, 13/hour, 34/day) ─────────────────

class FibonacciRateLimiter {
  constructor() {
    // Per-IP buckets for each window
    this.minuteBuckets = new Map();
    this.hourBuckets = new Map();
    this.dayBuckets = new Map();

    // Periodic cleanup
    this.cleanupTimer = setInterval(() => this._cleanup(), 60 * 1000);
    this.cleanupTimer.unref();
  }

  _getKey(req) {
    return req.ip || req.socket?.remoteAddress || 'unknown';
  }

  _incrementBucket(bucketMap, key, windowMs) {
    const now = Date.now();
    let entry = bucketMap.get(key);
    if (!entry || now - entry.start >= windowMs) {
      entry = { start: now, count: 0 };
      bucketMap.set(key, entry);
    }
    entry.count += 1;
    return entry.count;
  }

  _cleanup() {
    const now = Date.now();
    for (const [key, entry] of this.minuteBuckets) {
      if (now - entry.start >= config.rateLimit.windowMs.minute) this.minuteBuckets.delete(key);
    }
    for (const [key, entry] of this.hourBuckets) {
      if (now - entry.start >= config.rateLimit.windowMs.hour) this.hourBuckets.delete(key);
    }
    for (const [key, entry] of this.dayBuckets) {
      if (now - entry.start >= config.rateLimit.windowMs.day) this.dayBuckets.delete(key);
    }
  }

  check(req) {
    const key = this._getKey(req);

    const minuteCount = this._incrementBucket(this.minuteBuckets, key, config.rateLimit.windowMs.minute);
    if (minuteCount > config.rateLimit.perMinute) {
      return { allowed: false, retryAfter: 60, limit: config.rateLimit.perMinute, window: 'minute' };
    }

    const hourCount = this._incrementBucket(this.hourBuckets, key, config.rateLimit.windowMs.hour);
    if (hourCount > config.rateLimit.perHour) {
      return { allowed: false, retryAfter: 3600, limit: config.rateLimit.perHour, window: 'hour' };
    }

    const dayCount = this._incrementBucket(this.dayBuckets, key, config.rateLimit.windowMs.day);
    if (dayCount > config.rateLimit.perDay) {
      return { allowed: false, retryAfter: 86400, limit: config.rateLimit.perDay, window: 'day' };
    }

    return { allowed: true };
  }

  shutdown() {
    if (this.cleanupTimer) {
      clearInterval(this.cleanupTimer);
      this.cleanupTimer = null;
    }
  }
}

const rateLimiter = new FibonacciRateLimiter();

// ─── Structured Error Response ───────────────────────────────────────────────

function sendError(res, statusCode, code, message) {
  return res.status(statusCode).json({
    error: {
      code,
      message,
      timestamp: new Date().toISOString(),
    },
  });
}

// ─── Middleware: Request Correlation ID ──────────────────────────────────────

function correlationId() {
  return function correlationIdMiddleware(req, res, next) {
    const id = req.headers['x-request-id'] || crypto.randomUUID();
    req.id = id;
    res.setHeader('X-Request-Id', id);
    next();
  };
}

// ─── Middleware: CORS Whitelist (explicit, NO wildcards) ─────────────────────

function corsWhitelist() {
  return function corsWhitelistMiddleware(req, res, next) {
    const origin = req.headers.origin;

    if (origin && isAllowedOrigin(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Request-Id, X-Heady-Api-Key');
      res.setHeader('Access-Control-Expose-Headers', 'X-Request-Id');
      res.setHeader('Access-Control-Max-Age', '600');
    }

    // Handle preflight
    if (req.method === 'OPTIONS') {
      if (origin && isAllowedOrigin(origin)) {
        return res.sendStatus(204);
      }
      return sendError(res, 403, 'CORS_FORBIDDEN', 'Origin not allowed');
    }

    next();
  };
}

// ─── Middleware: Domain Verification ─────────────────────────────────────────

function domainVerification() {
  return function domainVerificationMiddleware(req, res, next) {
    const origin = req.headers.origin;

    // Allow requests with no origin (server-to-server, curl, etc.)
    if (!origin) return next();

    if (!verifyDomain(origin)) {
      return sendError(res, 403, 'DOMAIN_FORBIDDEN', 'Request origin is not a registered Heady domain');
    }

    next();
  };
}

// ─── Middleware: JWT Verification ────────────────────────────────────────────

function jwtAuth() {
  return function jwtAuthMiddleware(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return sendError(res, 401, 'MISSING_TOKEN', 'Authorization header with Bearer token is required');
    }

    const token = authHeader.slice(7);

    try {
      const decoded = verifyToken(token);
      req.user = {
        sub: decoded.sub,
        email: decoded.email,
        roles: decoded.roles,
        jti: decoded.jti,
        type: decoded.type,
      };
      next();
    } catch (err) {
      if (err.code === 'TOKEN_REVOKED') {
        return sendError(res, 401, 'TOKEN_REVOKED', 'Token has been revoked');
      }
      if (err.name === 'TokenExpiredError') {
        return sendError(res, 401, 'TOKEN_EXPIRED', 'Token has expired');
      }
      if (err.name === 'JsonWebTokenError') {
        return sendError(res, 401, 'INVALID_TOKEN', 'Token is invalid');
      }
      return sendError(res, 401, 'AUTH_ERROR', 'Authentication failed');
    }
  };
}

// ─── Middleware: API Key Verification (service-to-service) ──────────────────

function apiKeyAuth() {
  return function apiKeyAuthMiddleware(req, res, next) {
    const apiKey = req.headers[config.apiKeyHeader];

    if (!apiKey) {
      return sendError(res, 401, 'MISSING_API_KEY', `${config.apiKeyHeader} header is required`);
    }

    try {
      const decoded = verifyToken(apiKey);

      if (decoded.type !== 'api_key') {
        return sendError(res, 401, 'INVALID_API_KEY', 'Provided key is not a valid API key');
      }

      req.service = {
        sub: decoded.sub,
        name: decoded.name,
        jti: decoded.jti,
        permissions: decoded.permissions,
      };
      next();
    } catch (err) {
      if (err.code === 'TOKEN_REVOKED') {
        return sendError(res, 401, 'API_KEY_REVOKED', 'API key has been revoked');
      }
      return sendError(res, 401, 'INVALID_API_KEY', 'API key verification failed');
    }
  };
}

// ─── Middleware: Either JWT or API Key ───────────────────────────────────────

function eitherAuth() {
  return function eitherAuthMiddleware(req, res, next) {
    const hasBearer = req.headers.authorization && req.headers.authorization.startsWith('Bearer ');
    const hasApiKey = !!req.headers[config.apiKeyHeader];

    if (hasBearer) {
      return jwtAuth()(req, res, next);
    }
    if (hasApiKey) {
      return apiKeyAuth()(req, res, next);
    }

    return sendError(res, 401, 'MISSING_CREDENTIALS', 'Bearer token or API key is required');
  };
}

// ─── Middleware: Rate Limiter ────────────────────────────────────────────────

function rateLimit() {
  return function rateLimitMiddleware(req, res, next) {
    const result = rateLimiter.check(req);

    if (!result.allowed) {
      res.setHeader('Retry-After', String(result.retryAfter));
      return sendError(
        res,
        429,
        'RATE_LIMITED',
        `Rate limit exceeded: ${result.limit} requests per ${result.window}`
      );
    }

    next();
  };
}

// ─── Shutdown ────────────────────────────────────────────────────────────────

function shutdownMiddleware() {
  rateLimiter.shutdown();
}

export {
  correlationId,
  corsWhitelist,
  domainVerification,
  jwtAuth,
  apiKeyAuth,
  eitherAuth,
  rateLimit,
  sendError,
  shutdownMiddleware,
};
