/**
 * Heady Unified Auth Service — Entry point.
 * Express server with all middleware, auth routes, health check, and graceful shutdown.
 */

import express from 'express';
import cookieParser from 'cookie-parser';
import pino from 'pino';
import pinoHttp from 'pino-http';

import config from './config.js';
import securityHeaders from './security-headers.js';
import {
  correlationId,
  corsWhitelist,
  domainVerification,
  jwtAuth,
  rateLimit,
  eitherAuth,
  shutdownMiddleware,
} from './auth-middleware.js';
import {
  handleRegister,
  handleLogin,
  handleRefresh,
  handleLogout,
  handleVerify,
  handleIntrospect,
  handleGoogleOAuthStart,
  handleGithubOAuthStart,
  handleGoogleCallback,
  handleGithubCallback,
  handleCreateApiKey,
} from './auth-gateway.js';
import { shutdownTokenManager } from './token-manager.js';

// ─── Logger ──────────────────────────────────────────────────────────────────

const logger = pino({
  level: config.logLevel,
  transport: config.nodeEnv === 'development'
    ? { target: 'pino/file', options: { destination: 1 } }
    : undefined,
  formatters: {
    level(label) {
      return { level: label };
    },
  },
  timestamp: pino.stdTimeFunctions.isoTime,
});

// ─── App ─────────────────────────────────────────────────────────────────────

const app = express();

// Trust proxy for correct IP behind load balancer
app.set('trust proxy', 1);

// Body parsing
app.use(express.json({ limit: '16kb' }));
app.use(express.urlencoded({ extended: false, limit: '16kb' }));
app.use(cookieParser(config.cookie.secret));

// Global middleware (order matters)
app.use(correlationId());
app.use(pinoHttp({ logger, autoLogging: { ignore: (req) => req.url === '/health' } }));
app.use(securityHeaders());
app.use(corsWhitelist());
app.use(domainVerification());

// ─── Health ──────────────────────────────────────────────────────────────────

app.get('/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    service: 'heady-auth',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// ─── Public Auth Routes (rate-limited) ───────────────────────────────────────

const authRouter = express.Router();
authRouter.use(rateLimit());

authRouter.post('/register', (req, res) => handleRegister(req, res, logger));
authRouter.post('/login', (req, res) => handleLogin(req, res, logger));
authRouter.post('/refresh', (req, res) => handleRefresh(req, res, logger));

// OAuth initiation
authRouter.get('/oauth/google', (req, res) => handleGoogleOAuthStart(req, res, logger));
authRouter.get('/oauth/github', (req, res) => handleGithubOAuthStart(req, res, logger));

// OAuth callbacks
authRouter.get('/callback/google', (req, res) => handleGoogleCallback(req, res, logger));
authRouter.get('/callback/github', (req, res) => handleGithubCallback(req, res, logger));

// ─── Protected Auth Routes ───────────────────────────────────────────────────

authRouter.post('/logout', jwtAuth(), (req, res) => handleLogout(req, res, logger));
authRouter.get('/verify', jwtAuth(), (req, res) => handleVerify(req, res));
authRouter.post('/introspect', eitherAuth(), (req, res) => handleIntrospect(req, res));
authRouter.post('/api-key', jwtAuth(), (req, res) => handleCreateApiKey(req, res, logger));

app.use('/auth', authRouter);

// ─── 404 handler ─────────────────────────────────────────────────────────────

app.use((req, res) => {
  res.status(404).json({
    error: {
      code: 'NOT_FOUND',
      message: `Route ${req.method} ${req.path} not found`,
      timestamp: new Date().toISOString(),
    },
  });
});

// ─── Global error handler ────────────────────────────────────────────────────

app.use((err, req, res, _next) => {
  logger.error({ err: err.message, stack: err.stack, url: req.url }, 'unhandled error');
  res.status(500).json({
    error: {
      code: 'INTERNAL_ERROR',
      message: config.nodeEnv === 'production' ? 'Internal server error' : err.message,
      timestamp: new Date().toISOString(),
    },
  });
});

// ─── Server Start ────────────────────────────────────────────────────────────

const server = app.listen(config.port, () => {
  logger.info({ port: config.port, env: config.nodeEnv }, 'heady auth service started');
});

// ─── Graceful Shutdown ───────────────────────────────────────────────────────

function gracefulShutdown(signal) {
  logger.info({ signal }, 'shutdown signal received');

  server.close((err) => {
    if (err) {
      logger.error({ err: err.message }, 'error during server close');
    }

    // Cleanup timers
    shutdownTokenManager();
    shutdownMiddleware();

    logger.info('heady auth service stopped');
    process.exit(err ? 1 : 0);
  });

  // Force shutdown after 10 seconds
  setTimeout(() => {
    logger.error('forced shutdown after timeout');
    process.exit(1);
  }, 10_000).unref();
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

export default app;
