/**
 * Token lifecycle manager.
 * Handles JWT creation (RS256), refresh, revocation, and introspection.
 * Uses in-memory blacklist with optional Redis backing.
 */

import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import config from './config.js';

// In-memory token blacklist (revoked JTIs)
// In production, back this with Redis for multi-instance support
const revokedTokens = new Map(); // jti -> expiry timestamp

// Periodic cleanup of expired entries from the blacklist
const CLEANUP_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes
let cleanupTimer = null;

function startCleanupTimer() {
  if (cleanupTimer) return;
  cleanupTimer = setInterval(() => {
    const now = Math.floor(Date.now() / 1000);
    for (const [jti, expiresAt] of revokedTokens) {
      if (expiresAt < now) {
        revokedTokens.delete(jti);
      }
    }
  }, CLEANUP_INTERVAL_MS);
  cleanupTimer.unref();
}

startCleanupTimer();

/**
 * Generate a unique token identifier.
 */
function generateJti() {
  return crypto.randomUUID();
}

/**
 * Create an access token (JWT signed with RS256).
 */
function createAccessToken(payload) {
  const jti = generateJti();
  const tokenPayload = {
    ...payload,
    jti,
    type: 'access',
  };

  const token = jwt.sign(tokenPayload, config.jwt.privateKey, {
    algorithm: config.jwt.algorithm,
    expiresIn: config.jwt.accessTokenExpirySeconds,
    issuer: config.jwt.issuer,
    audience: config.jwt.audience,
  });

  return { token, jti };
}

/**
 * Create a refresh token (JWT signed with RS256).
 */
function createRefreshToken(payload) {
  const jti = generateJti();
  const tokenPayload = {
    sub: payload.sub,
    jti,
    type: 'refresh',
  };

  const token = jwt.sign(tokenPayload, config.jwt.privateKey, {
    algorithm: config.jwt.algorithm,
    expiresIn: config.jwt.refreshTokenExpirySeconds,
    issuer: config.jwt.issuer,
    audience: config.jwt.audience,
  });

  return { token, jti };
}

/**
 * Create a service-to-service API key token.
 * Phi-scaled expiry: 89 days.
 */
function createApiKeyToken(servicePayload) {
  const jti = generateJti();
  const tokenPayload = {
    ...servicePayload,
    jti,
    type: 'api_key',
  };

  const token = jwt.sign(tokenPayload, config.jwt.privateKey, {
    algorithm: config.jwt.algorithm,
    expiresIn: `${config.jwt.apiKeyExpiryDays}d`,
    issuer: config.jwt.issuer,
    audience: config.jwt.audience,
  });

  return { token, jti };
}

/**
 * Issue a complete token pair (access + refresh).
 */
function issueTokenPair(userPayload) {
  const access = createAccessToken(userPayload);
  const refresh = createRefreshToken(userPayload);
  return {
    accessToken: access.token,
    refreshToken: refresh.token,
    accessJti: access.jti,
    refreshJti: refresh.jti,
    expiresIn: config.jwt.accessTokenExpirySeconds,
    tokenType: 'Bearer',
  };
}

/**
 * Verify and decode a token.
 * Checks signature, expiry, issuer, audience, and revocation status.
 */
function verifyToken(token) {
  const decoded = jwt.verify(token, config.jwt.publicKey, {
    algorithms: [config.jwt.algorithm],
    issuer: config.jwt.issuer,
    audience: config.jwt.audience,
  });

  if (decoded.jti && revokedTokens.has(decoded.jti)) {
    const err = new Error('Token has been revoked');
    err.code = 'TOKEN_REVOKED';
    throw err;
  }

  return decoded;
}

/**
 * Refresh an access token using a valid refresh token.
 * The old refresh token is revoked and a new pair is issued.
 */
function refreshTokenPair(refreshTokenString, logger) {
  const decoded = verifyToken(refreshTokenString);

  if (decoded.type !== 'refresh') {
    const err = new Error('Invalid token type for refresh');
    err.code = 'INVALID_TOKEN_TYPE';
    throw err;
  }

  // Revoke the old refresh token (rotation)
  revokeToken(decoded.jti, decoded.exp);

  if (logger) {
    logger.info({ sub: decoded.sub, oldJti: decoded.jti }, 'refresh token rotated');
  }

  // Issue new pair
  return issueTokenPair({ sub: decoded.sub, email: decoded.email, roles: decoded.roles });
}

/**
 * Revoke a token by adding its JTI to the blacklist.
 */
function revokeToken(jti, expiresAt) {
  if (!jti) return;
  // Store with expiry so we can clean up later
  const exp = expiresAt || Math.floor(Date.now() / 1000) + config.jwt.refreshTokenExpirySeconds;
  revokedTokens.set(jti, exp);
}

/**
 * Revoke all tokens for a user (bulk revocation).
 * In production, this would query Redis/DB for all JTIs belonging to the user.
 * With in-memory only, we can't do this perfectly — callers should track JTIs.
 */
function revokeAllForUser(jtis) {
  const exp = Math.floor(Date.now() / 1000) + config.jwt.refreshTokenExpirySeconds;
  for (const jti of jtis) {
    revokedTokens.set(jti, exp);
  }
}

/**
 * Token introspection — returns token metadata without throwing on invalid tokens.
 * Follows RFC 7662 structure.
 */
function introspectToken(token) {
  try {
    const decoded = jwt.verify(token, config.jwt.publicKey, {
      algorithms: [config.jwt.algorithm],
      issuer: config.jwt.issuer,
      audience: config.jwt.audience,
    });

    const isRevoked = decoded.jti ? revokedTokens.has(decoded.jti) : false;

    return {
      active: !isRevoked,
      sub: decoded.sub,
      iss: decoded.iss,
      aud: decoded.aud,
      exp: decoded.exp,
      iat: decoded.iat,
      jti: decoded.jti,
      type: decoded.type,
      token_type: 'Bearer',
    };
  } catch {
    return { active: false };
  }
}

/**
 * Decode a token without verification (for logging/debugging).
 */
function decodeToken(token) {
  return jwt.decode(token, { complete: true });
}

/**
 * Cleanup — stop the background timer (for graceful shutdown).
 */
function shutdown() {
  if (cleanupTimer) {
    clearInterval(cleanupTimer);
    cleanupTimer = null;
  }
}

export {
  createAccessToken,
  createRefreshToken,
  createApiKeyToken,
  issueTokenPair,
  verifyToken,
  refreshTokenPair,
  revokeToken,
  revokeAllForUser,
  introspectToken,
  decodeToken,
  shutdown as shutdownTokenManager,
};
