import { createRequire } from 'node:module';

// Phi-scaled constants (golden ratio ≈ 1.618)
const PHI = 1.618033988749895;

const REQUIRED_ENV = [
  'JWT_PRIVATE_KEY',
  'JWT_PUBLIC_KEY',
];

function validateEnv(env) {
  const missing = REQUIRED_ENV.filter((key) => !env[key]);
  if (missing.length > 0) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }
}

function buildConfig(env = process.env) {
  validateEnv(env);

  const config = {
    // Server
    port: parseInt(env.PORT || '3100', 10),
    nodeEnv: env.NODE_ENV || 'development',
    logLevel: env.LOG_LEVEL || 'info',

    // JWT / Token expiry (phi-scaled)
    jwt: {
      privateKey: env.JWT_PRIVATE_KEY,
      publicKey: env.JWT_PUBLIC_KEY,
      algorithm: 'RS256',
      issuer: env.JWT_ISSUER || 'https://auth.headyme.com',
      audience: env.JWT_AUDIENCE || 'heady-services',
      accessTokenExpirySeconds: 15 * 60,                          // 15 min
      refreshTokenExpirySeconds: 7 * 24 * 60 * 60,                // 7 days
      apiKeyExpiryDays: 89,                                        // ~55 * phi ≈ 89 (Fibonacci)
    },

    // OAuth providers
    oauth: {
      google: {
        clientId: env.GOOGLE_CLIENT_ID || '',
        clientSecret: env.GOOGLE_CLIENT_SECRET || '',
        callbackUrl: env.GOOGLE_CALLBACK_URL || '/auth/callback/google',
      },
      github: {
        clientId: env.GITHUB_CLIENT_ID || '',
        clientSecret: env.GITHUB_CLIENT_SECRET || '',
        callbackUrl: env.GITHUB_CALLBACK_URL || '/auth/callback/github',
      },
    },

    // Rate limiting — Fibonacci-based thresholds
    rateLimit: {
      perMinute: 5,
      perHour: 13,
      perDay: 34,
      windowMs: {
        minute: 60 * 1000,
        hour: 60 * 60 * 1000,
        day: 24 * 60 * 60 * 1000,
      },
    },

    // Cookies
    cookie: {
      secret: env.COOKIE_SECRET || env.JWT_PRIVATE_KEY,
      secure: (env.NODE_ENV || 'development') === 'production',
      httpOnly: true,
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days (matches refresh token)
    },

    // Redis (optional — falls back to in-memory)
    redis: {
      url: env.REDIS_URL || '',
    },

    // Bcrypt
    bcryptRounds: parseInt(env.BCRYPT_ROUNDS || '12', 10),

    // Service-to-service API key header
    apiKeyHeader: 'x-heady-api-key',

    // Phi constant for downstream use
    PHI,
  };

  return Object.freeze(config);
}

const config = buildConfig();

export default config;
export { buildConfig, PHI };
