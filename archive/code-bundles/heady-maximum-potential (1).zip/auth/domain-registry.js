/**
 * Domain registry — whitelist and routing for all Heady domains.
 * Every request is verified against this registry. NO wildcards in CORS origins.
 */

const HEADY_DOMAINS = [
  {
    name: 'headyme',
    domain: 'headyme.com',
    authRequired: true,
    description: 'Primary user-facing platform',
  },
  {
    name: 'headysystems',
    domain: 'headysystems.com',
    authRequired: true,
    description: 'Internal systems platform',
  },
  {
    name: 'headyconnection',
    domain: 'headyconnection.org',
    authRequired: true,
    description: 'Connection and networking service',
  },
  {
    name: 'headybuddy',
    domain: 'headybuddy.org',
    authRequired: false,
    description: 'Public community buddy service',
  },
  {
    name: 'headymcp',
    domain: 'headymcp.com',
    authRequired: true,
    description: 'MCP integration service',
  },
  {
    name: 'headyio',
    domain: 'headyio.com',
    authRequired: true,
    description: 'Developer I/O platform',
  },
  {
    name: 'headybot',
    domain: 'headybot.com',
    authRequired: true,
    description: 'Bot management service',
  },
  {
    name: 'headyapi',
    domain: 'headyapi.com',
    authRequired: true,
    description: 'Public API gateway',
  },
  {
    name: 'headyai',
    domain: 'headyai.com',
    authRequired: true,
    description: 'AI services platform',
  },
  {
    name: 'headycloud',
    domain: 'headycloud.com',
    authRequired: true,
    description: 'Cloud infrastructure',
  },
  {
    name: 'headyos',
    domain: 'headyos.com',
    authRequired: true,
    description: 'OS-level services',
  },
];

// Build explicit origin lists — NO wildcard CORS
function buildAllowedOrigins(entry) {
  const { domain } = entry;
  return [
    `https://${domain}`,
    `https://www.${domain}`,
    `https://app.${domain}`,
    `https://api.${domain}`,
    `https://auth.${domain}`,
    `https://admin.${domain}`,
  ];
}

const domainMap = new Map();
const allAllowedOrigins = new Set();

for (const entry of HEADY_DOMAINS) {
  const origins = buildAllowedOrigins(entry);
  domainMap.set(entry.domain, {
    ...entry,
    origins,
  });
  for (const origin of origins) {
    allAllowedOrigins.add(origin);
  }
}

// Frozen origin array for CORS config
const allowedOriginsArray = Object.freeze([...allAllowedOrigins]);

/**
 * Check if a given origin is in the whitelist.
 */
function isAllowedOrigin(origin) {
  if (!origin) return false;
  return allAllowedOrigins.has(origin);
}

/**
 * Resolve domain entry from an origin URL.
 * Supports subdomain matching against registered root domains.
 */
function resolveDomainFromOrigin(origin) {
  if (!origin) return null;
  let hostname;
  try {
    hostname = new URL(origin).hostname;
  } catch {
    return null;
  }
  for (const [rootDomain, entry] of domainMap) {
    if (hostname === rootDomain || hostname.endsWith(`.${rootDomain}`)) {
      return entry;
    }
  }
  return null;
}

/**
 * Check if a domain requires authentication.
 */
function isDomainAuthRequired(origin) {
  const entry = resolveDomainFromOrigin(origin);
  if (!entry) return true; // unknown domains require auth by default
  return entry.authRequired;
}

/**
 * Verify that a request origin is from a registered Heady domain.
 */
function verifyDomain(origin) {
  return resolveDomainFromOrigin(origin) !== null;
}

/**
 * Get CORS config for a specific origin.
 */
function getCorsConfigForOrigin(origin) {
  const entry = resolveDomainFromOrigin(origin);
  if (!entry) return null;
  return {
    origin: entry.origins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-Id', 'X-Heady-Api-Key'],
    exposedHeaders: ['X-Request-Id'],
    maxAge: 600,
  };
}

export {
  HEADY_DOMAINS,
  allowedOriginsArray,
  isAllowedOrigin,
  resolveDomainFromOrigin,
  isDomainAuthRequired,
  verifyDomain,
  getCorsConfigForOrigin,
};
