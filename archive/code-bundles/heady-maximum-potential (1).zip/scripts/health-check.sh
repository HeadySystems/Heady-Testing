#!/usr/bin/env bash
# Heady Health Check — Verify all services are responding
# Usage: ./scripts/health-check.sh [--verbose]

set -euo pipefail

VERBOSE="${1:-}"
PASS=0
FAIL=0
WARN=0

echo "╔══════════════════════════════════════════════╗"
echo "║  Heady Health Check                          ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Check Endpoint ──
check() {
  local NAME="$1"
  local URL="$2"
  local EXPECTED="${3:-200}"
  
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "$URL" 2>/dev/null || echo "000")
  LATENCY=$(curl -s -o /dev/null -w "%{time_total}" --max-time 10 "$URL" 2>/dev/null || echo "0")
  
  if [ "$HTTP_CODE" = "$EXPECTED" ]; then
    echo "  ✓ $NAME — ${HTTP_CODE} (${LATENCY}s)"
    PASS=$((PASS + 1))
  elif [ "$HTTP_CODE" = "000" ]; then
    echo "  ✗ $NAME — UNREACHABLE"
    FAIL=$((FAIL + 1))
  else
    echo "  ⚠ $NAME — ${HTTP_CODE} (expected ${EXPECTED})"
    WARN=$((WARN + 1))
  fi
  
  if [ "$VERBOSE" = "--verbose" ]; then
    echo "    URL: $URL"
    echo "    Latency: ${LATENCY}s"
    echo ""
  fi
}

# ── Heady Domains (via Cloudflare edge) ──
echo "▸ Heady Domains:"
check "headyme.com"          "https://headyme.com/health"
check "headysystems.com"     "https://headysystems.com/health"
check "headyconnection.org"  "https://headyconnection.org/health"
check "headybuddy.org"       "https://headybuddy.org/health"
check "headymcp.com"         "https://headymcp.com/health"
check "headyio.com"          "https://headyio.com/health"
check "headybot.com"         "https://headybot.com/health"
check "headyapi.com"         "https://headyapi.com/health"
check "headyai.com"          "https://headyai.com/health"
check "headycloud.com"       "https://headycloud.com/health"
check "headyos.com"          "https://headyos.com/health"
echo ""

# ── Cloud Run Services ──
echo "▸ Cloud Run Services:"
check "Conductor (origin)"   "https://heady-conductor-us-east1.a.run.app/health"
echo ""

# ── Colab Runtimes (ngrok tunnels) ──
echo "▸ Colab Runtimes:"
echo "  (Colab runtimes require active ngrok tunnels — check manually)"
echo "  Runtime 1 — Vector Brain:  port 8080"
echo "  Runtime 2 — Model Forge:   port 8081"
echo "  Runtime 3 — Conductor:     port 8082"
echo ""

# ── Summary ──
TOTAL=$((PASS + FAIL + WARN))
echo "═══════════════════════════════════════"
echo "  HEALTH CHECK: $PASS/$TOTAL passed, $FAIL failed, $WARN warnings"
echo "═══════════════════════════════════════"

if [ $FAIL -gt 0 ]; then
  exit 1
fi
