#!/usr/bin/env bash
# Heady Build Script — Validates and packages the system
# Usage: ./scripts/build.sh [--check-only]

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CHECK_ONLY="${1:-}"
ERRORS=0

echo "╔══════════════════════════════════════════════╗"
echo "║  Heady Maximum Potential — Build System      ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── 1. JavaScript Syntax Check ──
echo "▸ Checking JavaScript files..."
JS_COUNT=0
JS_FAIL=0
for f in $(find "$ROOT" -name '*.js' -not -path '*/node_modules/*' -not -path '*/.git/*'); do
  JS_COUNT=$((JS_COUNT + 1))
  if ! node --check "$f" 2>/dev/null; then
    echo "  ✗ FAIL: $f"
    JS_FAIL=$((JS_FAIL + 1))
    ERRORS=$((ERRORS + 1))
  fi
done
echo "  ✓ $((JS_COUNT - JS_FAIL))/$JS_COUNT JavaScript files pass syntax check"
echo ""

# ── 2. Python Syntax Check ──
echo "▸ Checking Python files..."
PY_COUNT=0
PY_FAIL=0
for f in $(find "$ROOT" -name '*.py' -not -path '*/node_modules/*' -not -path '*/.git/*'); do
  PY_COUNT=$((PY_COUNT + 1))
  if ! python3 -c "import ast; ast.parse(open('$f').read())" 2>/dev/null; then
    echo "  ✗ FAIL: $f"
    PY_FAIL=$((PY_FAIL + 1))
    ERRORS=$((ERRORS + 1))
  fi
done
echo "  ✓ $((PY_COUNT - PY_FAIL))/$PY_COUNT Python files pass syntax check"
echo ""

# ── 3. JSON/TOML Validation ──
echo "▸ Checking JSON files..."
JSON_COUNT=0
for f in $(find "$ROOT" -name '*.json' -not -path '*/node_modules/*'); do
  JSON_COUNT=$((JSON_COUNT + 1))
  if ! python3 -c "import json; json.load(open('$f'))" 2>/dev/null; then
    echo "  ✗ FAIL: $f"
    ERRORS=$((ERRORS + 1))
  fi
done
echo "  ✓ $JSON_COUNT JSON files validated"
echo ""

# ── 4. File Count Summary ──
echo "▸ File inventory:"
echo "  JavaScript: $(find "$ROOT" -name '*.js' -not -path '*/node_modules/*' | wc -l | tr -d ' ')"
echo "  Python:     $(find "$ROOT" -name '*.py' | wc -l | tr -d ' ')"
echo "  Markdown:   $(find "$ROOT" -name '*.md' | wc -l | tr -d ' ')"
echo "  JSON:       $(find "$ROOT" -name '*.json' -not -path '*/node_modules/*' | wc -l | tr -d ' ')"
echo "  TOML:       $(find "$ROOT" -name '*.toml' | wc -l | tr -d ' ')"
echo "  YAML:       $(find "$ROOT" -name '*.yml' -o -name '*.yaml' | wc -l | tr -d ' ')"
echo "  Dockerfile: $(find "$ROOT" -name 'Dockerfile' | wc -l | tr -d ' ')"
echo "  Total:      $(find "$ROOT" -type f -not -path '*/node_modules/*' -not -path '*/.git/*' | wc -l | tr -d ' ')"
echo ""

# ── 5. Check for magic numbers (no 0.5, 0.7, 0.85 etc.) ──
echo "▸ Checking for magic numbers in JS/Python..."
MAGIC=$(grep -rn '\b0\.\(5\|7\|85\|95\)\b' "$ROOT" --include='*.js' --include='*.py' \
  --exclude-dir=node_modules --exclude-dir=.git 2>/dev/null | \
  grep -v 'phi-math\|csl-engine\|test\|\.test\.' | head -5 || true)
if [ -n "$MAGIC" ]; then
  echo "  ⚠ Potential magic numbers found (should use phi-derived constants):"
  echo "$MAGIC" | sed 's/^/    /'
else
  echo "  ✓ No magic numbers detected (all constants phi-derived)"
fi
echo ""

if [ "$CHECK_ONLY" = "--check-only" ]; then
  echo "Check-only mode — skipping package step"
  exit $ERRORS
fi

# ── 6. Package ZIP ──
echo "▸ Packaging..."
ZIP_NAME="heady-maximum-potential.zip"
cd "$ROOT/.."
rm -f "$ZIP_NAME"
zip -r "$ZIP_NAME" "heady-maximum-potential/" \
  -x "*/node_modules/*" \
  -x "*/.git/*" \
  -x "*/__pycache__/*" \
  -x "*.pyc" > /dev/null
SIZE=$(du -h "$ZIP_NAME" | cut -f1)
echo "  ✓ Created $ZIP_NAME ($SIZE)"
echo ""

# ── Result ──
if [ $ERRORS -eq 0 ]; then
  echo "═══════════════════════════════════════"
  echo "  BUILD PASSED — 0 errors"
  echo "═══════════════════════════════════════"
else
  echo "═══════════════════════════════════════"
  echo "  BUILD FAILED — $ERRORS error(s)"
  echo "═══════════════════════════════════════"
  exit 1
fi
