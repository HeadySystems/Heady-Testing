#!/usr/bin/env bash
# Heady Deploy Script — Deploys services to Cloud Run and Cloudflare
# Usage: ./scripts/deploy.sh [component]
# Components: all, liquid-nodes, auth, gateway, colab

set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
COMPONENT="${1:-all}"
GCP_PROJECT="gen-lang-client-0920560496"
GCP_REGION="us-east1"
CF_ACCOUNT="8b1fa38f282c691423c6399247d53323"

echo "╔══════════════════════════════════════════════╗"
echo "║  Heady Deploy — $COMPONENT                  ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Pre-flight Checks ──
check_prerequisites() {
  echo "▸ Pre-flight checks..."
  
  for cmd in docker gcloud wrangler; do
    if ! command -v "$cmd" &>/dev/null; then
      echo "  ✗ $cmd not found. Install it first."
      exit 1
    fi
  done
  
  echo "  ✓ All tools available"
  echo ""
}

# ── Deploy Liquid Nodes (Cloud Run) ──
deploy_liquid_nodes() {
  echo "▸ Deploying Liquid Nodes to Cloud Run..."
  cd "$ROOT/liquid-nodes"
  
  IMAGE="gcr.io/$GCP_PROJECT/heady-liquid-nodes:$(date +%Y%m%d%H%M%S)"
  
  docker build -t "$IMAGE" .
  docker push "$IMAGE"
  
  gcloud run deploy heady-conductor \
    --image="$IMAGE" \
    --project="$GCP_PROJECT" \
    --region="$GCP_REGION" \
    --platform=managed \
    --allow-unauthenticated=false \
    --memory=2Gi \
    --cpu=2 \
    --min-instances=1 \
    --max-instances=8 \
    --port=8080 \
    --set-env-vars="NODE_ENV=production,PHI=1.618033988749895" \
    --quiet
  
  echo "  ✓ Liquid Nodes deployed"
  echo ""
}

# ── Deploy Auth Service (Cloud Run) ──
deploy_auth() {
  echo "▸ Deploying Auth Service to Cloud Run..."
  cd "$ROOT/auth"
  
  IMAGE="gcr.io/$GCP_PROJECT/heady-auth:$(date +%Y%m%d%H%M%S)"
  
  docker build -t "$IMAGE" .
  docker push "$IMAGE"
  
  gcloud run deploy heady-auth \
    --image="$IMAGE" \
    --project="$GCP_PROJECT" \
    --region="$GCP_REGION" \
    --platform=managed \
    --allow-unauthenticated=false \
    --memory=512Mi \
    --cpu=1 \
    --min-instances=1 \
    --max-instances=5 \
    --port=8081 \
    --quiet
  
  echo "  ✓ Auth Service deployed"
  echo ""
}

# ── Deploy Gateway (Cloudflare Worker) ──
deploy_gateway() {
  echo "▸ Deploying Liquid Gateway to Cloudflare..."
  cd "$ROOT/liquid-gateway"
  
  wrangler deploy --env production
  
  echo "  ✓ Liquid Gateway deployed to Cloudflare edge"
  echo ""
}

# ── Deploy Colab Runtimes ──
deploy_colab() {
  echo "▸ Deploying Colab notebooks..."
  echo "  Colab runtimes are managed via Google Colab Pro+."
  echo "  Upload the following notebooks:"
  echo "    1. colab/runtime_1_vector_brain.py  → Runtime 1 (Vector Brain, port 8080)"
  echo "    2. colab/runtime_2_model_forge.py   → Runtime 2 (Model Forge, port 8081)"
  echo "    3. colab/runtime_3_orchestrator.py  → Runtime 3 (Conductor, port 8082)"
  echo "  Then run colab/colab_launcher.py to initialize all three."
  echo "  ✓ Colab deployment instructions generated"
  echo ""
}

# ── Execute ──
check_prerequisites

case "$COMPONENT" in
  all)
    deploy_liquid_nodes
    deploy_auth
    deploy_gateway
    deploy_colab
    ;;
  liquid-nodes)  deploy_liquid_nodes ;;
  auth)          deploy_auth ;;
  gateway)       deploy_gateway ;;
  colab)         deploy_colab ;;
  *)
    echo "Unknown component: $COMPONENT"
    echo "Usage: ./scripts/deploy.sh [all|liquid-nodes|auth|gateway|colab]"
    exit 1
    ;;
esac

echo "═══════════════════════════════════════"
echo "  DEPLOY COMPLETE — $COMPONENT"
echo "═══════════════════════════════════════"
