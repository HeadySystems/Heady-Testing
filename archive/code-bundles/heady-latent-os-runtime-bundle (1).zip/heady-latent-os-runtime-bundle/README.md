# HeadyOS latent runtime bundle

This refreshed bundle is aligned to the latest public HeadyMe latent runtime package state from [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642.git).

## Included core runtime

- repo-native `@heady-ai/phi-math`
- repo-native `@heady-ai/csl-router`
- repo-native `@heady-ai/spatial-events`
- repo-native `@heady-ai/agent-identity`
- repo-native `@heady-ai/memory-stream`
- repo-native `@heady-ai/observability-kernel`
- repo-native `@heady-ai/latent-boundary`
- repo-native `@heady-ai/kernel`
- repo-native latent boundary OpenAPI and Cloud Run service config

## Included supporting material

- workspace research inputs and earlier analysis memos
- curated beneficial enterprise SDK, pilot, architecture, infra, security, observability, and service assets
- rebuild blueprints and latent-OS strategy material for follow-on integration work

## Validation target

The bundle is structured as a standalone TypeScript workspace for the eight latent runtime packages, while beneficial supporting files are included as reference material and are not part of the build graph.
