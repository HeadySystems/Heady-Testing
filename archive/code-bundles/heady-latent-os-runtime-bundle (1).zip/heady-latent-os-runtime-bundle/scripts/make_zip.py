from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
zip_path = root.with_suffix('.zip')

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for path in root.rglob('*'):
        if any(part in {'node_modules', '.turbo', 'dist'} for part in path.parts):
            continue
        zf.write(path, path.relative_to(root.parent))

print(zip_path)
