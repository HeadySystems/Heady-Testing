import { rmSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const packages = [
  'phi-math',
  'csl-router',
  'spatial-events',
  'agent-identity',
  'memory-stream',
  'observability-kernel',
  'latent-boundary',
  'kernel',
];

for (const name of packages) {
  const target = join(process.cwd(), 'packages', name, 'dist');
  if (existsSync(target)) rmSync(target, { recursive: true, force: true });
}
