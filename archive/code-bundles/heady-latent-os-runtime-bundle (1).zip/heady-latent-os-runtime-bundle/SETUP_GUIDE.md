# Setup guide

## What changed

1. The eight latent runtime packages are now copied from the latest repo-native implementations instead of the earlier overlay-only generator output.
2. The latent boundary OpenAPI contract and Cloud Run config are now copied directly from the refreshed repo.
3. Additional beneficial supporting assets are bundled under `beneficial-files/` for downstream architecture, deployment, observability, security, and SDK work.

## Merge order

1. Merge the eight `packages/*` directories.
2. Merge `infra/openapi/heady-latent-boundary.openapi.yaml` and `infra/cloudrun/latent-kernel-service.yaml`.
3. Reconcile root TypeScript path aliases for `@heady-ai/*` with the target monorepo.
4. Use `beneficial-files/` as reference material for follow-on integration into services, enterprise SDKs, security posture, and deployment workflows.

## Build

```bash
npm install
npm run typecheck
npm run build
npm test
```

## Notes

- The build graph only covers the eight runtime packages.
- The supporting service and docs assets are intentionally preserved outside the build graph as curated source material.
- Source repo reference: [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642.git)
