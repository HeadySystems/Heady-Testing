# Heady Monorepo — Latent OS Runtime Analysis
> **Purpose:** Identify existing patterns in `Heady-pre-production-9f2f0642` most relevant to reframing Heady as a latent OS runtime with no frontend/backend split. Covers package structure, runtime kernel, orchestration, vector memory, auth/security, MCP, observability, and deployment.  
> **Generated:** 2026-03-07 | **Repo version:** heady-systems v3.2.2

---

## 1. Monorepo Topology

### Workspace Layout

```
pnpm-workspace.yaml:
  packages/*   — 10 shared TypeScript libraries (published artifacts)
  apps/*        — 7 web/portal apps (headyweb, command-center, heady-mcp-portal…)
  workers/*     — 4 Cloudflare Worker edge services (TypeScript, Wrangler-managed)

Root:
  services/     — 21 standalone Node microservices (not in pnpm workspace)
  src/          — 75+ JS/TS source directories (monolithic source tree)
  infra/        — Terraform, Cloud Run YAML, Docker Compose
```

**Key tension for latent runtime migration:** `services/` and `src/` are NOT in the pnpm workspace; they are a flat monolithic source tree managed by the root `package.json`. The 10 packages in `packages/` are proper workspace packages with `dist/` outputs, CJS exports, and Turborepo build dependencies. The path to a latent runtime is to progressively extract `src/` modules into `packages/` while keeping `services/` as deployment boundaries.

### Package Dependency Graph

| Package | Version | Depends On | Role in Runtime |
|---|---|---|---|
| `@heady-ai/core` | 3.2.2 | (zero deps) | Logger, errors, config, Zod validation — **foundation** |
| `@heady-ai/vector-memory` | 3.2.2 | `@heady-ai/core` | 3D spatial store, cosine search, octree index |
| `@heady-ai/mcp-server` | 3.2.2 | `core`, `vector-memory` | JSON-RPC handler, tool registry, MCP protocol |
| `@heady-ai/orchestrator` | 3.2.2 | `core`, `vector-memory` | Monte Carlo scheduler, liquid architecture, multi-pool |
| `@heady-ai/gateway` | 3.2.2 | `core` | API gateway, domain routing, cross-domain auth |
| `@heady-ai/sacred-geometry-sdk` | 3.2.2 | (standalone) | φ-constants, Fibonacci sequences, phi-math |
| `@headysystems/semantic-logic` | 1.0.0 | typescript, ts-morph | CSL gate engine, source transformer (MIT) |
| `@headysystems/redis` | 3.2.2 | (standalone) | φ-scaled connection pool |
| `@headysystems/types` | 3.2.2 | (standalone) | Shared TypeScript type definitions |
| `@heady-ai/sdk` | 3.2.2 | `core` | External consumer client SDK |

**Turborepo pipeline:** `build → test → lint` with strict `^build` dependency ordering. All packages output to `dist/`. `dev` is persistent + uncached.

**`headyCore` module registry** (in root `package.json`): defines 11 first-party drop-in replacements (`heady-fetch`, `heady-jwt`, `heady-crypt`, `heady-scheduler`, `heady-kv`, `heady-duck`, etc.) that replace third-party packages (openai, redis, express, etc.). This is the stub interface layer for a runtime kernel.

---

## 2. Runtime Kernel

### Entry Point: `heady-manager.js` (11-phase boot)

The main process has been refactored from a God-class into a phased boot sequence — this is the runtime kernel pattern:

| Phase | Module | Function |
|---|---|---|
| 0 | `src/config/env-schema.js` | Env validation (fail-fast in production) |
| 1 | `src/bootstrap/config-globals.js` | EventBus, MIDI bus, edge cache, logger, secrets |
| 2 | `src/bootstrap/middleware-stack.js` | Security, CORS, rate limiting, site renderer |
| 3 | `src/bootstrap/auth-engine.js` | HeadyAuth, fallback login, Cloudflare secrets |
| 4 | `src/bootstrap/vector-stack.js` | Vector memory, pipeline, federation, bees, spatial |
| 5 | `src/bootstrap/engine-wiring.js` | MC scheduler, patterns, auto-success, QA |
| 6 | `src/bootstrap/pipeline-wiring.js` | Pipeline binding + self-healing |
| 7 | `src/bootstrap/service-registry.js` | 40+ services mounted via `try/require` |
| 8 | `src/bootstrap/inline-routes.js` | Health, CSL, edge, telemetry routes |
| 9 | `src/bootstrap/voice-relay.js` | WebSocket voice relay |
| 10 | `src/bootstrap/server-boot.js` | HTTP/HTTPS + WS + listen |

**Runtime relevance:** This phased boot is already a primitive kernel boot order. For a latent OS runtime with no frontend/backend split, phases 0–6 constitute the kernel, phase 7 is the service/module loader, and phases 9–10 can be abstracted as transport adapters.

### `src/kernel/index.js` — AIOS Kernel Facade

A purpose-built kernel facade already exists with 8 submodules and an ordered boot sequence:

```
bootOrder: configLoader → accessManager → memoryManager →
           contextManager → hookSystem → toolManager →
           scheduler → lifecycle
```

Modules are lazy-loaded via a registry pattern (`modules[name]()`). The `getKernel()` singleton and `Kernel.get(name)` accessor provide a clean import interface. **This is the strongest existing latent-runtime primitive in the repo.**

### `src/runtime/` — Runtime Primitives

| File | Pattern | Runtime Role |
|---|---|---|
| `sandbox-executor.js` | Child process isolation, memory/CPU limits, stdout capture | Tool execution sandbox |
| `hc_resource_manager.js` | EventEmitter, φ-scaled polling, safe-mode events | Resource governor |
| `hc_liquid.js` | Liquid architecture routing | Dynamic service topology |
| `hc_cloudflare.js` | Edge runtime abstraction | Edge deployment adapter |
| `cross-device-sync.js` | State synchronization across nodes | Distributed runtime |
| `deploy-gates.js` | Deployment gate checks | CI/CD gate primitives |
| `remote-compute.js` | Remote compute coordination | Compute federation |

**`HCResourceManager`** is notable: it emits `resource_event` and `mitigation:*` events at φ³ × 1000ms intervals (~4.236s), and triggers `safe_mode_activated` and `concurrency_lowered` automatically. This is a runtime governor with event-driven backpressure.

---

## 3. Orchestration

### Core Orchestration Patterns (`src/orchestration/` — 100+ files)

| Component | Pattern | Description |
|---|---|---|
| `cognitive-runtime-governor.js` | Phase-gate state machine | Tracks ingress, execution, completion; enforces terminal states; evaluates 6 migration phases (A–F) |
| `swarm-consensus.js` | Distributed file locking | φ-scaled TTL (48.5s), shared/exclusive lock types, heartbeat (8.09s), stale check (16.18s) |
| `swarm-intelligence.js` | Swarm-level consensus | Cross-node coordination |
| `heady-orchestrator.js` | High-level task routing | Routes to bees, agents, or services |
| `heady-conductor.js` | Task assignment | Assigns tasks to agents with load-awareness |
| `skill-router.js` | CSL-based skill dispatch | Routes intent to skill via cosine similarity |
| `monte-carlo-optimizer.js` | Stochastic scheduling | Monte Carlo rollouts for optimal task ordering |
| `cognitive-operations-controller.js` | Phase control | Guards phase transitions |
| `self-awareness.js` | Metacognitive monitoring | Self-correcting feedback loop |
| `self-correction-loop.js` | Auto-remediation | Detects and heals drift |
| `semantic-backpressure.js` | Flow control | Semantic dedup-aware backpressure |
| `seventeen-swarm-orchestrator.js` | 17-node swarm | Specialized swarm topology |
| `socratic-execution-loop.js` | Interrogative execution | Question-driven agent iteration |
| `task-decomposition-engine.js` | Task splitting | Breaks complex tasks into sub-tasks |
| `swarm-ignition.js` | Cold-start sequencing | Swarm bootstrap protocol |
| `buddy-watchdog.js` | Health watchdog | Monitors buddy system liveness |

**`src/core/heady-event-bus.js`** is the cross-service backbone:
- Local EventEmitter (in-process, zero latency)
- Redis pub/sub bridge (cross-process, same region)  
- Cloud Pub/Sub bridge (cross-region, durable)
- Topic namespace: `heady:<service>:<event>` enforced by regex
- Replay buffer (last-N events per topic)
- Dead-letter queue for undelivered events
- Correlation ID propagation for distributed tracing

**This is the latent OS event bus** — already designed for runtime-level message passing without a frontend/backend distinction.

### `src/orchestration/v2/` 
A parallel v2 orchestration layer exists (directory confirmed) suggesting an iterative upgrade pattern — the latent runtime should target v2 conventions.

---

## 4. Vector Memory

### `src/memory/vector-memory.js` — 3D Spatial Store

Architecture:
- **384-dim embeddings** (`sentence-transformers/all-MiniLM-L6-v2`)
- **3D coordinate projection:** dims [0–127] → x, [128–255] → y, [256–383] → z; sign of (x,y,z) → 8 octant zones
- **5 Fibonacci shards** (2000 vectors/shard max)
- **Zone-first query:** same zone first → expand to adjacent if score < 0.35
- **φ-derived timings:** persist debounce = φ² × 1000ms (~2618ms), autonomy maintenance = φ⁵ × 1000ms (~11,090ms)

**Memory importance scoring:** `I(m) = 0.3·Freq(m) + 0.4·e^(-γΔt) + 0.3·Surp(m)` — frequency, recency decay, surprise.

### `src/memory/` — Full Memory Stack

| File | Role |
|---|---|
| `vector-memory.js` | Primary 3D spatial store |
| `shadow-memory-persistence.js` | Exhale/Inhale protocol (Patent HS-052) — 5-tier Fibonacci storage |
| `vector-federation.js` | Cross-node vector sync |
| `octree-spatial-index.js` | Octree partitioning for proximity queries |
| `redis-spatial-index.js` | Redis-backed spatial queries |
| `hybrid-search.js` | Combines vector + keyword search |
| `graph-rag.js` | Graph-augmented retrieval |
| `embedding-router.js` | Routes embedding requests to providers |
| `embedding-provider.js` | Multi-provider embedding abstraction |
| `vector-pipeline.js` | Streaming vector ingestion pipeline |
| `vector-projection-engine.js` | Coordinate-mapped state projections |
| `memory-receipts.js` | Tamper-evident memory receipt chain |
| `vector-memory-optimizer.js` | Background defrag / compaction |
| `vector-template-engine.js` | Template-based vector generation |

### `packages/vector-memory` 
The standalone package wraps the core 3D store with TypeScript types and CJS exports. **This is the cleanest extraction target for a latent runtime kernel package.**

### `src/vsa/` — Vector Symbolic Architecture

| File | Pattern |
|---|---|
| `hypervector.js` | FHRR-style 4096-dim hypervectors, binding/bundling/permutation |
| `codebook.js` | Semantic codebook with cosine retrieval |
| `vsa-csl-bridge.js` | VSA ↔ CSL gate bridge (resonance, superposition, orthogonal) |
| `engine.py` | Python VSA engine |
| `bridge.py` | Python ↔ JS bridge |
| `swarm.py` | Swarm-level VSA operations |

VSA replaces conditional logic trees with hyperdimensional vector operations — a key primitive for a stateless latent runtime.

---

## 5. Auth / Security

### Auth Layer (`src/auth/`)

`HeadyAuth` (`hc_auth.js`) supports 6 authentication methods:

| Method | Session Duration | Notes |
|---|---|---|
| Manual (username/password) | 30 days | Standard |
| Device token | 90 days | Silent, auto-generated |
| Cloudflare WARP detection | 365 days | Extended enterprise session |
| Google OAuth | 180 days | Redirect flow |
| SSH key challenge-response | 365 days | Signature verification |
| GPG signature challenge-response | 365 days | Signed payload |

Features: JWT-style tokens, persistent sessions (`data/auth-sessions.json`), 3D vector prereq scanning on authenticated requests, JSONL audit log, admin tier detection via `HEADY_API_KEY`, cross-device session sharing.

**Provider registry pattern** (`provider-registry.js`): pluggable auth backends with dynamic routing (`dynamic-auth-router.js`). Subscription tiers (admin/premium/core/guest) mapped to capability feature sets and rate limits.

### Security Stack (`src/security/`)

**Full MCP security pipeline** (existing, production-grade):

```
Client Request
  → RBAC (JWT roles → 8-bit capability bitmask)
  → Rate Limiter (4-layer: global → tool → user → session + semantic dedup)
  → Input Validator (8 threat categories: SQLi, SSRF, XSS, prompt injection…)
  → CSL Router (namespace prefix → cosine similarity → φ-round-robin)
  → Connection Pool (HTTP / SSE / WebSocket / stdio)
  → Zero-Trust Sandbox (capability ACL + φ-scaled resource limits)
  → Upstream MCP Server
  → Output Scanner (12 pattern types: AWS keys, JWTs, cards, SSNs…)
  → Audit Logger (SHA-256 chain, SOC 2, CEF/syslog)
  → Response (X-RateLimit-* headers)
```

Key security primitives:

| Component | Implementation |
|---|---|
| `zero-trust-sandbox.js` | 8-bit capability bitmask, φ-scaled timeouts per tool category (13s/21s/34s), resource limits (21MB RAM, 21s CPU, 987KB I/O) |
| `rate-limiter.js` | Token bucket + sliding window, cosine dedup (threshold ≈ 0.972), priority queue, X-RateLimit-* headers |
| `audit-logger.js` | SHA-256 tamper-evident chain, SOC 2 criteria mapping, CEF/syslog export |
| `pqc.js` | Post-quantum cryptography primitives |
| `mtls.js` | Mutual TLS handshake |
| `webauthn.js` | WebAuthn passkey support |
| `web3-ledger-anchor.js` | Blockchain attestation anchor |
| `secret-rotation.js` | φ-scheduled rotation (55-day JWT, 89-day API keys) |
| `output-scanner.js` | 12-pattern secret/PII scanning on all outputs |
| `rbac-manager.js` | Role-based access control with capability bitmask |
| `input-validator.js` | 8-category threat detection |

---

## 6. MCP (Model Context Protocol)

### MCP Implementation (`src/mcp/` — 36 files)

| Component | Pattern |
|---|---|
| `mcp-server.js` + `heady-mcp-server.js` | JSON-RPC 2.0 server, tool dispatch |
| `mcp-router.js` | CSL-based intelligent routing with cosine similarity, multi-tenant, LRU cache |
| `tool-registry.js` | Tool registration, listing, JSON Schema validation, execution |
| `mcp-sse-transport.js` | SSE (Server-Sent Events) transport |
| `mcp-transport.js` | Multi-transport abstraction (HTTP/SSE/WebSocket/stdio) |
| `connector-discovery.js` | Auto-discovery of MCP servers |
| `continuous-learner.js` | Online learning from MCP interactions |
| `template-auto-gen.js` | Auto-generates MCP tool templates |
| `heady-mcp-tools.js` | Platform-specific tool implementations |
| `colab-mcp-bridge.js` | Colab/remote compute MCP bridge |
| `project-history-ingestor.js` | Git history → vector memory ingestor |

**`mcp-router.js` CSL routing logic:**
- Registers each server with a composite semantic vector (superposition of tool + capability name vectors)
- CSL gates: `multi_resonance`, `route_gate`, `soft_gate`, `risk_gate`, `ternary_gate`, `orthogonal_gate`
- Falls back to deterministic hash-based embeddings when production vector service unavailable
- Server state classified as: `resonant` / `ephemeral` / `repel` via ternary gate
- Route cache with LRU eviction; stale timeout = 300s

**Cloudflare Worker edge deployment** (`workers/mcp-transport/src/index.ts`):
- Handles POST (JSON-RPC) and GET (SSE heartbeat) on the edge
- CORS headers, 30s SSE heartbeat keepalive
- Imports from `@heady/mcp-server` package

### `packages/mcp-server` 
Standalone exportable package (`@heady-ai/mcp-server`). Depends on `core` + `vector-memory`. This is the primary MCP kernel package.

### `src/gateway/`
3-file gateway layer: `mcp-gateway.js`, `connection-pool.js`, `meta-server-proxy.js` — handles multi-transport connection pooling and MCP server proxying.

### `@modelcontextprotocol/sdk` 
Root `package.json` depends on `@modelcontextprotocol/sdk ^1.0.1` — official MCP SDK is the upstream protocol implementation.

---

## 7. Observability

### Telemetry Stack (`src/telemetry/`)

| Component | Description |
|---|---|
| `otel.js` | OpenTelemetry `NodeTracerProvider`, OTLP HTTP exporter, W3C trace context propagator, `withSpan()` helper |
| `cognitive-telemetry.js` | Agent/cognitive event tracking (latency, decisions, model calls) |
| `neural-stream-telemetry.js` | Real-time neural stream events (Patent HS-053) |
| `proof-view-receipts.js` | Cryptographic proof-of-view receipts |
| `provider-usage-tracker.js` | Per-provider token/cost tracking |
| `telemetry-collector.js` | Aggregation pipeline |

### Observability Stack (`src/observability/`)

| Component | Description |
|---|---|
| `structured-logger.js` | JSON logging, secret redaction (4 regex patterns), child loggers, Express middleware, X-Request-Id |
| `enterprise-logger.js` | Enterprise-grade structured logging with audit trail |
| `health-probes.js` | `/health/live` + `/health/ready` probe implementations |
| `drift-detector.js` | Detects behavioral drift in agent/model outputs |
| `incident-manager.js` | Incident lifecycle management |
| `system-monitor.js` | System-level metrics aggregation |
| `hc_qa.js` | QA scoring pipeline |
| `hc_self_critique.js` | AI self-evaluation with scoring |

**Deployment probes (Cloud Run):**
- `startupProbe` → `/health/live` (5s period, 12 failures = 60s window)
- `livenessProbe` → `/health/live` (30s period)
- `readinessProbe` → `/health/ready` (15s period)

**OTel endpoint:** Configurable via `OTEL_EXPORTER_OTLP_ENDPOINT` (default: `http://localhost:4318/v1/traces`)

**`src/orchestration/orchestration-health-dashboard.js`** + `pipeline-telemetry.js`: orchestration-level health aggregation and pipeline metrics.

---

## 8. Deployment Conventions

### Container Strategy

| Dockerfile | Purpose |
|---|---|
| `Dockerfile` | HeadyWeb production (Cloud Run) |
| `Dockerfile.monorepo` | Full monorepo build |
| `Dockerfile.production` | Optimized production image |
| `Dockerfile.universal` | Multi-service universal image |

All services run from a single container (`heady-manager`) serving 9 domains via internal routing.

### Cloud Run (`infra/cloudrun/service.yaml`)

Key configuration for latent runtime:
- `containerConcurrency: 100` (horizontal within instance)
- `timeoutSeconds: 300` (5 min — supports long-running agent tasks)
- `autoscaling: min=1, max=10, target=80` (always-on, no cold starts)
- `cpu-throttling: false` (CPU always allocated — critical for background agent loops)
- `startup-cpu-boost: true` (2x CPU for boot)
- `execution-environment: gen2` (full Linux, gVisor)
- `sessionAffinity: true` (WebSocket voice relay)
- VPC connector for Neon/Redis/internal services
- Traffic splitting configured for canary (`heady-manager-stable` → 100%)

**Secrets:** All 16 secrets injected from GCP Secret Manager via `valueFrom.secretKeyRef`.

### CI/CD (`cloudbuild.yaml`)

7-step pipeline: test → security-audit → build-image → push → deploy-canary → promote-stable → health-verify.

**Feature flags** (env vars in Cloud Run):
- `HEADY_FLAG_OTEL_TRACES`
- `HEADY_FLAG_AUDIT_LOGGING`
- `HEADY_FLAG_PROMPT_GUARD`
- `HEADY_FLAG_CANARY_DEPLOY`
- `HEADY_FLAG_EVAL_PIPELINE`

### Cloudflare Workers (`workers/`)

4 edge workers with `wrangler.toml` configuration:

| Worker | Role |
|---|---|
| `api-gateway` | Domain routing (9 domains → upstream), KV rate limiting |
| `mcp-transport` | Edge MCP JSON-RPC + SSE |
| `auth-service` | Edge auth layer |
| `edge-composer` | Edge content composition |

**Domain routing** (api-gateway worker): `headyme.com`, `headyio.com`, `headymcp.com`, `headysystems.com`, `headyconnection.org`, `headybuddy.org`, `headybot.com`, `headyapi.com`, `headyai.com` → all proxy to Cloud Run upstream.

### PM2 (`ecosystem.config.cjs`)

Local process management for dev/staging. `pm2 list` available via `npm run status`.

### Terraform (`infra/terraform/`)

`main.tf` + `variables.tf` — infrastructure-as-code for GCP resources.

---

## 9. HDY Scripting Language

`src/scripting/` implements a native DSL:

- **`hdy-parser.js`** — Parses `.hdy` scripts
- **`hdy-compiler.js`** — Compiles to `.hdyc` binary (22-byte header, embedding section, CSL graph, formula AST, guardrails section)
- **`hdy-runtime.js`** — Executes compiled scripts
- **`meaning-types.js`** / **`semantic-constraints.js`** — CSL-native semantic types

The `.hdyc` binary format pre-computes 384-dim embeddings and CSL gate ASTs at compile time. **This is a latent OS bytecode format** — scripts are compiled to coordinate-embedded, vector-native execution graphs rather than imperative bytecodes.

---

## 10. Continuous Semantic Logic (CSL)

### Engine (`src/core/csl-engine/`)

| File | Role |
|---|---|
| `csl-engine.js` | Core continuous gate implementations |
| `hdc-operations.js` | Hyperdimensional computing operations |
| `moe-csl-router.js` | Mixture-of-Experts CSL routing |

### `packages/heady-semantic-logic` (`@headysystems/semantic-logic`)

The standalone CSL package (MIT licensed) includes:
- Continuous gates: AND, OR, NOT, IMPLY, EQUIV, NAND, NOR, XOR (all returning `[0.0, 1.0]`)
- **CLI transformer** (`heady-semantic` bin): scans and transforms TypeScript source, replacing boolean logic with CSL gates
- Depends on `ts-morph` for AST transformation — this is a **compile-time rewriter**

CSL thresholds: DORMANT (0–0.236) → LOW (0.236–0.382) → MODERATE (0.382–0.618) → HIGH (0.618–0.854) → CRITICAL (0.854–1.0)

---

## 11. Connectors

### `src/connectors/`

| File | Role |
|---|---|
| `connector-manager.js` | Lifecycle management for external connectors |
| `connector-vault.js` | Secure credential storage for connectors |
| `connector-routes.js` | API routes for connector CRUD |
| `oauth-scopes.js` | OAuth scope management |
| `dynamic-synthesizer.js` | Runtime connector synthesis |

Connectors are the latent runtime's "peripheral drivers" — external service integrations managed via a unified vault + manager pattern.

---

## 12. Patterns Most Relevant to Latent OS Runtime

### What Already Exists (Reuse Directly)

| Domain | Existing Asset | Runtime Role |
|---|---|---|
| Kernel | `src/kernel/index.js` (Kernel facade) | OS kernel with module registry + boot order |
| Event bus | `src/core/heady-event-bus.js` | Inter-process message bus (3 tiers) |
| Resource gov | `src/runtime/hc_resource_manager.js` | System resource governor with safe-mode |
| Vector state | `src/memory/vector-memory.js` + `packages/vector-memory` | Spatial agent state store |
| Shadow memory | `src/memory/shadow-memory-persistence.js` | Exhale/Inhale persistence across nodes |
| CSL routing | `src/mcp/mcp-router.js` | Semantic dispatch (no hard if/else) |
| Tool sandbox | `src/runtime/sandbox-executor.js` | Isolated tool execution |
| MCP protocol | `packages/mcp-server` + `src/mcp/` | Tool registration and dispatch |
| Auth | `src/auth/hc_auth.js` | 6-method auth, 3D vector prereq |
| Security pipeline | `src/security/zero-trust-sandbox.js` + `rate-limiter.js` | Zero-trust execution gate |
| Observability | `src/telemetry/otel.js` + structured-logger | OTel traces + JSON logs |
| Edge transport | `workers/mcp-transport/` | Cloudflare edge MCP |
| Scripting | `src/scripting/` (HDY compiler) | Native latent OS bytecode |
| CSL gates | `packages/heady-semantic-logic` | Continuous decision logic |
| VSA | `src/vsa/` | Hyperdimensional state machine |
| Deployment | `infra/cloudrun/service.yaml` + `cloudbuild.yaml` | Cloud Run + canary pipeline |

### What Should Be Built as Merge-Ready Packages

Based on this analysis, the following new packages should be extracted or created:

| Package Name | Source Location | Description |
|---|---|---|
| `@heady-ai/kernel` | `src/kernel/` | AIOS kernel facade — module registry, boot sequence, lifecycle |
| `@heady-ai/event-bus` | `src/core/heady-event-bus.js` | 3-tier event bus (in-process / Redis / Cloud Pub/Sub) |
| `@heady-ai/runtime` | `src/runtime/` | Resource manager, sandbox executor, liquid routing, cross-device sync |
| `@heady-ai/csl-router` | `src/mcp/mcp-router.js` + `src/core/csl-engine/` | CSL-native semantic router for any intent dispatch |
| `@heady-ai/security` | `src/security/` | Zero-trust sandbox, rate limiter, audit chain, PQC, output scanner |
| `@heady-ai/auth` | `src/auth/` | HeadyAuth with all 6 providers, session management, tier system |
| `@heady-ai/observability` | `src/telemetry/` + `src/observability/` | OTel + structured logger + cognitive telemetry |
| `@heady-ai/connectors` | `src/connectors/` | Connector vault, dynamic synthesizer, OAuth scopes |
| `@heady-ai/hdy-runtime` | `src/scripting/` | HDY language compiler/parser/runtime (latent bytecode) |
| `@heady-ai/vsa` | `src/vsa/` | Hypervector operations, codebook, VSA-CSL bridge |

### Gaps Identified

| Gap | Impact | Recommendation |
|---|---|---|
| No feature-flag package | Cannot gate experimental runtime paths | Extract `src/config/` flags into `@heady-ai/flags` |
| Turbo pipeline doesn't include `services/` | Services lack incremental build | Add `services/*/package.json` to `pnpm-workspace.yaml` |
| No unified `packages/kernel/` yet | Kernel only exists as src module | Promote `src/kernel/` to `packages/kernel/` |
| `services/` not workspace members | Cannot be co-versioned with packages | Migrate to workspace members |
| CSL gate package (semantic-logic) is MIT, others UNLICENSED | License inconsistency | Normalize to UNLICENSED for IP protection |
| `heady-manager.js` still has 10 phases in single process | No runtime/service isolation boundary | Extract phases 0–6 as kernel, 7+ as userland |
| No load testing / perf baselines | Cannot detect regressions | Address the noted gap in heady-system-context.md |

---

## Summary Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                    HEADY LATENT OS RUNTIME                          │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────┐  │
│  │   KERNEL     │  │  EVENT BUS   │  │   RESOURCE GOVERNOR      │  │
│  │ src/kernel/  │  │ heady-event- │  │ hc_resource_manager.js   │  │
│  │ (8 modules,  │  │   bus.js     │  │ (φ-scaled, safe-mode)    │  │
│  │  boot order) │  │ (3-tier)     │  └──────────────────────────┘  │
│  └──────────────┘  └──────────────┘                                │
│                                                                     │
│  ┌──────────────────────────┐  ┌─────────────────────────────────┐ │
│  │     VECTOR STATE         │  │         CSL ROUTER              │ │
│  │  @heady-ai/vector-memory │  │  mcp-router.js (cosine, gates)  │ │
│  │  3D / 5 shards / φ-timing│  │  @headysystems/semantic-logic   │ │
│  │  shadow-memory (HS-052)  │  │  VSA bridge (4096-dim HV)       │ │
│  └──────────────────────────┘  └─────────────────────────────────┘ │
│                                                                     │
│  ┌──────────────────────────┐  ┌─────────────────────────────────┐ │
│  │          MCP             │  │        AUTH / SECURITY          │ │
│  │  @heady-ai/mcp-server    │  │  HeadyAuth (6 methods)          │ │
│  │  tool-registry           │  │  zero-trust-sandbox (bitmask)   │ │
│  │  workers/mcp-transport   │  │  rate-limiter (4-layer + dedup) │ │
│  │  (SSE + JSON-RPC)        │  │  audit-logger (SHA-256 chain)   │ │
│  └──────────────────────────┘  └─────────────────────────────────┘ │
│                                                                     │
│  ┌──────────────────────────┐  ┌─────────────────────────────────┐ │
│  │     OBSERVABILITY        │  │        DEPLOYMENT               │ │
│  │  OTel (OTLP HTTP)        │  │  Cloud Run (gen2, always-on)    │ │
│  │  structured-logger       │  │  Cloudflare Workers (4)         │ │
│  │  cognitive-telemetry     │  │  cloudbuild.yaml (7-step)       │ │
│  │  drift-detector          │  │  canary rollout (traffic split) │ │
│  └──────────────────────────┘  └─────────────────────────────────┘ │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐  │
│  │                    HDY SCRIPTING RUNTIME                     │  │
│  │  .hdy → HDYParser → HDYCompiler → .hdyc (CSL graph + 384D   │  │
│  │  embeddings pre-baked) → HDYRuntime (no if/else, vector-    │  │
│  │  native execution)                                           │  │
│  └──────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```
