# MANIFEST

## Root

- `package.json` — standalone build scripts for the refreshed runtime bundle
- `pnpm-workspace.yaml` — workspace layout for runtime packages
- `turbo.json` — pipeline definition
- `tsconfig.base.json` — path aliases for `@heady-ai/*`
- `tsconfig.json` — project references for the runtime packages
- `README.md` — overview of the refreshed bundle
- `SETUP_GUIDE.md` — integration notes
- `REFRESH_NOTES.md` — latest-repo alignment notes

## Runtime packages

- `packages/phi-math`
- `packages/csl-router`
- `packages/spatial-events`
- `packages/agent-identity`
- `packages/memory-stream`
- `packages/observability-kernel`
- `packages/latent-boundary`
- `packages/kernel`

## Runtime infra

- `infra/openapi/heady-latent-boundary.openapi.yaml`
- `infra/cloudrun/latent-kernel-service.yaml`

## Research bundle

- `research/heady-system-context.md`
- `research/repo-analysis.md`
- `research/best-practices-memo.md`
- `research/research-brief.txt`

## Curated beneficial files

- `beneficial-files/enterprise/docs/adr`
- `beneficial-files/enterprise/sdk`
- `beneficial-files/enterprise/pilot`
- `beneficial-files/docs/strategic`
- `beneficial-files/docs/research`
- `beneficial-files/docs/security`
- `beneficial-files/docs/testing`
- `beneficial-files/docs/deep-scan`
- `beneficial-files/docs/pilot`
- `beneficial-files/docs/specs`
- `beneficial-files/docs/rebuild-blueprints/max-v2`
- `beneficial-files/docs/rebuild-blueprints/max-potential`
- `beneficial-files/docs/rebuild-blueprints/zero-dep/heady-zero-dep`
- `beneficial-files/infra/openapi`
- `beneficial-files/infra/cloudrun`
- `beneficial-files/infra/observability`
- `beneficial-files/infra/security`
- `beneficial-files/infra/hardening`
- `beneficial-files/infra/terraform`
- `beneficial-files/services/heady-brain`
- `beneficial-files/services/heady-conductor`
- `beneficial-files/services/heady-projection`
- `beneficial-files/services/heady-infer`
- `beneficial-files/services/heady-vector`
- `beneficial-files/services/heady-guard`
- `beneficial-files/services/heady-health`
