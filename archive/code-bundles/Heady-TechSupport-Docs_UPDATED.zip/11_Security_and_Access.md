# Security and Access Guide

**Last updated:** 2026-02-24

This guide is written for support engineers and operators who need to:
- handle keys/tokens safely,
- understand authentication and authorization patterns,
- respond to suspected compromises, and
- harden the platform over time.

---

## 1) Key security principles

1. **Least privilege** - grant only what is needed.
2. **Defense in depth** - CDN/WAF + app auth + filesystem allowlists.
3. **Secure by default** - no localhost defaults in production.
4. **Secrets never in repos** - treat committed secrets as compromised.
5. **Auditability** - log actions, especially admin actions.

---

## 2) Authentication model (typical)

### 2.1 API key authentication
Many admin endpoints are protected with an API key header (commonly `x-heady-api-key`).

**Support impacts**
- Wrong/missing key looks like “admin UI broken.”
- Key rotations require updating clients and hosting env vars.

### 2.2 Other common tokens
From environment templates, you may see placeholders for:
- `HF_TOKEN` (Hugging Face)
- `ADMIN_TOKEN`
- `RENDER_API_KEY`
- SMTP credentials for email notifications

Treat all of these as secrets.

---

## 3) Authorization model (typical)

### 3.1 Admin UI permissions
Admin capabilities are powerful:
- file read/write
- triggering builds
- triggering audits
- viewing logs and metrics

Therefore:
- enforce allowlisted paths (roots)
- enforce max file sizes
- require authentication for all admin endpoints
- record audit logs for all admin actions

### 3.2 Filesystem allowlists
Never allow arbitrary read/write of the server filesystem.
- Configure allowlisted roots with environment variables.
- Reject traversal (../) and symlink escapes.
- Use explicit path normalization across platforms.

---

## 4) Edge security (Cloudflare / WAF)

### 4.1 Cloudflare challenges (double-edged sword)
Cloudflare protects you, but can also block legitimate users if:
- bot protection rules are too aggressive
- rate limits are too low
- WAF rules are misconfigured

Support procedure:
- allowlist health endpoints
- reduce sensitivity on subdomains used by mobile/automation
- implement “bypass token” for internal monitors where appropriate

### 4.2 DDoS / WAF examples (AWS model)
Some infra guidance includes:
- WAF rate-based rules
- AWS Shield Advanced (for DDoS)
- flow logs and alarms

Even if not fully implemented, the support team should expect:
- WAF rate-limits and blocks
- the need for emergency exceptions during incidents

---

## 5) Domain hygiene and environment safety

A domain inventory file includes a strict rule:
- do not reference domains you do not own
- do not rely on `.onrender.com`, `cloud.headysystems.com`, or localhost-like hosts in production

Support action:
- when troubleshooting routing bugs, search configs for disallowed hostnames and remove.

---

## 6) Secret handling and rotation

### 6.1 Storage
- Use hosting platform secret storage or a dedicated secrets manager.
- For local dev, store secrets in `.env` (uncommitted) or encrypted vaults.

### 6.2 Rotation cadence
- API keys: rotate at least quarterly (or immediately after suspected leak)
- Cloudflare tokens: rotate at least quarterly
- SMTP app passwords: rotate when staff changes or compromise suspected

### 6.3 If a secret is found in a repo (incident response)
1. Rotate immediately.
2. Remove from repository (and ideally from git history).
3. Audit logs for misuse.
4. Update “how we got here” and prevent recurrence (pre-commit checks).

---

## 7) Hardening checklist (support-owned)

- [ ] All admin endpoints require auth.
- [ ] CORS allowlist only includes production domains.
- [ ] Rate limiting in place (per-IP and per-key).
- [ ] WAF exceptions for health endpoints and monitors.
- [ ] File operations restricted to allowlisted paths.
- [ ] Build/audit scripts run with least-privileged system user.
- [ ] Logging includes request ids and auth context (no secrets in logs).
- [ ] Backups encrypted at rest and in transit.
- [ ] DR runbooks tested.



## Addendum: repo security findings to action (rescan 2026-02-24)

### 1) Assume any committed secret is compromised
A public repo should be treated as “the internet already has it.” Rotate immediately:
- DB credentials (`DATABASE_URL`, Postgres user/pass)
- Render API keys
- Cloudflare API tokens / account IDs
- `HEADY_API_KEY` / `ADMIN_TOKEN`

### 2) Remove secrets from Git history (not just HEAD)
Use a proper history rewrite tool (e.g., `git filter-repo`) and force-push, then rotate again. Also invalidate any cached build artifacts that might have captured secrets.

### 3) Lock down high-risk tracked artifacts
If files like `server.pid`, deploy logs (`.heady_deploy_log.jsonl`), or audit logs are tracked, move them to runtime storage and add to `.gitignore`.

### 4) Admin surface hardening checklist
- Require auth on **every** admin endpoint.
- Tight filesystem allowlist + path normalization.
- Rate limiting + audit trail.
- Disable in production unless explicitly enabled (feature flag).
