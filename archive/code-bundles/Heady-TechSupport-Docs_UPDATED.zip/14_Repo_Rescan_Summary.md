# Repo Rescan Summary

**Last updated:** 2026-02-24

This kit was originally generated from the HeadyMe repos visible on GitHub, and then **rescanned** to incorporate newer details.

## Repos scanned
- `HeadyMe/Heady-pre-production-9f2f0642` (hybrid Node/Python; large multi-folder layout; many operational docs/issues)
- `HeadyMe/Heady` (GitHub shows as `Heady-8f71ffc8`; includes explicit frontend + additional packages)
- `HeadyMe/HeadyMonorepo` (meta/status + automation commands)

## Notable deltas that affect tech support
1. **Render blueprints differ** between repos:
   - pre-production includes a python `heady-admin` service running `remote-admin-server.py`.
   - Heady repo includes a Node `heady-manager` with health check `/api/brain/health`.
2. **Operational guidance exists in Issues** (e.g., security cleanup and “perfect setup”) that should be treated as authoritative backlog items.
3. DNS/WAF/origin binding issues are repeatedly referenced; the deployment runbook now includes a Cloudflare Workers proxy stabilization pattern.

## What the support docs now assume
- There is a central “manager/gateway” service exposing `/api/health` and `/api/pulse`.
- Admin endpoints are present and must be protected by `HEADY_API_KEY`.
- Docker MCP is a supported local dev/support accelerator.
- Cloudflare is in the request path for most public domains; trust-proxy and correct origin binding are required.

