# Deployment and Release Runbook

**Last updated:** 2026-02-24

This runbook describes how to deploy Heady services and how to safely roll back when something goes wrong.

It is written to reduce risk by enforcing:
- pre-deploy checks,
- controlled rollouts,
- post-deploy verification,
- defined rollback procedures, and
- clear communication steps.

---

## 0) Release principles (support and safety)

1. **If health is red, do not deploy.**
2. **Deploy small changes frequently.**
3. **Make rollback easy** (revert commit, previous image tag, previous Render release).
4. **Separate config changes from code changes** when possible.
5. **Prefer staging validation** before production.

---

## 1) Pre-deploy checklist (must-do)

### 1.1 Confirm system health
```bash
curl -sf https://api.headysystems.com/api/health
```

### 1.2 Confirm readiness / risk (if Monte Carlo endpoints exist)
Examples (from command references):
```bash
curl -sf https://api.headysystems.com/api/monte-carlo/quick-deployment-risk
curl -sf https://api.headysystems.com/api/readiness/evaluate
```

### 1.3 Confirm config is correct
- `NODE_ENV`
- service URLs (avoid accidental localhost defaults)
- required secrets present (API keys, tokens)

### 1.4 Confirm CI checks
- Node tests (if implemented): `npm test`
- Python tests: `pytest` (if tests exist)
- Linting (if configured)

---

## 2) Deployment paths

### 2.1 Render deployment (common for web services)

#### How it works
The repos reference deployment via a `render.yaml` blueprint. In at least one configuration, Render runs a Python service on port 3000 (example: `remote-admin-server.py`). Your actual setup may include more services.

#### Standard procedure
1. Update code and configuration in repo.
2. Ensure secrets are in Render environment groups (do not commit).
3. Push to GitHub.
4. Allow Render to auto-build and deploy (or trigger manually).
5. Verify post-deploy health (Section 3).

#### Rollback (Render)
- Preferred: use Render “Rollback” to previous deploy.
- Alternative: revert the Git commit and trigger deploy.

### 2.2 Docker-based deployment (local or self-hosted)

#### Standard procedure
1. Build images:
```bash
docker-compose build
```

2. Deploy:
```bash
docker-compose up -d
```

3. Verify:
```bash
docker-compose ps
docker-compose logs --tail=200
```

#### Rollback (Docker)
- Deploy previous image tag (best if tagged releases exist).
- Or revert to previous git revision and rebuild.

### 2.3 Pipeline-driven deployment (HeadyCloud)

Some docs reference pipeline endpoints and scripts:

#### Trigger pipeline (example)
```bash
curl -sf -X POST https://headycloud.com/api/pipeline/run \
  -H "Authorization: Bearer $HEADY_API_KEY" \
  -d '{"pipeline":"autobuild"}'
```

#### Check pipeline state
```bash
curl -sf https://headycloud.com/api/pipeline/state \
  -H "Authorization: Bearer $HEADY_API_KEY"
```

#### Local scripts (examples)
```bash
python3 scripts/auto-deploy.py --clean-build
python3 scripts/deploy.py --env=production
python3 scripts/hcfull-pipeline.py
```

**Support note:** treat pipeline scripts as production tooling. Capture their output in an incident log if anything fails.

### 2.4 Cloudflare Workers deployment (edge)

The repos mention Cloudflare-managed subdomains and worker health. Exact worker deployment commands vary by repo, but a typical procedure is:

1. Build worker (if needed)
2. Deploy via Cloudflare tooling (e.g., wrangler)
3. Verify worker endpoints and logs
4. Verify Cloudflare security settings do not block real traffic

---

## 3) Post-deploy verification (must-do)

### 3.1 Basic checks
- API gateway:
  - `GET https://api.headysystems.com/api/health`
- If applicable:
  - `/api/system/status`
  - `/api/nodes`
  - `/api/registry`

### 3.2 UI checks
- Admin UI loads
- Admin UI can:
  - list roots
  - browse directories
  - read/write a small test file
  - trigger build/audit (if permitted)

### 3.3 Dependency checks
- DB connectivity (if used):
  - `/api/db/status` (if implemented) or logs show successful connection
- Redis connectivity (if used):
  - service logs show successful connection

### 3.4 Cloudflare sanity checks
- Confirm expected HTTP status (200), not a challenge page.
- Confirm origin is reachable directly (when needed) for debugging.

---

## 4) Release communication

### 4.1 Change record (minimum)
For every production release, record:
- release identifier (git sha)
- start time / end time
- changes included (1-3 sentences)
- verification results
- any incidents or rollbacks

### 4.2 Incident communications
If release causes user impact:
- declare incident and severity
- update status page / comms channel every 15-30 minutes until stable
- write a postmortem within 1-3 business days

---

## 5) Emergency rollback playbook

Trigger rollback immediately if:
- `/api/health` fails for > 5 minutes
- error rate spikes and user impact is confirmed
- auth failures lock out admins
- data integrity risk is suspected

Steps:
1. Stop the bleeding (disable new traffic if possible).
2. Roll back to last known good release.
3. Validate health and critical user flows.
4. Announce recovery and begin postmortem.



## Addendum: Render blueprint differences and DNS/proxy fixes (rescan 2026-02-24)

### Heady (Node) Render blueprint
- Node runtime, performance plan.
- Uses `npm install --production && npm run build` then `npm start`.
- `healthCheckPath: /api/brain/health`.
- Pulls secrets from Render secret store (`DATABASE_URL`, `HEADY_API_KEY`, `ADMIN_TOKEN`).

### Pre-production heady-admin (Python) Render blueprint
- Python runtime (Flask) on free plan.
- Minimal build (`pip install flask flask-cors`) and start `python remote-admin-server.py`.

### Cloudflare Workers proxy pattern
If DNS resolves but origin services are only reachable locally / wrong bind address, a temporary mitigation documented in `FINAL_SOLUTION_2026-02-16.md` is to stand up Workers that proxy subdomains to already-working origin endpoints. Use this as a **stabilization step** while you fix origin binding (`0.0.0.0`) and firewall/WAF.
