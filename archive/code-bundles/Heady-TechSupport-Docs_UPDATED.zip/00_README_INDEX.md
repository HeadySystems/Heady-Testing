# Heady Tech Support Documentation Kit

**Last updated:** 2026-02-24
**Audience:** support engineers, developers on-call, DevOps/infrastructure owners, and anyone who needs to operate and support the Heady ecosystem.

This kit is designed to be a **practical, operations-first** set of documents that describes how to:
- Understand the Heady system at a glance (what exists, where it runs, what it depends on)
- Bring up environments (local, hybrid, staging, production)
- Monitor and troubleshoot issues quickly (health checks, logs, metrics, common failures)
- Deploy, rollback, and perform routine operations (backups, rotations, change management)
- Run incident response end-to-end (triage, comms, mitigation, postmortems)

It is intentionally written so you can hand it to a new support engineer and they can become productive **without tribal knowledge**.

---

## How this kit is organized

### Core documents
- **01_Service_Catalog.md** - What services exist, where they run, ports, owners, health checks
- **02_Architecture_Overview.md** - System context, dependencies, data flows, diagrams
- **03_Environment_and_Configuration.md** - Environment variables, config files, secrets handling
- **04_Local_Development_Setup.md** - Local dev setup + common pitfalls
- **05_Docker_MCP_Runbook.md** - Docker Desktop MCP stack: start/stop, logs, common issues
- **06_Deployment_and_Release_Runbook.md** - Deploy/rollback procedures (Render, Docker, Cloudflare workers)
- **07_Monitoring_Alerting_and_Observability.md** - Health checks, metrics, alerting patterns, log locations
- **08_Incident_Response_Playbook.md** - Severity, triage, escalation, comms, and postmortems
- **09_Troubleshooting_Knowledge_Base.md** - “If X happens, do Y” KB articles
- **10_Backup_Restore_and_DR.md** - Backup/restore/runbooks for DB + key data
- **11_Security_and_Access.md** - Access model, API keys, CORS/WAF, secret rotation, hardening checklist
- **12_Support_Operations_and_Processes.md** - Ticket intake, SLAs/SLOs, maintenance windows, change mgmt

### Templates
- **templates/Ticket_Template.md**
- **templates/Incident_Report_Template.md**
- **templates/Postmortem_Template.md**
- **templates/Change_Request_Template.md**

### Quick reference
- **quickrefs/Commands_Quickref.md**
- **quickrefs/Health_Checks_Quickref.md**
- **quickrefs/Ports_Endpoints_Quickref.md**

### Optional artifacts
- **Heady_Service_Catalog.xlsx** - Same as Service Catalog, but spreadsheet-friendly
- **Heady_OnCall_Quick_Reference.pdf** - A printable “on-call card”
- **Heady_Tech_Support_Handbook.docx** - A single compiled handbook (for sharing)

---

## Key “golden rules” for Heady support

1. **Start with health, then logs, then configuration**
   - Health endpoints confirm “is it alive?”
   - Logs confirm “why did it fail?”
   - Config confirms “was it pointed at the right place?”

2. **Treat `HEADY_API_KEY` as the root key**
   - Many admin endpoints are protected by API key authentication.
   - If authentication fails, almost everything else will appear broken.

3. **Cloudflare and DNS are critical path**
   - A huge percentage of “site is down” incidents are actually DNS misrouting or Cloudflare/WAF challenges.
   - Always determine: *is the origin healthy*, *is DNS correct*, *is Cloudflare blocking*?

4. **Never place secrets in docs or repos**
   - If you see a token in a repo, treat it as leaked: rotate it and remove it.
   - Use environment variables / a secrets manager.

---

## Recommended first read (new on-call)

1. quickrefs/Health_Checks_Quickref.md  
2. 01_Service_Catalog.md  
3. 09_Troubleshooting_Knowledge_Base.md  
4. 08_Incident_Response_Playbook.md  

---

## Source repos used to compile this kit (HeadyMe GitHub)

This kit is based on publicly visible documentation and conventions present in:
- HeadyMe/Heady (mainline)
- HeadyMe/Heady-pre-production-9f2f0642 (pre-production / ops docs)
- HeadyMe/HeadyMonorepo (ecosystem overview)

Where repo documents conflict, this kit prefers:
1. “authoritative” domain ownership and environment guidance
2. operational runbooks that match current deployment
3. code-level truth (health endpoints, ports, etc.)

---

## TODOs for your team (fill these in)

To make this kit 100% production-ready for your organization, fill in:
- **Owner / on-call rotation** per service
- **Pager / alert routing** (Slack/PagerDuty/Email)
- **Actual log storage** (where logs land in prod)
- **Real SLO targets** (availability, latency, error rate) for each service
- **Canonical runbooks** for “hard” failures (DB corruption, key compromise, etc.)

