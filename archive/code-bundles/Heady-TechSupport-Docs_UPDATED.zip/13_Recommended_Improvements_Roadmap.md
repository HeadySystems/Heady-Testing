# Recommended Mods & Additions Roadmap (Support/Operations)

**Last updated:** 2026-02-24

This document is a **follow-up** to the tech support kit. It lists *every category of modification or addition* that would materially improve:
- supportability,
- reliability,
- security,
- developer experience, and
- operating cost / clarity.

It is written so you can turn it into epics/tickets.

---

## A. “Stop the bleeding” (do first)

### A1) Secrets hygiene + repo sanitization (Critical)
**Why it benefits:** Prevents immediate compromise, eliminates recurring incidents caused by leaked tokens/DB creds.  
**What to implement:**
- Rotate all credentials used by any public repo.
- Rewrite git history to remove secret-bearing files (not only delete them).
- Add secret scanning + pre-commit hooks (gitleaks / trufflehog) and CI gate.
- Move all runtime logs (deploy/audit) to non-repo storage.

**Support impact:** fewer “mystery” 401/403, fewer hostile traffic / abuse, cleaner incident response.

### A2) Harden the Admin IDE / admin APIs (Critical)
- Enforce auth everywhere (`HEADY_API_KEY` / `ADMIN_TOKEN`).
- Add IP allowlist and/or SSO for admin paths.
- Disable dangerous file operations by default; enable via feature flag.
- Add explicit audit log redaction for secrets.
- Add CSRF protection if used in browser contexts.

### A3) Cloudflare / origin correctness guardrails (Critical)
- Ensure origin services bind to `0.0.0.0` (not localhost) in any server unit files.
- Add a “wrong-origin” detector (health endpoint shows bind address, public IP, CF headers).
- Standardize WAF/challenge mode policies (avoid surprise 403 challenges on API routes).

---

## B. Reliability + incident reduction

### B1) Canonical health model + dependencies (High)
**What to implement:**
- `/api/health` for liveness (fast, no deps)
- `/api/ready` for readiness (checks DB/cache/model deps)
- `/api/status` for human-friendly status page JSON
- Each service exposes version + git SHA.

### B2) Structured logging + correlation IDs (High)
- JSON logs with request id, user id (if safe), route, latency, status, error class.
- Propagate `X-Request-Id` across services.
- Central log sink (Render, Loki, ELK, etc.) with retention policy.

### B3) Monitoring + SLOs (High)
- Define SLOs: availability, latency, error rate.
- Create alert rules: 5xx rate, p95 latency, deployment failures, DB connection exhaustion.
- Add dashboards: request volume, errors, queue depth, worker utilization.

### B4) Background job system (Medium → High)
If long-running builds/audits exist:
- Use a queue (BullMQ/Redis, Celery, etc.)
- Ensure idempotent jobs
- Expose job status endpoints

---

## C. Delivery + quality

### C1) CI that actually blocks regressions (High)
- Unit tests for critical endpoints and auth
- Smoke tests on PR
- Lint/format gate
- Dependency vulnerability scans (npm audit, pip-audit)

### C2) Release discipline (Medium)
- Tagging strategy
- Changelog generation
- “Release verify checklist” baked into pipelines

### C3) Repo hygiene / architecture boundaries (Medium)
- Reduce root-level sprawl (move docs into `/docs`, scripts into `/scripts`, configs into `/configs`)
- Deduplicate scripts (pick one canonical autobuild)
- Consider a true monorepo structure with tooling (pnpm workspaces / turborepo) OR split repos with clear contracts.

---

## D. Support tooling improvements

### D1) One-command diagnostics bundle (High)
Implement a `support-bundle` command that collects:
- env (redacted)
- service versions
- last N logs
- health snapshots
- docker/container status (if local)

### D2) “Known issues” knowledge base automation (Medium)
- Auto-open tickets on repeated alerts
- KB article linking in alerts

### D3) Self-serve status page (Medium)
- Public status w/ incident history
- Separate internal status with deeper metrics

---

## E. Security maturity additions

### E1) Threat modeling + abuse protection (Medium)
- Rate limit by route + token
- Bot / abuse monitoring
- Add WAF rules for API endpoints

### E2) Supply chain hardening (Medium)
- Pin dependencies
- SBOM generation
- Signed releases / provenance (SLSA-style)

---

## Implementation sequencing suggestion
1. **A1–A3**
2. **B1–B3**
3. **C1**
4. **D1**
5. Everything else

