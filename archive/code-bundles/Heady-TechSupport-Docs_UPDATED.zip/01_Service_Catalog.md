# Service Catalog (Heady Ecosystem)

**Last updated:** 2026-02-24

This catalog is the **single best starting point** when supporting Heady. It answers:
- What is each service?
- Where does it run (domain/port)?
- How do I know it is healthy?
- What does it depend on (DB, Redis, Cloudflare, tokens)?
- Where do I look first for logs and metrics?

> Note: The Heady repos include multiple “layers” (pre-production docs, monorepo guidance, and production endpoints). Some ports and URLs differ slightly across docs; this catalog documents the *most common* values and calls out known variants.

---

## 1) Primary production domains

The Heady ecosystem is designed to be accessed via branded domains. A curated list of domains is maintained (and includes a rule to avoid unowned domains and common anti-patterns like “cloud.headysystems.com”).  
**Treat the domain inventory as authoritative** for what can exist in production.  

**Core active services (examples):**
- headysystems.com
- headycloud.com
- headyconnection.org / headyconnection.com
- headymcp.com
- headybot.com
- headycheck.com
- headyio.com
- headybuddy.org

---

## 2) Service inventory

### Legend
- **Tier**:
  - *Tier 0*: Global entrypoints (DNS, CDN) - outages affect everything
  - *Tier 1*: Core platform services - outages impact most users
  - *Tier 2*: Supporting services - partial degradation possible
  - *Tier 3*: Optional/experimental - failure should not take down core workflows

### 2.1 Platform services (Tier 1)

| Service | Purpose | Primary Domain(s) | Default Port | Health Check | Key Dependencies | Repo Location (typical) | Support Owner |
|---|---|---:|---:|---|---|---|---|
| **HeadyManager API / Gateway** | Central orchestrator, admin API, MCP server, static file serving | api.headysystems.com (and/or headysystems.com) | 3300 | `GET /api/health` | HEADY_API_KEY, (optional) Postgres, (optional) HuggingFace token | `heady-manager.js`, `backend/` | TBD |
| **HeadyAdmin / Admin IDE** | Web-based IDE (Monaco) + file browser + logs + build/audit controls | `/admin` or `/admin.html` | Served by HeadyManager | `GET /api/health` + Admin endpoints | HEADY_API_KEY, filesystem allowlist, build/audit scripts | `public/admin.html` | TBD |
| **HeadyCloud** | Pipeline orchestration, deploy layers, Monte Carlo engine | headycloud.com | varies | `GET /api/health` (if exposed) | HEADY_API_KEY, pipeline state storage | `services/` / `scripts/` | TBD |
| **HeadyConnection** | Community/non-profit portal experience | headyconnection.org | N/A | site-specific | identity, content | `sites/` or separate repo | TBD |

### 2.2 Developer/user-facing apps (Tier 2)

| Service | Purpose | Primary Domain(s) | Default Port | Health Check | Key Dependencies | Repo Location (typical) | Support Owner |
|---|---|---:|---:|---|---|---|---|
| **HeadyBuddy UI** | Companion/chat interface and automation surface | buddy.headysystems.com and/or headybot.com | 3000 | `/api/health` (if implemented) | API gateway, sync token, model endpoints | `HeadyBuddy/`, `headybuddy/` | TBD |
| **HeadyAI-IDE** | AI-powered IDE with Arena mode, consensus router | ide.headysystems.com | 3400 (sometimes 3401) | `/health` and/or `/api/*/status` | API gateway, model endpoints | `HeadyAI-IDE/`, `heady-ide/` | TBD |
| **HeadyWeb** | Website and/or web application layer | web.headysystems.com | 3500 | site-specific | API gateway | `HeadyWeb/`, `headyweb/`, `sites/` | TBD |
| **HeadyLens** | Metrics/performance/errors endpoints | lens.headysystems.com | 8080 | `/api/metrics` (example) | metrics store/logs | `services/` or separate | TBD |

### 2.3 Edge and Cloudflare services (Tier 0-2, depending on routing)

| Service | Purpose | Domain(s) | Platform | Health Check | Notes |
|---|---|---|---|---|---|
| **Cloudflare DNS** | DNS resolution + proxy routing | All domains | Cloudflare | `dig`, `nslookup` | Often the root cause of “everything is down.” |
| **Cloudflare Workers** | Edge routing or small services (arena, nomenclature, etc.) | e.g., `arena.headysystems.com`, `nomenclature.headysystems.com` | Cloudflare Workers | worker-specific | Watch for Cloudflare WAF/bot challenges and “prohibited IP” misconfig. |

### 2.4 Data services (Tier 1-2)

| Component | Purpose | Typical Endpoint | Deployment Mode | Health Check | Notes |
|---|---|---|---|---|---|
| **PostgreSQL** | Primary persistence | `*:5432` | Docker / managed DB | `pg_isready` | In Docker MCP stack: `heady-postgres`. |
| **Redis** | Cache / session / queue | `*:6379` | Docker / managed Redis | `redis-cli ping` | In Docker MCP stack: `heady-redis`. |
| **HeadyMemory storage** | Persistent memory / state | file-backed or DB | local filesystem or service | N/A | Often stored under `.heady-memory/`. |

---

## 3) “First responders” for support

If you only remember a few commands, remember these:

### 3.1 Is it up?
- `curl -sf https://api.headysystems.com/api/health`
- `curl -sf https://headysystems.com/api/health`
- If it fails: check DNS and Cloudflare first (see Troubleshooting KB).

### 3.2 Is it the CDN/WAF?
- `curl -I https://app.headysystems.com`  
  - If you see HTTP 403 and “challenge”, it’s Cloudflare blocking (not the origin being down).

### 3.3 Are data dependencies up?
- Docker stack:
  - `docker-compose -f docker-compose.mcp.yml ps`
  - `docker exec heady-postgres pg_isready`
  - `docker exec heady-redis redis-cli ping`

---

## 4) Known variants and “gotchas”

### 4.1 Ports can differ across environments
- IDE service is referenced as 3400 in some docs and 3401 in others.
- Always prefer: **the port actually bound in the running environment** (container/service config).

### 4.2 Dual naming for “Buddy”
- Some docs refer to `buddy.headysystems.com` while env configuration may use `headybot.com`.
- Treat `headybot.com` as the public “friendly” entrypoint; treat `buddy.headysystems.com` as the technical service name.

### 4.3 Cloudflare “prohibited IP” errors
- This happens when DNS is pointed at a Cloudflare proxy IP instead of the true origin server.
- Resolution: update DNS to the **actual server IP** (or configure proper origin routing / load balancer).

---

## 5) Where to add / update services

When a new service is created or renamed:
1. Add it to this catalog.
2. Add its health checks to quickrefs/Health_Checks_Quickref.md.
3. Ensure it is included in monitoring/alerting (07_Monitoring_Alerting_and_Observability.md).
4. Ensure its domains are actually owned and listed in the authoritative domain inventory.
5. Confirm its secrets are stored securely (11_Security_and_Access.md).



## Updated service inventory (2026-02-24 rescan)

| Tier | Service | Primary domains / URLs | Ports | Health check | Notes |
|---|---|---|---|---|---|
| Tier 1 | HeadyManager API / Gateway | headysystems.com, api.headysystems.com, headycloud.com | 3300 | GET /api/health; GET /api/pulse | Render deploy uses render.yaml; health check may be /api/brain/health in Heady repo |
| Tier 1 | Admin IDE (Web) | headysystems.com/admin or /admin | served by 3300 | GET /api/health + admin endpoint auth | High-privilege surface: treat as admin console |
| Tier 1 | Remote Admin Server (Render python) | (Render service) heady-admin | 3000 | GET / (or /health if added) | Pre-production render.yaml defines python web 'heady-admin' on free plan |
| Tier 2 | HeadyAI-IDE | ide.headysystems.com | 3400 | service-specific | Confirm port/health path per app |
| Tier 2 | HeadyBuddy UI | buddy.headysystems.com, headybot.com | 3000 (varies) | service-specific | Ensure correct CORS origins, tokens |
| Tier 2 | HeadyWeb | web.headysystems.com | 3500 | service-specific | May be proxied via Cloudflare |
| Tier 2 | HeadyLens (metrics) | lens.headysystems.com | 8080 | /api/metrics (if implemented) | If not implemented, de-scope or implement |
| Tier 2 | HeadyConnection app | app.headyconnection.org | N/A | site-specific | May be separate deployment |
| Tier 1 | Cloudflare Workers (proxy) | app.headysystems.com, mobile.headysystems.com | N/A | curl proxied endpoints | Recommended in FINAL_SOLUTION_2026-02-16.md for rapid fix |
| Tier 2 | Docker MCP Stack | local | 5432, 6379 | docker-compose ps; pg_isready | Used to enhance dev/support automation |
