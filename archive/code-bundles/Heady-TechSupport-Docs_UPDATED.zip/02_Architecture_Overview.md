# Architecture Overview (Support-Focused)

**Last updated:** 2026-02-24

This document explains the Heady ecosystem in a way that helps support teams:
- localize failures quickly,
- understand blast radius,
- know what dependencies to check first, and
- avoid “rabbit hole debugging.”

---

## 1) One-paragraph summary

Heady is a **hybrid Node.js + Python** platform that operates as an ecosystem of services:
- A **central Node.js/Express orchestrator** (often called *HeadyManager*) exposes health endpoints, orchestrates work, and serves admin UI.
- A set of **Python workers/scripts** handle inference and build orchestration.
- A web-based **Admin IDE** provides file operations, build/audit triggers, and real-time log streaming.
- Optional containerized **MCP servers** (filesystem, memory, fetch, postgres, etc.) provide tool integrations and automation.
- The public system is fronted by **branded domains**, typically behind **Cloudflare** (DNS/CDN/WAF) and deployed via platforms like Render and/or Docker-based stacks.

---

## 2) Core components (code-level truth)

From the project documentation, the commonly referenced core components are:

- `heady-manager.js` (Node.js/Express): MCP server + Admin API + static file serving
- `src/process_data.py` (Python): inference worker (Hugging Face)
- `src/consolidated_builder.py` (Python): build orchestration / multi-agent coordination
- `admin_console.py` (Python): audit and health checks
- `public/index.html` (React via CDN): UI dashboard
- `public/admin.html` (React + Monaco): Admin IDE
- `render.yaml`: infrastructure-as-code style deployment blueprint

---

## 3) System context diagram

```mermaid
flowchart TB
  user[End User / Operator] --> cf[Cloudflare DNS/CDN/WAF]
  cf --> web[HeadyWeb (web.headysystems.com)]
  cf --> api[HeadyManager API (api.headysystems.com)]
  cf --> buddy[HeadyBuddy UI (buddy.headysystems.com / headybot.com)]
  cf --> ide[HeadyAI-IDE (ide.headysystems.com)]
  cf --> workers[Cloudflare Workers<br/>arena, nomenclature, etc.]

  api --> py[Python workers<br/>process_data.py, consolidated_builder.py]
  api --> admin[Admin IDE (/admin or /admin.html)]
  api --> mcp[MCP Service Layer]
  mcp --> fs[MCP filesystem]
  mcp --> mem[MCP memory]
  mcp --> fetch[MCP fetch]
  mcp --> pg[MCP postgres]

  api --> db[(PostgreSQL)]
  api --> redis[(Redis)]
```

### What this means for support
- **If everything is down**: start at Cloudflare/DNS.
- **If only one feature is down**: start at the service that owns that feature, then check its dependencies.
- **If admin UI loads but file operations fail**: it’s likely API key auth, path allowlists, or backend file handling.

---

## 4) The “support mental model”: layers and failure domains

Think of Heady as a stack of layers:

1. **Tier 0: DNS/CDN/WAF (Cloudflare)**
   - Symptoms: 403 challenges, “host not found,” SSL issues, redirect loops.
   - Fixes are usually: DNS records, proxy mode, WAF exceptions, origin IP routing.

2. **Tier 1: API gateway/orchestrator (HeadyManager)**
   - Symptoms: `/api/health` fails, admin UI can’t load data, pipeline calls fail.
   - Fixes: restart service, check env vars, check API key, check logs.

3. **Tier 2: Data plane (Postgres/Redis/HeadyMemory)**
   - Symptoms: 500s, timeouts, “cannot connect,” degraded performance.
   - Fixes: DB health, credentials, network, storage/disk.

4. **Tier 2-3: Feature services (IDE, Buddy, Workers, etc.)**
   - Symptoms: specific UI/features broken.
   - Fixes: service-specific runbook.

---

## 5) MCP integration (what it is, why it matters)

The ecosystem describes multiple MCP servers including:
- filesystem
- sequential-thinking
- memory
- fetch
- postgres
- git
- puppeteer
- cloudflare

In practice, this means:
- Certain operations may depend on MCP connectivity.
- Failures may present as “tools missing,” “automation failed,” or “service not registered.”

### Common support actions
- Confirm MCP services are running (Docker stack).
- Confirm the orchestrator can see them (registry endpoints, if available).
- Check Docker network connectivity.

---

## 6) Build / audit flows

### 6.1 Build orchestration
Build is orchestrated by a Python script (often `src/consolidated_builder.py`) which can be invoked:
- locally (CLI)
- via admin UI “Build” tab
- via API endpoints (admin build triggers)

Support implications:
- Build failures are often **Python dependency** or **filesystem permission/path** failures.
- Always capture build logs (admin SSE streams if possible).

### 6.2 Audits
Audits are performed by a Python console script (often `admin_console.py`), which can run full checks or targeted checks.

Support implications:
- Audits are a safe first step for diagnosing “system drift” or missing dependencies.
- Audits should be run before deploys when possible.

---

## 7) Data flow and observability concepts

The monorepo overview describes a pipeline-like flow:
- input interception
- routing / optimization
- execution and tracking
- audit logging and observability

Support implication:
- If a request is “accepted but nothing happens,” look for:
  - routing failures,
  - circuit-breaker activation,
  - queue backlog,
  - downstream service health.

---

## 8) Architecture checklists (support)

### 8.1 Before you declare an outage
- [ ] Does DNS resolve to the expected record?
- [ ] Is Cloudflare returning a challenge/403?
- [ ] Is the origin healthy when accessed directly (bypassing Cloudflare)?
- [ ] Does `/api/health` return 200 from the API domain?
- [ ] Are DB and Redis reachable from the API environment?
- [ ] Did recent deploys or WAF changes occur?

### 8.2 When debugging “admin UI broken”
- [ ] Can you load `/admin` or `/admin.html` at all?
- [ ] Does the browser console show 401/403 to admin endpoints?
- [ ] Is the API key header present?
- [ ] Does `/api/admin/roots` work with the key?
- [ ] Are file paths within allowlisted roots?

---

## Appendix: Diagrams you can paste into issues

### Service dependency diagram (minimal)
```mermaid
flowchart LR
  cf[Cloudflare] --> api[HeadyManager]
  api --> db[(Postgres)]
  api --> r[(Redis)]
  api --> py[Python worker/scripts]
  api --> admin[Admin IDE UI]
```



## Addendum: repo topology differences (rescan 2026-02-24)

### Heady-pre-production-9f2f0642
- Hybrid Node.js/Express `heady-manager.js` + Python workers (`src/process_data.py`, `src/consolidated_builder.py`, `admin_console.py`).
- Admin IDE served from `public/` with build/audit SSE endpoints.
- Docker Desktop MCP stack documented in `DOCKER_MCP_README.md`.

### Heady (Heady-8f71ffc8)
- Adds explicit **frontend (Vite + TailwindCSS)** and additional packages/folders (e.g., `heady-hive-sdk`, `heady-ide-ui`, `heady-buddy`).
- Render blueprint includes a health check path of `/api/brain/health` and cloud-only flags.

Support implication: incident triage should first determine **which repo/build** is deployed, because health checks, folder names, and deployment defaults differ.
