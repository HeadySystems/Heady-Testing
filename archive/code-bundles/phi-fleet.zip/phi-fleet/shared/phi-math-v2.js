'use strict';

/**
 * phi-math-v2.js
 * Canonical math library for the Heady ecosystem.
 * Every numeric constant in the system MUST derive from this file.
 *
 * @module phi-math-v2
 * @version 2.0.0
 */

// ─────────────────────────────────────────────────────────────────────────────
// CORE PHI CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────

/** The golden ratio φ = (1 + √5) / 2 ≈ 1.6180339887 */
const PHI = (1 + Math.sqrt(5)) / 2;

/** The reciprocal of φ, also φ - 1 ≈ 0.6180339887 */
const PSI = 1 / PHI;

/** φ² = φ + 1 ≈ 2.6180339887 */
const PHI_SQ = PHI + 1;

/** φ³ = 2φ + 1 ≈ 4.2360679775 */
const PHI_CB = 2 * PHI + 1;

/** Phi-derived temperature constant: ψ³ ≈ 0.236 */
const PHI_TEMPERATURE = PSI ** 3;

// ─────────────────────────────────────────────────────────────────────────────
// FIBONACCI UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

/** Memoization cache for Fibonacci values */
const _fibCache = new Map();

/**
 * Returns the nth Fibonacci number (0-indexed). Memoized.
 * Handles n in the range 0..50.
 *
 * @param {number} n - Non-negative integer index
 * @returns {number} The nth Fibonacci number
 */
function fib(n) {
  if (n < 0 || n > 50) throw new RangeError(`fib(n) only supports n in [0, 50], got ${n}`);
  if (n === 0) return 0;
  if (n === 1) return 1;
  if (_fibCache.has(n)) return _fibCache.get(n);
  const result = fib(n - 1) + fib(n - 2);
  _fibCache.set(n, result);
  return result;
}

/** Pre-computed Fibonacci sequence for lookup operations */
const FIB_SEQUENCE = Array.from({ length: 51 }, (_, i) => fib(i));

/**
 * Returns the Fibonacci number nearest to the given value.
 *
 * @param {number} value - The target value
 * @returns {number} The nearest Fibonacci number
 */
function fibNearest(value) {
  if (value <= 0) return 0;
  let best = FIB_SEQUENCE[0];
  let bestDist = Math.abs(value - best);
  for (let i = 1; i < FIB_SEQUENCE.length; i++) {
    const dist = Math.abs(value - FIB_SEQUENCE[i]);
    if (dist < bestDist) {
      bestDist = dist;
      best = FIB_SEQUENCE[i];
    } else if (dist > bestDist) {
      // Sequence is monotonically increasing; once distance grows, stop
      break;
    }
  }
  return best;
}

/**
 * Returns the smallest Fibonacci number greater than or equal to the given value.
 *
 * @param {number} value - The target value
 * @returns {number} The ceiling Fibonacci number
 */
function fibCeil(value) {
  if (value <= 0) return 0;
  for (let i = 0; i < FIB_SEQUENCE.length; i++) {
    if (FIB_SEQUENCE[i] >= value) return FIB_SEQUENCE[i];
  }
  return FIB_SEQUENCE[FIB_SEQUENCE.length - 1];
}

/**
 * Returns the largest Fibonacci number less than or equal to the given value.
 *
 * @param {number} value - The target value
 * @returns {number} The floor Fibonacci number
 */
function fibFloor(value) {
  if (value <= 0) return 0;
  let result = 0;
  for (let i = 0; i < FIB_SEQUENCE.length; i++) {
    if (FIB_SEQUENCE[i] <= value) {
      result = FIB_SEQUENCE[i];
    } else {
      break;
    }
  }
  return result;
}

/**
 * Returns true if n is a Fibonacci number.
 * Uses the mathematical identity: n is Fibonacci iff 5n²+4 or 5n²-4 is a perfect square.
 *
 * @param {number} n - Non-negative integer to test
 * @returns {boolean}
 */
function isFibonacci(n) {
  if (n < 0 || !Number.isInteger(n)) return false;
  const isPerfectSquare = (k) => {
    if (k < 0) return false;
    const root = Math.round(Math.sqrt(k));
    return root * root === k;
  };
  return isPerfectSquare(5 * n * n + 4) || isPerfectSquare(5 * n * n - 4);
}

// ─────────────────────────────────────────────────────────────────────────────
// CSL THRESHOLDS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Computes a CSL threshold at a given level.
 * Formula: 1 - PSI^level × spread
 *
 * @param {number} level - Phi-series level (1, 2, 3, ...)
 * @param {number} [spread=0.5] - Scaling spread factor
 * @returns {number} Threshold value in [0, 1]
 */
function phiThreshold(level, spread = 0.5) {
  return 1 - (PSI ** level) * spread;
}

/**
 * CSL gate thresholds derived from phi.
 * MINIMUM = phiThreshold(1) = 1 - PSI × 0.5 ≈ 0.691, but set to 0.500 as floor.
 */
const CSL_THRESHOLDS = Object.freeze({
  MINIMUM:  0.500,
  LOW:      parseFloat((1 - PSI    * 0.5).toFixed(15)),  // ≈ 0.691
  MEDIUM:   parseFloat((1 - PSI**2 * 0.5).toFixed(15)),  // ≈ 0.809
  HIGH:     parseFloat((1 - PSI**3 * 0.5).toFixed(15)),  // ≈ 0.882
  CRITICAL: parseFloat((1 - PSI**4 * 0.5).toFixed(15)),  // ≈ 0.927
});

/** Semantic deduplication similarity threshold: 1 - PSI^6 × 0.5 ≈ 0.972 */
const DEDUP_THRESHOLD = parseFloat((1 - PSI**6 * 0.5).toFixed(15));

/** Default coherence drift detection threshold (MEDIUM level) */
const COHERENCE_DRIFT_THRESHOLD = CSL_THRESHOLDS.MEDIUM;

// ─────────────────────────────────────────────────────────────────────────────
// PRESSURE LEVELS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * System pressure level thresholds derived from phi.
 * - NOMINAL_MAX:  ψ²  ≈ 0.382  (max nominal operating pressure)
 * - ELEVATED_MAX: ψ   ≈ 0.618  (max elevated pressure)
 * - HIGH_MAX:     1-ψ³ ≈ 0.764  (max high pressure)
 * - CRITICAL_MIN: 1-ψ⁴ ≈ 0.854  (critical pressure onset)
 */
const PRESSURE_LEVELS = Object.freeze({
  NOMINAL_MAX:  PSI ** 2,
  ELEVATED_MAX: PSI,
  HIGH_MAX:     1 - PSI ** 3,
  CRITICAL_MIN: 1 - PSI ** 4,
});

// ─────────────────────────────────────────────────────────────────────────────
// ALERT THRESHOLDS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Alert threshold levels derived from phi.
 * - WARNING:  ψ      ≈ 0.618
 * - CAUTION:  1-ψ²   ≈ 0.618 → 1-0.382 = 0.618 (note: same, distinct semantics)
 * - CRITICAL: 1-ψ³   ≈ 0.764
 * - EXCEEDED: 1-ψ⁴   ≈ 0.854
 * - HARD_MAX: 1.0
 */
const ALERT_THRESHOLDS = Object.freeze({
  WARNING:  PSI,
  CAUTION:  1 - PSI ** 2,
  CRITICAL: 1 - PSI ** 3,
  EXCEEDED: 1 - PSI ** 4,
  HARD_MAX: 1.0,
});

// ─────────────────────────────────────────────────────────────────────────────
// MATHEMATICAL PRIMITIVES
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Standard sigmoid activation function.
 *
 * @param {number} x - Input value
 * @returns {number} Output in (0, 1)
 */
function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}

/**
 * Computes an adaptive temperature from entropy relative to a maximum.
 * Scales linearly: temp = PHI_TEMPERATURE × (entropy / maxEntropy)
 *
 * @param {number} entropy    - Current entropy measure
 * @param {number} maxEntropy - Maximum possible entropy
 * @returns {number} Adaptive temperature in [0, PHI_TEMPERATURE]
 */
function adaptiveTemperature(entropy, maxEntropy) {
  if (maxEntropy <= 0) return PHI_TEMPERATURE;
  const ratio = Math.max(0, Math.min(1, entropy / maxEntropy));
  return PHI_TEMPERATURE * ratio;
}

// ─────────────────────────────────────────────────────────────────────────────
// CSL GATE FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Smooth sigmoid CSL gate.
 * Combines a raw value with a cosine similarity score using sigmoid blending.
 *
 * @param {number} value    - Raw input value (any range)
 * @param {number} cosScore - Cosine similarity score in [-1, 1]
 * @param {number} tau      - Temperature parameter controlling gate sharpness
 * @param {number} temp     - Phi temperature modifier
 * @returns {number} Gated output in (0, 1)
 */
function cslGate(value, cosScore, tau, temp) {
  const t = tau !== undefined ? tau : 1.0;
  const temperature = temp !== undefined ? temp : PHI_TEMPERATURE;
  const scaled = (value * cosScore) / (t * (temperature + Number.EPSILON));
  return sigmoid(scaled);
}

/**
 * Smooth weight interpolation using CSL sigmoid blending.
 * Blends between two weight extremes based on cosine similarity.
 *
 * @param {number} weightHigh - Weight when cosScore is high
 * @param {number} weightLow  - Weight when cosScore is low
 * @param {number} cosScore   - Cosine similarity in [-1, 1]
 * @param {number} tau        - Temperature parameter
 * @param {number} temp       - Phi temperature modifier
 * @returns {number} Interpolated weight
 */
function cslBlend(weightHigh, weightLow, cosScore, tau, temp) {
  const gate = cslGate(cosScore, cosScore, tau, temp);
  return weightLow + (weightHigh - weightLow) * gate;
}

// ─────────────────────────────────────────────────────────────────────────────
// BACKOFF & TIMING
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Computes a phi-series exponential backoff with ±38.2% jitter.
 * Base interval grows by PHI on each attempt.
 *
 * @param {number} attempt  - Attempt number (0-indexed)
 * @param {number} [baseMs=1000]  - Base delay in milliseconds
 * @param {number} [maxMs=60000] - Maximum delay cap in milliseconds
 * @returns {number} Delay in milliseconds with jitter applied
 */
function phiBackoff(attempt, baseMs = 1000, maxMs = 60000) {
  const raw = baseMs * (PHI ** attempt);
  const capped = Math.min(raw, maxMs);
  // ±38.2% jitter (PSI²/2 ≈ 0.191 each side → total range 0.382)
  const jitter = 1 + (Math.random() - 0.5) * (PSI ** 2);
  return Math.round(Math.min(capped * jitter, maxMs));
}

/**
 * Returns timeout in milliseconds for a given phi level.
 * Level 0→1000ms, each subsequent level multiplied by PHI.
 * Level 0=1000, 1=1618, 2=2618, 3=4236, 4=6854, 5=11090
 *
 * @param {number} level - Timeout level (0-5)
 * @returns {number} Timeout in milliseconds
 */
function phiTimeout(level) {
  return Math.round(1000 * (PHI ** level));
}

/**
 * Computes an adaptive polling interval scaled by health score.
 * Healthy systems (score→1) get longer intervals; unhealthy (score→0) get shorter.
 *
 * @param {number} baseMs      - Base interval in milliseconds
 * @param {number} healthScore - Health score in [0, 1]
 * @returns {number} Interval in milliseconds
 */
function phiAdaptiveInterval(baseMs, healthScore) {
  const score = Math.max(0, Math.min(1, healthScore));
  // Scale from PSI (unhealthy) to PHI (healthy) relative to base
  const multiplier = PSI + (PHI - PSI) * score;
  return Math.round(baseMs * multiplier);
}

// ─────────────────────────────────────────────────────────────────────────────
// PHI WEIGHT & SPLIT UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Returns n weights summing to 1.0 using a PSI-based geometric series.
 * The first weight is largest; each subsequent weight is PSI times the previous.
 *
 * @param {number} n - Number of weights (must be >= 1)
 * @returns {number[]} Array of n normalized weights summing to 1.0
 */
function phiFusionWeights(n) {
  if (n < 1 || !Number.isInteger(n)) throw new RangeError(`phiFusionWeights requires integer n >= 1, got ${n}`);
  if (n === 1) return [1.0];
  const raw = Array.from({ length: n }, (_, i) => PSI ** i);
  const sum = raw.reduce((acc, w) => acc + w, 0);
  return raw.map(w => w / sum);
}

/**
 * Alias for phiFusionWeights — returns phi-proportioned resource allocation weights.
 *
 * @param {number} n - Number of resource buckets
 * @returns {number[]} Normalized weights summing to 1.0
 */
function phiResourceWeights(n) {
  return phiFusionWeights(n);
}

/**
 * Splits an integer `whole` into n phi-proportioned integer parts.
 * Parts are rounded and any remainder is added to the first part.
 *
 * @param {number} whole - The total integer to split
 * @param {number} n     - Number of parts
 * @returns {number[]} Array of n integers summing to `whole`
 */
function phiMultiSplit(whole, n) {
  const weights = phiFusionWeights(n);
  const parts = weights.map(w => Math.floor(w * whole));
  const remainder = whole - parts.reduce((acc, p) => acc + p, 0);
  parts[0] += remainder;
  return parts;
}

/**
 * Returns a phi-proportioned token budget breakdown.
 *
 * @param {number} [base=8192] - Total token budget
 * @returns {{ working: number, session: number, memory: number, artifacts: number }}
 */
function phiTokenBudgets(base = 8192) {
  const [working, session, memory, artifacts] = phiMultiSplit(base, 4);
  return { working, session, memory, artifacts };
}

/**
 * Returns phi-proportioned Fibonacci pool sizes starting from a base Fibonacci number.
 *
 * @param {number} [base=5] - Starting Fibonacci number
 * @returns {number[]} Five consecutive Fibonacci pool sizes: [5, 8, 13, 21, 34]
 */
function phiPoolSizes(base = 5) {
  // Find the Fibonacci index of base, then return 5 consecutive values
  const startIdx = FIB_SEQUENCE.indexOf(fibCeil(base));
  const idx = startIdx < 0 ? FIB_SEQUENCE.indexOf(5) : startIdx;
  return FIB_SEQUENCE.slice(idx, idx + 5);
}

// ─────────────────────────────────────────────────────────────────────────────
// VECTOR OPERATIONS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Computes the cosine similarity between two numeric vectors.
 *
 * @param {number[]} a - First vector
 * @param {number[]} b - Second vector (must be same length as a)
 * @returns {number} Cosine similarity in [-1, 1]
 */
function cosineSimilarity(a, b) {
  if (a.length !== b.length) throw new Error(`cosineSimilarity: vectors must have equal length (${a.length} vs ${b.length})`);
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot  += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  if (denom === 0) return 0;
  return Math.max(-1, Math.min(1, dot / denom));
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIORITY SCORING
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Phi-weighted factor fusion for priority scoring.
 * Accepts any number of factor values in [0, 1] and combines them
 * using phi-geometric weights (most significant factor first).
 *
 * @param {...number} factors - Factor values in [0, 1], ordered by importance
 * @returns {number} Fused priority score in [0, 1]
 */
function phiPriorityScore(...factors) {
  if (factors.length === 0) return 0;
  const weights = phiFusionWeights(factors.length);
  return factors.reduce((acc, f, i) => acc + f * weights[i], 0);
}

/**
 * Eviction weight constants for cache/memory management.
 * Derived from phi-fusion weights over 3 factors.
 *  importance ≈ 0.486 (PSI^0 / sum)
 *  recency    ≈ 0.300 (PSI^1 / sum)
 *  relevance  ≈ 0.214 (PSI^2 / sum, adjusted)
 */
const EVICTION_WEIGHTS = Object.freeze({
  importance: 0.486,
  recency:    0.300,
  relevance:  0.214,
});

// ─────────────────────────────────────────────────────────────────────────────
// COMPLIANCE VALIDATION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Validates that a configuration object uses phi-compliant numeric values.
 * Scans all numeric leaves; flags values that are not derived from phi
 * (i.e., not within ±0.001 of any known phi constant or threshold).
 *
 * @param {Object} config - Configuration object to validate
 * @returns {Array<{ path: string, value: number, suggestion: string }>} violations
 */
function validatePhiCompliance(config) {
  const PHI_REFERENCE_VALUES = [
    PHI, PSI, PHI_SQ, PHI_CB, PHI_TEMPERATURE,
    ...Object.values(CSL_THRESHOLDS),
    DEDUP_THRESHOLD,
    ...Object.values(PRESSURE_LEVELS),
    ...Object.values(ALERT_THRESHOLDS),
    ...Object.values(EVICTION_WEIGHTS),
    ...FIB_SEQUENCE.slice(0, 30),
  ];

  const violations = [];

  function scan(obj, path) {
    if (obj === null || obj === undefined) return;
    if (typeof obj === 'number') {
      // Skip integers that are Fibonacci numbers or zero/one
      if (Number.isInteger(obj) && (obj === 0 || obj === 1 || isFibonacci(obj))) return;
      if (Number.isInteger(obj)) return; // All integers are allowed (e.g., ms values)
      const isPhiDerived = PHI_REFERENCE_VALUES.some(ref => Math.abs(obj - ref) < 0.001);
      if (!isPhiDerived) {
        const nearest = PHI_REFERENCE_VALUES.reduce((best, ref) =>
          Math.abs(obj - ref) < Math.abs(obj - best) ? ref : best
        );
        violations.push({
          path,
          value: obj,
          suggestion: `Consider using phi-derived value ≈ ${nearest.toFixed(6)}`,
        });
      }
      return;
    }
    if (typeof obj === 'object') {
      for (const key of Object.keys(obj)) {
        scan(obj[key], path ? `${path}.${key}` : key);
      }
    }
  }

  scan(config, '');
  return violations;
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
  // Core constants
  PHI,
  PSI,
  PHI_SQ,
  PHI_CB,
  PHI_TEMPERATURE,

  // Fibonacci
  fib,
  fibNearest,
  fibCeil,
  fibFloor,
  isFibonacci,
  FIB_SEQUENCE,

  // CSL Thresholds
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  COHERENCE_DRIFT_THRESHOLD,
  phiThreshold,

  // Pressure & Alert Levels
  PRESSURE_LEVELS,
  ALERT_THRESHOLDS,

  // Math primitives
  sigmoid,
  adaptiveTemperature,

  // CSL gate functions
  cslGate,
  cslBlend,

  // Timing & backoff
  phiBackoff,
  phiTimeout,
  phiAdaptiveInterval,

  // Weight & split utilities
  phiFusionWeights,
  phiResourceWeights,
  phiMultiSplit,
  phiTokenBudgets,
  phiPoolSizes,

  // Vector operations
  cosineSimilarity,

  // Priority & eviction
  phiPriorityScore,
  EVICTION_WEIGHTS,

  // Compliance
  validatePhiCompliance,
};
