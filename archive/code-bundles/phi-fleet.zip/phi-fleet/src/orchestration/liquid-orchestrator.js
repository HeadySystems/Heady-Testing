/**
 * @file liquid-orchestrator.js
 * @description Dynamic Liquid Latent OS Orchestrator — the nervous system of the Heady Latent OS.
 *   Routes all work through phi-scaled resource pools with intelligent scheduling,
 *   Fibonacci-stepped concurrency, phi-priority scoring, circuit breakers, and
 *   semantic deduplication.
 *
 * @module orchestration/liquid-orchestrator
 * @version 2.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const {
  PHI,
  PSI,
  fib,
  PRESSURE_LEVELS,
  DEDUP_THRESHOLD,
  CSL_THRESHOLDS,
  phiBackoff,
  phiAdaptiveInterval,
  cosineSimilarity,
  phiPriorityScore,
  phiFusionWeights,
} = require('../../shared/phi-math-v2');

// ── Phi-scaled timeout helper ────────────────────────────────────────────────

/**
 * Compute a phi-geometric timeout in milliseconds.
 * phiTimeout(n) = 1000 * PHI^n
 *   n=3 → ≈ 4236 ms  (Hot pool)
 *   n=4 → ≈ 6854 ms  (circuit breaker half-open)
 *   n=5 → ≈ 11090 ms (Warm pool)
 *   n=7 → ≈ 29034 ms (Cold pool)
 *
 * @param {number} n - Exponent index
 * @returns {number} Timeout in milliseconds
 */
function phiTimeout(n) {
  return Math.round(1000 * Math.pow(PHI, n));
}

// ── Constants ────────────────────────────────────────────────────────────────

/** Pool names in order of temperature */
const POOL_NAMES = Object.freeze(['hot', 'warm', 'cold', 'reserve', 'governance']);

/**
 * Phi-resource allocation weights (percentages).
 * Hot:34, Warm:21, Cold:13, Reserve:8, Governance:5 ≈ 81% (rest is overhead).
 */
const POOL_WEIGHTS = Object.freeze({
  hot:        0.34,
  warm:       0.21,
  cold:       0.13,
  reserve:    0.08,
  governance: 0.05,
});

/**
 * Fibonacci-stepped concurrency caps per pool.
 * Each pool gets a Fibonacci number reflecting its relative capacity.
 */
const POOL_FIB_CONCURRENCY = Object.freeze({
  hot:        fib(10), // 55
  warm:       fib(9),  // 34
  cold:       fib(8),  // 21
  reserve:    fib(7),  // 13
  governance: fib(6),  // 8
});

/** Fibonacci queue depth limits per pool */
const POOL_FIB_QUEUE_DEPTH = Object.freeze({
  hot:        fib(11), // 89
  warm:       fib(10), // 55
  cold:       fib(9),  // 34
  reserve:    fib(8),  // 21
  governance: fib(7),  // 13
});

/** Phi-scaled timeouts per pool (ms) */
const POOL_TIMEOUTS = Object.freeze({
  hot:        phiTimeout(3),  // ≈ 4 236 ms
  warm:       phiTimeout(5),  // ≈ 11 090 ms
  cold:       phiTimeout(7),  // ≈ 29 034 ms
  reserve:    phiTimeout(6),  // ≈ 17 944 ms
  governance: phiTimeout(8),  // ≈ 46 979 ms
});

/** Circuit breaker opens after this many consecutive failures */
const CB_FAILURE_THRESHOLD = fib(5); // 5

/** Circuit breaker half-open wait (ms) */
const CB_HALF_OPEN_DELAY = phiTimeout(4); // ≈ 6 854 ms

/** Pressure level labels */
const PRESSURE = Object.freeze({
  NOMINAL:  'NOMINAL',
  ELEVATED: 'ELEVATED',
  HIGH:     'HIGH',
  CRITICAL: 'CRITICAL',
});

/**
 * Task domain → default pool mapping.
 * Domains are categorised by their operational temperature.
 */
const DOMAIN_POOL_MAP = Object.freeze({
  code_generation:  'hot',
  code_review:      'warm',
  security:         'hot',
  architecture:     'warm',
  research:         'cold',
  documentation:    'cold',
  creative:         'warm',
  translation:      'warm',
  monitoring:       'hot',
  cleanup:          'cold',
  analytics:        'cold',
  maintenance:      'reserve',
});

/** Fibonacci sequence used for pre-warming workers */
const PREWARM_SIZES = Object.freeze([fib(5), fib(6), fib(7), fib(8)]); // [5, 8, 13, 21]

// ── Utility helpers ──────────────────────────────────────────────────────────

/**
 * Snap a value to the nearest Fibonacci number in a bounded range.
 * Fibonacci steps considered: 5, 8, 13, 21, 34, 55, 89.
 *
 * @param {number} value - Raw value to snap
 * @returns {number} Nearest Fibonacci number
 */
function snapToFibonacci(value) {
  const candidates = [fib(5), fib(6), fib(7), fib(8), fib(9), fib(10), fib(11)];
  return candidates.reduce((nearest, f) =>
    Math.abs(f - value) < Math.abs(nearest - value) ? f : nearest
  );
}

/**
 * Generate a deterministic stub embedding (384-dim) for a string.
 * Returns a plain Array<number> of unit-normalised values, compatible with
 * phi-math-v2's cosineSimilarity which requires plain Array inputs.
 * In production this would be replaced by a real embedding model call.
 *
 * @param {string} text - Input text
 * @returns {number[]} 384-dimensional unit vector (plain Array)
 */
function stubEmbedding(text) {
  const dim = 384;
  const vec = new Array(dim);
  let hash = 5381;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) + hash) ^ text.charCodeAt(i);
    hash >>>= 0;
  }
  for (let i = 0; i < dim; i++) {
    hash   = ((hash * 1664525) + 1013904223) >>> 0;
    vec[i] = ((hash & 0xFFFF) / 0xFFFF) * 2 - 1;
  }
  const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0)) || 1;
  return vec.map(v => v / norm);
}

// ── CircuitBreaker ───────────────────────────────────────────────────────────

/**
 * Per-pool circuit breaker.
 * States: CLOSED → OPEN (after threshold failures) → HALF_OPEN → CLOSED
 */
class CircuitBreaker {
  /**
   * @param {string} poolName - Name of the associated pool
   * @param {number} [failureThreshold=CB_FAILURE_THRESHOLD] - Consecutive failures before opening
   * @param {number} [halfOpenDelay=CB_HALF_OPEN_DELAY] - Ms before transitioning OPEN→HALF_OPEN
   */
  constructor(poolName, failureThreshold = CB_FAILURE_THRESHOLD, halfOpenDelay = CB_HALF_OPEN_DELAY) {
    this.poolName        = poolName;
    this.failureThreshold = failureThreshold;
    this.halfOpenDelay   = halfOpenDelay;
    this.state           = 'CLOSED';
    this.consecutiveFailures = 0;
    this.lastOpenedAt    = null;
  }

  /**
   * Returns true if the circuit is allowing requests through.
   * @returns {boolean}
   */
  isAllowing() {
    if (this.state === 'CLOSED') return true;
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastOpenedAt >= this.halfOpenDelay) {
        this.state = 'HALF_OPEN';
        return true;
      }
      return false;
    }
    // HALF_OPEN — allow one probe
    return true;
  }

  /** Record a successful execution. */
  recordSuccess() {
    this.consecutiveFailures = 0;
    this.state = 'CLOSED';
  }

  /** Record a failed execution. */
  recordFailure() {
    this.consecutiveFailures += 1;
    if (this.consecutiveFailures >= this.failureThreshold) {
      this.state = 'OPEN';
      this.lastOpenedAt = Date.now();
    }
  }

  /**
   * Serialisable status snapshot.
   * @returns {object}
   */
  getStatus() {
    return {
      poolName: this.poolName,
      state:    this.state,
      consecutiveFailures: this.consecutiveFailures,
      lastOpenedAt: this.lastOpenedAt,
    };
  }
}

// ── PoolState ────────────────────────────────────────────────────────────────

/**
 * Encapsulates the live state of a single resource pool.
 */
class PoolState {
  /**
   * @param {string} name - Pool name
   * @param {number} maxConcurrency - Maximum concurrent tasks (Fibonacci-sized)
   * @param {number} queueDepth - Maximum queue depth (Fibonacci-sized)
   * @param {number} timeout - Execution timeout in ms
   */
  constructor(name, maxConcurrency, queueDepth, timeout) {
    this.name           = name;
    this.maxConcurrency = snapToFibonacci(maxConcurrency);
    this.maxQueueDepth  = snapToFibonacci(queueDepth);
    this.timeout        = timeout;
    this.currentLoad    = 0;
    this.queue          = [];
    this.healthScore    = 1.0;
    this.circuitBreaker = new CircuitBreaker(name);
    this.totalExecuted  = 0;
    this.totalFailed    = 0;
    this.totalTimedOut  = 0;
    this.latencySum     = 0; // ms
    this.lastRebalancedAt = null;
  }

  /**
   * Pool utilisation ratio [0, 1].
   * @returns {number}
   */
  get pressure() {
    const activePressure = this.maxConcurrency > 0
      ? this.currentLoad / this.maxConcurrency
      : 0;
    const queuePressure = this.maxQueueDepth > 0
      ? this.queue.length / this.maxQueueDepth
      : 0;
    return Math.min((activePressure + queuePressure) / 2, 1);
  }

  /**
   * Average latency in ms (0 if no tasks completed).
   * @returns {number}
   */
  get avgLatency() {
    return this.totalExecuted > 0 ? this.latencySum / this.totalExecuted : 0;
  }

  /**
   * Returns a full snapshot of pool metrics.
   * @returns {object}
   */
  getMetrics() {
    return {
      name:            this.name,
      maxConcurrency:  this.maxConcurrency,
      currentLoad:     this.currentLoad,
      queueLength:     this.queue.length,
      maxQueueDepth:   this.maxQueueDepth,
      pressure:        +this.pressure.toFixed(4),
      healthScore:     +this.healthScore.toFixed(4),
      totalExecuted:   this.totalExecuted,
      totalFailed:     this.totalFailed,
      totalTimedOut:   this.totalTimedOut,
      avgLatency:      +this.avgLatency.toFixed(2),
      circuitBreaker:  this.circuitBreaker.getStatus(),
    };
  }
}

// ── LiquidOrchestrator ───────────────────────────────────────────────────────

/**
 * @class LiquidOrchestrator
 * @description The Dynamic Liquid Latent OS orchestrator.
 *   Manages phi-scaled resource pools, intelligent task routing, phi-priority
 *   scoring, circuit breakers, semantic deduplication, adaptive scheduling,
 *   and backpressure management.
 *
 * @example
 * const orchestrator = new LiquidOrchestrator({ maxTotalBudget: 100 });
 * await orchestrator.routeTask({ id: 'task-1', type: 'code_generation', prompt: '...' });
 */
class LiquidOrchestrator {
  /**
   * @param {object} [config={}] - Configuration overrides
   * @param {number} [config.maxTotalBudget=100]      - Total concurrency budget
   * @param {number} [config.baseIntervalMs=5000]     - Base scheduling interval (ms)
   * @param {number} [config.rebalanceIntervalMs=15000] - Rebalancing interval (ms)
   * @param {boolean} [config.enablePrewarm=true]     - Pre-warm pools on init
   * @param {Function} [config.onCriticalPressure]    - Callback for critical pressure events
   * @param {Function} [config.onTaskComplete]        - Callback fired when a task completes
   * @param {Function} [config.onTaskFail]            - Callback fired when a task fails
   * @param {Function} [config.taskExecutor]          - Pluggable execution fn: async (task) => result
   */
  constructor(config = {}) {
    this._config = {
      maxTotalBudget:      config.maxTotalBudget      ?? 100,
      baseIntervalMs:      config.baseIntervalMs      ?? 5000,
      rebalanceIntervalMs: config.rebalanceIntervalMs ?? 15000,
      enablePrewarm:       config.enablePrewarm       ?? true,
      onCriticalPressure:  config.onCriticalPressure  ?? null,
      onTaskComplete:      config.onTaskComplete      ?? null,
      onTaskFail:          config.onTaskFail          ?? null,
      taskExecutor:        config.taskExecutor        ?? this._defaultExecutor.bind(this),
    };

    /** @type {Map<string, PoolState>} */
    this._pools = this._initialisePools();

    /** Deduplification registry: taskId → embedding */
    this._dedupRegistry = new Map();

    /** Task metadata store */
    this._taskMeta = new Map();

    /** Completed-task timing history (ring buffer, max 200 entries) */
    this._completionHistory = [];

    /** Scheduling timer handles */
    this._timers = {};

    this._running = false;

    if (this._config.enablePrewarm) {
      this._prewarmPools();
    }
  }

  // ── Initialisation ─────────────────────────────────────────────────────────

  /**
   * Initialise all resource pools from phi-resource weights.
   * @private
   * @returns {Map<string, PoolState>}
   */
  _initialisePools() {
    const pools = new Map();
    for (const name of POOL_NAMES) {
      pools.set(
        name,
        new PoolState(
          name,
          POOL_FIB_CONCURRENCY[name],
          POOL_FIB_QUEUE_DEPTH[name],
          POOL_TIMEOUTS[name],
        )
      );
    }
    return pools;
  }

  /**
   * Pre-warm pools by setting initial worker counts from PREWARM_SIZES.
   * Sizes step through Fibonacci values: [5, 8, 13, 21].
   * @private
   */
  _prewarmPools() {
    const poolArr = POOL_NAMES;
    poolArr.forEach((name, idx) => {
      const pool = this._pools.get(name);
      const warmSize = PREWARM_SIZES[Math.min(idx, PREWARM_SIZES.length - 1)];
      // Pre-warm is simulated — in production this would spin up workers
      pool._prewarmWorkers = warmSize;
    });
  }

  // ── Pool Management ─────────────────────────────────────────────────────────

  /**
   * Compute the phi-weighted pressure score for a pool.
   * When pressure exceeds PSI (0.618), the pool is considered overloaded.
   *
   * @param {string} poolName - Target pool name
   * @returns {number} Pressure in [0, 1]
   */
  getPoolPressure(poolName) {
    const pool = this._pools.get(poolName);
    if (!pool) throw new Error(`Unknown pool: ${poolName}`);
    return pool.pressure;
  }

  /**
   * Dynamic rebalancing: when any pool's pressure exceeds PSI, redistribute
   * capacity from lower-pressure pools.
   * Pool sizes snap to the nearest Fibonacci number after redistribution.
   */
  rebalancePools() {
    const overloaded = [];
    const underloaded = [];

    for (const [name, pool] of this._pools) {
      if (pool.pressure > PSI) {
        overloaded.push({ name, pool, pressure: pool.pressure });
      } else if (pool.pressure < PSI * PSI) {
        underloaded.push({ name, pool, pressure: pool.pressure });
      }
    }

    if (overloaded.length === 0 || underloaded.length === 0) return;

    for (const over of overloaded) {
      // Borrow capacity from the least-loaded underloaded pool
      const donor = underloaded.sort((a, b) => a.pressure - b.pressure)[0];
      if (!donor) continue;

      const transfer = Math.floor(donor.pool.maxConcurrency * PSI * PSI);
      if (transfer < 1) continue;

      const newDonorCap = snapToFibonacci(donor.pool.maxConcurrency - transfer);
      const newOverCap  = snapToFibonacci(over.pool.maxConcurrency  + transfer);

      donor.pool.maxConcurrency = newDonorCap;
      over.pool.maxConcurrency  = newOverCap;
      over.pool.lastRebalancedAt = new Date().toISOString();
    }
  }

  /**
   * Scale a pool up or down by one Fibonacci step.
   *
   * @param {string} poolName - Target pool name
   * @param {'up'|'down'} direction - Scaling direction
   * @returns {number} New maxConcurrency
   */
  scalePool(poolName, direction) {
    const pool = this._pools.get(poolName);
    if (!pool) throw new Error(`Unknown pool: ${poolName}`);

    const fibSteps = [fib(5), fib(6), fib(7), fib(8), fib(9), fib(10), fib(11)];
    const currentIdx = fibSteps.findIndex(f => f >= pool.maxConcurrency);

    if (direction === 'up') {
      const nextIdx = Math.min(currentIdx + 1, fibSteps.length - 1);
      pool.maxConcurrency = fibSteps[nextIdx];
    } else {
      const prevIdx = Math.max(currentIdx - 1, 0);
      pool.maxConcurrency = fibSteps[prevIdx];
    }

    return pool.maxConcurrency;
  }

  // ── Task Classification & Routing ──────────────────────────────────────────

  /**
   * Classify a task into its domain, priority, target pool, and estimated duration.
   *
   * @param {object} task - Raw task descriptor
   * @param {string} [task.type]        - Domain hint (e.g., 'code_generation')
   * @param {number} [task.urgency=0.5]       - Urgency score [0, 1]
   * @param {number} [task.complexity=0.5]    - Complexity score [0, 1]
   * @param {boolean} [task.userFacing=false] - Whether result is surfaced to user
   * @param {number} [task.businessValue=0.5] - Business-value score [0, 1]
   * @returns {{ domain: string, priority: number, pool: string, estimatedDuration: number }}
   */
  classifyTask(task) {
    const domain = DOMAIN_POOL_MAP[task.type] ? task.type : 'research';
    const pool   = DOMAIN_POOL_MAP[domain] ?? 'cold';

    const urgency       = task.urgency       ?? 0.5;
    const complexity    = task.complexity    ?? 0.5;
    const userFacing    = task.userFacing    ? 1.0 : 0.0;
    const businessValue = task.businessValue ?? 0.5;

    const priority = phiPriorityScore(urgency, complexity, userFacing, businessValue);

    // Estimate duration from pool timeout as a phi-fraction
    const poolState = this._pools.get(pool);
    const estimatedDuration = poolState ? Math.round(poolState.timeout * PSI) : 5000;

    return { domain, priority, pool, estimatedDuration };
  }

  /**
   * Compute a phi-weighted priority score for a task.
   * Higher score = higher scheduling priority.
   *
   * @param {number} urgency       - [0,1] How time-sensitive
   * @param {number} complexity    - [0,1] Computational complexity
   * @param {number} userFacing    - [0,1] User-facing impact
   * @param {number} businessValue - [0,1] Business value
   * @returns {number} Priority score in [0, 1]
   */
  phiPriorityScore(urgency, complexity, userFacing, businessValue) {
    return phiPriorityScore(urgency, complexity, userFacing, businessValue);
  }

  /**
   * Route a task into the appropriate pool queue with phi-priority ordering.
   * Performs semantic deduplication before enqueue.
   *
   * @param {object} task - Task descriptor (must have `id` and `type`)
   * @returns {{ queued: boolean, pool: string, priority: number, reason?: string }}
   */
  routeTask(task) {
    if (!task || !task.id) throw new TypeError('task.id is required');

    const classification = this.classifyTask(task);
    const { pool, priority } = classification;
    task._priority   = priority;
    task._pool       = pool;
    task._classifiedAt = Date.now();

    // Semantic dedup
    const taskText  = `${task.type || ''} ${task.prompt || task.description || task.id}`;
    const embedding = stubEmbedding(taskText);

    for (const [existingId, existingEmb] of this._dedupRegistry) {
      const sim = cosineSimilarity(embedding, existingEmb);
      if (sim > DEDUP_THRESHOLD) {
        return {
          queued:   false,
          pool,
          priority,
          reason:   `Duplicate of task ${existingId} (similarity=${sim.toFixed(4)})`,
        };
      }
    }

    this._dedupRegistry.set(task.id, embedding);

    // Check system pressure
    const systemPressure = this.getSystemPressure();
    if (systemPressure === PRESSURE.CRITICAL && priority < 0.5) {
      this._shedLowPriorityTasks(pool);
      this._notifyCriticalPressure(pool);
      return {
        queued:   false,
        pool,
        priority,
        reason:   'CRITICAL pressure — low-priority task shed',
      };
    }

    const poolState = this._pools.get(pool);
    if (!poolState) throw new Error(`Unknown pool: ${pool}`);

    // Queue overflow protection
    if (poolState.queue.length >= poolState.maxQueueDepth) {
      return {
        queued:  false,
        pool,
        priority,
        reason: `Queue depth limit reached (${poolState.maxQueueDepth})`,
      };
    }

    // Insert in priority order (highest first)
    const insertIdx = poolState.queue.findIndex(t => (t._priority ?? 0) < priority);
    if (insertIdx === -1) {
      poolState.queue.push(task);
    } else {
      poolState.queue.splice(insertIdx, 0, task);
    }

    this._taskMeta.set(task.id, {
      id:            task.id,
      pool,
      priority,
      queuedAt:      Date.now(),
      startedAt:     null,
      completedAt:   null,
      status:        'QUEUED',
    });

    return { queued: true, pool, priority };
  }

  // ── Execution Engine ───────────────────────────────────────────────────────

  /**
   * Default no-op task executor (stub).
   * Replace via config.taskExecutor for real workloads.
   *
   * @private
   * @param {object} task
   * @returns {Promise<object>}
   */
  async _defaultExecutor(task) {
    // Simulate work proportional to task complexity
    const duration = Math.round((task.complexity ?? 0.5) * 200 + 50);
    await new Promise(resolve => setTimeout(resolve, duration));
    return { taskId: task.id, status: 'ok', simulatedMs: duration };
  }

  /**
   * Execute a task: pull from pool, run with phi-timeout, phi-backoff retry.
   * Uses the pool's circuit breaker to gate execution.
   *
   * @param {object} task - Task descriptor (must already be classified)
   * @returns {Promise<object>} Execution result
   * @throws {Error} On unrecoverable failure after phi-backoff retries
   */
  async executeTask(task) {
    const poolName = task._pool ?? this.classifyTask(task).pool;
    const pool     = this._pools.get(poolName);
    if (!pool) throw new Error(`Unknown pool: ${poolName}`);

    const meta = this._taskMeta.get(task.id) ?? {};
    meta.startedAt = Date.now();
    meta.status    = 'RUNNING';
    this._taskMeta.set(task.id, meta);

    pool.currentLoad++;

    const maxRetries = fib(3); // 2 retries
    let lastError;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      if (!pool.circuitBreaker.isAllowing()) {
        pool.currentLoad = Math.max(0, pool.currentLoad - 1);
        throw new Error(`Circuit breaker OPEN for pool "${poolName}"`);
      }

      try {
        const result = await this._withTimeout(
          this._config.taskExecutor(task),
          pool.timeout,
          `Task ${task.id} timed out after ${pool.timeout}ms`
        );

        pool.circuitBreaker.recordSuccess();
        pool.totalExecuted++;
        const elapsed = Date.now() - meta.startedAt;
        pool.latencySum += elapsed;
        pool.healthScore = Math.min(1, pool.healthScore + (1 - pool.healthScore) * PSI * PSI);

        meta.completedAt = Date.now();
        meta.status      = 'COMPLETED';
        this._taskMeta.set(task.id, meta);

        this._completionHistory.push({ taskId: task.id, pool: poolName, elapsed, at: Date.now() });
        if (this._completionHistory.length > 200) this._completionHistory.shift();

        this._dedupRegistry.delete(task.id);
        pool.currentLoad = Math.max(0, pool.currentLoad - 1);

        if (this._config.onTaskComplete) this._config.onTaskComplete(task, result);
        return result;

      } catch (err) {
        lastError = err;

        if (err.message.includes('timed out')) {
          pool.totalTimedOut++;
        } else {
          pool.totalFailed++;
        }

        pool.circuitBreaker.recordFailure();
        pool.healthScore = Math.max(0, pool.healthScore - PSI * PSI * PSI);

        if (attempt < maxRetries) {
          const delay = phiBackoff(attempt, 500, 30000);
          await new Promise(resolve => setTimeout(resolve, delay));
        }
      }
    }

    pool.currentLoad = Math.max(0, pool.currentLoad - 1);
    meta.status = 'FAILED';
    this._taskMeta.set(task.id, meta);
    this._dedupRegistry.delete(task.id);

    if (this._config.onTaskFail) this._config.onTaskFail(task, lastError);
    throw lastError;
  }

  /**
   * Wrap a promise with a hard timeout.
   *
   * @private
   * @param {Promise<any>} promise - Promise to race
   * @param {number}  ms           - Timeout in ms
   * @param {string}  message      - Error message on timeout
   * @returns {Promise<any>}
   */
  _withTimeout(promise, ms, message) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(message)), ms);
      promise.then(
        result => { clearTimeout(timer); resolve(result); },
        err    => { clearTimeout(timer); reject(err);    }
      );
    });
  }

  // ── Backpressure Management ─────────────────────────────────────────────────

  /**
   * Determine the current pressure level of a pool.
   *
   * @param {string} poolName - Pool name
   * @returns {'NOMINAL'|'ELEVATED'|'HIGH'|'CRITICAL'}
   */
  getPoolPressureLevel(poolName) {
    const p = this.getPoolPressure(poolName);
    if (p < PRESSURE_LEVELS.NOMINAL_MAX)  return PRESSURE.NOMINAL;
    if (p < PRESSURE_LEVELS.ELEVATED_MAX) return PRESSURE.ELEVATED;
    if (p < PRESSURE_LEVELS.HIGH_MAX)     return PRESSURE.HIGH;
    return PRESSURE.CRITICAL;
  }

  /**
   * Returns the aggregate system pressure level (worst across all pools).
   *
   * @returns {'NOMINAL'|'ELEVATED'|'HIGH'|'CRITICAL'}
   */
  getSystemPressure() {
    const levels = [PRESSURE.NOMINAL, PRESSURE.ELEVATED, PRESSURE.HIGH, PRESSURE.CRITICAL];
    let worst = 0;
    for (const name of POOL_NAMES) {
      const lvl = this.getPoolPressureLevel(name);
      const idx = levels.indexOf(lvl);
      if (idx > worst) worst = idx;
    }
    return levels[worst];
  }

  /**
   * Shed low-priority tasks from a pool when CRITICAL pressure is detected.
   * Tasks with priority below PSI*PSI (≈0.382) are removed from the queue.
   *
   * @private
   * @param {string} poolName - Pool to shed from
   */
  _shedLowPriorityTasks(poolName) {
    const pool = this._pools.get(poolName);
    if (!pool) return;
    const before = pool.queue.length;
    pool.queue = pool.queue.filter(t => (t._priority ?? 0) >= PSI * PSI);
    const shed = before - pool.queue.length;
    if (shed > 0) {
      // Mark shed tasks in meta
      pool.queue.forEach(t => {
        const m = this._taskMeta.get(t.id);
        if (m && m.status === 'QUEUED') {
          m.status = 'SHED';
          this._taskMeta.set(t.id, m);
        }
      });
    }
  }

  /**
   * Notify the HeadyConductor of a critical pressure event.
   * @private
   * @param {string} poolName
   */
  _notifyCriticalPressure(poolName) {
    if (this._config.onCriticalPressure) {
      this._config.onCriticalPressure({
        pool:     poolName,
        pressure: this.getPoolPressure(poolName),
        level:    PRESSURE.CRITICAL,
        at:       new Date().toISOString(),
      });
    }
  }

  // ── Adaptive Scheduling ─────────────────────────────────────────────────────

  /**
   * Start the adaptive scheduler.
   * Monitors pools, drains queues, triggers rebalancing, and schedules
   * maintenance tasks in the Cold pool during low-load periods.
   */
  start() {
    if (this._running) return;
    this._running = true;

    // Main drain loop — uses phi-adaptive interval based on system health
    const drainLoop = () => {
      if (!this._running) return;
      this._drainQueues();
      const health       = this._computeOverallHealth();
      const nextInterval = phiAdaptiveInterval(this._config.baseIntervalMs, health);
      this._timers.drain = setTimeout(drainLoop, Math.round(nextInterval));
    };
    drainLoop();

    // Rebalance loop
    const rebalanceLoop = () => {
      if (!this._running) return;
      this.rebalancePools();
      this._timers.rebalance = setTimeout(rebalanceLoop, this._config.rebalanceIntervalMs);
    };
    rebalanceLoop();

    // Maintenance scheduling — runs during low-load periods
    const maintenanceLoop = () => {
      if (!this._running) return;
      const sysPress = this.getSystemPressure();
      if (sysPress === PRESSURE.NOMINAL) {
        this._scheduleMaintenanceTasks();
      }
      this._timers.maintenance = setTimeout(maintenanceLoop, phiTimeout(8)); // ≈47s
    };
    maintenanceLoop();
  }

  /** Stop the adaptive scheduler and clear all timers. */
  stop() {
    this._running = false;
    for (const handle of Object.values(this._timers)) {
      clearTimeout(handle);
    }
    this._timers = {};
  }

  /**
   * Drain pending tasks from all pool queues by dispatching ready tasks.
   * @private
   */
  _drainQueues() {
    for (const name of POOL_NAMES) {
      const pool = this._pools.get(name);
      while (pool.queue.length > 0 && pool.currentLoad < pool.maxConcurrency) {
        const task = pool.queue.shift();
        if (!task) break;
        // Fire-and-forget; errors are captured inside executeTask
        this.executeTask(task).catch(() => {});
      }
    }
  }

  /**
   * Schedule maintenance tasks into the Cold pool.
   * Maintenance tasks are given minimum priority so they don't block user work.
   * @private
   */
  _scheduleMaintenanceTasks() {
    const tasks = [
      { id: `maint-gc-${Date.now()}`,      type: 'cleanup',     priority: 0.1, description: 'garbage-collection' },
      { id: `maint-audit-${Date.now()}`,   type: 'analytics',   priority: 0.1, description: 'metric-audit' },
      { id: `maint-health-${Date.now()}`,  type: 'maintenance', priority: 0.1, description: 'pool-health-check' },
    ];
    for (const t of tasks) {
      t._priority = t.priority;
      t._pool     = 'cold';
      const pool  = this._pools.get('cold');
      if (pool.queue.length < pool.maxQueueDepth - 3) {
        pool.queue.push(t);
      }
    }
  }

  /**
   * Compute an overall health score across all pools (weighted by pool weight).
   * @private
   * @returns {number} Weighted health score in [0, 1]
   */
  _computeOverallHealth() {
    let total = 0;
    let weightSum = 0;
    for (const name of POOL_NAMES) {
      const pool = this._pools.get(name);
      const w    = POOL_WEIGHTS[name] ?? 0.1;
      total     += pool.healthScore * w;
      weightSum += w;
    }
    return weightSum > 0 ? total / weightSum : 1;
  }

  // ── Observability ──────────────────────────────────────────────────────────

  /**
   * Returns metrics snapshots for all pools.
   *
   * @returns {object} Keyed by pool name
   */
  getPoolStatus() {
    const status = {};
    for (const [name, pool] of this._pools) {
      status[name] = pool.getMetrics();
    }
    return status;
  }

  /**
   * Returns the current aggregate system pressure descriptor.
   *
   * @returns {{ level: string, perPool: object, overallPressure: number }}
   */
  getSystemPressureReport() {
    const perPool = {};
    let maxP = 0;
    for (const name of POOL_NAMES) {
      const p = this.getPoolPressure(name);
      perPool[name] = { pressure: +p.toFixed(4), level: this.getPoolPressureLevel(name) };
      if (p > maxP) maxP = p;
    }
    return {
      level:           this.getSystemPressure(),
      overallPressure: +maxP.toFixed(4),
      perPool,
    };
  }

  /**
   * Returns task execution statistics across all known tasks.
   *
   * @returns {{ total: number, completed: number, failed: number, shed: number, queued: number, running: number, avgLatencyMs: number }}
   */
  getTaskMetrics() {
    let total = 0, completed = 0, failed = 0, shed = 0, queued = 0, running = 0;
    let latencySum = 0, latencyCount = 0;

    for (const meta of this._taskMeta.values()) {
      total++;
      switch (meta.status) {
        case 'COMPLETED': completed++; break;
        case 'FAILED':    failed++;    break;
        case 'SHED':      shed++;      break;
        case 'QUEUED':    queued++;    break;
        case 'RUNNING':   running++;   break;
      }
      if (meta.completedAt && meta.startedAt) {
        latencySum += (meta.completedAt - meta.startedAt);
        latencyCount++;
      }
    }

    return {
      total,
      completed,
      failed,
      shed,
      queued,
      running,
      avgLatencyMs: latencyCount > 0 ? +(latencySum / latencyCount).toFixed(2) : 0,
    };
  }

  /**
   * Returns a full system health report.
   *
   * @returns {object} Comprehensive health snapshot
   */
  healthCheck() {
    const pools          = this.getPoolStatus();
    const pressure       = this.getSystemPressureReport();
    const tasks          = this.getTaskMetrics();
    const overallHealth  = this._computeOverallHealth();

    const circuitBreakersSummary = {};
    for (const [name, pool] of this._pools) {
      circuitBreakersSummary[name] = pool.circuitBreaker.getStatus();
    }

    return {
      status:          overallHealth > CSL_THRESHOLDS.MEDIUM ? 'HEALTHY' : 'DEGRADED',
      overallHealth:   +overallHealth.toFixed(4),
      systemPressure:  pressure.level,
      pools,
      pressure,
      tasks,
      circuitBreakers: circuitBreakersSummary,
      dedupRegistrySize: this._dedupRegistry.size,
      recentCompletions: this._completionHistory.slice(-10),
      schedulerRunning: this._running,
      poolWeights:     POOL_WEIGHTS,
      poolTimeouts:    POOL_TIMEOUTS,
      fibConcurrency:  POOL_FIB_CONCURRENCY,
      prewarmSizes:    PREWARM_SIZES,
      thresholds: {
        psi:                PSI,
        cbFailureThreshold: CB_FAILURE_THRESHOLD,
        cbHalfOpenDelayMs:  CB_HALF_OPEN_DELAY,
        dedupThreshold:     DEDUP_THRESHOLD,
        pressureLevels:     PRESSURE_LEVELS,
      },
      generatedAt: new Date().toISOString(),
    };
  }

  // ── Pool Allocation Reference ──────────────────────────────────────────────

  /**
   * Returns phi-resource pool allocation weights.
   *
   * @returns {{ hot: number, warm: number, cold: number, reserve: number, governance: number }}
   */
  getPoolAllocation() {
    return { ...POOL_WEIGHTS };
  }

  // ── Semantic Deduplication ─────────────────────────────────────────────────

  /**
   * Check if a task would be considered a duplicate of an already-tracked task.
   *
   * @param {object} task - Task with `id`, `type`, and optional `prompt`/`description`
   * @returns {{ isDuplicate: boolean, matchId?: string, similarity?: number }}
   */
  checkDuplicate(task) {
    const text = `${task.type || ''} ${task.prompt || task.description || task.id}`;
    const emb  = stubEmbedding(text);
    for (const [existingId, existingEmb] of this._dedupRegistry) {
      const sim = cosineSimilarity(emb, existingEmb);
      if (sim > DEDUP_THRESHOLD) {
        return { isDuplicate: true, matchId: existingId, similarity: +sim.toFixed(4) };
      }
    }
    return { isDuplicate: false };
  }

  // ── Priority Inspection ────────────────────────────────────────────────────

  /**
   * Recompute and reorder the priority queue for a given pool.
   * Useful after bulk task ingestion.
   *
   * @param {string} poolName - Pool to sort
   */
  reorderQueue(poolName) {
    const pool = this._pools.get(poolName);
    if (!pool) throw new Error(`Unknown pool: ${poolName}`);
    pool.queue.sort((a, b) => (b._priority ?? 0) - (a._priority ?? 0));
  }

  /**
   * Drain and return all queued tasks from a pool without executing them.
   * Useful for graceful shutdown or load shedding.
   *
   * @param {string} poolName - Target pool
   * @returns {object[]} Drained task objects
   */
  drainPool(poolName) {
    const pool = this._pools.get(poolName);
    if (!pool) throw new Error(`Unknown pool: ${poolName}`);
    const tasks = [...pool.queue];
    pool.queue = [];
    return tasks;
  }

  // ── Static helpers (exposed for external use) ──────────────────────────────

  /**
   * Return the phi-timeout value for a given exponent.
   * @param {number} n - Exponent
   * @returns {number} Timeout ms
   */
  static phiTimeout(n) {
    return phiTimeout(n);
  }

  /**
   * Snap a concurrency value to the nearest valid Fibonacci step.
   * @param {number} value
   * @returns {number}
   */
  static snapToFibonacci(value) {
    return snapToFibonacci(value);
  }
}

// ── Module Export ─────────────────────────────────────────────────────────────

module.exports = {
  LiquidOrchestrator,
  CircuitBreaker,
  PoolState,
  POOL_NAMES,
  POOL_WEIGHTS,
  POOL_TIMEOUTS,
  POOL_FIB_CONCURRENCY,
  POOL_FIB_QUEUE_DEPTH,
  DOMAIN_POOL_MAP,
  PRESSURE,
  PRESSURE_LEVELS,
  CB_FAILURE_THRESHOLD,
  CB_HALF_OPEN_DELAY,
  PREWARM_SIZES,
  phiTimeout,
  snapToFibonacci,
  stubEmbedding,
};
