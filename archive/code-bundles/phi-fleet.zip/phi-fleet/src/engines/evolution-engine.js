'use strict';

/**
 * evolution-engine.js
 * Stage 19 (EVOLUTION) of the HCFullPipeline.
 *
 * Controlled mutation of pipeline parameters with fitness-based selection.
 * Implements the full mutate → test → measure → promote/discard cycle.
 * The system EVOLVES — it does not merely optimize, it transforms.
 *
 * All numeric constants are phi-derived via phi-math-v2:
 *   mutationRate          0.0618   (1/φ / 10)
 *   populationSize        8        (fib(6))
 *   maxMutationMagnitude  0.13     (fib(7)/100)
 *   rollbackThreshold     0.05     (fib(5)/100)
 *   approvalThreshold     0.08     (fib(6)/100)
 *   generationsPerDay     3        (fib(4))
 *   survivorCount         5        (fib(5))
 *
 * Fitness weights (sum ≈ 1.0):
 *   latency    0.34
 *   cost       0.21
 *   quality    0.21
 *   reliability 0.13
 *   elegance   0.11
 *
 * Immutable parameters (NEVER mutated):
 *   phi_constant, fibonacci_sequence, csl_gate_math, security_policies
 *
 * @module evolution-engine
 * @version 1.0.0
 * @see hcfullpipeline.yaml §evolution (Stage 12 / Pipeline Stage 19)
 */

const {
  PHI,
  PSI,
  PHI_SQ,
  PHI_CB,
  fib,
  phiThreshold,
  phiBackoff,
  CSL_THRESHOLDS,
  phiFusionWeights,
  cosineSimilarity,
  cslGate,
  fibNearest: nearestFib,
  phiResourceWeights,
} = require('../../shared/phi-math-v2');

// ─────────────────────────────────────────────────────────────────────────────
// MODULE-LEVEL PHI-DERIVED CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────

/** Conservative mutation rate: 1/φ / 10 ≈ 0.0618 */
const MUTATION_RATE = PSI / 10;

/** Maximum candidates per generation: fib(6) = 8 */
const POPULATION_SIZE = fib(6);

/** Maximum magnitude of a single mutation: fib(7)/100 = 0.13 */
const MAX_MUTATION_MAGNITUDE = fib(7) / 100;

/** Auto-rollback threshold — regression above this triggers automatic revert: fib(5)/100 = 0.05 */
const ROLLBACK_ON_REGRESSION_ABOVE = fib(5) / 100;

/** Human approval required for changes above this magnitude: fib(6)/100 = 0.08 */
const REQUIRES_APPROVAL_ABOVE = fib(6) / 100;

/** Maximum evolution cycles per day: fib(4) = 3 */
const GENERATIONS_PER_DAY = fib(4);

/** Number of survivors kept after tournament selection: fib(5) = 5 */
const SURVIVOR_COUNT = fib(5);

/**
 * Fitness dimension weights — phi-weighted composite.
 * Sum = 1.00 (latency+cost+quality+reliability+elegance).
 * These are prescribed by the YAML evolution config.
 */
const FITNESS_WEIGHTS = Object.freeze({
  latency:     0.34,
  cost:        0.21,
  quality:     0.21,
  reliability: 0.13,
  elegance:    0.11,
});

/**
 * Parameters that may NEVER be mutated under any circumstances.
 * @type {ReadonlySet<string>}
 */
const IMMUTABLE_PARAMS = Object.freeze(new Set([
  'phi_constant',
  'fibonacci_sequence',
  'csl_gate_math',
  'security_policies',
]));

/** Minimum acceptable composite fitness score: CSL_THRESHOLDS.LOW ≈ 0.691 */
const MINIMUM_FITNESS_BAR = CSL_THRESHOLDS.LOW;

/**
 * PSI² used in threshold mutations: ≈ 0.382
 * Represents ψ² — the "conjugate squared" phi constant.
 */
const PSI_SQ = PSI * PSI;

// ─────────────────────────────────────────────────────────────────────────────
// MUTATION STATUS ENUM
// ─────────────────────────────────────────────────────────────────────────────

/**
 * All possible lifecycle states for a Mutation.
 * @readonly
 * @enum {string}
 */
const MutationStatus = Object.freeze({
  PROPOSED:    'proposed',
  TESTING:     'testing',
  PROMOTED:    'promoted',
  DISCARDED:   'discarded',
  ROLLED_BACK: 'rolledBack',
});

// ─────────────────────────────────────────────────────────────────────────────
// UTILITY HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Generates a deterministic-ish ID string for a mutation.
 * Format: `mut_<generation>_<timestamp_hex>_<random_hex>`
 *
 * @param {number} generation - The generation number
 * @returns {string} Unique mutation ID
 */
function _generateMutationId(generation) {
  const ts = Date.now().toString(16);
  const rnd = Math.floor(Math.random() * 0xFFFFFF).toString(16).padStart(6, '0');
  return `mut_g${generation}_${ts}_${rnd}`;
}

/**
 * Clamps a value to [min, max].
 *
 * @param {number} value
 * @param {number} min
 * @param {number} max
 * @returns {number}
 */
function _clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

/**
 * Returns the number of evolution cycles that have occurred today
 * within a given history array.
 *
 * @param {GenerationRecord[]} history - Full evolution history
 * @returns {number} Count of generations today
 */
function _generationsToday(history) {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  return history.filter(r => r.timestamp >= todayStart).length;
}

// ─────────────────────────────────────────────────────────────────────────────
// MUTATION CLASS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @typedef {Object} FitnessScores
 * @property {number} latency      - Latency improvement score [0, 1]
 * @property {number} cost         - Cost reduction score [0, 1]
 * @property {number} quality      - Quality improvement score [0, 1]
 * @property {number} reliability  - Reliability improvement score [0, 1]
 * @property {number} elegance     - Elegance/phi-alignment score [0, 1]
 * @property {number} composite    - Phi-weighted composite of all dimensions
 */

/**
 * Represents a single parameter mutation — the atomic unit of evolution.
 *
 * A Mutation captures the complete before/after state of a parameter change,
 * its measured fitness across all dimensions, and its lifecycle status.
 *
 * @class Mutation
 */
class Mutation {
  /**
   * Creates a new Mutation.
   *
   * @param {Object} opts
   * @param {string} opts.id             - Unique mutation identifier
   * @param {number} opts.generation     - Generation number this mutation belongs to
   * @param {string} opts.parameter      - Dot-path of the mutated parameter
   * @param {*}      opts.originalValue  - The value before mutation
   * @param {*}      opts.mutatedValue   - The proposed new value
   * @param {number} opts.magnitude      - Fractional magnitude of change (0–1)
   * @param {string} [opts.paramType]    - Semantic type: 'threshold'|'timing'|'pool'|'parameter'
   * @param {string} [opts.notes]        - Free-text notes on why this mutation was generated
   */
  constructor({
    id,
    generation,
    parameter,
    originalValue,
    mutatedValue,
    magnitude,
    paramType = 'parameter',
    notes = '',
  }) {
    /** @type {string} */
    this.id = id;

    /** @type {number} Unix timestamp (ms) when this mutation was created */
    this.timestamp = Date.now();

    /** @type {number} */
    this.generation = generation;

    /** @type {string} Dot-notation path of the mutated config parameter */
    this.parameter = parameter;

    /** @type {*} */
    this.originalValue = originalValue;

    /** @type {*} */
    this.mutatedValue = mutatedValue;

    /**
     * Fractional magnitude of the change, always in [0, MAX_MUTATION_MAGNITUDE].
     * e.g., 0.05 means the value changed by 5%.
     * @type {number}
     */
    this.magnitude = _clamp(Math.abs(magnitude), 0, MAX_MUTATION_MAGNITUDE);

    /** @type {string} */
    this.paramType = paramType;

    /** @type {string} */
    this.notes = notes;

    /**
     * Measured fitness scores across all dimensions.
     * Populated after simulation/measurement.
     * @type {FitnessScores|null}
     */
    this.fitness = null;

    /**
     * Whether this mutation requires human approval before promotion.
     * Set to true if magnitude > REQUIRES_APPROVAL_ABOVE.
     * @type {boolean}
     */
    this.requiresApproval = this.magnitude > REQUIRES_APPROVAL_ABOVE;

    /**
     * Whether human approval has been granted (only relevant when requiresApproval is true).
     * @type {boolean}
     */
    this.approvalGranted = false;

    /**
     * Lifecycle status of this mutation.
     * @type {string}
     */
    this.status = MutationStatus.PROPOSED;

    /**
     * ISO timestamp when status last changed.
     * @type {string|null}
     */
    this.statusChangedAt = null;

    /**
     * Optional error message if something went wrong during evaluation.
     * @type {string|null}
     */
    this.errorMessage = null;
  }

  /**
   * Transitions this mutation to a new status.
   * Records a statusChangedAt timestamp.
   *
   * @param {string} newStatus - One of MutationStatus values
   * @returns {Mutation} this (for chaining)
   */
  transitionTo(newStatus) {
    this.status = newStatus;
    this.statusChangedAt = new Date().toISOString();
    return this;
  }

  /**
   * Returns a plain-object snapshot of this mutation for logging.
   *
   * @returns {Object}
   */
  toRecord() {
    return {
      id:              this.id,
      timestamp:       this.timestamp,
      generation:      this.generation,
      parameter:       this.parameter,
      paramType:       this.paramType,
      originalValue:   this.originalValue,
      mutatedValue:    this.mutatedValue,
      magnitude:       this.magnitude,
      fitness:         this.fitness,
      status:          this.status,
      requiresApproval: this.requiresApproval,
      approvalGranted: this.approvalGranted,
      notes:           this.notes,
      statusChangedAt: this.statusChangedAt,
      errorMessage:    this.errorMessage,
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// GENERATION RECORD TYPE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @typedef {Object} GenerationRecord
 * @property {number}   generation          - Sequential generation index
 * @property {number}   timestamp           - Unix timestamp (ms) when this generation ran
 * @property {Object[]} candidates          - All Mutation records evaluated this generation
 * @property {Object|null} winner           - The promoted Mutation record, or null
 * @property {number|null} fitnessImprovement - Composite fitness delta vs baseline (null if no winner)
 * @property {string[]} promotedParameters  - Parameter paths that were changed this generation
 */

// ─────────────────────────────────────────────────────────────────────────────
// FITNESS EVALUATOR
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Evaluates and compares fitness scores for mutations.
 *
 * Uses the phi-weighted composite defined in the YAML evolution config:
 *   latency×0.34 + cost×0.21 + quality×0.21 + reliability×0.13 + elegance×0.11
 *
 * @class FitnessEvaluator
 */
class FitnessEvaluator {
  /**
   * Creates a FitnessEvaluator.
   *
   * @param {Object} [config={}] - Optional weight overrides
   * @param {number} [config.latencyWeight=0.34]
   * @param {number} [config.costWeight=0.21]
   * @param {number} [config.qualityWeight=0.21]
   * @param {number} [config.reliabilityWeight=0.13]
   * @param {number} [config.eleganceWeight=0.11]
   * @param {number} [config.minimumBar=CSL_THRESHOLDS.LOW]
   */
  constructor(config = {}) {
    this.weights = {
      latency:     config.latencyWeight     ?? FITNESS_WEIGHTS.latency,
      cost:        config.costWeight        ?? FITNESS_WEIGHTS.cost,
      quality:     config.qualityWeight     ?? FITNESS_WEIGHTS.quality,
      reliability: config.reliabilityWeight ?? FITNESS_WEIGHTS.reliability,
      elegance:    config.eleganceWeight    ?? FITNESS_WEIGHTS.elegance,
    };
    this.minimumBar = config.minimumBar ?? MINIMUM_FITNESS_BAR;
  }

  /**
   * Computes the phi-weighted composite fitness score from raw dimension metrics.
   *
   * All input dimension scores should be in [0, 1] where 1 = perfect improvement.
   * The composite is the weighted sum: Σ(weight_i × score_i).
   *
   * @param {Object} metrics - Raw metric scores
   * @param {number} [metrics.latency=0]     - Latency improvement score [0, 1]
   * @param {number} [metrics.cost=0]        - Cost reduction score [0, 1]
   * @param {number} [metrics.quality=0]     - Quality improvement score [0, 1]
   * @param {number} [metrics.reliability=0] - Reliability improvement score [0, 1]
   * @param {number} [metrics.elegance=0]    - Elegance/phi-alignment score [0, 1]
   * @returns {FitnessScores} Full fitness breakdown including composite
   */
  computeComposite(metrics) {
    const latency     = _clamp(metrics.latency     ?? 0, 0, 1);
    const cost        = _clamp(metrics.cost        ?? 0, 0, 1);
    const quality     = _clamp(metrics.quality     ?? 0, 0, 1);
    const reliability = _clamp(metrics.reliability ?? 0, 0, 1);
    const elegance    = _clamp(metrics.elegance    ?? 0, 0, 1);

    const composite =
      latency     * this.weights.latency     +
      cost        * this.weights.cost        +
      quality     * this.weights.quality     +
      reliability * this.weights.reliability +
      elegance    * this.weights.elegance;

    return {
      latency,
      cost,
      quality,
      reliability,
      elegance,
      composite: _clamp(composite, 0, 1),
    };
  }

  /**
   * Compares mutated fitness against baseline and returns the improvement ratio.
   *
   * Positive values indicate improvement; negative values indicate regression.
   * For example: 0.05 means the composite fitness improved by 5%.
   *
   * @param {FitnessScores} mutated   - Fitness scores for the mutated config
   * @param {FitnessScores} baseline  - Fitness scores for the current baseline
   * @returns {number} Signed improvement ratio (mutated.composite − baseline.composite)
   */
  compareFitness(mutated, baseline) {
    if (!mutated  || typeof mutated.composite  !== 'number') return -1;
    if (!baseline || typeof baseline.composite !== 'number') return 0;
    return mutated.composite - baseline.composite;
  }

  /**
   * Returns true if the given fitness scores exceed the minimum acceptable bar.
   * Minimum bar = CSL_THRESHOLDS.LOW ≈ 0.691.
   *
   * @param {FitnessScores} fitness - Fitness scores to evaluate
   * @returns {boolean}
   */
  meetsMinimumBar(fitness) {
    if (!fitness || typeof fitness.composite !== 'number') return false;
    return fitness.composite >= this.minimumBar;
  }

  /**
   * Returns the CSL tier classification for a given composite score.
   * Maps to MINIMUM / LOW / MEDIUM / HIGH / CRITICAL from phi-math-v2.
   *
   * @param {number} composite - Composite fitness score in [0, 1]
   * @returns {string} One of: 'MINIMUM' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
   */
  classifyFitnessTier(composite) {
    if (composite >= CSL_THRESHOLDS.CRITICAL) return 'CRITICAL';
    if (composite >= CSL_THRESHOLDS.HIGH)     return 'HIGH';
    if (composite >= CSL_THRESHOLDS.MEDIUM)   return 'MEDIUM';
    if (composite >= CSL_THRESHOLDS.LOW)      return 'LOW';
    return 'MINIMUM';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MUTATION GENERATOR
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Generates candidate mutations for a given configuration.
 *
 * All mutations are bounded by MAX_MUTATION_MAGNITUDE (13%) and never touch
 * immutable parameters. Random perturbation scales are phi-derived.
 *
 * @class MutationGenerator
 */
class MutationGenerator {
  /**
   * Creates a MutationGenerator.
   *
   * @param {Object} [config={}]
   * @param {number} [config.mutationRate=MUTATION_RATE]             - Base rate of change
   * @param {number} [config.maxMagnitude=MAX_MUTATION_MAGNITUDE]    - Maximum fractional change
   * @param {Set<string>} [config.immutableParams=IMMUTABLE_PARAMS]  - Parameter names that must not change
   */
  constructor(config = {}) {
    this.mutationRate  = config.mutationRate  ?? MUTATION_RATE;
    this.maxMagnitude  = config.maxMagnitude  ?? MAX_MUTATION_MAGNITUDE;
    this.immutableSet  = config.immutableParams ?? IMMUTABLE_PARAMS;
  }

  /**
   * Checks whether a parameter is immutable and must not be mutated.
   *
   * The check tests the final segment of a dot-path against the immutable set,
   * and also tests the full path, to handle both top-level keys and nested paths.
   *
   * @param {string} paramName - Parameter name or dot-path
   * @returns {boolean} True if immutable
   */
  isImmutable(paramName) {
    if (this.immutableSet.has(paramName)) return true;
    // Also check the leaf key (last segment of dot-path)
    const leaf = paramName.split('.').pop();
    return this.immutableSet.has(leaf);
  }

  /**
   * Generates a numeric parameter mutation using a scaled random walk.
   * The perturbation = currentValue × U(-1, 1) × mutationRate × maxMagnitude,
   * clamped so the final |delta / currentValue| ≤ maxMagnitude.
   *
   * @param {string} param        - Parameter dot-path
   * @param {number} currentValue - Current numeric value
   * @param {number} generation   - Current generation number
   * @returns {Mutation|null} The proposed Mutation, or null if immutable / non-numeric
   */
  generateParameterMutation(param, currentValue, generation) {
    if (this.isImmutable(param)) return null;
    if (typeof currentValue !== 'number' || !isFinite(currentValue)) return null;

    // Random direction and magnitude, scaled by phi mutation rate
    const direction = Math.random() > 0.5 ? 1 : -1;
    const scaleFactor = Math.random() * this.mutationRate; // 0..MUTATION_RATE
    const delta = currentValue * direction * scaleFactor;
    const mutatedValue = currentValue + delta;

    // Compute fractional magnitude
    const magnitude = currentValue !== 0
      ? Math.abs(delta / currentValue)
      : Math.abs(delta);

    const clampedMagnitude = _clamp(magnitude, 0, this.maxMagnitude);

    // Re-clamp the actual mutated value to respect maxMagnitude
    const clampedDelta = currentValue * (direction * clampedMagnitude);
    const finalValue = currentValue + clampedDelta;

    return new Mutation({
      id:            _generateMutationId(generation),
      generation,
      parameter:     param,
      originalValue: currentValue,
      mutatedValue:  finalValue,
      magnitude:     clampedMagnitude,
      paramType:     'parameter',
      notes:         `Random walk mutation at rate ${this.mutationRate.toFixed(6)}`,
    });
  }

  /**
   * Generates a threshold mutation, adjusting by ±ψ² × currentValue × mutationRate.
   *
   * Threshold parameters (CSL scores, similarity thresholds) are adjusted using
   * the ψ² (≈ 0.382) scaling factor for phi-harmonic perturbations.
   *
   * @param {string} param     - Threshold parameter dot-path
   * @param {number} threshold - Current threshold value (must be in [0, 1])
   * @param {number} generation - Current generation number
   * @returns {Mutation|null}
   */
  generateThresholdMutation(param, threshold, generation) {
    if (this.isImmutable(param)) return null;
    if (typeof threshold !== 'number' || threshold < 0 || threshold > 1) return null;

    // ±ψ² × currentValue × mutationRate
    const direction = Math.random() > 0.5 ? 1 : -1;
    const delta = PSI_SQ * threshold * this.mutationRate * direction;
    const mutatedValue = _clamp(threshold + delta, 0, 1);
    const magnitude = threshold !== 0 ? Math.abs(delta / threshold) : Math.abs(delta);

    return new Mutation({
      id:            _generateMutationId(generation),
      generation,
      parameter:     param,
      originalValue: threshold,
      mutatedValue,
      magnitude:     _clamp(magnitude, 0, this.maxMagnitude),
      paramType:     'threshold',
      notes:         `Threshold mutation via ψ²=${PSI_SQ.toFixed(6)} scaling`,
    });
  }

  /**
   * Generates a timing mutation by scaling a timing value by a random phi power.
   *
   * Timing values (intervals, timeouts, delays) are scaled by PHI^k where k is
   * drawn uniformly from {-1, +1}, producing a golden-ratio step up or down.
   * The magnitude is bounded by maxMagnitude.
   *
   * @param {string} param   - Timing parameter dot-path (e.g. 'retryDelayMs')
   * @param {number} timing  - Current timing value in milliseconds
   * @param {number} generation - Current generation number
   * @returns {Mutation|null}
   */
  generateTimingMutation(param, timing, generation) {
    if (this.isImmutable(param)) return null;
    if (typeof timing !== 'number' || timing <= 0) return null;

    // Choose phi power: -1 or +1 (scale down by ψ or up by φ)
    const exponent = Math.random() > 0.5 ? 1 : -1;
    const scaledRaw = timing * Math.pow(PHI, exponent);
    const delta = scaledRaw - timing;
    const magnitude = Math.abs(delta / timing);

    // Clamp to maxMagnitude
    const clampedMag = _clamp(magnitude, 0, this.maxMagnitude);
    const clampedDelta = timing * clampedMag * (exponent > 0 ? 1 : -1);
    const mutatedValue = Math.max(1, Math.round(timing + clampedDelta));

    return new Mutation({
      id:            _generateMutationId(generation),
      generation,
      parameter:     param,
      originalValue: timing,
      mutatedValue,
      magnitude:     clampedMag,
      paramType:     'timing',
      notes:         `Phi-power timing mutation (φ^${exponent}), clamped to ${(clampedMag * 100).toFixed(1)}%`,
    });
  }

  /**
   * Generates a pool-configuration mutation by redistributing resource weights
   * using phi-geometric reallocation.
   *
   * The pool config is expected to be an array of numeric allocation values
   * that sum to a whole (e.g., [100, 200, 50] total = 350).
   * The mutation redistributes using phiResourceWeights and injects a small
   * perturbation at a randomly selected bucket.
   *
   * @param {string}   param      - Parameter dot-path for the pool
   * @param {number[]} poolConfig - Array of current numeric allocations
   * @param {number}   generation - Current generation number
   * @returns {Mutation|null}
   */
  generatePoolMutation(param, poolConfig, generation) {
    if (this.isImmutable(param)) return null;
    if (!Array.isArray(poolConfig) || poolConfig.length < 2) return null;
    if (!poolConfig.every(v => typeof v === 'number' && isFinite(v))) return null;

    const total = poolConfig.reduce((s, v) => s + v, 0);
    if (total <= 0) return null;

    const n = poolConfig.length;
    const weights = phiResourceWeights(n);
    const baseAllocations = weights.map(w => w * total);

    // Apply small perturbation to one randomly selected bucket
    const bucketIdx = Math.floor(Math.random() * n);
    const perturbation = total * this.mutationRate * (Math.random() > 0.5 ? 1 : -1);
    const mutatedAllocations = baseAllocations.map((v, i) => {
      if (i === bucketIdx) return Math.max(0, v + perturbation);
      return v;
    });

    // Normalize to preserve total
    const newTotal = mutatedAllocations.reduce((s, v) => s + v, 0);
    const normalizedAllocations = mutatedAllocations.map(v => (v / newTotal) * total);

    // Magnitude = max fractional change across all buckets
    const magnitude = Math.max(
      ...poolConfig.map((orig, i) =>
        orig !== 0 ? Math.abs((normalizedAllocations[i] - orig) / orig) : 0
      )
    );

    return new Mutation({
      id:            _generateMutationId(generation),
      generation,
      parameter:     param,
      originalValue: poolConfig,
      mutatedValue:  normalizedAllocations,
      magnitude:     _clamp(magnitude, 0, this.maxMagnitude),
      paramType:     'pool',
      notes:         `Pool reallocation via phi-resource weights, perturbation at bucket[${bucketIdx}]`,
    });
  }

  /**
   * Generates a batch of diversified mutations for a given configuration object.
   * Walks the config's top-level numeric/array keys and generates one mutation
   * per eligible parameter, then returns up to `count` randomly sampled mutations.
   *
   * Skips immutable keys and non-mutable types (booleans, strings, nested objects
   * unless they are numeric arrays).
   *
   * @param {Object} config     - Current pipeline configuration
   * @param {number} count      - Desired number of candidates (≤ POPULATION_SIZE)
   * @param {number} generation - Current generation index
   * @returns {Mutation[]} Array of candidate mutations (length ≤ count)
   */
  generateBatch(config, count, generation) {
    const safeCount = _clamp(count, 1, POPULATION_SIZE);
    const candidates = [];

    const walk = (obj, prefix) => {
      for (const [key, value] of Object.entries(obj)) {
        const fullPath = prefix ? `${prefix}.${key}` : key;

        if (this.isImmutable(fullPath) || this.isImmutable(key)) continue;

        if (typeof value === 'number' && isFinite(value)) {
          // Detect threshold vs timing vs generic parameter
          const isThreshold = (
            fullPath.toLowerCase().includes('threshold') ||
            fullPath.toLowerCase().includes('score') ||
            fullPath.toLowerCase().includes('rate') ||
            (value >= 0 && value <= 1)
          );
          const isTiming = (
            fullPath.toLowerCase().includes('ms') ||
            fullPath.toLowerCase().includes('interval') ||
            fullPath.toLowerCase().includes('timeout') ||
            fullPath.toLowerCase().includes('delay') ||
            value > 100
          );

          let mut = null;
          if (isThreshold && value >= 0 && value <= 1) {
            mut = this.generateThresholdMutation(fullPath, value, generation);
          } else if (isTiming) {
            mut = this.generateTimingMutation(fullPath, value, generation);
          } else {
            mut = this.generateParameterMutation(fullPath, value, generation);
          }
          if (mut) candidates.push(mut);

        } else if (Array.isArray(value) && value.every(v => typeof v === 'number')) {
          const mut = this.generatePoolMutation(fullPath, value, generation);
          if (mut) candidates.push(mut);

        } else if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
          // Recurse into nested objects (one level deep to avoid runaway expansion)
          if (!prefix) walk(value, fullPath);
        }
      }
    };

    walk(config, '');

    // Shuffle and take the first `safeCount` candidates
    for (let i = candidates.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [candidates[i], candidates[j]] = [candidates[j], candidates[i]];
    }

    return candidates.slice(0, safeCount);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// EVOLUTION ENGINE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @typedef {Object} EvolutionConfig
 * @property {number} [mutationRate=MUTATION_RATE]
 * @property {number} [populationSize=POPULATION_SIZE]
 * @property {number} [maxMutationMagnitude=MAX_MUTATION_MAGNITUDE]
 * @property {number} [rollbackOnRegressionAbove=ROLLBACK_ON_REGRESSION_ABOVE]
 * @property {number} [requiresApprovalAbove=REQUIRES_APPROVAL_ABOVE]
 * @property {number} [generationsPerDay=GENERATIONS_PER_DAY]
 * @property {number} [survivorCount=SURVIVOR_COUNT]
 * @property {Set<string>} [immutableParams=IMMUTABLE_PARAMS]
 * @property {Function} [onMutationProposed]    - Async callback when a mutation is proposed
 * @property {Function} [onMutationPromoted]    - Async callback when a mutation is promoted
 * @property {Function} [onMutationRolledBack]  - Async callback when a mutation is rolled back
 * @property {Function} [onApprovalRequired]    - Async callback requesting human approval
 * @property {Function} [logger]                - Optional logger (defaults to console)
 */

/**
 * @typedef {Object} BaselineMetrics
 * @property {number} [latency]     - Baseline latency score [0, 1]
 * @property {number} [cost]        - Baseline cost score [0, 1]
 * @property {number} [quality]     - Baseline quality score [0, 1]
 * @property {number} [reliability] - Baseline reliability score [0, 1]
 * @property {number} [elegance]    - Baseline elegance score [0, 1]
 */

/**
 * EvolutionEngine — Stage 19 of the HCFullPipeline.
 *
 * Orchestrates the full evolution cycle for a generation:
 *   1. Validates daily generation budget (max fib(4)=3/day)
 *   2. Generates up to fib(6)=8 mutation candidates
 *   3. Evaluates each candidate's fitness via FitnessEvaluator
 *   4. Runs tournament selection to identify the fib(5)=5 survivors
 *   5. Promotes the best-scoring survivor if it beats baseline
 *   6. Auto-rolls back if the winner regresses > 5%
 *   7. Requires human approval for magnitude > 8%
 *   8. Records the full generation to evolution history
 *
 * @class EvolutionEngine
 */
class EvolutionEngine {
  /**
   * Creates an EvolutionEngine.
   *
   * @param {EvolutionConfig} [config={}] - Evolution configuration
   */
  constructor(config = {}) {
    this._config = {
      mutationRate:              config.mutationRate              ?? MUTATION_RATE,
      populationSize:            config.populationSize            ?? POPULATION_SIZE,
      maxMutationMagnitude:      config.maxMutationMagnitude      ?? MAX_MUTATION_MAGNITUDE,
      rollbackOnRegressionAbove: config.rollbackOnRegressionAbove ?? ROLLBACK_ON_REGRESSION_ABOVE,
      requiresApprovalAbove:     config.requiresApprovalAbove     ?? REQUIRES_APPROVAL_ABOVE,
      generationsPerDay:         config.generationsPerDay         ?? GENERATIONS_PER_DAY,
      survivorCount:             config.survivorCount             ?? SURVIVOR_COUNT,
      immutableParams:           config.immutableParams           ?? IMMUTABLE_PARAMS,
    };

    /** @type {Function} */
    this._logger = config.logger ?? console;

    /** @type {Function|null} */
    this._onMutationProposed   = config.onMutationProposed   ?? null;
    /** @type {Function|null} */
    this._onMutationPromoted   = config.onMutationPromoted   ?? null;
    /** @type {Function|null} */
    this._onMutationRolledBack = config.onMutationRolledBack ?? null;
    /** @type {Function|null} */
    this._onApprovalRequired   = config.onApprovalRequired   ?? null;

    /** @type {FitnessEvaluator} */
    this._fitnessEvaluator = new FitnessEvaluator();

    /** @type {MutationGenerator} */
    this._mutationGenerator = new MutationGenerator({
      mutationRate:  this._config.mutationRate,
      maxMagnitude:  this._config.maxMutationMagnitude,
      immutableParams: this._config.immutableParams,
    });

    /**
     * Full evolution history, in chronological order.
     * @type {GenerationRecord[]}
     */
    this._history = [];

    /**
     * Running generation counter (total lifetime generations, not just today).
     * @type {number}
     */
    this._generationCounter = 0;

    /**
     * Currently live configuration (deep copy of the most recently promoted state).
     * Null until the first evolve() call.
     * @type {Object|null}
     */
    this._liveConfig = null;

    this._logger.info?.('[EvolutionEngine] Initialized', {
      mutationRate:         this._config.mutationRate,
      populationSize:       this._config.populationSize,
      maxMutationMagnitude: this._config.maxMutationMagnitude,
      generationsPerDay:    this._config.generationsPerDay,
    });
  }

  // ───────────────────────────────────────────────────────────────────────────
  // PUBLIC API
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Runs one complete evolution cycle.
   *
   * Steps:
   *   1. Check daily generation budget
   *   2. Compute baseline fitness from provided metrics
   *   3. Generate a population of mutation candidates
   *   4. Evaluate fitness for each candidate
   *   5. Tournament-select survivors
   *   6. Identify the best candidate
   *   7. Apply safety guards (rollback / approval checks)
   *   8. Promote the winner to live config if approved
   *   9. Record the generation to history
   *
   * @param {Object}          currentConfig   - The current pipeline configuration object
   * @param {BaselineMetrics} baseline        - Baseline performance metrics (all in [0,1])
   * @returns {Promise<GenerationRecord>} The completed generation record
   * @throws {Error} If the daily generation budget is exhausted
   */
  async evolve(currentConfig, baseline) {
    // 1. Daily budget guard
    const todayCount = _generationsToday(this._history);
    if (todayCount >= this._config.generationsPerDay) {
      const msg = `[EvolutionEngine] Daily generation budget exhausted `
        + `(${todayCount}/${this._config.generationsPerDay} generations today). `
        + `Max = fib(4) = ${fib(4)}.`;
      this._logger.warn?.(msg);
      throw new Error(msg);
    }

    this._generationCounter++;
    const generation = this._generationCounter;
    this._liveConfig = this._deepClone(currentConfig);

    this._logger.info?.(`[EvolutionEngine] Starting generation ${generation} (${todayCount + 1}/${this._config.generationsPerDay} today)`);

    // 2. Baseline fitness
    const baselineFitness = this._fitnessEvaluator.computeComposite(baseline);
    this._logger.info?.(`[EvolutionEngine] Baseline composite fitness: ${baselineFitness.composite.toFixed(6)} (${this._fitnessEvaluator.classifyFitnessTier(baselineFitness.composite)})`);

    // 3. Generate population
    const mutations = this.generateMutations(currentConfig, this._config.populationSize, generation);
    this._logger.info?.(`[EvolutionEngine] Generated ${mutations.length} candidate mutations`);

    // Notify proposals
    for (const mut of mutations) {
      mut.transitionTo(MutationStatus.TESTING);
      if (this._onMutationProposed) {
        await this._safeCallback(this._onMutationProposed, mut);
      }
    }

    // 4. Evaluate fitness — in a real system this would run simulations;
    //    here we compute phi-weighted fitness from simulated metric deltas
    const evaluated = [];
    for (const mut of mutations) {
      try {
        const simulatedMetrics = await this._simulateMutationMetrics(mut, baseline);
        mut.fitness = this._fitnessEvaluator.computeComposite(simulatedMetrics);
        evaluated.push(mut);
      } catch (err) {
        mut.errorMessage = err.message;
        mut.transitionTo(MutationStatus.DISCARDED);
        this._logger.warn?.(`[EvolutionEngine] Failed to evaluate mutation ${mut.id}: ${err.message}`);
      }
    }

    // 5. Tournament selection
    const survivors = this.selectSurvivors(evaluated);
    this._logger.info?.(`[EvolutionEngine] ${survivors.length} survivors after tournament selection`);

    // Discard non-survivors
    for (const mut of evaluated) {
      if (!survivors.includes(mut) && mut.status !== MutationStatus.DISCARDED) {
        mut.transitionTo(MutationStatus.DISCARDED);
      }
    }

    // 6. Identify winner (highest composite fitness among survivors)
    let winner = null;
    let fitnessImprovement = null;
    const promotedParameters = [];

    if (survivors.length > 0) {
      winner = survivors.reduce((best, mut) =>
        (mut.fitness.composite > best.fitness.composite) ? mut : best
      );

      fitnessImprovement = this._fitnessEvaluator.compareFitness(winner.fitness, baselineFitness);

      this._logger.info?.(`[EvolutionEngine] Winner: ${winner.id} (parameter: ${winner.parameter}, composite: ${winner.fitness.composite.toFixed(6)}, improvement: ${(fitnessImprovement * 100).toFixed(3)}%)`);

      // 7. Safety guards
      if (fitnessImprovement < 0) {
        // Regression detected
        const regressionMag = Math.abs(fitnessImprovement);
        if (regressionMag > this._config.rollbackOnRegressionAbove) {
          this._logger.warn?.(`[EvolutionEngine] Auto-rollback triggered: regression ${(regressionMag * 100).toFixed(2)}% > ${(this._config.rollbackOnRegressionAbove * 100)}%`);
          await this.rollback(winner);
          winner = null;
          fitnessImprovement = null;
        } else {
          // Minor regression — discard without rollback
          winner.transitionTo(MutationStatus.DISCARDED);
          this._logger.info?.(`[EvolutionEngine] Winner discarded: minor regression ${(regressionMag * 100).toFixed(2)}% within tolerance`);
          winner = null;
          fitnessImprovement = null;
        }
      } else if (!this._fitnessEvaluator.meetsMinimumBar(winner.fitness)) {
        this._logger.warn?.(`[EvolutionEngine] Winner discarded: composite ${winner.fitness.composite.toFixed(6)} below minimum bar ${MINIMUM_FITNESS_BAR}`);
        winner.transitionTo(MutationStatus.DISCARDED);
        winner = null;
        fitnessImprovement = null;
      } else if (winner && winner.requiresApproval) {
        // 8. Approval required
        this._logger.info?.(`[EvolutionEngine] Mutation ${winner.id} requires human approval (magnitude ${(winner.magnitude * 100).toFixed(2)}% > ${(this._config.requiresApprovalAbove * 100)}%)`);
        if (this._onApprovalRequired) {
          const approved = await this._safeCallback(this._onApprovalRequired, winner);
          if (approved) {
            winner.approvalGranted = true;
          } else {
            this._logger.warn?.(`[EvolutionEngine] Human approval denied for mutation ${winner.id}. Discarding.`);
            winner.transitionTo(MutationStatus.DISCARDED);
            winner = null;
            fitnessImprovement = null;
          }
        } else {
          // No approval handler — refuse promotion conservatively
          this._logger.warn?.(`[EvolutionEngine] No approval handler registered. Discarding mutation requiring approval: ${winner.id}`);
          winner.transitionTo(MutationStatus.DISCARDED);
          winner = null;
          fitnessImprovement = null;
        }
      }

      // 9. Promote
      if (winner) {
        await this.promoteMutation(winner);
        promotedParameters.push(winner.parameter);
      }
    } else {
      this._logger.info?.('[EvolutionEngine] No viable survivors this generation. No mutation promoted.');
    }

    // Record generation
    const generationRecord = {
      generation,
      timestamp:          Date.now(),
      candidates:         mutations.map(m => m.toRecord()),
      winner:             winner ? winner.toRecord() : null,
      fitnessImprovement: fitnessImprovement,
      promotedParameters,
    };

    this._history.push(generationRecord);
    this._logger.info?.(`[EvolutionEngine] Generation ${generation} complete. ${promotedParameters.length > 0 ? 'Promoted: ' + promotedParameters.join(', ') : 'No promotion.'}`);

    return generationRecord;
  }

  /**
   * Generates `count` mutation candidates for the given configuration.
   * Delegates to MutationGenerator.generateBatch and enforces the population cap.
   *
   * @param {Object} config     - Current pipeline configuration
   * @param {number} count      - Desired number of candidates
   * @param {number} [generation=this._generationCounter] - Generation number to assign
   * @returns {Mutation[]} Array of proposed mutations
   */
  generateMutations(config, count, generation) {
    const gen = generation ?? this._generationCounter;
    const safeCount = _clamp(count, 1, POPULATION_SIZE);
    return this._mutationGenerator.generateBatch(config, safeCount, gen);
  }

  /**
   * Evaluates the fitness of a proposed mutation against provided metrics.
   *
   * In production this should invoke actual simulation/measurement; here the
   * metrics object is combined with a small phi-random perturbation to model
   * the change the mutation introduces.
   *
   * @param {Mutation} mutation           - The proposed mutation to evaluate
   * @param {BaselineMetrics} metrics     - Baseline metrics object
   * @returns {FitnessScores} Computed fitness scores
   */
  evaluateFitness(mutation, metrics) {
    const simulated = this._deriveMetricsFromMutation(mutation, metrics);
    return this._fitnessEvaluator.computeComposite(simulated);
  }

  /**
   * Tournament selection: retain the top `survivorCount` mutations by composite fitness.
   *
   * Uses a phi-inspired tournament: each candidate is seeded by its composite score
   * multiplied by a phi-random factor, ensuring diversity is preserved even among
   * close-fitness candidates. The top fib(5) = 5 are returned.
   *
   * @param {Mutation[]} population - All evaluated mutations with fitness set
   * @returns {Mutation[]} Selected survivors (length ≤ SURVIVOR_COUNT)
   */
  selectSurvivors(population) {
    const eligible = population.filter(m =>
      m.fitness && typeof m.fitness.composite === 'number' && m.status !== MutationStatus.DISCARDED
    );

    if (eligible.length <= this._config.survivorCount) return eligible;

    // Phi-randomised tournament seeding
    const seeded = eligible.map(mut => ({
      mut,
      // Add a small phi-proportioned noise to break ties without discarding good candidates
      seed: mut.fitness.composite * (1 + (Math.random() - 0.5) * PSI * this._config.mutationRate),
    }));

    seeded.sort((a, b) => b.seed - a.seed);

    return seeded.slice(0, this._config.survivorCount).map(s => s.mut);
  }

  /**
   * Promotes a winning mutation to the live configuration.
   *
   * Applies the mutated value at the mutation's parameter path on the internal
   * live config snapshot, transitions the mutation to PROMOTED, and fires the
   * onMutationPromoted callback.
   *
   * @param {Mutation} mutation - The mutation to promote
   * @returns {Promise<void>}
   */
  async promoteMutation(mutation) {
    if (!mutation) return;

    try {
      if (this._liveConfig) {
        this._applyMutationToConfig(this._liveConfig, mutation.parameter, mutation.mutatedValue);
      }

      mutation.transitionTo(MutationStatus.PROMOTED);

      this._logger.info?.(`[EvolutionEngine] Promoted mutation ${mutation.id}: ${mutation.parameter} ${JSON.stringify(mutation.originalValue)} → ${JSON.stringify(mutation.mutatedValue)} (Δ${(mutation.magnitude * 100).toFixed(2)}%)`);

      if (this._onMutationPromoted) {
        await this._safeCallback(this._onMutationPromoted, mutation);
      }
    } catch (err) {
      mutation.errorMessage = `Promotion failed: ${err.message}`;
      mutation.transitionTo(MutationStatus.DISCARDED);
      this._logger.error?.(`[EvolutionEngine] Promotion error for ${mutation.id}: ${err.message}`);
    }
  }

  /**
   * Rolls back a mutation, restoring the parameter to its original value.
   *
   * Applies the originalValue back to the live config, transitions the mutation
   * to ROLLED_BACK, and fires the onMutationRolledBack callback.
   *
   * @param {Mutation} mutation - The mutation to roll back
   * @returns {Promise<void>}
   */
  async rollback(mutation) {
    if (!mutation) return;

    try {
      if (this._liveConfig) {
        this._applyMutationToConfig(this._liveConfig, mutation.parameter, mutation.originalValue);
      }

      mutation.transitionTo(MutationStatus.ROLLED_BACK);

      this._logger.warn?.(`[EvolutionEngine] Rolled back mutation ${mutation.id}: ${mutation.parameter} restored to ${JSON.stringify(mutation.originalValue)}`);

      if (this._onMutationRolledBack) {
        await this._safeCallback(this._onMutationRolledBack, mutation);
      }
    } catch (err) {
      mutation.errorMessage = `Rollback failed: ${err.message}`;
      this._logger.error?.(`[EvolutionEngine] Rollback error for ${mutation.id}: ${err.message}`);
    }
  }

  /**
   * Returns the full evolution history as an array of GenerationRecord objects.
   * The returned array is a shallow copy to prevent external mutation.
   *
   * @returns {GenerationRecord[]}
   */
  getEvolutionHistory() {
    return [...this._history];
  }

  /**
   * Returns the current generation counter (total lifetime generations).
   * @returns {number}
   */
  getCurrentGeneration() {
    return this._generationCounter;
  }

  /**
   * Returns how many generations have run today.
   * @returns {number}
   */
  getGenerationsToday() {
    return _generationsToday(this._history);
  }

  /**
   * Returns whether more generations can run today.
   * @returns {boolean}
   */
  canEvolveToday() {
    return _generationsToday(this._history) < this._config.generationsPerDay;
  }

  /**
   * Returns the current live configuration snapshot.
   * This is the last promoted state of the config, or null before first evolve().
   *
   * @returns {Object|null}
   */
  getLiveConfig() {
    return this._liveConfig ? this._deepClone(this._liveConfig) : null;
  }

  /**
   * Returns a summary of the evolution engine's state.
   * Useful for health-check endpoints and logging.
   *
   * @returns {Object}
   */
  getSummary() {
    const totalGenerations = this._history.length;
    const promoted = this._history.filter(r => r.winner !== null).length;
    const totalCandidates = this._history.reduce((s, r) => s + r.candidates.length, 0);
    const avgImprovement = promoted > 0
      ? this._history
          .filter(r => r.fitnessImprovement !== null)
          .reduce((s, r) => s + r.fitnessImprovement, 0) / promoted
      : 0;

    return {
      totalGenerations,
      generationsToday:   _generationsToday(this._history),
      generationBudget:   this._config.generationsPerDay,
      promotedGenerations: promoted,
      discardedGenerations: totalGenerations - promoted,
      totalCandidatesEvaluated: totalCandidates,
      averageFitnessImprovement: avgImprovement,
      mutationRate:         this._config.mutationRate,
      populationSize:       this._config.populationSize,
      maxMutationMagnitude: this._config.maxMutationMagnitude,
    };
  }

  // ───────────────────────────────────────────────────────────────────────────
  // PRIVATE HELPERS
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Simulates post-mutation metric scores by deriving expected changes from
   * the mutation's parameter type, direction, and magnitude.
   *
   * In production this would invoke HeadySims. Here, we model the expected
   * effect using phi-harmonic extrapolation:
   *   - Threshold mutations improve quality/reliability at small magnitudes
   *   - Timing mutations primarily affect latency
   *   - Pool mutations primarily affect cost
   *   - Generic parameter mutations affect quality
   *
   * @param {Mutation}        mutation - Proposed mutation
   * @param {BaselineMetrics} baseline - Current baseline metrics
   * @returns {Promise<Object>} Simulated metric scores in [0, 1]
   * @private
   */
  async _simulateMutationMetrics(mutation, baseline) {
    return this._deriveMetricsFromMutation(mutation, baseline);
  }

  /**
   * Derives simulated metric scores synchronously from a mutation's properties.
   *
   * Uses phi-harmonic scaling to project expected metric changes:
   *   - The direction of change is encoded in whether mutatedValue > originalValue
   *   - Magnitude is scaled by PHI / PSI ratio for threshold vs timing mutations
   *   - A small phi-random noise is added to model real-world variability
   *
   * @param {Mutation}        mutation - The mutation to project
   * @param {BaselineMetrics} baseline - Baseline metrics
   * @returns {Object} Projected metrics
   * @private
   */
  _deriveMetricsFromMutation(mutation, baseline) {
    const base = {
      latency:     baseline.latency     ?? 0.5,
      cost:        baseline.cost        ?? 0.5,
      quality:     baseline.quality     ?? 0.5,
      reliability: baseline.reliability ?? 0.5,
      elegance:    baseline.elegance    ?? 0.5,
    };

    const direction = (
      typeof mutation.originalValue === 'number' &&
      typeof mutation.mutatedValue  === 'number' &&
      mutation.mutatedValue > mutation.originalValue
    ) ? 1 : -1;

    const mag = mutation.magnitude;

    // Phi-random noise in [−ψ², +ψ²] scaled by magnitude
    const noise = () => (Math.random() - 0.5) * PSI_SQ * mag;

    let deltas;
    switch (mutation.paramType) {
      case 'threshold':
        // Threshold adjustments primarily improve quality and reliability
        deltas = {
          latency:     mag * PHI * 0.05  * direction + noise(),
          cost:        mag * PSI  * 0.03 * direction + noise(),
          quality:     mag * PHI  * 0.12 * direction + noise(),
          reliability: mag * PHI  * 0.10 * direction + noise(),
          elegance:    mag * PSI  * 0.08 * direction + noise(),
        };
        break;

      case 'timing':
        // Timing mutations primarily affect latency; cost is secondary
        deltas = {
          latency:     mag * PHI  * 0.15 * direction + noise(),
          cost:        mag * PSI  * 0.05 * direction + noise(),
          quality:     mag * PSI  * 0.02 * noise(),
          reliability: mag * PSI  * 0.04 * direction + noise(),
          elegance:    mag * PSI  * 0.03 * direction + noise(),
        };
        break;

      case 'pool':
        // Pool redistribution primarily affects cost; some reliability impact
        deltas = {
          latency:     mag * PSI  * 0.04 * direction + noise(),
          cost:        mag * PHI  * 0.13 * direction + noise(),
          quality:     mag * PSI  * 0.03 * noise(),
          reliability: mag * PHI  * 0.08 * direction + noise(),
          elegance:    mag * PSI  * 0.06 * direction + noise(),
        };
        break;

      default:
        // Generic parameter: broadband effect
        deltas = {
          latency:     mag * PSI  * 0.06 * direction + noise(),
          cost:        mag * PSI  * 0.04 * direction + noise(),
          quality:     mag * PHI  * 0.09 * direction + noise(),
          reliability: mag * PSI  * 0.05 * direction + noise(),
          elegance:    mag * PSI  * 0.07 * direction + noise(),
        };
    }

    return {
      latency:     _clamp(base.latency     + deltas.latency,     0, 1),
      cost:        _clamp(base.cost        + deltas.cost,        0, 1),
      quality:     _clamp(base.quality     + deltas.quality,     0, 1),
      reliability: _clamp(base.reliability + deltas.reliability, 0, 1),
      elegance:    _clamp(base.elegance    + deltas.elegance,    0, 1),
    };
  }

  /**
   * Applies a new value to a nested dot-path within a config object.
   * Creates intermediate objects as needed.
   *
   * @param {Object} config    - Config object to mutate in-place
   * @param {string} paramPath - Dot-notation path (e.g. 'stages.retries.maxAttempts')
   * @param {*}      value     - New value to set
   * @private
   */
  _applyMutationToConfig(config, paramPath, value) {
    const keys = paramPath.split('.');
    let cursor = config;
    for (let i = 0; i < keys.length - 1; i++) {
      const key = keys[i];
      if (!(key in cursor) || typeof cursor[key] !== 'object') {
        cursor[key] = {};
      }
      cursor = cursor[key];
    }
    cursor[keys[keys.length - 1]] = value;
  }

  /**
   * Deep-clones a plain object using JSON serialization.
   * Suitable for config objects (no functions, no circular refs).
   *
   * @param {Object} obj
   * @returns {Object}
   * @private
   */
  _deepClone(obj) {
    try {
      return JSON.parse(JSON.stringify(obj));
    } catch {
      // Fallback: return a shallow copy
      return Object.assign({}, obj);
    }
  }

  /**
   * Wraps an async callback in a try/catch to prevent callback errors from
   * propagating into the evolution cycle.
   *
   * @param {Function} fn   - Async callback function
   * @param {...*} args     - Arguments to pass
   * @returns {Promise<*>}  The callback's return value, or undefined on error
   * @private
   */
  async _safeCallback(fn, ...args) {
    try {
      return await fn(...args);
    } catch (err) {
      this._logger.error?.(`[EvolutionEngine] Callback error: ${err.message}`);
      return undefined;
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORTS
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
  // Core classes
  EvolutionEngine,
  Mutation,
  FitnessEvaluator,
  MutationGenerator,

  // Enum
  MutationStatus,

  // Phi-derived constants (exposed for testing and inspection)
  MUTATION_RATE,
  POPULATION_SIZE,
  MAX_MUTATION_MAGNITUDE,
  ROLLBACK_ON_REGRESSION_ABOVE,
  REQUIRES_APPROVAL_ABOVE,
  GENERATIONS_PER_DAY,
  SURVIVOR_COUNT,
  FITNESS_WEIGHTS,
  IMMUTABLE_PARAMS,
  MINIMUM_FITNESS_BAR,
  PSI_SQ,
};
