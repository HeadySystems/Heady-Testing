---
name: heady-platform-release-governance
description: Use when the user needs governed release management for Heady services, websites, packages, or agent-driven changes. Triggers include release governance, deployment gates, approval trails, rollout controls, publish policies, release checklist, production safeguards, and Git-versioned change control across the Heady ecosystem.
metadata:
  author: perplexity-computer
  version: '1.0'
---

# Heady Platform Release Governance

## When to Use This Skill

Use this skill when the task involves:

- defining release gates for services, sites, or packages
- building approval trails for production changes
- designing canary, staged, or rollback-aware releases
- aligning agent-driven change systems with governance controls
- packaging release checklists, promotion rules, and verification procedures

## Instructions

1. Identify the release artifact:
   - service
   - website
   - package or SDK
   - infrastructure change
   - multi-service coordinated release

2. Define the release path:
   - source branch or change origin
   - required validation steps
   - pre-release environment
   - promotion conditions
   - rollout strategy
   - rollback strategy

3. Separate the governance model into three layers:
   - technical validation
   - operational readiness
   - approval and auditability

4. For each release, specify:
   - tests that must pass
   - configuration validation
   - secrets and environment checks
   - dependency compatibility checks
   - observability checks after release
   - owner or approver roles

5. If the release is agent-assisted, define guardrails clearly:
   - allowed autonomous actions
   - blocked actions
   - changes requiring human approval
   - required Git trail and changelog updates

6. Recommend rollout controls such as:
   - canary release
   - feature flag rollout
   - blue/green or shadow validation
   - automated smoke tests
   - error budget stop conditions

7. End with:
   - Release Gates
   - Approval Rules
   - Rollback Triggers
   - Required Artifacts

## Examples

### Example: Service rollout
Input: Design a governed release path for heady-auth and heady-memory.

Output should include:
- validation gates
- deploy sequence
- rollback behavior
- approval checkpoints
- required monitoring after release

### Example: Package publishing
Input: Create governance for publishing Heady installable packages.

Output should include:
- versioning rules
- package verification
- signing or integrity checks
- staged distribution rules
- post-publish verification
