---
name: heady-device-provisioning-ops
description: Use when the user needs Heady device setup, companion rollout, remote access preparation, cross-device runtime provisioning, or operational guidance for phones, desktops, mini-computers, edge nodes, and developer workstations. Triggers include device provisioning, termux, workstation setup, node bootstrap, remote management, cross-device sync, and Heady runtime installation.
metadata:
  author: perplexity-computer
  version: '1.0'
---

# Heady Device Provisioning Ops

## When to Use This Skill

Use this skill when the task involves:

- preparing a new device to join the Heady ecosystem
- provisioning developer workstations, mini-computers, or mobile nodes
- setting up remote access, identity, and runtime services
- standardizing cross-device sync and operational posture
- building repeatable bootstrap and verification procedures

## Instructions

1. Classify the device:
   - phone or tablet
   - laptop or desktop
   - mini-computer or homelab node
   - cloud VM
   - edge runtime host

2. Define the provisioning layers:
   - operating system prerequisites
   - package and runtime installation
   - identity and access setup
   - network and tunnel setup
   - Heady services or agents to install
   - observability and recovery hooks

3. For each layer, include:
   - required software
   - configuration files
   - secret handling method
   - health verification command or endpoint
   - rollback or reset step

4. Standardize bootstrap outputs:
   - device name and role
   - registered identity
   - installed services
   - sync state
   - telemetry visibility
   - backup or recovery path

5. Recommend security defaults:
   - no plaintext secrets
   - least-privilege access
   - signed updates where possible
   - host firewall and allowed ports
   - verified tunnels or mTLS for remote access

6. For multi-device systems, define continuity rules:
   - session handoff
   - shared memory sync
   - device capability registry
   - preferred routing by workload type

7. End with:
   - Provisioning Checklist
   - Required Runtime Components
   - Verification Steps
   - Recovery Procedure

## Examples

### Example: Android bridge
Input: Create provisioning ops for an Android device running a Heady companion bridge.

Output should include:
- Termux prerequisites
- SSH or secure remote control path
- service startup behavior
- sync and heartbeat checks
- recovery after reboot

### Example: Mini-computer node
Input: Provision a Ryzen mini-computer as a Heady local orchestration node.

Output should include:
- runtime packages
- Docker or service setup
- telemetry and log shipping
- remote management setup
- health and restart policies
