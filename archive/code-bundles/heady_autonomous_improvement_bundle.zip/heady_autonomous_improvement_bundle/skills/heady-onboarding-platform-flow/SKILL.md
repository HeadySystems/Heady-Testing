---
name: heady-onboarding-platform-flow
description: Use when the user needs Heady onboarding architecture, staged signup and activation flows, auth-to-profile orchestration, welcome journeys, tier upgrades, or lifecycle design for new users, partners, developers, and pilot accounts. Triggers include onboarding, activation, signup flow, welcome flow, user provisioning, account setup, lifecycle stages, and cross-service first-run experience.
metadata:
  author: perplexity-computer
  version: '1.0'
---

# Heady Onboarding Platform Flow

## When to Use This Skill

Use this skill when the task involves:

- designing or improving Heady onboarding journeys
- mapping auth, profile, workspace, and memory bootstrapping
- creating staged onboarding for consumer, enterprise, nonprofit, or developer users
- wiring first-run experiences across multiple Heady services or domains
- defining activation milestones, drop-off points, and recovery loops

## Instructions

1. Identify the onboarding subject:
   - individual user
   - developer
   - enterprise admin
   - nonprofit/community member
   - partner or marketplace seller

2. Map the onboarding sequence from first touch through steady-state usage:
   - entry point
   - authentication method
   - account and profile creation
   - role and tier assignment
   - workspace initialization
   - memory/context seeding
   - tutorial or guided activation
   - first successful outcome

3. Separate the flow into stages:
   - discover
   - authenticate
   - provision
   - personalize
   - activate
   - retain

4. For each stage, define:
   - required data inputs
   - services involved
   - state transitions
   - failure and retry behavior
   - observability events
   - security checks

5. When designing implementation guidance, include:
   - idempotent provisioning rules
   - rollback or compensation steps for partial failure
   - rate limits and abuse controls
   - event names for analytics and monitoring
   - cross-domain session propagation requirements where relevant

6. Recommend activation metrics such as:
   - signup completion rate
   - time to first successful action
   - workspace readiness success
   - profile completion rate
   - day-1 and day-7 retention proxies

7. End with:
   - Onboarding Stages
   - Required Services
   - Failure Recovery Rules
   - Highest-Value Next Build Steps

## Examples

### Example: Developer onboarding
Input: Build a better onboarding flow for developers using headyapi.com and the MCP layer.

Output should include:
- account creation path
- API key and workspace provisioning
- documentation exposure
- sample app quickstart
- analytics events
- rollback handling if provisioning partially fails

### Example: Cross-domain member onboarding
Input: Design onboarding so a user signs in once and can use HeadyMe, HeadyConnection, and HeadyEX.

Output should include:
- central auth entry
- session propagation model
- per-domain profile hydration
- user preference seeding
- consent and privacy checkpoints
