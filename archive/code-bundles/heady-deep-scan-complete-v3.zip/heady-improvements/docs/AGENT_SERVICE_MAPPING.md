# Heady™ Agent-Service Unified Mapping

## Problem

Three different sources define agents/services with inconsistent naming:
1. Architecture Overview (attached doc): 20+ named agents
2. Master System Prompt: 19 registered services  
3. src/agents/: ~8 implementations

## Unified Mapping

| Agent Name (Doc) | Service Name (Registry) | Implementation | Status |
|-----------------|------------------------|----------------|--------|
| HeadyBrain | heady-brains | src/agents/heady-buddy-agent.js (partial) | ⚠️ Stub |
| HeadySoul | heady-soul | (none) | ❌ Missing |
| HeadyVinci | heady-vinci | (none) | ❌ Missing |
| HeadyCoder | heady-conductor | src/agents/agent-orchestrator.js | ⚠️ Partial |
| HeadyCodex | (claude-code agent) | src/agents/claude-code-agent.js | ✅ Implemented |
| HeadyCopilot | (external) | (GitHub Copilot integration) | ✅ External |
| HeadyJules | (external) | (Google Jules bot integration) | ✅ External |
| HeadyPerplexity | (external) | .agents/skills/heady-perplexity/ | ✅ Skill |
| HeadyGrok | heady-battle | src/arena/battle-arena-protocol.js | ⚠️ Partial |
| HeadyBattle | heady-battle | src/battle-orchestration/ | ⚠️ Partial |
| HeadySims | (within battle) | configs/HeadySims-scheduler.yaml | ⚠️ Config only |
| HeadyCreative | (within vinci) | src/bees/creative-bee.js | ⚠️ Bee only |
| HeadyVinci Canvas | (within vinci) | (none) | ❌ Missing |
| HeadyManager | heady-manager | heady-manager.js (49KB monolith) | ✅ Implemented |
| HeadyConductor | heady-conductor | (within manager) | ⚠️ Not separated |
| HeadyLens | heady-lens | (none) | ❌ Missing |
| HeadyOps | heady-ops | (none) | ❌ Missing |
| HeadyMaintenance | heady-maintenance | src/autonomy/heady-maintenance-ops.js | ✅ Implemented |
| HeadyBuddy | (within manager) | src/agents/buddy-agent-hub.js | ✅ Implemented |
| HeadyFintech | (within agents) | src/agents/heady-fintech-agent.js | ✅ Implemented |

## Implementation Priority

1. **HeadySoul** — Required by heady-conductor (dependency in service-catalog.yaml)
2. **HeadyVinci** — Required by heady-conductor and heady-bee-factory
3. **HeadyLens** — Change microscope, needed for drift detection
4. **HeadyOps** — Deployment automation agent
5. **HeadyConductor** (separate) — Extract from heady-manager.js monolith