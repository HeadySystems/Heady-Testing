# Heady™ Service Dependency Graph

## Mermaid Diagram

```mermaid
graph TD
    DR[domain-router<br/>L1 Edge<br/>:4301] --> OK[observability-kernel<br/>L2 Gateway<br/>:4302]
    DR --> HG[heady-governance<br/>L3 Orchestration<br/>:4310]

    OK --> BT[budget-tracker<br/>L2 Gateway<br/>:4303]
    OK --> HM[heady-memory<br/>L6 Persistence<br/>:4304]
    OK --> HH[heady-health<br/>L5 Service Mesh<br/>:4305]

    HM --> HH
    HG --> HS[heady-soul<br/>L4 Intelligence<br/>:4308]
    HG --> HGU[heady-guard<br/>L5 Security<br/>:4311]

    HM --> HB[heady-brains<br/>L4 Intelligence<br/>:4307]
    HM --> HV[heady-vinci<br/>L4 Intelligence<br/>:4309]
    HM --> HA[heady-autobiographer<br/>L6 Persistence<br/>:4312]

    HH --> HBF[heady-bee-factory<br/>L3 Orchestration<br/>:4313]
    HV --> HBF

    HB --> HC[heady-conductor<br/>L3 Orchestration<br/>:4306]
    HS --> HC
    HV --> HC
    HG --> HC

    HC --> HPE[hcfullpipeline-executor<br/>L3 Orchestration<br/>:4314]
    HBF --> HPE
    HG --> HPE

    OK --> ASE[auto-success-engine<br/>L3 Orchestration<br/>:4315]
    HH --> ASE
    BT --> ASE

    classDef l1 fill:#FF6B6B,stroke:#333,color:#fff
    classDef l2 fill:#4ECDC4,stroke:#333,color:#fff
    classDef l3 fill:#45B7D1,stroke:#333,color:#fff
    classDef l4 fill:#96CEB4,stroke:#333,color:#fff
    classDef l5 fill:#FFEAA7,stroke:#333,color:#333
    classDef l6 fill:#DDA0DD,stroke:#333,color:#fff

    class DR l1
    class OK,BT l2
    class HC,HBF,HPE,ASE l3
    class HB,HS,HV l4
    class HH,HGU l5
    class HM,HA,HG l6
```

## Layer Legend

| Layer | Color | Services |
|-------|-------|----------|
| L1 Edge | Red | domain-router |
| L2 Gateway | Teal | observability-kernel, budget-tracker |
| L3 Orchestration | Blue | heady-conductor, bee-factory, pipeline-executor, auto-success |
| L4 Intelligence | Green | heady-brains, heady-soul, heady-vinci |
| L5 Service Mesh | Yellow | heady-health, heady-guard |
| L6 Persistence | Purple | heady-memory, heady-autobiographer, heady-governance |