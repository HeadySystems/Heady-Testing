# Heady™ Service Bootstrap Plan

## Deployment Priority Matrix

Based on service-catalog.yaml dependency analysis, deploy in this order:

### Phase 1: Foundation (Week 1)
| # | Service | Port | Dependencies | Why First |
|---|---------|------|-------------|-----------|
| 1 | domain-router | 4301 | None | Root dependency for all services |
| 2 | observability-kernel | 4302 | domain-router | Required for monitoring everything else |
| 3 | heady-governance | 4310 | domain-router | Policy enforcement needed before services start |

### Phase 2: Core Intelligence (Week 2)
| # | Service | Port | Dependencies | Why |
|---|---------|------|-------------|-----|
| 4 | heady-memory | 4304 | observability-kernel | Memory substrate for all intelligence |
| 5 | heady-health | 4305 | observability-kernel, heady-memory | Health attestation for all services |
| 6 | budget-tracker | 4303 | observability-kernel | Cost governance before AI calls |

### Phase 3: Intelligence Layer (Week 3)
| # | Service | Port | Dependencies | Why |
|---|---------|------|-------------|-----|
| 7 | heady-brains | 4307 | heady-memory | Primary reasoning engine |
| 8 | heady-soul | 4308 | heady-governance | Alignment and reflection |
| 9 | heady-vinci | 4309 | heady-memory | Pattern recognition and learning |
| 10 | heady-guard | 4311 | heady-governance | Security enforcement |

### Phase 4: Orchestration (Week 4)
| # | Service | Port | Dependencies | Why |
|---|---------|------|-------------|-----|
| 11 | heady-conductor | 4306 | brains, soul, vinci, governance | Central orchestration |
| 12 | heady-bee-factory | 4313 | health, vinci | Worker creation |
| 13 | auto-success-engine | 4315 | observability, health, budget | The heartbeat |
| 14 | hcfullpipeline-executor | 4314 | conductor, bee-factory, governance | Full pipeline |
| 15 | heady-autobiographer | 4312 | heady-memory | Self-documentation |

### Deployment Command Template

```bash
# For each service:
cd services/SERVICE_NAME
gcloud run deploy SERVICE_NAME \
  --source . \
  --region us-east1 \
  --allow-unauthenticated \
  --set-env-vars="PORT=PORT_NUMBER,NODE_ENV=production" \
  --quiet
```

### Health Verification

After each service deploys, verify:
```bash
curl -s https://SERVICE_URL/health/ready | jq .
```

Expected: `{"status": "ok", "service": "SERVICE_NAME", "version": "4.0.0"}`