# Heady™ Manager Decomposition Plan

## Current State

`heady-manager.js` is a 49KB monolith that handles:
- MCP server + API gateway (port 3300)
- All service routing (42 routes)
- Health checks
- Service registration
- Conductor logic
- Battle orchestration
- Memory operations

## Target Architecture

Break into 8 focused modules per Pillar 1 (Liquid Architecture):

| Module | Extracted From | Max Size | Port |
|--------|---------------|----------|------|
| `heady-gateway.js` | Route handling, auth middleware | 500 lines | 3300 |
| `heady-conductor-service.js` | Orchestration logic | 800 lines | 4306 |
| `heady-mcp-service.js` | MCP protocol handler | 600 lines | 4320 |
| `heady-registry-service.js` | Service registration, discovery | 400 lines | 4321 |
| `heady-health-service.js` | Health checks, readiness probes | 300 lines | 4305 |
| `heady-battle-service.js` | Arena mode, battle orchestration | 600 lines | 4322 |
| `heady-memory-service.js` | Vector memory operations | 500 lines | 4304 |
| `heady-streaming-service.js` | SSE, WebSocket, real-time | 400 lines | 4323 |

## Decomposition Steps

1. Create service scaffolds using Cloud Run template
2. Extract route groups from monolith into corresponding service
3. Wire inter-service communication via direct HTTP (no proxy, per CLAUDE.md)
4. Update service-catalog.yaml with new ports
5. Deploy each service independently
6. Redirect heady-manager to act as thin gateway only
7. Run integration tests to verify routing
8. Delete deprecated code from heady-manager.js