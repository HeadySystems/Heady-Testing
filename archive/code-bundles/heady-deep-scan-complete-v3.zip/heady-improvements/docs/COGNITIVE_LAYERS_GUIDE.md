# Heady™ Cognitive Layers Architecture Guide

## Overview

The Heady cognitive architecture uses 7 animal-metaphor layers that run in PARALLEL
through a fusion engine. Each layer provides a different cognitive function, and outputs
are synthesized via WEIGHTED_SYNTHESIS conflict resolution.

## Layer Definitions

| Layer | Animal | Function | Priority | min_confidence |
|-------|--------|----------|----------|---------------|
| owl_wisdom | 🦉 Owl | First principles, deep reasoning, pattern recognition across time | CRITICAL | 0.691 |
| eagle_omniscience | 🦅 Eagle | 360° awareness, edge cases, security implications, failure modes | CRITICAL | 0.691 |
| dolphin_creativity | 🐬 Dolphin | Lateral thinking, elegant solutions, combinatorial innovation | CRITICAL | 0.691 |
| rabbit_multiplication | 🐰 Rabbit | Idea proliferation, 5+ angles minimum, contingency breeding | CRITICAL | 0.691 |
| ant_task | 🐜 Ant | Zero-skip repetitive execution, batch consistency | HIGH | 0.691 |
| elephant_memory | 🐘 Elephant | Perfect recall, cross-session continuity, deep focus | HIGH | 0.691 |
| beaver_build | 🦫 Beaver | Clean architecture, proper scaffolding, quality construction | HIGH | 0.691 |

## Fusion Engine

```
Mode: PARALLEL (all 7 layers execute simultaneously)
Conflict Resolution: WEIGHTED_SYNTHESIS
Output Thresholds:
  - all_layers_minimum: 0.691 (CSL threshold)
  - critical_layers_minimum: 0.809 (CSL high-confidence)
  - consensus_threshold: 0.882 (CSL super-majority)
```

## Runtime Mapping

Each cognitive layer maps to specific system components:

| Layer | System Component | Implementation |
|-------|-----------------|----------------|
| owl_wisdom | HeadyBrain | src/agents/heady-buddy-agent.js → inference-gateway routing |
| eagle_omniscience | HeadySoul + HeadyGrok | src/awareness/metacognitive-loop.js |
| dolphin_creativity | HeadyCreative + HeadyVinci | src/bees/creative-bee.js |
| rabbit_multiplication | HeadySims + Arena Mode | src/arena/battle-arena-protocol.js |
| ant_task | HeadyBee Factory | src/bees/bee-factory.js → blast() |
| elephant_memory | 3D Vector Memory | src/bees-memory/v2/vector-memory-v2.js |
| beaver_build | HeadyCoder + HeadyCodex | src/agents/claude-code-agent.js |

## How Decisions Flow

1. Input arrives at HeadyConductor (L3 Orchestration)
2. All 7 cognitive layers process in parallel
3. Each returns a confidence-scored response (0→1 CSL gate)
4. Fusion engine applies WEIGHTED_SYNTHESIS:
   - CRITICAL layers (owl, eagle, dolphin, rabbit) get 2x weight
   - HIGH layers (ant, elephant, beaver) get 1x weight
5. If consensus ≥ 0.882 → execute immediately
6. If consensus ≥ 0.691 but < 0.882 → route to Arena Mode for competitive validation
7. If consensus < 0.691 → escalate to Creator (Eric)