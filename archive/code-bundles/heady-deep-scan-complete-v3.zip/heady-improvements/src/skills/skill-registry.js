// HEADY_BRAND:BEGIN
// Heady™ Runtime Skill Registry
// Auto-discovers .agents/skills/*/SKILL.md and exposes runtime bindings
// HEADY_BRAND:END

const fs = require('fs');
const path = require('path');
const yaml = require('yaml');

const SKILLS_DIR = path.resolve(__dirname, '../../.agents/skills');

class SkillRegistry {
  constructor() {
    this.skills = new Map();
    this.loaded = false;
  }

  async discover() {
    if (this.loaded) return;

    const dirs = fs.readdirSync(SKILLS_DIR, { withFileTypes: true })
      .filter(d => d.isDirectory())
      .map(d => d.name);

    for (const dir of dirs) {
      const skillPath = path.join(SKILLS_DIR, dir, 'SKILL.md');
      if (!fs.existsSync(skillPath)) continue;

      const content = fs.readFileSync(skillPath, 'utf-8');
      const metadata = this._parseFrontmatter(content);

      this.skills.set(metadata.name || dir, {
        id: dir,
        name: metadata.name || dir,
        description: metadata.description || '',
        version: metadata.metadata?.version || '1.0',
        author: metadata.metadata?.author || 'unknown',
        content: content,
        path: skillPath,
      });
    }

    this.loaded = true;
    console.log(`[SkillRegistry] Discovered ${this.skills.size} skills`);
  }

  getSkill(name) {
    return this.skills.get(name) || null;
  }

  listSkills() {
    return Array.from(this.skills.values()).map(s => ({
      id: s.id, name: s.name, description: s.description, version: s.version
    }));
  }

  searchSkills(query) {
    const q = query.toLowerCase();
    return this.listSkills().filter(s =>
      s.name.includes(q) || s.description.toLowerCase().includes(q)
    );
  }

  _parseFrontmatter(content) {
    const match = content.match(/^---\n([\s\S]*?)\n---/);
    if (!match) return {};
    try {
      return yaml.parse(match[1]);
    } catch {
      return {};
    }
  }
}

module.exports = { SkillRegistry, skillRegistry: new SkillRegistry() };