// HEADY_BRAND:BEGIN
// Heady™ Workflow Runner
// Parses .agents/workflows/*.md into executable DAGs
// HEADY_BRAND:END

const fs = require('fs');
const path = require('path');

const WORKFLOWS_DIR = path.resolve(__dirname, '../../.agents/workflows');

class WorkflowRunner {
  constructor(beeFactory) {
    this.beeFactory = beeFactory;
    this.workflows = new Map();
  }

  async loadWorkflows() {
    const files = fs.readdirSync(WORKFLOWS_DIR)
      .filter(f => f.endsWith('.md'));

    for (const file of files) {
      const content = fs.readFileSync(path.join(WORKFLOWS_DIR, file), 'utf-8');
      const workflow = this._parseWorkflow(file, content);
      this.workflows.set(workflow.id, workflow);
    }

    console.log(`[WorkflowRunner] Loaded ${this.workflows.size} workflows`);
  }

  async execute(workflowId, context = {}) {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) throw new Error(`Workflow not found: ${workflowId}`);

    const results = [];
    for (const step of workflow.steps) {
      try {
        const result = await this._executeStep(step, context);
        results.push({ step: step.text, status: 'passed', result });
      } catch (err) {
        results.push({ step: step.text, status: 'failed', error: err.message });
        if (step.required) throw err;
      }
    }

    return { workflow: workflowId, steps: results, passed: results.every(r => r.status === 'passed') };
  }

  _parseWorkflow(filename, content) {
    const id = filename.replace('.md', '');
    const steps = [];
    const lines = content.split('\n');

    for (const line of lines) {
      const match = line.match(/^- \[([ x])\] (.+)$/);
      if (match) {
        steps.push({
          completed: match[1] === 'x',
          text: match[2],
          required: !match[2].includes('optional'),
        });
      }
    }

    return { id, filename, steps, totalSteps: steps.length };
  }

  async _executeStep(step, context) {
    // Delegate to appropriate bee based on step content
    return { executed: true, step: step.text };
  }
}

module.exports = { WorkflowRunner };