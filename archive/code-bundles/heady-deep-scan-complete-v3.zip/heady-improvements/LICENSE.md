Business Source License 1.1

Parameters

Licensor:             HeadySystems Inc.
Licensed Work:        Heady™ Sovereign AI Platform
                      The Licensed Work is (c) 2024-2026 HeadySystems Inc.
Additional Use Grant: You may make production use of the Licensed Work,
                      provided your use does not include offering the
                      Licensed Work to third parties as a hosted or
                      managed service where the service provides users
                      with access to any substantial set of the features
                      or functionality of the Licensed Work.
Change Date:          Four years from the date the Licensed Work is
                      published.
Change License:       Apache License, Version 2.0

For information about alternative licensing arrangements for the Licensed Work,
please contact: legal@headysystems.com

Notice

Business Source License 1.1 is not an Open Source license. However, the
Licensed Work will eventually be made available under an Open Source License,
as stated in this License.

60+ Provisional Patents Pending — U.S. Patent and Trademark Office