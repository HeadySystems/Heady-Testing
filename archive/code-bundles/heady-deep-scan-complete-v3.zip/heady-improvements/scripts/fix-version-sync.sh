#!/bin/bash
# fix-version-sync.sh — Synchronize version across all config files
# Heady™ Deep Scan Improvement Package

VERSION="4.0.0"  # Source of truth: package.json

echo "🔄 Syncing version to $VERSION across all config files..."

# HEADY_CONTEXT.md
sed -i "s/Version: [0-9.]*/Version: $VERSION/g" HEADY_CONTEXT.md
sed -i "s/heady-systems v[0-9.]*/heady-systems v$VERSION/g" HEADY_CONTEXT.md

# .windsurfrules
sed -i "s/Version: [0-9.]*/Version: $VERSION/g" .windsurfrules

# heady-cognitive-config.json
python3 -c "
import json
with open('configs/heady-cognitive-config.json', 'r') as f:
    data = json.load(f)
data['cognitive_architecture']['version'] = '$VERSION'
with open('configs/heady-cognitive-config.json', 'w') as f:
    json.dump(data, f, indent=4)
print('  ✅ configs/heady-cognitive-config.json')
"

# render.yaml
sed -i 's/HEADY_VERSION.*$/HEADY_VERSION/; s/value: "[0-9.]*"/value: "$VERSION"/' render.yaml

# heady-registry.json
python3 -c "
import json
with open('configs/heady-registry.json', 'r') as f:
    data = json.load(f)
data['_meta']['version'] = '$VERSION'
with open('configs/heady-registry.json', 'w') as f:
    json.dump(data, f, indent=2)
print('  ✅ configs/heady-registry.json')
"

echo ""
echo "✅ Version synced to $VERSION. Verify:"
echo "   grep -rn 'version.*3\.2\.3\|version.*3\.0\.0' . --include='*.json' --include='*.yaml' --include='*.md'"