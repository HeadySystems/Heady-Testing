#!/bin/bash
# fix-phi-constants.sh — Replace hardcoded 30000 with phi-math imports
# Heady™ Deep Scan Improvement Package

echo "🔧 Fixing φ-constant drift in source modules..."

FILES=(
  "src/system-monitor.js"
  "src/monte-carlo.js"
  "src/self-awareness.js"
  "src/services/service-manager.js"
  "src/projection/projection-engine.js"
  "src/arena/arena-mode-service.js"
  "src/bees/bee-factory.js"
)

for file in "${FILES[@]}"; do
  if [ -f "$file" ]; then
    # Check if import already exists
    if ! grep -q "AUTO_SUCCESS" "$file"; then
      # Add import at top (after brand header if present)
      sed -i '/HEADY_BRAND:END/a\nconst { AUTO_SUCCESS, PHI_TIMING } = require("../shared/phi-math");' "$file"
      echo "  ✅ Added phi-math import to $file"
    fi

    # Replace 30000 with AUTO_SUCCESS.CYCLE_MS
    sed -i 's/30000/AUTO_SUCCESS.CYCLE_MS/g' "$file"
    echo "  ✅ Replaced 30000 → AUTO_SUCCESS.CYCLE_MS in $file"

    # Replace 135 (tasks) with AUTO_SUCCESS.TASKS_TOTAL
    sed -i 's/\b135\b/AUTO_SUCCESS.TASKS_TOTAL/g' "$file"
    echo "  ✅ Replaced 135 → AUTO_SUCCESS.TASKS_TOTAL in $file"
  else
    echo "  ⚠️  File not found: $file"
  fi
done

# Fix telemetry files
find src/telemetry -name "*.js" -exec sed -i 's/30000/AUTO_SUCCESS.CYCLE_MS/g' {} \;
echo "  ✅ Fixed src/telemetry/*.js"

echo ""
echo "🐝 φ-constant drift fixed. Run tests to verify:"
echo "   pnpm test --filter='**/system-monitor*' --filter='**/monte-carlo*'"