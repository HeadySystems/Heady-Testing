#!/bin/bash
# projection-sync-pipeline.sh — Sync monorepo modules to core repos
# Heady™ Deep Scan Improvement Package

set -euo pipefail

MONOREPO_ROOT="/home/headyme/Heady"
GITHUB_ORG="HeadyMe"

declare -A REPO_MAP=(
  ["headymcp-core"]="src/mcp"
  ["headyapi-core"]="src/services/inference-gateway.js src/architecture/v2/heady-api-gateway-v2.js src/auth"
  ["headybuddy-core"]="src/agents/heady-buddy-agent.js src/agents/buddy-agent-hub.js src/agents/buddy-device-bridge.js src/bees/buddy-core-v2.js"
  ["headyos-core"]="src/orchestration src/autonomy src/awareness"
  ["headysystems-core"]="src/resilience src/architecture/v2 configs/service-catalog.yaml"
  ["headybot-core"]="src/bees/bee-factory.js src/bees/registry.js src/agents/agent-orchestrator.js"
  ["headyio-core"]="packages/ src/api"
  ["headyconnection-core"]="src/auth configs/governance-policies.yaml"
)

for repo in "${!REPO_MAP[@]}"; do
  echo "🔄 Syncing $repo..."

  WORK_DIR="/tmp/heady-sync/$repo"
  rm -rf "$WORK_DIR"
  git clone "https://github.com/$GITHUB_ORG/$repo.git" "$WORK_DIR"

  mkdir -p "$WORK_DIR/src"

  for src in ${REPO_MAP[$repo]}; do
    if [ -d "$MONOREPO_ROOT/$src" ]; then
      cp -r "$MONOREPO_ROOT/$src" "$WORK_DIR/src/"
    elif [ -f "$MONOREPO_ROOT/$src" ]; then
      cp "$MONOREPO_ROOT/$src" "$WORK_DIR/src/"
    fi
  done

  cd "$WORK_DIR"
  git add -A
  git diff --staged --quiet || {
    git commit -m "feat: sync from monorepo $(date -u +%Y-%m-%dT%H:%M:%SZ)"
    git push
    echo "  ✅ $repo updated"
  }
done

echo ""
echo "🐝 Projection sync complete."