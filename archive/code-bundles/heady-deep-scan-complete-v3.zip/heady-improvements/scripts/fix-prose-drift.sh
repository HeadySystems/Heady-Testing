#!/bin/bash
# fix-prose-drift.sh — Update governance document prose to match φ-scaled values
# Heady™ Deep Scan Improvement Package

echo "📝 Fixing prose drift in governance documents..."

FILES=(
  "MASTER_DIRECTIVES.md"
  "UNBREAKABLE_LAWS.md"
  "SYSTEM_PRIME_DIRECTIVE.md"
  "README.md"
)

for file in "${FILES[@]}"; do
  if [ -f "$file" ]; then
    sed -i 's/135 background tasks/fib(12) = 144 background tasks/g' "$file"
    sed -i 's/135 tasks/fib(12) = 144 tasks/g' "$file"
    sed -i 's/9 categories/fib(7) = 13 categories/g' "$file"
    sed -i 's/30-second cycle/φ⁷ × 1000 = 29,034ms cycle/g' "$file"
    sed -i 's/30 seconds/29,034ms (φ⁷ × 1000)/g' "$file"
    sed -i 's/15 tasks each/11 tasks each (fib(12)\/fib(7))/g' "$file"
    echo "  ✅ Fixed $file"
  else
    echo "  ⚠️  File not found: $file"
  fi
done

echo ""
echo "✅ Prose drift fixed. Verify with:"
echo "   grep -rn '135 background\|9 categories\|30-second cycle\|15 tasks each' *.md"