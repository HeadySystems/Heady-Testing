#!/bin/bash
# fix-windsurfrules.sh — Fix .windsurfrules phi-constant references
# Heady™ Deep Scan v3.0

echo "🔧 Fixing .windsurfrules..."

FILE=".windsurfrules"

if [ -f "$FILE" ]; then
  # Fix Law #7 text
  sed -i 's/135-task\/30-second heartbeat cycle/144-task\/29034ms heartbeat cycle/g' "$FILE"

  # Fix Architecture section
  sed -i 's/135 auto-success tasks/144 auto-success tasks/g' "$FILE"

  # Fix version
  sed -i 's/Version: 3.2.3/Version: 4.0.0/g' "$FILE"

  echo "  ✅ Fixed .windsurfrules"
else
  echo "  ⚠️  .windsurfrules not found"
fi

echo ""
echo "✅ Verify with:"
echo "   grep -n '135\|30-second\|3.2.3' .windsurfrules"