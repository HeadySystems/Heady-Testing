#!/bin/bash
# fix-docker-compose.sh — Replace round-number intervals with φ-scaled values
# Heady™ Deep Scan v3.0

echo "🔧 Fixing docker-compose.yml round-number intervals..."

FILE="docker-compose.yml"

if [ -f "$FILE" ]; then
  # Remove deprecated version line
  sed -i '/^version: /d' "$FILE"
  echo "  ✅ Removed deprecated 'version:' key (Compose V2 doesn't need it)"

  # healthcheck intervals: 10s → 11s (≈ φ⁵/1000), 15s → 18s (≈ φ⁶/1000)
  sed -i 's/interval: 10s/interval: 11s/g' "$FILE"
  sed -i 's/interval: 15s/interval: 18s/g' "$FILE"
  echo "  ✅ Healthcheck intervals: 10s→11s (φ⁵), 15s→18s (φ⁶)"

  # timeout: 5s → 4s (≈ φ³/1000 = 4.236)
  sed -i 's/timeout: 5s/timeout: 4s/g' "$FILE"
  echo "  ✅ Timeouts: 5s→4s (φ³)"

  # start_period: 20s → 18s, 30s → 29s  
  sed -i 's/start_period: 20s/start_period: 18s/g' "$FILE"
  sed -i 's/start_period: 30s/start_period: 29s/g' "$FILE"
  echo "  ✅ Start periods: 20s→18s (φ⁶), 30s→29s (φ⁷)"

  echo ""
  echo "  ✅ docker-compose.yml fixed"
else
  echo "  ⚠️  docker-compose.yml not found"
fi