#!/bin/bash
# fix-ecosystem-config.sh — Replace round numbers with φ-scaled values
# Heady™ Deep Scan v3.0

echo "🔧 Fixing ecosystem.config.cjs round numbers..."

FILE="ecosystem.config.cjs"

if [ -f "$FILE" ]; then
  # kill_timeout: 5000 → 4236 (φ³ × 1000)
  sed -i "s/kill_timeout: 5000/kill_timeout: 4236/g" "$FILE"
  echo "  ✅ kill_timeout: 5000 → 4236 (φ³ × 1000)"

  # listen_timeout: 10000 → 11090 (φ⁵ × 1000)  
  sed -i "s/listen_timeout: 10000/listen_timeout: 11090/g" "$FILE"
  echo "  ✅ listen_timeout: 10000 → 11090 (φ⁵ × 1000)"

  echo ""
  echo "  ✅ ecosystem.config.cjs fixed"
else
  echo "  ⚠️  ecosystem.config.cjs not found"
fi