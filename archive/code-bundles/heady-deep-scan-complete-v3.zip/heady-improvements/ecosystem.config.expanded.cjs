// ecosystem.config.expanded.cjs
// Expanded PM2 configuration covering all critical Heady services
// All timing constants derived from φ (NO round numbers)
// Heady™ Deep Scan v3.0

const PHI3 = 4236;   // φ³ × 1000
const PHI5 = 11090;  // φ⁵ × 1000
const PHI1 = 1618;   // φ × 1000

const baseConfig = {
  max_restarts: 8,           // fib(6)
  restart_delay: PHI3,       // φ³ × 1000 = 4236ms
  exp_backoff_restart_delay: PHI1, // φ × 1000 = 1618ms
  kill_timeout: PHI3,        // φ³ × 1000 = 4236ms
  listen_timeout: PHI5,      // φ⁵ × 1000 = 11090ms
  min_uptime: '11s',         // ≈ φ⁵
  merge_logs: true,
  log_date_format: 'YYYY-MM-DD HH:mm:ss.SSS',
};

module.exports = {
  apps: [
    {
      name: 'domain-router',
      script: 'services/domain-router/dist/index.js',
      instances: 2,
      exec_mode: 'cluster',
      max_memory_restart: '233M',  // fib(13)
      env_production: { NODE_ENV: 'production', PORT: 4301 },
      ...baseConfig,
    },
    {
      name: 'observability-kernel',
      script: 'services/observability-kernel/dist/index.js',
      instances: 1,
      max_memory_restart: '233M',
      env_production: { NODE_ENV: 'production', PORT: 4302 },
      ...baseConfig,
    },
    {
      name: 'heady-conductor',
      script: 'services/heady-conductor/dist/index.js',
      instances: 2,
      exec_mode: 'cluster',
      max_memory_restart: '377M',  // fib(14)
      env_production: { NODE_ENV: 'production', PORT: 4306 },
      ...baseConfig,
    },
    {
      name: 'auto-success-engine',
      script: 'services/auto-success-engine/dist/index.js',
      instances: 1,
      max_memory_restart: '233M',
      env_production: {
        NODE_ENV: 'production',
        PORT: 4315,
        AUTO_SUCCESS_CYCLE_MS: 29034,
      },
      cron_restart: '0 */4 * * *',
      ...baseConfig,
    },
    {
      name: 'heady-memory',
      script: 'services/heady-memory/dist/index.js',
      instances: 1,
      max_memory_restart: '610M',  // fib(15) - memory needs more RAM
      env_production: { NODE_ENV: 'production', PORT: 4304 },
      ...baseConfig,
    },
    {
      name: 'heady-health',
      script: 'services/heady-health/dist/index.js',
      instances: 1,
      max_memory_restart: '144M',  // fib(12)
      env_production: { NODE_ENV: 'production', PORT: 4305 },
      ...baseConfig,
    },
    {
      name: 'heady-brains',
      script: 'services/heady-brains/dist/index.js',
      instances: 2,
      exec_mode: 'cluster',
      max_memory_restart: '610M',
      env_production: { NODE_ENV: 'production', PORT: 4307 },
      ...baseConfig,
    },
    {
      name: 'heady-governance',
      script: 'services/heady-governance/dist/index.js',
      instances: 1,
      max_memory_restart: '144M',
      env_production: { NODE_ENV: 'production', PORT: 4310 },
      ...baseConfig,
    },
    {
      name: 'heady-bee-factory',
      script: 'services/heady-bee-factory/dist/index.js',
      instances: 1,
      max_memory_restart: '233M',
      env_production: { NODE_ENV: 'production', PORT: 4313 },
      ...baseConfig,
    },
    {
      name: 'hcfullpipeline-executor',
      script: 'services/hcfullpipeline-executor/dist/index.js',
      instances: 1,
      max_memory_restart: '377M',
      env_production: { NODE_ENV: 'production', PORT: 4314 },
      ...baseConfig,
    },
  ],
};