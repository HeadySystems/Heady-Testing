"""
Heady Colab Pro+ Runtime 4 — Orchestration & Swarm Coordination
═══════════════════════════════════════════════════════════════════
GPU: A100/TPU-v2-8 | RAM: 55GB | Disk: 233GB
Port: 3304 | Health: 3314
Tunnel: orchestrator.headyos.com

Services:
  - HeadyConductor task routing & HCFP pipeline orchestration
  - HeadyBee swarm coordination (bee factory, consensus, load balancing)
  - Sacred Geometry topology management (node placement, coherence monitoring)
  - CSL engine operations (gate evaluation, MoE routing, ternary logic)
  - Backpressure management & SRE adaptive throttling
  - Inter-runtime communication broker (coordinates runtimes 1-3)

Model Configs (TPU-aware):
  - Qwen3-Embedding-8B (embedding orchestration)
  - Qwen2.5-Coder-32B (code-task routing)
  - DeepSeek-R1-Distill-32B (reasoning pipeline)
  - Gemma-3-12B (fast classification & gating)

Sacred Geometry v4.0 — Zero Magic Numbers
© 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
"""

import math, os, sys, json, time, logging, threading, subprocess, uuid, hashlib
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from collections import OrderedDict, deque

PHI = (1 + math.sqrt(5)) / 2
PSI = 1 / PHI
PHI2 = PHI + 1
PHI3 = 2 * PHI + 1
FIB = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765]

def fib(n): return FIB[n] if n < len(FIB) else FIB[-1]
def phi_threshold(level, spread=0.5): return 1 - (PSI ** level) * spread
def phi_backoff(attempt, base_s=1.0, max_s=60.0): return min(base_s * (PHI ** attempt), max_s)

CSL_THRESHOLDS = {
    'MINIMUM':  phi_threshold(0),   # 0.500
    'LOW':      phi_threshold(1),   # 0.691
    'MEDIUM':   phi_threshold(2),   # 0.809
    'HIGH':     phi_threshold(3),   # 0.882
    'CRITICAL': phi_threshold(4),   # 0.927
}

# ═══════════════════════════════════════════════════════════════
# ENVIRONMENT
# ═══════════════════════════════════════════════════════════════

os.environ["HEADY_ROLE"] = "orchestration"
os.environ["HEADY_RUNTIME_ID"] = "heady-orchestration-runtime"
os.environ["PORT"] = "3304"
os.environ["HEALTH_PORT"] = "3314"
os.environ["MAX_CONCURRENT_PIPELINES"] = str(fib(7))       # 13
os.environ["MAX_SWARM_BEES"] = str(fib(12))                # 144
os.environ["CONSENSUS_QUORUM_RATIO"] = str(round(PSI, 3))  # 0.618
os.environ["BACKPRESSURE_WINDOW_MS"] = str(fib(13) * 100)  # 23300ms
os.environ["TOPOLOGY_REFRESH_MS"] = str(round(PHI * 1000 * fib(5)))  # ~8090ms
os.environ["CSL_GATE_CACHE_SIZE"] = str(fib(16))            # 987
os.environ["MOE_TOP_K_EXPERTS"] = str(fib(4))               # 3
os.environ["TERNARY_PRECISION_BITS"] = str(fib(6))          # 8
os.environ["INTER_RUNTIME_TIMEOUT_MS"] = str(fib(8) * 1000) # 21000ms

# Runtime endpoints for inter-runtime broker
RUNTIME_ENDPOINTS = {
    "vector_ops":    os.getenv("VECTOR_OPS_URL", "http://localhost:3301"),
    "llm_inference": os.getenv("LLM_INFERENCE_URL", "http://localhost:3302"),
    "training":      os.getenv("TRAINING_URL", "http://localhost:3303"),
}

CF_TUNNEL_TOKEN = os.getenv("CF_TUNNEL_TOKEN_ORCH", "")

# ═══════════════════════════════════════════════════════════════
# INSTALL DEPENDENCIES
# ═══════════════════════════════════════════════════════════════

PACKAGES = [
    "torch", "transformers", "accelerate",
    "fastapi", "uvicorn[standard]", "pydantic>=2.0",
    "httpx", "structlog", "numpy", "scipy",
    "networkx",
]
subprocess.run([sys.executable, "-m", "pip", "install", "-q"] + PACKAGES, check=True)
subprocess.run(["wget", "-q", "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64", "-O", "/usr/local/bin/cloudflared"], check=True)
subprocess.run(["chmod", "+x", "/usr/local/bin/cloudflared"], check=True)

# ═══════════════════════════════════════════════════════════════
# MODEL CONFIGURATION (TPU-AWARE)
# ═══════════════════════════════════════════════════════════════

@dataclass
class ModelConfig:
    name: str
    hf_id: str
    max_tokens: int
    quantization: str
    task_types: List[str]
    temperature_default: float
    tpu_compatible: bool

MODELS = {
    "qwen3-embed-8b": ModelConfig(
        name="qwen3-embed-8b",
        hf_id="Qwen/Qwen3-Embedding-8B",
        max_tokens=fib(16) * 8,                    # 7896
        quantization="int4",
        task_types=["embedding", "retrieval", "semantic-routing"],
        temperature_default=round(PSI * PSI, 3),   # 0.382
        tpu_compatible=True,
    ),
    "qwen25-coder-32b": ModelConfig(
        name="qwen25-coder-32b",
        hf_id="Qwen/Qwen2.5-Coder-32B-Instruct",
        max_tokens=fib(16) * 4,                    # 3948
        quantization="int4",
        task_types=["code-routing", "pipeline-generation", "code-review"],
        temperature_default=round(PSI * PSI, 3),   # 0.382
        tpu_compatible=True,
    ),
    "deepseek-r1-32b": ModelConfig(
        name="deepseek-r1-32b",
        hf_id="deepseek-ai/DeepSeek-R1-Distill-Qwen-32B",
        max_tokens=fib(16) * 4,                    # 3948
        quantization="int4",
        task_types=["reasoning", "planning", "complex-routing", "consensus"],
        temperature_default=round(PSI, 3),          # 0.618
        tpu_compatible=True,
    ),
    "gemma3-12b": ModelConfig(
        name="gemma3-12b",
        hf_id="google/gemma-3-12b-it",
        max_tokens=fib(16) * 8,                    # 7896
        quantization="int4",
        task_types=["classify", "gate-eval", "quick-route", "moe-dispatch"],
        temperature_default=round(PSI * PSI * PSI, 3),  # 0.236
        tpu_compatible=True,
    ),
}

# ═══════════════════════════════════════════════════════════════
# STRUCTURED LOGGING WITH CORRELATION IDS
# ═══════════════════════════════════════════════════════════════

import structlog

structlog.configure(
    processors=[
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.add_log_level,
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.JSONRenderer(),
    ],
    wrapper_class=structlog.BoundLogger,
    context_class=dict,
    logger_factory=structlog.PrintLoggerFactory(),
)

log = structlog.get_logger()

def new_correlation_id() -> str:
    return uuid.uuid4().hex[:fib(7)]  # 13-char correlation ID

# ═══════════════════════════════════════════════════════════════
# CSL ENGINE — GATE EVALUATION, MOE ROUTING, TERNARY LOGIC
# ═══════════════════════════════════════════════════════════════

class TernaryValue(Enum):
    FALSE = -1
    UNKNOWN = 0
    TRUE = 1

class CSLEngine:
    """Coherence Signaling Logic engine with ternary gate evaluation and MoE routing."""

    def __init__(self):
        self._gate_cache = OrderedDict()
        self._cache_size = fib(16)                     # 987
        self._moe_top_k = fib(4)                       # 3
        self._metrics = {
            "gate_evaluations": 0,
            "cache_hits": 0,
            "moe_dispatches": 0,
            "ternary_evaluations": 0,
        }

    def _cache_key(self, gate_id: str, inputs_hash: str) -> str:
        return hashlib.sha256(f"{gate_id}:{inputs_hash}".encode()).hexdigest()[:16]

    def evaluate_gate(self, gate_id: str, coherence_score: float,
                      threshold_level: str = "MEDIUM") -> Dict:
        """Evaluate a CSL gate against phi-derived threshold."""
        self._metrics["gate_evaluations"] += 1
        threshold = CSL_THRESHOLDS.get(threshold_level, CSL_THRESHOLDS["MEDIUM"])

        inputs_hash = hashlib.sha256(
            f"{coherence_score:.6f}:{threshold_level}".encode()
        ).hexdigest()[:8]
        cache_key = self._cache_key(gate_id, inputs_hash)

        if cache_key in self._gate_cache:
            self._gate_cache.move_to_end(cache_key)
            self._metrics["cache_hits"] += 1
            return self._gate_cache[cache_key]

        passed = coherence_score >= threshold
        margin = coherence_score - threshold
        confidence = min(abs(margin) / (1.0 - threshold + 1e-10), 1.0)

        result = {
            "gate_id": gate_id,
            "passed": passed,
            "coherence_score": round(coherence_score, 6),
            "threshold": round(threshold, 6),
            "threshold_level": threshold_level,
            "margin": round(margin, 6),
            "confidence": round(confidence, 6),
            "ternary": TernaryValue.TRUE.value if passed else (
                TernaryValue.UNKNOWN.value if abs(margin) < PSI * PSI * (1.0 - threshold)
                else TernaryValue.FALSE.value
            ),
        }

        self._gate_cache[cache_key] = result
        if len(self._gate_cache) > self._cache_size:
            self._gate_cache.popitem(last=False)

        return result

    def evaluate_ternary(self, value_a: float, value_b: float,
                         threshold: float = None) -> Dict:
        """Ternary logic comparison with phi-scaled dead zone."""
        self._metrics["ternary_evaluations"] += 1
        threshold = threshold or (PSI * PSI * PSI)  # 0.236 dead zone
        diff = value_a - value_b

        if diff > threshold:
            result = TernaryValue.TRUE
        elif diff < -threshold:
            result = TernaryValue.FALSE
        else:
            result = TernaryValue.UNKNOWN

        return {
            "result": result.value,
            "result_label": result.name,
            "diff": round(diff, 6),
            "threshold": round(threshold, 6),
            "value_a": round(value_a, 6),
            "value_b": round(value_b, 6),
        }

    def moe_route(self, task_type: str, expert_scores: Dict[str, float]) -> Dict:
        """Mixture-of-Experts routing with phi-scaled gating."""
        self._metrics["moe_dispatches"] += 1

        if not expert_scores:
            return {"selected": [], "error": "no experts available"}

        sorted_experts = sorted(expert_scores.items(), key=lambda x: x[1], reverse=True)
        top_k = min(self._moe_top_k, len(sorted_experts))
        selected = sorted_experts[:top_k]

        total_score = sum(s for _, s in selected)
        weights = {}
        for expert_id, score in selected:
            weights[expert_id] = round(score / total_score, 6) if total_score > 0 else round(1.0 / top_k, 6)

        return {
            "task_type": task_type,
            "selected_experts": [{"expert_id": eid, "score": round(sc, 6), "weight": weights[eid]} for eid, sc in selected],
            "top_k": top_k,
            "total_candidates": len(expert_scores),
            "gating_threshold": round(CSL_THRESHOLDS["LOW"], 6),
        }

    def health(self):
        return {
            "gate_cache_size": len(self._gate_cache),
            "gate_cache_capacity": self._cache_size,
            "moe_top_k": self._moe_top_k,
            "thresholds": {k: round(v, 4) for k, v in CSL_THRESHOLDS.items()},
            "metrics": {**self._metrics},
        }

csl_engine = CSLEngine()

# ═══════════════════════════════════════════════════════════════
# SACRED GEOMETRY TOPOLOGY MANAGER
# ═══════════════════════════════════════════════════════════════

import numpy as np

class TopologyManager:
    """Sacred Geometry topology: node placement, coherence monitoring, phi-spiral layout."""

    def __init__(self):
        self._nodes = {}  # node_id -> {position, coherence, load, last_seen}
        self._edges = {}  # (src, dst) -> {latency_ms, bandwidth, coherence}
        self._refresh_interval_ms = int(os.environ.get("TOPOLOGY_REFRESH_MS", "8090"))
        self._golden_angle = 2 * math.pi * PSI * PSI  # ~137.5° in radians
        self._metrics = {
            "nodes_registered": 0,
            "topology_refreshes": 0,
            "coherence_checks": 0,
            "rebalances": 0,
        }

    def register_node(self, node_id: str, role: str, endpoint: str,
                      capacity: int = fib(8)) -> Dict:
        """Register a node with phi-spiral placement."""
        index = len(self._nodes)
        angle = index * self._golden_angle
        radius = PHI * math.sqrt(index + 1)
        position = {
            "x": round(radius * math.cos(angle), 6),
            "y": round(radius * math.sin(angle), 6),
            "layer": index // fib(5),  # 5 nodes per layer
            "spiral_index": index,
        }

        self._nodes[node_id] = {
            "node_id": node_id,
            "role": role,
            "endpoint": endpoint,
            "position": position,
            "capacity": capacity,
            "active_tasks": 0,
            "coherence_score": CSL_THRESHOLDS["HIGH"],
            "last_seen": time.time(),
            "registered_at": time.time(),
        }
        self._metrics["nodes_registered"] += 1

        log.info("node_registered", node_id=node_id, role=role,
                 position_x=position["x"], position_y=position["y"])

        return {"registered": True, "node_id": node_id, "position": position}

    def update_node_coherence(self, node_id: str, coherence_score: float,
                              active_tasks: int = 0) -> Dict:
        """Update node coherence score and task count."""
        self._metrics["coherence_checks"] += 1

        if node_id not in self._nodes:
            return {"error": f"Node {node_id} not registered"}

        node = self._nodes[node_id]
        previous_coherence = node["coherence_score"]
        node["coherence_score"] = coherence_score
        node["active_tasks"] = active_tasks
        node["last_seen"] = time.time()

        gate_result = csl_engine.evaluate_gate(
            gate_id=f"topology-{node_id}",
            coherence_score=coherence_score,
            threshold_level="LOW",
        )

        return {
            "node_id": node_id,
            "coherence_score": round(coherence_score, 6),
            "previous_coherence": round(previous_coherence, 6),
            "gate_passed": gate_result["passed"],
            "healthy": gate_result["passed"],
        }

    def register_edge(self, src_id: str, dst_id: str, latency_ms: float,
                      bandwidth_mbps: float = 0.0) -> Dict:
        """Register an edge between two nodes with coherence weighting."""
        if src_id not in self._nodes or dst_id not in self._nodes:
            return {"error": "Both nodes must be registered"}

        src_pos = self._nodes[src_id]["position"]
        dst_pos = self._nodes[dst_id]["position"]
        distance = math.sqrt(
            (src_pos["x"] - dst_pos["x"]) ** 2 + (src_pos["y"] - dst_pos["y"]) ** 2
        )

        src_coh = self._nodes[src_id]["coherence_score"]
        dst_coh = self._nodes[dst_id]["coherence_score"]
        edge_coherence = round((src_coh + dst_coh) / PHI2, 6)  # Phi-weighted average

        self._edges[(src_id, dst_id)] = {
            "latency_ms": latency_ms,
            "bandwidth_mbps": bandwidth_mbps,
            "distance": round(distance, 6),
            "coherence": edge_coherence,
        }

        return {
            "edge": f"{src_id}->{dst_id}",
            "latency_ms": latency_ms,
            "distance": round(distance, 6),
            "coherence": edge_coherence,
        }

    def get_topology_snapshot(self) -> Dict:
        """Get full topology state."""
        self._metrics["topology_refreshes"] += 1
        now = time.time()
        stale_threshold = self._refresh_interval_ms / 1000.0 * PHI  # ~13.1s

        node_states = []
        for nid, node in self._nodes.items():
            age_s = now - node["last_seen"]
            node_states.append({
                **node,
                "stale": age_s > stale_threshold,
                "age_s": round(age_s, 1),
            })

        total_coherence = sum(n["coherence_score"] for n in self._nodes.values())
        avg_coherence = total_coherence / len(self._nodes) if self._nodes else 0.0

        return {
            "node_count": len(self._nodes),
            "edge_count": len(self._edges),
            "avg_coherence": round(avg_coherence, 6),
            "nodes": node_states,
            "edges": [
                {"src": k[0], "dst": k[1], **v}
                for k, v in self._edges.items()
            ],
        }

    def select_node(self, task_type: str, min_coherence: str = "LOW") -> Optional[Dict]:
        """Select optimal node for a task based on coherence and load."""
        threshold = CSL_THRESHOLDS.get(min_coherence, CSL_THRESHOLDS["LOW"])
        candidates = []

        for nid, node in self._nodes.items():
            if node["coherence_score"] < threshold:
                continue
            if node["active_tasks"] >= node["capacity"]:
                continue
            load_ratio = node["active_tasks"] / node["capacity"] if node["capacity"] > 0 else 1.0
            score = node["coherence_score"] * (1.0 - load_ratio * PSI)
            candidates.append((nid, node, score))

        if not candidates:
            return None

        candidates.sort(key=lambda x: x[2], reverse=True)
        best_id, best_node, best_score = candidates[0]

        return {
            "node_id": best_id,
            "role": best_node["role"],
            "endpoint": best_node["endpoint"],
            "coherence_score": round(best_node["coherence_score"], 6),
            "selection_score": round(best_score, 6),
            "candidates_evaluated": len(candidates),
        }

    def health(self):
        return {
            "node_count": len(self._nodes),
            "edge_count": len(self._edges),
            "refresh_interval_ms": self._refresh_interval_ms,
            "metrics": {**self._metrics},
        }

topology = TopologyManager()

# Register built-in runtime nodes
for role, endpoint in RUNTIME_ENDPOINTS.items():
    topology.register_node(
        node_id=f"runtime-{role}",
        role=role,
        endpoint=endpoint,
        capacity=fib(8),  # 21
    )

# ═══════════════════════════════════════════════════════════════
# HEADYBEE SWARM COORDINATION
# ═══════════════════════════════════════════════════════════════

class BeeState(Enum):
    IDLE = "idle"
    WORKING = "working"
    WAITING = "waiting"
    RETURNING = "returning"
    DEAD = "dead"

@dataclass
class HeadyBee:
    bee_id: str
    task_id: str
    state: BeeState
    coherence_score: float
    payload: Dict
    created_at: float
    last_heartbeat: float

class SwarmCoordinator:
    """HeadyBee swarm: bee factory, consensus, load balancing with phi-scaled thresholds."""

    def __init__(self):
        self._bees = {}  # bee_id -> HeadyBee
        self._max_bees = fib(12)                           # 144
        self._consensus_quorum = float(os.environ.get("CONSENSUS_QUORUM_RATIO", str(round(PSI, 3))))
        self._heartbeat_timeout_s = fib(8) * PHI           # ~34s
        self._bee_counter = 0
        self._metrics = {
            "bees_spawned": 0,
            "bees_completed": 0,
            "bees_failed": 0,
            "consensus_rounds": 0,
            "rebalances": 0,
        }

    def spawn_bee(self, task_id: str, payload: Dict = None) -> Dict:
        """Spawn a new HeadyBee worker."""
        active_count = sum(1 for b in self._bees.values() if b.state != BeeState.DEAD)
        if active_count >= self._max_bees:
            return {"error": "Swarm at capacity", "max_bees": self._max_bees, "active": active_count}

        self._bee_counter += 1
        bee_id = f"bee-{self._bee_counter:04d}-{uuid.uuid4().hex[:fib(5)]}"  # 5-char suffix

        bee = HeadyBee(
            bee_id=bee_id,
            task_id=task_id,
            state=BeeState.WORKING,
            coherence_score=CSL_THRESHOLDS["HIGH"],
            payload=payload or {},
            created_at=time.time(),
            last_heartbeat=time.time(),
        )
        self._bees[bee_id] = bee
        self._metrics["bees_spawned"] += 1

        log.info("bee_spawned", bee_id=bee_id, task_id=task_id)
        return {"spawned": True, "bee_id": bee_id, "task_id": task_id}

    def heartbeat(self, bee_id: str, coherence_score: float = None,
                  state: str = None) -> Dict:
        """Process bee heartbeat."""
        if bee_id not in self._bees:
            return {"error": f"Unknown bee: {bee_id}"}

        bee = self._bees[bee_id]
        bee.last_heartbeat = time.time()

        if coherence_score is not None:
            bee.coherence_score = coherence_score
        if state:
            try:
                bee.state = BeeState(state)
            except ValueError:
                return {"error": f"Invalid state: {state}"}

        return {
            "bee_id": bee_id,
            "state": bee.state.value,
            "coherence_score": round(bee.coherence_score, 6),
        }

    def complete_bee(self, bee_id: str, result: Dict = None) -> Dict:
        """Mark bee as completed and collect result."""
        if bee_id not in self._bees:
            return {"error": f"Unknown bee: {bee_id}"}

        bee = self._bees[bee_id]
        bee.state = BeeState.DEAD
        self._metrics["bees_completed"] += 1

        log.info("bee_completed", bee_id=bee_id, task_id=bee.task_id,
                 duration_s=round(time.time() - bee.created_at, 2))

        return {
            "bee_id": bee_id,
            "task_id": bee.task_id,
            "duration_s": round(time.time() - bee.created_at, 2),
            "result": result,
        }

    def run_consensus(self, topic: str, votes: Dict[str, float]) -> Dict:
        """Run phi-quorum consensus across bee votes."""
        self._metrics["consensus_rounds"] += 1

        if not votes:
            return {"consensus": False, "reason": "no votes"}

        total_voters = len(votes)
        quorum_needed = max(1, int(math.ceil(total_voters * self._consensus_quorum)))

        positive_votes = {k: v for k, v in votes.items() if v >= CSL_THRESHOLDS["MEDIUM"]}
        negative_votes = {k: v for k, v in votes.items() if v < CSL_THRESHOLDS["MINIMUM"]}
        uncertain_votes = {
            k: v for k, v in votes.items()
            if CSL_THRESHOLDS["MINIMUM"] <= v < CSL_THRESHOLDS["MEDIUM"]
        }

        consensus_reached = len(positive_votes) >= quorum_needed
        avg_confidence = sum(votes.values()) / total_voters if total_voters > 0 else 0.0

        log.info("consensus_round", topic=topic, reached=consensus_reached,
                 positive=len(positive_votes), quorum=quorum_needed)

        return {
            "topic": topic,
            "consensus": consensus_reached,
            "quorum_needed": quorum_needed,
            "total_voters": total_voters,
            "positive": len(positive_votes),
            "negative": len(negative_votes),
            "uncertain": len(uncertain_votes),
            "avg_confidence": round(avg_confidence, 6),
            "quorum_ratio": round(self._consensus_quorum, 3),
        }

    def rebalance(self) -> Dict:
        """Rebalance swarm by retiring stale bees and redistributing load."""
        self._metrics["rebalances"] += 1
        now = time.time()
        retired = []

        for bee_id, bee in list(self._bees.items()):
            if bee.state == BeeState.DEAD:
                continue
            age_s = now - bee.last_heartbeat
            if age_s > self._heartbeat_timeout_s:
                bee.state = BeeState.DEAD
                self._metrics["bees_failed"] += 1
                retired.append(bee_id)
                log.warning("bee_retired_stale", bee_id=bee_id,
                            last_heartbeat_age_s=round(age_s, 1))

        coherence_below = sum(
            1 for b in self._bees.values()
            if b.state != BeeState.DEAD and b.coherence_score < CSL_THRESHOLDS["LOW"]
        )

        active = sum(1 for b in self._bees.values() if b.state != BeeState.DEAD)

        return {
            "active_bees": active,
            "retired_stale": len(retired),
            "retired_ids": retired,
            "low_coherence_count": coherence_below,
            "max_bees": self._max_bees,
        }

    def get_swarm_status(self) -> Dict:
        """Get full swarm status."""
        by_state = {}
        for bee in self._bees.values():
            s = bee.state.value
            by_state[s] = by_state.get(s, 0) + 1

        active_bees = [
            {
                "bee_id": b.bee_id,
                "task_id": b.task_id,
                "state": b.state.value,
                "coherence_score": round(b.coherence_score, 4),
                "age_s": round(time.time() - b.created_at, 1),
            }
            for b in self._bees.values()
            if b.state != BeeState.DEAD
        ]

        return {
            "total_bees": len(self._bees),
            "by_state": by_state,
            "active_bees": active_bees,
            "max_bees": self._max_bees,
        }

    def health(self):
        active = sum(1 for b in self._bees.values() if b.state != BeeState.DEAD)
        return {
            "active_bees": active,
            "max_bees": self._max_bees,
            "consensus_quorum": round(self._consensus_quorum, 3),
            "metrics": {**self._metrics},
        }

swarm = SwarmCoordinator()

# ═══════════════════════════════════════════════════════════════
# HEADYCONDUCTOR — HCFP PIPELINE ORCHESTRATION
# ═══════════════════════════════════════════════════════════════

class PipelineState(Enum):
    PENDING = "pending"
    RUNNING = "running"
    WAITING_CONSENSUS = "waiting_consensus"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class PipelineStage:
    stage_id: str
    stage_type: str          # "csl_gate", "moe_route", "runtime_call", "swarm_dispatch", "transform"
    target_runtime: str      # "vector_ops", "llm_inference", "training", "local"
    config: Dict
    status: str = "pending"
    result: Dict = field(default_factory=dict)
    started_at: float = 0.0
    completed_at: float = 0.0

@dataclass
class Pipeline:
    pipeline_id: str
    correlation_id: str
    task_type: str
    stages: List[PipelineStage]
    state: PipelineState
    created_at: float
    completed_at: float = 0.0
    retries: int = 0
    max_retries: int = fib(4)   # 3
    result: Dict = field(default_factory=dict)

class HeadyConductor:
    """HCFP pipeline orchestration with CSL-gated stages and phi-scaled retries."""

    def __init__(self):
        self._pipelines = OrderedDict()
        self._max_concurrent = fib(7)  # 13
        self._semaphore = threading.Semaphore(self._max_concurrent)
        self._metrics = {
            "pipelines_created": 0,
            "pipelines_succeeded": 0,
            "pipelines_failed": 0,
            "stages_executed": 0,
            "retries": 0,
        }

    def create_pipeline(self, task_type: str, stages: List[Dict]) -> Dict:
        """Create a new HCFP pipeline."""
        correlation_id = new_correlation_id()
        pipeline_id = f"pipe-{int(time.time())}-{correlation_id[:fib(5)]}"

        pipeline_stages = []
        for i, stage_cfg in enumerate(stages):
            stage = PipelineStage(
                stage_id=f"{pipeline_id}-s{i}",
                stage_type=stage_cfg.get("type", "runtime_call"),
                target_runtime=stage_cfg.get("target", "local"),
                config=stage_cfg.get("config", {}),
            )
            pipeline_stages.append(stage)

        pipeline = Pipeline(
            pipeline_id=pipeline_id,
            correlation_id=correlation_id,
            task_type=task_type,
            stages=pipeline_stages,
            state=PipelineState.PENDING,
            created_at=time.time(),
        )

        self._pipelines[pipeline_id] = pipeline
        self._metrics["pipelines_created"] += 1

        log.info("pipeline_created", pipeline_id=pipeline_id,
                 correlation_id=correlation_id, task_type=task_type,
                 stage_count=len(pipeline_stages))

        return {
            "pipeline_id": pipeline_id,
            "correlation_id": correlation_id,
            "task_type": task_type,
            "stage_count": len(pipeline_stages),
            "state": pipeline.state.value,
        }

    def execute_pipeline(self, pipeline_id: str) -> Dict:
        """Execute a pipeline stage-by-stage with CSL gating."""
        if pipeline_id not in self._pipelines:
            return {"error": f"Unknown pipeline: {pipeline_id}"}

        pipeline = self._pipelines[pipeline_id]

        if not self._semaphore.acquire(timeout=fib(8)):  # 21s
            return {"error": "Pipeline queue full", "pipeline_id": pipeline_id}

        try:
            pipeline.state = PipelineState.RUNNING
            stage_results = []

            for stage in pipeline.stages:
                stage.started_at = time.time()
                stage.status = "running"
                self._metrics["stages_executed"] += 1

                result = self._execute_stage(stage, pipeline.correlation_id)
                stage.result = result
                stage.completed_at = time.time()

                if result.get("error"):
                    stage.status = "failed"
                    if pipeline.retries < pipeline.max_retries:
                        pipeline.retries += 1
                        self._metrics["retries"] += 1
                        wait_s = phi_backoff(pipeline.retries)
                        log.warning("stage_retry", pipeline_id=pipeline_id,
                                    stage_id=stage.stage_id, attempt=pipeline.retries,
                                    backoff_s=round(wait_s, 2))
                        time.sleep(wait_s)
                        result = self._execute_stage(stage, pipeline.correlation_id)
                        stage.result = result
                        stage.completed_at = time.time()
                        if result.get("error"):
                            stage.status = "failed"
                            pipeline.state = PipelineState.FAILED
                            pipeline.completed_at = time.time()
                            self._metrics["pipelines_failed"] += 1
                            return self._pipeline_summary(pipeline)
                        stage.status = "succeeded"
                    else:
                        pipeline.state = PipelineState.FAILED
                        pipeline.completed_at = time.time()
                        self._metrics["pipelines_failed"] += 1
                        return self._pipeline_summary(pipeline)
                else:
                    stage.status = "succeeded"

                stage_results.append({
                    "stage_id": stage.stage_id,
                    "type": stage.stage_type,
                    "status": stage.status,
                    "duration_ms": round((stage.completed_at - stage.started_at) * 1000),
                })

            pipeline.state = PipelineState.SUCCEEDED
            pipeline.completed_at = time.time()
            pipeline.result = {"stages": stage_results}
            self._metrics["pipelines_succeeded"] += 1

            log.info("pipeline_succeeded", pipeline_id=pipeline_id,
                     correlation_id=pipeline.correlation_id,
                     duration_ms=round((pipeline.completed_at - pipeline.created_at) * 1000))

            return self._pipeline_summary(pipeline)

        finally:
            self._semaphore.release()

    def _execute_stage(self, stage: PipelineStage, correlation_id: str) -> Dict:
        """Execute a single pipeline stage."""
        log.info("stage_executing", stage_id=stage.stage_id,
                 stage_type=stage.stage_type, target=stage.target_runtime,
                 correlation_id=correlation_id)

        if stage.stage_type == "csl_gate":
            coherence = stage.config.get("coherence_score", CSL_THRESHOLDS["HIGH"])
            level = stage.config.get("threshold_level", "MEDIUM")
            gate_result = csl_engine.evaluate_gate(stage.stage_id, coherence, level)
            if not gate_result["passed"]:
                return {"error": "CSL gate failed", "gate": gate_result}
            return gate_result

        elif stage.stage_type == "moe_route":
            task_type = stage.config.get("task_type", "general")
            experts = stage.config.get("expert_scores", {})
            return csl_engine.moe_route(task_type, experts)

        elif stage.stage_type == "swarm_dispatch":
            task_id = stage.config.get("task_id", stage.stage_id)
            payload = stage.config.get("payload", {})
            return swarm.spawn_bee(task_id, payload)

        elif stage.stage_type == "topology_select":
            task_type = stage.config.get("task_type", "general")
            min_coherence = stage.config.get("min_coherence", "LOW")
            node = topology.select_node(task_type, min_coherence)
            if node is None:
                return {"error": "No suitable node found"}
            return node

        elif stage.stage_type == "runtime_call":
            target = stage.target_runtime
            endpoint = RUNTIME_ENDPOINTS.get(target)
            if not endpoint:
                return {"error": f"Unknown runtime: {target}"}
            return self._call_runtime(endpoint, stage.config, correlation_id)

        elif stage.stage_type == "transform":
            return {"transformed": True, "config": stage.config}

        return {"error": f"Unknown stage type: {stage.stage_type}"}

    def _call_runtime(self, endpoint: str, config: Dict, correlation_id: str) -> Dict:
        """Call a sibling runtime via HTTP with correlation ID."""
        import httpx

        path = config.get("path", "/health")
        method = config.get("method", "GET").upper()
        body = config.get("body", None)
        timeout_ms = int(os.environ.get("INTER_RUNTIME_TIMEOUT_MS", "21000"))

        headers = {
            "X-Correlation-ID": correlation_id,
            "X-Source-Runtime": "orchestration",
            "Content-Type": "application/json",
        }

        url = f"{endpoint}{path}"

        try:
            with httpx.Client(timeout=timeout_ms / 1000.0) as client:
                if method == "GET":
                    resp = client.get(url, headers=headers)
                elif method == "POST":
                    resp = client.post(url, headers=headers, json=body)
                else:
                    return {"error": f"Unsupported method: {method}"}

                resp.raise_for_status()
                return {"status_code": resp.status_code, "data": resp.json()}

        except httpx.TimeoutException:
            log.error("runtime_call_timeout", url=url, timeout_ms=timeout_ms,
                      correlation_id=correlation_id)
            return {"error": "timeout", "url": url, "timeout_ms": timeout_ms}
        except httpx.HTTPStatusError as e:
            log.error("runtime_call_error", url=url, status=e.response.status_code,
                      correlation_id=correlation_id)
            return {"error": "http_error", "status_code": e.response.status_code, "url": url}
        except Exception as e:
            log.error("runtime_call_exception", url=url, error=str(e),
                      correlation_id=correlation_id)
            return {"error": str(e), "url": url}

    def _pipeline_summary(self, pipeline: Pipeline) -> Dict:
        duration_ms = round(
            ((pipeline.completed_at or time.time()) - pipeline.created_at) * 1000
        )
        return {
            "pipeline_id": pipeline.pipeline_id,
            "correlation_id": pipeline.correlation_id,
            "task_type": pipeline.task_type,
            "state": pipeline.state.value,
            "stage_count": len(pipeline.stages),
            "retries": pipeline.retries,
            "duration_ms": duration_ms,
            "stages": [
                {
                    "stage_id": s.stage_id,
                    "type": s.stage_type,
                    "target": s.target_runtime,
                    "status": s.status,
                    "duration_ms": round((s.completed_at - s.started_at) * 1000) if s.completed_at else 0,
                }
                for s in pipeline.stages
            ],
        }

    def get_pipeline(self, pipeline_id: str) -> Optional[Dict]:
        pipeline = self._pipelines.get(pipeline_id)
        if not pipeline:
            return None
        return self._pipeline_summary(pipeline)

    def list_pipelines(self, limit: int = fib(8)) -> List[Dict]:
        """List recent pipelines."""
        items = list(self._pipelines.values())[-limit:]
        return [self._pipeline_summary(p) for p in reversed(items)]

    def health(self):
        active = sum(
            1 for p in self._pipelines.values()
            if p.state in (PipelineState.PENDING, PipelineState.RUNNING, PipelineState.WAITING_CONSENSUS)
        )
        return {
            "active_pipelines": active,
            "max_concurrent": self._max_concurrent,
            "total_pipelines": len(self._pipelines),
            "metrics": {**self._metrics},
        }

conductor = HeadyConductor()

# ═══════════════════════════════════════════════════════════════
# BACKPRESSURE MANAGER & SRE ADAPTIVE THROTTLING
# ═══════════════════════════════════════════════════════════════

class BackpressureManager:
    """SRE adaptive throttling with phi-scaled backpressure windows."""

    def __init__(self):
        self._window_ms = int(os.environ.get("BACKPRESSURE_WINDOW_MS", "23300"))
        self._window_size = fib(11)                # 89 samples per window
        self._request_log = deque(maxlen=self._window_size)
        self._error_log = deque(maxlen=self._window_size)
        self._throttle_level = 0                   # 0=none, 1=light, 2=moderate, 3=heavy, 4=shed
        self._throttle_thresholds = {
            0: CSL_THRESHOLDS["HIGH"],             # Below 0.882 error rate → no throttle
            1: CSL_THRESHOLDS["MEDIUM"],           # 0.809 → light
            2: CSL_THRESHOLDS["LOW"],              # 0.691 → moderate
            3: CSL_THRESHOLDS["MINIMUM"],          # 0.500 → heavy
        }
        self._shed_rate = round(PSI * PSI, 3)      # 0.382 — shed 38.2% of requests at max
        self._metrics = {
            "total_requests": 0,
            "throttled_requests": 0,
            "shed_requests": 0,
            "level_changes": 0,
        }

    def record_request(self, success: bool, latency_ms: float):
        """Record a request outcome for backpressure calculation."""
        now = time.time()
        self._request_log.append({"ts": now, "latency_ms": latency_ms, "success": success})
        if not success:
            self._error_log.append({"ts": now, "latency_ms": latency_ms})
        self._metrics["total_requests"] += 1
        self._update_throttle_level()

    def _update_throttle_level(self):
        """Recalculate throttle level based on recent error rates."""
        if len(self._request_log) < fib(5):  # Need at least 5 samples
            return

        now = time.time()
        window_start = now - (self._window_ms / 1000.0)

        recent = [r for r in self._request_log if r["ts"] >= window_start]
        if not recent:
            return

        success_count = sum(1 for r in recent if r["success"])
        success_rate = success_count / len(recent)

        old_level = self._throttle_level

        if success_rate >= self._throttle_thresholds[0]:
            self._throttle_level = 0
        elif success_rate >= self._throttle_thresholds[1]:
            self._throttle_level = 1
        elif success_rate >= self._throttle_thresholds[2]:
            self._throttle_level = 2
        elif success_rate >= self._throttle_thresholds[3]:
            self._throttle_level = 3
        else:
            self._throttle_level = 4

        if old_level != self._throttle_level:
            self._metrics["level_changes"] += 1
            log.info("throttle_level_changed", old=old_level, new=self._throttle_level,
                     success_rate=round(success_rate, 4))

    def should_admit(self) -> Dict:
        """Decide whether to admit a new request based on current backpressure."""
        if self._throttle_level == 0:
            return {"admit": True, "throttle_level": 0, "reason": "no_backpressure"}

        if self._throttle_level >= 4:
            import random
            if random.random() < self._shed_rate:
                self._metrics["shed_requests"] += 1
                return {"admit": False, "throttle_level": 4, "reason": "load_shed"}

        delay_ms = round(phi_backoff(self._throttle_level, base_s=0.1, max_s=5.0) * 1000)
        self._metrics["throttled_requests"] += 1

        return {
            "admit": True,
            "throttle_level": self._throttle_level,
            "delay_ms": delay_ms,
            "reason": "throttled",
        }

    def get_status(self) -> Dict:
        now = time.time()
        window_start = now - (self._window_ms / 1000.0)
        recent = [r for r in self._request_log if r["ts"] >= window_start]
        success_count = sum(1 for r in recent if r["success"])
        latencies = [r["latency_ms"] for r in recent]

        return {
            "throttle_level": self._throttle_level,
            "window_ms": self._window_ms,
            "recent_requests": len(recent),
            "success_rate": round(success_count / len(recent), 4) if recent else 1.0,
            "avg_latency_ms": round(sum(latencies) / len(latencies), 2) if latencies else 0.0,
            "p95_latency_ms": round(
                sorted(latencies)[int(len(latencies) * 0.95)] if latencies else 0.0, 2
            ),
            "shed_rate": self._shed_rate,
        }

    def health(self):
        return {
            "throttle_level": self._throttle_level,
            "window_ms": self._window_ms,
            "metrics": {**self._metrics},
        }

backpressure = BackpressureManager()

# ═══════════════════════════════════════════════════════════════
# INTER-RUNTIME COMMUNICATION BROKER
# ═══════════════════════════════════════════════════════════════

class RuntimeBroker:
    """Coordinates communication between runtimes 1-3 with health monitoring."""

    def __init__(self):
        self._runtime_health = {}  # runtime_role -> {status, last_check, latency_ms}
        self._check_interval_s = fib(7)  # 13s between health checks
        self._metrics = {
            "health_checks": 0,
            "messages_routed": 0,
            "errors": 0,
        }

    def check_runtime_health(self, role: str) -> Dict:
        """Check health of a sibling runtime."""
        self._metrics["health_checks"] += 1
        endpoint = RUNTIME_ENDPOINTS.get(role)

        if not endpoint:
            return {"role": role, "status": "unknown", "error": "no endpoint configured"}

        import httpx

        correlation_id = new_correlation_id()
        start = time.time()

        try:
            with httpx.Client(timeout=fib(5)) as client:
                resp = client.get(
                    f"{endpoint}/health",
                    headers={
                        "X-Correlation-ID": correlation_id,
                        "X-Source-Runtime": "orchestration",
                    },
                )
                resp.raise_for_status()
                latency_ms = round((time.time() - start) * 1000, 2)
                data = resp.json()

                self._runtime_health[role] = {
                    "status": "healthy",
                    "last_check": time.time(),
                    "latency_ms": latency_ms,
                    "data": data,
                }

                topology.update_node_coherence(
                    f"runtime-{role}",
                    data.get("coherence_score", CSL_THRESHOLDS["HIGH"]),
                    data.get("active_tasks", 0),
                )

                return {"role": role, "status": "healthy", "latency_ms": latency_ms}

        except Exception as e:
            latency_ms = round((time.time() - start) * 1000, 2)
            self._metrics["errors"] += 1
            self._runtime_health[role] = {
                "status": "unhealthy",
                "last_check": time.time(),
                "latency_ms": latency_ms,
                "error": str(e),
            }

            topology.update_node_coherence(f"runtime-{role}", 0.0, 0)
            log.error("runtime_health_check_failed", role=role, error=str(e),
                      correlation_id=correlation_id)

            return {"role": role, "status": "unhealthy", "error": str(e), "latency_ms": latency_ms}

    def route_message(self, target_role: str, path: str, method: str = "POST",
                      body: Dict = None) -> Dict:
        """Route a message to a sibling runtime."""
        self._metrics["messages_routed"] += 1
        correlation_id = new_correlation_id()

        admission = backpressure.should_admit()
        if not admission["admit"]:
            log.warning("message_shed", target=target_role, path=path,
                        correlation_id=correlation_id)
            return {"error": "load_shed", "throttle_level": admission["throttle_level"]}

        if admission.get("delay_ms", 0) > 0:
            time.sleep(admission["delay_ms"] / 1000.0)

        start = time.time()
        result = conductor._call_runtime(
            RUNTIME_ENDPOINTS.get(target_role, ""),
            {"path": path, "method": method, "body": body},
            correlation_id,
        )
        latency_ms = round((time.time() - start) * 1000, 2)

        success = "error" not in result
        backpressure.record_request(success, latency_ms)

        return {
            "correlation_id": correlation_id,
            "target": target_role,
            "path": path,
            "latency_ms": latency_ms,
            "success": success,
            "result": result,
        }

    def check_all_runtimes(self) -> Dict:
        """Health check all sibling runtimes."""
        results = {}
        for role in RUNTIME_ENDPOINTS:
            results[role] = self.check_runtime_health(role)
        return results

    def health(self):
        return {
            "runtimes": {
                role: {
                    "status": info.get("status", "unknown"),
                    "latency_ms": info.get("latency_ms", 0),
                }
                for role, info in self._runtime_health.items()
            },
            "check_interval_s": self._check_interval_s,
            "metrics": {**self._metrics},
        }

broker = RuntimeBroker()

# ═══════════════════════════════════════════════════════════════
# BACKGROUND TOPOLOGY HEALTH MONITOR
# ═══════════════════════════════════════════════════════════════

def _topology_health_loop():
    """Background thread: periodically check sibling runtimes and rebalance swarm."""
    interval_s = fib(7)  # 13s
    while True:
        try:
            broker.check_all_runtimes()
            swarm.rebalance()
        except Exception as e:
            log.error("topology_health_loop_error", error=str(e))
        time.sleep(interval_s)

topology_monitor_thread = threading.Thread(target=_topology_health_loop, daemon=True)
topology_monitor_thread.start()

# ═══════════════════════════════════════════════════════════════
# FASTAPI SERVICE
# ═══════════════════════════════════════════════════════════════

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel
import uvicorn

app = FastAPI(title="Heady Orchestration & Swarm Runtime", version="4.1.0")
start_time = time.time()

# --- Request/Response Models ---

class CSLGateRequest(BaseModel):
    gate_id: str
    coherence_score: float
    threshold_level: str = "MEDIUM"

class TernaryRequest(BaseModel):
    value_a: float
    value_b: float
    threshold: Optional[float] = None

class MoERouteRequest(BaseModel):
    task_type: str
    expert_scores: Dict[str, float]

class NodeRegisterRequest(BaseModel):
    node_id: str
    role: str
    endpoint: str
    capacity: int = fib(8)

class NodeCoherenceRequest(BaseModel):
    node_id: str
    coherence_score: float
    active_tasks: int = 0

class EdgeRegisterRequest(BaseModel):
    src_id: str
    dst_id: str
    latency_ms: float
    bandwidth_mbps: float = 0.0

class SpawnBeeRequest(BaseModel):
    task_id: str
    payload: Dict = {}

class BeeHeartbeatRequest(BaseModel):
    bee_id: str
    coherence_score: Optional[float] = None
    state: Optional[str] = None

class BeeCompleteRequest(BaseModel):
    bee_id: str
    result: Dict = {}

class ConsensusRequest(BaseModel):
    topic: str
    votes: Dict[str, float]

class PipelineCreateRequest(BaseModel):
    task_type: str
    stages: List[Dict]

class RuntimeMessageRequest(BaseModel):
    target_role: str
    path: str
    method: str = "POST"
    body: Dict = {}

# --- Middleware: correlation ID injection ---

@app.middleware("http")
async def correlation_id_middleware(request: Request, call_next):
    correlation_id = request.headers.get("X-Correlation-ID", new_correlation_id())
    request.state.correlation_id = correlation_id
    response = await call_next(request)
    response.headers["X-Correlation-ID"] = correlation_id
    return response

# --- Health ---

@app.get("/health")
async def health():
    return {
        "status": "healthy",
        "role": "orchestration",
        "runtime_id": "heady-orchestration-runtime",
        "gpu": os.environ.get("COLAB_GPU", "unknown"),
        "uptime_s": round(time.time() - start_time),
        "csl_engine": csl_engine.health(),
        "topology": topology.health(),
        "swarm": swarm.health(),
        "conductor": conductor.health(),
        "backpressure": backpressure.health(),
        "broker": broker.health(),
        "coherence_score": CSL_THRESHOLDS["HIGH"],
        "models": list(MODELS.keys()),
    }

# --- CSL Engine Endpoints ---

@app.post("/csl/gate")
async def csl_gate(req: CSLGateRequest):
    if req.threshold_level not in CSL_THRESHOLDS:
        raise HTTPException(400, f"Invalid threshold level. Valid: {list(CSL_THRESHOLDS.keys())}")
    return csl_engine.evaluate_gate(req.gate_id, req.coherence_score, req.threshold_level)

@app.post("/csl/ternary")
async def csl_ternary(req: TernaryRequest):
    return csl_engine.evaluate_ternary(req.value_a, req.value_b, req.threshold)

@app.post("/csl/moe_route")
async def csl_moe_route(req: MoERouteRequest):
    if not req.expert_scores:
        raise HTTPException(400, "expert_scores must not be empty")
    return csl_engine.moe_route(req.task_type, req.expert_scores)

# --- Topology Endpoints ---

@app.post("/topology/register_node")
async def topology_register_node(req: NodeRegisterRequest):
    return topology.register_node(req.node_id, req.role, req.endpoint, req.capacity)

@app.post("/topology/update_coherence")
async def topology_update_coherence(req: NodeCoherenceRequest):
    return topology.update_node_coherence(req.node_id, req.coherence_score, req.active_tasks)

@app.post("/topology/register_edge")
async def topology_register_edge(req: EdgeRegisterRequest):
    return topology.register_edge(req.src_id, req.dst_id, req.latency_ms, req.bandwidth_mbps)

@app.get("/topology/snapshot")
async def topology_snapshot():
    return topology.get_topology_snapshot()

@app.post("/topology/select_node")
async def topology_select_node(task_type: str = "general", min_coherence: str = "LOW"):
    node = topology.select_node(task_type, min_coherence)
    if node is None:
        raise HTTPException(404, "No suitable node found")
    return node

# --- Swarm Endpoints ---

@app.post("/swarm/spawn")
async def swarm_spawn(req: SpawnBeeRequest):
    result = swarm.spawn_bee(req.task_id, req.payload)
    if "error" in result:
        raise HTTPException(429, result["error"])
    return result

@app.post("/swarm/heartbeat")
async def swarm_heartbeat(req: BeeHeartbeatRequest):
    result = swarm.heartbeat(req.bee_id, req.coherence_score, req.state)
    if "error" in result:
        raise HTTPException(404, result["error"])
    return result

@app.post("/swarm/complete")
async def swarm_complete(req: BeeCompleteRequest):
    result = swarm.complete_bee(req.bee_id, req.result)
    if "error" in result:
        raise HTTPException(404, result["error"])
    return result

@app.post("/swarm/consensus")
async def swarm_consensus(req: ConsensusRequest):
    if not req.votes:
        raise HTTPException(400, "votes must not be empty")
    return swarm.run_consensus(req.topic, req.votes)

@app.post("/swarm/rebalance")
async def swarm_rebalance():
    return swarm.rebalance()

@app.get("/swarm/status")
async def swarm_status():
    return swarm.get_swarm_status()

# --- Pipeline / Conductor Endpoints ---

@app.post("/pipeline/create")
async def pipeline_create(req: PipelineCreateRequest):
    if not req.stages:
        raise HTTPException(400, "stages must not be empty")
    if len(req.stages) > fib(8):  # Max 21 stages
        raise HTTPException(400, f"Max {fib(8)} stages per pipeline")
    return conductor.create_pipeline(req.task_type, req.stages)

@app.post("/pipeline/{pipeline_id}/execute")
async def pipeline_execute(pipeline_id: str):
    result = conductor.execute_pipeline(pipeline_id)
    if "error" in result and "Unknown pipeline" in result.get("error", ""):
        raise HTTPException(404, result["error"])
    return result

@app.get("/pipeline/{pipeline_id}")
async def pipeline_get(pipeline_id: str):
    result = conductor.get_pipeline(pipeline_id)
    if result is None:
        raise HTTPException(404, f"Pipeline {pipeline_id} not found")
    return result

@app.get("/pipelines")
async def pipeline_list(limit: int = fib(8)):
    return conductor.list_pipelines(limit)

# --- Inter-Runtime Broker Endpoints ---

@app.post("/broker/route")
async def broker_route(req: RuntimeMessageRequest):
    if req.target_role not in RUNTIME_ENDPOINTS:
        raise HTTPException(400, f"Unknown runtime: {req.target_role}. Available: {list(RUNTIME_ENDPOINTS.keys())}")
    return broker.route_message(req.target_role, req.path, req.method, req.body)

@app.get("/broker/health_check")
async def broker_health_check():
    return broker.check_all_runtimes()

@app.get("/broker/runtime/{role}")
async def broker_runtime_health(role: str):
    if role not in RUNTIME_ENDPOINTS:
        raise HTTPException(404, f"Unknown runtime: {role}")
    return broker.check_runtime_health(role)

# --- Backpressure Endpoints ---

@app.get("/backpressure/status")
async def backpressure_status():
    return backpressure.get_status()

@app.get("/backpressure/admit")
async def backpressure_admit():
    return backpressure.should_admit()

# ═══════════════════════════════════════════════════════════════
# START SERVICES + CLOUDFLARE TUNNEL
# ═══════════════════════════════════════════════════════════════

api_thread = threading.Thread(
    target=lambda: uvicorn.run(app, host="0.0.0.0", port=3304, log_level="info"),
    daemon=True,
)
api_thread.start()

health_app = FastAPI()

@health_app.get("/health")
async def health_probe():
    return {"status": "healthy", "role": "orchestration", "uptime_s": round(time.time() - start_time)}

health_thread = threading.Thread(
    target=lambda: uvicorn.run(health_app, host="0.0.0.0", port=3314, log_level="warning"),
    daemon=True,
)
health_thread.start()

if CF_TUNNEL_TOKEN:
    subprocess.Popen(["cloudflared", "tunnel", "--no-autoupdate", "run", "--token", CF_TUNNEL_TOKEN])
    print("Cloudflare tunnel started → orchestrator.headyos.com")

print(f"""
═══════════════════════════════════════════════
  HEADY ORCHESTRATION & SWARM RUNTIME — ACTIVE
  API:    http://localhost:3304
  Health: http://localhost:3314/health
  Tunnel: orchestrator.headyos.com (if configured)
  CSL:    {len(CSL_THRESHOLDS)} threshold levels
  Swarm:  max {swarm._max_bees} bees
  Pipes:  max {conductor._max_concurrent} concurrent
  Nodes:  {topology.health()['node_count']} registered
  Models: {list(MODELS.keys())}
  Broker: {list(RUNTIME_ENDPOINTS.keys())}
═══════════════════════════════════════════════
""")

while True:
    time.sleep(fib(8))
