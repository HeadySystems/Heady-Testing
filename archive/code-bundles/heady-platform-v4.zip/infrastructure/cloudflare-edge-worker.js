/**
 * Heady™ Cloudflare Edge Worker — KV-Cached API Gateway
 * 
 * Deployed to Cloudflare Workers for sub-10ms edge reads.
 * Caches frequently accessed data in KV with φ-scaled TTLs.
 * Falls back to Cloud Run origin when cache misses.
 * 
 * NO priority/ranking. NO magic numbers. φ-scaled everything.
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;

/* φ-scaled TTLs in seconds */
const TTL = {
  HEALTH: 5,                           /* fib(5) — short-lived health status */
  FLAGS: 13,                           /* fib(7) — feature flag evaluations */
  CONFIG: 34,                          /* fib(9) — system configuration */
  SEARCH: 89,                          /* fib(11) — search results */
  STATIC: 233,                         /* fib(13) — semi-static content */
  IMMUTABLE: 610,                      /* fib(15) — content that rarely changes */
};

/* φ-scaled rate limits (requests per minute) */
const RATE_LIMITS = {
  ANONYMOUS: 34,                       /* fib(9) */
  AUTHENTICATED: 89,                   /* fib(11) */
  ENTERPRISE: 233,                     /* fib(13) */
};

/* Origin configuration */
const ORIGIN_BASE = 'https://api.headysystems.com';
const HEADY_DOMAINS = [
  'headyme.com', 'headysystems.com', 'heady-ai.com', 'headyos.com',
  'headyconnection.org', 'headyconnection.com', 'headyex.com',
  'headyfinance.com', 'admin.headysystems.com'
];

/**
 * Determine cache TTL based on request path using CSL-style pattern matching.
 * Returns TTL in seconds or 0 for no-cache.
 */
function determineTTL(pathname) {
  if (pathname === '/health' || pathname === '/ready') return TTL.HEALTH;
  if (pathname.startsWith('/flags/') && pathname.includes('/evaluate')) return TTL.FLAGS;
  if (pathname.startsWith('/config')) return TTL.CONFIG;
  if (pathname.startsWith('/search')) return TTL.SEARCH;
  if (pathname.startsWith('/api/services')) return TTL.STATIC;
  if (pathname.startsWith('/api/schemas')) return TTL.IMMUTABLE;
  if (pathname.startsWith('/api/error-codes')) return TTL.IMMUTABLE;
  /* Write operations — never cache */
  return 0;
}

/**
 * Build a deterministic cache key from request properties.
 * Includes method, path, and sorted query params for consistency.
 */
function buildCacheKey(request) {
  const url = new URL(request.url);
  const params = [...url.searchParams.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join('&');
  return `heady:${request.method}:${url.pathname}${params ? '?' + params : ''}`;
}

/**
 * Extract auth tier from request for rate limiting.
 * Checks __heady_session cookie and Authorization header.
 */
function getAuthTier(request) {
  const cookie = request.headers.get('Cookie') || '';
  const hasSession = cookie.includes('__heady_session=');
  const authHeader = request.headers.get('Authorization') || '';
  const hasApiKey = authHeader.startsWith('Bearer heady-ent-');

  if (hasApiKey) return 'ENTERPRISE';
  if (hasSession) return 'AUTHENTICATED';
  return 'ANONYMOUS';
}

/**
 * Rate limit check using Cloudflare KV as sliding window counter.
 * Window size: φ * 60 ≈ 97 seconds (smoothed minute window).
 */
async function checkRateLimit(request, env) {
  const tier = getAuthTier(request);
  const limit = RATE_LIMITS[tier];
  const ip = request.headers.get('CF-Connecting-IP') || 'unknown';
  const key = `ratelimit:${tier}:${ip}`;
  const windowMs = Math.round(PHI * 60 * 1000);

  const current = await env.HEADY_KV.get(key, { type: 'json' });
  const now = Date.now();

  if (!current) {
    await env.HEADY_KV.put(key, JSON.stringify({ count: 1, start: now }), {
      expirationTtl: Math.round(windowMs / 1000)
    });
    return { allowed: true, remaining: limit - 1, limit, tier };
  }

  if (now - current.start > windowMs) {
    await env.HEADY_KV.put(key, JSON.stringify({ count: 1, start: now }), {
      expirationTtl: Math.round(windowMs / 1000)
    });
    return { allowed: true, remaining: limit - 1, limit, tier };
  }

  if (current.count >= limit) {
    const retryAfter = Math.round((current.start + windowMs - now) / 1000);
    return { allowed: false, remaining: 0, limit, tier, retryAfter };
  }

  current.count++;
  await env.HEADY_KV.put(key, JSON.stringify(current), {
    expirationTtl: Math.round((current.start + windowMs - now) / 1000)
  });
  return { allowed: true, remaining: limit - current.count, limit, tier };
}

/**
 * Add security headers (CSP, HSTS, etc.) to response.
 */
function addSecurityHeaders(response, origin) {
  const headers = new Headers(response.headers);
  headers.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains; preload');
  headers.set('X-Content-Type-Options', 'nosniff');
  headers.set('X-Frame-Options', 'SAMEORIGIN');
  headers.set('X-XSS-Protection', '1; mode=block');
  headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  headers.set('X-Heady-Edge', 'cloudflare-worker');
  headers.set('X-Heady-Phi', PHI.toString());

  /* CORS for Heady domains */
  if (origin && HEADY_DOMAINS.some(d => origin.includes(d))) {
    headers.set('Access-Control-Allow-Origin', origin);
    headers.set('Access-Control-Allow-Credentials', 'true');
    headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Heady-Context');
    headers.set('Access-Control-Max-Age', '89'); /* fib(11) */
  }

  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers
  });
}

/**
 * Main request handler — edge-first with KV cache and origin fallback.
 */
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const startTime = Date.now();
    const origin = request.headers.get('Origin');

    /* Handle CORS preflight */
    if (request.method === 'OPTIONS') {
      return addSecurityHeaders(new Response(null, { status: 204 }), origin);
    }

    /* Rate limiting */
    const rateResult = await checkRateLimit(request, env);
    if (!rateResult.allowed) {
      return addSecurityHeaders(new Response(JSON.stringify({
        error: 'HEADY-EDGE-429',
        message: 'Rate limit exceeded',
        tier: rateResult.tier,
        retryAfter: rateResult.retryAfter,
        phi: PHI
      }), {
        status: 429,
        headers: {
          'Content-Type': 'application/json',
          'Retry-After': String(rateResult.retryAfter),
          'X-RateLimit-Limit': String(rateResult.limit),
          'X-RateLimit-Remaining': '0'
        }
      }), origin);
    }

    /* Determine if cacheable */
    const ttl = (request.method === 'GET') ? determineTTL(url.pathname) : 0;
    const cacheKey = buildCacheKey(request);

    /* Check KV cache for GET requests */
    if (ttl > 0) {
      const cached = await env.HEADY_KV.get(cacheKey, { type: 'text' });
      if (cached) {
        const edgeLatency = Date.now() - startTime;
        const resp = new Response(cached, {
          headers: {
            'Content-Type': 'application/json',
            'X-Heady-Cache': 'HIT',
            'X-Heady-Edge-Latency': `${edgeLatency}ms`,
            'Cache-Control': `public, max-age=${ttl}`,
            'X-RateLimit-Limit': String(rateResult.limit),
            'X-RateLimit-Remaining': String(rateResult.remaining)
          }
        });
        return addSecurityHeaders(resp, origin);
      }
    }

    /* Forward to origin */
    const originUrl = `${ORIGIN_BASE}${url.pathname}${url.search}`;
    const originRequest = new Request(originUrl, {
      method: request.method,
      headers: request.headers,
      body: request.method !== 'GET' ? request.body : undefined
    });

    let originResponse;
    try {
      originResponse = await fetch(originRequest, {
        cf: { cacheTtl: 0 } /* bypass Cloudflare auto-cache, we manage our own */
      });
    } catch (err) {
      /* Origin unreachable — serve stale cache if available */
      if (ttl > 0) {
        const stale = await env.HEADY_KV.get(cacheKey, { type: 'text' });
        if (stale) {
          return addSecurityHeaders(new Response(stale, {
            headers: {
              'Content-Type': 'application/json',
              'X-Heady-Cache': 'STALE',
              'X-Heady-Origin-Error': 'unreachable',
              'Cache-Control': 'public, max-age=5'
            }
          }), origin);
        }
      }
      return addSecurityHeaders(new Response(JSON.stringify({
        error: 'HEADY-EDGE-502',
        message: 'Origin unreachable',
        phi: PHI
      }), { status: 502, headers: { 'Content-Type': 'application/json' } }), origin);
    }

    /* Cache successful GET responses in KV */
    const responseBody = await originResponse.text();
    if (ttl > 0 && originResponse.ok) {
      ctx.waitUntil(env.HEADY_KV.put(cacheKey, responseBody, { expirationTtl: ttl }));
    }

    const edgeLatency = Date.now() - startTime;
    const resp = new Response(responseBody, {
      status: originResponse.status,
      headers: {
        'Content-Type': originResponse.headers.get('Content-Type') || 'application/json',
        'X-Heady-Cache': ttl > 0 ? 'MISS' : 'BYPASS',
        'X-Heady-Edge-Latency': `${edgeLatency}ms`,
        'X-RateLimit-Limit': String(rateResult.limit),
        'X-RateLimit-Remaining': String(rateResult.remaining),
        ...(ttl > 0 ? { 'Cache-Control': `public, max-age=${ttl}` } : {})
      }
    });

    return addSecurityHeaders(resp, origin);
  }
};
