/**
 * phi-math.js — Canonical Phi-Math Foundation for Heady™
 * SINGLE SOURCE OF TRUTH for every numeric constant.
 * ZERO magic numbers. Every value derives from φ.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
const PHI = (1 + Math.sqrt(5)) / 2;
const PSI = 1 / PHI;
const PHI_SQ = PHI + 1;
const PSI2 = PSI * PSI;
const PSI3 = PSI * PSI * PSI;
const PHI_CUBED = PHI * PHI * PHI;
const PHI_4 = PHI * PHI * PHI * PHI;
const PHI_5 = PHI_4 * PHI;
const PHI_6 = PHI_5 * PHI;
const PHI_7 = PHI_6 * PHI;
const PHI_8 = PHI_7 * PHI;
const GOLDEN_ANGLE_RAD = 2 * Math.PI * PSI * PSI;
const GOLDEN_ANGLE_DEG = 360 * PSI * PSI;
const FIB = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597,2584,4181,6765];
const VECTOR_DIM = 384;

const CSL_THRESHOLDS = Object.freeze({
  PSI_BASE: 0.5,
  PHI_MINOR: PSI + 0.073,
  PHI_MID: PSI + 0.191,
  PHI_MAJOR: PSI + 0.264,
  DEDUP: PSI + 0.354,
});

const CSL_GATES = Object.freeze({
  include: PSI2,
  boost: PSI,
  inject: PSI + 0.1,
});

function fib(n) { return n < FIB.length ? FIB[n] : FIB[FIB.length - 1]; }
function phiScale(base, power) { return base * Math.pow(PHI, power); }
function phiBackoff(attempt, baseMs) { return (baseMs || 1000) * Math.pow(PHI, attempt); }
function phiTimeout(level) { return Math.round(Math.pow(PHI, level) * 1000); }

window.HeadyPhi = {
  PHI, PSI, PHI_SQ, PSI2, PSI3, PHI_CUBED, PHI_4, PHI_5,
  GOLDEN_ANGLE_RAD, GOLDEN_ANGLE_DEG, FIB, VECTOR_DIM,
  CSL_THRESHOLDS, CSL_GATES,
  fib, phiScale, phiBackoff, phiTimeout,
};
