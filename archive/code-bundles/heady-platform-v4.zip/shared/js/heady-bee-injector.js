/**
 * heady-bee-injector.js — HeadyBee Content Workers (Browser Edition)
 * ALL bees are concurrent equals — fire simultaneously.
 * Injects dynamic content, stats, personalization, related content.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
(function() {
  const PHI = (1 + Math.sqrt(5)) / 2;
  const API_BASE = 'https://api.headysystems.com';

  class HeadyBeeInjector {
    constructor() {
      this.bees = [];
      this.results = new Map();
      this.init();
    }

    init() {
      this.registerDefaultBees();
      if (document.readyState === 'complete') {
        this.runAllBees();
      } else {
        window.addEventListener('load', () => this.runAllBees());
      }
    }

    registerBee(name, fn) {
      this.bees.push({ name, fn, status: 'idle' });
    }

    registerDefaultBees() {
      this.registerBee('dynamic-stats', async () => {
        return {
          patents: '51+',
          agents: '20+',
          swarms: 17,
          services: 50,
          domains: 9,
          uptime: '99.9%',
          vectorDims: 384,
          beeTypes: '30+',
        };
      });

      this.registerBee('ecosystem-links', async () => {
        return {
          sites: [
            { name: 'HeadyMe', url: 'https://headyme.com', role: 'Personal AI Cloud' },
            { name: 'HeadySystems', url: 'https://headysystems.com', role: 'Enterprise Infrastructure' },
            { name: 'HeadyAI', url: 'https://heady-ai.com', role: 'Research & Science' },
            { name: 'HeadyOS', url: 'https://headyos.com', role: 'AI Operating System' },
            { name: 'HeadyConnection', url: 'https://headyconnection.org', role: 'Non-Profit 501(c)(3)' },
            { name: 'Community', url: 'https://headyconnection.com', role: 'Community Portal' },
            { name: 'HeadyEX', url: 'https://headyex.com', role: 'Agent Marketplace' },
            { name: 'HeadyFinance', url: 'https://headyfinance.com', role: 'Investor Relations' },
            { name: 'Admin', url: 'https://admin.headysystems.com', role: 'Operations Dashboard' },
          ]
        };
      });

      this.registerBee('page-context', async () => {
        if (window.HeadyAutoContext) {
          return window.HeadyAutoContext.getContext();
        }
        return { page: { title: document.title, url: window.location.href } };
      });

      this.registerBee('personalization', async () => {
        const user = window.HeadyAuth?.getUser();
        if (!user) return null;
        return {
          uid: user.uid,
          displayName: user.displayName,
          greeting: `Welcome back, ${user.displayName?.split(' ')[0] || 'Explorer'}`,
          lastVisit: localStorage.getItem('heady_last_visit_' + window.location.hostname),
        };
      });

      this.registerBee('live-health', async () => {
        try {
          const res = await fetch(`${API_BASE}/health`, { signal: AbortSignal.timeout(4236) });
          if (res.ok) {
            const data = await res.json().catch(() => ({}));
            return { status: 'operational', ...data };
          }
          return { status: 'degraded' };
        } catch {
          return { status: 'offline' };
        }
      });

      this.registerBee('visitor-tracking', async () => {
        const host = window.location.hostname;
        const key = 'heady_visit_count_' + host;
        const count = parseInt(localStorage.getItem(key) || '0') + 1;
        localStorage.setItem(key, count.toString());
        localStorage.setItem('heady_last_visit_' + host, new Date().toISOString());
        return { visitCount: count, host };
      });
    }

    async runAllBees() {
      const startTime = performance.now();
      const promises = this.bees.map(async (bee) => {
        bee.status = 'running';
        try {
          const result = await bee.fn();
          bee.status = 'complete';
          this.results.set(bee.name, result);
          return { name: bee.name, result, error: null };
        } catch (err) {
          bee.status = 'error';
          return { name: bee.name, result: null, error: err.message };
        }
      });
      const results = await Promise.allSettled(promises);
      const elapsed = performance.now() - startTime;
      this.injectResults();
      console.log(`[HeadyBee] ${this.bees.length} bees completed in ${elapsed.toFixed(1)}ms (concurrent)`);
    }

    injectResults() {
      const stats = this.results.get('dynamic-stats');
      if (stats) {
        document.querySelectorAll('[data-heady-stat]').forEach(el => {
          const key = el.dataset.headyStat;
          if (stats[key] !== undefined) {
            this.animateCounter(el, stats[key]);
          }
        });
      }
      const personalization = this.results.get('personalization');
      if (personalization) {
        document.querySelectorAll('[data-heady-greeting]').forEach(el => {
          el.textContent = personalization.greeting;
        });
      }
      const health = this.results.get('live-health');
      if (health) {
        document.querySelectorAll('[data-heady-health]').forEach(el => {
          el.textContent = health.status;
          el.className = 'health-status health-' + health.status;
        });
      }
    }

    animateCounter(el, value) {
      if (typeof value === 'number') {
        let current = 0;
        const step = Math.ceil(value / 34);
        const interval = setInterval(() => {
          current += step;
          if (current >= value) {
            current = value;
            clearInterval(interval);
          }
          el.textContent = current.toLocaleString();
        }, 30);
      } else {
        el.textContent = value;
      }
    }

    getBeeResult(name) { return this.results.get(name); }
    getAllResults() { return Object.fromEntries(this.results); }
  }

  window.HeadyBees = new HeadyBeeInjector();
})();
