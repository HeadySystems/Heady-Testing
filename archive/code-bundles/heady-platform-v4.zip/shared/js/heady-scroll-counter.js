/**
 * heady-scroll-counter.js — Animated counters on scroll
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
(function() {
  function animateValue(el, start, end, duration) {
    const isNum = !isNaN(parseFloat(end));
    if (!isNum) { el.textContent = end; return; }
    const endVal = parseFloat(end.toString().replace(/[^0-9.]/g, ''));
    const suffix = end.toString().replace(/[0-9.]/g, '');
    let startTime = null;
    function step(timestamp) {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = Math.floor(start + (endVal - start) * eased);
      el.textContent = current.toLocaleString() + suffix;
      if (progress < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  document.addEventListener('DOMContentLoaded', () => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const val = el.dataset.count || el.textContent;
          animateValue(el, 0, val, 1618);
          observer.unobserve(el);
        }
      });
    }, { threshold: 0.3 });
    document.querySelectorAll('[data-count]').forEach(el => observer.observe(el));
  });
})();
