/**
 * sacred-geometry-canvas.js — Sacred Geometry Animations for Heady™
 * 9 unique patterns, one per site. φ-scaled everything.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
(function() {
  const PHI = (1 + Math.sqrt(5)) / 2;
  const PSI = 1 / PHI;
  const GA = 2 * Math.PI * PSI * PSI;

  class SacredGeometryCanvas {
    constructor(canvasId, pattern, accentColor) {
      this.canvas = document.getElementById(canvasId);
      if (!this.canvas) return;
      this.ctx = this.canvas.getContext('2d');
      this.pattern = pattern;
      this.accent = accentColor || '#00d4aa';
      this.t = 0;
      this.particles = [];
      this.resize();
      window.addEventListener('resize', () => this.resize());
      this.initParticles();
      this.animate();
    }
    resize() {
      const r = window.devicePixelRatio || 1;
      this.canvas.width = this.canvas.offsetWidth * r;
      this.canvas.height = this.canvas.offsetHeight * r;
      this.ctx.scale(r, r);
      this.w = this.canvas.offsetWidth;
      this.h = this.canvas.offsetHeight;
      this.cx = this.w / 2;
      this.cy = this.h / 2;
    }
    initParticles() {
      const count = 89;
      for (let i = 0; i < count; i++) {
        const angle = i * GA;
        const radius = Math.sqrt(i) * 13;
        this.particles.push({
          x: this.cx + Math.cos(angle) * radius,
          y: this.cy + Math.sin(angle) * radius,
          baseAngle: angle, baseRadius: radius,
          size: 1 + (i % 5) * PSI, opacity: 0.3 + Math.random() * 0.4,
        });
      }
    }
    animate() {
      this.t += 0.003;
      this.ctx.clearRect(0, 0, this.w, this.h);
      const patterns = {
        'flower-of-life': () => this.drawFlowerOfLife(),
        'metatrons-cube': () => this.drawMetatronsCube(),
        'sri-yantra': () => this.drawSriYantra(),
        'torus': () => this.drawTorus(),
        'seed-of-life': () => this.drawSeedOfLife(),
        'fibonacci-spiral': () => this.drawFibonacciSpiral(),
        'vesica-piscis': () => this.drawVesicaPiscis(),
      };
      (patterns[this.pattern] || patterns['flower-of-life'])();
      this.drawParticles();
      this.drawConnections();
      requestAnimationFrame(() => this.animate());
    }
    hexColor(opacity) {
      return this.accent + Math.round(opacity * 255).toString(16).padStart(2, '0');
    }
    drawCircle(x, y, r, opacity) {
      this.ctx.beginPath();
      this.ctx.arc(x, y, r, 0, Math.PI * 2);
      this.ctx.strokeStyle = this.hexColor(opacity || 0.15);
      this.ctx.lineWidth = 0.8;
      this.ctx.stroke();
    }
    drawLine(x1, y1, x2, y2, opacity) {
      this.ctx.beginPath();
      this.ctx.moveTo(x1, y1); this.ctx.lineTo(x2, y2);
      this.ctx.strokeStyle = this.hexColor(opacity || 0.08);
      this.ctx.lineWidth = 0.5;
      this.ctx.stroke();
    }
    drawFlowerOfLife() {
      const r = Math.min(this.w, this.h) * 0.12;
      const pulse = 1 + Math.sin(this.t * PHI) * 0.03;
      this.drawCircle(this.cx, this.cy, r * pulse, 0.2);
      for (let i = 0; i < 6; i++) {
        const a = (Math.PI / 3) * i + this.t * 0.1;
        const x = this.cx + Math.cos(a) * r * pulse;
        const y = this.cy + Math.sin(a) * r * pulse;
        this.drawCircle(x, y, r * pulse, 0.12);
      }
      for (let ring = 2; ring <= 3; ring++) {
        for (let i = 0; i < 6 * ring; i++) {
          const a = (Math.PI / (3 * ring)) * i + this.t * 0.05 * ring;
          const x = this.cx + Math.cos(a) * r * ring * PSI * pulse;
          const y = this.cy + Math.sin(a) * r * ring * PSI * pulse;
          this.drawCircle(x, y, r * PSI * pulse, 0.06 / ring);
        }
      }
    }
    drawMetatronsCube() {
      const r = Math.min(this.w, this.h) * 0.18;
      const pulse = 1 + Math.sin(this.t * PHI) * 0.02;
      const pts = [];
      pts.push([this.cx, this.cy]);
      for (let i = 0; i < 6; i++) {
        const a = (Math.PI / 3) * i + this.t * 0.08;
        pts.push([this.cx + Math.cos(a) * r * pulse, this.cy + Math.sin(a) * r * pulse]);
      }
      for (let i = 0; i < 6; i++) {
        const a = (Math.PI / 3) * i + Math.PI / 6 + this.t * 0.08;
        pts.push([this.cx + Math.cos(a) * r * PHI * PSI * pulse, this.cy + Math.sin(a) * r * PHI * PSI * pulse]);
      }
      for (let i = 0; i < pts.length; i++) {
        for (let j = i + 1; j < pts.length; j++) {
          this.drawLine(pts[i][0], pts[i][1], pts[j][0], pts[j][1], 0.06);
        }
      }
      pts.forEach(p => this.drawCircle(p[0], p[1], 3, 0.4));
    }
    drawSriYantra() {
      const size = Math.min(this.w, this.h) * 0.2;
      const pulse = 1 + Math.sin(this.t * PHI) * 0.02;
      for (let tri = 0; tri < 9; tri++) {
        const up = tri % 2 === 0;
        const s = size * (1 - tri * 0.08) * pulse;
        const yOff = (up ? -1 : 1) * tri * 3;
        this.ctx.beginPath();
        if (up) {
          this.ctx.moveTo(this.cx, this.cy - s * 0.7 + yOff);
          this.ctx.lineTo(this.cx - s * 0.6, this.cy + s * 0.4 + yOff);
          this.ctx.lineTo(this.cx + s * 0.6, this.cy + s * 0.4 + yOff);
        } else {
          this.ctx.moveTo(this.cx, this.cy + s * 0.7 + yOff);
          this.ctx.lineTo(this.cx - s * 0.6, this.cy - s * 0.4 + yOff);
          this.ctx.lineTo(this.cx + s * 0.6, this.cy - s * 0.4 + yOff);
        }
        this.ctx.closePath();
        this.ctx.strokeStyle = this.hexColor(0.15 - tri * 0.01);
        this.ctx.lineWidth = 0.8;
        this.ctx.stroke();
      }
      this.drawCircle(this.cx, this.cy, size * 0.85 * pulse, 0.1);
      this.drawCircle(this.cx, this.cy, size * pulse, 0.08);
    }
    drawTorus() {
      const R = Math.min(this.w, this.h) * 0.15;
      const rr = R * PSI;
      for (let i = 0; i < 55; i++) {
        const theta = (i / 55) * Math.PI * 2;
        const phi2 = this.t * 0.5 + (i / 55) * Math.PI * 8;
        const x = this.cx + (R + rr * Math.cos(phi2)) * Math.cos(theta);
        const y = this.cy + (R + rr * Math.cos(phi2)) * Math.sin(theta) * 0.4;
        const depth = (Math.cos(phi2) + 1) / 2;
        this.drawCircle(x, y, 1.5 + depth * 2, 0.1 + depth * 0.2);
      }
      for (let j = 0; j < 21; j++) {
        const phi2 = (j / 21) * Math.PI * 2;
        for (let i = 0; i < 34; i++) {
          const theta = (i / 34) * Math.PI * 2;
          const x = this.cx + (R + rr * Math.cos(phi2 + this.t)) * Math.cos(theta);
          const y = this.cy + (R + rr * Math.cos(phi2 + this.t)) * Math.sin(theta) * 0.4;
          const s = 0.5 + (Math.cos(phi2 + this.t) + 1) * 0.5;
          this.ctx.fillStyle = this.hexColor(0.03 + s * 0.05);
          this.ctx.fillRect(x, y, 1, 1);
        }
      }
    }
    drawSeedOfLife() {
      const r = Math.min(this.w, this.h) * 0.1;
      const pulse = 1 + Math.sin(this.t * PHI) * 0.03;
      this.drawCircle(this.cx, this.cy, r * pulse, 0.2);
      for (let i = 0; i < 6; i++) {
        const a = (Math.PI / 3) * i + this.t * 0.12;
        const x = this.cx + Math.cos(a) * r * pulse;
        const y = this.cy + Math.sin(a) * r * pulse;
        this.drawCircle(x, y, r * pulse, 0.15);
      }
      this.drawCircle(this.cx, this.cy, r * 2.2 * pulse, 0.06);
    }
    drawFibonacciSpiral() {
      const scale = Math.min(this.w, this.h) * 0.002;
      this.ctx.beginPath();
      for (let i = 0; i < 610; i++) {
        const angle = i * GA + this.t * 0.3;
        const radius = Math.sqrt(i) * scale * 8;
        const x = this.cx + Math.cos(angle) * radius;
        const y = this.cy + Math.sin(angle) * radius;
        if (i === 0) this.ctx.moveTo(x, y); else this.ctx.lineTo(x, y);
      }
      this.ctx.strokeStyle = this.hexColor(0.1);
      this.ctx.lineWidth = 0.6;
      this.ctx.stroke();
      for (let i = 0; i < 144; i++) {
        const angle = i * GA + this.t * 0.3;
        const radius = Math.sqrt(i) * scale * 8;
        const x = this.cx + Math.cos(angle) * radius;
        const y = this.cy + Math.sin(angle) * radius;
        const s = 1 + (i % 8) * 0.3;
        this.drawCircle(x, y, s, 0.1 + (i % 5) * 0.04);
      }
    }
    drawVesicaPiscis() {
      const r = Math.min(this.w, this.h) * 0.15;
      const d = r * PSI;
      const pulse = 1 + Math.sin(this.t * PHI) * 0.02;
      this.drawCircle(this.cx - d * pulse, this.cy, r * pulse, 0.18);
      this.drawCircle(this.cx + d * pulse, this.cy, r * pulse, 0.18);
      const intersection = Math.sqrt(r * r - d * d) * pulse;
      this.ctx.beginPath();
      this.ctx.ellipse(this.cx, this.cy, d * 0.6 * pulse, intersection, 0, 0, Math.PI * 2);
      this.ctx.strokeStyle = this.hexColor(0.25);
      this.ctx.lineWidth = 1;
      this.ctx.stroke();
      for (let ring = 1; ring <= 3; ring++) {
        this.drawCircle(this.cx, this.cy, r * ring * PSI * 0.5 * pulse, 0.06);
      }
    }
    drawParticles() {
      this.particles.forEach((p, i) => {
        const angle = p.baseAngle + this.t * (0.1 + (i % 5) * 0.02);
        const breathe = 1 + Math.sin(this.t * PHI + i * PSI) * 0.05;
        p.x = this.cx + Math.cos(angle) * p.baseRadius * breathe;
        p.y = this.cy + Math.sin(angle) * p.baseRadius * breathe;
        this.ctx.beginPath();
        this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        this.ctx.fillStyle = this.hexColor(p.opacity * 0.5);
        this.ctx.fill();
      });
    }
    drawConnections() {
      const threshold = 55;
      for (let i = 0; i < this.particles.length; i++) {
        for (let j = i + 1; j < this.particles.length; j++) {
          const dx = this.particles[i].x - this.particles[j].x;
          const dy = this.particles[i].y - this.particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < threshold) {
            const opacity = (1 - dist / threshold) * 0.15;
            this.drawLine(
              this.particles[i].x, this.particles[i].y,
              this.particles[j].x, this.particles[j].y, opacity
            );
          }
        }
      }
    }
  }

  window.SacredGeometryCanvas = SacredGeometryCanvas;
})();
