/**
 * Heady i18n Module
 * Lightweight internationalization with φ-scaled constants.
 * Loads locale from navigator.language or ?lang= query param.
 * Falls back to 'en' when a locale is unavailable.
 */

const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI2,
  boost: PSI,
  inject: PSI + 0.1,
});

const CACHE_TTL_MS = FIB[10] * 1000;
const MAX_INTERPOLATION_DEPTH = FIB[4];
const FALLBACK_LOCALE = 'en';
const LOCALE_PATH_PREFIX = '../shared/locales/';

const localeCache = new Map();
let currentLocale = FALLBACK_LOCALE;
let currentStrings = null;
let cacheTimestamp = 0;

function detectLocale() {
  const params = new URLSearchParams(window.location.search);
  const queryLang = params.get('lang');
  if (queryLang && /^[a-z]{2}(-[A-Z]{2})?$/.test(queryLang)) {
    return queryLang;
  }
  const navLang = navigator.language || navigator.userLanguage || FALLBACK_LOCALE;
  return navLang;
}

function normalizeLocale(locale) {
  if (!locale || typeof locale !== 'string') return FALLBACK_LOCALE;
  const cleaned = locale.trim().toLowerCase().replace('_', '-');
  if (cleaned.length === FIB[4]) return cleaned.slice(0, FIB[1] + FIB[1]);
  if (cleaned.length >= FIB[1] + FIB[1]) return cleaned.slice(0, FIB[1] + FIB[1]);
  return FALLBACK_LOCALE;
}

function resolveLocaleChain(locale) {
  const normalized = normalizeLocale(locale);
  const chain = [normalized];
  if (normalized.includes('-')) {
    chain.push(normalized.split('-')[0]);
  }
  if (!chain.includes(FALLBACK_LOCALE)) {
    chain.push(FALLBACK_LOCALE);
  }
  return chain;
}

async function fetchLocaleData(locale) {
  const now = Date.now();
  const cached = localeCache.get(locale);
  if (cached && (now - cached.timestamp) < CACHE_TTL_MS) {
    return cached.data;
  }

  const url = `${LOCALE_PATH_PREFIX}${locale}.json`;
  try {
    const response = await fetch(url);
    if (!response.ok) return null;
    const data = await response.json();
    localeCache.set(locale, { data, timestamp: now });
    return data;
  } catch (_) {
    return null;
  }
}

async function loadLocale(locale) {
  const chain = resolveLocaleChain(locale);
  for (let i = 0; i < chain.length; i++) {
    const data = await fetchLocaleData(chain[i]);
    if (data) {
      currentLocale = chain[i];
      currentStrings = data;
      cacheTimestamp = Date.now();
      document.documentElement.setAttribute('lang', currentLocale);
      return true;
    }
  }
  return false;
}

function interpolate(template, params) {
  if (!params || typeof template !== 'string') return template;
  let result = template;
  let depth = 0;
  let previous = '';
  while (result !== previous && depth < MAX_INTERPOLATION_DEPTH) {
    previous = result;
    result = result.replace(/\{\{(\w+)\}\}/g, (match, key) => {
      return Object.prototype.hasOwnProperty.call(params, key) ? String(params[key]) : match;
    });
    depth++;
  }
  return result;
}

function getNestedValue(obj, keyPath) {
  const segments = keyPath.split('.');
  let current = obj;
  for (let i = 0; i < segments.length; i++) {
    if (current == null || typeof current !== 'object') return undefined;
    current = current[segments[i]];
  }
  return current;
}

function t(key, params) {
  if (!currentStrings) return key;
  const value = getNestedValue(currentStrings, key);
  if (value === undefined) return key;
  if (typeof value !== 'string') return String(value);
  return interpolate(value, params);
}

function getLocale() {
  return currentLocale;
}

function getAvailableKeys() {
  if (!currentStrings) return [];
  const keys = [];
  function walk(obj, prefix) {
    for (const k of Object.keys(obj)) {
      const fullKey = prefix ? `${prefix}.${k}` : k;
      if (typeof obj[k] === 'object' && obj[k] !== null) {
        walk(obj[k], fullKey);
      } else {
        keys.push(fullKey);
      }
    }
  }
  walk(currentStrings, '');
  return keys;
}

async function changeLocale(newLocale) {
  const success = await loadLocale(newLocale);
  if (success) {
    const url = new URL(window.location);
    url.searchParams.set('lang', currentLocale);
    window.history.replaceState({}, '', url);
  }
  return success;
}

async function init() {
  const detected = detectLocale();
  await loadLocale(detected);
}

if (typeof window !== 'undefined') {
  window.HeadyI18n = Object.freeze({
    t,
    init,
    getLocale,
    changeLocale,
    getAvailableKeys,
    PHI,
    PSI,
    PSI2,
    FIB,
    VECTOR_DIM,
    CSL_GATES,
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
}

export { t, init, getLocale, changeLocale, getAvailableKeys };
