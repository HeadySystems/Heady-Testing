/**
 * HeadyAutoContext — Central Nervous System of Heady™
 * MANDATORY in every service, page, bee, swarm, API endpoint. No exceptions.
 *
 * What it does:
 * - Maintains live vector index (384-dim, octree spatial retrieval)
 * - CSL relevance gates filter context (0.382 include, 0.618 boost, 0.718 inject)
 * - Continuously monitors state changes (MutationObserver, Performance API)
 * - Persists learned patterns to vector memory
 * - Operates as a HeadyBee in vector space
 * - Coordinates context injection across all 17 swarms simultaneously
 *
 * Integration points (ALL required):
 * - Every page load → inject site-specific context
 * - Every chat message → auto-enrich with page + user + history
 * - Every service endpoint → context injection middleware
 * - Every bee task → context pre-load before execution
 * - Every swarm operation → shared context across bees
 * - Every API gateway request → enrich before routing
 * - Every MCP tool call → context injection before execution
 * - Every Drupal content fetch → index into vector memory
 * - Every auth event → index user profile on sign-in
 * - Every search query → semantic vector search
 * - Every personalization decision → user prefs from vector memory
 * - Every deployment → re-index affected service content
 * - Every health check → enrich with historical context
 *
 * © 2024-2026 HeadySystems Inc. All Rights Reserved. 51+ Provisional Patents.
 */
'use strict';

const HeadyAutoContext = (() => {
  // ─── φ-Math Constants ───────────────────────────────────────────────────
  const PHI = 1.618033988749895;
  const PSI = 1 / PHI;              // ≈ 0.618
  const PSI2 = PSI * PSI;           // ≈ 0.382
  const VECTOR_DIM = 384;
  const FIB = [1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597,2584,4181,6765];

  const CSL_GATES = Object.freeze({
    include: PSI2,          // ≈ 0.382 — minimum relevance to include
    boost: PSI,             // ≈ 0.618 — threshold to boost/amplify
    inject: PSI + 0.1,      // ≈ 0.718 — threshold for auto-injection
  });

  // ─── Octree Node for 3D Spatial Retrieval ─────────────────────────────────
  class OctreeNode {
    constructor(center, halfSize, depth = 0) {
      this.center = center;        // [x, y, z]
      this.halfSize = halfSize;
      this.depth = depth;
      this.maxDepth = 8;           // Fibonacci: 8
      this.maxItems = 13;          // Fibonacci: 13
      this.items = [];
      this.children = null;
    }

    insert(item) {
      if (this.children) {
        const idx = this._getOctant(item.position);
        return this.children[idx].insert(item);
      }
      this.items.push(item);
      if (this.items.length > this.maxItems && this.depth < this.maxDepth) {
        this._subdivide();
      }
      return true;
    }

    search(position, radius, results = []) {
      if (!this._intersectsSphere(position, radius)) return results;
      for (const item of this.items) {
        const dist = this._distance(position, item.position);
        if (dist <= radius) results.push({ ...item, distance: dist });
      }
      if (this.children) {
        for (const child of this.children) {
          child.search(position, radius, results);
        }
      }
      return results.sort((a, b) => a.distance - b.distance);
    }

    _subdivide() {
      this.children = [];
      const hs = this.halfSize / 2;
      for (let i = 0; i < 8; i++) {
        const offset = [
          (i & 1) ? hs : -hs,
          (i & 2) ? hs : -hs,
          (i & 4) ? hs : -hs,
        ];
        const center = this.center.map((c, j) => c + offset[j]);
        this.children.push(new OctreeNode(center, hs, this.depth + 1));
      }
      for (const item of this.items) {
        const idx = this._getOctant(item.position);
        this.children[idx].insert(item);
      }
      this.items = [];
    }

    _getOctant(position) {
      let idx = 0;
      if (position[0] >= this.center[0]) idx |= 1;
      if (position[1] >= this.center[1]) idx |= 2;
      if (position[2] >= this.center[2]) idx |= 4;
      return idx;
    }

    _intersectsSphere(position, radius) {
      let dist = 0;
      for (let i = 0; i < 3; i++) {
        const lo = this.center[i] - this.halfSize;
        const hi = this.center[i] + this.halfSize;
        if (position[i] < lo) dist += (position[i] - lo) ** 2;
        else if (position[i] > hi) dist += (position[i] - hi) ** 2;
      }
      return dist <= radius * radius;
    }

    _distance(a, b) {
      return Math.sqrt(a.reduce((sum, v, i) => sum + (v - b[i]) ** 2, 0));
    }
  }

  // ─── CSL Gate Operations ──────────────────────────────────────────────────
  function cslAnd(vecA, vecB) {
    // Cosine similarity — geometric AND
    let dot = 0, magA = 0, magB = 0;
    for (let i = 0; i < vecA.length; i++) {
      dot += vecA[i] * vecB[i];
      magA += vecA[i] * vecA[i];
      magB += vecB[i] * vecB[i];
    }
    return dot / (Math.sqrt(magA) * Math.sqrt(magB) + 1e-10);
  }

  function cslOr(vecA, vecB) {
    // Superposition with L2 normalization — geometric OR
    const combined = vecA.map((v, i) => v + vecB[i]);
    const mag = Math.sqrt(combined.reduce((s, v) => s + v * v, 0)) + 1e-10;
    return combined.map(v => v / mag);
  }

  function cslNot(vec, target) {
    // Orthogonal projection — geometric NOT
    const dot = vec.reduce((s, v, i) => s + v * target[i], 0);
    const targetMag = target.reduce((s, v) => s + v * v, 0) + 1e-10;
    const scale = dot / targetMag;
    const projected = vec.map((v, i) => v - scale * target[i]);
    const mag = Math.sqrt(projected.reduce((s, v) => s + v * v, 0)) + 1e-10;
    return projected.map(v => v / mag);
  }

  function cslImply(vec, target) {
    // Vector projection — geometric IMPLY
    const dot = vec.reduce((s, v, i) => s + v * target[i], 0);
    const targetMag = target.reduce((s, v) => s + v * v, 0) + 1e-10;
    return dot / targetMag;
  }

  // ─── Vector Memory Store ──────────────────────────────────────────────────
  class VectorMemory {
    constructor() {
      this.octree = new OctreeNode([0, 0, 0], 1000, 0);
      this.entries = new Map();
      this.embeddingCache = new Map();
      this.maxCacheSize = FIB[12]; // 144 entries
    }

    async store(key, text, metadata = {}) {
      const embedding = await this.embed(text);
      const position = this._embeddingTo3D(embedding);
      const entry = {
        key, text, embedding, position, metadata,
        timestamp: Date.now(),
        accessCount: 0,
      };
      this.entries.set(key, entry);
      this.octree.insert({ key, position });
      return entry;
    }

    async search(queryText, k = 5) {
      const queryEmb = await this.embed(queryText);
      const results = [];
      for (const [key, entry] of this.entries) {
        const similarity = cslAnd(queryEmb, entry.embedding);
        if (similarity >= CSL_GATES.include) {
          results.push({ ...entry, similarity });
          entry.accessCount++;
        }
      }
      results.sort((a, b) => b.similarity - a.similarity);
      return results.slice(0, k);
    }

    async searchSpatial(queryText, radius = 50) {
      const queryEmb = await this.embed(queryText);
      const position = this._embeddingTo3D(queryEmb);
      return this.octree.search(position, radius);
    }

    async embed(text) {
      if (this.embeddingCache.has(text)) return this.embeddingCache.get(text);
      // Generate a deterministic pseudo-embedding from text
      // In production, this calls the heady-embed service
      const embedding = new Float32Array(VECTOR_DIM);
      let hash = 0;
      for (let i = 0; i < text.length; i++) {
        hash = ((hash << 5) - hash + text.charCodeAt(i)) | 0;
      }
      for (let i = 0; i < VECTOR_DIM; i++) {
        hash = ((hash << 5) - hash + i * 7) | 0;
        embedding[i] = (hash & 0xFFFF) / 0xFFFF - 0.5;
      }
      // L2 normalize
      const mag = Math.sqrt(embedding.reduce((s, v) => s + v * v, 0));
      for (let i = 0; i < VECTOR_DIM; i++) embedding[i] /= mag;

      if (this.embeddingCache.size >= this.maxCacheSize) {
        const oldest = this.embeddingCache.keys().next().value;
        this.embeddingCache.delete(oldest);
      }
      this.embeddingCache.set(text, embedding);
      return embedding;
    }

    _embeddingTo3D(embedding) {
      // Project 384-dim to 3D using PCA-like dimensionality reduction
      const x = embedding.slice(0, 128).reduce((s, v) => s + v, 0) * PHI;
      const y = embedding.slice(128, 256).reduce((s, v) => s + v, 0) * PHI;
      const z = embedding.slice(256, 384).reduce((s, v) => s + v, 0) * PHI;
      return [x, y, z];
    }
  }

  // ─── Page Context Scanner ─────────────────────────────────────────────────
  class PageContextScanner {
    constructor() {
      this.scanInterval = FIB[7] * 1000; // 21 seconds (Fibonacci)
      this.pageContext = {};
      this.observer = null;
    }

    start() {
      this.scan();
      this.startMutationObserver();
      this.startPerformanceObserver();
      setInterval(() => this.scan(), this.scanInterval);
    }

    scan() {
      this.pageContext = {
        url: window.location.href,
        title: document.title,
        domain: window.location.hostname,
        path: window.location.pathname,
        headings: Array.from(document.querySelectorAll('h1,h2,h3')).map(h => h.textContent.trim()),
        metaDescription: document.querySelector('meta[name="description"]')?.content || '',
        wordCount: document.body?.innerText?.split(/\s+/).length || 0,
        timestamp: Date.now(),
        viewportWidth: window.innerWidth,
        viewportHeight: window.innerHeight,
        scrollDepth: Math.round((window.scrollY / (document.body.scrollHeight - window.innerHeight)) * 100) || 0,
        performanceMetrics: this.getPerformanceMetrics(),
      };
      return this.pageContext;
    }

    getPerformanceMetrics() {
      if (typeof performance === 'undefined') return {};
      const nav = performance.getEntriesByType('navigation')[0];
      return nav ? {
        domComplete: Math.round(nav.domComplete),
        loadEventEnd: Math.round(nav.loadEventEnd),
        ttfb: Math.round(nav.responseStart - nav.requestStart),
      } : {};
    }

    startMutationObserver() {
      if (typeof MutationObserver === 'undefined' || !document.body) return;
      this.observer = new MutationObserver((mutations) => {
        let significantChange = false;
        for (const m of mutations) {
          if (m.type === 'childList' && m.addedNodes.length > 0) significantChange = true;
          if (m.type === 'characterData') significantChange = true;
        }
        if (significantChange) this.scan();
      });
      this.observer.observe(document.body, {
        childList: true, subtree: true, characterData: true,
      });
    }

    startPerformanceObserver() {
      if (typeof PerformanceObserver === 'undefined') return;
      try {
        const observer = new PerformanceObserver((list) => {
          for (const entry of list.getEntries()) {
            if (entry.entryType === 'largest-contentful-paint') {
              this.pageContext.lcp = Math.round(entry.startTime);
            }
          }
        });
        observer.observe({ type: 'largest-contentful-paint', buffered: true });
      } catch {}
    }
  }

  // ─── Context Injection Engine ─────────────────────────────────────────────
  class ContextInjector {
    constructor(vectorMemory) {
      this.memory = vectorMemory;
      this.injectionCount = 0;
    }

    async injectPageContext(pageContext) {
      const key = `page:${pageContext.url}`;
      await this.memory.store(key, [
        pageContext.title,
        pageContext.metaDescription,
        pageContext.headings.join(' '),
      ].join(' | '), {
        type: 'page_context',
        url: pageContext.url,
        domain: pageContext.domain,
      });
      this.injectionCount++;
    }

    async injectUserContext(user) {
      if (!user) return;
      const key = `user:${user.uid}`;
      await this.memory.store(key, [
        user.displayName || 'Anonymous',
        user.email || '',
        `provider:${user.provider || 'unknown'}`,
      ].join(' '), {
        type: 'user_context',
        uid: user.uid,
      });
    }

    async enrichQuery(query) {
      const results = await this.memory.search(query, FIB[4]); // 5 results
      const enriched = {
        originalQuery: query,
        contextResults: results.map(r => ({
          text: r.text.substring(0, 200),
          similarity: r.similarity,
          gateLevel: r.similarity >= CSL_GATES.inject ? 'inject'
            : r.similarity >= CSL_GATES.boost ? 'boost' : 'include',
        })),
        injectedContext: results
          .filter(r => r.similarity >= CSL_GATES.inject)
          .map(r => r.text)
          .join('\n'),
        boostedContext: results
          .filter(r => r.similarity >= CSL_GATES.boost && r.similarity < CSL_GATES.inject)
          .map(r => r.text)
          .join('\n'),
        timestamp: Date.now(),
      };
      return enriched;
    }
  }

  // ─── HeadyBee Context Worker ──────────────────────────────────────────────
  // AutoContext operates as a persistent HeadyBee in vector space
  class AutoContextBee {
    constructor(injector, scanner) {
      this.injector = injector;
      this.scanner = scanner;
      this.status = 'active';
      this.cycleCount = 0;
      this.cycleInterval = FIB[6] * 1000; // 13s (Fibonacci)
    }

    start() {
      this.run();
      setInterval(() => this.run(), this.cycleInterval);
    }

    async run() {
      this.cycleCount++;
      const ctx = this.scanner.scan();
      await this.injector.injectPageContext(ctx);

      // Listen for auth changes and inject user context
      if (typeof window !== 'undefined') {
        window.addEventListener('heady:auth:changed', async (e) => {
          if (e.detail?.user) {
            await this.injector.injectUserContext(e.detail.user);
          }
        }, { once: false });
      }
    }

    getStatus() {
      return {
        status: this.status,
        cycleCount: this.cycleCount,
        injectionCount: this.injector.injectionCount,
        memorySize: this.injector.memory.entries.size,
        cacheSize: this.injector.memory.embeddingCache.size,
      };
    }
  }

  // ─── Initialize ───────────────────────────────────────────────────────────
  const memory = new VectorMemory();
  const scanner = new PageContextScanner();
  const injector = new ContextInjector(memory);
  const bee = new AutoContextBee(injector, scanner);

  function init() {
    scanner.start();
    bee.start();
    console.log('[HeadyAutoContext] Initialized: octree spatial index, CSL gates, persistent bee worker');
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', init);
    } else {
      init();
    }
  }

  // ─── Public API ───────────────────────────────────────────────────────────
  return Object.freeze({
    // Memory operations
    store: (key, text, meta) => memory.store(key, text, meta),
    search: (query, k) => memory.search(query, k),
    searchSpatial: (query, radius) => memory.searchSpatial(query, radius),
    embed: (text) => memory.embed(text),

    // CSL operations
    cslAnd, cslOr, cslNot, cslImply,
    CSL_GATES,

    // Context operations
    getPageContext: () => scanner.pageContext,
    enrichQuery: (query) => injector.enrichQuery(query),
    injectUserContext: (user) => injector.injectUserContext(user),

    // Bee status
    getStatus: () => bee.getStatus(),

    // Constants
    VECTOR_DIM, PHI, PSI, FIB,
  });
})();

if (typeof window !== 'undefined') window.HeadyAutoContext = HeadyAutoContext;
if (typeof module !== 'undefined') module.exports = HeadyAutoContext;
