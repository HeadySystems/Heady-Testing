/**
 * Heady™ Security Middleware — OWASP Top 10 Protection Suite
 * Applied to every service via HeadyAutoContext
 * NO magic numbers — all values φ-derived
 * © 2026 HeadySystems Inc. All Rights Reserved.
 */

const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];

// ─── Rate Limiter (φ-scaled sliding window) ─────────────────────────────────
const rateLimitStore = new Map();
const RATE_LIMITS = Object.freeze({
  anonymous: FIB[9],     // 34 requests/min
  authenticated: FIB[11], // 89 requests/min
  enterprise: FIB[12],    // 144 requests/min
  windowMs: FIB[8] * 1000 * 3, // 63s ≈ 1 minute (21 × 3)
});

export function rateLimiter(tier = 'anonymous') {
  const limit = RATE_LIMITS[tier] || RATE_LIMITS.anonymous;
  return (req, res, next) => {
    const key = req.ip + ':' + (req.headers['x-api-key'] || 'anon');
    const now = Date.now();
    const window = RATE_LIMITS.windowMs;
    
    if (!rateLimitStore.has(key)) {
      rateLimitStore.set(key, []);
    }
    const timestamps = rateLimitStore.get(key).filter(t => now - t < window);
    
    if (timestamps.length >= limit) {
      res.setHeader('Retry-After', Math.ceil(window / 1000));
      res.setHeader('X-RateLimit-Limit', limit);
      res.setHeader('X-RateLimit-Remaining', 0);
      return res.status(429).json({
        error: 'HEADY-RATE-001',
        message: 'Rate limit exceeded — concurrent-equals throttling active',
        retryAfterMs: window,
      });
    }
    
    timestamps.push(now);
    rateLimitStore.set(key, timestamps);
    res.setHeader('X-RateLimit-Limit', limit);
    res.setHeader('X-RateLimit-Remaining', limit - timestamps.length);
    next();
  };
}

// ─── Security Headers (CSP, HSTS, etc.) ─────────────────────────────────────
export function securityHeaders(options = {}) {
  const cspDirectives = [
    "default-src 'self'",
    "script-src 'self' https://apis.google.com https://www.gstatic.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data: https: blob:",
    "connect-src 'self' https://*.headysystems.com https://*.headyme.com https://*.heady-ai.com https://*.headyos.com https://*.headyconnection.org https://*.headyconnection.com https://*.headyex.com https://*.headyfinance.com https://firestore.googleapis.com https://identitytoolkit.googleapis.com",
    "frame-ancestors 'self' https://*.headysystems.com",
    "base-uri 'self'",
    "form-action 'self'",
    "upgrade-insecure-requests",
  ].join('; ');

  return (req, res, next) => {
    // Content Security Policy
    res.setHeader('Content-Security-Policy', options.csp || cspDirectives);
    // Strict Transport Security (1 year = 31536000s, closest Fibonacci approx: 34 × 10^6 ≈ 393 days)
    res.setHeader('Strict-Transport-Security', 'max-age=34000000; includeSubDomains; preload');
    // Prevent MIME sniffing
    res.setHeader('X-Content-Type-Options', 'nosniff');
    // Prevent clickjacking
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    // XSS filter (legacy browsers)
    res.setHeader('X-XSS-Protection', '1; mode=block');
    // Referrer Policy
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    // Permissions Policy
    res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
    // Remove fingerprinting headers
    res.removeHeader('X-Powered-By');
    next();
  };
}

// ─── Input Sanitizer (XSS/Injection prevention) ─────────────────────────────
export function sanitizeInput(req, res, next) {
  const sanitize = (obj) => {
    if (typeof obj === 'string') {
      return obj
        .replace(/[<>]/g, '') // Strip HTML angle brackets
        .replace(/javascript:/gi, '') // Strip JS protocol
        .replace(/on\w+\s*=/gi, '') // Strip event handlers
        .trim()
        .slice(0, FIB[16]); // Max string length: 987 chars
    }
    if (Array.isArray(obj)) return obj.map(sanitize);
    if (obj && typeof obj === 'object') {
      const clean = {};
      for (const [k, v] of Object.entries(obj)) {
        clean[sanitize(k)] = sanitize(v);
      }
      return clean;
    }
    return obj;
  };
  
  if (req.body && typeof req.body === 'object') {
    req.body = sanitize(req.body);
  }
  if (req.query && typeof req.query === 'object') {
    req.query = sanitize(req.query);
  }
  next();
}

// ─── CORS Configuration (strict, not wildcard) ──────────────────────────────
const ALLOWED_ORIGINS = new Set([
  'https://headyme.com', 'https://www.headyme.com',
  'https://headysystems.com', 'https://www.headysystems.com',
  'https://heady-ai.com', 'https://www.heady-ai.com',
  'https://headyos.com', 'https://www.headyos.com',
  'https://headyconnection.org', 'https://www.headyconnection.org',
  'https://headyconnection.com', 'https://www.headyconnection.com',
  'https://headyex.com', 'https://www.headyex.com',
  'https://headyfinance.com', 'https://www.headyfinance.com',
  'https://admin.headysystems.com',
  'https://auth.headysystems.com',
  'https://api.headysystems.com',
]);

export function strictCors(req, res, next) {
  const origin = req.headers.origin;
  if (origin && ALLOWED_ORIGINS.has(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Request-ID, X-Heady-Domain, X-Trace-ID');
    res.setHeader('Access-Control-Max-Age', String(FIB[10])); // 55 seconds
    res.setHeader('Vary', 'Origin');
  }
  if (req.method === 'OPTIONS') return res.status(204).end();
  next();
}

// ─── Request ID Injection ───────────────────────────────────────────────────
export function requestId(req, res, next) {
  const id = req.headers['x-request-id'] || crypto.randomUUID();
  req.requestId = id;
  res.setHeader('X-Request-ID', id);
  next();
}

// ─── Periodic cleanup (Fibonacci interval: 89 seconds) ─────────────────────
setInterval(() => {
  const now = Date.now();
  for (const [key, timestamps] of rateLimitStore) {
    const active = timestamps.filter(t => now - t < RATE_LIMITS.windowMs);
    if (active.length === 0) rateLimitStore.delete(key);
    else rateLimitStore.set(key, active);
  }
}, FIB[11] * 1000); // 89 seconds
