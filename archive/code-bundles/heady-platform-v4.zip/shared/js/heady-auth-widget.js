/**
 * Heady™ Auth Widget — Cross-Site Authentication Widget
 * Security: httpOnly cookie relay, iframe heartbeat, CSRF protection, global sign-out
 * Emits heady:auth:changed custom events for reactivity
 * © 2024-2026 HeadySystems Inc. All Rights Reserved. 51+ Provisional Patents.
 */
'use strict';

const HeadyAuthWidget = (() => {
  // ─── φ-Constants ──────────────────────────────────────────────────────────
  const PHI = 1.618033988749895;
  const PSI = 1 / PHI; // ≈ 0.618

  // ─── Config ───────────────────────────────────────────────────────────────
  const AUTH_DOMAIN = 'https://auth.headysystems.com';
  const AUTH_PAGE = '/login';
  const TOKEN_REFRESH_INTERVAL = Math.round(PSI * 15 * 60 * 1000); // ~9.27 min (φ-scaled)
  const HEARTBEAT_INTERVAL = Math.round(PSI * 30 * 1000); // ~18.5s (φ-scaled)

  // ─── Allowed Domains for Token Relay ──────────────────────────────────────
  const ALLOWED_ORIGINS = Object.freeze([
    'https://headyme.com', 'https://headysystems.com', 'https://heady-ai.com',
    'https://headyos.com', 'https://headyconnection.org', 'https://headyconnection.com',
    'https://headyex.com', 'https://headyfinance.com', 'https://admin.headysystems.com',
    'https://auth.headysystems.com',
    'http://localhost:3000', 'http://localhost:8080', // dev
  ]);

  // ─── State ────────────────────────────────────────────────────────────────
  let currentUser = null;
  let refreshTimer = null;
  let heartbeatTimer = null;
  let relayIframe = null;

  // ─── CSRF Token Generation ────────────────────────────────────────────────
  function generateCsrfToken() {
    const array = new Uint8Array(16);
    crypto.getRandomValues(array);
    return Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
  }

  // ─── Relay Iframe for Cross-Domain Token Sync ─────────────────────────────
  function createRelayIframe() {
    if (relayIframe) return;
    relayIframe = document.createElement('iframe');
    relayIframe.id = 'heady-auth-relay';
    relayIframe.src = `${AUTH_DOMAIN}/relay.html`;
    relayIframe.style.cssText = 'display:none;width:0;height:0;border:0;position:absolute;';
    relayIframe.setAttribute('aria-hidden', 'true');
    relayIframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
    document.body.appendChild(relayIframe);
  }

  // ─── Message Handler for Token Relay ──────────────────────────────────────
  function handleAuthMessage(event) {
    if (!ALLOWED_ORIGINS.includes(event.origin)) return;
    const data = event.data;
    if (!data || typeof data !== 'object') return;

    switch (data.type) {
      case 'heady:auth:token':
        handleTokenReceived(data);
        break;
      case 'heady:auth:signout':
        handleGlobalSignOut();
        break;
      case 'heady:auth:heartbeat':
        handleHeartbeat(data);
        break;
      case 'heady:auth:refresh':
        handleTokenRefresh(data);
        break;
    }
  }

  function handleTokenReceived(data) {
    if (!data.user || !data.token) return;
    if (data.expiresAt && Date.now() > data.expiresAt) {
      console.warn('[HeadyAuth] Received expired token, requesting refresh');
      requestTokenRefresh();
      return;
    }
    currentUser = data.user;
    renderWidget();
    dispatchAuthEvent('authenticated', data.user);
  }

  function handleGlobalSignOut() {
    currentUser = null;
    clearInterval(refreshTimer);
    clearInterval(heartbeatTimer);
    renderWidget();
    dispatchAuthEvent('signed-out', null);
  }

  function handleHeartbeat(data) {
    if (data.user && data.expiresAt > Date.now()) {
      currentUser = data.user;
    }
  }

  function handleTokenRefresh(data) {
    if (data.token && data.expiresAt > Date.now()) {
      currentUser = data.user;
      dispatchAuthEvent('token-refreshed', data.user);
    }
  }

  // ─── Token Refresh via Relay Iframe ───────────────────────────────────────
  function requestTokenRefresh() {
    if (relayIframe?.contentWindow) {
      relayIframe.contentWindow.postMessage(
        { type: 'heady:auth:request-refresh', csrf: generateCsrfToken() },
        AUTH_DOMAIN
      );
    }
  }

  function startHeartbeat() {
    heartbeatTimer = setInterval(() => {
      if (relayIframe?.contentWindow) {
        relayIframe.contentWindow.postMessage(
          { type: 'heady:auth:ping', timestamp: Date.now() },
          AUTH_DOMAIN
        );
      }
    }, HEARTBEAT_INTERVAL);
  }

  function startTokenRefreshCycle() {
    refreshTimer = setInterval(() => {
      requestTokenRefresh();
    }, TOKEN_REFRESH_INTERVAL);
  }

  // ─── Dispatch Custom Events ───────────────────────────────────────────────
  function dispatchAuthEvent(status, user) {
    window.dispatchEvent(new CustomEvent('heady:auth:changed', {
      detail: { status, user, timestamp: Date.now() },
      bubbles: true,
    }));
  }

  // ─── Sign Out (Global) ────────────────────────────────────────────────────
  function signOut() {
    // Broadcast sign-out to all domains via relay
    if (relayIframe?.contentWindow) {
      relayIframe.contentWindow.postMessage(
        { type: 'heady:auth:signout-request', csrf: generateCsrfToken() },
        AUTH_DOMAIN
      );
    }
    handleGlobalSignOut();
    // Redirect to auth domain for server-side cookie clearing
    window.location.href = `${AUTH_DOMAIN}/signout?redirect=${encodeURIComponent(window.location.href)}`;
  }

  // ─── Render Widget ────────────────────────────────────────────────────────
  function renderWidget() {
    let widget = document.getElementById('heady-auth-widget');
    if (!widget) {
      widget = document.createElement('div');
      widget.id = 'heady-auth-widget';
      widget.setAttribute('role', 'navigation');
      widget.setAttribute('aria-label', 'Authentication');
      // Insert into nav if exists, otherwise append to body
      const nav = document.querySelector('.nav-inner') || document.querySelector('nav');
      if (nav) {
        nav.appendChild(widget);
      } else {
        document.body.appendChild(widget);
      }
    }

    if (currentUser) {
      const avatar = currentUser.photoURL
        ? `<img src="${currentUser.photoURL}" alt="${currentUser.displayName || 'User'}" style="width:34px;height:34px;border-radius:50%;border:2px solid var(--accent,#00d4aa);">`
        : `<div style="width:34px;height:34px;border-radius:50%;background:var(--accent,#00d4aa);display:flex;align-items:center;justify-content:center;color:#0a0a0f;font-weight:700;font-size:0.875rem;">${(currentUser.displayName || currentUser.email || 'U')[0].toUpperCase()}</div>`;
      widget.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;cursor:pointer;" id="heady-user-menu">
          ${avatar}
          <span style="color:#e8e8f0;font-size:0.875rem;">${currentUser.displayName || currentUser.email || 'Guest'}</span>
        </div>
        <div id="heady-user-dropdown" style="display:none;position:absolute;right:0;top:100%;margin-top:8px;background:rgba(18,18,26,0.95);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:8px 0;min-width:180px;z-index:10000;">
          <a href="https://headyme.com" style="display:block;padding:8px 21px;color:#e8e8f0;text-decoration:none;font-size:0.875rem;">Dashboard</a>
          <a href="https://admin.headysystems.com" style="display:block;padding:8px 21px;color:#e8e8f0;text-decoration:none;font-size:0.875rem;">Admin</a>
          <div style="border-top:1px solid rgba(255,255,255,0.08);margin:5px 0;"></div>
          <button id="heady-signout-btn" style="display:block;width:100%;text-align:left;padding:8px 21px;color:#ff6b6b;background:none;border:none;cursor:pointer;font-size:0.875rem;">Sign Out</button>
        </div>`;
      // Wire dropdown toggle
      const menu = widget.querySelector('#heady-user-menu');
      const dropdown = widget.querySelector('#heady-user-dropdown');
      menu.addEventListener('click', () => {
        dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
      });
      widget.querySelector('#heady-signout-btn').addEventListener('click', signOut);
      document.addEventListener('click', (e) => {
        if (!widget.contains(e.target)) dropdown.style.display = 'none';
      });
    } else {
      const currentUrl = encodeURIComponent(window.location.href);
      widget.innerHTML = `
        <a href="${AUTH_DOMAIN}${AUTH_PAGE}?redirect=${currentUrl}"
           style="display:inline-flex;align-items:center;gap:8px;padding:8px 21px;border-radius:8px;
                  background:rgba(255,255,255,0.05);border:1px solid rgba(255,255,255,0.08);
                  color:#e8e8f0;text-decoration:none;font-size:0.875rem;
                  transition:all 0.3s cubic-bezier(0.618,0,0.382,1);"
           onmouseover="this.style.borderColor='var(--accent,#00d4aa)'"
           onmouseout="this.style.borderColor='rgba(255,255,255,0.08)'">
          <span>🔐</span> Sign In
        </a>`;
    }
    widget.style.cssText = 'position:relative;margin-left:auto;';
  }

  // ─── Initialize ───────────────────────────────────────────────────────────
  function init() {
    window.addEventListener('message', handleAuthMessage);
    createRelayIframe();
    startHeartbeat();
    startTokenRefreshCycle();
    renderWidget();
    console.log('[HeadyAuth] Widget initialized with relay iframe, heartbeat, and CSRF protection');
  }

  // Auto-init when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // ─── Public API ───────────────────────────────────────────────────────────
  return Object.freeze({
    getUser: () => currentUser,
    signOut,
    isAuthenticated: () => currentUser !== null,
    onAuthChanged: (callback) => {
      window.addEventListener('heady:auth:changed', (e) => callback(e.detail));
    },
  });
})();

if (typeof window !== 'undefined') window.HeadyAuthWidget = HeadyAuthWidget;
