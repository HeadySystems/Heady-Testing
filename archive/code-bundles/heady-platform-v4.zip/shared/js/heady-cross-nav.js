/**
 * heady-cross-nav.js — Cross-site ecosystem navigation
 * Links all 9 Heady sites together. Highlights current site.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
(function() {
  const SITES = [
    { id: 'headyme', name: 'HeadyMe', url: 'https://headyme.com', role: 'Personal AI Cloud', accent: '#00d4aa' },
    { id: 'headysystems', name: 'HeadySystems', url: 'https://headysystems.com', role: 'Enterprise Infrastructure', accent: '#00d4aa' },
    { id: 'heady-ai', name: 'HeadyAI', url: 'https://heady-ai.com', role: 'Research & Science', accent: '#8b5cf6' },
    { id: 'headyos', name: 'HeadyOS', url: 'https://headyos.com', role: 'AI Operating System', accent: '#14b8a6' },
    { id: 'headyconnection-org', name: 'HeadyConnection', url: 'https://headyconnection.org', role: 'Non-Profit 501(c)(3)', accent: '#f59e0b' },
    { id: 'headyconnection-com', name: 'Community', url: 'https://headyconnection.com', role: 'Community Portal', accent: '#06b6d4' },
    { id: 'headyex', name: 'HeadyEX', url: 'https://headyex.com', role: 'Agent Marketplace', accent: '#10b981' },
    { id: 'headyfinance', name: 'HeadyFinance', url: 'https://headyfinance.com', role: 'Investor Relations', accent: '#a855f7' },
    { id: 'admin', name: 'Admin Portal', url: 'https://admin.headysystems.com', role: 'Internal Ops', accent: '#06b6d4' },
  ];

  function detectCurrentSite() {
    const host = window.location.hostname;
    return SITES.find(s => s.url.includes(host))?.id || null;
  }

  function renderEcosystemMap(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const currentId = detectCurrentSite();
    container.innerHTML = SITES.map(s => `
      <a href="${s.url}" class="ecosystem-card${s.id === currentId ? ' current' : ''}" target="${s.id === currentId ? '_self' : '_blank'}">
        <div class="eco-name">${s.name}</div>
        <div class="eco-role">${s.role}</div>
      </a>
    `).join('');
  }

  function renderFooterNav(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const cols = [
      { title: 'Platform', items: SITES.slice(0, 4) },
      { title: 'Community', items: SITES.slice(4, 7) },
      { title: 'Business', items: SITES.slice(7) },
    ];
    container.innerHTML = `
      <div class="footer-brand">
        <h3>Heady™</h3>
        <p>Sovereign AI Operating System. 51+ provisional patents. φ-scaled everything. Sacred Geometry orchestration across 17 concurrent swarms.</p>
        <p style="margin-top:var(--space-md);font-size:var(--text-xs);">© ${new Date().getFullYear()} HeadySystems Inc. All Rights Reserved.</p>
      </div>
      ${cols.map(col => `
        <div class="footer-col">
          <h4>${col.title}</h4>
          <ul>${col.items.map(s => `<li><a href="${s.url}" target="_blank">${s.name}</a></li>`).join('')}</ul>
        </div>
      `).join('')}
    `;
  }

  window.HeadyCrossNav = { SITES, detectCurrentSite, renderEcosystemMap, renderFooterNav };
})();
