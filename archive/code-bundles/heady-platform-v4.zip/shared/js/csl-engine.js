/**
 * csl-engine.js — Continuous Semantic Logic Gates for Heady™
 * Geometric vector operations as logical gates.
 * Domain: Unit vectors in ℝᴰ, D ∈ {384, 1536}
 * Truth value: τ(a,b) = cos(θ) ∈ [-1, +1]
 * © 2024-2026 HeadySystems Inc. 60+ Provisional Patents.
 */
(function() {
  const { PHI, PSI, CSL_GATES } = window.HeadyPhi;

  function dot(a, b) {
    let s = 0; for (let i = 0; i < a.length; i++) s += a[i] * b[i]; return s;
  }
  function norm(v) { return Math.sqrt(dot(v, v)); }
  function normalize(v) {
    const n = norm(v); if (n === 0) return new Float64Array(v.length);
    return v.map(x => x / n);
  }
  function cosineSimilarity(a, b) {
    const na = norm(a), nb = norm(b);
    if (na === 0 || nb === 0) return 0;
    return dot(a, b) / (na * nb);
  }
  function cslAND(a, b) { return cosineSimilarity(a, b); }
  function cslOR(a, b) {
    const sum = a.map((v, i) => v + b[i]); return normalize(sum);
  }
  function cslNOT(v, basis) {
    const d = dot(v, basis); return v.map((x, i) => x - d * basis[i]);
  }
  function cslIMPLY(a, b) {
    const d = dot(a, b) / dot(b, b); return b.map(x => x * d);
  }
  function cslGate(similarity, gate) {
    return similarity >= (gate || CSL_GATES.include);
  }
  function cslRelevanceScore(query, candidates) {
    return candidates.map((c, i) => ({
      index: i, similarity: cosineSimilarity(query, c.vector),
      payload: c.payload,
    })).filter(r => r.similarity >= CSL_GATES.include)
      .sort((a, b) => b.similarity - a.similarity);
  }

  window.HeadyCSL = {
    dot, norm, normalize, cosineSimilarity,
    cslAND, cslOR, cslNOT, cslIMPLY,
    cslGate, cslRelevanceScore,
  };
})();
