/**
 * saga-coordinator — Distributed transaction orchestrator with compensating actions
 * Heady™ Service | Domain: orchestration | Port: 3405
 * ALL requests enriched by HeadyAutoContext (MANDATORY)
 * NO priority/ranking code. Everything concurrent and equal.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
'use strict';

import express from 'express';
import { randomUUID } from 'crypto';
import pg from 'pg';

// ─── φ-Math Constants (No Magic Numbers) ──────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── Service Config ───────────────────────────────────────────────────────────
const SERVICE_NAME = 'saga-coordinator';
const PORT = process.env.PORT || 3405;
const DOMAIN = 'orchestration';
const BOOT_TIME = Date.now();

// ─── Saga Constants (φ-derived) ──────────────────────────────────────────────
const STEP_TIMEOUT_MS = Math.round(PHI * 1000 * PHI * PHI);  // ≈ 4236ms
const MAX_RETRIES_PER_STEP = FIB[5];                          // 8
const SAGA_TTL_MS = FIB[10] * 1000;                           // 89000ms (89s)
const MAX_CONCURRENT_SAGAS = FIB[8];                           // 34
const RETRY_BASE_DELAY_MS = Math.round(PHI * 1000);           // ≈ 1618ms
const CLEANUP_INTERVAL_MS = FIB[9] * 1000;                    // 55000ms

// ─── Structured Logging ──────────────────────────────────────────────────────
function structuredLog(level, msg, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    service: SERVICE_NAME,
    level,
    message: msg,
    correlationId: meta.correlationId || 'system',
    domain: DOMAIN,
    ...meta,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── PostgreSQL Connection Pool ──────────────────────────────────────────────
const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://heady:heady@localhost:5432/heady',
  max: FIB[7],                          // 21 connections
  idleTimeoutMillis: FIB[10] * 1000,    // 89s
  connectionTimeoutMillis: FIB[8] * 1000, // 34s
});

pool.on('error', (err) => {
  structuredLog('error', 'Unexpected pool error', { error: err.message });
});

// ─── Schema Initialization ───────────────────────────────────────────────────
async function initSchema() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS sagas (
        saga_id UUID PRIMARY KEY,
        saga_type VARCHAR(144) NOT NULL,
        status VARCHAR(34) NOT NULL DEFAULT 'pending',
        payload JSONB NOT NULL DEFAULT '{}',
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '89 seconds')
      );
      CREATE TABLE IF NOT EXISTS saga_steps (
        id SERIAL PRIMARY KEY,
        saga_id UUID NOT NULL REFERENCES sagas(saga_id) ON DELETE CASCADE,
        step_name VARCHAR(144) NOT NULL,
        step_index INTEGER NOT NULL,
        status VARCHAR(34) NOT NULL DEFAULT 'pending',
        payload JSONB NOT NULL DEFAULT '{}',
        compensate_payload JSONB NOT NULL DEFAULT '{}',
        result JSONB,
        error_message TEXT,
        retries INTEGER NOT NULL DEFAULT 0,
        executed_at TIMESTAMPTZ,
        compensated_at TIMESTAMPTZ
      );
      CREATE INDEX IF NOT EXISTS idx_sagas_status ON sagas(status);
      CREATE INDEX IF NOT EXISTS idx_saga_steps_saga_id ON saga_steps(saga_id);
    `);
    structuredLog('info', 'Schema initialized');
  } finally {
    client.release();
  }
}

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '1mb' }));
app.disable('x-powered-by');

// ─── MANDATORY: HeadyAutoContext Enrichment Middleware ─────────────────────────
app.use((req, res, next) => {
  req.headyContext = {
    service: SERVICE_NAME,
    domain: DOMAIN,
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
    timestamp: Date.now(),
    vectorDim: VECTOR_DIM,
    cslGates: CSL_GATES,
  };
  res.setHeader('X-Heady-Service', SERVICE_NAME);
  res.setHeader('X-Correlation-Id', req.headyContext.correlationId);
  res.setHeader('X-Heady-Domain', DOMAIN);
  next();
});

// ─── Bulkhead Pattern ────────────────────────────────────────────────────────
const BULKHEAD = {
  maxConcurrent: FIB[9],   // 55
  queueSize: FIB[10],      // 89
  active: 0,
  queued: 0,
};

function bulkheadMiddleware(req, res, next) {
  if (BULKHEAD.active >= BULKHEAD.maxConcurrent) {
    if (BULKHEAD.queued >= BULKHEAD.queueSize) {
      return res.status(503).json({
        error: 'Service at capacity',
        service: SERVICE_NAME,
        bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
      });
    }
    BULKHEAD.queued++;
    setTimeout(() => {
      BULKHEAD.queued--;
      BULKHEAD.active++;
      res.on('finish', () => { BULKHEAD.active--; });
      next();
    }, Math.round(PSI * 1000));
    return;
  }
  BULKHEAD.active++;
  res.on('finish', () => { BULKHEAD.active--; });
  next();
}

app.use('/saga', bulkheadMiddleware);

// ─── Circuit Breaker ─────────────────────────────────────────────────────────
const circuitBreaker = {
  state: 'closed',
  failures: 0,
  maxFailures: FIB[7],                  // 21
  resetTimeoutMs: FIB[10] * 1000,       // 89s
  lastFailure: 0,

  check() {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure > this.resetTimeoutMs) {
        this.state = 'half-open';
        return true;
      }
      return false;
    }
    return true;
  },

  recordSuccess() {
    this.failures = 0;
    this.state = 'closed';
  },

  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.failures >= this.maxFailures) {
      this.state = 'open';
      structuredLog('warn', 'Circuit breaker opened', { failures: this.failures });
    }
  },
};

// ─── Saga Definitions Registry ───────────────────────────────────────────────
const sagaRegistry = new Map();
let activeSagaCount = 0;

// Built-in saga: UserSignup
sagaRegistry.set('UserSignup', {
  steps: [
    {
      name: 'createFirebaseAccount',
      execute: async (payload, ctx) => {
        const res = await fetchWithTimeout(
          `${process.env.AUTH_SERVICE_URL || 'http://auth-session-server:3397'}/auth/create`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': ctx.correlationId },
            body: JSON.stringify({ email: payload.email, displayName: payload.displayName }),
          },
          STEP_TIMEOUT_MS
        );
        return res;
      },
      compensate: async (payload, result, ctx) => {
        await fetchWithTimeout(
          `${process.env.AUTH_SERVICE_URL || 'http://auth-session-server:3397'}/auth/delete`,
          {
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': ctx.correlationId },
            body: JSON.stringify({ uid: result.uid }),
          },
          STEP_TIMEOUT_MS
        );
      },
    },
    {
      name: 'indexVectorMemory',
      execute: async (payload, ctx) => {
        const res = await fetchWithTimeout(
          `${process.env.MEMORY_SERVICE_URL || 'http://heady-memory:3317'}/vectors/index`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': ctx.correlationId },
            body: JSON.stringify({
              userId: payload.userId,
              content: `User profile: ${payload.displayName} <${payload.email}>`,
              dimensions: VECTOR_DIM,
            }),
          },
          STEP_TIMEOUT_MS
        );
        return res;
      },
      compensate: async (payload, result, ctx) => {
        await fetchWithTimeout(
          `${process.env.MEMORY_SERVICE_URL || 'http://heady-memory:3317'}/vectors/${result.vectorId}`,
          {
            method: 'DELETE',
            headers: { 'X-Correlation-Id': ctx.correlationId },
          },
          STEP_TIMEOUT_MS
        );
      },
    },
    {
      name: 'sendWelcomeNotification',
      execute: async (payload, ctx) => {
        const res = await fetchWithTimeout(
          `${process.env.NOTIFICATION_SERVICE_URL || 'http://notification-service:3398'}/notifications/send`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-Correlation-Id': ctx.correlationId },
            body: JSON.stringify({
              userId: payload.userId,
              channel: 'email',
              template: 'welcome',
              data: { displayName: payload.displayName },
            }),
          },
          STEP_TIMEOUT_MS
        );
        return res;
      },
      compensate: async () => {
        // Notifications are fire-and-forget; no compensating action needed
      },
    },
    {
      name: 'createDrupalAccount',
      execute: async (payload, ctx) => {
        const res = await fetchWithTimeout(
          `${process.env.DRUPAL_URL || 'http://drupal:8080'}/jsonapi/user/user`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/vnd.api+json',
              'X-Correlation-Id': ctx.correlationId,
            },
            body: JSON.stringify({
              data: {
                type: 'user--user',
                attributes: {
                  name: payload.email,
                  mail: payload.email,
                  display_name: payload.displayName,
                },
              },
            }),
          },
          STEP_TIMEOUT_MS
        );
        return res;
      },
      compensate: async (payload, result, ctx) => {
        if (result && result.data && result.data.id) {
          await fetchWithTimeout(
            `${process.env.DRUPAL_URL || 'http://drupal:8080'}/jsonapi/user/user/${result.data.id}`,
            {
              method: 'DELETE',
              headers: { 'X-Correlation-Id': ctx.correlationId },
            },
            STEP_TIMEOUT_MS
          );
        }
      },
    },
  ],
});

// ─── HTTP Fetch with Timeout ─────────────────────────────────────────────────
async function fetchWithTimeout(url, options, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    const body = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${JSON.stringify(body)}`);
    }
    return body;
  } finally {
    clearTimeout(timer);
  }
}

// ─── Saga Execution Engine ───────────────────────────────────────────────────
async function executeSaga(sagaId, sagaType, payload) {
  const definition = sagaRegistry.get(sagaType);
  if (!definition) {
    throw new Error(`Unknown saga type: ${sagaType}`);
  }

  const ctx = {
    correlationId: sagaId,
    sagaId,
    sagaType,
  };

  const completedSteps = [];

  // Insert saga steps into DB
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    for (let i = 0; i < definition.steps.length; i++) {
      await client.query(
        `INSERT INTO saga_steps (saga_id, step_name, step_index, payload) VALUES ($1, $2, $3, $4)`,
        [sagaId, definition.steps[i].name, i, JSON.stringify(payload)]
      );
    }
    await client.query(
      `UPDATE sagas SET status = 'executing', updated_at = NOW() WHERE saga_id = $1`,
      [sagaId]
    );
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }

  // Execute steps sequentially (saga pattern requires ordered execution)
  for (let i = 0; i < definition.steps.length; i++) {
    const step = definition.steps[i];
    let attempt = 0;
    let stepResult = null;
    let stepError = null;

    while (attempt < MAX_RETRIES_PER_STEP) {
      try {
        structuredLog('info', `Executing step: ${step.name}`, {
          correlationId: sagaId,
          step: step.name,
          attempt: attempt + 1,
          maxRetries: MAX_RETRIES_PER_STEP,
        });

        stepResult = await step.execute(payload, ctx);

        // Record success in DB
        await pool.query(
          `UPDATE saga_steps SET status = 'completed', result = $1, retries = $2, executed_at = NOW()
           WHERE saga_id = $3 AND step_name = $4`,
          [JSON.stringify(stepResult), attempt, sagaId, step.name]
        );

        completedSteps.push({ step, result: stepResult, index: i });
        stepError = null;
        break;
      } catch (err) {
        attempt++;
        stepError = err;
        structuredLog('warn', `Step failed: ${step.name}`, {
          correlationId: sagaId,
          step: step.name,
          attempt,
          error: err.message,
        });

        if (attempt < MAX_RETRIES_PER_STEP) {
          // φ-exponential backoff
          const delay = Math.round(RETRY_BASE_DELAY_MS * Math.pow(PHI, attempt - 1));
          await new Promise((resolve) => setTimeout(resolve, delay));
        }
      }
    }

    if (stepError) {
      // Record step failure
      await pool.query(
        `UPDATE saga_steps SET status = 'failed', error_message = $1, retries = $2, executed_at = NOW()
         WHERE saga_id = $3 AND step_name = $4`,
        [stepError.message, attempt, sagaId, step.name]
      );

      structuredLog('error', `Saga step failed permanently, initiating compensation`, {
        correlationId: sagaId,
        failedStep: step.name,
        completedSteps: completedSteps.length,
      });

      // Compensate in LIFO order
      await compensateSaga(sagaId, completedSteps, payload, ctx);

      await pool.query(
        `UPDATE sagas SET status = 'compensated', updated_at = NOW() WHERE saga_id = $1`,
        [sagaId]
      );

      activeSagaCount--;
      return { status: 'compensated', failedStep: step.name, error: stepError.message };
    }

    // Enrich payload with step result for downstream steps
    payload = { ...payload, [`${step.name}Result`]: stepResult };
  }

  // All steps completed
  await pool.query(
    `UPDATE sagas SET status = 'completed', updated_at = NOW() WHERE saga_id = $1`,
    [sagaId]
  );

  activeSagaCount--;
  structuredLog('info', 'Saga completed', { correlationId: sagaId, steps: completedSteps.length });
  return { status: 'completed', steps: completedSteps.map((s) => s.step.name) };
}

// ─── Compensation Engine (LIFO) ─────────────────────────────────────────────
async function compensateSaga(sagaId, completedSteps, originalPayload, ctx) {
  structuredLog('info', 'Starting LIFO compensation', {
    correlationId: sagaId,
    stepsToCompensate: completedSteps.length,
  });

  // LIFO: reverse order
  for (let i = completedSteps.length - 1; i >= 0; i--) {
    const { step, result } = completedSteps[i];
    try {
      await step.compensate(originalPayload, result, ctx);
      await pool.query(
        `UPDATE saga_steps SET status = 'compensated', compensated_at = NOW()
         WHERE saga_id = $1 AND step_name = $2`,
        [sagaId, step.name]
      );
      structuredLog('info', `Compensated step: ${step.name}`, { correlationId: sagaId });
    } catch (err) {
      structuredLog('error', `Compensation failed for step: ${step.name}`, {
        correlationId: sagaId,
        step: step.name,
        error: err.message,
      });
      await pool.query(
        `UPDATE saga_steps SET status = 'compensation_failed', error_message = $1
         WHERE saga_id = $2 AND step_name = $3`,
        [err.message, sagaId, step.name]
      );
    }
  }
}

// ─── Health Endpoints ────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: SERVICE_NAME,
    domain: DOMAIN,
    uptime: Date.now() - BOOT_TIME,
    activeSagas: activeSagaCount,
    circuitBreaker: circuitBreaker.state,
    bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
    phi: PHI,
    vectorDim: VECTOR_DIM,
  });
});

app.get('/ready', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ready', service: SERVICE_NAME });
  } catch (err) {
    res.status(503).json({ status: 'not_ready', error: err.message });
  }
});

app.get('/healthz', (req, res) => {
  res.json({ status: 'ok', service: SERVICE_NAME });
});

// ─── POST /saga/start ────────────────────────────────────────────────────────
app.post('/saga/start', async (req, res) => {
  const { sagaType, payload } = req.body;
  const correlationId = req.headyContext.correlationId;

  if (!sagaType || !payload) {
    return res.status(400).json({
      error: 'Missing sagaType or payload',
      service: SERVICE_NAME,
      correlationId,
    });
  }

  if (!sagaRegistry.has(sagaType)) {
    return res.status(400).json({
      error: `Unknown saga type: ${sagaType}`,
      availableTypes: Array.from(sagaRegistry.keys()),
      service: SERVICE_NAME,
      correlationId,
    });
  }

  if (activeSagaCount >= MAX_CONCURRENT_SAGAS) {
    return res.status(429).json({
      error: 'Concurrent saga limit reached',
      limit: MAX_CONCURRENT_SAGAS,
      service: SERVICE_NAME,
      correlationId,
    });
  }

  if (!circuitBreaker.check()) {
    return res.status(503).json({
      error: 'Circuit breaker is open',
      service: SERVICE_NAME,
      correlationId,
    });
  }

  const sagaId = randomUUID();

  try {
    await pool.query(
      `INSERT INTO sagas (saga_id, saga_type, payload, expires_at)
       VALUES ($1, $2, $3, NOW() + INTERVAL '${FIB[10]} seconds')`,
      [sagaId, sagaType, JSON.stringify(payload)]
    );

    activeSagaCount++;
    structuredLog('info', 'Saga started', { correlationId: sagaId, sagaType });

    // Execute asynchronously
    executeSaga(sagaId, sagaType, payload).catch((err) => {
      structuredLog('error', 'Saga execution error', {
        correlationId: sagaId,
        error: err.message,
      });
      pool.query(
        `UPDATE sagas SET status = 'failed', updated_at = NOW() WHERE saga_id = $1`,
        [sagaId]
      ).catch(() => {});
      activeSagaCount--;
      circuitBreaker.recordFailure();
    });

    circuitBreaker.recordSuccess();

    res.status(202).json({
      sagaId,
      sagaType,
      status: 'executing',
      statusUrl: `/saga/${sagaId}/status`,
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    circuitBreaker.recordFailure();
    structuredLog('error', 'Failed to start saga', { correlationId, error: err.message });
    res.status(500).json({ error: 'Failed to start saga', service: SERVICE_NAME, correlationId });
  }
});

// ─── GET /saga/:id/status ────────────────────────────────────────────────────
app.get('/saga/:id/status', async (req, res) => {
  const { id } = req.params;
  const correlationId = req.headyContext.correlationId;

  try {
    const sagaResult = await pool.query(
      `SELECT saga_id, saga_type, status, payload, created_at, updated_at, expires_at
       FROM sagas WHERE saga_id = $1`,
      [id]
    );

    if (sagaResult.rows.length === 0) {
      return res.status(404).json({ error: 'Saga not found', sagaId: id, service: SERVICE_NAME, correlationId });
    }

    const stepsResult = await pool.query(
      `SELECT step_name, step_index, status, result, error_message, retries, executed_at, compensated_at
       FROM saga_steps WHERE saga_id = $1 ORDER BY step_index`,
      [id]
    );

    const saga = sagaResult.rows[0];
    res.json({
      sagaId: saga.saga_id,
      sagaType: saga.saga_type,
      status: saga.status,
      payload: saga.payload,
      steps: stepsResult.rows,
      createdAt: saga.created_at,
      updatedAt: saga.updated_at,
      expiresAt: saga.expires_at,
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    structuredLog('error', 'Failed to fetch saga status', { correlationId, error: err.message });
    res.status(500).json({ error: 'Internal error', service: SERVICE_NAME, correlationId });
  }
});

// ─── POST /saga/:id/retry ────────────────────────────────────────────────────
app.post('/saga/:id/retry', async (req, res) => {
  const { id } = req.params;
  const correlationId = req.headyContext.correlationId;

  try {
    const sagaResult = await pool.query(
      `SELECT saga_id, saga_type, status, payload FROM sagas WHERE saga_id = $1`,
      [id]
    );

    if (sagaResult.rows.length === 0) {
      return res.status(404).json({ error: 'Saga not found', sagaId: id, service: SERVICE_NAME, correlationId });
    }

    const saga = sagaResult.rows[0];
    if (saga.status !== 'failed' && saga.status !== 'compensated') {
      return res.status(409).json({
        error: `Cannot retry saga in status: ${saga.status}`,
        sagaId: id,
        service: SERVICE_NAME,
        correlationId,
      });
    }

    if (activeSagaCount >= MAX_CONCURRENT_SAGAS) {
      return res.status(429).json({
        error: 'Concurrent saga limit reached',
        limit: MAX_CONCURRENT_SAGAS,
        service: SERVICE_NAME,
        correlationId,
      });
    }

    // Reset saga and steps
    await pool.query(
      `UPDATE sagas SET status = 'pending', updated_at = NOW(),
       expires_at = NOW() + INTERVAL '${FIB[10]} seconds' WHERE saga_id = $1`,
      [id]
    );
    await pool.query(
      `UPDATE saga_steps SET status = 'pending', result = NULL, error_message = NULL,
       retries = 0, executed_at = NULL, compensated_at = NULL WHERE saga_id = $1`,
      [id]
    );

    activeSagaCount++;
    structuredLog('info', 'Saga retry initiated', { correlationId: id, sagaType: saga.saga_type });

    executeSaga(id, saga.saga_type, saga.payload).catch((err) => {
      structuredLog('error', 'Saga retry error', { correlationId: id, error: err.message });
      pool.query(
        `UPDATE sagas SET status = 'failed', updated_at = NOW() WHERE saga_id = $1`, [id]
      ).catch(() => {});
      activeSagaCount--;
    });

    res.status(202).json({
      sagaId: id,
      sagaType: saga.saga_type,
      status: 'retrying',
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    structuredLog('error', 'Failed to retry saga', { correlationId, error: err.message });
    res.status(500).json({ error: 'Internal error', service: SERVICE_NAME, correlationId });
  }
});

// ─── DELETE /saga/:id/cancel ─────────────────────────────────────────────────
app.delete('/saga/:id/cancel', async (req, res) => {
  const { id } = req.params;
  const correlationId = req.headyContext.correlationId;

  try {
    const sagaResult = await pool.query(
      `SELECT saga_id, saga_type, status, payload FROM sagas WHERE saga_id = $1`,
      [id]
    );

    if (sagaResult.rows.length === 0) {
      return res.status(404).json({ error: 'Saga not found', sagaId: id, service: SERVICE_NAME, correlationId });
    }

    const saga = sagaResult.rows[0];
    if (saga.status === 'completed') {
      return res.status(409).json({
        error: 'Cannot cancel a completed saga',
        sagaId: id,
        service: SERVICE_NAME,
        correlationId,
      });
    }

    await pool.query(
      `UPDATE sagas SET status = 'cancelled', updated_at = NOW() WHERE saga_id = $1`,
      [id]
    );
    await pool.query(
      `UPDATE saga_steps SET status = 'cancelled' WHERE saga_id = $1 AND status = 'pending'`,
      [id]
    );

    structuredLog('info', 'Saga cancelled', { correlationId: id, sagaType: saga.saga_type });

    res.json({
      sagaId: id,
      status: 'cancelled',
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    structuredLog('error', 'Failed to cancel saga', { correlationId, error: err.message });
    res.status(500).json({ error: 'Internal error', service: SERVICE_NAME, correlationId });
  }
});

// ─── GET /saga/types ─────────────────────────────────────────────────────────
app.get('/saga/types', (req, res) => {
  const types = [];
  for (const [name, def] of sagaRegistry) {
    types.push({
      name,
      steps: def.steps.map((s) => s.name),
      stepCount: def.steps.length,
    });
  }
  res.json({
    types,
    constants: {
      stepTimeoutMs: STEP_TIMEOUT_MS,
      maxRetriesPerStep: MAX_RETRIES_PER_STEP,
      sagaTtlMs: SAGA_TTL_MS,
      maxConcurrentSagas: MAX_CONCURRENT_SAGAS,
      retryBaseDelayMs: RETRY_BASE_DELAY_MS,
    },
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── Expired Saga Cleanup ────────────────────────────────────────────────────
async function cleanupExpiredSagas() {
  try {
    const result = await pool.query(
      `UPDATE sagas SET status = 'expired', updated_at = NOW()
       WHERE status IN ('pending', 'executing') AND expires_at < NOW()
       RETURNING saga_id`
    );
    if (result.rowCount > 0) {
      structuredLog('info', 'Expired sagas cleaned up', { count: result.rowCount });
    }
  } catch (err) {
    structuredLog('error', 'Cleanup error', { error: err.message });
  }
}

let cleanupTimer = null;

// ─── Graceful Shutdown ───────────────────────────────────────────────────────
let server = null;
const shutdownHandlers = [];

function addShutdownHandler(name, handler) {
  shutdownHandlers.push({ name, handler });
}

async function gracefulShutdown(signal) {
  structuredLog('info', `Shutdown initiated: ${signal}`, { activeSagas: activeSagaCount });

  if (cleanupTimer) {
    clearInterval(cleanupTimer);
    cleanupTimer = null;
  }

  // LIFO shutdown
  for (let i = shutdownHandlers.length - 1; i >= 0; i--) {
    const { name, handler } = shutdownHandlers[i];
    try {
      await handler();
      structuredLog('info', `Shutdown handler completed: ${name}`);
    } catch (err) {
      structuredLog('error', `Shutdown handler failed: ${name}`, { error: err.message });
    }
  }

  if (server) {
    server.close(() => {
      structuredLog('info', 'HTTP server closed');
      pool.end().then(() => {
        structuredLog('info', 'Database pool closed');
        process.exit(0);
      });
    });
    setTimeout(() => process.exit(1), FIB[8] * 1000);
  } else {
    await pool.end();
    process.exit(0);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

addShutdownHandler('cleanup-timer', async () => {
  if (cleanupTimer) clearInterval(cleanupTimer);
});

addShutdownHandler('mark-executing-sagas', async () => {
  await pool.query(
    `UPDATE sagas SET status = 'interrupted', updated_at = NOW()
     WHERE status = 'executing'`
  ).catch(() => {});
});

// ─── Server Startup ──────────────────────────────────────────────────────────
async function start() {
  try {
    await initSchema();
    cleanupTimer = setInterval(cleanupExpiredSagas, CLEANUP_INTERVAL_MS);

    server = app.listen(PORT, () => {
      structuredLog('info', `${SERVICE_NAME} listening`, {
        port: PORT,
        domain: DOMAIN,
        phi: PHI,
        stepTimeoutMs: STEP_TIMEOUT_MS,
        maxRetries: MAX_RETRIES_PER_STEP,
        sagaTtlMs: SAGA_TTL_MS,
        maxConcurrent: MAX_CONCURRENT_SAGAS,
        vectorDim: VECTOR_DIM,
      });
    });
  } catch (err) {
    structuredLog('error', 'Failed to start', { error: err.message });
    process.exit(1);
  }
}

start();
