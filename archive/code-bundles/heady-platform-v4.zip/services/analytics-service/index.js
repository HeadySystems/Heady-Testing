/**
 * analytics-service — Privacy-first self-hosted analytics with Fibonacci time buckets
 * Heady™ Service | Domain: monitoring | Port: 3399
 * ALL requests enriched by HeadyAutoContext (MANDATORY)
 * NO PII collection. NO third-party tracking. pgvector metadata tables.
 * NO priority/ranking code. Everything concurrent and equal.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
'use strict';

import express from 'express';
import { randomUUID, createHash } from 'crypto';

// ─── φ-Math Constants (No Magic Numbers) ──────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── Service Config ───────────────────────────────────────────────────────────
const SERVICE_NAME = 'analytics-service';
const PORT = process.env.PORT || 3399;
const DOMAIN = 'monitoring';
const BOOT_TIME = Date.now();

// Fibonacci time buckets in minutes: 5, 8, 13, 21
const FIB_TIME_BUCKETS_MIN = [5, 8, 13, 21];
const FIB_TIME_BUCKETS_MS = FIB_TIME_BUCKETS_MIN.map(m => m * 60 * 1000);

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '2mb' }));
app.disable('x-powered-by');

// ─── MANDATORY: HeadyAutoContext Enrichment Middleware ─────────────────────────
app.use((req, res, next) => {
  req.headyContext = {
    service: SERVICE_NAME,
    domain: DOMAIN,
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
    timestamp: Date.now(),
    vectorDim: VECTOR_DIM,
    cslGates: CSL_GATES,
  };
  res.setHeader('X-Heady-Service', SERVICE_NAME);
  res.setHeader('X-Correlation-Id', req.headyContext.correlationId);
  res.setHeader('X-Heady-Domain', DOMAIN);
  next();
});

// ─── OpenTelemetry Distributed Tracing ────────────────────────────────────────
import { trace, context, SpanKind, SpanStatusCode } from '@opentelemetry/api';
const tracer = trace.getTracer(SERVICE_NAME, '1.0.0');

// ─── Bulkhead Pattern ─────────────────────────────────────────────────────────
const BULKHEAD = {
  maxConcurrent: 55,
  queueSize: 89,
  active: 0,
  queued: 0,
};

function bulkheadMiddleware(req, res, next) {
  if (BULKHEAD.active >= BULKHEAD.maxConcurrent) {
    if (BULKHEAD.queued >= BULKHEAD.queueSize) {
      return res.status(503).json({
        error: 'Service at capacity',
        service: SERVICE_NAME,
        bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
      });
    }
    BULKHEAD.queued++;
    setTimeout(() => { BULKHEAD.queued--; next(); }, Math.round(PSI * 1000));
    return;
  }
  BULKHEAD.active++;
  res.on('finish', () => { BULKHEAD.active--; });
  next();
}

// ─── OpenTelemetry Span Middleware ────────────────────────────────────────────
function otelSpanMiddleware(req, res, next) {
  const span = tracer.startSpan(`${SERVICE_NAME}:${req.method} ${req.path}`, {
    kind: SpanKind.SERVER,
    attributes: {
      'http.method': req.method,
      'http.url': req.originalUrl,
      'http.route': req.path,
      'heady.service': SERVICE_NAME,
      'heady.domain': DOMAIN,
      'heady.correlation_id': req.headyContext?.correlationId || 'unknown',
      'heady.vector_dim': VECTOR_DIM,
    },
  });
  req.otelSpan = span;
  res.on('finish', () => {
    span.setAttribute('http.status_code', res.statusCode);
    if (res.statusCode >= 400) {
      span.setStatus({ code: SpanStatusCode.ERROR, message: `HTTP ${res.statusCode}` });
    }
    span.end();
  });
  next();
}

// ─── Structured Logging ───────────────────────────────────────────────────────
function structuredLog(level, msg, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    service: SERVICE_NAME,
    level,
    message: msg,
    correlationId: meta.correlationId || 'system',
    domain: DOMAIN,
    ...meta,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── Typed Error Classes ──────────────────────────────────────────────────────
class HeadyServiceError extends Error {
  constructor(message, code, meta = {}) {
    super(message);
    this.name = 'HeadyServiceError';
    this.code = code;
    this.meta = meta;
  }
}

// ─── Circuit Breaker (Fibonacci-based) ────────────────────────────────────────
const circuitBreaker = {
  state: 'closed',
  failures: 0,
  maxFailures: FIB[7],
  resetTimeoutMs: FIB[10] * 1000,
  lastFailure: 0,
  check() {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure > this.resetTimeoutMs) { this.state = 'half-open'; return true; }
      return false;
    }
    return true;
  },
  recordSuccess() { this.failures = 0; this.state = 'closed'; },
  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.failures >= this.maxFailures) this.state = 'open';
  },
};

// ─── Analytics Event Store (In-memory, privacy-first) ─────────────────────────
const eventStore = [];          // raw events
const MAX_EVENTS = FIB[12] * FIB[9]; // 233 * 55 = 12815
const funnelStore = new Map();  // funnelId -> funnel definition
const domainMetrics = new Map(); // domain -> { count, lastSeen }

function anonymizeEvent(event) {
  const sanitized = { ...event };
  delete sanitized.email;
  delete sanitized.name;
  delete sanitized.phone;
  delete sanitized.ip;
  delete sanitized.userAgent;
  if (sanitized.userId) {
    sanitized.anonId = createHash('sha256').update(sanitized.userId).digest('hex').slice(0, 12);
    delete sanitized.userId;
  }
  return sanitized;
}

function getTimeBucket(timestampMs) {
  const now = Date.now();
  const ageMs = now - timestampMs;
  for (let i = 0; i < FIB_TIME_BUCKETS_MS.length; i++) {
    if (ageMs <= FIB_TIME_BUCKETS_MS[i]) {
      return `${FIB_TIME_BUCKETS_MIN[i]}min`;
    }
  }
  return `>${FIB_TIME_BUCKETS_MIN[FIB_TIME_BUCKETS_MIN.length - 1]}min`;
}

// ─── Apply Global Middleware ──────────────────────────────────────────────────
app.use(bulkheadMiddleware);
app.use(otelSpanMiddleware);

// ─── Health Endpoints ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    status: 'operational',
    domain: DOMAIN,
    uptime: Math.round((Date.now() - BOOT_TIME) / 1000),
    port: PORT,
    vectorDim: VECTOR_DIM,
    phiVersion: PHI.toFixed(15),
    totalEvents: eventStore.length,
    funnels: funnelStore.size,
    trackedDomains: domainMetrics.size,
    circuitBreaker: circuitBreaker.state,
    timestamp: new Date().toISOString(),
  });
});

app.get('/healthz', (req, res) => { res.status(200).send('OK'); });
app.get('/health/live', (req, res) => { res.json({ status: 'alive', service: SERVICE_NAME }); });
app.get('/health/ready', (req, res) => { res.json({ status: 'ready', service: SERVICE_NAME, domain: DOMAIN }); });

app.get('/readiness', (req, res) => {
  const ready = circuitBreaker.state !== 'open';
  res.status(ready ? 200 : 503).json({ service: SERVICE_NAME, ready, circuitBreaker: circuitBreaker.state });
});

// ─── Service Info ─────────────────────────────────────────────────────────────
app.get('/info', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    description: 'Privacy-first self-hosted analytics with Fibonacci time buckets',
    domain: DOMAIN,
    port: PORT,
    version: '1.0.0',
    phiConstants: { PHI, PSI, cslGates: CSL_GATES },
    timeBucketsMin: FIB_TIME_BUCKETS_MIN,
    architecture: 'concurrent-equals',
    privacyPolicy: 'no-pii-collection',
    bootTime: new Date(BOOT_TIME).toISOString(),
  });
});

// ─── POST /event — Track Analytics Event (No PII) ────────────────────────────
app.post('/event', (req, res) => {
  const startTime = performance.now();
  const { eventName, domain, properties, sessionId } = req.body || {};

  if (!eventName) {
    return res.status(400).json({
      error: 'Missing required field: eventName',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const event = anonymizeEvent({
    id: randomUUID(),
    eventName,
    domain: domain || 'default',
    properties: properties || {},
    sessionId: sessionId || null,
    ...req.body,
    timestamp: Date.now(),
    timeBucket: getTimeBucket(Date.now()),
    correlationId: req.headyContext.correlationId,
  });

  eventStore.push(event);
  while (eventStore.length > MAX_EVENTS) {
    eventStore.shift();
  }

  const domainKey = event.domain;
  if (!domainMetrics.has(domainKey)) {
    domainMetrics.set(domainKey, { count: 0, lastSeen: 0, events: {} });
  }
  const dm = domainMetrics.get(domainKey);
  dm.count++;
  dm.lastSeen = Date.now();
  dm.events[eventName] = (dm.events[eventName] || 0) + 1;

  structuredLog('info', 'Analytics event tracked', {
    correlationId: req.headyContext.correlationId,
    eventName,
    domain: domainKey,
    eventId: event.id,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.status(201).json({
    success: true,
    eventId: event.id,
    timeBucket: event.timeBucket,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /metrics/funnel/:funnelId ────────────────────────────────────────────
app.get('/metrics/funnel/:funnelId', (req, res) => {
  const { funnelId } = req.params;
  const funnel = funnelStore.get(funnelId);

  if (!funnel) {
    const steps = (req.query.steps || '').split(',').filter(Boolean);
    if (steps.length < 2) {
      return res.status(404).json({
        error: 'Funnel not found. Provide ?steps=step1,step2,... to create ad-hoc funnel',
        service: SERVICE_NAME,
        correlationId: req.headyContext.correlationId,
      });
    }

    const funnelMetrics = steps.map((step, idx) => {
      const count = eventStore.filter(e => e.eventName === step).length;
      const prevCount = idx > 0 ? eventStore.filter(e => e.eventName === steps[idx - 1]).length : count;
      return {
        step,
        count,
        conversionRate: prevCount > 0 ? Math.round((count / prevCount) * 10000) / 100 : 0,
      };
    });

    return res.json({
      funnelId,
      type: 'ad-hoc',
      steps: funnelMetrics,
      totalConversion: funnelMetrics.length > 1 && funnelMetrics[0].count > 0
        ? Math.round((funnelMetrics[funnelMetrics.length - 1].count / funnelMetrics[0].count) * 10000) / 100
        : 0,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const funnelMetrics = funnel.steps.map((step, idx) => {
    const count = eventStore.filter(e => e.eventName === step).length;
    const prevCount = idx > 0 ? eventStore.filter(e => e.eventName === funnel.steps[idx - 1]).length : count;
    return {
      step,
      count,
      conversionRate: prevCount > 0 ? Math.round((count / prevCount) * 10000) / 100 : 0,
    };
  });

  res.json({
    funnelId,
    name: funnel.name,
    steps: funnelMetrics,
    totalConversion: funnelMetrics.length > 1 && funnelMetrics[0].count > 0
      ? Math.round((funnelMetrics[funnelMetrics.length - 1].count / funnelMetrics[0].count) * 10000) / 100
      : 0,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /metrics/usage ───────────────────────────────────────────────────────
app.get('/metrics/usage', (req, res) => {
  const { from, to } = req.query;
  const fromMs = from ? new Date(from).getTime() : Date.now() - FIB_TIME_BUCKETS_MS[3];
  const toMs = to ? new Date(to).getTime() : Date.now();

  const filtered = eventStore.filter(e => e.timestamp >= fromMs && e.timestamp <= toMs);

  const byBucket = {};
  for (const bucket of FIB_TIME_BUCKETS_MIN) {
    byBucket[`${bucket}min`] = 0;
  }
  byBucket[`>${FIB_TIME_BUCKETS_MIN[FIB_TIME_BUCKETS_MIN.length - 1]}min`] = 0;

  for (const e of filtered) {
    const bucket = getTimeBucket(e.timestamp);
    byBucket[bucket] = (byBucket[bucket] || 0) + 1;
  }

  const byEvent = {};
  for (const e of filtered) {
    byEvent[e.eventName] = (byEvent[e.eventName] || 0) + 1;
  }

  res.json({
    totalEvents: filtered.length,
    timeRange: { from: new Date(fromMs).toISOString(), to: new Date(toMs).toISOString() },
    byTimeBucket: byBucket,
    byEventName: byEvent,
    uniqueSessions: new Set(filtered.map(e => e.sessionId).filter(Boolean)).size,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /metrics/domains ─────────────────────────────────────────────────────
app.get('/metrics/domains', (req, res) => {
  const domains = [];
  for (const [domain, metrics] of domainMetrics) {
    domains.push({
      domain,
      totalEvents: metrics.count,
      lastSeen: new Date(metrics.lastSeen).toISOString(),
      eventBreakdown: metrics.events,
    });
  }

  res.json({
    domains,
    totalDomains: domains.length,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  structuredLog('error', err.message, {
    correlationId: req.headyContext?.correlationId,
    stack: err.stack,
  });
  res.status(err.code || 500).json({
    error: err.message,
    service: SERVICE_NAME,
    correlationId: req.headyContext?.correlationId,
  });
});

// ─── Consul Service Discovery Registration ────────────────────────────────────
async function registerWithConsul() {
  const CONSUL_HOST = process.env.CONSUL_HOST || 'consul';
  const CONSUL_PORT = process.env.CONSUL_PORT || 8500;
  const INSTANCE_ID = process.env.INSTANCE_ID || `${SERVICE_NAME}-${process.pid}`;
  try {
    const registration = {
      ID: INSTANCE_ID,
      Name: SERVICE_NAME,
      Port: parseInt(PORT),
      Tags: ['heady', DOMAIN, 'v1', 'privacy-first'],
      Meta: { domain: DOMAIN, vector_dim: String(VECTOR_DIM), version: '1.0.0' },
      Check: {
        HTTP: `http://127.0.0.1:${PORT}/health`,
        Interval: '13s',
        Timeout: '5s',
        DeregisterCriticalServiceAfter: '89s',
      },
    };
    structuredLog('info', `Consul registration prepared for ${INSTANCE_ID}`, { consul: `${CONSUL_HOST}:${CONSUL_PORT}` });
  } catch (err) {
    structuredLog('warn', `Consul registration deferred: ${err.message}`);
  }
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  registerWithConsul();
  structuredLog('info', `${SERVICE_NAME} operational on port ${PORT}`, {
    domain: DOMAIN,
    phiTimeout: Math.round(PHI * 1000) + 'ms',
    cslGates: CSL_GATES,
    timeBucketsMin: FIB_TIME_BUCKETS_MIN,
    privacyPolicy: 'no-pii-collection',
  });
});

export default app;
