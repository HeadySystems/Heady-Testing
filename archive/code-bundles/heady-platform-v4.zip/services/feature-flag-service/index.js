/**
 * feature-flag-service — φ-scaled feature rollout management with CSL confidence gating
 * Heady™ Service | Domain: platform | Port: 3406
 * ALL requests enriched by HeadyAutoContext (MANDATORY)
 * NO priority/ranking code. Everything concurrent and equal.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
'use strict';

import express from 'express';
import { randomUUID } from 'crypto';
import pg from 'pg';

// ─── φ-Math Constants (No Magic Numbers) ──────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── Service Config ───────────────────────────────────────────────────────────
const SERVICE_NAME = 'feature-flag-service';
const PORT = process.env.PORT || 3406;
const DOMAIN = 'platform';
const BOOT_TIME = Date.now();

// ─── Feature Flag Constants (φ-derived) ──────────────────────────────────────
const ROLLOUT_TIERS = Object.freeze([
  { name: 'canary', pct: PSI2 * 100 },       // ≈ 6.18% — exploration gate (ψ² × 100)
  { name: 'include', pct: PSI2 * 100 * PHI }, // ≈ 38.2% — include gate (PSI2 as fraction)
  { name: 'boost', pct: PSI * 100 },          // ≈ 61.8% — boost gate
  { name: 'full', pct: 100 },                 // 100% — full rollout
]);
const EVALUATE_CACHE_MAX_AGE = FIB[6];         // 13 seconds
const FLAG_NAME_MAX_LEN = FIB[11];              // 144 characters
const DEFAULT_CSL_GATE = CSL_GATES.include;     // ≈ 0.382
const POOL_SIZE = FIB[7];                       // 21 connections
const IDLE_TIMEOUT_MS = FIB[10] * 1000;         // 89s
const CONNECTION_TIMEOUT_MS = FIB[8] * 1000;    // 34s

// ─── Structured Logging ──────────────────────────────────────────────────────
function structuredLog(level, msg, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    service: SERVICE_NAME,
    level,
    message: msg,
    correlationId: meta.correlationId || 'system',
    domain: DOMAIN,
    ...meta,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── PostgreSQL Connection Pool ──────────────────────────────────────────────
const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://heady:heady@localhost:5432/heady',
  max: POOL_SIZE,
  idleTimeoutMillis: IDLE_TIMEOUT_MS,
  connectionTimeoutMillis: CONNECTION_TIMEOUT_MS,
});

pool.on('error', (err) => {
  structuredLog('error', 'Unexpected pool error', { error: err.message });
});

// ─── Schema Initialization ───────────────────────────────────────────────────
async function initSchema() {
  const client = await pool.connect();
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS feature_flags (
        flag_name VARCHAR(144) PRIMARY KEY,
        description TEXT NOT NULL DEFAULT '',
        rollout_pct NUMERIC(6,3) NOT NULL DEFAULT 0,
        rollout_tier VARCHAR(34) NOT NULL DEFAULT 'canary',
        csl_confidence_gate NUMERIC(5,4) NOT NULL DEFAULT 0.382,
        kill_switch BOOLEAN NOT NULL DEFAULT false,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_feature_flags_kill ON feature_flags(kill_switch);
    `);
    structuredLog('info', 'Schema initialized');
  } finally {
    client.release();
  }
}

// ─── Deterministic Hash (MurmurHash3-like) ──────────────────────────────────
function deterministicHash(input) {
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  h ^= h >>> FIB[5];
  h = Math.imul(h, 0x85ebca6b);
  h ^= h >>> FIB[6];
  h = Math.imul(h, 0xc2b2ae35);
  h ^= h >>> FIB[5];
  return (h >>> 0) / 0xffffffff;
}

// ─── Flag Evaluation Logic ───────────────────────────────────────────────────
function evaluateFlag(flag, userId, cslScore) {
  // Kill switch overrides everything
  if (flag.kill_switch) {
    return {
      enabled: false,
      reason: 'kill_switch_active',
      rolloutPct: parseFloat(flag.rollout_pct),
      tier: flag.rollout_tier,
    };
  }

  // CSL confidence gating
  const confidenceGate = parseFloat(flag.csl_confidence_gate);
  if (cslScore !== undefined && cslScore < confidenceGate) {
    return {
      enabled: false,
      reason: 'below_csl_confidence_gate',
      cslScore,
      requiredGate: confidenceGate,
      rolloutPct: parseFloat(flag.rollout_pct),
      tier: flag.rollout_tier,
    };
  }

  // Deterministic rollout based on user hash
  const rolloutPct = parseFloat(flag.rollout_pct);
  if (rolloutPct <= 0) {
    return {
      enabled: false,
      reason: 'rollout_at_zero',
      rolloutPct,
      tier: flag.rollout_tier,
    };
  }

  if (rolloutPct >= 100) {
    return {
      enabled: true,
      reason: 'fully_rolled_out',
      rolloutPct,
      tier: flag.rollout_tier,
    };
  }

  const hashKey = `${userId}:${flag.flag_name}`;
  const userBucket = deterministicHash(hashKey) * 100;
  const enabled = userBucket < rolloutPct;

  return {
    enabled,
    reason: enabled ? 'within_rollout_bucket' : 'outside_rollout_bucket',
    userBucket: Math.round(userBucket * 1000) / 1000,
    rolloutPct,
    tier: flag.rollout_tier,
  };
}

// ─── Determine Next Rollout Tier ─────────────────────────────────────────────
function getNextTier(currentPct) {
  const current = parseFloat(currentPct);
  for (let i = 0; i < ROLLOUT_TIERS.length; i++) {
    if (current < ROLLOUT_TIERS[i].pct - 0.01) {
      return ROLLOUT_TIERS[i];
    }
  }
  return null;
}

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '1mb' }));
app.disable('x-powered-by');

// ─── MANDATORY: HeadyAutoContext Enrichment Middleware ─────────────────────────
app.use((req, res, next) => {
  req.headyContext = {
    service: SERVICE_NAME,
    domain: DOMAIN,
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
    timestamp: Date.now(),
    vectorDim: VECTOR_DIM,
    cslGates: CSL_GATES,
  };
  res.setHeader('X-Heady-Service', SERVICE_NAME);
  res.setHeader('X-Correlation-Id', req.headyContext.correlationId);
  res.setHeader('X-Heady-Domain', DOMAIN);
  next();
});

// ─── Bulkhead Pattern ────────────────────────────────────────────────────────
const BULKHEAD = {
  maxConcurrent: FIB[9],   // 55
  queueSize: FIB[10],      // 89
  active: 0,
  queued: 0,
};

function bulkheadMiddleware(req, res, next) {
  if (BULKHEAD.active >= BULKHEAD.maxConcurrent) {
    if (BULKHEAD.queued >= BULKHEAD.queueSize) {
      return res.status(503).json({
        error: 'Service at capacity',
        service: SERVICE_NAME,
        bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
      });
    }
    BULKHEAD.queued++;
    setTimeout(() => {
      BULKHEAD.queued--;
      BULKHEAD.active++;
      res.on('finish', () => { BULKHEAD.active--; });
      next();
    }, Math.round(PSI * 1000));
    return;
  }
  BULKHEAD.active++;
  res.on('finish', () => { BULKHEAD.active--; });
  next();
}

app.use('/flags', bulkheadMiddleware);

// ─── Circuit Breaker ─────────────────────────────────────────────────────────
const circuitBreaker = {
  state: 'closed',
  failures: 0,
  maxFailures: FIB[7],                  // 21
  resetTimeoutMs: FIB[10] * 1000,       // 89s
  lastFailure: 0,

  check() {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure > this.resetTimeoutMs) {
        this.state = 'half-open';
        return true;
      }
      return false;
    }
    return true;
  },

  recordSuccess() {
    this.failures = 0;
    this.state = 'closed';
  },

  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.failures >= this.maxFailures) {
      this.state = 'open';
      structuredLog('warn', 'Circuit breaker opened', { failures: this.failures });
    }
  },
};

// ─── Health Endpoints ────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: SERVICE_NAME,
    domain: DOMAIN,
    uptime: Date.now() - BOOT_TIME,
    circuitBreaker: circuitBreaker.state,
    bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
    rolloutTiers: ROLLOUT_TIERS,
    phi: PHI,
    vectorDim: VECTOR_DIM,
  });
});

app.get('/ready', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ready', service: SERVICE_NAME });
  } catch (err) {
    res.status(503).json({ status: 'not_ready', error: err.message });
  }
});

app.get('/healthz', (req, res) => {
  res.json({ status: 'ok', service: SERVICE_NAME });
});

// ─── POST /flags — Create Flag ───────────────────────────────────────────────
app.post('/flags', async (req, res) => {
  const { name, description, rolloutPct, cslConfidenceGate } = req.body;
  const correlationId = req.headyContext.correlationId;

  if (!name || typeof name !== 'string') {
    return res.status(400).json({
      error: 'Missing or invalid flag name',
      service: SERVICE_NAME,
      correlationId,
    });
  }

  if (name.length > FLAG_NAME_MAX_LEN) {
    return res.status(400).json({
      error: `Flag name exceeds ${FLAG_NAME_MAX_LEN} characters`,
      service: SERVICE_NAME,
      correlationId,
    });
  }

  if (!circuitBreaker.check()) {
    return res.status(503).json({
      error: 'Circuit breaker is open',
      service: SERVICE_NAME,
      correlationId,
    });
  }

  const pct = rolloutPct !== undefined ? parseFloat(rolloutPct) : ROLLOUT_TIERS[0].pct;
  const gate = cslConfidenceGate !== undefined ? parseFloat(cslConfidenceGate) : DEFAULT_CSL_GATE;
  const tier = ROLLOUT_TIERS.find((t) => pct <= t.pct + 0.01) || ROLLOUT_TIERS[ROLLOUT_TIERS.length - 1];

  try {
    const result = await pool.query(
      `INSERT INTO feature_flags (flag_name, description, rollout_pct, rollout_tier, csl_confidence_gate)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING flag_name, description, rollout_pct, rollout_tier, csl_confidence_gate, kill_switch, created_at`,
      [name, description || '', pct, tier.name, gate]
    );

    circuitBreaker.recordSuccess();
    structuredLog('info', 'Flag created', { correlationId, flagName: name, rolloutPct: pct, tier: tier.name });

    res.status(201).json({
      flag: result.rows[0],
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    circuitBreaker.recordFailure();
    if (err.code === '23505') {
      return res.status(409).json({
        error: `Flag already exists: ${name}`,
        service: SERVICE_NAME,
        correlationId,
      });
    }
    structuredLog('error', 'Failed to create flag', { correlationId, error: err.message });
    res.status(500).json({ error: 'Internal error', service: SERVICE_NAME, correlationId });
  }
});

// ─── GET /flags — List All Flags ─────────────────────────────────────────────
app.get('/flags', async (req, res) => {
  const correlationId = req.headyContext.correlationId;

  try {
    const result = await pool.query(
      `SELECT flag_name, description, rollout_pct, rollout_tier, csl_confidence_gate,
              kill_switch, created_at, updated_at
       FROM feature_flags ORDER BY created_at`
    );

    circuitBreaker.recordSuccess();
    res.json({
      flags: result.rows,
      count: result.rowCount,
      rolloutTiers: ROLLOUT_TIERS,
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    circuitBreaker.recordFailure();
    structuredLog('error', 'Failed to list flags', { correlationId, error: err.message });
    res.status(500).json({ error: 'Internal error', service: SERVICE_NAME, correlationId });
  }
});

// ─── GET /flags/:name — Get Flag Details ─────────────────────────────────────
app.get('/flags/:name', async (req, res) => {
  const { name } = req.params;
  const correlationId = req.headyContext.correlationId;

  if (name === 'evaluate' || name === 'advance') return;

  try {
    const result = await pool.query(
      `SELECT flag_name, description, rollout_pct, rollout_tier, csl_confidence_gate,
              kill_switch, created_at, updated_at
       FROM feature_flags WHERE flag_name = $1`,
      [name]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: `Flag not found: ${name}`,
        service: SERVICE_NAME,
        correlationId,
      });
    }

    circuitBreaker.recordSuccess();
    const flag = result.rows[0];
    const nextTier = getNextTier(flag.rollout_pct);

    res.json({
      flag,
      nextTier: nextTier ? { name: nextTier.name, pct: Math.round(nextTier.pct * 1000) / 1000 } : null,
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    circuitBreaker.recordFailure();
    structuredLog('error', 'Failed to get flag', { correlationId, error: err.message });
    res.status(500).json({ error: 'Internal error', service: SERVICE_NAME, correlationId });
  }
});

// ─── PUT /flags/:name — Update Flag ──────────────────────────────────────────
app.put('/flags/:name', async (req, res) => {
  const { name } = req.params;
  const correlationId = req.headyContext.correlationId;
  const { description, rolloutPct, cslConfidenceGate, killSwitch } = req.body;

  if (!circuitBreaker.check()) {
    return res.status(503).json({
      error: 'Circuit breaker is open',
      service: SERVICE_NAME,
      correlationId,
    });
  }

  try {
    const existing = await pool.query(
      `SELECT flag_name FROM feature_flags WHERE flag_name = $1`,
      [name]
    );

    if (existing.rows.length === 0) {
      return res.status(404).json({
        error: `Flag not found: ${name}`,
        service: SERVICE_NAME,
        correlationId,
      });
    }

    const updates = [];
    const values = [];
    let paramIndex = 1;

    if (description !== undefined) {
      updates.push(`description = $${paramIndex++}`);
      values.push(description);
    }
    if (rolloutPct !== undefined) {
      const pct = parseFloat(rolloutPct);
      const tier = ROLLOUT_TIERS.find((t) => pct <= t.pct + 0.01) || ROLLOUT_TIERS[ROLLOUT_TIERS.length - 1];
      updates.push(`rollout_pct = $${paramIndex++}`);
      values.push(pct);
      updates.push(`rollout_tier = $${paramIndex++}`);
      values.push(tier.name);
    }
    if (cslConfidenceGate !== undefined) {
      updates.push(`csl_confidence_gate = $${paramIndex++}`);
      values.push(parseFloat(cslConfidenceGate));
    }
    if (killSwitch !== undefined) {
      updates.push(`kill_switch = $${paramIndex++}`);
      values.push(Boolean(killSwitch));
    }

    if (updates.length === 0) {
      return res.status(400).json({
        error: 'No fields to update',
        service: SERVICE_NAME,
        correlationId,
      });
    }

    updates.push(`updated_at = NOW()`);
    values.push(name);

    const result = await pool.query(
      `UPDATE feature_flags SET ${updates.join(', ')} WHERE flag_name = $${paramIndex}
       RETURNING flag_name, description, rollout_pct, rollout_tier, csl_confidence_gate,
                 kill_switch, created_at, updated_at`,
      values
    );

    circuitBreaker.recordSuccess();
    structuredLog('info', 'Flag updated', { correlationId, flagName: name });

    res.json({
      flag: result.rows[0],
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    circuitBreaker.recordFailure();
    structuredLog('error', 'Failed to update flag', { correlationId, error: err.message });
    res.status(500).json({ error: 'Internal error', service: SERVICE_NAME, correlationId });
  }
});

// ─── GET /flags/:name/evaluate — Evaluate Flag for User ──────────────────────
app.get('/flags/:name/evaluate', async (req, res) => {
  const { name } = req.params;
  const { user_id, csl_score } = req.query;
  const correlationId = req.headyContext.correlationId;

  if (!user_id) {
    return res.status(400).json({
      error: 'Missing user_id query parameter',
      service: SERVICE_NAME,
      correlationId,
    });
  }

  try {
    const result = await pool.query(
      `SELECT flag_name, description, rollout_pct, rollout_tier, csl_confidence_gate,
              kill_switch FROM feature_flags WHERE flag_name = $1`,
      [name]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: `Flag not found: ${name}`,
        service: SERVICE_NAME,
        correlationId,
      });
    }

    const flag = result.rows[0];
    const cslScore = csl_score !== undefined ? parseFloat(csl_score) : undefined;
    const evaluation = evaluateFlag(flag, user_id, cslScore);

    circuitBreaker.recordSuccess();

    // Edge-cacheable response
    res.setHeader('Cache-Control', `public, max-age=${EVALUATE_CACHE_MAX_AGE}`);
    res.setHeader('Vary', 'X-Correlation-Id');

    res.json({
      flagName: name,
      userId: user_id,
      ...evaluation,
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    circuitBreaker.recordFailure();
    structuredLog('error', 'Failed to evaluate flag', { correlationId, error: err.message });
    res.status(500).json({ error: 'Internal error', service: SERVICE_NAME, correlationId });
  }
});

// ─── POST /flags/:name/advance — Advance to Next φ-Tier ─────────────────────
app.post('/flags/:name/advance', async (req, res) => {
  const { name } = req.params;
  const correlationId = req.headyContext.correlationId;

  if (!circuitBreaker.check()) {
    return res.status(503).json({
      error: 'Circuit breaker is open',
      service: SERVICE_NAME,
      correlationId,
    });
  }

  try {
    const result = await pool.query(
      `SELECT flag_name, rollout_pct, rollout_tier, kill_switch
       FROM feature_flags WHERE flag_name = $1`,
      [name]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({
        error: `Flag not found: ${name}`,
        service: SERVICE_NAME,
        correlationId,
      });
    }

    const flag = result.rows[0];

    if (flag.kill_switch) {
      return res.status(409).json({
        error: 'Cannot advance flag with active kill switch',
        flagName: name,
        service: SERVICE_NAME,
        correlationId,
      });
    }

    const nextTier = getNextTier(flag.rollout_pct);

    if (!nextTier) {
      return res.status(409).json({
        error: 'Flag is already at full rollout',
        flagName: name,
        currentPct: parseFloat(flag.rollout_pct),
        service: SERVICE_NAME,
        correlationId,
      });
    }

    const updated = await pool.query(
      `UPDATE feature_flags SET rollout_pct = $1, rollout_tier = $2, updated_at = NOW()
       WHERE flag_name = $3
       RETURNING flag_name, description, rollout_pct, rollout_tier, csl_confidence_gate,
                 kill_switch, created_at, updated_at`,
      [nextTier.pct, nextTier.name, name]
    );

    circuitBreaker.recordSuccess();
    structuredLog('info', 'Flag advanced', {
      correlationId,
      flagName: name,
      previousPct: parseFloat(flag.rollout_pct),
      newPct: nextTier.pct,
      tier: nextTier.name,
    });

    const nextNextTier = getNextTier(nextTier.pct);

    res.json({
      flag: updated.rows[0],
      previousTier: flag.rollout_tier,
      previousPct: parseFloat(flag.rollout_pct),
      nextTier: nextNextTier ? { name: nextNextTier.name, pct: Math.round(nextNextTier.pct * 1000) / 1000 } : null,
      service: SERVICE_NAME,
      correlationId,
    });
  } catch (err) {
    circuitBreaker.recordFailure();
    structuredLog('error', 'Failed to advance flag', { correlationId, error: err.message });
    res.status(500).json({ error: 'Internal error', service: SERVICE_NAME, correlationId });
  }
});

// ─── Graceful Shutdown ───────────────────────────────────────────────────────
let server = null;

async function gracefulShutdown(signal) {
  structuredLog('info', `Shutdown initiated: ${signal}`);

  if (server) {
    server.close(() => {
      structuredLog('info', 'HTTP server closed');
      pool.end().then(() => {
        structuredLog('info', 'Database pool closed');
        process.exit(0);
      });
    });
    setTimeout(() => process.exit(1), FIB[8] * 1000);
  } else {
    await pool.end();
    process.exit(0);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// ─── Server Startup ──────────────────────────────────────────────────────────
async function start() {
  try {
    await initSchema();

    server = app.listen(PORT, () => {
      structuredLog('info', `${SERVICE_NAME} listening`, {
        port: PORT,
        domain: DOMAIN,
        phi: PHI,
        rolloutTiers: ROLLOUT_TIERS.map((t) => `${t.name}=${Math.round(t.pct * 1000) / 1000}%`),
        evaluateCacheMaxAge: EVALUATE_CACHE_MAX_AGE,
        cslDefaultGate: DEFAULT_CSL_GATE,
        vectorDim: VECTOR_DIM,
      });
    });
  } catch (err) {
    structuredLog('error', 'Failed to start', { error: err.message });
    process.exit(1);
  }
}

start();
