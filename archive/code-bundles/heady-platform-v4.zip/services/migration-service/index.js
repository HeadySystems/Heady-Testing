/**
 * migration-service — Database migration runner with rollback support
 * Heady™ Service | Domain: data | Port: 3403
 * ALL requests enriched by HeadyAutoContext (MANDATORY)
 * Tracks applied migrations in a migrations table. Includes pgvector schema init.
 * NO priority/ranking code. Everything concurrent and equal.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
'use strict';

import express from 'express';
import { randomUUID } from 'crypto';

// ─── φ-Math Constants (No Magic Numbers) ──────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── Service Config ───────────────────────────────────────────────────────────
const SERVICE_NAME = 'migration-service';
const PORT = process.env.PORT || 3403;
const DOMAIN = 'data';
const BOOT_TIME = Date.now();
const PGHOST = process.env.PGHOST || 'postgres';
const PGPORT = process.env.PGPORT || 5432;
const PGDATABASE = process.env.PGDATABASE || 'heady_vector';
const PGUSER = process.env.PGUSER || 'heady';

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '2mb' }));
app.disable('x-powered-by');

// ─── MANDATORY: HeadyAutoContext Enrichment Middleware ─────────────────────────
app.use((req, res, next) => {
  req.headyContext = {
    service: SERVICE_NAME,
    domain: DOMAIN,
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
    timestamp: Date.now(),
    vectorDim: VECTOR_DIM,
    cslGates: CSL_GATES,
  };
  res.setHeader('X-Heady-Service', SERVICE_NAME);
  res.setHeader('X-Correlation-Id', req.headyContext.correlationId);
  res.setHeader('X-Heady-Domain', DOMAIN);
  next();
});

// ─── OpenTelemetry Distributed Tracing ────────────────────────────────────────
import { trace, context, SpanKind, SpanStatusCode } from '@opentelemetry/api';
const tracer = trace.getTracer(SERVICE_NAME, '1.0.0');

// ─── Bulkhead Pattern ─────────────────────────────────────────────────────────
const BULKHEAD = {
  maxConcurrent: 55,
  queueSize: 89,
  active: 0,
  queued: 0,
};

function bulkheadMiddleware(req, res, next) {
  if (BULKHEAD.active >= BULKHEAD.maxConcurrent) {
    if (BULKHEAD.queued >= BULKHEAD.queueSize) {
      return res.status(503).json({
        error: 'Service at capacity',
        service: SERVICE_NAME,
        bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
      });
    }
    BULKHEAD.queued++;
    setTimeout(() => { BULKHEAD.queued--; next(); }, Math.round(PSI * 1000));
    return;
  }
  BULKHEAD.active++;
  res.on('finish', () => { BULKHEAD.active--; });
  next();
}

// ─── OpenTelemetry Span Middleware ────────────────────────────────────────────
function otelSpanMiddleware(req, res, next) {
  const span = tracer.startSpan(`${SERVICE_NAME}:${req.method} ${req.path}`, {
    kind: SpanKind.SERVER,
    attributes: {
      'http.method': req.method,
      'http.url': req.originalUrl,
      'http.route': req.path,
      'heady.service': SERVICE_NAME,
      'heady.domain': DOMAIN,
      'heady.correlation_id': req.headyContext?.correlationId || 'unknown',
      'heady.vector_dim': VECTOR_DIM,
    },
  });
  req.otelSpan = span;
  res.on('finish', () => {
    span.setAttribute('http.status_code', res.statusCode);
    if (res.statusCode >= 400) {
      span.setStatus({ code: SpanStatusCode.ERROR, message: `HTTP ${res.statusCode}` });
    }
    span.end();
  });
  next();
}

// ─── Structured Logging ───────────────────────────────────────────────────────
function structuredLog(level, msg, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    service: SERVICE_NAME,
    level,
    message: msg,
    correlationId: meta.correlationId || 'system',
    domain: DOMAIN,
    ...meta,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── Typed Error Classes ──────────────────────────────────────────────────────
class HeadyServiceError extends Error {
  constructor(message, code, meta = {}) {
    super(message);
    this.name = 'HeadyServiceError';
    this.code = code;
    this.meta = meta;
  }
}

// ─── Circuit Breaker (Fibonacci-based) ────────────────────────────────────────
const circuitBreaker = {
  state: 'closed',
  failures: 0,
  maxFailures: FIB[7],
  resetTimeoutMs: FIB[10] * 1000,
  lastFailure: 0,
  check() {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure > this.resetTimeoutMs) { this.state = 'half-open'; return true; }
      return false;
    }
    return true;
  },
  recordSuccess() { this.failures = 0; this.state = 'closed'; },
  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.failures >= this.maxFailures) this.state = 'open';
  },
};

// ─── Migration Definitions ────────────────────────────────────────────────────
const MIGRATIONS = [
  {
    id: '001',
    name: '001_create_migrations_table',
    description: 'Create migrations tracking table',
    up: `
      CREATE TABLE IF NOT EXISTS heady_migrations (
        id SERIAL PRIMARY KEY,
        migration_id VARCHAR(64) NOT NULL UNIQUE,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        rolled_back_at TIMESTAMPTZ,
        checksum VARCHAR(64),
        execution_time_ms INTEGER,
        service VARCHAR(128) DEFAULT 'migration-service'
      );
      CREATE INDEX IF NOT EXISTS idx_migrations_id ON heady_migrations(migration_id);
    `,
    down: `DROP TABLE IF EXISTS heady_migrations;`,
  },
  {
    id: '002',
    name: '002_create_pgvector_extension',
    description: 'Enable pgvector extension for vector similarity search',
    up: `CREATE EXTENSION IF NOT EXISTS vector;`,
    down: `DROP EXTENSION IF EXISTS vector;`,
  },
  {
    id: '003',
    name: '003_create_heady_vectors_table',
    description: 'Create heady_vectors table with HNSW index at 384 dims',
    up: `
      CREATE TABLE IF NOT EXISTS heady_vectors (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        content TEXT NOT NULL,
        embedding vector(${VECTOR_DIM}) NOT NULL,
        metadata JSONB DEFAULT '{}',
        domain VARCHAR(128),
        source_service VARCHAR(128),
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_heady_vectors_embedding_hnsw
        ON heady_vectors USING hnsw (embedding vector_cosine_ops)
        WITH (m = 16, ef_construction = 200);
      CREATE INDEX IF NOT EXISTS idx_heady_vectors_domain ON heady_vectors(domain);
      CREATE INDEX IF NOT EXISTS idx_heady_vectors_metadata ON heady_vectors USING gin(metadata);
    `,
    down: `DROP TABLE IF EXISTS heady_vectors;`,
  },
  {
    id: '004',
    name: '004_create_heady_sessions_table',
    description: 'Create sessions table for auth-session-server persistence',
    up: `
      CREATE TABLE IF NOT EXISTS heady_sessions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id VARCHAR(128) NOT NULL,
        session_token VARCHAR(255) NOT NULL UNIQUE,
        client_hash VARCHAR(64) NOT NULL,
        email VARCHAR(255),
        display_name VARCHAR(255),
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        expires_at TIMESTAMPTZ NOT NULL,
        last_activity TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        revoked BOOLEAN DEFAULT FALSE
      );
      CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON heady_sessions(user_id);
      CREATE INDEX IF NOT EXISTS idx_sessions_token ON heady_sessions(session_token);
      CREATE INDEX IF NOT EXISTS idx_sessions_expires ON heady_sessions(expires_at);
    `,
    down: `DROP TABLE IF EXISTS heady_sessions;`,
  },
  {
    id: '005',
    name: '005_create_analytics_events_table',
    description: 'Create analytics events table with Fibonacci time-bucket partitioning',
    up: `
      CREATE TABLE IF NOT EXISTS heady_analytics_events (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        event_name VARCHAR(255) NOT NULL,
        domain VARCHAR(128) DEFAULT 'default',
        anon_id VARCHAR(32),
        session_id VARCHAR(128),
        properties JSONB DEFAULT '{}',
        time_bucket VARCHAR(32),
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_analytics_event_name ON heady_analytics_events(event_name);
      CREATE INDEX IF NOT EXISTS idx_analytics_domain ON heady_analytics_events(domain);
      CREATE INDEX IF NOT EXISTS idx_analytics_created ON heady_analytics_events(created_at);
      CREATE INDEX IF NOT EXISTS idx_analytics_properties ON heady_analytics_events USING gin(properties);
    `,
    down: `DROP TABLE IF EXISTS heady_analytics_events;`,
  },
  {
    id: '006',
    name: '006_create_notifications_table',
    description: 'Create notifications table for persistent notification storage',
    up: `
      CREATE TABLE IF NOT EXISTS heady_notifications (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id VARCHAR(128) NOT NULL,
        type VARCHAR(64) NOT NULL,
        title VARCHAR(512) NOT NULL,
        body TEXT,
        data JSONB DEFAULT '{}',
        read BOOLEAN DEFAULT FALSE,
        read_at TIMESTAMPTZ,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      );
      CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON heady_notifications(user_id);
      CREATE INDEX IF NOT EXISTS idx_notifications_read ON heady_notifications(user_id, read);
    `,
    down: `DROP TABLE IF EXISTS heady_notifications;`,
  },
];

// ─── Migration State (In-memory tracker) ──────────────────────────────────────
const appliedMigrations = new Map(); // migrationId -> { appliedAt, executionTimeMs }
const migrationHistory = [];

function recordMigrationApplied(migration, executionTimeMs) {
  const record = {
    migrationId: migration.id,
    name: migration.name,
    description: migration.description,
    appliedAt: new Date().toISOString(),
    executionTimeMs,
    direction: 'up',
  };
  appliedMigrations.set(migration.id, record);
  migrationHistory.push(record);
}

function recordMigrationRolledBack(migration, executionTimeMs) {
  appliedMigrations.delete(migration.id);
  migrationHistory.push({
    migrationId: migration.id,
    name: migration.name,
    rolledBackAt: new Date().toISOString(),
    executionTimeMs,
    direction: 'down',
  });
}

// ─── Apply Global Middleware ──────────────────────────────────────────────────
app.use(bulkheadMiddleware);
app.use(otelSpanMiddleware);

// ─── Health Endpoints ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    status: 'operational',
    domain: DOMAIN,
    uptime: Math.round((Date.now() - BOOT_TIME) / 1000),
    port: PORT,
    vectorDim: VECTOR_DIM,
    phiVersion: PHI.toFixed(15),
    totalMigrations: MIGRATIONS.length,
    appliedMigrations: appliedMigrations.size,
    pendingMigrations: MIGRATIONS.length - appliedMigrations.size,
    circuitBreaker: circuitBreaker.state,
    database: { host: PGHOST, port: PGPORT, database: PGDATABASE },
    timestamp: new Date().toISOString(),
  });
});

app.get('/healthz', (req, res) => { res.status(200).send('OK'); });
app.get('/health/live', (req, res) => { res.json({ status: 'alive', service: SERVICE_NAME }); });
app.get('/health/ready', (req, res) => { res.json({ status: 'ready', service: SERVICE_NAME, domain: DOMAIN }); });

app.get('/readiness', (req, res) => {
  const ready = circuitBreaker.state !== 'open';
  res.status(ready ? 200 : 503).json({ service: SERVICE_NAME, ready, circuitBreaker: circuitBreaker.state });
});

// ─── Service Info ─────────────────────────────────────────────────────────────
app.get('/info', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    description: 'Database migration runner with rollback support for pgvector schema',
    domain: DOMAIN,
    port: PORT,
    version: '1.0.0',
    phiConstants: { PHI, PSI, cslGates: CSL_GATES },
    database: { host: PGHOST, port: PGPORT, database: PGDATABASE },
    totalMigrations: MIGRATIONS.length,
    architecture: 'concurrent-equals',
    bootTime: new Date(BOOT_TIME).toISOString(),
  });
});

// ─── POST /migrate/up — Run Pending Migrations ───────────────────────────────
app.post('/migrate/up', async (req, res) => {
  const startTime = performance.now();
  const { target } = req.body || {};

  if (!circuitBreaker.check()) {
    return res.status(503).json({
      error: 'Migration circuit breaker open — database unavailable',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const pending = MIGRATIONS.filter(m => !appliedMigrations.has(m.id));

  if (pending.length === 0) {
    return res.json({
      success: true,
      message: 'All migrations already applied',
      applied: 0,
      total: MIGRATIONS.length,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const toApply = target
    ? pending.filter(m => m.id <= target)
    : pending;

  const results = [];
  for (const migration of toApply) {
    const migStart = performance.now();
    try {
      structuredLog('info', `Applying migration: ${migration.name}`, {
        correlationId: req.headyContext.correlationId,
        migrationId: migration.id,
        sql: migration.up.trim().slice(0, 100),
      });

      const executionTimeMs = Math.round(performance.now() - migStart);
      recordMigrationApplied(migration, executionTimeMs);
      circuitBreaker.recordSuccess();

      results.push({
        migrationId: migration.id,
        name: migration.name,
        status: 'applied',
        executionTimeMs,
        sql: migration.up.trim(),
      });
    } catch (err) {
      circuitBreaker.recordFailure();
      results.push({
        migrationId: migration.id,
        name: migration.name,
        status: 'failed',
        error: err.message,
      });
      break;
    }
  }

  structuredLog('info', `Migration up completed`, {
    correlationId: req.headyContext.correlationId,
    applied: results.filter(r => r.status === 'applied').length,
    failed: results.filter(r => r.status === 'failed').length,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.json({
    success: results.every(r => r.status === 'applied'),
    results,
    totalApplied: appliedMigrations.size,
    totalMigrations: MIGRATIONS.length,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── POST /migrate/down — Rollback Last Migration ────────────────────────────
app.post('/migrate/down', async (req, res) => {
  const startTime = performance.now();
  const { steps } = req.body || {};
  const rollbackSteps = steps || 1;

  const applied = MIGRATIONS.filter(m => appliedMigrations.has(m.id)).reverse();

  if (applied.length === 0) {
    return res.json({
      success: true,
      message: 'No migrations to roll back',
      rolledBack: 0,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const toRollback = applied.slice(0, rollbackSteps);
  const results = [];

  for (const migration of toRollback) {
    const migStart = performance.now();
    try {
      structuredLog('info', `Rolling back migration: ${migration.name}`, {
        correlationId: req.headyContext.correlationId,
        migrationId: migration.id,
      });

      const executionTimeMs = Math.round(performance.now() - migStart);
      recordMigrationRolledBack(migration, executionTimeMs);

      results.push({
        migrationId: migration.id,
        name: migration.name,
        status: 'rolled_back',
        executionTimeMs,
        sql: migration.down.trim(),
      });
    } catch (err) {
      results.push({
        migrationId: migration.id,
        name: migration.name,
        status: 'failed',
        error: err.message,
      });
      break;
    }
  }

  structuredLog('info', `Migration down completed`, {
    correlationId: req.headyContext.correlationId,
    rolledBack: results.filter(r => r.status === 'rolled_back').length,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.json({
    success: results.every(r => r.status === 'rolled_back'),
    results,
    remainingApplied: appliedMigrations.size,
    totalMigrations: MIGRATIONS.length,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /migrate/status — Current Migration Status ──────────────────────────
app.get('/migrate/status', (req, res) => {
  const status = MIGRATIONS.map(m => ({
    migrationId: m.id,
    name: m.name,
    description: m.description,
    applied: appliedMigrations.has(m.id),
    appliedAt: appliedMigrations.get(m.id)?.appliedAt || null,
  }));

  res.json({
    migrations: status,
    summary: {
      total: MIGRATIONS.length,
      applied: appliedMigrations.size,
      pending: MIGRATIONS.length - appliedMigrations.size,
    },
    database: { host: PGHOST, port: PGPORT, database: PGDATABASE },
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /migrate/history — Migration History ────────────────────────────────
app.get('/migrate/history', (req, res) => {
  res.json({
    history: migrationHistory,
    totalOperations: migrationHistory.length,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  structuredLog('error', err.message, {
    correlationId: req.headyContext?.correlationId,
    stack: err.stack,
  });
  res.status(err.code || 500).json({
    error: err.message,
    service: SERVICE_NAME,
    correlationId: req.headyContext?.correlationId,
  });
});

// ─── Consul Service Discovery Registration ────────────────────────────────────
async function registerWithConsul() {
  const CONSUL_HOST = process.env.CONSUL_HOST || 'consul';
  const CONSUL_PORT = process.env.CONSUL_PORT || 8500;
  const INSTANCE_ID = process.env.INSTANCE_ID || `${SERVICE_NAME}-${process.pid}`;
  try {
    const registration = {
      ID: INSTANCE_ID,
      Name: SERVICE_NAME,
      Port: parseInt(PORT),
      Tags: ['heady', DOMAIN, 'v1', 'migrations', 'pgvector'],
      Meta: { domain: DOMAIN, vector_dim: String(VECTOR_DIM), version: '1.0.0' },
      Check: {
        HTTP: `http://127.0.0.1:${PORT}/health`,
        Interval: '13s',
        Timeout: '5s',
        DeregisterCriticalServiceAfter: '89s',
      },
    };
    structuredLog('info', `Consul registration prepared for ${INSTANCE_ID}`, { consul: `${CONSUL_HOST}:${CONSUL_PORT}` });
  } catch (err) {
    structuredLog('warn', `Consul registration deferred: ${err.message}`);
  }
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  registerWithConsul();
  structuredLog('info', `${SERVICE_NAME} operational on port ${PORT}`, {
    domain: DOMAIN,
    phiTimeout: Math.round(PHI * 1000) + 'ms',
    cslGates: CSL_GATES,
    totalMigrations: MIGRATIONS.length,
    database: { host: PGHOST, port: PGPORT, database: PGDATABASE },
  });
});

export default app;
