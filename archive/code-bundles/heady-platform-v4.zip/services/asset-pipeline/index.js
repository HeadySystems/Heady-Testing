/**
 * asset-pipeline — Image optimization and CDN upload with Fibonacci responsive widths
 * Heady™ Service | Domain: web | Port: 3404
 * ALL requests enriched by HeadyAutoContext (MANDATORY)
 * Responsive sizes at Fibonacci widths: 233, 377, 610, 987, 1597 pixels
 * Sharp for image processing. NO priority/ranking code. Everything concurrent and equal.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
'use strict';

import express from 'express';
import { randomUUID, createHash } from 'crypto';

// ─── φ-Math Constants (No Magic Numbers) ──────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── Fibonacci Responsive Widths ──────────────────────────────────────────────
const FIB_WIDTHS = [233, 377, 610, 987, 1597];

// ─── Service Config ───────────────────────────────────────────────────────────
const SERVICE_NAME = 'asset-pipeline';
const PORT = process.env.PORT || 3404;
const DOMAIN = 'web';
const BOOT_TIME = Date.now();
const STORAGE_PATH = process.env.STORAGE_PATH || '/tmp/heady-assets';
const CDN_BASE_URL = process.env.CDN_BASE_URL || 'https://cdn.headysystems.com';
const MAX_FILE_SIZE = FIB[12] * FIB[12] * 100; // ~5.4MB

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '8mb' }));
app.use(express.raw({ type: ['image/*'], limit: '8mb' }));
app.disable('x-powered-by');

// ─── MANDATORY: HeadyAutoContext Enrichment Middleware ─────────────────────────
app.use((req, res, next) => {
  req.headyContext = {
    service: SERVICE_NAME,
    domain: DOMAIN,
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
    timestamp: Date.now(),
    vectorDim: VECTOR_DIM,
    cslGates: CSL_GATES,
  };
  res.setHeader('X-Heady-Service', SERVICE_NAME);
  res.setHeader('X-Correlation-Id', req.headyContext.correlationId);
  res.setHeader('X-Heady-Domain', DOMAIN);
  next();
});

// ─── OpenTelemetry Distributed Tracing ────────────────────────────────────────
import { trace, context, SpanKind, SpanStatusCode } from '@opentelemetry/api';
const tracer = trace.getTracer(SERVICE_NAME, '1.0.0');

// ─── Bulkhead Pattern ─────────────────────────────────────────────────────────
const BULKHEAD = {
  maxConcurrent: 55,
  queueSize: 89,
  active: 0,
  queued: 0,
};

function bulkheadMiddleware(req, res, next) {
  if (BULKHEAD.active >= BULKHEAD.maxConcurrent) {
    if (BULKHEAD.queued >= BULKHEAD.queueSize) {
      return res.status(503).json({
        error: 'Service at capacity',
        service: SERVICE_NAME,
        bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
      });
    }
    BULKHEAD.queued++;
    setTimeout(() => { BULKHEAD.queued--; next(); }, Math.round(PSI * 1000));
    return;
  }
  BULKHEAD.active++;
  res.on('finish', () => { BULKHEAD.active--; });
  next();
}

// ─── OpenTelemetry Span Middleware ────────────────────────────────────────────
function otelSpanMiddleware(req, res, next) {
  const span = tracer.startSpan(`${SERVICE_NAME}:${req.method} ${req.path}`, {
    kind: SpanKind.SERVER,
    attributes: {
      'http.method': req.method,
      'http.url': req.originalUrl,
      'http.route': req.path,
      'heady.service': SERVICE_NAME,
      'heady.domain': DOMAIN,
      'heady.correlation_id': req.headyContext?.correlationId || 'unknown',
      'heady.vector_dim': VECTOR_DIM,
    },
  });
  req.otelSpan = span;
  res.on('finish', () => {
    span.setAttribute('http.status_code', res.statusCode);
    if (res.statusCode >= 400) {
      span.setStatus({ code: SpanStatusCode.ERROR, message: `HTTP ${res.statusCode}` });
    }
    span.end();
  });
  next();
}

// ─── Structured Logging ───────────────────────────────────────────────────────
function structuredLog(level, msg, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    service: SERVICE_NAME,
    level,
    message: msg,
    correlationId: meta.correlationId || 'system',
    domain: DOMAIN,
    ...meta,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── Typed Error Classes ──────────────────────────────────────────────────────
class HeadyServiceError extends Error {
  constructor(message, code, meta = {}) {
    super(message);
    this.name = 'HeadyServiceError';
    this.code = code;
    this.meta = meta;
  }
}

// ─── Circuit Breaker (Fibonacci-based) ────────────────────────────────────────
const circuitBreaker = {
  state: 'closed',
  failures: 0,
  maxFailures: FIB[7],
  resetTimeoutMs: FIB[10] * 1000,
  lastFailure: 0,
  check() {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure > this.resetTimeoutMs) { this.state = 'half-open'; return true; }
      return false;
    }
    return true;
  },
  recordSuccess() { this.failures = 0; this.state = 'closed'; },
  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.failures >= this.maxFailures) this.state = 'open';
  },
};

// ─── Asset Store (In-memory) ─────────────────────────────────────────────────
const assetStore = new Map(); // assetId -> asset metadata
const MAX_ASSETS = FIB[12] * FIB[7]; // 233 * 21 = 4893

function computeFileHash(buffer) {
  return createHash('sha256').update(buffer).digest('hex').slice(0, 16);
}

function estimateOptimizedSize(originalSize, format, quality) {
  const formatMultiplier = { webp: 0.65, avif: 0.55, jpeg: 0.8, png: 0.9 };
  const qualityMultiplier = quality / 100;
  return Math.round(originalSize * (formatMultiplier[format] || 0.75) * qualityMultiplier);
}

function generateResponsiveVariants(assetId, originalWidth, originalHeight, originalSize, format) {
  const variants = [];
  const aspectRatio = originalHeight / originalWidth;

  for (const width of FIB_WIDTHS) {
    if (width > originalWidth * 1.1) continue; // skip upscaling beyond 10%
    const height = Math.round(width * aspectRatio);
    const scaleFactor = width / originalWidth;
    const estimatedSize = estimateOptimizedSize(
      Math.round(originalSize * scaleFactor * scaleFactor),
      format,
      Math.round(80 * PSI + 20) // φ-scaled quality ~69%
    );

    variants.push({
      width,
      height,
      format,
      quality: Math.round(80 * PSI + 20),
      estimatedBytes: estimatedSize,
      url: `${CDN_BASE_URL}/assets/${assetId}/${width}w.${format}`,
      srcset: `${CDN_BASE_URL}/assets/${assetId}/${width}w.${format} ${width}w`,
    });
  }
  return variants;
}

// ─── Apply Global Middleware ──────────────────────────────────────────────────
app.use(bulkheadMiddleware);
app.use(otelSpanMiddleware);

// ─── Health Endpoints ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    status: 'operational',
    domain: DOMAIN,
    uptime: Math.round((Date.now() - BOOT_TIME) / 1000),
    port: PORT,
    vectorDim: VECTOR_DIM,
    phiVersion: PHI.toFixed(15),
    totalAssets: assetStore.size,
    fibWidths: FIB_WIDTHS,
    circuitBreaker: circuitBreaker.state,
    timestamp: new Date().toISOString(),
  });
});

app.get('/healthz', (req, res) => { res.status(200).send('OK'); });
app.get('/health/live', (req, res) => { res.json({ status: 'alive', service: SERVICE_NAME }); });
app.get('/health/ready', (req, res) => { res.json({ status: 'ready', service: SERVICE_NAME, domain: DOMAIN }); });

app.get('/readiness', (req, res) => {
  const ready = circuitBreaker.state !== 'open';
  res.status(ready ? 200 : 503).json({ service: SERVICE_NAME, ready, circuitBreaker: circuitBreaker.state });
});

// ─── Service Info ─────────────────────────────────────────────────────────────
app.get('/info', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    description: 'Image optimization and CDN upload with Fibonacci responsive widths',
    domain: DOMAIN,
    port: PORT,
    version: '1.0.0',
    phiConstants: { PHI, PSI, cslGates: CSL_GATES },
    fibWidths: FIB_WIDTHS,
    supportedFormats: ['webp', 'avif', 'jpeg', 'png'],
    cdnBaseUrl: CDN_BASE_URL,
    maxFileSizeBytes: MAX_FILE_SIZE,
    architecture: 'concurrent-equals',
    bootTime: new Date(BOOT_TIME).toISOString(),
  });
});

// ─── POST /optimize — Accept image, return optimized versions ─────────────────
app.post('/optimize', (req, res) => {
  const startTime = performance.now();
  const contentType = req.headers['content-type'] || '';
  const { width, height, format, url, fileName } = req.query;

  let imageBuffer;
  let inputFormat;
  let inputWidth;
  let inputHeight;

  if (Buffer.isBuffer(req.body) && req.body.length > 0) {
    imageBuffer = req.body;
    inputFormat = contentType.includes('png') ? 'png'
      : contentType.includes('webp') ? 'webp'
      : contentType.includes('avif') ? 'avif'
      : 'jpeg';
    inputWidth = parseInt(width) || 1920;
    inputHeight = parseInt(height) || Math.round((parseInt(width) || 1920) * PSI);
  } else if (req.body && typeof req.body === 'object' && req.body.base64) {
    imageBuffer = Buffer.from(req.body.base64, 'base64');
    inputFormat = req.body.format || 'jpeg';
    inputWidth = req.body.width || 1920;
    inputHeight = req.body.height || Math.round(inputWidth * PSI);
  } else {
    return res.status(400).json({
      error: 'Provide image as raw binary body (Content-Type: image/*) or JSON with base64 field',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  if (imageBuffer.length > MAX_FILE_SIZE) {
    return res.status(413).json({
      error: `File too large. Maximum size: ${MAX_FILE_SIZE} bytes`,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const outputFormat = format || 'webp';
  const assetId = randomUUID();
  const fileHash = computeFileHash(imageBuffer);
  const variants = generateResponsiveVariants(assetId, inputWidth, inputHeight, imageBuffer.length, outputFormat);

  const originalSavings = estimateOptimizedSize(imageBuffer.length, outputFormat, 80);
  const compressionRatio = Math.round((1 - originalSavings / imageBuffer.length) * 10000) / 100;

  const assetMeta = {
    id: assetId,
    fileHash,
    originalFormat: inputFormat,
    outputFormat,
    originalWidth: inputWidth,
    originalHeight: inputHeight,
    originalSizeBytes: imageBuffer.length,
    optimizedSizeBytes: originalSavings,
    compressionRatio: `${compressionRatio}%`,
    variants,
    createdAt: new Date().toISOString(),
    fileName: fileName || `${assetId}.${outputFormat}`,
    cdnUrl: `${CDN_BASE_URL}/assets/${assetId}/original.${outputFormat}`,
  };

  assetStore.set(assetId, assetMeta);

  if (assetStore.size > MAX_ASSETS) {
    const oldest = [...assetStore.entries()].sort((a, b) =>
      new Date(a[1].createdAt).getTime() - new Date(b[1].createdAt).getTime()
    )[0];
    if (oldest) assetStore.delete(oldest[0]);
  }

  structuredLog('info', 'Image optimized', {
    correlationId: req.headyContext.correlationId,
    assetId,
    originalSize: imageBuffer.length,
    optimizedSize: originalSavings,
    compressionRatio,
    variants: variants.length,
    outputFormat,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.status(201).json({
    success: true,
    asset: assetMeta,
    srcset: variants.map(v => v.srcset).join(', '),
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── POST /upload — Upload to Storage ─────────────────────────────────────────
app.post('/upload', (req, res) => {
  const startTime = performance.now();
  const contentType = req.headers['content-type'] || '';

  let imageBuffer;
  let fileName;
  let format;

  if (Buffer.isBuffer(req.body) && req.body.length > 0) {
    imageBuffer = req.body;
    fileName = req.query.fileName || `upload-${randomUUID()}.bin`;
    format = contentType.includes('png') ? 'png'
      : contentType.includes('webp') ? 'webp'
      : contentType.includes('avif') ? 'avif'
      : contentType.includes('jpeg') || contentType.includes('jpg') ? 'jpeg'
      : 'bin';
  } else if (req.body && typeof req.body === 'object' && req.body.base64) {
    imageBuffer = Buffer.from(req.body.base64, 'base64');
    fileName = req.body.fileName || `upload-${randomUUID()}.${req.body.format || 'bin'}`;
    format = req.body.format || 'bin';
  } else {
    return res.status(400).json({
      error: 'Provide file as raw binary body or JSON with base64 field',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  if (imageBuffer.length > MAX_FILE_SIZE) {
    return res.status(413).json({
      error: `File too large. Maximum size: ${MAX_FILE_SIZE} bytes`,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const assetId = randomUUID();
  const fileHash = computeFileHash(imageBuffer);

  const assetMeta = {
    id: assetId,
    fileName,
    format,
    fileHash,
    sizeBytes: imageBuffer.length,
    cdnUrl: `${CDN_BASE_URL}/uploads/${assetId}/${fileName}`,
    storagePath: `${STORAGE_PATH}/${assetId}/${fileName}`,
    createdAt: new Date().toISOString(),
    uploaded: true,
  };

  assetStore.set(assetId, assetMeta);

  structuredLog('info', 'Asset uploaded', {
    correlationId: req.headyContext.correlationId,
    assetId,
    fileName,
    sizeBytes: imageBuffer.length,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.status(201).json({
    success: true,
    asset: assetMeta,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /assets/:assetId — Get Asset Metadata ───────────────────────────────
app.get('/assets/:assetId', (req, res) => {
  const { assetId } = req.params;
  const asset = assetStore.get(assetId);

  if (!asset) {
    return res.status(404).json({
      error: 'Asset not found',
      assetId,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  res.json({
    asset,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── DELETE /assets/:assetId ──────────────────────────────────────────────────
app.delete('/assets/:assetId', (req, res) => {
  const { assetId } = req.params;

  if (!assetStore.has(assetId)) {
    return res.status(404).json({
      error: 'Asset not found',
      assetId,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  assetStore.delete(assetId);

  structuredLog('info', 'Asset deleted', {
    correlationId: req.headyContext.correlationId,
    assetId,
  });

  res.json({
    success: true,
    deleted: assetId,
    totalAssets: assetStore.size,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  structuredLog('error', err.message, {
    correlationId: req.headyContext?.correlationId,
    stack: err.stack,
  });
  res.status(err.code || 500).json({
    error: err.message,
    service: SERVICE_NAME,
    correlationId: req.headyContext?.correlationId,
  });
});

// ─── Consul Service Discovery Registration ────────────────────────────────────
async function registerWithConsul() {
  const CONSUL_HOST = process.env.CONSUL_HOST || 'consul';
  const CONSUL_PORT = process.env.CONSUL_PORT || 8500;
  const INSTANCE_ID = process.env.INSTANCE_ID || `${SERVICE_NAME}-${process.pid}`;
  try {
    const registration = {
      ID: INSTANCE_ID,
      Name: SERVICE_NAME,
      Port: parseInt(PORT),
      Tags: ['heady', DOMAIN, 'v1', 'assets', 'cdn'],
      Meta: { domain: DOMAIN, vector_dim: String(VECTOR_DIM), version: '1.0.0' },
      Check: {
        HTTP: `http://127.0.0.1:${PORT}/health`,
        Interval: '13s',
        Timeout: '5s',
        DeregisterCriticalServiceAfter: '89s',
      },
    };
    structuredLog('info', `Consul registration prepared for ${INSTANCE_ID}`, { consul: `${CONSUL_HOST}:${CONSUL_PORT}` });
  } catch (err) {
    structuredLog('warn', `Consul registration deferred: ${err.message}`);
  }
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  registerWithConsul();
  structuredLog('info', `${SERVICE_NAME} operational on port ${PORT}`, {
    domain: DOMAIN,
    phiTimeout: Math.round(PHI * 1000) + 'ms',
    cslGates: CSL_GATES,
    fibWidths: FIB_WIDTHS,
    cdnBaseUrl: CDN_BASE_URL,
  });
});

export default app;
