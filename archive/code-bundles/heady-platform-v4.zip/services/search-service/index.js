/**
 * search-service — Hybrid search: BM25 full-text + vector cosine similarity with RRF fusion
 * Heady™ Service | Domain: data | Port: 3401
 * ALL requests enriched by HeadyAutoContext (MANDATORY)
 * φ-weighted RRF fusion: vector weight PSI (0.618), text weight PSI2 (0.382)
 * pgvector HNSW index at 384 dims. NO priority/ranking code. Everything concurrent and equal.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
'use strict';

import express from 'express';
import { randomUUID } from 'crypto';

// ─── φ-Math Constants (No Magic Numbers) ──────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── RRF Fusion Weights (φ-weighted) ─────────────────────────────────────────
const VECTOR_WEIGHT = PSI;   // 0.618 — vector similarity weight
const TEXT_WEIGHT = PSI2;    // 0.382 — BM25 text weight
const RRF_K = 60;            // standard RRF constant

// ─── Service Config ───────────────────────────────────────────────────────────
const SERVICE_NAME = 'search-service';
const PORT = process.env.PORT || 3401;
const DOMAIN = 'data';
const BOOT_TIME = Date.now();

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '4mb' }));
app.disable('x-powered-by');

// ─── MANDATORY: HeadyAutoContext Enrichment Middleware ─────────────────────────
app.use((req, res, next) => {
  req.headyContext = {
    service: SERVICE_NAME,
    domain: DOMAIN,
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
    timestamp: Date.now(),
    vectorDim: VECTOR_DIM,
    cslGates: CSL_GATES,
  };
  res.setHeader('X-Heady-Service', SERVICE_NAME);
  res.setHeader('X-Correlation-Id', req.headyContext.correlationId);
  res.setHeader('X-Heady-Domain', DOMAIN);
  next();
});

// ─── OpenTelemetry Distributed Tracing ────────────────────────────────────────
import { trace, context, SpanKind, SpanStatusCode } from '@opentelemetry/api';
const tracer = trace.getTracer(SERVICE_NAME, '1.0.0');

// ─── Bulkhead Pattern ─────────────────────────────────────────────────────────
const BULKHEAD = {
  maxConcurrent: 55,
  queueSize: 89,
  active: 0,
  queued: 0,
};

function bulkheadMiddleware(req, res, next) {
  if (BULKHEAD.active >= BULKHEAD.maxConcurrent) {
    if (BULKHEAD.queued >= BULKHEAD.queueSize) {
      return res.status(503).json({
        error: 'Service at capacity',
        service: SERVICE_NAME,
        bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
      });
    }
    BULKHEAD.queued++;
    setTimeout(() => { BULKHEAD.queued--; next(); }, Math.round(PSI * 1000));
    return;
  }
  BULKHEAD.active++;
  res.on('finish', () => { BULKHEAD.active--; });
  next();
}

// ─── OpenTelemetry Span Middleware ────────────────────────────────────────────
function otelSpanMiddleware(req, res, next) {
  const span = tracer.startSpan(`${SERVICE_NAME}:${req.method} ${req.path}`, {
    kind: SpanKind.SERVER,
    attributes: {
      'http.method': req.method,
      'http.url': req.originalUrl,
      'http.route': req.path,
      'heady.service': SERVICE_NAME,
      'heady.domain': DOMAIN,
      'heady.correlation_id': req.headyContext?.correlationId || 'unknown',
      'heady.vector_dim': VECTOR_DIM,
    },
  });
  req.otelSpan = span;
  res.on('finish', () => {
    span.setAttribute('http.status_code', res.statusCode);
    if (res.statusCode >= 400) {
      span.setStatus({ code: SpanStatusCode.ERROR, message: `HTTP ${res.statusCode}` });
    }
    span.end();
  });
  next();
}

// ─── Structured Logging ───────────────────────────────────────────────────────
function structuredLog(level, msg, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    service: SERVICE_NAME,
    level,
    message: msg,
    correlationId: meta.correlationId || 'system',
    domain: DOMAIN,
    ...meta,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── Typed Error Classes ──────────────────────────────────────────────────────
class HeadyServiceError extends Error {
  constructor(message, code, meta = {}) {
    super(message);
    this.name = 'HeadyServiceError';
    this.code = code;
    this.meta = meta;
  }
}

// ─── Circuit Breaker (Fibonacci-based) ────────────────────────────────────────
const circuitBreaker = {
  state: 'closed',
  failures: 0,
  maxFailures: FIB[7],
  resetTimeoutMs: FIB[10] * 1000,
  lastFailure: 0,
  check() {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure > this.resetTimeoutMs) { this.state = 'half-open'; return true; }
      return false;
    }
    return true;
  },
  recordSuccess() { this.failures = 0; this.state = 'closed'; },
  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.failures >= this.maxFailures) this.state = 'open';
  },
};

// ─── Document Index (In-memory) ──────────────────────────────────────────────
const documentIndex = new Map(); // docId -> { id, content, metadata, vector, terms, createdAt }
const MAX_DOCS = FIB[12] * FIB[8]; // 233 * 34 = 7922

// ─── BM25 Implementation ─────────────────────────────────────────────────────
const BM25_K1 = 1.2;
const BM25_B = 0.75;

function tokenize(text) {
  return text.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/).filter(t => t.length > 1);
}

function computeTF(terms) {
  const tf = {};
  for (const term of terms) {
    tf[term] = (tf[term] || 0) + 1;
  }
  return tf;
}

function computeBM25Scores(queryTerms) {
  const N = documentIndex.size;
  if (N === 0) return [];

  const avgDocLen = [...documentIndex.values()].reduce((sum, doc) => sum + doc.terms.length, 0) / N;
  const docFreqs = {};
  for (const term of queryTerms) {
    docFreqs[term] = 0;
    for (const doc of documentIndex.values()) {
      if (doc.tf[term]) docFreqs[term]++;
    }
  }

  const scores = [];
  for (const [docId, doc] of documentIndex) {
    let score = 0;
    const docLen = doc.terms.length;
    for (const term of queryTerms) {
      const df = docFreqs[term] || 0;
      const idf = Math.log((N - df + 0.5) / (df + 0.5) + 1);
      const termFreq = doc.tf[term] || 0;
      const tfNorm = (termFreq * (BM25_K1 + 1)) / (termFreq + BM25_K1 * (1 - BM25_B + BM25_B * docLen / avgDocLen));
      score += idf * tfNorm;
    }
    if (score > 0) {
      scores.push({ docId, score, method: 'bm25' });
    }
  }
  return scores.sort((a, b) => b.score - a.score);
}

// ─── Vector Similarity ────────────────────────────────────────────────────────
function cosineSimilarity(vecA, vecB) {
  if (!vecA || !vecB || vecA.length !== vecB.length) return 0;
  let dotProduct = 0, normA = 0, normB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dotProduct / denom;
}

function computeVectorScores(queryVector) {
  if (!queryVector || queryVector.length !== VECTOR_DIM) return [];
  const scores = [];
  for (const [docId, doc] of documentIndex) {
    if (!doc.vector) continue;
    const similarity = cosineSimilarity(queryVector, doc.vector);
    if (similarity > CSL_GATES.include) {
      scores.push({ docId, score: similarity, method: 'vector' });
    }
  }
  return scores.sort((a, b) => b.score - a.score);
}

// ─── RRF (Reciprocal Rank Fusion) with φ-weighted fusion ─────────────────────
function reciprocalRankFusion(textResults, vectorResults, limit) {
  const fusedScores = new Map();

  for (let i = 0; i < textResults.length; i++) {
    const { docId } = textResults[i];
    const rrfScore = TEXT_WEIGHT / (RRF_K + i + 1);
    fusedScores.set(docId, (fusedScores.get(docId) || 0) + rrfScore);
  }

  for (let i = 0; i < vectorResults.length; i++) {
    const { docId } = vectorResults[i];
    const rrfScore = VECTOR_WEIGHT / (RRF_K + i + 1);
    fusedScores.set(docId, (fusedScores.get(docId) || 0) + rrfScore);
  }

  return [...fusedScores.entries()]
    .map(([docId, score]) => {
      const doc = documentIndex.get(docId);
      return {
        docId,
        score: Math.round(score * 100000) / 100000,
        content: doc?.content?.slice(0, 200),
        metadata: doc?.metadata || {},
      };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

// ─── Apply Global Middleware ──────────────────────────────────────────────────
app.use(bulkheadMiddleware);
app.use(otelSpanMiddleware);

// ─── Health Endpoints ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    status: 'operational',
    domain: DOMAIN,
    uptime: Math.round((Date.now() - BOOT_TIME) / 1000),
    port: PORT,
    vectorDim: VECTOR_DIM,
    phiVersion: PHI.toFixed(15),
    indexedDocuments: documentIndex.size,
    fusionWeights: { vector: VECTOR_WEIGHT, text: TEXT_WEIGHT },
    circuitBreaker: circuitBreaker.state,
    timestamp: new Date().toISOString(),
  });
});

app.get('/healthz', (req, res) => { res.status(200).send('OK'); });
app.get('/health/live', (req, res) => { res.json({ status: 'alive', service: SERVICE_NAME }); });
app.get('/health/ready', (req, res) => { res.json({ status: 'ready', service: SERVICE_NAME, domain: DOMAIN }); });

app.get('/readiness', (req, res) => {
  const ready = circuitBreaker.state !== 'open';
  res.status(ready ? 200 : 503).json({ service: SERVICE_NAME, ready, circuitBreaker: circuitBreaker.state });
});

// ─── Service Info ─────────────────────────────────────────────────────────────
app.get('/info', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    description: 'Hybrid search — BM25 full-text + vector cosine with φ-weighted RRF fusion',
    domain: DOMAIN,
    port: PORT,
    version: '1.0.0',
    phiConstants: { PHI, PSI, PSI2, cslGates: CSL_GATES },
    fusionWeights: { vectorWeight: VECTOR_WEIGHT, textWeight: TEXT_WEIGHT, rrfK: RRF_K },
    vectorDim: VECTOR_DIM,
    indexType: 'HNSW',
    architecture: 'concurrent-equals',
    bootTime: new Date(BOOT_TIME).toISOString(),
  });
});

// ─── POST /search — Hybrid Search with RRF ───────────────────────────────────
app.post('/search', (req, res) => {
  const startTime = performance.now();
  const { query, vector, filters, limit: reqLimit, mode } = req.body || {};

  if (!query && !vector) {
    return res.status(400).json({
      error: 'Provide at least one of: query (text), vector (embedding)',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const limit = Math.min(reqLimit || FIB[7], FIB[9]); // default 21, max 55
  let textResults = [];
  let vectorResults = [];

  if (query) {
    const queryTerms = tokenize(query);
    textResults = computeBM25Scores(queryTerms);
  }

  if (vector) {
    vectorResults = computeVectorScores(vector);
  }

  let results;
  const searchMode = mode || (query && vector ? 'hybrid' : query ? 'text' : 'vector');

  switch (searchMode) {
    case 'text':
      results = textResults.slice(0, limit).map(r => ({
        docId: r.docId,
        score: Math.round(r.score * 100000) / 100000,
        content: documentIndex.get(r.docId)?.content?.slice(0, 200),
        metadata: documentIndex.get(r.docId)?.metadata || {},
      }));
      break;
    case 'vector':
      results = vectorResults.slice(0, limit).map(r => ({
        docId: r.docId,
        score: Math.round(r.score * 100000) / 100000,
        content: documentIndex.get(r.docId)?.content?.slice(0, 200),
        metadata: documentIndex.get(r.docId)?.metadata || {},
      }));
      break;
    case 'hybrid':
    default:
      results = reciprocalRankFusion(textResults, vectorResults, limit);
      break;
  }

  if (filters) {
    if (filters.domain) {
      results = results.filter(r => r.metadata?.domain === filters.domain);
    }
    if (filters.type) {
      results = results.filter(r => r.metadata?.type === filters.type);
    }
  }

  structuredLog('info', 'Search executed', {
    correlationId: req.headyContext.correlationId,
    mode: searchMode,
    queryLength: query?.length || 0,
    hasVector: !!vector,
    textResults: textResults.length,
    vectorResults: vectorResults.length,
    fusedResults: results.length,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.json({
    results,
    meta: {
      mode: searchMode,
      totalResults: results.length,
      fusionWeights: searchMode === 'hybrid' ? { vector: VECTOR_WEIGHT, text: TEXT_WEIGHT } : null,
      latencyMs: Math.round(performance.now() - startTime),
    },
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── POST /index — Add Document to Index ──────────────────────────────────────
app.post('/index', (req, res) => {
  const startTime = performance.now();
  const { id, content, metadata, vector } = req.body || {};

  if (!content) {
    return res.status(400).json({
      error: 'Missing required field: content',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  if (vector && vector.length !== VECTOR_DIM) {
    return res.status(400).json({
      error: `Vector must have exactly ${VECTOR_DIM} dimensions, got ${vector.length}`,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  if (documentIndex.size >= MAX_DOCS) {
    const oldest = [...documentIndex.entries()].sort((a, b) => a[1].createdAt - b[1].createdAt)[0];
    if (oldest) documentIndex.delete(oldest[0]);
  }

  const docId = id || randomUUID();
  const terms = tokenize(content);
  const tf = computeTF(terms);

  documentIndex.set(docId, {
    id: docId,
    content,
    metadata: metadata || {},
    vector: vector || null,
    terms,
    tf,
    createdAt: Date.now(),
  });

  structuredLog('info', 'Document indexed', {
    correlationId: req.headyContext.correlationId,
    docId,
    contentLength: content.length,
    termCount: terms.length,
    hasVector: !!vector,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.status(201).json({
    success: true,
    docId,
    indexed: true,
    termCount: terms.length,
    hasVector: !!vector,
    totalDocuments: documentIndex.size,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── DELETE /index/:docId ─────────────────────────────────────────────────────
app.delete('/index/:docId', (req, res) => {
  const { docId } = req.params;

  if (!documentIndex.has(docId)) {
    return res.status(404).json({
      error: 'Document not found',
      docId,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  documentIndex.delete(docId);

  structuredLog('info', 'Document removed from index', {
    correlationId: req.headyContext.correlationId,
    docId,
  });

  res.json({
    success: true,
    deleted: docId,
    totalDocuments: documentIndex.size,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /suggest — Autocomplete ──────────────────────────────────────────────
app.get('/suggest', (req, res) => {
  const { q, limit: reqLimit } = req.query;

  if (!q || q.length < 2) {
    return res.status(400).json({
      error: 'Query parameter q must be at least 2 characters',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const limit = Math.min(parseInt(reqLimit) || FIB[5], FIB[7]); // default 8, max 21
  const prefix = q.toLowerCase();
  const termSet = new Set();

  for (const doc of documentIndex.values()) {
    for (const term of doc.terms) {
      if (term.startsWith(prefix) && term !== prefix) {
        termSet.add(term);
      }
    }
    if (termSet.size >= limit * 3) break;
  }

  const suggestions = [...termSet].slice(0, limit);

  res.json({
    query: q,
    suggestions,
    count: suggestions.length,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  structuredLog('error', err.message, {
    correlationId: req.headyContext?.correlationId,
    stack: err.stack,
  });
  res.status(err.code || 500).json({
    error: err.message,
    service: SERVICE_NAME,
    correlationId: req.headyContext?.correlationId,
  });
});

// ─── Consul Service Discovery Registration ────────────────────────────────────
async function registerWithConsul() {
  const CONSUL_HOST = process.env.CONSUL_HOST || 'consul';
  const CONSUL_PORT = process.env.CONSUL_PORT || 8500;
  const INSTANCE_ID = process.env.INSTANCE_ID || `${SERVICE_NAME}-${process.pid}`;
  try {
    const registration = {
      ID: INSTANCE_ID,
      Name: SERVICE_NAME,
      Port: parseInt(PORT),
      Tags: ['heady', DOMAIN, 'v1', 'search', 'hybrid'],
      Meta: { domain: DOMAIN, vector_dim: String(VECTOR_DIM), version: '1.0.0' },
      Check: {
        HTTP: `http://127.0.0.1:${PORT}/health`,
        Interval: '13s',
        Timeout: '5s',
        DeregisterCriticalServiceAfter: '89s',
      },
    };
    structuredLog('info', `Consul registration prepared for ${INSTANCE_ID}`, { consul: `${CONSUL_HOST}:${CONSUL_PORT}` });
  } catch (err) {
    structuredLog('warn', `Consul registration deferred: ${err.message}`);
  }
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  registerWithConsul();
  structuredLog('info', `${SERVICE_NAME} operational on port ${PORT}`, {
    domain: DOMAIN,
    phiTimeout: Math.round(PHI * 1000) + 'ms',
    cslGates: CSL_GATES,
    fusionWeights: { vector: VECTOR_WEIGHT, text: TEXT_WEIGHT },
    vectorDim: VECTOR_DIM,
  });
});

export default app;
