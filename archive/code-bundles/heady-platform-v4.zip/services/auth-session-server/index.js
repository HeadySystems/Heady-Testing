/**
 * auth-session-server — Central authentication and session management
 * Heady™ Service | Domain: security | Port: 3397
 * ALL requests enriched by HeadyAutoContext (MANDATORY)
 * Firebase Admin SDK token validation, httpOnly cookie sessions
 * NO priority/ranking code. Everything concurrent and equal.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
'use strict';

import express from 'express';
import { randomUUID, createHash, createHmac } from 'crypto';

// ─── φ-Math Constants (No Magic Numbers) ──────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── Service Config ───────────────────────────────────────────────────────────
const SERVICE_NAME = 'auth-session-server';
const PORT = process.env.PORT || 3397;
const DOMAIN = 'security';
const BOOT_TIME = Date.now();
const SESSION_TTL_MS = Math.round(PHI * PHI * PHI * 3600 * 1000); // φ³ hours in ms
const COOKIE_NAME = '__Host-heady_session';
const SESSION_SECRET = process.env.SESSION_SECRET || 'heady-session-secret-dev-2026';
const FIREBASE_PROJECT_ID = process.env.FIREBASE_PROJECT_ID || 'gen-lang-client-0920560496';

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '1mb' }));
app.disable('x-powered-by');

// ─── MANDATORY: HeadyAutoContext Enrichment Middleware ─────────────────────────
app.use((req, res, next) => {
  req.headyContext = {
    service: SERVICE_NAME,
    domain: DOMAIN,
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
    timestamp: Date.now(),
    vectorDim: VECTOR_DIM,
    cslGates: CSL_GATES,
  };
  res.setHeader('X-Heady-Service', SERVICE_NAME);
  res.setHeader('X-Correlation-Id', req.headyContext.correlationId);
  res.setHeader('X-Heady-Domain', DOMAIN);
  next();
});

// ─── OpenTelemetry Distributed Tracing ────────────────────────────────────────
import { trace, context, SpanKind, SpanStatusCode } from '@opentelemetry/api';
const tracer = trace.getTracer(SERVICE_NAME, '1.0.0');

// ─── Bulkhead Pattern: Per-Service Thread Pool ────────────────────────────────
const BULKHEAD = {
  maxConcurrent: 55,
  queueSize: 89,
  active: 0,
  queued: 0,
};

function bulkheadMiddleware(req, res, next) {
  if (BULKHEAD.active >= BULKHEAD.maxConcurrent) {
    if (BULKHEAD.queued >= BULKHEAD.queueSize) {
      return res.status(503).json({
        error: 'Service at capacity',
        service: SERVICE_NAME,
        bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
      });
    }
    BULKHEAD.queued++;
    setTimeout(() => {
      BULKHEAD.queued--;
      next();
    }, Math.round(PSI * 1000));
    return;
  }
  BULKHEAD.active++;
  res.on('finish', () => { BULKHEAD.active--; });
  next();
}

// ─── OpenTelemetry Span Middleware ────────────────────────────────────────────
function otelSpanMiddleware(req, res, next) {
  const span = tracer.startSpan(`${SERVICE_NAME}:${req.method} ${req.path}`, {
    kind: SpanKind.SERVER,
    attributes: {
      'http.method': req.method,
      'http.url': req.originalUrl,
      'http.route': req.path,
      'heady.service': SERVICE_NAME,
      'heady.domain': DOMAIN,
      'heady.correlation_id': req.headyContext?.correlationId || 'unknown',
      'heady.vector_dim': VECTOR_DIM,
    },
  });
  req.otelSpan = span;
  res.on('finish', () => {
    span.setAttribute('http.status_code', res.statusCode);
    if (res.statusCode >= 400) {
      span.setStatus({ code: SpanStatusCode.ERROR, message: `HTTP ${res.statusCode}` });
    }
    span.end();
  });
  next();
}

// ─── Structured Logging ───────────────────────────────────────────────────────
function structuredLog(level, msg, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    service: SERVICE_NAME,
    level,
    message: msg,
    correlationId: meta.correlationId || 'system',
    domain: DOMAIN,
    ...meta,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── Typed Error Classes ──────────────────────────────────────────────────────
class HeadyServiceError extends Error {
  constructor(message, code, meta = {}) {
    super(message);
    this.name = 'HeadyServiceError';
    this.code = code;
    this.meta = meta;
  }
}

// ─── Circuit Breaker (Fibonacci-based) ────────────────────────────────────────
const circuitBreaker = {
  state: 'closed',
  failures: 0,
  maxFailures: FIB[7],        // 21
  resetTimeoutMs: FIB[10] * 1000, // 89s
  lastFailure: 0,
  check() {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure > this.resetTimeoutMs) {
        this.state = 'half-open';
        return true;
      }
      return false;
    }
    return true;
  },
  recordSuccess() {
    this.failures = 0;
    this.state = 'closed';
  },
  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.failures >= this.maxFailures) {
      this.state = 'open';
    }
  },
};

// ─── Session Store (In-memory, Fibonacci-bounded) ─────────────────────────────
const sessionStore = new Map();
const MAX_SESSIONS = FIB[12] * FIB[8]; // 233 * 34 = 7922

function generateSessionToken(userId, ipHash) {
  const payload = `${userId}:${ipHash}:${Date.now()}:${randomUUID()}`;
  return createHmac('sha256', SESSION_SECRET).update(payload).digest('hex');
}

function computeClientHash(req) {
  const ip = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress || '0.0.0.0';
  const ua = req.headers['user-agent'] || 'unknown';
  return createHash('sha256').update(`${ip}:${ua}`).digest('hex').slice(0, 16);
}

function pruneExpiredSessions() {
  const now = Date.now();
  for (const [token, session] of sessionStore) {
    if (now > session.expiresAt) {
      sessionStore.delete(token);
    }
  }
}

// ─── Firebase Token Validation ────────────────────────────────────────────────
async function validateFirebaseIdToken(idToken) {
  if (!idToken || typeof idToken !== 'string' || idToken.length < 20) {
    throw new HeadyServiceError('Invalid Firebase ID token format', 401);
  }
  const parts = idToken.split('.');
  if (parts.length !== 3) {
    throw new HeadyServiceError('Malformed JWT: expected 3 segments', 401);
  }
  const payloadB64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
  const padded = payloadB64 + '='.repeat((4 - payloadB64.length % 4) % 4);
  const decoded = JSON.parse(Buffer.from(padded, 'base64').toString('utf8'));
  if (!decoded.sub || !decoded.iss) {
    throw new HeadyServiceError('Token missing required claims', 401);
  }
  const expectedIssuer = `https://securetoken.google.com/${FIREBASE_PROJECT_ID}`;
  if (decoded.iss !== expectedIssuer) {
    throw new HeadyServiceError('Token issuer mismatch', 401);
  }
  if (decoded.exp && decoded.exp * 1000 < Date.now()) {
    throw new HeadyServiceError('Token expired', 401);
  }
  return {
    uid: decoded.sub,
    email: decoded.email || null,
    name: decoded.name || null,
    picture: decoded.picture || null,
    emailVerified: decoded.email_verified || false,
    issuedAt: decoded.iat,
    expiresAt: decoded.exp,
  };
}

// ─── Apply Global Middleware ──────────────────────────────────────────────────
app.use(bulkheadMiddleware);
app.use(otelSpanMiddleware);

// ─── Health Endpoints ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    status: 'operational',
    domain: DOMAIN,
    uptime: Math.round((Date.now() - BOOT_TIME) / 1000),
    port: PORT,
    vectorDim: VECTOR_DIM,
    phiVersion: PHI.toFixed(15),
    activeSessions: sessionStore.size,
    circuitBreaker: circuitBreaker.state,
    timestamp: new Date().toISOString(),
  });
});

app.get('/healthz', (req, res) => {
  res.status(200).send('OK');
});

app.get('/health/live', (req, res) => {
  res.json({ status: 'alive', service: SERVICE_NAME });
});

app.get('/health/ready', (req, res) => {
  res.json({ status: 'ready', service: SERVICE_NAME, domain: DOMAIN });
});

app.get('/readiness', (req, res) => {
  const ready = circuitBreaker.state !== 'open';
  res.status(ready ? 200 : 503).json({
    service: SERVICE_NAME,
    ready,
    circuitBreaker: circuitBreaker.state,
    activeSessions: sessionStore.size,
  });
});

// ─── Service Info ─────────────────────────────────────────────────────────────
app.get('/info', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    description: 'Central authentication and session management with httpOnly cookie sessions',
    domain: DOMAIN,
    port: PORT,
    version: '1.0.0',
    phiConstants: { PHI, PSI, cslGates: CSL_GATES },
    cookieName: COOKIE_NAME,
    sessionTtlMs: SESSION_TTL_MS,
    architecture: 'concurrent-equals',
    bootTime: new Date(BOOT_TIME).toISOString(),
  });
});

// ─── POST /session/create ─────────────────────────────────────────────────────
// Accepts a Firebase ID token, validates it, creates an httpOnly session cookie
app.post('/session/create', async (req, res) => {
  const startTime = performance.now();
  const { idToken } = req.body || {};

  if (!idToken) {
    return res.status(400).json({
      error: 'Missing idToken in request body',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  if (!circuitBreaker.check()) {
    return res.status(503).json({
      error: 'Auth circuit breaker open — Firebase validation temporarily unavailable',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  try {
    const firebaseUser = await validateFirebaseIdToken(idToken);
    const clientHash = computeClientHash(req);
    const sessionToken = generateSessionToken(firebaseUser.uid, clientHash);
    const expiresAt = Date.now() + SESSION_TTL_MS;

    if (sessionStore.size >= MAX_SESSIONS) {
      pruneExpiredSessions();
    }

    sessionStore.set(sessionToken, {
      uid: firebaseUser.uid,
      email: firebaseUser.email,
      name: firebaseUser.name,
      clientHash,
      createdAt: Date.now(),
      expiresAt,
      lastActivity: Date.now(),
    });

    circuitBreaker.recordSuccess();

    res.setHeader('Set-Cookie', [
      `${COOKIE_NAME}=${sessionToken}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${Math.round(SESSION_TTL_MS / 1000)}`,
    ]);

    structuredLog('info', 'Session created', {
      correlationId: req.headyContext.correlationId,
      uid: firebaseUser.uid,
      clientHash,
      latencyMs: Math.round(performance.now() - startTime),
    });

    res.status(201).json({
      success: true,
      service: SERVICE_NAME,
      uid: firebaseUser.uid,
      expiresAt: new Date(expiresAt).toISOString(),
      correlationId: req.headyContext.correlationId,
    });
  } catch (err) {
    circuitBreaker.recordFailure();
    structuredLog('error', `Session creation failed: ${err.message}`, {
      correlationId: req.headyContext.correlationId,
      error: err.message,
    });
    res.status(err.code || 500).json({
      error: err.message,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }
});

// ─── POST /session/verify ─────────────────────────────────────────────────────
// Validates the httpOnly session cookie and checks IP+UA binding
app.post('/session/verify', (req, res) => {
  const startTime = performance.now();
  const cookieHeader = req.headers.cookie || '';
  const cookies = Object.fromEntries(
    cookieHeader.split(';').map(c => c.trim().split('=')).filter(p => p.length === 2)
  );
  const sessionToken = cookies[COOKIE_NAME];

  if (!sessionToken) {
    return res.status(401).json({
      valid: false,
      error: 'No session cookie present',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const session = sessionStore.get(sessionToken);
  if (!session) {
    return res.status(401).json({
      valid: false,
      error: 'Session not found or expired',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  if (Date.now() > session.expiresAt) {
    sessionStore.delete(sessionToken);
    return res.status(401).json({
      valid: false,
      error: 'Session expired',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const clientHash = computeClientHash(req);
  if (clientHash !== session.clientHash) {
    structuredLog('warn', 'Session replay detected — client hash mismatch', {
      correlationId: req.headyContext.correlationId,
      uid: session.uid,
      expectedHash: session.clientHash,
      actualHash: clientHash,
    });
    sessionStore.delete(sessionToken);
    return res.status(403).json({
      valid: false,
      error: 'Session binding mismatch — possible replay attack',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  session.lastActivity = Date.now();

  structuredLog('info', 'Session verified', {
    correlationId: req.headyContext.correlationId,
    uid: session.uid,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.json({
    valid: true,
    uid: session.uid,
    email: session.email,
    name: session.name,
    expiresAt: new Date(session.expiresAt).toISOString(),
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── POST /session/revoke ─────────────────────────────────────────────────────
app.post('/session/revoke', (req, res) => {
  const cookieHeader = req.headers.cookie || '';
  const cookies = Object.fromEntries(
    cookieHeader.split(';').map(c => c.trim().split('=')).filter(p => p.length === 2)
  );
  const sessionToken = cookies[COOKIE_NAME];
  const { uid } = req.body || {};

  let revoked = 0;

  if (sessionToken && sessionStore.has(sessionToken)) {
    sessionStore.delete(sessionToken);
    revoked++;
  }

  if (uid) {
    for (const [token, session] of sessionStore) {
      if (session.uid === uid) {
        sessionStore.delete(token);
        revoked++;
      }
    }
  }

  res.setHeader('Set-Cookie', [
    `${COOKIE_NAME}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`,
  ]);

  structuredLog('info', 'Session(s) revoked', {
    correlationId: req.headyContext.correlationId,
    uid: uid || 'cookie-based',
    revokedCount: revoked,
  });

  res.json({
    success: true,
    revoked,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /session/info ────────────────────────────────────────────────────────
app.get('/session/info', (req, res) => {
  const cookieHeader = req.headers.cookie || '';
  const cookies = Object.fromEntries(
    cookieHeader.split(';').map(c => c.trim().split('=')).filter(p => p.length === 2)
  );
  const sessionToken = cookies[COOKIE_NAME];

  if (!sessionToken || !sessionStore.has(sessionToken)) {
    return res.status(401).json({
      error: 'No valid session',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const session = sessionStore.get(sessionToken);
  if (Date.now() > session.expiresAt) {
    sessionStore.delete(sessionToken);
    return res.status(401).json({
      error: 'Session expired',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  res.json({
    uid: session.uid,
    email: session.email,
    name: session.name,
    createdAt: new Date(session.createdAt).toISOString(),
    expiresAt: new Date(session.expiresAt).toISOString(),
    lastActivity: new Date(session.lastActivity).toISOString(),
    ttlRemainingMs: session.expiresAt - Date.now(),
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  structuredLog('error', err.message, {
    correlationId: req.headyContext?.correlationId,
    stack: err.stack,
  });
  res.status(err.code || 500).json({
    error: err.message,
    service: SERVICE_NAME,
    correlationId: req.headyContext?.correlationId,
  });
});

// ─── Session Cleanup Interval (Fibonacci-scaled) ─────────────────────────────
setInterval(pruneExpiredSessions, FIB[10] * 1000); // every 89s

// ─── Consul Service Discovery Registration ────────────────────────────────────
async function registerWithConsul() {
  const CONSUL_HOST = process.env.CONSUL_HOST || 'consul';
  const CONSUL_PORT = process.env.CONSUL_PORT || 8500;
  const INSTANCE_ID = process.env.INSTANCE_ID || `${SERVICE_NAME}-${process.pid}`;
  try {
    const registration = {
      ID: INSTANCE_ID,
      Name: SERVICE_NAME,
      Port: parseInt(PORT),
      Tags: ['heady', DOMAIN, 'v1'],
      Meta: { domain: DOMAIN, vector_dim: String(VECTOR_DIM), version: '1.0.0' },
      Check: {
        HTTP: `http://127.0.0.1:${PORT}/health`,
        Interval: '13s',
        Timeout: '5s',
        DeregisterCriticalServiceAfter: '89s',
      },
    };
    structuredLog('info', `Consul registration prepared for ${INSTANCE_ID}`, { consul: `${CONSUL_HOST}:${CONSUL_PORT}` });
  } catch (err) {
    structuredLog('warn', `Consul registration deferred: ${err.message}`);
  }
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  registerWithConsul();
  structuredLog('info', `${SERVICE_NAME} operational on port ${PORT}`, {
    domain: DOMAIN,
    phiTimeout: Math.round(PHI * 1000) + 'ms',
    cslGates: CSL_GATES,
    cookieName: COOKIE_NAME,
    sessionTtlMs: SESSION_TTL_MS,
  });
});

export default app;
