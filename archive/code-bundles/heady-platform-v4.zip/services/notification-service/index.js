/**
 * notification-service — WebSocket + SSE + webhook notification delivery
 * Heady™ Service | Domain: integration | Port: 3398
 * ALL requests enriched by HeadyAutoContext (MANDATORY)
 * In-memory notification queue with Fibonacci max size (233)
 * NO priority/ranking code. Everything concurrent and equal.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
'use strict';

import express from 'express';
import { randomUUID, createHash, createHmac } from 'crypto';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';

// ─── φ-Math Constants (No Magic Numbers) ──────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── Service Config ───────────────────────────────────────────────────────────
const SERVICE_NAME = 'notification-service';
const PORT = process.env.PORT || 3398;
const DOMAIN = 'integration';
const BOOT_TIME = Date.now();
const MAX_QUEUE_SIZE = FIB[12]; // 233
const SESSION_COOKIE = '__Host-heady_session';
const AUTH_SERVICE_URL = process.env.AUTH_SERVICE_URL || 'http://auth-session-server:3397';

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '2mb' }));
app.disable('x-powered-by');

// ─── MANDATORY: HeadyAutoContext Enrichment Middleware ─────────────────────────
app.use((req, res, next) => {
  req.headyContext = {
    service: SERVICE_NAME,
    domain: DOMAIN,
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
    timestamp: Date.now(),
    vectorDim: VECTOR_DIM,
    cslGates: CSL_GATES,
  };
  res.setHeader('X-Heady-Service', SERVICE_NAME);
  res.setHeader('X-Correlation-Id', req.headyContext.correlationId);
  res.setHeader('X-Heady-Domain', DOMAIN);
  next();
});

// ─── OpenTelemetry Distributed Tracing ────────────────────────────────────────
import { trace, context, SpanKind, SpanStatusCode } from '@opentelemetry/api';
const tracer = trace.getTracer(SERVICE_NAME, '1.0.0');

// ─── Bulkhead Pattern ─────────────────────────────────────────────────────────
const BULKHEAD = {
  maxConcurrent: 55,
  queueSize: 89,
  active: 0,
  queued: 0,
};

function bulkheadMiddleware(req, res, next) {
  if (BULKHEAD.active >= BULKHEAD.maxConcurrent) {
    if (BULKHEAD.queued >= BULKHEAD.queueSize) {
      return res.status(503).json({
        error: 'Service at capacity',
        service: SERVICE_NAME,
        bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
      });
    }
    BULKHEAD.queued++;
    setTimeout(() => {
      BULKHEAD.queued--;
      next();
    }, Math.round(PSI * 1000));
    return;
  }
  BULKHEAD.active++;
  res.on('finish', () => { BULKHEAD.active--; });
  next();
}

// ─── OpenTelemetry Span Middleware ────────────────────────────────────────────
function otelSpanMiddleware(req, res, next) {
  const span = tracer.startSpan(`${SERVICE_NAME}:${req.method} ${req.path}`, {
    kind: SpanKind.SERVER,
    attributes: {
      'http.method': req.method,
      'http.url': req.originalUrl,
      'http.route': req.path,
      'heady.service': SERVICE_NAME,
      'heady.domain': DOMAIN,
      'heady.correlation_id': req.headyContext?.correlationId || 'unknown',
      'heady.vector_dim': VECTOR_DIM,
    },
  });
  req.otelSpan = span;
  res.on('finish', () => {
    span.setAttribute('http.status_code', res.statusCode);
    if (res.statusCode >= 400) {
      span.setStatus({ code: SpanStatusCode.ERROR, message: `HTTP ${res.statusCode}` });
    }
    span.end();
  });
  next();
}

// ─── Structured Logging ───────────────────────────────────────────────────────
function structuredLog(level, msg, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    service: SERVICE_NAME,
    level,
    message: msg,
    correlationId: meta.correlationId || 'system',
    domain: DOMAIN,
    ...meta,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── Typed Error Classes ──────────────────────────────────────────────────────
class HeadyServiceError extends Error {
  constructor(message, code, meta = {}) {
    super(message);
    this.name = 'HeadyServiceError';
    this.code = code;
    this.meta = meta;
  }
}

// ─── Circuit Breaker (Fibonacci-based) ────────────────────────────────────────
const circuitBreaker = {
  state: 'closed',
  failures: 0,
  maxFailures: FIB[7],
  resetTimeoutMs: FIB[10] * 1000,
  lastFailure: 0,
  check() {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure > this.resetTimeoutMs) {
        this.state = 'half-open';
        return true;
      }
      return false;
    }
    return true;
  },
  recordSuccess() { this.failures = 0; this.state = 'closed'; },
  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.failures >= this.maxFailures) this.state = 'open';
  },
};

// ─── Notification Store (In-memory, Fibonacci-bounded) ────────────────────────
const notificationStore = new Map(); // userId -> notification[]
const sseClients = new Map();        // userId -> Set<res>
const wsClients = new Map();         // userId -> Set<ws>

function getNotificationsForUser(userId) {
  if (!notificationStore.has(userId)) {
    notificationStore.set(userId, []);
  }
  return notificationStore.get(userId);
}

function addNotification(userId, notification) {
  const list = getNotificationsForUser(userId);
  list.push(notification);
  while (list.length > MAX_QUEUE_SIZE) {
    list.shift();
  }
}

function broadcastToUser(userId, notification) {
  const sseSet = sseClients.get(userId);
  if (sseSet) {
    for (const client of sseSet) {
      client.write(`data: ${JSON.stringify(notification)}\n\n`);
    }
  }
  const wsSet = wsClients.get(userId);
  if (wsSet) {
    for (const ws of wsSet) {
      if (ws.readyState === 1) {
        ws.send(JSON.stringify(notification));
      }
    }
  }
}

// ─── Auth Validation Helper ───────────────────────────────────────────────────
function extractSessionCookie(cookieHeader) {
  if (!cookieHeader) return null;
  const cookies = Object.fromEntries(
    cookieHeader.split(';').map(c => c.trim().split('=')).filter(p => p.length === 2)
  );
  return cookies[SESSION_COOKIE] || null;
}

// ─── Apply Global Middleware ──────────────────────────────────────────────────
app.use(bulkheadMiddleware);
app.use(otelSpanMiddleware);

// ─── Health Endpoints ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    status: 'operational',
    domain: DOMAIN,
    uptime: Math.round((Date.now() - BOOT_TIME) / 1000),
    port: PORT,
    vectorDim: VECTOR_DIM,
    phiVersion: PHI.toFixed(15),
    queueMaxSize: MAX_QUEUE_SIZE,
    activeUsers: notificationStore.size,
    sseClients: [...sseClients.values()].reduce((s, set) => s + set.size, 0),
    wsClients: [...wsClients.values()].reduce((s, set) => s + set.size, 0),
    circuitBreaker: circuitBreaker.state,
    timestamp: new Date().toISOString(),
  });
});

app.get('/healthz', (req, res) => { res.status(200).send('OK'); });
app.get('/health/live', (req, res) => { res.json({ status: 'alive', service: SERVICE_NAME }); });
app.get('/health/ready', (req, res) => { res.json({ status: 'ready', service: SERVICE_NAME, domain: DOMAIN }); });

app.get('/readiness', (req, res) => {
  const ready = circuitBreaker.state !== 'open';
  res.status(ready ? 200 : 503).json({ service: SERVICE_NAME, ready, circuitBreaker: circuitBreaker.state });
});

// ─── Service Info ─────────────────────────────────────────────────────────────
app.get('/info', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    description: 'WebSocket + SSE + webhook notification delivery',
    domain: DOMAIN,
    port: PORT,
    version: '1.0.0',
    phiConstants: { PHI, PSI, cslGates: CSL_GATES },
    maxQueueSize: MAX_QUEUE_SIZE,
    architecture: 'concurrent-equals',
    bootTime: new Date(BOOT_TIME).toISOString(),
  });
});

// ─── POST /notify ─────────────────────────────────────────────────────────────
app.post('/notify', (req, res) => {
  const startTime = performance.now();
  const { userId, type, title, body, data } = req.body || {};

  if (!userId || !type || !title) {
    return res.status(400).json({
      error: 'Missing required fields: userId, type, title',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const notification = {
    id: randomUUID(),
    userId,
    type,
    title,
    body: body || null,
    data: data || {},
    read: false,
    createdAt: new Date().toISOString(),
    correlationId: req.headyContext.correlationId,
  };

  addNotification(userId, notification);
  broadcastToUser(userId, notification);

  structuredLog('info', 'Notification sent', {
    correlationId: req.headyContext.correlationId,
    userId,
    type,
    notificationId: notification.id,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.status(201).json({
    success: true,
    notification,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /stream — SSE Event Stream ───────────────────────────────────────────
app.get('/stream', (req, res) => {
  const userId = req.query.userId;
  if (!userId) {
    return res.status(400).json({ error: 'Missing userId query parameter', service: SERVICE_NAME });
  }

  const sessionCookie = extractSessionCookie(req.headers.cookie);
  if (!sessionCookie) {
    return res.status(401).json({ error: 'No session cookie — authentication required', service: SERVICE_NAME });
  }

  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Heady-Service': SERVICE_NAME,
    'X-Correlation-Id': req.headyContext.correlationId,
  });

  res.write(`data: ${JSON.stringify({ type: 'connected', service: SERVICE_NAME, userId })}\n\n`);

  if (!sseClients.has(userId)) sseClients.set(userId, new Set());
  sseClients.get(userId).add(res);

  structuredLog('info', 'SSE client connected', {
    correlationId: req.headyContext.correlationId,
    userId,
  });

  const heartbeatInterval = setInterval(() => {
    res.write(`: heartbeat ${Date.now()}\n\n`);
  }, FIB[8] * 1000); // 34s heartbeat

  req.on('close', () => {
    clearInterval(heartbeatInterval);
    sseClients.get(userId)?.delete(res);
    if (sseClients.get(userId)?.size === 0) sseClients.delete(userId);
    structuredLog('info', 'SSE client disconnected', { correlationId: req.headyContext.correlationId, userId });
  });
});

// ─── GET /notifications/:userId ───────────────────────────────────────────────
app.get('/notifications/:userId', (req, res) => {
  const { userId } = req.params;
  const { unreadOnly } = req.query;

  let notifications = getNotificationsForUser(userId);
  if (unreadOnly === 'true') {
    notifications = notifications.filter(n => !n.read);
  }

  res.json({
    userId,
    notifications,
    count: notifications.length,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── POST /notifications/mark-read ────────────────────────────────────────────
app.post('/notifications/mark-read', (req, res) => {
  const { userId, notificationIds } = req.body || {};

  if (!userId || !Array.isArray(notificationIds)) {
    return res.status(400).json({
      error: 'Missing userId or notificationIds array',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const idSet = new Set(notificationIds);
  const notifications = getNotificationsForUser(userId);
  let marked = 0;

  for (const n of notifications) {
    if (idSet.has(n.id) && !n.read) {
      n.read = true;
      n.readAt = new Date().toISOString();
      marked++;
    }
  }

  structuredLog('info', 'Notifications marked as read', {
    correlationId: req.headyContext.correlationId,
    userId,
    marked,
    requested: notificationIds.length,
  });

  res.json({
    success: true,
    marked,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  structuredLog('error', err.message, {
    correlationId: req.headyContext?.correlationId,
    stack: err.stack,
  });
  res.status(err.code || 500).json({
    error: err.message,
    service: SERVICE_NAME,
    correlationId: req.headyContext?.correlationId,
  });
});

// ─── HTTP + WebSocket Server ──────────────────────────────────────────────────
const server = createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

wss.on('connection', (ws, req) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  const userId = url.searchParams.get('userId');
  const correlationId = req.headers['x-correlation-id'] || randomUUID();

  if (!userId) {
    ws.close(4000, 'Missing userId query parameter');
    return;
  }

  const cookieHeader = req.headers.cookie || '';
  const sessionCookie = extractSessionCookie(cookieHeader);
  if (!sessionCookie) {
    ws.close(4001, 'No session cookie — authentication required');
    return;
  }

  if (!wsClients.has(userId)) wsClients.set(userId, new Set());
  wsClients.get(userId).add(ws);

  structuredLog('info', 'WebSocket client connected', { correlationId, userId });

  ws.send(JSON.stringify({ type: 'connected', service: SERVICE_NAME, userId, correlationId }));

  ws.on('message', (raw) => {
    const frameCookie = extractSessionCookie(cookieHeader);
    if (!frameCookie) {
      ws.close(4001, 'Session expired — re-authenticate');
      return;
    }

    try {
      const message = JSON.parse(raw.toString());
      structuredLog('info', 'WebSocket message received', {
        correlationId,
        userId,
        messageType: message.type || 'unknown',
      });

      if (message.type === 'ping') {
        ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now(), service: SERVICE_NAME }));
      } else if (message.type === 'mark-read' && Array.isArray(message.notificationIds)) {
        const notifications = getNotificationsForUser(userId);
        const idSet = new Set(message.notificationIds);
        for (const n of notifications) {
          if (idSet.has(n.id)) { n.read = true; n.readAt = new Date().toISOString(); }
        }
        ws.send(JSON.stringify({ type: 'mark-read-ack', marked: message.notificationIds.length }));
      }
    } catch (err) {
      structuredLog('warn', 'Invalid WebSocket message', { correlationId, userId, error: err.message });
    }
  });

  ws.on('close', () => {
    wsClients.get(userId)?.delete(ws);
    if (wsClients.get(userId)?.size === 0) wsClients.delete(userId);
    structuredLog('info', 'WebSocket client disconnected', { correlationId, userId });
  });
});

// ─── Consul Service Discovery Registration ────────────────────────────────────
async function registerWithConsul() {
  const CONSUL_HOST = process.env.CONSUL_HOST || 'consul';
  const CONSUL_PORT = process.env.CONSUL_PORT || 8500;
  const INSTANCE_ID = process.env.INSTANCE_ID || `${SERVICE_NAME}-${process.pid}`;
  try {
    const registration = {
      ID: INSTANCE_ID,
      Name: SERVICE_NAME,
      Port: parseInt(PORT),
      Tags: ['heady', DOMAIN, 'v1', 'websocket', 'sse'],
      Meta: { domain: DOMAIN, vector_dim: String(VECTOR_DIM), version: '1.0.0' },
      Check: {
        HTTP: `http://127.0.0.1:${PORT}/health`,
        Interval: '13s',
        Timeout: '5s',
        DeregisterCriticalServiceAfter: '89s',
      },
    };
    structuredLog('info', `Consul registration prepared for ${INSTANCE_ID}`, { consul: `${CONSUL_HOST}:${CONSUL_PORT}` });
  } catch (err) {
    structuredLog('warn', `Consul registration deferred: ${err.message}`);
  }
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
server.listen(PORT, () => {
  registerWithConsul();
  structuredLog('info', `${SERVICE_NAME} operational on port ${PORT}`, {
    domain: DOMAIN,
    phiTimeout: Math.round(PHI * 1000) + 'ms',
    cslGates: CSL_GATES,
    maxQueueSize: MAX_QUEUE_SIZE,
    transports: ['http', 'sse', 'websocket'],
  });
});

export default app;
