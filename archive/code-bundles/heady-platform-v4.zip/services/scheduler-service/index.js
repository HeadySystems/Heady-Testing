/**
 * scheduler-service — Cron-equivalent with φ-scaled Fibonacci intervals
 * Heady™ Service | Domain: orchestration | Port: 3402
 * ALL requests enriched by HeadyAutoContext (MANDATORY)
 * Job intervals use Fibonacci seconds: 5s, 8s, 13s, 21s, 34s, 55s, 89s, etc.
 * NO priority/ranking code. Everything concurrent and equal.
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 */
'use strict';

import express from 'express';
import { randomUUID } from 'crypto';

// ─── φ-Math Constants (No Magic Numbers) ──────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// Fibonacci interval options in seconds
const FIB_INTERVALS_SEC = [5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];

// ─── Service Config ───────────────────────────────────────────────────────────
const SERVICE_NAME = 'scheduler-service';
const PORT = process.env.PORT || 3402;
const DOMAIN = 'orchestration';
const BOOT_TIME = Date.now();

// ─── Express Setup ────────────────────────────────────────────────────────────
const app = express();
app.use(express.json({ limit: '2mb' }));
app.disable('x-powered-by');

// ─── MANDATORY: HeadyAutoContext Enrichment Middleware ─────────────────────────
app.use((req, res, next) => {
  req.headyContext = {
    service: SERVICE_NAME,
    domain: DOMAIN,
    correlationId: req.headers['x-correlation-id'] || randomUUID(),
    timestamp: Date.now(),
    vectorDim: VECTOR_DIM,
    cslGates: CSL_GATES,
  };
  res.setHeader('X-Heady-Service', SERVICE_NAME);
  res.setHeader('X-Correlation-Id', req.headyContext.correlationId);
  res.setHeader('X-Heady-Domain', DOMAIN);
  next();
});

// ─── OpenTelemetry Distributed Tracing ────────────────────────────────────────
import { trace, context, SpanKind, SpanStatusCode } from '@opentelemetry/api';
const tracer = trace.getTracer(SERVICE_NAME, '1.0.0');

// ─── Bulkhead Pattern ─────────────────────────────────────────────────────────
const BULKHEAD = {
  maxConcurrent: 55,
  queueSize: 89,
  active: 0,
  queued: 0,
};

function bulkheadMiddleware(req, res, next) {
  if (BULKHEAD.active >= BULKHEAD.maxConcurrent) {
    if (BULKHEAD.queued >= BULKHEAD.queueSize) {
      return res.status(503).json({
        error: 'Service at capacity',
        service: SERVICE_NAME,
        bulkhead: { active: BULKHEAD.active, queued: BULKHEAD.queued },
      });
    }
    BULKHEAD.queued++;
    setTimeout(() => { BULKHEAD.queued--; next(); }, Math.round(PSI * 1000));
    return;
  }
  BULKHEAD.active++;
  res.on('finish', () => { BULKHEAD.active--; });
  next();
}

// ─── OpenTelemetry Span Middleware ────────────────────────────────────────────
function otelSpanMiddleware(req, res, next) {
  const span = tracer.startSpan(`${SERVICE_NAME}:${req.method} ${req.path}`, {
    kind: SpanKind.SERVER,
    attributes: {
      'http.method': req.method,
      'http.url': req.originalUrl,
      'http.route': req.path,
      'heady.service': SERVICE_NAME,
      'heady.domain': DOMAIN,
      'heady.correlation_id': req.headyContext?.correlationId || 'unknown',
      'heady.vector_dim': VECTOR_DIM,
    },
  });
  req.otelSpan = span;
  res.on('finish', () => {
    span.setAttribute('http.status_code', res.statusCode);
    if (res.statusCode >= 400) {
      span.setStatus({ code: SpanStatusCode.ERROR, message: `HTTP ${res.statusCode}` });
    }
    span.end();
  });
  next();
}

// ─── Structured Logging ───────────────────────────────────────────────────────
function structuredLog(level, msg, meta = {}) {
  const entry = {
    timestamp: new Date().toISOString(),
    service: SERVICE_NAME,
    level,
    message: msg,
    correlationId: meta.correlationId || 'system',
    domain: DOMAIN,
    ...meta,
  };
  process.stdout.write(JSON.stringify(entry) + '\n');
}

// ─── Typed Error Classes ──────────────────────────────────────────────────────
class HeadyServiceError extends Error {
  constructor(message, code, meta = {}) {
    super(message);
    this.name = 'HeadyServiceError';
    this.code = code;
    this.meta = meta;
  }
}

// ─── Circuit Breaker (Fibonacci-based) ────────────────────────────────────────
const circuitBreaker = {
  state: 'closed',
  failures: 0,
  maxFailures: FIB[7],
  resetTimeoutMs: FIB[10] * 1000,
  lastFailure: 0,
  check() {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailure > this.resetTimeoutMs) { this.state = 'half-open'; return true; }
      return false;
    }
    return true;
  },
  recordSuccess() { this.failures = 0; this.state = 'closed'; },
  recordFailure() {
    this.failures++;
    this.lastFailure = Date.now();
    if (this.failures >= this.maxFailures) this.state = 'open';
  },
};

// ─── Job Registry (In-memory) ─────────────────────────────────────────────────
const jobRegistry = new Map(); // jobId -> job
const jobTimers = new Map();   // jobId -> timer handle
const MAX_JOBS = FIB[12];     // 233

function nearestFibInterval(seconds) {
  let closest = FIB_INTERVALS_SEC[0];
  let minDiff = Math.abs(seconds - closest);
  for (const fib of FIB_INTERVALS_SEC) {
    const diff = Math.abs(seconds - fib);
    if (diff < minDiff) {
      minDiff = diff;
      closest = fib;
    }
  }
  return closest;
}

function executeJob(job) {
  const executionId = randomUUID();
  job.lastRun = Date.now();
  job.runCount++;
  job.lastExecutionId = executionId;

  structuredLog('info', `Job executed: ${job.name}`, {
    jobId: job.id,
    executionId,
    runCount: job.runCount,
    intervalSec: job.intervalSec,
  });

  if (job.webhookUrl) {
    const payload = {
      jobId: job.id,
      executionId,
      name: job.name,
      runCount: job.runCount,
      timestamp: new Date().toISOString(),
      service: SERVICE_NAME,
    };
    structuredLog('info', `Webhook dispatch for job ${job.id}`, {
      jobId: job.id,
      webhookUrl: job.webhookUrl,
      executionId,
    });
  }

  if (job.maxRuns > 0 && job.runCount >= job.maxRuns) {
    stopJob(job.id);
    job.status = 'completed';
    structuredLog('info', `Job completed max runs: ${job.name}`, {
      jobId: job.id,
      maxRuns: job.maxRuns,
    });
  }
}

function startJob(job) {
  if (jobTimers.has(job.id)) {
    clearInterval(jobTimers.get(job.id));
  }
  const timer = setInterval(() => executeJob(job), job.intervalSec * 1000);
  jobTimers.set(job.id, timer);
  job.status = 'active';
  structuredLog('info', `Job started: ${job.name}`, {
    jobId: job.id,
    intervalSec: job.intervalSec,
  });
}

function stopJob(jobId) {
  const timer = jobTimers.get(jobId);
  if (timer) {
    clearInterval(timer);
    jobTimers.delete(jobId);
  }
  const job = jobRegistry.get(jobId);
  if (job && job.status === 'active') {
    job.status = 'paused';
  }
}

// ─── Apply Global Middleware ──────────────────────────────────────────────────
app.use(bulkheadMiddleware);
app.use(otelSpanMiddleware);

// ─── Health Endpoints ─────────────────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    status: 'operational',
    domain: DOMAIN,
    uptime: Math.round((Date.now() - BOOT_TIME) / 1000),
    port: PORT,
    vectorDim: VECTOR_DIM,
    phiVersion: PHI.toFixed(15),
    activeJobs: [...jobRegistry.values()].filter(j => j.status === 'active').length,
    totalJobs: jobRegistry.size,
    circuitBreaker: circuitBreaker.state,
    timestamp: new Date().toISOString(),
  });
});

app.get('/healthz', (req, res) => { res.status(200).send('OK'); });
app.get('/health/live', (req, res) => { res.json({ status: 'alive', service: SERVICE_NAME }); });
app.get('/health/ready', (req, res) => { res.json({ status: 'ready', service: SERVICE_NAME, domain: DOMAIN }); });

app.get('/readiness', (req, res) => {
  const ready = circuitBreaker.state !== 'open';
  res.status(ready ? 200 : 503).json({ service: SERVICE_NAME, ready, circuitBreaker: circuitBreaker.state });
});

// ─── Service Info ─────────────────────────────────────────────────────────────
app.get('/info', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    description: 'Cron-equivalent with Fibonacci-scaled intervals',
    domain: DOMAIN,
    port: PORT,
    version: '1.0.0',
    phiConstants: { PHI, PSI, cslGates: CSL_GATES },
    fibIntervalsSec: FIB_INTERVALS_SEC,
    maxJobs: MAX_JOBS,
    architecture: 'concurrent-equals',
    bootTime: new Date(BOOT_TIME).toISOString(),
  });
});

// ─── POST /jobs — Create a Scheduled Job ──────────────────────────────────────
app.post('/jobs', (req, res) => {
  const startTime = performance.now();
  const { name, intervalSec, webhookUrl, payload, maxRuns, autoStart } = req.body || {};

  if (!name) {
    return res.status(400).json({
      error: 'Missing required field: name',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  if (!intervalSec || intervalSec < 1) {
    return res.status(400).json({
      error: 'Missing or invalid intervalSec (must be >= 1)',
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  if (jobRegistry.size >= MAX_JOBS) {
    return res.status(429).json({
      error: `Maximum job limit reached (${MAX_JOBS})`,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  const fibInterval = nearestFibInterval(intervalSec);
  const jobId = randomUUID();

  const job = {
    id: jobId,
    name,
    intervalSec: fibInterval,
    requestedIntervalSec: intervalSec,
    webhookUrl: webhookUrl || null,
    payload: payload || {},
    maxRuns: maxRuns || 0,
    runCount: 0,
    status: 'created',
    lastRun: null,
    lastExecutionId: null,
    createdAt: Date.now(),
    correlationId: req.headyContext.correlationId,
  };

  jobRegistry.set(jobId, job);

  if (autoStart !== false) {
    startJob(job);
  }

  structuredLog('info', 'Job created', {
    correlationId: req.headyContext.correlationId,
    jobId,
    name,
    intervalSec: fibInterval,
    requestedIntervalSec: intervalSec,
    latencyMs: Math.round(performance.now() - startTime),
  });

  res.status(201).json({
    success: true,
    job: {
      id: job.id,
      name: job.name,
      intervalSec: job.intervalSec,
      requestedIntervalSec: job.requestedIntervalSec,
      fibonacciSnapped: intervalSec !== fibInterval,
      status: job.status,
      maxRuns: job.maxRuns,
      createdAt: new Date(job.createdAt).toISOString(),
    },
    availableIntervals: FIB_INTERVALS_SEC,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── GET /jobs — List All Jobs ────────────────────────────────────────────────
app.get('/jobs', (req, res) => {
  const { status } = req.query;
  let jobs = [...jobRegistry.values()];

  if (status) {
    jobs = jobs.filter(j => j.status === status);
  }

  res.json({
    jobs: jobs.map(j => ({
      id: j.id,
      name: j.name,
      intervalSec: j.intervalSec,
      status: j.status,
      runCount: j.runCount,
      maxRuns: j.maxRuns,
      lastRun: j.lastRun ? new Date(j.lastRun).toISOString() : null,
      createdAt: new Date(j.createdAt).toISOString(),
    })),
    total: jobs.length,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── DELETE /jobs/:jobId — Remove Job ─────────────────────────────────────────
app.delete('/jobs/:jobId', (req, res) => {
  const { jobId } = req.params;
  const job = jobRegistry.get(jobId);

  if (!job) {
    return res.status(404).json({
      error: 'Job not found',
      jobId,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  stopJob(jobId);
  jobRegistry.delete(jobId);

  structuredLog('info', 'Job deleted', {
    correlationId: req.headyContext.correlationId,
    jobId,
    name: job.name,
  });

  res.json({
    success: true,
    deleted: jobId,
    name: job.name,
    totalJobs: jobRegistry.size,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── POST /jobs/:jobId/trigger — Manually Trigger Job ────────────────────────
app.post('/jobs/:jobId/trigger', (req, res) => {
  const { jobId } = req.params;
  const job = jobRegistry.get(jobId);

  if (!job) {
    return res.status(404).json({
      error: 'Job not found',
      jobId,
      service: SERVICE_NAME,
      correlationId: req.headyContext.correlationId,
    });
  }

  executeJob(job);

  res.json({
    success: true,
    triggered: true,
    jobId,
    name: job.name,
    executionId: job.lastExecutionId,
    runCount: job.runCount,
    service: SERVICE_NAME,
    correlationId: req.headyContext.correlationId,
  });
});

// ─── Error Handler ────────────────────────────────────────────────────────────
app.use((err, req, res, _next) => {
  structuredLog('error', err.message, {
    correlationId: req.headyContext?.correlationId,
    stack: err.stack,
  });
  res.status(err.code || 500).json({
    error: err.message,
    service: SERVICE_NAME,
    correlationId: req.headyContext?.correlationId,
  });
});

// ─── Consul Service Discovery Registration ────────────────────────────────────
async function registerWithConsul() {
  const CONSUL_HOST = process.env.CONSUL_HOST || 'consul';
  const CONSUL_PORT = process.env.CONSUL_PORT || 8500;
  const INSTANCE_ID = process.env.INSTANCE_ID || `${SERVICE_NAME}-${process.pid}`;
  try {
    const registration = {
      ID: INSTANCE_ID,
      Name: SERVICE_NAME,
      Port: parseInt(PORT),
      Tags: ['heady', DOMAIN, 'v1', 'scheduler', 'fibonacci'],
      Meta: { domain: DOMAIN, vector_dim: String(VECTOR_DIM), version: '1.0.0' },
      Check: {
        HTTP: `http://127.0.0.1:${PORT}/health`,
        Interval: '13s',
        Timeout: '5s',
        DeregisterCriticalServiceAfter: '89s',
      },
    };
    structuredLog('info', `Consul registration prepared for ${INSTANCE_ID}`, { consul: `${CONSUL_HOST}:${CONSUL_PORT}` });
  } catch (err) {
    structuredLog('warn', `Consul registration deferred: ${err.message}`);
  }
}

// ─── Boot ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  registerWithConsul();
  structuredLog('info', `${SERVICE_NAME} operational on port ${PORT}`, {
    domain: DOMAIN,
    phiTimeout: Math.round(PHI * 1000) + 'ms',
    cslGates: CSL_GATES,
    fibIntervalsSec: FIB_INTERVALS_SEC,
    maxJobs: MAX_JOBS,
  });
});

export default app;
