/**
 * vector-ops.test.js — Vector operations test suite
 * Heady™ Platform | Tests
 * Validates cosine similarity, normalization, embedding dimensions, HNSW recall, RRF fusion
 * Run: node tests/vector-ops.test.js
 */
'use strict';

// ─── φ-Math Constants (No Magic Numbers) ────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── HNSW/Search Constants (φ-derived) ──────────────────────────────────────
const HNSW_M = FIB[5];             // 8 connections per node
const HNSW_EF_CONSTRUCTION = FIB[9]; // 55
const RRF_K = FIB[9];              // 55 (Reciprocal Rank Fusion constant)
const BM25_K1 = PSI + PSI2;        // ≈ 1.0
const BM25_B = PSI;                // ≈ 0.618

// ─── Test Runner ─────────────────────────────────────────────────────────────
let passed = 0, failed = 0;
function assert(condition, msg) {
  if (condition) { passed++; process.stdout.write(JSON.stringify({ test: msg, status: 'pass' }) + '\n'); }
  else { failed++; process.stdout.write(JSON.stringify({ test: msg, status: 'FAIL' }) + '\n'); }
}
function assertClose(a, b, epsilon, msg) { assert(Math.abs(a - b) < epsilon, msg); }

const EPSILON = 1e-10;
const LOOSE_EPSILON = 1e-6;

// ─── Vector Operations ──────────────────────────────────────────────────────
function dotProduct(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i] * b[i];
  return sum;
}

function magnitude(v) {
  return Math.sqrt(dotProduct(v, v));
}

function normalize(v) {
  const mag = magnitude(v);
  if (mag === 0) return v.slice();
  return v.map(x => x / mag);
}

function cosineSimilarity(a, b) {
  const magA = magnitude(a);
  const magB = magnitude(b);
  if (magA === 0 || magB === 0) return 0;
  return dotProduct(a, b) / (magA * magB);
}

function euclideanDistance(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += (a[i] - b[i]) * (a[i] - b[i]);
  return Math.sqrt(sum);
}

// ─── HNSW Recall Simulation ─────────────────────────────────────────────────
function simulateHnswRecall(efSearch, numNeighbors, datasetSize) {
  // Recall approximation: recall improves with ef_search relative to k
  // Using sigmoid with φ-scaled steepness
  const ratio = efSearch / numNeighbors;
  const steepness = PHI;
  return 1 / (1 + Math.exp(-steepness * (ratio - PHI)));
}

// ─── RRF Fusion Scoring ─────────────────────────────────────────────────────
function rrfScore(ranks, k) {
  let score = 0;
  for (const rank of ranks) {
    score += 1 / (k + rank);
  }
  return score;
}

function hybridSearch(bm25Results, vectorResults, k) {
  const scores = new Map();

  for (let i = 0; i < bm25Results.length; i++) {
    const docId = bm25Results[i];
    const current = scores.get(docId) || { bm25Rank: null, vectorRank: null, rrfScore: 0 };
    current.bm25Rank = i + 1;
    current.rrfScore += 1 / (k + i + 1);
    scores.set(docId, current);
  }

  for (let i = 0; i < vectorResults.length; i++) {
    const docId = vectorResults[i];
    const current = scores.get(docId) || { bm25Rank: null, vectorRank: null, rrfScore: 0 };
    current.vectorRank = i + 1;
    current.rrfScore += 1 / (k + i + 1);
    scores.set(docId, current);
  }

  return Array.from(scores.entries())
    .sort((a, b) => b[1].rrfScore - a[1].rrfScore)
    .map(([docId, data]) => ({ docId, ...data }));
}

// ─── Helper: Create Test Vectors ─────────────────────────────────────────────
function createDeterministicVector(dim, seed) {
  const v = [];
  for (let i = 0; i < dim; i++) {
    v.push(Math.sin((i + 1) * seed * PHI) * Math.cos(i * seed * PSI));
  }
  return v;
}

function createUnitVector(dim, index) {
  const v = new Array(dim).fill(0);
  v[index] = 1;
  return v;
}

// ─── Cosine Similarity Tests ─────────────────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'Cosine Similarity' }) + '\n');

// Identical normalized vectors → 1.0
const v1 = normalize(createDeterministicVector(VECTOR_DIM, 1));
assertClose(cosineSimilarity(v1, v1), 1.0, LOOSE_EPSILON,
  'Cosine similarity of identical normalized vectors === 1.0');

// Orthogonal vectors → 0.0
const orthoA = createUnitVector(VECTOR_DIM, 0);
const orthoB = createUnitVector(VECTOR_DIM, 1);
assertClose(cosineSimilarity(orthoA, orthoB), 0.0, EPSILON,
  'Cosine similarity of orthogonal vectors === 0.0');

// Anti-parallel → -1.0
const antiA = createUnitVector(VECTOR_DIM, 0);
const antiB = antiA.map(x => -x);
assertClose(cosineSimilarity(antiA, antiB), -1.0, EPSILON,
  'Cosine similarity of anti-parallel vectors === -1.0');

// Scale invariance
const v2 = createDeterministicVector(VECTOR_DIM, 2);
const v2Scaled = v2.map(x => x * PHI * PHI);
assertClose(cosineSimilarity(v2, v2Scaled), 1.0, LOOSE_EPSILON,
  'Cosine similarity is scale-invariant');

// Symmetry
const v3 = createDeterministicVector(VECTOR_DIM, 3);
assertClose(cosineSimilarity(v1, v3), cosineSimilarity(v3, v1), EPSILON,
  'Cosine similarity is symmetric');

// Bounded range [-1, 1]
const sim13 = cosineSimilarity(v1, v3);
assert(sim13 >= -1 - EPSILON && sim13 <= 1 + EPSILON,
  `Cosine similarity bounded [-1, 1]: ${sim13.toFixed(6)}`);

// Triangle inequality for angular distance
const v4 = createDeterministicVector(VECTOR_DIM, 4);
const angle12 = Math.acos(Math.max(-1, Math.min(1, cosineSimilarity(normalize(v1), normalize(v3)))));
const angle23 = Math.acos(Math.max(-1, Math.min(1, cosineSimilarity(normalize(v3), normalize(v4)))));
const angle13 = Math.acos(Math.max(-1, Math.min(1, cosineSimilarity(normalize(v1), normalize(v4)))));
assert(angle13 <= angle12 + angle23 + LOOSE_EPSILON,
  'Angular distance satisfies triangle inequality');

// ─── Vector Normalization Tests ──────────────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'Vector Normalization' }) + '\n');

const rawVec = createDeterministicVector(VECTOR_DIM, 5);
const normVec = normalize(rawVec);

assertClose(magnitude(normVec), 1.0, LOOSE_EPSILON,
  'Normalized vector has unit length');

// Normalizing a normalized vector is idempotent
const doubleNorm = normalize(normVec);
assertClose(magnitude(doubleNorm), 1.0, LOOSE_EPSILON,
  'Double normalization is idempotent');

for (let i = 0; i < VECTOR_DIM; i++) {
  if (Math.abs(normVec[i] - doubleNorm[i]) > LOOSE_EPSILON) {
    assert(false, 'Double normalization preserves all components');
    break;
  }
  if (i === VECTOR_DIM - 1) assert(true, 'Double normalization preserves all components');
}

// Direction preserved after normalization
assertClose(cosineSimilarity(rawVec, normVec), 1.0, LOOSE_EPSILON,
  'Normalization preserves direction');

// Zero vector normalization returns zero vector
const zeroVec = new Array(VECTOR_DIM).fill(0);
const normZero = normalize(zeroVec);
assertClose(magnitude(normZero), 0.0, EPSILON,
  'Zero vector normalization returns zero vector');

// Large magnitude vector normalizes correctly
const largeVec = rawVec.map(x => x * FIB[15]); // scale by 987
assertClose(magnitude(normalize(largeVec)), 1.0, LOOSE_EPSILON,
  'Large magnitude vector normalizes to unit length');

// Small magnitude vector normalizes correctly
const smallVec = rawVec.map(x => x * 1e-8);
assertClose(magnitude(normalize(smallVec)), 1.0, LOOSE_EPSILON,
  'Small magnitude vector normalizes to unit length');

// ─── Embedding Dimension Validation Tests ────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'Embedding Dimension Validation' }) + '\n');

assert(VECTOR_DIM === 384,
  'VECTOR_DIM === 384');

// Validate vectors are created at correct dimension
const testEmbed = createDeterministicVector(VECTOR_DIM, 7);
assert(testEmbed.length === VECTOR_DIM,
  `Test embedding has ${VECTOR_DIM} dimensions`);

// Dimension mismatch detection
function validateDimension(v, expectedDim) {
  return v.length === expectedDim;
}

assert(validateDimension(testEmbed, VECTOR_DIM) === true,
  '384-d vector passes dimension validation');

const wrongDim = createDeterministicVector(VECTOR_DIM - 1, 8);
assert(validateDimension(wrongDim, VECTOR_DIM) === false,
  '383-d vector fails dimension validation');

const overDim = createDeterministicVector(VECTOR_DIM + 1, 9);
assert(validateDimension(overDim, VECTOR_DIM) === false,
  '385-d vector fails dimension validation');

// All components are finite numbers
const finiteCheck = testEmbed.every(x => Number.isFinite(x));
assert(finiteCheck,
  'All embedding components are finite numbers');

// No NaN values
const nanCheck = testEmbed.every(x => !Number.isNaN(x));
assert(nanCheck,
  'No NaN values in embedding');

// ─── HNSW Recall Tests ──────────────────────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'HNSW Recall' }) + '\n');

// Higher ef_search → higher recall
const recallLow = simulateHnswRecall(FIB[5], FIB[4], FIB[14]);     // ef=8, k=5
const recallMed = simulateHnswRecall(FIB[7], FIB[4], FIB[14]);     // ef=21, k=5
const recallHigh = simulateHnswRecall(FIB[9], FIB[4], FIB[14]);    // ef=55, k=5

assert(recallMed > recallLow,
  `Recall at ef=${FIB[7]} > ef=${FIB[5]} (${recallMed.toFixed(4)} > ${recallLow.toFixed(4)})`);
assert(recallHigh > recallMed,
  `Recall at ef=${FIB[9]} > ef=${FIB[7]} (${recallHigh.toFixed(4)} > ${recallMed.toFixed(4)})`);

// High ef_search approaches perfect recall
const recallVeryHigh = simulateHnswRecall(FIB[11], FIB[4], FIB[14]); // ef=144, k=5
assert(recallVeryHigh > 0.9,
  `Recall at ef=${FIB[11]} > 0.9 (${recallVeryHigh.toFixed(4)})`);

// Recall bounded [0, 1]
assert(recallLow >= 0 && recallLow <= 1,
  'Recall bounded [0, 1] at low ef');
assert(recallHigh >= 0 && recallHigh <= 1,
  'Recall bounded [0, 1] at high ef');

// HNSW M parameter is Fibonacci
assert(HNSW_M === FIB[5],
  `HNSW_M === FIB[5] = ${FIB[5]}`);
assert(HNSW_EF_CONSTRUCTION === FIB[9],
  `HNSW_EF_CONSTRUCTION === FIB[9] = ${FIB[9]}`);

// ─── Hybrid Search RRF Fusion Tests ─────────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'Hybrid Search RRF Fusion' }) + '\n');

// Basic RRF scoring
assertClose(rrfScore([1], RRF_K), 1 / (RRF_K + 1), EPSILON,
  `RRF score for rank 1 === 1/(${RRF_K}+1)`);

// Multiple ranks accumulate
const multiRrf = rrfScore([1, 3], RRF_K);
const expectedMulti = 1 / (RRF_K + 1) + 1 / (RRF_K + 3);
assertClose(multiRrf, expectedMulti, EPSILON,
  'RRF score accumulates across multiple rank lists');

// Higher rank → higher score
assert(rrfScore([1], RRF_K) > rrfScore([2], RRF_K),
  'Rank 1 scores higher than rank 2');

// RRF K constant is Fibonacci
assert(RRF_K === FIB[9],
  `RRF_K === FIB[9] = ${FIB[9]}`);

// Hybrid search: document appearing in both lists ranks highest
const bm25Results = ['doc-a', 'doc-b', 'doc-c', 'doc-d', 'doc-e'];
const vectorResults = ['doc-c', 'doc-a', 'doc-f', 'doc-g', 'doc-h'];
const hybridResults = hybridSearch(bm25Results, vectorResults, RRF_K);

const docAScore = hybridResults.find(r => r.docId === 'doc-a');
const docBScore = hybridResults.find(r => r.docId === 'doc-b');
assert(docAScore.rrfScore > docBScore.rrfScore,
  'Doc in both lists (doc-a) scores higher than doc in one list (doc-b)');

// Doc-c appears in both (rank 3 in BM25, rank 1 in vector)
const docCScore = hybridResults.find(r => r.docId === 'doc-c');
assert(docCScore.bm25Rank === 3 && docCScore.vectorRank === 1,
  'doc-c has correct ranks in both lists');

// Results are sorted by descending RRF score
for (let i = 1; i < hybridResults.length; i++) {
  assert(hybridResults[i].rrfScore <= hybridResults[i - 1].rrfScore,
    `Hybrid results sorted: position ${i - 1} >= position ${i}`);
}

// Documents appearing in both lists should be at the top
const docsInBothLists = hybridResults.filter(r => r.bm25Rank !== null && r.vectorRank !== null);
const docsInOneList = hybridResults.filter(r => r.bm25Rank === null || r.vectorRank === null);
if (docsInBothLists.length > 0 && docsInOneList.length > 0) {
  assert(docsInBothLists[docsInBothLists.length - 1].rrfScore >= docsInOneList[0].rrfScore,
    'All dual-list docs score >= single-list docs');
}

// BM25 constants are φ-derived
assertClose(BM25_K1, PSI + PSI2, EPSILON,
  `BM25_K1 === PSI + PSI² ≈ ${(PSI + PSI2).toFixed(6)}`);
assertClose(BM25_B, PSI, EPSILON,
  `BM25_B === PSI ≈ ${PSI.toFixed(6)}`);

// ─── Euclidean Distance Tests ────────────────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'Euclidean Distance' }) + '\n');

// Distance to self is 0
assertClose(euclideanDistance(v1, v1), 0.0, EPSILON,
  'Euclidean distance to self === 0');

// Symmetry
const distAB = euclideanDistance(v1, v3);
const distBA = euclideanDistance(v3, v1);
assertClose(distAB, distBA, EPSILON,
  'Euclidean distance is symmetric');

// Non-negative
assert(euclideanDistance(v1, v3) >= 0,
  'Euclidean distance is non-negative');

// Triangle inequality
const dist12 = euclideanDistance(v1, v3);
const dist23 = euclideanDistance(v3, v4);
const dist13 = euclideanDistance(v1, v4);
assert(dist13 <= dist12 + dist23 + LOOSE_EPSILON,
  'Euclidean distance satisfies triangle inequality');

// Normalized vectors: distance related to cosine similarity
// ||a - b||² = 2 - 2*cos(θ) for unit vectors
const normV1 = normalize(v1);
const normV3 = normalize(v3);
const distNorm = euclideanDistance(normV1, normV3);
const expectedDist = Math.sqrt(2 - 2 * cosineSimilarity(normV1, normV3));
assertClose(distNorm, expectedDist, LOOSE_EPSILON,
  'Euclidean distance of unit vectors related to cosine similarity');

// ─── Summary ─────────────────────────────────────────────────────────────────
process.stdout.write('\n' + JSON.stringify({
  suite: 'vector-ops',
  passed,
  failed,
  total: passed + failed,
  status: failed === 0 ? 'ALL PASS' : 'FAILURES',
}) + '\n');

process.exit(failed > 0 ? 1 : 0);
