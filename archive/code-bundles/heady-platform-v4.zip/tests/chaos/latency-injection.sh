#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# latency-injection.sh — Chaos engineering: latency injection with tc
# Heady™ Platform | Chaos Tests
# Uses traffic control (tc) to inject Fibonacci-staged latency
# Verifies circuit breakers trigger and services recover
# All numeric constants derived from φ (1.618033988749895) or Fibonacci
# Run: bash tests/chaos/latency-injection.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

# ─── φ-Math Constants ────────────────────────────────────────────────────────
PHI="1.618033988749895"
PSI="0.618033988749895"
# Fibonacci sequence: 1,1,2,3,5,8,13,21,34,55,89,144,233,377,610,987,1597
FIB_3=3
FIB_4=5
FIB_5=8
FIB_6=13
FIB_7=21
FIB_8=34
FIB_9=55
FIB_10=89
FIB_12=233
FIB_14=610
FIB_LATENCY_1618=1618   # ≈ PHI * 1000

# Fibonacci-staged latency tiers (ms)
LATENCY_STAGES=("$FIB_10" "$FIB_12" "$FIB_14" "$FIB_LATENCY_1618")
# Corresponding labels
LATENCY_LABELS=("89ms" "233ms" "610ms" "1618ms")

# ─── Config ──────────────────────────────────────────────────────────────────
NETWORK="${HEADY_NETWORK:-heady-mesh}"
STAGE_DURATION_S=$FIB_5            # 8 seconds per latency stage
HEALTH_TIMEOUT_S=$FIB_3            # 3 seconds
RECOVERY_WAIT_S=$FIB_4             # 5 seconds
MAX_RETRIES=$FIB_4                 # 5 retries
RETRY_DELAY_S=$FIB_3               # 3 seconds
CIRCUIT_BREAKER_THRESHOLD=$FIB_7   # 21 failures (matches service config)
CIRCUIT_BREAKER_RESET_S=$FIB_10    # 89 seconds

# ─── Structured Output ───────────────────────────────────────────────────────
log_json() {
  local level="$1" msg="$2"
  shift 2
  printf '{"timestamp":"%s","level":"%s","suite":"latency-injection","msg":"%s"%s}\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$level" "$msg" "$*"
}

# ─── Get Running Heady Containers ────────────────────────────────────────────
get_heady_containers() {
  docker ps --format '{{.Names}}' --filter "network=${NETWORK}" 2>/dev/null || true
}

# ─── Health Check with Timing ─────────────────────────────────────────────────
check_health_timed() {
  local container="$1"
  local port
  port=$(docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}}{{(index $conf 0).HostPort}}{{end}}' "$container" 2>/dev/null | head -1)
  if [ -z "$port" ]; then
    printf '{"status":"error","code":"no-port","durationMs":0}'
    return 1
  fi

  local start_ms end_ms duration_ms status
  start_ms=$(date +%s%3N)
  status=$(curl -s -o /dev/null -w '%{http_code}' --max-time "$HEALTH_TIMEOUT_S" "http://localhost:${port}/health" 2>/dev/null || echo "000")
  end_ms=$(date +%s%3N)
  duration_ms=$((end_ms - start_ms))

  printf '{"status":"%s","code":"%s","durationMs":%d}' \
    "$([ "$status" = "200" ] && echo "healthy" || echo "degraded")" "$status" "$duration_ms"
  [ "$status" = "200" ]
}

# ─── Inject Latency via tc ────────────────────────────────────────────────────
inject_latency() {
  local container="$1" latency_ms="$2"
  # Get container PID for nsenter
  local pid
  pid=$(docker inspect --format '{{.State.Pid}}' "$container" 2>/dev/null)
  if [ -z "$pid" ] || [ "$pid" = "0" ]; then
    log_json "error" "cannot-get-pid" ",\"container\":\"$container\""
    return 1
  fi

  # Add latency using tc qdisc netem inside container network namespace
  nsenter -t "$pid" -n tc qdisc add dev eth0 root netem delay "${latency_ms}ms" 2>/dev/null || \
    nsenter -t "$pid" -n tc qdisc change dev eth0 root netem delay "${latency_ms}ms" 2>/dev/null || \
    docker exec "$container" tc qdisc add dev eth0 root netem delay "${latency_ms}ms" 2>/dev/null || \
    docker exec "$container" tc qdisc change dev eth0 root netem delay "${latency_ms}ms" 2>/dev/null
}

# ─── Remove Latency ──────────────────────────────────────────────────────────
remove_latency() {
  local container="$1"
  local pid
  pid=$(docker inspect --format '{{.State.Pid}}' "$container" 2>/dev/null)
  if [ -n "$pid" ] && [ "$pid" != "0" ]; then
    nsenter -t "$pid" -n tc qdisc del dev eth0 root 2>/dev/null || true
  fi
  docker exec "$container" tc qdisc del dev eth0 root 2>/dev/null || true
}

# ─── Verify Circuit Breaker Behavior ─────────────────────────────────────────
verify_circuit_breaker() {
  local container="$1" latency_ms="$2"
  local port
  port=$(docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}}{{(index $conf 0).HostPort}}{{end}}' "$container" 2>/dev/null | head -1)
  if [ -z "$port" ]; then
    log_json "warn" "skip-circuit-breaker-check" ",\"reason\":\"no-port\""
    return 0
  fi

  # With high latency, requests should fail fast (circuit breaker open) rather than timeout
  local start_ms end_ms duration_ms status
  start_ms=$(date +%s%3N)
  status=$(curl -s -o /dev/null -w '%{http_code}' --max-time "$FIB_5" "http://localhost:${port}/health" 2>/dev/null || echo "000")
  end_ms=$(date +%s%3N)
  duration_ms=$((end_ms - start_ms))

  if [ "$latency_ms" -ge "$FIB_LATENCY_1618" ]; then
    # At 1618ms+ latency, circuit breaker should eventually open
    # Requests should either succeed slowly or fail fast (not hang)
    if [ "$duration_ms" -lt "$((latency_ms * 3))" ]; then
      log_json "pass" "circuit-breaker-responsive" ",\"container\":\"$container\",\"latencyMs\":$latency_ms,\"responseDurationMs\":$duration_ms"
      return 0
    else
      log_json "FAIL" "circuit-breaker-slow" ",\"container\":\"$container\",\"latencyMs\":$latency_ms,\"responseDurationMs\":$duration_ms"
      return 1
    fi
  fi
  return 0
}

# ─── Main Latency Injection Test ─────────────────────────────────────────────
run_latency_test() {
  local containers
  containers=$(get_heady_containers)

  if [ -z "$containers" ]; then
    log_json "error" "no-containers-found" ",\"network\":\"$NETWORK\""
    exit 1
  fi

  # Select a random container
  local target
  target=$(echo "$containers" | shuf -n 1)

  local container_count
  container_count=$(echo "$containers" | wc -l)
  log_json "info" "test-start" ",\"target\":\"$target\",\"containerCount\":$container_count,\"stages\":\"${LATENCY_LABELS[*]}\""

  # Verify healthy baseline
  local baseline
  baseline=$(check_health_timed "$target")
  log_json "info" "baseline-health" ",\"container\":\"$target\",\"result\":$baseline"

  # ─── Fibonacci-Staged Latency Injection ─────────────────────────────────
  local stage_idx=0
  local test_passed=true

  for latency_ms in "${LATENCY_STAGES[@]}"; do
    local label="${LATENCY_LABELS[$stage_idx]}"
    log_json "info" "stage-start" ",\"stage\":$stage_idx,\"latency\":\"$label\",\"durationS\":$STAGE_DURATION_S"

    # Inject latency
    if inject_latency "$target" "$latency_ms"; then
      log_json "info" "latency-injected" ",\"container\":\"$target\",\"latencyMs\":$latency_ms"
    else
      log_json "warn" "latency-injection-failed" ",\"container\":\"$target\",\"latencyMs\":$latency_ms"
      stage_idx=$((stage_idx + 1))
      continue
    fi

    # Wait for latency to take effect
    sleep "$FIB_3"

    # Check health under latency
    local health_result
    health_result=$(check_health_timed "$target")
    log_json "info" "health-under-latency" ",\"container\":\"$target\",\"latency\":\"$label\",\"result\":$health_result"

    # Verify circuit breaker at high latency
    if ! verify_circuit_breaker "$target" "$latency_ms"; then
      test_passed=false
    fi

    # Wait remainder of stage
    local remaining=$((STAGE_DURATION_S - FIB_3))
    [ "$remaining" -gt 0 ] && sleep "$remaining"

    stage_idx=$((stage_idx + 1))
  done

  # ─── Remove Latency ─────────────────────────────────────────────────────
  log_json "info" "removing-latency" ",\"container\":\"$target\""
  remove_latency "$target"

  # ─── Verify Recovery ────────────────────────────────────────────────────
  log_json "info" "phase-recovery" ",\"waitS\":$RECOVERY_WAIT_S"
  sleep "$RECOVERY_WAIT_S"

  local recovery_result
  recovery_result=$(check_health_timed "$target")
  log_json "info" "recovery-health" ",\"container\":\"$target\",\"result\":$recovery_result"

  # Retry health check if first attempt fails
  if ! echo "$recovery_result" | grep -q '"status":"healthy"'; then
    local retries=0
    while [ "$retries" -lt "$MAX_RETRIES" ]; do
      sleep "$RETRY_DELAY_S"
      recovery_result=$(check_health_timed "$target")
      if echo "$recovery_result" | grep -q '"status":"healthy"'; then
        break
      fi
      retries=$((retries + 1))
    done
  fi

  if echo "$recovery_result" | grep -q '"status":"healthy"'; then
    log_json "pass" "service-recovered" ",\"container\":\"$target\""
  else
    log_json "FAIL" "service-not-recovered" ",\"container\":\"$target\",\"result\":$recovery_result"
    test_passed=false
  fi

  # Final result
  if [ "$test_passed" = true ]; then
    log_json "info" "test-complete" ",\"result\":\"pass\",\"stages\":${#LATENCY_STAGES[@]}"
  else
    log_json "info" "test-complete" ",\"result\":\"fail\",\"stages\":${#LATENCY_STAGES[@]}"
    exit 1
  fi
}

# ─── Execute ──────────────────────────────────────────────────────────────────
run_latency_test
