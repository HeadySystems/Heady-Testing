#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# network-partition.sh — Chaos engineering: network partition simulation
# Heady™ Platform | Chaos Tests
# Uses docker network disconnect/connect to simulate network partitions
# All numeric constants derived from φ (1.618033988749895) or Fibonacci
# Run: bash tests/chaos/network-partition.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

# ─── φ-Math Constants ────────────────────────────────────────────────────────
PHI="1.618033988749895"
PSI="0.618033988749895"
# Fibonacci sequence: 1,1,2,3,5,8,13,21,34,55,89
FIB_3=3
FIB_4=5
FIB_5=8
FIB_6=13
FIB_7=21
FIB_8=34
FIB_9=55

# ─── Config ──────────────────────────────────────────────────────────────────
NETWORK="${HEADY_NETWORK:-heady-mesh}"
PARTITION_DURATION_S=$FIB_5       # 8 seconds (≈ φ * 5)
RECOVERY_WAIT_S=$FIB_4            # 5 seconds
HEALTH_TIMEOUT_S=$FIB_3           # 3 seconds
MAX_RETRIES=$FIB_4                # 5 retries for health checks
RETRY_DELAY_S=$FIB_3              # 3 seconds between retries

# ─── Structured Output ───────────────────────────────────────────────────────
log_json() {
  local level="$1" msg="$2"
  shift 2
  printf '{"timestamp":"%s","level":"%s","suite":"network-partition","msg":"%s"%s}\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$level" "$msg" "$*"
}

# ─── Get Running Heady Containers ────────────────────────────────────────────
get_heady_containers() {
  docker ps --format '{{.Names}}' --filter "network=${NETWORK}" 2>/dev/null || true
}

# ─── Health Check ─────────────────────────────────────────────────────────────
check_health() {
  local container="$1"
  local port
  port=$(docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}}{{(index $conf 0).HostPort}}{{end}}' "$container" 2>/dev/null | head -1)
  if [ -z "$port" ]; then
    return 1
  fi
  local status
  status=$(curl -s -o /dev/null -w '%{http_code}' --max-time "$HEALTH_TIMEOUT_S" "http://localhost:${port}/health" 2>/dev/null || echo "000")
  [ "$status" = "200" ]
}

# ─── Wait for Health with Retries ─────────────────────────────────────────────
wait_for_health() {
  local container="$1"
  local retries=0
  while [ "$retries" -lt "$MAX_RETRIES" ]; do
    if check_health "$container"; then
      return 0
    fi
    retries=$((retries + 1))
    sleep "$RETRY_DELAY_S"
  done
  return 1
}

# ─── Verify Other Services During Partition ───────────────────────────────────
verify_degradation() {
  local partitioned_container="$1"
  local containers healthy_count=0 total_count=0
  containers=$(get_heady_containers)

  while IFS= read -r container; do
    [ -z "$container" ] && continue
    [ "$container" = "$partitioned_container" ] && continue
    total_count=$((total_count + 1))
    if check_health "$container"; then
      healthy_count=$((healthy_count + 1))
    fi
  done <<< "$containers"

  log_json "info" "degradation-check" ",\"healthyServices\":$healthy_count,\"totalServices\":$total_count,\"partitionedService\":\"$partitioned_container\""
  # Other services should remain healthy during partition
  [ "$healthy_count" -eq "$total_count" ]
}

# ─── Main Partition Test ──────────────────────────────────────────────────────
run_partition_test() {
  local containers
  containers=$(get_heady_containers)

  if [ -z "$containers" ]; then
    log_json "error" "no-containers-found" ",\"network\":\"$NETWORK\""
    exit 1
  fi

  local container_count
  container_count=$(echo "$containers" | wc -l)
  log_json "info" "test-start" ",\"network\":\"$NETWORK\",\"containerCount\":$container_count,\"partitionDurationS\":$PARTITION_DURATION_S"

  # Select a random container to partition
  local target
  target=$(echo "$containers" | shuf -n 1)
  log_json "info" "target-selected" ",\"container\":\"$target\""

  # Verify target is healthy before partition
  if ! check_health "$target"; then
    log_json "warn" "target-unhealthy-before-partition" ",\"container\":\"$target\""
  fi

  # ─── Phase 1: Disconnect ────────────────────────────────────────────────
  log_json "info" "phase-disconnect" ",\"container\":\"$target\",\"network\":\"$NETWORK\""
  docker network disconnect "$NETWORK" "$target" 2>/dev/null
  local disconnect_result=$?

  if [ "$disconnect_result" -ne 0 ]; then
    log_json "error" "disconnect-failed" ",\"container\":\"$target\",\"exitCode\":$disconnect_result"
    exit 1
  fi

  log_json "info" "partition-active" ",\"container\":\"$target\",\"durationS\":$PARTITION_DURATION_S"

  # ─── Phase 2: Verify Graceful Degradation ───────────────────────────────
  sleep "$FIB_3"  # Wait 3s for partition to take effect
  if verify_degradation "$target"; then
    log_json "pass" "graceful-degradation" ",\"container\":\"$target\",\"otherServicesHealthy\":true"
  else
    log_json "FAIL" "graceful-degradation" ",\"container\":\"$target\",\"otherServicesHealthy\":false"
  fi

  # Wait remaining partition duration
  local remaining=$((PARTITION_DURATION_S - FIB_3))
  [ "$remaining" -gt 0 ] && sleep "$remaining"

  # ─── Phase 3: Reconnect ─────────────────────────────────────────────────
  log_json "info" "phase-reconnect" ",\"container\":\"$target\",\"network\":\"$NETWORK\""
  docker network connect "$NETWORK" "$target" 2>/dev/null
  local connect_result=$?

  if [ "$connect_result" -ne 0 ]; then
    log_json "error" "reconnect-failed" ",\"container\":\"$target\",\"exitCode\":$connect_result"
    exit 1
  fi

  # ─── Phase 4: Verify Recovery ───────────────────────────────────────────
  log_json "info" "phase-recovery" ",\"container\":\"$target\",\"waitS\":$RECOVERY_WAIT_S"
  sleep "$RECOVERY_WAIT_S"

  if wait_for_health "$target"; then
    log_json "pass" "recovery-verified" ",\"container\":\"$target\""
  else
    log_json "FAIL" "recovery-failed" ",\"container\":\"$target\""
    exit 1
  fi

  # Final check: all services healthy
  local all_healthy=true
  while IFS= read -r container; do
    [ -z "$container" ] && continue
    if ! check_health "$container"; then
      log_json "FAIL" "post-recovery-health" ",\"container\":\"$container\""
      all_healthy=false
    fi
  done <<< "$(get_heady_containers)"

  if [ "$all_healthy" = true ]; then
    log_json "pass" "all-services-recovered" ",\"containerCount\":$container_count"
  else
    log_json "FAIL" "some-services-unhealthy" ""
    exit 1
  fi

  log_json "info" "test-complete" ",\"result\":\"pass\",\"partitionDurationS\":$PARTITION_DURATION_S,\"recoveryWaitS\":$RECOVERY_WAIT_S"
}

# ─── Execute ──────────────────────────────────────────────────────────────────
run_partition_test
