#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# resource-exhaustion.sh — Chaos engineering: resource limit stress testing
# Heady™ Platform | Chaos Tests
# Uses docker update to constrain memory/CPU and verify OOM handling
# All numeric constants derived from φ (1.618033988749895) or Fibonacci
# Run: bash tests/chaos/resource-exhaustion.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

# ─── φ-Math Constants ────────────────────────────────────────────────────────
PHI="1.618033988749895"
PSI="0.618033988749895"
# Fibonacci sequence: 1,1,2,3,5,8,13,21,34,55,89,144,233
FIB_3=3
FIB_4=5
FIB_5=8
FIB_6=13
FIB_7=21
FIB_8=34
FIB_9=55
FIB_10=89
FIB_11=144
FIB_12=233

# ─── Config ──────────────────────────────────────────────────────────────────
NETWORK="${HEADY_NETWORK:-heady-mesh}"
CONSTRAINED_MEMORY_MB=$FIB_8       # 34MB (FIB[8])
NORMAL_MEMORY_MB=$FIB_12           # 233MB (FIB[12])
CONSTRAINED_CPU="0.${FIB_5}${FIB_5}" # 0.088 → use Fibonacci-derived fraction
CPU_QUOTA=$((FIB_5 * 1000))        # 8000 (8% of a core)
CPU_PERIOD=100000                   # Standard 100ms period
HEALTH_TIMEOUT_S=$FIB_3            # 3 seconds
STRESS_DURATION_S=$FIB_6           # 13 seconds
RECOVERY_WAIT_S=$FIB_5             # 8 seconds
MAX_RETRIES=$FIB_5                 # 8 retries
RETRY_DELAY_S=$FIB_3              # 3 seconds
MAX_RESTART_WAIT_S=$FIB_10        # 89 seconds max wait for restart

# ─── Structured Output ───────────────────────────────────────────────────────
log_json() {
  local level="$1" msg="$2"
  shift 2
  printf '{"timestamp":"%s","level":"%s","suite":"resource-exhaustion","msg":"%s"%s}\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$level" "$msg" "$*"
}

# ─── Get Running Heady Containers ────────────────────────────────────────────
get_heady_containers() {
  docker ps --format '{{.Names}}' --filter "network=${NETWORK}" 2>/dev/null || true
}

# ─── Get Container Stats ─────────────────────────────────────────────────────
get_container_stats() {
  local container="$1"
  docker stats --no-stream --format '{"memUsage":"{{.MemUsage}}","cpuPct":"{{.CPUPerc}}","memPct":"{{.MemPerc}}"}' "$container" 2>/dev/null || echo '{"memUsage":"unknown","cpuPct":"unknown","memPct":"unknown"}'
}

# ─── Health Check ─────────────────────────────────────────────────────────────
check_health() {
  local container="$1"
  local port
  port=$(docker inspect --format='{{range $p, $conf := .NetworkSettings.Ports}}{{(index $conf 0).HostPort}}{{end}}' "$container" 2>/dev/null | head -1)
  if [ -z "$port" ]; then
    return 1
  fi
  local status
  status=$(curl -s -o /dev/null -w '%{http_code}' --max-time "$HEALTH_TIMEOUT_S" "http://localhost:${port}/health" 2>/dev/null || echo "000")
  [ "$status" = "200" ]
}

# ─── Wait for Container Health with Retries ───────────────────────────────────
wait_for_health() {
  local container="$1"
  local retries=0
  while [ "$retries" -lt "$MAX_RETRIES" ]; do
    if check_health "$container"; then
      return 0
    fi
    retries=$((retries + 1))
    sleep "$RETRY_DELAY_S"
  done
  return 1
}

# ─── Wait for Container to Be Running ────────────────────────────────────────
wait_for_running() {
  local container="$1"
  local elapsed=0
  while [ "$elapsed" -lt "$MAX_RESTART_WAIT_S" ]; do
    local state
    state=$(docker inspect --format '{{.State.Status}}' "$container" 2>/dev/null || echo "unknown")
    if [ "$state" = "running" ]; then
      return 0
    fi
    sleep "$FIB_3"
    elapsed=$((elapsed + FIB_3))
  done
  return 1
}

# ─── Get Current Memory Limit ─────────────────────────────────────────────────
get_memory_limit() {
  local container="$1"
  docker inspect --format '{{.HostConfig.Memory}}' "$container" 2>/dev/null || echo "0"
}

# ─── Memory Constraint Test ───────────────────────────────────────────────────
test_memory_constraint() {
  local container="$1"
  log_json "info" "memory-test-start" ",\"container\":\"$container\",\"constrainedMB\":$CONSTRAINED_MEMORY_MB"

  # Record original memory limit
  local original_limit
  original_limit=$(get_memory_limit "$container")
  log_json "info" "original-memory-limit" ",\"container\":\"$container\",\"bytes\":$original_limit"

  # Get baseline stats
  local baseline_stats
  baseline_stats=$(get_container_stats "$container")
  log_json "info" "baseline-stats" ",\"container\":\"$container\",\"stats\":$baseline_stats"

  # Apply memory constraint: FIB[8] = 34MB
  log_json "info" "applying-memory-constraint" ",\"container\":\"$container\",\"memoryMB\":$CONSTRAINED_MEMORY_MB"
  docker update --memory="${CONSTRAINED_MEMORY_MB}m" --memory-swap="${CONSTRAINED_MEMORY_MB}m" "$container" 2>/dev/null

  # Monitor under constraint
  sleep "$FIB_4"
  local constrained_stats
  constrained_stats=$(get_container_stats "$container")
  log_json "info" "constrained-stats" ",\"container\":\"$container\",\"stats\":$constrained_stats"

  # Check if container is still running or was OOM killed
  local state
  state=$(docker inspect --format '{{.State.Status}}' "$container" 2>/dev/null || echo "unknown")
  local oom_killed
  oom_killed=$(docker inspect --format '{{.State.OOMKilled}}' "$container" 2>/dev/null || echo "unknown")

  log_json "info" "container-state-under-constraint" ",\"container\":\"$container\",\"state\":\"$state\",\"oomKilled\":$oom_killed"

  if [ "$state" = "running" ]; then
    # Container survived — check if still healthy
    if check_health "$container"; then
      log_json "pass" "survived-memory-constraint" ",\"container\":\"$container\",\"memoryMB\":$CONSTRAINED_MEMORY_MB"
    else
      log_json "info" "degraded-under-memory-constraint" ",\"container\":\"$container\",\"memoryMB\":$CONSTRAINED_MEMORY_MB"
    fi
  else
    # Container was killed — verify restart policy handles it
    log_json "info" "container-oom-killed" ",\"container\":\"$container\",\"oomKilled\":$oom_killed"

    # Restore memory before waiting for restart
    docker update --memory="${NORMAL_MEMORY_MB}m" --memory-swap="${NORMAL_MEMORY_MB}m" "$container" 2>/dev/null || true

    if wait_for_running "$container"; then
      log_json "pass" "oom-restart-successful" ",\"container\":\"$container\""
    else
      log_json "FAIL" "oom-restart-failed" ",\"container\":\"$container\""
      return 1
    fi
  fi

  # Restore normal memory limit
  if [ "$original_limit" -gt 0 ]; then
    docker update --memory="$original_limit" --memory-swap="$original_limit" "$container" 2>/dev/null || true
  else
    docker update --memory="${NORMAL_MEMORY_MB}m" --memory-swap="${NORMAL_MEMORY_MB}m" "$container" 2>/dev/null || true
  fi
  log_json "info" "memory-restored" ",\"container\":\"$container\""

  return 0
}

# ─── CPU Constraint Test ──────────────────────────────────────────────────────
test_cpu_constraint() {
  local container="$1"
  log_json "info" "cpu-test-start" ",\"container\":\"$container\",\"cpuQuota\":$CPU_QUOTA,\"cpuPeriod\":$CPU_PERIOD"

  # Get baseline stats
  local baseline_stats
  baseline_stats=$(get_container_stats "$container")
  log_json "info" "cpu-baseline-stats" ",\"container\":\"$container\",\"stats\":$baseline_stats"

  # Apply CPU constraint
  docker update --cpu-quota="$CPU_QUOTA" --cpu-period="$CPU_PERIOD" "$container" 2>/dev/null
  log_json "info" "cpu-constraint-applied" ",\"container\":\"$container\",\"effectiveCpu\":\"$(echo "scale=3; $CPU_QUOTA / $CPU_PERIOD" | bc 2>/dev/null || echo "$CPU_QUOTA/$CPU_PERIOD")\""

  # Run under CPU constraint for STRESS_DURATION_S
  local elapsed=0
  while [ "$elapsed" -lt "$STRESS_DURATION_S" ]; do
    sleep "$FIB_3"
    elapsed=$((elapsed + FIB_3))

    local stats
    stats=$(get_container_stats "$container")
    log_json "info" "cpu-constrained-stats" ",\"container\":\"$container\",\"elapsedS\":$elapsed,\"stats\":$stats"
  done

  # Check health under CPU constraint
  if check_health "$container"; then
    log_json "pass" "healthy-under-cpu-constraint" ",\"container\":\"$container\""
  else
    log_json "info" "degraded-under-cpu-constraint" ",\"container\":\"$container\""
  fi

  # Remove CPU constraint
  docker update --cpu-quota=0 --cpu-period=0 "$container" 2>/dev/null || \
    docker update --cpu-quota=-1 "$container" 2>/dev/null || true
  log_json "info" "cpu-constraint-removed" ",\"container\":\"$container\""

  return 0
}

# ─── Main Resource Exhaustion Test ────────────────────────────────────────────
run_resource_test() {
  local containers
  containers=$(get_heady_containers)

  if [ -z "$containers" ]; then
    log_json "error" "no-containers-found" ",\"network\":\"$NETWORK\""
    exit 1
  fi

  local container_count
  container_count=$(echo "$containers" | wc -l)

  # Select a random container
  local target
  target=$(echo "$containers" | shuf -n 1)

  log_json "info" "test-start" ",\"target\":\"$target\",\"containerCount\":$container_count,\"memoryConstraintMB\":$CONSTRAINED_MEMORY_MB,\"cpuQuota\":$CPU_QUOTA"

  # Verify healthy baseline
  if check_health "$target"; then
    log_json "info" "baseline-healthy" ",\"container\":\"$target\""
  else
    log_json "warn" "baseline-unhealthy" ",\"container\":\"$target\""
  fi

  local test_passed=true

  # ─── Phase 1: Memory Constraint ──────────────────────────────────────────
  if ! test_memory_constraint "$target"; then
    test_passed=false
  fi

  # Wait for stability between tests
  sleep "$RECOVERY_WAIT_S"

  # Verify recovery after memory test
  if wait_for_health "$target"; then
    log_json "pass" "memory-test-recovery" ",\"container\":\"$target\""
  else
    log_json "FAIL" "memory-test-recovery-failed" ",\"container\":\"$target\""
    test_passed=false
  fi

  # ─── Phase 2: CPU Constraint ─────────────────────────────────────────────
  if ! test_cpu_constraint "$target"; then
    test_passed=false
  fi

  # Wait for stability
  sleep "$RECOVERY_WAIT_S"

  # Verify final recovery
  if wait_for_health "$target"; then
    log_json "pass" "final-recovery" ",\"container\":\"$target\""
  else
    log_json "FAIL" "final-recovery-failed" ",\"container\":\"$target\""
    test_passed=false
  fi

  # Final summary
  if [ "$test_passed" = true ]; then
    log_json "info" "test-complete" ",\"result\":\"pass\",\"target\":\"$target\""
  else
    log_json "info" "test-complete" ",\"result\":\"fail\",\"target\":\"$target\""
    exit 1
  fi
}

# ─── Execute ──────────────────────────────────────────────────────────────────
run_resource_test
