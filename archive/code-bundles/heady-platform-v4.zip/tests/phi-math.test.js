/**
 * phi-math.test.js — φ-math foundation test suite
 * Heady™ Platform | Tests
 * Validates golden ratio constants, Fibonacci sequences, and φ-derived thresholds
 * Run: node tests/phi-math.test.js
 */
'use strict';

// ─── φ-Math Constants (No Magic Numbers) ────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── Test Runner ─────────────────────────────────────────────────────────────
let passed = 0, failed = 0;
function assert(condition, msg) {
  if (condition) { passed++; process.stdout.write(JSON.stringify({ test: msg, status: 'pass' }) + '\n'); }
  else { failed++; process.stdout.write(JSON.stringify({ test: msg, status: 'FAIL' }) + '\n'); }
}
function assertClose(a, b, epsilon, msg) { assert(Math.abs(a - b) < epsilon, msg); }

// ─── φ Identity Tests ───────────────────────────────────────────────────────
const EPSILON = 1e-10;

assertClose(PHI * PSI, 1, EPSILON,
  'PHI * PSI === 1 (golden ratio reciprocal identity)');

assertClose(PHI * PHI, PHI + 1, EPSILON,
  'PHI^2 === PHI + 1 (fundamental golden ratio property)');

assertClose(PSI, PHI - 1, EPSILON,
  'PSI === PHI - 1 (reciprocal equals phi minus one)');

assertClose(PHI, (1 + Math.sqrt(5)) / 2, EPSILON,
  'PHI === (1 + sqrt(5)) / 2 (closed-form definition)');

assertClose(PSI, (Math.sqrt(5) - 1) / 2, EPSILON,
  'PSI === (sqrt(5) - 1) / 2 (reciprocal closed form)');

assertClose(PSI2, 2 - PHI, EPSILON,
  'PSI^2 === 2 - PHI');

assertClose(PHI * PHI * PHI, PHI * PHI + PHI, EPSILON,
  'PHI^3 === PHI^2 + PHI (cubic identity)');

assertClose(1 / PHI + 1 / (PHI * PHI), 1, EPSILON,
  '1/PHI + 1/PHI^2 === 1 (partition of unity)');

// ─── Fibonacci Sequence Tests ────────────────────────────────────────────────
function generateFib(n) {
  const seq = [1, 1];
  for (let i = 2; i < n; i++) {
    seq[i] = seq[i - 1] + seq[i - 2];
  }
  return seq;
}

const generatedFib = generateFib(FIB.length);
for (let i = 0; i < FIB.length; i++) {
  assert(FIB[i] === generatedFib[i],
    `FIB[${i}] === ${FIB[i]} (Fibonacci sequence correctness)`);
}

// Extended Fibonacci correctness up to fib(20)
const FIB_20 = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765];
const generatedFib20 = generateFib(20);
for (let i = 0; i < 20; i++) {
  assert(generatedFib20[i] === FIB_20[i],
    `fib(${i}) === ${FIB_20[i]} (extended Fibonacci correctness)`);
}

// Fibonacci ratio converges to PHI
for (let i = FIB.length - 1; i >= FIB.length - 3; i--) {
  const ratio = generatedFib[i] / generatedFib[i - 1];
  assertClose(ratio, PHI, 1e-3,
    `FIB[${i}]/FIB[${i - 1}] ≈ PHI (ratio convergence: ${ratio.toFixed(6)})`);
}

// Fibonacci: each term is sum of two prior
for (let i = 2; i < FIB.length; i++) {
  assert(FIB[i] === FIB[i - 1] + FIB[i - 2],
    `FIB[${i}] === FIB[${i - 1}] + FIB[${i - 2}] (recurrence relation)`);
}

// ─── phiThreshold Tests ──────────────────────────────────────────────────────
function phiThreshold(level) {
  return 1 / (1 + Math.pow(PHI, -level));
}

const expectedThresholds = [
  { level: 0, expected: 0.5 },
  { level: 1, expected: 1 / (1 + PSI) },
  { level: 2, expected: 1 / (1 + PSI2) },
  { level: 3, expected: 1 / (1 + Math.pow(PSI, 3)) },
  { level: 4, expected: 1 / (1 + Math.pow(PSI, 4)) },
];

for (const { level, expected } of expectedThresholds) {
  assertClose(phiThreshold(level), expected, EPSILON,
    `phiThreshold(${level}) === ${expected.toFixed(6)}`);
}

assertClose(phiThreshold(0), 0.5, EPSILON,
  'phiThreshold(0) === 0.5 (even split at level 0)');

assert(phiThreshold(4) > 0.87 && phiThreshold(4) < 0.88,
  `phiThreshold(4) ≈ 0.873 (bounded check: ${phiThreshold(4).toFixed(6)})`);

// Monotonically increasing
for (let i = 1; i <= 4; i++) {
  assert(phiThreshold(i) > phiThreshold(i - 1),
    `phiThreshold(${i}) > phiThreshold(${i - 1}) (monotonically increasing)`);
}

// Approaches 1 as level increases
assertClose(phiThreshold(34), 1.0, 1e-5,
  'phiThreshold(34) ≈ 1.0 (approaches unity at high levels)');

// ─── phiBackoff Tests ────────────────────────────────────────────────────────
function phiBackoff(attempt, baseMs) {
  return baseMs * Math.pow(PHI, attempt);
}

const BASE_DELAY = FIB[6]; // 13ms

assertClose(phiBackoff(0, BASE_DELAY), BASE_DELAY, EPSILON,
  'phiBackoff(0) === base delay (no backoff at attempt 0)');

assertClose(phiBackoff(1, BASE_DELAY), BASE_DELAY * PHI, EPSILON,
  'phiBackoff(1) === base * PHI');

assertClose(phiBackoff(2, BASE_DELAY), BASE_DELAY * PHI * PHI, EPSILON,
  'phiBackoff(2) === base * PHI^2');

// Exponential growth check
for (let i = 1; i <= 5; i++) {
  const ratio = phiBackoff(i, BASE_DELAY) / phiBackoff(i - 1, BASE_DELAY);
  assertClose(ratio, PHI, EPSILON,
    `phiBackoff ratio between attempts ${i - 1}→${i} === PHI`);
}

// Backoff produces specific expected values
assertClose(phiBackoff(3, BASE_DELAY), BASE_DELAY * PHI * PHI * PHI, 1e-6,
  `phiBackoff(3, ${BASE_DELAY}) === ${(BASE_DELAY * PHI * PHI * PHI).toFixed(3)}ms`);

assertClose(phiBackoff(5, BASE_DELAY), BASE_DELAY * Math.pow(PHI, 5), 1e-6,
  `phiBackoff(5, ${BASE_DELAY}) === ${(BASE_DELAY * Math.pow(PHI, 5)).toFixed(3)}ms`);

// ─── CSL_GATES Constant Validation ──────────────────────────────────────────
assertClose(CSL_GATES.include, PSI2, EPSILON,
  'CSL_GATES.include === PSI^2 ≈ 0.382');

assertClose(CSL_GATES.boost, PSI, EPSILON,
  'CSL_GATES.boost === PSI ≈ 0.618');

assertClose(CSL_GATES.inject, PSI + 0.1, EPSILON,
  'CSL_GATES.inject === PSI + 0.1 ≈ 0.718');

assert(CSL_GATES.include < CSL_GATES.boost,
  'CSL_GATES.include < CSL_GATES.boost (gate ordering)');

assert(CSL_GATES.boost < CSL_GATES.inject,
  'CSL_GATES.boost < CSL_GATES.inject (gate ordering)');

// ─── VECTOR_DIM Validation ──────────────────────────────────────────────────
assert(VECTOR_DIM === 384,
  'VECTOR_DIM === 384 (embedding dimension)');

assert(VECTOR_DIM % 2 === 0,
  'VECTOR_DIM is even (required for paired operations)');

// ─── Binet Formula Verification ─────────────────────────────────────────────
function binetFib(n) {
  const sqrt5 = Math.sqrt(5);
  return Math.round((Math.pow(PHI, n + 1) - Math.pow(-PSI, n + 1)) / sqrt5);
}

for (let i = 0; i < FIB.length; i++) {
  assert(binetFib(i) === FIB[i],
    `Binet formula fib(${i}) === ${FIB[i]} (closed-form verification)`);
}

// ─── Summary ─────────────────────────────────────────────────────────────────
process.stdout.write('\n' + JSON.stringify({
  suite: 'phi-math',
  passed,
  failed,
  total: passed + failed,
  status: failed === 0 ? 'ALL PASS' : 'FAILURES',
}) + '\n');

process.exit(failed > 0 ? 1 : 0);
