/**
 * api-gateway.k6.js — k6 load test for Heady™ API Gateway
 * Run: k6 run tests/load/api-gateway.k6.js
 * Fibonacci-staged ramp-up with φ-derived thresholds
 */

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend } from 'k6/metrics';

// ─── φ-Math Constants (No Magic Numbers) ────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];

// ─── Service Config ─────────────────────────────────────────────────────────
const BASE_URL = __ENV.API_GATEWAY_URL || 'http://localhost:3312';
const STAGE_DURATION_S = FIB[6]; // 13s per stage

// ─── Custom Metrics ─────────────────────────────────────────────────────────
const healthCheckDuration = new Trend('health_check_duration', true);
const serviceListDuration = new Trend('service_list_duration', true);
const errorRate = new Rate('error_rate');

// ─── φ-Derived Thresholds ───────────────────────────────────────────────────
// p95 < 1618ms (PHI * 1000), p99 < 2618ms (PHI² * 1000), error rate < 6.18%
const P95_THRESHOLD_MS = Math.round(PHI * 1000);    // 1618ms
const P99_THRESHOLD_MS = Math.round(PHI * PHI * 1000); // 2618ms
const ERROR_RATE_THRESHOLD = PSI2 * PSI2 * 100 / (PSI2 * 100 / (PSI2 * 100 / 100)); // simplified to 6.18%
const MAX_ERROR_RATE = 0.0618;

export const options = {
  stages: [
    // Fibonacci ramp-up: 1→1→2→3→5→8→13→21→34 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[0] },  // 1 VU
    { duration: `${STAGE_DURATION_S}s`, target: FIB[1] },  // 1 VU
    { duration: `${STAGE_DURATION_S}s`, target: FIB[2] },  // 2 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[3] },  // 3 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[4] },  // 5 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[5] },  // 8 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[6] },  // 13 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[7] },  // 21 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[8] },  // 34 VUs
    // Fibonacci ramp-down
    { duration: `${STAGE_DURATION_S}s`, target: FIB[5] },  // 8 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[2] },  // 2 VUs
    { duration: `${STAGE_DURATION_S}s`, target: 0 },        // 0 VUs
  ],
  thresholds: {
    'http_req_duration': [
      `p(95)<${P95_THRESHOLD_MS}`,
      `p(99)<${P99_THRESHOLD_MS}`,
    ],
    'error_rate': [`rate<${MAX_ERROR_RATE}`],
    'health_check_duration': [`p(95)<${Math.round(PSI * 1000)}`],  // p95 < 618ms for health
    'service_list_duration': [`p(95)<${P95_THRESHOLD_MS}`],
  },
};

// ─── Request Headers ─────────────────────────────────────────────────────────
const headers = {
  'Content-Type': 'application/json',
  'X-Correlation-Id': `k6-load-${Date.now()}`,
  'X-Heady-Domain': 'testing',
};

// ─── Health Check Scenario ───────────────────────────────────────────────────
function testHealthCheck() {
  const res = http.get(`${BASE_URL}/health`, { headers, tags: { endpoint: 'health' } });

  const success = check(res, {
    'health: status 200': (r) => r.status === 200,
    'health: has status field': (r) => {
      try { return JSON.parse(r.body).status !== undefined; }
      catch { return false; }
    },
    'health: response time < φ*1000ms': (r) => r.timings.duration < PHI * 1000,
  });

  healthCheckDuration.add(res.timings.duration);
  errorRate.add(!success);
}

// ─── Service List Scenario ───────────────────────────────────────────────────
function testServiceList() {
  const res = http.get(`${BASE_URL}/api/services`, { headers, tags: { endpoint: 'services' } });

  const success = check(res, {
    'services: status 200': (r) => r.status === 200,
    'services: returns array': (r) => {
      try { return Array.isArray(JSON.parse(r.body)); }
      catch { return false; }
    },
    'services: response time < p95 threshold': (r) => r.timings.duration < P95_THRESHOLD_MS,
  });

  serviceListDuration.add(res.timings.duration);
  errorRate.add(!success);
}

// ─── Service Route Proxy Test ────────────────────────────────────────────────
function testServiceProxy() {
  const res = http.get(`${BASE_URL}/api/heady-brain/health`, {
    headers,
    tags: { endpoint: 'proxy' },
    timeout: `${Math.round(PHI * PHI * 1000)}ms`, // 2618ms timeout
  });

  const success = check(res, {
    'proxy: status is success or 502': (r) => r.status === 200 || r.status === 502,
    'proxy: has correlation id': (r) => r.headers['X-Correlation-Id'] !== undefined || r.headers['x-correlation-id'] !== undefined,
  });

  errorRate.add(!success);
}

// ─── Main Test Function ──────────────────────────────────────────────────────
export default function () {
  // Weight distribution using φ: health gets PHI weight, services gets 1, proxy gets PSI
  const rand = Math.random() * (PHI + 1 + PSI);

  if (rand < PHI) {
    testHealthCheck();
  } else if (rand < PHI + 1) {
    testServiceList();
  } else {
    testServiceProxy();
  }

  // Think time: φ-scaled random sleep between PSI and PHI seconds
  sleep(PSI + Math.random() * (PHI - PSI));
}

// ─── Setup ───────────────────────────────────────────────────────────────────
export function setup() {
  const res = http.get(`${BASE_URL}/health`);
  const setupData = {
    gatewayReachable: res.status === 200,
    baseUrl: BASE_URL,
    startTime: Date.now(),
    fibStages: FIB.slice(0, 9).join('→'),
    p95Threshold: P95_THRESHOLD_MS,
    p99Threshold: P99_THRESHOLD_MS,
    maxErrorRate: MAX_ERROR_RATE,
  };
  return setupData;
}

// ─── Teardown ────────────────────────────────────────────────────────────────
export function teardown(data) {
  const elapsed = Date.now() - data.startTime;
  const summary = {
    suite: 'api-gateway-load',
    elapsedMs: elapsed,
    baseUrl: data.baseUrl,
    fibStages: data.fibStages,
    thresholds: {
      p95: `${data.p95Threshold}ms`,
      p99: `${data.p99Threshold}ms`,
      errorRate: `${(data.maxErrorRate * 100).toFixed(2)}%`,
    },
  };
  // k6 outputs to stdout natively; structured summary logged here
  console.log(JSON.stringify(summary));
}
