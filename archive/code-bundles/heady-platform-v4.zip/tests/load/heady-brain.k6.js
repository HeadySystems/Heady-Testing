/**
 * heady-brain.k6.js — k6 load test for Heady™ Brain (inference service)
 * Run: k6 run tests/load/heady-brain.k6.js
 * Fibonacci-staged ramp-up with φ-derived thresholds for inference latency
 */

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend } from 'k6/metrics';

// ─── φ-Math Constants (No Magic Numbers) ────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];

// ─── Service Config ─────────────────────────────────────────────────────────
const BASE_URL = __ENV.HEADY_BRAIN_URL || 'http://localhost:3310';
const STAGE_DURATION_S = FIB[6]; // 13s per stage

// ─── Custom Metrics ─────────────────────────────────────────────────────────
const inferDuration = new Trend('infer_duration', true);
const routeDuration = new Trend('route_duration', true);
const errorRate = new Rate('error_rate');

// ─── φ-Derived Thresholds ───────────────────────────────────────────────────
// Inference is slower: p95 < 4236ms (PHI³ * 1000), p99 < 6854ms (PHI⁴ * 1000)
const P95_THRESHOLD_MS = Math.round(PHI * PHI * PHI * 1000);        // 4236ms
const P99_THRESHOLD_MS = Math.round(PHI * PHI * PHI * PHI * 1000);  // 6854ms
const ROUTE_P95_MS = Math.round(PHI * 1000);                         // 1618ms for routing
const MAX_ERROR_RATE = 0.0618;

export const options = {
  stages: [
    // Fibonacci ramp-up: 1→1→2→3→5→8→13→21→34 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[0] },  // 1 VU
    { duration: `${STAGE_DURATION_S}s`, target: FIB[1] },  // 1 VU
    { duration: `${STAGE_DURATION_S}s`, target: FIB[2] },  // 2 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[3] },  // 3 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[4] },  // 5 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[5] },  // 8 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[6] },  // 13 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[7] },  // 21 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[8] },  // 34 VUs
    // Fibonacci ramp-down
    { duration: `${STAGE_DURATION_S}s`, target: FIB[5] },  // 8 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[2] },  // 2 VUs
    { duration: `${STAGE_DURATION_S}s`, target: 0 },        // 0 VUs
  ],
  thresholds: {
    'http_req_duration': [`p(99)<${P99_THRESHOLD_MS}`],
    'infer_duration': [`p(95)<${P95_THRESHOLD_MS}`],
    'route_duration': [`p(95)<${ROUTE_P95_MS}`],
    'error_rate': [`rate<${MAX_ERROR_RATE}`],
  },
};

// ─── Request Headers ─────────────────────────────────────────────────────────
const headers = {
  'Content-Type': 'application/json',
  'X-Correlation-Id': `k6-brain-${Date.now()}`,
  'X-Heady-Domain': 'testing',
};

// ─── Sample Prompts (φ-indexed selection) ────────────────────────────────────
const PROMPTS = [
  'Explain the golden ratio and its significance in mathematics.',
  'What are the applications of Fibonacci sequences in computer science?',
  'Describe the concept of continuous semantic logic.',
  'How do vector embeddings represent semantic meaning?',
  'Explain the relationship between cosine similarity and semantic search.',
  'What is the role of attention mechanisms in transformer models?',
  'Describe how HNSW indexes work for approximate nearest neighbor search.',
  'Explain the saga pattern in distributed systems.',
];

// ─── Sample Routing Contexts ─────────────────────────────────────────────────
const ROUTE_CONTEXTS = [
  { task: 'reasoning', complexity: PHI, domain: 'mathematics' },
  { task: 'coding', complexity: PSI, domain: 'engineering' },
  { task: 'analysis', complexity: PSI2, domain: 'science' },
  { task: 'creative', complexity: PHI * PSI, domain: 'writing' },
  { task: 'factual', complexity: PSI2 * PHI, domain: 'general' },
];

// ─── Inference Test ──────────────────────────────────────────────────────────
function testInfer() {
  const promptIdx = Math.floor(Math.random() * PROMPTS.length);
  const payload = JSON.stringify({
    prompt: PROMPTS[promptIdx],
    maxTokens: FIB[8],                   // 34 tokens
    temperature: PSI,                     // 0.618
    vectorDim: 384,
    cslConfidence: CSL_GATES_INCLUDE(),
  });

  const res = http.post(`${BASE_URL}/infer`, payload, {
    headers,
    tags: { endpoint: 'infer' },
    timeout: `${P99_THRESHOLD_MS}ms`,
  });

  const success = check(res, {
    'infer: status 200 or 503': (r) => r.status === 200 || r.status === 503,
    'infer: has response body': (r) => r.body && r.body.length > 0,
    'infer: response time < p95': (r) => r.timings.duration < P95_THRESHOLD_MS,
    'infer: has correlation id': (r) =>
      r.headers['X-Correlation-Id'] !== undefined ||
      r.headers['x-correlation-id'] !== undefined,
  });

  inferDuration.add(res.timings.duration);
  errorRate.add(!success);
}

// ─── Model Route Test ────────────────────────────────────────────────────────
function testRoute() {
  const ctxIdx = Math.floor(Math.random() * ROUTE_CONTEXTS.length);
  const payload = JSON.stringify({
    context: ROUTE_CONTEXTS[ctxIdx],
    prompt: PROMPTS[Math.floor(Math.random() * PROMPTS.length)],
    cslThreshold: PSI,
  });

  const res = http.post(`${BASE_URL}/route`, payload, {
    headers,
    tags: { endpoint: 'route' },
    timeout: `${Math.round(PHI * PHI * 1000)}ms`, // 2618ms timeout
  });

  const success = check(res, {
    'route: status 200 or 503': (r) => r.status === 200 || r.status === 503,
    'route: has model selection': (r) => {
      try {
        const body = JSON.parse(r.body);
        return body.model !== undefined || body.error !== undefined;
      } catch { return r.status === 503; }
    },
    'route: response time < route p95': (r) => r.timings.duration < ROUTE_P95_MS,
  });

  routeDuration.add(res.timings.duration);
  errorRate.add(!success);
}

// ─── Health Check ────────────────────────────────────────────────────────────
function testHealth() {
  const res = http.get(`${BASE_URL}/health`, {
    headers,
    tags: { endpoint: 'health' },
  });

  const success = check(res, {
    'health: status 200': (r) => r.status === 200,
    'health: response time < 618ms': (r) => r.timings.duration < PSI * 1000,
  });

  errorRate.add(!success);
}

// ─── CSL Gate Helper ─────────────────────────────────────────────────────────
function CSL_GATES_INCLUDE() { return PSI * PSI; }

// ─── Main Test Function ──────────────────────────────────────────────────────
export default function () {
  // Weight distribution: infer (PHI), route (1), health (PSI)
  const rand = Math.random() * (PHI + 1 + PSI);

  if (rand < PHI) {
    testInfer();
  } else if (rand < PHI + 1) {
    testRoute();
  } else {
    testHealth();
  }

  // Think time: longer for inference — φ² scaled
  sleep(PSI + Math.random() * PHI);
}

// ─── Setup ───────────────────────────────────────────────────────────────────
export function setup() {
  const res = http.get(`${BASE_URL}/health`);
  return {
    brainReachable: res.status === 200,
    baseUrl: BASE_URL,
    startTime: Date.now(),
    fibStages: FIB.slice(0, 9).join('→'),
    inferP95: P95_THRESHOLD_MS,
    routeP95: ROUTE_P95_MS,
    p99: P99_THRESHOLD_MS,
  };
}

// ─── Teardown ────────────────────────────────────────────────────────────────
export function teardown(data) {
  const elapsed = Date.now() - data.startTime;
  console.log(JSON.stringify({
    suite: 'heady-brain-load',
    elapsedMs: elapsed,
    baseUrl: data.baseUrl,
    fibStages: data.fibStages,
    thresholds: {
      inferP95: `${data.inferP95}ms`,
      routeP95: `${data.routeP95}ms`,
      p99: `${data.p99}ms`,
    },
  }));
}
