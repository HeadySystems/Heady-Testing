/**
 * search-service.k6.js — k6 load test for Heady™ Search Service
 * Run: k6 run tests/load/search-service.k6.js
 * Fibonacci-staged ramp-up testing BM25 and hybrid vector search
 */

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend } from 'k6/metrics';

// ─── φ-Math Constants (No Magic Numbers) ────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;

// ─── Service Config ─────────────────────────────────────────────────────────
const BASE_URL = __ENV.SEARCH_SERVICE_URL || 'http://localhost:3401';
const STAGE_DURATION_S = FIB[6]; // 13s per stage

// ─── Custom Metrics ─────────────────────────────────────────────────────────
const bm25Duration = new Trend('bm25_search_duration', true);
const hybridDuration = new Trend('hybrid_search_duration', true);
const errorRate = new Rate('error_rate');

// ─── φ-Derived Thresholds ───────────────────────────────────────────────────
const P95_THRESHOLD_MS = Math.round(PHI * 1000);           // 1618ms
const P99_THRESHOLD_MS = Math.round(PHI * PHI * 1000);     // 2618ms
const HYBRID_P95_MS = Math.round(PHI * PHI * 1000);        // 2618ms (hybrid is heavier)
const MAX_ERROR_RATE = 0.0618;

export const options = {
  stages: [
    // Fibonacci ramp-up: 1→1→2→3→5→8→13→21→34 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[0] },  // 1 VU
    { duration: `${STAGE_DURATION_S}s`, target: FIB[1] },  // 1 VU
    { duration: `${STAGE_DURATION_S}s`, target: FIB[2] },  // 2 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[3] },  // 3 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[4] },  // 5 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[5] },  // 8 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[6] },  // 13 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[7] },  // 21 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[8] },  // 34 VUs
    // Fibonacci ramp-down
    { duration: `${STAGE_DURATION_S}s`, target: FIB[5] },  // 8 VUs
    { duration: `${STAGE_DURATION_S}s`, target: FIB[2] },  // 2 VUs
    { duration: `${STAGE_DURATION_S}s`, target: 0 },        // 0 VUs
  ],
  thresholds: {
    'http_req_duration': [
      `p(95)<${P95_THRESHOLD_MS}`,
      `p(99)<${P99_THRESHOLD_MS}`,
    ],
    'bm25_search_duration': [`p(95)<${P95_THRESHOLD_MS}`],
    'hybrid_search_duration': [`p(95)<${HYBRID_P95_MS}`],
    'error_rate': [`rate<${MAX_ERROR_RATE}`],
  },
};

// ─── Request Headers ─────────────────────────────────────────────────────────
const headers = {
  'Content-Type': 'application/json',
  'X-Correlation-Id': `k6-search-${Date.now()}`,
  'X-Heady-Domain': 'testing',
};

// ─── Sample Search Queries ───────────────────────────────────────────────────
const SEARCH_QUERIES = [
  'golden ratio applications',
  'fibonacci sequence algorithms',
  'vector embedding similarity',
  'distributed transaction patterns',
  'semantic search optimization',
  'neural network architecture',
  'cosine similarity computation',
  'approximate nearest neighbor',
  'continuous semantic logic',
  'feature flag rollout strategies',
  'circuit breaker resilience',
  'saga orchestration pattern',
  'phi-scaled backoff retry',
];

// ─── Sample Vector (384-d deterministic) ─────────────────────────────────────
function generateTestVector(seed) {
  const vec = [];
  for (let i = 0; i < VECTOR_DIM; i++) {
    vec.push(Math.sin((i + 1) * seed * PHI) * Math.cos(i * seed * PSI));
  }
  // Normalize to unit length
  const mag = Math.sqrt(vec.reduce((sum, x) => sum + x * x, 0));
  return vec.map(x => x / mag);
}

// ─── BM25 Search Test ────────────────────────────────────────────────────────
function testBm25Search() {
  const queryIdx = Math.floor(Math.random() * SEARCH_QUERIES.length);
  const query = SEARCH_QUERIES[queryIdx];
  const limit = FIB[4]; // 5 results

  const res = http.get(`${BASE_URL}/search?q=${encodeURIComponent(query)}&limit=${limit}`, {
    headers,
    tags: { endpoint: 'bm25' },
    timeout: `${P99_THRESHOLD_MS}ms`,
  });

  const success = check(res, {
    'bm25: status 200 or 503': (r) => r.status === 200 || r.status === 503,
    'bm25: returns results': (r) => {
      try {
        const body = JSON.parse(r.body);
        return Array.isArray(body.results) || body.error !== undefined;
      } catch { return r.status === 503; }
    },
    'bm25: response time < p95': (r) => r.timings.duration < P95_THRESHOLD_MS,
    'bm25: has correlation id': (r) =>
      r.headers['X-Correlation-Id'] !== undefined ||
      r.headers['x-correlation-id'] !== undefined,
  });

  bm25Duration.add(res.timings.duration);
  errorRate.add(!success);
}

// ─── Hybrid Vector Search Test ───────────────────────────────────────────────
function testHybridSearch() {
  const queryIdx = Math.floor(Math.random() * SEARCH_QUERIES.length);
  const seed = queryIdx + 1;
  const payload = JSON.stringify({
    query: SEARCH_QUERIES[queryIdx],
    vector: generateTestVector(seed),
    limit: FIB[5],                        // 8 results
    rrfK: FIB[9],                          // 55
    bm25Weight: PSI,                       // 0.618
    vectorWeight: PHI - 1,                 // 0.618 (same as PSI)
    cslThreshold: PSI2,                    // 0.382
  });

  const res = http.post(`${BASE_URL}/search/hybrid`, payload, {
    headers,
    tags: { endpoint: 'hybrid' },
    timeout: `${Math.round(PHI * PHI * PHI * 1000)}ms`, // 4236ms timeout
  });

  const success = check(res, {
    'hybrid: status 200 or 503': (r) => r.status === 200 || r.status === 503,
    'hybrid: returns fused results': (r) => {
      try {
        const body = JSON.parse(r.body);
        return (Array.isArray(body.results) && body.fusionMethod !== undefined) || body.error !== undefined;
      } catch { return r.status === 503; }
    },
    'hybrid: response time < hybrid p95': (r) => r.timings.duration < HYBRID_P95_MS,
    'hybrid: results respect limit': (r) => {
      try {
        const body = JSON.parse(r.body);
        return !body.results || body.results.length <= FIB[5];
      } catch { return true; }
    },
  });

  hybridDuration.add(res.timings.duration);
  errorRate.add(!success);
}

// ─── Health Check ────────────────────────────────────────────────────────────
function testHealth() {
  const res = http.get(`${BASE_URL}/health`, {
    headers,
    tags: { endpoint: 'health' },
  });

  check(res, {
    'health: status 200': (r) => r.status === 200,
    'health: response time < 618ms': (r) => r.timings.duration < PSI * 1000,
  });
}

// ─── Main Test Function ──────────────────────────────────────────────────────
export default function () {
  // Weight distribution: bm25 (PHI), hybrid (1), health (PSI)
  const rand = Math.random() * (PHI + 1 + PSI);

  if (rand < PHI) {
    testBm25Search();
  } else if (rand < PHI + 1) {
    testHybridSearch();
  } else {
    testHealth();
  }

  // Think time: φ-scaled
  sleep(PSI + Math.random() * PSI);
}

// ─── Setup ───────────────────────────────────────────────────────────────────
export function setup() {
  const res = http.get(`${BASE_URL}/health`);
  return {
    searchReachable: res.status === 200,
    baseUrl: BASE_URL,
    startTime: Date.now(),
    fibStages: FIB.slice(0, 9).join('→'),
    bm25P95: P95_THRESHOLD_MS,
    hybridP95: HYBRID_P95_MS,
    p99: P99_THRESHOLD_MS,
    vectorDim: VECTOR_DIM,
    rrfK: FIB[9],
  };
}

// ─── Teardown ────────────────────────────────────────────────────────────────
export function teardown(data) {
  const elapsed = Date.now() - data.startTime;
  console.log(JSON.stringify({
    suite: 'search-service-load',
    elapsedMs: elapsed,
    baseUrl: data.baseUrl,
    fibStages: data.fibStages,
    vectorDim: data.vectorDim,
    rrfK: data.rrfK,
    thresholds: {
      bm25P95: `${data.bm25P95}ms`,
      hybridP95: `${data.hybridP95}ms`,
      p99: `${data.p99}ms`,
    },
  }));
}
