/**
 * csl-gates.test.js — Continuous Semantic Logic operations test suite
 * Heady™ Platform | Tests
 * Validates CSL AND, OR, NOT, GATE operations and phiThreshold values
 * Run: node tests/csl-gates.test.js
 */
'use strict';

// ─── φ-Math Constants (No Magic Numbers) ────────────────────────────────────
const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];
const VECTOR_DIM = 384;
const CSL_GATES = Object.freeze({
  include: PSI * PSI,   // ≈ 0.382
  boost: PSI,           // ≈ 0.618
  inject: PSI + 0.1,    // ≈ 0.718
});

// ─── Test Runner ─────────────────────────────────────────────────────────────
let passed = 0, failed = 0;
function assert(condition, msg) {
  if (condition) { passed++; process.stdout.write(JSON.stringify({ test: msg, status: 'pass' }) + '\n'); }
  else { failed++; process.stdout.write(JSON.stringify({ test: msg, status: 'FAIL' }) + '\n'); }
}
function assertClose(a, b, epsilon, msg) { assert(Math.abs(a - b) < epsilon, msg); }

const EPSILON = 1e-10;
const LOOSE_EPSILON = 1e-6;

// ─── Vector Utility Functions ────────────────────────────────────────────────
function dotProduct(a, b) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) sum += a[i] * b[i];
  return sum;
}

function magnitude(v) {
  return Math.sqrt(dotProduct(v, v));
}

function normalize(v) {
  const mag = magnitude(v);
  if (mag === 0) return v.slice();
  return v.map(x => x / mag);
}

function cosineSimilarity(a, b) {
  const magA = magnitude(a);
  const magB = magnitude(b);
  if (magA === 0 || magB === 0) return 0;
  return dotProduct(a, b) / (magA * magB);
}

// ─── CSL Operations ─────────────────────────────────────────────────────────
function cslAnd(a, b) {
  // CSL AND: cosine similarity between two concept vectors
  return cosineSimilarity(a, b);
}

function cslNot(v, gate) {
  // CSL NOT: orthogonal projection — remove gate component from v
  const gateNorm = normalize(gate);
  const proj = dotProduct(v, gateNorm);
  return v.map((x, i) => x - proj * gateNorm[i]);
}

function cslOr(a, b) {
  // CSL OR: superposition — normalized sum of two concept vectors
  const sum = a.map((x, i) => x + b[i]);
  return normalize(sum);
}

function sigmoid(x, steepness) {
  return 1 / (1 + Math.exp(-steepness * x));
}

function cslGate(value, threshold, steepness) {
  // CSL GATE: sigmoid activation around a threshold
  const k = steepness || FIB[7]; // 21 default steepness
  return sigmoid(value - threshold, k);
}

function phiThreshold(level) {
  return 1 / (1 + Math.pow(PHI, -level));
}

// ─── Helper: Create Test Vectors ─────────────────────────────────────────────
function createUnitVector(dim, index) {
  const v = new Array(dim).fill(0);
  v[index] = 1;
  return v;
}

function createRandomVector(dim) {
  const v = [];
  for (let i = 0; i < dim; i++) {
    v.push(Math.sin((i + 1) * PHI) * Math.cos(i * PSI));
  }
  return v;
}

function createConstantVector(dim, value) {
  return new Array(dim).fill(value);
}

// ─── CSL AND Tests (Cosine Similarity) ──────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'CSL AND (Cosine Similarity)' }) + '\n');

// Identical vectors: cosine similarity = 1.0
const vecA = createRandomVector(VECTOR_DIM);
assertClose(cslAnd(vecA, vecA), 1.0, LOOSE_EPSILON,
  'AND of identical vectors === 1.0');

// Normalized identical vectors
const normA = normalize(vecA);
assertClose(cslAnd(normA, normA), 1.0, LOOSE_EPSILON,
  'AND of identical normalized vectors === 1.0');

// Orthogonal vectors: cosine similarity = 0.0
const orthoA = createUnitVector(VECTOR_DIM, 0);
const orthoB = createUnitVector(VECTOR_DIM, 1);
assertClose(cslAnd(orthoA, orthoB), 0.0, EPSILON,
  'AND of orthogonal unit vectors === 0.0');

// Anti-parallel vectors: cosine similarity = -1.0
const antiA = createUnitVector(VECTOR_DIM, 0);
const antiB = antiA.map(x => -x);
assertClose(cslAnd(antiA, antiB), -1.0, EPSILON,
  'AND of anti-parallel vectors === -1.0');

// Scaled vectors: cosine similarity unaffected by magnitude
const scaledA = vecA.map(x => x * PHI);
assertClose(cslAnd(vecA, scaledA), 1.0, LOOSE_EPSILON,
  'AND is scale-invariant (same direction, different magnitude)');

// Partially overlapping vectors
const partialA = createUnitVector(VECTOR_DIM, 0);
const partialB = normalize([1, 1, ...new Array(VECTOR_DIM - 2).fill(0)]);
const expectedPartialCos = 1 / Math.sqrt(2);
assertClose(cslAnd(partialA, partialB), expectedPartialCos, LOOSE_EPSILON,
  `AND of 45° vectors ≈ ${expectedPartialCos.toFixed(6)}`);

// Symmetry: AND(a, b) === AND(b, a)
const vecB = createRandomVector(VECTOR_DIM).map((x, i) => x + Math.sin(i * PSI2));
assertClose(cslAnd(vecA, vecB), cslAnd(vecB, vecA), EPSILON,
  'AND is symmetric: AND(a,b) === AND(b,a)');

// Range: cosine similarity bounded [-1, 1]
const cslAndResult = cslAnd(vecA, vecB);
assert(cslAndResult >= -1 - EPSILON && cslAndResult <= 1 + EPSILON,
  'AND result bounded in [-1, 1]');

// ─── CSL NOT Tests (Orthogonal Projection) ──────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'CSL NOT (Orthogonal Projection)' }) + '\n');

// NOT produces vector orthogonal to gate
const notResult = cslNot(vecA, orthoA);
assertClose(dotProduct(notResult, normalize(orthoA)), 0.0, LOOSE_EPSILON,
  'NOT result is orthogonal to gate vector');

// NOT of a vector along gate direction = zero vector
const alongGate = createUnitVector(VECTOR_DIM, 0).map(x => x * PHI);
const notAlongGate = cslNot(alongGate, createUnitVector(VECTOR_DIM, 0));
assertClose(magnitude(notAlongGate), 0.0, LOOSE_EPSILON,
  'NOT of vector along gate === zero vector');

// NOT preserves orthogonal component
const compositeVec = createUnitVector(VECTOR_DIM, 0).map((x, i) => i < 2 ? 1 : 0);
const gate = createUnitVector(VECTOR_DIM, 0);
const notComposite = cslNot(compositeVec, gate);
assertClose(notComposite[0], 0.0, LOOSE_EPSILON,
  'NOT removes gate component (index 0)');
assertClose(notComposite[1], 1.0, LOOSE_EPSILON,
  'NOT preserves orthogonal component (index 1)');

// Double NOT with same gate is idempotent
const doubleNot = cslNot(cslNot(vecA, orthoA), orthoA);
const singleNot = cslNot(vecA, orthoA);
for (let i = 0; i < VECTOR_DIM; i++) {
  if (Math.abs(doubleNot[i] - singleNot[i]) > LOOSE_EPSILON) {
    assert(false, 'Double NOT is idempotent');
    break;
  }
  if (i === VECTOR_DIM - 1) {
    assert(true, 'Double NOT is idempotent');
  }
}

// NOT reduces magnitude (removes a component)
assert(magnitude(cslNot(vecA, orthoA)) <= magnitude(vecA) + LOOSE_EPSILON,
  'NOT reduces or preserves magnitude');

// ─── CSL OR Tests (Superposition) ───────────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'CSL OR (Superposition)' }) + '\n');

// OR produces unit-length normalized vector
const orResult = cslOr(vecA, vecB);
assertClose(magnitude(orResult), 1.0, LOOSE_EPSILON,
  'OR result is unit-length normalized');

// OR of identical vectors = normalized self
const orSelf = cslOr(vecA, vecA);
const normSelf = normalize(vecA);
assertClose(cosineSimilarity(orSelf, normSelf), 1.0, LOOSE_EPSILON,
  'OR(v, v) === normalize(v)');

// OR symmetry
const orAB = cslOr(vecA, vecB);
const orBA = cslOr(vecB, vecA);
assertClose(cosineSimilarity(orAB, orBA), 1.0, LOOSE_EPSILON,
  'OR is symmetric: OR(a,b) === OR(b,a)');

// OR of orthogonal unit vectors: 45° result
const orOrtho = cslOr(orthoA, orthoB);
assertClose(magnitude(orOrtho), 1.0, LOOSE_EPSILON,
  'OR of orthogonal unit vectors is unit-length');
assertClose(orOrtho[0], 1 / Math.sqrt(2), LOOSE_EPSILON,
  'OR of orthogonal unit vectors: component[0] = 1/√2');
assertClose(orOrtho[1], 1 / Math.sqrt(2), LOOSE_EPSILON,
  'OR of orthogonal unit vectors: component[1] = 1/√2');

// OR result direction is between inputs
const simToA = cosineSimilarity(orResult, normalize(vecA));
const simToB = cosineSimilarity(orResult, normalize(vecB));
assert(simToA > 0 && simToB > 0,
  'OR result has positive similarity to both inputs');

// ─── CSL GATE Tests (Sigmoid Activation) ────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'CSL GATE (Sigmoid Activation)' }) + '\n');

// Gate at threshold = 0.5
assertClose(cslGate(CSL_GATES.include, CSL_GATES.include, FIB[7]), 0.5, LOOSE_EPSILON,
  'GATE at threshold === 0.5 (sigmoid midpoint)');

// Gate well above threshold → ~1.0
assert(cslGate(1.0, CSL_GATES.include, FIB[7]) > 0.99,
  'GATE well above threshold ≈ 1.0');

// Gate well below threshold → ~0.0
assert(cslGate(0.0, CSL_GATES.include, FIB[7]) < 0.01,
  'GATE well below threshold ≈ 0.0');

// Gate output bounded [0, 1]
for (let v = -2; v <= 2; v += 0.5) {
  const gateVal = cslGate(v, CSL_GATES.boost, FIB[7]);
  assert(gateVal >= 0 && gateVal <= 1,
    `GATE output bounded [0,1] for input ${v}: ${gateVal.toFixed(6)}`);
}

// Higher steepness → sharper transition
const gentleGate = cslGate(CSL_GATES.boost + 0.1, CSL_GATES.boost, FIB[5]); // steepness=8
const sharpGate = cslGate(CSL_GATES.boost + 0.1, CSL_GATES.boost, FIB[9]);  // steepness=55
assert(sharpGate > gentleGate,
  'Higher steepness produces sharper gate transition');

// Gate monotonically increasing
const gateValues = [];
for (let v = 0; v <= 1; v += 0.1) {
  gateValues.push(cslGate(v, CSL_GATES.boost, FIB[7]));
}
let isMonotonic = true;
for (let i = 1; i < gateValues.length; i++) {
  if (gateValues[i] < gateValues[i - 1] - LOOSE_EPSILON) { isMonotonic = false; break; }
}
assert(isMonotonic, 'GATE is monotonically increasing');

// ─── phiThreshold Tests ─────────────────────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'phiThreshold' }) + '\n');

assertClose(phiThreshold(0), 0.5, EPSILON,
  'phiThreshold(0) === 0.500 (even split)');

assertClose(phiThreshold(1), 1 / (1 + PSI), EPSILON,
  `phiThreshold(1) === ${(1 / (1 + PSI)).toFixed(6)}`);

assertClose(phiThreshold(2), 1 / (1 + PSI2), EPSILON,
  `phiThreshold(2) === ${(1 / (1 + PSI2)).toFixed(6)}`);

assert(phiThreshold(4) > 0.872 && phiThreshold(4) < 0.873,
  `phiThreshold(4) ≈ 0.873 (actual: ${phiThreshold(4).toFixed(6)})`);

// Threshold approaches 1.0 asymptotically
assert(phiThreshold(10) > 0.99,
  `phiThreshold(10) > 0.99 (approaches unity: ${phiThreshold(10).toFixed(6)})`);

// Threshold at negative level approaches 0 asymptotically
assert(phiThreshold(-10) < 0.01,
  `phiThreshold(-10) < 0.01 (approaches zero: ${phiThreshold(-10).toFixed(6)})`);

// Monotonically increasing
for (let i = -3; i <= 4; i++) {
  assert(phiThreshold(i + 1) > phiThreshold(i),
    `phiThreshold(${i + 1}) > phiThreshold(${i}) (monotonic)`);
}

// Symmetry around level 0: phiThreshold(n) + phiThreshold(-n) === 1
for (let i = 1; i <= 5; i++) {
  assertClose(phiThreshold(i) + phiThreshold(-i), 1.0, EPSILON,
    `phiThreshold(${i}) + phiThreshold(${-i}) === 1.0 (sigmoid symmetry)`);
}

// ─── CSL Gate Constants Ordering ─────────────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'CSL Gate Constants' }) + '\n');

assert(CSL_GATES.include < CSL_GATES.boost,
  'include < boost (gate ordering)');
assert(CSL_GATES.boost < CSL_GATES.inject,
  'boost < inject (gate ordering)');
assert(CSL_GATES.include > 0 && CSL_GATES.include < 1,
  'include gate in (0, 1)');
assert(CSL_GATES.boost > 0 && CSL_GATES.boost < 1,
  'boost gate in (0, 1)');
assert(CSL_GATES.inject > 0 && CSL_GATES.inject < 1,
  'inject gate in (0, 1)');

// CSL gate values are φ-derived
assertClose(CSL_GATES.include, PSI2, EPSILON,
  'include gate === PSI² ≈ 0.382');
assertClose(CSL_GATES.boost, PSI, EPSILON,
  'boost gate === PSI ≈ 0.618');
assertClose(CSL_GATES.include + CSL_GATES.boost, 1.0, EPSILON,
  'include + boost === 1.0 (complementary gates)');

// ─── Combined CSL Operation Tests ────────────────────────────────────────────
process.stdout.write(JSON.stringify({ section: 'Combined CSL Operations' }) + '\n');

// OR then AND with one input recovers high similarity
const combined = cslOr(vecA, vecB);
const simAfterOr = cslAnd(combined, normalize(vecA));
assert(simAfterOr > 0,
  'OR→AND preserves positive similarity with input');

// NOT then AND with gate = 0
const notted = cslNot(vecA, orthoA);
assertClose(cslAnd(notted, orthoA), 0.0, LOOSE_EPSILON,
  'NOT→AND with gate === 0 (orthogonality preserved)');

// GATE filters CSL AND results
const similarity = cslAnd(normalize(vecA), normalize(vecB));
const gatedSim = cslGate(Math.abs(similarity), CSL_GATES.include, FIB[7]);
assert(gatedSim >= 0 && gatedSim <= 1,
  'Gated similarity bounded [0, 1]');

// ─── Summary ─────────────────────────────────────────────────────────────────
process.stdout.write('\n' + JSON.stringify({
  suite: 'csl-gates',
  passed,
  failed,
  total: passed + failed,
  status: failed === 0 ? 'ALL PASS' : 'FAILURES',
}) + '\n');

process.exit(failed > 0 ? 1 : 0);
