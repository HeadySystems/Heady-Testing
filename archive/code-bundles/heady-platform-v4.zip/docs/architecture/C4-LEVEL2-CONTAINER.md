# C4 Level 2 — Container Diagram

> Heady™ Platform — All 62 services organized by domain
> © 2026 HeadySystems Inc. — Eric Haywood, Founder

```mermaid
graph TB
    subgraph Edge["Edge Layer (Cloudflare)"]
        CF_WORKER[Edge Worker<br/>KV cache, rate limiting<br/>φ-scaled TTLs]
        CF_PAGES[Cloudflare Pages<br/>9 static sites]
    end

    subgraph Gateway["Gateway Layer"]
        API_GW[api-gateway<br/>:3348]
        DOMAIN_RT[domain-router<br/>:3349]
        AUTH_SS[auth-session-server<br/>:3397]
    end

    subgraph Inference["Inference Domain"]
        BRAIN[heady-brain<br/>:3310]
        BRAINS[heady-brains<br/>:3311]
        INFER[heady-infer<br/>:3314]
        AI_RT[ai-router<br/>:3347]
        MODEL_GW[model-gateway<br/>:3350]
    end

    subgraph Memory["Memory Domain"]
        EMBED[heady-embed<br/>:3315]
        MEMORY[heady-memory<br/>:3316]
        VECTOR[heady-vector<br/>:3317]
        PROJ[heady-projection<br/>:3318]
        SEARCH[search-service<br/>:3401]
    end

    subgraph Agents["Agent Domain"]
        BEE_F[heady-bee-factory<br/>:3319]
        HIVE[heady-hive<br/>:3320]
        FED[heady-federation<br/>:3321]
    end

    subgraph Orchestration["Orchestration Domain"]
        SOUL[heady-soul<br/>:3312]
        COND[heady-conductor<br/>:3313]
        ORCH[heady-orchestration<br/>:3322]
        ASE[auto-success-engine<br/>:3333]
        HCFP[hcfullpipeline-executor<br/>:3334]
        CHAIN[heady-chain<br/>:3335]
        PROMPT[prompt-manager<br/>:3345]
        SAGA[saga-coordinator<br/>:3405]
    end

    subgraph Security["Security Domain"]
        GUARD[heady-guard<br/>:3323]
        SEC[heady-security<br/>:3324]
        GOV[heady-governance<br/>:3325]
        SECRET[secret-gateway<br/>:3346]
    end

    subgraph Monitoring["Monitoring Domain"]
        HEALTH[heady-health<br/>:3326]
        EVAL[heady-eval<br/>:3327]
        MAINT[heady-maintenance<br/>:3328]
        TEST[heady-testing<br/>:3329]
    end

    subgraph Web["Web Domain"]
        WEB[heady-web<br/>:3330]
        BUDDY[heady-buddy<br/>:3331]
        UI[heady-ui<br/>:3332]
        ONBOARD[heady-onboarding<br/>:3336]
        PILOT[heady-pilot-onboarding<br/>:3337]
        TASK_B[heady-task-browser<br/>:3338]
    end

    subgraph Integration["Integration Domain"]
        MCP[mcp-server<br/>:3351]
        GMCP[google-mcp<br/>:3352]
        MMCP[memory-mcp<br/>:3353]
        PMCP[perplexity-mcp<br/>:3354]
        JMCP[jules-mcp<br/>:3355]
        HF[huggingface-gateway<br/>:3356]
        COLAB[colab-gateway<br/>:3357]
        SILICON[silicon-bridge<br/>:3358]
        DISCORD[discord-bot<br/>:3359]
    end

    subgraph Specialized["Specialized Domain"]
        VINCI[heady-vinci<br/>:3340]
        AUTO[heady-autobiographer<br/>:3341]
        MIDI[heady-midi<br/>:3342]
        BUDGET[budget-tracker<br/>:3343]
        CLI[cli-service<br/>:3344]
        NOTIFY[notification-service<br/>:3398]
        ANALYTICS[analytics-service<br/>:3399]
        BILLING[billing-service<br/>:3400]
        SCHED[scheduler-service<br/>:3402]
        MIGRATE[migration-service<br/>:3403]
        ASSET[asset-pipeline<br/>:3404]
        FLAGS[feature-flag-service<br/>:3406]
    end

    subgraph Data["Data Layer"]
        CACHE[heady-cache<br/>:3336]
        PG[(PostgreSQL<br/>+ pgvector)]
        CONSUL[(Consul<br/>Service Discovery)]
        OTEL[(OpenTelemetry<br/>Collector)]
        NATS_Q[(NATS JetStream<br/>Event Mesh)]
    end

    CF_WORKER --> API_GW
    CF_PAGES --> DOMAIN_RT
    API_GW --> Inference
    API_GW --> Memory
    API_GW --> Agents
    API_GW --> Orchestration
    AUTH_SS --> GUARD
    BRAIN --> PG
    EMBED --> PG
    MEMORY --> PG
    VECTOR --> PG
    SEARCH --> PG

    style Edge fill:#0d1117,stroke:#00d4aa,color:#00d4aa
    style Gateway fill:#0d1117,stroke:#FFA726,color:#FFA726
    style Inference fill:#0d1117,stroke:#CE93D8,color:#CE93D8
    style Memory fill:#0d1117,stroke:#42A5F5,color:#42A5F5
    style Agents fill:#0d1117,stroke:#66BB6A,color:#66BB6A
    style Orchestration fill:#0d1117,stroke:#FF7043,color:#FF7043
    style Security fill:#0d1117,stroke:#EF5350,color:#EF5350
    style Monitoring fill:#0d1117,stroke:#FFEE58,color:#FFEE58
    style Web fill:#0d1117,stroke:#26C6DA,color:#26C6DA
    style Integration fill:#0d1117,stroke:#AB47BC,color:#AB47BC
    style Specialized fill:#0d1117,stroke:#8D6E63,color:#8D6E63
    style Data fill:#0d1117,stroke:#78909C,color:#78909C
```
