# C4 Level 3 — Component Diagram: CSL Engine

> Internal structure of the Continuous Semantic Logic engine
> © 2026 HeadySystems Inc. — Eric Haywood, Founder

```mermaid
graph TB
    subgraph CSL_Engine["CSL Engine (shared/js/csl-engine.js)"]
        AND_GATE[CSL AND Gate<br/>cos(a,b) = a·b / ‖a‖·‖b‖<br/>Semantic alignment measure]
        OR_GATE[CSL OR Gate<br/>normalize(a + b)<br/>Superposition / soft union]
        NOT_GATE[CSL NOT Gate<br/>a - proj_b(a)<br/>Orthogonal projection]
        IMPLY_GATE[CSL IMPLY Gate<br/>proj_b(a) = (a·b/‖b‖²)·b<br/>Component in direction of b]
        XOR_GATE[CSL XOR Gate<br/>normalize(a+b) - proj_mutual<br/>Exclusive components]
        CONSENSUS[CSL CONSENSUS<br/>Σ(wᵢ·vᵢ) / ‖Σ(wᵢ·vᵢ)‖<br/>Weighted centroid]
        SIGMOID_GATE[CSL GATE<br/>value × σ((cos-τ)/temp)<br/>Soft sigmoid gating]
    end

    subgraph PHI_Math["φ-Math Foundation (shared/js/phi-math.js)"]
        THRESHOLDS[phiThreshold(level)<br/>L0=0.500, L1=0.691<br/>L2=0.809, L3=0.882, L4=0.927]
        BACKOFF[phiBackoff(attempt)<br/>1000→1618→2618→4236ms<br/>φ-exponential growth]
        FIBONACCI[Fibonacci Sequence<br/>1,1,2,3,5,8,13,21,34<br/>55,89,144,233,377]
        FUSION[phiFusionWeights(n)<br/>[0.618, 0.382] for n=2<br/>ψ-geometric series]
    end

    subgraph Vector_Ops["Vector Operations"]
        COSINE[Cosine Similarity<br/>384-dimensional ℝᴰ]
        NORMALIZE[Vector Normalization<br/>v / ‖v‖ → unit sphere]
        PROJECT[Orthogonal Projection<br/>proj_b(a) = (a·b/‖b‖²)·b]
        SUPERPOSE[Superposition<br/>normalize(Σ vectors)]
    end

    subgraph Ternary["Ternary Logic"]
        TRUE_STATE[TRUE<br/>cos ≈ +1<br/>Aligned vectors]
        UNKNOWN_STATE[UNKNOWN<br/>cos ≈ 0<br/>Orthogonal vectors]
        FALSE_STATE[FALSE<br/>cos ≈ -1<br/>Antipodal vectors]
    end

    AND_GATE --> COSINE
    NOT_GATE --> PROJECT
    OR_GATE --> SUPERPOSE
    OR_GATE --> NORMALIZE
    IMPLY_GATE --> PROJECT
    SIGMOID_GATE --> THRESHOLDS
    CONSENSUS --> FUSION

    COSINE --> Ternary
    THRESHOLDS --> FIBONACCI

    style CSL_Engine fill:#0a2a1a,stroke:#00d4aa,stroke-width:2px,color:#00d4aa
    style PHI_Math fill:#1a1a2e,stroke:#CE93D8,color:#CE93D8
    style Vector_Ops fill:#1a1a2e,stroke:#42A5F5,color:#42A5F5
    style Ternary fill:#1a1a2e,stroke:#FFA726,color:#FFA726
```

## Mathematical Proofs

| Property | CSL Gate | Proof |
|----------|----------|-------|
| Commutativity | AND | cos(a,b) = cos(b,a) ✓ (dot product is commutative) |
| Idempotency | NOT | NOT(NOT(a,b),b) = NOT(a,b) ✓ (double projection unchanged) |
| Orthogonality | NOT | NOT(a,b) · b = 0 ✓ (result is perpendicular to gate) |
| Boundedness | GATE | 0 ≤ σ((cos-τ)/T) ≤ 1 ✓ (sigmoid is bounded) |
| Differentiability | GATE | σ is C∞ differentiable ✓ (valid activation function) |

## CSL vs Boolean Performance

| Metric | CSL | Boolean | Improvement |
|--------|-----|---------|-------------|
| Semantic negation success | 100% | 32% | 3.1× |
| Routing speed | 0.1s | 0.59s | 5.9× faster |
| Routing cost | $0.001 | $0.0018 | 43% cheaper |
| Classification accuracy | 94.7% | 91.2% | +3.5pp |
