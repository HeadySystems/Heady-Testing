# C4 Level 1 — System Context Diagram

> Heady™ Platform — How it relates to external systems and users
> © 2026 HeadySystems Inc. — Eric Haywood, Founder

```mermaid
graph TB
    subgraph Users
        DEV[Developer<br/>Uses HeadyBuddy, CLI,<br/>MCP tools]
        ENDUSER[End User<br/>Accesses 9 websites,<br/>AI chat, search]
        ADMIN[Admin<br/>Manages services via<br/>admin.headysystems.com]
        NONPROFIT[Nonprofit Partner<br/>Engages via<br/>HeadyConnection]
    end

    subgraph Heady Platform
        HEADY[Heady™ Sovereign AI OS<br/>62 microservices<br/>9 websites<br/>14 skills<br/>Drupal CMS]
    end

    subgraph External Systems
        FIREBASE[Firebase Auth<br/>Google OAuth,<br/>Email/Password,<br/>Anonymous]
        PGVECTOR[PostgreSQL + pgvector<br/>384-dim vector memory<br/>HNSW indexing]
        CLAUDE[Anthropic Claude<br/>Primary LLM inference]
        GPT[OpenAI GPT-4o<br/>Secondary LLM inference]
        GEMINI[Google Gemini<br/>Tertiary LLM inference]
        STRIPE[Stripe<br/>Billing, subscriptions,<br/>HeadyCoin ledger]
        GITHUB[GitHub<br/>HeadyMe repos,<br/>CI/CD pipelines]
        CF[Cloudflare<br/>CDN, Workers KV,<br/>edge caching, DNS]
        GCP[Google Cloud<br/>Cloud Run, Secret Manager,<br/>Cloud Build]
        NATS[NATS JetStream<br/>Async event mesh]
        DISCORD[Discord<br/>Bot integration]
        DRUPAL[Drupal CMS<br/>13 content types,<br/>headless API]
    end

    DEV --> HEADY
    ENDUSER --> HEADY
    ADMIN --> HEADY
    NONPROFIT --> HEADY

    HEADY --> FIREBASE
    HEADY --> PGVECTOR
    HEADY --> CLAUDE
    HEADY --> GPT
    HEADY --> GEMINI
    HEADY --> STRIPE
    HEADY --> GITHUB
    HEADY --> CF
    HEADY --> GCP
    HEADY --> NATS
    HEADY --> DISCORD
    HEADY --> DRUPAL

    style HEADY fill:#0a2a1a,stroke:#00d4aa,stroke-width:3px,color:#00d4aa
    style FIREBASE fill:#1a1a2e,stroke:#FFA726,color:#FFA726
    style PGVECTOR fill:#1a1a2e,stroke:#42A5F5,color:#42A5F5
    style CLAUDE fill:#1a1a2e,stroke:#CE93D8,color:#CE93D8
    style GPT fill:#1a1a2e,stroke:#66BB6A,color:#66BB6A
    style GEMINI fill:#1a1a2e,stroke:#29B6F6,color:#29B6F6
```
