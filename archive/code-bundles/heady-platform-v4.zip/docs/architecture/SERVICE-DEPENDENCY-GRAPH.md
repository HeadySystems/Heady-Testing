# Service Dependency Graph

> Heady™ Platform — Inter-service communication topology
> © 2026 HeadySystems Inc. — Eric Haywood, Founder
> 
> All connections are concurrent and equal — no service has priority over another.
> Communication is φ-timed with circuit breakers (Fibonacci: 89 open / 55 half-open / 144 close).

```mermaid
graph LR
    subgraph External["External Traffic"]
        CLIENT[Client Browser]
        MOBILE[Mobile App]
        CLI_USER[CLI / SDK]
    end

    subgraph Edge["Cloudflare Edge"]
        EDGE[Edge Worker<br/>KV Cache]
    end

    subgraph Ingress["Ingress"]
        API_GW[api-gateway<br/>:3348]
        DOMAIN_RT[domain-router<br/>:3349]
        AUTH[auth-session-server<br/>:3397]
    end

    subgraph Core_Inference["Core Inference"]
        BRAIN[heady-brain<br/>:3310]
        BRAINS[heady-brains<br/>:3311]
        INFER[heady-infer<br/>:3314]
        AI_RT[ai-router<br/>:3347]
        MODEL_GW[model-gateway<br/>:3350]
    end

    subgraph Core_Memory["Core Memory"]
        EMBED[heady-embed<br/>:3315]
        MEM[heady-memory<br/>:3316]
        VEC[heady-vector<br/>:3317]
        PROJ[heady-projection<br/>:3318]
        SEARCH[search-service<br/>:3401]
    end

    subgraph Core_Orch["Core Orchestration"]
        SOUL[heady-soul<br/>:3312]
        COND[heady-conductor<br/>:3313]
        ORCH[heady-orchestration<br/>:3322]
        SAGA[saga-coordinator<br/>:3405]
    end

    subgraph Pipelines["Pipelines"]
        ASE[auto-success-engine<br/>:3333]
        HCFP[hcfullpipeline<br/>:3334]
        CHAIN[heady-chain<br/>:3335]
    end

    subgraph Agents["Agent Layer"]
        BEE[heady-bee-factory<br/>:3319]
        HIVE[heady-hive<br/>:3320]
        FED[heady-federation<br/>:3321]
    end

    subgraph Security_Layer["Security"]
        GUARD[heady-guard<br/>:3323]
        SEC[heady-security<br/>:3324]
        GOV[heady-governance<br/>:3325]
        SECRET[secret-gateway<br/>:3346]
    end

    subgraph Platform["Platform Services"]
        CACHE[heady-cache<br/>:3336]
        FLAGS[feature-flag-service<br/>:3406]
        NOTIFY[notification-service<br/>:3398]
        BILLING[billing-service<br/>:3400]
        ANALYTICS[analytics-service<br/>:3399]
        SCHED[scheduler-service<br/>:3402]
    end

    subgraph Data["Data Layer"]
        PG[(PostgreSQL<br/>pgvector)]
        CONSUL[(Consul)]
        NATS[(NATS<br/>JetStream)]
        OTEL[(OpenTelemetry)]
    end

    %% External → Edge → Ingress
    CLIENT --> EDGE
    MOBILE --> EDGE
    CLI_USER --> API_GW
    EDGE --> API_GW
    EDGE --> DOMAIN_RT

    %% Ingress → Services
    API_GW --> BRAIN
    API_GW --> SEARCH
    API_GW --> AUTH
    API_GW --> GUARD
    DOMAIN_RT --> API_GW

    %% Inference chain
    BRAIN --> AI_RT
    AI_RT --> MODEL_GW
    MODEL_GW --> INFER
    BRAINS --> BRAIN

    %% Memory chain
    BRAIN --> EMBED
    EMBED --> VEC
    VEC --> PG
    MEM --> VEC
    MEM --> PG
    PROJ --> VEC
    SEARCH --> VEC
    SEARCH --> PG

    %% Orchestration
    SOUL --> COND
    COND --> ORCH
    ORCH --> BEE
    BEE --> HIVE
    HIVE --> FED
    SAGA --> NOTIFY
    SAGA --> EMBED
    SAGA --> AUTH

    %% Pipelines
    ASE --> BRAIN
    ASE --> EMBED
    HCFP --> ASE
    CHAIN --> HCFP

    %% Security
    AUTH --> GUARD
    GUARD --> SEC
    SEC --> GOV
    SECRET --> GOV

    %% Platform services → Data
    BILLING --> PG
    ANALYTICS --> PG
    FLAGS --> PG
    SCHED --> PG
    CACHE --> PG

    %% Event mesh
    NOTIFY --> NATS
    ANALYTICS --> NATS
    BILLING --> NATS
    SAGA --> NATS

    %% Observability
    BRAIN --> OTEL
    API_GW --> OTEL
    AUTH --> OTEL

    %% Service discovery
    API_GW --> CONSUL
    BRAIN --> CONSUL

    style Edge fill:#0d1117,stroke:#00d4aa,color:#00d4aa
    style Ingress fill:#0d1117,stroke:#FFA726,color:#FFA726
    style Core_Inference fill:#0d1117,stroke:#CE93D8,color:#CE93D8
    style Core_Memory fill:#0d1117,stroke:#42A5F5,color:#42A5F5
    style Core_Orch fill:#0d1117,stroke:#FF7043,color:#FF7043
    style Agents fill:#0d1117,stroke:#66BB6A,color:#66BB6A
    style Security_Layer fill:#0d1117,stroke:#EF5350,color:#EF5350
    style Platform fill:#0d1117,stroke:#26C6DA,color:#26C6DA
    style Data fill:#0d1117,stroke:#78909C,color:#78909C
```

## Dependency Matrix

| Service | Depends On | Depended By |
|---------|-----------|-------------|
| api-gateway | consul, heady-guard | All client-facing services |
| heady-brain | ai-router, heady-embed, pgvector | heady-brains, auto-success-engine |
| heady-embed | heady-vector, pgvector | heady-brain, search-service, saga-coordinator |
| heady-memory | heady-vector, pgvector | heady-projection, search-service |
| heady-conductor | heady-orchestration | heady-soul |
| saga-coordinator | pgvector, NATS, notification-service | api-gateway |
| auth-session-server | heady-guard, Firebase | api-gateway, saga-coordinator |
| search-service | heady-vector, pgvector | api-gateway |
| feature-flag-service | pgvector | All services (optional) |
| notification-service | NATS | saga-coordinator, billing-service |
| billing-service | pgvector, Stripe, NATS | api-gateway |

## Communication Patterns

| Pattern | Protocol | Used By |
|---------|----------|---------|
| Synchronous request | HTTP/REST | api-gateway → services |
| Async events | NATS JetStream | notification, analytics, billing |
| gRPC (future) | HTTP/2 | Inter-service high-frequency calls |
| WebSocket | WS/WSS | heady-buddy, notification-service |
| SSE | HTTP streaming | notification-service, heady-brain |
| Edge cache | Cloudflare KV | Edge worker → all read paths |
