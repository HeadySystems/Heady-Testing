# Heady™ Platform — Error Code Catalog

> All services operate as concurrent equals — NO priority/ranking.
> Founded by Eric Haywood. 58 services · 9 sites · φ-scaled.
> © 2024-2026 HeadySystems Inc. All Rights Reserved.

Every error response in the Heady™ platform includes a structured error code, HTTP status, description, and resolution. Error codes follow the format `{SERVICE_PREFIX}-{NNN}`.

Each service has 5 standard error codes plus service-specific codes.

---

## Standard Error Codes (per service)

Every service implements these 5 base codes:

| Suffix | HTTP | Description | Resolution |
|--------|------|-------------|------------|
| `-001` | 503 | Service unavailable | Check health endpoint, verify container is running, check circuit breaker state |
| `-002` | 401 | Authentication failed | Verify `__Host-heady_session` cookie is present and valid, check auth-session-server |
| `-003` | 400 | Input validation failed | Check request body against JSON schema, verify required fields |
| `-004` | 502 | Upstream dependency failed | Check dependent service health, verify network connectivity on heady-mesh |
| `-005` | 429 | Rate limit exceeded (bulkhead full) | Retry after Fibonacci backoff (1s, 2s, 3s, 5s, 8s), check bulkhead max concurrent (55) |

---

## Core Intelligence Services (Ports 3310-3318)

### heady-brain (Port 3310)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| BRAIN-001 | 503 | Service unavailable | `curl localhost:3310/health` — restart if unhealthy |
| BRAIN-002 | 401 | Authentication failed | Verify session cookie, call auth-session-server /session/verify |
| BRAIN-003 | 400 | Input validation failed | Check inference request body: prompt required, max_tokens must be Fibonacci |
| BRAIN-004 | 502 | Upstream dependency failed | Check model-gateway, ai-router health |
| BRAIN-005 | 429 | Bulkhead full | Reduce concurrent requests, current max: 55 |
| BRAIN-006 | 422 | Prompt exceeds context window | Reduce prompt length, current max tokens: φ-scaled |
| BRAIN-007 | 408 | Inference timeout | Model response exceeded 89s (Fibonacci timeout) |

### heady-brains (Port 3311)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| BRAINS-001 | 503 | Service unavailable | `curl localhost:3311/health` |
| BRAINS-002 | 401 | Authentication failed | Verify session cookie |
| BRAINS-003 | 400 | Input validation failed | Check multi-brain coordination request |
| BRAINS-004 | 502 | Upstream dependency failed | Check heady-brain instances |
| BRAINS-005 | 429 | Bulkhead full | Reduce concurrent multi-brain requests |
| BRAINS-006 | 409 | Brain coordination conflict | Multiple brains returned conflicting results — CSL fusion applied |

### heady-soul (Port 3312)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| SOUL-001 | 503 | Service unavailable | `curl localhost:3312/health` |
| SOUL-002 | 401 | Authentication failed | Verify session cookie |
| SOUL-003 | 400 | Input validation failed | Check soul context request body |
| SOUL-004 | 502 | Upstream dependency failed | Check heady-memory, heady-brain |
| SOUL-005 | 429 | Bulkhead full | Reduce concurrent requests |
| SOUL-006 | 422 | Context depth exceeded | Reduce context chain length, max depth: FIB[7] (21) |

### heady-conductor (Port 3313)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| CONDUCTOR-001 | 503 | Service unavailable | `curl localhost:3313/health` |
| CONDUCTOR-002 | 401 | Authentication failed | Verify session cookie |
| CONDUCTOR-003 | 400 | Input validation failed | Check orchestration request |
| CONDUCTOR-004 | 502 | Upstream dependency failed | Check agent services (bee-factory, hive) |
| CONDUCTOR-005 | 429 | Bulkhead full | Too many concurrent orchestrations |
| CONDUCTOR-006 | 408 | Orchestration timeout | Agent coordination exceeded 89s |
| CONDUCTOR-007 | 422 | No qualifying agents | No agents above CSL include gate (0.382) |

### heady-infer (Port 3314)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| INFER-001 | 503 | Service unavailable | `curl localhost:3314/health` |
| INFER-002 | 401 | Authentication failed | Verify session cookie |
| INFER-003 | 400 | Input validation failed | Check inference parameters |
| INFER-004 | 502 | Model gateway unreachable | Check model-gateway at :3352 |
| INFER-005 | 429 | Bulkhead full | Reduce concurrent inference requests |
| INFER-006 | 422 | Model not available | Requested model not in registry |
| INFER-007 | 413 | Input too large | Reduce input size, max: FIB[12] * 1024 bytes |

### heady-embed (Port 3315)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| EMBED-001 | 503 | Service unavailable | `curl localhost:3315/health` |
| EMBED-002 | 401 | Authentication failed | Verify session cookie |
| EMBED-003 | 400 | Input validation failed | Check embedding request: text field required |
| EMBED-004 | 502 | Embedding model unreachable | Check huggingface-gateway, model-gateway |
| EMBED-005 | 429 | Bulkhead full | Reduce concurrent embedding requests |
| EMBED-006 | 422 | Dimension mismatch | Output dimension must be 384 (VECTOR_DIM) |

### heady-memory (Port 3316)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| MEMORY-001 | 503 | Service unavailable | `curl localhost:3316/health` |
| MEMORY-002 | 401 | Authentication failed | Verify session cookie |
| MEMORY-003 | 400 | Input validation failed | Check memory store/retrieve request |
| MEMORY-004 | 502 | pgvector unreachable | Check PostgreSQL at :5432 |
| MEMORY-005 | 429 | Bulkhead full | Reduce concurrent memory operations |
| MEMORY-006 | 404 | Memory not found | Memory ID does not exist in store |
| MEMORY-007 | 422 | Vector dimension invalid | Embedding must be 384 dimensions |

### heady-vector (Port 3317)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| VECTOR-001 | 503 | Service unavailable | `curl localhost:3317/health` |
| VECTOR-002 | 401 | Authentication failed | Verify session cookie |
| VECTOR-003 | 400 | Input validation failed | Check vector operation request |
| VECTOR-004 | 502 | pgvector unreachable | Check PostgreSQL at :5432 |
| VECTOR-005 | 429 | Bulkhead full | Reduce concurrent vector operations |
| VECTOR-006 | 422 | Vector dimension mismatch | Must be 384 dimensions (VECTOR_DIM) |
| VECTOR-007 | 404 | Vector not found | Document ID not in heady_vectors table |

### heady-projection (Port 3318)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| PROJECTION-001 | 503 | Service unavailable | `curl localhost:3318/health` |
| PROJECTION-002 | 401 | Authentication failed | Verify session cookie |
| PROJECTION-003 | 400 | Input validation failed | Check projection request |
| PROJECTION-004 | 502 | Upstream dependency failed | Check heady-vector, heady-embed |
| PROJECTION-005 | 429 | Bulkhead full | Reduce concurrent projections |
| PROJECTION-006 | 422 | Source dimension unsupported | Input dimension cannot be projected to 384 |

---

## Agent & Bee Services (Ports 3319-3322)

### heady-bee-factory (Port 3319)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| BEEFACTORY-001 | 503 | Service unavailable | `curl localhost:3319/health` |
| BEEFACTORY-002 | 401 | Authentication failed | Verify session cookie |
| BEEFACTORY-003 | 400 | Input validation failed | Check bee creation request |
| BEEFACTORY-004 | 502 | Upstream dependency failed | Check heady-hive |
| BEEFACTORY-005 | 429 | Bulkhead full | Too many concurrent bee spawns |
| BEEFACTORY-006 | 422 | Bee template invalid | Template must define capabilities and CSL thresholds |

### heady-hive (Port 3320)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| HIVE-001 | 503 | Service unavailable | `curl localhost:3320/health` |
| HIVE-002 | 401 | Authentication failed | Verify session cookie |
| HIVE-003 | 400 | Input validation failed | Check hive operation request |
| HIVE-004 | 502 | Upstream dependency failed | Check bee-factory, orchestration |
| HIVE-005 | 429 | Bulkhead full | Hive at capacity — max bees: FIB[12] (233) |
| HIVE-006 | 409 | Bee coordination conflict | Concurrent bee results conflicted |

### heady-orchestration (Port 3321)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| ORCH-001 | 503 | Service unavailable | `curl localhost:3321/health` |
| ORCH-002 | 401 | Authentication failed | Verify session cookie |
| ORCH-003 | 400 | Input validation failed | Check orchestration request |
| ORCH-004 | 502 | Upstream dependency failed | Check conductor, hive, bee-factory |
| ORCH-005 | 429 | Bulkhead full | Too many concurrent orchestrations |
| ORCH-006 | 408 | Orchestration timeout | Exceeded 89s Fibonacci timeout |

### heady-federation (Port 3322)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| FEDERATION-001 | 503 | Service unavailable | `curl localhost:3322/health` |
| FEDERATION-002 | 401 | Authentication failed | Verify session cookie |
| FEDERATION-003 | 400 | Input validation failed | Check federation request |
| FEDERATION-004 | 502 | Upstream dependency failed | Check orchestration, external gateways |
| FEDERATION-005 | 429 | Bulkhead full | Too many concurrent federation requests |
| FEDERATION-006 | 403 | Federation peer rejected | Remote peer denied federation handshake |

---

## Security & Governance (Ports 3323-3325)

### heady-guard (Port 3323)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| GUARD-001 | 503 | Service unavailable | `curl localhost:3323/health` |
| GUARD-002 | 401 | Authentication failed | Verify session cookie |
| GUARD-003 | 400 | Input validation failed | Check guard check request |
| GUARD-004 | 502 | Upstream dependency failed | Check auth-session-server, security |
| GUARD-005 | 429 | Bulkhead full | Too many concurrent guard checks |
| GUARD-006 | 403 | Access denied by policy | CSL governance score below include gate |

### heady-security (Port 3324)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| SECURITY-001 | 503 | Service unavailable | `curl localhost:3324/health` |
| SECURITY-002 | 401 | Authentication failed | Verify session cookie |
| SECURITY-003 | 400 | Input validation failed | Check security scan request |
| SECURITY-004 | 502 | Upstream dependency failed | Check guard, governance |
| SECURITY-005 | 429 | Bulkhead full | Too many concurrent security scans |
| SECURITY-006 | 403 | Threat detected | Request flagged by security analysis |

### heady-governance (Port 3325)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| GOVERNANCE-001 | 503 | Service unavailable | `curl localhost:3325/health` |
| GOVERNANCE-002 | 401 | Authentication failed | Verify session cookie |
| GOVERNANCE-003 | 400 | Input validation failed | Check governance policy request |
| GOVERNANCE-004 | 502 | Upstream dependency failed | Check guard, security |
| GOVERNANCE-005 | 429 | Bulkhead full | Too many concurrent governance checks |
| GOVERNANCE-006 | 403 | Policy violation | Content or action violates governance policy |

---

## Monitoring & Health (Ports 3326-3329)

### heady-health (Port 3326)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| HEALTH-001 | 503 | Service unavailable | `curl localhost:3326/health` |
| HEALTH-002 | 401 | Authentication failed | Verify session cookie |
| HEALTH-003 | 400 | Input validation failed | Check health query parameters |
| HEALTH-004 | 502 | Upstream dependency failed | One or more monitored services unreachable |
| HEALTH-005 | 429 | Bulkhead full | Too many concurrent health aggregation requests |
| HEALTH-006 | 207 | Partial health data | Some services returned errors during aggregation |

### heady-eval (Port 3327)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| EVAL-001 | 503 | Service unavailable | `curl localhost:3327/health` |
| EVAL-002 | 401 | Authentication failed | Verify session cookie |
| EVAL-003 | 400 | Input validation failed | Check evaluation request |
| EVAL-004 | 502 | Upstream dependency failed | Check model services |
| EVAL-005 | 429 | Bulkhead full | Too many concurrent evaluations |
| EVAL-006 | 422 | Evaluation criteria invalid | Criteria must define CSL-compatible scoring |

### heady-maintenance (Port 3328)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| MAINTENANCE-001 | 503 | Service unavailable | `curl localhost:3328/health` |
| MAINTENANCE-002 | 401 | Authentication failed | Verify session cookie |
| MAINTENANCE-003 | 400 | Input validation failed | Check maintenance request |
| MAINTENANCE-004 | 502 | Upstream dependency failed | Check target service |
| MAINTENANCE-005 | 429 | Bulkhead full | Too many concurrent maintenance tasks |
| MAINTENANCE-006 | 409 | Maintenance window conflict | Another maintenance operation is active |

### heady-testing (Port 3329)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| TESTING-001 | 503 | Service unavailable | `curl localhost:3329/health` |
| TESTING-002 | 401 | Authentication failed | Verify session cookie |
| TESTING-003 | 400 | Input validation failed | Check test suite request |
| TESTING-004 | 502 | Upstream dependency failed | Check target service under test |
| TESTING-005 | 429 | Bulkhead full | Too many concurrent test suites |
| TESTING-006 | 422 | Test suite not found | Specified test suite ID does not exist |

---

## User-Facing Services (Ports 3330-3335)

### heady-web (Port 3330)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| WEB-001 | 503 | Service unavailable | `curl localhost:3330/health` |
| WEB-002 | 401 | Authentication failed | Verify session cookie |
| WEB-003 | 400 | Input validation failed | Check request parameters |
| WEB-004 | 502 | Upstream dependency failed | Check api-gateway, heady-brain |
| WEB-005 | 429 | Bulkhead full | Too many concurrent web requests |
| WEB-006 | 404 | Page not found | Requested route not registered |

### heady-buddy (Port 3331)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| BUDDY-001 | 503 | Service unavailable | `curl localhost:3331/health` |
| BUDDY-002 | 401 | Authentication failed | Verify session cookie |
| BUDDY-003 | 400 | Input validation failed | Check buddy interaction request |
| BUDDY-004 | 502 | Upstream dependency failed | Check heady-brain, heady-memory |
| BUDDY-005 | 429 | Bulkhead full | Too many concurrent buddy sessions |
| BUDDY-006 | 422 | Conversation context overflow | Reduce conversation history length |

### heady-ui (Port 3332)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| UI-001 | 503 | Service unavailable | `curl localhost:3332/health` |
| UI-002 | 401 | Authentication failed | Verify session cookie |
| UI-003 | 400 | Input validation failed | Check UI component request |
| UI-004 | 502 | Upstream dependency failed | Check api-gateway |
| UI-005 | 429 | Bulkhead full | Too many concurrent UI requests |
| UI-006 | 404 | Component not found | Requested UI component not registered |

### heady-onboarding (Port 3333)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| ONBOARD-001 | 503 | Service unavailable | `curl localhost:3333/health` |
| ONBOARD-002 | 401 | Authentication failed | Verify session cookie |
| ONBOARD-003 | 400 | Input validation failed | Check onboarding step request |
| ONBOARD-004 | 502 | Upstream dependency failed | Check auth-session-server |
| ONBOARD-005 | 429 | Bulkhead full | Too many concurrent onboarding flows |
| ONBOARD-006 | 409 | Onboarding already completed | User has already finished onboarding |

### heady-pilot-onboarding (Port 3334)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| PILOT-001 | 503 | Service unavailable | `curl localhost:3334/health` |
| PILOT-002 | 401 | Authentication failed | Verify session cookie |
| PILOT-003 | 400 | Input validation failed | Check pilot enrollment request |
| PILOT-004 | 502 | Upstream dependency failed | Check onboarding service |
| PILOT-005 | 429 | Bulkhead full | Too many concurrent pilot enrollments |
| PILOT-006 | 403 | Pilot program closed | Pilot enrollment period has ended |

### heady-task-browser (Port 3335)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| TASKBROWSER-001 | 503 | Service unavailable | `curl localhost:3335/health` |
| TASKBROWSER-002 | 401 | Authentication failed | Verify session cookie |
| TASKBROWSER-003 | 400 | Input validation failed | Check task query parameters |
| TASKBROWSER-004 | 502 | Upstream dependency failed | Check orchestration, conductor |
| TASKBROWSER-005 | 429 | Bulkhead full | Too many concurrent task queries |
| TASKBROWSER-006 | 404 | Task not found | Task ID does not exist |

---

## Pipeline & Workflow (Ports 3340-3343)

### auto-success-engine (Port 3340)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| ASE-001 | 503 | Service unavailable | `curl localhost:3340/health` |
| ASE-002 | 401 | Authentication failed | Verify session cookie |
| ASE-003 | 400 | Input validation failed | Check success criteria request |
| ASE-004 | 502 | Upstream dependency failed | Check dependent pipeline services |
| ASE-005 | 429 | Bulkhead full | Too many concurrent success evaluations |
| ASE-006 | 422 | Success criteria undefined | Pipeline must define success metrics |

### hcfullpipeline-executor (Port 3341)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| PIPELINE-001 | 503 | Service unavailable | `curl localhost:3341/health` |
| PIPELINE-002 | 401 | Authentication failed | Verify session cookie |
| PIPELINE-003 | 400 | Input validation failed | Check pipeline definition |
| PIPELINE-004 | 502 | Upstream dependency failed | Check pipeline stage services |
| PIPELINE-005 | 429 | Bulkhead full | Too many concurrent pipeline executions |
| PIPELINE-006 | 422 | Pipeline stage failed | A stage in the pipeline returned an error |
| PIPELINE-007 | 408 | Pipeline timeout | Execution exceeded Fibonacci timeout |

### heady-chain (Port 3342)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| CHAIN-001 | 503 | Service unavailable | `curl localhost:3342/health` |
| CHAIN-002 | 401 | Authentication failed | Verify session cookie |
| CHAIN-003 | 400 | Input validation failed | Check chain definition |
| CHAIN-004 | 502 | Upstream dependency failed | Check chain step services |
| CHAIN-005 | 429 | Bulkhead full | Too many concurrent chains |
| CHAIN-006 | 422 | Chain step failed | A step in the chain returned an error |

### heady-cache (Port 3343)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| CACHE-001 | 503 | Service unavailable | `curl localhost:3343/health` |
| CACHE-002 | 401 | Authentication failed | Verify session cookie |
| CACHE-003 | 400 | Input validation failed | Check cache operation request |
| CACHE-004 | 502 | Upstream dependency failed | Check cache backend |
| CACHE-005 | 429 | Bulkhead full | Too many concurrent cache operations |
| CACHE-006 | 404 | Cache miss | Key not found in cache |
| CACHE-007 | 413 | Cache entry too large | Value exceeds max cache entry size |

---

## AI Routing & Gateway (Ports 3350-3353)

### ai-router (Port 3350)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| AIROUTER-001 | 503 | Service unavailable | `curl localhost:3350/health` |
| AIROUTER-002 | 401 | Authentication failed | Verify session cookie |
| AIROUTER-003 | 400 | Input validation failed | Check routing request |
| AIROUTER-004 | 502 | All model gateways unavailable | Check google-mcp, huggingface-gateway, etc. |
| AIROUTER-005 | 429 | Bulkhead full | Too many concurrent routing requests |
| AIROUTER-006 | 422 | No qualifying models | No model gateway above CSL include gate for task type |

### api-gateway (Port 3351)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| APIGATEWAY-001 | 503 | Service unavailable | `curl localhost:3351/health` |
| APIGATEWAY-002 | 401 | Authentication failed | Verify session cookie or API key |
| APIGATEWAY-003 | 400 | Input validation failed | Check API request format |
| APIGATEWAY-004 | 502 | Upstream service failed | Check target service health |
| APIGATEWAY-005 | 429 | Rate limit exceeded | API rate limit hit — retry after backoff |
| APIGATEWAY-006 | 404 | Route not found | API endpoint does not exist |

### model-gateway (Port 3352)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| MODELGW-001 | 503 | Service unavailable | `curl localhost:3352/health` |
| MODELGW-002 | 401 | Authentication failed | Verify session cookie |
| MODELGW-003 | 400 | Input validation failed | Check model request parameters |
| MODELGW-004 | 502 | Model provider unreachable | Check external API connectivity |
| MODELGW-005 | 429 | Bulkhead full | Too many concurrent model requests |
| MODELGW-006 | 422 | Model not registered | Requested model ID not in gateway registry |

### domain-router (Port 3353)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| DOMAINROUTER-001 | 503 | Service unavailable | `curl localhost:3353/health` |
| DOMAINROUTER-002 | 401 | Authentication failed | Verify session cookie |
| DOMAINROUTER-003 | 400 | Input validation failed | Check domain routing request |
| DOMAINROUTER-004 | 502 | Target domain service failed | Check services in target domain |
| DOMAINROUTER-005 | 429 | Bulkhead full | Too many concurrent domain routing requests |
| DOMAINROUTER-006 | 404 | Domain not found | Requested domain not in routing table |

---

## External Integrations (Ports 3360-3368)

### mcp-server (Port 3360)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| MCP-001 | 503 | Service unavailable | `curl localhost:3360/health` |
| MCP-002 | 401 | Authentication failed | Verify session cookie |
| MCP-003 | 400 | Input validation failed | Check MCP protocol request |
| MCP-004 | 502 | MCP provider unreachable | Check MCP endpoint connectivity |
| MCP-005 | 429 | Bulkhead full | Too many concurrent MCP calls |
| MCP-006 | 422 | MCP protocol error | Invalid MCP message format |

### google-mcp (Port 3361)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| GOOGLEMCP-001 | 503 | Service unavailable | `curl localhost:3361/health` |
| GOOGLEMCP-002 | 401 | Authentication failed | Verify session cookie and Google API key |
| GOOGLEMCP-003 | 400 | Input validation failed | Check Google AI request |
| GOOGLEMCP-004 | 502 | Google API unreachable | Check Google AI API status |
| GOOGLEMCP-005 | 429 | Rate limit from Google | Google API rate limit — retry with Fibonacci backoff |
| GOOGLEMCP-006 | 403 | Google API quota exceeded | Check Google Cloud project quota |

### memory-mcp (Port 3362)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| MEMORYMCP-001 | 503 | Service unavailable | `curl localhost:3362/health` |
| MEMORYMCP-002 | 401 | Authentication failed | Verify session cookie |
| MEMORYMCP-003 | 400 | Input validation failed | Check memory protocol request |
| MEMORYMCP-004 | 502 | Memory backend unreachable | Check heady-memory, pgvector |
| MEMORYMCP-005 | 429 | Bulkhead full | Too many concurrent memory MCP operations |
| MEMORYMCP-006 | 404 | Memory context not found | Requested memory context does not exist |

### perplexity-mcp (Port 3363)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| PERPLEXITY-001 | 503 | Service unavailable | `curl localhost:3363/health` |
| PERPLEXITY-002 | 401 | Authentication failed | Verify Perplexity API key |
| PERPLEXITY-003 | 400 | Input validation failed | Check Perplexity query request |
| PERPLEXITY-004 | 502 | Perplexity API unreachable | Check Perplexity API status |
| PERPLEXITY-005 | 429 | Rate limit from Perplexity | Perplexity rate limit — retry with backoff |
| PERPLEXITY-006 | 422 | Query too complex | Simplify search query |

### jules-mcp (Port 3364)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| JULES-001 | 503 | Service unavailable | `curl localhost:3364/health` |
| JULES-002 | 401 | Authentication failed | Verify Jules API key |
| JULES-003 | 400 | Input validation failed | Check code analysis request |
| JULES-004 | 502 | Jules API unreachable | Check Jules API status |
| JULES-005 | 429 | Rate limit from Jules | Jules rate limit — retry with backoff |
| JULES-006 | 422 | Code analysis failed | Code input could not be parsed |

### huggingface-gateway (Port 3365)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| HFGW-001 | 503 | Service unavailable | `curl localhost:3365/health` |
| HFGW-002 | 401 | Authentication failed | Verify HuggingFace API token |
| HFGW-003 | 400 | Input validation failed | Check inference request |
| HFGW-004 | 502 | HuggingFace API unreachable | Check HF Inference API status |
| HFGW-005 | 429 | Rate limit from HuggingFace | HF rate limit — retry with backoff |
| HFGW-006 | 422 | Model loading | Model is loading on HF — retry after 13s |

### colab-gateway (Port 3366)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| COLAB-001 | 503 | Service unavailable | `curl localhost:3366/health` |
| COLAB-002 | 401 | Authentication failed | Verify Google OAuth token |
| COLAB-003 | 400 | Input validation failed | Check notebook execution request |
| COLAB-004 | 502 | Colab runtime unreachable | Check Google Colab API status |
| COLAB-005 | 429 | Colab quota exceeded | Colab compute quota hit |
| COLAB-006 | 408 | Notebook execution timeout | Notebook exceeded 89s timeout |

### silicon-bridge (Port 3367)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| SILICON-001 | 503 | Service unavailable | `curl localhost:3367/health` |
| SILICON-002 | 401 | Authentication failed | Verify session cookie |
| SILICON-003 | 400 | Input validation failed | Check silicon compute request |
| SILICON-004 | 502 | Silicon compute unreachable | Check silicon provider connectivity |
| SILICON-005 | 429 | Bulkhead full | Too many concurrent silicon operations |
| SILICON-006 | 422 | Compute format unsupported | Requested compute format not available |

### discord-bot (Port 3368)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| DISCORD-001 | 503 | Service unavailable | `curl localhost:3368/health` |
| DISCORD-002 | 401 | Authentication failed | Verify Discord bot token |
| DISCORD-003 | 400 | Input validation failed | Check bot command request |
| DISCORD-004 | 502 | Discord API unreachable | Check Discord API status |
| DISCORD-005 | 429 | Discord rate limit | Discord API rate limit — retry after header delay |
| DISCORD-006 | 403 | Bot permission denied | Bot lacks required Discord permissions |

---

## Specialized Services (Ports 3380-3393)

### heady-vinci (Port 3380)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| VINCI-001 | 503 | Service unavailable | `curl localhost:3380/health` |
| VINCI-002 | 401 | Authentication failed | Verify session cookie |
| VINCI-003 | 400 | Input validation failed | Check creative generation request |
| VINCI-004 | 502 | Image generation backend failed | Check model gateways |
| VINCI-005 | 429 | Bulkhead full | Too many concurrent creative operations |
| VINCI-006 | 422 | Content policy violation | Generated content flagged by governance |

### heady-autobiographer (Port 3381)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| AUTOBIO-001 | 503 | Service unavailable | `curl localhost:3381/health` |
| AUTOBIO-002 | 401 | Authentication failed | Verify session cookie |
| AUTOBIO-003 | 400 | Input validation failed | Check autobiography request |
| AUTOBIO-004 | 502 | Upstream dependency failed | Check heady-memory, heady-brain |
| AUTOBIO-005 | 429 | Bulkhead full | Too many concurrent autobiography sessions |
| AUTOBIO-006 | 422 | Insufficient memory data | Not enough stored memories for generation |

### heady-midi (Port 3382)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| MIDI-001 | 503 | Service unavailable | `curl localhost:3382/health` |
| MIDI-002 | 401 | Authentication failed | Verify session cookie |
| MIDI-003 | 400 | Input validation failed | Check MIDI generation request |
| MIDI-004 | 502 | Music generation backend failed | Check model gateways |
| MIDI-005 | 429 | Bulkhead full | Too many concurrent MIDI generations |
| MIDI-006 | 422 | Invalid MIDI parameters | Check tempo, key, time signature values |

### budget-tracker (Port 3390)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| BUDGET-001 | 503 | Service unavailable | `curl localhost:3390/health` |
| BUDGET-002 | 401 | Authentication failed | Verify session cookie |
| BUDGET-003 | 400 | Input validation failed | Check budget request |
| BUDGET-004 | 502 | Upstream dependency failed | Check billing-service |
| BUDGET-005 | 429 | Bulkhead full | Too many concurrent budget operations |
| BUDGET-006 | 422 | Budget exceeded | Operation would exceed budget limit |

### cli-service (Port 3391)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| CLI-001 | 503 | Service unavailable | `curl localhost:3391/health` |
| CLI-002 | 401 | Authentication failed | Verify session cookie or CLI token |
| CLI-003 | 400 | Input validation failed | Check CLI command request |
| CLI-004 | 502 | Upstream dependency failed | Check target service |
| CLI-005 | 429 | Bulkhead full | Too many concurrent CLI sessions |
| CLI-006 | 422 | Unknown command | CLI command not recognized |

### prompt-manager (Port 3392)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| PROMPT-001 | 503 | Service unavailable | `curl localhost:3392/health` |
| PROMPT-002 | 401 | Authentication failed | Verify session cookie |
| PROMPT-003 | 400 | Input validation failed | Check prompt template request |
| PROMPT-004 | 502 | Upstream dependency failed | Check heady-brain |
| PROMPT-005 | 429 | Bulkhead full | Too many concurrent prompt operations |
| PROMPT-006 | 404 | Prompt template not found | Template ID does not exist |

### secret-gateway (Port 3393)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| SECRETGW-001 | 503 | Service unavailable | `curl localhost:3393/health` |
| SECRETGW-002 | 401 | Authentication failed | Verify session cookie |
| SECRETGW-003 | 400 | Input validation failed | Check secret retrieval request |
| SECRETGW-004 | 502 | Secret store unreachable | Check secret backend connectivity |
| SECRETGW-005 | 429 | Bulkhead full | Too many concurrent secret operations |
| SECRETGW-006 | 403 | Secret access denied | Insufficient permissions for requested secret |
| SECRETGW-007 | 404 | Secret not found | Secret key does not exist |

---

## New Platform Services (Ports 3397-3404)

### auth-session-server (Port 3397)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| AUTH-001 | 503 | Service unavailable | `curl localhost:3397/health` |
| AUTH-002 | 401 | Firebase ID token invalid | Re-authenticate with Firebase client SDK |
| AUTH-003 | 400 | Input validation failed | Check session creation request body |
| AUTH-004 | 502 | Firebase Admin SDK unreachable | Check Firebase project config |
| AUTH-005 | 429 | Bulkhead full | Too many concurrent auth operations |
| AUTH-006 | 403 | Session replay detected | IP or User-Agent hash mismatch — re-authenticate |
| AUTH-007 | 410 | Session revoked | Session was explicitly revoked — re-authenticate |
| AUTH-008 | 422 | Cookie creation failed | Could not set httpOnly cookie |

### notification-service (Port 3398)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| NOTIFY-001 | 503 | Service unavailable | `curl localhost:3398/health` |
| NOTIFY-002 | 401 | Authentication failed | Verify session cookie |
| NOTIFY-003 | 400 | Input validation failed | Check notification request body |
| NOTIFY-004 | 502 | Delivery channel failed | Check WebSocket, SSE, or webhook endpoint |
| NOTIFY-005 | 429 | Notification queue full | Queue at Fibonacci max (233) — messages dropping |
| NOTIFY-006 | 404 | User notifications not found | User ID has no stored notifications |
| NOTIFY-007 | 422 | Invalid delivery channel | Channel must be: websocket, sse, webhook, or http |

### analytics-service (Port 3399)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| ANALYTICS-001 | 503 | Service unavailable | `curl localhost:3399/health` |
| ANALYTICS-002 | 401 | Authentication failed | Verify session cookie |
| ANALYTICS-003 | 400 | Input validation failed | Check analytics event body |
| ANALYTICS-004 | 502 | pgvector metadata store failed | Check PostgreSQL at :5432 |
| ANALYTICS-005 | 429 | Bulkhead full | Too many concurrent analytics writes |
| ANALYTICS-006 | 422 | PII detected in event | Event contains personally identifiable information — rejected |
| ANALYTICS-007 | 404 | Funnel not found | Funnel ID does not exist |

### billing-service (Port 3400)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| BILLING-001 | 503 | Service unavailable | `curl localhost:3400/health` |
| BILLING-002 | 401 | Authentication failed | Verify session cookie |
| BILLING-003 | 400 | Input validation failed | Check billing request body |
| BILLING-004 | 502 | Stripe API unreachable | Check Stripe API status and keys |
| BILLING-005 | 429 | Bulkhead full | Too many concurrent billing operations |
| BILLING-006 | 403 | Stripe webhook signature invalid | Check STRIPE_WEBHOOK_SECRET |
| BILLING-007 | 404 | Subscription not found | User has no active subscription |
| BILLING-008 | 422 | Invalid plan ID | Plan must be: starter, growth, scale, or enterprise |

### search-service (Port 3401)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| SEARCH-001 | 503 | Service unavailable | `curl localhost:3401/health` |
| SEARCH-002 | 401 | Authentication failed | Verify session cookie |
| SEARCH-003 | 400 | Input validation failed | Check search query body |
| SEARCH-004 | 502 | pgvector unreachable | Check PostgreSQL at :5432 |
| SEARCH-005 | 429 | Bulkhead full | Too many concurrent search queries |
| SEARCH-006 | 422 | Vector dimension mismatch | Embedding must be 384 dimensions |
| SEARCH-007 | 404 | Document not found | Document ID not in search index |

### scheduler-service (Port 3402)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| SCHEDULER-001 | 503 | Service unavailable | `curl localhost:3402/health` |
| SCHEDULER-002 | 401 | Authentication failed | Verify session cookie |
| SCHEDULER-003 | 400 | Input validation failed | Check job creation body |
| SCHEDULER-004 | 502 | Job webhook delivery failed | Check webhook target URL |
| SCHEDULER-005 | 429 | Bulkhead full | Too many concurrent scheduler operations |
| SCHEDULER-006 | 404 | Job not found | Job ID does not exist |
| SCHEDULER-007 | 422 | Invalid Fibonacci interval | Interval must be Fibonacci: 5, 8, 13, 21, 34, 55, 89... |
| SCHEDULER-008 | 409 | Job registry full | Max jobs reached (FIB[12] = 233) |

### migration-service (Port 3403)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| MIGRATION-001 | 503 | Service unavailable | `curl localhost:3403/health` |
| MIGRATION-002 | 401 | Authentication failed | Verify session cookie |
| MIGRATION-003 | 400 | Input validation failed | Check migration request |
| MIGRATION-004 | 502 | PostgreSQL unreachable | Check PostgreSQL at :5432 |
| MIGRATION-005 | 429 | Bulkhead full | Too many concurrent migration operations |
| MIGRATION-006 | 409 | Migration already applied | Target migration has already been run |
| MIGRATION-007 | 422 | Rollback failed | Down migration encountered an error |
| MIGRATION-008 | 404 | No pending migrations | All migrations are already applied |

### asset-pipeline (Port 3404)
| Code | HTTP | Description | Resolution |
|------|------|-------------|------------|
| ASSET-001 | 503 | Service unavailable | `curl localhost:3404/health` |
| ASSET-002 | 401 | Authentication failed | Verify session cookie |
| ASSET-003 | 400 | Input validation failed | Check asset upload request |
| ASSET-004 | 502 | CDN upload failed | Check CDN connectivity |
| ASSET-005 | 429 | Bulkhead full | Too many concurrent asset operations |
| ASSET-006 | 413 | File too large | Exceeds max size (FIB[12]² × 100 bytes) |
| ASSET-007 | 404 | Asset not found | Asset ID does not exist |
| ASSET-008 | 422 | Unsupported image format | Must be: webp, avif, jpeg, or png |

---

## Error Code Statistics

- **Total services**: 58
- **Standard codes (5 per service)**: 290
- **Service-specific codes**: 82
- **Total error codes**: 372
- **HTTP status distribution**: 400 (58), 401 (58), 403 (8), 404 (14), 408 (4), 409 (5), 410 (1), 413 (2), 422 (24), 429 (58), 502 (58), 503 (58)
