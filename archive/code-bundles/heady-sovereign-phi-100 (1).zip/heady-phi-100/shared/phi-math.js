/**
 * @fileoverview phi-math.js — Heady™ Sovereign Phi-100 Canonical Phi-Math Foundation
 * @version 3.2.3
 * @description
 *   The single source of truth for all golden-ratio mathematics used throughout
 *   the Heady™ Sovereign Phi-100 system. Every threshold, weight, backoff,
 *   token budget, and fusion coefficient in the platform derives from the
 *   constants and functions defined here.
 *
 *   Golden Ratio identity:  PHI = (1 + √5) / 2  ≈ 1.6180339887
 *   Inverse identity:       PSI = PHI - 1 = 1/PHI ≈ 0.6180339887
 *   Quadratic identity:     PHI² = PHI + 1       ≈ 2.6180339887
 *
 * @module phi-math
 * @author Heady™ Core Engineering
 */

'use strict';

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 1 — FUNDAMENTAL PHI CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * The Golden Ratio φ (phi).
 * Satisfies: PHI² = PHI + 1  and  PHI = (1 + √5) / 2.
 * Used as the universal growth and spacing coefficient throughout the system.
 * @constant {number}
 */
const PHI = 1.6180339887;

/**
 * The Inverse Golden Ratio ψ (psi) = 1/PHI = PHI - 1.
 * Appears naturally in decay, compression, and threshold hierarchies.
 * @constant {number}
 */
const PSI = 0.6180339887;

/**
 * PHI squared = PHI + 1 ≈ 2.6180339887.
 * Used for session-scope token budgets and second-order scaling factors.
 * @constant {number}
 */
const PHI_SQ = 2.6180339887;

/**
 * PHI cubed = PHI² × PHI = PHI² + PHI ≈ 4.2360679775.
 * Used for memory-scope token budgets and third-order scaling factors.
 * @constant {number}
 */
const PHI_CUBED = 4.2360679775;

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 2 — FIBONACCI SEQUENCE
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Canonical Fibonacci sequence for indices 1–20.
 * Each element F(i) satisfies F(i) = F(i-1) + F(i-2), F(1)=F(2)=1.
 * These values underpin resource-pool sizing, ring topology node counts,
 * and spacing scales across the entire Phi-100 platform.
 * @constant {number[]}
 */
const FIB = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765];

/**
 * Compute the nth Fibonacci number (1-indexed, memoized).
 * Returns undefined for n < 1.
 * @param {number} n - Position in the Fibonacci sequence (1-based).
 * @returns {number|undefined} F(n), or undefined if n is out of range.
 * @example
 * fib(10); // → 55
 * fib(20); // → 6765
 */
function fib(n) {
  if (n < 1 || !Number.isInteger(n)) return undefined;
  if (n <= FIB.length) return FIB[n - 1];
  // Extend beyond the pre-computed cache using the recurrence relation
  let a = FIB[FIB.length - 2];
  let b = FIB[FIB.length - 1];
  for (let i = FIB.length + 1; i <= n; i++) {
    const c = a + b;
    a = b;
    b = c;
  }
  return b;
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 3 — CSL (COSINE SIMILARITY LAYER) THRESHOLDS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute a phi-based confidence threshold for a given severity level.
 * Formula: 1 - PSI^level × spread
 * At level 0 → 1 - 1·0.5 = 0.5 (MINIMUM)
 * At level 4 → 1 - PSI⁴·0.5 ≈ 0.927 (CRITICAL)
 *
 * @param {number} level  - Severity level 0–4.
 * @param {number} [spread=0.5] - Scaling spread applied to PSI^level.
 * @returns {number} Threshold value in [0, 1].
 * @example
 * phiThreshold(0);       // → 0.5
 * phiThreshold(1);       // → 0.6909830056
 * phiThreshold(2);       // → 0.7639320225
 * phiThreshold(3);       // → 0.8090169944
 * phiThreshold(4);       // → 0.9270509831
 */
function phiThreshold(level, spread = 0.5) {
  return 1 - Math.pow(PSI, level) * spread;
}

/**
 * Canonical CSL (Cosine Similarity Layer) gate thresholds.
 * MINIMUM→CRITICAL follow the phiThreshold(level) series.
 * DEDUP is a hardened deduplication threshold set at 0.972.
 *
 * @constant {{MINIMUM: number, LOW: number, MEDIUM: number, HIGH: number, CRITICAL: number, DEDUP: number}}
 */
const CSL_THRESHOLDS = {
  /** phiThreshold(0) = 0.5 — bare minimum for content admittance */
  MINIMUM:  phiThreshold(0),
  /** phiThreshold(1) ≈ 0.691 — low-confidence acceptance floor */
  LOW:      phiThreshold(1),
  /** phiThreshold(2) ≈ 0.764 — medium confidence gate */
  MEDIUM:   phiThreshold(2),
  /** phiThreshold(3) ≈ 0.809 — high confidence gate (coherence floor) */
  HIGH:     phiThreshold(3),
  /** phiThreshold(4) ≈ 0.927 — critical confidence gate */
  CRITICAL: phiThreshold(4),
  /** Hard deduplication threshold — signals near-identical vector overlap */
  DEDUP:    0.972,
};

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 4 — BACKOFF & TIMING
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute an exponential-phi backoff delay for retry logic.
 * Base formula:  delay = baseMs × PHI^attempt
 * Jitter:        ±38.2% (= PSI²) of the computed delay — mirrors the
 *                inverse-square of the golden ratio, naturally bounded.
 * Capped at maxMs to prevent thundering-herd scenarios.
 *
 * @param {number} attempt - Zero-based retry attempt index (0 = first retry).
 * @param {number} [baseMs=1000] - Base delay in milliseconds.
 * @param {number} [maxMs=60000] - Hard cap on the returned delay.
 * @returns {number} Jittered delay in milliseconds, capped at maxMs.
 * @example
 * phiBackoff(0);  // ≈ 1000 ± 382 ms
 * phiBackoff(3);  // ≈ 4236 ± 1618 ms
 * phiBackoff(8);  // capped at 60000 ms
 */
function phiBackoff(attempt, baseMs = 1000, maxMs = 60000) {
  const raw   = baseMs * Math.pow(PHI, attempt);
  const jitter = raw * PSI * PSI * (2 * Math.random() - 1); // ±38.2% (PSI² ≈ 0.382)
  return Math.min(maxMs, Math.max(0, raw + jitter));
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 5 — FUSION WEIGHTS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Generate n phi-geometric fusion weights that sum to exactly 1.0.
 * Weight formula: w[i] = PSI^i / Σ(PSI^0 … PSI^(n-1))
 * The most-significant signal (i=0) always receives the largest weight;
 * each subsequent signal is discounted by a factor of PSI.
 *
 * @param {number} n - Number of signals to weight (n ≥ 1).
 * @returns {number[]} Array of n weights summing to 1.0, descending order.
 * @example
 * phiFusionWeights(3); // → [0.5728..., 0.2540..., 0.1728...]  (sum = 1.0)
 */
function phiFusionWeights(n) {
  if (n < 1) return [];
  const psiPows = Array.from({ length: n }, (_, i) => Math.pow(PSI, i));
  const total   = psiPows.reduce((acc, v) => acc + v, 0);
  return psiPows.map(v => v / total);
}

/**
 * Compute a 3-factor phi-weighted priority score.
 * Weights: [criticality × w0, urgency × w1, impact × w2]
 * where [w0, w1, w2] = phiFusionWeights(3).
 * All inputs should be in [0, 1]; output is in [0, 1].
 *
 * @param {number} criticality - How critical the task/event is (0–1).
 * @param {number} urgency     - How time-sensitive the task/event is (0–1).
 * @param {number} impact      - Expected downstream impact of the task/event (0–1).
 * @returns {number} Composite phi-weighted priority score in [0, 1].
 * @example
 * phiPriorityScore(1.0, 0.8, 0.6); // → 0.8728...
 */
function phiPriorityScore(criticality, urgency, impact) {
  const [w0, w1, w2] = phiFusionWeights(3);
  return criticality * w0 + urgency * w1 + impact * w2;
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 6 — TOKEN BUDGETS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute phi-scaled token budgets for each memory tier.
 * - working:   base                  (immediate context window)
 * - session:   base × PHI_SQ         (rolling session context)
 * - memory:    base × PHI^4          (long-term recall store)
 * - artifacts: base × PHI^6          (persistent artifact storage)
 *
 * @param {number} [base=8192] - Base token count (default: 8192).
 * @returns {{working: number, session: number, memory: number, artifacts: number}}
 * @example
 * phiTokenBudgets();
 * // → { working: 8192, session: 21450, memory: 56823, artifacts: 150572 }
 */
function phiTokenBudgets(base = 8192) {
  return {
    working:   Math.round(base),
    session:   Math.round(base * PHI_SQ),
    memory:    Math.round(base * Math.pow(PHI, 4)),
    artifacts: Math.round(base * Math.pow(PHI, 6)),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 7 — RESOURCE WEIGHTS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute an n-way phi-geometric resource split (identical math to
 * phiFusionWeights but semantically scoped to resource allocation).
 * Each tier receives PSI^i / Σ(PSI^0…PSI^(n-1)) of the total capacity.
 *
 * @param {number} n - Number of resource tiers (n ≥ 1).
 * @returns {number[]} n weights summing to 1.0, descending priority order.
 * @example
 * phiResourceWeights(4);
 * // → [0.4822..., 0.2980..., 0.1842..., 0.1138...]
 */
function phiResourceWeights(n) {
  return phiFusionWeights(n);
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 8 — PRESSURE & ALERT LEVELS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * System resource pressure bands defined by phi-geometric boundaries.
 * Each entry is [lowerBound, upperBound] (exclusive lower, inclusive upper).
 *
 * NOMINAL:   [0, PSI²]           ≈ [0, 0.382]   — healthy headroom
 * ELEVATED:  [PSI², PSI]         ≈ [0.382, 0.618] — above baseline
 * HIGH:      [PSI, 1-PSI³]       ≈ [0.618, 0.764] — attention required
 * CRITICAL:  [1-PSI⁴, 1.0]       ≈ [0.854, 1.0]  — immediate action
 *
 * @constant {{NOMINAL: number[], ELEVATED: number[], HIGH: number[], CRITICAL: number[]}}
 */
const PRESSURE_LEVELS = {
  NOMINAL:  [0,                      PSI * PSI],
  ELEVATED: [PSI * PSI,              PSI],
  HIGH:     [PSI,                    1 - PSI * PSI * PSI],
  CRITICAL: [1 - Math.pow(PSI, 4),   1.0],
};

/**
 * Scalar alert thresholds for progressive escalation triggers.
 * Derived from phi-inverse power series for natural harmonic spacing.
 *
 * warning:  PSI           ≈ 0.618
 * caution:  1 - PSI²      ≈ 0.618  (note: same as warning; caution = 1-PSI²)
 * critical: 1 - PSI³      ≈ 0.764
 * exceeded: 1 - PSI⁴      ≈ 0.854
 * hard_max: 1.0
 *
 * @constant {{warning: number, caution: number, critical: number, exceeded: number, hard_max: number}}
 */
const ALERT_THRESHOLDS = {
  warning:  PSI,
  caution:  1 - PSI * PSI,
  critical: 1 - PSI * PSI * PSI,
  exceeded: 1 - Math.pow(PSI, 4),
  hard_max: 1.0,
};

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 9 — EVICTION WEIGHTS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Memory-eviction scoring weights for the Elephant Memory layer.
 * Weights are calibrated to sum to 1.0 and reflect that importance is the
 * dominant signal, followed by recency, with relevance as a tiebreaker.
 * These values are inspired by the Fibonacci ratios 34/70, 21/70, 15/70.
 *
 * @constant {{importance: number, recency: number, relevance: number}}
 */
const EVICTION_WEIGHTS = {
  importance: 0.486,
  recency:    0.300,
  relevance:  0.214,
};

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 10 — VECTOR MATH
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute cosine similarity between two equal-length numeric vectors.
 * Returns a value in [-1, 1]; returns 0 if either vector has zero magnitude.
 * Used throughout the CSL pipeline for semantic proximity gating.
 *
 * @param {number[]} a - First vector (any length ≥ 1).
 * @param {number[]} b - Second vector (must match length of a).
 * @returns {number} Cosine similarity in [-1, 1].
 * @throws {Error} If vectors differ in length.
 * @example
 * cosineSimilarity([1,0,0], [1,0,0]); // → 1.0
 * cosineSimilarity([1,0,0], [0,1,0]); // → 0.0
 */
function cosineSimilarity(a, b) {
  if (a.length !== b.length) throw new Error('cosineSimilarity: vectors must have equal length');
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot  += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  return denom === 0 ? 0 : dot / denom;
}

/**
 * CSL gate: applies a phi-sigmoid gate to an input value based on cosine score.
 * Formula: value × sigmoid((cosScore - tau) / temperature)
 * where sigmoid(x) = 1 / (1 + e^(-x))
 *
 * A cosScore well above tau produces a gate near 1.0 (pass-through).
 * A cosScore well below tau suppresses the value toward 0.
 * temperature controls the gate's sharpness (lower = sharper cut-off).
 *
 * @param {number} value        - The raw signal value to gate.
 * @param {number} cosScore     - Cosine similarity score in [-1, 1].
 * @param {number} tau          - Threshold pivot (e.g. CSL_THRESHOLDS.MEDIUM).
 * @param {number} [temperature=0.1] - Sigmoid temperature (sharpness control).
 * @returns {number} Gated value in [0, value].
 * @example
 * cslGate(1.0, 0.85, CSL_THRESHOLDS.MEDIUM); // → ~0.985 (near pass-through)
 * cslGate(1.0, 0.50, CSL_THRESHOLDS.MEDIUM); // → ~0.073 (heavily suppressed)
 */
function cslGate(value, cosScore, tau, temperature = 0.1) {
  const logit  = (cosScore - tau) / temperature;
  const sigmoid = 1 / (1 + Math.exp(-logit));
  return value * sigmoid;
}

/**
 * Compute entropy-adaptive sampling temperature.
 * At zero entropy → temperature = PSI (≈0.618, conservative / focused).
 * At max entropy  → temperature = 1.0  (maximally exploratory).
 * Formula: PSI + (1 - PSI) × (entropy / maxEntropy)
 *
 * This ensures that when the system is uncertain (high entropy) it explores
 * more broadly, and when it is confident (low entropy) it focuses precisely.
 *
 * @param {number} entropy    - Current information entropy.
 * @param {number} maxEntropy - Maximum possible entropy for the distribution.
 * @returns {number} Adaptive temperature in [PSI, 1.0].
 * @example
 * adaptiveTemperature(0, 10);   // → 0.6180339887  (PSI, fully focused)
 * adaptiveTemperature(10, 10);  // → 1.0           (fully exploratory)
 * adaptiveTemperature(5, 10);   // → 0.809...      (balanced)
 */
function adaptiveTemperature(entropy, maxEntropy) {
  if (maxEntropy === 0) return PSI;
  return PSI + (1 - PSI) * (entropy / maxEntropy);
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 11 — PHI MULTI-SPLIT
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Recursively split a whole value into n parts using the PSI-geometric series.
 * Part formula: parts[i] = whole × PSI^i / Σ(PSI^0…PSI^(n-1))
 * Equivalent to phiFusionWeights(n).map(w => whole * w) but optimised for
 * direct resource allocation (e.g., token budgets, bandwidth, thread pools).
 *
 * Numerical note: the last element absorbs any floating-point residual so
 * that sum(parts) === whole exactly.
 *
 * @param {number} whole - Total resource quantity to split.
 * @param {number} n     - Number of parts (n ≥ 1).
 * @returns {number[]} n parts where sum ≈ whole (last part absorbs residual).
 * @example
 * phiMultiSplit(100, 3);
 * // → [57.28..., 35.40..., 21.87...]  (sum = 100)
 */
function phiMultiSplit(whole, n) {
  if (n < 1) return [];
  const weights = phiFusionWeights(n);
  const parts   = weights.map(w => whole * w);
  // Correct floating-point drift on the last element
  const allocated = parts.slice(0, -1).reduce((s, v) => s + v, 0);
  parts[parts.length - 1] = whole - allocated;
  return parts;
}

// ─────────────────────────────────────────────────────────────────────────────
//  MODULE EXPORTS
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
  // Constants
  PHI,
  PSI,
  PHI_SQ,
  PHI_CUBED,

  // Fibonacci
  FIB,
  fib,

  // Thresholds
  phiThreshold,
  CSL_THRESHOLDS,

  // Backoff & timing
  phiBackoff,

  // Fusion & scoring
  phiFusionWeights,
  phiPriorityScore,

  // Token budgets
  phiTokenBudgets,

  // Resource allocation
  phiResourceWeights,

  // Pressure & alert levels
  PRESSURE_LEVELS,
  ALERT_THRESHOLDS,

  // Memory eviction
  EVICTION_WEIGHTS,

  // Vector math & gates
  cosineSimilarity,
  cslGate,
  adaptiveTemperature,

  // Splitting
  phiMultiSplit,
};
