/**
 * @fileoverview self-healing-mesh.js — Heady™ Sovereign Phi-100 Self-Healing Mesh
 * @version 3.2.3
 * @description
 *   Implements the Self-Healing Mesh for the Heady™ Sovereign Phi-100 platform.
 *   Every component registered with the mesh is continuously monitored through a
 *   phi-governed lifecycle: HEALTHY → SUSPECT → QUARANTINED → RECOVERING → RESTORED.
 *
 *   Key design principles:
 *   - Circuit breaker trips at fib(5)=5 consecutive failures → automatic quarantine
 *   - Phi-backoff governs all recovery timing (attempt 0 → ~1000 ms … attempt 4 → ~6854 ms)
 *   - Quarantine TTL = PHI^6 × 1000 ≈ 17944 ms, then an automatic recovery probe
 *   - Coherence scoring via cosineSimilarity between live and healthy-baseline embeddings
 *   - Drift below CSL_THRESHOLDS.MEDIUM (≈ 0.764) escalates a component to SUSPECT
 *   - System health aggregated with phiFusionWeights(N) across all component scores
 *   - Canary validation gates the final RESTORED transition
 *   - Post-recovery cooldown of phiBackoff(3) base ≈ 4236 ms prevents immediate re-failure
 *
 * @module self-healing-mesh
 * @author Heady™ Core Engineering
 */

'use strict';

const EventEmitter = require('events');

const phiMath = require('../../shared/phi-math.js');

const {
  PHI,
  PSI,
  FIB,
  fib,
  CSL_THRESHOLDS,
  phiBackoff,
  phiFusionWeights,
  PRESSURE_LEVELS,
  ALERT_THRESHOLDS,
  cosineSimilarity,
  cslGate,
} = phiMath;

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 1 — CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Maximum consecutive failures before a component is quarantined.
 * Phi-harmonic: fib(5) = 5
 * @constant {number}
 */
const CIRCUIT_BREAKER_THRESHOLD = fib(5); // 5

/**
 * Maximum recovery attempts per quarantine cycle.
 * Phi-harmonic: fib(5) = 5
 * @constant {number}
 */
const MAX_RECOVERY_ATTEMPTS = fib(5); // 5

/**
 * Quarantine TTL in milliseconds.
 * Derived: PHI^6 × 1000 ≈ 17944 ms — the sixth phi-power timeout.
 * After this window elapses the mesh emits an automatic recovery probe.
 * @constant {number}
 */
const QUARANTINE_TTL_MS = Math.round(Math.pow(PHI, 6) * 1000); // 17944

/**
 * Post-recovery cooldown in milliseconds.
 * Derived: phiBackoff(3, 1000) base (no jitter) = PHI^3 × 1000 ≈ 4236 ms.
 * Prevents the component from being checked again immediately after RESTORED.
 * @constant {number}
 */
const RECOVERY_COOLDOWN_MS = Math.round(Math.pow(PHI, 3) * 1000); // 4236

/**
 * Coherence drift threshold.
 * Components whose live-vs-baseline cosine similarity falls below this value
 * are escalated to SUSPECT.  Equals CSL_THRESHOLDS.MEDIUM ≈ 0.764.
 * @constant {number}
 */
const DRIFT_THRESHOLD = CSL_THRESHOLDS.MEDIUM;

/**
 * Canary confidence threshold before a RECOVERING component is fully RESTORED.
 * Uses CSL_THRESHOLDS.HIGH ≈ 0.809 — one tier above the drift floor.
 * @constant {number}
 */
const CANARY_CONFIDENCE_THRESHOLD = CSL_THRESHOLDS.HIGH;

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 2 — LIFECYCLE STATE ENUMERATION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Enumeration of the five lifecycle states every mesh component can occupy.
 *
 * Allowed transitions (governed by {@link TRANSITION_SIGNALS}):
 *   HEALTHY       → SUSPECT        (FAILURE_DETECTED | THRESHOLD_BREACHED)
 *   SUSPECT       → HEALTHY        (health check passes, coherence restored)
 *   SUSPECT       → QUARANTINED    (THRESHOLD_BREACHED)
 *   QUARANTINED   → RECOVERING     (QUARANTINE_EXPIRED | manual attemptRecovery)
 *   RECOVERING    → RESTORED       (RECOVERY_SUCCESS + ATTESTATION_PASSED)
 *   RECOVERING    → QUARANTINED    (RECOVERY_FAILED)
 *   RESTORED      → HEALTHY        (attestation + canary pass)
 *   Any state     → QUARANTINED    (THRESHOLD_BREACHED beyond circuit breaker)
 *
 * @enum {string}
 */
const STATES = {
  HEALTHY:     'HEALTHY',
  SUSPECT:     'SUSPECT',
  QUARANTINED: 'QUARANTINED',
  RECOVERING:  'RECOVERING',
  RESTORED:    'RESTORED',
};

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 3 — FAILURE UNIT TYPES
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Enumeration of healable failure unit types the mesh can manage.
 * @enum {string}
 */
const COMPONENT_TYPES = {
  SERVICE:        'service',
  WORKER:         'worker',
  AGENT:          'agent',
  TOOL_CONNECTOR: 'tool_connector',
  PROVIDER_ROUTE: 'provider_route',
};

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 4 — TRANSITION SIGNAL ENUMERATION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Signals that drive state machine transitions within the mesh.
 *
 * FAILURE_DETECTED   — a single health-check failure was observed
 * THRESHOLD_BREACHED — consecutive failures reached fib(5)=5 (circuit breaker)
 * QUARANTINE_EXPIRED — the quarantine TTL (17944 ms) elapsed
 * RECOVERY_SUCCESS   — a recovery attempt completed successfully
 * RECOVERY_FAILED    — a recovery attempt did not succeed
 * ATTESTATION_PASSED — canary validation confirmed the component is trustworthy
 *
 * @enum {string}
 */
const TRANSITION_SIGNALS = {
  FAILURE_DETECTED:   'FAILURE_DETECTED',
  THRESHOLD_BREACHED: 'THRESHOLD_BREACHED',
  QUARANTINE_EXPIRED: 'QUARANTINE_EXPIRED',
  RECOVERY_SUCCESS:   'RECOVERY_SUCCESS',
  RECOVERY_FAILED:    'RECOVERY_FAILED',
  ATTESTATION_PASSED: 'ATTESTATION_PASSED',
};

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 5 — INTERNAL HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Compute a scalar health score for a component record.
 * Score is gated through the CSL sigmoid using coherence similarity so that
 * components with low embedding drift contribute strongly while drifting
 * components are softly penalised even before formal state changes.
 *
 * @param {ComponentRecord} record - The internal component record.
 * @returns {number} Health score in [0, 1].
 */
function _computeHealthScore(record) {
  // Base score from state
  const stateScore = _stateBaseScore(record.state);

  // Coherence factor: cosineSimilarity between live embedding and healthy baseline
  let coherence = 1.0;
  if (
    record.healthyEmbedding &&
    record.currentEmbedding &&
    record.healthyEmbedding.length === record.currentEmbedding.length
  ) {
    coherence = cosineSimilarity(record.currentEmbedding, record.healthyEmbedding);
    // Clamp to [0, 1] — negative similarity is treated as total incoherence
    coherence = Math.max(0, coherence);
  }

  // Apply CSL sigmoid gate: coherence well above DRIFT_THRESHOLD → near pass-through
  const gatedScore = cslGate(stateScore, coherence, DRIFT_THRESHOLD, PSI * PSI);

  return Math.min(1.0, Math.max(0, gatedScore));
}

/**
 * Map a lifecycle state to a base health score.
 * Uses phi-harmonic spacing so each tier is a PSI-step below the previous.
 *
 * HEALTHY     → 1.0
 * RESTORED    → 1 - PSI^4  ≈ 0.854
 * RECOVERING  → 1 - PSI^3  ≈ 0.764
 * SUSPECT     → 1 - PSI^2  ≈ 0.618
 * QUARANTINED → PSI^3       ≈ 0.236
 *
 * @param {string} state - One of the STATES values.
 * @returns {number} Base score in [0, 1].
 */
function _stateBaseScore(state) {
  switch (state) {
    case STATES.HEALTHY:     return 1.0;
    case STATES.RESTORED:    return ALERT_THRESHOLDS.exceeded;    // ≈ 0.854
    case STATES.RECOVERING:  return ALERT_THRESHOLDS.critical;    // ≈ 0.764
    case STATES.SUSPECT:     return ALERT_THRESHOLDS.warning;     // ≈ 0.618
    case STATES.QUARANTINED: return PSI * PSI * PSI;               // ≈ 0.236
    default:                 return 0;
  }
}

/**
 * Determine whether a load is within the NOMINAL pressure band.
 * Uses PRESSURE_LEVELS.NOMINAL = [0, PSI²] ≈ [0, 0.382].
 *
 * @param {number} load - Normalised load value in [0, 1].
 * @returns {boolean}
 */
function _isNominalPressure(load) {
  const [lo, hi] = PRESSURE_LEVELS.NOMINAL;
  return load >= lo && load <= hi;
}

/**
 * Return true when the given timestamp is within the recovery cooldown window.
 * @param {number|null} restoredAt - Epoch ms of last restoration, or null.
 * @returns {boolean}
 */
function _inCooldown(restoredAt) {
  if (!restoredAt) return false;
  return (Date.now() - restoredAt) < RECOVERY_COOLDOWN_MS;
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION 6 — SELFHEALINGMESH CLASS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @typedef {Object} ComponentConfig
 * @property {string}   id          - Unique component identifier.
 * @property {string}   type        - One of the {@link COMPONENT_TYPES} values.
 * @property {Function} healthCheck - Async function that resolves to a health result.
 * @property {number[]} [healthyEmbedding] - Reference embedding for coherence scoring.
 * @property {Object}   [meta]      - Optional metadata bag.
 */

/**
 * @typedef {Object} ComponentRecord
 * @property {string}        id                  - Component identifier.
 * @property {string}        type                - Component type.
 * @property {Function}      healthCheck         - Registered health-check function.
 * @property {string}        state               - Current lifecycle state.
 * @property {number}        consecutiveFailures - Rolling failure counter.
 * @property {number}        recoveryAttempts    - Attempts in the current cycle.
 * @property {number|null}   quarantinedAt       - Epoch ms of quarantine entry.
 * @property {number|null}   restoredAt          - Epoch ms of last restoration.
 * @property {number|null}   lastCheckedAt       - Epoch ms of last health check.
 * @property {string|null}   quarantineReason    - Human-readable quarantine cause.
 * @property {string|null}   quarantineTimer     - Node.js timer handle for TTL.
 * @property {number[]|null} healthyEmbedding    - Baseline embedding vector.
 * @property {number[]|null} currentEmbedding    - Most-recent live embedding.
 * @property {Object}        meta                - Arbitrary metadata.
 */

/**
 * @typedef {Object} HealthResult
 * @property {boolean}      healthy   - Whether the component is currently healthy.
 * @property {number[]}     [embedding] - Optional live embedding for coherence checks.
 * @property {string}       [reason]  - Explanatory message on failure.
 * @property {Object}       [details] - Arbitrary diagnostic payload.
 */

/**
 * @typedef {Object} SystemHealthReport
 * @property {number}   score         - Phi-fusion-weighted aggregate health in [0, 1].
 * @property {string}   pressureBand  - Current PRESSURE_LEVELS band name.
 * @property {string}   alertLevel    - Nearest ALERT_THRESHOLDS tier name.
 * @property {number}   total         - Total registered component count.
 * @property {number}   healthy       - Count in HEALTHY state.
 * @property {number}   suspect       - Count in SUSPECT state.
 * @property {number}   quarantined   - Count in QUARANTINED state.
 * @property {number}   recovering    - Count in RECOVERING state.
 * @property {number}   restored      - Count in RESTORED state.
 * @property {Object[]} components    - Per-component health detail.
 */

/**
 * SelfHealingMesh — monitors, quarantines, and auto-recovers registered
 * components using a phi-governed state machine.
 *
 * @extends EventEmitter
 *
 * @fires SelfHealingMesh#stateChange
 * @fires SelfHealingMesh#quarantined
 * @fires SelfHealingMesh#recovered
 * @fires SelfHealingMesh#healingFailed
 *
 * @example
 * const mesh = new SelfHealingMesh({ checkIntervalMs: 5000 });
 * mesh.registerComponent('api-gateway', 'service', async () => {
 *   const ok = await pingGateway();
 *   return { healthy: ok };
 * });
 * mesh.on('quarantined', ({ id, reason }) => logger.warn('quarantined', id, reason));
 * mesh.on('recovered',   ({ id })          => logger.info('recovered',   id));
 */
class SelfHealingMesh extends EventEmitter {

  // ───────────────────────────────────────────────────────────────────────────
  //  Constructor
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Create a new SelfHealingMesh instance.
   *
   * @param {Object}  [config={}]                - Configuration options.
   * @param {number}  [config.checkIntervalMs]   - Periodic health-poll interval (ms).
   *                                               Defaults to phiBackoff(4) base ≈ 6854 ms.
   * @param {boolean} [config.autoStart=false]   - Start the polling loop immediately.
   * @param {number}  [config.driftThreshold]    - Override the coherence drift threshold.
   * @param {number}  [config.circuitBreaker]    - Override consecutive-failure threshold.
   * @param {Object}  [config.meta={}]           - Arbitrary metadata stored on the mesh.
   */
  constructor(config = {}) {
    super();

    /**
     * Configuration record with phi-math defaults applied.
     * @type {Object}
     * @private
     */
    this._config = {
      checkIntervalMs:  config.checkIntervalMs  || Math.round(Math.pow(PHI, 4) * 1000), // ≈6854
      autoStart:        config.autoStart        || false,
      driftThreshold:   config.driftThreshold   || DRIFT_THRESHOLD,
      circuitBreaker:   config.circuitBreaker   || CIRCUIT_BREAKER_THRESHOLD,
      meta:             config.meta             || {},
    };

    /**
     * Registry of all managed components, keyed by component id.
     * @type {Map<string, ComponentRecord>}
     * @private
     */
    this._registry = new Map();

    /**
     * Node.js interval handle for the periodic health-poll loop.
     * @type {NodeJS.Timeout|null}
     * @private
     */
    this._pollTimer = null;

    /**
     * Mesh-level start timestamp (epoch ms).
     * @type {number}
     */
    this.startedAt = Date.now();

    if (this._config.autoStart) {
      this.startPolling();
    }
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  Registration
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Register a new component with the mesh.
   * If a component with the same id is already registered, this is a no-op
   * and the existing record is returned unchanged.
   *
   * @param {string}   id              - Unique identifier for this component.
   * @param {string}   type            - Component type; one of {@link COMPONENT_TYPES}.
   * @param {Function} healthCheck     - Async function returning {@link HealthResult}.
   * @param {Object}   [options={}]    - Additional registration options.
   * @param {number[]} [options.healthyEmbedding] - Baseline embedding for coherence.
   * @param {Object}   [options.meta={}]          - Arbitrary metadata.
   * @returns {ComponentRecord} The newly created (or existing) component record.
   * @throws {TypeError} If id, type, or healthCheck are missing or invalid types.
   *
   * @example
   * mesh.registerComponent('auth-service', 'service', checkAuthService, {
   *   healthyEmbedding: baselineVector,
   * });
   */
  registerComponent(id, type, healthCheck, options = {}) {
    if (!id || typeof id !== 'string') {
      throw new TypeError('registerComponent: id must be a non-empty string');
    }
    if (!Object.values(COMPONENT_TYPES).includes(type)) {
      throw new TypeError(
        `registerComponent: type "${type}" is not a valid COMPONENT_TYPE`
      );
    }
    if (typeof healthCheck !== 'function') {
      throw new TypeError('registerComponent: healthCheck must be a function');
    }

    if (this._registry.has(id)) {
      return this._registry.get(id);
    }

    /** @type {ComponentRecord} */
    const record = {
      id,
      type,
      healthCheck,
      state:               STATES.HEALTHY,
      consecutiveFailures: 0,
      recoveryAttempts:    0,
      quarantinedAt:       null,
      restoredAt:          null,
      lastCheckedAt:       null,
      quarantineReason:    null,
      quarantineTimer:     null,
      healthyEmbedding:    options.healthyEmbedding || null,
      currentEmbedding:    options.healthyEmbedding || null,
      meta:                options.meta || {},
    };

    this._registry.set(id, record);
    return record;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  Health Checks
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Run the registered health check for a single component and update its state.
   *
   * Health-check outcomes:
   *  - Pass (healthy=true):  reset consecutive-failure counter; restore HEALTHY if
   *                          coherence is above DRIFT_THRESHOLD and not in cooldown.
   *  - Fail (healthy=false): increment consecutive-failure counter; escalate state
   *                          via {@link SelfHealingMesh#transitionState}.
   *  - Drift detected:       coherence < DRIFT_THRESHOLD → FAILURE_DETECTED signal
   *                          even if the health-check itself returned healthy=true.
   *
   * @param {string} componentId - Registered component identifier.
   * @returns {Promise<HealthResult>} The result returned by the health-check function.
   * @throws {Error} If componentId is not registered.
   */
  async checkHealth(componentId) {
    const record = this._getRecord(componentId);

    // Skip components that are in a non-pollable state
    if (record.state === STATES.QUARANTINED) {
      return { healthy: false, reason: 'Component is quarantined' };
    }
    if (_inCooldown(record.restoredAt)) {
      return { healthy: true, reason: 'In post-recovery cooldown' };
    }

    let result;
    try {
      result = await record.healthCheck();
    } catch (err) {
      result = { healthy: false, reason: err.message || 'healthCheck threw' };
    }

    record.lastCheckedAt = Date.now();

    // Update live embedding if provided
    if (result.embedding && Array.isArray(result.embedding)) {
      record.currentEmbedding = result.embedding;

      // Lazily set baseline if not yet established
      if (!record.healthyEmbedding) {
        record.healthyEmbedding = result.embedding;
      }
    }

    // Check coherence drift (even on a "healthy" result)
    const hasDrift = this._detectDrift(record);

    if (!result.healthy || hasDrift) {
      record.consecutiveFailures += 1;

      const signal =
        record.consecutiveFailures >= this._config.circuitBreaker
          ? TRANSITION_SIGNALS.THRESHOLD_BREACHED
          : TRANSITION_SIGNALS.FAILURE_DETECTED;

      await this.transitionState(componentId, signal);
    } else {
      // Successful check — decay failure counter using PSI (golden-ratio decay)
      record.consecutiveFailures = Math.floor(record.consecutiveFailures * PSI);

      if (
        record.state === STATES.SUSPECT ||
        record.state === STATES.RESTORED
      ) {
        // Coherence restored: transition back to healthy
        const prevState = record.state;
        record.state = STATES.HEALTHY;
        this._emitStateChange(record, prevState, STATES.HEALTHY);
      }
    }

    return result;
  }

  /**
   * Run health checks for all registered components in parallel.
   * Uses Promise.allSettled so a single failing check does not abort the others.
   *
   * @returns {Promise<Map<string, HealthResult>>} Map of componentId → HealthResult.
   */
  async checkAllHealth() {
    const ids = Array.from(this._registry.keys());
    const settled = await Promise.allSettled(
      ids.map(id => this.checkHealth(id).then(r => ({ id, result: r })))
    );

    const results = new Map();
    for (const outcome of settled) {
      if (outcome.status === 'fulfilled') {
        results.set(outcome.value.id, outcome.value.result);
      } else {
        // Wrap rejection as a failed result
        const id = ids[settled.indexOf(outcome)];
        results.set(id, { healthy: false, reason: outcome.reason?.message });
      }
    }
    return results;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  State Machine
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Advance a component through the state machine in response to a signal.
   *
   * Valid transition map:
   * ```
   *  HEALTHY      + FAILURE_DETECTED   → SUSPECT
   *  HEALTHY      + THRESHOLD_BREACHED → QUARANTINED
   *  SUSPECT      + THRESHOLD_BREACHED → QUARANTINED
   *  SUSPECT      + FAILURE_DETECTED   → SUSPECT   (no-op, counter already incremented)
   *  QUARANTINED  + QUARANTINE_EXPIRED → RECOVERING
   *  RECOVERING   + RECOVERY_SUCCESS   → RESTORED  (pending attestation)
   *  RECOVERING   + RECOVERY_FAILED    → QUARANTINED
   *  RESTORED     + ATTESTATION_PASSED → HEALTHY
   * ```
   *
   * All other combinations are silently ignored (idempotent).
   *
   * @param {string} componentId - Registered component identifier.
   * @param {string} signal      - One of the {@link TRANSITION_SIGNALS} values.
   * @returns {Promise<void>}
   * @throws {Error} If componentId is not registered.
   */
  async transitionState(componentId, signal) {
    const record = this._getRecord(componentId);
    const current = record.state;

    switch (current) {
      case STATES.HEALTHY:
        if (signal === TRANSITION_SIGNALS.FAILURE_DETECTED) {
          record.state = STATES.SUSPECT;
          this._emitStateChange(record, current, STATES.SUSPECT);
        } else if (signal === TRANSITION_SIGNALS.THRESHOLD_BREACHED) {
          await this.quarantine(componentId, 'Circuit breaker tripped from HEALTHY');
        }
        break;

      case STATES.SUSPECT:
        if (signal === TRANSITION_SIGNALS.THRESHOLD_BREACHED) {
          await this.quarantine(componentId, 'Failure threshold breached from SUSPECT');
        }
        // FAILURE_DETECTED in SUSPECT: no state change, counter already updated
        break;

      case STATES.QUARANTINED:
        if (
          signal === TRANSITION_SIGNALS.QUARANTINE_EXPIRED ||
          signal === TRANSITION_SIGNALS.RECOVERY_SUCCESS
        ) {
          await this._enterRecovering(record);
        }
        break;

      case STATES.RECOVERING:
        if (signal === TRANSITION_SIGNALS.RECOVERY_SUCCESS) {
          await this._enterRestored(record);
        } else if (signal === TRANSITION_SIGNALS.RECOVERY_FAILED) {
          await this.quarantine(
            componentId,
            `Recovery failed (attempt ${record.recoveryAttempts}/${MAX_RECOVERY_ATTEMPTS})`
          );
        }
        break;

      case STATES.RESTORED:
        if (signal === TRANSITION_SIGNALS.ATTESTATION_PASSED) {
          record.state = STATES.HEALTHY;
          record.restoredAt = Date.now();
          this._emitStateChange(record, STATES.RESTORED, STATES.HEALTHY);
          /**
           * @event SelfHealingMesh#recovered
           * @type {Object}
           * @property {string} id   - Component identifier.
           * @property {string} type - Component type.
           * @property {number} at   - Epoch ms.
           */
          this.emit('recovered', { id: record.id, type: record.type, at: record.restoredAt });
        }
        break;

      default:
        break;
    }
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  Quarantine
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Isolate a component in QUARANTINED state and schedule the TTL-expiry probe.
   *
   * The quarantine TTL is QUARANTINE_TTL_MS ≈ 17944 ms (PHI^6 × 1000).
   * When the TTL fires the mesh automatically calls {@link SelfHealingMesh#attemptRecovery}.
   *
   * @param {string} componentId - Registered component identifier.
   * @param {string} [reason='Manual quarantine'] - Human-readable explanation.
   * @returns {Promise<void>}
   * @throws {Error} If componentId is not registered.
   *
   * @example
   * await mesh.quarantine('payment-worker', 'Latency SLA breach detected');
   */
  async quarantine(componentId, reason = 'Manual quarantine') {
    const record = this._getRecord(componentId);

    // Cancel any pre-existing TTL timer
    if (record.quarantineTimer) {
      clearTimeout(record.quarantineTimer);
      record.quarantineTimer = null;
    }

    const prevState = record.state;
    record.state            = STATES.QUARANTINED;
    record.quarantinedAt    = Date.now();
    record.quarantineReason = reason;
    record.recoveryAttempts = 0;

    this._emitStateChange(record, prevState, STATES.QUARANTINED);

    /**
     * @event SelfHealingMesh#quarantined
     * @type {Object}
     * @property {string} id     - Component identifier.
     * @property {string} type   - Component type.
     * @property {string} reason - Why it was quarantined.
     * @property {number} at     - Epoch ms.
     * @property {number} ttlMs  - Milliseconds until auto-recovery probe.
     */
    this.emit('quarantined', {
      id:     record.id,
      type:   record.type,
      reason: record.quarantineReason,
      at:     record.quarantinedAt,
      ttlMs:  QUARANTINE_TTL_MS,
    });

    // Schedule auto-recovery probe after TTL
    record.quarantineTimer = setTimeout(async () => {
      record.quarantineTimer = null;
      if (record.state === STATES.QUARANTINED) {
        await this.transitionState(componentId, TRANSITION_SIGNALS.QUARANTINE_EXPIRED);
      }
    }, QUARANTINE_TTL_MS);

    // Allow timer to be garbage-collected if the process exits
    if (record.quarantineTimer.unref) {
      record.quarantineTimer.unref();
    }
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  Recovery
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Attempt to recover a component that is in RECOVERING state.
   *
   * Recovery procedure:
   *  1. Increment attempt counter.
   *  2. Wait for phiBackoff(attempt) ms.
   *  3. Run the component's health check.
   *  4. On success → signal RECOVERY_SUCCESS → enter RESTORED.
   *  5. On failure:
   *     - If attempts < MAX_RECOVERY_ATTEMPTS → signal RECOVERY_FAILED → re-quarantine.
   *     - If attempts >= MAX_RECOVERY_ATTEMPTS → emit 'healingFailed', stay quarantined.
   *
   * @param {string} componentId - Registered component identifier.
   * @returns {Promise<boolean>} True if recovery succeeded, false otherwise.
   * @throws {Error} If componentId is not registered.
   *
   * @example
   * const healed = await mesh.attemptRecovery('db-connector');
   */
  async attemptRecovery(componentId) {
    const record = this._getRecord(componentId);

    // Guard: only attempt recovery when in RECOVERING state
    if (record.state !== STATES.RECOVERING) {
      if (record.state === STATES.QUARANTINED) {
        await this._enterRecovering(record);
      } else {
        return record.state === STATES.HEALTHY || record.state === STATES.RESTORED;
      }
    }

    record.recoveryAttempts += 1;
    const attempt = record.recoveryAttempts - 1; // zero-based for phiBackoff

    // Phi-backoff delay before each attempt
    const delay = phiBackoff(attempt);
    await _sleep(delay);

    let result;
    try {
      result = await record.healthCheck();
    } catch (err) {
      result = { healthy: false, reason: err.message || 'healthCheck threw during recovery' };
    }

    // Update live embedding if provided
    if (result.embedding && Array.isArray(result.embedding)) {
      record.currentEmbedding = result.embedding;
    }

    if (result.healthy) {
      await this.transitionState(componentId, TRANSITION_SIGNALS.RECOVERY_SUCCESS);
      return true;
    }

    // Failed attempt
    if (record.recoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
      // Exhausted all attempts — escalate to permanent failure signal
      /**
       * @event SelfHealingMesh#healingFailed
       * @type {Object}
       * @property {string} id       - Component identifier.
       * @property {string} type     - Component type.
       * @property {number} attempts - Number of recovery attempts made.
       * @property {string} reason   - Last failure reason.
       */
      this.emit('healingFailed', {
        id:       record.id,
        type:     record.type,
        attempts: record.recoveryAttempts,
        reason:   result.reason || 'Max recovery attempts exhausted',
      });
      // Re-quarantine to await manual intervention
      await this.quarantine(componentId, 'Max recovery attempts exhausted');
      return false;
    }

    // Still have attempts remaining — signal RECOVERY_FAILED (re-quarantine)
    await this.transitionState(componentId, TRANSITION_SIGNALS.RECOVERY_FAILED);
    return false;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  Restoration
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Restore a component from RESTORED to HEALTHY after canary validation.
   *
   * The restore flow:
   *  1. Run canary health check.
   *  2. Compute coherence: cosineSimilarity(current, healthy baseline).
   *  3. Gate the coherence score through cslGate at CANARY_CONFIDENCE_THRESHOLD.
   *  4. If gated score >= CANARY_CONFIDENCE_THRESHOLD → ATTESTATION_PASSED.
   *  5. Otherwise → back to QUARANTINED (coherence too low for full restore).
   *
   * @param {string} componentId - Registered component identifier.
   * @returns {Promise<boolean>} True if fully restored to HEALTHY, false otherwise.
   * @throws {Error} If componentId is not registered.
   *
   * @example
   * const fullyHealthy = await mesh.restore('auth-agent');
   */
  async restore(componentId) {
    const record = this._getRecord(componentId);

    if (record.state !== STATES.RESTORED) {
      return record.state === STATES.HEALTHY;
    }

    // Canary validation: run health check
    let canaryResult;
    try {
      canaryResult = await record.healthCheck();
    } catch (err) {
      canaryResult = { healthy: false, reason: err.message };
    }

    if (!canaryResult.healthy) {
      await this.quarantine(componentId, 'Canary validation failed during restore');
      return false;
    }

    // Update live embedding from canary result
    if (canaryResult.embedding && Array.isArray(canaryResult.embedding)) {
      record.currentEmbedding = canaryResult.embedding;
    }

    // Coherence attestation
    const coherenceScore = this._coherenceScore(record);
    const gated = cslGate(coherenceScore, coherenceScore, CANARY_CONFIDENCE_THRESHOLD, PSI * PSI);

    if (gated >= CANARY_CONFIDENCE_THRESHOLD) {
      await this.transitionState(componentId, TRANSITION_SIGNALS.ATTESTATION_PASSED);
      return true;
    }

    // Coherence below canary threshold — back to quarantine
    await this.quarantine(
      componentId,
      `Coherence score ${coherenceScore.toFixed(4)} below canary threshold ${CANARY_CONFIDENCE_THRESHOLD}`
    );
    return false;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  System Health Aggregation
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Compute an aggregate system health report.
   *
   * The scalar health score uses phiFusionWeights(N) across all N component
   * health scores sorted descending (healthiest components are most-weighted).
   * This reflects the system's real capacity: a few healthy nodes sustain
   * throughput; a few quarantined nodes are discounted via PSI-decay.
   *
   * @returns {SystemHealthReport}
   *
   * @example
   * const report = mesh.getSystemHealth();
   * console.log(`System health: ${(report.score * 100).toFixed(1)}%`);
   */
  getSystemHealth() {
    const records = Array.from(this._registry.values());
    const total = records.length;

    // Count per-state
    let healthy = 0, suspect = 0, quarantined = 0, recovering = 0, restored = 0;
    const scores = [];

    const components = records.map(record => {
      const score = _computeHealthScore(record);
      scores.push(score);

      switch (record.state) {
        case STATES.HEALTHY:     healthy++;     break;
        case STATES.SUSPECT:     suspect++;     break;
        case STATES.QUARANTINED: quarantined++; break;
        case STATES.RECOVERING:  recovering++;  break;
        case STATES.RESTORED:    restored++;    break;
      }

      return {
        id:                 record.id,
        type:               record.type,
        state:              record.state,
        score:              score,
        consecutiveFailures:record.consecutiveFailures,
        recoveryAttempts:   record.recoveryAttempts,
        lastCheckedAt:      record.lastCheckedAt,
        quarantineReason:   record.quarantineReason,
        coherence:          this._coherenceScore(record),
      };
    });

    // Phi-fusion weighted aggregate — sort descending so highest scores receive
    // the largest fusion weights (most-healthy components dominate the aggregate)
    const sortedScores = [...scores].sort((a, b) => b - a);
    let aggregateScore = 0;

    if (sortedScores.length > 0) {
      const weights = phiFusionWeights(sortedScores.length);
      aggregateScore = sortedScores.reduce((sum, s, i) => sum + s * weights[i], 0);
    }

    // Determine pressure band
    const pressureBand = this._pressureBand(1 - aggregateScore);

    // Determine alert level
    const alertLevel = this._alertLevel(1 - aggregateScore);

    return {
      score:       aggregateScore,
      pressureBand,
      alertLevel,
      total,
      healthy,
      suspect,
      quarantined,
      recovering,
      restored,
      components,
    };
  }

  /**
   * Return an array of component records currently in QUARANTINED state.
   *
   * @returns {ComponentRecord[]} Snapshot of quarantined components.
   *
   * @example
   * const blocked = mesh.getQuarantined();
   * blocked.forEach(c => console.log(c.id, c.quarantineReason));
   */
  getQuarantined() {
    return Array.from(this._registry.values())
      .filter(r => r.state === STATES.QUARANTINED);
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  Polling Lifecycle
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Start the periodic polling loop.
   * Calls {@link SelfHealingMesh#checkAllHealth} every `checkIntervalMs`.
   * Idempotent — safe to call multiple times.
   *
   * @returns {this} For chaining.
   */
  startPolling() {
    if (this._pollTimer) return this;
    this._pollTimer = setInterval(async () => {
      try {
        await this.checkAllHealth();
      } catch (_err) {
        // Swallow top-level errors — individual component errors are handled inside
      }
    }, this._config.checkIntervalMs);

    if (this._pollTimer.unref) {
      this._pollTimer.unref();
    }
    return this;
  }

  /**
   * Stop the periodic polling loop.
   * Does not affect quarantine TTL timers; those remain active.
   *
   * @returns {this} For chaining.
   */
  stopPolling() {
    if (this._pollTimer) {
      clearInterval(this._pollTimer);
      this._pollTimer = null;
    }
    return this;
  }

  /**
   * Gracefully shut down the mesh.
   * Stops polling, cancels all quarantine TTL timers, and removes all listeners.
   *
   * @returns {void}
   */
  destroy() {
    this.stopPolling();
    for (const record of this._registry.values()) {
      if (record.quarantineTimer) {
        clearTimeout(record.quarantineTimer);
        record.quarantineTimer = null;
      }
    }
    this.removeAllListeners();
    this._registry.clear();
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  Private Helpers
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Retrieve a component record by id or throw if not found.
   * @param {string} componentId
   * @returns {ComponentRecord}
   * @throws {Error}
   * @private
   */
  _getRecord(componentId) {
    const record = this._registry.get(componentId);
    if (!record) {
      throw new Error(`SelfHealingMesh: component "${componentId}" is not registered`);
    }
    return record;
  }

  /**
   * Compute cosine similarity between a component's current and healthy embeddings.
   * Returns 1.0 if no embeddings are set (no drift detectable).
   *
   * @param {ComponentRecord} record
   * @returns {number} Similarity in [0, 1].
   * @private
   */
  _coherenceScore(record) {
    if (
      !record.healthyEmbedding ||
      !record.currentEmbedding ||
      record.healthyEmbedding.length !== record.currentEmbedding.length
    ) {
      return 1.0; // No baseline available — assume coherent
    }
    const sim = cosineSimilarity(record.currentEmbedding, record.healthyEmbedding);
    return Math.max(0, sim);
  }

  /**
   * Return true when a component's coherence has drifted below DRIFT_THRESHOLD.
   *
   * @param {ComponentRecord} record
   * @returns {boolean}
   * @private
   */
  _detectDrift(record) {
    if (!record.healthyEmbedding || !record.currentEmbedding) return false;
    const sim = this._coherenceScore(record);
    return sim < this._config.driftThreshold;
  }

  /**
   * Transition a component into RECOVERING state and schedule the first attempt.
   *
   * @param {ComponentRecord} record
   * @returns {Promise<void>}
   * @private
   */
  async _enterRecovering(record) {
    const prevState = record.state;
    record.state            = STATES.RECOVERING;
    record.recoveryAttempts = 0;
    this._emitStateChange(record, prevState, STATES.RECOVERING);

    // Kick off the first recovery attempt
    // (non-blocking — fire-and-forget from the perspective of the caller)
    this.attemptRecovery(record.id).catch(() => {});
  }

  /**
   * Transition a component into RESTORED state after a successful health check.
   *
   * @param {ComponentRecord} record
   * @returns {Promise<void>}
   * @private
   */
  async _enterRestored(record) {
    const prevState = record.state;
    record.state            = STATES.RESTORED;
    record.consecutiveFailures = 0;
    this._emitStateChange(record, prevState, STATES.RESTORED);

    // Immediately attempt attestation / canary validation
    this.restore(record.id).catch(() => {});
  }

  /**
   * Emit a stateChange event with a structured payload.
   *
   * @param {ComponentRecord} record
   * @param {string} from - Previous state.
   * @param {string} to   - New state.
   * @private
   *
   * @fires SelfHealingMesh#stateChange
   */
  _emitStateChange(record, from, to) {
    /**
     * @event SelfHealingMesh#stateChange
     * @type {Object}
     * @property {string} id   - Component identifier.
     * @property {string} type - Component type.
     * @property {string} from - Previous state.
     * @property {string} to   - New state.
     * @property {number} at   - Epoch ms of transition.
     */
    this.emit('stateChange', {
      id:   record.id,
      type: record.type,
      from,
      to,
      at:   Date.now(),
    });
  }

  /**
   * Map a normalised load value to a PRESSURE_LEVELS band name.
   *
   * @param {number} load - Normalised load [0, 1].
   * @returns {string} Band name.
   * @private
   */
  _pressureBand(load) {
    if (load <= PRESSURE_LEVELS.NOMINAL[1])  return 'NOMINAL';
    if (load <= PRESSURE_LEVELS.ELEVATED[1]) return 'ELEVATED';
    if (load <= PRESSURE_LEVELS.HIGH[1])     return 'HIGH';
    return 'CRITICAL';
  }

  /**
   * Map a normalised load value to the nearest ALERT_THRESHOLDS tier name.
   *
   * @param {number} load - Normalised load [0, 1].
   * @returns {string} Alert tier name.
   * @private
   */
  _alertLevel(load) {
    if (load < ALERT_THRESHOLDS.warning)  return 'nominal';
    if (load < ALERT_THRESHOLDS.caution)  return 'warning';
    if (load < ALERT_THRESHOLDS.critical) return 'caution';
    if (load < ALERT_THRESHOLDS.exceeded) return 'critical';
    return 'exceeded';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  INTERNAL UTILITY
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Promise-based sleep helper.
 * @param {number} ms - Duration in milliseconds.
 * @returns {Promise<void>}
 * @private
 */
function _sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─────────────────────────────────────────────────────────────────────────────
//  MODULE EXPORTS
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
  SelfHealingMesh,
  STATES,
  COMPONENT_TYPES,
  TRANSITION_SIGNALS,
  // Phi-derived constants (useful for test assertions and external config)
  CIRCUIT_BREAKER_THRESHOLD,
  MAX_RECOVERY_ATTEMPTS,
  QUARANTINE_TTL_MS,
  RECOVERY_COOLDOWN_MS,
  DRIFT_THRESHOLD,
  CANARY_CONFIDENCE_THRESHOLD,
};
