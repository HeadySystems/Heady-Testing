'use strict';

/**
 * @fileoverview evolution-engine.js — Heady™ Sovereign Phi-100 Evolution Engine
 *
 * @description
 *   The "learning brain" of the Alive Software Architecture. Captures patterns
 *   from pipeline runs, detects semantic drift via cosine-similarity gating,
 *   proposes and evaluates phi-weighted evolutionary changes, and ensures the
 *   system continuously improves itself over time.
 *
 *   Core responsibilities:
 *     1. Pattern capture  — extract signal vectors from completed pipeline runs
 *     2. Drift detection  — compare live embeddings to reference baselines via CSL
 *     3. Evolution proposal — synthesise actionable improvement proposals
 *     4. Proposal evaluation — phi-fusion weighted scoring (benefit · risk · alignment)
 *     5. Evolution application — commit approved changes and update reference store
 *     6. Rollback            — revert failed evolutions safely
 *     7. Reporting           — drift summaries and full evolution audit log
 *
 *   Pattern store capacity: fib(14) = 377  (FIFO eviction when full)
 *   Drift threshold:        CSL_THRESHOLDS.HIGH  ≈ 0.809  (semantic coherence floor)
 *   Critical-drift floor:   CSL_THRESHOLDS.LOW   ≈ 0.691  (immediate alert trigger)
 *   Evolution scoring:      phiFusionWeights(3) over [benefit, risk, alignment]
 *   Auto-approval gate:     CSL_THRESHOLDS.HIGH  ≈ 0.809
 *   Evolution cooldown:     PHI^5 × 1000 ms      ≈ 11090 ms
 *   Generation numbering:   Fibonacci-indexed (F(1), F(2), F(3), …)
 *
 * @version 3.2.3
 * @module EvolutionEngine
 * @author Heady™ Core Engineering
 */

const EventEmitter = require('events');
const crypto = require('crypto');

const phiMath = require('../../shared/phi-math.js');

const {
  PHI,
  PSI,
  FIB,
  fib,
  CSL_THRESHOLDS,
  phiBackoff,
  phiFusionWeights,
  cosineSimilarity,
  cslGate,
  adaptiveTemperature,
  PRESSURE_LEVELS,
} = phiMath;

// ─────────────────────────────────────────────────────────────────────────────
//  DERIVED PHI CONSTANTS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Maximum number of patterns held in the pattern store.
 * fib(14) = 377 — a canonical Fibonacci cache-size boundary.
 * @constant {number}
 */
const PATTERN_STORE_MAX = fib(14); // 377

/**
 * Cosine-similarity threshold below which semantic drift is flagged.
 * Corresponds to CSL_THRESHOLDS.HIGH ≈ 0.809 (coherence floor).
 * @constant {number}
 */
const DRIFT_THRESHOLD = CSL_THRESHOLDS.HIGH; // ≈ 0.809

/**
 * Cosine-similarity threshold below which drift is deemed critical.
 * Corresponds to CSL_THRESHOLDS.LOW ≈ 0.691 — triggers an immediate alert.
 * @constant {number}
 */
const CRITICAL_DRIFT_THRESHOLD = CSL_THRESHOLDS.LOW; // ≈ 0.691

/**
 * Minimum phi-fusion evolution score required for automatic approval.
 * Maps to CSL_THRESHOLDS.HIGH ≈ 0.809.
 * @constant {number}
 */
const EVOLUTION_APPROVAL_GATE = CSL_THRESHOLDS.HIGH; // ≈ 0.809

/**
 * Minimum cooldown between successive evolution applications.
 * PHI^5 × 1000 ≈ 11090 ms — the fifth phi-power timeout tier.
 * @constant {number}
 */
const EVOLUTION_COOLDOWN_MS = Math.round(Math.pow(PHI, 5) * 1000); // 11090

/**
 * Phi-fusion weights for evolution scoring over three factors:
 * [0] benefit weight  ≈ 0.5728
 * [1] risk weight     ≈ 0.2540
 * [2] alignment weight ≈ 0.1728  (sum = 1.0)
 * @constant {number[]}
 */
const EVOLUTION_WEIGHTS = phiFusionWeights(3);

/**
 * Evolution proposal status codes.
 * @enum {string}
 */
const PROPOSAL_STATUS = {
  PENDING:  'PENDING',
  APPROVED: 'APPROVED',
  REJECTED: 'REJECTED',
  APPLIED:  'APPLIED',
  ROLLED_BACK: 'ROLLED_BACK',
};

/**
 * Drift severity codes.
 * @enum {string}
 */
const DRIFT_SEVERITY = {
  NONE:     'NONE',
  MODERATE: 'MODERATE',
  CRITICAL: 'CRITICAL',
};

// ─────────────────────────────────────────────────────────────────────────────
//  HELPER UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Generate a compact, unique ID using 8 hex characters from crypto entropy.
 * @returns {string} 8-character hexadecimal ID string.
 */
function _genId() {
  return crypto.randomBytes(4).toString('hex');
}

/**
 * Return the current high-resolution timestamp in milliseconds.
 * @returns {number} Current time in ms (Date.now() precision).
 */
function _now() {
  return Date.now();
}

/**
 * Compute Shannon entropy for a numeric distribution.
 * Each element is treated as a probability (will be normalised if needed).
 * Returns 0 for empty or uniform-zero distributions.
 *
 * @param {number[]} values - Raw probability or frequency values.
 * @returns {number} Shannon entropy H (nats or bits depending on log base).
 */
function _shannonEntropy(values) {
  if (!values || values.length === 0) return 0;
  const total = values.reduce((s, v) => s + Math.abs(v), 0);
  if (total === 0) return 0;
  return values.reduce((h, v) => {
    const p = Math.abs(v) / total;
    return p > 0 ? h - p * Math.log(p) : h;
  }, 0);
}

/**
 * Derive a Fibonacci generation number for an evolution index.
 * Generation 0 → fib(1)=1, generation 1 → fib(2)=1, generation 2 → fib(3)=2, …
 *
 * @param {number} index - Zero-based evolution count.
 * @returns {number} Fibonacci generation label.
 */
function _fibGeneration(index) {
  return fib(Math.min(index + 1, FIB.length));
}

/**
 * Extract a lightweight embedding vector from a pipeline result's metadata.
 * Produces a 16-dimensional float vector encoding execution signals.
 * Falls back to a zero vector if the result lacks expected fields.
 *
 * @param {Object} pipelineResult - Completed pipeline run result object.
 * @returns {number[]} 16-dimensional numeric embedding vector.
 */
function _extractEmbedding(pipelineResult) {
  const dim = 16;
  const vec = new Array(dim).fill(0);

  if (!pipelineResult || typeof pipelineResult !== 'object') return vec;

  const r = pipelineResult;

  // [0] Overall success rate (0–1)
  vec[0] = typeof r.successRate === 'number' ? Math.min(1, Math.max(0, r.successRate)) : 0;

  // [1] Normalised latency score (lower latency → higher score)
  const latencyMs = typeof r.latencyMs === 'number' ? r.latencyMs : 0;
  vec[1] = Math.exp(-latencyMs / (PHI * 1000));

  // [2] Error rate (0–1, inverted from success)
  vec[2] = typeof r.errorRate === 'number' ? Math.min(1, Math.max(0, r.errorRate)) : (1 - vec[0]);

  // [3] Retry count normalised by fib(8)=21
  const retries = typeof r.retries === 'number' ? r.retries : 0;
  vec[3] = Math.min(1, retries / fib(8));

  // [4] Stage completion ratio
  const totalStages = typeof r.totalStages === 'number' ? r.totalStages : fib(7); // default 13
  const completedStages = typeof r.completedStages === 'number' ? r.completedStages : totalStages;
  vec[4] = totalStages > 0 ? Math.min(1, completedStages / totalStages) : 0;

  // [5] Token utilisation ratio (0–1)
  vec[5] = typeof r.tokenUtilisation === 'number' ? Math.min(1, Math.max(0, r.tokenUtilisation)) : PSI;

  // [6] Cost efficiency signal (inverted cost delta, normalised)
  const costDelta = typeof r.costDelta === 'number' ? r.costDelta : 0;
  vec[6] = 1 / (1 + Math.abs(costDelta));

  // [7] Quality score from quality gate (0–1)
  vec[7] = typeof r.qualityScore === 'number' ? Math.min(1, Math.max(0, r.qualityScore)) : CSL_THRESHOLDS.HIGH;

  // [8] Pattern novelty (0–1): how different from recent patterns
  vec[8] = typeof r.patternNovelty === 'number' ? Math.min(1, Math.max(0, r.patternNovelty)) : PSI;

  // [9] Cognitive layer activation breadth (0–1, normalised over 7 layers)
  const layersActive = typeof r.layersActive === 'number' ? r.layersActive : 1;
  vec[9] = Math.min(1, layersActive / 7);

  // [10] Swarm utilisation ratio (0–1, normalised over 17 swarms)
  const swarmsActive = typeof r.swarmsActive === 'number' ? r.swarmsActive : 1;
  vec[10] = Math.min(1, swarmsActive / fib(7)); // fib(7)=13 ≈ typical active

  // [11] Memory recall effectiveness (0–1)
  vec[11] = typeof r.memoryRecallScore === 'number' ? Math.min(1, Math.max(0, r.memoryRecallScore)) : PSI;

  // [12] CSL coherence score from last CSL gate
  vec[12] = typeof r.cslCoherence === 'number' ? Math.min(1, Math.max(0, r.cslCoherence)) : DRIFT_THRESHOLD;

  // [13] Alignment signal (0–1): alignment with strategic intent
  vec[13] = typeof r.alignmentScore === 'number' ? Math.min(1, Math.max(0, r.alignmentScore)) : CSL_THRESHOLDS.HIGH;

  // [14] Resource pressure inverse (1 - pressure → lower pressure is better)
  const pressure = typeof r.resourcePressure === 'number' ? Math.min(1, Math.max(0, r.resourcePressure)) : PRESSURE_LEVELS.NOMINAL[1];
  vec[14] = 1 - pressure;

  // [15] Overall phi-priority composite (0–1)
  vec[15] = typeof r.phiPriorityScore === 'number' ? Math.min(1, Math.max(0, r.phiPriorityScore)) : PSI;

  return vec;
}

// ─────────────────────────────────────────────────────────────────────────────
//  EVOLUTION ENGINE CLASS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @class EvolutionEngine
 * @extends EventEmitter
 *
 * @description
 *   The Evolution Engine is the adaptive learning layer of the Alive Software
 *   Architecture. It continuously monitors pipeline execution patterns, detects
 *   semantic drift from established baselines, proposes phi-scored evolutions,
 *   and applies approved improvements — all governed by golden-ratio mathematics.
 *
 * @fires EvolutionEngine#driftDetected
 * @fires EvolutionEngine#evolutionProposed
 * @fires EvolutionEngine#evolutionApplied
 * @fires EvolutionEngine#evolutionRolledBack
 *
 * @example
 * const engine = new EvolutionEngine({ componentId: 'my-service' });
 * engine.on('driftDetected', ({ componentId, similarity, severity }) => {
 *   console.log(`Drift in ${componentId}: similarity=${similarity}, severity=${severity}`);
 * });
 * engine.capturePattern(pipelineResult);
 */
class EvolutionEngine extends EventEmitter {

  /**
   * Create a new EvolutionEngine instance.
   *
   * @param {Object}  [config={}]                   - Engine configuration.
   * @param {string}  [config.componentId='system'] - Identifier for this engine instance.
   * @param {number}  [config.driftThreshold]       - Override drift detection threshold (default: DRIFT_THRESHOLD).
   * @param {number}  [config.approvalGate]         - Override auto-approval gate (default: EVOLUTION_APPROVAL_GATE).
   * @param {number}  [config.cooldownMs]           - Override evolution cooldown in ms (default: EVOLUTION_COOLDOWN_MS).
   * @param {number}  [config.patternStoreMax]      - Override max pattern store size (default: PATTERN_STORE_MAX=377).
   * @param {boolean} [config.verbose=false]        - Enable verbose debug logging.
   */
  constructor(config = {}) {
    super();

    /**
     * Engine configuration (phi-defaults applied for any missing fields).
     * @type {Object}
     * @private
     */
    this._config = {
      componentId:    config.componentId    || 'system',
      driftThreshold: config.driftThreshold || DRIFT_THRESHOLD,
      approvalGate:   config.approvalGate   || EVOLUTION_APPROVAL_GATE,
      cooldownMs:     config.cooldownMs     || EVOLUTION_COOLDOWN_MS,
      patternStoreMax: config.patternStoreMax || PATTERN_STORE_MAX,
      verbose:        config.verbose        || false,
    };

    /**
     * Circular/FIFO pattern store.
     * Stores up to fib(14)=377 pattern entries; oldest entry is evicted when full.
     * @type {Array<PatternEntry>}
     * @private
     */
    this._patternStore = [];

    /**
     * Drift tracker: maps componentId → DriftState.
     * DriftState holds the reference embedding and drift history for each component.
     * @type {Map<string, DriftState>}
     * @private
     */
    this._driftTracker = new Map();

    /**
     * Ordered log of all evolution proposals (pending, approved, applied, or rolled back).
     * @type {Array<EvolutionProposal>}
     * @private
     */
    this._evolutionLog = [];

    /**
     * Snapshot store for rollback support.
     * Maps evolutionId → snapshot taken immediately before application.
     * @type {Map<string, RollbackSnapshot>}
     * @private
     */
    this._rollbackStore = new Map();

    /**
     * Timestamp (ms) of the last successfully applied evolution.
     * Used to enforce EVOLUTION_COOLDOWN_MS between successive applications.
     * @type {number}
     * @private
     */
    this._lastEvolutionAt = 0;

    /**
     * Total count of successfully applied evolutions (used for Fibonacci generation labelling).
     * @type {number}
     * @private
     */
    this._evolutionCount = 0;

    /**
     * Running reference embeddings per component.
     * Updated after each successful evolution application.
     * @type {Map<string, number[]>}
     * @private
     */
    this._referenceEmbeddings = new Map();

    this._log(`EvolutionEngine initialised [componentId=${this._config.componentId}]`);
    this._log(`  patternStoreMax=${this._config.patternStoreMax}, driftThreshold=${this._config.driftThreshold.toFixed(4)}, cooldown=${this._config.cooldownMs}ms`);
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  PATTERN CAPTURE
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Capture and store a pattern extracted from a completed pipeline run.
   *
   * The pattern encodes the execution signature (embedding vector), pipeline
   * metadata, and a Shannon entropy score of the run's output distribution.
   * When the pattern store is full, the oldest pattern is evicted (FIFO).
   *
   * @param {Object} pipelineResult - Result object from a completed pipeline run.
   *   Expected fields (all optional; defaults applied if absent):
   *   - {string}  pipelineId          — unique pipeline run identifier
   *   - {string}  stage               — final pipeline stage name
   *   - {number}  successRate         — fraction of sub-tasks succeeded (0–1)
   *   - {number}  latencyMs           — total pipeline latency in ms
   *   - {number}  errorRate           — fraction of sub-tasks that errored (0–1)
   *   - {number}  retries             — total retry count
   *   - {number}  totalStages         — number of stages in the pipeline
   *   - {number}  completedStages     — stages that completed without error
   *   - {number}  tokenUtilisation    — token budget utilisation ratio (0–1)
   *   - {number}  costDelta           — relative cost change vs baseline
   *   - {number}  qualityScore        — quality gate output score (0–1)
   *   - {number}  patternNovelty      — novelty vs recent history (0–1)
   *   - {number}  layersActive        — cognitive layers activated (1–7)
   *   - {number}  swarmsActive        — swarms activated
   *   - {number}  memoryRecallScore   — memory recall effectiveness (0–1)
   *   - {number}  cslCoherence        — CSL coherence score (0–1)
   *   - {number}  alignmentScore      — alignment with strategic intent (0–1)
   *   - {number}  resourcePressure    — resource pressure reading (0–1)
   *   - {number}  phiPriorityScore    — composite phi-priority score (0–1)
   *
   * @returns {PatternEntry} The stored pattern entry.
   */
  capturePattern(pipelineResult) {
    if (!pipelineResult || typeof pipelineResult !== 'object') {
      this._warn('capturePattern: pipelineResult is null or not an object — skipping');
      return null;
    }

    const embedding = _extractEmbedding(pipelineResult);
    const entropy   = _shannonEntropy(embedding);
    const maxEnt    = Math.log(embedding.length); // max entropy for uniform dist

    /** @type {PatternEntry} */
    const entry = {
      id:             _genId(),
      capturedAt:     _now(),
      pipelineId:     pipelineResult.pipelineId || `pipe-${_genId()}`,
      stage:          pipelineResult.stage      || 'UNKNOWN',
      embedding,
      entropy,
      temperature:    adaptiveTemperature(entropy, maxEnt),
      successRate:    pipelineResult.successRate    || 0,
      latencyMs:      pipelineResult.latencyMs      || 0,
      qualityScore:   pipelineResult.qualityScore   || 0,
      alignmentScore: pipelineResult.alignmentScore || 0,
      meta:           pipelineResult.meta           || {},
    };

    // FIFO eviction when at capacity
    if (this._patternStore.length >= this._config.patternStoreMax) {
      this._patternStore.shift();
    }
    this._patternStore.push(entry);

    this._log(`capturePattern [${entry.id}] pipelineId=${entry.pipelineId} stage=${entry.stage} entropy=${entropy.toFixed(4)} temp=${entry.temperature.toFixed(4)}`);

    return entry;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  DRIFT DETECTION
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Detect semantic drift for a component by comparing its current embedding
   * against a reference baseline using cosine similarity.
   *
   * Drift severity levels:
   * - NONE     : similarity >= DRIFT_THRESHOLD (≈ 0.809)
   * - MODERATE : CRITICAL_DRIFT_THRESHOLD (≈ 0.691) <= similarity < DRIFT_THRESHOLD
   * - CRITICAL : similarity < CRITICAL_DRIFT_THRESHOLD — emits immediate alert
   *
   * If no reference embedding exists for the component, the current embedding
   * is stored as the new baseline and no drift is flagged.
   *
   * @param {string}   componentId        - Unique identifier of the component being monitored.
   * @param {number[]} currentEmbedding   - Current semantic embedding vector.
   * @param {number[]} [referenceEmbedding] - Optional explicit reference; if omitted, the
   *                                          engine's stored baseline for componentId is used.
   * @returns {DriftResult} Detection result with similarity score, severity, and metadata.
   *
   * @fires EvolutionEngine#driftDetected  When similarity < DRIFT_THRESHOLD.
   */
  detectDrift(componentId, currentEmbedding, referenceEmbedding) {
    if (!componentId || typeof componentId !== 'string') {
      throw new Error('detectDrift: componentId must be a non-empty string');
    }
    if (!Array.isArray(currentEmbedding) || currentEmbedding.length === 0) {
      throw new Error('detectDrift: currentEmbedding must be a non-empty numeric array');
    }

    // Resolve reference: explicit param > stored baseline > none (bootstrap)
    let ref = referenceEmbedding;
    if (!ref) {
      ref = this._referenceEmbeddings.get(componentId) ||
            this._driftTracker.get(componentId)?.referenceEmbedding;
    }

    if (!ref) {
      // No baseline yet — bootstrap from current embedding
      this._setReference(componentId, currentEmbedding);
      this._log(`detectDrift [${componentId}]: no baseline — bootstrapping reference`);

      /** @type {DriftResult} */
      return {
        componentId,
        similarity:  1.0,
        severity:    DRIFT_SEVERITY.NONE,
        driftDetected: false,
        critical:    false,
        gatedScore:  1.0,
        timestamp:   _now(),
        bootstrapped: true,
      };
    }

    // Pad shorter vector with zeros so lengths match
    const maxLen = Math.max(currentEmbedding.length, ref.length);
    const padCurrent = _padVector(currentEmbedding, maxLen);
    const padRef     = _padVector(ref,              maxLen);

    const similarity = cosineSimilarity(padCurrent, padRef);

    // Compute entropy of current embedding to set adaptive temperature for gating
    const entropy  = _shannonEntropy(currentEmbedding);
    const maxEnt   = Math.log(currentEmbedding.length);
    const temp     = adaptiveTemperature(entropy, maxEnt);

    // CSL gate: modulates gatedScore based on how far similarity is from drift threshold
    const gatedScore = cslGate(similarity, similarity, this._config.driftThreshold, temp);

    // Classify severity
    let severity     = DRIFT_SEVERITY.NONE;
    let driftDetected = false;
    let critical     = false;

    if (similarity < CRITICAL_DRIFT_THRESHOLD) {
      severity      = DRIFT_SEVERITY.CRITICAL;
      driftDetected = true;
      critical      = true;
    } else if (similarity < this._config.driftThreshold) {
      severity      = DRIFT_SEVERITY.MODERATE;
      driftDetected = true;
    }

    // Update drift tracker state
    const state = this._driftTracker.get(componentId) || {
      componentId,
      referenceEmbedding: padRef,
      driftHistory: [],
      lastChecked: 0,
    };
    state.lastChecked = _now();
    state.lastSimilarity = similarity;
    state.lastSeverity   = severity;
    if (!state.referenceEmbedding) state.referenceEmbedding = padRef;
    state.driftHistory.push({ timestamp: _now(), similarity, severity });

    // Cap drift history to fib(8)=21 entries
    const histCap = fib(8); // 21
    if (state.driftHistory.length > histCap) {
      state.driftHistory = state.driftHistory.slice(-histCap);
    }
    this._driftTracker.set(componentId, state);

    /** @type {DriftResult} */
    const result = {
      componentId,
      similarity,
      severity,
      driftDetected,
      critical,
      gatedScore,
      threshold:   this._config.driftThreshold,
      criticalFloor: CRITICAL_DRIFT_THRESHOLD,
      temperature: temp,
      timestamp:   _now(),
      bootstrapped: false,
    };

    if (driftDetected) {
      this._log(`detectDrift [${componentId}]: similarity=${similarity.toFixed(4)} severity=${severity}${critical ? ' *** CRITICAL ***' : ''}`);

      /**
       * Drift detected event.
       * @event EvolutionEngine#driftDetected
       * @type {DriftResult}
       */
      this.emit('driftDetected', result);
    }

    return result;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  EVOLUTION PROPOSAL
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Generate an evolution proposal based on an observed pattern.
   *
   * The proposal encodes the detected improvement opportunity, estimated
   * benefit/risk/alignment scores, and metadata for the evaluation pipeline.
   * Benefit is derived from quality and alignment signals; risk from error rate
   * and entropy; alignment from CSL coherence and strategic scoring.
   *
   * @param {PatternEntry} pattern - A pattern entry from the pattern store.
   * @returns {EvolutionProposal} The generated (un-scored) proposal.
   *
   * @fires EvolutionEngine#evolutionProposed
   */
  proposeEvolution(pattern) {
    if (!pattern || typeof pattern !== 'object') {
      throw new Error('proposeEvolution: pattern must be a valid PatternEntry object');
    }

    const embedding = pattern.embedding || [];
    const entropy   = pattern.entropy   || 0;
    const maxEnt    = Math.log(Math.max(embedding.length, 1));

    // Derive raw factor scores from pattern signals
    const benefit = _computeBenefit(pattern);
    const risk     = _computeRisk(pattern, entropy, maxEnt);
    const alignment = _computeAlignment(pattern);

    /** @type {EvolutionProposal} */
    const proposal = {
      id:            `evo-${_genId()}`,
      patternId:     pattern.id,
      pipelineId:    pattern.pipelineId,
      stage:         pattern.stage,
      status:        PROPOSAL_STATUS.PENDING,
      createdAt:     _now(),
      benefit,
      risk,
      alignment,
      score:         null, // computed in evaluateProposal
      autoApproved:  false,
      generation:    _fibGeneration(this._evolutionCount),
      embedding:     embedding.slice(), // snapshot
      entropy,
      temperature:   adaptiveTemperature(entropy, maxEnt),
      description:   _describeProposal(pattern, benefit, risk, alignment),
      meta: {
        successRate:   pattern.successRate,
        latencyMs:     pattern.latencyMs,
        qualityScore:  pattern.qualityScore,
        alignmentScore: pattern.alignmentScore,
      },
    };

    this._evolutionLog.push(proposal);

    this._log(`proposeEvolution [${proposal.id}] benefit=${benefit.toFixed(4)} risk=${risk.toFixed(4)} alignment=${alignment.toFixed(4)} gen=${proposal.generation}`);

    /**
     * Evolution proposed event.
     * @event EvolutionEngine#evolutionProposed
     * @type {EvolutionProposal}
     */
    this.emit('evolutionProposed', proposal);

    return proposal;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  PROPOSAL EVALUATION
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Score and evaluate an evolution proposal using phi-fusion weights.
   *
   * Scoring formula:
   *   score = benefit × w[0]  +  risk × w[1]  +  alignment × w[2]
   * where [w[0], w[1], w[2]] = phiFusionWeights(3) ≈ [0.5728, 0.2540, 0.1728]
   *
   * Note: `risk` is inverted for scoring (lower raw risk → higher score contribution).
   * The adaptive temperature from the pattern's entropy modulates CSL gate sharpness.
   *
   * Auto-approval: score >= EVOLUTION_APPROVAL_GATE (≈ 0.809) sets status=APPROVED.
   * Otherwise:     status=REJECTED (proposal can still be manually overridden).
   *
   * @param {EvolutionProposal} proposal - A proposal returned from proposeEvolution().
   * @returns {EvolutionProposal} The proposal with populated score and updated status.
   */
  evaluateProposal(proposal) {
    if (!proposal || typeof proposal !== 'object') {
      throw new Error('evaluateProposal: proposal must be a valid EvolutionProposal object');
    }

    const [w0, w1, w2] = EVOLUTION_WEIGHTS;

    // risk is inverted: high raw risk reduces the score
    const invertedRisk = 1 - Math.min(1, Math.max(0, proposal.risk));

    const rawScore = (proposal.benefit  * w0) +
                     (invertedRisk       * w1) +
                     (proposal.alignment * w2);

    // Apply CSL gate with adaptive temperature for entropy-aware sharpness
    const gatedScore = cslGate(
      rawScore,
      rawScore,
      this._config.approvalGate,
      proposal.temperature || 0.1,
    );

    // Final score: blend raw and gated using PSI / PHI weighting for stability
    const score = (rawScore * PHI + gatedScore * PSI) / (PHI + PSI);

    proposal.score       = Math.min(1, Math.max(0, score));
    proposal.rawScore    = rawScore;
    proposal.gatedScore  = gatedScore;
    proposal.weights     = { benefit: w0, risk: w1, alignment: w2 };
    proposal.autoApproved = proposal.score >= this._config.approvalGate;
    proposal.status      = proposal.autoApproved
      ? PROPOSAL_STATUS.APPROVED
      : PROPOSAL_STATUS.REJECTED;

    this._log(`evaluateProposal [${proposal.id}] score=${proposal.score.toFixed(4)} rawScore=${rawScore.toFixed(4)} status=${proposal.status}`);

    // Sync log entry
    this._syncLogEntry(proposal);

    return proposal;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  EVOLUTION APPLICATION
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Apply an approved evolution proposal.
   *
   * Prerequisites:
   * 1. Proposal status must be APPROVED.
   * 2. Sufficient cooldown (EVOLUTION_COOLDOWN_MS) since the last applied evolution.
   *
   * On success:
   * - Reference embedding for the relevant component is updated.
   * - A rollback snapshot is stored.
   * - Evolution generation counter is incremented.
   * - Proposal status transitions to APPLIED.
   *
   * @param {EvolutionProposal} proposal - An approved proposal from evaluateProposal().
   * @returns {{ success: boolean, evolutionId: string, message: string, appliedAt: number }}
   *   Result object indicating success or failure with a human-readable message.
   *
   * @fires EvolutionEngine#evolutionApplied  On successful application.
   */
  applyEvolution(proposal) {
    if (!proposal || typeof proposal !== 'object') {
      throw new Error('applyEvolution: proposal must be a valid EvolutionProposal object');
    }

    if (proposal.status !== PROPOSAL_STATUS.APPROVED) {
      return {
        success:     false,
        evolutionId: proposal.id,
        message:     `Cannot apply proposal with status=${proposal.status}; must be APPROVED`,
        appliedAt:   null,
      };
    }

    // Enforce cooldown
    const elapsed = _now() - this._lastEvolutionAt;
    if (this._lastEvolutionAt > 0 && elapsed < this._config.cooldownMs) {
      const remaining = this._config.cooldownMs - elapsed;
      return {
        success:     false,
        evolutionId: proposal.id,
        message:     `Evolution cooldown active — ${remaining}ms remaining (cooldown=${this._config.cooldownMs}ms)`,
        appliedAt:   null,
      };
    }

    // Take rollback snapshot before applying
    const componentId = proposal.pipelineId || this._config.componentId;
    const priorRef    = this._referenceEmbeddings.get(componentId) ||
                        this._driftTracker.get(componentId)?.referenceEmbedding ||
                        null;

    /** @type {RollbackSnapshot} */
    const snapshot = {
      evolutionId:      proposal.id,
      componentId,
      snapshotAt:       _now(),
      priorReference:   priorRef ? priorRef.slice() : null,
      priorLogEntry:    Object.assign({}, proposal),
      evolutionCount:   this._evolutionCount,
    };
    this._rollbackStore.set(proposal.id, snapshot);

    // Apply: update reference embedding for the component
    if (proposal.embedding && proposal.embedding.length > 0) {
      this._setReference(componentId, proposal.embedding);
    }

    // Update state
    this._evolutionCount++;
    this._lastEvolutionAt = _now();
    proposal.status       = PROPOSAL_STATUS.APPLIED;
    proposal.appliedAt    = _now();
    proposal.generation   = _fibGeneration(this._evolutionCount - 1);

    this._syncLogEntry(proposal);

    this._log(`applyEvolution [${proposal.id}] componentId=${componentId} generation=${proposal.generation} evolutionCount=${this._evolutionCount}`);

    const result = {
      success:     true,
      evolutionId: proposal.id,
      componentId,
      generation:  proposal.generation,
      message:     `Evolution applied — generation=${proposal.generation} componentId=${componentId}`,
      appliedAt:   proposal.appliedAt,
    };

    /**
     * Evolution applied event.
     * @event EvolutionEngine#evolutionApplied
     * @type {{ success: boolean, evolutionId: string, componentId: string, generation: number, appliedAt: number }}
     */
    this.emit('evolutionApplied', result);

    return result;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  EVOLUTION ROLLBACK
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Rollback a previously applied evolution, restoring the prior reference
   * embedding and decrementing the evolution generation counter.
   *
   * Only evolutions with status=APPLIED that have a stored snapshot can be
   * rolled back. A rollback itself does not consume the cooldown window.
   *
   * @param {string} evolutionId - The `id` of the EvolutionProposal to roll back.
   * @returns {{ success: boolean, evolutionId: string, message: string, rolledBackAt: number }}
   *   Result object indicating success or failure with a human-readable message.
   *
   * @fires EvolutionEngine#evolutionRolledBack  On successful rollback.
   */
  rollbackEvolution(evolutionId) {
    if (!evolutionId || typeof evolutionId !== 'string') {
      throw new Error('rollbackEvolution: evolutionId must be a non-empty string');
    }

    const snapshot = this._rollbackStore.get(evolutionId);
    if (!snapshot) {
      return {
        success:       false,
        evolutionId,
        message:       `No rollback snapshot found for evolutionId=${evolutionId}`,
        rolledBackAt:  null,
      };
    }

    // Find the proposal in the log
    const proposal = this._evolutionLog.find(p => p.id === evolutionId);
    if (!proposal) {
      return {
        success:       false,
        evolutionId,
        message:       `No proposal found in evolutionLog for evolutionId=${evolutionId}`,
        rolledBackAt:  null,
      };
    }
    if (proposal.status !== PROPOSAL_STATUS.APPLIED) {
      return {
        success:       false,
        evolutionId,
        message:       `Proposal status=${proposal.status}; only APPLIED proposals can be rolled back`,
        rolledBackAt:  null,
      };
    }

    // Restore prior reference embedding
    if (snapshot.priorReference) {
      this._setReference(snapshot.componentId, snapshot.priorReference);
    } else {
      // No prior reference — remove the entry entirely
      this._referenceEmbeddings.delete(snapshot.componentId);
    }

    // Decrement evolution counter (don't go below 0)
    this._evolutionCount = Math.max(0, snapshot.evolutionCount);

    // Update proposal status
    proposal.status       = PROPOSAL_STATUS.ROLLED_BACK;
    proposal.rolledBackAt = _now();
    this._syncLogEntry(proposal);

    // Remove the snapshot (one-shot rollback)
    this._rollbackStore.delete(evolutionId);

    this._log(`rollbackEvolution [${evolutionId}] componentId=${snapshot.componentId} evolutionCount restored to ${this._evolutionCount}`);

    const result = {
      success:       true,
      evolutionId,
      componentId:   snapshot.componentId,
      message:       `Evolution rolled back — componentId=${snapshot.componentId} evolutionCount=${this._evolutionCount}`,
      rolledBackAt:  proposal.rolledBackAt,
    };

    /**
     * Evolution rolled back event.
     * @event EvolutionEngine#evolutionRolledBack
     * @type {{ success: boolean, evolutionId: string, componentId: string, rolledBackAt: number }}
     */
    this.emit('evolutionRolledBack', result);

    return result;
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  REPORTING
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Generate a system-wide drift summary report.
   *
   * Iterates all tracked components and aggregates drift state into a
   * structured report, sorted by ascending similarity (most-drifted first).
   *
   * @returns {DriftReport} Drift report object with per-component entries and summary statistics.
   */
  getDriftReport() {
    const components = [];
    let criticalCount  = 0;
    let moderateCount  = 0;
    let healthyCount   = 0;
    const simValues    = [];

    for (const [componentId, state] of this._driftTracker) {
      const sim      = state.lastSimilarity  !== undefined ? state.lastSimilarity  : 1.0;
      const severity = state.lastSeverity    || DRIFT_SEVERITY.NONE;

      simValues.push(sim);

      if (severity === DRIFT_SEVERITY.CRITICAL)  criticalCount++;
      else if (severity === DRIFT_SEVERITY.MODERATE) moderateCount++;
      else healthyCount++;

      components.push({
        componentId,
        similarity:  sim,
        severity,
        driftDetected: severity !== DRIFT_SEVERITY.NONE,
        lastChecked: state.lastChecked || 0,
        historyLength: (state.driftHistory || []).length,
        driftHistory: (state.driftHistory || []).slice(-fib(5)), // last 5 entries
      });
    }

    // Sort most-drifted first (ascending similarity)
    components.sort((a, b) => a.similarity - b.similarity);

    const avgSimilarity = simValues.length > 0
      ? simValues.reduce((s, v) => s + v, 0) / simValues.length
      : 1.0;

    const minSimilarity = simValues.length > 0 ? Math.min(...simValues) : 1.0;

    /** @type {DriftReport} */
    return {
      generatedAt:    _now(),
      totalComponents: components.length,
      criticalCount,
      moderateCount,
      healthyCount,
      avgSimilarity,
      minSimilarity,
      driftThreshold: this._config.driftThreshold,
      criticalFloor:  CRITICAL_DRIFT_THRESHOLD,
      components,
      systemDriftSeverity: criticalCount > 0
        ? DRIFT_SEVERITY.CRITICAL
        : moderateCount > 0
          ? DRIFT_SEVERITY.MODERATE
          : DRIFT_SEVERITY.NONE,
    };
  }

  /**
   * Return the full history of all evolution proposals, in chronological order.
   *
   * @returns {EvolutionProposal[]} Array of all proposals (pending, approved,
   *   rejected, applied, and rolled back).
   */
  getEvolutionLog() {
    return this._evolutionLog.slice();
  }

  /**
   * Return the current contents of the pattern store.
   * Patterns are returned in insertion order (oldest first).
   *
   * @returns {PatternEntry[]} Array of stored patterns (max fib(14)=377 entries).
   */
  getPatternStore() {
    return this._patternStore.slice();
  }

  // ───────────────────────────────────────────────────────────────────────────
  //  PRIVATE HELPERS
  // ───────────────────────────────────────────────────────────────────────────

  /**
   * Set the reference embedding for a component, updating both the
   * reference store and the drift tracker baseline.
   *
   * @param {string}   componentId - Component identifier.
   * @param {number[]} embedding   - New reference embedding vector.
   * @private
   */
  _setReference(componentId, embedding) {
    this._referenceEmbeddings.set(componentId, embedding.slice());

    const existing = this._driftTracker.get(componentId) || {
      componentId,
      driftHistory: [],
      lastChecked:  0,
    };
    existing.referenceEmbedding = embedding.slice();
    this._driftTracker.set(componentId, existing);
  }

  /**
   * Sync an updated proposal back into the evolution log (in-place update
   * so external references to log entries stay consistent).
   *
   * @param {EvolutionProposal} proposal - Proposal whose log entry needs refreshing.
   * @private
   */
  _syncLogEntry(proposal) {
    const idx = this._evolutionLog.findIndex(p => p.id === proposal.id);
    if (idx !== -1) {
      this._evolutionLog[idx] = proposal;
    }
  }

  /**
   * Emit a verbose debug log (gated by config.verbose).
   * @param {string} msg - Log message.
   * @private
   */
  _log(msg) {
    if (this._config.verbose) {
      process.stdout.write(`[EvolutionEngine][${new Date().toISOString()}] ${msg}\n`);
    }
  }

  /**
   * Emit a warning log (always active, regardless of verbose flag).
   * @param {string} msg - Warning message.
   * @private
   */
  _warn(msg) {
    process.stderr.write(`[EvolutionEngine][WARN][${new Date().toISOString()}] ${msg}\n`);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  MODULE-LEVEL PURE HELPERS (not exported)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Pad a numeric vector to a target length with zeros.
 * @param {number[]} vec    - Source vector.
 * @param {number}   length - Target length.
 * @returns {number[]} Padded vector of exactly `length` elements.
 */
function _padVector(vec, length) {
  if (vec.length === length) return vec;
  const out = new Array(length).fill(0);
  for (let i = 0; i < Math.min(vec.length, length); i++) out[i] = vec[i];
  return out;
}

/**
 * Compute a normalised benefit score from a pattern entry.
 * Higher quality + alignment + success → higher benefit.
 *
 * @param {PatternEntry} pattern - Captured pattern.
 * @returns {number} Benefit score in [0, 1].
 */
function _computeBenefit(pattern) {
  const [w0, w1, w2] = phiFusionWeights(3);
  const quality   = pattern.qualityScore   || 0;
  const alignment = pattern.alignmentScore || 0;
  const success   = pattern.successRate    || 0;
  return Math.min(1, quality * w0 + success * w1 + alignment * w2);
}

/**
 * Compute a normalised risk score from a pattern entry.
 * Higher entropy + lower embedding coherence → higher risk.
 *
 * @param {PatternEntry} pattern    - Captured pattern.
 * @param {number}       entropy    - Shannon entropy of the pattern embedding.
 * @param {number}       maxEntropy - Maximum possible entropy.
 * @returns {number} Risk score in [0, 1].
 */
function _computeRisk(pattern, entropy, maxEntropy) {
  const normEntropy = maxEntropy > 0 ? entropy / maxEntropy : 0;

  // Embedding index 2 = error rate, index 3 = retry rate (from _extractEmbedding)
  const embedding = pattern.embedding || [];
  const errorRate = embedding[2] || 0;
  const retryRate = embedding[3] || 0;

  const [w0, w1, w2] = phiFusionWeights(3);
  return Math.min(1, normEntropy * w0 + errorRate * w1 + retryRate * w2);
}

/**
 * Compute a normalised alignment score from a pattern entry.
 * CSL coherence + strategic alignment + memory recall → alignment score.
 *
 * @param {PatternEntry} pattern - Captured pattern.
 * @returns {number} Alignment score in [0, 1].
 */
function _computeAlignment(pattern) {
  const embedding = pattern.embedding || [];
  // index 12 = cslCoherence, index 13 = alignmentScore, index 11 = memoryRecall
  const cslCoherence  = embedding[12] || CSL_THRESHOLDS.HIGH;
  const alignScore    = embedding[13] || 0;
  const memRecall     = embedding[11] || 0;

  const [w0, w1, w2] = phiFusionWeights(3);
  return Math.min(1, cslCoherence * w0 + alignScore * w1 + memRecall * w2);
}

/**
 * Generate a human-readable description string for an evolution proposal.
 *
 * @param {PatternEntry} pattern   - Source pattern.
 * @param {number}       benefit   - Computed benefit score.
 * @param {number}       risk      - Computed risk score.
 * @param {number}       alignment - Computed alignment score.
 * @returns {string} Description string.
 */
function _describeProposal(pattern, benefit, risk, alignment) {
  const quality    = (pattern.qualityScore   || 0).toFixed(3);
  const success    = (pattern.successRate    || 0).toFixed(3);
  const latency    = (pattern.latencyMs      || 0).toFixed(0);
  const benefitStr = benefit.toFixed(4);
  const riskStr    = risk.toFixed(4);
  const alignStr   = alignment.toFixed(4);

  return `Evolution candidate from pipeline=${pattern.pipelineId} stage=${pattern.stage}: ` +
    `quality=${quality} successRate=${success} latencyMs=${latency}ms | ` +
    `benefit=${benefitStr} risk=${riskStr} alignment=${alignStr}`;
}

// ─────────────────────────────────────────────────────────────────────────────
//  JSDoc TYPE DEFINITIONS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @typedef {Object} PatternEntry
 * @property {string}   id             - Unique pattern identifier.
 * @property {number}   capturedAt     - Unix timestamp (ms) when captured.
 * @property {string}   pipelineId     - Source pipeline run identifier.
 * @property {string}   stage          - Final pipeline stage of the run.
 * @property {number[]} embedding      - 16-dimensional semantic embedding vector.
 * @property {number}   entropy        - Shannon entropy of the embedding.
 * @property {number}   temperature    - Adaptive temperature derived from entropy.
 * @property {number}   successRate    - Pipeline success rate (0–1).
 * @property {number}   latencyMs      - Pipeline total latency in ms.
 * @property {number}   qualityScore   - Quality gate output score (0–1).
 * @property {number}   alignmentScore - Strategic alignment score (0–1).
 * @property {Object}   meta           - Raw metadata pass-through from pipelineResult.
 */

/**
 * @typedef {Object} DriftState
 * @property {string}   componentId        - Component identifier.
 * @property {number[]} referenceEmbedding - Baseline embedding vector.
 * @property {number}   lastSimilarity     - Most recent cosine similarity reading.
 * @property {string}   lastSeverity       - Most recent drift severity label.
 * @property {number}   lastChecked        - Timestamp of most recent drift check.
 * @property {Array<{timestamp: number, similarity: number, severity: string}>} driftHistory
 *   - Rolling history of drift readings (capped at fib(8)=21 entries).
 */

/**
 * @typedef {Object} DriftResult
 * @property {string}  componentId    - Component identifier.
 * @property {number}  similarity     - Cosine similarity between current and reference.
 * @property {string}  severity       - NONE | MODERATE | CRITICAL
 * @property {boolean} driftDetected  - True when similarity < driftThreshold.
 * @property {boolean} critical       - True when similarity < criticalFloor.
 * @property {number}  gatedScore     - CSL-gated similarity score.
 * @property {number}  [threshold]    - The drift threshold used.
 * @property {number}  [criticalFloor] - The critical drift floor used.
 * @property {number}  [temperature]  - Adaptive temperature applied to CSL gate.
 * @property {number}  timestamp      - Unix timestamp (ms) of detection.
 * @property {boolean} bootstrapped   - True if this was the first reading (baseline set).
 */

/**
 * @typedef {Object} EvolutionProposal
 * @property {string}   id           - Unique proposal identifier (e.g. "evo-a1b2c3d4").
 * @property {string}   patternId    - Source PatternEntry identifier.
 * @property {string}   pipelineId   - Source pipeline run identifier.
 * @property {string}   stage        - Pipeline stage that generated the source pattern.
 * @property {string}   status       - PENDING | APPROVED | REJECTED | APPLIED | ROLLED_BACK
 * @property {number}   createdAt    - Unix timestamp (ms) of proposal creation.
 * @property {number}   benefit      - Raw benefit score (0–1).
 * @property {number}   risk         - Raw risk score (0–1).
 * @property {number}   alignment    - Raw alignment score (0–1).
 * @property {number|null} score     - Final phi-fusion score (null until evaluated).
 * @property {number}   [rawScore]   - Unmodulated weighted score before CSL gate.
 * @property {number}   [gatedScore] - Score after CSL gate.
 * @property {boolean}  autoApproved - True when score >= approvalGate.
 * @property {number}   generation   - Fibonacci generation label for this evolution.
 * @property {number[]} embedding    - Snapshot of source pattern embedding.
 * @property {number}   entropy      - Source pattern entropy.
 * @property {number}   temperature  - Adaptive temperature for this proposal.
 * @property {string}   description  - Human-readable description of the proposal.
 * @property {Object}   meta         - Additional metadata from the source pattern.
 * @property {number}   [appliedAt]  - Unix timestamp (ms) of application (if applied).
 * @property {number}   [rolledBackAt] - Unix timestamp (ms) of rollback (if rolled back).
 */

/**
 * @typedef {Object} RollbackSnapshot
 * @property {string}      evolutionId    - ID of the evolution being snapshotted.
 * @property {string}      componentId    - Component whose reference was updated.
 * @property {number}      snapshotAt     - Timestamp (ms) of snapshot creation.
 * @property {number[]|null} priorReference - Prior reference embedding (null if bootstrapped).
 * @property {EvolutionProposal} priorLogEntry - Copy of the proposal before application.
 * @property {number}      evolutionCount - Evolution counter value before application.
 */

/**
 * @typedef {Object} DriftReport
 * @property {number}  generatedAt           - Unix timestamp (ms) of report generation.
 * @property {number}  totalComponents       - Number of tracked components.
 * @property {number}  criticalCount         - Components in CRITICAL drift.
 * @property {number}  moderateCount         - Components in MODERATE drift.
 * @property {number}  healthyCount          - Components with no drift detected.
 * @property {number}  avgSimilarity         - Average similarity across all components.
 * @property {number}  minSimilarity         - Minimum similarity (most-drifted component).
 * @property {number}  driftThreshold        - Configured drift detection threshold.
 * @property {number}  criticalFloor         - Configured critical drift floor.
 * @property {string}  systemDriftSeverity   - Aggregate system severity: NONE | MODERATE | CRITICAL.
 * @property {Array<Object>} components      - Per-component drift entries, sorted by ascending similarity.
 */

// ─────────────────────────────────────────────────────────────────────────────
//  MODULE EXPORTS
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
  EvolutionEngine,

  // Exported constants for consumers that need to reference the same thresholds
  PATTERN_STORE_MAX,
  DRIFT_THRESHOLD,
  CRITICAL_DRIFT_THRESHOLD,
  EVOLUTION_APPROVAL_GATE,
  EVOLUTION_COOLDOWN_MS,
  EVOLUTION_WEIGHTS,
  PROPOSAL_STATUS,
  DRIFT_SEVERITY,
};
