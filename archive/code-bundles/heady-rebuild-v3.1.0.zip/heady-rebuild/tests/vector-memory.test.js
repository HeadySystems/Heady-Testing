/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 *
 * Vector memory tests — store, search, delete, update, drift detection.
 *
 * VectorMemory is imported from src/vector-memory.  Because that module
 * depends on external providers we test it through a lightweight in-process
 * implementation that matches the documented contract, and we also smoke-test
 * the real module when it is importable.
 */

'use strict';

// ─── Inline reference implementation ─────────────────────────────────────────
// Provides a deterministic VectorMemory for unit testing purposes.
// Matches the API surface used throughout the Heady platform.

class TestVectorMemory {
  constructor(opts = {}) {
    this._entries   = new Map();       // key → { vector, metadata, namespace, createdAt, updatedAt }
    this._ns        = opts.defaultNamespace || 'default';
    this._maxEntries = opts.maxEntries || 10_000;
    this._driftThreshold = opts.driftThreshold ?? 0.3;
  }

  // ── store ──────────────────────────────────────────────────────────────────

  store(key, vector, metadata = {}, namespace) {
    if (!key)    throw new TypeError('key is required');
    if (!Array.isArray(vector) || vector.length === 0) throw new TypeError('vector must be a non-empty array');

    const ns = namespace || this._ns;

    if (this._entries.size >= this._maxEntries) {
      // Evict oldest entry
      const oldest = [...this._entries.keys()][0];
      this._entries.delete(oldest);
    }

    const now = Date.now();
    const existing = this._entries.get(key);
    this._entries.set(key, {
      key,
      vector: [...vector],
      metadata: { ...metadata },
      namespace: ns,
      createdAt: existing ? existing.createdAt : now,
      updatedAt: now,
    });
    return this;
  }

  // ── get ───────────────────────────────────────────────────────────────────

  get(key) {
    return this._entries.get(key) || null;
  }

  // ── search ────────────────────────────────────────────────────────────────

  /**
   * Brute-force cosine similarity search.
   * @param {number[]} queryVector
   * @param {number}   limit
   * @param {number}   minScore
   * @param {string}   [namespace]
   * @returns {{ key, score, metadata }[]}
   */
  search(queryVector, limit = 10, minScore = 0, namespace) {
    if (!Array.isArray(queryVector)) throw new TypeError('queryVector must be an array');

    const ns = namespace || this._ns;
    const results = [];

    for (const entry of this._entries.values()) {
      if (entry.namespace !== ns) continue;
      const score = _cosineSimilarity(queryVector, entry.vector);
      if (score >= minScore) {
        results.push({ key: entry.key, score, metadata: entry.metadata, vector: entry.vector });
      }
    }

    return results
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  searchByVector(opts = {}) {
    return this.search(opts.vector, opts.limit, opts.minScore, opts.namespace);
  }

  // ── delete ────────────────────────────────────────────────────────────────

  delete(key) {
    return this._entries.delete(key);
  }

  // ── update ────────────────────────────────────────────────────────────────

  update(key, updates = {}) {
    const entry = this._entries.get(key);
    if (!entry) return false;
    if (updates.vector) {
      if (!Array.isArray(updates.vector)) throw new TypeError('vector must be an array');
      entry.vector = [...updates.vector];
    }
    if (updates.metadata) {
      entry.metadata = { ...entry.metadata, ...updates.metadata };
    }
    entry.updatedAt = Date.now();
    return true;
  }

  // ── list / count ──────────────────────────────────────────────────────────

  list(namespace) {
    const ns = namespace || this._ns;
    return [...this._entries.values()].filter(e => e.namespace === ns);
  }

  count(namespace) {
    if (namespace) return this.list(namespace).length;
    return this._entries.size;
  }

  clear(namespace) {
    if (namespace) {
      for (const [k, v] of this._entries) {
        if (v.namespace === namespace) this._entries.delete(k);
      }
    } else {
      this._entries.clear();
    }
    return this;
  }

  // ── Drift detection ───────────────────────────────────────────────────────

  /**
   * Detect semantic drift by comparing a new vector to the centroid of
   * all stored vectors in a namespace.
   * @param {number[]} newVector
   * @param {string}   [namespace]
   * @returns {{ drifted: boolean, score: number, centroid: number[] }}
   */
  detectDrift(newVector, namespace) {
    const ns = namespace || this._ns;
    const entries = this.list(ns);
    if (entries.length === 0) return { drifted: false, score: 1.0, centroid: null };

    const dims = newVector.length;
    const centroidVec = Array(dims).fill(0);
    for (const e of entries) {
      for (let i = 0; i < dims; i++) {
        centroidVec[i] += (e.vector[i] || 0) / entries.length;
      }
    }

    const score = _cosineSimilarity(newVector, centroidVec);
    const drifted = score < (1 - this._driftThreshold);
    return { drifted, score, centroid: centroidVec };
  }

  // ── getRecent ─────────────────────────────────────────────────────────────

  getRecent(opts = {}) {
    const { limit = 5, namespace } = opts;
    const ns = namespace || this._ns;
    return [...this._entries.values()]
      .filter(e => e.namespace === ns)
      .sort((a, b) => b.updatedAt - a.updatedAt)
      .slice(0, limit);
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function _cosineSimilarity(a, b) {
  let dot = 0, na = 0, nb = 0;
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) {
    dot += a[i] * b[i];
    na  += a[i] * a[i];
    nb  += b[i] * b[i];
  }
  const denom = Math.sqrt(na) * Math.sqrt(nb);
  return denom === 0 ? 0 : dot / denom;
}

function makeVector(dims = 4, seed = 1) {
  const v = Array.from({ length: dims }, (_, i) => Math.sin(seed * (i + 1)));
  const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0)) || 1;
  return v.map(x => x / norm);
}

// ─── Tests ────────────────────────────────────────────────────────────────────

describe('VectorMemory — store', () => {
  let mem;
  beforeEach(() => { mem = new TestVectorMemory(); });

  test('store() persists a vector entry', () => {
    const v = makeVector(4, 1);
    mem.store('doc-1', v, { title: 'first' });
    const entry = mem.get('doc-1');
    expect(entry).not.toBeNull();
    expect(entry.vector).toEqual(v);
    expect(entry.metadata.title).toBe('first');
  });

  test('store() returns the instance for chaining', () => {
    const result = mem.store('doc-2', makeVector(4, 2));
    expect(result).toBe(mem);
  });

  test('store() throws on missing key', () => {
    expect(() => mem.store(null, makeVector())).toThrow(/key/i);
  });

  test('store() throws on invalid vector', () => {
    expect(() => mem.store('bad', 'not-an-array')).toThrow(/vector/i);
  });

  test('store() handles multiple namespaces independently', () => {
    mem.store('ns1-key', makeVector(4, 1), {}, 'ns1');
    mem.store('ns2-key', makeVector(4, 2), {}, 'ns2');
    expect(mem.count('ns1')).toBe(1);
    expect(mem.count('ns2')).toBe(1);
    // ns1-key should not appear in ns2 search
    const results = mem.search(makeVector(4, 2), 10, 0, 'ns1');
    expect(results.map(r => r.key)).not.toContain('ns2-key');
  });

  test('count() returns total entries', () => {
    mem.store('a', makeVector(4, 1));
    mem.store('b', makeVector(4, 2));
    expect(mem.count()).toBe(2);
  });
});

describe('VectorMemory — search', () => {
  let mem;
  beforeEach(() => {
    mem = new TestVectorMemory();
    mem.store('item-1', makeVector(8, 1), { label: 'one' });
    mem.store('item-2', makeVector(8, 2), { label: 'two' });
    mem.store('item-3', makeVector(8, 3), { label: 'three' });
    mem.store('item-4', makeVector(8, 4), { label: 'four' });
  });

  test('search() returns results sorted by descending cosine score', () => {
    const query = makeVector(8, 1); // identical to item-1
    const results = mem.search(query, 4);
    expect(results[0].key).toBe('item-1');
    expect(results[0].score).toBeCloseTo(1.0, 5);
    for (let i = 1; i < results.length; i++) {
      expect(results[i - 1].score).toBeGreaterThanOrEqual(results[i].score);
    }
  });

  test('search() respects limit parameter', () => {
    const results = mem.search(makeVector(8, 1), 2);
    expect(results).toHaveLength(2);
  });

  test('search() filters by minScore threshold', () => {
    // All vectors have positive similarity to each other (same distribution)
    const results = mem.search(makeVector(8, 1), 10, 0.99);
    expect(results.every(r => r.score >= 0.99)).toBe(true);
  });

  test('search() returns empty array when no entries match namespace', () => {
    const results = mem.search(makeVector(8, 1), 10, 0, 'empty-ns');
    expect(results).toHaveLength(0);
  });

  test('search() throws on invalid query vector', () => {
    expect(() => mem.search('not-a-vector')).toThrow(/vector/i);
  });

  test('searchByVector() is equivalent to search()', () => {
    const query = makeVector(8, 2);
    const r1 = mem.search(query, 3);
    const r2 = mem.searchByVector({ vector: query, limit: 3 });
    expect(r1.map(x => x.key)).toEqual(r2.map(x => x.key));
  });
});

describe('VectorMemory — delete', () => {
  let mem;
  beforeEach(() => {
    mem = new TestVectorMemory();
    mem.store('del-a', makeVector(4, 1), { info: 'a' });
    mem.store('del-b', makeVector(4, 2), { info: 'b' });
  });

  test('delete() removes an existing entry', () => {
    const removed = mem.delete('del-a');
    expect(removed).toBe(true);
    expect(mem.get('del-a')).toBeNull();
    expect(mem.count()).toBe(1);
  });

  test('delete() returns false for non-existent key', () => {
    expect(mem.delete('ghost')).toBe(false);
  });

  test('deleted entry does not appear in search results', () => {
    mem.delete('del-a');
    const results = mem.search(makeVector(4, 1), 10);
    expect(results.map(r => r.key)).not.toContain('del-a');
  });

  test('clear() removes all entries in a namespace', () => {
    mem.store('ns-key', makeVector(4, 3), {}, 'test-ns');
    mem.clear('test-ns');
    expect(mem.count('test-ns')).toBe(0);
    // default namespace unaffected
    expect(mem.count()).toBe(2);
  });
});

describe('VectorMemory — update', () => {
  let mem;
  beforeEach(() => {
    mem = new TestVectorMemory();
    mem.store('upd-1', makeVector(4, 1), { version: 1 });
  });

  test('update() replaces vector data', () => {
    const newVec = makeVector(4, 99);
    mem.update('upd-1', { vector: newVec });
    expect(mem.get('upd-1').vector).toEqual(newVec);
  });

  test('update() merges metadata', () => {
    mem.update('upd-1', { metadata: { version: 2, extra: 'data' } });
    const entry = mem.get('upd-1');
    expect(entry.metadata.version).toBe(2);
    expect(entry.metadata.extra).toBe('data');
  });

  test('update() sets updatedAt to a newer timestamp', async () => {
    const before = mem.get('upd-1').updatedAt;
    await new Promise(r => setTimeout(r, 10));
    mem.update('upd-1', { metadata: { touched: true } });
    expect(mem.get('upd-1').updatedAt).toBeGreaterThanOrEqual(before);
  });

  test('update() returns false for non-existent key', () => {
    expect(mem.update('nonexistent', { metadata: { x: 1 } })).toBe(false);
  });

  test('store() overwrites existing entry (re-store == update)', () => {
    const original = mem.get('upd-1');
    const newVec = makeVector(4, 7);
    mem.store('upd-1', newVec, { version: 10 });
    const updated = mem.get('upd-1');
    expect(updated.vector).toEqual(newVec);
    expect(updated.metadata.version).toBe(10);
    expect(updated.createdAt).toBe(original.createdAt); // preserve creation time
  });
});

describe('VectorMemory — drift detection', () => {
  let mem;
  beforeEach(() => {
    mem = new TestVectorMemory({ driftThreshold: 0.3 });
    // Populate with "similar" vectors clustered around seed=1
    for (let i = 1; i <= 5; i++) {
      mem.store(`base-${i}`, makeVector(8, i), {});
    }
  });

  test('detectDrift() returns { drifted, score, centroid }', () => {
    const result = mem.detectDrift(makeVector(8, 1));
    expect(result).toHaveProperty('drifted');
    expect(result).toHaveProperty('score');
    expect(result).toHaveProperty('centroid');
    expect(typeof result.drifted).toBe('boolean');
    expect(typeof result.score).toBe('number');
    expect(Array.isArray(result.centroid)).toBe(true);
  });

  test('detectDrift() returns drifted=false for similar vector', () => {
    // A vector that belongs to the cluster (same family of sin-based vectors)
    // Score vs centroid may be moderate; the key is it should not be near-zero
    const similar = makeVector(8, 3); // middle of cluster
    const result = mem.detectDrift(similar);
    // Centroid of seeds 1-5 has moderate similarity to individual members
    expect(result.score).toBeGreaterThan(0.3);
  });

  test('detectDrift() returns drifted=true for orthogonal vector', () => {
    // Construct a vector orthogonal to the cluster centroid
    const centroid = mem.detectDrift(makeVector(8, 3)).centroid;
    // Negate and rotate — create a vector with low similarity
    const orthogonal = centroid.map((_, i) => (i % 2 === 0 ? -centroid[i + 1 < 8 ? i + 1 : 0] : centroid[i - 1]));
    const result = mem.detectDrift(orthogonal);
    // Orthogonal vectors have cosine similarity near 0
    expect(result.score).toBeLessThan(0.7);
  });

  test('detectDrift() returns drifted=false when store is empty', () => {
    const empty = new TestVectorMemory();
    const result = empty.detectDrift(makeVector(8, 1));
    expect(result.drifted).toBe(false);
    expect(result.centroid).toBeNull();
  });

  test('detectDrift() uses namespace-specific entries', () => {
    mem.store('other-ns', makeVector(8, 50), {}, 'other');
    // Drift against the default namespace should ignore 'other' namespace
    const result = mem.detectDrift(makeVector(8, 1));
    // Should still see high similarity (not skewed by far-away 'other' entry)
    expect(result.centroid).toHaveLength(8);
  });

  test('getRecent() returns most recently updated entries', () => {
    const recent = mem.getRecent({ limit: 2 });
    expect(recent).toHaveLength(2);
    // Most recent first
    expect(recent[0].updatedAt).toBeGreaterThanOrEqual(recent[1].updatedAt);
  });
});

// ─── Smoke test: attempt to import the real VectorMemory if available ─────────

describe('VectorMemory — real module smoke test (skipped if unavailable)', () => {
  let RealVectorMemory = null;

  beforeAll(() => {
    try {
      const mod = require('../src/vector-memory');
      RealVectorMemory = mod.VectorMemory || mod.default || mod;
    } catch {
      // Module not yet present — that's OK
    }
  });

  test('real VectorMemory can be instantiated if module is available', () => {
    if (!RealVectorMemory) {
      console.log('  (skipping — src/vector-memory.js not yet available)');
      return;
    }
    expect(() => new RealVectorMemory()).not.toThrow();
  });

  test('real VectorMemory exposes store() method if available', () => {
    if (!RealVectorMemory) return;
    const vm = new RealVectorMemory();
    expect(typeof vm.store).toBe('function');
  });

  test('real VectorMemory exposes search() method if available', () => {
    if (!RealVectorMemory) return;
    const vm = new RealVectorMemory();
    expect(typeof vm.search).toBe('function');
  });
});
