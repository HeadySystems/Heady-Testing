# Heady™ AI Platform v3.1.0

> **© 2024-2026 HeadySystems Inc. All Rights Reserved. PROPRIETARY AND CONFIDENTIAL.**

The Heady™ AI Platform is a production-grade, multi-node intelligence orchestration system built on Node.js 20+. It combines a Model Context Protocol (MCP) server, vector memory, pattern recognition, behavioral correction, narrative logging, and a proactive AI companion — all coordinated by the HeadyConductor orchestration engine.

**Never average. Always ready.**

---

## Architecture

```
╔═══════════════════════════════════════════════════════════════════════╗
║                   HEADY™ AI PLATFORM v3.1.0                          ║
╠═══════════════════════════════════════════════════════════════════════╣
║                                                                       ║
║   CLIENT LAYER                                                        ║
║   ┌─────────────┐  ┌─────────────┐  ┌──────────────┐                ║
║   │  MCP Client │  │  REST API   │  │  Web / Buddy │                ║
║   │  (Claude,   │  │  Consumer   │  │  Dashboard   │                ║
║   │  Cursor...) │  └──────┬──────┘  └──────┬───────┘                ║
║   └──────┬──────┘         │                │                        ║
║          └────────────────┴────────┬───────┘                        ║
║                                    │                                  ║
║   CLOUDFLARE TUNNEL                │                                  ║
║   ┌─────────────────────────────────────────────────────────────┐    ║
║   │  manager.headysystems.com  │  api.headysystems.com           │   ║
║   │  conductor.headysystems.com│  mcp.headymcp.com               │   ║
║   │  buddy.headybuddy.org      │  web.headysystems.com           │   ║
║   └────────────────────────┬────────────────────────────────────┘    ║
║                             │                                         ║
║   HEADY MANAGER (:3301)     │                                         ║
║   ┌─────────────────────────▼──────────────────────────────────┐     ║
║   │                                                             │     ║
║   │   ┌────────────────────────────────────┐                   │     ║
║   │   │      HeadyConductor (Orchestrator) │                   │     ║
║   │   └──────┬──────────────┬──────────────┘                   │     ║
║   │          │              │                                   │     ║
║   │   ┌──────▼──────┐  ┌───▼────────────────────────────────┐  │     ║
║   │   │ MCP Server  │  │        Node Mesh                   │  │     ║
║   │   │ (31 tools)  │  │                                    │  │     ║
║   │   │             │  │  HeadySoul   HeadyBrains            │  │     ║
║   │   │ ToolRegistry│  │  HeadyVinci  HeadyMemory            │  │     ║
║   │   └─────────────┘  │  HeadyArena  HeadyGovernance        │  │     ║
║   │                    │  HeadyBee    HeadyAutobiographer     │  │     ║
║   │   ┌─────────────┐  │  HeadyBuddy  HeadyLens              │  │     ║
║   │   │HCFullPipeline│  └────────────────────────────────────┘  │     ║
║   │   └─────────────┘                                            │     ║
║   │                                                               │     ║
║   │   SERVICES: StoryDriver │ BuddySystem │ Corrections           │    ║
║   └──────────────────────────────────────────────────────────────┘    ║
║                             │                                          ║
║   DATA LAYER                │                                          ║
║   ┌─────────────────────────▼──────────────────────────────────┐     ║
║   │  PostgreSQL + pgvector (:5432)  │  Redis (:6379)           │     ║
║   └──────────────────────────────────────────────────────────── ┘    ║
║                                                                        ║
╚════════════════════════════════════════════════════════════════════════╝

LAYERS
  local      → on-device / edge  (Vinci, Memory, Governance, Autobiographer)
  cloud-me   → personal cloud    (Soul, Brains)
  cloud-sys  → HeadySystems infra (Arena, Conductor)
  cloud-conn → external services  (Bee, Lens)
  hybrid     → adaptive           (Soul, Conductor, Buddy)
```

---

## Quick Start

### Prerequisites

- Node.js 20+
- npm 10+
- Docker & Docker Compose (for containerized deployment)
- PostgreSQL 16 with pgvector (or use Docker Compose)
- Redis 7.2+ (or use Docker Compose)

### 1. Install & Configure

```bash
# Bootstrap (checks Node version, installs deps, creates .env, initializes data dir)
chmod +x heady-init.sh && ./heady-init.sh

# Or manually:
npm install
cp .env.example .env
# Edit .env with your API keys and settings
```

### 2. Start the Platform

```bash
# Start the Heady Manager (all services)
npm start

# Start MCP server on stdio (for Claude Desktop, Cursor, etc.)
npm run start:mcp

# Development mode with hot-reload
npm run dev
```

### 3. Docker Deployment

```bash
# Full stack (Manager + Postgres + Redis)
docker compose up -d

# Check all services are healthy
docker compose ps

# View logs
docker compose logs -f heady-manager

# Scale horizontally (example)
docker compose up -d --scale heady-manager=3
```

---

## Cloudflare Tunnel Setup

```bash
# 1. Install cloudflared
brew install cloudflare/cloudflare/cloudflared   # macOS
# or: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/

# 2. Authenticate
cloudflared tunnel login

# 3. Create the tunnel
cloudflared tunnel create heady-platform

# 4. Note the tunnel ID, add to .env:
#    CF_TUNNEL_ID=<your-tunnel-id>

# 5. Copy credentials file
cp ~/.cloudflared/<tunnel-id>.json /etc/cloudflare/tunnel-credentials.json

# 6. Run the tunnel (production — use as a service)
cloudflared tunnel --config cloudflare/tunnel-config.yml run

# 7. Create DNS records in Cloudflare dashboard:
#    CNAME manager.headysystems.com   → <tunnel-id>.cfargotunnel.com
#    CNAME api.headysystems.com       → <tunnel-id>.cfargotunnel.com
#    CNAME conductor.headysystems.com → <tunnel-id>.cfargotunnel.com
#    CNAME mcp.headymcp.com           → <tunnel-id>.cfargotunnel.com
#    CNAME buddy.headybuddy.org       → <tunnel-id>.cfargotunnel.com
#    CNAME web.headysystems.com       → <tunnel-id>.cfargotunnel.com
```

---

## MCP Integration

### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "heady": {
      "command": "node",
      "args": ["/path/to/heady-rebuild/src/mcp/mcp-server.js"],
      "env": {
        "HEADY_API_URL": "https://manager.headysystems.com",
        "HEADY_API_KEY": "your-api-key"
      }
    }
  }
}
```

### Cursor

Add to `.cursor/mcp.json` in your project root:

```json
{
  "mcpServers": {
    "heady": {
      "command": "node",
      "args": ["src/mcp/mcp-server.js"]
    }
  }
}
```

---

## MCP Tools Reference (31 Tools)

| # | Tool | Description |
|---|------|-------------|
| 1 | `heady_memory` | Search vector memory with semantic similarity |
| 2 | `heady_embed` | Generate embeddings (text → vector) |
| 3 | `heady_soul` | Soul intelligence: analyze / optimize / learn |
| 4 | `heady_vinci` | Pattern recognition: learn / predict / recognize |
| 5 | `heady_conductor_route` | Route task via HeadyConductor |
| 6 | `heady_pipeline_run` | Execute HCFullPipeline |
| 7 | `heady_battle` | Arena battle between candidate solutions |
| 8 | `heady_health` | Health check for a service |
| 9 | `heady_status` | Full system status |
| 10 | `heady_nodes` | List all active nodes |
| 11 | `heady_monte_carlo` | Run Monte Carlo simulation |
| 12 | `heady_deploy` | Deploy to target environment |
| 13 | `heady_code_generate` | Generate production-ready code |
| 14 | `heady_code_review` | Review code for bugs/security/quality |
| 15 | `heady_research` | Deep research on any topic |
| 16 | `heady_creative` | Creative content generation |
| 17 | `heady_analyze` | Data/text analysis |
| 18 | `heady_patterns` | Detect patterns in data |
| 19 | `heady_governance_check` | Validate action against governance policies |
| 20 | `heady_budget_status` | Budget tracking and limits |
| 21 | `heady_bee_spawn` | Spawn a Bee worker agent |
| 22 | `heady_bee_status` | Check Bee agent status |
| 23 | `heady_drift_check` | Check semantic drift for a component |
| 24 | `heady_coherence` | System coherence score |
| 25 | `heady_readiness` | Operational readiness check |
| 26 | `heady_story` | Log event to HeadyAutobiographer |
| 27 | `heady_corrections` | Analyze and apply behavioral corrections |
| 28 | `heady_lens` | AR overlay explanation for targets |
| 29 | `heady_secrets` | Secret management (get/set/rotate/list) |
| 30 | `heady_config` | Configuration management (get/set) |
| 31 | `heady_audit` | Audit trail query |

---

## Environment Variables

Copy `.env.example` to `.env` and configure:

### Core

| Variable | Default | Description |
|----------|---------|-------------|
| `NODE_ENV` | `production` | Runtime environment |
| `PORT` | `3301` | HTTP server port |
| `LOG_LEVEL` | `info` | Logging level (`debug`, `info`, `warn`, `error`) |
| `LOG_FORMAT` | `json` | Log format (`json`, `pretty`) |

### AI / LLM

| Variable | Required | Description |
|----------|----------|-------------|
| `OPENAI_API_KEY` | Yes | OpenAI API key |
| `ANTHROPIC_API_KEY` | No | Anthropic API key (fallback) |
| `DEFAULT_MODEL` | `gpt-4o` | Default LLM model |
| `EMBEDDING_MODEL` | `text-embedding-3-small` | Embedding model |
| `EMBEDDING_DIMS` | `1536` | Embedding vector dimensions |

### Database

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | — | PostgreSQL connection string with pgvector |
| `POSTGRES_USER` | `heady` | DB username |
| `POSTGRES_PASSWORD` | — | DB password (required) |
| `POSTGRES_DB` | `headydb` | Database name |
| `DB_POOL_MIN` | `2` | Connection pool minimum |
| `DB_POOL_MAX` | `10` | Connection pool maximum |

### Redis

| Variable | Default | Description |
|----------|---------|-------------|
| `REDIS_URL` | `redis://redis:6379` | Redis connection URL |
| `REDIS_PASSWORD` | — | Redis password (optional) |
| `REDIS_MAX_MEMORY` | `256mb` | Max Redis memory |

### Security

| Variable | Required | Description |
|----------|----------|-------------|
| `HEADY_SECRET_KEY` | Yes | Platform master secret |
| `JWT_SECRET` | Yes | JWT signing secret |
| `API_KEY_SALT` | Yes | API key hashing salt |

### Pipeline

| Variable | Default | Description |
|----------|---------|-------------|
| `CONDUCTOR_TIMEOUT` | `30000` | Conductor task timeout (ms) |
| `CONDUCTOR_MAX_RETRIES` | `3` | Max conductor retries |
| `PIPELINE_FULL_AUTO` | `false` | Enable full-auto pipeline mode |
| `BUDGET_DAILY_USD` | `100` | Daily LLM spend limit |
| `BUDGET_WARN_PCT` | `80` | Budget warning threshold (%) |

### Cloudflare

| Variable | Required | Description |
|----------|----------|-------------|
| `CF_TUNNEL_ID` | Yes (tunnel) | Cloudflare Tunnel ID |
| `CF_TUNNEL_TOKEN` | Yes (tunnel) | Cloudflare Tunnel token |
| `CF_ACCOUNT_ID` | No | Cloudflare Account ID |

---

## Domain Map

| Domain | Role | Description |
|--------|------|-------------|
| `manager.headysystems.com` | Primary | Orchestration manager |
| `api.headysystems.com` | API | Public REST API |
| `conductor.headysystems.com` | Routing | Task conductor |
| `mcp.headymcp.com` | MCP | Model Context Protocol server |
| `buddy.headybuddy.org` | Companion | HeadyBuddy interface |
| `web.headysystems.com` | Dashboard | Web layer |
| `headyconnection.org` | Community | Community platform |
| `headybee.co` | Agents | Bee worker colony |
| `headylens.ai` | AR | Overlay intelligence |
| `headyarena.io` | Evaluation | Battle arena |
| `headyvinci.com` | Patterns | Pattern recognition |
| `headysoul.ai` | Intelligence | Soul engine |

---

## File Structure

```
heady-rebuild/
├── src/
│   ├── mcp/
│   │   ├── mcp-server.js        # MCP Server — 31 tools, stdio transport
│   │   └── tool-registry.js     # Tool registration, validation, execution
│   ├── services/
│   │   ├── story-driver.js      # HeadyAutobiographer / narrative logger
│   │   ├── buddy-system.js      # HeadyBuddy companion system
│   │   └── corrections.js       # Behavioral analysis and corrections
│   ├── conductor/               # HeadyConductor orchestration
│   ├── nodes/                   # Node implementations
│   ├── memory/                  # Vector memory layer
│   ├── governance/              # Policy and safety validation
│   ├── arena/                   # Battle arena evaluation
│   └── web/                     # Web layer / dashboard
├── configs/
│   ├── heady-registry.json      # Service registry (9 domains, 11 nodes, 5 layers)
│   └── hcfullpipeline.json      # Pipeline stages, pools, timeouts
├── cloudflare/
│   └── tunnel-config.yml        # Cloudflare Tunnel ingress rules
├── scripts/
│   └── init-db.sql              # Database initialization
├── data/                        # Runtime data directory
├── logs/                        # Application logs
├── Dockerfile                   # Multi-stage Docker build (node:20-alpine)
├── docker-compose.yml           # Full stack (Manager + Postgres + Redis)
├── heady-init.sh                # Bootstrap script
├── .env.example                 # Environment variable template
├── package.json
└── README.md
```

---

## npm Scripts

```bash
npm start           # Start Heady Manager
npm run start:mcp   # Start MCP server (stdio transport)
npm run dev         # Development mode (nodemon)
npm test            # Run test suite
npm run lint        # ESLint check
npm run health      # Quick health check against running server
```

---

## Health Endpoints

| Endpoint | Description |
|----------|-------------|
| `GET /health/live` | Liveness — is the process running? |
| `GET /health/ready` | Readiness — are all deps connected? |
| `GET /health/status` | Full status with all node states |

---

## License

**PROPRIETARY AND CONFIDENTIAL**
© 2024-2026 HeadySystems Inc. All Rights Reserved.
Unauthorized copying, distribution, or use is strictly prohibited.
