/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

/**
 * Structured logger for the Heady™ AI Platform.
 * Uses pino when available, falls back to a console-based logger.
 */

let pino;
try {
  pino = require('pino');
} catch {
  pino = null;
}

const LEVELS = { trace: 10, debug: 20, info: 30, warn: 40, error: 50, fatal: 60 };
const currentLevel = LEVELS[process.env.LOG_LEVEL] || LEVELS.info;

function _emit(level, levelName, args) {
  if (LEVELS[levelName] < currentLevel) return;
  const [msg, ...rest] = args;
  const meta = rest.length > 0 && typeof rest[0] === 'object' ? rest[0] : {};
  const line = JSON.stringify({ level: levelName, time: Date.now(), msg, ...meta });
  if (levelName === 'error' || levelName === 'fatal') {
    process.stderr.write(line + '\n');
  } else {
    process.stdout.write(line + '\n');
  }
}

function createLogger(name) {
  if (pino) {
    return pino({ name, level: process.env.LOG_LEVEL || 'info' });
  }
  const logger = {};
  for (const level of Object.keys(LEVELS)) {
    logger[level] = (...args) => _emit(level, level, args);
  }
  return logger;
}

const defaultLogger = createLogger('heady');

module.exports = defaultLogger;
module.exports.createLogger = createLogger;
