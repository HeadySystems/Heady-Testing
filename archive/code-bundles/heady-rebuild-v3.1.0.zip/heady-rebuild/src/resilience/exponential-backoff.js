/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const logger = require('../utils/logger');

/**
 * Golden Ratio (φ) constant.
 * Used as the base for exponential backoff: delay * PHI^attempt
 *
 * Why PHI?
 *   PHI produces sub-exponential but super-linear growth — aggressive enough
 *   to back off rapidly, but gentler than base-2, reducing retry storms.
 *   PHI is also irrational, making PHI-jittered retry intervals spread more
 *   uniformly and less prone to thundering herd than power-of-2 intervals.
 */
const PHI = 1.6180339887;

// ─── Default options ──────────────────────────────────────────────────────────
const DEFAULT_BASE_DELAY_MS = 500;    // 500 ms
const DEFAULT_MAX_DELAY_MS  = 60_000; // 60 s cap
const DEFAULT_MAX_ATTEMPTS  = 7;
const DEFAULT_JITTER_FACTOR = 0.3;    // 30 % jitter

// ─── Core functions ───────────────────────────────────────────────────────────

/**
 * Compute the PHI-exponential backoff delay for a given attempt.
 *
 * Formula: delay = baseDelay * PHI^attempt
 * Capped at maxDelayMs.
 *
 * @param {number} attempt    - 0-indexed attempt number (0 = first retry)
 * @param {number} [baseDelay=500]  - Base delay in ms
 * @param {number} [maxDelay=60000] - Maximum delay cap in ms
 * @returns {number} Delay in ms (integer, no jitter)
 */
function phiBackoff(attempt, baseDelay = DEFAULT_BASE_DELAY_MS, maxDelay = DEFAULT_MAX_DELAY_MS) {
  if (attempt < 0) throw new RangeError('attempt must be >= 0');
  const raw = baseDelay * Math.pow(PHI, attempt);
  return Math.min(Math.round(raw), maxDelay);
}

/**
 * Add random jitter to a delay to avoid synchronized retries (thundering herd).
 *
 * Uses "full jitter" strategy: delay ∈ [0, delay * (1 + jitterFactor)].
 * Full jitter outperforms equal jitter in distributed systems under load.
 *
 * @param {number} delay               - Base delay in ms
 * @param {number} [jitterFactor=0.3]  - Fraction of delay to add as random noise
 * @returns {number} Delay with jitter applied (integer)
 */
function withJitter(delay, jitterFactor = DEFAULT_JITTER_FACTOR) {
  if (jitterFactor < 0 || jitterFactor > 1) {
    throw new RangeError('jitterFactor must be between 0 and 1');
  }
  const jitter = Math.random() * delay * jitterFactor;
  return Math.round(delay + jitter);
}

/**
 * Convenience: compute PHI backoff with jitter in one call.
 *
 * @param {number} attempt
 * @param {number} [baseDelay=500]
 * @param {number} [maxDelay=60000]
 * @param {number} [jitterFactor=0.3]
 * @returns {number} ms
 */
function phiBackoffWithJitter(
  attempt,
  baseDelay   = DEFAULT_BASE_DELAY_MS,
  maxDelay    = DEFAULT_MAX_DELAY_MS,
  jitterFactor = DEFAULT_JITTER_FACTOR
) {
  return withJitter(phiBackoff(attempt, baseDelay, maxDelay), jitterFactor);
}

/**
 * Sleep for `ms` milliseconds. Promise-based.
 * @param {number} ms
 * @returns {Promise<void>}
 */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ─── retry() ─────────────────────────────────────────────────────────────────

/**
 * Retry a function with PHI-exponential backoff.
 *
 * @template T
 * @param {() => Promise<T>} fn         - Async function to retry
 * @param {object}           [options]
 * @param {number} [options.maxAttempts=7]        - Maximum number of total attempts
 * @param {number} [options.baseDelay=500]        - Base delay in ms
 * @param {number} [options.maxDelay=60000]       - Maximum delay cap in ms
 * @param {number} [options.jitterFactor=0.3]     - Jitter fraction (0–1)
 * @param {Function|null} [options.shouldRetry]  - (error, attempt) => boolean — custom retry predicate
 * @param {Function|null} [options.onRetry]      - (error, attempt, delayMs) => void — callback on each retry
 * @param {string}  [options.label]              - Label for logging
 * @returns {Promise<T>}
 * @throws {*} The last error after all attempts are exhausted
 */
async function retry(fn, options = {}) {
  const maxAttempts  = options.maxAttempts  || DEFAULT_MAX_ATTEMPTS;
  const baseDelay    = options.baseDelay    || DEFAULT_BASE_DELAY_MS;
  const maxDelay     = options.maxDelay     || DEFAULT_MAX_DELAY_MS;
  const jitterFactor = options.jitterFactor !== undefined ? options.jitterFactor : DEFAULT_JITTER_FACTOR;
  const shouldRetry  = options.shouldRetry  || null;
  const onRetry      = options.onRetry      || null;
  const label        = options.label        || 'fn';

  let lastError;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      const result = await fn();

      if (attempt > 0) {
        logger.info(`[phiBackoff:retry] ${label} succeeded after ${attempt + 1} attempt(s)`);
      }

      return result;

    } catch (err) {
      lastError = err;

      // Check if we should retry this error
      if (typeof shouldRetry === 'function' && !shouldRetry(err, attempt)) {
        logger.debug(`[phiBackoff:retry] ${label} not retrying: shouldRetry returned false`, {
          attempt, error: err.message,
        });
        throw err;
      }

      const isLastAttempt = attempt === maxAttempts - 1;
      if (isLastAttempt) {
        logger.error(`[phiBackoff:retry] ${label} exhausted all ${maxAttempts} attempts`, {
          error: err.message,
        });
        break;
      }

      // Compute delay for next attempt (attempt index = retry number)
      const rawDelay    = phiBackoff(attempt, baseDelay, maxDelay);
      const jitteredDelay = withJitter(rawDelay, jitterFactor);

      if (typeof onRetry === 'function') {
        try {
          onRetry(err, attempt, jitteredDelay);
        } catch {
          // Non-fatal — don't let the callback break retry logic
        }
      }

      logger.warn(`[phiBackoff:retry] ${label} attempt ${attempt + 1}/${maxAttempts} failed; retrying in ${jitteredDelay}ms`, {
        error: err.message,
        delay: jitteredDelay,
        phi: PHI,
        rawDelay,
      });

      await sleep(jitteredDelay);
    }
  }

  throw lastError;
}

// ─── Retry with custom error classes ─────────────────────────────────────────

/**
 * A predicate factory that retries only on specific error codes.
 *
 * @param {...string} codes - Error codes to retry on
 * @returns {Function} (error) => boolean
 */
function retryOnCodes(...codes) {
  const codeSet = new Set(codes);
  return (err) => codeSet.has(err.code);
}

/**
 * A predicate that retries on network / transient errors only.
 * Useful for LLM API calls, vector DB ops, etc.
 *
 * @param {Error} err
 * @returns {boolean}
 */
function isTransientError(err) {
  if (!err) return false;
  const transientCodes = new Set([
    'ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND',
    'EPIPE', 'EAI_AGAIN', 'CIRCUIT_OPEN', 'RATE_LIMIT_EXCEEDED',
  ]);
  if (transientCodes.has(err.code)) return true;
  if (err.status && (err.status === 429 || err.status === 503 || err.status === 502)) return true;
  if (err.isTimeout) return true;
  return false;
}

// ─── Delay schedule preview ───────────────────────────────────────────────────

/**
 * Preview the backoff delay schedule for a given config.
 * Useful for testing and documentation.
 *
 * @param {object} [options]
 * @param {number} [options.maxAttempts=7]
 * @param {number} [options.baseDelay=500]
 * @param {number} [options.maxDelay=60000]
 * @returns {number[]} Array of delays in ms (no jitter)
 */
function previewSchedule(options = {}) {
  const maxAttempts = options.maxAttempts || DEFAULT_MAX_ATTEMPTS;
  const baseDelay   = options.baseDelay   || DEFAULT_BASE_DELAY_MS;
  const maxDelay    = options.maxDelay    || DEFAULT_MAX_DELAY_MS;

  return Array.from({ length: maxAttempts }, (_, i) => phiBackoff(i, baseDelay, maxDelay));
}

// ─── Exports ──────────────────────────────────────────────────────────────────
module.exports = {
  PHI,
  phiBackoff,
  withJitter,
  phiBackoffWithJitter,
  sleep,
  retry,
  retryOnCodes,
  isTransientError,
  previewSchedule,
};
