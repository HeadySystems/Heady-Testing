/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const { EventEmitter } = require('events');
const logger = require('../utils/logger');

const PHI = 1.6180339887;

// ─── Circuit States ───────────────────────────────────────────────────────────
const CircuitState = Object.freeze({
  CLOSED:    'CLOSED',    // Normal operation — requests pass through
  OPEN:      'OPEN',      // Failing — requests rejected immediately
  HALF_OPEN: 'HALF_OPEN', // Recovery probe — limited requests pass
});

// ─── Default configuration ────────────────────────────────────────────────────
const DEFAULT_CONFIG = {
  name:             'default',
  failureThreshold: 5,          // Open after N consecutive failures
  successThreshold: 2,          // Close after N consecutive successes in HALF_OPEN
  recoveryTimeout:  30_000,     // ms before moving OPEN → HALF_OPEN
  halfOpenRequests: 1,          // Number of probe requests allowed in HALF_OPEN
  timeout:          10_000,     // ms before a call is considered failed (timeout)
  volumeThreshold:  10,         // Min requests before opening is allowed (prevents false opens on startup)
  errorFilter:      null,       // Optional: (error) => boolean — only count filtered errors
  phiRecoveryScale: true,       // Use PHI-exponential back-off on recovery timeout
};

/**
 * CircuitBreaker — Implements the Circuit Breaker resilience pattern.
 *
 * State machine:
 *   CLOSED   → requests pass through; failures counted
 *            → OPEN when failureThreshold reached
 *
 *   OPEN     → all requests rejected with CircuitOpenError
 *            → transitions to HALF_OPEN after recoveryTimeout (PHI-scaled on retries)
 *
 *   HALF_OPEN → limited probe requests allowed
 *             → CLOSED if successThreshold successes in a row
 *             → OPEN if any probe fails
 *
 * @extends EventEmitter
 */
class CircuitBreaker extends EventEmitter {
  /**
   * @param {object} [options]  - Merged with DEFAULT_CONFIG
   * @param {string} [options.name]
   * @param {number} [options.failureThreshold]
   * @param {number} [options.successThreshold]
   * @param {number} [options.recoveryTimeout]
   * @param {number} [options.halfOpenRequests]
   * @param {number} [options.timeout]
   * @param {number} [options.volumeThreshold]
   * @param {Function|null} [options.errorFilter]
   * @param {boolean} [options.phiRecoveryScale]
   */
  constructor(options = {}) {
    super();
    this._config = { ...DEFAULT_CONFIG, ...options };

    this._state          = CircuitState.CLOSED;
    this._failureCount   = 0;
    this._successCount   = 0;   // Consecutive successes in HALF_OPEN
    this._totalRequests  = 0;   // Total requests since last reset
    this._openedAt       = null;
    this._recoveryAttempts = 0; // For PHI-scaled recovery delays
    this._halfOpenActive = 0;   // Active probe requests in HALF_OPEN
    this._recoveryTimer  = null;
    this._stats = {
      totalRequests:   0,
      successCount:    0,
      failureCount:    0,
      rejectedCount:   0,
      timeoutCount:    0,
      openTransitions: 0,
      closeTransitions: 0,
    };

    logger.info('[CircuitBreaker] Initialized', {
      name: this._config.name,
      failureThreshold: this._config.failureThreshold,
      recoveryTimeout: this._config.recoveryTimeout,
    });
  }

  // ─── Public API ──────────────────────────────────────────────────────────────

  /**
   * Execute a function with circuit breaker protection.
   *
   * @template T
   * @param {() => Promise<T>} fn - The function to execute
   * @returns {Promise<T>}
   * @throws {CircuitOpenError}    if circuit is OPEN
   * @throws {CircuitTimeoutError} if call exceeds timeout
   * @throws {*}                   passes through errors from fn()
   */
  async execute(fn) {
    this._stats.totalRequests++;
    this._totalRequests++;

    switch (this._state) {
      case CircuitState.OPEN:
        return this._handleOpen();

      case CircuitState.HALF_OPEN:
        return this._handleHalfOpen(fn);

      case CircuitState.CLOSED:
      default:
        return this._handleClosed(fn);
    }
  }

  /**
   * Force the circuit to OPEN state.
   * Useful for maintenance windows.
   */
  forceOpen() {
    this._transitionToOpen();
    logger.warn('[CircuitBreaker] Forced OPEN', { name: this._config.name });
  }

  /**
   * Force the circuit to CLOSED state and reset all counters.
   */
  forceClose() {
    this._transitionToClosed();
    logger.info('[CircuitBreaker] Forced CLOSE', { name: this._config.name });
  }

  /**
   * Get the current state.
   * @returns {string} CircuitState value
   */
  getState() {
    return this._state;
  }

  /**
   * Get circuit statistics.
   * @returns {object}
   */
  getStats() {
    return {
      name: this._config.name,
      state: this._state,
      failureCount: this._failureCount,
      successCount: this._successCount,
      totalRequests: this._totalRequests,
      openedAt: this._openedAt,
      recoveryAttempts: this._recoveryAttempts,
      ...this._stats,
    };
  }

  /**
   * Reset all counters and return to CLOSED state.
   */
  reset() {
    this._state         = CircuitState.CLOSED;
    this._failureCount  = 0;
    this._successCount  = 0;
    this._totalRequests = 0;
    this._openedAt      = null;
    this._recoveryAttempts = 0;
    this._halfOpenActive = 0;
    if (this._recoveryTimer) {
      clearTimeout(this._recoveryTimer);
      this._recoveryTimer = null;
    }
    this.emit('circuit:reset', { name: this._config.name });
    logger.info('[CircuitBreaker] Reset', { name: this._config.name });
  }

  // ─── State Handlers ───────────────────────────────────────────────────────────

  /**
   * Handle execution in CLOSED state.
   */
  async _handleClosed(fn) {
    try {
      const result = await this._callWithTimeout(fn);
      this._onSuccess();
      return result;
    } catch (err) {
      this._onFailure(err);
      throw err;
    }
  }

  /**
   * Handle execution in OPEN state — reject immediately.
   */
  _handleOpen() {
    this._stats.rejectedCount++;
    const err = Object.assign(
      new Error(`[CircuitBreaker:${this._config.name}] Circuit is OPEN — request rejected`),
      {
        code: 'CIRCUIT_OPEN',
        circuitName: this._config.name,
        openedAt: this._openedAt,
        retryAfterMs: this._nextRecoveryMs(),
      }
    );
    this.emit('circuit:rejected', { name: this._config.name });
    throw err;
  }

  /**
   * Handle execution in HALF_OPEN state — allow limited probes.
   */
  async _handleHalfOpen(fn) {
    if (this._halfOpenActive >= this._config.halfOpenRequests) {
      // Already at probe limit
      return this._handleOpen();
    }

    this._halfOpenActive++;

    try {
      const result = await this._callWithTimeout(fn);
      this._halfOpenActive--;
      this._onHalfOpenSuccess();
      return result;
    } catch (err) {
      this._halfOpenActive--;
      this._onHalfOpenFailure(err);
      throw err;
    }
  }

  // ─── Success / Failure Accounting ────────────────────────────────────────────

  _onSuccess() {
    this._failureCount = 0;
    this._successCount++;
    this._stats.successCount++;
  }

  _onFailure(err) {
    if (this._shouldCount(err)) {
      this._failureCount++;
      this._stats.failureCount++;
      if (err && err.isTimeout) this._stats.timeoutCount++;

      if (this._failureCount >= this._config.failureThreshold &&
          this._totalRequests >= this._config.volumeThreshold) {
        this._transitionToOpen();
      }
    }
  }

  _onHalfOpenSuccess() {
    this._successCount++;
    this._stats.successCount++;

    if (this._successCount >= this._config.successThreshold) {
      this._transitionToClosed();
    }
  }

  _onHalfOpenFailure(err) {
    if (this._shouldCount(err)) {
      this._stats.failureCount++;
      this._transitionToOpen(); // Any failure in HALF_OPEN re-opens
    }
  }

  /**
   * Determine if an error should count toward the failure threshold.
   */
  _shouldCount(err) {
    if (typeof this._config.errorFilter === 'function') {
      return this._config.errorFilter(err);
    }
    return true; // Count all errors by default
  }

  // ─── State Transitions ────────────────────────────────────────────────────────

  _transitionToOpen() {
    if (this._state === CircuitState.OPEN) return; // Already open

    const prev = this._state;
    this._state    = CircuitState.OPEN;
    this._openedAt = Date.now();
    this._successCount = 0;
    this._stats.openTransitions++;

    if (this._recoveryTimer) clearTimeout(this._recoveryTimer);

    const delay = this._nextRecoveryMs();
    this._recoveryTimer = setTimeout(() => this._transitionToHalfOpen(), delay);
    if (this._recoveryTimer.unref) this._recoveryTimer.unref();

    this.emit('circuit:opened', {
      name: this._config.name,
      failureCount: this._failureCount,
      recoveryDelayMs: delay,
    });
    logger.warn('[CircuitBreaker] CLOSED → OPEN', {
      name: this._config.name,
      failureCount: this._failureCount,
      recoveryDelayMs: delay,
    });
  }

  _transitionToHalfOpen() {
    if (this._state !== CircuitState.OPEN) return;

    this._recoveryAttempts++;
    this._state        = CircuitState.HALF_OPEN;
    this._successCount = 0;
    this._failureCount = 0;
    this._halfOpenActive = 0;

    this.emit('circuit:half-open', { name: this._config.name, attempt: this._recoveryAttempts });
    logger.info('[CircuitBreaker] OPEN → HALF_OPEN', {
      name: this._config.name,
      attempt: this._recoveryAttempts,
    });
  }

  _transitionToClosed() {
    const prev = this._state;
    this._state          = CircuitState.CLOSED;
    this._failureCount   = 0;
    this._successCount   = 0;
    this._openedAt       = null;
    this._recoveryAttempts = 0;
    this._halfOpenActive = 0;
    this._stats.closeTransitions++;

    if (this._recoveryTimer) {
      clearTimeout(this._recoveryTimer);
      this._recoveryTimer = null;
    }

    this.emit('circuit:closed', { name: this._config.name });
    logger.info('[CircuitBreaker] → CLOSED', { name: this._config.name, from: prev });
  }

  // ─── PHI-Exponential Recovery Timing ─────────────────────────────────────────

  /**
   * Compute next recovery delay using PHI-exponential backoff.
   * delay = recoveryTimeout * PHI^attempts, capped at 5 minutes.
   * @returns {number} ms
   */
  _nextRecoveryMs() {
    if (!this._config.phiRecoveryScale) return this._config.recoveryTimeout;
    const attempts = this._recoveryAttempts;
    const scaled = this._config.recoveryTimeout * Math.pow(PHI, Math.min(attempts, 6));
    return Math.min(scaled, 5 * 60_000); // Max 5 minutes
  }

  // ─── Timeout Wrapper ─────────────────────────────────────────────────────────

  /**
   * Call fn() with a hard timeout.
   */
  _callWithTimeout(fn) {
    const timeoutMs = this._config.timeout;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(Object.assign(
          new Error(`[CircuitBreaker:${this._config.name}] Timeout after ${timeoutMs}ms`),
          { code: 'CIRCUIT_TIMEOUT', isTimeout: true }
        ));
      }, timeoutMs);

      Promise.resolve().then(fn).then(
        (v) => { clearTimeout(timer); resolve(v); },
        (e) => { clearTimeout(timer); reject(e); }
      );
    });
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────
module.exports = { CircuitBreaker, CircuitState, PHI };
