/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const { EventEmitter } = require('events');
const logger = require('../utils/logger');

const PHI = 1.6180339887;

// ─── Fibonacci allocation percentages for pool sizing ────────────────────────
// Sequence: 1, 1, 2, 3, 5, 8, 13 → normalize to 100 %
// Hot=34%, Warm=21%, Cold=13%, Reserve=8%, Governance=5%  (sums ~81%, rest flex)
const FIBONACCI_ALLOCATIONS = {
  HOT:        0.34,
  WARM:       0.21,
  COLD:       0.13,
  RESERVE:    0.08,
  GOVERNANCE: 0.05,
};

const POOL_NAMES = Object.freeze({
  HOT:        'HOT',
  WARM:       'WARM',
  COLD:       'COLD',
  RESERVE:    'RESERVE',
  GOVERNANCE: 'GOVERNANCE',
});

// ─── Semaphore ────────────────────────────────────────────────────────────────

/**
 * Counting semaphore for concurrency control.
 * Supports async acquire/release with FIFO queue.
 */
class Semaphore {
  /**
   * @param {number} maxConcurrency
   */
  constructor(maxConcurrency) {
    this._max     = maxConcurrency;
    this._current = 0;
    this._queue   = []; // Array<{ resolve: Function, reject: Function, timeout: NodeJS.Timeout }>
  }

  /**
   * Acquire a slot. Resolves when a slot is available.
   * @param {number} [timeoutMs] - Optional timeout in ms; rejects with error if exceeded
   * @returns {Promise<void>}
   */
  acquire(timeoutMs = 30_000) {
    return new Promise((resolve, reject) => {
      if (this._current < this._max) {
        this._current++;
        resolve();
        return;
      }

      let timer = null;
      const entry = { resolve, reject, timer: null };

      if (timeoutMs > 0) {
        entry.timer = setTimeout(() => {
          const idx = this._queue.indexOf(entry);
          if (idx !== -1) this._queue.splice(idx, 1);
          reject(new Error(`Semaphore acquire timeout after ${timeoutMs}ms`));
        }, timeoutMs);
      }

      this._queue.push(entry);
    });
  }

  /**
   * Release a slot. Wakes the next waiter.
   */
  release() {
    if (this._queue.length > 0) {
      const next = this._queue.shift();
      if (next.timer) clearTimeout(next.timer);
      // Keep current count the same — the waiting coroutine takes the slot
      next.resolve();
    } else {
      this._current = Math.max(0, this._current - 1);
    }
  }

  get available() { return Math.max(0, this._max - this._current); }
  get waiting()   { return this._queue.length; }
  get inUse()     { return this._current; }
  get capacity()  { return this._max; }
}

// ─── Pool ─────────────────────────────────────────────────────────────────────

/**
 * Represents a single resource pool.
 */
class Pool {
  /**
   * @param {object} config
   * @param {string} config.name
   * @param {number} config.allocation   - Fraction of total capacity (e.g. 0.34)
   * @param {number} config.concurrency  - Max simultaneous tasks
   * @param {number} config.timeout      - Acquire timeout ms
   * @param {string} [config.description]
   */
  constructor(config) {
    this.name        = config.name;
    this.allocation  = config.allocation;
    this.concurrency = config.concurrency;
    this.timeout     = config.timeout || 30_000;
    this.description = config.description || '';
    this._semaphore  = new Semaphore(config.concurrency);
    this._acquireCount = 0;
    this._releaseCount = 0;
    this._timeoutCount = 0;
    this._createdAt = Date.now();
  }

  /**
   * Acquire a slot in this pool.
   * @returns {Promise<void>}
   */
  async acquire() {
    try {
      await this._semaphore.acquire(this.timeout);
      this._acquireCount++;
    } catch (err) {
      this._timeoutCount++;
      throw Object.assign(err, { pool: this.name });
    }
  }

  /**
   * Release a slot back to the pool.
   */
  release() {
    this._semaphore.release();
    this._releaseCount++;
  }

  /**
   * @returns {object} Utilization statistics
   */
  getUtilization() {
    const used = this._semaphore.inUse;
    return {
      name: this.name,
      capacity: this.concurrency,
      inUse: used,
      available: this._semaphore.available,
      waiting: this._semaphore.waiting,
      utilization: used / this.concurrency,
      acquireCount: this._acquireCount,
      releaseCount: this._releaseCount,
      timeoutCount: this._timeoutCount,
      allocationFraction: this.allocation,
    };
  }

  /**
   * Resize the pool's concurrency limit dynamically.
   * @param {number} newConcurrency
   */
  resize(newConcurrency) {
    const old = this.concurrency;
    this.concurrency = Math.max(1, newConcurrency);
    // Adjust the semaphore's capacity
    this._semaphore._max = this.concurrency;
    logger.info('[Pool] Resized', { pool: this.name, from: old, to: this.concurrency });
  }
}

// ─── PoolManager ─────────────────────────────────────────────────────────────

/**
 * Manages the five resource pools: Hot, Warm, Cold, Reserve, Governance.
 *
 * Pools are sized by Fibonacci allocation percentages from a total concurrency budget.
 * Includes dynamic rebalancing when pools are overloaded.
 *
 * @extends EventEmitter
 */
class PoolManager extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.totalConcurrency=100] - Total concurrency budget
   * @param {number} [options.rebalanceIntervalMs=60000] - How often to auto-rebalance
   * @param {object} [options.overrides]            - Per-pool override configs
   */
  constructor(options = {}) {
    super();

    this.totalConcurrency      = options.totalConcurrency || 100;
    this.rebalanceIntervalMs   = options.rebalanceIntervalMs || 60_000;
    this._rebalanceTimer       = null;
    this._pools                = new Map();

    const overrides = options.overrides || {};

    // Initialize pools from Fibonacci allocations
    for (const [poolName, fraction] of Object.entries(FIBONACCI_ALLOCATIONS)) {
      const concurrency = Math.max(
        1,
        Math.floor((overrides[poolName]?.allocationFraction || fraction) * this.totalConcurrency)
      );
      const pool = new Pool({
        name: poolName,
        allocation: overrides[poolName]?.allocationFraction || fraction,
        concurrency,
        timeout: overrides[poolName]?.timeout || this._defaultTimeout(poolName),
        description: this._poolDescription(poolName),
      });
      this._pools.set(poolName, pool);
    }

    // Start auto-rebalancing
    this._startRebalanceLoop();

    logger.info('[PoolManager] Initialized', {
      totalConcurrency: this.totalConcurrency,
      pools: Object.fromEntries(
        Array.from(this._pools.entries()).map(([k, v]) => [k, v.concurrency])
      ),
    });
  }

  _defaultTimeout(poolName) {
    const map = {
      HOT:        5_000,
      WARM:       15_000,
      COLD:       30_000,
      RESERVE:    60_000,
      GOVERNANCE: 10_000,
    };
    return map[poolName] || 30_000;
  }

  _poolDescription(poolName) {
    const map = {
      HOT:        'Real-time, latency-critical tasks',
      WARM:       'Standard interactive tasks',
      COLD:       'Background and batch tasks',
      RESERVE:    'Emergency overflow and failsafe',
      GOVERNANCE: 'Policy enforcement and audit tasks',
    };
    return map[poolName] || '';
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Acquire a resource slot from the named pool.
   *
   * @param {string} poolName - One of HOT | WARM | COLD | RESERVE | GOVERNANCE
   * @returns {Promise<object>} Release token: call token.release() when done
   */
  async acquire(poolName) {
    const pool = this._getPool(poolName);
    await pool.acquire();

    const token = {
      pool: poolName,
      acquiredAt: Date.now(),
      released: false,
      release: () => this.release(poolName, token),
    };

    this.emit('pool:acquired', { pool: poolName, utilization: pool.getUtilization() });
    return token;
  }

  /**
   * Release a resource slot back to the named pool.
   * @param {string} poolName
   * @param {object} [token] - Release token (optional, for tracking)
   */
  release(poolName, token = null) {
    const pool = this._getPool(poolName);
    pool.release();
    if (token && !token.released) token.released = true;
    this.emit('pool:released', { pool: poolName, utilization: pool.getUtilization() });
  }

  /**
   * Get utilization statistics for all pools or a specific pool.
   * @param {string} [poolName] - Omit for all pools
   * @returns {object}
   */
  getUtilization(poolName = null) {
    if (poolName) {
      return this._getPool(poolName).getUtilization();
    }
    const result = {};
    for (const [name, pool] of this._pools) {
      result[name] = pool.getUtilization();
    }
    return result;
  }

  /**
   * Get all pool names.
   * @returns {string[]}
   */
  getPoolNames() {
    return Array.from(this._pools.keys());
  }

  /**
   * Returns the pool object (for inspection).
   * @param {string} poolName
   * @returns {Pool}
   */
  getPool(poolName) {
    return this._getPool(poolName);
  }

  // ─── Dynamic Rebalancing ────────────────────────────────────────────────────

  /**
   * Trigger an immediate rebalance check.
   * Redistributes capacity from under-utilized pools to over-loaded ones.
   */
  rebalance() {
    const stats = this.getUtilization();
    const overloaded   = [];
    const underloaded  = [];

    for (const [name, stat] of Object.entries(stats)) {
      if (stat.utilization > 0.85 || stat.waiting > 0) overloaded.push(name);
      else if (stat.utilization < 0.3) underloaded.push(name);
    }

    if (overloaded.length === 0 || underloaded.length === 0) return;

    logger.info('[PoolManager] Rebalancing pools', { overloaded, underloaded });

    for (const overName of overloaded) {
      for (const underName of underloaded) {
        const overPool  = this._pools.get(overName);
        const underPool = this._pools.get(underName);

        // Transfer 1 concurrency unit
        if (underPool.concurrency > 1) {
          overPool.resize(overPool.concurrency + 1);
          underPool.resize(underPool.concurrency - 1);

          this.emit('pool:rebalanced', {
            from: underName, to: overName,
            fromNew: underPool.concurrency, toNew: overPool.concurrency,
          });
          logger.info('[PoolManager] Transferred slot', {
            from: underName, to: overName,
          });
          break; // One transfer per overloaded pool per cycle
        }
      }
    }
  }

  /**
   * Start the automatic rebalancing interval.
   */
  _startRebalanceLoop() {
    this._rebalanceTimer = setInterval(() => {
      try {
        this.rebalance();
      } catch (err) {
        logger.error('[PoolManager] Rebalance error', { error: err.message });
      }
    }, this.rebalanceIntervalMs);

    // Don't block process exit
    if (this._rebalanceTimer.unref) {
      this._rebalanceTimer.unref();
    }
  }

  /**
   * Stop rebalancing and clean up.
   */
  destroy() {
    if (this._rebalanceTimer) {
      clearInterval(this._rebalanceTimer);
      this._rebalanceTimer = null;
    }
    logger.info('[PoolManager] Destroyed');
  }

  // ─── Helpers ────────────────────────────────────────────────────────────────

  _getPool(poolName) {
    const pool = this._pools.get(poolName);
    if (!pool) throw new Error(`[PoolManager] Unknown pool: ${poolName}`);
    return pool;
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────
module.exports = { PoolManager, Pool, Semaphore, POOL_NAMES, FIBONACCI_ALLOCATIONS, PHI };
