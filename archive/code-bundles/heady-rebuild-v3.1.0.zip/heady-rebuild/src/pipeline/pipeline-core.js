/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const { EventEmitter } = require('events');
const logger = require('../utils/logger');
const { MonteCarloEngine } = require('../monte-carlo');
const { SelfAwareness } = require('../self-awareness');
const { DriftDetector } = require('../drift-detector');
const { PatternEngine } = require('../patterns/pattern-engine');
const { ContinuousLearning } = require('../continuous-learning');
const { HeadyConductor } = require('../orchestration/heady-conductor');
const { HeadyOrchestrator } = require('../orchestration/heady-orchestrator');
const { BeeFactory } = require('../bees/bee-factory');
const { LLMRouter } = require('../providers/llm-router');

const PHI = 1.6180339887;

// ─── Pipeline States ──────────────────────────────────────────────────────────
const PipelineState = Object.freeze({
  IDLE:      'IDLE',
  RUNNING:   'RUNNING',
  COMPLETE:  'COMPLETE',
  FAILED:    'FAILED',
  ROLLING_BACK: 'ROLLING_BACK',
});

// ─── Stage Names ──────────────────────────────────────────────────────────────
const Stages = Object.freeze({
  INTAKE:          'INTAKE',
  TRIAGE:          'TRIAGE',
  CONTEXT:         'CONTEXT',
  CLASSIFY:        'CLASSIFY',
  ROUTE:           'ROUTE',
  EXECUTE:         'EXECUTE',
  VALIDATE:        'VALIDATE',
  ASSURE:          'ASSURE',
  PATTERN_CAPTURE: 'PATTERN_CAPTURE',
  STORY_UPDATE:    'STORY_UPDATE',
  RECEIPT:         'RECEIPT',
  LEARN:           'LEARN',
});

// Stages that can run in parallel after ROUTE
const PARALLEL_GROUPS = {
  post_execute: [Stages.PATTERN_CAPTURE, Stages.STORY_UPDATE],
};

// Non-critical stages that can be skipped in emergency mode
const SKIPPABLE_STAGES = new Set([
  Stages.PATTERN_CAPTURE,
  Stages.STORY_UPDATE,
  Stages.ASSURE,
  Stages.LEARN,
]);

/**
 * Generates a UUID-like run identifier.
 * @returns {string}
 */
function generateRunId() {
  const ts = Date.now().toString(36);
  const rand = Math.random().toString(36).slice(2, 10);
  const rand2 = Math.random().toString(36).slice(2, 6);
  return `hc-run-${ts}-${rand}-${rand2}`;
}

/**
 * HCFullPipeline — The 12-stage orchestration spine of the Heady AI Platform.
 *
 * Stage order:
 *   INTAKE → TRIAGE → CONTEXT → CLASSIFY → ROUTE → EXECUTE
 *   → VALIDATE → ASSURE → PATTERN_CAPTURE/STORY_UPDATE (parallel)
 *   → RECEIPT → LEARN
 *
 * @extends EventEmitter
 */
class HCFullPipeline extends EventEmitter {
  /**
   * @param {object} options
   * @param {object} [options.conductor]        - HeadyConductor instance
   * @param {object} [options.orchestrator]     - HeadyOrchestrator instance
   * @param {object} [options.beeFactory]       - BeeFactory instance
   * @param {object} [options.llmRouter]        - LLMRouter instance
   * @param {object} [options.monteCarlo]       - MonteCarloEngine instance
   * @param {object} [options.selfAwareness]    - SelfAwareness instance
   * @param {object} [options.driftDetector]    - DriftDetector instance
   * @param {object} [options.patternEngine]    - PatternEngine instance
   * @param {object} [options.continuousLearning] - ContinuousLearning instance
   * @param {boolean} [options.fullAuto=false]  - Enable autonomous background mode
   */
  constructor(options = {}) {
    super();

    this.conductor        = options.conductor        || new HeadyConductor();
    this.orchestrator     = options.orchestrator     || new HeadyOrchestrator();
    this.beeFactory       = options.beeFactory       || new BeeFactory();
    this.llmRouter        = options.llmRouter        || new LLMRouter();
    this.monteCarlo       = options.monteCarlo       || new MonteCarloEngine();
    this.selfAwareness    = options.selfAwareness    || new SelfAwareness();
    this.driftDetector    = options.driftDetector    || new DriftDetector();
    this.patternEngine    = options.patternEngine    || new PatternEngine();
    this.continuousLearning = options.continuousLearning || new ContinuousLearning();

    this.fullAuto  = options.fullAuto || false;
    this.state     = PipelineState.IDLE;
    this.activeRun = null;
    this._stages   = this._buildStages();

    if (this.fullAuto) {
      this._startFullAutoLoop();
    }

    logger.info('[HCFullPipeline] Initialized', { fullAuto: this.fullAuto });
  }

  // ─── Stage Definitions ──────────────────────────────────────────────────────

  /**
   * Build the ordered stage registry.
   * @returns {Map<string, object>}
   */
  _buildStages() {
    const stages = new Map();

    stages.set(Stages.INTAKE, {
      name: Stages.INTAKE,
      timeout: 5_000,
      required: true,
      canSkip: false,
      handler: this._stageIntake.bind(this),
      rollbackFn: this._rollbackIntake.bind(this),
    });

    stages.set(Stages.TRIAGE, {
      name: Stages.TRIAGE,
      timeout: 8_000,
      required: true,
      canSkip: false,
      handler: this._stageTriage.bind(this),
      rollbackFn: null,
    });

    stages.set(Stages.CONTEXT, {
      name: Stages.CONTEXT,
      timeout: 15_000,
      required: true,
      canSkip: false,
      handler: this._stageContext.bind(this),
      rollbackFn: null,
    });

    stages.set(Stages.CLASSIFY, {
      name: Stages.CLASSIFY,
      timeout: 10_000,
      required: true,
      canSkip: false,
      handler: this._stageClassify.bind(this),
      rollbackFn: null,
    });

    stages.set(Stages.ROUTE, {
      name: Stages.ROUTE,
      timeout: 5_000,
      required: true,
      canSkip: false,
      handler: this._stageRoute.bind(this),
      rollbackFn: null,
    });

    stages.set(Stages.EXECUTE, {
      name: Stages.EXECUTE,
      timeout: 120_000,
      required: true,
      canSkip: false,
      handler: this._stageExecute.bind(this),
      rollbackFn: this._rollbackExecute.bind(this),
    });

    stages.set(Stages.VALIDATE, {
      name: Stages.VALIDATE,
      timeout: 20_000,
      required: true,
      canSkip: false,
      handler: this._stageValidate.bind(this),
      rollbackFn: null,
    });

    stages.set(Stages.ASSURE, {
      name: Stages.ASSURE,
      timeout: 30_000,
      required: false,
      canSkip: true,
      handler: this._stageAssure.bind(this),
      rollbackFn: null,
    });

    stages.set(Stages.PATTERN_CAPTURE, {
      name: Stages.PATTERN_CAPTURE,
      timeout: 10_000,
      required: false,
      canSkip: true,
      handler: this._stagePatternCapture.bind(this),
      rollbackFn: null,
    });

    stages.set(Stages.STORY_UPDATE, {
      name: Stages.STORY_UPDATE,
      timeout: 10_000,
      required: false,
      canSkip: true,
      handler: this._stageStoryUpdate.bind(this),
      rollbackFn: null,
    });

    stages.set(Stages.RECEIPT, {
      name: Stages.RECEIPT,
      timeout: 5_000,
      required: true,
      canSkip: false,
      handler: this._stageReceipt.bind(this),
      rollbackFn: null,
    });

    stages.set(Stages.LEARN, {
      name: Stages.LEARN,
      timeout: 20_000,
      required: false,
      canSkip: true,
      handler: this._stageLearn.bind(this),
      rollbackFn: null,
    });

    return stages;
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Execute the full 12-stage pipeline for a task.
   *
   * @param {object} task                  - The task descriptor
   * @param {string} task.id               - Task ID
   * @param {string} task.type             - Task type
   * @param {object} task.payload          - Task payload
   * @param {object} [options]
   * @param {boolean} [options.emergency]  - Skip non-critical stages
   * @param {string}  [options.priority]   - 'high' | 'normal' | 'low'
   * @param {object}  [options.meta]       - Additional metadata
   * @returns {Promise<object>} Pipeline run result
   */
  async run(task, options = {}) {
    if (this.state === PipelineState.RUNNING) {
      throw new Error('[HCFullPipeline] Pipeline already running; concurrent runs require separate instances');
    }

    const runId = generateRunId();
    const emergency = options.emergency || false;
    const priority  = options.priority  || 'normal';

    /** @type {PipelineRunState} */
    const runState = {
      runId,
      task,
      options,
      priority,
      emergency,
      startedAt: Date.now(),
      completedAt: null,
      state: PipelineState.RUNNING,
      stages: {},
      stagesCompleted: [],
      result: null,
      error: null,
      // Shared context bag passed through all stages
      context: {
        task,
        runId,
        priority,
        emergency,
        meta: options.meta || {},
        assembled: {},
        classification: null,
        route: null,
        execution: null,
        validation: null,
        assurance: null,
        patterns: null,
        story: null,
        receipt: null,
        learnings: null,
      },
    };

    this.activeRun = runState;
    this.state = PipelineState.RUNNING;
    this.emit('pipeline:start', { runId, task, priority, emergency });
    logger.info('[HCFullPipeline] Run started', { runId, taskId: task.id, priority, emergency });

    try {
      // ── Sequential stages up to ASSURE ─────────────────────────────────────
      const sequentialStages = [
        Stages.INTAKE,
        Stages.TRIAGE,
        Stages.CONTEXT,
        Stages.CLASSIFY,
        Stages.ROUTE,
        Stages.EXECUTE,
        Stages.VALIDATE,
        Stages.ASSURE,
      ];

      for (const stageName of sequentialStages) {
        if (emergency && SKIPPABLE_STAGES.has(stageName)) {
          this._recordSkip(runState, stageName, 'emergency mode');
          continue;
        }
        await this._runStageWithState(stageName, runState);
      }

      // ── Parallel: PATTERN_CAPTURE + STORY_UPDATE ────────────────────────────
      if (emergency) {
        this._recordSkip(runState, Stages.PATTERN_CAPTURE, 'emergency mode');
        this._recordSkip(runState, Stages.STORY_UPDATE, 'emergency mode');
      } else {
        await Promise.all([
          this._runStageWithState(Stages.PATTERN_CAPTURE, runState),
          this._runStageWithState(Stages.STORY_UPDATE, runState),
        ]);
      }

      // ── Sequential: RECEIPT → LEARN ─────────────────────────────────────────
      await this._runStageWithState(Stages.RECEIPT, runState);

      if (emergency) {
        this._recordSkip(runState, Stages.LEARN, 'emergency mode');
      } else {
        await this._runStageWithState(Stages.LEARN, runState);
      }

      // ── Finalize ─────────────────────────────────────────────────────────────
      runState.completedAt = Date.now();
      runState.state = PipelineState.COMPLETE;
      runState.result = runState.context.receipt || runState.context.execution;
      this.state = PipelineState.IDLE;
      this.activeRun = null;

      this.emit('pipeline:complete', {
        runId,
        duration: runState.completedAt - runState.startedAt,
        result: runState.result,
      });
      logger.info('[HCFullPipeline] Run complete', {
        runId,
        duration: runState.completedAt - runState.startedAt,
      });

      return {
        runId,
        state: PipelineState.COMPLETE,
        duration: runState.completedAt - runState.startedAt,
        stagesCompleted: runState.stagesCompleted,
        result: runState.result,
        context: runState.context,
      };

    } catch (err) {
      runState.error = err;
      runState.state = PipelineState.FAILED;
      this.state = PipelineState.ROLLING_BACK;
      logger.error('[HCFullPipeline] Run failed, initiating rollback', {
        runId, error: err.message, stage: err.stage || 'unknown',
      });
      this.emit('pipeline:failed', { runId, error: err });

      await this._rollback(runState);

      this.state = PipelineState.IDLE;
      this.activeRun = null;

      throw err;
    }
  }

  /**
   * Execute a single named stage against a provided context object.
   * Useful for targeted re-runs or testing individual stages.
   *
   * @param {string} stageName
   * @param {object} context
   * @returns {Promise<object>} Updated context
   */
  async runStage(stageName, context) {
    const stageDef = this._stages.get(stageName);
    if (!stageDef) throw new Error(`[HCFullPipeline] Unknown stage: ${stageName}`);

    const runState = {
      runId: context.runId || generateRunId(),
      task: context.task,
      options: {},
      emergency: false,
      stages: {},
      stagesCompleted: [],
      context,
    };

    await this._runStageWithState(stageName, runState);
    return runState.context;
  }

  // ─── Internal Stage Runner ───────────────────────────────────────────────────

  /**
   * Run a single stage, record timing, emit events, handle timeout + errors.
   */
  async _runStageWithState(stageName, runState) {
    const stageDef = this._stages.get(stageName);
    if (!stageDef) throw new Error(`[HCFullPipeline] Unknown stage: ${stageName}`);

    const stageRecord = {
      name: stageName,
      startedAt: Date.now(),
      completedAt: null,
      duration: null,
      skipped: false,
      error: null,
    };
    runState.stages[stageName] = stageRecord;

    this.emit('stage:start', { runId: runState.runId, stage: stageName });
    logger.debug('[HCFullPipeline] Stage start', { runId: runState.runId, stage: stageName });

    try {
      await this._withTimeout(
        stageDef.handler(runState.context),
        stageDef.timeout,
        stageName
      );

      stageRecord.completedAt = Date.now();
      stageRecord.duration = stageRecord.completedAt - stageRecord.startedAt;
      runState.stagesCompleted.push(stageName);

      this.emit('stage:complete', {
        runId: runState.runId,
        stage: stageName,
        duration: stageRecord.duration,
      });
      logger.debug('[HCFullPipeline] Stage complete', {
        runId: runState.runId,
        stage: stageName,
        duration: stageRecord.duration,
      });

    } catch (err) {
      stageRecord.completedAt = Date.now();
      stageRecord.duration = stageRecord.completedAt - stageRecord.startedAt;
      stageRecord.error = err.message;

      if (!stageDef.required && stageDef.canSkip) {
        logger.warn('[HCFullPipeline] Optional stage failed, continuing', {
          runId: runState.runId, stage: stageName, error: err.message,
        });
        this.emit('stage:skipped', { runId: runState.runId, stage: stageName, reason: err.message });
      } else {
        err.stage = stageName;
        this.emit('stage:failed', { runId: runState.runId, stage: stageName, error: err });
        throw err;
      }
    }
  }

  /**
   * Wrap a promise with a hard timeout.
   */
  _withTimeout(promise, ms, label) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(Object.assign(new Error(`Stage timeout: ${label} exceeded ${ms}ms`), { stage: label, isTimeout: true }));
      }, ms);
      promise.then(
        (v) => { clearTimeout(timer); resolve(v); },
        (e) => { clearTimeout(timer); reject(e); }
      );
    });
  }

  _recordSkip(runState, stageName, reason) {
    runState.stages[stageName] = {
      name: stageName,
      skipped: true,
      reason,
      startedAt: Date.now(),
      completedAt: Date.now(),
      duration: 0,
      error: null,
    };
    this.emit('stage:skipped', { runId: runState.runId, stage: stageName, reason });
    logger.debug('[HCFullPipeline] Stage skipped', { runId: runState.runId, stage: stageName, reason });
  }

  // ─── Rollback ────────────────────────────────────────────────────────────────

  async _rollback(runState) {
    this.emit('pipeline:rollback:start', { runId: runState.runId });
    logger.warn('[HCFullPipeline] Rollback started', { runId: runState.runId });

    // Reverse the completed stages
    const toRollback = [...runState.stagesCompleted].reverse();

    for (const stageName of toRollback) {
      const stageDef = this._stages.get(stageName);
      if (stageDef && stageDef.rollbackFn) {
        try {
          await stageDef.rollbackFn(runState.context);
          logger.debug('[HCFullPipeline] Rolled back stage', { runId: runState.runId, stage: stageName });
        } catch (rbErr) {
          logger.error('[HCFullPipeline] Rollback failed for stage', {
            runId: runState.runId, stage: stageName, error: rbErr.message,
          });
        }
      }
    }

    this.emit('pipeline:rollback:complete', { runId: runState.runId });
    logger.info('[HCFullPipeline] Rollback complete', { runId: runState.runId });
  }

  // ─── Stage Handlers ──────────────────────────────────────────────────────────

  /**
   * INTAKE: Validate and normalize raw task input.
   */
  async _stageIntake(ctx) {
    const { task } = ctx;

    if (!task) throw new Error('INTAKE: task is required');
    if (!task.id) task.id = `task-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    if (!task.type) throw new Error('INTAKE: task.type is required');
    if (!task.payload) task.payload = {};

    ctx.assembled.intakeAt = Date.now();
    ctx.assembled.taskNormalized = {
      id: task.id,
      type: task.type,
      payload: task.payload,
      source: task.source || 'unknown',
      version: task.version || '1.0',
    };

    logger.debug('[HCFullPipeline:INTAKE] Task normalized', { taskId: task.id });
  }

  async _rollbackIntake(ctx) {
    // Nothing persisted during intake
    logger.debug('[HCFullPipeline:INTAKE] Rollback (no-op)');
  }

  /**
   * TRIAGE: Assess urgency, priority, resource requirements.
   */
  async _stageTriage(ctx) {
    const { task, priority, emergency } = ctx;

    // Run Monte Carlo to estimate resource cost
    const costEstimate = await this.monteCarlo.estimateCost({
      taskType: task.type,
      payloadSize: JSON.stringify(task.payload).length,
    }).catch(() => ({ mean: 100, p95: 200 }));

    ctx.assembled.triage = {
      urgency: emergency ? 'critical' : priority,
      estimatedCost: costEstimate,
      requiresLLM: task.type !== 'cache_lookup',
      resourceClass: costEstimate.p95 > 500 ? 'heavy' : costEstimate.p95 > 100 ? 'medium' : 'light',
      triageAt: Date.now(),
    };

    logger.debug('[HCFullPipeline:TRIAGE] Triaged', { taskId: task.id, triage: ctx.assembled.triage });
  }

  /**
   * CONTEXT: Assemble full context from memory, patterns, user state.
   */
  async _stageContext(ctx) {
    const { task } = ctx;

    // Self-awareness snapshot for drift baseline
    const awarenessSnapshot = await this.selfAwareness.getSnapshot().catch(() => ({}));

    // Drift check
    const driftReport = await this.driftDetector.check({
      taskType: task.type,
      timestamp: Date.now(),
    }).catch(() => ({ driftScore: 0, status: 'ok' }));

    if (driftReport.driftScore > 0.7) {
      logger.warn('[HCFullPipeline:CONTEXT] High drift detected', { driftScore: driftReport.driftScore });
      this.emit('drift:warning', { runId: ctx.runId, driftReport });
    }

    ctx.assembled.context = {
      awarenessSnapshot,
      driftReport,
      sessionId: task.payload.sessionId || null,
      userId: task.payload.userId || null,
      contextAt: Date.now(),
    };

    logger.debug('[HCFullPipeline:CONTEXT] Context assembled', { taskId: task.id });
  }

  /**
   * CLASSIFY: Classify intent, extract entities, determine execution class.
   */
  async _stageClassify(ctx) {
    const { task } = ctx;

    const classification = {
      intent: task.type,
      confidence: 1.0,
      entities: [],
      executionClass: ctx.assembled.triage.resourceClass,
      needsReasoning: true,
      classifiedAt: Date.now(),
    };

    // Simple rule-based entity extraction from payload keys
    classification.entities = Object.keys(task.payload).map((k) => ({
      key: k,
      value: task.payload[k],
      type: typeof task.payload[k],
    }));

    ctx.classification = classification;
    logger.debug('[HCFullPipeline:CLASSIFY] Classified', { taskId: task.id, intent: classification.intent });
  }

  /**
   * ROUTE: Select execution path: which bees/conductor/orchestrator to invoke.
   */
  async _stageRoute(ctx) {
    const { task, classification } = ctx;

    // Route via conductor
    const route = await this.conductor.route({
      task,
      classification,
      triage: ctx.assembled.triage,
    }).catch(() => ({
      handler: 'orchestrator',
      beeType: null,
      model: null,
    }));

    ctx.route = {
      ...route,
      routedAt: Date.now(),
    };

    logger.debug('[HCFullPipeline:ROUTE] Routed', { taskId: task.id, handler: route.handler });
  }

  /**
   * EXECUTE: Dispatch to the appropriate execution handler.
   */
  async _stageExecute(ctx) {
    const { task, route } = ctx;

    let result;

    if (route.handler === 'bee' && route.beeType) {
      const bee = await this.beeFactory.spawn(route.beeType, { task });
      result = await bee.execute(task);
    } else if (route.handler === 'orchestrator') {
      result = await this.orchestrator.execute(task, ctx);
    } else {
      result = await this.conductor.execute(task, ctx);
    }

    ctx.execution = {
      result,
      handler: route.handler,
      executedAt: Date.now(),
    };

    logger.debug('[HCFullPipeline:EXECUTE] Executed', { taskId: task.id, handler: route.handler });
  }

  async _rollbackExecute(ctx) {
    if (ctx.execution && ctx.route) {
      logger.warn('[HCFullPipeline:EXECUTE] Rollback: attempting to undo execution', {
        taskId: ctx.task.id,
        handler: ctx.route.handler,
      });
      // Attempt conductor-level undo if supported
      try {
        await this.conductor.undo(ctx.task, ctx.execution);
      } catch {
        // Non-fatal
      }
    }
  }

  /**
   * VALIDATE: Validate the execution result for correctness and safety.
   */
  async _stageValidate(ctx) {
    const { execution, task } = ctx;

    if (!execution || !execution.result) {
      throw new Error('VALIDATE: no execution result to validate');
    }

    const validation = {
      passed: true,
      checks: [],
      validatedAt: Date.now(),
    };

    // Check 1: result is non-null
    validation.checks.push({
      name: 'non_null',
      passed: execution.result !== null && execution.result !== undefined,
    });

    // Check 2: Self-awareness coherence check
    const coherence = await this.selfAwareness.checkCoherence(execution.result).catch(() => ({ ok: true }));
    validation.checks.push({ name: 'coherence', passed: coherence.ok !== false });

    // Check 3: Drift post-execution
    const postDrift = await this.driftDetector.check({
      taskType: task.type,
      result: execution.result,
      phase: 'post_execute',
    }).catch(() => ({ driftScore: 0 }));
    validation.checks.push({ name: 'drift', passed: postDrift.driftScore < 0.8 });

    validation.passed = validation.checks.every((c) => c.passed);

    if (!validation.passed) {
      const failed = validation.checks.filter((c) => !c.passed).map((c) => c.name);
      throw new Error(`VALIDATE: failed checks: ${failed.join(', ')}`);
    }

    ctx.validation = validation;
    logger.debug('[HCFullPipeline:VALIDATE] Validation passed', { taskId: task.id });
  }

  /**
   * ASSURE: Quality assurance and deployment certification gate.
   */
  async _stageAssure(ctx) {
    const { execution, task } = ctx;

    // HeadyAssure certification
    const assurance = {
      certified: true,
      score: Math.min(1, (execution.result ? 0.9 : 0.5) * PHI / PHI),
      assuredAt: Date.now(),
      notes: [],
    };

    // Monte Carlo confidence
    const confidence = await this.monteCarlo.assessConfidence(execution.result).catch(() => ({ score: 0.9 }));
    assurance.score = confidence.score;
    assurance.certified = confidence.score >= 0.6;

    if (!assurance.certified) {
      assurance.notes.push(`Confidence below threshold: ${confidence.score.toFixed(3)}`);
    }

    ctx.assurance = assurance;
    logger.debug('[HCFullPipeline:ASSURE] Assurance complete', {
      taskId: task.id, certified: assurance.certified, score: assurance.score,
    });
  }

  /**
   * PATTERN_CAPTURE: Record patterns from this execution for future learning.
   */
  async _stagePatternCapture(ctx) {
    const { task, execution, validation } = ctx;

    const captured = await this.patternEngine.capture({
      taskType: task.type,
      classification: ctx.classification,
      route: ctx.route,
      executionDuration: execution ? (execution.executedAt - (ctx.assembled.triage?.triageAt || 0)) : 0,
      outcome: validation?.passed ? 'success' : 'failure',
      result: execution?.result,
    }).catch((err) => {
      logger.warn('[HCFullPipeline:PATTERN_CAPTURE] Non-fatal capture error', { error: err.message });
      return null;
    });

    ctx.patterns = { captured, capturedAt: Date.now() };
    logger.debug('[HCFullPipeline:PATTERN_CAPTURE] Patterns captured', { taskId: task.id });
  }

  /**
   * STORY_UPDATE: Update the running session story / narrative state.
   */
  async _stageStoryUpdate(ctx) {
    const { task, execution } = ctx;

    const storyEntry = {
      taskId: task.id,
      taskType: task.type,
      summary: `Executed ${task.type} with result: ${execution?.result ? 'success' : 'empty'}`,
      timestamp: Date.now(),
      runId: ctx.runId,
    };

    // Self-awareness stores the narrative
    await this.selfAwareness.appendStory(storyEntry).catch((err) => {
      logger.warn('[HCFullPipeline:STORY_UPDATE] Non-fatal story error', { error: err.message });
    });

    ctx.story = storyEntry;
    logger.debug('[HCFullPipeline:STORY_UPDATE] Story updated', { taskId: task.id });
  }

  /**
   * RECEIPT: Compose final receipt / structured response.
   */
  async _stageReceipt(ctx) {
    const { task, execution } = ctx;

    ctx.receipt = {
      runId: ctx.runId,
      taskId: task.id,
      taskType: task.type,
      status: 'success',
      result: execution?.result || null,
      duration: Date.now() - ctx.assembled.intakeAt,
      stagesCompleted: Object.keys(ctx).filter((k) => ctx[k]?.capturedAt || ctx[k]?.validatedAt),
      assurance: ctx.assurance || null,
      issuedAt: Date.now(),
    };

    logger.debug('[HCFullPipeline:RECEIPT] Receipt issued', { runId: ctx.runId, taskId: task.id });
  }

  /**
   * LEARN: Feed outcomes back into continuous learning.
   */
  async _stageLearn(ctx) {
    const { task } = ctx;

    await this.continuousLearning.record({
      runId: ctx.runId,
      taskId: task.id,
      taskType: task.type,
      classification: ctx.classification,
      route: ctx.route,
      outcome: ctx.validation?.passed ? 'success' : 'failure',
      assuranceScore: ctx.assurance?.score || null,
      patterns: ctx.patterns?.captured || null,
      duration: ctx.receipt?.duration || null,
    }).catch((err) => {
      logger.warn('[HCFullPipeline:LEARN] Non-fatal learning error', { error: err.message });
    });

    ctx.learnings = { recorded: true, learnedAt: Date.now() };
    logger.debug('[HCFullPipeline:LEARN] Learning recorded', { taskId: task.id });
  }

  // ─── fullAuto Mode ──────────────────────────────────────────────────────────

  /**
   * Start continuous beneficial background processing loop.
   * Uses PHI-scaled intervals to avoid thundering herd.
   */
  _startFullAutoLoop() {
    logger.info('[HCFullPipeline] fullAuto mode enabled');
    const BASE_INTERVAL_MS = 30_000; // 30 seconds base
    let iteration = 0;

    const loop = async () => {
      if (this.state !== PipelineState.RUNNING) {
        try {
          await this._fullAutoTick(iteration);
        } catch (err) {
          logger.error('[HCFullPipeline:fullAuto] Tick error', { error: err.message });
        }
      }
      iteration++;
      // PHI-scaled backoff to avoid over-running: oscillate around base
      const jitter = (Math.sin(iteration / PHI) + 1) * 5_000; // 0–10 s jitter
      const nextInterval = BASE_INTERVAL_MS + jitter;
      this._fullAutoTimer = setTimeout(loop, nextInterval);
    };

    this._fullAutoTimer = setTimeout(loop, BASE_INTERVAL_MS);
  }

  /**
   * One iteration of the fullAuto background loop.
   */
  async _fullAutoTick(iteration) {
    logger.debug('[HCFullPipeline:fullAuto] Background tick', { iteration });

    // Drift monitoring
    const drift = await this.driftDetector.check({ phase: 'background', iteration }).catch(() => null);
    if (drift && drift.driftScore > 0.5) {
      this.emit('drift:background', { iteration, driftScore: drift.driftScore });
    }

    // Pattern consolidation every PHI^n iterations
    if (iteration % Math.round(PHI * PHI) === 0) {
      await this.patternEngine.consolidate().catch(() => null);
    }

    // Continuous learning housekeeping
    await this.continuousLearning.housekeep().catch(() => null);
  }

  /**
   * Stop the fullAuto background loop.
   */
  stopFullAuto() {
    if (this._fullAutoTimer) {
      clearTimeout(this._fullAutoTimer);
      this._fullAutoTimer = null;
      logger.info('[HCFullPipeline] fullAuto mode stopped');
    }
  }

  // ─── Status / Introspection ──────────────────────────────────────────────────

  /**
   * @returns {object} Current pipeline state snapshot
   */
  getStatus() {
    return {
      state: this.state,
      fullAuto: this.fullAuto,
      activeRunId: this.activeRun?.runId || null,
      stagesAvailable: Array.from(this._stages.keys()),
    };
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────
module.exports = { HCFullPipeline, Stages, PipelineState, PHI };
