/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

/**
 * @fileoverview LIFO (last-in, first-out) graceful shutdown manager for the
 * Heady™ AI Platform. Collects shutdown handlers and executes them in reverse
 * registration order when a termination signal is received.
 * @module src/lifecycle/graceful-shutdown
 */

const { createLogger } = require('../utils/logger');

const logger = createLogger('lifecycle:shutdown');

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Maximum milliseconds to wait for all handlers to complete. */
const SHUTDOWN_TIMEOUT_MS = 30000;

/** Signals that trigger graceful shutdown. */
const HANDLED_SIGNALS = ['SIGTERM', 'SIGINT'];

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------

/**
 * @typedef {Object} ShutdownHandler
 * @property {string} name - Display name for logging
 * @property {Function} fn - Async function to call during shutdown
 * @property {number} registeredAt - Epoch ms when handler was registered
 */

/** @type {ShutdownHandler[]} */
const _handlers = [];

/** Whether a shutdown is currently in progress. */
let _shutdownInProgress = false;

/** Whether signal listeners have been attached. */
let _listenersAttached = false;

// ---------------------------------------------------------------------------
// Registration
// ---------------------------------------------------------------------------

/**
 * Registers a shutdown handler. Handlers are called in LIFO order.
 * @param {string} name - A descriptive name for logging (e.g. 'postgres-pool')
 * @param {Function} fn - An async (or sync) cleanup function. Receives the signal name.
 * @returns {void}
 * @throws {TypeError} If name is not a string or fn is not a function
 */
function registerShutdownHandler(name, fn) {
  if (typeof name !== 'string' || !name.trim()) {
    throw new TypeError('Shutdown handler name must be a non-empty string');
  }
  if (typeof fn !== 'function') {
    throw new TypeError(`Shutdown handler "${name}" must be a function`);
  }
  _handlers.push({ name, fn, registeredAt: Date.now() });
  logger.debug(`Registered shutdown handler: ${name}`, { total: _handlers.length });
}

/**
 * Removes a previously registered handler by name.
 * @param {string} name
 * @returns {boolean} True if a handler was removed
 */
function unregisterShutdownHandler(name) {
  const idx = _handlers.findLastIndex((h) => h.name === name);
  if (idx === -1) return false;
  _handlers.splice(idx, 1);
  logger.debug(`Unregistered shutdown handler: ${name}`);
  return true;
}

// ---------------------------------------------------------------------------
// Core shutdown logic
// ---------------------------------------------------------------------------

/**
 * Executes all registered handlers in LIFO order with a global timeout.
 * @param {string} signal - The signal or reason triggering shutdown
 * @returns {Promise<void>}
 */
async function triggerShutdown(signal) {
  if (_shutdownInProgress) {
    logger.warn(`Shutdown already in progress, ignoring signal: ${signal}`);
    return;
  }
  _shutdownInProgress = true;

  logger.logSystem('shutdown:begin', {
    signal,
    handlers: _handlers.length,
    timeoutMs: SHUTDOWN_TIMEOUT_MS,
  });

  // Execute in LIFO order
  const ordered = [..._handlers].reverse();

  // Race all handlers against the global timeout
  const shutdownPromise = (async () => {
    for (const { name, fn } of ordered) {
      const start = Date.now();
      try {
        logger.info(`Running shutdown handler: ${name}`);
        await Promise.resolve(fn(signal));
        logger.info(`Shutdown handler completed: ${name}`, { durationMs: Date.now() - start });
      } catch (err) {
        logger.error(`Shutdown handler failed: ${name}`, { err, durationMs: Date.now() - start });
        // Continue with remaining handlers even if one fails
      }
    }
  })();

  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error('Graceful shutdown timed out')), SHUTDOWN_TIMEOUT_MS)
  );

  try {
    await Promise.race([shutdownPromise, timeoutPromise]);
    logger.logSystem('shutdown:complete', { signal });
  } catch (err) {
    logger.fatal('Graceful shutdown timeout — forcing exit', { err, signal });
  } finally {
    process.exit(signal === 'SIGINT' ? 130 : 0);
  }
}

// ---------------------------------------------------------------------------
// Signal / error listeners
// ---------------------------------------------------------------------------

/**
 * Attaches process-level signal and error handlers.
 * Safe to call multiple times — handlers are only attached once.
 * @returns {void}
 */
function attachProcessHandlers() {
  if (_listenersAttached) return;
  _listenersAttached = true;

  for (const sig of HANDLED_SIGNALS) {
    process.on(sig, () => {
      logger.system(`Received signal: ${sig}`);
      triggerShutdown(sig).catch((err) => {
        logger.fatal('Fatal error during shutdown', { err });
        process.exit(1);
      });
    });
  }

  process.on('uncaughtException', (err, origin) => {
    logger.fatal('Uncaught exception — initiating emergency shutdown', { err, origin });
    triggerShutdown('uncaughtException').catch(() => process.exit(1));
  });

  process.on('unhandledRejection', (reason, promise) => {
    logger.error('Unhandled promise rejection', {
      reason: reason instanceof Error ? { message: reason.message, stack: reason.stack } : reason,
      promise: String(promise),
    });
    // In Node 20+ unhandledRejection crashes by default; we log and let Node handle it
  });

  logger.debug('Process signal/error handlers attached');
}

// ---------------------------------------------------------------------------
// Status helpers
// ---------------------------------------------------------------------------

/**
 * Returns the names of all registered handlers in registration order.
 * @returns {string[]}
 */
function getRegisteredHandlers() {
  return _handlers.map((h) => h.name);
}

/**
 * Returns whether a shutdown is currently in progress.
 * @returns {boolean}
 */
function isShuttingDown() {
  return _shutdownInProgress;
}

/**
 * Resets internal state (for testing only).
 * @returns {void}
 */
function _resetForTesting() {
  _handlers.length = 0;
  _shutdownInProgress = false;
  // Do NOT reset _listenersAttached as we can't remove Node process listeners
}

module.exports = {
  registerShutdownHandler,
  unregisterShutdownHandler,
  triggerShutdown,
  attachProcessHandlers,
  getRegisteredHandlers,
  isShuttingDown,
  _resetForTesting,
  SHUTDOWN_TIMEOUT_MS,
};
