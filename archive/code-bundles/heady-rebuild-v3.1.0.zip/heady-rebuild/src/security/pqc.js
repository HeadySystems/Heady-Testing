/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

/**
 * Post-Quantum Cryptography (PQC) module for the Heady AI Platform.
 *
 * Production intent:
 *   - sign / verify:      CRYSTALS-Dilithium3 (NIST PQC standard)
 *   - encrypt / decrypt:  AES-256-GCM (quantum-resistant at 256-bit key)
 *   - hashQuantumSafe:    SHA3-256 equivalent (SHA-512 approximation)
 *
 * Current implementation:
 *   The Dilithium3 stub uses HMAC-SHA512 for sign/verify because the
 *   `crystals-dilithium` npm package requires native bindings that may not be
 *   available in all environments. Drop in the real implementation by replacing
 *   the _dilithiumSign / _dilithiumVerify methods when the native module is
 *   available.
 *
 *   AES-256-GCM and SHA-512 are provided by Node.js core `crypto` module and
 *   are production-ready as-is.
 */

const crypto = require('crypto');

const ALG_SYMMETRIC  = 'aes-256-gcm';
const ALG_HASH       = 'sha512';         // Used as SHA3-256 approximation
const ALG_HMAC       = 'sha512';         // Used for Dilithium stub
const GCM_IV_LENGTH  = 12;              // 96-bit IV for AES-GCM
const GCM_TAG_LENGTH = 16;              // 128-bit auth tag
const KEY_LEN_BYTES  = 32;              // 256 bits

/**
 * Encode binary buffer to URL-safe base64.
 * @param {Buffer} buf
 * @returns {string}
 */
function b64url(buf) {
  return buf.toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

/**
 * Decode URL-safe base64 to Buffer.
 * @param {string} str
 * @returns {Buffer}
 */
function fromB64url(str) {
  // Re-pad
  const padded = str.replace(/-/g, '+').replace(/_/g, '/');
  const rem = padded.length % 4;
  return Buffer.from(rem === 0 ? padded : padded + '==='.slice(rem - 1), 'base64');
}

/**
 * Serialize data to a canonical Buffer (JSON for objects, UTF-8 for strings).
 * @param {*} data
 * @returns {Buffer}
 */
function toBuffer(data) {
  if (Buffer.isBuffer(data)) return data;
  if (typeof data === 'string') return Buffer.from(data, 'utf8');
  return Buffer.from(JSON.stringify(data), 'utf8');
}

/**
 * Derive a 32-byte key from a secret using HKDF-SHA512.
 * @param {string|Buffer} secret
 * @param {string} [info]
 * @returns {Buffer}
 */
function deriveKey(secret, info = 'heady-pqc-v1') {
  const secretBuf = toBuffer(secret);

  // HKDF with Node 15+ built-in
  if (crypto.hkdfSync) {
    return Buffer.from(
      crypto.hkdfSync(ALG_HASH, secretBuf, Buffer.alloc(0), Buffer.from(info), KEY_LEN_BYTES)
    );
  }

  // Fallback: PBKDF2
  return crypto.pbkdf2Sync(secretBuf, info, 100_000, KEY_LEN_BYTES, ALG_HASH);
}

// ─── Internal Dilithium3 stub implementations ────────────────────────────────

/**
 * CRYSTALS-Dilithium3 signing stub.
 * Computes HMAC-SHA512(key, data) as a stand-in until the native module
 * is available. The interface is API-compatible with the real Dilithium3.
 *
 * Replace this function body with:
 *   const dilithium = require('crystals-dilithium');
 *   return dilithium.sign(data, key.secretKey);
 *
 * @param {Buffer} data
 * @param {object} key  - { secretKey: Buffer }
 * @returns {Buffer} Signature
 */
function _dilithiumSign(data, key) {
  const hmac = crypto.createHmac(ALG_HMAC, key.secretKey || key);
  hmac.update(data);
  return hmac.digest();
}

/**
 * CRYSTALS-Dilithium3 verification stub.
 * Uses constant-time HMAC comparison.
 *
 * @param {Buffer} data
 * @param {Buffer} signature
 * @param {object} key  - { publicKey: Buffer }
 * @returns {boolean}
 */
function _dilithiumVerify(data, signature, key) {
  try {
    const expected = _dilithiumSign(data, { secretKey: key.publicKey || key });
    if (expected.length !== signature.length) return false;
    return crypto.timingSafeEqual(expected, signature);
  } catch {
    return false;
  }
}

// ─── headyPQC ─────────────────────────────────────────────────────────────────

/**
 * headyPQC — Post-Quantum Cryptography object.
 *
 * All methods are synchronous-capable or return Promises for future
 * async native-module integration.
 */
const headyPQC = Object.freeze({

  /**
   * Sign data using CRYSTALS-Dilithium3 (stub: HMAC-SHA512).
   *
   * @param {*} data            - Data to sign (string, object, or Buffer)
   * @param {object|string} key - Signing key. Use key from generateKeyPair().
   * @returns {string} URL-safe base64 signature
   */
  sign(data, key) {
    const buf = toBuffer(data);
    const sig = _dilithiumSign(buf, typeof key === 'string' ? { secretKey: Buffer.from(key, 'base64') } : key);
    return b64url(sig);
  },

  /**
   * Verify a signature against data.
   *
   * @param {*}             data       - Original data
   * @param {string}        signature  - URL-safe base64 signature from sign()
   * @param {object|string} key        - Verification key (publicKey from generateKeyPair())
   * @returns {boolean}
   */
  verify(data, signature, key) {
    try {
      const buf = toBuffer(data);
      const sigBuf = fromB64url(signature);
      const keyObj = typeof key === 'string'
        ? { publicKey: Buffer.from(key, 'base64') }
        : key;
      return _dilithiumVerify(buf, sigBuf, keyObj);
    } catch {
      return false;
    }
  },

  /**
   * Generate a Dilithium3-compatible signing key pair.
   * Stub: generates two cryptographically-random 64-byte values.
   *
   * Replace with:
   *   const dilithium = require('crystals-dilithium');
   *   return dilithium.keyPair();
   *
   * @returns {{ publicKey: string, secretKey: string }} Base64-encoded keys
   */
  generateKeyPair() {
    const secretKey = crypto.randomBytes(64);
    const publicKey = crypto.createHash(ALG_HASH).update(secretKey).digest();
    return {
      publicKey: publicKey.toString('base64'),
      secretKey: secretKey.toString('base64'),
      algorithm: 'Dilithium3-stub',
      createdAt: new Date().toISOString(),
    };
  },

  /**
   * Encrypt data with AES-256-GCM.
   *
   * @param {*}             data - Data to encrypt
   * @param {string|Buffer} key  - 32-byte key or a passphrase (auto-derived)
   * @returns {string} Serialized ciphertext: "iv:authTag:ciphertext" in base64url
   */
  encrypt(data, key) {
    const plaintext = toBuffer(data);
    const derivedKey = Buffer.isBuffer(key) && key.length === KEY_LEN_BYTES
      ? key
      : deriveKey(key, 'heady-pqc-encrypt');

    const iv     = crypto.randomBytes(GCM_IV_LENGTH);
    const cipher = crypto.createCipheriv(ALG_SYMMETRIC, derivedKey, iv, {
      authTagLength: GCM_TAG_LENGTH,
    });

    const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
    const authTag   = cipher.getAuthTag();

    // Pack: iv (12) + authTag (16) + ciphertext
    const packed = Buffer.concat([iv, authTag, encrypted]);
    return b64url(packed);
  },

  /**
   * Decrypt AES-256-GCM ciphertext.
   *
   * @param {string}        ciphertext - Output from encrypt()
   * @param {string|Buffer} key        - Same key used for encryption
   * @returns {Buffer} Decrypted plaintext
   * @throws {Error} On authentication failure or bad key
   */
  decrypt(ciphertext, key) {
    const derivedKey = Buffer.isBuffer(key) && key.length === KEY_LEN_BYTES
      ? key
      : deriveKey(key, 'heady-pqc-encrypt');

    const packed = fromB64url(ciphertext);
    const iv        = packed.slice(0, GCM_IV_LENGTH);
    const authTag   = packed.slice(GCM_IV_LENGTH, GCM_IV_LENGTH + GCM_TAG_LENGTH);
    const encrypted = packed.slice(GCM_IV_LENGTH + GCM_TAG_LENGTH);

    const decipher = crypto.createDecipheriv(ALG_SYMMETRIC, derivedKey, iv, {
      authTagLength: GCM_TAG_LENGTH,
    });
    decipher.setAuthTag(authTag);

    return Buffer.concat([decipher.update(encrypted), decipher.final()]);
  },

  /**
   * Quantum-safe hash using SHA-512 (approximation of SHA3-256 for environments
   * without sha3 support). If sha3-256 is available via OpenSSL, use it instead.
   *
   * @param {*} data
   * @returns {string} Hex digest
   */
  hashQuantumSafe(data) {
    const buf = toBuffer(data);
    // Prefer SHA3-256 if OpenSSL supports it
    const hashes = crypto.getHashes();
    if (hashes.includes('sha3-256')) {
      return crypto.createHash('sha3-256').update(buf).digest('hex');
    }
    // Fallback: SHA-512 (256-bit collision resistance, quantum-safe for pre-image)
    return crypto.createHash(ALG_HASH).update(buf).digest('hex');
  },

  /**
   * Derive a symmetric key from a passphrase using HKDF-SHA512.
   * Useful for generating deterministic session keys.
   *
   * @param {string|Buffer} passphrase
   * @param {string}        [salt]
   * @returns {Buffer} 32-byte key
   */
  deriveKey(passphrase, salt = 'heady-pqc-v1') {
    return deriveKey(passphrase, salt);
  },

  /**
   * Generate a cryptographically random nonce.
   * @param {number} [bytes=32]
   * @returns {string} Hex-encoded nonce
   */
  randomNonce(bytes = 32) {
    return crypto.randomBytes(bytes).toString('hex');
  },
});

// ─── Exports ──────────────────────────────────────────────────────────────────
module.exports = { headyPQC, deriveKey, b64url, fromB64url, toBuffer };
