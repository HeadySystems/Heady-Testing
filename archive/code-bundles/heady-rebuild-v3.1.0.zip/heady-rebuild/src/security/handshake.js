/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');
const logger = require('../utils/logger');
const { headyPQC } = require('./pqc');

const PHI = 1.6180339887;

// ─── Handshake state machine ──────────────────────────────────────────────────
const HandshakeState = Object.freeze({
  IDLE:       'IDLE',
  INITIATED:  'INITIATED',
  CHALLENGED: 'CHALLENGED',
  RESPONDED:  'RESPONDED',
  VERIFIED:   'VERIFIED',
  FAILED:     'FAILED',
  EXPIRED:    'EXPIRED',
});

// Challenge / session TTL
const CHALLENGE_TTL_MS  = 30_000;  // 30 seconds
const SESSION_TTL_MS    = 3_600_000; // 1 hour

/**
 * Generate a cryptographically random nonce as hex.
 * @param {number} [bytes=32]
 * @returns {string}
 */
function randomNonce(bytes = 32) {
  return crypto.randomBytes(bytes).toString('hex');
}

/**
 * Derive a session key from two nonces using HKDF.
 * @param {string} nonceA
 * @param {string} nonceB
 * @param {string} [peerId]
 * @returns {Buffer} 32-byte session key
 */
function deriveSessionKey(nonceA, nonceB, peerId = '') {
  const material = `${nonceA}:${nonceB}:${peerId}`;
  return headyPQC.deriveKey(material, 'heady-handshake-session-v1');
}

/**
 * Handshake — Nonce-based challenge-response authentication protocol.
 *
 * Protocol:
 *   1. Initiator calls initiate(peerId)
 *      → generates initiator nonce, state = INITIATED
 *      → returns { handshakeId, challenge: { initiatorNonce, timestamp } }
 *
 *   2. Responder calls respond(challenge)
 *      → generates responder nonce
 *      → signs (initiatorNonce + responderNonce) with own key
 *      → returns { handshakeId, response: { responderNonce, signature } }
 *
 *   3. Initiator calls verify(response)
 *      → verifies signature
 *      → derives shared session key from both nonces
 *      → state = VERIFIED
 *      → returns { sessionKey, sessionId }
 *
 * @extends EventEmitter
 */
class Handshake extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {object} [options.keyPair]        - { publicKey, secretKey } for signing
   * @param {number} [options.challengeTtlMs] - Challenge TTL in ms
   * @param {number} [options.sessionTtlMs]   - Session TTL in ms
   */
  constructor(options = {}) {
    super();

    // Load or generate key pair
    if (options.keyPair) {
      this._keyPair = options.keyPair;
    } else {
      this._keyPair = headyPQC.generateKeyPair();
      logger.debug('[Handshake] Generated ephemeral key pair');
    }

    this._challengeTtlMs = options.challengeTtlMs || CHALLENGE_TTL_MS;
    this._sessionTtlMs   = options.sessionTtlMs   || SESSION_TTL_MS;

    // Active handshakes: handshakeId → HandshakeRecord
    this._active   = new Map();

    // Completed sessions: sessionId → SessionRecord
    this._sessions = new Map();

    logger.info('[Handshake] Initialized');
  }

  // ─── Public API ──────────────────────────────────────────────────────────────

  /**
   * Initiate a handshake with a peer.
   *
   * @param {string} peerId - Identifier for the remote peer
   * @returns {object} { handshakeId, challenge, publicKey }
   */
  initiate(peerId) {
    if (!peerId) throw new Error('[Handshake] initiate: peerId required');

    const handshakeId    = `hs-${randomNonce(8)}`;
    const initiatorNonce = randomNonce(32);
    const timestamp      = Date.now();

    const record = {
      handshakeId,
      peerId,
      initiatorNonce,
      responderNonce: null,
      state: HandshakeState.INITIATED,
      initiatedAt: timestamp,
      expiresAt: timestamp + this._challengeTtlMs,
      sessionKey: null,
      sessionId: null,
    };

    this._active.set(handshakeId, record);

    // Schedule expiry cleanup
    setTimeout(() => this._expireHandshake(handshakeId), this._challengeTtlMs);

    const result = {
      handshakeId,
      challenge: {
        initiatorNonce,
        timestamp,
        expiresAt: record.expiresAt,
      },
      publicKey: this._keyPair.publicKey,
    };

    this.emit('handshake:initiated', { handshakeId, peerId });
    logger.debug('[Handshake] Initiated', { handshakeId, peerId });

    return result;
  }

  /**
   * Respond to a handshake challenge.
   * Called by the peer receiving the initiation.
   *
   * @param {object} challenge
   * @param {string} challenge.handshakeId
   * @param {string} challenge.initiatorNonce
   * @param {number} challenge.timestamp
   * @param {string} [challenge.expiresAt]
   * @returns {object} { handshakeId, response, publicKey }
   */
  respond(challenge) {
    const { handshakeId, initiatorNonce, timestamp } = challenge;

    if (!handshakeId)    throw new Error('[Handshake] respond: handshakeId required');
    if (!initiatorNonce) throw new Error('[Handshake] respond: initiatorNonce required');

    // Check TTL
    const now = Date.now();
    const challengeAge = now - (timestamp || now);
    if (challengeAge > this._challengeTtlMs) {
      throw Object.assign(
        new Error('[Handshake] respond: challenge expired'),
        { code: 'HANDSHAKE_EXPIRED' }
      );
    }

    const responderNonce = randomNonce(32);

    // Sign the combined nonces to prove ownership of private key
    const sigPayload = `${initiatorNonce}:${responderNonce}:${handshakeId}`;
    const signature  = headyPQC.sign(sigPayload, this._keyPair);

    // Store a local record so we can validate if we are also verifying
    const record = {
      handshakeId,
      peerId: 'remote',
      initiatorNonce,
      responderNonce,
      state: HandshakeState.RESPONDED,
      initiatedAt: timestamp || now,
      respondedAt: now,
      expiresAt: (timestamp || now) + this._challengeTtlMs,
      sessionKey: null,
      sessionId: null,
    };
    this._active.set(handshakeId, record);

    const result = {
      handshakeId,
      response: {
        responderNonce,
        signature,
        respondedAt: now,
      },
      publicKey: this._keyPair.publicKey,
    };

    this.emit('handshake:responded', { handshakeId });
    logger.debug('[Handshake] Responded', { handshakeId });

    return result;
  }

  /**
   * Verify a handshake response and establish a session.
   * Called by the original initiator after receiving respond().
   *
   * @param {object} params
   * @param {string} params.handshakeId
   * @param {object} params.response            - Response from respond()
   * @param {string} params.response.responderNonce
   * @param {string} params.response.signature
   * @param {string} params.peerPublicKey       - Peer's public key from respond()
   * @returns {object} { verified, sessionId, sessionKey, expiresAt }
   */
  verify({ handshakeId, response, peerPublicKey }) {
    const record = this._active.get(handshakeId);

    if (!record) {
      throw Object.assign(
        new Error(`[Handshake] verify: unknown handshakeId: ${handshakeId}`),
        { code: 'HANDSHAKE_UNKNOWN' }
      );
    }

    if (record.state === HandshakeState.EXPIRED || Date.now() > record.expiresAt) {
      record.state = HandshakeState.EXPIRED;
      throw Object.assign(
        new Error('[Handshake] verify: handshake expired'),
        { code: 'HANDSHAKE_EXPIRED' }
      );
    }

    // Reconstruct the signed payload
    const sigPayload = `${record.initiatorNonce}:${response.responderNonce}:${handshakeId}`;

    // Verify signature with peer's public key
    const isValid = headyPQC.verify(
      sigPayload,
      response.signature,
      { publicKey: peerPublicKey }
    );

    if (!isValid) {
      record.state = HandshakeState.FAILED;
      this._active.delete(handshakeId);
      this.emit('handshake:failed', { handshakeId, reason: 'invalid_signature' });
      logger.warn('[Handshake] Verification failed', { handshakeId });

      return {
        verified: false,
        sessionId: null,
        sessionKey: null,
      };
    }

    // Derive shared session key
    const sessionKey = deriveSessionKey(
      record.initiatorNonce,
      response.responderNonce,
      record.peerId
    );
    const sessionId  = headyPQC.hashQuantumSafe(`${handshakeId}:${Date.now()}`).slice(0, 32);
    const expiresAt  = Date.now() + this._sessionTtlMs;

    // Store session
    const session = {
      sessionId,
      handshakeId,
      peerId: record.peerId,
      sessionKey,
      sessionKeyHex: sessionKey.toString('hex'),
      establishedAt: Date.now(),
      expiresAt,
      active: true,
    };
    this._sessions.set(sessionId, session);

    // Update record
    record.state      = HandshakeState.VERIFIED;
    record.sessionKey = sessionKey;
    record.sessionId  = sessionId;
    record.responderNonce = response.responderNonce;

    // Schedule session expiry
    setTimeout(() => this._expireSession(sessionId), this._sessionTtlMs);

    this._active.delete(handshakeId); // Clean up handshake record
    this.emit('handshake:verified', { handshakeId, sessionId, peerId: record.peerId });
    logger.info('[Handshake] Verified and session established', { handshakeId, sessionId });

    return {
      verified: true,
      sessionId,
      sessionKey: sessionKey.toString('hex'),
      expiresAt,
    };
  }

  // ─── Session Management ──────────────────────────────────────────────────────

  /**
   * Lookup an active session by ID.
   * @param {string} sessionId
   * @returns {object|null}
   */
  getSession(sessionId) {
    const session = this._sessions.get(sessionId);
    if (!session) return null;
    if (Date.now() > session.expiresAt) {
      session.active = false;
      return null;
    }
    return { ...session, sessionKey: undefined }; // Don't expose key externally
  }

  /**
   * Revoke a session.
   * @param {string} sessionId
   */
  revokeSession(sessionId) {
    const session = this._sessions.get(sessionId);
    if (session) {
      session.active = false;
      this._sessions.delete(sessionId);
      this.emit('session:revoked', { sessionId });
      logger.info('[Handshake] Session revoked', { sessionId });
    }
  }

  /**
   * Return own public key.
   * @returns {string}
   */
  getPublicKey() {
    return this._keyPair.publicKey;
  }

  // ─── Cleanup ──────────────────────────────────────────────────────────────────

  _expireHandshake(handshakeId) {
    const record = this._active.get(handshakeId);
    if (record && record.state !== HandshakeState.VERIFIED) {
      record.state = HandshakeState.EXPIRED;
      this._active.delete(handshakeId);
      this.emit('handshake:expired', { handshakeId });
      logger.debug('[Handshake] Handshake expired', { handshakeId });
    }
  }

  _expireSession(sessionId) {
    const session = this._sessions.get(sessionId);
    if (session && session.active) {
      session.active = false;
      this._sessions.delete(sessionId);
      this.emit('session:expired', { sessionId });
      logger.debug('[Handshake] Session expired', { sessionId });
    }
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────
module.exports = { Handshake, HandshakeState, deriveSessionKey, randomNonce };
