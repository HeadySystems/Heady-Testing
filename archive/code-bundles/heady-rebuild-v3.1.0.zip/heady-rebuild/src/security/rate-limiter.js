/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const { EventEmitter } = require('events');
const logger = require('../utils/logger');

const PHI = 1.6180339887;

// ─── Default limits ───────────────────────────────────────────────────────────
const DEFAULT_WINDOW_MS     = 60_000;   // 1 minute sliding window
const DEFAULT_MAX_REQUESTS  = 100;      // Requests per window
const DEFAULT_BURST_TOKENS  = 20;       // Token bucket burst allowance
const DEFAULT_REFILL_RATE   = 10;       // Tokens refilled per second

// ─── In-memory store ──────────────────────────────────────────────────────────

/**
 * Redis-compatible in-memory store for rate limiting.
 * Stores sliding window request timestamps and token bucket state.
 *
 * For production Redis usage: swap this store's get/set/zadd methods
 * with redis client calls (ioredis / node-redis).
 */
class InMemoryStore {
  constructor() {
    this._data    = new Map(); // key → { timestamps: number[], tokens: number, lastRefill: number }
    this._cleanup = setInterval(() => this._gc(), 120_000);
    if (this._cleanup.unref) this._cleanup.unref();
  }

  /**
   * Get the state for a key, creating if absent.
   * @param {string} key
   * @param {number} maxTokens
   * @returns {object}
   */
  getState(key, maxTokens) {
    if (!this._data.has(key)) {
      this._data.set(key, {
        timestamps: [],
        tokens: maxTokens,
        lastRefill: Date.now(),
      });
    }
    return this._data.get(key);
  }

  set(key, value) {
    this._data.set(key, value);
  }

  has(key) {
    return this._data.has(key);
  }

  delete(key) {
    this._data.delete(key);
  }

  /**
   * Garbage collect stale entries (older than 10 minutes).
   */
  _gc() {
    const now = Date.now();
    const staleThreshold = 10 * 60_000;
    for (const [key, state] of this._data) {
      const latest = state.timestamps.length
        ? state.timestamps[state.timestamps.length - 1]
        : 0;
      if (now - latest > staleThreshold) {
        this._data.delete(key);
      }
    }
  }

  destroy() {
    clearInterval(this._cleanup);
  }
}

// ─── Rate Limiter ─────────────────────────────────────────────────────────────

/**
 * Advanced Rate Limiter for the Heady AI Platform (conductor use).
 *
 * Features:
 *   - Sliding window algorithm per route + per identity
 *   - Token bucket for burst allowance
 *   - Per-route and per-identity limit overrides
 *   - Redis-compatible in-memory fallback
 *   - PHI-scaled penalty delays for repeat violations
 *
 * @extends EventEmitter
 */
class RateLimiter extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.windowMs]        - Sliding window duration in ms
   * @param {number} [options.maxRequests]     - Max requests per window (global default)
   * @param {number} [options.burstTokens]     - Token bucket burst allowance
   * @param {number} [options.refillRate]      - Tokens per second refill rate
   * @param {object} [options.routeLimits]     - Per-route overrides: { routeName: { maxRequests, windowMs } }
   * @param {object} [options.identityLimits]  - Per-identity overrides: { identityId: { maxRequests } }
   * @param {object} [options.store]           - Optional Redis-compatible store (must implement getState/set)
   */
  constructor(options = {}) {
    super();

    this._windowMs    = options.windowMs    || DEFAULT_WINDOW_MS;
    this._maxRequests = options.maxRequests || DEFAULT_MAX_REQUESTS;
    this._burstTokens = options.burstTokens || DEFAULT_BURST_TOKENS;
    this._refillRate  = options.refillRate  || DEFAULT_REFILL_RATE;

    this._routeLimits    = options.routeLimits    || {};
    this._identityLimits = options.identityLimits || {};

    this._store = options.store || new InMemoryStore();

    // Violation counts per key (for PHI-penalty)
    this._violations = new Map();

    logger.info('[RateLimiter] Initialized', {
      windowMs: this._windowMs,
      maxRequests: this._maxRequests,
      burstTokens: this._burstTokens,
    });
  }

  // ─── Public API ──────────────────────────────────────────────────────────────

  /**
   * Check if a request is allowed and consume a token.
   *
   * @param {object} params
   * @param {string} params.route     - Route identifier (e.g. '/api/chat')
   * @param {string} params.identity  - Identity / user / API key identifier
   * @returns {RateLimitResult}
   */
  check({ route, identity }) {
    const now = Date.now();

    // Compute composite key: per-route + per-identity
    const routeKey    = `route:${route}`;
    const identityKey = `identity:${identity}`;
    const compositeKey = `${routeKey}|${identityKey}`;

    // Resolve limits (most restrictive wins)
    const limits = this._resolveLimits(route, identity);

    // ── Sliding Window Check ────────────────────────────────────────────────
    const windowState = this._store.getState(compositeKey + ':window', limits.burstTokens);
    const windowStart = now - limits.windowMs;

    // Prune timestamps outside the window
    windowState.timestamps = windowState.timestamps.filter((t) => t > windowStart);

    const requestCount = windowState.timestamps.length;
    const windowAllowed = requestCount < limits.maxRequests;

    // ── Token Bucket Check ───────────────────────────────────────────────────
    const bucketState = this._store.getState(compositeKey + ':bucket', limits.burstTokens);
    this._refillBucket(bucketState, limits);

    const bucketAllowed = bucketState.tokens >= 1;

    // ── Decision ─────────────────────────────────────────────────────────────
    const allowed = windowAllowed && bucketAllowed;

    if (allowed) {
      // Consume
      windowState.timestamps.push(now);
      bucketState.tokens = Math.max(0, bucketState.tokens - 1);
      this._violations.delete(compositeKey); // Reset violations on success
    } else {
      // Track violation for PHI-penalty
      const vCount = (this._violations.get(compositeKey) || 0) + 1;
      this._violations.set(compositeKey, vCount);

      const penalty = this._phiPenaltyMs(vCount);
      this.emit('rate-limited', { route, identity, requestCount, compositeKey, penalty });
      logger.warn('[RateLimiter] Rate limit exceeded', {
        route, identity, requestCount, limit: limits.maxRequests, penalty,
      });
    }

    const resetIn = windowState.timestamps.length > 0
      ? Math.max(0, limits.windowMs - (now - windowState.timestamps[0]))
      : limits.windowMs;

    return {
      allowed,
      route,
      identity,
      requestCount: requestCount + (allowed ? 1 : 0),
      limit: limits.maxRequests,
      remaining: Math.max(0, limits.maxRequests - requestCount - (allowed ? 1 : 0)),
      resetIn,
      windowMs: limits.windowMs,
      bucketTokens: bucketState.tokens,
      retryAfterMs: allowed ? 0 : resetIn,
    };
  }

  /**
   * Middleware-style function: checks rate limit and throws if denied.
   *
   * @param {string} route
   * @param {string} identity
   * @throws {RateLimitError} if denied
   */
  enforce(route, identity) {
    const result = this.check({ route, identity });
    if (!result.allowed) {
      const err = Object.assign(
        new Error(`Rate limit exceeded for ${identity} on ${route}`),
        {
          code: 'RATE_LIMIT_EXCEEDED',
          retryAfterMs: result.retryAfterMs,
          ...result,
        }
      );
      throw err;
    }
    return result;
  }

  /**
   * Add or update a per-route limit.
   * @param {string} route
   * @param {object} limits - { maxRequests, windowMs, burstTokens }
   */
  setRouteLimit(route, limits) {
    this._routeLimits[route] = limits;
    logger.info('[RateLimiter] Route limit updated', { route, limits });
  }

  /**
   * Add or update a per-identity limit.
   * @param {string} identity
   * @param {object} limits - { maxRequests, windowMs }
   */
  setIdentityLimit(identity, limits) {
    this._identityLimits[identity] = limits;
    logger.info('[RateLimiter] Identity limit updated', { identity, limits });
  }

  /**
   * Reset all counters for a specific identity.
   * @param {string} identity
   */
  resetIdentity(identity) {
    const prefix = `identity:${identity}`;
    // In-memory: iterate and delete matching keys
    if (this._store instanceof InMemoryStore) {
      for (const key of this._store._data.keys()) {
        if (key.includes(prefix)) {
          this._store.delete(key);
        }
      }
    }
    this._violations.delete(`identity:${identity}`);
    logger.info('[RateLimiter] Identity reset', { identity });
  }

  /**
   * Get current stats for a route + identity pair.
   * @param {string} route
   * @param {string} identity
   * @returns {object}
   */
  getStats(route, identity) {
    const now = Date.now();
    const compositeKey = `route:${route}|identity:${identity}`;
    const limits = this._resolveLimits(route, identity);
    const windowState = this._store.getState(compositeKey + ':window', limits.burstTokens);
    const windowStart = now - limits.windowMs;
    const recent = windowState.timestamps.filter((t) => t > windowStart);

    return {
      route,
      identity,
      requestCount: recent.length,
      limit: limits.maxRequests,
      remaining: Math.max(0, limits.maxRequests - recent.length),
      windowMs: limits.windowMs,
      violations: this._violations.get(compositeKey) || 0,
    };
  }

  /**
   * Clean up resources.
   */
  destroy() {
    if (this._store && this._store.destroy) {
      this._store.destroy();
    }
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  /**
   * Resolve effective limits for a route + identity (most restrictive wins).
   */
  _resolveLimits(route, identity) {
    const routeOverride    = this._routeLimits[route]    || {};
    const identityOverride = this._identityLimits[identity] || {};

    return {
      maxRequests: Math.min(
        routeOverride.maxRequests    || this._maxRequests,
        identityOverride.maxRequests || this._maxRequests
      ),
      windowMs: Math.min(
        routeOverride.windowMs    || this._windowMs,
        identityOverride.windowMs || this._windowMs
      ),
      burstTokens: Math.min(
        routeOverride.burstTokens    || this._burstTokens,
        identityOverride.burstTokens || this._burstTokens
      ),
      refillRate: this._refillRate,
    };
  }

  /**
   * Refill the token bucket based on elapsed time.
   */
  _refillBucket(state, limits) {
    const now = Date.now();
    const elapsed = (now - state.lastRefill) / 1000; // seconds
    const tokensToAdd = elapsed * limits.refillRate;

    state.tokens = Math.min(limits.burstTokens, state.tokens + tokensToAdd);
    state.lastRefill = now;
  }

  /**
   * Compute a PHI-scaled penalty delay for repeat violators.
   * @param {number} violationCount
   * @returns {number} ms
   */
  _phiPenaltyMs(violationCount) {
    // PHI^n seconds, capped at 5 minutes
    const seconds = Math.min(300, Math.pow(PHI, Math.min(violationCount, 10)));
    return Math.round(seconds * 1000);
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────
module.exports = { RateLimiter, InMemoryStore, PHI };
