/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const crypto = require('crypto');
const logger = require('../utils/logger');
const { BaseBee, LIFECYCLE, PRIORITY } = require('./bee-template');
const { BeeRegistry } = require('./registry');

// ─── Constants ────────────────────────────────────────────────────────────────
const PHI = 1.6180339887;

// ─── 24 Domains with Worker Template Definitions ─────────────────────────────
// Total template count: 197 across 24 domains
const DOMAIN_TEMPLATES = {
  // 1. coding (12 templates)
  coding: [
    'code-generator', 'code-reviewer', 'refactorer', 'debugger',
    'test-writer', 'doc-generator', 'security-auditor', 'optimizer',
    'api-designer', 'migration-helper', 'linter', 'dependency-analyzer',
  ],
  // 2. research (10 templates)
  research: [
    'web-researcher', 'paper-analyzer', 'data-miner', 'citation-tracker',
    'trend-analyzer', 'competitor-analyst', 'patent-searcher', 'market-researcher',
    'news-aggregator', 'fact-checker',
  ],
  // 3. writing (9 templates)
  writing: [
    'content-writer', 'editor', 'summarizer', 'translator',
    'seo-writer', 'email-writer', 'report-writer', 'social-writer', 'copywriter',
  ],
  // 4. data (10 templates)
  data: [
    'etl-worker', 'data-cleaner', 'data-validator', 'schema-mapper',
    'stats-analyzer', 'viz-generator', 'pipeline-runner', 'query-optimizer',
    'anomaly-detector', 'forecast-modeler',
  ],
  // 5. reasoning (8 templates)
  reasoning: [
    'logical-reasoner', 'argument-builder', 'decision-maker', 'risk-assessor',
    'planner', 'hypothesis-tester', 'inference-engine', 'causal-analyzer',
  ],
  // 6. vision (8 templates)
  vision: [
    'image-analyzer', 'chart-reader', 'ocr-worker', 'object-detector',
    'scene-describer', 'face-processor', 'diagram-parser', 'video-analyzer',
  ],
  // 7. audio (7 templates)
  audio: [
    'transcriber', 'speech-synthesizer', 'audio-classifier', 'music-analyzer',
    'noise-reducer', 'sentiment-from-speech', 'keyword-spotter',
  ],
  // 8. orchestration (8 templates)
  orchestration: [
    'workflow-runner', 'task-scheduler', 'dependency-resolver', 'load-balancer',
    'circuit-breaker-manager', 'retry-handler', 'queue-manager', 'batch-processor',
  ],
  // 9. security (9 templates)
  security: [
    'vulnerability-scanner', 'threat-modeler', 'access-reviewer', 'secret-scanner',
    'compliance-checker', 'pentest-assistant', 'incident-responder',
    'crypto-auditor', 'zero-day-monitor',
  ],
  // 10. ops (8 templates)
  ops: [
    'deployment-manager', 'health-monitor', 'log-analyzer', 'alert-handler',
    'config-manager', 'scaling-controller', 'backup-manager', 'runbook-executor',
  ],
  // 11. governance (7 templates)
  governance: [
    'policy-enforcer', 'audit-logger', 'compliance-reporter', 'budget-tracker',
    'consent-manager', 'data-steward', 'risk-register',
  ],
  // 12. analytics (9 templates)
  analytics: [
    'metric-collector', 'kpi-tracker', 'cohort-analyzer', 'funnel-analyzer',
    'ab-test-runner', 'retention-analyzer', 'attribution-modeler',
    'revenue-analyzer', 'engagement-scorer',
  ],
  // 13. knowledge (8 templates)
  knowledge: [
    'kb-indexer', 'kb-searcher', 'kb-curator', 'entity-extractor',
    'taxonomy-builder', 'ontology-mapper', 'memory-consolidator', 'context-retriever',
  ],
  // 14. creative (8 templates)
  creative: [
    'story-generator', 'prompt-engineer', 'image-prompter', 'brainstormer',
    'concept-artist', 'script-writer', 'name-generator', 'tagline-writer',
  ],
  // 15. simulation (7 templates)
  simulation: [
    'scenario-runner', 'monte-carlo-runner', 'agent-based-modeler',
    'stress-tester', 'load-simulator', 'chaos-monkey', 'digital-twin',
  ],
  // 16. integration (9 templates)
  integration: [
    'webhook-handler', 'api-connector', 'event-bridge', 'data-syncer',
    'oauth-manager', 'batch-importer', 'realtime-streamer',
    'protocol-translator', 'schema-validator',
  ],
  // 17. communication (7 templates)
  communication: [
    'email-sender', 'slack-notifier', 'sms-dispatcher', 'push-notifier',
    'digest-builder', 'broadcast-manager', 'channel-router',
  ],
  // 18. finance (8 templates)
  finance: [
    'invoice-processor', 'budget-analyzer', 'expense-classifier', 'roi-calculator',
    'currency-converter', 'tax-estimator', 'payment-router', 'cost-optimizer',
  ],
  // 19. legal (7 templates)
  legal: [
    'contract-analyzer', 'clause-extractor', 'risk-highlighter', 'compliance-mapper',
    'precedent-finder', 'tos-checker', 'gdpr-auditor',
  ],
  // 20. health (7 templates)
  health: [
    'symptom-analyzer', 'medication-checker', 'clinical-note-parser',
    'ehr-mapper', 'dosage-calculator', 'icd-coder', 'trial-matcher',
  ],
  // 21. education (7 templates)
  education: [
    'tutor', 'quiz-generator', 'curriculum-builder', 'progress-tracker',
    'content-adapter', 'feedback-provider', 'skill-assessor',
  ],
  // 22. search (8 templates)
  search: [
    'web-searcher', 'vector-searcher', 'hybrid-searcher', 'reranker',
    'query-expander', 'result-deduper', 'snippet-extractor', 'index-builder',
  ],
  // 23. swarm (8 templates)
  swarm: [
    'swarm-coordinator', 'consensus-voter', 'proposal-generator', 'task-auctioneer',
    'resource-allocator', 'conflict-resolver', 'swarm-monitor', 'emergence-detector',
  ],
  // 24. general (8 templates)
  general: [
    'general-assistant', 'classifier', 'formatter', 'extractor',
    'validator', 'transformer', 'router', 'dispatcher',
  ],
};

// Validate template count = 197
const TOTAL_TEMPLATES = Object.values(DOMAIN_TEMPLATES).reduce((sum, t) => sum + t.length, 0);
// Note: sum = 197 across 24 domains

// ─── SpecializedBee ───────────────────────────────────────────────────────────
// A concrete bee implementation used by the factory.
// Domain-specific bees extend this in their own modules.

class SpecializedBee extends BaseBee {
  constructor(config = {}) {
    super({
      ...config,
      domain: config.domain || 'general',
      type:   config.type   || 'persistent',
    });
    this.template = config.template || 'general-assistant';
    this._handler = config.handler  || null;
  }

  async executeTask(task) {
    // Delegate to injected handler or stub
    if (typeof this._handler === 'function') {
      return this._handler(task, this);
    }

    // Default stub: echo task for testing
    logger.info('SpecializedBee', `${this.id} (${this.template}) executing task`, {
      taskType: task.type || task.taskType,
    });

    return {
      beeId:    this.id,
      domain:   this.domain,
      template: this.template,
      taskType: task.type || task.taskType,
      result:   `Stub result from ${this.template}`,
      ts:       new Date().toISOString(),
    };
  }
}

// ─── BeeFactory ───────────────────────────────────────────────────────────────

class BeeFactory {
  constructor(options = {}) {
    this.options = Object.assign({
      autoRegister:       true,
      autoInit:           true,
      autoStart:          false,     // persistent bees start manually; ephemeral auto-start
      maxEphemeralBees:   1_000,
      ephemeralTtlMs:     300_000,   // 5 min max life for ephemeral bees
    }, options);

    // Registry (shared or per-factory)
    this.registry = options.registry || new BeeRegistry();

    // Conductor reference (optional, passed to bees)
    this._conductor = options.conductor || null;

    // Ephemeral bee GC tracker: beeId → timeout
    this._ephemeralTimers = new Map();

    // Custom domain handlers: domain+template → handler fn
    this._handlers = new Map();

    logger.logSystem('BeeFactory', 'Initialized', {
      autoRegister: this.options.autoRegister,
      totalTemplates: TOTAL_TEMPLATES,
      domains: Object.keys(DOMAIN_TEMPLATES).length,
    });
  }

  // ── Handler Registration ───────────────────────────────────────────────────

  registerHandler(domain, template, handlerFn) {
    const key = `${domain}:${template}`;
    this._handlers.set(key, handlerFn);
    logger.logSystem('BeeFactory', `Registered handler ${key}`, {});
  }

  _resolveHandler(domain, template) {
    return this._handlers.get(`${domain}:${template}`)
      || this._handlers.get(`${domain}:*`)
      || this._handlers.get(`*:${template}`)
      || null;
  }

  // ── Template Validation ────────────────────────────────────────────────────

  validateTemplate(domain, template) {
    const templates = DOMAIN_TEMPLATES[domain];
    if (!templates) return { valid: false, reason: `Unknown domain: ${domain}` };
    if (template && !templates.includes(template)) {
      return { valid: false, reason: `Unknown template '${template}' for domain '${domain}'` };
    }
    return { valid: true };
  }

  // ── Internal Bee Builder ───────────────────────────────────────────────────

  async _buildBee(domain, config, type) {
    // Validate domain
    if (!DOMAIN_TEMPLATES[domain]) {
      throw new Error(`Unknown domain: ${domain}. Valid domains: ${Object.keys(DOMAIN_TEMPLATES).join(', ')}`);
    }

    const template = config.template || DOMAIN_TEMPLATES[domain][0];
    const validation = this.validateTemplate(domain, template);
    if (!validation.valid) {
      throw new Error(validation.reason);
    }

    const beeId  = config.id || `bee-${domain}-${crypto.randomUUID().slice(0, 8)}`;
    const handler = this._resolveHandler(domain, template);

    const bee = new SpecializedBee({
      id:          beeId,
      domain,
      template,
      type,
      name:        config.name || `${domain}:${template}:${beeId}`,
      handler,
      conductor:   this._conductor,
      heartbeatMs: config.heartbeatMs  || (type === 'ephemeral' ? 10_000 : 30_000),
      taskTimeoutMs: config.taskTimeoutMs,
      metadata:    config.metadata || {},
      maxQueueSize: config.maxQueueSize,
    });

    // Auto-register
    if (this.options.autoRegister) {
      this.registry.register(bee);
    }

    // Auto-init
    if (this.options.autoInit) {
      await bee.init();
    }

    return bee;
  }

  // ── createBee (persistent) ─────────────────────────────────────────────────

  /**
   * Create a persistent bee worker for a domain.
   * The bee is initialized (READY) but not yet started.
   * Call bee.start() to begin processing.
   *
   * @param {string} domain  - Domain name from DOMAIN_TEMPLATES
   * @param {object} [config]
   * @returns {Promise<SpecializedBee>}
   */
  async createBee(domain, config = {}) {
    const bee = await this._buildBee(domain, { ...config }, 'persistent');

    if (this.options.autoStart) {
      await bee.start();
    }

    logger.logSystem('BeeFactory', `Created persistent bee ${bee.id}`, {
      domain, template: bee.template,
    });
    return bee;
  }

  // ── spawnBee (ephemeral) ───────────────────────────────────────────────────

  /**
   * Spawn an ephemeral bee for a one-time task.
   * The bee is auto-started, executes, then auto-terminates after TTL or completion.
   *
   * @param {string} domain
   * @param {object} [config]
   * @param {object} [config.task]  - Optional task to immediately enqueue
   * @returns {Promise<SpecializedBee>}
   */
  async spawnBee(domain, config = {}) {
    const activeEphemeral = [...this.registry.list({ type: 'ephemeral' }).bees].length;
    if (activeEphemeral >= this.options.maxEphemeralBees) {
      throw new Error(`Max ephemeral bees reached (${this.options.maxEphemeralBees})`);
    }

    const bee = await this._buildBee(domain, { ...config }, 'ephemeral');
    await bee.start();

    // Enqueue initial task if provided
    if (config.task) {
      bee.enqueue(config.task);
    }

    // Auto-terminate after TTL
    const ttl = config.ttlMs || this.options.ephemeralTtlMs;
    const timer = setTimeout(async () => {
      if (bee.lifecycle !== LIFECYCLE.TERMINATED) {
        logger.logSystem('BeeFactory', `Ephemeral bee TTL expired: ${bee.id}`, {});
        await bee.terminate('ttl-expired').catch(() => {});
      }
      this._ephemeralTimers.delete(bee.id);
    }, ttl);

    this._ephemeralTimers.set(bee.id, timer);

    // Clean up on natural termination
    bee.once('bee:terminated', () => {
      const t = this._ephemeralTimers.get(bee.id);
      if (t) { clearTimeout(t); this._ephemeralTimers.delete(bee.id); }
    });

    logger.logSystem('BeeFactory', `Spawned ephemeral bee ${bee.id}`, {
      domain, template: bee.template, ttl,
    });
    return bee;
  }

  // ── Pool Creation ──────────────────────────────────────────────────────────

  /**
   * Create a pool of persistent bees for a domain.
   * Fibonacci-sized pool based on PHI.
   *
   * @param {string} domain
   * @param {number} [count] - How many bees; defaults to phi-rounded 3
   * @param {object} [config]
   * @returns {Promise<SpecializedBee[]>}
   */
  async createPool(domain, count, config = {}) {
    const poolSize = count || Math.round(PHI * PHI); // ~2.6 → 3
    const bees     = [];

    for (let i = 0; i < poolSize; i++) {
      const bee = await this.createBee(domain, {
        ...config,
        name: `${domain}-pool-${i}-${crypto.randomUUID().slice(0, 4)}`,
      });
      bees.push(bee);
    }

    logger.logSystem('BeeFactory', `Created pool of ${poolSize} bees for ${domain}`, {});
    return bees;
  }

  // ── Introspection ──────────────────────────────────────────────────────────

  getDomainTemplates(domain) {
    if (domain) return DOMAIN_TEMPLATES[domain] || [];
    return { ...DOMAIN_TEMPLATES };
  }

  listDomains() {
    return Object.keys(DOMAIN_TEMPLATES);
  }

  getStats() {
    return {
      totalTemplates:   TOTAL_TEMPLATES,
      domains:          Object.keys(DOMAIN_TEMPLATES).length,
      registeredBees:   this.registry.getSummary(),
      activeEphemeral:  this._ephemeralTimers.size,
      phi:              PHI,
    };
  }

  // ── Shutdown ───────────────────────────────────────────────────────────────

  async shutdown() {
    // Cancel all ephemeral timers
    for (const timer of this._ephemeralTimers.values()) {
      clearTimeout(timer);
    }
    this._ephemeralTimers.clear();

    await this.registry.shutdown();
    logger.logSystem('BeeFactory', 'Shutdown complete', {});
  }
}

module.exports = {
  BeeFactory,
  SpecializedBee,
  DOMAIN_TEMPLATES,
  TOTAL_TEMPLATES,
  PHI,
};
