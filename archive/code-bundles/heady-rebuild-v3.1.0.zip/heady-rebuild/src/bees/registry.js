/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const { EventEmitter } = require('events');
const logger = require('../utils/logger');
const { LIFECYCLE } = require('./bee-template');

// ─── BeeRegistry ──────────────────────────────────────────────────────────────

class BeeRegistry extends EventEmitter {
  constructor(options = {}) {
    super();
    this.options = Object.assign({
      maxBees:              10_000,
      staleHeartbeatMs:     90_000,  // Bee is stale if no heartbeat in 90s
      cleanupIntervalMs:    60_000,  // Run stale bee cleanup every 60s
    }, options);

    // Primary storage: beeId → bee instance
    this._bees = new Map();

    // Indexes for fast lookups
    this._byDomain  = new Map(); // domain  → Set<beeId>
    this._byType    = new Map(); // type    → Set<beeId>  ('persistent'|'ephemeral')
    this._byLifecycle = new Map(); // lifecycle → Set<beeId>

    // Lifecycle state initialization
    for (const state of Object.values(LIFECYCLE)) {
      this._byLifecycle.set(state, new Set());
    }

    // Domain-level statistics cache
    this._domainStats = new Map();

    // Cleanup timer
    this._cleanupTimer = setInterval(
      () => this._cleanupStaleBees(),
      this.options.cleanupIntervalMs
    );

    logger.logSystem('BeeRegistry', 'Initialized', {
      maxBees: this.options.maxBees,
    });
  }

  // ── Registration ──────────────────────────────────────────────────────────

  register(bee) {
    if (!bee || !bee.id) throw new Error('bee must have an id');
    if (this._bees.size >= this.options.maxBees) {
      throw new Error(`BeeRegistry at capacity (${this.options.maxBees})`);
    }
    if (this._bees.has(bee.id)) {
      logger.warn('BeeRegistry', `Re-registering existing bee: ${bee.id}`, {});
      this.deregister(bee.id);
    }

    this._bees.set(bee.id, bee);
    this._indexBee(bee);

    // Attach lifecycle change listener for dynamic index updates
    bee.on('lifecycle:changed', ({ from, to }) => {
      this._reindexLifecycle(bee.id, from, to);
      this._invalidateDomainStats(bee.domain);
    });

    // Track heartbeats
    bee.on('heartbeat', () => this._invalidateDomainStats(bee.domain));

    this._invalidateDomainStats(bee.domain);
    this.emit('bee:registered', { beeId: bee.id, domain: bee.domain, type: bee.type });
    logger.logSystem('BeeRegistry', `Registered ${bee.id}`, { domain: bee.domain, type: bee.type });

    return bee.id;
  }

  deregister(beeId) {
    const bee = this._bees.get(beeId);
    if (!bee) return false;

    this._bees.delete(beeId);
    this._unindexBee(bee);
    this._invalidateDomainStats(bee.domain);

    this.emit('bee:deregistered', { beeId, domain: bee.domain });
    logger.logSystem('BeeRegistry', `Deregistered ${beeId}`, { domain: bee.domain });
    return true;
  }

  // ── Index Helpers ──────────────────────────────────────────────────────────

  _indexBee(bee) {
    // Domain index
    if (!this._byDomain.has(bee.domain)) this._byDomain.set(bee.domain, new Set());
    this._byDomain.get(bee.domain).add(bee.id);

    // Type index
    if (!this._byType.has(bee.type)) this._byType.set(bee.type, new Set());
    this._byType.get(bee.type).add(bee.id);

    // Lifecycle index
    const state = bee.lifecycle || LIFECYCLE.CREATED;
    if (!this._byLifecycle.has(state)) this._byLifecycle.set(state, new Set());
    this._byLifecycle.get(state).add(bee.id);
  }

  _unindexBee(bee) {
    this._byDomain.get(bee.domain)?.delete(bee.id);
    this._byType.get(bee.type)?.delete(bee.id);
    for (const set of this._byLifecycle.values()) {
      set.delete(bee.id);
    }
  }

  _reindexLifecycle(beeId, from, to) {
    this._byLifecycle.get(from)?.delete(beeId);
    if (!this._byLifecycle.has(to)) this._byLifecycle.set(to, new Set());
    this._byLifecycle.get(to).add(beeId);
  }

  _invalidateDomainStats(domain) {
    this._domainStats.delete(domain);
  }

  // ── Find ───────────────────────────────────────────────────────────────────

  /**
   * Find bees matching a query.
   * @param {object} query
   * @param {string}   [query.domain]     - Exact domain match
   * @param {string}   [query.type]       - 'persistent' | 'ephemeral'
   * @param {string}   [query.lifecycle]  - LIFECYCLE value
   * @param {string[]} [query.domains]    - Match any of these domains
   * @param {Function} [query.filter]     - Arbitrary filter function(bee) → boolean
   * @param {number}   [query.limit]      - Max results
   * @returns {object[]} array of bee status objects
   */
  find(query = {}) {
    let candidateIds;

    if (query.domain) {
      candidateIds = this._byDomain.get(query.domain) || new Set();
    } else if (query.domains) {
      candidateIds = new Set();
      for (const d of query.domains) {
        for (const id of (this._byDomain.get(d) || [])) candidateIds.add(id);
      }
    } else {
      candidateIds = new Set(this._bees.keys());
    }

    // Further filter by type
    if (query.type) {
      const typeIds = this._byType.get(query.type) || new Set();
      candidateIds = new Set([...candidateIds].filter(id => typeIds.has(id)));
    }

    // Further filter by lifecycle
    if (query.lifecycle) {
      const lcIds = this._byLifecycle.get(query.lifecycle) || new Set();
      candidateIds = new Set([...candidateIds].filter(id => lcIds.has(id)));
    }

    let results = [];
    for (const id of candidateIds) {
      const bee = this._bees.get(id);
      if (!bee) continue;
      if (query.filter && !query.filter(bee)) continue;
      results.push(bee.getStatus ? bee.getStatus() : { id: bee.id, domain: bee.domain });
      if (query.limit && results.length >= query.limit) break;
    }

    return results;
  }

  get(beeId) {
    return this._bees.get(beeId) || null;
  }

  // ── List ───────────────────────────────────────────────────────────────────

  /**
   * List bees with optional filters.
   * @param {object} filters
   * @param {string} [filters.domain]
   * @param {string} [filters.type]
   * @param {string} [filters.lifecycle]
   * @param {number} [filters.limit]
   * @param {number} [filters.offset]
   * @returns {{ bees: object[], total: number }}
   */
  list(filters = {}) {
    const all = this.find({
      domain:    filters.domain,
      type:      filters.type,
      lifecycle: filters.lifecycle,
    });

    const total  = all.length;
    const offset = filters.offset || 0;
    const limit  = filters.limit  || all.length;
    const bees   = all.slice(offset, offset + limit);

    return { bees, total };
  }

  // ── Health Aggregation ─────────────────────────────────────────────────────

  aggregateHealth() {
    const now   = Date.now();
    let healthy = 0, stale = 0, terminated = 0, total = 0;

    for (const bee of this._bees.values()) {
      total++;
      const status = bee.getStatus ? bee.getStatus() : { lifecycle: bee.lifecycle };

      if (status.lifecycle === LIFECYCLE.TERMINATED) {
        terminated++;
        continue;
      }

      const lastHB = status.lastHeartbeat;
      if (lastHB && (now - lastHB) > this.options.staleHeartbeatMs) {
        stale++;
      } else if (
        status.lifecycle === LIFECYCLE.RUNNING ||
        status.lifecycle === LIFECYCLE.READY
      ) {
        healthy++;
      }
    }

    const healthScore = total > 0 ? (healthy / total) : 1.0;

    return {
      total,
      healthy,
      stale,
      terminated,
      healthScore:  parseFloat(healthScore.toFixed(4)),
      status:       healthScore >= 0.9 ? 'HEALTHY' : healthScore >= 0.6 ? 'DEGRADED' : 'CRITICAL',
      ts:           new Date().toISOString(),
    };
  }

  // ── Domain Statistics ──────────────────────────────────────────────────────

  getDomainStats(domain) {
    if (this._domainStats.has(domain)) {
      return this._domainStats.get(domain);
    }

    const ids = this._byDomain.get(domain) || new Set();
    const stats = {
      domain,
      total:       ids.size,
      byLifecycle: {},
      byType:      {},
      queueDepth:  0,
      tasksCompleted: 0,
      tasksFailed:    0,
    };

    for (const id of ids) {
      const bee = this._bees.get(id);
      if (!bee) continue;
      const s = bee.getStatus ? bee.getStatus() : {};

      stats.byLifecycle[s.lifecycle || 'UNKNOWN'] =
        (stats.byLifecycle[s.lifecycle || 'UNKNOWN'] || 0) + 1;

      stats.byType[s.type || 'unknown'] =
        (stats.byType[s.type || 'unknown'] || 0) + 1;

      stats.queueDepth      += s.queueSize || 0;
      stats.tasksCompleted  += s.stats?.tasksCompleted || 0;
      stats.tasksFailed     += s.stats?.tasksFailed    || 0;
    }

    this._domainStats.set(domain, stats);
    return stats;
  }

  getAllDomainStats() {
    const result = {};
    for (const domain of this._byDomain.keys()) {
      result[domain] = this.getDomainStats(domain);
    }
    return result;
  }

  listDomains() {
    return [...this._byDomain.keys()];
  }

  // ── Stale Bee Cleanup ──────────────────────────────────────────────────────

  _cleanupStaleBees() {
    const now = Date.now();
    let cleaned = 0;

    for (const [id, bee] of this._bees.entries()) {
      const status = bee.getStatus ? bee.getStatus() : {};

      // Auto-deregister terminated bees
      if (status.lifecycle === LIFECYCLE.TERMINATED) {
        this.deregister(id);
        cleaned++;
        continue;
      }

      // Warn on stale heartbeat
      if (status.lastHeartbeat && (now - status.lastHeartbeat) > this.options.staleHeartbeatMs) {
        logger.warn('BeeRegistry', `Stale heartbeat for bee ${id}`, {
          domain: bee.domain,
          lastHeartbeat: new Date(status.lastHeartbeat).toISOString(),
        });
        this.emit('bee:stale', { beeId: id, domain: bee.domain, lastHeartbeat: status.lastHeartbeat });
      }
    }

    if (cleaned > 0) {
      logger.logSystem('BeeRegistry', `Cleanup: removed ${cleaned} terminated bees`, {
        remaining: this._bees.size,
      });
    }
  }

  // ── Shutdown ───────────────────────────────────────────────────────────────

  async shutdown() {
    clearInterval(this._cleanupTimer);

    // Terminate all active bees
    const terminatePromises = [];
    for (const bee of this._bees.values()) {
      if (bee.lifecycle !== LIFECYCLE.TERMINATED && typeof bee.terminate === 'function') {
        terminatePromises.push(bee.terminate('registry-shutdown').catch(() => {}));
      }
    }

    await Promise.allSettled(terminatePromises);
    this._bees.clear();
    this._byDomain.clear();
    this._byType.clear();
    this._byLifecycle.clear();

    logger.logSystem('BeeRegistry', 'Shutdown complete', {});
    this.emit('registry:shutdown');
  }

  // ── Summary ───────────────────────────────────────────────────────────────

  getSummary() {
    return {
      totalBees:   this._bees.size,
      domains:     this._byDomain.size,
      byLifecycle: Object.fromEntries(
        [...this._byLifecycle.entries()].map(([k, v]) => [k, v.size])
      ),
      byType: Object.fromEntries(
        [...this._byType.entries()].map(([k, v]) => [k, v.size])
      ),
      health: this.aggregateHealth(),
    };
  }
}

module.exports = { BeeRegistry };
