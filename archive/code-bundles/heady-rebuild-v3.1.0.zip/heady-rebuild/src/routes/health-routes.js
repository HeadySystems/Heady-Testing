/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

/**
 * @fileoverview Health check route handlers for the Heady™ AI Platform.
 * Provides liveness, readiness, and startup probes compatible with
 * Kubernetes, Cloudflare Workers, and any load balancer health checks.
 * @module src/routes/health-routes
 */

const { createLogger } = require('../utils/logger');
const { isShuttingDown } = require('../lifecycle/graceful-shutdown');
const config = require('../config');

const logger = createLogger('health');

// ---------------------------------------------------------------------------
// Subsystem registry
// ---------------------------------------------------------------------------

/**
 * @typedef {Object} SubsystemCheck
 * @property {string} name - Subsystem name
 * @property {Function} check - Async function returning { status, details }
 */

/** @type {SubsystemCheck[]} */
const _subsystems = [];

/**
 * Registers a subsystem health check.
 * @param {string} name
 * @param {Function} checkFn - Async fn returning { status: 'pass'|'warn'|'fail', details?: Object }
 */
function registerSubsystem(name, checkFn) {
  _subsystems.push({ name, check: checkFn });
}

// ---------------------------------------------------------------------------
// Built-in checks
// ---------------------------------------------------------------------------

/** Returns process memory usage details. */
async function checkMemory() {
  const mem = process.memoryUsage();
  const heapUsedMb = Math.round(mem.heapUsed / 1024 / 1024);
  const heapTotalMb = Math.round(mem.heapTotal / 1024 / 1024);
  const rssMb = Math.round(mem.rss / 1024 / 1024);
  const usageRatio = mem.heapUsed / mem.heapTotal;

  return {
    status: usageRatio > 0.95 ? 'fail' : usageRatio > 0.85 ? 'warn' : 'pass',
    details: { heapUsedMb, heapTotalMb, rssMb, usageRatio: Math.round(usageRatio * 100) + '%' },
  };
}

/** Returns process uptime and start time. */
async function checkProcess() {
  return {
    status: 'pass',
    details: {
      uptimeSeconds: Math.round(process.uptime()),
      pid: process.pid,
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
    },
  };
}

/** Returns event loop lag estimate. */
async function checkEventLoop() {
  const start = Date.now();
  return new Promise((resolve) => {
    setImmediate(() => {
      const lagMs = Date.now() - start;
      resolve({
        status: lagMs > 500 ? 'fail' : lagMs > 100 ? 'warn' : 'pass',
        details: { lagMs },
      });
    });
  });
}

// Register built-in checks
registerSubsystem('process', checkProcess);
registerSubsystem('memory', checkMemory);
registerSubsystem('event-loop', checkEventLoop);

// ---------------------------------------------------------------------------
// Route handlers
// ---------------------------------------------------------------------------

/**
 * GET /health/live — Liveness probe.
 * Returns 200 if the process is alive (not in fatal crash state).
 * Returns 503 during shutdown to drain load balancer traffic.
 *
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 */
function handleLiveness(req, res) {
  const shuttingDown = isShuttingDown();
  const status = shuttingDown ? 503 : 200;

  const body = {
    status: shuttingDown ? 'shutting_down' : 'alive',
    timestamp: new Date().toISOString(),
    platform: config.server.platform,
    version: config.server.version,
    environment: config.server.environment,
    node: config.server.name,
  };

  logger.logHealth('liveness', shuttingDown ? 'warn' : 'pass', { status });

  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache, no-store',
  });
  res.end(JSON.stringify(body));
}

/**
 * GET /health/ready — Readiness probe.
 * Runs all registered subsystem checks. Returns 200 if all pass or warn,
 * 503 if any fail or shutdown is in progress.
 *
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 */
async function handleReadiness(req, res) {
  if (isShuttingDown()) {
    const body = {
      status: 'not_ready',
      reason: 'shutdown_in_progress',
      timestamp: new Date().toISOString(),
    };
    res.writeHead(503, { 'Content-Type': 'application/json', 'Cache-Control': 'no-cache' });
    res.end(JSON.stringify(body));
    return;
  }

  const startMs = Date.now();
  const checks = {};
  let overallStatus = 'pass';

  // Run all checks in parallel
  const results = await Promise.allSettled(
    _subsystems.map(async ({ name, check }) => {
      const t0 = Date.now();
      try {
        const result = await Promise.race([
          check(),
          new Promise((_, rej) => setTimeout(() => rej(new Error('Health check timeout')), 5000)),
        ]);
        return { name, ...result, durationMs: Date.now() - t0 };
      } catch (err) {
        return { name, status: 'fail', details: { error: err.message }, durationMs: Date.now() - t0 };
      }
    })
  );

  for (const settled of results) {
    const r = settled.status === 'fulfilled' ? settled.value : { name: '?', status: 'fail', details: { error: settled.reason?.message } };
    checks[r.name] = { status: r.status, details: r.details, durationMs: r.durationMs };
    logger.logHealth(r.name, r.status);

    if (r.status === 'fail') overallStatus = 'fail';
    else if (r.status === 'warn' && overallStatus !== 'fail') overallStatus = 'warn';
  }

  const httpStatus = overallStatus === 'fail' ? 503 : 200;

  const body = {
    status: overallStatus,
    timestamp: new Date().toISOString(),
    durationMs: Date.now() - startMs,
    platform: config.server.platform,
    version: config.server.version,
    environment: config.server.environment,
    node: config.server.name,
    checks,
  };

  res.writeHead(httpStatus, {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache, no-store',
  });
  res.end(JSON.stringify(body));
}

/**
 * GET /health/startup — Startup probe.
 * Returns 200 once the platform has completed initialisation.
 * The startup flag is set externally via markStartupComplete().
 *
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 */
function handleStartup(req, res) {
  const ready = _startupComplete;
  const status = ready ? 200 : 503;

  const body = {
    status: ready ? 'started' : 'starting',
    startupTimeMs: ready ? _startupTimeMs : null,
    timestamp: new Date().toISOString(),
  };

  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Cache-Control': 'no-cache, no-store',
  });
  res.end(JSON.stringify(body));
}

// ---------------------------------------------------------------------------
// Startup flag
// ---------------------------------------------------------------------------

let _startupComplete = false;
let _startupTimeMs = 0;
const _startTime = Date.now();

/**
 * Marks the platform as fully started (called after all modules are init'd).
 */
function markStartupComplete() {
  _startupComplete = true;
  _startupTimeMs = Date.now() - _startTime;
  logger.logSystem('startup:complete', { startupTimeMs: _startupTimeMs });
}

// ---------------------------------------------------------------------------
// Route registration helper
// ---------------------------------------------------------------------------

/**
 * Attaches health routes to a HeadyServer router.
 * @param {Object} router - HeadyServer router instance with .get() method
 */
function registerHealthRoutes(router) {
  router.get('/health/live', handleLiveness);
  router.get('/health/ready', handleReadiness);
  router.get('/health/startup', handleStartup);
  logger.debug('Health routes registered: /health/live, /health/ready, /health/startup');
}

module.exports = {
  handleLiveness,
  handleReadiness,
  handleStartup,
  registerHealthRoutes,
  registerSubsystem,
  markStartupComplete,
};
