/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const { EventEmitter } = require('events');
const logger = require('../utils/logger');

// ─── Constants ────────────────────────────────────────────────────────────────
const PHI = 1.6180339887;

// Attention modes
const MODES = {
  AUTONOMOUS: 'AUTONOMOUS', // User absent  → 90% background attention
  ACTIVE:     'ACTIVE',     // User present → 100% attention
  SLEEPING:   'SLEEPING',   // Low-power idle
};

// Resource allocation per mode (fraction of total resources 0–1)
const MODE_ALLOCATIONS = {
  [MODES.AUTONOMOUS]: {
    background: 0.90,
    foreground: 0.05,
    reserve:    0.05,
    attention:  0.90,
  },
  [MODES.ACTIVE]: {
    background: 0.20,
    foreground: 0.75,
    reserve:    0.05,
    attention:  1.00,
  },
  [MODES.SLEEPING]: {
    background: 0.10,
    foreground: 0.00,
    reserve:    0.90,
    attention:  0.10,
  },
};

// Task type → preferred allocation tier
const TASK_TIERS = {
  chat:          'foreground',
  realtime:      'foreground',
  inference:     'foreground',
  analyze:       'background',
  simulate:      'background',
  embed:         'background',
  governance:    'background',
  maintenance:   'background',
  housekeeping:  'background',
  idle:          'reserve',
};

// Singleton instance
let _instance = null;

// ─── CognitiveRuntimeGovernor ─────────────────────────────────────────────────

class CognitiveRuntimeGovernor extends EventEmitter {
  constructor(options = {}) {
    super();
    this.options = Object.assign({
      userAbsenceTimeoutMs: 300_000,  // 5 min of inactivity → AUTONOMOUS
      idleTimeoutMs:        1_800_000, // 30 min → SLEEPING
      maxConcurrentTasks:   100,
      totalResourceUnits:   1000,
    }, options);

    this._mode = MODES.AUTONOMOUS;
    this._activeTasks = new Map(); // taskId → task state

    // Resource tracking
    this._resourceUsage = {
      foreground: 0,
      background: 0,
      reserve:    0,
    };

    // User presence timer
    this._userAbsenceTimer = null;
    this._idleTimer        = null;
    this._lastUserActivity = null;

    // Task counter
    this._taskCounter = 0;

    logger.logSystem('CognitiveRuntimeGovernor', 'Initialized', {
      mode:          this._mode,
      maxTasks:      this.options.maxConcurrentTasks,
      totalUnits:    this.options.totalResourceUnits,
    });
  }

  // ── Singleton ──────────────────────────────────────────────────────────────

  static getInstance(options) {
    if (!_instance) {
      _instance = new CognitiveRuntimeGovernor(options);
    }
    return _instance;
  }

  static resetInstance() {
    _instance = null;
  }

  // ── Mode Management ────────────────────────────────────────────────────────

  get mode() { return this._mode; }

  _setMode(newMode) {
    if (newMode === this._mode) return;
    const prev = this._mode;
    this._mode = newMode;
    logger.logSystem('CognitiveRuntimeGovernor', `Mode change: ${prev} → ${newMode}`, {
      activeTasks: this._activeTasks.size,
    });
    this.emit('mode:changed', { from: prev, to: newMode, ts: Date.now() });
  }

  userPresent() {
    this._lastUserActivity = Date.now();
    this._clearTimers();
    this._setMode(MODES.ACTIVE);
    this._scheduleAbsenceTimer();
  }

  userAbsent() {
    this._clearTimers();
    this._setMode(MODES.AUTONOMOUS);
    this._scheduleIdleTimer();
    logger.logSystem('CognitiveRuntimeGovernor', 'User absent — switching to AUTONOMOUS', {});
  }

  _scheduleAbsenceTimer() {
    this._userAbsenceTimer = setTimeout(() => {
      logger.logSystem('CognitiveRuntimeGovernor', 'User absence timeout — switching to AUTONOMOUS', {});
      this._setMode(MODES.AUTONOMOUS);
      this._scheduleIdleTimer();
    }, this.options.userAbsenceTimeoutMs);
  }

  _scheduleIdleTimer() {
    this._idleTimer = setTimeout(() => {
      if (this._activeTasks.size === 0) {
        logger.logSystem('CognitiveRuntimeGovernor', 'Idle timeout — entering SLEEPING mode', {});
        this._setMode(MODES.SLEEPING);
      }
    }, this.options.idleTimeoutMs);
  }

  _clearTimers() {
    if (this._userAbsenceTimer) { clearTimeout(this._userAbsenceTimer); this._userAbsenceTimer = null; }
    if (this._idleTimer)        { clearTimeout(this._idleTimer);        this._idleTimer = null; }
  }

  // ── Resource Allocation ────────────────────────────────────────────────────

  /**
   * Allocate resources for a task type based on current mode.
   *
   * @param {string} taskType
   * @param {object} [opts]
   * @param {number} [opts.requestedUnits]  - How many units the task wants
   * @param {string} [opts.tenantId]
   * @returns {{ taskId: string, tier: string, units: number, allocation: object, mode: string }}
   */
  allocate(taskType, opts = {}) {
    // Wake up if sleeping and a task arrives
    if (this._mode === MODES.SLEEPING) {
      this._setMode(MODES.AUTONOMOUS);
    }

    if (this._activeTasks.size >= this.options.maxConcurrentTasks) {
      throw new Error(`Max concurrent tasks reached (${this.options.maxConcurrentTasks})`);
    }

    const modeAlloc = MODE_ALLOCATIONS[this._mode];
    const tier      = TASK_TIERS[taskType] || 'background';

    // How many total units are available for this tier?
    const tierCapacity = Math.floor(this.options.totalResourceUnits * modeAlloc[tier]);
    const currentUsage = this._resourceUsage[tier] || 0;
    const available    = Math.max(0, tierCapacity - currentUsage);

    // Grant requested or default phi-fraction of available
    const defaultRequest = Math.floor(available / PHI);
    const requested      = opts.requestedUnits || defaultRequest;
    const granted        = Math.min(requested, available);

    if (granted === 0) {
      logger.warn('CognitiveRuntimeGovernor', `No capacity for task type ${taskType}`, {
        tier, tierCapacity, currentUsage, mode: this._mode,
      });
    }

    const taskId = `task-${Date.now()}-${++this._taskCounter}`;
    const taskState = {
      taskId,
      taskType,
      tier,
      units:        granted,
      tenantId:     opts.tenantId || null,
      startedAt:    Date.now(),
      mode:         this._mode,
    };

    this._activeTasks.set(taskId, taskState);
    this._resourceUsage[tier] = (this._resourceUsage[tier] || 0) + granted;

    this.emit('task:allocated', { taskId, taskType, tier, units: granted, mode: this._mode });

    logger.info('CognitiveRuntimeGovernor', `Allocated task ${taskId}`, {
      taskType, tier, granted, mode: this._mode,
    });

    return {
      taskId,
      tier,
      units:      granted,
      allocation: { ...modeAlloc },
      mode:       this._mode,
      attention:  modeAlloc.attention,
    };
  }

  /**
   * Release resources held by a completed task.
   *
   * @param {string} taskId
   */
  release(taskId) {
    const task = this._activeTasks.get(taskId);
    if (!task) {
      logger.warn('CognitiveRuntimeGovernor', `release called for unknown taskId: ${taskId}`, {});
      return false;
    }

    this._resourceUsage[task.tier] = Math.max(0, (this._resourceUsage[task.tier] || 0) - task.units);
    this._activeTasks.delete(taskId);

    const duration = Date.now() - task.startedAt;
    this.emit('task:released', { taskId, taskType: task.taskType, duration });

    logger.info('CognitiveRuntimeGovernor', `Released task ${taskId}`, {
      taskType: task.taskType,
      duration,
      remainingTasks: this._activeTasks.size,
    });

    return true;
  }

  // ── Introspection ──────────────────────────────────────────────────────────

  getStatus() {
    const modeAlloc = MODE_ALLOCATIONS[this._mode];
    const total     = this.options.totalResourceUnits;

    const pools = {};
    for (const [tier, fraction] of Object.entries(modeAlloc)) {
      if (tier === 'attention') continue;
      const capacity = Math.floor(total * fraction);
      const used     = this._resourceUsage[tier] || 0;
      pools[tier] = {
        capacity,
        used,
        available: capacity - used,
        utilization: capacity > 0 ? parseFloat((used / capacity * 100).toFixed(1)) : 0,
      };
    }

    return {
      mode:          this._mode,
      attention:     modeAlloc.attention,
      activeTasks:   this._activeTasks.size,
      maxTasks:      this.options.maxConcurrentTasks,
      totalUnits:    total,
      pools,
      lastUserActivity: this._lastUserActivity,
      phi:           PHI,
    };
  }

  listActiveTasks() {
    return [...this._activeTasks.values()];
  }

  getActiveTasksByType(taskType) {
    return [...this._activeTasks.values()].filter(t => t.taskType === taskType);
  }

  // ── Graceful Shutdown ──────────────────────────────────────────────────────

  shutdown() {
    this._clearTimers();
    const remaining = [...this._activeTasks.keys()];
    for (const taskId of remaining) {
      this.release(taskId);
    }
    this._setMode(MODES.SLEEPING);
    logger.logSystem('CognitiveRuntimeGovernor', 'Shutdown complete', {
      clearedTasks: remaining.length,
    });
  }
}

module.exports = {
  CognitiveRuntimeGovernor,
  MODES,
  MODE_ALLOCATIONS,
  TASK_TIERS,
  PHI,
};
