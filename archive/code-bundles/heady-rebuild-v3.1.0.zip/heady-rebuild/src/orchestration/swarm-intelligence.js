/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

const logger = require('../utils/logger');

// ─── Constants ────────────────────────────────────────────────────────────────
const PHI = 1.6180339887;

// Fibonacci sequence for budget weights
const FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233];

// Cloud status thresholds
const HEALTH_THRESHOLDS = {
  HEALTHY:   0.9,
  DEGRADED:  0.6,
  CRITICAL:  0.3,
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Get Fibonacci weight for a zero-based index (cycles if idx >= FIBONACCI.length)
 */
function fibWeight(idx) {
  return FIBONACCI[idx % FIBONACCI.length];
}

/**
 * Normalize an array of weights to sum to 1.0
 */
function normalizeWeights(weights) {
  const total = weights.reduce((s, w) => s + w, 0);
  if (total === 0) return weights.map(() => 0);
  return weights.map(w => w / total);
}

// ─── computeSwarmAllocation ───────────────────────────────────────────────────

/**
 * Fibonacci-weighted budget allocation across swarm nodes.
 *
 * @param {Array<{id: string, priority?: number, capacity?: number}>} nodes
 * @param {number} budget - Total budget units to distribute
 * @returns {Array<{nodeId: string, allocation: number, weight: number}>}
 */
function computeSwarmAllocation(nodes, budget) {
  if (!Array.isArray(nodes) || nodes.length === 0) {
    logger.warn('swarm-intelligence', 'computeSwarmAllocation called with empty nodes', {});
    return [];
  }

  if (typeof budget !== 'number' || budget <= 0) {
    throw new Error('budget must be a positive number');
  }

  // Build fibonacci weights, higher priority → higher fib index
  const sorted = [...nodes].map((node, idx) => ({
    ...node,
    _origIdx: idx,
    _priority: typeof node.priority === 'number' ? node.priority : idx,
  })).sort((a, b) => a._priority - b._priority);

  const rawWeights = sorted.map((_, i) => fibWeight(i));
  const normalized = normalizeWeights(rawWeights);

  const result = sorted.map((node, i) => {
    const weight     = normalized[i];
    const allocation = budget * weight;
    return {
      nodeId:     node.id,
      allocation: parseFloat(allocation.toFixed(4)),
      weight:     parseFloat(weight.toFixed(6)),
      priority:   node._priority,
    };
  });

  const totalAllocated = result.reduce((s, r) => s + r.allocation, 0);
  logger.info('swarm-intelligence', 'computeSwarmAllocation', {
    nodes: nodes.length,
    budget,
    totalAllocated: totalAllocated.toFixed(4),
  });

  return result;
}

// ─── evaluateLiveCloudStatus ──────────────────────────────────────────────────

/**
 * Aggregate cloud service health from multiple services.
 *
 * @param {Array<{id: string, healthy: boolean, latencyMs?: number, errorRate?: number, uptime?: number}>} services
 * @returns {{ overallScore: number, status: string, breakdown: object[], degraded: string[], critical: string[] }}
 */
function evaluateLiveCloudStatus(services) {
  if (!Array.isArray(services) || services.length === 0) {
    return {
      overallScore: 0,
      status:       'UNKNOWN',
      breakdown:    [],
      degraded:     [],
      critical:     [],
    };
  }

  const breakdown = services.map(svc => {
    const healthyScore  = svc.healthy   ? 1.0 : 0.0;
    const latencyScore  = svc.latencyMs !== undefined
      ? Math.max(0, 1 - svc.latencyMs / 2000)  // 0ms = 1.0, 2000ms = 0.0
      : 0.8; // unknown → assume decent
    const errorScore    = svc.errorRate !== undefined
      ? Math.max(0, 1 - svc.errorRate)
      : 0.9;
    const uptimeScore   = svc.uptime !== undefined
      ? Math.min(svc.uptime, 1.0)
      : 0.95;

    // Phi-weighted composite score
    const score = (
      healthyScore  * 0.40 +
      latencyScore  * 0.25 +
      errorScore    * 0.25 +
      uptimeScore   * 0.10
    );

    let status = 'HEALTHY';
    if (score < HEALTH_THRESHOLDS.CRITICAL) status = 'CRITICAL';
    else if (score < HEALTH_THRESHOLDS.DEGRADED) status = 'DEGRADED';

    return {
      serviceId:    svc.id,
      score:        parseFloat(score.toFixed(4)),
      status,
      components: {
        healthyScore,
        latencyScore:  parseFloat(latencyScore.toFixed(4)),
        errorScore:    parseFloat(errorScore.toFixed(4)),
        uptimeScore:   parseFloat(uptimeScore.toFixed(4)),
      },
    };
  });

  const overallScore = breakdown.reduce((s, b) => s + b.score, 0) / breakdown.length;

  let overallStatus = 'HEALTHY';
  if (overallScore < HEALTH_THRESHOLDS.CRITICAL)  overallStatus = 'CRITICAL';
  else if (overallScore < HEALTH_THRESHOLDS.DEGRADED) overallStatus = 'DEGRADED';

  const degraded  = breakdown.filter(b => b.status === 'DEGRADED').map(b => b.serviceId);
  const critical  = breakdown.filter(b => b.status === 'CRITICAL').map(b => b.serviceId);

  logger.info('swarm-intelligence', 'evaluateLiveCloudStatus', {
    services:  services.length,
    overallScore: overallScore.toFixed(4),
    status:    overallStatus,
    degraded:  degraded.length,
    critical:  critical.length,
  });

  return {
    overallScore: parseFloat(overallScore.toFixed(4)),
    status:       overallStatus,
    breakdown,
    degraded,
    critical,
  };
}

// ─── swarmVote ────────────────────────────────────────────────────────────────

/**
 * Democratic voting among agents on a set of proposals.
 *
 * @param {Array<{id: string, description?: string}>} proposals
 * @param {Array<{id: string, weight?: number, votes: string[]}>} voters
 *   voters[i].votes is an ordered preference list of proposal IDs
 * @returns {{ winner: string|null, tally: object, participation: number, method: string }}
 */
function swarmVote(proposals, voters) {
  if (!Array.isArray(proposals) || proposals.length === 0) {
    throw new Error('proposals must be a non-empty array');
  }
  if (!Array.isArray(voters) || voters.length === 0) {
    throw new Error('voters must be a non-empty array');
  }

  const proposalIds = new Set(proposals.map(p => p.id));
  const tally = {};
  for (const p of proposals) tally[p.id] = 0;

  let totalWeight = 0;
  let participating = 0;

  for (const voter of voters) {
    const weight = typeof voter.weight === 'number' ? voter.weight : 1;
    const validVotes = (voter.votes || []).filter(v => proposalIds.has(v));

    if (validVotes.length === 0) continue;
    participating++;
    totalWeight += weight;

    // Borda count: top vote gets full weight, subsequent get phi-discounted weight
    for (let rank = 0; rank < validVotes.length; rank++) {
      const voteWeight = weight * Math.pow(1 / PHI, rank);
      tally[validVotes[rank]] += voteWeight;
    }
  }

  // Find winner
  let winner = null;
  let topScore = -Infinity;
  for (const [id, score] of Object.entries(tally)) {
    if (score > topScore) {
      topScore = score;
      winner   = id;
    }
  }

  // Normalize tally to percentages
  const normalizedTally = {};
  for (const [id, score] of Object.entries(tally)) {
    normalizedTally[id] = totalWeight > 0
      ? parseFloat((score / totalWeight * 100).toFixed(2))
      : 0;
  }

  const participation = voters.length > 0
    ? parseFloat((participating / voters.length * 100).toFixed(1))
    : 0;

  logger.info('swarm-intelligence', 'swarmVote', {
    proposals:     proposals.length,
    voters:        voters.length,
    participating,
    winner,
    topScore:      topScore.toFixed(4),
  });

  return {
    winner,
    tally:         normalizedTally,
    rawTally:      tally,
    participation,
    method:        'borda-phi-weighted',
    ts:            new Date().toISOString(),
  };
}

// ─── consensusScore ───────────────────────────────────────────────────────────

/**
 * Calculate agreement level from a set of votes.
 *
 * @param {Array<{agentId: string, vote: string, confidence?: number, weight?: number}>} votes
 * @returns {{ score: number, dominant: string|null, agreement: string, distribution: object }}
 */
function consensusScore(votes) {
  if (!Array.isArray(votes) || votes.length === 0) {
    return { score: 0, dominant: null, agreement: 'NO_VOTES', distribution: {} };
  }

  // Count weighted votes per option
  const counts = {};
  let totalWeight = 0;

  for (const v of votes) {
    const w = (typeof v.weight === 'number' ? v.weight : 1) *
              (typeof v.confidence === 'number' ? Math.max(0, Math.min(1, v.confidence)) : 1);
    counts[v.vote] = (counts[v.vote] || 0) + w;
    totalWeight += w;
  }

  if (totalWeight === 0) {
    return { score: 0, dominant: null, agreement: 'NO_WEIGHT', distribution: {} };
  }

  // Distribution as fractions
  const distribution = {};
  for (const [option, weight] of Object.entries(counts)) {
    distribution[option] = parseFloat((weight / totalWeight).toFixed(4));
  }

  // Dominant option
  let dominant = null, maxFrac = 0;
  for (const [option, frac] of Object.entries(distribution)) {
    if (frac > maxFrac) { maxFrac = frac; dominant = option; }
  }

  // Consensus score: proportion of votes on dominant option
  // Adjusted by Herfindahl–Hirschman concentration index
  const hhiSum = Object.values(distribution).reduce((s, f) => s + f * f, 0);

  // Normalize HHI: 1/n (uniform) → 0 score, 1.0 (full consensus) → 1.0 score
  const n = Object.keys(counts).length;
  const minHHI = n > 1 ? 1 / n : 1;
  const normalizedScore = n > 1
    ? (hhiSum - minHHI) / (1 - minHHI)
    : 1.0;

  const score = parseFloat(Math.max(0, Math.min(1, normalizedScore)).toFixed(4));

  let agreement = 'LOW';
  if (score >= 0.8)      agreement = 'STRONG';
  else if (score >= 0.6) agreement = 'MODERATE';
  else if (score >= 0.4) agreement = 'WEAK';

  logger.info('swarm-intelligence', 'consensusScore', {
    votes:     votes.length,
    options:   n,
    dominant,
    score,
    agreement,
  });

  return {
    score,
    dominant,
    agreement,
    distribution,
    dominantFraction: maxFrac,
    optionCount:      n,
    ts:               new Date().toISOString(),
  };
}

// ─── buildSwarmProposal ───────────────────────────────────────────────────────

/**
 * Construct a swarm proposal from a task description.
 * Utility for building proposals to pass to swarmVote.
 */
function buildSwarmProposal(id, description, metadata = {}) {
  return { id, description, metadata, createdAt: Date.now() };
}

module.exports = {
  computeSwarmAllocation,
  evaluateLiveCloudStatus,
  swarmVote,
  consensusScore,
  buildSwarmProposal,
  FIBONACCI,
  HEALTH_THRESHOLDS,
  PHI,
};
