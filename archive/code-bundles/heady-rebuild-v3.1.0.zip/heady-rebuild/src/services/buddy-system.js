/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */
'use strict';

const EventEmitter = require('events');

// ─── Personality Config ───────────────────────────────────────────────────────

const DEFAULT_PERSONALITY = Object.freeze({
  name: 'Heady',
  version: '3.1.0',
  traits: [
    'helpful',
    'always-on',
    'proactive',
    'never-average',
    'direct',
    'growth-oriented',
  ],
  tone: 'professional-yet-approachable',
  catchphrase: 'Never average. Always ready.',
  responseStyle: {
    concise: true,
    actionable: true,
    positive: true,
    empowering: true,
  },
  domains: [
    'productivity',
    'learning',
    'technical',
    'creative',
    'decision-support',
    'wellbeing',
  ],
  proactiveThresholds: {
    idleMinutes: 30,
    errorRate: 0.05,
    performanceDegradation: 0.15,
    memoryUsagePercent: 80,
  },
});

// ─── Suggestion Templates ─────────────────────────────────────────────────────

const SUGGESTION_TEMPLATES = {
  high_error_rate: (rate) =>
    `I noticed an elevated error rate of ${(rate * 100).toFixed(1)}%. I can help diagnose and remediate — want me to run a health check?`,
  idle_too_long: (minutes) =>
    `You haven't checked in for ${minutes} minutes. Ready to tackle something? I have some ideas.`,
  performance_degraded: (pct) =>
    `System performance dropped by ${(pct * 100).toFixed(1)}%. I can optimize resource allocation or identify the bottleneck.`,
  memory_high: (pct) =>
    `Memory usage is at ${pct}%. Let me help clear caches or redistribute workloads before it becomes an issue.`,
  learning_opportunity: (topic) =>
    `Based on recent patterns, ${topic} seems like a high-value area to develop. Want me to put together a learning plan?`,
  automation_possible: (task) =>
    `I've noticed you're doing "${task}" repeatedly. I can automate that — should take me about 5 minutes.`,
  pattern_insight: (pattern) =>
    `I spotted an interesting pattern: ${pattern}. This could be worth exploring.`,
  default: () =>
    `Things are running smoothly. Want to explore something new or optimize current workflows?`,
};

// ─── BuddySystem ──────────────────────────────────────────────────────────────

/**
 * HeadyBuddy Companion System
 *
 * A proactive, always-on companion that processes user messages,
 * suggests improvements based on observed state, and routes complex
 * tasks through HeadyConductor.
 */
class BuddySystem extends EventEmitter {
  /**
   * @param {object} [opts]
   * @param {object} [opts.conductor]     - HeadyConductor instance for task routing
   * @param {object} [opts.storyDriver]   - StoryDriver instance for narrative logging
   * @param {object} [opts.personality]   - Override personality config
   * @param {object} [opts.logger]        - Pino/Winston-compatible logger
   */
  constructor({ conductor, storyDriver, personality, logger } = {}) {
    super();

    this._conductor = conductor || null;
    this._storyDriver = storyDriver || null;
    this._personality = { ...DEFAULT_PERSONALITY, ...(personality || {}) };
    this._log = logger || this._defaultLogger();

    this._conversationHistory = [];
    this._maxHistoryLength = 100;
    this._sessionStart = new Date().toISOString();
    this._messageCount = 0;
  }

  // ── Private ──────────────────────────────────────────────────────────────

  _defaultLogger() {
    return {
      info:  (...a) => {},
      warn:  (...a) => console.error('[BuddySystem:WARN]',  ...a),
      error: (...a) => console.error('[BuddySystem:ERROR]', ...a),
      debug: (...a) => process.env.LOG_LEVEL === 'debug' && console.error('[BuddySystem:DEBUG]', ...a),
    };
  }

  _trimHistory() {
    if (this._conversationHistory.length > this._maxHistoryLength) {
      this._conversationHistory = this._conversationHistory.slice(-this._maxHistoryLength);
    }
  }

  _classifyIntent(message) {
    const lower = message.toLowerCase();

    if (/\b(help|how|what|explain|tell me)\b/.test(lower)) return 'question';
    if (/\b(do|run|execute|start|stop|deploy|create|build)\b/.test(lower)) return 'command';
    if (/\b(status|health|check|monitor|what('s| is) happening)\b/.test(lower)) return 'status_check';
    if (/\b(idea|suggest|recommend|improve|better|optimize)\b/.test(lower)) return 'improvement';
    if (/\b(error|broken|fix|problem|issue|fail)\b/.test(lower)) return 'troubleshoot';
    if (/\b(hello|hi|hey|sup|greet)\b/.test(lower)) return 'greeting';
    if (/\b(thanks|thank you|great|awesome|perfect)\b/.test(lower)) return 'acknowledgment';

    return 'general';
  }

  async _routeToCondutor(message, context) {
    if (!this._conductor || typeof this._conductor.chat !== 'function') {
      return null;
    }
    try {
      return await this._conductor.chat(message, context);
    } catch (err) {
      this._log.error('Conductor routing error', { error: err.message });
      return null;
    }
  }

  async _buildDirectResponse(message, context, intent) {
    const p = this._personality;
    const ts = new Date().toISOString();

    switch (intent) {
      case 'greeting':
        return {
          message: `Hey! ${p.name} here — ${p.catchphrase} What are we building today?`,
          intent,
          suggestions: await this.suggestImprovements(context),
        };

      case 'acknowledgment':
        return {
          message: `Happy to help! Let me know what's next.`,
          intent,
        };

      case 'status_check':
        return {
          message: `I'll pull the latest system status for you.`,
          intent,
          action: { type: 'tool_call', tool: 'heady_status', args: {} },
        };

      case 'troubleshoot':
        return {
          message: `Let's fix this. I'll run diagnostics and trace the issue.`,
          intent,
          action: { type: 'tool_call', tool: 'heady_health', args: {} },
        };

      case 'improvement':
        return {
          message: `I have some ideas. Let me analyze current patterns first.`,
          intent,
          suggestions: await this.suggestImprovements(context),
        };

      default:
        return {
          message: `Got it. Routing your request through Heady's reasoning layer.`,
          intent,
          routed: true,
        };
    }
  }

  // ── Public API ────────────────────────────────────────────────────────────

  /**
   * Process a user message with optional context.
   *
   * @param {string} message    - User message
   * @param {object} [context]  - Session context (userId, sessionId, metadata)
   * @returns {Promise<object>} Response object
   */
  async chat(message, context = {}) {
    if (!message || typeof message !== 'string') {
      throw new Error('Message must be a non-empty string');
    }

    this._messageCount++;
    const intent = this._classifyIntent(message);
    const ts = new Date().toISOString();

    // Add to history
    this._conversationHistory.push({
      role: 'user',
      message,
      intent,
      timestamp: ts,
      context,
    });
    this._trimHistory();

    // Log to story driver if available
    if (this._storyDriver) {
      await this._storyDriver.record('action_taken', {
        actor: context.userId || 'user',
        description: `sent buddy message with intent '${intent}'`,
        service: 'buddy-system',
      }).catch(() => {});
    }

    // Try conductor first for complex tasks
    let response = null;
    if (intent === 'command' || intent === 'general') {
      response = await this._routeToCondutor(message, context);
    }

    // Fall back to direct response
    if (!response) {
      response = await this._buildDirectResponse(message, context, intent);
    }

    // Add assistant message to history
    this._conversationHistory.push({
      role: 'assistant',
      message: response.message,
      intent,
      timestamp: new Date().toISOString(),
    });

    this.emit('message', { userMessage: message, response, intent, context });

    return {
      ...response,
      timestamp: ts,
      sessionMessages: this._messageCount,
    };
  }

  /**
   * Get the current buddy personality configuration.
   * @returns {object}
   */
  getPersonality() {
    return { ...this._personality };
  }

  /**
   * Generate proactive improvement suggestions based on the user/system state.
   *
   * @param {object} [userState]
   * @param {number}  [userState.errorRate]             - Current error rate (0-1)
   * @param {number}  [userState.idleMinutes]           - Minutes since last activity
   * @param {number}  [userState.performanceDegradation] - Performance drop (0-1)
   * @param {number}  [userState.memoryUsagePercent]    - Memory usage percentage
   * @param {string[]} [userState.recentTasks]          - Recent task types for pattern analysis
   * @returns {Promise<Array<{ priority: string, message: string, action: string }>>}
   */
  async suggestImprovements(userState = {}) {
    const suggestions = [];
    const thresholds = this._personality.proactiveThresholds;

    if (userState.errorRate && userState.errorRate > thresholds.errorRate) {
      suggestions.push({
        priority: 'high',
        category: 'reliability',
        message: SUGGESTION_TEMPLATES.high_error_rate(userState.errorRate),
        action: 'heady_health',
      });
    }

    if (userState.idleMinutes && userState.idleMinutes > thresholds.idleMinutes) {
      suggestions.push({
        priority: 'low',
        category: 'engagement',
        message: SUGGESTION_TEMPLATES.idle_too_long(userState.idleMinutes),
        action: 'heady_status',
      });
    }

    if (userState.performanceDegradation && userState.performanceDegradation > thresholds.performanceDegradation) {
      suggestions.push({
        priority: 'medium',
        category: 'performance',
        message: SUGGESTION_TEMPLATES.performance_degraded(userState.performanceDegradation),
        action: 'heady_conductor_route',
      });
    }

    if (userState.memoryUsagePercent && userState.memoryUsagePercent > thresholds.memoryUsagePercent) {
      suggestions.push({
        priority: 'medium',
        category: 'resources',
        message: SUGGESTION_TEMPLATES.memory_high(userState.memoryUsagePercent),
        action: 'heady_health',
      });
    }

    if (userState.recentTasks && userState.recentTasks.length > 0) {
      // Detect repetitive tasks
      const taskCounts = {};
      for (const task of userState.recentTasks) {
        taskCounts[task] = (taskCounts[task] || 0) + 1;
      }
      const mostFrequent = Object.entries(taskCounts).sort((a, b) => b[1] - a[1])[0];
      if (mostFrequent && mostFrequent[1] >= 3) {
        suggestions.push({
          priority: 'medium',
          category: 'automation',
          message: SUGGESTION_TEMPLATES.automation_possible(mostFrequent[0]),
          action: 'heady_pipeline_run',
        });
      }
    }

    // Always provide a default if no specific suggestions
    if (suggestions.length === 0) {
      suggestions.push({
        priority: 'low',
        category: 'general',
        message: SUGGESTION_TEMPLATES.default(),
        action: 'heady_status',
      });
    }

    return suggestions;
  }

  /**
   * Get conversation history.
   *
   * @param {number} [limit=20]
   * @returns {object[]}
   */
  getHistory(limit = 20) {
    return this._conversationHistory.slice(-limit);
  }

  /**
   * Get session statistics.
   * @returns {object}
   */
  getSessionStats() {
    return {
      sessionStart: this._sessionStart,
      messageCount: this._messageCount,
      historyLength: this._conversationHistory.length,
      conductorAttached: !!this._conductor,
      storyDriverAttached: !!this._storyDriver,
      personality: this._personality.name,
    };
  }

  /**
   * Clear conversation history.
   */
  clearHistory() {
    this._conversationHistory = [];
    this._messageCount = 0;
    this._sessionStart = new Date().toISOString();
  }
}

module.exports = BuddySystem;
