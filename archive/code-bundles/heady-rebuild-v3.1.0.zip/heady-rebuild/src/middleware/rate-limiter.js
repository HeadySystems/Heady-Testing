/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

/**
 * @fileoverview Sliding-window rate limiter for the Heady™ AI Platform.
 * Uses an in-memory Map for storage. Configurable per-route windows and
 * request limits. No external dependencies required.
 * @module src/middleware/rate-limiter
 */

const { createLogger } = require('../utils/logger');

const logger = createLogger('middleware:rate-limiter');

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/**
 * @typedef {Object} RateLimitOptions
 * @property {number} [windowMs=60000] - Sliding window duration in ms
 * @property {number} [max=100] - Maximum requests per window
 * @property {string} [keyPrefix='rl'] - Prefix for the store key namespace
 * @property {Function} [keyGenerator] - (req) => string — derives a client key
 * @property {Function} [skip] - (req) => boolean — skip rate limiting for request
 * @property {string} [message] - Custom rejection message
 * @property {number} [statusCode=429] - HTTP status on rejection
 */

/**
 * @typedef {Object} RateLimitEntry
 * @property {number[]} timestamps - Sorted array of request timestamps (epoch ms)
 */

// ---------------------------------------------------------------------------
// Global in-memory store
// ---------------------------------------------------------------------------

/** @type {Map<string, RateLimitEntry>} */
const _store = new Map();

/** Cleanup interval handle. */
let _cleanupHandle = null;

/**
 * Purges expired entries from the store to prevent unbounded memory growth.
 * @param {number} maxWindowMs - The maximum window used across all limiters
 */
function _garbageCollect(maxWindowMs) {
  const cutoff = Date.now() - maxWindowMs;
  for (const [key, entry] of _store) {
    // Remove timestamps older than the window
    entry.timestamps = entry.timestamps.filter((t) => t > cutoff);
    if (entry.timestamps.length === 0) {
      _store.delete(key);
    }
  }
}

/**
 * Starts the background garbage collection interval.
 * @param {number} intervalMs
 */
function startGarbageCollection(intervalMs = 60000) {
  if (_cleanupHandle) return;
  _cleanupHandle = setInterval(() => _garbageCollect(intervalMs * 2), intervalMs);
  if (_cleanupHandle.unref) _cleanupHandle.unref(); // Don't block process exit
  logger.debug('Rate limiter GC started', { intervalMs });
}

// ---------------------------------------------------------------------------
// Default key generator
// ---------------------------------------------------------------------------

/**
 * Extracts the client IP from a request, respecting common proxy headers.
 * @param {import('http').IncomingMessage} req
 * @returns {string}
 */
function defaultKeyGenerator(req) {
  const forwarded = req.headers['x-forwarded-for'];
  if (forwarded) {
    // Take the first (client) IP from the chain
    return forwarded.split(',')[0].trim();
  }
  return req.socket?.remoteAddress || 'unknown';
}

// ---------------------------------------------------------------------------
// Sliding window counter
// ---------------------------------------------------------------------------

/**
 * Records a new request and returns the current count within the window.
 * Uses the sliding window algorithm (not fixed window) for accuracy.
 *
 * @param {string} key - Store key
 * @param {number} windowMs - Window size in ms
 * @param {number} now - Current timestamp
 * @returns {{ count: number, oldestTs: number|null, resetMs: number }}
 */
function _recordHit(key, windowMs, now) {
  const cutoff = now - windowMs;
  let entry = _store.get(key);

  if (!entry) {
    entry = { timestamps: [] };
    _store.set(key, entry);
  }

  // Evict timestamps outside the window
  entry.timestamps = entry.timestamps.filter((t) => t > cutoff);

  // Record this request
  entry.timestamps.push(now);

  const oldest = entry.timestamps[0] || now;
  const resetMs = Math.max(0, oldest + windowMs - now);

  return {
    count: entry.timestamps.length,
    oldestTs: oldest,
    resetMs,
  };
}

// ---------------------------------------------------------------------------
// Middleware factory
// ---------------------------------------------------------------------------

/**
 * Creates a rate-limiting middleware for a specific route pattern.
 *
 * @param {RateLimitOptions} [options={}]
 * @returns {Function} Middleware (req, res, next) => void
 *
 * @example
 * // Limit /api/pipeline/run to 10 requests per minute
 * server.use('/api/pipeline/run', rateLimiter({ max: 10, windowMs: 60000 }));
 */
function rateLimiter(options = {}) {
  const {
    windowMs = 60000,
    max = 100,
    keyPrefix = 'rl',
    keyGenerator = defaultKeyGenerator,
    skip = null,
    message = 'Too many requests — please try again later.',
    statusCode = 429,
  } = options;

  // Ensure GC is running
  startGarbageCollection(windowMs);

  return function rateLimit(req, res, next) {
    // Optional skip function
    if (typeof skip === 'function' && skip(req)) {
      return next();
    }

    const now = Date.now();
    const clientKey = keyGenerator(req);
    const storeKey = `${keyPrefix}:${clientKey}`;

    const { count, resetMs } = _recordHit(storeKey, windowMs, now);

    const remaining = Math.max(0, max - count);
    const resetEpoch = Math.ceil((now + resetMs) / 1000);

    // Always set rate limit headers
    res.setHeader('X-Heady-Rate-Limit-Limit', String(max));
    res.setHeader('X-Heady-Rate-Limit-Remaining', String(remaining));
    res.setHeader('X-Heady-Rate-Limit-Reset', String(resetEpoch));
    res.setHeader('X-Heady-Rate-Limit-Window', String(windowMs));

    if (count > max) {
      res.setHeader('Retry-After', String(Math.ceil(resetMs / 1000)));
      logger.warn('Rate limit exceeded', {
        key: storeKey,
        count,
        max,
        windowMs,
        path: req.url,
        method: req.method,
      });
      res.writeHead(statusCode, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        error: 'Rate limit exceeded',
        message,
        retryAfterMs: resetMs,
        resetAt: new Date(now + resetMs).toISOString(),
      }));
      return;
    }

    next();
  };
}

// ---------------------------------------------------------------------------
// Pre-built limiters for common routes
// ---------------------------------------------------------------------------

/**
 * Returns a standard API rate limiter (300 req/min).
 * @returns {Function}
 */
function apiLimiter() {
  return rateLimiter({ windowMs: 60000, max: 300, keyPrefix: 'api' });
}

/**
 * Returns a pipeline rate limiter (10 req/min — expensive operations).
 * @returns {Function}
 */
function pipelineLimiter() {
  return rateLimiter({ windowMs: 60000, max: 10, keyPrefix: 'pipeline', message: 'Pipeline rate limit exceeded. Pipelines are resource-intensive; please wait before retrying.' });
}

/**
 * Returns a battle/simulation rate limiter (5 req/min).
 * @returns {Function}
 */
function battleLimiter() {
  return rateLimiter({ windowMs: 60000, max: 5, keyPrefix: 'battle', message: 'Battle simulation rate limit exceeded.' });
}

/**
 * Returns a health-check rate limiter (600 req/min — generous for probes).
 * @returns {Function}
 */
function healthLimiter() {
  return rateLimiter({ windowMs: 60000, max: 600, keyPrefix: 'health' });
}

// ---------------------------------------------------------------------------
// Store inspection (for metrics / admin)
// ---------------------------------------------------------------------------

/**
 * Returns the current number of tracked client keys.
 * @returns {number}
 */
function getStoreSize() {
  return _store.size;
}

/**
 * Returns hit count for a specific client key prefix.
 * @param {string} key
 * @param {number} [windowMs=60000]
 * @returns {number}
 */
function getHitCount(key, windowMs = 60000) {
  const entry = _store.get(key);
  if (!entry) return 0;
  const cutoff = Date.now() - windowMs;
  return entry.timestamps.filter((t) => t > cutoff).length;
}

/**
 * Clears all rate limit data (useful in tests).
 */
function clearStore() {
  _store.clear();
}

module.exports = {
  rateLimiter,
  apiLimiter,
  pipelineLimiter,
  battleLimiter,
  healthLimiter,
  defaultKeyGenerator,
  getStoreSize,
  getHitCount,
  clearStore,
  startGarbageCollection,
};
