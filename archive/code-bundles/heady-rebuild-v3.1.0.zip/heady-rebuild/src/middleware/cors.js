/**
 * © 2024-2026 HeadySystems Inc. All Rights Reserved.
 * PROPRIETARY AND CONFIDENTIAL.
 */

'use strict';

/**
 * @fileoverview CORS middleware for the Heady™ AI Platform.
 * Allows requests only from registered Heady custom domains.
 * Localhost is explicitly denied in all environments.
 * @module src/middleware/cors
 */

const { isAllowedOrigin, ALL_ALLOWED_ORIGINS } = require('../config/domains');
const { createLogger } = require('../utils/logger');

const logger = createLogger('middleware:cors');

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** HTTP methods allowed in CORS preflight. */
const ALLOWED_METHODS = 'GET, POST, PUT, PATCH, DELETE, OPTIONS, HEAD';

/** Headers that the browser may send. */
const ALLOWED_HEADERS = [
  'Content-Type',
  'Authorization',
  'X-Requested-With',
  'X-Heady-Correlation-Id',
  'X-Heady-Api-Key',
  'X-Heady-Node',
  'X-Heady-Version',
  'Accept',
  'Accept-Language',
  'Cache-Control',
].join(', ');

/** Headers exposed to the browser from the response. */
const EXPOSED_HEADERS = [
  'X-Heady-Correlation-Id',
  'X-Heady-Node',
  'X-Heady-Version',
  'X-Heady-Rate-Limit-Remaining',
  'X-Heady-Rate-Limit-Reset',
  'X-Request-Id',
  'Content-Length',
  'Content-Type',
].join(', ');

/** Max age for preflight cache in seconds (1 hour). */
const MAX_AGE = '3600';

/** Platform version injected into every response. */
const PLATFORM_VERSION = '3.1.0';

// ---------------------------------------------------------------------------
// Helper: detect localhost attempts
// ---------------------------------------------------------------------------

/**
 * Returns true if the origin looks like localhost or a loopback.
 * @param {string} origin
 * @returns {boolean}
 */
function isLocalhostOrigin(origin) {
  if (!origin) return false;
  try {
    const url = new URL(origin);
    const h = url.hostname;
    return (
      h === 'localhost' ||
      h === '127.0.0.1' ||
      h === '::1' ||
      h.endsWith('.localhost') ||
      h.startsWith('192.168.') ||
      h.startsWith('10.') ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(h)
    );
  } catch (_) {
    return false;
  }
}

// ---------------------------------------------------------------------------
// Core CORS applier
// ---------------------------------------------------------------------------

/**
 * Applies CORS headers to a response.
 * If the request Origin is an allowed Heady domain, sets specific headers.
 * If Origin is absent (direct API call), allows the request without CORS headers.
 * Localhost origins always receive 403.
 *
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 * @returns {'allow'|'deny'|'preflight'} Action taken
 */
function applyCors(req, res) {
  const origin = req.headers['origin'];
  const method = req.method;

  // Always inject Heady version header
  res.setHeader('X-Heady-Version', PLATFORM_VERSION);
  res.setHeader('X-Heady-Node', process.env.HEADY_NODE_NAME || 'heady-primary');

  // No Origin header — direct request (e.g. curl, server-to-server)
  if (!origin) {
    return 'allow';
  }

  // Explicitly deny localhost
  if (isLocalhostOrigin(origin)) {
    logger.warn('CORS blocked localhost origin', { origin, path: req.url });
    res.writeHead(403, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Forbidden', reason: 'localhost origins are not permitted' }));
    return 'deny';
  }

  // Check against allowed origins
  if (!isAllowedOrigin(origin)) {
    logger.warn('CORS blocked disallowed origin', { origin, path: req.url });
    res.writeHead(403, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Forbidden', reason: 'origin not in Heady domain allowlist' }));
    return 'deny';
  }

  // Allowed origin — set CORS headers
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Methods', ALLOWED_METHODS);
  res.setHeader('Access-Control-Allow-Headers', ALLOWED_HEADERS);
  res.setHeader('Access-Control-Expose-Headers', EXPOSED_HEADERS);
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Max-Age', MAX_AGE);
  res.setHeader('Vary', 'Origin');

  // Handle preflight OPTIONS
  if (method === 'OPTIONS') {
    res.writeHead(204, { 'Content-Length': '0' });
    res.end();
    return 'preflight';
  }

  return 'allow';
}

// ---------------------------------------------------------------------------
// Middleware factory
// ---------------------------------------------------------------------------

/**
 * Returns a middleware function compatible with HeadyServer's pipeline.
 * Calls next() if the origin is allowed, otherwise ends the response.
 *
 * @returns {Function} Middleware (req, res, next) => void
 */
function corsMiddleware() {
  return function cors(req, res, next) {
    const action = applyCors(req, res);
    if (action === 'deny') return; // Response already sent
    if (action === 'preflight') return; // Response already sent
    next();
  };
}

/**
 * Returns the full list of allowed origins for diagnostics.
 * @returns {string[]}
 */
function getAllowedOrigins() {
  return [...ALL_ALLOWED_ORIGINS];
}

module.exports = {
  corsMiddleware,
  applyCors,
  getAllowedOrigins,
  isLocalhostOrigin,
  ALLOWED_METHODS,
  ALLOWED_HEADERS,
  EXPOSED_HEADERS,
};
