---
name: health-monitoring-probes
description: Use when the user needs kubernetes-compatible health probes patterns or guidance derived from the HeadyMe repository. Keywords include health, monitoring, probes, Heady, nodes, components, workflows, and the repo modules evidenced by src/routes/health-routes.js, src/bees/health-bee.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Kubernetes-Compatible Health Probes

## When to Use This Skill

- Use when the user needs liveness, readiness, or deep health check design for services, workers, or infrastructure.
- Use when the user wants probe-compatible monitoring for orchestrated systems.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- Comprehensive health check system with three endpoints: /health/live (liveness probe), /health/ready (readiness probe), and /health/full (deep introspection). Checks process health, uptime, resilience systems, filesystem, memory, event loop, vector memory, and self-awareness telemetry. Kubernetes-compatible with proper status codes and structured responses.
- Reusable value: Health probes are fundamental for containerized and orchestrated applications. This implementation provides production patterns for liveness, readiness, and deep health checks compatible with Kubernetes, load balancers, and monitoring systems. Reusable for any service requiring health monitoring, graceful degradation, or orchestration integration.
- Confidence: high

## Instructions

1. Identify which components must be checked for liveliness, readiness, and deep operational health.
2. Separate fast checks from expensive introspection.
3. Define status codes, payload shape, and dependency checks.
4. Recommend how probes should interact with deploys, autoscaling, and alerting.
5. Return a clear probe model and verification checklist.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/routes/health-routes.js`
- `src/bees/health-bee.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/routes/health-routes.js

## Example Triggers

- Help me design a kubernetes-compatible health probes pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the health monitoring probes pattern

## Template

Use the template file in `templates/health-probe-template.md` for structured work.
