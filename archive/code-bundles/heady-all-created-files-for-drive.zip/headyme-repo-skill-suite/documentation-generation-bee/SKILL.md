---
name: documentation-generation-bee
description: Use when the user needs automated documentation generation patterns or guidance derived from the HeadyMe repository. Keywords include documentation, generation, bee, Heady, nodes, components, workflows, and the repo modules evidenced by src/bees/documentation-bee.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'medium'
---

# Automated Documentation Generation

## When to Use This Skill

- Use when the user needs automated technical documentation generation from code structure, services, or workflows.
- Use when nodes or components should produce maintainable docs as part of the system.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- An agent-based system for generating and maintaining documentation. The documentation-bee.js analyzes code, generates API docs, creates README files, and maintains documentation currency. Can be integrated into CI/CD pipelines for automatic documentation updates on code changes.
- Reusable value: Automated documentation generation reduces maintenance burden and improves code quality. This bee-based pattern provides a framework for analyzing codebases and generating structured documentation. Reusable for any development workflow, open-source project, or documentation pipeline requiring automation.
- Confidence: medium

## Instructions

1. Identify the code surface, workflows, or APIs that need documentation.
2. Separate architecture docs, operator docs, and developer reference materials.
3. Recommend extraction patterns for routes, interfaces, dependencies, and operational steps.
4. Prefer concise, update-friendly documentation formats.
5. Return a documentation plan with coverage priorities and refresh strategy.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/bees/documentation-bee.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/bees/documentation-bee.js

## Example Triggers

- Help me design a automated documentation generation pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the documentation generation bee pattern

## Template

Use the template file in `templates/documentation-plan-template.md` for structured work.
