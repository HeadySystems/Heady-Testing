---
name: cloud-deployment-automation
description: Use when the user needs multi-platform cloud deployment automation patterns or guidance derived from the HeadyMe repository. Keywords include cloud, deployment, automation, Heady, nodes, components, workflows, and the repo modules evidenced by src/bees/cloud-run-deployer-bee.js, src/bees/full-cloud-deploy-swarm-bee.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Multi-Platform Cloud Deployment Automation

## When to Use This Skill

- Use when the user needs multi-cloud deployment workflows, automated rollout planning, or coordinated release operations across Cloud Run, Workers, or containers.
- Use when services must be projected or deployed automatically from a main codebase.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- Automated deployment system supporting Google Cloud Run, Cloudflare Workers, and HuggingFace Spaces. Includes cloud-run-deployer-bee.js, full-cloud-deploy-swarm-bee.js, and deployment-bee.js for orchestrated deployments. Integrates with GitHub Actions for CI/CD, Docker for containerization, and Terraform for IaC. Features autonomous projection pattern where services are automatically deployed from the main codebase.
- Reusable value: Multi-platform deployment automation is essential for modern DevOps. This implementation provides patterns for orchestrating deployments across multiple cloud platforms, managing containers, and automating infrastructure. Reusable for any application requiring automated deployment, infrastructure as code, or multi-cloud strategies.
- Confidence: high

## Instructions

1. Identify target platforms, deployment artifacts, environments, and release triggers.
2. Map the build, test, deploy, and verification sequence.
3. Recommend rollback paths, health checks, and secrets handling.
4. Call out where GitHub Actions, Docker, or IaC should coordinate the release.
5. Return a deployment automation plan with platform-specific notes.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/bees/cloud-run-deployer-bee.js`
- `src/bees/full-cloud-deploy-swarm-bee.js`
- `src/bees/deployment-bee.js`
- `.github/workflows/deploy.yml`
- `Dockerfile`

### Evidence URLs

- https://github.com/HeadyMe/headyme-core/blob/main/.github/workflows/deploy.yml
- https://github.com/HeadyMe/headyme-core/blob/main/Dockerfile

## Example Triggers

- Help me design a multi-platform cloud deployment automation pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the cloud deployment automation pattern

## Template

Use the template file in `templates/deployment-automation-template.md` for structured work.
