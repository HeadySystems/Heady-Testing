---
name: swarm-consensus-intelligence
description: Use when the user needs swarm consensus and intelligence patterns or guidance derived from the HeadyMe repository. Keywords include swarm, consensus, intelligence, Heady, nodes, components, workflows, and the repo modules evidenced by src/orchestration/swarm-consensus.js, src/orchestration/swarm-intelligence.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'medium'
---

# Swarm Consensus and Intelligence

## When to Use This Skill

- Use when the user needs multi-agent coordination, consensus design, or swarm decision-making patterns.
- Use when several nodes or workers must agree, rank options, or converge on a plan.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A swarm intelligence system implementing consensus protocols for multi-agent coordination. Includes swarm-consensus.js for reaching agreement among agents, swarm-intelligence.js for collective decision-making, and swarm-ignition.js for initializing swarm behaviors. Enables emergent intelligence from coordinated agent behaviors.
- Reusable value: Swarm intelligence enables powerful collective behaviors from simple agents. This implementation provides patterns for multi-agent consensus, distributed decision-making, and emergent coordination. Reusable for distributed AI systems, multi-agent simulations, collaborative filtering, or any system requiring collective intelligence.
- Confidence: medium

## Instructions

1. Identify the agents, their scopes, and the decisions they must coordinate on.
2. Specify how proposals are generated, compared, voted on, or merged.
3. Define tie-breaking, deadlock resolution, and escalation logic.
4. Recommend observability so consensus quality can be audited.
5. Return a swarm coordination model with failure modes and next steps.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/orchestration/swarm-consensus.js`
- `src/orchestration/swarm-intelligence.js`
- `src/orchestration/swarm-ignition.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/orchestration/swarm-consensus.js

## Example Triggers

- Help me design a swarm consensus and intelligence pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the swarm consensus intelligence pattern

## Template

Use the template file in `templates/swarm-consensus-template.md` for structured work.
