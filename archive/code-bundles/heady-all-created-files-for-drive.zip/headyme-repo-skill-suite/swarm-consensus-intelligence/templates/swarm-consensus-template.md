# Swarm Consensus Plan

## Agents

## Shared Decision

## Proposal Flow

## Consensus Rule

## Deadlock Handling

## Audit Signals
