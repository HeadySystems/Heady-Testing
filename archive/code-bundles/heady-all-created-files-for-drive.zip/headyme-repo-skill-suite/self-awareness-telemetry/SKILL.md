---
name: self-awareness-telemetry
description: Use when the user needs self-awareness telemetry loop patterns or guidance derived from the HeadyMe repository. Keywords include self, awareness, telemetry, Heady, nodes, components, workflows, and the repo modules evidenced by src/self-awareness.js, src/vector-memory.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Self-Awareness Telemetry Loop

## When to Use This Skill

- Use when the user wants self-monitoring, introspection, adaptive telemetry, or metacognitive control loops for Heady nodes or agents.
- Use when the user needs a system to observe itself and change behavior based on runtime state.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- An Internal Monologue Loop that continuously monitors system telemetry, ingests metrics into a ring buffer, stores observations in vector memory, and performs confidence scoring. Enables metacognition by allowing the system to introspect its own state, detect anomalies, and adjust behavior dynamically. Integrates with the self-awareness.js module for real-time system introspection.
- Reusable value: Self-awareness and metacognition are powerful patterns for building adaptive systems. This telemetry loop enables systems to monitor their own performance, detect degradation, and self-heal. Reusable for observability platforms, autonomous systems, self-tuning applications, or any system requiring adaptive behavior based on runtime metrics.
- Confidence: high

## Instructions

1. Define which runtime signals matter most: latency, errors, confidence, saturation, drift, or policy violations.
2. Describe how observations should be buffered, scored, and persisted.
3. Recommend loops for introspection, anomaly detection, and behavior adjustment.
4. Connect telemetry outputs to decision logic, alerts, or autonomous corrections.
5. Return an adaptive monitoring design with measurable thresholds and next steps.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/self-awareness.js`
- `src/vector-memory.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/self-awareness.js

## Example Triggers

- Help me design a self-awareness telemetry loop pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the self awareness telemetry pattern

## Template

Use the template file in `templates/telemetry-loop-template.md` for structured work.
