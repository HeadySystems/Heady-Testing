---
name: phi-exponential-backoff
description: Use when the user needs golden ratio exponential backoff patterns or guidance derived from the HeadyMe repository. Keywords include phi, exponential, backoff, Heady, nodes, components, workflows, and the repo modules evidenced by src/resilience/exponential-backoff.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Golden Ratio Exponential Backoff

## When to Use This Skill

- Use when the user needs retry logic, cooldown timing, or backoff strategies for Heady services, APIs, queues, or orchestration loops.
- Use when the user wants golden-ratio-inspired timing instead of basic doubling.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A retry mechanism using φ (Golden Ratio, PHI = 1.618...) as the scaling factor for exponential backoff delays. Produces the sequence: 1s → 1.6s → 2.6s → 4.2s → 6.9s → 11.1s → 17.9s → 29s. This 'Sacred Geometry' approach provides optimal spacing between retry attempts based on mathematical harmony, balancing aggressive retries with respectful backoff.
- Reusable value: A novel approach to exponential backoff that's more sophisticated than standard 2x doubling. The φ-based scaling creates natural, harmonious intervals that can improve retry patterns in distributed systems. Reusable for any retry logic, API rate limiting, circuit breaker recovery, or backpressure handling. The mathematical elegance makes delays more predictable and tunable.
- Confidence: high

## Instructions

1. Clarify the retry context, error class, rate-limit profile, and acceptable latency.
2. Map retry phases using phi-scaled intervals and explain the tradeoff versus linear or 2x exponential delays.
3. Specify max attempts, jitter strategy if needed, reset conditions, and visibility requirements.
4. Recommend guardrails to avoid retry storms and thundering herd behavior.
5. Return a practical timing schedule and integration notes.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/resilience/exponential-backoff.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/resilience/exponential-backoff.js

## Example Triggers

- Help me design a golden ratio exponential backoff pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the phi exponential backoff pattern

## Template

Use the template file in `templates/backoff-plan-template.md` for structured work.
