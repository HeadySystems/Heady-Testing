---
name: heady-bee-agent-factory
description: Use when the user needs dynamic agent worker factory patterns or guidance derived from the HeadyMe repository. Keywords include heady, bee, agent, factory, Heady, nodes, components, workflows, and the repo modules evidenced by src/bees/bee-factory.js, src/bees/registry.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Dynamic Agent Worker Factory

## When to Use This Skill

- Use when the user wants to design, refactor, or reason about specialized agent workers, dynamic worker creation, or task decomposition into focused nodes.
- Use when the user is building a swarm, registry, worker lifecycle, or runtime agent factory pattern.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A factory pattern for creating and managing specialized agent workers (called 'bees') at runtime. Supports 24 domains with 197 workers, providing dynamic bee creation via createBee() and ephemeral bee spawning via spawnBee(). Each bee is a focused, single-purpose agent that can be instantiated with custom configuration (e.g., interval, target, context). Includes central registry for bee discovery and lifecycle management.
- Reusable value: The bee factory pattern is a reusable abstraction for decomposing complex AI workflows into specialized, single-purpose agents. This pattern enables dynamic scaling, hot-swapping of capabilities, and modular agent composition. Applicable to any multi-agent system requiring task delegation, specialized workers, or domain decomposition.
- Confidence: high

## Instructions

1. Identify the domains, tasks, or behaviors that should become specialized workers.
2. Define clear worker boundaries, inputs, outputs, lifecycle hooks, and registration patterns.
3. Recommend when to use persistent workers versus ephemeral spawned workers.
4. Prefer a registry or discovery model so workers can be enumerated, routed, and observed consistently.
5. Return concrete worker roles, orchestration flow, and next implementation steps.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/bees/bee-factory.js`
- `src/bees/registry.js`
- `src/orchestration/heady-bees.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/bees/bee-factory.js
- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/bees/registry.js

## Example Triggers

- Help me design a dynamic agent worker factory pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the heady bee agent factory pattern

## Template

Use the template file in `templates/agent-factory-template.md` for structured work.
