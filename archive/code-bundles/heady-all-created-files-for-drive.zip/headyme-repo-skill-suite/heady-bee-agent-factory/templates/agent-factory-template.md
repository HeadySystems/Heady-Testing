# Agent Factory Design

## Goal

## Worker Domains

## Registry Model

## Lifecycle

## Routing Rules

## Observability

## Next Build Steps
