---
name: mcp-protocol-integration
description: Use when the user needs model context protocol (mcp) integration patterns or guidance derived from the HeadyMe repository. Keywords include mcp, protocol, integration, Heady, nodes, components, workflows, and the repo modules evidenced by src/bees/mcp-bee.js, heady-manager.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Model Context Protocol (MCP) Integration

## When to Use This Skill

- Use when the user needs Model Context Protocol design, tool registration, model-tool interoperability, or MCP client/server planning.
- Use when the user wants to connect Heady services to MCP-capable ecosystems.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- Implementation of the Model Context Protocol as both client and server with tool registry support. Enables standardized communication between AI models and external tools/services. Provides bidirectional MCP support for sending context to models and receiving tool invocation requests. Includes mcp-bee.js for bee-based MCP orchestration.
- Reusable value: MCP is an emerging standard for AI model integration. This implementation provides production patterns for MCP client/server setup, tool registration, and context management. Reusable for any AI application requiring tool use, function calling, or integration with external services through standardized protocols.
- Confidence: high

## Instructions

1. Clarify whether the system is acting as an MCP client, server, or both.
2. Define the tools, schemas, auth flow, transport, and context boundaries.
3. Recommend registry, discovery, and failure-handling patterns for tools.
4. Call out compatibility, observability, and security requirements.
5. Return a practical MCP integration blueprint with next build steps.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/bees/mcp-bee.js`
- `heady-manager.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/bees/mcp-bee.js

## Example Triggers

- Help me design a model context protocol (mcp) integration pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the mcp protocol integration pattern

## Template

Use the template file in `templates/mcp-integration-template.md` for structured work.
