---
name: monte-carlo-simulation
description: Use when the user needs monte carlo simulation engine patterns or guidance derived from the HeadyMe repository. Keywords include monte, carlo, simulation, Heady, nodes, components, workflows, and the repo modules evidenced by src/monte-carlo.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'medium'
---

# Monte Carlo Simulation Engine

## When to Use This Skill

- Use when the user wants probabilistic modeling, uncertainty analysis, or simulation-based decision support.
- Use when a system or workflow should be evaluated through repeated randomized trials.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A Monte Carlo simulation engine integrated into the pipeline's MONTE_CARLO stage. Performs probabilistic simulation for decision-making, risk assessment, and outcome prediction. Part of the 12-stage HCFullPipeline, used for evaluating multiple scenarios before committing to decisions.
- Reusable value: Monte Carlo methods are powerful for uncertainty quantification and decision support. This implementation provides a framework for probabilistic simulations within workflow pipelines. Reusable for financial modeling, risk assessment, optimization problems, or any decision-making system requiring scenario analysis.
- Confidence: medium

## Instructions

1. Clarify the uncertain variables, distributions, constraints, and success metrics.
2. Recommend simulation count, sensitivity analysis, and output summaries.
3. Separate assumptions from measured inputs.
4. Explain how results should influence decisions, approvals, or resource allocation.
5. Return a simulation plan with model variables and interpretation guidance.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/monte-carlo.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/monte-carlo.js

## Example Triggers

- Help me design a monte carlo simulation engine pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the monte carlo simulation pattern

## Template

Use the template file in `templates/monte-carlo-template.md` for structured work.
