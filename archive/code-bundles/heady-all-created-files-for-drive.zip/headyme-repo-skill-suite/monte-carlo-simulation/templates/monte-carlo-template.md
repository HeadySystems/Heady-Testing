# Monte Carlo Plan

## Decision Question

## Variables

## Assumptions

## Simulation Design

## Outputs

## Decision Use
