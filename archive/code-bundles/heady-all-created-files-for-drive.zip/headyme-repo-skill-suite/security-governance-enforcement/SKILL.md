---
name: security-governance-enforcement
description: Use when the user needs security and governance enforcement patterns or guidance derived from the HeadyMe repository. Keywords include security, governance, enforcement, Heady, nodes, components, workflows, and the repo modules evidenced by src/bees/security-bee.js, src/bees/governance-bee.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Security and Governance Enforcement

## When to Use This Skill

- Use when the user needs security controls, governance checks, credential handling, or policy enforcement around Heady services and agents.
- Use when systems need operational guardrails before execution.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A comprehensive security system with security-bee.js for security enforcement, governance-bee.js for policy compliance, and credential-bee.js for credential management. Integrates with CodeQL SAST, Gitleaks, SBOM scanning, and pre-commit hooks. Implements policy-engine.js for declarative security rules and rulez-gatekeeper.js for access control.
- Reusable value: Security enforcement and governance are essential for production systems. This multi-layered approach provides patterns for credential management, policy enforcement, vulnerability scanning, and compliance checking. Reusable for any application requiring security governance, compliance automation, or DevSecOps integration.
- Confidence: high

## Instructions

1. Identify secrets, permissions, policy boundaries, and high-risk operations.
2. Separate preventive controls from detective controls.
3. Define credential handling, audit requirements, and escalation paths.
4. Recommend enforcement at build time, deploy time, and runtime where relevant.
5. Return a governance plan with concrete controls and verification steps.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/bees/security-bee.js`
- `src/bees/governance-bee.js`
- `src/bees/credential-bee.js`
- `src/policy-engine.js`
- `src/orchestration/rulez-gatekeeper.js`
- `.github/workflows/security-scan.yml`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/.github/workflows/security-scan.yml

## Example Triggers

- Help me design a security and governance enforcement pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the security governance enforcement pattern

## Template

Use the template file in `templates/security-governance-template.md` for structured work.
