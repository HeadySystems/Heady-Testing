---
name: multi-stage-pipeline-orchestration
description: Use when the user needs 12-stage pipeline orchestration (hcfullpipeline) patterns or guidance derived from the HeadyMe repository. Keywords include multi, stage, pipeline, orchestration, Heady, nodes, components, workflows, and the repo modules evidenced by src/pipeline/pipeline-core.js, src/pipeline/pipeline-infra.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# 12-Stage Pipeline Orchestration (HCFullPipeline)

## When to Use This Skill

- Use when the user needs staged workflows, approval chains, execution gates, or end-to-end orchestration patterns.
- Use when the user wants to break a complex process into explicit, trackable stages.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A comprehensive 12-stage pipeline for orchestrating complex workflows: INTAKE → TRIAGE → MONTE_CARLO → ARENA → JUDGE → APPROVE → EXECUTE → VERIFY → RECEIPT. Each stage has specific responsibilities, state management, and transition logic. Supports parallel execution, stage skipping, rollback, and comprehensive state tracking.
- Reusable value: Multi-stage pipelines are fundamental for workflow orchestration, data processing, and task automation. This 12-stage pattern provides a robust framework for breaking down complex processes into manageable stages with clear boundaries. Reusable for ETL pipelines, CI/CD workflows, approval chains, content moderation, or any multi-step process requiring orchestration.
- Confidence: high

## Instructions

1. List the stages, transition rules, and ownership of each stage.
2. Define what data enters, exits, and is validated at each point.
3. Call out where parallelism, approval, rollback, or re-entry is needed.
4. Recommend clear stage success criteria and observability hooks.
5. Return a pipeline map, risks, and next implementation steps.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/pipeline/pipeline-core.js`
- `src/pipeline/pipeline-infra.js`
- `src/pipeline/pipeline-pools.js`
- `src/agents/pipeline-handlers.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/pipeline/pipeline-core.js

## Example Triggers

- Help me design a 12-stage pipeline orchestration (hcfullpipeline) pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the multi stage pipeline orchestration pattern

## Template

Use the template file in `templates/pipeline-template.md` for structured work.
