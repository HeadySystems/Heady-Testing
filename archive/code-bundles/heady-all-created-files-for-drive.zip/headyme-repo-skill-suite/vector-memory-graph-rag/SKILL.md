---
name: vector-memory-graph-rag
description: Use when the user needs 3d spatial vector memory with graph rag patterns or guidance derived from the HeadyMe repository. Keywords include vector, memory, graph, rag, Heady, nodes, components, workflows, and the repo modules evidenced by src/vector-memory.js, src/vector-space-ops.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# 3D Spatial Vector Memory with Graph RAG

## When to Use This Skill

- Use when the user needs semantic memory, embedding storage, graph-linked retrieval, or STM-to-LTM memory consolidation.
- Use when the user is designing vector memory for assistants, swarms, or context systems.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A sophisticated vector memory system implementing 3D spatial sharding, Graph RAG (Retrieval-Augmented Generation), importance scoring I(m), and STM→LTM (Short-Term Memory to Long-Term Memory) consolidation. Stores and retrieves vector embeddings with spatial awareness, graph relationships, and temporal decay. Supports semantic search and context retrieval for AI agents.
- Reusable value: Advanced vector memory systems are critical for building AI agents with long-term context retention. This implementation provides production patterns for vector storage, semantic retrieval, memory consolidation, and importance-based pruning. Reusable for chatbots, AI assistants, recommendation systems, or any application requiring semantic memory and context management.
- Confidence: high

## Instructions

1. Clarify the memory types, embedding pipeline, retrieval goals, and retention policy.
2. Map how vector similarity, graph links, and importance scoring should work together.
3. Define consolidation rules for short-term versus long-term memory.
4. Recommend pruning, sharding, and observability approaches.
5. Return a memory topology with retrieval flow and implementation priorities.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/vector-memory.js`
- `src/vector-space-ops.js`
- `src/vector-federation.js`
- `src/vector-pipeline.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/vector-memory.js

## Example Triggers

- Help me design a 3d spatial vector memory with graph rag pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the vector memory graph rag pattern

## Template

Use the template file in `templates/vector-memory-template.md` for structured work.
