---
name: buddy-watchdog-hallucination-detection
description: Use when the user needs ai hallucination detection watchdog patterns or guidance derived from the HeadyMe repository. Keywords include buddy, watchdog, hallucination, detection, Heady, nodes, components, workflows, and the repo modules evidenced by src/orchestration/buddy-watchdog.js, src/orchestration/buddy-core.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'medium'
---

# AI Hallucination Detection Watchdog

## When to Use This Skill

- Use when the user needs AI output validation, hallucination detection, or watchdog logic around autonomous agents.
- Use when the user wants confidence checks and recovery paths for unreliable model behavior.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A self-healing watchdog system that monitors AI agent outputs for hallucinations, inconsistencies, and errors. Part of the Buddy Core system, it implements continuous validation, confidence scoring, and automatic correction. Uses the buddy-watchdog.js module to detect when agents produce unreliable outputs and triggers recovery mechanisms.
- Reusable value: Hallucination detection is crucial for production AI systems. This watchdog pattern provides automatic validation and correction of AI outputs, improving reliability and trustworthiness. Reusable for any AI agent system, chatbot, code generation tool, or automated decision-making system where output validation is critical.
- Confidence: medium

## Instructions

1. Define what counts as a hallucination, contradiction, or unsafe output in the target system.
2. Specify confidence signals, validation checks, and escalation conditions.
3. Design recovery paths such as retry, abstain, request evidence, or handoff.
4. Recommend lightweight checks first, then deeper validation for expensive flows.
5. Return a watchdog policy with triggers, actions, and tuning guidance.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/orchestration/buddy-watchdog.js`
- `src/orchestration/buddy-core.js`
- `src/agents/buddy-error-protocol.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/orchestration/buddy-watchdog.js

## Example Triggers

- Help me design a ai hallucination detection watchdog pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the buddy watchdog hallucination detection pattern

## Template

Use the template file in `templates/watchdog-policy-template.md` for structured work.
