---
name: autonomous-projection-pattern
description: Use when the user needs autonomous monorepo projection patterns or guidance derived from the HeadyMe repository. Keywords include autonomous, projection, pattern, Heady, nodes, components, workflows, and the repo modules evidenced by scripts/, HeadyMe/headyme-core (entire projected repo).
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Autonomous Monorepo Projection

## When to Use This Skill

- Use when the user wants to split a monorepo or central intelligence system into projected services, public repos, or deployable microservices.
- Use when components should be derived automatically from a source system and shipped independently.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A system for autonomously projecting domain-specific services from a monorepo to separate public repositories. Implements the flow: pgvector (Brain) → Eradication Protocol → Domain Slicer → GitHub Push → Live deployment. Enables maintaining a single source of truth while automatically generating and deploying specialized microservices. Demonstrated by the projection of headyme-core from the main Heady repository.
- Reusable value: Monorepo projection enables maintaining DRY principles while deploying focused microservices. This pattern provides automation for code extraction, repository creation, and continuous deployment from a monorepo. Reusable for any organization managing microservices, multi-tenant applications, or open-source projects derived from proprietary codebases.
- Confidence: high

## Instructions

1. Identify the source system, target services, and projection boundaries.
2. Define what gets copied, transformed, versioned, and deployed.
3. Recommend validation checks between source and projected outputs.
4. Call out repo strategy, deployment flow, and operational ownership.
5. Return a projection blueprint with release logic and failure protections.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `scripts/`
- `HeadyMe/headyme-core (entire projected repo)`

### Evidence URLs

- https://github.com/HeadyMe/headyme-core
- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/tree/main/scripts

## Example Triggers

- Help me design a autonomous monorepo projection pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the autonomous projection pattern pattern

## Template

Use the template file in `templates/projection-pattern-template.md` for structured work.
