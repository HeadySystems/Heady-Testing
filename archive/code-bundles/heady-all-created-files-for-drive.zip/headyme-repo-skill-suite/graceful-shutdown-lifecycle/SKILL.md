---
name: graceful-shutdown-lifecycle
description: Use when the user needs graceful shutdown with lifo cleanup patterns or guidance derived from the HeadyMe repository. Keywords include graceful, shutdown, lifecycle, Heady, nodes, components, workflows, and the repo modules evidenced by src/lifecycle/graceful-shutdown.js, src/bees/lifecycle-bee.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Graceful Shutdown with LIFO Cleanup

## When to Use This Skill

- Use when the user needs clean shutdown sequencing, request draining, or resource cleanup planning.
- Use when long-running services must terminate safely without losing state or corrupting work.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A graceful shutdown system handling SIGTERM and SIGINT signals with Last-In-First-Out (LIFO) cleanup order. Manages connection draining, resource cleanup, and state persistence with configurable timeouts (5s per handler). Ensures clean shutdown of databases, message queues, health endpoints, and active requests before process termination.
- Reusable value: Graceful shutdown is critical for zero-downtime deployments and data integrity. This implementation provides a robust pattern for managing shutdown sequences, resource cleanup, and state persistence. Reusable for any long-running service, API server, or application requiring clean shutdown procedures.
- Confidence: high

## Instructions

1. List the resources and handlers that need ordered cleanup.
2. Define signal handling, time budgets, and request-drain behavior.
3. Recommend cleanup ordering and persistence guarantees.
4. Include fallback behavior when handlers exceed their deadline.
5. Return a shutdown runbook with ordered steps and failure protections.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/lifecycle/graceful-shutdown.js`
- `src/bees/lifecycle-bee.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/lifecycle/graceful-shutdown.js

## Example Triggers

- Help me design a graceful shutdown with lifo cleanup pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the graceful shutdown lifecycle pattern

## Template

Use the template file in `templates/shutdown-runbook-template.md` for structured work.
