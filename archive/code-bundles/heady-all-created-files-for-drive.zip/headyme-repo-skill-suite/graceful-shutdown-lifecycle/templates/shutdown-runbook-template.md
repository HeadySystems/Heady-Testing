# Graceful Shutdown Runbook

## Signals

## Active Resources

## Cleanup Order

## Drain Rules

## Time Budgets

## Failure Fallbacks
