---
name: circuit-breaker-resilience
description: Use when the user needs multi-service circuit breaker patterns or guidance derived from the HeadyMe repository. Keywords include circuit, breaker, resilience, Heady, nodes, components, workflows, and the repo modules evidenced by src/resilience/circuit-breaker.js, src/resilience/pool.js.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: headyme-repo-derived
  source_repo: HeadyMe/Heady
  confidence: 'high'
---

# Multi-Service Circuit Breaker

## When to Use This Skill

- Use when the user is designing service resilience, degraded-mode behavior, or failure isolation for APIs, workers, or infrastructure.
- Use when the user needs circuit breaker thresholds, recovery rules, or dependency protection.

## Repo-Derived Capability

This skill was derived from the scanned HeadyMe repository and maps to the following capability:

- A circuit breaker implementation with CLOSED→OPEN→HALF_OPEN state transitions for 16 pre-registered services. Monitors failure rates and automatically opens circuits to prevent cascade failures. Includes configurable thresholds, timeout management, and half-open testing for gradual recovery. Part of a comprehensive resilience stack with connection pooling, rate limiting, and caching.
- Reusable value: Circuit breakers are essential for building resilient distributed systems. This implementation provides a production-ready pattern for preventing cascade failures, managing degraded dependencies, and automatically recovering from transient errors. Reusable for any microservice architecture, API gateway, or system with external dependencies.
- Confidence: high

## Instructions

1. Identify the protected dependency, failure signals, and downstream blast radius.
2. Define CLOSED, OPEN, and HALF_OPEN transitions with measurable thresholds.
3. Recommend timeout, cooldown, and recovery probe behavior.
4. Pair the circuit breaker with rate limiting, caching, pooling, or fallback logic where relevant.
5. Return the state model, threshold recommendations, and hardening steps.

## Output Preferences

- Use concise headings
- Prefer bullets over long paragraphs
- Provide implementation-oriented recommendations
- Include risks, tradeoffs, and next steps when relevant

## Repo Evidence

### Evidence Paths

- `src/resilience/circuit-breaker.js`
- `src/resilience/pool.js`
- `src/resilience/rate-limiter.js`
- `src/resilience/cache.js`

### Evidence URLs

- https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/resilience/circuit-breaker.js

## Example Triggers

- Help me design a multi-service circuit breaker pattern for Heady
- Translate this repo capability into an implementation plan
- Refactor my current approach using the circuit breaker resilience pattern

## Template

Use the template file in `templates/circuit-breaker-template.md` for structured work.
