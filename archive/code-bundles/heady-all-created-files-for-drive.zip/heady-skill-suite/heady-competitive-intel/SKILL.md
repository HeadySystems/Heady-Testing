---
name: heady-competitive-intel
description: Use when the user needs competitor tracking, launch intelligence, pricing comparisons, vendor benchmarking, strategic positioning, or market monitoring for AI platforms that affect Heady. Triggers include Anthropic, OpenAI, Google DeepMind, Perplexity, Meta, pricing, model launches, product updates, benchmark, differentiation, and go-to-market analysis.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: heady
---

# Heady Competitive Intel

## When to Use This Skill

Use this skill for current intelligence on AI companies, infrastructure vendors, model providers, and adjacent platforms that shape Heady's market position.

## Focus Areas

- Product launches and capability changes
- API and platform pricing
- positioning and messaging shifts
- enterprise packaging and distribution
- integration patterns that threaten or enable Heady

## Instructions

1. Identify the competitors or vendors that matter to the request.
2. Prefer official sources first, then reputable secondary reporting.
3. Extract the facts that matter most for strategic comparison:
   - launch date
   - pricing
   - target user
   - integration model
   - strengths
   - limitations
4. Build a comparison table before writing conclusions.
5. Separate facts from interpretation.
6. Conclude with what changes Heady should consider in response.

## Output Format

Use:

- Snapshot Summary
- Vendor Matrix
- Strategic Implications for Heady
- Fastest Countermoves
- Heady Integration Opportunity

## Default Watchlist

Prioritize Anthropic, OpenAI, Google, Perplexity, Meta, Cloudflare, major vector database vendors, and important MCP ecosystem participants unless the user narrows scope.

## Example Triggers

- Compare current pricing across OpenAI, Anthropic, and Perplexity
- What recent launches threaten HeadyAI or HeadyBuddy
- Build a competitive brief for MCP ecosystem players
- Track where Cloudflare is moving versus Google Cloud Run patterns
