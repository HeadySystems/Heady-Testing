---
name: heady-patent-intel
description: Use when the user needs patent-aware research, prior-art review, novelty framing, reduction-to-practice support, claim differentiation analysis, filing support structure, or careful IP-safe language for Heady inventions. Triggers include patents, provisional, prior art, novelty, non-obviousness, claim chart, assignee, filing number, CSP, CSL, Sacred Geometry, vector memory, and orchestration methods.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: heady
---

# Heady Patent Intel

## When to Use This Skill

Use this skill when the user is evaluating Heady inventions, mapping differentiators, or researching prior art and patent positioning.

## Objectives

- Support novelty and non-obviousness analysis
- Gather comparable filings and prior art references
- Help structure invention narratives and reduction-to-practice evidence
- Identify crowded areas and likely overlap

## Instructions

1. Define the invention concept in one sentence.
2. Break it into claim-worthy elements:
   - data structures
   - orchestration methods
   - inference or routing logic
   - interface behavior
   - persistence or memory model
   - system topology
3. Research patents, applications, papers, repositories, and official product references that could serve as prior art or contextual evidence.
4. Distinguish between:
   - broad concept similarity
   - similar implementation pattern
   - likely direct overlap
   - genuine differentiation
5. Use careful language such as:
   - potentially novel
   - appears differentiated by
   - likely overlap in
   - reduction to practice may be evidenced by
6. Never claim legal certainty.
7. When available, include filing numbers, dates, assignees, and short relevance notes.

## Output Format

Structure results as:

- Invention Summary
- Potentially Novel Elements
- Closest Prior Art
- Overlap Risk
- Differentiation Angles
- Evidence of Reduction to Practice
- Recommended Patent Drafting Focus

## Heady-Specific Angles

Pay special attention to:

- Continuous Semantic Logic
- Sacred Geometry orchestration
- vector-native workspace operations
- latent routing and resonance gating
- Shadow Memory and cross-session persistence
- multi-agent swarm coordination patterns

## Example Triggers

- Find prior art for Continuous Semantic Logic
- Help me frame Sacred Geometry orchestration in patent-safe language
- Compare this invention concept against existing AI routing patents
- Build an invention brief with reduction-to-practice notes
