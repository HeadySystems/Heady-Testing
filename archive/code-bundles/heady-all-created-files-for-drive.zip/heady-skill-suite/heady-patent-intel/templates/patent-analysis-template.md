# Patent Analysis Brief

## Invention Summary

## Core Claim Elements

## Potentially Novel Mechanisms

## Closest Prior Art

## Overlap Risk

## Differentiation Angles

## Reduction to Practice Evidence

## Drafting Focus
