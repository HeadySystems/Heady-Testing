---
name: heady-nonprofit-grants
description: Use when the user needs nonprofit research, grant prospecting, mission-aligned partnerships, compliance-oriented briefing, donor or foundation analysis, or strategic writing support for HeadyConnection. Triggers include 501c3, grant, donor, foundation, nonprofit compliance, impact narrative, community program, partnership, philanthropy, and HeadyConnection.
metadata:
  author: perplexity-computer
  version: '1.0'
  owner: Eric Head
  suite: heady
---

# Heady Nonprofit Grants

## When to Use This Skill

Use this skill for HeadyConnection.org and other mission-driven work involving nonprofit operations, funding strategy, compliance-sensitive research, or public-interest partnerships.

## Objectives

- Find aligned grants and funders
- build concise compliance-aware briefs
- strengthen mission and impact framing
- connect technical work to community benefit

## Instructions

1. Clarify the mission area, program area, geography, and funding need.
2. Research funders, grant programs, deadlines, eligibility, and restrictions.
3. Separate confirmed facts from inferred fit.
4. Highlight mission alignment, exclusions, reporting burden, and likely competitiveness.
5. Translate technical Heady capabilities into community or educational impact when relevant.
6. Avoid overstating legal or tax conclusions.
7. Recommend the strongest next applications or partnership targets.

## Output Format

- Funding Need Summary
- Best-Fit Opportunities
- Eligibility Notes
- Required Materials
- Risks or Restrictions
- Recommended Outreach or Application Order

## Example Triggers

- Find grants that fit HeadyConnection's mission
- Build a foundation prospect list for AI education or community empowerment
- Turn this technical platform into a nonprofit-facing impact brief
- Summarize compliance considerations for a new community program
