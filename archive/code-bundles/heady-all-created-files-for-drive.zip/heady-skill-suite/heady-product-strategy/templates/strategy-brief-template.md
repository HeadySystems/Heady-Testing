# Strategy Brief

## Audience

## Product / Domain in Scope

## Problem

## Promise

## Proof

## Differentiation

## Ecosystem Fit

## Recommended Next Moves
