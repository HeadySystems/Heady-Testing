# Incident Runbook

## Symptom

## Blast Radius

## Recent Changes

## Ranked Hypotheses

## Validation Checks

## Immediate Fix

## Rollback Plan

## Hardening Steps
