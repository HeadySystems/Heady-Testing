/**
 * chaos-engineering.js — CSL-Gated Chaos Engineering Framework
 *
 * Injects controlled failures into the Heady platform to test resilience.
 * φ-scaled blast radius, Fibonacci-timed experiments, CSL gates for safety.
 *
 * Eric Haywood — HeadySystems
 * License: PROPRIETARY
 */

import { PHI, PSI, phiThreshold, fibSequence } from '../shared/phi-math.js';
import { createHash } from 'crypto';

// ── φ-Derived Constants ──────────────────────────────────
const CSL_THRESHOLDS = {
  CRITICAL: phiThreshold(4),
  HIGH:     phiThreshold(3),
  MEDIUM:   phiThreshold(2),
  LOW:      phiThreshold(1),
  MINIMUM:  phiThreshold(0),
};

const MAX_BLAST_RADIUS    = PSI;           // Max 61.8% of services
const EXPERIMENT_TTL_MS   = 89 * 1000;     // fib(11) = 89s max experiment duration
const COOLDOWN_MS         = 55 * 1000;     // fib(10) = 55s between experiments
const MAX_CONCURRENT      = 3;             // fib(4) concurrent experiments
const ABORT_THRESHOLD     = CSL_THRESHOLDS.HIGH; // Abort if health < 0.882
const SAFETY_CHECK_INTERVAL = 5 * 1000;    // fib(5) = 5s health checks during chaos

// ── Experiment Registry ──────────────────────────────────
const experiments = new Map();
let activeCount = 0;
let lastExperimentEnd = 0;

function cslGate(value, score, threshold, temperature = PSI * PSI * PSI) {
  const sigmoid = 1 / (1 + Math.exp(-(score - threshold) / temperature));
  return value * sigmoid;
}

// ── Experiment Types ─────────────────────────────────────
const EXPERIMENT_TYPES = {
  LATENCY_INJECTION: {
    name: 'Latency Injection',
    description: 'Adds artificial delay to service responses',
    safetyLevel: CSL_THRESHOLDS.LOW,
    apply: (target, params) => ({
      type: 'LATENCY_INJECTION',
      target,
      delayMs: params.delayMs || Math.round(1000 * PSI),  // 618ms default
      probability: params.probability || PSI2,              // 38.2% of requests
    }),
  },
  
  ERROR_INJECTION: {
    name: 'Error Injection',
    description: 'Forces services to return error responses',
    safetyLevel: CSL_THRESHOLDS.MEDIUM,
    apply: (target, params) => ({
      type: 'ERROR_INJECTION',
      target,
      statusCode: params.statusCode || 503,
      probability: params.probability || PSI * PSI2,        // 23.6%
    }),
  },
  
  RESOURCE_EXHAUSTION: {
    name: 'Resource Exhaustion',
    description: 'Simulates memory/CPU pressure',
    safetyLevel: CSL_THRESHOLDS.HIGH,
    apply: (target, params) => ({
      type: 'RESOURCE_EXHAUSTION',
      target,
      cpuLoad: params.cpuLoad || PSI,                       // 61.8% CPU
      memoryPressure: params.memoryPressure || PSI2,         // 38.2% memory
    }),
  },
  
  NETWORK_PARTITION: {
    name: 'Network Partition',
    description: 'Simulates network isolation between services',
    safetyLevel: CSL_THRESHOLDS.CRITICAL,
    apply: (target, params) => ({
      type: 'NETWORK_PARTITION',
      target,
      isolateFrom: params.isolateFrom || [],
      dropRate: params.dropRate || PSI,                      // 61.8% packet loss
    }),
  },
  
  DEPENDENCY_FAILURE: {
    name: 'Dependency Failure',
    description: 'Simulates downstream service failures',
    safetyLevel: CSL_THRESHOLDS.MEDIUM,
    apply: (target, params) => ({
      type: 'DEPENDENCY_FAILURE',
      target,
      dependency: params.dependency || 'database',
      failureMode: params.failureMode || 'timeout',
      timeoutMs: params.timeoutMs || Math.round(1000 * PHI), // 1618ms
    }),
  },
};

// ── Safety Checks ────────────────────────────────────────
async function checkSystemHealth(healthFn) {
  if (typeof healthFn !== 'function') return 1.0;
  try {
    const health = await healthFn();
    return typeof health === 'number' ? health : (health?.score ?? 1.0);
  } catch {
    return 0.0; // Can't check health = assume worst
  }
}

function isExperimentSafe(type, currentHealth) {
  const expType = EXPERIMENT_TYPES[type];
  if (!expType) return false;
  
  // CSL gate: current health must exceed experiment's safety level
  const safetyGated = cslGate(1, currentHealth, expType.safetyLevel);
  return safetyGated > CSL_THRESHOLDS.MINIMUM;
}

// ── Experiment Lifecycle ─────────────────────────────────
/**
 * Create and start a chaos experiment
 */
export async function runExperiment(options = {}) {
  const {
    type,
    target,
    params = {},
    durationMs = EXPERIMENT_TTL_MS,
    healthFn = null,
    onStart = null,
    onEnd = null,
    onAbort = null,
  } = options;

  // Pre-flight checks
  if (!EXPERIMENT_TYPES[type]) {
    return { success: false, reason: `Unknown experiment type: ${type}` };
  }
  
  if (activeCount >= MAX_CONCURRENT) {
    return { success: false, reason: `Max concurrent experiments (${MAX_CONCURRENT}) reached` };
  }
  
  const now = Date.now();
  if (now - lastExperimentEnd < COOLDOWN_MS) {
    return { 
      success: false, 
      reason: 'Cooldown period active',
      retryAfter: COOLDOWN_MS - (now - lastExperimentEnd),
    };
  }

  // Health check before starting
  const currentHealth = await checkSystemHealth(healthFn);
  if (!isExperimentSafe(type, currentHealth)) {
    return {
      success: false,
      reason: `System health (${currentHealth.toFixed(3)}) too low for ${type}`,
      requiredHealth: EXPERIMENT_TYPES[type].safetyLevel,
    };
  }

  // Create experiment
  const id = createHash('sha256')
    .update(`${type}-${target}-${now}-${Math.random()}`)
    .digest('hex')
    .slice(0, 21);
  
  const experiment = {
    id,
    ...EXPERIMENT_TYPES[type].apply(target, params),
    name: EXPERIMENT_TYPES[type].name,
    startedAt: now,
    expiresAt: now + Math.min(durationMs, EXPERIMENT_TTL_MS),
    status: 'RUNNING',
    healthSnapshots: [{ time: now, health: currentHealth }],
    abortReason: null,
  };

  experiments.set(id, experiment);
  activeCount++;
  
  if (typeof onStart === 'function') await onStart(experiment);

  // Safety monitor loop
  const monitor = setInterval(async () => {
    const health = await checkSystemHealth(healthFn);
    experiment.healthSnapshots.push({ time: Date.now(), health });
    
    // Abort if health drops below threshold
    if (health < (1 - ABORT_THRESHOLD)) {
      experiment.status = 'ABORTED';
      experiment.abortReason = `Health dropped to ${health.toFixed(3)}`;
      clearInterval(monitor);
      activeCount--;
      lastExperimentEnd = Date.now();
      if (typeof onAbort === 'function') await onAbort(experiment);
    }
  }, SAFETY_CHECK_INTERVAL);

  // Auto-expire
  setTimeout(async () => {
    clearInterval(monitor);
    if (experiment.status === 'RUNNING') {
      experiment.status = 'COMPLETED';
      activeCount--;
      lastExperimentEnd = Date.now();
      if (typeof onEnd === 'function') await onEnd(experiment);
    }
  }, Math.min(durationMs, EXPERIMENT_TTL_MS));

  return { success: true, experimentId: id, experiment };
}

/**
 * Abort a running experiment
 */
export function abortExperiment(id) {
  const exp = experiments.get(id);
  if (!exp || exp.status !== 'RUNNING') return false;
  exp.status = 'ABORTED';
  exp.abortReason = 'MANUAL';
  activeCount--;
  lastExperimentEnd = Date.now();
  return true;
}

/**
 * Get experiment results
 */
export function getExperiment(id) {
  return experiments.get(id) || null;
}

/**
 * List all experiments
 */
export function listExperiments(filter = {}) {
  const results = [];
  for (const [, exp] of experiments) {
    if (filter.status && exp.status !== filter.status) continue;
    if (filter.type && exp.type !== filter.type) continue;
    results.push(exp);
  }
  return results;
}

/**
 * Get chaos engineering summary
 */
export function getSummary() {
  let byStatus = { RUNNING: 0, COMPLETED: 0, ABORTED: 0 };
  let byType = {};
  for (const [, exp] of experiments) {
    byStatus[exp.status] = (byStatus[exp.status] || 0) + 1;
    byType[exp.type] = (byType[exp.type] || 0) + 1;
  }
  return {
    totalExperiments: experiments.size,
    activeCount,
    byStatus,
    byType,
    safetyThresholds: {
      maxBlastRadius: MAX_BLAST_RADIUS,
      abortThreshold: ABORT_THRESHOLD,
      maxConcurrent: MAX_CONCURRENT,
    },
  };
}

export { EXPERIMENT_TYPES, CSL_THRESHOLDS };
export default { runExperiment, abortExperiment, getExperiment, listExperiments, getSummary, EXPERIMENT_TYPES };
