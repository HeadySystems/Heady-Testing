#!/usr/bin/env node

const TestGenerator = require('../src/testing/test-generator');
const CoverageTracker = require('../src/testing/coverage-tracker');
const IntegrationTestRunner = require('../src/testing/integration-test-runner');
const RegressionDetector = require('../src/testing/regression-detector');
const logger = require('../src/utils/logger').child({ component: 'test-runner' });

async function main() {
    logger.info('Starting comprehensive test suite');

    const results = {
        unit: null,
        integration: null,
        coverage: null,
        regression: null
    };

    try {
        // 1. Generate auto-tests if needed
        const generator = new TestGenerator();
        const genReport = await generator.scanAndGenerate();
        logger.info('Test generation complete', genReport);

        // 2. Run integration tests
        const integrationRunner = new IntegrationTestRunner();
        results.integration = await integrationRunner.runAll();

        // 3. Track coverage
        const coverageTracker = new CoverageTracker();
        results.coverage = await coverageTracker.scan();
        coverageTracker.generateReport(results.coverage);

        // 4. Detect regressions
        const regressionDetector = new RegressionDetector();
        const baseline = regressionDetector.loadBaseline();
        results.regression = regressionDetector.detectRegressions(results.integration.tests, baseline);

        // Save new baseline
        regressionDetector.saveBaseline(results.integration.tests);

        // Summary
        logger.info('Test suite complete', {
            integration: {
                pass: results.integration.pass,
                fail: results.integration.fail
            },
            coverage: {
                total: results.coverage.total,
                tested: results.coverage.partial + results.coverage.auto
            },
            regressions: results.regression.regressions.length
        });

        // Exit with appropriate code
        if (results.regression.hasRegressions || results.integration.fail > 0) {
            process.exit(1);
        } else {
            process.exit(0);
        }

    } catch (err) {
        logger.error('Test suite failed', { error: err.message });
        process.exit(1);
    }
}

if (require.main === module) {
    main();
}

module.exports = { main };
