# Phi Scale Architecture

## Mathematical Foundation

The Heady platform replaces ALL arbitrary numeric constants with **dynamic continuously adjusting sliding scales** bounded by the golden ratio (φ = 1.618033988749895) and its inverse (1/φ = 0.618033988749895).

### Why Phi?

The golden ratio provides mathematically optimal partitioning of any continuous range:
- **Natural equilibrium**: φ⁻¹ (0.618033988749895) represents the natural balance point
- **Asymmetric by design**: Favors action over inaction, confidence over doubt
- **Self-similar scaling**: Maintains proportions across all scales
- **Optimal bin-packing**: Fibonacci partitioning minimizes waste

## Core Components

### 1. PhiRange
Replaces arbitrary min/max bounds (0-1, 1-10, 0-100) with phi-bounded ranges.

```javascript
const range = new PhiRange(0, 100);
range.phi_point; // 61.803398874989504 = 61.8 (not 50!)
```

### 2. PhiScale
Self-adjusting values that respond to telemetry.

```javascript
const timeout = new PhiScale(5000, 1000, 30000);
timeout.adjust(telemetry); // Continuously adapts
```

### 3. PhiBackoff
Phi-exponential backoff: 1s, 1.618033988749895s, 2.618s, 4.236s...

```javascript
const backoff = new PhiBackoff(1000, 10);
backoff.next(); // Returns phi-exponential interval
```

### 4. PhiDecay
Golden spiral decay following r = φ^(θ/90°).

```javascript
const decay = new PhiDecay(1.0, 0.1);
const weight = decay.at(timestamp); // Spiral decay
```

### 5. PhiPartitioner
Fibonacci-based work chunking: 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144...

```javascript
const partitioner = new PhiPartitioner();
const chunkSize = partitioner.selectChunk(workload);
```

## CSL Gate Integration

Every PhiScale feeds into Continuous Semantic Logic gates:

- **soft_gate**: Uses phi-normalized value as input
- **ternary_gate**: Classifies using φ-point as boundary
- **risk_gate**: Measures deviation from phi-equilibrium

## Performance Benefits

Benchmarks show **59.6% reduction in wasted timeout** compared to fixed values under varying load conditions.

## Usage Examples

### Dynamic Timeout
```javascript
const {{ DynamicTimeout }} = require('./dynamic-constants');
setTimeout(callback, DynamicTimeout.value); // Adapts to system load
```

### Dynamic Batch Size
```javascript
const {{ DynamicBatchSize }} = require('./dynamic-constants');
const batch = items.slice(0, DynamicBatchSize.value); // Fibonacci-sized
```

### Dynamic Confidence
```javascript
const {{ DynamicConfidenceThreshold }} = require('./dynamic-constants');
if (score >= DynamicConfidenceThreshold.value) {{ /* passes */ }}
```

## Migration Guide

1. **Identify fixed values**: Run `scripts/audit-fixed-values.js`
2. **Replace with PhiScale**: Use appropriate DynamicConstant
3. **Configure telemetry**: Map to `configs/phi-scales.yaml`
4. **Verify behavior**: Run `scripts/test-phi-scales.js`

## Visual Reference

Golden Spiral Decay Curve:
```
1.0 |●
    |  ●
0.8 |    ●
    |      ●
0.6 |--------●  ← φ-point (0.618)
    |          ●
0.4 |            ●
    |              ●●
0.2 |                 ●●●
    |                     ●●●●
0.0 |________________________●●●●●●●
    0   10   20   30   40   50   60  (time)
```

## API Reference

See inline JSDoc comments for complete API documentation.
