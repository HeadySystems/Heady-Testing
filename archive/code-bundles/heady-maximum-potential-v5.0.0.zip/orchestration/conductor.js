/**
 * HeadyConductor — Central Orchestration Engine
 *
 * The Conductor is the routing authority for all Heady pipeline executions.
 * Classifies tasks via CSL cosine scoring, routes to optimal nodes, manages
 * the full HCFullPipeline lifecycle, and coordinates HeadyBee swarms.
 *
 * Sacred Geometry v4.0 — Zero Magic Numbers
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import {
  PHI, PSI, PHI2, PHI3, FIB, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD,
  PRESSURE_LEVELS, POOL_ALLOCATION, POOL_SIZES,
  SIZING, RESOURCE_WEIGHTS,
  phiThreshold, phiBackoff, phiFusionWeights,
  cslGate, cslBlend, cslAND, cslOR, cslNOT, cslIMPLY,
  cslCONSENSUS, fibIndex, phiTokenBudgets, cosineSimilarity,
} from '../shared/phi-constants.js';

import { LiquidNode, BeeNode, CircuitBreaker, HeadyError, NodeRegistry, createLogger } from '../shared/liquid-node.js';

// ─── Routing Matrix ─────────────────────────────────────────────────────────

const ROUTING_MATRIX = Object.freeze({
  'code-generation':  { primary: ['JULES', 'BUILDER'],             fallback1: ['GPT4o', 'BUILDER'],     fallback2: ['GroqLlama'],        pool: 'hot' },
  'code-review':      { primary: ['OBSERVER'],                     fallback1: ['GPT4o'],                fallback2: ['GeminiPro'],        pool: 'hot' },
  'security-audit':   { primary: ['MURPHY', 'CIPHER'],             fallback1: ['GPT4o'],                fallback2: ['ClaudeOpus'],       pool: 'hot' },
  'architecture':     { primary: ['ATLAS', 'PYTHIA', 'HeadyVinci'],fallback1: ['GPT4o', 'HeadyVinci'],  fallback2: ['ClaudeSonnet'],     pool: 'hot' },
  'research':         { primary: ['HeadyResearch', 'SOPHIA'],      fallback1: ['ClaudeSonnet'],         fallback2: ['GPT4o'],            pool: 'warm' },
  'documentation':    { primary: ['ATLAS', 'HeadyCodex'],          fallback1: ['ClaudeSonnet'],         fallback2: ['GeminiPro'],        pool: 'warm' },
  'quick-task':       { primary: ['GroqLlama'],                    fallback1: ['GPT4oMini'],            fallback2: ['GeminiFlash'],      pool: 'hot' },
  'creative':         { primary: ['MUSE', 'NOVA'],                 fallback1: ['GPT4o', 'NOVA'],        fallback2: ['GeminiPro'],        pool: 'warm' },
  'cleanup':          { primary: ['JANITOR', 'HeadyMaid'],         fallback1: ['HeadyMaintenance'],     fallback2: [],                   pool: 'cold' },
  'analytics':        { primary: ['HeadyPatterns', 'HeadyMC'],     fallback1: ['DuckDBLocal'],          fallback2: [],                   pool: 'cold' },
  'embeddings':       { primary: ['CloudflareEdge'],               fallback1: ['NomicV2'],              fallback2: ['LocalOllama'],       pool: 'hot' },
  'monitoring':       { primary: ['OBSERVER', 'LENS', 'SENTINEL'], fallback1: ['HeadyLens'],            fallback2: [],                   pool: 'warm' },
  'translation':      { primary: ['BRIDGE'],                       fallback1: ['GPT4o'],                fallback2: ['GeminiPro'],        pool: 'warm' },
});

// ─── Edge-Origin Complexity Routing ─────────────────────────────────────────

const COMPLEXITY_ROUTES = Object.freeze({
  EDGE_ONLY:      { max: PSI * PSI, label: 'edge-only' },       // < 0.382
  EDGE_PREFERRED: { max: PSI,       label: 'edge-preferred' },  // 0.382–0.618
  ORIGIN_REQUIRED:{ max: 1.0,       label: 'origin-required' }, // > 0.618
});

// ─── Task Classification Embeddings (Simulated 384D → compressed keys) ──────

const TASK_TYPE_KEYS = Object.keys(ROUTING_MATRIX);

// ─── Bee Type Names (33 specialist bee types) ───────────────────────────────

const BEE_TYPE_NAMES = Object.freeze([
  'WorkerBee',       'ScoutBee',        'GuardBee',        'NurseBee',
  'BuilderBee',      'ForagerBee',       'MessengerBee',    'ArchivistBee',
  'AnalystBee',      'AuditorBee',       'ValidatorBee',    'TranslatorBee',
  'OptimizerBee',    'MonitorBee',       'SchedulerBee',    'CacheBee',
  'IndexerBee',      'RouterBee',        'BalancerBee',     'CollectorBee',
  'ReducerBee',      'MapperBee',        'FilterBee',       'SorterBee',
  'MergerBee',       'SplitterBee',      'EncoderBee',      'DecoderBee',
  'CompressorBee',   'ExpanderBee',      'SentinelBee',     'HealerBee',
  'QueenBee',
]);

// ─── HeadyConductor ─────────────────────────────────────────────────────────

export class HeadyConductor extends LiquidNode {
  /**
   * @param {Object} config
   * @param {NodeRegistry} [config.nodeRegistry]
   * @param {number} [config.maxPendingTasks] - fib(13)=233
   * @param {number} [config.classificationCacheSize] - fib(16)=987
   */
  constructor(config = {}) {
    super({
      name: 'HeadyConductor',
      version: '4.1.0',
      pool: 'hot',
      ring: 'inner',
      ...config,
    });

    this.nodeRegistry = config.nodeRegistry || null;

    /** Max pending tasks before backpressure */
    this.maxPendingTasks = config.maxPendingTasks || FIB[13]; // 233

    /** Classification result cache (LRU) */
    this._classificationCacheSize = config.classificationCacheSize || FIB[16]; // 987
    this._classificationCache = new Map();

    /** @type {Map<string, CircuitBreaker>} Per-node circuit breakers */
    this._nodeBreakers = new Map();

    /** @type {Array<Object>} Pending task queue */
    this._taskQueue = [];

    /** @type {number} Tasks currently being routed */
    this._activeRoutings = 0;
    this._maxActiveRoutings = FIB[6]; // 8 concurrent routings

    /** Routing telemetry */
    this._routingMetrics = {
      totalClassified: 0,
      totalRouted: 0,
      fallbacksUsed: 0,
      cacheHits: 0,
      backpressureEvents: 0,
    };

    /** Route override table (from ArenaMode promotions) */
    this._routeOverrides = new Map();
  }

  // ─── Lifecycle ──────────────────────────────────────────────────────────────

  async spawn(context = {}) {
    this.logger.info({
      maxPendingTasks: this.maxPendingTasks,
      routingMatrixSize: TASK_TYPE_KEYS.length,
    }, 'Spawning HeadyConductor');

    if (this.nodeRegistry && typeof this.nodeRegistry.register === 'function') {
      this.nodeRegistry.register(this);
    }

    this._setState('ACTIVE');
    return { status: 'spawned', node: this.name };
  }

  async execute(task) {
    if (!task || !task.type) {
      throw new HeadyError('Task must include a type field', 400, 'INVALID_TASK');
    }

    // Backpressure check
    if (this._taskQueue.length >= this.maxPendingTasks) {
      this._routingMetrics.backpressureEvents++;
      throw new HeadyError(
        `Conductor backpressure: ${this._taskQueue.length} pending tasks`,
        429,
        'CONDUCTOR_BACKPRESSURE'
      );
    }

    // Classify → Route → Dispatch
    const classification = this.classify(task);
    const route = this.route(classification, task);
    const result = await this.dispatch(route, task);

    return result;
  }

  async report() {
    return {
      node: this.name,
      state: this.state,
      version: this.version,
      pendingTasks: this._taskQueue.length,
      activeRoutings: this._activeRoutings,
      metrics: { ...this._routingMetrics },
      routeOverrides: this._routeOverrides.size,
      cacheSize: this._classificationCache.size,
      nodeBreakers: this._getBreakersStatus(),
    };
  }

  async retire() {
    this.logger.info({ pendingTasks: this._taskQueue.length }, 'Retiring HeadyConductor');
    this._taskQueue = [];
    this._classificationCache.clear();
    this._routeOverrides.clear();

    if (this.nodeRegistry && typeof this.nodeRegistry.unregister === 'function') {
      this.nodeRegistry.unregister(this.name);
    }

    this._setState('RETIRED');
    return { status: 'retired', metrics: { ...this._routingMetrics } };
  }

  // ─── Classification ─────────────────────────────────────────────────────────

  /**
   * Classify a task by type and compute complexity score.
   * Uses CSL cosine scoring against the routing matrix keys.
   */
  classify(task) {
    const cacheKey = `${task.type}:${task.domain || ''}`;

    // Cache check
    if (this._classificationCache.has(cacheKey)) {
      this._routingMetrics.cacheHits++;
      return this._classificationCache.get(cacheKey);
    }

    this._routingMetrics.totalClassified++;

    // Direct match against routing matrix
    const taskType = this._matchTaskType(task.type);
    const complexity = this._estimateComplexity(task);
    const computeRoute = this._computeRouteForComplexity(complexity);

    const classification = {
      taskType,
      domain: task.domain || 'general',
      complexity,
      computeRoute,
      pool: ROUTING_MATRIX[taskType]?.pool || 'warm',
      confidence: taskType === task.type ? 1.0 : CSL_THRESHOLDS.HIGH,
      timestamp: Date.now(),
    };

    // LRU cache insert
    this._classificationCache.set(cacheKey, classification);
    if (this._classificationCache.size > this._classificationCacheSize) {
      const firstKey = this._classificationCache.keys().next().value;
      this._classificationCache.delete(firstKey);
    }

    return classification;
  }

  /**
   * Match task type string to closest routing matrix key.
   * Uses string similarity as a simplified CSL proxy.
   */
  _matchTaskType(type) {
    const normalized = type.toLowerCase().replace(/[_\s]+/g, '-');
    if (ROUTING_MATRIX[normalized]) return normalized;

    // Fuzzy match: find best overlap
    let bestMatch = 'quick-task'; // default fallback
    let bestScore = 0;

    for (const key of TASK_TYPE_KEYS) {
      const score = this._stringSimilarity(normalized, key);
      if (score > bestScore) {
        bestScore = score;
        bestMatch = key;
      }
    }

    return bestScore >= CSL_THRESHOLDS.LOW ? bestMatch : 'quick-task';
  }

  /**
   * Simple Jaccard-like string similarity for task matching.
   */
  _stringSimilarity(a, b) {
    const setA = new Set(a.split('-'));
    const setB = new Set(b.split('-'));
    let intersection = 0;
    for (const token of setA) {
      if (setB.has(token)) intersection++;
    }
    const union = setA.size + setB.size - intersection;
    return union > 0 ? intersection / union : 0;
  }

  /**
   * Estimate task complexity on a [0,1] scale using heuristics.
   */
  _estimateComplexity(task) {
    let score = PSI * PSI; // 0.382 baseline

    // Context length increases complexity
    if (task.contextLength) {
      const tokens = phiTokenBudgets();
      score += (task.contextLength / tokens.memory) * PSI; // scaled by memory budget
    }

    // Multi-step tasks are more complex
    if (task.steps && task.steps > 1) {
      score += Math.min(task.steps / FIB[6], PSI) * PSI; // up to PSI^2 addition
    }

    // Explicit complexity hints
    if (task.complexity === 'high' || task.complexity === 'origin-required') {
      score = Math.max(score, PSI + 0.01); // force origin-required
    }
    if (task.complexity === 'low' || task.complexity === 'edge-only') {
      score = Math.min(score, PSI * PSI - 0.01); // force edge-only
    }

    return Math.min(score, 1.0);
  }

  /**
   * Determine compute route (edge/origin) based on complexity score.
   */
  _computeRouteForComplexity(complexity) {
    if (complexity < COMPLEXITY_ROUTES.EDGE_ONLY.max) return 'edge-only';
    if (complexity < COMPLEXITY_ROUTES.EDGE_PREFERRED.max) return 'edge-preferred';
    return 'origin-required';
  }

  // ─── Routing ────────────────────────────────────────────────────────────────

  /**
   * Route a classified task to the optimal node chain.
   */
  route(classification, task) {
    this._routingMetrics.totalRouted++;

    const { taskType } = classification;

    // Check for arena-promoted override
    if (this._routeOverrides.has(taskType)) {
      const override = this._routeOverrides.get(taskType);
      this.logger.info({ taskType, override: override.nodes }, 'Using arena-promoted route override');
      return {
        nodes: override.nodes,
        fallbackChain: ROUTING_MATRIX[taskType]?.primary || [],
        pool: classification.pool,
        computeRoute: classification.computeRoute,
        source: 'arena-override',
      };
    }

    const matrixEntry = ROUTING_MATRIX[taskType] || ROUTING_MATRIX['quick-task'];

    // Build fallback chain: primary → fallback1 → fallback2
    const primaryNodes = this._filterAvailableNodes(matrixEntry.primary);
    const fallback1 = this._filterAvailableNodes(matrixEntry.fallback1);
    const fallback2 = this._filterAvailableNodes(matrixEntry.fallback2);

    let selectedNodes = primaryNodes;
    let source = 'primary';

    if (selectedNodes.length === 0) {
      selectedNodes = fallback1;
      source = 'fallback1';
      this._routingMetrics.fallbacksUsed++;
      this.logger.warn({ taskType }, 'Primary nodes unavailable, using fallback1');
    }

    if (selectedNodes.length === 0) {
      selectedNodes = fallback2;
      source = 'fallback2';
      this.logger.warn({ taskType }, 'Fallback1 unavailable, using fallback2');
    }

    if (selectedNodes.length === 0) {
      selectedNodes = ['HeadyConductor']; // self-handle as last resort
      source = 'self-fallback';
      this.logger.error({ taskType }, 'All nodes unavailable for task type');
    }

    return {
      nodes: selectedNodes,
      fallbackChain: [...fallback1, ...fallback2],
      pool: matrixEntry.pool,
      computeRoute: classification.computeRoute,
      source,
    };
  }

  /**
   * Filter node list to only those whose circuit breakers allow execution.
   */
  _filterAvailableNodes(nodeNames) {
    return (nodeNames || []).filter(name => {
      const breaker = this._nodeBreakers.get(name);
      if (!breaker) return true; // no breaker = assume healthy
      return breaker.canExecute();
    });
  }

  // ─── Dispatch ─────────────────────────────────────────────────────────────

  /**
   * Dispatch a task to the routed nodes and collect results.
   */
  async dispatch(route, task) {
    this._activeRoutings++;

    try {
      const { nodes, pool, computeRoute } = route;

      // For hot pool: execute primary node, with fallback on failure
      // For warm/cold: try nodes sequentially
      for (const nodeName of nodes) {
        try {
          const result = await this._executeOnNode(nodeName, task, pool);
          this._recordNodeSuccess(nodeName);
          return {
            executedBy: nodeName,
            pool,
            computeRoute,
            result,
            source: route.source,
          };
        } catch (err) {
          this._recordNodeFailure(nodeName, err);
          this.logger.warn({
            node: nodeName, error: err.message,
          }, 'Node execution failed, trying next');
        }
      }

      // All nodes failed — try fallback chain
      for (const fallbackNode of route.fallbackChain) {
        try {
          const result = await this._executeOnNode(fallbackNode, task, pool);
          this._recordNodeSuccess(fallbackNode);
          this._routingMetrics.fallbacksUsed++;
          return {
            executedBy: fallbackNode,
            pool,
            computeRoute,
            result,
            source: 'fallback-dispatch',
          };
        } catch (err) {
          this._recordNodeFailure(fallbackNode, err);
        }
      }

      throw new HeadyError(
        `All nodes exhausted for task type ${task.type}`,
        503,
        'ALL_NODES_EXHAUSTED',
        { taskType: task.type, attemptedNodes: [...nodes, ...route.fallbackChain] }
      );

    } finally {
      this._activeRoutings--;
    }
  }

  /**
   * Execute a task on a specific node (via registry or simulation).
   */
  async _executeOnNode(nodeName, task, pool) {
    // Ensure breaker exists
    if (!this._nodeBreakers.has(nodeName)) {
      this._nodeBreakers.set(nodeName, new CircuitBreaker({
        failureThreshold: FIB[5],       // 5 failures
        resetTimeoutMs: FIB[8] * 1000,  // 21s
        halfOpenProbes: FIB[3],         // 2 probes
      }));
    }

    const breaker = this._nodeBreakers.get(nodeName);
    if (!breaker.canExecute()) {
      throw new HeadyError(`Circuit breaker OPEN for ${nodeName}`, 503, 'CIRCUIT_OPEN');
    }

    // Try real node from registry
    if (this.nodeRegistry) {
      const node = this.nodeRegistry.getNode(nodeName);
      if (node && typeof node.execute === 'function') {
        return node.execute(task);
      }
    }

    // Simulation fallback
    return {
      simulated: true,
      node: nodeName,
      taskType: task.type,
      pool,
      timestamp: Date.now(),
      output: task.payload || {},
    };
  }

  _recordNodeSuccess(nodeName) {
    const breaker = this._nodeBreakers.get(nodeName);
    if (breaker) breaker.recordSuccess();
  }

  _recordNodeFailure(nodeName, err) {
    const breaker = this._nodeBreakers.get(nodeName);
    if (breaker) breaker.recordFailure();
  }

  // ─── Arena Integration ────────────────────────────────────────────────────

  /**
   * Apply an arena-promoted route override for a task type.
   */
  applyArenaPromotion(taskType, winningNodes) {
    this._routeOverrides.set(taskType, {
      nodes: winningNodes,
      promotedAt: Date.now(),
    });
    this.logger.info({ taskType, nodes: winningNodes }, 'Arena promotion applied');
  }

  /**
   * Clear an arena promotion (revert to routing matrix).
   */
  clearArenaPromotion(taskType) {
    this._routeOverrides.delete(taskType);
  }

  // ─── Queries ──────────────────────────────────────────────────────────────

  getRoutingMatrix() {
    return { ...ROUTING_MATRIX };
  }

  getRouteOverrides() {
    const overrides = {};
    for (const [k, v] of this._routeOverrides) {
      overrides[k] = { ...v };
    }
    return overrides;
  }

  _getBreakersStatus() {
    const status = {};
    for (const [name, breaker] of this._nodeBreakers) {
      status[name] = breaker.getStatus();
    }
    return status;
  }

  healthCheck() {
    const openBreakers = [...this._nodeBreakers.values()].filter(b => {
      const s = b.getStatus();
      return s.state === 'OPEN';
    }).length;
    const totalBreakers = this._nodeBreakers.size;

    const healthRatio = totalBreakers > 0 ? 1 - (openBreakers / totalBreakers) : 1.0;

    return {
      status: healthRatio >= PSI ? 'healthy' : (healthRatio >= PSI * PSI ? 'degraded' : 'unhealthy'),
      healthRatio,
      pendingTasks: this._taskQueue.length,
      activeRoutings: this._activeRoutings,
      openCircuitBreakers: openBreakers,
      totalNodes: totalBreakers,
      metrics: { ...this._routingMetrics },
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// BEE FACTORY — Spawns typed bees from BEE_TYPE_NAMES
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * BeeFactory — Spawns and manages typed HeadyBee workers.
 *
 * Creates BeeNode instances by type name, tracks active bees with a
 * Fibonacci-bounded pool, and provides lifecycle management (spawn, retire,
 * recycle). Pool capacity follows POOL_SIZES (min=fib(3)=2, max=fib(7)=13).
 */
class BeeFactory {
  /**
   * @param {Object} [config={}]
   * @param {number} [config.maxPoolSize] - Max active bees (default POOL_SIZES.max)
   * @param {number} [config.defaultTimeoutMs] - Bee execution timeout in ms
   */
  constructor(config = {}) {
    /** @type {Map<string, BeeNode>} Active bee instances by ID */
    this.activeBees = new Map();

    /** @type {BeeNode[]} Recycled bee pool for reuse */
    this.recyclePool = [];

    this.maxPoolSize = config.maxPoolSize || POOL_SIZES.max;
    this.defaultTimeoutMs = config.defaultTimeoutMs || fib(8) * 1000; // 21s

    this.logger = createLogger('BeeFactory');

    this.factoryMetrics = {
      totalSpawned: 0,
      totalRetired: 0,
      totalRecycled: 0,
      peakActive: 0,
    };
  }

  /**
   * Spawn a bee of a given type.
   * @param {string} typeName - One of BEE_TYPE_NAMES
   * @param {Object} [context={}] - Spawn context
   * @returns {Promise<BeeNode>} The spawned bee
   */
  async spawn(typeName, context = {}) {
    if (!BEE_TYPE_NAMES.includes(typeName)) {
      throw new HeadyError(`BeeFactory: unknown bee type '${typeName}'`, 400, 'UNKNOWN_BEE_TYPE');
    }

    if (this.activeBees.size >= this.maxPoolSize) {
      throw new HeadyError(
        `BeeFactory: pool at capacity (${this.maxPoolSize})`,
        429, 'BEE_POOL_FULL'
      );
    }

    // Try recycled bee first
    let bee = this.recyclePool.pop();
    if (bee) {
      bee.retired = false;
      this.factoryMetrics.totalRecycled++;
    } else {
      const id = `${typeName}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      bee = new BeeNode({
        name: id,
        ring: 'outer',
        pool: 'warm',
      });
      bee.beeType = typeName;
    }

    await bee.spawn(context);
    this.activeBees.set(bee.name, bee);

    this.factoryMetrics.totalSpawned++;
    if (this.activeBees.size > this.factoryMetrics.peakActive) {
      this.factoryMetrics.peakActive = this.activeBees.size;
    }

    this.logger.info({ type: typeName, id: bee.name, active: this.activeBees.size }, 'Bee spawned');
    return bee;
  }

  /**
   * Retire a bee and optionally recycle it.
   * @param {string} beeId - The bee's name/ID
   * @param {boolean} [recycle=true] - Whether to keep for reuse
   */
  async retire(beeId, recycle = true) {
    const bee = this.activeBees.get(beeId);
    if (!bee) return;

    await bee.retire();
    this.activeBees.delete(beeId);
    this.factoryMetrics.totalRetired++;

    if (recycle && this.recyclePool.length < POOL_SIZES.min) {
      this.recyclePool.push(bee);
    }

    this.logger.info({ id: beeId, active: this.activeBees.size }, 'Bee retired');
  }

  /**
   * Retire all active bees.
   */
  async retireAll() {
    const ids = [...this.activeBees.keys()];
    for (const id of ids) {
      await this.retire(id, false);
    }
  }

  /**
   * Get factory status.
   * @returns {Object} Factory metrics and pool state
   */
  status() {
    return {
      activeBees: this.activeBees.size,
      recyclePool: this.recyclePool.length,
      maxPoolSize: this.maxPoolSize,
      metrics: { ...this.factoryMetrics },
      types: [...new Set([...this.activeBees.values()].map(b => b.beeType))],
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SWARM INTELLIGENCE — Collective bee coordination
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * SwarmIntelligence — Coordinates bee swarms for parallel task execution.
 *
 * Distributes tasks across a BeeFactory-managed swarm, aggregates results
 * using phi-fusion weighted consensus, and applies CSL-gated quality filters.
 * Max concurrency = SIZING.MAX_CONCURRENT = fib(6) = 8.
 */
class SwarmIntelligence {
  /**
   * @param {BeeFactory} beeFactory - Factory for spawning bees
   * @param {Object} [config={}]
   */
  constructor(beeFactory, config = {}) {
    if (!beeFactory) throw new HeadyError('SwarmIntelligence requires a BeeFactory', 400, 'MISSING_FACTORY');

    this.beeFactory = beeFactory;
    this.maxConcurrent = config.maxConcurrent || SIZING.MAX_CONCURRENT;

    /** @type {Map<string, Object>} Active swarm tasks by swarm ID */
    this.activeSwarms = new Map();

    this.logger = createLogger('SwarmIntelligence');

    this.swarmMetrics = {
      swarmsLaunched: 0,
      tasksDistributed: 0,
      consensusReached: 0,
      qualityFiltered: 0,
    };
  }

  /**
   * Distribute tasks across a swarm of bees.
   * @param {Object[]} tasks - Array of tasks to distribute
   * @param {string} beeType - Bee type to spawn for this swarm
   * @param {Object} [context={}] - Shared swarm context
   * @returns {Promise<Object>} Aggregated swarm result
   */
  async distribute(tasks, beeType, context = {}) {
    if (!tasks || tasks.length === 0) {
      return { results: [], consensus: null, timestamp: new Date().toISOString() };
    }

    const swarmId = `swarm_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.activeSwarms.set(swarmId, { beeType, taskCount: tasks.length, startedAt: Date.now() });
    this.swarmMetrics.swarmsLaunched++;

    // Process in batches of maxConcurrent
    const results = [];
    for (let i = 0; i < tasks.length; i += this.maxConcurrent) {
      const batch = tasks.slice(i, i + this.maxConcurrent);
      const batchResults = await this._executeBatch(batch, beeType, context);
      results.push(...batchResults);
    }

    this.swarmMetrics.tasksDistributed += tasks.length;

    // Aggregate via consensus
    const consensus = this._computeConsensus(results);
    this.activeSwarms.delete(swarmId);

    this.logger.info({ swarmId, tasks: tasks.length, results: results.length }, 'Swarm completed');

    return { swarmId, results, consensus, timestamp: new Date().toISOString() };
  }

  /**
   * Execute a batch of tasks concurrently.
   * @private
   */
  async _executeBatch(batch, beeType, context) {
    const beePromises = batch.map(async (task) => {
      let bee;
      try {
        bee = await this.beeFactory.spawn(beeType, context);
        const result = await bee.execute(task);
        await bee.report(result);
        return { status: 'success', beeId: bee.name, result };
      } catch (err) {
        return { status: 'error', beeId: bee?.name, error: err.message };
      } finally {
        if (bee) await this.beeFactory.retire(bee.name);
      }
    });

    return Promise.all(beePromises);
  }

  /**
   * Compute phi-fusion weighted consensus from swarm results.
   * @private
   */
  _computeConsensus(results) {
    const successful = results.filter(r => r.status === 'success');
    if (successful.length === 0) return { score: 0, quality: 'none', successRate: 0 };

    const successRate = successful.length / results.length;
    const qualityScore = cslGate(1.0, successRate, CSL_THRESHOLDS.MEDIUM);

    if (qualityScore >= CSL_THRESHOLDS.HIGH) {
      this.swarmMetrics.consensusReached++;
    } else {
      this.swarmMetrics.qualityFiltered++;
    }

    return {
      score: qualityScore,
      quality: qualityScore >= CSL_THRESHOLDS.HIGH ? 'strong'
        : qualityScore >= CSL_THRESHOLDS.MEDIUM ? 'moderate' : 'weak',
      successRate,
      successfulCount: successful.length,
      totalCount: results.length,
    };
  }

  /**
   * Get swarm intelligence status.
   * @returns {Object}
   */
  status() {
    return {
      activeSwarms: this.activeSwarms.size,
      factoryStatus: this.beeFactory.status(),
      metrics: { ...this.swarmMetrics },
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// ARENA MODE — Competitive node evaluation and promotion
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * ArenaMode — Competitive evaluation arena for node selection.
 *
 * Runs challenge tasks against multiple candidate nodes, scores their output
 * using phi-fusion weighted dimensions (accuracy, latency, cost), and promotes
 * winners into the conductor's route override table. Match history bounded
 * at SIZING.PATTERN_STORE = fib(14) = 377.
 */
class ArenaMode {
  /**
   * @param {HeadyConductor} conductor - The conductor to apply promotions to
   * @param {Object} [config={}]
   */
  constructor(conductor, config = {}) {
    if (!conductor) throw new HeadyError('ArenaMode requires a HeadyConductor', 400, 'MISSING_CONDUCTOR');

    this.conductor = conductor;

    /** @type {Object[]} Match history — bounded at SIZING.PATTERN_STORE */
    this.matchHistory = [];

    /** @type {Map<string, Object>} Current rankings per task type */
    this.rankings = new Map();

    /** phi-fusion 3-way weights: accuracy, latency, cost */
    this.scoreWeights = phiFusionWeights(3);

    this.logger = createLogger('ArenaMode');

    this.arenaMetrics = {
      matchesRun: 0,
      promotions: 0,
      demotions: 0,
    };
  }

  /**
   * Run a competitive match between candidate nodes.
   * @param {string} taskType - Task type being contested
   * @param {string[]} candidates - Node names to compete
   * @param {Object} challengeTask - The task for evaluation
   * @returns {Promise<Object>} Match result with scores and winner
   */
  async runMatch(taskType, candidates, challengeTask) {
    if (!candidates || candidates.length < fib(3)) {
      throw new HeadyError('ArenaMode: match requires at least fib(3) candidates', 400, 'INSUFFICIENT_CANDIDATES');
    }

    this.arenaMetrics.matchesRun++;
    const scores = [];

    for (const nodeName of candidates) {
      const startTime = Date.now();
      let result;
      let error = null;

      try {
        if (this.conductor.nodeRegistry) {
          const node = this.conductor.nodeRegistry.getNode(nodeName);
          if (node && typeof node.execute === 'function') {
            result = await node.execute(challengeTask);
          }
        }
        if (!result) {
          result = { simulated: true, node: nodeName };
        }
      } catch (err) {
        error = err.message;
      }

      const latency = Date.now() - startTime;
      const accuracy = error ? 0 : cslGate(1.0, 1.0, CSL_THRESHOLDS.LOW);
      const latencyScore = cslGate(1.0, 1.0 - Math.min(latency / (fib(8) * 1000), 1.0), CSL_THRESHOLDS.LOW);
      const costScore = cslGate(1.0, PSI, CSL_THRESHOLDS.LOW); // normalized cost estimate

      const composite =
        accuracy * this.scoreWeights[0] +
        latencyScore * this.scoreWeights[1] +
        costScore * this.scoreWeights[2];

      scores.push({
        node: nodeName,
        accuracy,
        latency: latencyScore,
        cost: costScore,
        composite,
        error,
      });
    }

    // Sort by composite descending
    scores.sort((a, b) => b.composite - a.composite);
    const winner = scores[0];

    // Record match
    const match = {
      taskType,
      candidates,
      scores,
      winner: winner.node,
      winnerScore: winner.composite,
      timestamp: new Date().toISOString(),
    };

    this.matchHistory.push(match);
    while (this.matchHistory.length > SIZING.PATTERN_STORE) {
      this.matchHistory.shift();
    }

    // Update rankings
    this.rankings.set(taskType, {
      leader: winner.node,
      score: winner.composite,
      matchCount: (this.rankings.get(taskType)?.matchCount || 0) + 1,
      lastMatch: match.timestamp,
    });

    this.logger.info({ taskType, winner: winner.node, score: winner.composite.toFixed(4) }, 'Match completed');

    return match;
  }

  /**
   * Promote the current leader for a task type into conductor routing.
   * @param {string} taskType - Task type to promote
   * @returns {boolean} Whether promotion was applied
   */
  promote(taskType) {
    const ranking = this.rankings.get(taskType);
    if (!ranking || ranking.score < CSL_THRESHOLDS.MEDIUM) {
      this.logger.warn({ taskType }, 'Promotion denied: insufficient score');
      return false;
    }

    this.conductor.applyArenaPromotion(taskType, [ranking.leader]);
    this.arenaMetrics.promotions++;
    this.logger.info({ taskType, node: ranking.leader }, 'Arena promotion applied');
    return true;
  }

  /**
   * Demote (remove override) for a task type.
   * @param {string} taskType - Task type to demote
   */
  demote(taskType) {
    this.conductor.clearArenaPromotion(taskType);
    this.rankings.delete(taskType);
    this.arenaMetrics.demotions++;
    this.logger.info({ taskType }, 'Arena demotion applied');
  }

  /**
   * Get arena status.
   * @returns {Object}
   */
  status() {
    return {
      rankings: Object.fromEntries(this.rankings),
      matchHistory: this.matchHistory.length,
      metrics: { ...this.arenaMetrics },
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// RESOURCE POOL MANAGER — Fibonacci-bounded resource allocation
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * ResourcePoolManager — Manages pool allocation across hot/warm/cold/reserve/governance.
 *
 * Allocates capacity using POOL_ALLOCATION percentages (Fibonacci-derived),
 * tracks utilization with CSL-gated pressure levels, and triggers scaling
 * recommendations when utilization exceeds phi-thresholds.
 */
class ResourcePoolManager {
  /**
   * @param {Object} [config={}]
   * @param {number} [config.totalCapacity] - Total resource units (default SIZING.QUEUE_DEPTH)
   */
  constructor(config = {}) {
    this.totalCapacity = config.totalCapacity || SIZING.QUEUE_DEPTH;

    /** @type {Map<string, Object>} Per-pool state */
    this.pools = new Map();

    this.logger = createLogger('ResourcePoolManager');

    // Initialize pools from POOL_ALLOCATION
    for (const [poolName, fraction] of Object.entries(POOL_ALLOCATION)) {
      this.pools.set(poolName, {
        name: poolName,
        allocated: Math.round(this.totalCapacity * fraction),
        used: 0,
        weight: RESOURCE_WEIGHTS[poolName] || PSI,
      });
    }

    this.poolMetrics = {
      allocations: 0,
      releases: 0,
      overflows: 0,
      rebalances: 0,
    };
  }

  /**
   * Allocate units from a specific pool.
   * @param {string} poolName - Pool to allocate from
   * @param {number} units - Number of units to allocate
   * @returns {Object} Allocation result
   */
  allocate(poolName, units) {
    const pool = this.pools.get(poolName);
    if (!pool) throw new HeadyError(`ResourcePoolManager: unknown pool '${poolName}'`, 400, 'UNKNOWN_POOL');

    const available = pool.allocated - pool.used;
    if (units > available) {
      this.poolMetrics.overflows++;
      throw new HeadyError(
        `ResourcePoolManager: pool '${poolName}' has ${available} available, ${units} requested`,
        429, 'POOL_OVERFLOW'
      );
    }

    pool.used += units;
    this.poolMetrics.allocations++;
    this.logger.info({ pool: poolName, units, used: pool.used, allocated: pool.allocated }, 'Resources allocated');

    return {
      pool: poolName,
      allocated: units,
      remaining: pool.allocated - pool.used,
      utilization: pool.allocated > 0 ? pool.used / pool.allocated : 0,
    };
  }

  /**
   * Release units back to a pool.
   * @param {string} poolName - Pool to release to
   * @param {number} units - Number of units to release
   */
  release(poolName, units) {
    const pool = this.pools.get(poolName);
    if (!pool) return;

    pool.used = Math.max(0, pool.used - units);
    this.poolMetrics.releases++;
  }

  /**
   * Get utilization and pressure level for a pool.
   * @param {string} poolName - Pool name
   * @returns {Object} Utilization info with pressure level
   */
  utilization(poolName) {
    const pool = this.pools.get(poolName);
    if (!pool) return null;

    const ratio = pool.allocated > 0 ? pool.used / pool.allocated : 0;
    const pressure = ratio >= PRESSURE_LEVELS.CRITICAL.min ? 'critical'
      : ratio >= PRESSURE_LEVELS.HIGH.min ? 'high'
        : ratio >= PRESSURE_LEVELS.ELEVATED.min ? 'elevated' : 'nominal';

    const gatedUtilization = cslGate(ratio, ratio, CSL_THRESHOLDS.LOW);

    return {
      pool: poolName,
      used: pool.used,
      allocated: pool.allocated,
      utilization: ratio,
      gatedUtilization,
      pressure,
    };
  }

  /**
   * Get overall system utilization across all pools.
   * @returns {Object} Aggregated utilization with per-pool breakdown
   */
  systemUtilization() {
    const breakdown = {};
    let totalUsed = 0;
    let totalAllocated = 0;

    for (const [name, pool] of this.pools) {
      breakdown[name] = this.utilization(name);
      totalUsed += pool.used;
      totalAllocated += pool.allocated;
    }

    const overallRatio = totalAllocated > 0 ? totalUsed / totalAllocated : 0;
    const pressure = overallRatio >= PRESSURE_LEVELS.CRITICAL.min ? 'critical'
      : overallRatio >= PRESSURE_LEVELS.HIGH.min ? 'high'
        : overallRatio >= PRESSURE_LEVELS.ELEVATED.min ? 'elevated' : 'nominal';

    return {
      overall: { used: totalUsed, allocated: totalAllocated, utilization: overallRatio, pressure },
      pools: breakdown,
      metrics: { ...this.poolMetrics },
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Rebalance pools by redistributing unused capacity from low-utilization
   * pools to high-utilization pools, weighted by RESOURCE_WEIGHTS.
   * @returns {Object} Rebalance result
   */
  rebalance() {
    const transfers = [];
    const poolEntries = [...this.pools.entries()];

    // Identify donors (utilization < PSI²) and receivers (utilization > PSI)
    const donors = [];
    const receivers = [];

    for (const [name, pool] of poolEntries) {
      const ratio = pool.allocated > 0 ? pool.used / pool.allocated : 0;
      if (ratio < PSI * PSI && pool.allocated - pool.used > 0) {
        donors.push({ name, surplus: Math.floor((pool.allocated - pool.used) * PSI) });
      } else if (ratio > PSI) {
        receivers.push({ name, weight: pool.weight });
      }
    }

    // Transfer surplus from donors to receivers proportional to weight
    const totalWeight = receivers.reduce((s, r) => s + r.weight, 0);
    if (totalWeight > 0 && donors.length > 0) {
      const totalSurplus = donors.reduce((s, d) => s + d.surplus, 0);

      for (const receiver of receivers) {
        const share = Math.floor(totalSurplus * (receiver.weight / totalWeight));
        if (share > 0) {
          const pool = this.pools.get(receiver.name);
          pool.allocated += share;
          transfers.push({ to: receiver.name, units: share });
        }
      }

      for (const donor of donors) {
        const pool = this.pools.get(donor.name);
        pool.allocated -= donor.surplus;
        transfers.push({ from: donor.name, units: donor.surplus });
      }
    }

    this.poolMetrics.rebalances++;
    this.logger.info({ transfers: transfers.length }, 'Pool rebalance completed');

    return { transfers, timestamp: new Date().toISOString() };
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {
  ROUTING_MATRIX, COMPLEXITY_ROUTES, BEE_TYPE_NAMES,
  BeeFactory, SwarmIntelligence, ArenaMode, ResourcePoolManager,
};
export default HeadyConductor;
