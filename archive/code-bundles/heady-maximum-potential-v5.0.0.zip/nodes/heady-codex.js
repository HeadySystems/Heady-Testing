/**
 * HEADY-CODEX — Code Documentation & API Reference Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Full documentation pipeline: code analysis, signature extraction, docstring
 * generation, example generation, reference compilation, and format output.
 * Coverage scoring uses CSL-gated phi-fusion weights.
 *
 * Ring: Memory | Pool: Warm | Domain: headyme.com
 *
 * @module heady-codex
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// DOCUMENTATION QUALITY WEIGHTS — phi-fusion 4-way
// ═══════════════════════════════════════════════════════════════

const DOC_QUALITY_WEIGHTS = phiFusionWeights(4);
// completeness ≈ 0.418, accuracy ≈ 0.258, clarity ≈ 0.160, examples ≈ 0.099

// ═══════════════════════════════════════════════════════════════
// COMPLEXITY TIERS — Fibonacci-scaled
// ═══════════════════════════════════════════════════════════════

const COMPLEXITY_TIERS = Object.freeze({
  trivial:   fib(3),   // 2 — simple getters/setters
  standard:  fib(5),   // 5 — typical methods
  complex:   fib(7),   // 13 — multi-branch logic
  advanced:  fib(8),   // 21 — algorithms, state machines
});

// ═══════════════════════════════════════════════════════════════
// HEADY-CODEX NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyCodexNode — Documentation pipeline with code analysis, signature
 * extraction, docstring generation, example generation, reference
 * compilation, and formatted output. CSL-gated quality scoring.
 *
 * @extends LiquidNode
 */
class HeadyCodexNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HEADY-CODEX'] - Node name
   */
  constructor(config = {}) {
    super({
      name: 'HEADY-CODEX',
      ring: 'memory',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: [
        'code-documentation',
        'api-reference',
        'technical-writing',
        'jsdoc-generation',
        'readme-generation',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Documentation cache — max FIB[16]=987 */
    this.docCache = new Map();

    /** @type {Map<string, Object>} Extracted signature registry */
    this.signatureRegistry = new Map();

    /** @type {Object[]} Generated examples store — bounded by SIZING.PATTERN_STORE */
    this.exampleStore = [];

    /** @type {Map<string, Object>} Reference compilation index */
    this.referenceIndex = new Map();

    this.codexMetrics = {
      modulesDocumented: 0,
      apisDocumented: 0,
      examplesGenerated: 0,
      coverageScore: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Route to documentation pipeline stage.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - analyze | signatures | docstrings | examples | reference | format | stats
   * @returns {Object} Task result
   */
  async process(task) {
    if (!task || !task.type) {
      throw new HeadyError('HEADY-CODEX: task must include a type', 400, 'INVALID_TASK');
    }
    this.transition('thinking');
    let result;
    switch (task.type) {
      case 'analyze':    result = this.analyzeCode(task.code || task); break;
      case 'signatures': result = this.extractSignatures(task.code || ''); break;
      case 'docstrings': result = this.generateDocstrings(task.signatures || []); break;
      case 'examples':   result = this.generateExamples(task.signatures || []); break;
      case 'reference':  result = this.compileReference(task.modules || []); break;
      case 'format':     result = this.formatOutput(task.documentation || task); break;
      case 'stats':      result = this.stats(); break;
      default:
        throw new HeadyError(`HEADY-CODEX: unknown task type: ${task.type}`, 400, 'UNKNOWN_TASK');
    }
    this.metrics.requestsHandled++;
    this.transition('responding');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // CODE ANALYSIS
  // ─────────────────────────────────────────────────────────────

  /**
   * Analyze code structure for documentation generation.
   * @param {Object|string} code - Code or code descriptor
   * @param {string} [code.source] - Source code string
   * @param {string} [code.language] - Programming language
   * @param {string} [code.moduleName] - Module name
   * @returns {Object} Analysis result with complexity and coverage metrics
   */
  analyzeCode(code) {
    const source = typeof code === 'string' ? code : (code.source || code.code || '');
    const moduleName = (typeof code === 'object' && code.moduleName) || 'unknown';

    if (!source) {
      throw new HeadyError('HEADY-CODEX: analyze requires code', 400, 'MISSING_CODE');
    }

    const lines = source.split('\n');
    const lineCount = lines.length;
    const functionMatches = source.match(/(?:function\s+\w+|(?:async\s+)?\w+\s*\()/g) || [];
    const classMatches = source.match(/class\s+\w+/g) || [];
    const exportMatches = source.match(/export\s+/g) || [];
    const commentLines = lines.filter(l => l.trim().startsWith('//') || l.trim().startsWith('*')).length;

    const complexityScore = cslGate(
      1.0,
      Math.min((functionMatches.length + classMatches.length * PHI) / fib(7), 1.0),
      CSL_THRESHOLDS.LOW,
    );

    const commentRatio = lineCount > 0 ? commentLines / lineCount : 0;
    const documentationCoverage = cslGate(1.0, commentRatio * PHI, CSL_THRESHOLDS.LOW);

    const tier = complexityScore >= CSL_THRESHOLDS.HIGH ? 'advanced'
      : complexityScore >= CSL_THRESHOLDS.MEDIUM ? 'complex'
        : complexityScore >= CSL_THRESHOLDS.LOW ? 'standard' : 'trivial';

    const analysis = {
      id: `ana_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      moduleName,
      lineCount,
      functionCount: functionMatches.length,
      classCount: classMatches.length,
      exportCount: exportMatches.length,
      commentLines,
      complexityScore,
      documentationCoverage,
      complexityTier: tier,
      analyzedAt: new Date().toISOString(),
    };

    this._cacheDoc(`ana:${moduleName}`, analysis);
    this.codexMetrics.modulesDocumented++;
    this.logger.info({ module: moduleName, lines: lineCount, complexity: tier }, 'Code analyzed');
    return analysis;
  }

  // ─────────────────────────────────────────────────────────────
  // SIGNATURE EXTRACTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Extract function and class signatures from source code.
   * @param {string} code - Source code to extract from
   * @returns {Object} Extracted signatures with parameter info
   */
  extractSignatures(code) {
    if (!code) {
      return { signatures: [], message: 'No code provided' };
    }

    const signatures = [];
    const lines = code.split('\n');

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();

      // Match function declarations and method definitions
      const funcMatch = line.match(/(?:async\s+)?(?:function\s+)?(\w+)\s*\(([^)]*)\)/);
      if (funcMatch) {
        const name = funcMatch[1];
        const params = funcMatch[2].split(',').map(p => p.trim()).filter(Boolean);
        const isAsync = line.includes('async');

        signatures.push({
          name,
          params,
          isAsync,
          line: i + 1,
          complexity: cslGate(1.0, Math.min(params.length / fib(5), 1.0), CSL_THRESHOLDS.LOW),
        });

        this.signatureRegistry.set(name, { params, isAsync, line: i + 1 });
      }

      // Match class declarations
      const classMatch = line.match(/class\s+(\w+)(?:\s+extends\s+(\w+))?/);
      if (classMatch) {
        signatures.push({
          name: classMatch[1],
          extends: classMatch[2] || null,
          type: 'class',
          line: i + 1,
          complexity: CSL_THRESHOLDS.MEDIUM,
        });
      }
    }

    // Bound signature registry
    while (this.signatureRegistry.size > SIZING.CACHE_SIZE) {
      const oldest = this.signatureRegistry.keys().next().value;
      this.signatureRegistry.delete(oldest);
    }

    this.logger.info({ signatures: signatures.length }, 'Signatures extracted');
    return {
      signatureCount: signatures.length,
      signatures,
      extractedAt: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // DOCSTRING GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate JSDoc-style docstrings for extracted signatures.
   * @param {Object[]} signatures - Signatures from extractSignatures
   * @returns {Object} Generated docstrings with quality scores
   */
  generateDocstrings(signatures) {
    if (!signatures || signatures.length === 0) {
      return { docstrings: [], message: 'No signatures provided' };
    }

    const docstrings = [];
    for (const sig of signatures) {
      const paramDocs = (sig.params || []).map(p => ` * @param {*} ${p}`).join('\n');
      const asyncTag = sig.isAsync ? ' * @async\n' : '';
      const returnsTag = ' * @returns {*}';

      const template = sig.type === 'class'
        ? `/**\n * ${sig.name}${sig.extends ? ` extends ${sig.extends}` : ''}\n * @class\n */`
        : `/**\n * ${sig.name}\n${asyncTag}${paramDocs ? paramDocs + '\n' : ''}${returnsTag}\n */`;

      const completeness = cslGate(
        1.0,
        Math.min(((sig.params || []).length + 1) / fib(4), 1.0),
        CSL_THRESHOLDS.LOW,
      );

      docstrings.push({
        name: sig.name,
        docstring: template,
        completeness,
        line: sig.line,
      });
    }

    const avgCompleteness = docstrings.reduce((s, d) => s + d.completeness, 0) / docstrings.length;
    this.logger.info({ count: docstrings.length, avgCompleteness: avgCompleteness.toFixed(4) }, 'Docstrings generated');

    return {
      docstringCount: docstrings.length,
      docstrings,
      avgCompleteness,
      generatedAt: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // EXAMPLE GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate usage examples for documented signatures.
   * @param {Object[]} signatures - Signatures to generate examples for
   * @returns {Object} Generated examples with quality scores
   */
  generateExamples(signatures) {
    if (!signatures || signatures.length === 0) {
      return { examples: [], message: 'No signatures provided' };
    }

    const examples = [];
    for (const sig of signatures) {
      if (sig.type === 'class') {
        examples.push({
          name: sig.name,
          example: `const instance = new ${sig.name}();`,
          quality: CSL_THRESHOLDS.MEDIUM,
        });
      } else {
        const args = (sig.params || []).map(() => '/* ... */').join(', ');
        const prefix = sig.isAsync ? 'await ' : '';
        examples.push({
          name: sig.name,
          example: `const result = ${prefix}${sig.name}(${args});`,
          quality: cslGate(1.0, Math.min((sig.params || []).length / fib(4), 1.0), CSL_THRESHOLDS.LOW),
        });
      }
    }

    // Store examples
    for (const ex of examples) {
      this.exampleStore.push({ ...ex, generatedAt: new Date().toISOString() });
    }
    while (this.exampleStore.length > SIZING.PATTERN_STORE) {
      this.exampleStore.shift();
    }

    this.codexMetrics.examplesGenerated += examples.length;
    this.logger.info({ examples: examples.length }, 'Examples generated');

    return {
      exampleCount: examples.length,
      examples,
      generatedAt: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // REFERENCE COMPILATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Compile API reference from multiple module analyses.
   * @param {Object[]} modules - Module descriptors with name and signatures
   * @returns {Object} Compiled API reference with coverage metrics
   */
  compileReference(modules) {
    if (!modules || modules.length === 0) {
      return { reference: {}, message: 'No modules provided' };
    }

    const reference = {};
    let totalSignatures = 0;
    let documentedSignatures = 0;

    for (const mod of modules) {
      const name = mod.name || mod.moduleName || 'unknown';
      const sigs = mod.signatures || [];
      const documented = sigs.filter(s => s.docstring || s.documented);

      reference[name] = {
        signatureCount: sigs.length,
        documentedCount: documented.length,
        coverage: sigs.length > 0 ? documented.length / sigs.length : 0,
        signatures: sigs,
      };

      totalSignatures += sigs.length;
      documentedSignatures += documented.length;

      this.referenceIndex.set(name, reference[name]);
    }

    // Bound reference index
    while (this.referenceIndex.size > SIZING.CACHE_SIZE) {
      const oldest = this.referenceIndex.keys().next().value;
      this.referenceIndex.delete(oldest);
    }

    const overallCoverage = totalSignatures > 0 ? documentedSignatures / totalSignatures : 0;
    const coverageGated = cslGate(1.0, overallCoverage, CSL_THRESHOLDS.MEDIUM);
    this._updateCoverageScore(coverageGated);

    this.codexMetrics.apisDocumented += modules.length;
    this.logger.info({ modules: modules.length, coverage: coverageGated.toFixed(4) }, 'Reference compiled');

    return {
      moduleCount: modules.length,
      totalSignatures,
      documentedSignatures,
      overallCoverage: coverageGated,
      reference,
      compiledAt: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // FORMAT OUTPUT
  // ─────────────────────────────────────────────────────────────

  /**
   * Format documentation for final output with quality scoring.
   * Quality: completeness × 0.418, accuracy × 0.258, clarity × 0.160, examples × 0.099.
   * @param {Object} documentation - Documentation to format
   * @returns {Object} Formatted output with quality score
   */
  formatOutput(documentation) {
    const sections = documentation.sections || [];
    const title = documentation.title || documentation.moduleName || 'Documentation';

    const completeness = cslGate(
      1.0,
      Math.min(sections.length / fib(5), 1.0),
      CSL_THRESHOLDS.LOW,
    );
    const accuracy = documentation.accuracy || CSL_THRESHOLDS.MEDIUM;
    const clarity = documentation.clarity || CSL_THRESHOLDS.MEDIUM;
    const exampleCoverage = documentation.exampleCount
      ? cslGate(1.0, Math.min(documentation.exampleCount / fib(4), 1.0), CSL_THRESHOLDS.LOW)
      : CSL_THRESHOLDS.LOW;

    const qualityScore =
      completeness * DOC_QUALITY_WEIGHTS[0] +
      accuracy * DOC_QUALITY_WEIGHTS[1] +
      clarity * DOC_QUALITY_WEIGHTS[2] +
      exampleCoverage * DOC_QUALITY_WEIGHTS[3];

    const result = {
      id: `doc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      title,
      sectionCount: sections.length,
      qualityScore,
      qualityBreakdown: {
        completeness,
        accuracy,
        clarity,
        examples: exampleCoverage,
      },
      weights: [...DOC_QUALITY_WEIGHTS],
      formattedAt: new Date().toISOString(),
    };

    this._cacheDoc(`fmt:${title}`, result);
    this.logger.info({ title, quality: qualityScore.toFixed(4) }, 'Output formatted');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & INTERNALS
  // ─────────────────────────────────────────────────────────────

  /** @returns {Object} Codex operational statistics */
  stats() {
    return {
      ...this.codexMetrics,
      docCacheSize: this.docCache.size,
      signatureRegistrySize: this.signatureRegistry.size,
      exampleStoreSize: this.exampleStore.length,
      referenceIndexSize: this.referenceIndex.size,
      complexityTiers: { ...COMPLEXITY_TIERS },
      qualityWeights: [...DOC_QUALITY_WEIGHTS],
    };
  }

  /** Cache documentation, evicting oldest if over FIB[16]=987. */
  _cacheDoc(key, doc) {
    this.docCache.set(key, doc);
    while (this.docCache.size > SIZING.CACHE_SIZE) {
      const oldest = this.docCache.keys().next().value;
      this.docCache.delete(oldest);
    }
  }

  /** Update running average coverage score. */
  _updateCoverageScore(score) {
    const n = this.codexMetrics.apisDocumented + 1;
    this.codexMetrics.coverageScore =
      (this.codexMetrics.coverageScore * (n - 1) + score) / n;
  }
}

export { HeadyCodexNode, HeadyCodexNode as HeadyCodex };
