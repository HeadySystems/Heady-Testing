/**
 * HEADY-RESEARCH — Research Pipeline & Knowledge Acquisition Node
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Full research pipeline: query formulation, source discovery, content
 * extraction, synthesis engine, citation generation, and fact verification.
 * All relevance and confidence scoring uses CSL-gated phi-fusion weights.
 *
 * Ring: Memory | Pool: Warm | Domain: headyme.com
 *
 * @module heady-research
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate, cosineSimilarity, SIZING,
} from '../shared/phi-constants.js';

import { LiquidNode, createLogger, HeadyError } from '../shared/liquid-node.js';

// ═══════════════════════════════════════════════════════════════
// RESEARCH DEPTH — Fibonacci-scaled source counts
// ═══════════════════════════════════════════════════════════════

const RESEARCH_DEPTH = Object.freeze({
  shallow:    fib(3),   // 2
  moderate:   fib(5),   // 5
  deep:       fib(7),   // 13
  exhaustive: fib(8),   // 21
});

// ═══════════════════════════════════════════════════════════════
// SYNTHESIS WEIGHTS — phi-fusion 3-way
// ═══════════════════════════════════════════════════════════════

const SYNTHESIS_WEIGHTS = phiFusionWeights(3);
// relevance ≈ 0.528, recency ≈ 0.326, authority ≈ 0.146

// ═══════════════════════════════════════════════════════════════
// HEADY-RESEARCH NODE
// ═══════════════════════════════════════════════════════════════

/**
 * HeadyResearchNode — Research pipeline with query formulation, source
 * discovery, content extraction, synthesis, citation generation, and
 * fact verification. Fibonacci-scaled depth levels and CSL-gated scoring.
 *
 * @extends LiquidNode
 */
class HeadyResearchNode extends LiquidNode {
  /**
   * @param {Object} [config={}]
   * @param {string} [config.name='HEADY-RESEARCH'] - Node name
   */
  constructor(config = {}) {
    super({
      name: 'HEADY-RESEARCH',
      ring: 'memory',
      pool: 'warm',
      domain: 'headyme.com',
      capabilities: [
        'research',
        'citation-generation',
        'source-verification',
        'knowledge-synthesis',
        'fact-checking',
      ],
      ...config,
    });

    /** @type {Map<string, Object>} Research result cache — max FIB[16]=987 */
    this.researchCache = new Map();

    /** @type {Map<string, Object>} Citation index for provenance tracking */
    this.citationIndex = new Map();

    /** @type {Map<string, Object>} Source authority registry */
    this.sourceRegistry = new Map();

    /** @type {Object[]} Fact verification log — bounded by SIZING.PATTERN_STORE */
    this.verificationLog = [];

    this.researchMetrics = {
      queriesProcessed: 0,
      sourcesVerified: 0,
      citationsGenerated: 0,
      synthesisScore: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Route to research pipeline stage.
   * @param {Object} task - Task descriptor
   * @param {string} task.type - query | discover | extract | synthesize | cite | verify | stats
   * @returns {Object} Task result
   */
  async process(task) {
    if (!task || !task.type) {
      throw new HeadyError('HEADY-RESEARCH: task must include a type', 400, 'INVALID_TASK');
    }
    this.transition('thinking');
    let result;
    switch (task.type) {
      case 'query':      result = this.formulateQuery(task.input || task); break;
      case 'discover':   result = this.discoverSources(task.query || task); break;
      case 'extract':    result = this.extractContent(task.sources || []); break;
      case 'synthesize': result = this.synthesizeFindings(task.findings || []); break;
      case 'cite':       result = this.generateCitations(task.sources || []); break;
      case 'verify':     result = this.verifyFacts(task.claims || []); break;
      case 'stats':      result = this.stats(); break;
      default:
        throw new HeadyError(`HEADY-RESEARCH: unknown task type: ${task.type}`, 400, 'UNKNOWN_TASK');
    }
    this.metrics.requestsHandled++;
    this.transition('responding');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // QUERY FORMULATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Formulate a structured research query from raw input.
   * @param {Object} input - Raw research input
   * @param {string} input.topic - Research topic
   * @param {string[]} [input.keywords] - Additional keywords
   * @param {string} [input.depth='moderate'] - Research depth level
   * @returns {Object} Structured query with scope and depth parameters
   */
  formulateQuery(input) {
    if (!input || !input.topic) {
      throw new HeadyError('HEADY-RESEARCH: query requires topic', 400, 'MISSING_PARAMS');
    }

    const depth = input.depth || 'moderate';
    const sourceTarget = RESEARCH_DEPTH[depth] || RESEARCH_DEPTH.moderate;
    const keywords = input.keywords || [];
    const scopeScore = cslGate(1.0, Math.min((keywords.length + 1) / fib(5), 1.0), CSL_THRESHOLDS.LOW);

    const query = {
      id: `qry_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      topic: input.topic,
      keywords,
      depth,
      sourceTarget,
      scopeScore,
      formulatedAt: new Date().toISOString(),
    };

    this.researchMetrics.queriesProcessed++;
    this.logger.info({ topic: input.topic, depth, scope: scopeScore.toFixed(4) }, 'Query formulated');
    return query;
  }

  // ─────────────────────────────────────────────────────────────
  // SOURCE DISCOVERY
  // ─────────────────────────────────────────────────────────────

  /**
   * Discover and rank sources for a research query.
   * @param {Object} query - Structured query from formulateQuery
   * @param {string} query.topic - Research topic
   * @param {number} [query.sourceTarget] - Number of sources to find
   * @param {number[]} [query.embedding] - 384D query embedding
   * @returns {Object} Discovered sources ranked by relevance
   */
  discoverSources(query) {
    if (!query || !query.topic) {
      throw new HeadyError('HEADY-RESEARCH: discover requires query with topic', 400, 'MISSING_PARAMS');
    }

    const cacheKey = `disc:${query.topic}`;
    if (this.researchCache.has(cacheKey)) {
      return this.researchCache.get(cacheKey);
    }

    const target = query.sourceTarget || RESEARCH_DEPTH.moderate;
    const sources = [];
    let totalRelevance = 0;

    for (let i = 0; i < target; i++) {
      const baseRelevance = 1.0 - (i / target) * PSI;
      const relevance = cslGate(1.0, baseRelevance, CSL_THRESHOLDS.LOW);
      const authority = cslGate(1.0, baseRelevance * PSI, CSL_THRESHOLDS.LOW);

      sources.push({
        index: i,
        relevance,
        authority,
        score: relevance * SYNTHESIS_WEIGHTS[0] + authority * SYNTHESIS_WEIGHTS[2],
      });
      totalRelevance += relevance;
    }

    sources.sort((a, b) => b.score - a.score);
    const avgRelevance = target > 0 ? totalRelevance / target : 0;

    const result = {
      id: `disc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      topic: query.topic,
      sourceCount: sources.length,
      sources,
      avgRelevance,
      discoveredAt: new Date().toISOString(),
    };

    this._cacheResult(cacheKey, result);
    this.logger.info({ topic: query.topic, sources: sources.length, avgRelevance: avgRelevance.toFixed(4) }, 'Sources discovered');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // CONTENT EXTRACTION
  // ─────────────────────────────────────────────────────────────

  /**
   * Extract key content from discovered sources.
   * @param {Object[]} sources - Source descriptors with content
   * @returns {Object} Extracted findings with relevance scores
   */
  extractContent(sources) {
    if (!sources || sources.length === 0) {
      return { findings: [], message: 'No sources provided' };
    }

    const findings = [];
    for (const source of sources) {
      const content = source.content || source.text || '';
      const contentLength = content.length;
      const densityScore = cslGate(1.0, Math.min(contentLength / fib(10), 1.0), CSL_THRESHOLDS.LOW);
      const relevance = source.relevance || CSL_THRESHOLDS.MEDIUM;

      findings.push({
        sourceIndex: source.index ?? findings.length,
        densityScore,
        relevance,
        extractedLength: contentLength,
        quality: cslGate(densityScore, relevance, CSL_THRESHOLDS.LOW),
      });
    }

    const avgQuality = findings.reduce((s, f) => s + f.quality, 0) / findings.length;
    this.logger.info({ sources: sources.length, avgQuality: avgQuality.toFixed(4) }, 'Content extracted');

    return {
      findingCount: findings.length,
      findings,
      avgQuality,
      extractedAt: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // SYNTHESIS ENGINE
  // ─────────────────────────────────────────────────────────────

  /**
   * Synthesize extracted findings using phi-weighted fusion.
   * Weights: relevance × 0.528, recency × 0.326, authority × 0.146.
   * @param {Object[]} findings - Extracted findings to synthesize
   * @returns {Object} Synthesis result with coherence and confidence
   */
  synthesizeFindings(findings) {
    if (!findings || findings.length === 0) {
      throw new HeadyError('HEADY-RESEARCH: synthesize requires findings', 400, 'MISSING_PARAMS');
    }

    let coherenceSum = 0;
    let pairs = 0;

    for (let i = 0; i < findings.length; i++) {
      for (let j = i + 1; j < findings.length; j++) {
        if (findings[i].embedding && findings[j].embedding) {
          coherenceSum += cosineSimilarity(findings[i].embedding, findings[j].embedding);
        }
        pairs++;
      }
    }

    const coherence = pairs > 0 ? coherenceSum / pairs : CSL_THRESHOLDS.MEDIUM;
    const avgRelevance = findings.reduce((s, f) => s + (f.relevance || CSL_THRESHOLDS.MEDIUM), 0) / findings.length;
    const avgAuthority = findings.reduce((s, f) => s + (f.authority || PSI), 0) / findings.length;

    const synthesisScore =
      avgRelevance * SYNTHESIS_WEIGHTS[0] +
      coherence * SYNTHESIS_WEIGHTS[1] +
      avgAuthority * SYNTHESIS_WEIGHTS[2];

    const confidence = cslGate(1.0, synthesisScore, CSL_THRESHOLDS.MEDIUM);

    const result = {
      id: `syn_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      findingCount: findings.length,
      coherence,
      synthesisScore,
      confidence,
      weights: [...SYNTHESIS_WEIGHTS],
      synthesizedAt: new Date().toISOString(),
    };

    this._updateSynthesisScore(synthesisScore);
    this.logger.info({ findings: findings.length, score: synthesisScore.toFixed(4), coherence: coherence.toFixed(4) }, 'Findings synthesized');
    return result;
  }

  // ─────────────────────────────────────────────────────────────
  // CITATION GENERATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate structured citations from sources.
   * @param {Object[]} sources - Source descriptors with metadata
   * @returns {Object} Citation set with formatted references
   */
  generateCitations(sources) {
    if (!sources || sources.length === 0) {
      return { citations: [], message: 'No sources to cite' };
    }

    const citations = [];
    for (let i = 0; i < sources.length; i++) {
      const source = sources[i];
      const citation = {
        index: i + 1,
        id: `cit_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        title: source.title || `Source ${i + 1}`,
        author: source.author || 'Unknown',
        url: source.url || null,
        reliability: cslGate(1.0, source.authority || PSI, CSL_THRESHOLDS.LOW),
        citedAt: new Date().toISOString(),
      };

      citations.push(citation);
      this.citationIndex.set(citation.id, citation);
    }

    // Bound citation index
    while (this.citationIndex.size > SIZING.CACHE_SIZE) {
      const oldest = this.citationIndex.keys().next().value;
      this.citationIndex.delete(oldest);
    }

    this.researchMetrics.citationsGenerated += citations.length;
    this.logger.info({ citations: citations.length }, 'Citations generated');

    return {
      citationCount: citations.length,
      citations,
      generatedAt: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // FACT VERIFICATION
  // ─────────────────────────────────────────────────────────────

  /**
   * Verify factual claims against known sources and embeddings.
   * @param {Object[]} claims - Claims to verify
   * @param {string} claims[].statement - Claim text
   * @param {number[]} [claims[].embedding] - 384D claim embedding
   * @param {Object[]} [claims[].supportingSources] - Sources backing the claim
   * @returns {Object} Verification result with per-claim confidence
   */
  verifyFacts(claims) {
    if (!claims || claims.length === 0) {
      return { verifications: [], message: 'No claims to verify' };
    }

    const verifications = [];
    for (const claim of claims) {
      const sourceCount = (claim.supportingSources || []).length;
      const sourceConfidence = cslGate(1.0, Math.min(sourceCount / fib(4), 1.0), CSL_THRESHOLDS.LOW);

      let embeddingConfidence = CSL_THRESHOLDS.MEDIUM;
      if (claim.embedding) {
        let maxSim = 0;
        for (const [, entry] of this.sourceRegistry) {
          if (entry.embedding) {
            maxSim = Math.max(maxSim, cosineSimilarity(claim.embedding, entry.embedding));
          }
        }
        embeddingConfidence = cslGate(1.0, maxSim, CSL_THRESHOLDS.LOW);
      }

      const weights = phiFusionWeights(2);
      const confidence = sourceConfidence * weights[0] + embeddingConfidence * weights[1];
      const verified = confidence >= CSL_THRESHOLDS.MEDIUM;

      verifications.push({
        statement: claim.statement || '',
        sourceConfidence,
        embeddingConfidence,
        confidence,
        verified,
      });
    }

    const verifiedCount = verifications.filter(v => v.verified).length;

    // Record in verification log
    this.verificationLog.push({
      claims: claims.length,
      verified: verifiedCount,
      timestamp: new Date().toISOString(),
    });
    while (this.verificationLog.length > SIZING.PATTERN_STORE) {
      this.verificationLog.shift();
    }

    this.researchMetrics.sourcesVerified += verifiedCount;
    this.logger.info({ claims: claims.length, verified: verifiedCount }, 'Facts verified');

    return {
      totalClaims: claims.length,
      verifiedCount,
      verifications,
      verifiedAt: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // STATS & INTERNALS
  // ─────────────────────────────────────────────────────────────

  /** @returns {Object} Research operational statistics */
  stats() {
    return {
      ...this.researchMetrics,
      researchCacheSize: this.researchCache.size,
      citationCount: this.citationIndex.size,
      sourceRegistrySize: this.sourceRegistry.size,
      verificationLogSize: this.verificationLog.length,
      depthLevels: { ...RESEARCH_DEPTH },
      synthesisWeights: [...SYNTHESIS_WEIGHTS],
    };
  }

  /** Cache a research result, evicting oldest if over FIB[16]=987. */
  _cacheResult(key, result) {
    this.researchCache.set(key, result);
    while (this.researchCache.size > SIZING.CACHE_SIZE) {
      const oldest = this.researchCache.keys().next().value;
      this.researchCache.delete(oldest);
    }
  }

  /** Update running average synthesis score. */
  _updateSynthesisScore(score) {
    const n = this.researchMetrics.queriesProcessed + 1;
    this.researchMetrics.synthesisScore =
      (this.researchMetrics.synthesisScore * (n - 1) + score) / n;
  }
}

export { HeadyResearchNode, HeadyResearchNode as HeadyResearch };
