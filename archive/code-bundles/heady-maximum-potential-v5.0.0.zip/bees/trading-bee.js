/**
 * TradingBee — Risk Assessment & Strategy Execution Bee
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Assesses portfolio risk using phi-fusion scoring, executes trading
 * strategies with CSL-gated entry/exit signals, tracks open positions
 * with Fibonacci-level take-profit/stop-loss, and reports realized +
 * unrealized PnL. All sizing and thresholds derive from phi-constants.
 *
 * Ring: Outer | Pool: Hot | Domain: headyme.com
 *
 * @module trading-bee
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  phiFusionWeights, cslGate,
  SIZING,
} from '../shared/phi-constants.js';

import { BaseHeadyBee } from './base-heady-bee.js';

// ═══════════════════════════════════════════════════════════════
// TRADING BEE
// ═══════════════════════════════════════════════════════════════

/**
 * TradingBee — Risk assessment, strategy execution, position tracking, PnL reporting.
 *
 * Risk scoring uses phi-fusion 3-way weights (volatility, exposure, drawdown).
 * Strategy signals are CSL-gated to filter noise. Positions use Fibonacci-level
 * take-profit and stop-loss targets. PnL computation tracks realized and unrealized.
 *
 * @extends BaseHeadyBee
 */
class TradingBee extends BaseHeadyBee {
  /**
   * @param {Object} [config={}]
   * @param {Object} [config.task] - Task descriptor
   */
  constructor(config = {}) {
    super({
      type: 'trading-bee',
      pool: 'hot',
      capabilities: ['trading-bee', 'risk-assess', 'strategy-execute', 'position-track', 'pnl-report'],
      ...config,
    });

    /** @type {Map<string, Object>} Open positions by symbol */
    this.positions = new Map();

    /** @type {Object[]} Trade history — bounded at SIZING.PATTERN_STORE (377) */
    this.tradeHistory = [];

    /** @type {number[]} Risk weights: volatility × 0.528, exposure × 0.326, drawdown × 0.146 */
    this.riskWeights = phiFusionWeights(3);

    /** @type {number} Max concurrent positions — fib(6)=8 */
    this.maxPositions = fib(6);

    this.tradingMetrics = {
      risksAssessed: 0,
      strategiesExecuted: 0,
      positionsTracked: 0,
      pnlReports: 0,
      totalRealizedPnl: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Execute a trading task.
   * @param {Object} task
   * @param {string} task.type - risk | strategy | position | pnl
   * @returns {Promise<Object>} Task result
   */
  async execute(task) {
    switch (task.type) {
      case 'risk':     return this.assessRisk(task.portfolio || {});
      case 'strategy': return this.executeStrategy(task.signal || task);
      case 'position': return this.trackPosition(task.symbol, task.price);
      case 'pnl':      return this.reportPnL();
      default:
        throw new Error(`TradingBee: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // ASSESS RISK
  // ─────────────────────────────────────────────────────────────

  /**
   * Assess portfolio risk using phi-fusion 3-way scoring.
   * Dimensions: volatility × 0.528, exposure × 0.326, drawdown × 0.146.
   * @param {Object} portfolio - Portfolio descriptor
   * @param {number} [portfolio.volatility] - Annualized volatility (0-1)
   * @param {number} [portfolio.exposure] - Total exposure as fraction of capital (0-1+)
   * @param {number} [portfolio.drawdown] - Current drawdown from peak (0-1)
   * @returns {Object} Risk assessment result
   */
  assessRisk(portfolio) {
    const volatility = portfolio.volatility || PSI * PSI;
    const exposure = portfolio.exposure || PSI;
    const drawdown = portfolio.drawdown || 0;

    const volScore = cslGate(1.0, 1.0 - volatility, CSL_THRESHOLDS.LOW);
    const expScore = cslGate(1.0, 1.0 - Math.min(exposure, 1.0), CSL_THRESHOLDS.LOW);
    const ddScore = cslGate(1.0, 1.0 - drawdown, CSL_THRESHOLDS.MEDIUM);

    const composite =
      volScore * this.riskWeights[0] +
      expScore * this.riskWeights[1] +
      ddScore * this.riskWeights[2];

    const riskLevel = composite >= CSL_THRESHOLDS.HIGH ? 'low'
      : composite >= CSL_THRESHOLDS.MEDIUM ? 'moderate'
        : composite >= CSL_THRESHOLDS.LOW ? 'high' : 'critical';

    const positionLimit = riskLevel === 'critical' ? 0
      : riskLevel === 'high' ? fib(3)
        : riskLevel === 'moderate' ? fib(5)
          : this.maxPositions;

    this.tradingMetrics.risksAssessed++;
    this.logger.info({ riskLevel, composite: composite.toFixed(4), positionLimit }, 'Risk assessed');

    return {
      volatility: volScore,
      exposure: expScore,
      drawdown: ddScore,
      composite,
      riskLevel,
      positionLimit,
      weights: [...this.riskWeights],
      timestamp: new Date().toISOString(),
    };
  }

  // ─────────────────────────────────────────────────────────────
  // EXECUTE STRATEGY
  // ─────────────────────────────────────────────────────────────

  /**
   * Execute a trading strategy based on CSL-gated signal strength.
   * @param {Object} signal - Trading signal
   * @param {string} signal.symbol - Trading symbol
   * @param {string} signal.direction - 'long' | 'short'
   * @param {number} signal.strength - Signal strength (0-1)
   * @param {number} signal.price - Entry price
   * @param {number} [signal.size] - Position size (default fib(3)=2)
   * @returns {Object} Execution result
   */
  executeStrategy(signal) {
    if (!signal.symbol || !signal.direction || signal.price == null) {
      throw new Error('TradingBee: executeStrategy requires symbol, direction, and price');
    }

    const gatedStrength = cslGate(signal.strength || PSI, signal.strength || PSI, CSL_THRESHOLDS.MEDIUM);
    const execute = gatedStrength >= CSL_THRESHOLDS.MEDIUM;

    if (!execute) {
      this.logger.info({ symbol: signal.symbol, gatedStrength: gatedStrength.toFixed(4) }, 'Signal below threshold — no trade');
      return { symbol: signal.symbol, executed: false, reason: 'signal-weak', gatedStrength, timestamp: new Date().toISOString() };
    }

    if (this.positions.size >= this.maxPositions) {
      this.logger.warn({ symbol: signal.symbol, positions: this.positions.size }, 'Position limit reached');
      return { symbol: signal.symbol, executed: false, reason: 'position-limit', timestamp: new Date().toISOString() };
    }

    // Fibonacci take-profit and stop-loss levels
    const isLong = signal.direction === 'long';
    const tp1 = signal.price * (isLong ? (1 + PSI * PSI / 10) : (1 - PSI * PSI / 10));
    const tp2 = signal.price * (isLong ? (1 + PSI / 10) : (1 - PSI / 10));
    const stopLoss = signal.price * (isLong ? (1 - PSI * PSI * PSI / 10) : (1 + PSI * PSI * PSI / 10));

    const position = {
      symbol: signal.symbol,
      direction: signal.direction,
      entryPrice: signal.price,
      size: signal.size || fib(3),
      currentPrice: signal.price,
      tp1,
      tp2,
      stopLoss,
      gatedStrength,
      openedAt: Date.now(),
      unrealizedPnl: 0,
    };

    this.positions.set(signal.symbol, position);

    this.tradingMetrics.strategiesExecuted++;
    this.tradingMetrics.positionsTracked = this.positions.size;
    this.logger.info({ symbol: signal.symbol, direction: signal.direction, price: signal.price }, 'Strategy executed');

    return { ...position, executed: true, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // TRACK POSITION
  // ─────────────────────────────────────────────────────────────

  /**
   * Update a position with the latest price and check TP/SL levels.
   * @param {string} symbol - Trading symbol
   * @param {number} price - Current price
   * @returns {Object} Position status with unrealized PnL
   */
  trackPosition(symbol, price) {
    if (!symbol || price == null) {
      throw new Error('TradingBee: trackPosition requires symbol and price');
    }

    const pos = this.positions.get(symbol);
    if (!pos) {
      return { symbol, tracked: false, reason: 'no-position', timestamp: new Date().toISOString() };
    }

    pos.currentPrice = price;
    const multiplier = pos.direction === 'long' ? 1 : -1;
    pos.unrealizedPnl = (price - pos.entryPrice) * multiplier * pos.size;

    // Check take-profit and stop-loss
    let action = 'hold';
    const isLong = pos.direction === 'long';
    if ((isLong && price >= pos.tp2) || (!isLong && price <= pos.tp2)) {
      action = 'close-tp2';
    } else if ((isLong && price >= pos.tp1) || (!isLong && price <= pos.tp1)) {
      action = 'partial-tp1';
    } else if ((isLong && price <= pos.stopLoss) || (!isLong && price >= pos.stopLoss)) {
      action = 'close-sl';
    }

    // Auto-close on TP2 or SL
    if (action === 'close-tp2' || action === 'close-sl') {
      this.tradingMetrics.totalRealizedPnl += pos.unrealizedPnl;
      this.tradeHistory.push({
        symbol, direction: pos.direction, entryPrice: pos.entryPrice,
        exitPrice: price, pnl: pos.unrealizedPnl, action, closedAt: Date.now(),
      });
      while (this.tradeHistory.length > SIZING.PATTERN_STORE) this.tradeHistory.shift();
      this.positions.delete(symbol);
    }

    this.logger.info({ symbol, price, action, pnl: pos.unrealizedPnl.toFixed(2) }, 'Position tracked');

    return { symbol, price, action, unrealizedPnl: pos.unrealizedPnl, position: { ...pos }, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // REPORT PNL
  // ─────────────────────────────────────────────────────────────

  /**
   * Report realized + unrealized PnL across all positions and history.
   * @returns {Object} PnL report
   */
  reportPnL() {
    let unrealizedTotal = 0;
    const openPositions = [];

    for (const [symbol, pos] of this.positions) {
      unrealizedTotal += pos.unrealizedPnl;
      openPositions.push({ symbol, direction: pos.direction, entryPrice: pos.entryPrice, currentPrice: pos.currentPrice, unrealizedPnl: pos.unrealizedPnl });
    }

    const realizedTotal = this.tradingMetrics.totalRealizedPnl;
    const totalPnl = realizedTotal + unrealizedTotal;

    this.tradingMetrics.pnlReports++;
    this.logger.info({ realized: realizedTotal.toFixed(2), unrealized: unrealizedTotal.toFixed(2), total: totalPnl.toFixed(2) }, 'PnL reported');

    return {
      realizedPnl: realizedTotal,
      unrealizedPnl: unrealizedTotal,
      totalPnl,
      openPositions,
      closedTrades: this.tradeHistory.length,
      timestamp: new Date().toISOString(),
    };
  }
}

export { TradingBee, TradingBee as default };
