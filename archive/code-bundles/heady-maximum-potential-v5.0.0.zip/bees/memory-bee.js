/**
 * MemoryBee — Vector Memory Operations Worker
 *
 * Handles vector store/retrieve/embed/search operations as a HeadyBee.
 * Part of the 33-type bee swarm registry.
 *
 * Sacred Geometry v4.0 — Zero Magic Numbers
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, DEDUP_THRESHOLD,
  phiBackoff, phiFusionWeights, cslGate,
  SIZING, POOL_SIZES, cosineSimilarity,
} from '../shared/phi-constants.js';

import { BaseHeadyBee } from './base-heady-bee.js';

// ─── Configuration ─────────────────────────────────────────────────────────

const MEMORY_CONFIG = Object.freeze({
  batchSize:        fib(6),                        // 8 vectors per batch
  maxCacheSize:     SIZING.CACHE_SIZE,             // 987 cached embeddings
  pruneThreshold:   CSL_THRESHOLDS.LOW,            // 0.691 — below = stale
  deduplication:    DEDUP_THRESHOLD,               // 0.972 — above = duplicate
  searchK:          SIZING.HNSW_M,                 // 21 — k-nearest neighbors
  embeddingDim:     FIB[14] + FIB[5] + FIB[2],    // 384 (377+5+2) — standard dim
  staleWindowMs:    fib(11) * 24 * 3600 * 1000,   // 89 days retention
});

// ─── MemoryBee ─────────────────────────────────────────────────────────────

export class MemoryBee extends BaseHeadyBee {
  constructor(config = {}) {
    super({
      name: config.name || 'MemoryBee',
      type: 'memory-bee',
      pool: 'hot',
      capabilities: [
        'vector-store', 'vector-retrieve', 'batch-embed',
        'nearest-search', 'stale-prune', 'dedup-check',
      ],
      ...config,
    });

    /** @type {Map<string, { vector: number[], metadata: object, storedAt: number }>} */
    this._cache = new Map();

    /** Telemetry */
    this._metrics = {
      vectorsStored: 0,
      vectorsRetrieved: 0,
      batchesEmbedded: 0,
      searchesPerformed: 0,
      duplicatesDetected: 0,
      stalesPruned: 0,
    };
  }

  // ─── Lifecycle ──────────────────────────────────────────────────────────

  async spawn(context = {}) {
    await super.spawn(context);
    this._cache.clear();
    this._log('info', 'MemoryBee spawned', { config: MEMORY_CONFIG });
    return this;
  }

  async execute(task = {}) {
    this._transitionTo('thinking');
    const { operation, payload } = task;

    let result;
    switch (operation) {
      case 'store':
        result = await this.storeVector(payload);
        break;
      case 'retrieve':
        result = await this.retrieveNearest(payload);
        break;
      case 'batch-embed':
        result = await this.batchEmbed(payload);
        break;
      case 'prune':
        result = await this.pruneStale(payload);
        break;
      default:
        result = await this.storeVector(payload);
    }

    this._transitionTo('responding');
    return { status: 'completed', operation, result, metrics: { ...this._metrics } };
  }

  // ─── Operations ─────────────────────────────────────────────────────────

  async storeVector({ key, vector, metadata = {} }) {
    // Dedup check
    for (const [existingKey, entry] of this._cache) {
      if (existingKey === key) continue;
      const sim = cosineSimilarity(vector, entry.vector);
      if (sim >= MEMORY_CONFIG.deduplication) {
        this._metrics.duplicatesDetected++;
        this._log('debug', 'Duplicate detected', { key, existingKey, similarity: sim });
        return { stored: false, duplicateOf: existingKey, similarity: sim };
      }
    }

    this._cache.set(key, { vector, metadata, storedAt: Date.now() });
    this._metrics.vectorsStored++;

    // Evict if over cache limit
    if (this._cache.size > MEMORY_CONFIG.maxCacheSize) {
      const oldest = [...this._cache.entries()]
        .sort((a, b) => a[1].storedAt - b[1].storedAt)
        .slice(0, SIZING.BATCH_EVICTION);
      for (const [k] of oldest) this._cache.delete(k);
    }

    return { stored: true, key, cacheSize: this._cache.size };
  }

  async retrieveNearest({ queryVector, k = MEMORY_CONFIG.searchK }) {
    this._metrics.searchesPerformed++;
    const scored = [];

    for (const [key, entry] of this._cache) {
      const sim = cosineSimilarity(queryVector, entry.vector);
      if (sim >= CSL_THRESHOLDS.MINIMUM) {
        scored.push({ key, similarity: sim, metadata: entry.metadata });
      }
    }

    scored.sort((a, b) => b.similarity - a.similarity);
    const results = scored.slice(0, k);
    this._metrics.vectorsRetrieved += results.length;
    return { results, totalScanned: this._cache.size };
  }

  async batchEmbed({ texts = [], model = 'default' }) {
    this._metrics.batchesEmbedded++;
    const batches = [];
    for (let i = 0; i < texts.length; i += MEMORY_CONFIG.batchSize) {
      batches.push(texts.slice(i, i + MEMORY_CONFIG.batchSize));
    }

    const embeddings = [];
    for (const batch of batches) {
      for (const text of batch) {
        // Deterministic mock embedding from text hash
        const vec = new Array(MEMORY_CONFIG.embeddingDim).fill(0).map((_, idx) => {
          const charCode = text.charCodeAt(idx % text.length) || 0;
          return (charCode / 127.0 - 0.5) * 2;
        });
        const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0));
        embeddings.push(norm > 0 ? vec.map(v => v / norm) : vec);
      }
    }

    return { embeddings, count: embeddings.length, model, batchCount: batches.length };
  }

  async pruneStale({ maxAgeMs = MEMORY_CONFIG.staleWindowMs } = {}) {
    const now = Date.now();
    const toDelete = [];

    for (const [key, entry] of this._cache) {
      if (now - entry.storedAt > maxAgeMs) toDelete.push(key);
    }

    for (const key of toDelete) this._cache.delete(key);
    this._metrics.stalesPruned += toDelete.length;

    return { pruned: toDelete.length, remaining: this._cache.size };
  }

  // ─── Report ─────────────────────────────────────────────────────────────

  async report() {
    return {
      ...await super.report(),
      cacheSize: this._cache.size,
      metrics: { ...this._metrics },
    };
  }

  async retire() {
    this._cache.clear();
    return super.retire();
  }
}

export { MemoryBee as MemoryBeeNode };
