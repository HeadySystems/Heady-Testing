/**
 * TelemetryBee — Telemetry Collection & Export Worker
 *
 * Collects metrics, spans, and health data across the Heady swarm.
 * Part of the 33-type bee swarm registry.
 *
 * Sacred Geometry v4.0 — Zero Magic Numbers
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, phiBackoff, phiFusionWeights,
  SIZING, phiAdaptiveInterval,
} from '../shared/phi-constants.js';

import { BaseHeadyBee } from './base-heady-bee.js';

const TELEMETRY_CONFIG = Object.freeze({
  maxMetricBuffer: SIZING.QUEUE_DEPTH,       // 233 buffered metrics
  maxSpanBuffer:   SIZING.CACHE_SIZE,        // 987 buffered spans
  flushIntervalMs: fib(8) * 1000,            // 21s flush interval
  aggregationWindowMs: fib(9) * 1000,        // 34s aggregation window
  healthCheckIntervalMs: fib(7) * 1000,      // 13s health probes
});

export class TelemetryBee extends BaseHeadyBee {
  constructor(config = {}) {
    super({
      name: config.name || 'TelemetryBee',
      type: 'telemetry-bee',
      pool: 'warm',
      capabilities: [
        'metric-collection', 'metric-export', 'span-aggregation',
        'health-reporting', 'latency-tracking', 'error-classification',
      ],
      ...config,
    });

    this._metricBuffer = [];
    this._spanBuffer = [];
    this._healthReports = new Map();
    this._metrics = {
      metricsCollected: 0,
      metricsExported: 0,
      spansAggregated: 0,
      healthChecksRun: 0,
      flushCycles: 0,
    };
  }

  async spawn(context = {}) {
    await super.spawn(context);
    this._metricBuffer = [];
    this._spanBuffer = [];
    this._healthReports.clear();
    this._log('info', 'TelemetryBee spawned', { config: TELEMETRY_CONFIG });
    return this;
  }

  async execute(task = {}) {
    this._transitionTo('thinking');
    const { operation, payload } = task;

    let result;
    switch (operation) {
      case 'collect':   result = this.collectMetrics(payload); break;
      case 'export':    result = await this.exportMetrics(payload); break;
      case 'aggregate': result = this.aggregateSpans(payload); break;
      case 'health':    result = this.reportHealth(payload); break;
      default:          result = this.collectMetrics(payload);
    }

    this._transitionTo('responding');
    return { status: 'completed', operation, result, metrics: { ...this._metrics } };
  }

  collectMetrics({ name, value, tags = {}, timestamp = Date.now() }) {
    this._metrics.metricsCollected++;
    const entry = { name, value, tags, timestamp };
    this._metricBuffer.push(entry);

    if (this._metricBuffer.length > TELEMETRY_CONFIG.maxMetricBuffer) {
      this._metricBuffer = this._metricBuffer.slice(-TELEMETRY_CONFIG.maxMetricBuffer);
    }

    return { buffered: this._metricBuffer.length, entry };
  }

  async exportMetrics({ format = 'json' } = {}) {
    this._metrics.flushCycles++;
    const batch = [...this._metricBuffer];
    this._metricBuffer = [];
    this._metrics.metricsExported += batch.length;

    return {
      exported: batch.length,
      format,
      metrics: format === 'json' ? batch : batch.map(m => `${m.name}=${m.value}`).join('\n'),
    };
  }

  aggregateSpans({ spans = [] }) {
    this._metrics.spansAggregated += spans.length;
    for (const span of spans) {
      this._spanBuffer.push({ ...span, receivedAt: Date.now() });
    }

    if (this._spanBuffer.length > TELEMETRY_CONFIG.maxSpanBuffer) {
      this._spanBuffer = this._spanBuffer.slice(-TELEMETRY_CONFIG.maxSpanBuffer);
    }

    const grouped = {};
    for (const s of this._spanBuffer) {
      const key = s.operationName || s.name || 'unknown';
      if (!grouped[key]) grouped[key] = { count: 0, totalDurationMs: 0 };
      grouped[key].count++;
      grouped[key].totalDurationMs += s.durationMs || 0;
    }

    const summary = Object.entries(grouped).map(([op, data]) => ({
      operation: op,
      count: data.count,
      avgDurationMs: Math.round(data.totalDurationMs / data.count),
    }));

    return { aggregated: spans.length, totalBuffered: this._spanBuffer.length, summary };
  }

  reportHealth({ nodeReports = [] } = {}) {
    this._metrics.healthChecksRun++;
    for (const report of nodeReports) {
      this._healthReports.set(report.name, {
        ...report,
        lastChecked: Date.now(),
      });
    }

    const allReports = [...this._healthReports.values()];
    const healthyCount = allReports.filter(r =>
      r.state === 'active' || r.state === 'ACTIVE' || r.coherenceScore >= CSL_THRESHOLDS.MEDIUM
    ).length;

    return {
      totalNodes: allReports.length,
      healthy: healthyCount,
      healthRatio: allReports.length > 0 ? healthyCount / allReports.length : 1,
      reports: allReports,
    };
  }

  async report() {
    return {
      ...await super.report(),
      metricBufferSize: this._metricBuffer.length,
      spanBufferSize: this._spanBuffer.length,
      healthReportsCount: this._healthReports.size,
      metrics: { ...this._metrics },
    };
  }

  async retire() {
    this._metricBuffer = [];
    this._spanBuffer = [];
    this._healthReports.clear();
    return super.retire();
  }
}

export { TelemetryBee as TelemetryBeeNode };
