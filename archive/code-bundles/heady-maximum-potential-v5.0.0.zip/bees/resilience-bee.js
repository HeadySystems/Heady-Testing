/**
 * ResilienceBee — Resilience Pattern Enforcement Worker
 *
 * Monitors and enforces circuit breakers, retries, and resilience patterns.
 * Part of the 33-type bee swarm registry.
 *
 * Sacred Geometry v4.0 — Zero Magic Numbers
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS, SIZING,
  phiBackoff, phiAdaptiveInterval, PRESSURE_LEVELS,
} from '../shared/phi-constants.js';

import { BaseHeadyBee } from './base-heady-bee.js';

const RESILIENCE_CONFIG = Object.freeze({
  failureThreshold:  SIZING.FAILURE_THRESHOLD,   // 5 failures → trip
  halfOpenProbes:    fib(3),                      // 2 probes in half-open
  resetTimeoutMs:    fib(8) * 1000,              // 21s before half-open
  maxRetries:        fib(6),                      // 8 retries max
  retryBaseMs:       fib(7) * 100,               // 1300ms base backoff
  healthWindowMs:    fib(9) * 1000,              // 34s sliding window
});

export class ResilienceBee extends BaseHeadyBee {
  constructor(config = {}) {
    super({
      name: config.name || 'ResilienceBee',
      type: 'resilience-bee',
      pool: 'warm',
      capabilities: [
        'circuit-breaker-enforcement', 'retry-monitoring',
        'resilience-assessment', 'violation-reporting', 'pressure-detection',
      ],
      ...config,
    });

    /** @type {Map<string, { state: string, failures: number, lastFailure: number, probes: number }>} */
    this._breakers = new Map();
    this._violations = [];
    this._metrics = {
      breakersMonitored: 0,
      tripsDetected: 0,
      retrySuggested: 0,
      assessmentsRun: 0,
      violationsReported: 0,
    };
  }

  async spawn(context = {}) {
    await super.spawn(context);
    this._breakers.clear();
    this._violations = [];
    this._log('info', 'ResilienceBee spawned', { config: RESILIENCE_CONFIG });
    return this;
  }

  async execute(task = {}) {
    this._transitionTo('thinking');
    const { operation, payload } = task;

    let result;
    switch (operation) {
      case 'circuit-breaker': result = this.enforceCircuitBreaker(payload); break;
      case 'retry':           result = this.monitorRetries(payload); break;
      case 'assess':          result = this.assessResilience(payload); break;
      case 'violations':      result = this.reportViolations(payload); break;
      default:                result = this.assessResilience(payload);
    }

    this._transitionTo('responding');
    return { status: 'completed', operation, result, metrics: { ...this._metrics } };
  }

  enforceCircuitBreaker({ serviceId, success = false, error = null }) {
    this._metrics.breakersMonitored++;
    let breaker = this._breakers.get(serviceId);
    if (!breaker) {
      breaker = { state: 'closed', failures: 0, lastFailure: 0, probes: 0 };
      this._breakers.set(serviceId, breaker);
    }

    const now = Date.now();

    if (breaker.state === 'open') {
      if (now - breaker.lastFailure >= RESILIENCE_CONFIG.resetTimeoutMs) {
        breaker.state = 'half-open';
        breaker.probes = 0;
      }
      return { serviceId, state: breaker.state, canExecute: breaker.state === 'half-open' };
    }

    if (breaker.state === 'half-open') {
      breaker.probes++;
      if (success) {
        if (breaker.probes >= RESILIENCE_CONFIG.halfOpenProbes) {
          breaker.state = 'closed';
          breaker.failures = 0;
        }
      } else {
        breaker.state = 'open';
        breaker.lastFailure = now;
        this._metrics.tripsDetected++;
      }
      return { serviceId, state: breaker.state, canExecute: breaker.state !== 'open' };
    }

    // closed state
    if (success) {
      breaker.failures = Math.max(0, breaker.failures - 1);
    } else {
      breaker.failures++;
      breaker.lastFailure = now;
      if (breaker.failures >= RESILIENCE_CONFIG.failureThreshold) {
        breaker.state = 'open';
        this._metrics.tripsDetected++;
        this._violations.push({
          type: 'circuit-breaker-trip', serviceId, failures: breaker.failures, timestamp: now,
        });
      }
    }

    return { serviceId, state: breaker.state, failures: breaker.failures, canExecute: true };
  }

  monitorRetries({ serviceId, attempt = 0, maxRetries = RESILIENCE_CONFIG.maxRetries }) {
    this._metrics.retrySuggested++;
    const shouldRetry = attempt < maxRetries;
    const delayMs = shouldRetry ? phiBackoff(attempt, RESILIENCE_CONFIG.retryBaseMs) : 0;

    if (!shouldRetry) {
      this._violations.push({
        type: 'max-retries-exceeded', serviceId, attempt, timestamp: Date.now(),
      });
      this._metrics.violationsReported++;
    }

    return { serviceId, shouldRetry, attempt, delayMs, maxRetries };
  }

  assessResilience({ services = [] } = {}) {
    this._metrics.assessmentsRun++;
    const assessments = services.map(svc => {
      const breaker = this._breakers.get(svc.id);
      const pressureLevel = svc.errorRate >= PRESSURE_LEVELS.CRITICAL.min ? 'critical'
        : svc.errorRate >= PRESSURE_LEVELS.HIGH.min ? 'high'
        : svc.errorRate >= PRESSURE_LEVELS.ELEVATED.min ? 'elevated'
        : 'nominal';

      return {
        serviceId: svc.id,
        breakerState: breaker?.state || 'unknown',
        pressureLevel,
        errorRate: svc.errorRate || 0,
        recommendation: pressureLevel === 'critical' ? 'shed-load'
          : pressureLevel === 'high' ? 'throttle'
          : 'normal',
      };
    });

    return { assessed: assessments.length, assessments };
  }

  reportViolations({ since = 0 } = {}) {
    const filtered = this._violations.filter(v => v.timestamp >= since);
    return { violations: filtered, total: this._violations.length };
  }

  async report() {
    return {
      ...await super.report(),
      breakerCount: this._breakers.size,
      violationCount: this._violations.length,
      metrics: { ...this._metrics },
    };
  }

  async retire() {
    this._breakers.clear();
    this._violations = [];
    return super.retire();
  }
}

export { ResilienceBee as ResilienceBeeNode };
