/**
 * MidiBee — MIDI Processing & Generative Music Bee
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 *
 * Processes MIDI events, generates Fibonacci-stepped note sequences,
 * synchronizes tempo using phi-scaled BPM, and maps musical patterns
 * to vector embeddings for CSL-gated similarity analysis.
 *
 * Ring: Outer | Pool: Cold | Domain: headyme.com
 *
 * @module midi-bee
 * @version 4.1.0
 */

import {
  PHI, PSI, FIB, fib,
  CSL_THRESHOLDS,
  cslGate, cosineSimilarity,
  SIZING,
} from '../shared/phi-constants.js';

import { BaseHeadyBee } from './base-heady-bee.js';

// ═══════════════════════════════════════════════════════════════
// MIDI CONSTANTS — phi-derived
// ═══════════════════════════════════════════════════════════════

/** Default BPM: round(PHI * fib(10)) = round(1.618 * 55) = 89 */
const DEFAULT_BPM = Math.round(PHI * fib(10));

/** MIDI velocity range: [fib(4), fib(7)] = [3, 13] mapped to 0-127 */
const VELOCITY_MIN = fib(4);
const VELOCITY_MAX = fib(7) * 10;

// ═══════════════════════════════════════════════════════════════
// MIDI BEE
// ═══════════════════════════════════════════════════════════════

/**
 * MidiBee — MIDI event processing, sequence generation, tempo sync, vector mapping.
 *
 * Processes MIDI note/CC events with phi-scaled velocity curves, generates
 * Fibonacci-stepped pitch sequences, synchronizes tempo using phi-BPM
 * ratios, and converts musical patterns to 384D vector embeddings.
 *
 * @extends BaseHeadyBee
 */
class MidiBee extends BaseHeadyBee {
  /**
   * @param {Object} [config={}]
   * @param {Object} [config.task] - Task descriptor
   */
  constructor(config = {}) {
    super({
      type: 'midi-bee',
      pool: 'cold',
      capabilities: ['midi-bee', 'midi-process', 'sequence-generate', 'tempo-sync', 'map-to-vector'],
      ...config,
    });

    /** @type {number} Current BPM — phi-scaled default */
    this.bpm = DEFAULT_BPM;

    /** @type {Object[]} Event buffer — bounded at FIB[9]=34 */
    this.eventBuffer = [];

    /** @type {Object[]} Generated sequences — bounded at FIB[8]=21 */
    this.sequences = [];

    this.midiMetrics = {
      eventsProcessed: 0,
      sequencesGenerated: 0,
      tempoSyncs: 0,
      vectorsMapped: 0,
    };
  }

  // ─────────────────────────────────────────────────────────────
  // TASK DISPATCH
  // ─────────────────────────────────────────────────────────────

  /**
   * Execute a MIDI task.
   * @param {Object} task
   * @param {string} task.type - process | generate | tempo | vector
   * @returns {Promise<Object>} Task result
   */
  async execute(task) {
    switch (task.type) {
      case 'process':  return this.processMidiEvent(task.event || task);
      case 'generate': return this.generateSequence(task.rootNote, task.steps);
      case 'tempo':    return this.syncTempo(task.targetBpm, task.reference);
      case 'vector':   return this.mapToVector(task.pattern || []);
      default:
        throw new Error(`MidiBee: unknown task type: ${task.type}`);
    }
  }

  // ─────────────────────────────────────────────────────────────
  // PROCESS MIDI EVENT
  // ─────────────────────────────────────────────────────────────

  /**
   * Process a MIDI event with phi-scaled velocity curve.
   * @param {Object} event - MIDI event descriptor
   * @param {string} event.kind - 'noteOn' | 'noteOff' | 'cc'
   * @param {number} event.note - MIDI note number (0-127)
   * @param {number} [event.velocity] - Raw velocity (0-127)
   * @param {number} [event.channel] - MIDI channel (0-15)
   * @returns {Object} Processed event with phi-scaled velocity
   */
  processMidiEvent(event) {
    if (!event || !event.kind) {
      throw new Error('MidiBee: processMidiEvent requires event with kind');
    }

    const rawVelocity = event.velocity || fib(7) * 8;
    // Phi-scaled velocity curve: apply PSI-power compression
    const normalizedV = Math.min(rawVelocity / 127, 1.0);
    const scaledV = Math.pow(normalizedV, PSI);
    const outputVelocity = Math.round(scaledV * 127);

    const processed = {
      kind: event.kind,
      note: event.note || 0,
      velocity: outputVelocity,
      channel: event.channel || 0,
      bpm: this.bpm,
      tickMs: Math.round(60000 / (this.bpm * fib(4))),
      processedAt: Date.now(),
    };

    this.eventBuffer.push(processed);
    while (this.eventBuffer.length > FIB[9]) {
      this.eventBuffer.shift();
    }

    this.midiMetrics.eventsProcessed++;
    this.logger.info({ kind: event.kind, note: event.note, velocity: outputVelocity }, 'MIDI event processed');

    return { event: processed, bufferSize: this.eventBuffer.length, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // GENERATE SEQUENCE
  // ─────────────────────────────────────────────────────────────

  /**
   * Generate a Fibonacci-stepped note sequence from a root note.
   * Intervals follow Fibonacci: [1, 1, 2, 3, 5, 8, 13, ...] semitones.
   * @param {number} [rootNote] - MIDI root note (default 60 = middle C)
   * @param {number} [steps] - Number of steps (default fib(6)=8)
   * @returns {Object} Generated sequence
   */
  generateSequence(rootNote, steps) {
    const root = rootNote || 60;
    const count = steps || fib(6);
    const notes = [{ note: root, velocity: fib(7) * 8, step: 0, interval: 0 }];

    let currentNote = root;
    for (let i = 1; i < count; i++) {
      const interval = FIB[i % FIB.length] || 1;
      // Alternate ascending/descending using PSI probability
      const direction = ((i * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff < PSI ? -1 : 1;
      currentNote = Math.max(0, Math.min(127, currentNote + interval * direction));

      const velocity = Math.round(fib(7) * 8 * Math.pow(PSI, i / count));
      notes.push({ note: currentNote, velocity: Math.max(1, velocity), step: i, interval: interval * direction });
    }

    const sequence = {
      id: `seq_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      rootNote: root,
      steps: count,
      notes,
      bpm: this.bpm,
      durationMs: Math.round((count * 60000) / (this.bpm * fib(4))),
    };

    this.sequences.push(sequence);
    while (this.sequences.length > FIB[8]) {
      this.sequences.shift();
    }

    this.midiMetrics.sequencesGenerated++;
    this.logger.info({ root, steps: count, notes: notes.length }, 'Sequence generated');

    return { sequence, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // SYNC TEMPO
  // ─────────────────────────────────────────────────────────────

  /**
   * Synchronize tempo using phi-scaled BPM ratios.
   * @param {number} [targetBpm] - Target BPM
   * @param {number} [reference] - Reference BPM to sync against
   * @returns {Object} Tempo sync result
   */
  syncTempo(targetBpm, reference) {
    const prevBpm = this.bpm;
    const ref = reference || DEFAULT_BPM;

    if (targetBpm) {
      this.bpm = targetBpm;
    } else {
      // Snap to nearest phi-harmonic of reference
      const ratios = [PSI * PSI, PSI, 1.0, PHI, PHI * PHI];
      const candidates = ratios.map(r => Math.round(ref * r));
      const nearest = candidates.reduce((best, c) =>
        Math.abs(c - prevBpm) < Math.abs(best - prevBpm) ? c : best
      );
      this.bpm = nearest;
    }

    const tickMs = Math.round(60000 / (this.bpm * fib(4)));
    const ratio = this.bpm / ref;
    const phiAligned = cslGate(1.0, 1.0 - Math.abs(ratio - Math.round(ratio / PSI) * PSI), CSL_THRESHOLDS.LOW);

    this.midiMetrics.tempoSyncs++;
    this.logger.info({ prevBpm, newBpm: this.bpm, ref, phiAligned: phiAligned.toFixed(4) }, 'Tempo synced');

    return { prevBpm, newBpm: this.bpm, reference: ref, tickMs, phiAligned, timestamp: new Date().toISOString() };
  }

  // ─────────────────────────────────────────────────────────────
  // MAP TO VECTOR
  // ─────────────────────────────────────────────────────────────

  /**
   * Map a musical pattern (array of MIDI notes) to a 384D vector embedding.
   * Uses pitch histogram + interval histogram normalized to unit length.
   * @param {number[]} pattern - Array of MIDI note numbers
   * @returns {Object} Vector embedding result
   */
  mapToVector(pattern) {
    if (!pattern || pattern.length === 0) {
      throw new Error('MidiBee: mapToVector requires a non-empty pattern');
    }

    const dim = FIB[14] + FIB[5] + FIB[3]; // 384
    const vector = new Array(dim).fill(0);

    // Pitch histogram: distribute notes across first 128 dims
    for (const note of pattern) {
      const idx = Math.min(Math.max(0, Math.round(note)), 127);
      vector[idx] += 1.0 / pattern.length;
    }

    // Interval histogram: distribute intervals across next 128 dims
    for (let i = 1; i < pattern.length; i++) {
      const interval = Math.abs(pattern[i] - pattern[i - 1]);
      const idx = 128 + Math.min(interval, 127);
      vector[idx] += 1.0 / (pattern.length - 1 || 1);
    }

    // Stats in remaining dims
    const mean = pattern.reduce((s, v) => s + v, 0) / pattern.length;
    const variance = pattern.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / pattern.length;
    vector[256] = mean / 127;
    vector[257] = Math.sqrt(variance) / 127;
    vector[258] = pattern.length / fib(10);

    // Normalize to unit length
    const norm = Math.sqrt(vector.reduce((s, v) => s + v * v, 0));
    if (norm > 0) {
      for (let i = 0; i < dim; i++) vector[i] /= norm;
    }

    this.midiMetrics.vectorsMapped++;
    this.logger.info({ patternLength: pattern.length, dim }, 'Pattern mapped to vector');

    return { embedding: vector, dim, patternLength: pattern.length, timestamp: new Date().toISOString() };
  }
}

export { MidiBee, MidiBee as default };
