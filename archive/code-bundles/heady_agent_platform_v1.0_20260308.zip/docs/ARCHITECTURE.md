# Heady Agent Platform Architecture

## System Overview

The Heady Agent Platform implements a hierarchical multi-agent orchestration system with:

### Topology
```
CENTER (Strategic Layer)
└── HeadySoul (orchestration, highest Fibonacci weight)

INNER RING (Tactical Layer - 5 swarms)
├── Cognition-Core (reasoning)
├── Memory-Weave (memory management)
├── Context-Bridge (context handling)
├── Task-Planner (planning)
└── Consensus-Forge (consensus)

MIDDLE RING (Operational Layer - 7 swarms)
├── Code-Artisan (coding)
├── Data-Sculptor (data processing)
├── Research-Herald (research)
├── Tool-Weaver (tool integration)
├── Language-Flow (NLP)
├── Vision-Scribe (vision tasks)
└── Audio-Pulse (audio processing)

OUTER RING (Edge Workers - 3 swarms)
├── Integration-Node (API integration)
├── Cache-Guardian (caching)
└── Stream-Runner (streaming)

GOVERNANCE (Policy Layer - 1 swarm)
└── Policy-Sentinel (compliance & governance)
```

## CSL Routing

Cosine Similarity Layer (CSL) gates all task routing decisions:

- **HIGH threshold**: 0.882 (strategic/critical tasks)
- **MEDIUM threshold**: 0.809 (tactical coordination)
- **LOW threshold**: 0.691 (operational tasks)

All thresholds derived from phi-harmonic levels: φⁿ

## Phi-Math Integration

Golden ratio (φ = 1.6180339887) governs all system parameters:

- **Resource weights**: Fibonacci-normalized per swarm
- **Queue depths**: fib(13) = 233 tasks
- **Backoff timings**: φ-exponential with ψ² jitter
- **Health check intervals**: Adaptive via φ/ψ scaling
- **Priority scoring**: task.weight × φ^(tier_depth)

## Integration Points

### External Frameworks
- **Transformers Agents 2.0**: Primary agent execution engine
- **SmolAgents**: Lightweight code-based agents for rapid tasks
- **ModelScope-Agent**: Semantic routing and tool retrieval

### Model Providers
- Qwen2.5-Coder-32B (coding swarms)
- DeepSeek-V3.1 (strategic reasoning)
- Llama-3.1-405B (HeadySoul center)
- Llama-3.1-8B (operational swarms)

### Infrastructure
- Node.js 20+ runtime
- MCP (Model Context Protocol) gateway
- Cloudflare Workers (edge compute)
- Docker/Podman containers
