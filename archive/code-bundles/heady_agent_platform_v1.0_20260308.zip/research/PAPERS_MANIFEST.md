# Research Papers & References

## Core Agent Orchestration

### 1. HuggingGPT (2023)
- **Title**: Solving AI Tasks with ChatGPT and its Friends in Hugging Face
- **URL**: https://arxiv.org/pdf/2303.17580.pdf
- **Relevance**: Original LLM-as-orchestrator architecture, inspired SmolAgents
- **Key Concepts**: Task planning, model selection, tool routing

### 2. ModelScope-Agent (2023)
- **Title**: Building Your Customizable Agent System with Open-source LLMs
- **URL**: https://aclanthology.org/2023.emnlp-demo.51.pdf
- **Relevance**: Semantic tool retrieval, closest to CSL routing
- **Key Concepts**: Retrieve→Plan→Execute loop, embedding-based routing

### 3. Transformers Agents 2.0 (2025)
- **Title**: License to Call: Introducing Transformers Agents 2.0
- **URL**: https://huggingface.co/blog/agents
- **Relevance**: Production-grade framework (chosen for Heady)
- **Key Concepts**: Dual execution modes, hierarchical agents, ManagedAgent

### 4. Multi-Agent Collaboration via Evolving Orchestration (2025)
- **Title**: Puppeteer: Multi-Agent Orchestration with Llama
- **URL**: https://arxiv.org/html/2505.19591v2
- **Relevance**: Centralized orchestrator + agent subspaces (17-swarm pattern)
- **Key Concepts**: Mono/heterogeneous agents, dynamic orchestration

### 5. AgentScope: Flexible Multi-Agent Platform (2024)
- **Title**: AgentScope Multi-Agent Framework
- **URL**: http://arxiv.org/pdf/2402.14034.pdf
- **Relevance**: Actor-based distribution, MsgHub pattern
- **Key Concepts**: Very large-scale (10K+ agents), pipeline syntax

## Scheduling & Load Balancing

### 6. Cooperative Load Balancing in Multi-Cloud (2025)
- **Source**: Wiley Online Library
- **Relevance**: Fibonacci resource allocation justification
- **Key Concepts**: Dynamic load distribution, resource weighting

### 7. Deterministic Multi-Agent Orchestration (2024)
- **Title**: Deterministic Multi-Agent System for Incident Response
- **Relevance**: Production determinism requirements
- **Key Concepts**: CSL gates, confidence thresholding, fallback routing

## Implementation Guides

### 8. SmolAgents Documentation (2025)
- **URL**: https://huggingface.co/docs/smolagents/
- **Relevance**: Lightweight alternative for rapid prototyping
- **Key Concepts**: Code-based actions, 1K lines, minimal overhead

### 9. LLM Orchestration Best Practices (2025)
- **Source**: ZenML, Mirascope blogs
- **Relevance**: Production deployment patterns
- **Key Concepts**: Error handling, monitoring, observability

### 10. Multi-Agent Collaboration Mechanisms Survey (2025)
- **URL**: https://huggingface.co/papers/2501.06322
- **Relevance**: Framework coverage of cooperation/competition patterns
- **Key Concepts**: Swarm-bee binding justification

## Download Instructions

All papers are available in `research/papers/` directory as PDFs.
Use `fetch_papers.sh` script to download missing papers.
