// Full implementation from attached file
// See 02-swarm-orchestration-optimization.md for complete source
