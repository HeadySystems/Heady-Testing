#!/bin/bash
# Heady Agent Platform Quick Start

echo "🚀 Heady Agent Platform Setup"
echo "=============================="

# Check prerequisites
command -v node >/dev/null 2>&1 || { echo "❌ Node.js required"; exit 1; }
command -v npm >/dev/null 2>&1 || { echo "❌ npm required"; exit 1; }

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Setup environment
if [ ! -f .env ]; then
    echo "⚙️  Creating .env from template..."
    cp .env.example .env
    echo "⚠️  Please edit .env and add your API keys"
fi

# Run tests
echo "🧪 Running tests..."
npm test

echo "✅ Setup complete!"
echo "Next steps:"
echo "1. Edit .env with your API keys"
echo "2. npm run dev     # Start development server"
echo "3. npm run build   # Build production"
echo "4. npm start       # Run production server"
