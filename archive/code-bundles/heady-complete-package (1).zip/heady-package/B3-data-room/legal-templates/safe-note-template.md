# SAFE Note Template — HeadySystems Inc.
## Post-Money Simple Agreement for Future Equity

**CONFIDENTIAL — Template Document**  
*Last Updated: March 2026*

> ⚠️ **LEGAL DISCLAIMER:** This document is a template for discussion purposes only. It is based on the Y Combinator Post-Money SAFE (2018 version). This template has not been reviewed by legal counsel for use in any specific transaction. Neither HeadySystems Inc. nor any of its representatives make any representation that this template is appropriate for any particular investment. **Both parties must consult qualified legal counsel before executing any investment agreement.** This document does not constitute legal advice.

---

## SAFE Summary Terms

| Term | Value |
|------|-------|
| **Instrument** | Post-Money SAFE (Simple Agreement for Future Equity) |
| **Valuation Cap** | $10,000,000 – $15,000,000 (to be negotiated) |
| **Discount Rate** | 20% |
| **Pro Rata Rights** | Yes — investor may participate in next equity round |
| **MFN (Most Favored Nation)** | Yes — if Company issues SAFEs on better terms, this SAFE automatically updates |
| **Interest** | None |
| **Maturity Date** | None — converts at Equity Financing, Liquidity Event, or Dissolution |

---

## SIMPLE AGREEMENT FOR FUTURE EQUITY

**THIS CERTIFIES THAT** in exchange for the payment by [INVESTOR NAME] (the "Investor") of [INVESTMENT AMOUNT] (the "Purchase Amount") on or about [DATE], HeadySystems Inc., a Delaware corporation (the "Company"), hereby issues to the Investor the right to certain shares of the Company's capital stock, subject to the terms set forth below.

**The "Post-Money Valuation Cap"** is $[___________].

**The "Discount Rate"** is 80%.

---

## 1. Events

### (a) Equity Financing

If there is an Equity Financing before the expiration or termination of this instrument, the Company will automatically issue to the Investor a number of shares of Safe Preferred Stock equal to the Purchase Amount divided by the Conversion Price.

**"Conversion Price"** means the lesser of:
1. The Safe Price (Purchase Amount ÷ Post-Money Valuation Cap × number of Company Shares Outstanding immediately prior to the Equity Financing on a Fully Diluted Basis); or
2. The Discount Price (the price per share of the Standard Preferred Stock sold in the Equity Financing multiplied by the Discount Rate)

### (b) Liquidity Event

If there is a Liquidity Event before the expiration or termination of this instrument, the Investor will, at its option, either:
1. Receive a cash payment equal to the Purchase Amount; or
2. Automatically receive from the Company a number of shares of Common Stock equal to the Purchase Amount divided by the Liquidity Price.

**"Liquidity Price"** means the fair market value of Common Stock at the time of the Liquidity Event, as determined by reference to the Liquidity Capitalization.

### (c) Dissolution Event

If there is a Dissolution Event before this instrument expires or terminates, the Company will pay an amount equal to the Purchase Amount, due and payable to the Investor immediately prior to, or concurrent with, the consummation of the Dissolution Event.

---

## 2. Definitions

**"Company Capitalization"** means the sum, as of immediately prior to the Equity Financing, of: (1) all shares of Capital Stock (on an as-converted basis) issued and outstanding, assuming exercise or conversion of all outstanding vested and unvested options, warrants and other convertible securities, but excluding: (A) this instrument, (B) other Safes, (C) convertible promissory notes.

**"Equity Financing"** means a bona fide transaction or series of transactions with the principal purpose of raising capital, pursuant to which the Company issues and sells Preferred Stock at a fixed pre-money valuation. The Equity Financing must be at least $1,000,000 in aggregate proceeds to the Company.

**"Fully Diluted Basis"** means the aggregate number of issued and outstanding shares of Capital Stock of the Company, assuming full conversion or exercise of all convertible and exercisable securities, including all shares of Capital Stock reserved and available for future grant under any equity incentive or similar plan of the Company.

**"Liquidity Event"** means a Change of Control or an IPO.

**"Change of Control"** means: (i) a transaction or series of related transactions in which any person becomes the beneficial owner of more than 50% of the outstanding voting securities of the Company; (ii) a reorganization, merger or consolidation in which the holders of the Company's outstanding voting securities before the transaction hold less than 50% after the transaction; or (iii) a sale, transfer or other disposition of all or substantially all of the assets of the Company.

**"Safe Preferred Stock"** means the shares of a series of Preferred Stock issued to the Investor in an Equity Financing, having the identical rights, privileges, preferences and restrictions as the shares of Standard Preferred Stock.

---

## 3. Company Representations

In connection with the issuance of this Safe, the Company represents and warrants to the Investor that:

(a) The Company is a corporation duly organized, validly existing and in good standing under the laws of the State of Delaware.

(b) The execution, delivery and performance by the Company of this Safe is within the power of the Company and has been duly authorized by all necessary actions on the part of the Company.

(c) This Safe constitutes a legal, valid and binding obligation of the Company, enforceable against the Company in accordance with its terms.

(d) The Company is not in violation of any of the provisions of the Company's certificate of incorporation or bylaws in any material respect, and is not in violation of any judgment, order, writ, injunction, decree, rule or regulation applicable to the Company or its properties or assets.

---

## 4. Investor Representations

The Investor represents and warrants that:

(a) The Investor has the full legal capacity, power and authority to execute and deliver this Safe and to perform its obligations hereunder.

(b) This Safe constitutes a valid and binding obligation of the Investor, enforceable in accordance with its terms.

(c) The Investor is an accredited investor as such term is defined in Rule 501 of Regulation D under the Securities Act of 1933, as amended ("Securities Act").

(d) The Investor understands that the Company's business is speculative and involves a high degree of risk, and the Investor is capable of bearing such risk, including the complete loss of the investment.

(e) The Investor is purchasing this Safe solely for its own account for investment purposes, and not with a view to, or for offer or sale in connection with, any distribution thereof.

---

## 5. Pro Rata Rights Agreement

**Pro Rata Rights.** Subject to the limitations set forth herein, the Investor shall have the right to purchase its pro rata share of all Equity Securities in each subsequent equity financing of the Company.

"Pro Rata Share" means the ratio of (x) the number of shares of the Company's Common Stock issued or issuable upon conversion of this Safe owned by such Investor, to (y) the total number of shares of the Company's Common Stock issued or issuable upon conversion of all Safes and all Preferred Stock of the Company.

The Investor shall have 10 business days from the date of written notice from the Company to exercise its pro rata right by delivering written notice to the Company and paying the aggregate purchase price.

---

## 6. Most Favored Nation (MFN)

In the event that, after the date of this Safe and before the next Equity Financing, the Company issues a Safe to any third party at a Valuation Cap that is less than the Valuation Cap set forth in this Safe, or containing terms otherwise more favorable to such third party than the terms of this Safe, then the Company shall promptly notify the Investor in writing of such issuance, and the Investor shall have the option to elect (by written notice to the Company delivered within 20 days of such notification) to have this Safe amended to reflect the more favorable terms.

---

## 7. Miscellaneous

(a) **Governing Law.** This Safe shall be governed by the laws of the State of Delaware, without regard to the conflicts of law provisions of such laws.

(b) **Amendments; Waivers.** Any provision of this Safe may be amended, waived or modified by written consent of the Company and the Investor.

(c) **Severability.** In the event any provision of this Safe is found to be invalid, illegal or unenforceable, the remainder of this Safe will be enforceable.

(d) **Counterparts.** This Safe may be executed in two or more counterparts, each of which shall be deemed an original.

(e) **Entire Agreement.** This Safe constitutes the full and entire understanding and agreement between the parties with regard to the subjects hereof.

---

## Signature Block

**IN WITNESS WHEREOF**, the undersigned have executed this Safe as of the date first written above.

**HEADYSYSTEMS INC.**

By: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Name: Eric Haywood

Title: Founder / CEO

Date: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

---

**INVESTOR:**

By: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Name: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Title: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Entity: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Date: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Investment Amount: $\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

---

*Template based on Y Combinator Post-Money SAFE (2018). Consult legal counsel before executing. This template does not constitute legal advice.*
