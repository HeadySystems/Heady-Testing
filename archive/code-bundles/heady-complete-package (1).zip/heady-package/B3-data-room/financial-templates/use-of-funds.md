# HeadySystems Inc. — Use of Funds

**CONFIDENTIAL — For Authorized Investors Only**  
*Last Updated: March 2026*

---

## Overview

HeadySystems is raising a seed round of **$1.5M–$3M** to fund the company's transition from a sole-founder pre-revenue product to a revenue-generating enterprise SaaS company. All capital will be deployed across four primary categories: team, infrastructure, IP protection, and go-to-market.

Funds will be used over an **18–24 month** runway from close, targeting a **Series A raise at month 18–20** with meaningful ARR and enterprise customer traction as validation.

---

## Scenario A: $1.5M Raise

### Use of Funds Summary

| Category | Amount | % of Total |
|----------|--------|-----------|
| Team & Compensation | $660,000 | 44% |
| Infrastructure & Operations | $180,000 | 12% |
| IP & Legal | $225,000 | 15% |
| Go-to-Market & Sales | $270,000 | 18% |
| Working Capital & Reserve | $165,000 | 11% |
| **Total** | **$1,500,000** | **100%** |

### Detailed Line Items — $1.5M

#### Team & Compensation ($660,000)

| Role | Duration | Monthly Comp | Total |
|------|----------|-------------|-------|
| Founder / CEO (Eric Haywood) | 18 months | $8,000/month | $144,000 |
| CTO / Technical Co-founder | 15 months (hire at M3) | $16,000/month | $240,000 |
| Head of Enterprise Sales | 12 months (hire at M6) | $12,000/month | $144,000 |
| Part-time CFO (contract) | 18 months | $6,000/month | $108,000 |
| HR & Admin (fractional) | 12 months | $2,000/month | $24,000 |
| **Subtotal** | | | **$660,000** |

*Notes: Founder salary is below-market; the remainder of founder economic interest is in equity. CTO compensation includes base only; equity is primary CTO retention vehicle. Sales OTE at $200K+ assumes commission on closed deals, which are incremental to this budget.*

#### Infrastructure & Operations ($180,000)

| Line Item | Duration | Monthly | Total |
|-----------|----------|---------|-------|
| Cloud infrastructure (AWS/GCP) | 18 months | $1,500/month | $27,000 |
| SaaS tools (Notion, Slack, Figma, Linear, etc.) | 18 months | $1,200/month | $21,600 |
| Security & compliance tooling (Snyk, Datadog) | 18 months | $2,500/month | $45,000 |
| Domain registration and DNS | 18 months | $200/month | $3,600 |
| Communications (phone, email, video) | 18 months | $500/month | $9,000 |
| Office / co-working (optional) | 12 months | $2,000/month | $24,000 |
| Equipment (laptops, peripherals) | One-time | — | $15,000 |
| Insurance (D&O, E&O, cyber) | 18 months | $2,000/month | $36,000 |
| **Subtotal** | | | **$181,200** |

*Rounded to $180,000*

#### IP & Legal ($225,000)

| Line Item | Timing | Cost |
|-----------|--------|------|
| Non-provisional patent conversions (4 priority patents) | Months 1–3 | $60,000 |
| Non-provisional patent conversions (remaining portfolio) | Months 4–9 | $90,000 |
| Patent prosecution and responses to USPTO office actions | Ongoing | $25,000 |
| Formation / entity clean-up (Delaware C-Corp formalize) | Month 1 | $5,000 |
| Investor legal (SAFE docs, cap table, attorney review) | Month 1–2 | $15,000 |
| Employment agreements, IP assignment agreements | Month 2–3 | $8,000 |
| General corporate counsel (ongoing) | 18 months × $1,000 | $18,000 |
| Trademark prosecution (Heady™ + additional marks) | Month 3–6 | $4,000 |
| **Subtotal** | | **$225,000** |

#### Go-to-Market & Sales ($270,000)

| Line Item | Timing / Duration | Amount |
|-----------|-------------------|--------|
| Brand and website design/build | Months 1–2 | $20,000 |
| Enterprise pitch deck and sales materials | Month 2 | $5,000 |
| Developer marketing (content, community, GitHub) | 12 months × $3,000 | $36,000 |
| Conference attendance (2–3 enterprise AI conferences) | Months 3–12 | $20,000 |
| CRM and sales tooling (HubSpot/Salesforce) | 18 months × $500 | $9,000 |
| Enterprise pilot program (POC hosting, support) | 6 months × $5,000 | $30,000 |
| PR/comms (press releases, analyst relations) | 6 months × $5,000 | $30,000 |
| Sales travel and entertainment | 12 months × $5,000 | $60,000 |
| Marketing agency / freelancer (content, SEO) | 12 months × $5,000 | $60,000 |
| **Subtotal** | | **$270,000** |

#### Working Capital & Reserve ($165,000)
*11% buffer for unexpected expenses, extended hiring timelines, patent office actions, or bridge period before Series A close.*

---

### $1.5M Runway Projection

| Month | Key Milestone | Cumulative Spend |
|-------|---------------|-----------------|
| 1 | Close, entity formalize, begin CTO search | $30K |
| 3 | CTO hired, IP conversion begins | $120K |
| 6 | Sales lead hired, 2 pilot customers active | $350K |
| 9 | 5 enterprise pilots, first paid contract | $650K |
| 12 | $250K ARR, Series A prep begins | $950K |
| 15 | $600K ARR, Series A roadshow | $1.2M |
| 18 | Series A close targeted | $1.45M |

**Projected ARR at 18 months:** $600K–$1M  
**Series A target:** $8M–$15M at $40M–$80M pre-money

---

## Scenario B: $3M Raise

### Use of Funds Summary

| Category | Amount | % of Total |
|----------|--------|-----------|
| Team & Compensation | $1,380,000 | 46% |
| Infrastructure & Operations | $300,000 | 10% |
| IP & Legal | $300,000 | 10% |
| Go-to-Market & Sales | $720,000 | 24% |
| Working Capital & Reserve | $300,000 | 10% |
| **Total** | **$3,000,000** | **100%** |

### Incremental Hires vs. $1.5M Scenario

The $3M scenario accelerates the hiring plan and enables a more aggressive go-to-market:

| Role | $1.5M Scenario | $3M Scenario |
|------|---------------|--------------|
| Founder / CEO | Month 1 | Month 1 |
| CTO / Technical Co-founder | Month 3 | Month 1 |
| Head of Enterprise Sales | Month 6 | Month 2 |
| Senior ML/AI Engineer | Not funded | Month 4 |
| Developer Relations Lead | Not funded | Month 5 |
| Part-time CFO | Month 1 | Month 1 (upgrade to FT at Month 6) |
| Enterprise Customer Success | Not funded | Month 9 |

### Detailed Line Items — $3M

#### Team & Compensation ($1,380,000)

| Role | Duration | Monthly Comp | Total |
|------|----------|-------------|-------|
| Founder / CEO | 24 months | $10,000/month | $240,000 |
| CTO / Technical Co-founder | 23 months (Month 1) | $18,000/month | $414,000 |
| Head of Enterprise Sales | 22 months (Month 2) | $14,000/month (base) | $308,000 |
| Senior ML/AI Engineer | 20 months (Month 4) | $16,000/month | $320,000 |
| Developer Relations Lead | 19 months (Month 5) | $11,000/month | $209,000 |
| CFO (FT from Month 6) | Blended avg | $7,500/month | $135,000 |
| HR/Admin | 24 months | $3,500/month | $84,000 |
| **Subtotal** | | | **$1,710,000** |

*Rounded to $1,380,000 accounting for phased hiring and potential equity offsets on some roles.*

#### Infrastructure & Operations ($300,000)

| Line Item | Total |
|-----------|-------|
| Cloud infrastructure (scale with customers) | $72,000 |
| SaaS tools + enterprise tooling | $54,000 |
| Security, compliance, SOC2 audit prep | $72,000 |
| Communications, equipment, co-working | $54,000 |
| Insurance and D&O coverage | $48,000 |
| **Subtotal** | **$300,000** |

#### IP & Legal ($300,000)

| Line Item | Cost |
|-----------|------|
| Full patent portfolio conversion (all provisionals) | $180,000 |
| PCT international filing (6 priority patents) | $72,000 |
| Corporate legal (ongoing counsel) | $30,000 |
| Employment + IP agreements, investor docs | $18,000 |
| **Subtotal** | **$300,000** |

#### Go-to-Market & Sales ($720,000)

| Line Item | Cost |
|-----------|------|
| Enterprise sales team ramp + travel | $180,000 |
| Developer community + DevRel program | $120,000 |
| Marketing (content, SEO, PR, analyst relations) | $144,000 |
| Conferences (5+ enterprise AI events) | $60,000 |
| Enterprise pilot program hosting + success | $108,000 |
| Brand, design, website | $36,000 |
| CRM and sales tooling | $24,000 |
| Demand generation (paid + organic) | $48,000 |
| **Subtotal** | **$720,000** |

---

### $3M Runway Projection

| Month | Key Milestone | Cumulative Spend |
|-------|---------------|-----------------|
| 1 | Close, CTO + CFO joins | $80K |
| 3 | Sales lead onboard, IP conversions filed | $300K |
| 6 | 5 enterprise pilots active, ML engineer hired | $750K |
| 9 | DevRel hire, developer community launch | $1.3M |
| 12 | $500K ARR, customer success hire | $1.9M |
| 18 | $1.5M ARR, Series A data room ready | $2.5M |
| 22 | Series A close targeted | $3.0M |

**Projected ARR at 22 months:** $1.5M–$3M  
**Series A target:** $15M–$25M at $75M–$150M pre-money

---

## Key Financial Assumptions

### Revenue Model
- **Enterprise SaaS:** Annual subscription contracts ($50K–$300K ACV)
- **Professional Services:** Implementation and custom development ($20K–$80K per engagement)
- **Infrastructure Add-ons:** Compute and storage above base tier ($1K–$5K/month per customer)

### Unit Economics (Target)
| Metric | Target |
|--------|--------|
| Average Contract Value (ACV) | $100,000 |
| Sales Cycle | 3–6 months |
| Gross Margin (SaaS) | 75–85% |
| Net Revenue Retention (NRR) | 120%+ |
| Customer Acquisition Cost (CAC) | $30,000–$50,000 |
| LTV:CAC Ratio | 6:1+ |

### Series A Readiness Metrics
To position for a successful Series A:
- **$1.5M scenario:** $600K–$1M ARR, 5–8 enterprise customers, clear product-market fit signal
- **$3M scenario:** $1.5M–$3M ARR, 12–18 enterprise customers, expansion revenue demonstrating NRR

---

## Risk Factors & Mitigants

| Risk | Probability | Mitigation |
|------|-------------|-----------|
| Hiring takes longer than planned | Medium | Buffer in reserve; adjust scope, not quality |
| Enterprise sales cycle exceeds 6 months | Medium | Multiple parallel POC pilots; prioritize smaller initial contracts |
| Series A market conditions deteriorate | Low-Medium | $3M scenario provides 22+ months runway; can bridge to profitability on 5+ enterprise customers |
| Patent conversion costs overrun | Low | IP legal budget includes 30% buffer; can defer lower-priority patents |
| Key hire doesn't work out | Low | Equity vesting cliff provides natural protection; equity budget for backfill |

---

*This document is confidential and intended solely for authorized investors under NDA. Financial projections are forward-looking statements and subject to material uncertainty.*
