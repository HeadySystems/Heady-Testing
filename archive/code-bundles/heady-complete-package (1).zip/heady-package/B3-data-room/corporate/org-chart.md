# HeadySystems Inc. — Organization Chart & Hiring Plan

**CONFIDENTIAL — For Authorized Investors Only**  
*Last Updated: March 2026*

---

## Current Organization (Pre-Seed)

```
┌─────────────────────────────────────────────────────┐
│              HeadySystems Inc.                      │
│                                                     │
│         Eric Haywood — Founder / CEO               │
│                                                     │
│   Engineering  ·  Product  ·  Operations  ·  IP    │
└─────────────────────────────────────────────────────┘
```

### Eric Haywood — Founder / CEO
**Functional Responsibilities:**
- **Engineering:** Full-stack architecture, 21 microservices, CI/CD, all production code
- **Product:** Feature roadmap, UX/DX design, API design, developer experience
- **Operations:** Entity management (HeadySystems + HeadyConnection), legal coordination, domain portfolio
- **IP:** Inventor of record on all 51+ patent applications, USPTO filings management
- **Finance:** Bookkeeping, entity compliance, investor relations
- **Marketing:** Brand strategy, domain infrastructure, technical positioning
- **Sales:** Relationship development, enterprise pipeline (pre-hire)

**Capacity Assessment:** Current scope is at maximum single-founder capacity. Seed funding enables delegation and specialization across all functions.

---

## Target Organization (Post-Seed, Month 6)

```
┌─────────────────────────────────────────────────────────────────┐
│                      HeadySystems Inc.                          │
│                                                                 │
│              Eric Haywood — Founder / CEO                      │
│         ┌──────────────┬──────────────┬──────────────┐         │
│         │              │              │              │         │
│      CTO/Co-       Head of        Senior         Dev Rel      │
│      founder       Enterprise     ML/AI          Lead         │
│                    Sales          Engineer                     │
│                         │                                      │
│                    Part-time CFO (contract)                    │
└─────────────────────────────────────────────────────────────────┘
```

---

## Planned Hires — Seed Funding

### 1. CTO / Technical Co-Founder
**Priority:** Hire #1 (within 60 days of close)  
**Compensation:** Equity-heavy (4–8% with 4-year vest, 1-year cliff) + market salary ($180K–$220K)  
**Profile:**
- 8+ years senior engineering, ideally distributed systems or AI infrastructure
- Track record building production AI/ML systems at scale
- Experience managing engineering teams and technical roadmaps
- Familiarity with TypeScript/Node.js ecosystem a plus
- Bonus: Patent co-inventor experience or IP strategy exposure

**Responsibilities:**
- Own engineering roadmap and technical architecture alongside Eric
- Lead infrastructure build-out for multi-tenant SaaS
- Manage future engineering hires
- Drive non-provisional patent conversion strategy with legal counsel
- Represent technical depth to enterprise customers and future investors

---

### 2. Head of Enterprise Sales
**Priority:** Hire #2 (within 90 days of close)  
**Compensation:** Base $120K–$160K + commission (OTE $200K–$280K) + equity (1–2%)  
**Profile:**
- 7+ years enterprise SaaS sales (AI/data/security verticals preferred)
- Proven track record closing $100K+ ACV deals
- Existing relationships with enterprise CTO/CIO-level buyers
- Experience selling technical infrastructure to non-technical decision-makers
- Comfort with long sales cycles and proof-of-concept pilot structures

**Responsibilities:**
- Build and manage enterprise pipeline from zero
- Define and execute ICP (Ideal Customer Profile) targeting
- Lead pilot program design and customer success for first 5 enterprise accounts
- Develop pricing and packaging strategy with founder
- Contribute to Series A fundraising narrative with revenue data

---

### 3. Senior ML/AI Engineer
**Priority:** Hire #3 (within 120 days of close)  
**Compensation:** $160K–$200K + equity (0.5–1.5%)  
**Profile:**
- Deep expertise in LLM integration, embeddings, vector databases
- Experience with production AI systems (not just research/Jupyter notebooks)
- Familiarity with agent orchestration patterns
- Strong Python and TypeScript/JavaScript skills
- Background in applied mathematics a strong plus (relevant to CSL/phi-scaling)

**Responsibilities:**
- Extend and optimize the CSL (Continuous Semantic Logic) engine
- Build and maintain vector storage and semantic search layers
- Develop training pipelines for domain-specific model fine-tuning
- Contribute to patent applications for new AI innovations
- Support enterprise customers on AI integration challenges

---

### 4. Developer Relations Lead
**Priority:** Hire #4 (within 150 days of close)  
**Compensation:** $120K–$150K + equity (0.25–0.75%)  
**Profile:**
- Developer relations or developer advocacy background
- Strong public technical communication (writing, talks, demos)
- Experience building developer communities around APIs/SDKs
- Familiarity with open-source ecosystem dynamics
- Network within AI/ML developer communities

**Responsibilities:**
- Build and manage developer community (Discord, GitHub, newsletter)
- Create technical content: tutorials, case studies, documentation
- Manage public GitHub presence (github.com/HeadyMe)
- Represent HeadySystems at conferences and hackathons
- Drive bottom-up enterprise adoption through developer champions

---

### 5. Part-Time CFO / Finance (Contract)
**Priority:** Engage immediately post-close  
**Compensation:** Contract ($5K–$8K/month)  
**Profile:**
- CFO-level finance professional with startup/VC-backed company experience
- Familiarity with Delaware C-Corp compliance, 409A valuations, cap table management
- Experience preparing companies for Series A due diligence
- Network with Big 4 audit relationships preferred

**Responsibilities:**
- Establish financial reporting infrastructure
- Manage cap table (Carta or equivalent)
- Lead 409A valuation process
- Prepare financial projections and models for Series A
- Coordinate with legal on SAFE note administration and investor relations

---

## Advisory Board

**Status:** Currently seeking advisors. Target profile:

| Seat | Target Background | Status |
|------|-------------------|--------|
| Technical Advisor (AI/ML) | Senior AI researcher, professor, or CTO at AI company | Seeking |
| Enterprise Sales Advisor | VP/SVP Sales at enterprise SaaS company ($100M+ ARR) | Seeking |
| IP Strategy Advisor | Patent attorney with AI/software patent experience | Seeking |
| Investor Advisor | LP or GP at top-tier VC with AI portfolio | Seeking |
| Industry Advisor | CTO/CIO at target enterprise vertical | Seeking |

**Advisory Compensation:** Standard 0.1–0.25% equity with 2-year vest, no cliff, subject to Board approval post-formation.

---

## Organizational Philosophy

HeadySystems is built on a **technical-first hiring culture**. Every early hire must be able to build, not just manage. The organizational structure prioritizes:

1. **Density of impact per headcount:** Small teams with extreme individual output
2. **IP consciousness:** All engineers sign IP assignment agreements; inventions are assets
3. **Security by default:** Every hire undergoes background check; all systems access is role-based
4. **Ownership culture:** Equity compensation is meaningful, not symbolic

The target is **10–12 people by end of Year 1** post-seed close. The company is not optimizing for headcount growth — it is optimizing for revenue per employee and IP generation velocity.

---

## Headcount Plan by Quarter (Post-Seed Close)

| Quarter | Hires | Total Headcount | Key Milestone |
|---------|-------|-----------------|---------------|
| Q1 | CTO, Part-time CFO | 3 | Architecture review complete |
| Q2 | Head of Enterprise Sales, Senior ML/AI Eng | 5 | First 2 enterprise pilots signed |
| Q3 | Dev Rel Lead, 1 Engineer | 7 | Community launch, 5 pilots active |
| Q4 | 2 Engineers, 1 Customer Success | 10 | First paid contracts closed |

---

*This document is confidential and intended solely for authorized investors under NDA.*
