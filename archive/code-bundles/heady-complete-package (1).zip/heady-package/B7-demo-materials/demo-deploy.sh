#!/bin/bash
# =============================================================================
# HeadySystems Inc. — Demo Deployment Script
# Version: 1.0.0 | March 2026
# Contact: eric@headyconnection.org
# 
# One-command demo deployment for HeadyOS.
# Checks prerequisites, pulls latest code, builds all services,
# starts the full system via docker-compose, runs health checks,
# and opens the admin portal in your default browser.
#
# Requirements:
#   - Docker 24+ (with docker-compose plugin or docker-compose v2)
#   - Node.js 20+
#   - pnpm 8+
#   - git
#   - curl
#   - 16GB RAM (8GB minimum)
#   - 20GB free disk space
#
# Usage:
#   chmod +x demo-deploy.sh
#   ./demo-deploy.sh                     # Standard demo deploy
#   ./demo-deploy.sh --local             # Use existing local repo (no git pull)
#   ./demo-deploy.sh --reset             # Wipe state and redeploy from scratch
#   ./demo-deploy.sh --port 4000         # Run on custom port (default: 3000)
#   ./demo-deploy.sh --no-browser        # Skip browser auto-open
# =============================================================================

set -euo pipefail

# ─── CONFIGURATION ──────────────────────────────────────────────────────────
REPO_URL="https://github.com/headysystems/headyos"
REPO_DIR="${HEADY_REPO_DIR:-$(pwd)/headyos}"
ADMIN_PORT="${HEADY_PORT:-3000}"
COMPOSE_FILE="docker-compose.yml"
HEALTH_CHECK_URL="http://localhost:${ADMIN_PORT}/health"
HEALTH_CHECK_RETRIES=30
HEALTH_CHECK_INTERVAL=5
LOG_FILE="/tmp/heady-deploy-$(date +%Y%m%d-%H%M%S).log"
OPEN_BROWSER=true
LOCAL_ONLY=false
RESET=false

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ─── ARGUMENT PARSING ────────────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case $1 in
    --local)       LOCAL_ONLY=true; shift ;;
    --reset)       RESET=true; shift ;;
    --no-browser)  OPEN_BROWSER=false; shift ;;
    --port)        ADMIN_PORT="$2"; HEALTH_CHECK_URL="http://localhost:${ADMIN_PORT}/health"; shift 2 ;;
    --repo-dir)    REPO_DIR="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: $0 [--local] [--reset] [--no-browser] [--port PORT] [--repo-dir DIR]"
      exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ─── HELPER FUNCTIONS ────────────────────────────────────────────────────────
log()     { echo -e "${CYAN}[HEADY]${NC} $1" | tee -a "$LOG_FILE"; }
success() { echo -e "${GREEN}[  OK  ]${NC} $1" | tee -a "$LOG_FILE"; }
warn()    { echo -e "${YELLOW}[ WARN ]${NC} $1" | tee -a "$LOG_FILE"; }
error()   { echo -e "${RED}[ FAIL ]${NC} $1" | tee -a "$LOG_FILE"; exit 1; }
header()  { echo -e "\n${BOLD}${CYAN}━━━ $1 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }

command_exists() { command -v "$1" &>/dev/null; }

open_browser() {
  local url="$1"
  if command_exists xdg-open; then
    xdg-open "$url" &>/dev/null &
  elif command_exists open; then
    open "$url" &>/dev/null &
  elif command_exists start; then
    start "$url" &>/dev/null &
  else
    warn "Could not auto-open browser. Navigate to: $url"
  fi
}

# ─── BANNER ─────────────────────────────────────────────────────────────────
echo -e "
${CYAN}${BOLD}
  ██╗  ██╗███████╗ █████╗ ██████╗ ██╗   ██╗ ██████╗ ███████╗
  ██║  ██║██╔════╝██╔══██╗██╔══██╗╚██╗ ██╔╝██╔═══██╗██╔════╝
  ███████║█████╗  ███████║██║  ██║ ╚████╔╝ ██║   ██║███████╗
  ██╔══██║██╔══╝  ██╔══██║██║  ██║  ╚██╔╝  ██║   ██║╚════██║
  ██║  ██║███████╗██║  ██║██████╔╝   ██║   ╚██████╔╝███████║
  ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝    ╚═╝    ╚═════╝ ╚══════╝
${NC}
${BOLD}  HeadyOS Demo Deployment v1.0.0${NC}
  The AI-Native Autonomous Operating System
  $(date '+%Y-%m-%d %H:%M:%S %Z')
  Log: ${LOG_FILE}
" | tee "$LOG_FILE"

# ─── STEP 1: PREREQUISITES ───────────────────────────────────────────────────
header "STEP 1: Checking Prerequisites"

# Docker
if ! command_exists docker; then
  error "Docker not found. Install Docker Desktop from https://docker.com/get-started"
fi
DOCKER_VERSION=$(docker --version | grep -oP '\d+\.\d+' | head -1)
success "Docker $DOCKER_VERSION found"

# Docker daemon
if ! docker info &>/dev/null; then
  error "Docker daemon is not running. Start Docker Desktop and retry."
fi
success "Docker daemon is running"

# docker-compose (v2 plugin or standalone)
if docker compose version &>/dev/null 2>&1; then
  COMPOSE_CMD="docker compose"
  COMPOSE_VERSION=$(docker compose version --short)
  success "docker compose plugin v${COMPOSE_VERSION} found"
elif command_exists docker-compose; then
  COMPOSE_CMD="docker-compose"
  COMPOSE_VERSION=$(docker-compose --version | grep -oP '\d+\.\d+' | head -1)
  success "docker-compose v${COMPOSE_VERSION} found"
else
  error "docker compose not found. Install Docker Desktop or docker-compose v2."
fi

# Node.js
if ! command_exists node; then
  error "Node.js not found. Install Node.js 20+ from https://nodejs.org"
fi
NODE_VERSION=$(node --version | tr -d 'v')
NODE_MAJOR=$(echo "$NODE_VERSION" | cut -d. -f1)
if [[ "$NODE_MAJOR" -lt 20 ]]; then
  error "Node.js 20+ required. Found v${NODE_VERSION}. Update from https://nodejs.org"
fi
success "Node.js v${NODE_VERSION} found"

# pnpm
if ! command_exists pnpm; then
  warn "pnpm not found. Attempting auto-install..."
  npm install -g pnpm@latest >> "$LOG_FILE" 2>&1 || error "pnpm install failed. Run: npm install -g pnpm"
fi
PNPM_VERSION=$(pnpm --version)
success "pnpm v${PNPM_VERSION} found"

# git
if ! command_exists git; then
  error "git not found. Install from https://git-scm.com"
fi
success "git found"

# curl
if ! command_exists curl; then
  error "curl not found. Install curl for health checking."
fi
success "curl found"

# Disk space (20GB minimum)
AVAILABLE_DISK=$(df -BG . | awk 'NR==2 {print $4}' | tr -d 'G')
if [[ "${AVAILABLE_DISK:-0}" -lt 20 ]]; then
  warn "Low disk space: ${AVAILABLE_DISK}GB available. 20GB+ recommended."
else
  success "Disk space OK: ${AVAILABLE_DISK}GB available"
fi

# RAM (8GB minimum)
if command_exists free; then
  AVAILABLE_RAM_GB=$(free -g | awk 'NR==2 {print $2}')
  if [[ "${AVAILABLE_RAM_GB:-0}" -lt 8 ]]; then
    warn "Low RAM: ${AVAILABLE_RAM_GB}GB. 16GB recommended for full demo."
  else
    success "RAM OK: ${AVAILABLE_RAM_GB}GB available"
  fi
fi

success "All prerequisites satisfied"

# ─── STEP 2: REPOSITORY ──────────────────────────────────────────────────────
header "STEP 2: Repository"

if [[ "$RESET" == "true" ]] && [[ -d "$REPO_DIR" ]]; then
  log "Reset flag set — removing existing repo at ${REPO_DIR}..."
  rm -rf "$REPO_DIR"
fi

if [[ "$LOCAL_ONLY" == "true" ]]; then
  if [[ ! -d "$REPO_DIR" ]]; then
    error "--local specified but repo dir not found: ${REPO_DIR}"
  fi
  log "Using local repo at: ${REPO_DIR}"
  cd "$REPO_DIR"
  success "Local repo ready"
elif [[ -d "$REPO_DIR/.git" ]]; then
  log "Existing repo found at ${REPO_DIR}. Pulling latest..."
  cd "$REPO_DIR"
  git fetch origin >> "$LOG_FILE" 2>&1
  git pull origin main >> "$LOG_FILE" 2>&1 || warn "git pull failed — using local state"
  COMMIT=$(git rev-parse --short HEAD)
  success "Repo updated to commit ${COMMIT}"
else
  log "Cloning HeadyOS from ${REPO_URL}..."
  git clone "$REPO_URL" "$REPO_DIR" >> "$LOG_FILE" 2>&1 || \
    error "Clone failed. Check network access to ${REPO_URL} or use --local flag."
  cd "$REPO_DIR"
  COMMIT=$(git rev-parse --short HEAD)
  success "Cloned successfully (commit ${COMMIT})"
fi

# ─── STEP 3: ENVIRONMENT ─────────────────────────────────────────────────────
header "STEP 3: Environment Configuration"

if [[ ! -f ".env" ]]; then
  if [[ -f ".env.demo" ]]; then
    log "Copying .env.demo → .env"
    cp .env.demo .env
    success ".env created from .env.demo"
  elif [[ -f ".env.example" ]]; then
    log "Copying .env.example → .env"
    cp .env.example .env
    warn ".env created from .env.example — review API keys if needed"
  else
    warn ".env file not found and no template available. System may start with defaults."
  fi
else
  success ".env already exists — skipping"
fi

# Set demo port in .env if not default
if [[ "$ADMIN_PORT" != "3000" ]]; then
  log "Setting PORT=${ADMIN_PORT} in .env"
  if grep -q "^PORT=" .env; then
    sed -i "s/^PORT=.*/PORT=${ADMIN_PORT}/" .env
  else
    echo "PORT=${ADMIN_PORT}" >> .env
  fi
fi

# ─── STEP 4: DEPENDENCIES ────────────────────────────────────────────────────
header "STEP 4: Installing Dependencies"

log "Running pnpm install (this may take 2–5 minutes on first run)..."
pnpm install --frozen-lockfile >> "$LOG_FILE" 2>&1 || \
  pnpm install >> "$LOG_FILE" 2>&1 || \
  error "pnpm install failed. Check ${LOG_FILE} for details."
success "Dependencies installed"

# ─── STEP 5: BUILD ───────────────────────────────────────────────────────────
header "STEP 5: Building Services"

log "Building all 21 microservices (this may take 5–10 minutes on first run)..."

# Build TypeScript/Node services
if [[ -f "package.json" ]] && grep -q '"build"' package.json; then
  pnpm run build >> "$LOG_FILE" 2>&1 || \
    error "Build failed. Check ${LOG_FILE} for details."
  success "TypeScript compilation complete"
fi

# Build Docker images
log "Building Docker images..."
$COMPOSE_CMD -f "$COMPOSE_FILE" build --parallel >> "$LOG_FILE" 2>&1 || \
  error "Docker build failed. Check ${LOG_FILE} for details."
success "All Docker images built"

# ─── STEP 6: START SERVICES ──────────────────────────────────────────────────
header "STEP 6: Starting HeadyOS"

# Stop any existing instance
if $COMPOSE_CMD -f "$COMPOSE_FILE" ps --quiet 2>/dev/null | grep -q .; then
  log "Stopping existing HeadyOS instance..."
  $COMPOSE_CMD -f "$COMPOSE_FILE" down >> "$LOG_FILE" 2>&1
fi

log "Starting all 21 microservices..."
$COMPOSE_CMD -f "$COMPOSE_FILE" up -d >> "$LOG_FILE" 2>&1 || \
  error "docker-compose up failed. Check ${LOG_FILE} for details."
success "Docker containers started"

# ─── STEP 7: HEALTH CHECKS ───────────────────────────────────────────────────
header "STEP 7: Health Checks"

log "Waiting for HeadyOS to become healthy (max ${HEALTH_CHECK_RETRIES} checks × ${HEALTH_CHECK_INTERVAL}s)..."

HEALTHY=false
for i in $(seq 1 $HEALTH_CHECK_RETRIES); do
  HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" "$HEALTH_CHECK_URL" 2>/dev/null || echo "000")
  if [[ "$HTTP_CODE" == "200" ]]; then
    HEALTHY=true
    break
  fi
  printf "  Attempt %d/%d — status: %s\r" "$i" "$HEALTH_CHECK_RETRIES" "$HTTP_CODE"
  sleep $HEALTH_CHECK_INTERVAL
done

if [[ "$HEALTHY" != "true" ]]; then
  error "HeadyOS did not become healthy within $(( HEALTH_CHECK_RETRIES * HEALTH_CHECK_INTERVAL ))s. Check logs: $COMPOSE_CMD logs"
fi

echo "" # newline after progress
success "HeadyOS is healthy at ${HEALTH_CHECK_URL}"

# Check individual services if heady CLI available
if command_exists heady; then
  log "Running heady doctor..."
  heady doctor 2>&1 | tee -a "$LOG_FILE"
  success "heady doctor complete"
else
  warn "heady CLI not found in PATH — skipping doctor check. Add heady to PATH after install."
fi

# ─── STEP 8: STATUS SUMMARY ──────────────────────────────────────────────────
header "STEP 8: Deployment Complete"

CONTAINER_COUNT=$($COMPOSE_CMD -f "$COMPOSE_FILE" ps --quiet 2>/dev/null | wc -l | tr -d ' ')
ADMIN_URL="http://localhost:${ADMIN_PORT}"
API_URL="http://localhost:${ADMIN_PORT}/api"
HEALTH_URL="http://localhost:${ADMIN_PORT}/health"

echo -e "
${GREEN}${BOLD}  ✓ HeadyOS is running!${NC}

  ${BOLD}System Summary:${NC}
  ┌─────────────────────────────────────────────────────┐
  │  Containers:    ${CONTAINER_COUNT} running                             │
  │  Admin Portal:  ${ADMIN_URL}                   │
  │  API Base URL:  ${API_URL}               │
  │  Health Check:  ${HEALTH_URL}            │
  │  Log File:      ${LOG_FILE}  │
  └─────────────────────────────────────────────────────┘

  ${BOLD}Quick Commands:${NC}
  heady doctor          — Full system health check
  heady status          — Service status overview
  heady logs --follow   — Live log stream
  $COMPOSE_CMD down     — Stop all services

  ${BOLD}Demo Sequence:${NC}
  1. Open admin portal → verify all 21 services green
  2. Run: heady doctor
  3. Run: heady status
  4. Submit multi-agent task via admin or CLI
  5. Navigate to headyme.com, headysystems.com, headyai.com
  6. Close with: '51 patents. 5,381 files. Raising \$1.5M-\$3M.'
" | tee -a "$LOG_FILE"

if [[ "$OPEN_BROWSER" == "true" ]]; then
  log "Opening admin portal in browser..."
  sleep 2
  open_browser "$ADMIN_URL"
  success "Browser opened to ${ADMIN_URL}"
fi

echo -e "${CYAN}${BOLD}  HeadySystems Inc. | eric@headyconnection.org | headyme.com${NC}\n"
