# Heady Max Rebuild

This package rebuilds Heady as a clean monorepo that uses the public HeadyMe repository ecosystem as foundation material, especially the large pre-production monorepo at [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642), the documentation hub at [heady-docs](https://github.com/HeadyMe/heady-docs), and the projected product repos such as [headyme-core](https://github.com/HeadyMe/headyme-core) and [headysystems-core](https://github.com/HeadyMe/headysystems-core).

## Intent

The rebuild consolidates the strongest public patterns visible in the HeadyMe ecosystem into one operational structure:
- a gateway and control-plane layer inspired by `heady-manager.js`, `hc-full-pipeline.js`, and the public service map in [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642)
- a memory and orchestration layer aligned with the public vector-memory, Buddy, HeadyBees, resilience, and pipeline modules in [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642)
- a documentation and projection workflow aligned with the single-source-of-truth pattern documented in [heady-docs](https://github.com/HeadyMe/heady-docs)
- product-facing projections aligned with the projected service repos listed under the HeadyMe organization at [GitHub](https://github.com/HeadyMe)

## Monorepo Layout

```text
apps/
  gateway/        Unified API and control-plane entrypoint
  web/            Public Heady experience
  admin/          System dashboard and operator console
services/
  conductor/      Task routing and orchestration
  memory/         Context, vector-memory placeholder, persistence
  buddy/          Companion runtime facade
  mcp/            MCP-compatible transport facade
  worker/         Background queue and execution worker
packages/
  core/           Shared config, logging, HTTP helpers
  contracts/      Shared manifests and runtime contracts
  sdk/            Internal client helpers
configs/          Domain, system, projection, and geometry manifests
infra/            Docker, Cloud Run, Cloudflare, Terraform, CI
scripts/          Bootstrap, foundation import, validation, rebuild helpers
foundations/      Public-repo inventory and role mapping
```

## Quick Start

```bash
pnpm install
pnpm run validate
pnpm run dev
```

## Rebuild Sequence

1. Review `foundations/repo-role-map.md` to understand how each public HeadyMe repo contributes to the rebuild.
2. Run `pnpm run foundations:sync` to refresh the public foundation clones from the GitHub inventory saved in `foundations/repo-inventory.json`.
3. Edit `configs/system.json`, `configs/domains.json`, and `configs/projection-manifest.json` for your live environment.
4. Start the local stack with `pnpm run dev` or `docker compose up --build`.
5. Move each placeholder service toward production by replacing the local adapters with your live cloud, vector, model, and auth providers.

## What Is Included

This zip contains a clean rebuild structure, shared contracts, service skeletons, deployment scaffolding, docs with source URLs, and automation scripts. It does not blindly mirror the entire raw public monorepo; instead it reorganizes the strongest observable Heady foundations into a cleaner operating shape based on the public architecture, docs, and projected repos at [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642), [heady-docs](https://github.com/HeadyMe/heady-docs), [headyme-core](https://github.com/HeadyMe/headyme-core), and [headysystems-core](https://github.com/HeadyMe/headysystems-core).
