# Public Foundation Map

This rebuild uses the public HeadyMe repositories as architectural evidence, not as a raw dump.

## Core Monorepo

- [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642) is the main foundation because its public README exposes the Heady manager, HCFullPipeline, Buddy core, vector memory, HeadyBees, resilience stack, lifecycle modules, health routes, and CI posture.
- The same repo also exposes the public file patterns behind orchestration, services, routes, projections, infra, configs, extensions, and documentation, making it the strongest single source for a consolidated rebuild.

## Documentation System

- [heady-docs](https://github.com/HeadyMe/heady-docs) establishes a single-source-of-truth documentation hub with source packs, strategic docs, site assets, and patent indexing.
- This rebuild mirrors that pattern in `docs/` and `foundations/` so the codebase and the knowledge layer stay aligned.

## Projected Product Repos

- [headyme-core](https://github.com/HeadyMe/headyme-core) shows the projected personal-cloud surface for headyme.com.
- [headysystems-core](https://github.com/HeadyMe/headysystems-core) shows the projected infrastructure surface for headysystems.com.
- [headybuddy-core](https://github.com/HeadyMe/headybuddy-core), [headymcp-core](https://github.com/HeadyMe/headymcp-core), [headyapi-core](https://github.com/HeadyMe/headyapi-core), [headyconnection-core](https://github.com/HeadyMe/headyconnection-core), [headyio-core](https://github.com/HeadyMe/headyio-core), and [headybot-core](https://github.com/HeadyMe/headybot-core) reinforce the projection model where product surfaces are emitted from a deeper system core.

## Rebuild Decision

The package therefore treats Heady as one latent monorepo with projection targets rather than a collection of disconnected standalone sites. That choice follows the public repo patterns visible in [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642), [heady-docs](https://github.com/HeadyMe/heady-docs), and the projected product repos listed above.
