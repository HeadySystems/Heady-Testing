const http = require('http');
const { env, json, text, readJson, log } = require('@heady/core');
const { serviceManifest } = require('@heady/contracts');

const port = Number(env('HEADY_GATEWAY_PORT', 4000));
const server = http.createServer((req, res) => {
  const system = readJson('configs/system.json');
  const domains = readJson('configs/domains.json');
  const geometry = readJson('configs/sacred-geometry.json');

  if (req.url === '/health') {
    return json(res, 200, { ok: true, service: 'gateway', port });
  }
  if (req.url === '/api/manifest') {
    return json(res, 200, { system, domains, geometry, services: serviceManifest });
  }
  if (req.url === '/api/status') {
    return json(res, 200, {
      ok: true,
      systemName: system.systemName,
      mode: system.mode,
      services: serviceManifest.map(item => ({ ...item, url: `http://localhost:${process.env[item.portEnv] || item.defaultPort}` }))
    });
  }
  return text(res, 404, 'Not found');
});

server.listen(port, () => log('gateway', 'gateway online', { port }));
