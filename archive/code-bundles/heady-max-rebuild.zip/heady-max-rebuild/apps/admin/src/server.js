const http = require('http');
        const { env, html, json, readJson, log } = require('@heady/core');

        const port = Number(env('HEADY_ADMIN_PORT', 4020));
        const server = http.createServer((req, res) => {
          const geometry = readJson('configs/sacred-geometry.json');
          if (req.url === '/health') return json(res, 200, { ok: true, service: 'admin', port });
          if (req.url === '/') {
            const rows = geometry.nodes.map(node => `<tr><td>${node.name}</td><td>${node.role}</td><td>[${node.position.join(', ')}]</td></tr>`).join('');
            return html(res, 200, `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Heady Admin</title>
  <style>
    body {{ font-family: Inter, Arial, sans-serif; background:#0a0f19; color:#f4f7ff; margin:0; padding:40px; }}
    table {{ width:100%; border-collapse:collapse; margin-top:24px; }}
    td, th {{ border-bottom:1px solid #24324a; padding:12px; text-align:left; }}
  </style>
</head>
<body>
  <h1>Heady Admin</h1>
  <p>Current sacred-geometry topology for the rebuild package.</p>
  <table>
    <thead><tr><th>Node</th><th>Role</th><th>Position</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
</body>
</html>`);
          }
          return html(res, 404, '<h1>Not found</h1>');
        });

        server.listen(port, () => log('admin', 'admin online', { port }));
