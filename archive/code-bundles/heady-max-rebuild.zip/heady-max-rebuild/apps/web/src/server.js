const http = require('http');
        const { env, html, json, log } = require('@heady/core');

        const port = Number(env('HEADY_WEB_PORT', 4010));
        const server = http.createServer((req, res) => {
          if (req.url === '/health') return json(res, 200, { ok: true, service: 'web', port });
          if (req.url === '/') {
            return html(res, 200, `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>Heady Web</title>
  <style>
    body {{ font-family: Inter, Arial, sans-serif; background:#09111f; color:#ecf2ff; margin:0; padding:48px; }}
    .card {{ max-width:920px; margin:0 auto; background:#101b31; border:1px solid #203150; border-radius:20px; padding:32px; }}
    code {{ color:#89d5ff; }}
    a {{ color:#89d5ff; }}
  </style>
</head>
<body>
  <div class="card">
    <h1>Heady Web</h1>
    <p>This rebuild package treats the public site as a projection of the shared control plane and contracts.</p>
    <p>Check the gateway manifest at <a href="http://localhost:${process.env.HEADY_GATEWAY_PORT || 4000}/api/manifest">/api/manifest</a>.</p>
  </div>
</body>
</html>`);
          }
          return html(res, 404, '<h1>Not found</h1>');
        });

        server.listen(port, () => log('web', 'web online', { port }));
