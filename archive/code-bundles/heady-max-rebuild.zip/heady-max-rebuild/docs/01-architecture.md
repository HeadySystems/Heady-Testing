# Heady Architecture

## Objective

Rebuild Heady as a single operating repo with clear boundaries between control plane, orchestration, memory, companion runtime, tool transport, execution workers, and projected product surfaces. This direction is grounded in the public Heady manager, pipeline, Buddy, vector-memory, resilience, and projection patterns visible in [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642).

## Recommended Stack

- `apps/gateway` is the external control plane and public API edge.
- `services/conductor` owns task planning, routing, and execution intent.
- `services/memory` owns context persistence, vector-memory adapters, and state snapshots.
- `services/buddy` owns the user-facing companion runtime.
- `services/mcp` owns JSON-RPC style tool transport and registry.
- `services/worker` owns background execution and queue-safe jobs.
- `apps/web` and `apps/admin` are projections of shared contracts, configs, and system state.

## Why This Shape

The public Heady pre-production repo shows a very broad set of capabilities spread across orchestration, routes, services, bees, projections, and configs, while the projected repos show that product surfaces can remain thin when emitted from a shared core. This rebuild keeps the core centralized and projections thin because that is the cleanest way to preserve the latent-OS pattern visible in [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642), [headyme-core](https://github.com/HeadyMe/headyme-core), and [headysystems-core](https://github.com/HeadyMe/headysystems-core).

## Upgrade Path

1. Replace local JSON persistence with pgvector plus an operational relational store.
2. Replace local task routing with a durable queue and event bus.
3. Replace placeholder MCP registry with live tool registration and policy enforcement.
4. Replace local dashboards with live observability and release gates.
