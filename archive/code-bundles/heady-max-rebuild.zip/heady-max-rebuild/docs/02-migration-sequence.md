# Migration Sequence

## Phase 1

Use this package as the clean destination repo and map legacy capabilities into six runtime domains: gateway, conductor, memory, buddy, mcp, and worker. This is a direct simplification of the much broader public surface area visible in [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642).

## Phase 2

Port the best public patterns into shared packages first, especially health checks, registry contracts, orchestration manifests, and projection rules that are publicly evidenced in [Heady-pre-production-9f2f0642](https://github.com/HeadyMe/Heady-pre-production-9f2f0642) and the documentation structure in [heady-docs](https://github.com/HeadyMe/heady-docs).

## Phase 3

Re-project brand surfaces for headyme.com, headysystems.com, headybuddy.org, headymcp.com, and headyconnection.org from the new shared contracts rather than maintaining them as manually divergent sites. That projection model is reinforced by the public projected repos such as [headyme-core](https://github.com/HeadyMe/headyme-core), [headysystems-core](https://github.com/HeadyMe/headysystems-core), and [headyconnection-core](https://github.com/HeadyMe/headyconnection-core).

## Phase 4

Attach production infra, vector stores, auth, model routing, and cloud deployment only after the monorepo boundaries are clean. The public pre-production repo shows many infrastructure directions at once, so this rebuild intentionally narrows the execution path before scaling it.
