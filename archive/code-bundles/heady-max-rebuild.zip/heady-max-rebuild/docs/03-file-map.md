# File Map

- `apps/gateway` exposes the manifest, topology, status, and public system API.
- `apps/web` is the public-facing product shell.
- `apps/admin` is the operator dashboard.
- `services/conductor` provides route planning and task dispatch.
- `services/memory` provides context persistence and search placeholders.
- `services/buddy` provides a minimal companion facade.
- `services/mcp` provides a minimal JSON-RPC style MCP facade.
- `services/worker` provides queue and execution placeholders.
- `packages/core` centralizes logging, config access, and HTTP utilities.
- `packages/contracts` centralizes service and manifest contracts.
- `packages/sdk` centralizes internal fetch clients.
- `foundations/` keeps the public-traceability layer aligned with the GitHub inventory from [HeadyMe](https://github.com/HeadyMe).
