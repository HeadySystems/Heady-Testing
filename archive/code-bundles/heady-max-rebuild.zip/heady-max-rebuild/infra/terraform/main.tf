terraform {
  required_version = ">= 1.6.0"
}

variable "project_id" {
  type = string
}

output "heady_rebuild" {
  value = {
    project_id = var.project_id
    stack = "gateway + projections + services"
  }
}
