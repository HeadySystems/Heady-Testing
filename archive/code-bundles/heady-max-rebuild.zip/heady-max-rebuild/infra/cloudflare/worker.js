export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const upstream = env.HEADY_GATEWAY_ORIGIN || 'http://gateway:4000';
    const target = new URL(url.pathname + url.search, upstream);
    return fetch(target.toString(), request);
  }
};
