import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const root = path.resolve(process.cwd());
const inventory = JSON.parse(fs.readFileSync(path.join(root, 'foundations', 'repo-inventory.json'), 'utf8'));
const cloneRoot = path.join(root, 'foundations', 'clones');
fs.mkdirSync(cloneRoot, { recursive: true });

for (const repo of inventory) {
  if (!repo.url || !repo.name) continue;
  const destination = path.join(cloneRoot, repo.name);
  if (fs.existsSync(destination)) continue;
  execSync(`git clone --depth 1 ${repo.url} ${destination}`, { stdio: 'inherit' });
}

console.log(`Foundation sync complete: ${inventory.length} repositories listed.`);
