import fs from 'fs';
import path from 'path';
const root = path.resolve(process.cwd());
const domains = JSON.parse(fs.readFileSync(path.join(root, 'configs', 'domains.json'), 'utf8'));
console.log(JSON.stringify({ ok: true, domains, timestamp: new Date().toISOString() }, null, 2));
