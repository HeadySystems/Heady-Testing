import fs from 'fs';
import path from 'path';

const root = path.resolve(process.cwd());
const required = [
  'README.md',
  'configs/system.json',
  'configs/domains.json',
  'configs/sacred-geometry.json',
  'configs/projection-manifest.json',
  'foundations/repo-inventory.json',
  'foundations/repo-role-map.md',
  'docs/01-architecture.md',
  'apps/gateway/src/server.js',
  'services/conductor/src/server.js',
  'services/memory/src/server.js',
  'services/buddy/src/server.js',
  'services/mcp/src/server.js',
  'services/worker/src/server.js'
];

const missing = required.filter(item => !fs.existsSync(path.join(root, item)));
if (missing.length) {
  console.error(JSON.stringify({ ok: false, missing }, null, 2));
  process.exit(1);
}
console.log(JSON.stringify({ ok: true, checked: required.length }, null, 2));
