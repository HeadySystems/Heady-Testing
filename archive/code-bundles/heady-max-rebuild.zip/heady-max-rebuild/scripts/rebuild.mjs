import fs from 'fs';
import path from 'path';

const root = path.resolve(process.cwd());
const system = JSON.parse(fs.readFileSync(path.join(root, 'configs', 'system.json'), 'utf8'));
const projections = JSON.parse(fs.readFileSync(path.join(root, 'configs', 'projection-manifest.json'), 'utf8'));

console.log(JSON.stringify({
  ok: true,
  system,
  projections,
  next: [
    'Refresh foundations',
    'Port runtime adapters',
    'Attach vector and auth backends',
    'Deploy projections'
  ]
}, null, 2));
