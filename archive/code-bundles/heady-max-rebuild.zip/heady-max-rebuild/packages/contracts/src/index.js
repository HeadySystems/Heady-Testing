const serviceManifest = [
  { key: 'gateway', portEnv: 'HEADY_GATEWAY_PORT', defaultPort: 4000, type: 'app' },
  { key: 'web', portEnv: 'HEADY_WEB_PORT', defaultPort: 4010, type: 'app' },
  { key: 'admin', portEnv: 'HEADY_ADMIN_PORT', defaultPort: 4020, type: 'app' },
  { key: 'conductor', portEnv: 'HEADY_CONDUCTOR_PORT', defaultPort: 4100, type: 'service' },
  { key: 'memory', portEnv: 'HEADY_MEMORY_PORT', defaultPort: 4110, type: 'service' },
  { key: 'buddy', portEnv: 'HEADY_BUDDY_PORT', defaultPort: 4120, type: 'service' },
  { key: 'mcp', portEnv: 'HEADY_MCP_PORT', defaultPort: 4130, type: 'service' },
  { key: 'worker', portEnv: 'HEADY_WORKER_PORT', defaultPort: 4140, type: 'service' }
];

const taskContract = {
  fields: ['id', 'intent', 'priority', 'target', 'status', 'createdAt']
};

module.exports = { serviceManifest, taskContract };
