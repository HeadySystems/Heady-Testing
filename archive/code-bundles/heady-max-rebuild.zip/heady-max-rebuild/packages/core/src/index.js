const fs = require('fs');
const path = require('path');

function projectRoot() {
  return path.resolve(__dirname, '..', '..', '..');
}

function readJson(relativePath) {
  const filePath = path.join(projectRoot(), relativePath);
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function env(name, fallback = undefined) {
  return Object.prototype.hasOwnProperty.call(process.env, name) ? process.env[name] : fallback;
}

function log(scope, message, data = undefined) {
  const line = {
    ts: new Date().toISOString(),
    scope,
    message,
    data: data ?? null
  };
  console.log(JSON.stringify(line));
}

function json(res, statusCode, body) {
  const payload = JSON.stringify(body, null, 2);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload)
  });
  res.end(payload);
}

function text(res, statusCode, body) {
  res.writeHead(statusCode, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function html(res, statusCode, body) {
  res.writeHead(statusCode, {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Length': Buffer.byteLength(body)
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 1_000_000) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!raw) return resolve(null);
      try {
        resolve(JSON.parse(raw));
      } catch (error) {
        reject(error);
      }
    });
    req.on('error', reject);
  });
}

module.exports = { projectRoot, readJson, env, log, json, text, html, readBody };
