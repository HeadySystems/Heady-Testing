const http = require('http');
const { env, json, readBody, log } = require('@heady/core');
const port = Number(env('HEADY_MCP_PORT', 4130));
const tools = [
  { name: 'health.status', description: 'Return system health summary' },
  { name: 'memory.search', description: 'Search local memory placeholder' },
  { name: 'conductor.dispatch', description: 'Create a routed task placeholder' }
];
const server = http.createServer(async (req, res) => {
  if (req.url === '/health') return json(res, 200, { ok: true, service: 'mcp', port, tools: tools.length });
  if (req.url === '/mcp' && req.method === 'POST') {
    const body = await readBody(req).catch(() => null);
    if (body?.method === 'tools/list') return json(res, 200, { jsonrpc: '2.0', id: body.id ?? null, result: { tools } });
    return json(res, 200, { jsonrpc: '2.0', id: body?.id ?? null, result: { ok: true, note: 'MCP placeholder online' } });
  }
  return json(res, 404, { ok: false, error: 'Not found' });
});
server.listen(port, () => log('mcp', 'mcp online', { port }));
