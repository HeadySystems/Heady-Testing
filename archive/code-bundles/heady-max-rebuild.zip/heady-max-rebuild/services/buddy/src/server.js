const http = require('http');
const { env, json, readBody, log } = require('@heady/core');
const port = Number(env('HEADY_BUDDY_PORT', 4120));
const server = http.createServer(async (req, res) => {
  if (req.url === '/health') return json(res, 200, { ok: true, service: 'buddy', port });
  if (req.url === '/api/chat' && req.method === 'POST') {
    const body = await readBody(req).catch(() => null);
    const prompt = body?.message || 'Hello';
    return json(res, 200, {
      ok: true,
      response: `Buddy placeholder received: ${prompt}. Replace this adapter with your live multi-model and memory runtime.`
    });
  }
  return json(res, 404, { ok: false, error: 'Not found' });
});
server.listen(port, () => log('buddy', 'buddy online', { port }));
