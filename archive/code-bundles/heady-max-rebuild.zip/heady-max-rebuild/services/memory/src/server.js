const http = require('http');
const fs = require('fs');
const path = require('path');
const { env, json, readBody, log, projectRoot } = require('@heady/core');
const port = Number(env('HEADY_MEMORY_PORT', 4110));
const dataFile = path.join(projectRoot(), '.data', 'memory.json');
fs.mkdirSync(path.dirname(dataFile), { recursive: true });
if (!fs.existsSync(dataFile)) fs.writeFileSync(dataFile, JSON.stringify({ entries: [] }, null, 2));
function load() { return JSON.parse(fs.readFileSync(dataFile, 'utf8')); }
function save(data) { fs.writeFileSync(dataFile, JSON.stringify(data, null, 2)); }
const server = http.createServer(async (req, res) => {
  if (req.url === '/health') return json(res, 200, { ok: true, service: 'memory', port });
  if (req.url === '/api/memory/search' && req.method === 'POST') {
    const body = await readBody(req).catch(() => null);
    const q = String(body?.query || '').toLowerCase();
    const data = load();
    const results = data.entries.filter(entry => JSON.stringify(entry).toLowerCase().includes(q));
    return json(res, 200, { ok: true, count: results.length, results });
  }
  if (req.url === '/api/memory/store' && req.method === 'POST') {
    const body = await readBody(req).catch(() => null);
    const data = load();
    const entry = { id: `mem_${Date.now()}`, ...body, createdAt: new Date().toISOString() };
    data.entries.unshift(entry);
    save(data);
    return json(res, 200, { ok: true, entry });
  }
  return json(res, 404, { ok: false, error: 'Not found' });
});
server.listen(port, () => log('memory', 'memory online', { port, dataFile }));
