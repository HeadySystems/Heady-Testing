const http = require('http');
const { env, json, readBody, log } = require('@heady/core');
const { taskContract } = require('@heady/contracts');
const port = Number(env('HEADY_CONDUCTOR_PORT', 4100));
let tasks = [];
const server = http.createServer(async (req, res) => {
  if (req.url === '/health') return json(res, 200, { ok: true, service: 'conductor', port, tasks: tasks.length });
  if (req.url === '/api/tasks' && req.method === 'GET') return json(res, 200, { taskContract, tasks });
  if (req.url === '/api/dispatch' && req.method === 'POST') {
    const body = await readBody(req).catch(() => null);
    const task = {
      id: `task_${Date.now()}`,
      intent: body?.intent || 'unspecified',
      priority: body?.priority || 'high',
      target: body?.target || 'gateway',
      status: 'planned',
      createdAt: new Date().toISOString()
    };
    tasks.unshift(task);
    return json(res, 200, { ok: true, task });
  }
  return json(res, 404, { ok: false, error: 'Not found' });
});
server.listen(port, () => log('conductor', 'conductor online', { port }));
