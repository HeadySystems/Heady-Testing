const http = require('http');
const { env, json, log } = require('@heady/core');
const port = Number(env('HEADY_WORKER_PORT', 4140));
let lastTick = new Date().toISOString();
setInterval(() => { lastTick = new Date().toISOString(); }, 5000);
const server = http.createServer((req, res) => {
  if (req.url === '/health') return json(res, 200, { ok: true, service: 'worker', port, lastTick });
  if (req.url === '/api/queue') return json(res, 200, { ok: true, note: 'Replace with durable queue implementation', lastTick });
  return json(res, 404, { ok: false, error: 'Not found' });
});
server.listen(port, () => log('worker', 'worker online', { port }));
