# Model Context Protocol (MCP)

## Transport

Heady MCP supports:
- **Streamable HTTP**: Single endpoint, bidirectional
- **SSE fallback**: Long-lived streaming for older clients

## Tools

- `memory.store`: Store 3D vector memory
- `memory.query`: Semantic search
- `memory.stats`: User memory statistics
- `server.health`: Server status

## Authentication

All MCP requests require Bearer token in `Authorization` header.
