# Heady System Architecture

## Overview

Heady is a liquid, self-orchestrating AI platform spanning 20+ specialized agents.

## Core Components

1. **Vector Memory**: 3D spatial indexing with octree structure
2. **MCP Server**: JSON-RPC 2.0 over HTTP + SSE
3. **Gateway**: Auth + rate limiting at the edge
4. **Orchestrator**: Dynamic service allocation

## Deployment

- Apps: Vercel / Cloudflare Pages
- Workers: Cloudflare Workers (edge compute)
- Storage: R2 (vector data), D1 (metadata), KV (sessions)
