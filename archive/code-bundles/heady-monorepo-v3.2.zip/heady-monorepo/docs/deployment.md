# Deployment Guide

## Prerequisites

- Node.js 20+
- pnpm 9+
- Cloudflare account (for Workers)

## Steps

1. Install dependencies: `pnpm install`
2. Build packages: `pnpm build`
3. Deploy workers: `cd workers/mcp-transport && pnpm deploy`
4. Deploy apps: `vercel --prod` (or use Cloudflare Pages)

## Environment Variables

- `HEADY_API_KEY`: API gateway auth key
- `DATABASE_URL`: D1 database connection string
- `R2_BUCKET`: Vector storage bucket name
