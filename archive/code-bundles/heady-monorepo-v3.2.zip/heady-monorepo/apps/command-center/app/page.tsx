export default function HomePage() {
  return (
    <div style={{ fontFamily: 'system-ui', padding: '2rem' }}>
      <h1>Heady Command Center</h1>
      <p>Welcome to the Heady intelligence platform.</p>
      <ul>
        <li><strong>Dashboard</strong>: System overview</li>
        <li><strong>Services</strong>: AI agents and workers</li>
        <li><strong>Memory</strong>: 3D vector persistence</li>
        <li><strong>Gateway</strong>: API routing</li>
      </ul>
    </div>
  );
}
