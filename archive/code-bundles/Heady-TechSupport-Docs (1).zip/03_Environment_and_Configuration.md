# Environment and Configuration Guide

**Last updated:** 2026-02-23

This guide explains:
- how environments are structured (dev/staging/prod/hybrid),
- which configuration files matter,
- which environment variables are required,
- how secrets are handled safely, and
- common configuration failures that look like “code bugs.”

---

## 1) Environments

### 1.1 Local development
Goal: run services on a developer laptop with minimal external dependencies.

Common characteristics:
- `NODE_ENV=development`
- local ports bound on localhost
- optional local DB/Redis (Docker recommended)
- Cloudflare is **not** in the loop (unless explicitly testing).

### 1.2 Hybrid mode (local containers + cloud endpoints)
Hybrid mode is used when:
- you want local container services (DB/Redis/MCP) but still point to cloud endpoints for certain capabilities.

Hybrid characteristics:
- `HYBRID_MODE=true`
- local DB/Redis in Docker, cloud endpoints configured
- increased risk of “environment confusion” (wrong URLs, wrong auth, mixed origins)

### 1.3 Staging
Goal: production-like environment for validation before prod.

Best practice:
- Staging uses the same Cloudflare/WAF policies as prod (or an intentionally looser subset).
- Staging uses separate keys and separate database.

### 1.4 Production
Goal: stable environment with strong security controls and monitoring.

Best practice:
- No localhost defaults.
- No unowned domains.
- Strict secrets management.
- “Break glass” procedures for emergencies.

---

## 2) Configuration files (what to look for first)

### 2.1 `.env`
Local developer environment file. Never commit this.

### 2.2 `.env.example`
Template for environment variables, including:
- email notification settings
- API keys and tokens placeholders
- canonical branded domains (endpoints, docs, status)

### 2.3 `.env.hybrid`
Hybrid mode configuration (local containers + cloud endpoints).

### 2.4 `render.yaml`
Infrastructure blueprint for Render-based deployment.

### 2.5 `docker-compose.mcp.yml`
Compose file defining MCP servers plus Postgres/Redis for local/container operations.

---

## 3) Required environment variables (core)

These variables are foundational for support because misconfiguration causes the “system seems dead” symptoms.

### 3.1 `HEADY_API_KEY` (required for admin + protected endpoints)
- Required to access admin endpoints and many tool endpoints.
- Usually sent as an HTTP header (`x-heady-api-key` in some tooling).

**Support symptom patterns**
- Admin UI loads, but data tabs fail with 401/403.
- CLI calls that previously worked now fail.

**Support checklist**
- Validate the key exists in environment
- Validate the key is included in requests
- Rotate and re-deploy if compromise suspected

### 3.2 `NODE_ENV`
Common values:
- `development`
- `staging`
- `production`

**Support note:** logic may switch URLs based on environment. Mis-setting `NODE_ENV` can route to the wrong domain.

### 3.3 `PORT`
- Default is frequently 3300 for the manager/orchestrator.
- Confirm actual binding in service config or container config.

---

## 4) Optional but common environment variables

### 4.1 Hugging Face / inference
- `HF_TOKEN`: token for Hugging Face integration.

Symptoms:
- inference endpoints fail
- embeddings/generation endpoints return auth errors

### 4.2 Postgres / database connectivity
- `DATABASE_URL`: Postgres connection string.
- In Docker MCP stack, a typical pattern is:
  - `postgresql://postgres:<password>@<container>:5432/heady`

Symptoms:
- 500 errors on DB-backed endpoints
- “ECONNREFUSED” / timeouts / migration failures

### 4.3 CORS and trusted origins
- `HEADY_CORS_ORIGINS` or `ALLOWED_ORIGINS` (varies by service)
- Should list approved origins such as headysystems.com, headycloud.com, etc.

Symptoms:
- admin UI or IDE cannot call APIs due to browser CORS failures

Support:
- Inspect browser console for CORS errors
- Confirm list includes correct domains for the environment

---

## 5) Admin IDE configuration (filesystem safety)

The Admin IDE supports file operations and must be locked down.

Common controls:
- `HEADY_ADMIN_ROOT`: repository root for file access
- `HEADY_ADMIN_ALLOWED_PATHS`: allowlist for additional roots
- `HEADY_ADMIN_MAX_BYTES`: maximum file size that can be edited
- `HEADY_ADMIN_BUILD_SCRIPT`: path to build script (default often Python builder)
- `HEADY_ADMIN_AUDIT_SCRIPT`: path to audit script (default often admin_console.py)

Support symptoms:
- “File not found” in UI even when the file exists
- “Access denied” when browsing or editing
- Save conflicts (hash mismatch) if another operator edited concurrently

Support checklist:
- Confirm allowlisted roots include the file’s path
- Confirm server process has filesystem permissions
- If hash conflict occurs: refresh file, re-apply changes, save again

---

## 6) Remote GPU (optional)

Some environments support remote GPU configuration via env vars such as:
- `HEADY_ADMIN_ENABLE_GPU`
- `REMOTE_GPU_HOST`
- `REMOTE_GPU_PORT`
- `GPU_MEMORY_LIMIT`
- `ENABLE_GPUDIRECT`

Support tip:
- Treat GPU features as a separate “optional dependency.”
- If GPU is down, degrade gracefully to CPU inference or disable GPU features.

---

## 7) Cloud-first and “no localhost defaults”

Two sources of failure are explicitly called out in the repos:
- “environment confusion” (system defaulting to wrong mode)
- use of disallowed/incorrect domains or IPs

### 7.1 What to avoid
- localhost defaults in production
- `cloud.headysystems.com` references in production
- `.onrender.com` domains in production
- placeholder IPs like 127.0.0.1, 0.0.0.0

### 7.2 Support tactic
When you see unexpected routing behavior:
1. Print the runtime environment (`NODE_ENV`, URL env vars).
2. Confirm the domain inventory (what is actually owned/allowed).
3. Search config for disallowed hostnames and remove them.

---

## 8) Secrets management

### 8.1 Where secrets should live
- environment variables in the hosting platform (Render env groups, etc.)
- a secrets manager (preferred)
- encrypted vaults (for local development only)

### 8.2 Where secrets must not live
- committed docs
- committed `.env` files
- tickets or chat transcripts without redaction

### 8.3 If a secret appears in a repo (response plan)
1. Treat as compromised.
2. Rotate immediately.
3. Purge from history if possible.
4. Audit for misuse (Cloudflare logs, API logs, etc.).
5. Update this documentation to reinforce the rule.

---

## 9) Configuration troubleshooting quick checklist

When “everything seems broken,” do these in order:

1. **Check DNS/Cloudflare**: does the domain resolve and return a real origin response?
2. **Check `/api/health`**: does the manager return 200?
3. **Check authentication**: is `HEADY_API_KEY` present and used?
4. **Check CORS**: does the browser show CORS blocks?
5. **Check DB connectivity**: can the service reach Postgres/Redis?
6. **Check environment routing**: wrong `NODE_ENV` causing wrong URLs?

