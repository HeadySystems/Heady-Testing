# Troubleshooting Knowledge Base (Heady)

**Last updated:** 2026-02-23

This is a task-oriented KB: find the symptom that matches and follow the checklist.

---

## KB-000: “Start here” - fastest universal triage

1. **Is it DNS/CDN?**
   - `dig <domain> A`
   - `curl -I https://<domain>`
   - If you see 403 challenge pages, it is Cloudflare/WAF, not the origin.

2. **Is the API gateway up?**
   - `curl -sf https://api.headysystems.com/api/health`

3. **Is auth missing?**
   - Re-run your request with the API key header.

4. **Are dependencies up?**
   - Postgres: `pg_isready`
   - Redis: `redis-cli ping`

5. **What changed last?**
   - last deployment
   - DNS record change
   - WAF change
   - secret rotation

---

## KB-101: Cloudflare returns HTTP 403 challenge page (origin seems healthy)

### Symptoms
- `curl -I https://app.headysystems.com` returns 403
- Browser shows “challenge” page
- Internal logs show origin service is healthy

### Likely causes
- Cloudflare WAF rules are blocking
- Bot protection is triggered
- Rate limiting
- DNS points to the wrong IP (common: points to a Cloudflare proxy IP, causing “prohibited IP” errors)

### Diagnostics
1. Confirm origin health by bypassing Cloudflare:
   - Curl the origin IP directly (if accessible) or test from inside the server.
2. Check response headers:
   - Cloudflare responses often include `server: cloudflare` and challenge-related headers.
3. Confirm DNS record values:
   - The DNS record should point to the real origin IP (or a proper load balancer), not a Cloudflare proxy IP.

### Fix (safe sequence)
1. **Temporarily switch proxy mode to DNS-only** for the failing subdomain to validate the origin.
2. Update DNS to point to the actual origin server IP.
3. Adjust Cloudflare security settings:
   - disable/relax bot fight mode or WAF rules for the specific subdomain
   - add exceptions for health endpoints (`/api/health`, `/health`, etc.)
4. Re-enable proxy mode after verifying stable behavior.

### Prevent
- Add a “DNS must point to origin” check in deployment pipeline.
- Maintain an allowlisted domain inventory (do not route to unowned domains).

---

## KB-102: Domain does not resolve (NXDOMAIN / “Could not resolve host”)

### Symptoms
- `nslookup headyme.com` fails
- Browser cannot load site at all
- Deployments look fine but the domain is unreachable

### Likely causes
- Missing DNS records (A/AAAA/CNAME)
- Nameservers not set to Cloudflare (if Cloudflare intended)
- Registrar DNS misconfiguration

### Diagnostics
1. `dig headyme.com A`
2. confirm nameservers at registrar match Cloudflare (if using Cloudflare)
3. verify records exist for:
   - root (`@`)
   - `www`
   - subdomains used by apps (admin/api/buddy/app/mobile etc.)

### Fix
- Create/update A records to point to the origin server IP or load balancer.
- Wait for propagation (usually minutes, sometimes longer).
- Validate with `dig` and `curl -I`.

### Prevent
- Keep a canonical DNS record list and a change log.
- Automate DNS checks in CI (simple resolve + HTTP status checks).

---

## KB-103: “DNS points to prohibited IP” / wrong IP in Cloudflare

### Symptoms
- Cloudflare errors mention prohibited IP
- DNS records show an IP that is not your origin
- Origin is healthy when accessed locally, but not through public domain

### Likely causes
- DNS record content set to a Cloudflare edge IP instead of origin IP
- Misunderstanding between “proxy” vs “origin”

### Diagnostics
- Obtain real origin IP: `curl -s ifconfig.me` from the server (or from deployment output).
- Compare with DNS record.

### Fix
- Patch DNS records to actual origin IP.
- Re-test.
- If you need Cloudflare in front: keep proxy enabled, but origin must still be the real server/load balancer.

### Prevent
- Treat origin IP as an explicit config value.
- Add checks to prevent saving Cloudflare proxy IPs as DNS record values.

---

## KB-201: API health endpoint fails (5xx/timeout)

### Symptoms
- `/api/health` returns 500, or times out
- Admin UI can’t load or reports “backend offline”

### Likely causes
- Node process crashed or is in crashloop
- Host/container out of memory
- Port binding issue
- Dependency failure (DB connection or startup logic)

### Diagnostics
1. Check HTTP status:
   - `curl -v https://api.headysystems.com/api/health`
2. Check process/container health:
   - Docker: `docker ps`, `docker logs`
   - Render: check deploy logs
3. Check environment:
   - required variables present (`HEADY_API_KEY`, `PORT`, etc.)

### Fix
- Restart service (fast mitigation).
- Roll back to last known good release if restart doesn’t hold.
- If memory pressure: scale resources or fix leak.

### Prevent
- Add “startup dependency” checks and fail-fast with clear logs.
- Add crashloop alerts.

---

## KB-202: Admin UI loads but all tabs fail (401/403)

### Symptoms
- Admin page renders (HTML loads)
- API calls from the UI return 401 or 403
- You cannot browse files, view metrics, or run build/audit

### Likely causes
- Missing or wrong API key header
- API key changed (rotated) and UI is still using old value
- CORS blocks prevent sending auth headers

### Diagnostics
1. Open browser devtools network tab:
   - confirm requests include the expected auth header
2. Test with curl:
```bash
curl -H "x-heady-api-key: $HEADY_API_KEY" https://api.headysystems.com/api/admin/roots
```

### Fix
- Configure UI to send the correct API key
- Confirm server expects the same header name
- Update CORS allowlist to include the UI origin

### Prevent
- Implement key rotation with a grace window.
- Add a “you are not authenticated” banner instead of silent failures.

---

## KB-203: Admin file operations return “Access denied” or empty roots

### Symptoms
- file browser shows nothing
- attempts to read/write return “access denied”
- root list endpoint returns empty list

### Likely causes
- allowlisted root paths are not configured
- server doesn’t have filesystem permissions
- path normalization mismatch (Windows vs Linux paths)

### Diagnostics
- Confirm `HEADY_ADMIN_ROOT` and `HEADY_ADMIN_ALLOWED_PATHS` are set.
- Confirm the path you want is actually inside an allowed root.
- Check server logs for path validation errors.

### Fix
- Add the correct root to allowlist.
- Ensure the service user has filesystem permissions.
- Normalize paths consistently.

### Prevent
- Provide an onboarding script that sets correct defaults for dev vs prod.

---

## KB-204: Admin save conflict (SHA mismatch)

### Symptoms
- Admin editor says the file changed since it was opened
- Save is rejected

### Likely causes
- Another operator edited the file
- build/audit script rewrote the file
- file watcher triggered a formatting tool

### Diagnostics
- Re-open the file and compare the version.
- Check git history if file was committed recently.

### Fix
- Refresh file contents
- Re-apply changes
- Save again

### Prevent
- Use git-based changes for critical edits (PR review).
- Add UI “diff and merge” features.

---

## KB-301: Docker MCP services won’t start

### Symptoms
- `docker-compose ... up` fails
- containers restart repeatedly
- health check never becomes healthy

### Likely causes
- Docker Desktop not running
- port conflicts (3300/5432/6379)
- stale volumes causing DB init failure
- incorrect env vars in `.env`

### Diagnostics
- `docker ps` and `docker-compose ps`
- `docker-compose logs --tail=200`
- check ports:
  - `netstat -ano | findstr :5432` (Windows)
  - `lsof -i :5432` (macOS/Linux)

### Fix
- start Docker Desktop
- stop conflicting processes or change port mappings
- wipe dev volumes if safe:
  - `docker-compose down -v`
- rebuild:
  - `docker-compose up -d --build`

---

## KB-302: Database connection issues (Postgres)

### Symptoms
- API returns 500 with DB errors
- DB health endpoints fail
- `psql` cannot connect

### Diagnostics
- container readiness:
  - `docker exec heady-postgres pg_isready`
- connection string:
  - confirm host, user, password, db name
- logs:
  - `docker logs heady-postgres --tail=200`

### Fix
- correct `DATABASE_URL`
- restart DB container
- restore from backup if data is corrupted (dev)

---

## KB-401: Email notifications not sending (HeadySync / checkpoint reports)

### Symptoms
- checkpoint runs complete, but no email arrives
- test notifier fails
- SMTP auth errors in logs

### Likely causes
- SMTP credentials not set
- Gmail requires app password (not account password)
- SMTP blocked by firewall/network
- wrong ports (587 vs 465)

### Diagnostics
- confirm env vars:
  - `HEADY_SMTP_SERVER`
  - `HEADY_SMTP_PORT`
  - `HEADY_SMTP_USER`
  - `HEADY_SMTP_PASSWORD`
- run the notifier test script (if provided)

### Fix
- set SMTP env vars correctly
- generate and use app password (for Gmail)
- verify outbound SMTP connectivity from host

### Prevent
- run a daily email health check
- alert when emails fail to send for > N hours

---

## KB-501: HeadySync fails to push / verify remotes

### Symptoms
- sync workflow halts at push step
- verification step shows remotes out of sync

### Likely causes
- git auth failure (token expired)
- remote rejects (branch protection)
- network outage

### Diagnostics
- run `git status`, `git remote -v`, `git push` manually
- check which remote fails and why
- confirm you can authenticate with that remote

### Fix
- refresh git credentials / token
- resolve conflicts
- rerun `hsync` with verbose mode (if supported)

### Prevent
- use CI/CD credentials for automated pushes
- avoid pushing directly to protected branches; use PRs where possible

