# Ports and Endpoints Quick Reference (Heady)

> Ports vary across environments. Always confirm actual bindings in the running environment (Render config, Docker compose, systemd units, etc.).

## Common ports
- 3300 - HeadyManager API / MCP manager
- 3000 - Buddy or admin python server (varies)
- 3400 / 3401 - HeadyAI-IDE (varies)
- 3500 - HeadyWeb (varies)
- 8080 - HeadyLens metrics (varies)
- 5432 - PostgreSQL
- 6379 - Redis

## Common endpoints
- `GET /api/health`
- `GET /api/pulse`
- `GET /api/system/status`
- `GET /api/registry`
- `POST /api/pipeline/run` (HeadyCloud)
- `GET /api/pipeline/state` (HeadyCloud)

## Admin endpoints (examples)
- `/api/admin/roots`
- `/api/admin/files`
- `/api/admin/file`
- `/api/admin/build`
- `/api/admin/audit`
- `/api/admin/ops/:id/stream` (SSE)

