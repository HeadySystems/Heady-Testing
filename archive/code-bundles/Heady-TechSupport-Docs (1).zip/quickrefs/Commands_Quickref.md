# Commands Quick Reference (Heady)

## Core service checks
```bash
curl -sf https://api.headysystems.com/api/health
curl -sf https://headysystems.com/api/health
```

## Pipeline / HeadyCloud (if enabled)
```bash
curl -sf -X POST https://headycloud.com/api/pipeline/run   -H "Authorization: Bearer $HEADY_API_KEY"   -d '{"pipeline":"autobuild"}'

curl -sf https://headycloud.com/api/pipeline/state   -H "Authorization: Bearer $HEADY_API_KEY"
```

## Monte Carlo / readiness (if enabled)
```bash
curl -sf https://api.headysystems.com/api/monte-carlo/quick-readiness
curl -sf https://api.headysystems.com/api/monte-carlo/quick-deployment-risk
curl -sf https://api.headysystems.com/api/readiness/evaluate
```

## Docker MCP stack
```bash
docker-compose -f docker-compose.mcp.yml ps
docker-compose -f docker-compose.mcp.yml logs -f
docker exec heady-postgres pg_isready
docker exec heady-redis redis-cli ping
```

## Backup (Docker/dev)
```bash
docker exec heady-postgres pg_dump -U postgres heady > backup.sql
```

## HeadySync (repo sync workflow)
```bash
hsync "Message: what changed"
# or:
hsync
```

