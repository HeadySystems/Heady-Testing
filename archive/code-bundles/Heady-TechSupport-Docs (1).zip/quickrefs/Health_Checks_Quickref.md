# Health Checks Quick Reference (Heady)

## Tier 0: DNS/CDN
```bash
dig api.headysystems.com A
nslookup api.headysystems.com
curl -I https://api.headysystems.com
```

## Tier 1: API gateway / HeadyManager
```bash
curl -sf https://api.headysystems.com/api/health
curl -sf https://headysystems.com/api/health
```

## Tier 1: Status (if implemented)
```bash
curl -sf https://api.headysystems.com/api/system/status
curl -sf https://api.headysystems.com/api/registry
```

## Tier 2: IDE / Buddy (if implemented)
```bash
curl -I https://ide.headysystems.com/health
curl -I https://buddy.headysystems.com/
```

## Tier 1-2: Cloudflare workers
```bash
curl -I https://arena.headysystems.com/
curl -I https://nomenclature.headysystems.com/
```

## Data dependencies (Docker/dev)
```bash
docker exec heady-postgres pg_isready
docker exec heady-redis redis-cli ping
```

