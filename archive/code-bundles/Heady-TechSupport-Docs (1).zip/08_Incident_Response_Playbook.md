# Incident Response Playbook (Heady)

**Last updated:** 2026-02-23

This playbook defines how the team responds to outages and major degradations.

---

## 1) Goals

1. Restore service safely.
2. Communicate clearly and frequently.
3. Preserve evidence for learning.
4. Prevent recurrence.

---

## 2) Severity levels

### SEV-1 - Full outage / critical user impact
Examples:
- API health down
- authentication broken for admins/operators
- widespread 5xx errors or data loss risk
Response target:
- acknowledge within 5 minutes
- mitigation started within 15 minutes

### SEV-2 - Major degradation
Examples:
- high latency, partial unavailability
- one major app down but API up
Response target:
- acknowledge within 15 minutes

### SEV-3 - Partial feature degradation
Examples:
- Admin build failing, but user flows unaffected
- non-critical worker down
Response target:
- acknowledge within 1 hour

### SEV-4 - Minor issue / noise
Examples:
- flaky alert, minor UI issue
Response target:
- handle in backlog

---

## 3) Roles

For SEV-1/2, assign:

- **Incident Commander (IC)**
  - owns decision-making, coordination, timeline
- **Comms Lead**
  - updates status page, internal channels, stakeholders
- **Ops Lead**
  - executes mitigations (deploy/rollback/restart)
- **Scribe**
  - keeps timeline and captures evidence

One person can fill multiple roles if team is small, but explicitly assign them.

---

## 4) Incident workflow

### 4.1 Declare incident
- Create incident channel / ticket
- Assign roles
- Set severity
- Start a timeline

### 4.2 Triage (first 5-10 minutes)
Answer in order:
1. **Is it DNS/CDN?**
2. **Is the API gateway down?**
3. **Is it auth (HEADY_API_KEY) failure?**
4. **Is DB/Redis down?**
5. **Is it one service?**

Use the quick checks in quickrefs/Health_Checks_Quickref.md.

### 4.3 Mitigation
Choose the fastest safe mitigation:
- roll back the last release
- restart a crashed service
- bypass WAF rules temporarily
- switch Cloudflare proxy mode (DNS-only) to isolate issues
- disable a non-critical feature flag

### 4.4 Verification
- confirm core health endpoints
- validate critical user flows
- monitor metrics for at least 15 minutes

### 4.5 Close incident
- summarize what happened
- capture final metrics/graphs
- create follow-up tasks
- schedule postmortem

---

## 5) Evidence to capture (minimum)

- health endpoint responses (with timestamps)
- Cloudflare response headers (if edge is involved)
- service logs around onset
- deploy history / git sha deployed
- relevant dashboards/screenshots
- timeline of actions taken and outcomes

---

## 6) Communication templates (copy/paste)

### 6.1 Initial incident notice (internal)
- **Status:** Investigating
- **Impact:** <who/what is affected>
- **Start time:** <UTC>
- **Symptoms:** <observed>
- **Next update:** <time>

### 6.2 Status update
- **Status:** Investigating / Identified / Mitigating / Monitoring / Resolved
- **What we know:** <1-3 bullets>
- **What we’re doing now:** <1-3 bullets>
- **ETA:** if you have confidence, otherwise omit
- **Next update:** <time>

### 6.3 Resolution notice
- **Status:** Resolved
- **Root cause (preliminary):** <short>
- **Mitigation:** <short>
- **Follow-ups:** <short list>

---

## 7) Postmortems

A postmortem should include:
- timeline
- root cause analysis (technical + process)
- detection gaps
- what went well / what went poorly
- action items with owners and dates

Use templates/Postmortem_Template.md.

---

## 8) Common Heady incident patterns

### Pattern A: “Everything is down”
Often: DNS / Cloudflare / origin routing.  
Actions:
- confirm DNS resolution
- check Cloudflare challenge pages
- verify origin directly
- correct DNS to origin IP (not Cloudflare proxy IP)

### Pattern B: Admin UI broken
Often: API key auth missing, CORS misconfig, or file allowlist issues.  
Actions:
- confirm `HEADY_API_KEY` present and sent
- confirm allowlisted roots
- check admin endpoint responses

### Pattern C: DB unreachable
Often: network change, credential rotation, container crash.  
Actions:
- check DB health / disk / connections
- restart DB if needed (dev)
- restore from backup if data corruption suspected

