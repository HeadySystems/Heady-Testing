# Local Development Setup

**Last updated:** 2026-02-23

This document is written for support engineers and developers who need to run Heady locally to:
- reproduce issues,
- validate fixes,
- perform offline troubleshooting, or
- develop new features.

---

## 1) Prerequisites (baseline)

### Required tooling
- Node.js (18+ recommended for most tooling; some deterministic builds pin Node 20)
- npm (or pnpm if your repo uses it)
- Python 3.11+ recommended
- Git
- curl
- Docker Desktop (recommended for DB/Redis/MCP stack)

### Recommended tooling
- `jq` (JSON formatting)
- `psql` client (Postgres)
- `redis-cli` client
- a terminal multiplexer (tmux) or multiple terminal windows

---

## 2) Minimal local run (no DB)

### 2.1 Install dependencies
```bash
npm install
pip install -r requirements.txt
```

### 2.2 Set required environment variables
```bash
export HEADY_API_KEY="your-api-key"
export HF_TOKEN="your-hf-token"          # if using inference endpoints
export DATABASE_URL="postgresql://..."   # optional for no-DB mode
```

### 2.3 Start the server
```bash
npm start
# or:
node heady-manager.js
```

### 2.4 Verify
```bash
curl -sf http://localhost:3300/api/health
```

---

## 3) Local run with Docker (recommended)

This is the most support-friendly local environment because it matches production dependencies more closely.

### 3.1 Bring up the Docker MCP stack
Windows / PowerShell quick start:
```powershell
.\docker-mcp-setup.ps1
.\start-docker-mcp.ps1
docker-compose -f docker-compose.mcp.yml ps
```

### 3.2 Verify database and cache
```bash
docker exec heady-postgres pg_isready
docker exec heady-redis redis-cli ping
```

### 3.3 Point your app at Docker DB/Redis
Example DB string (adjust password):
```bash
export DATABASE_URL="postgresql://postgres:password@localhost:5432/heady"
```

### 3.4 Start HeadyManager
```bash
node heady-manager.js
```

### 3.5 Verify the full loop
```bash
curl -sf http://localhost:3300/api/health
```

---

## 4) Admin IDE (local)

### 4.1 Access
If served by the local manager, the Admin IDE is typically available at:
- `/admin` or `/admin.html`

### 4.2 Troubleshooting (local)
If the UI loads but:
- file browser shows nothing -> check allowlisted roots
- save fails -> check file size limits and SHA conflict detection
- build/audit buttons fail -> check script paths + python environment

---

## 5) Build and audit (local)

### 5.1 Run a build (CLI)
```bash
python src/consolidated_builder.py --project-root /path/to/project --output build-info.json
```

### 5.2 Run an audit (CLI)
```bash
python admin_console.py --project-root /path/to/project
# or targeted:
python admin_console.py --check health
python admin_console.py --check deps
python admin_console.py --check security
```

---

## 6) Common local issues and fixes

### 6.1 Port conflicts (3300, 5432, 6379)
Symptoms:
- “EADDRINUSE” on startup
- Docker containers fail to bind

Fix:
- Identify process using port:
  - Linux/macOS: `lsof -i :3300`
  - Windows: `netstat -ano | findstr :3300`
- Stop the conflicting process, or change port mappings in compose.

### 6.2 Missing Python deps
Symptoms:
- build/audit scripts crash with `ModuleNotFoundError`

Fix:
- Verify python version: `python --version`
- Reinstall deps: `pip install -r requirements.txt`
- Consider using a venv: `python -m venv .venv && source .venv/bin/activate`

### 6.3 API key issues
Symptoms:
- 401/403 for admin endpoints
- admin UI panels fail

Fix:
- Confirm server has `HEADY_API_KEY` set
- Confirm client sends `x-heady-api-key` header (or expected auth header)
- Rotate key if suspected leaked

### 6.4 Docker Desktop not running
Symptoms:
- `docker ps` fails
- compose scripts fail

Fix:
- Start Docker Desktop and wait for daemon readiness.

---

## 7) Reproducing production issues locally

To reproduce problems like Cloudflare challenges or DNS routing, local may not help directly.
Instead:
- validate the origin service locally,
- then compare with what Cloudflare returns in production.

See the Troubleshooting KB for the “Origin healthy but Cloudflare 403” playbook.

