# Monitoring, Alerting, and Observability

**Last updated:** 2026-02-23

This document explains how to observe the Heady system in production and how to design alerts that:
- detect real outages quickly,
- avoid false positives, and
- provide enough context for fast mitigation.

---

## 1) Observability goals for Heady

A support-ready platform should answer:
1. **Is the system up?**
2. **Is it serving users successfully?**
3. **Is it fast enough (latency)?**
4. **Is it safe (auth, security, data integrity)?**
5. **Can we recover quickly?**

---

## 2) Health checks (canonical endpoints)

### 2.1 API health (Tier 1)
- `GET /api/health` - simple health check
- `GET /api/pulse` - status and Docker info (if enabled)

**Support usage:** this is the first “is it alive?” check.

### 2.2 System status (Tier 1)
Some docs reference:
- `GET /api/system/status` - full system status
- `GET /api/registry` - component registry

### 2.3 Readiness and Monte Carlo risk checks (if present)
Examples referenced in command sheets:
- `GET /api/monte-carlo/readiness`
- `GET /api/monte-carlo/quick-readiness`
- `GET /api/monte-carlo/quick-deployment-risk`
- `GET /api/readiness/evaluate`

**Support usage:** these are useful for *change safety* and *deployment decisions*, not only outages.

### 2.4 Admin operation tracking (Tier 2)
Admin endpoints can expose:
- list operations
- operation status
- SSE log streams for build/audit operations

**Support usage:** when build/audit “hangs,” use op status + SSE logs to find the step that stalled.

---

## 3) Metrics (what to track)

### 3.1 Golden signals (per service)
For each service, track:
- **Traffic:** request rate (RPS)
- **Errors:** 4xx/5xx rate
- **Latency:** p50/p95/p99
- **Saturation:** CPU, memory, disk, connection pools

### 3.2 Platform-level metrics
- system CPU/memory
- disk usage (especially on DB hosts)
- container restarts / crashloops
- DB connections and slow queries
- queue/backlog (if present)

### 3.3 Cloudflare layer metrics (Tier 0)
Track:
- DNS resolution failures
- WAF challenge events (403)
- rate limit triggers
- origin health checks (if using Cloudflare load balancers)

**Support usage:** differentiate “origin down” vs “edge blocking users.”

---

## 4) Logs (where to look)

### 4.1 Service logs
You should have:
- structured logs from Node services (request id, user id, route)
- structured logs from Python scripts (build/audit/inference)

### 4.2 Admin build/audit logs
If admin operations stream logs via SSE:
- capture the SSE stream output in incident notes
- store logs with the incident ticket

### 4.3 Docker logs (local or containerized environments)
```bash
docker-compose logs -f
docker-compose logs --tail=200 heady-mcp-manager
```

---

## 5) Suggested alerts (baseline)

### 5.1 Tier 0 (Cloudflare/DNS) alerts
- DNS resolution failing for primary domains for > 2 minutes
- spike in Cloudflare 403 challenge responses
- SSL/TLS failures or certificate issues

### 5.2 Tier 1 (API gateway) alerts
- `/api/health` failing from 2+ regions for > 2 minutes
- 5xx rate > 5% for 5 minutes
- p95 latency > target (set per SLO)
- process restarts > 3 within 10 minutes (crashloop)

### 5.3 Tier 1 data alerts
- DB unreachable from API for > 1 minute
- DB disk usage > 80%
- connection pool saturation > 90%

### 5.4 Tier 2 (IDE/Buddy/Web) alerts
- service health endpoints failing
- elevated errors impacting user flows

---

## 6) Alert routing and escalation

### 6.1 Severity mapping
- **SEV-1**: user-facing outage (core flows down)
- **SEV-2**: major degradation (high errors/latency)
- **SEV-3**: partial feature degradation
- **SEV-4**: minor or internal issue

### 6.2 Escalation principle
Escalate to infrastructure (DNS/CDN/DB) quickly if:
- multiple services fail simultaneously
- edge responses are challenges/403s
- origin is healthy but users can’t reach it

---

## 7) Observability “first response” playbooks

### 7.1 If `/api/health` fails
1. Check DNS resolution for api domain.
2. Check Cloudflare for challenges.
3. Check origin health (direct IP if allowed).
4. Check service logs and restart status.
5. Check data dependencies (DB/Redis).

### 7.2 If admin operations hang
1. Query operation status endpoint (if available).
2. Attach to SSE stream.
3. Check server resource saturation.
4. Check filesystem permissions / path allowlists.
5. Check Python env/deps for scripts.

### 7.3 If Cloudflare returns 403 challenge
1. Confirm origin health locally (or direct IP).
2. Check Cloudflare WAF/bot protection settings for the subdomain.
3. Confirm DNS is pointing to actual origin IP (not a Cloudflare proxy IP).
4. Add WAF exceptions for health endpoints (if needed).

