# Backup, Restore, and Disaster Recovery (DR)

**Last updated:** 2026-02-23

This document defines how to protect Heady data and how to recover services after major failures.

---

## 1) Data classification (what must be backed up)

### 1.1 Critical (Tier 1)
- Primary PostgreSQL database (application state, logs, registry)
- Secrets store (NOT in plaintext - stored in secrets manager)
- Deployment configuration (Render/Cloudflare settings, IaC)

### 1.2 Important (Tier 2)
- `.heady-memory/` data (if used as persistent memory)
- build artifacts (if needed for auditability)
- audit logs / operation logs (if not already in DB)

### 1.3 Nice-to-have
- local caches
- temporary files

---

## 2) Backup strategies

### 2.1 PostgreSQL
**Preferred (production):**
- managed DB snapshots (daily + point-in-time recovery if available)

**Fallback / dev:**
- `pg_dump` exports

Example (Docker):
```bash
docker exec heady-postgres pg_dump -U postgres heady > heady_backup_$(date +%F).sql
```

### 2.2 Redis
Redis is often treated as cache. If it contains durable data, enable:
- AOF persistence
- regular snapshot backups

Example (Docker volume backup):
```bash
docker run --rm -v redis_data:/data -v $(pwd):/backup alpine   tar czf /backup/redis_data_backup_$(date +%F).tar.gz -C /data .
```

### 2.3 HeadyMemory directory backups
If `.heady-memory/` is critical:
- store it on durable storage (e.g., object storage)
- back it up daily

Example:
```bash
tar czf heady_memory_$(date +%F).tar.gz .heady-memory
```

---

## 3) Restore procedures

### 3.1 Restore PostgreSQL from SQL dump (Docker/dev)
```bash
cat heady_backup.sql | docker exec -i heady-postgres psql -U postgres heady
```

### 3.2 Restore volumes (Docker/dev)
If you have tarball backups of volumes, restore by:
- recreating volumes
- extracting tar to the volume mount
- restarting services

---

## 4) DR planning (production)

### 4.1 Define RPO/RTO
- **RPO** (Recovery Point Objective): acceptable data loss window
- **RTO** (Recovery Time Objective): acceptable downtime window

### 4.2 Multi-region concept (example)
Some architecture guidance proposes:
- Primary: `us-east-1` for full production
- Secondary: `us-west-2` for read replicas / failover
- DR: `eu-west-1` for point-in-time restore and critical services

### 4.3 Network segmentation (example)
A common VPC approach is:
- VPC CIDR `10.0.0.0/16`
- public subnets (LB/NAT)
- private subnets (apps)
- DB subnets (Postgres/Redis)

Support implication:
- outages can be isolated to subnets (routing, NAT, ACL problems)
- DR recovery depends on DNS/CDN updates and database restoration

---

## 5) DR runbook (high level)

### Scenario A: Region outage (Tier 0/1)
1. Declare incident (SEV-1).
2. Verify outage is region-wide.
3. Fail over to secondary region:
   - promote DB replica (or restore PITR)
   - deploy API and core services
4. Update DNS / Cloudflare to route to healthy region.
5. Validate health and user flows.
6. Monitor for stability and close incident.
7. Postmortem.

### Scenario B: Database corruption (Tier 1)
1. Stop writes (maintenance mode / disable traffic if necessary).
2. Identify last known good snapshot or PITR time.
3. Restore DB to new instance.
4. Point services to restored DB.
5. Run integrity checks.
6. Resume traffic.

### Scenario C: Secret compromise (Tier 1 security)
1. Rotate compromised secret immediately.
2. Revoke or invalidate tokens/keys.
3. Audit logs for misuse.
4. Re-deploy with new secrets.
5. Postmortem + hardening actions.

---

## 6) Backup verification (do not skip)

Backups are only useful if they restore.

At minimum:
- monthly restore drill in staging/dev
- verify dump files are non-empty and parseable
- ensure restore commands are documented and tested

