# Postmortem Template (Heady)

## Executive Summary
<3-6 sentences describing what happened and why it matters>

## Customer Impact
- Who was affected?
- What was the impact (outage, latency, partial features)?
- Duration:
- Metrics (error rate, latency, affected requests):

## Timeline (UTC)
| Time | Event | Owner |
|---|---|---|
| | | |

## Root Cause Analysis
### What happened
### Why it happened (5 Whys)
1.
2.
3.
4.
5.

## Contributing Factors
- Technical:
- Process:
- Monitoring gaps:

## What went well
- ...

## What went poorly
- ...

## Where we got lucky
- ...

## Action Items
| Item | Type (Prevent/Detect/Mitigate) | Owner | Due date | Status |
|---|---|---|---|---|
| | | | | |

## Lessons learned
- ...

