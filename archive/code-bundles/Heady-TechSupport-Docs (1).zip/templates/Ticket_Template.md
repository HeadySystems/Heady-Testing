# Ticket Template (Heady Support)

## Summary
<one sentence>

## Type
- [ ] Incident
- [ ] Bug
- [ ] Access/Config Request
- [ ] Question

## Severity
- [ ] SEV-1
- [ ] SEV-2
- [ ] SEV-3
- [ ] SEV-4

## Environment
- [ ] Production
- [ ] Staging
- [ ] Development
- [ ] Local
- [ ] Hybrid

## Impacted Service(s) / Domain(s)
- <service/domain>

## First Observed (timestamp + timezone)
- <YYYY-MM-DD HH:MM TZ>

## Current Status
- [ ] Investigating
- [ ] Identified
- [ ] Mitigating
- [ ] Monitoring
- [ ] Resolved

## Symptoms
- <what is broken, how is it visible?>

## Steps to Reproduce (if applicable)
1. ...
2. ...

## Expected Behavior
- ...

## Actual Behavior
- ...

## Evidence
- Health check results (paste output)
- Relevant logs (redacted)
- Screenshots
- Request IDs / correlation IDs

## Recent Changes
- Deployments? DNS/WAF changes? Secret rotations?

## What has already been tried?
- ...

## Contact / Stakeholder
- <name/email/handle>

