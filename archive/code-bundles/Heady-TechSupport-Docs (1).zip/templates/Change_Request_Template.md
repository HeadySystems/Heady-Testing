# Change Request Template (Heady)

## Change summary
- What are we changing?
- Why are we changing it?

## Scope
- Services/domains impacted:
- Environments impacted:

## Risk assessment
- What could go wrong?
- Blast radius:
- Is this reversible?

## Preconditions / dependencies
- Secrets needed:
- DNS/WAF changes needed:
- DB migrations needed:

## Rollout plan
1.
2.
3.

## Verification plan
- Health endpoints to check:
- User flows to test:
- Metrics to watch:

## Rollback plan
- Exact rollback steps:

## Maintenance window
- Proposed date/time (UTC):
- Communication plan:

## Approval
- Approved by:
- Date:

