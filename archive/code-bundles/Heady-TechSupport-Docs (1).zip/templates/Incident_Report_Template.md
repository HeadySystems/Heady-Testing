# Incident Report Template (Heady)

## Incident Summary
- Incident ID:
- Severity:
- Start time (UTC):
- End time (UTC):
- Duration:
- Impacted services/domains:
- User impact:

## Timeline (UTC)
| Time | Action / Observation | Owner | Result |
|---|---|---|---|
| | | | |

## Detection
- How was it detected? (alert, user report, etc.)
- Which signals were most helpful?

## Root Cause (preliminary)
- What failed?
- Why did it fail?
- Triggering event/change:

## Mitigation
- What actions restored service?
- What was the rollback/restart/config change?

## Verification
- Health endpoint results:
- Key user flows tested:

## Follow-up actions
| Action | Owner | Due date | Status |
|---|---|---|---|
| | | | |

## Customer/Stakeholder communication
- Initial notice:
- Updates:
- Resolution notice:

