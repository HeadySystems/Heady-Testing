# Support Operations and Processes

**Last updated:** 2026-02-23

This document defines how tech support should operate for Heady:
- intake and triage,
- escalation,
- change management,
- maintenance windows,
- knowledge base hygiene.

---

## 1) Support scope

Support covers:
- production and staging availability
- deployment assistance and rollbacks
- configuration and secret rotations
- DNS/CDN/WAF issues
- database and cache operations (backup/restore)
- admin UI/IDE operational support
- CI/CD and automation workflows (e.g., sync, checkpointing)

Support does not cover (unless explicitly assigned):
- feature design
- long-term roadmap
- major refactors without owner involvement

---

## 2) Ticket intake

### 2.1 Ticket types
- **Incident** (service down / major impact)
- **Bug** (functional defect)
- **Request** (access, config, data change)
- **Question** (how-to)

### 2.2 Required fields (minimum)
- environment (dev/staging/prod)
- impacted domain/service
- exact timestamp(s) and timezone
- reproduction steps (if any)
- error messages / screenshots
- request id / correlation id (if available)
- contact / stakeholder

Use templates/Ticket_Template.md.

---

## 3) Triage workflow

1. Assign severity (SEV-1..4)
2. Identify the impacted service
3. Determine failure layer:
   - Cloudflare/DNS
   - API gateway
   - data dependencies
   - feature service
4. Apply the relevant runbook
5. Escalate when:
   - infrastructure changes are required
   - code owner input is needed
   - data integrity is at risk

---

## 4) Escalation matrix

### 4.1 Escalate to infrastructure (DNS/CDN/DB) if:
- multiple services fail at once
- Cloudflare challenges block users
- SSL/TLS issues
- DB connectivity or corruption

### 4.2 Escalate to application owners if:
- reproducible code bug
- feature behavior inconsistent with expected outcomes
- logs indicate an internal exception path

---

## 5) SLAs and SLOs (templates)

### 5.1 Suggested SLOs (fill with real targets)
- API availability: 99.9%
- p95 latency: < 250ms
- error rate (5xx): < 1%

### 5.2 Suggested support SLAs (fill with real targets)
- SEV-1: acknowledge 5 min, mitigate 15 min
- SEV-2: acknowledge 15 min, mitigate 1 hr
- SEV-3: acknowledge 1 hr, mitigate 1-3 days
- SEV-4: next sprint / backlog

---

## 6) Change management

### 6.1 What counts as a change
- deployments
- DNS changes
- Cloudflare/WAF rule changes
- secret rotations
- DB migrations

### 6.2 Change request minimum
- purpose
- risk assessment
- rollback plan
- verification plan
- maintenance window if needed

Use templates/Change_Request_Template.md.

---

## 7) Maintenance windows

For high-risk changes (DNS, DB migrations):
- schedule a maintenance window
- announce ahead of time
- reduce traffic if possible
- have rollback ready
- do post-change verification

---

## 8) Repo synchronization and checkpointing (operations)

The ecosystem includes a “sync” workflow that conceptually:
- detects changes
- stages and commits
- runs an automated checkpoint/build
- captures registry/system status
- pushes to all remotes
- verifies remotes match

Support implications:
- if deploy pipeline depends on repo state, “sync drift” can cause confusion
- ensure remotes are consistent and verified before major releases
- email checkpoint reports can provide visibility for stakeholders (if configured)

---

## 9) Knowledge base hygiene

- Every resolved incident should produce at least one KB update:
  - new symptom pattern
  - better diagnostics
  - safer mitigation
- Track top recurring issues monthly (DNS/WAF/auth tend to dominate).
- Keep quickrefs updated whenever endpoints or ports change.

