# Docker MCP Runbook (HeadyMCP / Docker Desktop Integration)

**Last updated:** 2026-02-23

This runbook covers the Docker-based MCP stack used in the Heady ecosystem. It is written for:
- support engineers troubleshooting local or dev issues,
- operators validating DB/cache dependencies,
- developers using MCP tooling (filesystem, memory, fetch, postgres).

---

## 1) What this stack provides

The Docker MCP stack typically includes:
- a “manager” container running the Heady MCP orchestrator (port 3300)
- MCP servers:
  - filesystem
  - postgres
  - memory
  - fetch
- data dependencies:
  - PostgreSQL (5432)
  - Redis (6379)
- an isolated Docker bridge network for communication

---

## 2) Quick start (Windows PowerShell)

### 2.1 Setup
```powershell
.\docker-mcp-setup.ps1
```

### 2.2 Start all services
```powershell
.\start-docker-mcp.ps1
```

### 2.3 Verify services
```powershell
docker-compose -f docker-compose.mcp.yml ps
```

### 2.4 View logs
```powershell
docker-compose -f docker-compose.mcp.yml logs -f
```

### 2.5 Stop services
```powershell
.\stop-docker-mcp.ps1
```

---

## 3) Service inventory (typical)

| Container | Purpose | Ports | Health |
|---|---|---|---|
| `heady-mcp-manager` | orchestrator / manager | 3300:3300 | `GET /api/health` |
| `heady-postgres` | DB | 5432:5432 | `pg_isready` |
| `heady-redis` | cache | 6379:6379 | `redis-cli ping` |
| `heady-mcp-filesystem` | filesystem MCP server | internal | logs |
| `heady-mcp-postgres` | postgres MCP server | internal | logs |
| `heady-mcp-memory` | memory MCP server | internal | logs |
| `heady-mcp-fetch` | fetch MCP server | internal | logs |

---

## 4) Operational commands (day-2 support)

### 4.1 Check container status
```bash
docker ps --filter "name=heady"
docker-compose -f docker-compose.mcp.yml ps
```

### 4.2 Inspect logs
```bash
docker-compose -f docker-compose.mcp.yml logs --tail=200 heady-mcp-manager
docker-compose -f docker-compose.mcp.yml logs --tail=200 heady-postgres
```

### 4.3 Restart
```bash
docker-compose -f docker-compose.mcp.yml restart
# or one service:
docker-compose -f docker-compose.mcp.yml restart heady-postgres
```

### 4.4 Clean restart (wipe volumes)
**WARNING:** This deletes DB/cache data.
```bash
docker-compose -f docker-compose.mcp.yml down -v
docker-compose -f docker-compose.mcp.yml up -d --build
```

---

## 5) Database operations (support)

### 5.1 Confirm Postgres is ready
```bash
docker exec heady-postgres pg_isready
```

### 5.2 Connect with psql
```bash
docker exec -it heady-postgres psql -U postgres -d heady
```

### 5.3 Backup (dump)
```bash
docker exec heady-postgres pg_dump -U postgres heady > backup.sql
```

### 5.4 Restore
```bash
cat backup.sql | docker exec -i heady-postgres psql -U postgres heady
```

---

## 6) Redis operations (support)

### 6.1 Ping
```bash
docker exec -it heady-redis redis-cli ping
```

### 6.2 Memory info
```bash
docker exec -it heady-redis redis-cli info memory
```

### 6.3 Flush cache (use with caution)
```bash
docker exec -it heady-redis redis-cli FLUSHALL
```

---

## 7) Troubleshooting

### 7.1 Docker daemon not running
Symptoms:
- `docker ps` fails
- compose scripts fail

Fix:
- Start Docker Desktop and wait for “Engine running”

### 7.2 Port already in use
Symptoms:
- containers fail to start
- compose output mentions “bind: address already in use”

Fix options:
- stop the conflicting process
- remap ports in docker-compose (e.g., 5433:5432)

### 7.3 Volume permission issues
Symptoms:
- filesystem MCP cannot read/write files
- logs show permission denied

Fix:
- ensure workspace path is correct and accessible
- ensure volume mount path exists
- on macOS/Windows, confirm Docker Desktop “File Sharing” permissions include the path

### 7.4 Postgres init issues
Symptoms:
- DB container restarts repeatedly
- init.sql errors in logs

Fix:
- review `init.sql` and container logs
- wipe volume if in dev environment and recreate:
  - `docker-compose down -v` then `up -d`

---

## 8) Security notes

- Never commit `.env` files with secrets.
- If you need Cloudflare integration for tooling, pass tokens via environment variables only.
- Docker socket mounting enables powerful operations; treat it as privileged access.

---

## 9) Adding a new MCP server (procedure)

1. Add the service definition to `docker-compose.mcp.yml`.
2. Add config entry to `mcp_config.json` (if used).
3. Ensure the server is reachable on the MCP network.
4. Restart stack.
5. Validate the orchestrator can call it (registry/tool list if available).

