# GAPS_FOUND

## Issues found during this pass

### 1. Upstream site registry emitted forbidden wording
- File: `/home/user/workspace/heady-perplexity-full-system-context/heady-perplexity-bundle/01-site-registry.json`
- Problem: `headyos.com` feature copy contained `hot-reload`, which triggered the site generator forbidden-language validation.
- Resolution: replaced that phrase with `live sync`.

### 2. Service generator count mismatch
- File: `/home/user/workspace/heady-system-build/scripts/gen-services.py`
- Problem: the generator asserted 50 services but defined 51 entries.
- Root cause: both `heady-mcp-registry` and `heady-cache` were present at the tail of the list.
- Resolution: removed the extra generated service entry and preserved a 50-service output.

### 3. Service package template formatting bug
- File: `/home/user/workspace/heady-system-build/scripts/gen-services.py`
- Problem: Python string formatting failed while writing service `package.json` files.
- Root cause: raw JSON braces in the template were not escaped for Python `.format()`.
- Resolution: escaped template braces so generation succeeds.

### 4. Stale summary documentation language
- File: `/home/user/workspace/heady-system-build/docs/platform-build-summary.md`
- Problem: older wording still referenced banned or superseded language.
- Examples:
  - `CLOSED/OPEN/HALF_OPEN`
  - `heady-hot-cold-router`
- Resolution: updated those references to compliant concurrent-equals wording.

## Remaining limits after this pass

The build is materially improved and packaged for handoff, but these larger tasks are still not fully completed in a verified end-to-end way:

- All 50 services were generated and indexed, but they were not all launched simultaneously in this pass.
- No full docker-compose bring-up across the entire stack was completed in this pass.
- No full health sweep across every running service instance was completed in this pass.
- No live cross-domain browser sign-in verification across all public domains was completed in this pass.
- Drupal content-type install verification and webhook runtime verification were not completed in this pass.
- Infrastructure validation for real certificates, Consul mesh wiring, and live OpenTelemetry collector export was not completed in this pass.

## Practical interpretation

The code and generated artifacts are in a much better state and the generator pipeline now completes locally for sites and service scaffolds. Full runtime verification of every subsystem still remains as a larger follow-on task.