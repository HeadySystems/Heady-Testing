import { execSync } from 'node:child_process';
import path from 'node:path';

const root = path.resolve(process.cwd());
const target = path.join(path.dirname(root), 'heady-monorepo-rebuild.zip');
execSync(`python -m zipfile -c ${JSON.stringify(target)} ${JSON.stringify(root)}`, { stdio: 'inherit' });
console.log(target);
