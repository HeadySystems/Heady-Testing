# Heady Monorepo Rebuild

This monorepo is a clean rebuild of the Heady control plane around a working core instead of the broken projection shells found across the public repos.

## What is included

- A runnable API gateway with JWT and API-key auth
- A secure user-scoped memory system with 384-dimensional embeddings and derived 3D coordinates
- A file-backed persistence mode for zero-setup local use
- A PostgreSQL + pgvector mode for production persistence and vector search
- JSON-RPC 2.0 MCP endpoints over HTTP, WebSocket, and Server-Sent Events
- A small browser console so any site or UI can authenticate and work with the system
- Docker Compose for Postgres + pgvector deployment
- Tests and a smoke-check script

## Quick start

```bash
npm install
cp .env.example .env
npm run dev
```

Open [http://localhost:3400](http://localhost:3400).

Register the first account from the web console. The first registered account becomes the owner account automatically.

## Runtime modes

### Local file mode
If `DATABASE_URL` is empty, the system persists users and memories under `./data/` using JSON files. This mode is fully functional and useful for local development.

### PostgreSQL + pgvector mode
If `DATABASE_URL` is set, the gateway automatically provisions the vector schema and uses pgvector-backed similarity search.

```bash
docker compose up -d postgres
npm run dev
```

## Key routes

- `GET /api/health`
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `POST /api/auth/api-keys`
- `POST /api/memory/upsert`
- `POST /api/memory/search`
- `GET /api/memory/list`
- `GET /api/memory/timeline`
- `POST /mcp/rpc`
- `GET /mcp/sse`
- `WS /ws/events`
- `WS /ws/mcp`

## Monorepo layout

```text
apps/
  gateway/          Main API, event streams, MCP bridge, browser console
packages/
  shared/           Config, crypto, auth helpers, deterministic embeddings
  vector-memory/    Postgres + file-backed memory engine with 3D coordinates
  mcp/              MCP tool registry and JSON-RPC dispatch
configs/
  domains.json      Domain projection map from the public Heady repos
  source-map.json   Source inputs used for this rebuild
scripts/
  smoke-check.mjs   Minimal runtime verification
  package-zip.mjs   Creates the final distributable zip
```
