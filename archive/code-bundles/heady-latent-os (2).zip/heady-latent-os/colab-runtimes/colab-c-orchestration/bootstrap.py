# ============================================================
# Heady Latent OS — Colab Runtime C: Orchestration/Meta
# Run in Google Colab Pro+ with GPU runtime
# ============================================================
# Cell 1: Install dependencies
!pip install fastmcp numpy uvicorn starlette
!wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
!dpkg -i cloudflared-linux-amd64.deb

# Cell 2: Clone or upload the heady-latent-os package
# !git clone https://github.com/HeadyMe/heady-latent-os.git
# or upload the ZIP and unzip

# Cell 3: Set runtime identity
import os
os.environ['HEADY_RUNTIME'] = 'C'
os.environ['HEADY_MCP_PORT'] = '8003'

# Cell 4: Start MCP server in background
import subprocess
import threading
import time

def start_server():
    subprocess.Popen([
        'python', 'heady-latent-os/python-servers/mcp_tools/server.py'
    ])

threading.Thread(target=start_server, daemon=True).start()
time.sleep(3)
print("MCP Server A (audio/temporal) starting on port 8003...")

# Cell 5: Start Cloudflare tunnel
import socket

def wait_for_port(port, timeout=30):
    start = time.time()
    while time.time() - start < timeout:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect(('127.0.0.1', port))
            sock.close()
            return True
        except:
            time.sleep(0.5)
    return False

if wait_for_port(8003):
    print("Server is ready. Starting Cloudflare tunnel...")
    # Option 1: Quick tunnel (temporary URL)
    tunnel = subprocess.Popen(
        ['cloudflared', 'tunnel', '--url', 'http://127.0.0.1:8003'],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    # Read tunnel URL from stderr
    for line in tunnel.stderr:
        l = line.decode()
        if 'trycloudflare.com' in l:
            url = l[l.find('http'):].strip()
            print(f"\n🌀 Colab C Tunnel URL: {url}")
            print(f"   Set COLAB_C_URL={url}/mcp/ in your Node gateway .env")
            break
else:
    print("ERROR: Server failed to start on port 8003")

# Cell 6: Health check
import urllib.request
try:
    req = urllib.request.Request('http://127.0.0.1:8003/mcp/', method='POST',
        headers={'Content-Type': 'application/json'},
        data=json.dumps({"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}).encode())
    resp = urllib.request.urlopen(req)
    tools = json.loads(resp.read())
    print(f"Tools available: {len(tools.get('result',{}).get('tools',[]))}")
except Exception as e:
    print(f"Health check: {e}")
