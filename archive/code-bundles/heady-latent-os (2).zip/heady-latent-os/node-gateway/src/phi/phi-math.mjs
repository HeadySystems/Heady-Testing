// phi-math.mjs — Golden ratio math utilities for Heady Latent OS
// Zero fixed constants: everything derived from φ = (1+√5)/2

const PHI = (1 + Math.sqrt(5)) / 2;
const PHI_INV = 1 / PHI;
const PHI_SQ = PHI * PHI;
const PHI_CUBE = PHI * PHI * PHI;
const GOLDEN_ANGLE_RAD = 2 * Math.PI * (1 - PHI_INV);
const GOLDEN_ANGLE_DEG = GOLDEN_ANGLE_RAD * (180 / Math.PI);
const SQRT3 = Math.sqrt(3); // vesica piscis height:width ratio
const SQRT5 = Math.sqrt(5); // pentagonal diagonal

// Fibonacci generator (yields indefinitely)
function* fibonacci() {
  let a = 0, b = 1;
  while (true) { yield a; [a, b] = [b, a + b]; }
}

// Get first N Fibonacci numbers
function fibSequence(n) {
  const gen = fibonacci();
  return Array.from({ length: n }, () => gen.next().value);
}

// φ^n scaling for octave system
function phiScale(octave) { return Math.pow(PHI, octave); }

// Inverse: given a scale, find nearest octave
function scaleToOctave(scale) { return Math.round(Math.log(scale) / Math.log(PHI)); }

// Golden spiral: radius at angle θ
function goldenSpiralRadius(theta, a = 1) {
  return a * Math.pow(PHI, (2 * theta) / Math.PI);
}

// Golden spiral: [x, y] at angle θ
function goldenSpiralPoint(theta, a = 1) {
  const r = goldenSpiralRadius(theta, a);
  return [r * Math.cos(theta), r * Math.sin(theta)];
}

// φ-balanced weighted average (short:long = φ:1)
function phiBalance(shortTerm, longTerm) {
  return PHI_INV * shortTerm + (1 - PHI_INV) * longTerm;
}

// Exponential moving average with φ-derived alpha
function phiEMA(prev, current, depth = 1) {
  const alpha = 1 / Math.pow(PHI, depth);
  return (1 - alpha) * prev + alpha * current;
}

// Torus parametric coordinates
function torusPoint(theta, phiAngle, R = PHI, r = 1) {
  return [
    (R + r * Math.cos(phiAngle)) * Math.cos(theta),
    (R + r * Math.cos(phiAngle)) * Math.sin(theta),
    r * Math.sin(phiAngle)
  ];
}

// Vesica piscis height (given circle radius)
function vesicaHeight(radius) { return radius * SQRT3; }

// Seed of Life: positions of 7 circles (center + 6 around)
function seedOfLifePositions(radius) {
  const positions = [[0, 0]];
  for (let i = 0; i < 6; i++) {
    const angle = (Math.PI / 3) * i;
    positions.push([radius * Math.cos(angle), radius * Math.sin(angle)]);
  }
  return positions;
}

// Flower of Life: positions of 19 circles (inner two rings)
function flowerOfLifePositions(radius) {
  const positions = seedOfLifePositions(radius);
  for (let i = 0; i < 6; i++) {
    const a1 = (Math.PI / 3) * i;
    const a2 = (Math.PI / 3) * ((i + 1) % 6);
    const cx = radius * (Math.cos(a1) + Math.cos(a2));
    const cy = radius * (Math.sin(a1) + Math.sin(a2));
    positions.push([cx, cy]);
  }
  for (let i = 0; i < 6; i++) {
    const angle = (Math.PI / 3) * i;
    positions.push([2 * radius * Math.cos(angle), 2 * radius * Math.sin(angle)]);
  }
  return positions;
}

// Pentagram vertices
function pentagramVertices(radius, rotation = -Math.PI / 2) {
  return Array.from({ length: 5 }, (_, i) => {
    const angle = rotation + (2 * Math.PI * i) / 5;
    return [radius * Math.cos(angle), radius * Math.sin(angle)];
  });
}

// φ-proportional resource allocation for N agents
function phiAllocate(weights) {
  const total = weights.reduce((s, w) => s + w, 0);
  if (total === 0) return weights.map(() => 1 / weights.length);
  return weights.map(w => w / total);
}

// Quantize a float to nearest φ-scaled level within octave range
function phiQuantize(value, octave, levels = 8) {
  const scale = phiScale(octave);
  const step = scale / levels;
  return Math.round(value / step) * step;
}

export {
  PHI, PHI_INV, PHI_SQ, PHI_CUBE,
  GOLDEN_ANGLE_RAD, GOLDEN_ANGLE_DEG,
  SQRT3, SQRT5,
  fibonacci, fibSequence,
  phiScale, scaleToOctave,
  goldenSpiralRadius, goldenSpiralPoint,
  phiBalance, phiEMA,
  torusPoint, vesicaHeight,
  seedOfLifePositions, flowerOfLifePositions,
  pentagramVertices,
  phiAllocate, phiQuantize
};
