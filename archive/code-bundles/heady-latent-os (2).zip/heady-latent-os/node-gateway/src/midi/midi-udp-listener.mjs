// midi-udp-listener.mjs — Receives raw MIDI over UDP, parses, enriches with nibbles/vectors/phi
import dgram from 'node:dgram';
import { randomUUID } from 'node:crypto';
import { PHI, phiScale, goldenSpiralPoint, GOLDEN_ANGLE_RAD } from '../phi/phi-math.mjs';

const DEFAULT_PORT = 9000;

// MIDI status byte → message type
function midiType(status) {
  const hi = (status >> 4) & 0x0F;
  const types = { 0x8: 'note_off', 0x9: 'note_on', 0xA: 'aftertouch', 0xB: 'cc',
                   0xC: 'program_change', 0xD: 'aftertouch', 0xE: 'pitch_bend',
                   0xF: 'sysex' };
  return types[hi] || 'unknown';
}

// Parse raw MIDI bytes into structured message
function parseMidi(buf) {
  if (buf.length < 1) return null;
  const status = buf[0];
  const channel = status & 0x0F;
  const type = midiType(status);
  const msg = { raw: Buffer.from(buf).toString('hex').toUpperCase().match(/.{2}/g).join(' '), type, channel };

  if (['note_on', 'note_off'].includes(type) && buf.length >= 3) {
    msg.note = buf[1]; msg.velocity = buf[2];
    if (type === 'note_on' && msg.velocity === 0) msg.type = 'note_off';
  } else if (type === 'cc' && buf.length >= 3) {
    msg.cc_number = buf[1]; msg.cc_value = buf[2];
  } else if (type === 'pitch_bend' && buf.length >= 3) {
    msg.bend = (buf[2] << 7) | buf[1];
  }
  return msg;
}

// Extract nibbles from MIDI data for opcode routing
function extractNibbles(msg) {
  const note = msg.note ?? 0;
  const vel = msg.velocity ?? 0;
  return {
    op: (note >> 4) & 0x0F,        // high nibble of note = operation
    space: note & 0x0F,             // low nibble of note = space selector
    route: (vel >> 4) & 0x0F,       // high nibble of velocity = route
    morph: vel & 0x0F               // low nibble of velocity = morph transform
  };
}

// Map MIDI note to 8-octave vector position using φ-spiral
function midiToVector(msg) {
  const note = msg.note ?? 60;
  const vel = msg.velocity ?? 64;
  const octave = Math.min(7, Math.floor(note / 16));
  const normalizedNote = (note % 16) / 16;
  const normalizedVel = vel / 127;
  const spiralAngle = normalizedNote * 2 * Math.PI;
  const [sx, sy] = goldenSpiralPoint(spiralAngle, normalizedVel);
  return {
    pos: { v: [sx, sy, normalizedVel], octave },
    dir: { v: [Math.cos(GOLDEN_ANGLE_RAD * note), Math.sin(GOLDEN_ANGLE_RAD * note), 0], octave },
    energy: normalizedVel
  };
}

// Phi metadata for event
function phiMeta(msg) {
  const note = msg.note ?? 60;
  const octave = Math.min(7, Math.floor(note / 16));
  return {
    scale: phiScale(octave),
    level: octave,
    octave,
    spiral_angle: GOLDEN_ANGLE_RAD * note
  };
}

// Build full Heady event envelope from raw MIDI
function buildEvent(buf, rinfo) {
  const msg = parseMidi(buf);
  if (!msg) return null;
  return {
    schema: 'iglu:com.heady/midi_event/jsonschema/1-0-0',
    data: {
      id: randomUUID(),
      t: Date.now() / 1000,
      src: `midi://udp/${rinfo.address}:${rinfo.port}`,
      transport: `udp://${rinfo.address}:${rinfo.port}`,
      msg,
      nibbles: extractNibbles(msg),
      vectors: midiToVector(msg),
      phi: phiMeta(msg),
      geometry: { form: 'flower_of_life', rotation: 0, depth: 0 },
      logic: { truth: [1], continuity: 1.0, coherence: 1.0 }
    }
  };
}

// Create and start the UDP MIDI listener
function createMidiListener(port = DEFAULT_PORT, onEvent) {
  const server = dgram.createSocket({ type: 'udp4', reuseAddr: true });

  server.on('message', (buf, rinfo) => {
    const event = buildEvent(buf, rinfo);
    if (event && onEvent) onEvent(event);
  });

  server.on('listening', () => {
    const addr = server.address();
    console.log(`[MIDI-UDP] Listening on ${addr.address}:${addr.port}`);
  });

  server.on('error', (err) => {
    console.error(`[MIDI-UDP] Error: ${err.message}`);
    server.close();
  });

  server.bind(port);
  return server;
}

export { createMidiListener, buildEvent, parseMidi, extractNibbles, midiToVector, phiMeta };
