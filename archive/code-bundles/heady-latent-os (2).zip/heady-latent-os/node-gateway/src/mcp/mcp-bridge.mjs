// mcp-bridge.mjs — Forwards enriched MIDI events to Python MCP servers
// Supports dynamic tool discovery, φ-balanced routing, and liquid app registration
import { PHI, phiBalance, phiAllocate } from '../phi/phi-math.mjs';

const COLAB_ENDPOINTS = {
  A: { name: 'audio_temporal', url: process.env.COLAB_A_URL || 'http://localhost:8001/mcp/' },
  B: { name: 'visual_spatial', url: process.env.COLAB_B_URL || 'http://localhost:8002/mcp/' },
  C: { name: 'orchestration',  url: process.env.COLAB_C_URL || 'http://localhost:8003/mcp/' }
};

class MCPBridge {
  constructor() {
    this.toolCatalog = new Map();
    this.serverHealth = new Map();
    this.routeWeights = { A: 1, B: 1, C: 1 };
    this.eventCount = 0;
  }

  // Discover tools from all Colab MCP servers
  async discoverTools() {
    for (const [key, endpoint] of Object.entries(COLAB_ENDPOINTS)) {
      try {
        const res = await fetch(endpoint.url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ jsonrpc: '2.0', id: `discover-${key}`, method: 'tools/list', params: {} })
        });
        const data = await res.json();
        if (data.result?.tools) {
          for (const tool of data.result.tools) {
            this.toolCatalog.set(tool.name, { ...tool, server: key, endpoint: endpoint.url });
          }
          this.serverHealth.set(key, { alive: true, lastSeen: Date.now(), toolCount: data.result.tools.length });
        }
      } catch (err) {
        console.error(`[MCP] Discovery failed for Colab ${key}: ${err.message}`);
        this.serverHealth.set(key, { alive: false, lastSeen: Date.now(), toolCount: 0 });
      }
    }
    console.log(`[MCP] Discovered ${this.toolCatalog.size} tools across ${Object.keys(COLAB_ENDPOINTS).length} servers`);
  }

  // Route event to appropriate Colab based on nibble.route and φ-balanced load
  selectServer(event) {
    const routeNibble = event.data?.nibbles?.route ?? 0;

    // Direct routing for known nibble values
    if (routeNibble >= 1 && routeNibble <= 3) {
      return ['A', 'B', 'C'][routeNibble - 1];
    }

    // φ-balanced routing: use space nibble to hint domain, then load-balance
    const spaceNibble = event.data?.nibbles?.space ?? 0;
    const spaceToColab = { 1: 'A', 5: 'A', 2: 'B', 6: 'B', 12: 'B', 14: 'B',
                            3: 'C', 4: 'C', 7: 'C', 8: 'C', 9: 'C', 10: 'C', 11: 'C', 13: 'C', 15: 'C' };

    if (spaceToColab[spaceNibble]) return spaceToColab[spaceNibble];

    // Fallback: φ-weighted round-robin
    const weights = Object.values(this.routeWeights);
    const alloc = phiAllocate(weights);
    const r = Math.random();
    let cum = 0;
    const keys = Object.keys(this.routeWeights);
    for (let i = 0; i < keys.length; i++) {
      cum += alloc[i];
      if (r <= cum) return keys[i];
    }
    return 'C';
  }

  // Call an MCP tool on the appropriate server
  async callTool(toolName, args) {
    const tool = this.toolCatalog.get(toolName);
    if (!tool) throw new Error(`Tool not found: ${toolName}`);

    const res = await fetch(tool.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: '2.0',
        id: `call-${Date.now()}`,
        method: 'tools/call',
        params: { name: toolName, arguments: args }
      })
    });
    return res.json();
  }

  // Forward a MIDI event to the logic server
  async forwardEvent(event) {
    const server = this.selectServer(event);
    const endpoint = COLAB_ENDPOINTS[server];
    this.eventCount++;

    // Update φ-balanced weights based on health
    const health = this.serverHealth.get(server);
    if (health?.alive) {
      this.routeWeights[server] = phiBalance(this.routeWeights[server], 1.0);
    } else {
      this.routeWeights[server] = phiBalance(this.routeWeights[server], 0.1);
    }

    try {
      const res = await fetch(endpoint.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          jsonrpc: '2.0',
          id: event.data.id,
          method: 'tools/call',
          params: { name: 'logic_ingest_midi_event', arguments: { event: event.data } }
        })
      });
      return res.json();
    } catch (err) {
      console.error(`[MCP] Forward to Colab ${server} failed: ${err.message}`);
      this.serverHealth.set(server, { alive: false, lastSeen: Date.now() });
      return null;
    }
  }

  // Request a liquid UI layout from the visual server
  async requestLayout(context) {
    return this.callTool('ui_layout_for_context', { context });
  }

  // Get agent states from orchestration server
  async getAgentStates() {
    return this.callTool('get_agent_states', {});
  }

  getStatus() {
    return {
      tools: this.toolCatalog.size,
      servers: Object.fromEntries(this.serverHealth),
      weights: this.routeWeights,
      eventsProcessed: this.eventCount
    };
  }
}

export { MCPBridge, COLAB_ENDPOINTS };
