// index.mjs — Heady Latent OS Gateway
// MIDI→UDP listener + MCP bridge + liquid UI API
import express from 'express';
import { createMidiListener } from './midi/midi-udp-listener.mjs';
import { MCPBridge } from './mcp/mcp-bridge.mjs';
import { PHI, phiScale, fibSequence } from './phi/phi-math.mjs';

const MIDI_PORT = parseInt(process.env.MIDI_UDP_PORT || '9000');
const HTTP_PORT = parseInt(process.env.HTTP_PORT || '3000');

const bridge = new MCPBridge();
const app = express();
app.use(express.json());

// --- Startup ---
async function boot() {
  console.log('\n🌀 Heady Latent OS Gateway — Sacred Genesis v4.0');
  console.log(`   φ = ${PHI}`);
  console.log(`   Octave scales: ${Array.from({length:8}, (_,i) => phiScale(i).toFixed(3)).join(', ')}`);
  console.log(`   Fibonacci seed: ${fibSequence(13).join(', ')}\n`);

  // Discover MCP tools from Colab runtimes
  await bridge.discoverTools();

  // Start MIDI UDP listener
  createMidiListener(MIDI_PORT, async (event) => {
    console.log(`[EVENT] ${event.data.msg.type} ch:${event.data.msg.channel} nibbles:${JSON.stringify(event.data.nibbles)}`);
    const result = await bridge.forwardEvent(event);
    if (result?.result) {
      console.log(`[MCP] Response: ${JSON.stringify(result.result).slice(0, 120)}`);
    }
  });

  // --- HTTP API for liquid UI and status ---
  app.get('/status', (req, res) => res.json(bridge.getStatus()));

  app.get('/phi', (req, res) => res.json({
    phi: PHI, phi_inv: 1/PHI, phi_sq: PHI*PHI,
    golden_angle_deg: 137.5078,
    fibonacci: fibSequence(21),
    octave_scales: Array.from({length:8}, (_,i) => ({ octave: i, scale: phiScale(i) }))
  }));

  app.get('/nibbles', async (req, res) => {
    try {
      const result = await bridge.callTool('get_nibble_registry', {});
      res.json(result);
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.post('/nibbles', async (req, res) => {
    try {
      const result = await bridge.callTool('update_nibble_registry', req.body);
      res.json(result);
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.get('/layout', async (req, res) => {
    try {
      const result = await bridge.requestLayout(req.query);
      res.json(result);
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.get('/agents', async (req, res) => {
    try {
      const result = await bridge.getAgentStates();
      res.json(result);
    } catch (e) { res.status(500).json({ error: e.message }); }
  });

  app.get('/tools', (req, res) => {
    const tools = [...bridge.toolCatalog.values()].map(t => ({ name: t.name, server: t.server, description: t.description }));
    res.json({ count: tools.length, tools });
  });

  // Rediscovery endpoint (liquid architecture: tools can appear/disappear)
  app.post('/discover', async (req, res) => {
    await bridge.discoverTools();
    res.json(bridge.getStatus());
  });

  app.listen(HTTP_PORT, () => {
    console.log(`[HTTP] Gateway API on :${HTTP_PORT}`);
    console.log(`[MIDI] UDP listener on :${MIDI_PORT}`);
    console.log('\n🔷 Heady Latent OS is alive.\n');
  });
}

boot().catch(console.error);
