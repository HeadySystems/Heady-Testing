"""geometry.py — Sacred geometry primitives for Heady Latent OS.
Provides coordinate generators, intersection math, and transformation
functions for all major sacred geometry forms used in agent orchestration."""

import math
from dataclasses import dataclass, field
from typing import List, Tuple, Optional
from phi_orchestrator.phi_math import (
    PHI, PHI_INV, SQRT3, SQRT5, GOLDEN_ANGLE_RAD,
    seed_of_life_positions, flower_of_life_positions,
    pentagram_vertices, metatrons_cube_vertices, sri_yantra_triangles,
    torus_point, vesica_height, vesica_area
)


@dataclass
class GeometryForm:
    name: str
    vertices: List[Tuple[float, ...]] = field(default_factory=list)
    edges: List[Tuple[int, int]] = field(default_factory=list)
    faces: List[List[int]] = field(default_factory=list)
    center: Tuple[float, ...] = (0.0, 0.0, 0.0)
    radius: float = 1.0
    phi_ratio: float = PHI


def build_vesica_piscis(radius: float = 1.0) -> GeometryForm:
    """Two overlapping circles, centers on each other's perimeter.
    Height:width ratio = √3 ≈ 1.732."""
    h = vesica_height(radius)
    verts = [(-radius / 2, 0), (radius / 2, 0), (0, h / 2), (0, -h / 2)]
    return GeometryForm(name='vesica_piscis', vertices=verts, radius=radius)


def build_seed_of_life(radius: float = 1.0) -> GeometryForm:
    positions = seed_of_life_positions(radius)
    verts = [(x, y, 0.0) for x, y in positions]
    edges = [(0, i) for i in range(1, 7)]
    edges += [(i, (i % 6) + 1) for i in range(1, 7)]
    return GeometryForm(name='seed_of_life', vertices=verts, edges=edges, radius=radius)


def build_flower_of_life(radius: float = 1.0) -> GeometryForm:
    positions = flower_of_life_positions(radius)
    verts = [(x, y, 0.0) for x, y in positions]
    return GeometryForm(name='flower_of_life', vertices=verts, radius=radius)


def build_pentagram(radius: float = 1.0) -> GeometryForm:
    pv = pentagram_vertices(radius)
    verts = [(x, y, 0.0) for x, y in pv]
    edges = [(i, (i + 2) % 5) for i in range(5)]
    return GeometryForm(name='pentagram', vertices=verts, edges=edges, radius=radius)


def build_metatrons_cube(radius: float = 1.0) -> GeometryForm:
    mv = metatrons_cube_vertices(radius)
    verts = [(x, y, 0.0) for x, y in mv]
    edges = [(i, j) for i in range(13) for j in range(i + 1, 13)]
    return GeometryForm(name='metatrons_cube', vertices=verts, edges=edges, radius=radius)


def build_torus(R: float = PHI, r: float = 1.0, n_major: int = 36, n_minor: int = 18) -> GeometryForm:
    verts = []
    for i in range(n_major):
        theta = 2 * math.pi * i / n_major
        for j in range(n_minor):
            phi_a = 2 * math.pi * j / n_minor
            verts.append(torus_point(theta, phi_a, R, r))
    edges = []
    for i in range(n_major):
        for j in range(n_minor):
            idx = i * n_minor + j
            edges.append((idx, i * n_minor + (j + 1) % n_minor))
            edges.append((idx, ((i + 1) % n_major) * n_minor + j))
    return GeometryForm(name='torus', vertices=verts, edges=edges, radius=R)


def build_icosahedron(radius: float = 1.0) -> GeometryForm:
    t = PHI * radius / math.sqrt(1 + PHI**2)
    s = radius / math.sqrt(1 + PHI**2)
    verts = [
        (-s, t, 0), (s, t, 0), (-s, -t, 0), (s, -t, 0),
        (0, -s, t), (0, s, t), (0, -s, -t), (0, s, -t),
        (t, 0, -s), (t, 0, s), (-t, 0, -s), (-t, 0, s)
    ]
    faces = [
        [0,11,5],[0,5,1],[0,1,7],[0,7,10],[0,10,11],
        [1,5,9],[5,11,4],[11,10,2],[10,7,6],[7,1,8],
        [3,9,4],[3,4,2],[3,2,6],[3,6,8],[3,8,9],
        [4,9,5],[2,4,11],[6,2,10],[8,6,7],[9,8,1]
    ]
    return GeometryForm(name='icosahedron', vertices=verts, faces=faces, radius=radius, phi_ratio=PHI)


def build_dodecahedron(radius: float = 1.0) -> GeometryForm:
    """Dual of icosahedron. Vertices at face centroids of icosahedron."""
    ico = build_icosahedron(radius)
    verts = []
    for face in ico.faces:
        cx = sum(ico.vertices[i][0] for i in face) / 3
        cy = sum(ico.vertices[i][1] for i in face) / 3
        cz = sum(ico.vertices[i][2] for i in face) / 3
        norm = math.sqrt(cx**2 + cy**2 + cz**2)
        scale = radius / norm if norm > 0 else 1
        verts.append((cx * scale, cy * scale, cz * scale))
    return GeometryForm(name='dodecahedron', vertices=verts, radius=radius, phi_ratio=PHI)


def build_merkaba(radius: float = 1.0) -> GeometryForm:
    """Star tetrahedron: two interlocking tetrahedra."""
    h = radius * math.sqrt(2/3)
    r = radius * math.sqrt(2/3) * math.sqrt(3) / 3 * 2
    up = [
        (0, h, 0),
        (r, -h/3, 0),
        (-r/2, -h/3, r * SQRT3 / 2),
        (-r/2, -h/3, -r * SQRT3 / 2)
    ]
    down = [(x, -y, z) for x, y, z in up]
    return GeometryForm(name='merkaba', vertices=up + down, radius=radius)


GEOMETRY_BUILDERS = {
    'vesica_piscis': build_vesica_piscis,
    'seed_of_life': build_seed_of_life,
    'flower_of_life': build_flower_of_life,
    'pentagram': build_pentagram,
    'metatrons_cube': build_metatrons_cube,
    'torus': build_torus,
    'icosahedron': build_icosahedron,
    'dodecahedron': build_dodecahedron,
    'merkaba': build_merkaba,
}


def build_form(name: str, radius: float = 1.0, **kwargs) -> GeometryForm:
    builder = GEOMETRY_BUILDERS.get(name)
    if not builder:
        raise ValueError(f"Unknown geometry form: {name}. Available: {list(GEOMETRY_BUILDERS.keys())}")
    return builder(radius=radius, **kwargs)


def golden_angle_distribute(n: int, radius: float = 1.0) -> List[Tuple[float, float]]:
    """Distribute N points using the golden angle for optimal packing (sunflower pattern)."""
    points = []
    for i in range(n):
        r = radius * math.sqrt(i / n)
        theta = GOLDEN_ANGLE_RAD * i
        points.append((r * math.cos(theta), r * math.sin(theta)))
    return points


def pentagonal_ring_layout(n_agents: int, ring_radius: float = PHI) -> List[dict]:
    """Arrange agents in pentagonal rings, each ring at φ * previous radius."""
    agents_per_ring = 5
    rings = []
    remaining = n_agents
    ring_idx = 0
    r = ring_radius

    while remaining > 0:
        count = min(remaining, agents_per_ring)
        for i in range(count):
            angle = (2 * math.pi * i / agents_per_ring) + (ring_idx * math.pi / 5)
            rings.append({
                'ring': ring_idx,
                'index': i,
                'x': r * math.cos(angle),
                'y': r * math.sin(angle),
                'radius': r,
                'angle': angle
            })
        remaining -= count
        ring_idx += 1
        r *= PHI
        agents_per_ring = int(agents_per_ring * PHI)

    return rings
