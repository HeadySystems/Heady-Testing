"""scheduler.py — φ-based agent scheduler for Heady Latent OS.
Implements sacred geometry topology for agent graphs and
golden-ratio-proportional resource allocation.

This replaces the Auto-Success Engine stub with a living, 
φ-scaled heartbeat system."""

import time
import math
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from phi_orchestrator.phi_math import (
    PHI, PHI_INV, PHI_SQ, phi_balance, phi_ema,
    phi_allocate, phi_scale, fib_sequence, GOLDEN_ANGLE_RAD
)
from sacred_geometry.geometry import pentagonal_ring_layout, golden_angle_distribute


@dataclass
class AgentState:
    id: str
    name: str
    archetype: str = 'worker'
    ring: int = 0
    octave: int = 0
    p_short: float = 0.5
    q_long: float = 0.5
    phi_weight: float = 0.5
    geometry_role: str = 'spoke'
    torus_theta: float = 0.0
    torus_phi: float = 0.0
    alive: bool = True
    spawned_by: Optional[str] = None
    fibonacci_generation: int = 0
    task_count: int = 0
    error_count: int = 0
    last_reward: float = 0.0
    created_at: float = field(default_factory=time.time)


class PhiScheduler:
    """Sacred geometry agent orchestrator with φ-proportional scheduling.

    Core scheduling rule:
      A_i(t+1) = λ·p_i(t+1) + (1-λ)·q_i(t+1)
      where λ = 1/φ ≈ 0.618 (short-term:long-term = φ:1)

      p_i(t+1) = (1-α)·p_i(t) + α·r_i(t)  with α = 1/φ
      q_i(t+1) = (1-β)·q_i(t) + β·r_i(t)   with β = 1/φ²

    Agent topology:
      Pentagonal rings (sacred geometry), each ring at φ× previous radius.
      Hub agents at center, spoke agents on rings, bridge agents between rings,
      sentinel agents on outer ring, spiral_walker agents traverse the spiral.
    """

    ALPHA = PHI_INV          # short-term EMA rate ≈ 0.618
    BETA = 1 / PHI_SQ       # long-term EMA rate ≈ 0.382
    LAMBDA = PHI_INV         # balance weight (short:long = φ:1)

    # Agent count targets (Fibonacci numbers for organic growth)
    FIB_TARGETS = fib_sequence(12)  # [0,1,1,2,3,5,8,13,21,34,55,89]

    def __init__(self):
        self.agents: Dict[str, AgentState] = {}
        self.tick: int = 0
        self.heartbeat_interval: float = PHI  # seconds between heartbeats
        self.global_energy: float = 1.0
        self.torus_theta_cursor: float = 0.0

    def register_agent(self, agent_id: str, name: str, archetype: str = 'worker',
                       spawned_by: Optional[str] = None) -> AgentState:
        parent_gen = self.agents[spawned_by].fibonacci_generation if spawned_by and spawned_by in self.agents else -1
        agent = AgentState(
            id=agent_id, name=name, archetype=archetype,
            spawned_by=spawned_by,
            fibonacci_generation=parent_gen + 1
        )
        self.agents[agent_id] = agent
        self._recompute_topology()
        return agent

    def remove_agent(self, agent_id: str):
        if agent_id in self.agents:
            self.agents[agent_id].alive = False
            del self.agents[agent_id]
            self._recompute_topology()

    def record_reward(self, agent_id: str, reward: float):
        agent = self.agents.get(agent_id)
        if not agent:
            return
        agent.last_reward = reward
        agent.task_count += 1
        agent.p_short = (1 - self.ALPHA) * agent.p_short + self.ALPHA * reward
        agent.q_long = (1 - self.BETA) * agent.q_long + self.BETA * reward
        agent.phi_weight = self.LAMBDA * agent.p_short + (1 - self.LAMBDA) * agent.q_long

    def record_error(self, agent_id: str):
        agent = self.agents.get(agent_id)
        if agent:
            agent.error_count += 1
            self.record_reward(agent_id, 0.0)

    def heartbeat(self) -> Dict:
        """φ-scaled heartbeat: advance torus cursor by golden angle,
        recompute weights, emit allocation."""
        self.tick += 1
        self.torus_theta_cursor += GOLDEN_ANGLE_RAD
        if self.torus_theta_cursor > 2 * math.pi:
            self.torus_theta_cursor -= 2 * math.pi

        # Update all agent torus positions (toroidal flow)
        for agent in self.agents.values():
            agent.torus_theta += GOLDEN_ANGLE_RAD / phi_scale(agent.ring)
            agent.torus_phi += GOLDEN_ANGLE_RAD / phi_scale(agent.octave)

        # Global energy: φ-balanced average of all agent weights
        weights = [a.phi_weight for a in self.agents.values()]
        if weights:
            self.global_energy = sum(weights) / len(weights)

        allocation = self.allocate()
        return {
            'tick': self.tick,
            'torus_cursor': self.torus_theta_cursor,
            'global_energy': self.global_energy,
            'agent_count': len(self.agents),
            'allocation': allocation
        }

    def allocate(self) -> Dict[str, float]:
        """φ-proportional resource allocation across all agents."""
        if not self.agents:
            return {}
        weights = [max(a.phi_weight, 0.01) for a in self.agents.values()]
        alloc = phi_allocate(weights)
        return {agent.id: share for agent, share in zip(self.agents.values(), alloc)}

    def select_agent(self, task_type: str = 'general') -> Optional[str]:
        """Select best agent for a task using φ-weighted probability."""
        alive = [a for a in self.agents.values() if a.alive]
        if not alive:
            return None
        weights = [max(a.phi_weight, 0.01) for a in alive]
        total = sum(weights)
        import random
        r = random.random() * total
        cumulative = 0
        for agent, w in zip(alive, weights):
            cumulative += w
            if r <= cumulative:
                return agent.id
        return alive[-1].id

    def should_spawn(self) -> bool:
        """Fibonacci-guided organic growth: spawn when count is below next fib target."""
        count = len(self.agents)
        for target in self.FIB_TARGETS:
            if count < target and self.global_energy > PHI_INV:
                return True
        return False

    def should_prune(self) -> Optional[str]:
        """Prune weakest agent if population exceeds Fibonacci ceiling and energy is low."""
        count = len(self.agents)
        if count == 0:
            return None
        # Find Fibonacci ceiling
        ceiling = 1
        for t in self.FIB_TARGETS:
            if t >= count:
                ceiling = t
                break
        if count > ceiling and self.global_energy < PHI_INV:
            weakest = min(self.agents.values(), key=lambda a: a.phi_weight)
            return weakest.id
        return None

    def _recompute_topology(self):
        """Reposition agents in pentagonal ring sacred geometry layout."""
        n = len(self.agents)
        if n == 0:
            return
        layout = pentagonal_ring_layout(n)
        for agent, pos in zip(self.agents.values(), layout):
            agent.ring = pos['ring']
            if pos['ring'] == 0:
                agent.geometry_role = 'hub'
            elif pos['ring'] == max(p['ring'] for p in layout):
                agent.geometry_role = 'sentinel'
            else:
                agent.geometry_role = 'spoke'

    def get_states(self) -> List[Dict]:
        return [
            {
                'id': a.id, 'name': a.name, 'archetype': a.archetype,
                'ring': a.ring, 'octave': a.octave,
                'p_short': round(a.p_short, 4), 'q_long': round(a.q_long, 4),
                'phi_weight': round(a.phi_weight, 4),
                'geometry_role': a.geometry_role,
                'torus': {'theta': a.torus_theta, 'phi': a.torus_phi},
                'alive': a.alive, 'spawned_by': a.spawned_by,
                'fibonacci_generation': a.fibonacci_generation,
                'tasks': a.task_count, 'errors': a.error_count
            }
            for a in self.agents.values()
        ]

    def evolution_step(self) -> Dict:
        """EvolutionEngine step: mutate agent weights, potentially spawn/prune.
        This fills the EvolutionEngine stub."""
        result = {'spawned': [], 'pruned': [], 'evolved': []}

        # Spawn if Fibonacci growth says we should
        if self.should_spawn():
            best = max(self.agents.values(), key=lambda a: a.phi_weight) if self.agents else None
            if best:
                new_id = f"agent-{len(self.agents)}-gen{best.fibonacci_generation + 1}"
                self.register_agent(new_id, f"child-of-{best.name}", best.archetype, spawned_by=best.id)
                result['spawned'].append(new_id)

        # Prune if needed
        prune_id = self.should_prune()
        if prune_id:
            self.remove_agent(prune_id)
            result['pruned'].append(prune_id)

        # Evolve: apply small golden-angle rotation to all weights
        for agent in self.agents.values():
            noise = math.sin(GOLDEN_ANGLE_RAD * agent.task_count) * 0.01
            agent.phi_weight = max(0.01, agent.phi_weight + noise)
            result['evolved'].append(agent.id)

        return result
