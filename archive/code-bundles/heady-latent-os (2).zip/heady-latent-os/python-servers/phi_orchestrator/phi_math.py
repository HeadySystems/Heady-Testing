"""phi_math.py — Golden ratio mathematics for Heady Latent OS.
All constants derived from φ = (1+√5)/2. Zero magic numbers.
Compatible with phi-math.js (913 lines) from Sacred Genesis v4.0."""

import math
from typing import List, Tuple, Generator

PHI: float = (1 + math.sqrt(5)) / 2
PHI_INV: float = 1 / PHI
PHI_SQ: float = PHI ** 2
PHI_CUBE: float = PHI ** 3
GOLDEN_ANGLE_RAD: float = 2 * math.pi * (1 - PHI_INV)
GOLDEN_ANGLE_DEG: float = math.degrees(GOLDEN_ANGLE_RAD)
SQRT3: float = math.sqrt(3)  # vesica piscis height:width
SQRT5: float = math.sqrt(5)  # pentagonal diagonal


def fibonacci_gen() -> Generator[int, None, None]:
    a, b = 0, 1
    while True:
        yield a
        a, b = b, a + b


def fib_sequence(n: int) -> List[int]:
    gen = fibonacci_gen()
    return [next(gen) for _ in range(n)]


def fib_n(n: int) -> int:
    """Closed-form Fibonacci via Binet's formula (exact for n < 70)."""
    return round((PHI**n - (-PHI_INV)**n) / SQRT5)


def phi_scale(octave: int) -> float:
    return PHI ** octave


def scale_to_octave(scale: float) -> int:
    return round(math.log(max(scale, 1e-12)) / math.log(PHI))


def golden_spiral_radius(theta: float, a: float = 1.0) -> float:
    return a * PHI ** (2 * theta / math.pi)


def golden_spiral_point(theta: float, a: float = 1.0) -> Tuple[float, float]:
    r = golden_spiral_radius(theta, a)
    return (r * math.cos(theta), r * math.sin(theta))


def phi_balance(short_term: float, long_term: float) -> float:
    """φ-balanced combination: short:long = φ:1."""
    return PHI_INV * short_term + (1 - PHI_INV) * long_term


def phi_ema(prev: float, current: float, depth: int = 1) -> float:
    alpha = 1 / PHI ** depth
    return (1 - alpha) * prev + alpha * current


def torus_point(theta: float, phi_angle: float,
                R: float = PHI, r: float = 1.0) -> Tuple[float, float, float]:
    x = (R + r * math.cos(phi_angle)) * math.cos(theta)
    y = (R + r * math.cos(phi_angle)) * math.sin(theta)
    z = r * math.sin(phi_angle)
    return (x, y, z)


def vesica_height(radius: float) -> float:
    return radius * SQRT3


def vesica_area(radius: float) -> float:
    return (math.pi / 3 - SQRT3 / 2) * 2 * radius**2


def seed_of_life_positions(radius: float) -> List[Tuple[float, float]]:
    positions = [(0.0, 0.0)]
    for i in range(6):
        angle = (math.pi / 3) * i
        positions.append((radius * math.cos(angle), radius * math.sin(angle)))
    return positions


def flower_of_life_positions(radius: float) -> List[Tuple[float, float]]:
    positions = seed_of_life_positions(radius)
    for i in range(6):
        a1 = (math.pi / 3) * i
        a2 = (math.pi / 3) * ((i + 1) % 6)
        positions.append((radius * (math.cos(a1) + math.cos(a2)),
                          radius * (math.sin(a1) + math.sin(a2))))
    for i in range(6):
        angle = (math.pi / 3) * i
        positions.append((2 * radius * math.cos(angle), 2 * radius * math.sin(angle)))
    return positions


def pentagram_vertices(radius: float, rotation: float = -math.pi / 2) -> List[Tuple[float, float]]:
    return [(radius * math.cos(rotation + 2 * math.pi * i / 5),
             radius * math.sin(rotation + 2 * math.pi * i / 5)) for i in range(5)]


def metatrons_cube_vertices(radius: float) -> List[Tuple[float, float]]:
    """13 vertices: center + inner ring (6) + outer ring (6)."""
    inner = seed_of_life_positions(radius)[1:]
    outer = [(2 * radius * math.cos((math.pi / 3) * i + math.pi / 6),
              2 * radius * math.sin((math.pi / 3) * i + math.pi / 6)) for i in range(6)]
    return [(0.0, 0.0)] + inner + outer


def sri_yantra_triangles(radius: float) -> dict:
    """Returns upward (4) and downward (5) triangle vertices for Sri Yantra."""
    levels_up = [radius * PHI_INV**i for i in range(4)]
    levels_down = [radius * PHI_INV**i for i in range(5)]
    up = [[(r * math.cos(a), r * math.sin(a))
           for a in [-math.pi/2, math.pi/6, 5*math.pi/6]] for r in levels_up]
    down = [[(r * math.cos(a), r * math.sin(a))
             for a in [math.pi/2, -math.pi/6, -5*math.pi/6]] for r in levels_down]
    return {'upward': up, 'downward': down}


def phi_allocate(weights: List[float]) -> List[float]:
    total = sum(weights)
    if total == 0:
        return [1.0 / len(weights)] * len(weights)
    return [w / total for w in weights]


def phi_quantize(value: float, octave: int, levels: int = 8) -> float:
    scale = phi_scale(octave)
    step = scale / levels
    return round(value / step) * step


def phi_decay_schedule(steps: int) -> List[float]:
    """Generate a φ-decay learning rate schedule."""
    return [1.0 / PHI**i for i in range(steps)]


def toroidal_distance(theta1: float, phi1: float, theta2: float, phi2: float,
                       R: float = PHI, r: float = 1.0) -> float:
    """Approximate geodesic distance on torus surface."""
    dtheta = theta1 - theta2
    dphi = phi1 - phi2
    return math.sqrt((R * dtheta)**2 + (r * dphi)**2)
