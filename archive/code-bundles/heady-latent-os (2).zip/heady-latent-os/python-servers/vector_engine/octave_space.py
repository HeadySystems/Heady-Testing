"""octave_space.py — Eight-octave φ-scaled vector space engine.
Each octave scales by φ^n. No fixed constants."""

import math
import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List, Tuple
from phi_orchestrator.phi_math import PHI, PHI_INV, phi_scale, scale_to_octave, GOLDEN_ANGLE_RAD


OCTAVE_NAMES = [
    'quantum', 'signal', 'pattern', 'semantic',
    'agent', 'orchestral', 'world', 'meta'
]
OCTAVE_DIMS = [3, 3, 8, 16, 32, 64, 128, 256]


@dataclass
class OctaveVector:
    v: np.ndarray
    octave: int = 0

    @property
    def scale(self) -> float:
        return phi_scale(self.octave)

    @property
    def world_v(self) -> np.ndarray:
        return self.v * self.scale

    def shift_octave(self, delta: int) -> 'OctaveVector':
        new_oct = max(0, min(7, self.octave + delta))
        ratio = phi_scale(new_oct) / self.scale
        return OctaveVector(v=self.v * ratio, octave=new_oct)

    def spiral_transform(self, angle: float = GOLDEN_ANGLE_RAD) -> 'OctaveVector':
        if len(self.v) < 2:
            return self
        cos_a, sin_a = math.cos(angle), math.sin(angle)
        new_v = self.v.copy()
        new_v[0] = self.v[0] * cos_a - self.v[1] * sin_a
        new_v[1] = self.v[0] * sin_a + self.v[1] * cos_a
        return OctaveVector(v=new_v, octave=self.octave)

    def phi_scale_up(self) -> 'OctaveVector':
        return OctaveVector(v=self.v * PHI, octave=min(7, self.octave + 1))

    def phi_scale_down(self) -> 'OctaveVector':
        return OctaveVector(v=self.v * PHI_INV, octave=max(0, self.octave - 1))

    def reflect(self) -> 'OctaveVector':
        return OctaveVector(v=-self.v, octave=self.octave)

    def energy(self) -> float:
        return float(np.linalg.norm(self.v))

    def normalize(self) -> 'OctaveVector':
        norm = np.linalg.norm(self.v)
        if norm == 0:
            return self
        return OctaveVector(v=self.v / norm, octave=self.octave)

    def to_dict(self) -> dict:
        return {'v': self.v.tolist(), 'octave': self.octave, 'scale': self.scale}

    @classmethod
    def from_dict(cls, d: dict) -> 'OctaveVector':
        return cls(v=np.array(d['v']), octave=d.get('octave', 0))


class OctaveSpace:
    """Manages the full eight-octave vector space."""

    def __init__(self):
        self.fields: dict[str, dict[str, OctaveVector]] = {}

    def put(self, entity_id: str, field_name: str, vec: OctaveVector):
        if entity_id not in self.fields:
            self.fields[entity_id] = {}
        self.fields[entity_id][field_name] = vec

    def get(self, entity_id: str, field_name: str) -> Optional[OctaveVector]:
        return self.fields.get(entity_id, {}).get(field_name)

    def get_all_at_octave(self, octave: int) -> List[Tuple[str, str, OctaveVector]]:
        results = []
        for eid, fields in self.fields.items():
            for fname, vec in fields.items():
                if vec.octave == octave:
                    results.append((eid, fname, vec))
        return results

    def phi_distance(self, a: OctaveVector, b: OctaveVector) -> float:
        """Distance that accounts for octave difference via φ-scaling."""
        a_world = a.world_v
        b_world = b.world_v
        min_dim = min(len(a_world), len(b_world))
        return float(np.linalg.norm(a_world[:min_dim] - b_world[:min_dim]))

    def nearest_neighbors(self, target: OctaveVector, k: int = 5,
                           octave_range: Optional[Tuple[int, int]] = None) -> List[Tuple[str, str, float]]:
        results = []
        for eid, fields in self.fields.items():
            for fname, vec in fields.items():
                if octave_range and not (octave_range[0] <= vec.octave <= octave_range[1]):
                    continue
                dist = self.phi_distance(target, vec)
                results.append((eid, fname, dist))
        results.sort(key=lambda x: x[2])
        return results[:k]

    def snapshot(self) -> dict:
        snap = {}
        for eid, fields in self.fields.items():
            snap[eid] = {fname: vec.to_dict() for fname, vec in fields.items()}
        return snap
