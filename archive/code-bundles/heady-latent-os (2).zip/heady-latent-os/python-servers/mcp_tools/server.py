"""server.py — Heady Latent OS MCP Server (Python/FastMCP).
Exposes all OS tools over Streamable HTTP transport.
Run per Colab runtime: A (audio), B (visual), C (orchestration).

This is the core MCP server that fills in:
  - Auto-Success Engine (via heartbeat tool)
  - EvolutionEngine (via evolution_step tool)
  - PersonaRouter (via persona_switch tool)
  - WisdomStore (via wisdom_store/recall tools)
  - BudgetTracker (via budget tools)
  - HeadyLens (via lens_observe tool)
  - Council Mode (via council_invoke tool)
  - Nibble Registry (get/update tools)
  - Liquid UI layout generation
  - Agent state management
  - Vector space operations
"""

import json
import os
import sys
import time
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from fastmcp import FastMCP
from phi_orchestrator.phi_math import PHI, PHI_INV, phi_scale, fib_sequence, phi_balance
from phi_orchestrator.scheduler import PhiScheduler
from vector_engine.octave_space import OctaveSpace, OctaveVector
import numpy as np

RUNTIME_ID = os.environ.get('HEADY_RUNTIME', 'C')
PORT = int(os.environ.get('HEADY_MCP_PORT', '8003'))

mcp = FastMCP(
    name=f"HeadyLatentOS-{RUNTIME_ID}",
    stateless_http=True,
    json_response=True
)

# --- State singletons ---
scheduler = PhiScheduler()
octave_space = OctaveSpace()

# Default nibble registry (loaded from schema file or memory)
_nibble_registry_path = Path(__file__).resolve().parent.parent.parent / 'schemas' / 'iglu' / 'nibble_registry_default.json'
if _nibble_registry_path.exists():
    _nibble_registry = json.loads(_nibble_registry_path.read_text())
else:
    _nibble_registry = {'data': {'op': {}, 'space': {}, 'route': {}, 'morph': {}}}

# Wisdom store (in-memory, would be persisted to vector DB in production)
_wisdom_store: list = []

# Persona state
_active_persona: dict = {'name': 'HeadyBuddy', 'archetype': 'companion', 'voice': 'warm'}

# Budget tracker
_budget: dict = {'total': 1.0, 'spent': 0.0, 'allocations': {}}

# ============================
# TOOLS: Nibble Registry
# ============================

@mcp.tool()
def get_nibble_registry() -> dict:
    """Get the current live nibble registry with all opcode definitions."""
    return _nibble_registry

@mcp.tool()
def update_nibble_registry(category: str, key: str, value: dict) -> dict:
    """Update a single entry in the nibble registry. Category: op|space|route|morph."""
    if category not in _nibble_registry['data']:
        return {'error': f'Invalid category: {category}'}
    _nibble_registry['data'][category][str(key)] = value
    return {'status': 'updated', 'category': category, 'key': key}

# ============================
# TOOLS: MIDI Event Ingestion
# ============================

@mcp.tool()
def logic_ingest_midi_event(event: dict) -> dict:
    """Ingest a MIDI event, apply nibble-driven logic, update vector space."""
    nibbles = event.get('nibbles', {})
    vectors = event.get('vectors', {})
    phi_meta = event.get('phi', {})

    # Store vector in octave space
    if vectors.get('pos'):
        pos = vectors['pos']
        ov = OctaveVector(v=np.array(pos.get('v', [0, 0, 0])), octave=pos.get('octave', 0))
        octave_space.put(event.get('id', 'unknown'), 'pos', ov)

    # Apply nibble opcode
    op = nibbles.get('op', 0)
    op_def = _nibble_registry['data']['op'].get(str(op), {})
    phi_action = op_def.get('phi_action', 'none')

    result = {
        'status': 'ingested',
        'event_id': event.get('id'),
        'op_applied': op_def.get('name', 'unknown'),
        'phi_action': phi_action,
        'octave': phi_meta.get('octave', 0),
        'vector_stored': bool(vectors.get('pos'))
    }

    # Trigger side effects based on opcode
    if op == 7:  # spawn
        result['spawn_hint'] = True
    elif op == 11:  # evolve
        result['evolution'] = scheduler.evolution_step()
    elif op == 12:  # persona_switch
        result['persona'] = _active_persona
    elif op == 13:  # wisdom_store
        _wisdom_store.append({'event_id': event.get('id'), 't': time.time(), 'data': event})
        result['wisdom_stored'] = True
    elif op == 14:  # council_invoke
        result['council'] = 'Council Mode invoked — multi-agent deliberation pending'
    elif op == 15:  # auto_success heartbeat
        result['heartbeat'] = scheduler.heartbeat()

    return result

# ============================
# TOOLS: Agent Scheduling
# ============================

@mcp.tool()
def get_agent_states() -> dict:
    """Get all agent states with φ-weights, topology, and torus positions."""
    return {
        'agents': scheduler.get_states(),
        'global_energy': scheduler.global_energy,
        'tick': scheduler.tick,
        'torus_cursor': scheduler.torus_theta_cursor
    }

@mcp.tool()
def register_agent(agent_id: str, name: str, archetype: str = 'worker') -> dict:
    """Register a new agent in the φ-scheduler."""
    agent = scheduler.register_agent(agent_id, name, archetype)
    return {'status': 'registered', 'agent': agent.id, 'ring': agent.ring, 'role': agent.geometry_role}

@mcp.tool()
def agent_reward(agent_id: str, reward: float) -> dict:
    """Record a reward for an agent, updating φ-balanced weights."""
    scheduler.record_reward(agent_id, reward)
    agent = scheduler.agents.get(agent_id)
    if not agent:
        return {'error': 'Agent not found'}
    return {'agent': agent_id, 'p_short': agent.p_short, 'q_long': agent.q_long, 'phi_weight': agent.phi_weight}

@mcp.tool()
def phi_schedule_step() -> dict:
    """Run one φ-heartbeat step: advance torus, recompute weights, return allocation."""
    return scheduler.heartbeat()

@mcp.tool()
def evolution_step() -> dict:
    """Run one EvolutionEngine step: spawn/prune/evolve agents by Fibonacci growth rules."""
    return scheduler.evolution_step()

@mcp.tool()
def select_agent_for_task(task_type: str = 'general') -> dict:
    """Select the best agent for a task using φ-weighted probability."""
    agent_id = scheduler.select_agent(task_type)
    return {'selected': agent_id}

# ============================
# TOOLS: Auto-Success Engine
# ============================

@mcp.tool()
def auto_success_heartbeat() -> dict:
    """The Auto-Success Engine heartbeat — replaces the 100% stub.
    Runs φ-scaled scheduling, checks Fibonacci growth targets,
    evolves the agent population, and returns the full OS pulse."""
    hb = scheduler.heartbeat()
    evo = scheduler.evolution_step()
    return {
        'heartbeat': hb,
        'evolution': evo,
        'phi': PHI,
        'next_heartbeat_in': scheduler.heartbeat_interval,
        'fibonacci_targets': fib_sequence(12)
    }

# ============================
# TOOLS: PersonaRouter
# ============================

@mcp.tool()
def persona_switch(persona_name: str, archetype: str = 'companion', voice: str = 'warm') -> dict:
    """Switch the active persona (fills PersonaRouter stub)."""
    global _active_persona
    _active_persona = {'name': persona_name, 'archetype': archetype, 'voice': voice}
    return {'status': 'switched', 'persona': _active_persona}

@mcp.tool()
def get_persona() -> dict:
    """Get the current active persona."""
    return _active_persona

# ============================
# TOOLS: WisdomStore
# ============================

@mcp.tool()
def wisdom_store_insight(insight: str, tags: list = []) -> dict:
    """Store a wisdom insight (fills WisdomStore stub)."""
    entry = {'insight': insight, 'tags': tags, 't': time.time(), 'phi_weight': PHI_INV}
    _wisdom_store.append(entry)
    return {'stored': True, 'total_wisdom': len(_wisdom_store)}

@mcp.tool()
def wisdom_recall(query: str, limit: int = 5) -> dict:
    """Recall wisdom entries (simple keyword match; upgrade to vector search in production)."""
    results = [w for w in _wisdom_store if query.lower() in str(w).lower()]
    return {'results': results[-limit:], 'total': len(results)}

# ============================
# TOOLS: BudgetTracker
# ============================

@mcp.tool()
def budget_allocate(category: str, amount: float) -> dict:
    """Allocate budget to a category using φ-proportional limits."""
    _budget['allocations'][category] = _budget['allocations'].get(category, 0) + amount
    _budget['spent'] += amount
    remaining = _budget['total'] - _budget['spent']
    return {'category': category, 'allocated': amount, 'spent': _budget['spent'],
            'remaining': remaining, 'phi_ratio': _budget['spent'] / max(_budget['total'], 0.01)}

@mcp.tool()
def budget_status() -> dict:
    """Get current budget status."""
    return _budget

# ============================
# TOOLS: HeadyLens
# ============================

@mcp.tool()
def lens_observe(target: str, depth: int = 1) -> dict:
    """HeadyLens observation tool — inspect any OS entity."""
    if target == 'agents':
        return get_agent_states()
    elif target == 'nibbles':
        return get_nibble_registry()
    elif target == 'vectors':
        return {'snapshot': octave_space.snapshot()}
    elif target == 'wisdom':
        return {'wisdom': _wisdom_store[-depth:] if _wisdom_store else []}
    elif target == 'budget':
        return budget_status()
    elif target == 'persona':
        return get_persona()
    else:
        return {'error': f'Unknown target: {target}', 'available': ['agents', 'nibbles', 'vectors', 'wisdom', 'budget', 'persona']}

# ============================
# TOOLS: Council Mode
# ============================

@mcp.tool()
def council_invoke(question: str, agent_ids: list = []) -> dict:
    """Invoke Council Mode: multi-agent deliberation on a question.
    Each participating agent votes weighted by φ-weight."""
    if not agent_ids:
        agent_ids = list(scheduler.agents.keys())[:5]

    votes = []
    for aid in agent_ids:
        agent = scheduler.agents.get(aid)
        if agent:
            votes.append({
                'agent': aid,
                'weight': agent.phi_weight,
                'ring': agent.ring,
                'role': agent.geometry_role
            })

    total_weight = sum(v['weight'] for v in votes)
    for v in votes:
        v['normalized_influence'] = v['weight'] / total_weight if total_weight > 0 else 0

    return {
        'question': question,
        'council_size': len(votes),
        'votes': votes,
        'consensus_threshold': PHI_INV
    }

# ============================
# TOOLS: Vector Space
# ============================

@mcp.tool()
def vector_put(entity_id: str, field_name: str, v: list, octave: int = 0) -> dict:
    """Store a vector in the eight-octave space."""
    ov = OctaveVector(v=np.array(v), octave=octave)
    octave_space.put(entity_id, field_name, ov)
    return {'stored': True, 'entity': entity_id, 'field': field_name, 'scale': ov.scale}

@mcp.tool()
def vector_get(entity_id: str, field_name: str) -> dict:
    """Retrieve a vector from the eight-octave space."""
    ov = octave_space.get(entity_id, field_name)
    if ov is None:
        return {'error': 'Not found'}
    return ov.to_dict()

@mcp.tool()
def vector_nearest(v: list, octave: int = 0, k: int = 5) -> dict:
    """Find nearest neighbors in the octave space."""
    target = OctaveVector(v=np.array(v), octave=octave)
    results = octave_space.nearest_neighbors(target, k=k)
    return {'results': [{'entity': e, 'field': f, 'distance': d} for e, f, d in results]}

@mcp.tool()
def vector_phi_transform(entity_id: str, field_name: str, action: str) -> dict:
    """Apply a φ-based transform to a stored vector. Actions: scale_up, scale_down, spiral, reflect."""
    ov = octave_space.get(entity_id, field_name)
    if ov is None:
        return {'error': 'Not found'}
    if action == 'scale_up':
        ov = ov.phi_scale_up()
    elif action == 'scale_down':
        ov = ov.phi_scale_down()
    elif action == 'spiral':
        ov = ov.spiral_transform()
    elif action == 'reflect':
        ov = ov.reflect()
    else:
        return {'error': f'Unknown action: {action}'}
    octave_space.put(entity_id, field_name, ov)
    return {'transformed': True, 'action': action, 'result': ov.to_dict()}

# ============================
# TOOLS: Liquid UI Layout
# ============================

@mcp.tool()
def ui_layout_for_context(context: dict = {}) -> dict:
    """Generate a liquid UI layout based on current OS state.
    All proportions are φ-derived. No fixed constants."""
    agent_count = len(scheduler.agents)
    active_octaves = set()
    for eid, fields in octave_space.fields.items():
        for fname, vec in fields.items():
            active_octaves.add(vec.octave)

    layout = {
        'schema': 'iglu:com.heady/ui_layout/jsonschema/1-0-0',
        'data': {
            'phi': PHI,
            'geometry_base': 'flower_of_life',
            'root': {
                'kind': 'golden_split',
                'direction': 'horizontal',
                'ratio': PHI,
                'children': [
                    {
                        'id': 'main',
                        'kind': 'panel',
                        'weight': 1.0,
                        'children': [
                            {
                                'id': 'vector_view',
                                'kind': 'vector_pad',
                                'aspect': PHI,
                                'octaves': sorted(active_octaves) if active_octaves else [0, 1, 2, 3]
                            },
                            {
                                'id': 'timeline',
                                'kind': 'timeline',
                                'ticks': 5,
                                'subdivisions': 5,
                                'phi_scaled': True
                            }
                        ]
                    },
                    {
                        'id': 'side',
                        'kind': 'panel',
                        'weight': PHI_INV,
                        'children': [
                            {
                                'id': 'agent_ring',
                                'kind': 'agent_topology',
                                'geometry': 'pentagonal_ring',
                                'agent_count': agent_count
                            },
                            {
                                'id': 'torus_view',
                                'kind': 'torus_3d',
                                'R': PHI,
                                'r': 1.0,
                                'cursor': scheduler.torus_theta_cursor
                            },
                            {
                                'id': 'metrics',
                                'kind': 'metrics_panel',
                                'energy': scheduler.global_energy,
                                'tick': scheduler.tick
                            }
                        ]
                    }
                ]
            },
            'theme': {
                'palette_source': 'phi_harmonic',
                'base_hue': 222,  # deep blue
                'phi_step': GOLDEN_ANGLE_RAD * (180 / 3.14159)
            }
        }
    }
    return layout

# ============================
# TOOLS: Phi Constants & Info
# ============================

@mcp.tool()
def phi_info() -> dict:
    """Return all φ-derived constants and octave scales."""
    return {
        'phi': PHI, 'phi_inv': PHI_INV, 'phi_sq': PHI ** 2,
        'golden_angle_deg': 137.5078,
        'golden_angle_rad': GOLDEN_ANGLE_RAD,
        'fibonacci_21': fib_sequence(21),
        'octave_scales': [{'octave': i, 'scale': phi_scale(i)} for i in range(8)],
        'sqrt3_vesica': 1.7320508075688772,
        'sqrt5_pentagonal': 2.23606797749979
    }

# ============================
# RUN
# ============================

if __name__ == '__main__':
    print(f"\n🌀 Heady Latent OS — MCP Server (Runtime {RUNTIME_ID})")
    print(f"   φ = {PHI}")
    print(f"   Port: {PORT}")
    print(f"   Transport: Streamable HTTP\n")
    mcp.run(transport='streamable-http', host='0.0.0.0', port=PORT)
