// liquid-renderer.mjs — Renders self-describing UI layouts from MCP server responses
// No hardcoded components: everything is schema-driven and φ-proportioned

const PHI = (1 + Math.sqrt(5)) / 2;
const PHI_INV = 1 / PHI;

// Component registry: dynamically populated
const COMPONENT_REGISTRY = new Map();

function registerComponent(kind, renderer) {
  COMPONENT_REGISTRY.set(kind, renderer);
}

// Default renderers (replace with React/Three.js in production)
registerComponent('golden_split', (node, depth) => {
  const ratio = node.ratio || PHI;
  const dir = node.direction || 'horizontal';
  return {
    type: 'flex',
    direction: dir === 'horizontal' ? 'row' : 'column',
    children: (node.children || []).map((child, i) => ({
      ...renderNode(child, depth + 1),
      flex: i === 0 ? ratio : 1
    }))
  };
});

registerComponent('panel', (node, depth) => ({
  type: 'div',
  id: node.id,
  weight: node.weight || 1,
  children: (node.children || []).map(c => renderNode(c, depth + 1))
}));

registerComponent('vector_pad', (node, depth) => ({
  type: 'canvas3d',
  id: node.id,
  aspect: node.aspect || PHI,
  octaves: node.octaves || [0, 1, 2, 3],
  interactionMode: 'drag-rotate'
}));

registerComponent('timeline', (node, depth) => ({
  type: 'timeline',
  id: node.id,
  ticks: node.ticks || 5,
  subdivisions: node.subdivisions || 5,
  phiScaled: node.phi_scaled || true
}));

registerComponent('agent_topology', (node, depth) => ({
  type: 'svg-graph',
  id: node.id,
  geometry: node.geometry || 'pentagonal_ring',
  agentCount: node.agent_count || 0
}));

registerComponent('torus_3d', (node, depth) => ({
  type: 'three-torus',
  id: node.id,
  R: node.R || PHI,
  r: node.r || 1,
  cursor: node.cursor || 0
}));

registerComponent('metrics_panel', (node, depth) => ({
  type: 'metrics',
  id: node.id,
  energy: node.energy || 0,
  tick: node.tick || 0
}));

function renderNode(node, depth = 0) {
  const renderer = COMPONENT_REGISTRY.get(node.kind);
  if (renderer) return renderer(node, depth);
  return { type: 'unknown', kind: node.kind, id: node.id };
}

function renderLayout(layoutResponse) {
  const data = layoutResponse.data || layoutResponse;
  const root = data.root;
  if (!root) return { error: 'No root node in layout' };
  return {
    phi: data.phi,
    theme: data.theme,
    tree: renderNode(root)
  };
}

// φ-harmonic color palette generation
function phiPalette(baseHue, count = 8) {
  const goldenAngleDeg = 137.508;
  return Array.from({ length: count }, (_, i) => {
    const hue = (baseHue + goldenAngleDeg * i) % 360;
    const saturation = 60 + 20 * Math.sin(i * Math.PI / PHI);
    const lightness = 40 + 15 * Math.cos(i * Math.PI / PHI);
    return `hsl(${hue.toFixed(1)}, ${saturation.toFixed(1)}%, ${lightness.toFixed(1)}%)`;
  });
}

export { renderLayout, registerComponent, phiPalette, COMPONENT_REGISTRY };
