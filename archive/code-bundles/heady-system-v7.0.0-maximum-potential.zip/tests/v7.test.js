/**
 * HeadySystem v7.0.0 — Comprehensive Test Suite
 * Tests all core modules: phi-math v6, CSL engine, 17-swarm orchestrator,
 * bee-factory v2, auth-manager, auto-context, vector-memory, colab manager,
 * HCFullPipeline, auto-success engine.
 */

'use strict';

const { describe, it } = require('node:test');
const assert = require('node:assert/strict');

// ─── Phi-Math v6 Tests ──────────────────────────────────────────────────────

describe('phi-math v6.0', () => {
  const phi = require('../shared/phi-math');

  it('exports core constants', () => {
    assert.ok(Math.abs(phi.PHI - 1.6180339887) < 1e-8);
    assert.ok(Math.abs(phi.PSI - 0.6180339887) < 1e-8);
    assert.ok(Math.abs(phi.PHI2 - 2.6180339887) < 1e-8);
    assert.ok(Math.abs(phi.PHI7 - 29.0344418537) < 1e-4);
  });

  it('fib() computes correctly', () => {
    assert.equal(phi.fib(0), 0);
    assert.equal(phi.fib(1), 1);
    assert.equal(phi.fib(5), 5);
    assert.equal(phi.fib(8), 21);
    assert.equal(phi.fib(10), 55);
    assert.equal(phi.fib(20), 6765);
  });

  it('CSL_THRESHOLDS are phi-derived', () => {
    assert.ok(phi.CSL_THRESHOLDS.MINIMUM < phi.CSL_THRESHOLDS.LOW);
    assert.ok(phi.CSL_THRESHOLDS.LOW < phi.CSL_THRESHOLDS.MEDIUM);
    assert.ok(phi.CSL_THRESHOLDS.MEDIUM < phi.CSL_THRESHOLDS.HIGH);
    assert.ok(phi.CSL_THRESHOLDS.HIGH < phi.CSL_THRESHOLDS.CRITICAL);
    assert.ok(phi.CSL_THRESHOLDS.CRITICAL < phi.CSL_THRESHOLDS.DEDUP);
    assert.ok(Math.abs(phi.CSL_THRESHOLDS.LOW - 0.691) < 0.01);
  });

  it('phiBackoff grows by φ', () => {
    const d0 = phi.phiBackoff(0, 1000, 99999);
    const d1 = phi.phiBackoff(1, 1000, 99999);
    // Base should be ~1000, next ~1618 (with jitter)
    assert.ok(d0 >= 618 && d0 <= 1382);
    assert.ok(d1 >= 1000 && d1 <= 2236);
  });

  it('phiFusionWeights sum to 1.0', () => {
    for (let n = 1; n <= 5; n++) {
      const weights = phi.phiFusionWeights(n);
      const sum = weights.reduce((a, b) => a + b, 0);
      assert.ok(Math.abs(sum - 1.0) < 1e-10, 'weights for n=' + n + ' sum=' + sum);
    }
  });

  it('COLAB_RUNTIMES has 4 entries (Alpha/Beta/Gamma/Delta)', () => {
    const runtimes = phi.COLAB_RUNTIMES;
    assert.equal(Object.keys(runtimes).length, 4);
    assert.ok(runtimes.ALPHA);
    assert.ok(runtimes.BETA);
    assert.ok(runtimes.GAMMA);
    assert.ok(runtimes.DELTA);
    assert.equal(runtimes.DELTA.envVar, 'COLAB_DELTA_URL');
    assert.equal(runtimes.DELTA.role, 'monte-carlo-simulation');
  });

  it('SERVICE_PORTS covers 58+ services', () => {
    assert.ok(Object.keys(phi.SERVICE_PORTS).length >= 58);
    assert.equal(phi.SERVICE_PORTS['heady-manager'], 3300);
    assert.equal(phi.SERVICE_PORTS['kernel'], 3369);
  });

  it('SWARM_NAMES has exactly 17', () => {
    assert.equal(phi.SWARM_NAMES.length, 17);
    assert.ok(phi.SWARM_NAMES.includes('Deploy'));
    assert.ok(phi.SWARM_NAMES.includes('Emergency'));
  });

  it('HCFP_STAGES has exactly 21', () => {
    assert.equal(phi.HCFP_STAGES.length, 21);
    assert.equal(phi.HCFP_STAGES[0], 'CHANNEL_ENTRY');
    assert.equal(phi.HCFP_STAGES[20], 'RECEIPT');
  });

  it('COGNITIVE_ARCHETYPES has 7 entries', () => {
    assert.equal(Object.keys(phi.COGNITIVE_ARCHETYPES).length, 7);
    assert.ok(phi.COGNITIVE_ARCHETYPES.OWL);
    assert.ok(phi.COGNITIVE_ARCHETYPES.BEAVER);
  });

  it('AUTO_SUCCESS constants are phi-derived', () => {
    assert.ok(Math.abs(phi.AUTO_SUCCESS.CYCLE_MS - 29034) < 10);
    assert.ok(Math.abs(phi.AUTO_SUCCESS.TASK_TIMEOUT_MS - 4236) < 10);
    assert.equal(phi.AUTO_SUCCESS.MAX_RETRIES, 3);
    assert.equal(phi.AUTO_SUCCESS.CATEGORIES, 13);
  });

  it('cosineSimilarity works for identical vectors', () => {
    const v = new Float64Array([1, 0, 0]);
    assert.ok(Math.abs(phi.cosineSimilarity(v, v) - 1.0) < 1e-10);
  });

  it('cosineSimilarity returns 0 for orthogonal vectors', () => {
    const a = new Float64Array([1, 0, 0]);
    const b = new Float64Array([0, 1, 0]);
    assert.ok(Math.abs(phi.cosineSimilarity(a, b)) < 1e-10);
  });

  it('normalize produces unit vector', () => {
    const v = phi.normalize(new Float64Array([3, 4, 0]));
    const mag = Math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    assert.ok(Math.abs(mag - 1.0) < 1e-10);
  });

  it('cslGate produces gated value', () => {
    const high = phi.cslGate(1.0, 0.9, 0.5);
    const low = phi.cslGate(1.0, 0.1, 0.5);
    assert.ok(high > low);
    assert.ok(high > 0.9);
    assert.ok(low < 0.1);
  });
});

// ─── CSL Engine Tests ────────────────────────────────────────────────────────

describe('CSL Engine', () => {
  const csl = require('../shared/csl-engine');

  it('cslAND returns cosine similarity', () => {
    const v = new Float64Array([1, 0, 0]);
    assert.ok(Math.abs(csl.cslAND(v, v) - 1.0) < 1e-10);
  });

  it('cslOR combines vectors', () => {
    const a = new Float64Array([1, 0, 0]);
    const b = new Float64Array([0, 1, 0]);
    const result = csl.cslOR(a, b);
    assert.equal(result.length, 3);
    assert.ok(result[0] > 0);
    assert.ok(result[1] > 0);
  });

  it('cslNOT removes projection', () => {
    const a = new Float64Array([1, 1, 0]);
    const b = new Float64Array([1, 0, 0]);
    const result = csl.cslNOT(a, b);
    // Should be mostly in y direction
    assert.ok(Math.abs(result[1]) > Math.abs(result[0]));
  });

  it('resonanceGate returns sigmoid activation', () => {
    const high = csl.resonanceGate(0.9, 0.5);
    const low = csl.resonanceGate(0.1, 0.5);
    assert.ok(high > 0.9);
    assert.ok(low < 0.1);
  });

  it('ternaryGate classifies correctly', () => {
    const high = csl.ternaryGate(0.9, 0.7, 0.3);
    const low = csl.ternaryGate(0.1, 0.7, 0.3);
    assert.equal(high.state, 1);
    assert.equal(low.state, -1);
  });

  it('routeGate scores candidates', () => {
    const intent = new Float64Array([1, 0, 0]);
    const candidates = [
      { id: 'a', vector: new Float64Array([1, 0, 0]) },
      { id: 'b', vector: new Float64Array([0, 1, 0]) },
    ];
    const result = csl.routeGate(intent, candidates, 0.5);
    assert.ok(result.scores.length === 2);
    assert.equal(result.best.id, 'a');
  });
});

// ─── 17-Swarm Orchestrator Tests ─────────────────────────────────────────────

describe('17-Swarm Orchestrator', () => {
  const { SwarmOrchestrator, SwarmTask, SWARM_NAMES } = require('../src/orchestration/seventeen-swarm-orchestrator');

  it('creates all 17 swarms', () => {
    const orch = new SwarmOrchestrator();
    assert.equal(orch.listSwarmNames().length, 17);
    for (const name of SWARM_NAMES) {
      assert.ok(orch.getSwarm(name), 'Missing swarm: ' + name);
    }
  });

  it('dispatches tasks to correct swarm', () => {
    const orch = new SwarmOrchestrator();
    const task = orch.dispatch({ type: 'deploy_service', targetSwarm: 'Deploy' });
    assert.ok(task);
    assert.equal(task.targetSwarm, 'Deploy');
  });

  it('auto-routes by task type', () => {
    const orch = new SwarmOrchestrator();
    const task = orch.dispatch({ type: 'security_scan' });
    assert.ok(task);
  });

  it('returns comprehensive status', () => {
    const orch = new SwarmOrchestrator();
    const status = orch.getStatus();
    assert.equal(status.swarms.length, 17);
    assert.equal(status.initialized, false);
  });

  it('starts and stops cleanly', () => {
    const orch = new SwarmOrchestrator();
    orch.start();
    assert.equal(orch.getStatus().initialized, true);
    orch.stop();
    assert.equal(orch.getStatus().initialized, false);
  });
});

// ─── Bee Factory v2 Tests ────────────────────────────────────────────────────

describe('Bee Factory v2', () => {
  const bf = require('../src/bees/bee-factory-v2');

  it('createBee creates a dynamic bee', () => {
    const bee = bf.createBee('test-domain', { description: 'Test bee' });
    assert.ok(bee);
    assert.equal(bee.domain, 'test-domain');
    assert.ok(bee.vector);
    assert.ok(bee.csl);
  });

  it('spawnBee creates ephemeral bee', () => {
    const bee = bf.spawnBee('quick-task', async () => ({ done: true }));
    assert.ok(bee);
    assert.ok(bee.ephemeral);
    assert.ok(bee.domain.startsWith('ephemeral-'));
  });

  it('routeBee finds best match', () => {
    bf.createBee('deploy-k8s', { description: 'Kubernetes deployment' });
    bf.createBee('security-scan', { description: 'Security scanning' });
    const result = bf.routeBee('deploy something');
    assert.ok(result);
    assert.ok(result.ranked.length > 0);
  });

  it('createSwarm orchestrates multiple bees', () => {
    const swarm = bf.createSwarm('test-swarm', [
      { domain: 'worker-1', config: { description: 'Worker 1', workers: [{ name: 'w1', fn: async () => ({ ok: true }) }] } },
      { domain: 'worker-2', config: { description: 'Worker 2', workers: [{ name: 'w2', fn: async () => ({ ok: true }) }] } },
    ]);
    assert.ok(swarm);
    assert.ok(swarm.isSwarm);
  });

  it('listDynamicBees returns all bees', () => {
    const bees = bf.listDynamicBees();
    assert.ok(bees.length > 0);
  });

  it('dissolveBee removes bee', () => {
    bf.createBee('dissolve-me', {});
    bf.dissolveBee('dissolve-me');
    const bees = bf.listDynamicBees();
    assert.ok(!bees.find(b => b.domain === 'dissolve-me'));
  });

  it('BEE_DOMAINS has 24 entries', () => {
    assert.equal(bf.BEE_DOMAINS.length, 24);
  });
});

// ─── Auth Manager Tests ──────────────────────────────────────────────────────

describe('Auth Manager', () => {
  const { AuthManager, ROLES, COOKIE_NAME } = require('../src/services/auth/auth-manager');

  it('creates sessions with httpOnly cookie', async () => {
    const auth = new AuthManager();
    const result = await auth.createSession({ id: 'user1', email: 'test@test.com', role: ROLES.USER });
    assert.ok(result.sessionId);
    assert.ok(result.refreshToken);
    assert.equal(result.cookieName, COOKIE_NAME);
    assert.equal(COOKIE_NAME, '__Host-heady_session');
  });

  it('verifies valid sessions', async () => {
    const auth = new AuthManager();
    const { sessionId } = await auth.createSession({ id: 'user2', email: 'test@test.com' });
    const result = await auth.verifySession(sessionId);
    assert.ok(result.valid);
    assert.equal(result.payload.sub, 'user2');
  });

  it('rejects invalid sessions', async () => {
    const auth = new AuthManager();
    const result = await auth.verifySession('nonexistent');
    assert.equal(result.valid, false);
  });

  it('RBAC hasRole works correctly', () => {
    const auth = new AuthManager();
    assert.ok(auth.hasRole(ROLES.ADMIN, ROLES.USER));
    assert.ok(auth.hasRole(ROLES.USER, ROLES.USER));
    assert.ok(!auth.hasRole(ROLES.GUEST, ROLES.ADMIN));
  });

  it('creates and validates API keys', async () => {
    const auth = new AuthManager();
    const { apiKey, keyId } = await auth.createApiKey('user3', { role: ROLES.OPERATOR });
    assert.ok(apiKey.startsWith('hdy_'));
    const result = await auth.validateApiKey(apiKey);
    assert.ok(result.valid);
    assert.equal(result.record.role, ROLES.OPERATOR);
  });

  it('setCookieHeader generates correct cookie', () => {
    const auth = new AuthManager();
    const header = auth.setCookieHeader('test-session-id');
    assert.ok(header.includes('HttpOnly'));
    assert.ok(header.includes('Secure'));
    assert.ok(header.includes('SameSite=Strict'));
    assert.ok(header.includes('__Host-heady_session=test-session-id'));
  });
});

// ─── HCFullPipeline Tests ────────────────────────────────────────────────────

describe('HCFullPipeline', () => {
  const { HCFullPipeline, HCFP_STAGES, PIPELINE_VARIANTS } = require('../src/orchestration/hcfull-pipeline');

  it('has 21 stages', () => {
    assert.equal(HCFP_STAGES.length, 21);
  });

  it('has 4 pipeline variants', () => {
    assert.ok(PIPELINE_VARIANTS.FAST);
    assert.ok(PIPELINE_VARIANTS.FULL);
    assert.ok(PIPELINE_VARIANTS.ARENA);
    assert.ok(PIPELINE_VARIANTS.LEARNING);
  });

  it('executes FAST variant', async () => {
    const pipeline = new HCFullPipeline();
    const run = await pipeline.execute({ id: 'test-1', type: 'test' }, 'FAST');
    assert.equal(run.status, 'completed');
    assert.equal(run.variant, 'FAST');
  });

  it('tracks pipeline stats', async () => {
    const pipeline = new HCFullPipeline();
    await pipeline.execute({ id: 'test-2', type: 'test' }, 'FAST');
    const status = pipeline.getStatus();
    assert.ok(status.stats.completed > 0);
  });
});

// ─── Colab Runtime Manager Tests ─────────────────────────────────────────────

describe('Colab Runtime Manager', () => {
  const { ColabRuntimeManager, COLAB_RUNTIMES } = require('../src/colab/colab-runtime-manager-v2');

  it('initializes 4 runtimes', () => {
    const mgr = new ColabRuntimeManager();
    const status = mgr.getStatus();
    assert.equal(Object.keys(status.runtimes).length, 4);
    assert.ok(status.runtimes.ALPHA);
    assert.ok(status.runtimes.BETA);
    assert.ok(status.runtimes.GAMMA);
    assert.ok(status.runtimes.DELTA);
  });

  it('Delta runtime has correct role', () => {
    const mgr = new ColabRuntimeManager();
    const delta = mgr.getRuntime('DELTA');
    assert.equal(delta.role, 'monte-carlo-simulation');
    assert.equal(delta.envVar, 'COLAB_DELTA_URL');
    assert.ok(delta.capabilities.includes('monte-carlo'));
  });

  it('GPU allocations are phi-weighted', () => {
    const mgr = new ColabRuntimeManager();
    const status = mgr.getStatus();
    const alphaAlloc = parseFloat(status.runtimes.ALPHA.gpuAllocation);
    const deltaAlloc = parseFloat(status.runtimes.DELTA.gpuAllocation);
    assert.ok(alphaAlloc > deltaAlloc, 'Alpha should have more GPU than Delta');
  });
});

// ─── Auto-Success Engine Tests ───────────────────────────────────────────────

describe('Auto-Success Engine', () => {
  const { AutoSuccessEngine, CATEGORIES } = require('../src/intelligence/auto-success-engine');

  it('has 13 categories', () => {
    assert.equal(Object.keys(CATEGORIES).length, 13);
  });

  it('starts and stops cleanly', () => {
    const engine = new AutoSuccessEngine();
    engine.start();
    assert.ok(engine.getStatus().running);
    engine.stop();
    assert.ok(!engine.getStatus().running);
  });

  it('reports correct cycle interval', () => {
    const engine = new AutoSuccessEngine();
    const status = engine.getStatus();
    assert.ok(Math.abs(status.cycleMs - 29034) < 10);
  });
});

// ─── Summary ─────────────────────────────────────────────────────────────────

describe('v7.0 Architecture Validation', () => {
  it('phi-math exports all required symbols', () => {
    const phi = require('../shared/phi-math');
    const required = ['PHI', 'PSI', 'fib', 'CSL_THRESHOLDS', 'COLAB_RUNTIMES',
      'SERVICE_PORTS', 'SWARM_NAMES', 'HCFP_STAGES', 'AUTO_SUCCESS',
      'COGNITIVE_ARCHETYPES', 'SITE_DOMAINS', 'phiBackoff', 'phiFusionWeights',
      'cosineSimilarity', 'normalize', 'cslGate', 'cslAND', 'cslOR', 'cslNOT'];
    for (const sym of required) {
      assert.ok(phi[sym] !== undefined, 'Missing export: ' + sym);
    }
  });

  it('zero console.log in shared modules', () => {
    const fs = require('fs');
    const path = require('path');
    const sharedDir = path.join(__dirname, '..', 'shared');
    const files = fs.readdirSync(sharedDir).filter(f => f.endsWith('.js'));
    for (const file of files) {
      const content = fs.readFileSync(path.join(sharedDir, file), 'utf8');
      const lines = content.split('\n');
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i].trim();
        if (line.startsWith('//') || line.startsWith('*')) continue;
        assert.ok(!line.includes('console.log('),
          file + ':' + (i + 1) + ' contains console.log');
      }
    }
  });
});
