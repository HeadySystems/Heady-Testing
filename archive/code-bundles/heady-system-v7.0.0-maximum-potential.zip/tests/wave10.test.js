/**
 * Wave 10 Test Suite — Advanced Engine Components
 * Tests for HeadyRefactor, HeadyCopilot, GraphRAG, DurableObjectManager,
 * MonetizationEngine, ABTestingFramework, and EmbeddingRouter.
 * 
 * Run: node tests/wave10.test.js
 */

'use strict';

const assert = require('node:assert/strict');

/* ─── Test Framework ─── */
let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    passed++;
    process.stdout.write(`  ✓ ${name}\n`);
  } catch (err) {
    failed++;
    process.stderr.write(`  ✗ ${name}\n    ${err.message}\n`);
  }
}

async function testAsync(name, fn) {
  try {
    await fn();
    passed++;
    process.stdout.write(`  ✓ ${name}\n`);
  } catch (err) {
    failed++;
    process.stderr.write(`  ✗ ${name}\n    ${err.message}\n`);
  }
}

function describe(section) {
  process.stdout.write(`\n${section}\n`);
}

/* ─── Import all modules ─── */
const { PHI, PSI, fib, CSL_THRESHOLDS, phiFusionWeights, ALERT_THRESHOLDS, cslGate, cosineSimilarity } = require('../shared/phi-math.js');

const refactorModule = require('../src/refactor/heady-refactor.js');
const copilotModule = require('../src/copilot/heady-copilot.js');
const graphModule = require('../src/memory/graph-rag.js');
const doModule = require('../src/edge/durable-object-manager.js');
const monModule = require('../src/monetization/monetization-engine.js');
const abModule = require('../src/experimentation/ab-testing.js');
const routerModule = require('../src/embedding/embedding-router.js');

/* ═══════════════════════════════════════════════════════════════
   §1 — HeadyRefactor Tests
   ═══════════════════════════════════════════════════════════════ */
describe('HeadyRefactor');
const { analyze, refactor, batchAnalyze, generateDiff, RULES, CATEGORIES } = refactorModule;

test('should load 14 rules across 6 categories', () => {
  assert.equal(RULES.length, 14);
  assert.equal(Object.keys(CATEGORIES).length, 6);
});

test('should detect console.log as SEC_001', () => {
  const result = analyze('console.log("debug")', 'test.js');
  assert.ok(result.issues.some(i => i.ruleId === 'SEC_001'));
});

test('should detect localStorage as SEC_002', () => {
  const result = analyze('localStorage.getItem("token")', 'test.js');
  assert.ok(result.issues.some(i => i.ruleId === 'SEC_002'));
});

test('should detect TODO comments as READ_001', () => {
  const result = analyze('// TODO: fix this later', 'test.js');
  assert.ok(result.issues.some(i => i.ruleId === 'READ_001'));
});

test('should produce phi-weighted compliance score', () => {
  const result = analyze('const x = 1;', 'clean.js');
  assert.ok(result.score.overall >= 0 && result.score.overall <= 1);
  assert.ok(['A', 'B', 'C', 'D', 'F'].includes(result.score.grade));
});

test('should generate unified diff', () => {
  const diff = generateDiff('const a = 1;', 'const a = 2;', 'test.js');
  assert.ok(diff.includes('---'));
  assert.ok(diff.includes('+++'));
});

test('should support dry-run refactoring', () => {
  const result = refactor('console.log("test")', 'test.js', { dryRun: true });
  assert.ok(result.changes.every(c => c.status === 'dry-run' || c.status === 'skipped'));
});

test('refactor health check should report rule count', () => {
  const h = refactorModule.health.check();
  assert.equal(h.status, 'healthy');
  assert.equal(h.details.rulesLoaded, 14);
});

/* ═══════════════════════════════════════════════════════════════
   §2 — HeadyCopilot Tests
   ═══════════════════════════════════════════════════════════════ */
describe('HeadyCopilot');
const { getCompletions, getDiagnostics, getCodeActions, getHover, handleLSPRequest, SNIPPETS } = copilotModule;

test('should have 10+ snippet templates', () => {
  assert.ok(SNIPPETS.length >= 10);
});

test('should provide completions object', () => {
  const result = getCompletions({ code: 'heady-liquid', line: 0, character: 12, filePath: 'test.js' });
  assert.ok(result.items !== undefined);
});

test('should detect console.log in diagnostics', () => {
  const diagnostics = getDiagnostics('console.log("test")', 'test.js');
  assert.ok(diagnostics.some(d => d.code === 'SEC_001'));
  assert.ok(diagnostics.some(d => d.severity === 1));
});

test('should provide hover for PHI constant', () => {
  const hover = getHover('const x = PHI;', 0, 10);
  assert.ok(hover !== null);
  assert.ok(hover.contents.value.includes('1.618'));
});

test('should handle LSP initialize request', () => {
  const response = handleLSPRequest({ id: 1, method: 'initialize', params: {} });
  assert.equal(response.jsonrpc, '2.0');
  assert.ok(response.result.capabilities.completionProvider);
});

test('should handle unknown LSP method gracefully', () => {
  const response = handleLSPRequest({ id: 2, method: 'unknown/method', params: {} });
  assert.ok(response.error);
  assert.equal(response.error.code, -32601);
});

test('copilot health check should report snippet count', () => {
  const h = copilotModule.health.check();
  assert.equal(h.status, 'healthy');
  assert.ok(h.details.snippets >= 10);
});

/* ═══════════════════════════════════════════════════════════════
   §3 — GraphRAG Tests
   ═══════════════════════════════════════════════════════════════ */
describe('GraphRAG');
const { KnowledgeGraph, extractEntities, extractRelationships, detectCommunities, queryGraph, ingestDocument, getGraphStats, ENTITY_TYPES, RELATIONSHIP_TYPES } = graphModule;

test('should define 10 entity types and 13 relationship types', () => {
  assert.equal(ENTITY_TYPES.length, 10);
  assert.equal(RELATIONSHIP_TYPES.length, 13);
});

test('should extract entities from text', () => {
  const entities = extractEntities('HeadySoul uses PostgreSQL and Redis for Node.js backend');
  assert.ok(entities.length > 0);
  assert.ok(entities.some(e => e.type === 'COMPONENT' || e.type === 'TECHNOLOGY'));
});

test('should add entities to knowledge graph', () => {
  const graph = new KnowledgeGraph('test');
  const entity = graph.addEntity({ name: 'HeadyBrains', type: 'COMPONENT', description: 'Context assembler' });
  assert.ok(entity.id);
  assert.equal(entity.name, 'HeadyBrains');
});

test('should deduplicate entities by name', () => {
  const graph = new KnowledgeGraph('test');
  graph.addEntity({ name: 'Redis', type: 'TECHNOLOGY' });
  graph.addEntity({ name: 'Redis', type: 'TECHNOLOGY', description: 'In-memory store' });
  assert.equal(graph._entities.size, 1);
});

test('should add relationships between entities', () => {
  const graph = new KnowledgeGraph('test');
  const e1 = graph.addEntity({ name: 'HeadySoul', type: 'COMPONENT' });
  const e2 = graph.addEntity({ name: 'HeadyBrains', type: 'COMPONENT' });
  const rel = graph.addRelationship({ sourceId: e1.id, targetId: e2.id, type: 'COMMUNICATES_WITH' });
  assert.ok(rel.id);
});

test('should find neighbors via graph traversal', () => {
  const graph = new KnowledgeGraph('test');
  const a = graph.addEntity({ name: 'NodeA', type: 'CONCEPT' });
  const b = graph.addEntity({ name: 'NodeB', type: 'CONCEPT' });
  const c = graph.addEntity({ name: 'NodeC', type: 'CONCEPT' });
  graph.addRelationship({ sourceId: a.id, targetId: b.id, type: 'RELATED_TO' });
  graph.addRelationship({ sourceId: b.id, targetId: c.id, type: 'RELATED_TO' });
  const neighbors = graph.getNeighbors(a.id, 2);
  assert.ok(neighbors.length >= 2);
});

test('should support 4 query modes', () => {
  const graph = new KnowledgeGraph('test');
  graph.addEntity({ name: 'TestEntity', type: 'CONCEPT' });
  for (const mode of ['local', 'global', 'hybrid', 'naive']) {
    const result = queryGraph(graph, 'test query', { mode });
    assert.equal(result.mode, mode);
  }
});

test('should ingest document and build graph', () => {
  const graph = new KnowledgeGraph('test');
  const result = ingestDocument(graph, 'HeadyMemory uses PostgreSQL for persistence. Redis provides caching.');
  assert.ok(result.entitiesAdded > 0);
});

test('graphrag health check should report entity types', () => {
  const h = graphModule.health.check();
  assert.equal(h.status, 'healthy');
  assert.equal(h.details.entityTypes, 10);
});

/* ═══════════════════════════════════════════════════════════════
   §4 — DurableObjectManager Tests
   ═══════════════════════════════════════════════════════════════ */
describe('DurableObjectManager');
const { AgentStateMachine, EdgeEmbeddingCache, routeRequest, AGENT_STATES, COMPRESSION_TRIGGERS } = doModule;

test('should define 7 agent states', () => {
  assert.equal(Object.keys(AGENT_STATES).length, 7);
});

test('should validate state transitions', () => {
  const agent = new AgentStateMachine('test-agent');
  assert.equal(agent._state, AGENT_STATES.INIT);
  assert.ok(agent.transition(AGENT_STATES.ACTIVE, 'test'));
  assert.equal(agent._state, AGENT_STATES.ACTIVE);
  assert.ok(!agent.transition(AGENT_STATES.INIT, 'invalid'));
});

test('should record messages and track count', () => {
  const agent = new AgentStateMachine('test-agent');
  agent.transition(AGENT_STATES.ACTIVE);
  for (let i = 0; i < 5; i++) agent.recordMessage({ text: `Message ${i}` });
  assert.equal(agent._messageCount, 5);
});

test('should trigger compression at Fibonacci counts', () => {
  assert.deepEqual(COMPRESSION_TRIGGERS, [8, 13, 21, 34, 55, 89]);
});

test('should serialize and deserialize agent state', () => {
  const agent = new AgentStateMachine('test-agent');
  agent.transition(AGENT_STATES.ACTIVE);
  agent.recordMessage({ text: 'hello' });
  const json = agent.serialize();
  const restored = AgentStateMachine.deserialize(json);
  assert.equal(restored._agentId, 'test-agent');
  assert.equal(restored._state, AGENT_STATES.ACTIVE);
  assert.equal(restored._messageCount, 1);
});

test('should route simple requests to edge', () => {
  const decision = routeRequest({ type: 'lookup', tokenCount: 10, toolCalls: 0, contextLength: 0 });
  assert.equal(decision.target, 'edge');
});

test('should route complex requests to origin', () => {
  const decision = routeRequest({ type: 'reasoning', tokenCount: 500, toolCalls: 5, contextLength: 500, requiresReasoning: true });
  assert.equal(decision.target, 'origin');
});

/* ═══════════════════════════════════════════════════════════════
   §4b — DurableObjectManager Async Tests
   ═══════════════════════════════════════════════════════════════ */

async function runAsyncTests() {
  await testAsync('embedding cache L1 should work', async () => {
    const cache = new EdgeEmbeddingCache();
    const embedding = new Float32Array([1.0, 2.0, 3.0]);
    await cache.set('test-key', embedding);
    const result = await cache.get('test-key');
    assert.deepEqual(result, embedding);
  });

  /* ═══════════════════════════════════════════════════════════════
     §7b — EmbeddingRouter Async Tests
     ═══════════════════════════════════════════════════════════════ */

  await testAsync('circuit breaker should open after fib(5) failures', async () => {
    const cb = new CircuitBreaker('test');
    for (let i = 0; i < 5; i++) {
      try { await cb.execute(async () => { throw new Error('fail'); }); } catch (_) {}
    }
    assert.equal(cb.getStats().state, 'OPEN');
  });

  await testAsync('router should embed text', async () => {
    const router = new EmbeddingRouter();
    const result = await router.embed('Hello world');
    assert.ok(result.embeddings.length === 1);
    assert.ok(result.embeddings[0] instanceof Float32Array);
  });

  await testAsync('router should batch embed', async () => {
    const router = new EmbeddingRouter();
    const result = await router.embed(['Hello', 'World', 'Test']);
    assert.equal(result.embeddings.length, 3);
  });
}

/* ═══════════════════════════════════════════════════════════════
   §5 — MonetizationEngine Tests
   ═══════════════════════════════════════════════════════════════ */
describe('MonetizationEngine');
const { UsageMeter, FeatureGate, SubscriptionManager, RevenueAnalytics, getPricingData, PLANS, METRIC_TYPES, USAGE_ALERTS, TRIAL_DAYS, ANNUAL_DISCOUNT_PCT } = monModule;

test('should define 4 plan tiers', () => {
  assert.equal(Object.keys(PLANS).length, 4);
});

test('should have phi-derived alert thresholds', () => {
  assert.ok(Math.abs(USAGE_ALERTS.warning - PSI) < 0.001);
  assert.ok(USAGE_ALERTS.caution > USAGE_ALERTS.warning);
  assert.ok(USAGE_ALERTS.critical > USAGE_ALERTS.caution);
});

test('should use Fibonacci trial and discount values', () => {
  assert.equal(TRIAL_DAYS, 13);
  assert.equal(ANNUAL_DISCOUNT_PCT, 21);
});

test('should record usage and check limits', () => {
  const meter = new UsageMeter();
  const status = meter.record('user1', 'apiCalls', 1, 'community');
  assert.ok(status.usage > 0);
});

test('should gate features by plan', () => {
  const gate = new FeatureGate();
  assert.equal(gate.check('user1', 'graph_rag', 'community').allowed, false);
  assert.equal(gate.check('user1', 'graph_rag', 'developer').allowed, true);
});

test('should create subscriptions', () => {
  const mgr = new SubscriptionManager();
  const sub = mgr.create({ userId: 'user1', plan: 'developer', billing: 'monthly' });
  assert.ok(sub.id);
  assert.equal(sub.plan, 'developer');
  assert.equal(sub.monthlyPrice, 29);
});

test('should start trials with fib(7)=13 days', () => {
  const mgr = new SubscriptionManager();
  const { trial } = mgr.startTrial('user1', 'developer');
  assert.equal(trial.daysRemaining, 13);
});

test('should generate pricing data', () => {
  const data = getPricingData();
  assert.equal(data.length, 4);
  assert.ok(data.find(d => d.recommended));
});

test('monetization health check', () => {
  const h = monModule.health.check();
  assert.equal(h.status, 'healthy');
  assert.equal(h.details.plans, 4);
});

/* ═══════════════════════════════════════════════════════════════
   §6 — ABTestingFramework Tests
   ═══════════════════════════════════════════════════════════════ */
describe('ABTestingFramework');
const { ExperimentManager, STATES, ROLLOUT_STEPS, DEFAULT_SPLIT } = abModule;

test('should define Fibonacci rollout steps', () => {
  assert.deepEqual(ROLLOUT_STEPS, [1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 100]);
});

test('should use phi-weighted default split', () => {
  assert.ok(Math.abs(DEFAULT_SPLIT[0] - 0.618) < 0.01);
  assert.ok(Math.abs(DEFAULT_SPLIT[1] - 0.382) < 0.01);
});

test('should create experiments', () => {
  const mgr = new ExperimentManager();
  const exp = mgr.create({ name: 'Test Experiment', targetMetric: 'conversion' });
  assert.ok(exp.id);
  assert.equal(exp.state, STATES.DRAFT);
  assert.equal(exp.variants.length, 2);
});

test('should start and assign users', () => {
  const mgr = new ExperimentManager();
  const exp = mgr.create({ name: 'Test', targetMetric: 'conversion' });
  mgr.start(exp.id);
  const assignment = mgr.assign('user1', exp.id);
  assert.ok(assignment.variant);
  assert.equal(assignment.reason, 'assigned');
});

test('should provide sticky assignments', () => {
  const mgr = new ExperimentManager();
  const exp = mgr.create({ name: 'Sticky Test', targetMetric: 'click' });
  mgr.start(exp.id);
  const first = mgr.assign('user1', exp.id);
  const second = mgr.assign('user1', exp.id);
  assert.equal(first.variant, second.variant);
  assert.equal(second.reason, 'sticky');
});

test('should record conversions', () => {
  const mgr = new ExperimentManager();
  const exp = mgr.create({ name: 'Conv Test', targetMetric: 'purchase' });
  mgr.start(exp.id);
  mgr.assign('user1', exp.id);
  const result = mgr.recordConversion('user1', exp.id, { value: 42 });
  assert.equal(result.recorded, true);
});

test('should advance rollout through Fibonacci steps', () => {
  const mgr = new ExperimentManager();
  const exp = mgr.create({ name: 'Rollout Test', targetMetric: 'metric', rollout: true });
  mgr.start(exp.id);
  assert.equal(mgr.advanceRollout(exp.id).pct, 2);
  assert.equal(mgr.advanceRollout(exp.id).pct, 3);
});

test('should analyze experiment with maturity', () => {
  const mgr = new ExperimentManager();
  const exp = mgr.create({ name: 'Analysis Test', targetMetric: 'conversion' });
  mgr.start(exp.id);
  const analysis = mgr.analyze(exp.id);
  assert.ok(analysis.maturity !== undefined);
  assert.equal(analysis.variants.length, 2);
});

test('AB testing health check', () => {
  const h = abModule.health.check();
  assert.equal(h.status, 'healthy');
  assert.deepEqual(h.details.rolloutSteps, ROLLOUT_STEPS);
});

/* ═══════════════════════════════════════════════════════════════
   §7 — EmbeddingRouter Tests
   ═══════════════════════════════════════════════════════════════ */
describe('EmbeddingRouter');
const { EmbeddingRouter, EmbeddingCache, CircuitBreaker, PROVIDERS, TRUNCATION_LEVELS, STANDARD_DIM } = routerModule;

test('should define 6 providers', () => {
  assert.equal(Object.keys(PROVIDERS).length, 6);
});

test('should use 384d as standard dimension', () => {
  assert.equal(STANDARD_DIM, 384);
});

test('should define 3 truncation levels', () => {
  assert.equal(TRUNCATION_LEVELS.length, 3);
  assert.deepEqual(TRUNCATION_LEVELS.map(t => t.dim), [384, 256, 128]);
});

test('circuit breaker should start CLOSED', () => {
  const cb = new CircuitBreaker('test');
  assert.ok(cb.isAvailable());
  assert.equal(cb.getStats().state, 'CLOSED');
});

test('embedding cache should store and retrieve', () => {
  const cache = new EmbeddingCache();
  const emb = new Float32Array([1, 2, 3]);
  cache.set('key1', emb);
  assert.deepEqual(cache.get('key1'), emb);
});

test('embedding cache should report hit rate', () => {
  const cache = new EmbeddingCache();
  cache.set('key1', new Float32Array([1]));
  cache.get('key1');
  cache.get('key2');
  const stats = cache.getStats();
  assert.equal(stats.hits, 1);
  assert.equal(stats.misses, 1);
});

test('router health check', () => {
  const h = routerModule.health.check();
  assert.equal(h.status, 'healthy');
  assert.equal(h.details.providers, 6);
});

/* ═══════════════════════════════════════════════════════════════
   Run Async Tests & Summary
   ═══════════════════════════════════════════════════════════════ */

runAsyncTests().then(() => {
  process.stdout.write(`\n${'═'.repeat(55)}\n`);
  process.stdout.write(`Wave 10 Tests: ${passed} passed, ${failed} failed (${passed + failed} total)\n`);
  process.stdout.write(`${'═'.repeat(55)}\n`);
  if (failed > 0) process.exit(1);
}).catch(err => {
  process.stderr.write(`Fatal error in async tests: ${err.message}\n`);
  process.exit(1);
});
