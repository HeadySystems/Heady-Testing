/**
 * Heady™ Phi-Math Foundation Tests v6.1
 * Comprehensive validation of phi-math.js v5.1
 * Tests canonical v4.1.0 ops + v5.0 extensions + backward-compat aliases
 *
 * @author Eric Haywood — HeadySystems Inc.
 */

'use strict';

const assert = require('assert');
const path = require('path');

const phiMath = require(path.resolve(__dirname, '../shared/phi-math'));

const {
  // Core constants
  PHI, PSI, PHI2, PHI3, PHI_SQ, PHI_CUBE, PHI_FOURTH,
  PSI_SQ, PSI_CUBE, PSI_FOURTH, EMBEDDING_DIM,
  // Fibonacci
  FIB, FIB_CACHE, fib, fibonacci, nearestFib,
  // Thresholds
  phiThreshold, CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  // Pressure
  PRESSURE_LEVELS, getPressureLevel,
  // Alerts
  ALERT_THRESHOLDS,
  // Fusion & Scoring
  phiFusionWeights, phiFusionScore, phiPriorityScore,
  EVICTION_WEIGHTS, RESOURCE_WEIGHTS, RESOURCE_ALLOCATION,
  phiResourceWeights,
  // Backoff & Timing
  phiBackoff, phiBackoffWithJitter, fibRetryBackoff, phiAdaptiveInterval,
  BACKOFF_SEQUENCE,
  // Token Budgets
  phiTokenBudgets, COMPRESSION_TRIGGER,
  // CSL Gates
  PHI_TEMPERATURE, cslGate, cslBlend, adaptiveTemperature,
  // CSL Vector Ops (UPPERCASE canonical)
  cosineSimilarity, cslAND, cslOR, cslNOT, cslIMPLY, cslCONSENSUS, cslXOR,
  // CSL Vector Ops (camelCase compat)
  cslAnd, cslOr, cslNot, cslImply, cslConsensus, cslXor,
  // Sizing
  SIZING, FIBONACCI_SIZES, POOL_SIZES, RELEVANCE_GATES,
  // Utilities
  phiMultiSplit,
  // Timing
  TIMING,
  // HNSW
  HNSW_PARAMS,
  // Pipeline
  PIPELINE_STAGE_COUNT,
  // Colab
  COLAB_RUNTIMES,
  // Services
  SERVICE_PORTS,
} = phiMath;

const EPS = 1e-10;

// ═══════════════════════════════════════════════════════════
// 1. CORE CONSTANTS
// ═══════════════════════════════════════════════════════════

function testCoreConstants() {
  // Golden ratio identity: φ² = φ + 1
  assert(Math.abs(PHI * PHI - (PHI + 1)) < EPS, 'φ² should equal φ + 1');

  // Conjugate identity: 1/φ = φ - 1
  assert(Math.abs(1 / PHI - (PHI - 1)) < EPS, '1/φ should equal φ - 1');

  // PSI = 1/φ
  assert(Math.abs(PSI - 1 / PHI) < EPS, 'PSI should equal 1/PHI');

  // PHI * PSI = 1
  assert(Math.abs(PHI * PSI - 1) < EPS, 'PHI * PSI should equal 1');

  // PHI2 = φ² = φ + 1 (canonical alias)
  assert(Math.abs(PHI2 - (PHI + 1)) < EPS, 'PHI2 should equal PHI + 1');
  assert.strictEqual(PHI2, PHI_SQ, 'PHI2 should alias PHI_SQ');

  // PHI3 = φ³ = 2φ + 1 (canonical alias)
  assert(Math.abs(PHI3 - (2 * PHI + 1)) < EPS, 'PHI3 should equal 2*PHI + 1');
  assert.strictEqual(PHI3, PHI_CUBE, 'PHI3 should alias PHI_CUBE');

  // PHI_FOURTH = φ⁴ = 3φ + 2
  assert(Math.abs(PHI_FOURTH - (3 * PHI + 2)) < EPS, 'PHI_FOURTH should equal 3*PHI + 2');

  // PSI powers
  assert(Math.abs(PSI_SQ - PSI * PSI) < EPS, 'PSI_SQ');
  assert(Math.abs(PSI_CUBE - PSI * PSI * PSI) < EPS, 'PSI_CUBE');
  assert(Math.abs(PSI_FOURTH - Math.pow(PSI, 4)) < EPS, 'PSI_FOURTH');

  // Embedding dimension
  assert.strictEqual(EMBEDDING_DIM, 384, 'EMBEDDING_DIM should be 384');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 2. FIBONACCI SEQUENCE
// ═══════════════════════════════════════════════════════════

function testFibonacci() {
  // Known values
  assert.strictEqual(fib(0), 0);
  assert.strictEqual(fib(1), 1);
  assert.strictEqual(fib(2), 1);
  assert.strictEqual(fib(5), 5);
  assert.strictEqual(fib(8), 21);
  assert.strictEqual(fib(10), 55);
  assert.strictEqual(fib(12), 144);
  assert.strictEqual(fib(14), 377);
  assert.strictEqual(fib(16), 987);
  assert.strictEqual(fib(20), 6765);

  // Fibonacci recurrence: fib(n) = fib(n-1) + fib(n-2)
  for (let i = 2; i <= 20; i++) {
    assert.strictEqual(fib(i), fib(i - 1) + fib(i - 2), `fib(${i}) recurrence`);
  }

  // Ratio convergence: fib(n+1)/fib(n) → φ
  const ratio = fib(20) / fib(19);
  assert(Math.abs(ratio - PHI) < 0.0001, `fib(20)/fib(19) should approximate φ, got ${ratio}`);

  // nearestFib
  assert.strictEqual(nearestFib(20), 21);
  assert.strictEqual(nearestFib(10), 8);
  assert.strictEqual(nearestFib(100), 89);

  // fibonacci alias
  assert.strictEqual(fibonacci, fib, 'fibonacci should alias fib');
  assert.strictEqual(fibonacci(8), 21, 'fibonacci(8) should return 21');

  // FIB_CACHE alias
  assert.strictEqual(FIB_CACHE, FIB, 'FIB_CACHE should alias FIB');

  // Extended range (beyond cached)
  assert.strictEqual(fib(21), 10946);

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 3. CSL THRESHOLDS
// ═══════════════════════════════════════════════════════════

function testCSLThresholds() {
  // phiThreshold formula: 1 - ψ^level × 0.5
  assert(Math.abs(CSL_THRESHOLDS.MINIMUM - (1 - Math.pow(PSI, 0) * 0.5)) < EPS);
  assert(Math.abs(CSL_THRESHOLDS.LOW - (1 - Math.pow(PSI, 1) * 0.5)) < EPS);
  assert(Math.abs(CSL_THRESHOLDS.MEDIUM - (1 - Math.pow(PSI, 2) * 0.5)) < EPS);
  assert(Math.abs(CSL_THRESHOLDS.HIGH - (1 - Math.pow(PSI, 3) * 0.5)) < EPS);
  assert(Math.abs(CSL_THRESHOLDS.CRITICAL - (1 - Math.pow(PSI, 4) * 0.5)) < EPS);

  // Approximate value ranges
  assert(CSL_THRESHOLDS.MINIMUM > 0.49 && CSL_THRESHOLDS.MINIMUM < 0.51, 'MINIMUM ≈ 0.500');
  assert(CSL_THRESHOLDS.LOW > 0.68 && CSL_THRESHOLDS.LOW < 0.70, 'LOW ≈ 0.691');
  assert(CSL_THRESHOLDS.MEDIUM > 0.80 && CSL_THRESHOLDS.MEDIUM < 0.82, 'MEDIUM ≈ 0.809');
  assert(CSL_THRESHOLDS.HIGH > 0.87 && CSL_THRESHOLDS.HIGH < 0.89, 'HIGH ≈ 0.882');
  assert(CSL_THRESHOLDS.CRITICAL > 0.92 && CSL_THRESHOLDS.CRITICAL < 0.94, 'CRITICAL ≈ 0.927');

  // Monotonic increase
  assert(CSL_THRESHOLDS.MINIMUM < CSL_THRESHOLDS.LOW);
  assert(CSL_THRESHOLDS.LOW < CSL_THRESHOLDS.MEDIUM);
  assert(CSL_THRESHOLDS.MEDIUM < CSL_THRESHOLDS.HIGH);
  assert(CSL_THRESHOLDS.HIGH < CSL_THRESHOLDS.CRITICAL);

  // DEDUP above CRITICAL
  assert(DEDUP_THRESHOLD > CSL_THRESHOLDS.CRITICAL, 'DEDUP should exceed CRITICAL');
  assert(DEDUP_THRESHOLD > 0.97 && DEDUP_THRESHOLD < 0.98, 'DEDUP ≈ 0.972');

  // COHERENCE_DRIFT = MEDIUM
  assert.strictEqual(COHERENCE_DRIFT_THRESHOLD, CSL_THRESHOLDS.MEDIUM);

  // phiThreshold custom spread
  const customT = phiThreshold(2, 0.3);
  assert(Math.abs(customT - (1 - Math.pow(PSI, 2) * 0.3)) < EPS);

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 4. PRESSURE LEVELS
// ═══════════════════════════════════════════════════════════

function testPressureLevels() {
  assert(PRESSURE_LEVELS.NOMINAL.min === 0);
  assert(Math.abs(PRESSURE_LEVELS.NOMINAL.max - PSI_SQ) < EPS);
  assert(Math.abs(PRESSURE_LEVELS.ELEVATED.min - PSI_SQ) < EPS);
  assert(Math.abs(PRESSURE_LEVELS.ELEVATED.max - PSI) < EPS);

  // getPressureLevel classification
  assert.strictEqual(getPressureLevel(0.1), 'NOMINAL');
  assert.strictEqual(getPressureLevel(0.5), 'ELEVATED');
  assert.strictEqual(getPressureLevel(0.7), 'HIGH');
  assert.strictEqual(getPressureLevel(0.95), 'CRITICAL');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 5. ALERT THRESHOLDS
// ═══════════════════════════════════════════════════════════

function testAlertThresholds() {
  // Canonical lowercase keys
  assert(typeof ALERT_THRESHOLDS.warning === 'number', 'warning key exists');
  assert(typeof ALERT_THRESHOLDS.caution === 'number', 'caution key exists');
  assert(typeof ALERT_THRESHOLDS.critical === 'number', 'critical key exists');
  assert(typeof ALERT_THRESHOLDS.exceeded === 'number', 'exceeded key exists');
  assert.strictEqual(ALERT_THRESHOLDS.hard_max, 1.0, 'hard_max = 1.0');

  // Values derive from phi
  assert(Math.abs(ALERT_THRESHOLDS.warning - PSI) < EPS, 'warning = ψ');
  assert(Math.abs(ALERT_THRESHOLDS.critical - (1 - PSI_CUBE)) < EPS, 'critical = 1-ψ³');
  assert(Math.abs(ALERT_THRESHOLDS.exceeded - (1 - PSI_FOURTH)) < EPS, 'exceeded = 1-ψ⁴');

  // Monotonic
  assert(ALERT_THRESHOLDS.warning <= ALERT_THRESHOLDS.caution);
  assert(ALERT_THRESHOLDS.caution < ALERT_THRESHOLDS.critical);
  assert(ALERT_THRESHOLDS.critical < ALERT_THRESHOLDS.exceeded);
  assert(ALERT_THRESHOLDS.exceeded < ALERT_THRESHOLDS.hard_max);

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 6. FUSION & SCORING
// ═══════════════════════════════════════════════════════════

function testFusionScoring() {
  // 2-weight fusion → [ψ/(1+ψ), ψ²/(1+ψ)] ≈ [0.618, 0.382]
  const w2 = phiFusionWeights(2);
  assert(Math.abs(w2[0] + w2[1] - 1) < EPS, '2-weights sum to 1');
  assert(Math.abs(w2[0] - (1 / (1 + PSI))) < 0.001, 'w2[0] ≈ 0.618');

  // 3-weight fusion
  const w3 = phiFusionWeights(3);
  assert(Math.abs(w3.reduce((a, b) => a + b, 0) - 1) < EPS, '3-weights sum to 1');

  // phiFusionScore
  const score = phiFusionScore([0.8, 0.6], w2);
  assert(typeof score === 'number', 'phiFusionScore returns number');

  // phiPriorityScore — phi-weighted combination
  const ps = phiPriorityScore(1.0, 0.5, 0.2);
  assert(ps > 0 && ps < 1, 'phiPriorityScore in valid range');
  // Higher first factor should dominate
  assert(phiPriorityScore(1, 0, 0) > phiPriorityScore(0, 1, 0), 'First factor has highest weight');

  // EVICTION_WEIGHTS
  assert(Math.abs(EVICTION_WEIGHTS.importance + EVICTION_WEIGHTS.recency + EVICTION_WEIGHTS.relevance - 1) < 0.01);

  // RESOURCE_WEIGHTS
  const rwSum = Object.values(RESOURCE_WEIGHTS).reduce((a, b) => a + b, 0);
  assert(rwSum > 0.9 && rwSum < 1.1, 'RESOURCE_WEIGHTS sum ≈ 1');

  // phiResourceWeights aliases phiFusionWeights
  assert.deepStrictEqual(phiResourceWeights(3), phiFusionWeights(3));

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 7. PHI-BACKOFF
// ═══════════════════════════════════════════════════════════

function testPhiBackoff() {
  // No-jitter base case
  assert.strictEqual(phiBackoff(0, 1000, 60000, false), 1000, 'phiBackoff(0) no-jitter = 1000');

  // Phi scaling without jitter
  const expected = [1000, 1618, 2618, 4236, 6854, 11090];
  for (let i = 0; i < expected.length; i++) {
    const actual = phiBackoff(i, 1000, 60000, false);
    assert(Math.abs(actual - expected[i]) < 2, `phiBackoff(${i}) no-jitter should be ≈${expected[i]}, got ${actual}`);
  }

  // Respects max
  assert(phiBackoff(20, 1000, 60000, false) <= 60000, 'Should not exceed maxMs');

  // Jitter version stays within ±ψ² bounds (~38.2%)
  for (let i = 0; i < 20; i++) {
    const base = phiBackoff(2, 1000, 60000, false);
    const jittered = phiBackoffWithJitter(2);
    assert(jittered >= base * 0.5, `Jitter too low: ${jittered}`);
    assert(jittered <= base * 1.5, `Jitter too high: ${jittered}`);
  }

  // fibRetryBackoff — returns Fibonacci-scaled retry delays
  const retries = fibRetryBackoff(5, 100);
  assert.strictEqual(retries.length, 5);
  assert.strictEqual(retries[0], fib(4) * 100); // 300
  assert.strictEqual(retries[1], fib(5) * 100); // 500

  // phiAdaptiveInterval
  const growInterval = phiAdaptiveInterval(1000, true, 2000);
  assert(growInterval > 2000, 'Healthy should grow interval');
  const shrinkInterval = phiAdaptiveInterval(1000, false, 2000);
  assert(shrinkInterval < 2000, 'Unhealthy should shrink interval');

  // BACKOFF_SEQUENCE
  assert.strictEqual(BACKOFF_SEQUENCE[0], 1000);
  assert.strictEqual(BACKOFF_SEQUENCE[1], 1618);
  assert(BACKOFF_SEQUENCE.length >= 8, 'At least 8 backoff steps');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 8. TOKEN BUDGETS
// ═══════════════════════════════════════════════════════════

function testTokenBudgets() {
  const budgets = phiTokenBudgets(8192);
  assert.strictEqual(budgets.working, 8192, 'working = base');
  assert(budgets.session > budgets.working, 'session > working');
  assert(budgets.memory > budgets.session, 'memory > session');
  assert(budgets.artifacts > budgets.memory, 'artifacts > memory');

  // session = base × φ²
  assert(Math.abs(budgets.session - Math.round(8192 * PHI2)) < 1, 'session = base × φ²');

  // COMPRESSION_TRIGGER
  assert(Math.abs(COMPRESSION_TRIGGER - (1 - PSI_FOURTH)) < EPS, 'COMPRESSION_TRIGGER = 1-ψ⁴');
  assert(COMPRESSION_TRIGGER > 0.85 && COMPRESSION_TRIGGER < 0.86, 'COMPRESSION_TRIGGER ≈ 0.854');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 9. CSL GATE OPERATIONS
// ═══════════════════════════════════════════════════════════

function testCSLGates() {
  // PHI_TEMPERATURE = ψ³
  assert(Math.abs(PHI_TEMPERATURE - PSI_CUBE) < EPS, 'PHI_TEMPERATURE = ψ³');
  assert(PHI_TEMPERATURE > 0.23 && PHI_TEMPERATURE < 0.24, 'PHI_TEMPERATURE ≈ 0.236');

  // cslGate — sigmoid gating
  const gated = cslGate(1.0, 0.9, CSL_THRESHOLDS.MINIMUM, PHI_TEMPERATURE);
  assert(gated > 0.8, 'High cosScore should pass most of value through gate');
  const blocked = cslGate(1.0, 0.1, CSL_THRESHOLDS.HIGH, PHI_TEMPERATURE);
  assert(blocked < 0.05, 'Low cosScore should block most of value');

  // cslBlend — sigmoid interpolation
  const blended = cslBlend(1.0, 0.0, 0.9, CSL_THRESHOLDS.MINIMUM);
  assert(blended > 0.8, 'High cosScore should blend toward weightHigh');
  const blendLow = cslBlend(1.0, 0.0, 0.1, CSL_THRESHOLDS.HIGH);
  assert(blendLow < 0.05, 'Low cosScore should blend toward weightLow');

  // adaptiveTemperature
  const lowEntropy = adaptiveTemperature(0.1, 1.0);
  const highEntropy = adaptiveTemperature(0.9, 1.0);
  assert(highEntropy > lowEntropy, 'Higher entropy → higher temperature');
  // Formula: PHI_TEMPERATURE × (1 + ratio × φ)
  const expected = PHI_TEMPERATURE * (1 + 0.5 * PHI);
  assert(Math.abs(adaptiveTemperature(0.5, 1.0) - expected) < EPS, 'adaptiveTemperature formula');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 10. CSL VECTOR OPERATIONS
// ═══════════════════════════════════════════════════════════

function testCSLVectorOps() {
  const v1 = [1, 0, 0];
  const v2 = [1, 0, 0];
  const v3 = [0, 1, 0];
  const v4 = [0.707, 0.707, 0];

  // cosineSimilarity
  assert(Math.abs(cosineSimilarity(v1, v2) - 1.0) < EPS, 'Identical vectors → cos = 1');
  assert(Math.abs(cosineSimilarity(v1, v3)) < EPS, 'Orthogonal vectors → cos = 0');
  assert(cosineSimilarity(v1, v4) > 0.7 && cosineSimilarity(v1, v4) < 0.71, 'cos(45°) ≈ 0.707');

  // cslAND — cosine similarity
  assert(Math.abs(cslAND(v1, v2) - 1.0) < EPS, 'cslAND identical → 1');
  assert(Math.abs(cslAND(v1, v3)) < EPS, 'cslAND orthogonal → 0');

  // cslOR — normalized superposition
  const orResult = cslOR(v1, v3);
  assert(orResult.length === 3, 'cslOR preserves dimension');
  const orNorm = Math.sqrt(orResult.reduce((s, v) => s + v * v, 0));
  assert(Math.abs(orNorm - 1) < 0.01, 'cslOR result is normalized');

  // cslNOT — orthogonal projection (removes b from a)
  const notResult = cslNOT(v4, v1);
  // NOT(v4, v1) should have zero component along v1
  const dotCheck = notResult.reduce((s, v, i) => s + v * v1[i], 0);
  assert(Math.abs(dotCheck) < EPS, 'cslNOT orthogonality: NOT(a,b)·b = 0');

  // cslIMPLY — projection onto b
  const implyResult = cslIMPLY(v4, v1);
  // Should be the component of v4 along v1
  assert(Math.abs(implyResult[0] - 0.707) < 0.001, 'cslIMPLY projects onto b');
  assert(Math.abs(implyResult[1]) < EPS, 'cslIMPLY zeroes orthogonal component');

  // cslCONSENSUS — weighted centroid
  const consensus = cslCONSENSUS([v1, v3]);
  assert(consensus.length === 3, 'cslCONSENSUS preserves dimension');
  const cNorm = Math.sqrt(consensus.reduce((s, v) => s + v * v, 0));
  assert(Math.abs(cNorm - 1) < 0.01, 'cslCONSENSUS result is normalized');

  // cslXOR — exclusive components
  const xorResult = cslXOR(v1, v3);
  assert(xorResult.length === 3, 'cslXOR preserves dimension');

  // camelCase aliases match UPPERCASE originals
  assert.strictEqual(cslAnd, cslAND, 'cslAnd aliases cslAND');
  assert.strictEqual(cslOr, cslOR, 'cslOr aliases cslOR');
  assert.strictEqual(cslNot, cslNOT, 'cslNot aliases cslNOT');
  assert.strictEqual(cslImply, cslIMPLY, 'cslImply aliases cslIMPLY');
  assert.strictEqual(cslConsensus, cslCONSENSUS, 'cslConsensus aliases cslCONSENSUS');
  assert.strictEqual(cslXor, cslXOR, 'cslXor aliases cslXOR');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 11. SIZING CONSTANTS
// ═══════════════════════════════════════════════════════════

function testSizing() {
  // SIZING maps to Fibonacci
  assert.strictEqual(SIZING.FAILURE_THRESHOLD, 5, 'fib(5)');
  assert.strictEqual(SIZING.BATCH_EVICTION, 8, 'fib(6)');
  assert.strictEqual(SIZING.MAX_CONCURRENT, 8, 'fib(6)');
  assert.strictEqual(SIZING.SMALL_LIMIT, 13, 'fib(7)');
  assert.strictEqual(SIZING.HNSW_M, 21, 'fib(8)');
  assert.strictEqual(SIZING.RERANK_TOP_K, 21, 'fib(8)');
  assert.strictEqual(SIZING.SLIDING_WINDOW, 34, 'fib(9)');
  assert.strictEqual(SIZING.MAX_ENTITIES, 55, 'fib(10)');
  assert.strictEqual(SIZING.RETENTION_DAYS, 89, 'fib(11)');
  assert.strictEqual(SIZING.EF_CONSTRUCTION, 144, 'fib(12)');
  assert.strictEqual(SIZING.QUEUE_DEPTH, 233, 'fib(13)');
  assert.strictEqual(SIZING.PATTERN_STORE, 377, 'fib(14)');
  assert.strictEqual(SIZING.CACHE_SIZE, 987, 'fib(16)');
  assert.strictEqual(SIZING.HISTORY_BUFFER, 1597, 'fib(17)');
  assert.strictEqual(SIZING.LARGE_CACHE, 6765, 'fib(20)');

  // FIBONACCI_SIZES aliases SIZING
  assert.strictEqual(FIBONACCI_SIZES, SIZING, 'FIBONACCI_SIZES aliases SIZING');

  // POOL_SIZES
  assert.strictEqual(POOL_SIZES.min, 2, 'fib(3)');
  assert.strictEqual(POOL_SIZES.max, 13, 'fib(7)');
  assert.strictEqual(POOL_SIZES.LARGE, 21, 'fib(8)');

  // RELEVANCE_GATES
  assert(Math.abs(RELEVANCE_GATES.include - PSI_SQ) < EPS, 'include ≈ ψ²');
  assert(Math.abs(RELEVANCE_GATES.boost - PSI) < EPS, 'boost ≈ ψ');
  assert(RELEVANCE_GATES.inject > RELEVANCE_GATES.boost, 'inject > boost');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 12. SERVICE PORTS
// ═══════════════════════════════════════════════════════════

function testServicePorts() {
  assert(SERVICE_PORTS, 'SERVICE_PORTS should be defined');

  // All ports in range 3310-3396
  const ports = Object.values(SERVICE_PORTS);
  for (const port of ports) {
    if (typeof port === 'number') {
      assert(port >= 3310 && port <= 3396, `Port ${port} out of range 3310-3396`);
    }
  }

  // No duplicate ports
  const numPorts = ports.filter(p => typeof p === 'number');
  const uniquePorts = new Set(numPorts);
  assert.strictEqual(uniquePorts.size, numPorts.length, 'No duplicate ports');

  // Key services
  assert.strictEqual(SERVICE_PORTS.HEADY_AUTH, 3350);
  assert.strictEqual(SERVICE_PORTS.HEADY_CONDUCTOR, 3330);
  assert.strictEqual(SERVICE_PORTS.HEADY_SOUL, 3333);
  assert.strictEqual(SERVICE_PORTS.HEADYME_COM, 3371);
  assert.strictEqual(SERVICE_PORTS.HEADYSYSTEMS_COM, 3372);
  assert.strictEqual(SERVICE_PORTS.HEADYCONNECTION_ORG, 3375);

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 13. HNSW PARAMETERS
// ═══════════════════════════════════════════════════════════

function testHNSWParams() {
  assert.strictEqual(HNSW_PARAMS.M, 21, 'HNSW M = fib(8)');
  assert.strictEqual(HNSW_PARAMS.EF_CONSTRUCTION, 144, 'ef_construction = fib(12)');
  assert.strictEqual(HNSW_PARAMS.EF_SEARCH, 89, 'ef_search = fib(11)');
  assert.strictEqual(HNSW_PARAMS.DIMENSIONS, 384, 'dimensions = EMBEDDING_DIM');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 14. TIMING CONSTANTS
// ═══════════════════════════════════════════════════════════

function testTiming() {
  assert.strictEqual(TIMING.HEARTBEAT_MS, 13000, 'fib(7)*1000');
  assert.strictEqual(TIMING.HEALTH_CHECK_MS, 34000, 'fib(9)*1000');
  assert.strictEqual(TIMING.DRIFT_CHECK_MS, 89000, 'fib(11)*1000');
  assert.strictEqual(TIMING.CACHE_TTL_MS, 233000, 'fib(13)*1000');
  assert.strictEqual(TIMING.SESSION_TTL_MS, 1597000, 'fib(17)*1000');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 15. COLAB RUNTIMES
// ═══════════════════════════════════════════════════════════

function testColabRuntimes() {
  assert.strictEqual(COLAB_RUNTIMES.COUNT, 3, '3 Colab Pro+ memberships');
  assert.strictEqual(COLAB_RUNTIMES.GPU_MEMORY_GB, 55, 'fib(10)');
  assert.strictEqual(COLAB_RUNTIMES.MAX_CONCURRENT_TASKS, 21, 'fib(8)');
  assert.strictEqual(COLAB_RUNTIMES.BATCH_SIZE, 34, 'fib(9)');
  assert.strictEqual(COLAB_RUNTIMES.VECTOR_CACHE_SIZE, 6765, 'fib(20)');
  assert.strictEqual(COLAB_RUNTIMES.EMBEDDING_BATCH, 144, 'fib(12)');
  assert.strictEqual(COLAB_RUNTIMES.CHECKPOINT_INTERVAL_S, 233, 'fib(13)');

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// 16. UTILITIES
// ═══════════════════════════════════════════════════════════

function testUtilities() {
  // phiMultiSplit — divide a whole into phi-weighted parts
  const splits = phiMultiSplit(1000, 3);
  assert.strictEqual(splits.length, 3, '3-way split');
  const total = splits.reduce((a, b) => a + b, 0);
  assert(Math.abs(total - 1000) < 2, 'Splits sum ≈ whole');
  assert(splits[0] > splits[1], 'First split is largest');
  assert(splits[1] > splits[2], 'Decreasing order');

  // PIPELINE_STAGE_COUNT
  assert.strictEqual(PIPELINE_STAGE_COUNT, 21, 'fib(8)');

  // RESOURCE_ALLOCATION
  assert.strictEqual(RESOURCE_ALLOCATION.HOT, 0.34);
  assert.strictEqual(RESOURCE_ALLOCATION.WARM, 0.21);
  assert.strictEqual(RESOURCE_ALLOCATION.COLD, 0.13);

  return 'PASS';
}

// ═══════════════════════════════════════════════════════════
// TEST RUNNER
// ═══════════════════════════════════════════════════════════

function runAllTests() {
  const tests = [
    ['Core Constants', testCoreConstants],
    ['Fibonacci Sequence', testFibonacci],
    ['CSL Thresholds', testCSLThresholds],
    ['Pressure Levels', testPressureLevels],
    ['Alert Thresholds', testAlertThresholds],
    ['Fusion & Scoring', testFusionScoring],
    ['Phi-Backoff', testPhiBackoff],
    ['Token Budgets', testTokenBudgets],
    ['CSL Gate Operations', testCSLGates],
    ['CSL Vector Operations', testCSLVectorOps],
    ['Sizing Constants', testSizing],
    ['Service Ports', testServicePorts],
    ['HNSW Parameters', testHNSWParams],
    ['Timing Constants', testTiming],
    ['Colab Runtimes', testColabRuntimes],
    ['Utilities', testUtilities],
  ];

  let passed = 0;
  let failed = 0;
  let skipped = 0;
  const results = [];

  for (const [name, testFn] of tests) {
    try {
      const result = testFn();
      if (result === 'SKIP') {
        skipped++;
        results.push({ name, status: 'SKIP' });
      } else {
        passed++;
        results.push({ name, status: 'PASS' });
      }
    } catch (error) {
      failed++;
      results.push({ name, status: 'FAIL', error: error.message });
    }
  }

  const summary = {
    total: tests.length,
    passed,
    failed,
    skipped,
    results,
  };

  process.stdout.write(JSON.stringify(summary, null, 2) + '\n');

  if (failed > 0) {
    process.exit(1);
  }
}

runAllTests();
