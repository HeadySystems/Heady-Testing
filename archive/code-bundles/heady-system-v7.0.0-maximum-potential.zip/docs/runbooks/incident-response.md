# Runbook: Incident Response

## Overview
This runbook covers manual incident response procedures when automated self-healing is insufficient or has been escalated to human review.

## Severity Levels (Phi-Derived)

| Level | Threshold | Response Time | Escalation |
|-------|-----------|---------------|------------|
| SEV-1 Critical | similarity < 0.500 | Immediate | Eric Haywood + On-call |
| SEV-2 High | similarity < 0.691 | 15 min | On-call engineer |
| SEV-3 Medium | similarity < 0.809 | 1 hour | Automated handling |
| SEV-4 Low | similarity < 0.882 | Next sprint | Pattern logging only |

## Step 1: Assess

```bash
# Check overall system health
curl -s http://localhost:3310/health | jq .

# Check HeadyPatterns for recent drift events
curl -s http://localhost:3310/api/patterns/trend | jq .

# Check HeadyMC for recommended strategy
curl -s http://localhost:3310/api/mc/recommend | jq .
```

## Step 2: Isolate

If the affected component is a service:
```bash
# Check which service is affected
curl -s http://localhost:3310/api/conductor/status | jq '.nodes | map(select(.health < 0.691))'

# Quarantine the service (removes from load balancer)
curl -X POST http://localhost:3310/api/conductor/quarantine -d '{"nodeId": "AFFECTED_NODE"}'
```

If the affected component is a website (ports 3371-3379):
```bash
# Check website health
for port in 3371 3372 3373 3374 3375 3376 3377 3378 3379; do
  echo "Port $port: $(curl -s -o /dev/null -w '%{http_code}' http://localhost:$port/health)"
done
```

## Step 3: Diagnose

```bash
# Get HeadyAutobiographer recent events
curl -s http://localhost:3310/api/autobiographer/recent?limit=21 | jq .

# Check Prometheus alerts
curl -s http://localhost:9090/api/v1/alerts | jq '.data.alerts | map(select(.state == "firing"))'

# Check NATS JetStream backpressure
curl -s http://localhost:8222/jsz | jq .
```

## Step 4: Remediate

### Option A: Service Restart
```bash
# Docker restart
docker compose restart heady-SERVICE_NAME

# Kubernetes restart
kubectl rollout restart deployment/heady-SERVICE_NAME -n heady
```

### Option B: Rollback
```bash
# Check recent deployments
curl -s http://localhost:3310/api/liquid-deploy/history | jq '.[0:5]'

# Rollback last deployment
curl -X POST http://localhost:3310/api/liquid-deploy/rollback -d '{"manifestId": "MANIFEST_ID"}'
```

### Option C: Scale Out
```bash
# Kubernetes scale
kubectl scale deployment/heady-SERVICE_NAME --replicas=3 -n heady

# Docker scale
docker compose up -d --scale heady-SERVICE_NAME=3
```

## Step 5: Verify

```bash
# Run HeadyCheck on affected outputs
curl -s http://localhost:3310/api/check/verify -d '{"outputId": "AFFECTED_OUTPUT"}'

# Run HeadyAssure certification
curl -s http://localhost:3310/api/assure/certify -d '{"deploymentId": "DEPLOYMENT_ID"}'

# Check overall health again
curl -s http://localhost:3310/health | jq .
```

## Step 6: Post-Mortem

1. Check HeadyPatterns for the incident pattern
2. Verify the pattern was recorded for future prevention
3. Check if HeadyMC recommended the correct strategy
4. Update this runbook if new procedures were needed
5. Record in HeadyAutobiographer narrative

## Contacts
- **Founder/Chief Architect**: Eric Haywood (eric@headyconnection.org)
- **Automated Escalation**: HeadySoul → HeadyConductor → Notification Service
