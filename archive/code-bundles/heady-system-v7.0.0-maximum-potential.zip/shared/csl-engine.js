/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ CSL Engine — Continuous Semantic Logic
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Geometric AI: vector operations as logical gates.
 * 60+ provisional patents covering CSL operations.
 *
 * © 2026 HeadySystems Inc. — Eric Haywood
 */

'use strict';

const { PHI, PSI, PSI2, CSL_THRESHOLDS, cosineSimilarity, normalize } = require('./phi-math');

// ─── Core CSL Operations ─────────────────────────────────────────────────────

/** CSL AND — cosine similarity (geometric conjunction) */
function cslAND(a, b) { return cosineSimilarity(a, b); }

/** CSL OR — superposition (vector addition + normalize) */
function cslOR(a, b) {
  const result = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) result[i] = a[i] + b[i];
  return normalize(result);
}

/** CSL NOT — orthogonal projection removal */
function cslNOT(vec, removeVec) {
  const sim = cosineSimilarity(vec, removeVec);
  const result = new Float64Array(vec.length);
  for (let i = 0; i < vec.length; i++) result[i] = vec[i] - sim * removeVec[i];
  return normalize(result);
}

/** CSL IMPLY — projection (a implies b = project a onto b) */
function cslIMPLY(a, b) {
  const dot = cosineSimilarity(a, b);
  const result = new Float64Array(b.length);
  for (let i = 0; i < b.length; i++) result[i] = dot * b[i];
  return result;
}

/** CSL XOR — symmetric difference */
function cslXOR(a, b) {
  const aNotB = cslNOT(a, b);
  const bNotA = cslNOT(b, a);
  return cslOR(aNotB, bNotA);
}

/** CSL CONSENSUS — weighted average of multiple vectors */
function cslCONSENSUS(vectors, weights = null) {
  if (vectors.length === 0) return null;
  const dim = vectors[0].length;
  const result = new Float64Array(dim);
  const w = weights || vectors.map(() => 1 / vectors.length);
  for (let i = 0; i < vectors.length; i++) {
    for (let j = 0; j < dim; j++) {
      result[j] += vectors[i][j] * w[i];
    }
  }
  return normalize(result);
}

// ─── Gate Operations ─────────────────────────────────────────────────────────

/** Resonance gate — sigmoid activation around threshold */
function resonanceGate(cosScore, tau = CSL_THRESHOLDS.LOW, temp = 0.1) {
  return 1 / (1 + Math.exp(-(cosScore - tau) / temp));
}

/** Soft gate — continuous activation */
function softGate(value, center = 0.5, steepness = 10) {
  return 1 / (1 + Math.exp(-steepness * (value - center)));
}

/** Ternary gate — classify into +1/0/-1 */
function ternaryGate(value, highThreshold = 0.7, lowThreshold = 0.3) {
  const highActivation = softGate(value, highThreshold, 10);
  const lowActivation = softGate(value, lowThreshold, 10);
  if (highActivation > CSL_THRESHOLDS.MEDIUM) return { state: 1, resonanceActivation: highActivation };
  if (lowActivation < 1 - CSL_THRESHOLDS.MEDIUM) return { state: -1, resonanceActivation: 1 - lowActivation };
  return { state: 0, resonanceActivation: lowActivation };
}

/** Route gate — score candidates and select best */
function routeGate(intentVec, candidates, threshold = CSL_THRESHOLDS.LOW) {
  const scores = candidates.map(c => {
    const sim = cosineSimilarity(intentVec, c.vector);
    const activation = resonanceGate(sim, threshold);
    return { id: c.id, score: sim, activation };
  });
  scores.sort((a, b) => b.score - a.score);
  const best = scores[0] || null;
  return { scores, best, fallback: best ? best.score < threshold : true };
}

/** Multi-resonance — score intent against multiple targets */
function multiResonance(intentVec, targetVecs, threshold = CSL_THRESHOLDS.LOW) {
  return targetVecs.map((vec, index) => {
    const score = cosineSimilarity(intentVec, vec);
    return { index, score, activation: resonanceGate(score, threshold) };
  }).sort((a, b) => b.score - a.score);
}

/** Weighted superposition — blend two vectors with weight */
function weightedSuperposition(a, b, weightA = PSI) {
  const result = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) result[i] = a[i] * weightA + b[i] * (1 - weightA);
  return normalize(result);
}

/** Consensus superposition — average all vectors */
function consensusSuperposition(vectors) {
  return cslCONSENSUS(vectors);
}

/** Batch orthogonal — remove influence of multiple vectors */
function batchOrthogonal(vec, removeVecs) {
  let result = vec;
  for (const rv of removeVecs) result = cslNOT(result, rv);
  return result;
}

// ─── Stats ───────────────────────────────────────────────────────────────────

let _stats = { gateEvals: 0, cslOps: 0 };

function getStats() {
  return { ..._stats };
}

function resetStats() {
  _stats = { gateEvals: 0, cslOps: 0 };
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  cslAND, cslOR, cslNOT, cslIMPLY, cslXOR, cslCONSENSUS,
  resonanceGate, softGate, ternaryGate, routeGate,
  multiResonance, weightedSuperposition, consensusSuperposition,
  batchOrthogonal,
  getStats, resetStats,
  // Re-exports for convenience
  normalize, cosineSimilarity,
};
