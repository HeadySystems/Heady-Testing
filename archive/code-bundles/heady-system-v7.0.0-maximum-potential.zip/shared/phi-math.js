/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Phi-Math Foundation v6.0.0
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * ALL numeric constants derive from φ (golden ratio) and Fibonacci sequences.
 * ZERO magic numbers. Every value has a mathematical derivation.
 *
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder/Chief Architect
 * Sacred Geometry :: Organic Systems :: Breathing Interfaces
 * 60+ Provisional Patents
 */

'use strict';

// ─── Core Constants ──────────────────────────────────────────────────────────

const PHI  = (1 + Math.sqrt(5)) / 2;         // φ ≈ 1.6180339887
const PSI  = 1 / PHI;                         // ψ ≈ 0.6180339887
const PHI2 = PHI + 1;                         // φ² ≈ 2.6180339887
const PHI3 = 2 * PHI + 1;                     // φ³ ≈ 4.2360679775
const PHI4 = 3 * PHI + 2;                     // φ⁴ ≈ 6.8541019662
const PHI5 = 5 * PHI + 3;                     // φ⁵ ≈ 11.0901699437
const PHI6 = 8 * PHI + 5;                     // φ⁶ ≈ 17.9442719100
const PHI7 = 13 * PHI + 8;                    // φ⁷ ≈ 29.0344418537
const PSI2 = PSI * PSI;                       // ψ² ≈ 0.3819660113
const PSI3 = PSI * PSI * PSI;                 // ψ³ ≈ 0.2360679775
const PSI4 = Math.pow(PSI, 4);                // ψ⁴ ≈ 0.1458980338

// ─── Fibonacci Sequence ──────────────────────────────────────────────────────

const FIB_CACHE = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377,
  610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025];

function fib(n) {
  if (n < FIB_CACHE.length) return FIB_CACHE[n];
  let a = FIB_CACHE[FIB_CACHE.length - 2];
  let b = FIB_CACHE[FIB_CACHE.length - 1];
  for (let i = FIB_CACHE.length; i <= n; i++) {
    [a, b] = [b, a + b];
    FIB_CACHE[i] = b;
  }
  return FIB_CACHE[n];
}

// ─── Phi-Harmonic Thresholds ─────────────────────────────────────────────────

function phiThreshold(level, spread = 0.5) {
  return 1 - Math.pow(PSI, level) * spread;
}

const CSL_THRESHOLDS = Object.freeze({
  MINIMUM:  phiThreshold(0),   // ≈ 0.500
  LOW:      phiThreshold(1),   // ≈ 0.691
  MEDIUM:   phiThreshold(2),   // ≈ 0.809
  HIGH:     phiThreshold(3),   // ≈ 0.882
  CRITICAL: phiThreshold(4),   // ≈ 0.927
  DEDUP:    1 - Math.pow(PSI, 6) * 0.5, // ≈ 0.972
});

// ─── Pressure Levels ─────────────────────────────────────────────────────────

const PRESSURE_LEVELS = Object.freeze({
  NOMINAL:  { min: 0,    max: PSI2 },          // 0 – 0.382
  ELEVATED: { min: PSI2, max: PSI },            // 0.382 – 0.618
  HIGH:     { min: PSI,  max: 1 - PSI3 },       // 0.618 – 0.764
  CRITICAL: { min: 1 - PSI4, max: 1.0 },        // 0.854 – 1.0
});

// ─── Alert Thresholds ────────────────────────────────────────────────────────

const ALERT_THRESHOLDS = Object.freeze({
  WARNING:  PSI,           // ≈ 0.618
  CAUTION:  1 - PSI2,      // ≈ 0.618 (adjusted)
  CRITICAL: 1 - PSI3,      // ≈ 0.764
  EXCEEDED: 1 - PSI4,      // ≈ 0.854
  HARD_MAX: 1.0,
});

// ─── Eviction Weights (φ-normalized) ─────────────────────────────────────────

const EVICTION_WEIGHTS = Object.freeze({
  importance: PSI2 + PSI3 / 2,    // ≈ 0.500
  recency:    PSI3 + PSI4 / 2,    // ≈ 0.309
  relevance:  PSI4,                // ≈ 0.191
});

// ─── Phi-Scaled Functions ────────────────────────────────────────────────────

function phiBackoff(attempt, baseMs = 1000, maxMs = 60000) {
  const delay = baseMs * Math.pow(PHI, attempt);
  const jitter = delay * PSI2 * (Math.random() * 2 - 1);
  return Math.min(Math.round(delay + jitter), maxMs);
}

function phiFusionWeights(n) {
  if (n <= 0) return [];
  if (n === 1) return [1.0];
  const raw = [];
  for (let i = 0; i < n; i++) raw.push(Math.pow(PSI, i));
  const sum = raw.reduce((a, b) => a + b, 0);
  return raw.map(w => w / sum);
}

function phiResourceWeights(n) {
  return phiFusionWeights(n);
}

function phiTokenBudgets(base = 8192) {
  return {
    working:    base,
    session:    Math.round(base * PHI2),
    memory:     Math.round(base * PHI4),
    artifacts:  Math.round(base * PHI6),
  };
}

function phiPriorityScore(...factors) {
  const weights = phiFusionWeights(factors.length);
  return factors.reduce((sum, f, i) => sum + f * weights[i], 0);
}

function phiMultiSplit(whole, n) {
  const weights = phiFusionWeights(n);
  return weights.map(w => Math.round(whole * w));
}

// ─── CSL Gate Functions ──────────────────────────────────────────────────────

function cslGate(value, cosScore, tau = CSL_THRESHOLDS.LOW, temp = 0.1) {
  const activation = 1 / (1 + Math.exp(-(cosScore - tau) / temp));
  return value * activation;
}

function cslBlend(weightHigh, weightLow, cosScore, tau = CSL_THRESHOLDS.MEDIUM) {
  const t = Math.max(0, Math.min(1, (cosScore - tau + 0.5)));
  return weightHigh * t + weightLow * (1 - t);
}

function adaptiveTemperature(entropy, maxEntropy = Math.log(100)) {
  return 0.1 + (entropy / maxEntropy) * (PHI - 0.1);
}

// ─── Vector Operations ───────────────────────────────────────────────────────

function cosineSimilarity(a, b) {
  if (a.length !== b.length) return 0;
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  return denom === 0 ? 0 : dot / denom;
}

function normalize(vec) {
  let mag = 0;
  for (let i = 0; i < vec.length; i++) mag += vec[i] * vec[i];
  mag = Math.sqrt(mag);
  if (mag === 0) return new Float64Array(vec.length);
  const result = new Float64Array(vec.length);
  for (let i = 0; i < vec.length; i++) result[i] = vec[i] / mag;
  return result;
}

function topK(queryVec, items, k = 10) {
  const scored = items.map(item => ({
    id: item.id,
    score: cosineSimilarity(queryVec, item.vector),
  }));
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, k);
}

// CSL AND = cosine similarity (geometric AND)
function cslAND(a, b) { return cosineSimilarity(a, b); }

// CSL OR = superposition (vector addition + normalize)
function cslOR(a, b) {
  const result = new Float64Array(a.length);
  for (let i = 0; i < a.length; i++) result[i] = a[i] + b[i];
  return normalize(result);
}

// CSL NOT = orthogonal projection removal
function cslNOT(vec, removeVec) {
  const dot = cosineSimilarity(vec, removeVec);
  const result = new Float64Array(vec.length);
  for (let i = 0; i < vec.length; i++) result[i] = vec[i] - dot * removeVec[i];
  return normalize(result);
}

// ─── Colab Runtime Configuration (4 Pro+ Runtimes) ──────────────────────────

const COLAB_RUNTIMES = Object.freeze({
  ALPHA: {
    name: 'Alpha',
    envVar: 'COLAB_ALPHA_URL',
    role: 'embedding-inference',
    description: 'Primary embedding and fast inference runtime',
    gpuAllocation: PHI / (PHI + 1 + PSI + PSI2),   // φ-weighted largest share
    priority: CSL_THRESHOLDS.CRITICAL,
    capabilities: ['embedding', 'inference', 'classification', 'similarity'],
  },
  BETA: {
    name: 'Beta',
    envVar: 'COLAB_BETA_URL',
    role: 'training-finetuning',
    description: 'Model training and fine-tuning runtime',
    gpuAllocation: 1 / (PHI + 1 + PSI + PSI2),     // second share
    priority: CSL_THRESHOLDS.HIGH,
    capabilities: ['training', 'finetuning', 'evaluation', 'rl'],
  },
  GAMMA: {
    name: 'Gamma',
    envVar: 'COLAB_GAMMA_URL',
    role: 'vector-space-ops',
    description: 'Vector space operations and spatial memory',
    gpuAllocation: PSI / (PHI + 1 + PSI + PSI2),    // third share
    priority: CSL_THRESHOLDS.MEDIUM,
    capabilities: ['vector-ops', 'spatial-memory', 'graph-rag', 'clustering'],
  },
  DELTA: {
    name: 'Delta',
    envVar: 'COLAB_DELTA_URL',
    role: 'monte-carlo-simulation',
    description: 'Monte Carlo simulation and batch processing',
    gpuAllocation: PSI2 / (PHI + 1 + PSI + PSI2),   // smallest share
    priority: CSL_THRESHOLDS.LOW,
    capabilities: ['monte-carlo', 'batch-processing', 'analytics', 'optimization'],
  },
});

// ─── Service Port Registry ───────────────────────────────────────────────────

const BASE_PORT = 3300;
const SERVICE_PORTS = Object.freeze({
  'heady-manager':       BASE_PORT,       // 3300 — API Gateway
  'heady-conductor':     BASE_PORT + 1,   // 3301
  'heady-registry':      BASE_PORT + 2,   // 3302
  'ai-router':           BASE_PORT + 10,  // 3310
  'billing-service':     BASE_PORT + 11,  // 3311
  'budget-tracker':      BASE_PORT + 12,  // 3312
  'discord-bot':         BASE_PORT + 13,  // 3313
  'heady-chain':         BASE_PORT + 14,  // 3314
  'heady-eval':          BASE_PORT + 15,  // 3315
  'heady-federation':    BASE_PORT + 16,  // 3316
  'heady-guard':         BASE_PORT + 17,  // 3317
  'heady-hive':          BASE_PORT + 18,  // 3318
  'heady-infer':         BASE_PORT + 19,  // 3319
  'heady-midi':          BASE_PORT + 20,  // 3320
  'heady-onboarding':    BASE_PORT + 21,  // 3321
  'heady-pilot-onboard': BASE_PORT + 22,  // 3322
  'heady-projection':    BASE_PORT + 23,  // 3323
  'heady-task-browser':  BASE_PORT + 24,  // 3324
  'heady-testing':       BASE_PORT + 25,  // 3325
  'heady-ui':            BASE_PORT + 26,  // 3326
  'heady-vector':        BASE_PORT + 27,  // 3327
  'heady-web':           BASE_PORT + 28,  // 3328
  'huggingface-gateway': BASE_PORT + 29,  // 3329
  'jules-mcp':           BASE_PORT + 30,  // 3330
  'memory-mcp':          BASE_PORT + 31,  // 3331
  'model-gateway':       BASE_PORT + 32,  // 3332
  'perplexity-mcp':      BASE_PORT + 33,  // 3333
  'prompt-manager':      BASE_PORT + 34,  // 3334
  'search-service':      BASE_PORT + 35,  // 3335
  'secret-gateway':      BASE_PORT + 36,  // 3336
  'silicon-bridge':      BASE_PORT + 37,  // 3337
  'auth-session':        BASE_PORT + 40,  // 3340
  'notification':        BASE_PORT + 41,  // 3341
  'scheduler':           BASE_PORT + 42,  // 3342
  'analytics':           BASE_PORT + 43,  // 3343
  'backup':              BASE_PORT + 44,  // 3344
  'rate-limiter':        BASE_PORT + 45,  // 3345
  'health-registry':     BASE_PORT + 46,  // 3346
  'domain-router':       BASE_PORT + 47,  // 3347
  'continuous-embedder': BASE_PORT + 48,  // 3348
  'observability-kernel':BASE_PORT + 49,  // 3349
  'auto-success-engine': BASE_PORT + 50,  // 3350
  'heady-content-engine':BASE_PORT + 51,  // 3351
  'schema-registry':     BASE_PORT + 52,  // 3352
  'spatial-events':      BASE_PORT + 53,  // 3353
  'service-runtime':     BASE_PORT + 54,  // 3354
  'liquid-deploy':       BASE_PORT + 55,  // 3355
  'agent-identity':      BASE_PORT + 56,  // 3356
  'latent-boundary':     BASE_PORT + 57,  // 3357
  'memory-stream':       BASE_PORT + 58,  // 3358
  'hc-supervisor':       BASE_PORT + 59,  // 3359
  'hc-brain':            BASE_PORT + 60,  // 3360
  'hc-checkpoint':       BASE_PORT + 61,  // 3361
  'hc-readiness':        BASE_PORT + 62,  // 3362
  'hc-health':           BASE_PORT + 63,  // 3363
  'config-core':         BASE_PORT + 64,  // 3364
  'contract-types':      BASE_PORT + 65,  // 3365
  'csl-engine':          BASE_PORT + 66,  // 3366
  'csl-gate':            BASE_PORT + 67,  // 3367
  'csl-router':          BASE_PORT + 68,  // 3368
  'kernel':              BASE_PORT + 69,  // 3369
});

// ─── 17 Canonical Swarms ─────────────────────────────────────────────────────

const SWARM_NAMES = Object.freeze([
  'Deploy', 'Battle', 'Research', 'Security', 'Memory',
  'Creative', 'Trading', 'Health', 'Governance', 'Documentation',
  'Testing', 'Migration', 'Monitoring', 'Cleanup', 'Onboarding',
  'Analytics', 'Emergency',
]);

// ─── 9 Websites ──────────────────────────────────────────────────────────────

const SITE_DOMAINS = Object.freeze([
  'headyme.com', 'headysystems.com', 'heady-ai.com', 'headyos.com',
  'headyconnection.org', 'headyconnection.com', 'headyex.com',
  'headyfinance.com', 'admin.headysystems.com',
]);

// ─── 7 Cognitive Archetypes ──────────────────────────────────────────────────

const COGNITIVE_ARCHETYPES = Object.freeze({
  OWL:      { name: 'Wisdom',        icon: '🦉', layer: 'deep-knowledge',       threshold: CSL_THRESHOLDS.HIGH },
  EAGLE:    { name: 'Omniscience',   icon: '🦅', layer: 'panoramic-awareness',  threshold: CSL_THRESHOLDS.HIGH },
  DOLPHIN:  { name: 'Creativity',    icon: '🐬', layer: 'lateral-thinking',     threshold: CSL_THRESHOLDS.MEDIUM },
  RABBIT:   { name: 'Multiplication', icon: '🐇', layer: 'solution-space',      threshold: CSL_THRESHOLDS.MEDIUM },
  ANT:      { name: 'Repetition',    icon: '🐜', layer: 'relentless-execution', threshold: CSL_THRESHOLDS.LOW },
  ELEPHANT: { name: 'Memory',        icon: '🐘', layer: 'perfect-recall',       threshold: CSL_THRESHOLDS.HIGH },
  BEAVER:   { name: 'Structure',     icon: '🦫', layer: 'methodical-build',     threshold: CSL_THRESHOLDS.MEDIUM },
});

// ─── Auto-Success Engine Constants ───────────────────────────────────────────

const AUTO_SUCCESS = Object.freeze({
  CYCLE_MS:       Math.round(PHI7 * 1000),  // φ⁷ × 1000 ≈ 29,034ms
  TASK_TIMEOUT_MS: Math.round(PHI3 * 1000),  // φ³ × 1000 ≈ 4,236ms
  MAX_RETRIES:     fib(4),                    // 3
  MAX_TOTAL_RETRY: fib(6),                    // 8
  CATEGORIES:      fib(7),                    // 13 CSL-discovered categories
  TIER_WEIGHTS: {
    critical: PSI2,                           // ≈ 0.382
    high:     PSI3 + PSI4 / 2,               // ≈ 0.309
    standard: PSI3,                           // ≈ 0.236
    growth:   PSI4 + PSI4 * PSI / 2,         // ≈ 0.191
  },
});

// ─── HCFullPipeline Stages ───────────────────────────────────────────────────

const HCFP_STAGES = Object.freeze([
  'CHANNEL_ENTRY', 'RECON', 'INTAKE', 'CLASSIFY', 'TRIAGE',
  'DECOMPOSE', 'TRIAL_AND_ERROR', 'ORCHESTRATE', 'MONTE_CARLO', 'ARENA',
  'JUDGE', 'APPROVE', 'EXECUTE', 'VERIFY', 'SELF_AWARENESS',
  'SELF_CRITIQUE', 'MISTAKE_ANALYSIS', 'OPTIMIZATION_OPS',
  'CONTINUOUS_SEARCH', 'EVOLUTION', 'RECEIPT',
]); // 21 stages = fib(8)

// ─── Backward-Compat Aliases & Legacy Constants ───────────────────────────

const PHI_SQ = PHI2;
const PHI_CUBE = PHI3;
const PHI_FOURTH = PHI4;
const PSI_SQ = PSI2;
const PSI_CUBE = PSI3;
const PSI_FOURTH = PSI4;
const FIB = FIB_CACHE;
const fibonacci = fib;

function nearestFib(n) {
  let prev = 0, curr = 1;
  while (curr < n) { [prev, curr] = [curr, prev + curr]; }
  return (n - prev <= curr - n) ? prev : curr;
}

const DEDUP_THRESHOLD = 1 - Math.pow(PSI, 6) * 0.5; // phiThreshold(6) ≈ 0.972
const COHERENCE_DRIFT_THRESHOLD = CSL_THRESHOLDS.MEDIUM; // ≈ 0.809

// Lowercase alert aliases for backward compat
const ALERT_THRESHOLDS_COMPAT = Object.freeze({
  ...ALERT_THRESHOLDS,
  warning:  ALERT_THRESHOLDS.WARNING,
  caution:  ALERT_THRESHOLDS.CAUTION,
  critical: ALERT_THRESHOLDS.CRITICAL,
  exceeded: ALERT_THRESHOLDS.EXCEEDED,
  hard_max: ALERT_THRESHOLDS.HARD_MAX,
});

// Legacy timing constants (phi-derived, all in ms)
const TIMING = Object.freeze({
  HEARTBEAT_MS:       fib(8) * 1000,         // 21s
  HEALTH_CHECK_MS:    fib(9) * 1000,         // 34s
  SESSION_TTL_MS:     fib(17) * 100,         // ~159.7s ≈ 2.66min
  CACHE_TTL_MS:       fib(17) * 1000,        // ~1597s ≈ 26.6min
  HOT_TIMEOUT_MS:     fib(9) * 1000,         // 34s
  WARM_TIMEOUT_MS:    fib(12) * 1000,        // 144s
  COLD_TIMEOUT_MS:    fib(14) * 1000,        // 377s
  RECONNECT_BASE_MS:  fib(7) * 1000,         // 13s
  FLUSH_INTERVAL_MS:  fib(10) * 1000,        // 55s
});

// Legacy pool sizes (Fibonacci-derived)
const POOL_SIZES = Object.freeze({
  HOT:       fib(7),   // 13
  WARM:      fib(8),   // 21
  COLD:      fib(9),   // 34
  RESERVE:   fib(6),   // 8
  MAX_TOTAL: fib(11),  // 89
});

// Embedding dimension
const EMBEDDING_DIM = 384;

// Resource allocation (phi-weighted)
const RESOURCE_ALLOCATION = Object.freeze({
  HOT:        0.34,
  WARM:       0.21,
  COLD:       0.13,
  RESERVE:    0.08,
  GOVERNANCE: 0.05,
});

// Pipeline stage count
const PIPELINE_STAGE_COUNT = 21; // fib(8)

// Fibonacci size presets
const FIBONACCI_SIZES = Object.freeze({
  XS: fib(5),    // 5
  S:  fib(6),    // 8
  M:  fib(7),    // 13
  L:  fib(8),    // 21
  XL: fib(9),    // 34
  XXL: fib(10),  // 55
});

// Circuit breaker defaults
const CIRCUIT_BREAKER = Object.freeze({
  FAILURE_THRESHOLD:   fib(5),  // 5 failures to open
  HALF_OPEN_LIMIT:     fib(3),  // 2 test requests
  RESET_TIMEOUT_MS:    fib(9) * 1000, // 34s
  MONITOR_WINDOW_MS:   fib(10) * 1000, // 55s
});

// CSL gate temperature
const PHI_TEMPERATURE = PSI3; // ≈ 0.236

// Context compression trigger
const COMPRESSION_TRIGGER = 1 - PSI4; // ≈ 0.910

// HNSW index parameters (Fibonacci-derived)
const HNSW = Object.freeze({
  M:               fib(8),   // 21
  EF_CONSTRUCTION: fib(12),  // 144
  EF_SEARCH:       fib(11),  // 89
});

// Phi fusion score (sum fusion with phi weighting)
function phiFusionScore(factors) {
  const w = phiFusionWeights(factors.length);
  return factors.reduce((acc, f, i) => acc + f * w[i], 0);
}

// Get pressure level from a ratio (0-1)
function getPressureLevel(ratio) {
  if (ratio >= PRESSURE_LEVELS.CRITICAL.min) return 'CRITICAL';
  if (ratio >= PRESSURE_LEVELS.HIGH.min) return 'HIGH';
  if (ratio >= PRESSURE_LEVELS.ELEVATED.min) return 'ELEVATED';
  return 'NOMINAL';
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  // Core constants
  PHI, PSI, PHI2, PHI3, PHI4, PHI5, PHI6, PHI7,
  PSI2, PSI3, PSI4,
  PHI_SQ, PHI_CUBE, PHI_FOURTH, PSI_SQ, PSI_CUBE, PSI_FOURTH, // backward-compat aliases
  
  // Fibonacci
  fib, FIB_CACHE, FIB, fibonacci, nearestFib,
  
  // Thresholds & Levels
  CSL_THRESHOLDS, PRESSURE_LEVELS,
  ALERT_THRESHOLDS: ALERT_THRESHOLDS_COMPAT,
  EVICTION_WEIGHTS,
  DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  phiThreshold,
  
  // Phi-scaled functions
  phiBackoff, phiFusionWeights, phiResourceWeights,
  phiTokenBudgets, phiPriorityScore, phiMultiSplit,
  
  // CSL gates
  cslGate, cslBlend, adaptiveTemperature,
  
  // Vector operations
  cosineSimilarity, normalize, topK,
  cslAND, cslOR, cslNOT,
  
  // System architecture
  COLAB_RUNTIMES, SERVICE_PORTS, BASE_PORT,
  SWARM_NAMES, SITE_DOMAINS,
  COGNITIVE_ARCHETYPES,
  AUTO_SUCCESS, HCFP_STAGES,
  
  // Legacy backward-compat constants
  TIMING, POOL_SIZES, EMBEDDING_DIM,
  RESOURCE_ALLOCATION, PIPELINE_STAGE_COUNT,
  FIBONACCI_SIZES, CIRCUIT_BREAKER,
  PHI_TEMPERATURE, COMPRESSION_TRIGGER,
  HNSW,
  phiFusionScore, getPressureLevel,
};
