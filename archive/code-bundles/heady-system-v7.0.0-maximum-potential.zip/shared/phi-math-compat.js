/**
 * Heady™ Phi-Math v5.1 Backward-Compatibility Layer
 * Provides legacy function signatures for modules written against v5.1
 * 
 * @author Eric Haywood — HeadySystems Inc.
 * @license Proprietary — HeadySystems Inc.
 */
'use strict';

const pm = require('./phi-math');

const { PHI, PSI, PSI2, fib } = pm;

// phiBackoff with optional noJitter (4th param)
function phiBackoff(attempt, baseMs = 1000, maxMs = 60000, jitter = true) {
  const delay = baseMs * Math.pow(PHI, attempt);
  if (!jitter) return Math.min(Math.round(delay), maxMs);
  const j = delay * PSI2 * (Math.random() * 2 - 1);
  return Math.min(Math.round(delay + j), maxMs);
}

// phiBackoffWithJitter alias
function phiBackoffWithJitter(attempt, baseMs = 1000, maxMs = 60000) {
  return phiBackoff(attempt, baseMs, maxMs, true);
}

// fibRetryBackoff — Fibonacci-scaled retry delays
function fibRetryBackoff(count, baseMs = 100) {
  const delays = [];
  for (let i = 0; i < count; i++) delays.push(fib(i + 4) * baseMs);
  return delays;
}

// phiAdaptiveInterval
function phiAdaptiveInterval(baseMs, isHealthy, currentMs) {
  return isHealthy
    ? Math.min(currentMs * PHI, baseMs * Math.pow(PHI, 5))
    : Math.max(currentMs * PSI, baseMs);
}

// BACKOFF_SEQUENCE
const BACKOFF_SEQUENCE = [];
for (let i = 0; i < 13; i++) {
  BACKOFF_SEQUENCE.push(Math.round(1000 * Math.pow(PHI, i)));
}
Object.freeze(BACKOFF_SEQUENCE);

// Additional CSL ops
function cslIMPLY(a, b) {
  const dot = a.reduce((s, v, i) => s + v * b[i], 0);
  const normB = Math.sqrt(b.reduce((s, v) => s + v * v, 0));
  if (normB === 0) return new Float64Array(a.length);
  const scale = dot / (normB * normB);
  return b.map(v => v * scale);
}

function cslXOR(a, b) {
  const or = pm.cslOR(a, b);
  const and = pm.cslAND(a, b);
  return or.map((v, i) => v - and * or[i]); 
}

function cslCONSENSUS(vectors) {
  if (!vectors.length) return [];
  const dim = vectors[0].length;
  const sum = new Float64Array(dim);
  vectors.forEach(v => v.forEach((val, i) => sum[i] += val));
  const norm = Math.sqrt(sum.reduce((s, v) => s + v * v, 0));
  return norm > 0 ? sum.map(v => v / norm) : sum;
}

module.exports = {
  ...pm,
  phiBackoff,
  phiBackoffWithJitter,
  fibRetryBackoff,
  phiAdaptiveInterval,
  BACKOFF_SEQUENCE,
  cslIMPLY, cslImply: cslIMPLY,
  cslXOR, cslXor: cslXOR,
  cslCONSENSUS, cslConsensus: cslCONSENSUS,
};
