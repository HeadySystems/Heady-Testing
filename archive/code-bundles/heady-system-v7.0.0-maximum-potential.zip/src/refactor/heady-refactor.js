/**
 * HeadyRefactor — Automated Code Refactoring Engine
 * 
 * Phi-compliance transformation engine that analyzes, scores, and refactors code
 * to meet Heady™ standards. Detects magic numbers, console.log, localStorage usage,
 * non-phi constants, and applies AST-level transformations.
 * 
 * Features:
 * - 14 refactoring rules across 6 categories
 * - Phi-compliance scoring with phiFusionWeights
 * - AST-aware pattern matching and replacement
 * - Batch refactoring with dependency ordering
 * - Before/after diff generation
 * - Undo/rollback support with history buffer
 * 
 * @module heady-refactor
 * @version 1.0.0
 * @author Eric Haywood
 */

const {
  PHI,
  PSI,
  PHI2,
  PHI3,
  fib,
  fibonacci,
  phiThreshold,
  phiFusionWeights,
  phiBackoff,
  CSL_THRESHOLDS,
  PRESSURE_LEVELS,
  SIZING,
  ALERT_THRESHOLDS,
  cslGate,
  cosineSimilarity,
  SERVICE_PORTS
} = require('../../shared/phi-math.js');
const { createLogger } = require('../../shared/logger.js');
const { createHealthCheck } = require('../../shared/health.js');

const logger = createLogger('heady-refactor');

/* ═══════════════════════════════════════════════════════════════
   §1 — Constants (all phi-derived)
   ═══════════════════════════════════════════════════════════════ */

const MAX_HISTORY_BUFFER = fib(16);      // 987 undo entries
const MAX_BATCH_SIZE = fib(10);          // 55 files per batch
const MAX_ISSUES_PER_FILE = fib(12);     // 144 issues before truncation
const SIMILARITY_DEDUP = CSL_THRESHOLDS.CRITICAL; // 0.927 — dedup similar issues
const MIN_CONFIDENCE = CSL_THRESHOLDS.LOW;        // 0.691 — minimum refactor confidence
const HIGH_CONFIDENCE = CSL_THRESHOLDS.HIGH;      // 0.882 — auto-apply threshold
const DIFF_CONTEXT_LINES = fib(5);       // 5 lines of context in diffs
const CACHE_SIZE = fib(17);              // 1597 cached analysis results
const CACHE_TTL_MS = fib(14) * 1000;    // 377 seconds

/** Refactoring categories with phi-weighted importance */
const CATEGORIES = {
  PHI_COMPLIANCE:   { weight: 0.387, label: 'Phi Compliance' },
  SECURITY:         { weight: 0.239, label: 'Security' },
  PERFORMANCE:      { weight: 0.148, label: 'Performance' },
  READABILITY:      { weight: 0.092, label: 'Readability' },
  MAINTAINABILITY:  { weight: 0.057, label: 'Maintainability' },
  ARCHITECTURE:     { weight: 0.038, label: 'Architecture' }
};

/** Magic number detection — known non-phi constants to flag */
const MAGIC_NUMBER_PATTERNS = [
  { pattern: /(?<!\w)(?:100|200|300|400|500|1000|2000|5000|10000)\b/g, severity: 'HIGH', suggestion: 'Replace with fib(n) or phi-derived constant' },
  { pattern: /(?<!\w)0\.(5|6|7|75|8|85|9|95)\b/g, severity: 'MEDIUM', suggestion: 'Replace with phiThreshold(level) or PSI-derived value' },
  { pattern: /(?<!\w)(?:60000|30000|120000|300000)\b/g, severity: 'MEDIUM', suggestion: 'Replace with fib(n) * 1000 for timing constants' }
];

/** 14 Refactoring Rules */
const RULES = [
  // PHI_COMPLIANCE
  {
    id: 'PHI_001',
    category: 'PHI_COMPLIANCE',
    name: 'magic-number-detection',
    description: 'Detects non-phi numeric constants',
    severity: 'HIGH',
    detect: (code) => {
      const issues = [];
      for (const { pattern, severity, suggestion } of MAGIC_NUMBER_PATTERNS) {
        const regex = new RegExp(pattern.source, pattern.flags);
        let match;
        while ((match = regex.exec(code)) !== null) {
          issues.push({
            ruleId: 'PHI_001',
            line: _getLineNumber(code, match.index),
            column: _getColumn(code, match.index),
            value: match[0],
            message: `Magic number ${match[0]} — ${suggestion}`,
            severity,
            autoFixable: false
          });
        }
      }
      return issues;
    }
  },
  {
    id: 'PHI_002',
    category: 'PHI_COMPLIANCE',
    name: 'non-fibonacci-sizing',
    description: 'Detects array/cache/pool sizes that are not Fibonacci numbers',
    severity: 'MEDIUM',
    detect: (code) => {
      const issues = [];
      const fibSet = new Set([1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765]);
      const sizePatterns = [
        /(?:maxSize|capacity|limit|maxEntries|poolSize|bufferSize|cacheSize)\s*[:=]\s*(\d+)/gi,
        /new\s+(?:Array|Map|Set)\((\d+)\)/g,
        /\.slice\(0,\s*(\d+)\)/g
      ];
      for (const pattern of sizePatterns) {
        const regex = new RegExp(pattern.source, pattern.flags);
        let match;
        while ((match = regex.exec(code)) !== null) {
          const num = parseInt(match[1], 10);
          if (num > 1 && !fibSet.has(num)) {
            const nearest = _nearestFib(num);
            issues.push({
              ruleId: 'PHI_002',
              line: _getLineNumber(code, match.index),
              column: _getColumn(code, match.index),
              value: match[0],
              message: `Non-Fibonacci size ${num} — consider fib(${_fibIndex(nearest)}) = ${nearest}`,
              severity: 'MEDIUM',
              autoFixable: true,
              fix: { original: String(num), replacement: `fib(${_fibIndex(nearest)})` }
            });
          }
        }
      }
      return issues;
    }
  },
  {
    id: 'PHI_003',
    category: 'PHI_COMPLIANCE',
    name: 'non-phi-threshold',
    description: 'Detects threshold values not derived from phi',
    severity: 'MEDIUM',
    detect: (code) => {
      const issues = [];
      const thresholdPattern = /(?:threshold|THRESHOLD|minScore|maxScore)\s*[:=]\s*(0\.\d+)/gi;
      const phiValues = new Set(['0.382', '0.500', '0.618', '0.691', '0.764', '0.809', '0.854', '0.882', '0.910', '0.927', '0.972']);
      let match;
      while ((match = thresholdPattern.exec(code)) !== null) {
        const val = parseFloat(match[1]).toFixed(3);
        if (!phiValues.has(val)) {
          const nearest = _nearestPhiThreshold(parseFloat(match[1]));
          issues.push({
            ruleId: 'PHI_003',
            line: _getLineNumber(code, match.index),
            column: _getColumn(code, match.index),
            value: match[0],
            message: `Non-phi threshold ${match[1]} — nearest: phiThreshold(${nearest.level}) ≈ ${nearest.value.toFixed(3)}`,
            severity: 'MEDIUM',
            autoFixable: true,
            fix: { original: match[1], replacement: `phiThreshold(${nearest.level})` }
          });
        }
      }
      return issues;
    }
  },

  // SECURITY
  {
    id: 'SEC_001',
    category: 'SECURITY',
    name: 'console-log-detection',
    description: 'Detects console.log/warn/error usage (must use structured logger)',
    severity: 'HIGH',
    detect: (code) => {
      const issues = [];
      const pattern = /console\.(log|warn|error|info|debug|trace)\s*\(/g;
      let match;
      while ((match = pattern.exec(code)) !== null) {
        issues.push({
          ruleId: 'SEC_001',
          line: _getLineNumber(code, match.index),
          column: _getColumn(code, match.index),
          value: match[0],
          message: `console.${match[1]}() detected — use HeadyLogger structured logging`,
          severity: 'HIGH',
          autoFixable: true,
          fix: {
            original: `console.${match[1]}(`,
            replacement: `logger.${match[1] === 'log' ? 'info' : match[1]}({`
          }
        });
      }
      return issues;
    }
  },
  {
    id: 'SEC_002',
    category: 'SECURITY',
    name: 'localstorage-detection',
    description: 'Detects localStorage/sessionStorage usage (must use httpOnly cookies)',
    severity: 'CRITICAL',
    detect: (code) => {
      const issues = [];
      const pattern = /(?:localStorage|sessionStorage)\.(getItem|setItem|removeItem|clear)\s*\(/g;
      let match;
      while ((match = pattern.exec(code)) !== null) {
        issues.push({
          ruleId: 'SEC_002',
          line: _getLineNumber(code, match.index),
          column: _getColumn(code, match.index),
          value: match[0],
          message: 'localStorage/sessionStorage detected — use __Host-heady_session httpOnly cookie',
          severity: 'CRITICAL',
          autoFixable: false
        });
      }
      return issues;
    }
  },
  {
    id: 'SEC_003',
    category: 'SECURITY',
    name: 'eval-detection',
    description: 'Detects eval() and Function() constructor usage',
    severity: 'CRITICAL',
    detect: (code) => {
      const issues = [];
      const pattern = /(?:^|[^.\w])(?:eval|Function)\s*\(/gm;
      let match;
      while ((match = pattern.exec(code)) !== null) {
        issues.push({
          ruleId: 'SEC_003',
          line: _getLineNumber(code, match.index),
          column: _getColumn(code, match.index),
          value: match[0].trim(),
          message: 'eval()/Function() detected — use safe alternatives',
          severity: 'CRITICAL',
          autoFixable: false
        });
      }
      return issues;
    }
  },
  {
    id: 'SEC_004',
    category: 'SECURITY',
    name: 'hardcoded-secret-detection',
    description: 'Detects potential hardcoded secrets/tokens/keys',
    severity: 'CRITICAL',
    detect: (code) => {
      const issues = [];
      const patterns = [
        /(?:password|secret|token|api_?key|apiKey)\s*[:=]\s*['"][^'"]{8,}['"]/gi,
        /(?:Bearer|Basic)\s+[A-Za-z0-9+/=]{20,}/g
      ];
      for (const pattern of patterns) {
        const regex = new RegExp(pattern.source, pattern.flags);
        let match;
        while ((match = regex.exec(code)) !== null) {
          issues.push({
            ruleId: 'SEC_004',
            line: _getLineNumber(code, match.index),
            column: _getColumn(code, match.index),
            value: match[0].substring(0, 34) + '...',
            message: 'Potential hardcoded secret — use GCP Secret Manager',
            severity: 'CRITICAL',
            autoFixable: false
          });
        }
      }
      return issues;
    }
  },

  // PERFORMANCE
  {
    id: 'PERF_001',
    category: 'PERFORMANCE',
    name: 'sync-io-detection',
    description: 'Detects synchronous I/O operations',
    severity: 'HIGH',
    detect: (code) => {
      const issues = [];
      const pattern = /(?:readFileSync|writeFileSync|existsSync|mkdirSync|statSync|readdirSync)\s*\(/g;
      let match;
      while ((match = pattern.exec(code)) !== null) {
        issues.push({
          ruleId: 'PERF_001',
          line: _getLineNumber(code, match.index),
          column: _getColumn(code, match.index),
          value: match[0],
          message: `Synchronous I/O: ${match[0]} — use async variant`,
          severity: 'HIGH',
          autoFixable: true,
          fix: {
            original: match[0],
            replacement: match[0].replace('Sync', '').replace('(', 'Async(')
          }
        });
      }
      return issues;
    }
  },
  {
    id: 'PERF_002',
    category: 'PERFORMANCE',
    name: 'unbounded-loop-detection',
    description: 'Detects potentially unbounded loops',
    severity: 'MEDIUM',
    detect: (code) => {
      const issues = [];
      const pattern = /while\s*\(\s*true\s*\)/g;
      let match;
      while ((match = pattern.exec(code)) !== null) {
        issues.push({
          ruleId: 'PERF_002',
          line: _getLineNumber(code, match.index),
          column: _getColumn(code, match.index),
          value: match[0],
          message: 'Unbounded while(true) — add phi-scaled iteration limit',
          severity: 'MEDIUM',
          autoFixable: false
        });
      }
      return issues;
    }
  },

  // READABILITY
  {
    id: 'READ_001',
    category: 'READABILITY',
    name: 'todo-detection',
    description: 'Detects TODO/FIXME/HACK comments',
    severity: 'LOW',
    detect: (code) => {
      const issues = [];
      const pattern = /\/\/\s*(TODO|FIXME|HACK|XXX|TEMP)\b[:\s]*(.*)/gi;
      let match;
      while ((match = pattern.exec(code)) !== null) {
        issues.push({
          ruleId: 'READ_001',
          line: _getLineNumber(code, match.index),
          column: _getColumn(code, match.index),
          value: match[0],
          message: `${match[1]} comment found: "${match[2].trim()}" — must be resolved for production`,
          severity: 'LOW',
          autoFixable: false
        });
      }
      return issues;
    }
  },
  {
    id: 'READ_002',
    category: 'READABILITY',
    name: 'long-function-detection',
    description: 'Detects functions exceeding Fibonacci line limit',
    severity: 'LOW',
    detect: (code) => {
      const issues = [];
      const maxLines = fib(11); // 89 lines
      const funcPattern = /(?:function\s+\w+|(?:async\s+)?(?:const|let|var)\s+\w+\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=])\s*=>|\w+\s*\([^)]*\)\s*\{)/g;
      let match;
      while ((match = funcPattern.exec(code)) !== null) {
        const startLine = _getLineNumber(code, match.index);
        const braceDepth = _findFunctionEnd(code, match.index);
        if (braceDepth > maxLines) {
          issues.push({
            ruleId: 'READ_002',
            line: startLine,
            column: 0,
            value: match[0].substring(0, 55),
            message: `Function exceeds fib(11)=${maxLines} lines (${braceDepth} lines) — consider decomposition`,
            severity: 'LOW',
            autoFixable: false
          });
        }
      }
      return issues;
    }
  },

  // MAINTAINABILITY
  {
    id: 'MAINT_001',
    category: 'MAINTAINABILITY',
    name: 'missing-jsdoc',
    description: 'Detects exported functions without JSDoc',
    severity: 'LOW',
    detect: (code) => {
      const issues = [];
      const exportPattern = /export\s+(?:async\s+)?function\s+(\w+)/g;
      let match;
      while ((match = exportPattern.exec(code)) !== null) {
        const before = code.substring(Math.max(0, match.index - 8), match.index);
        if (!before.includes('*/')) {
          issues.push({
            ruleId: 'MAINT_001',
            line: _getLineNumber(code, match.index),
            column: _getColumn(code, match.index),
            value: `export function ${match[1]}`,
            message: `Exported function ${match[1]}() missing JSDoc documentation`,
            severity: 'LOW',
            autoFixable: false
          });
        }
      }
      return issues;
    }
  },
  {
    id: 'MAINT_002',
    category: 'MAINTAINABILITY',
    name: 'missing-error-handling',
    description: 'Detects async functions without try/catch',
    severity: 'MEDIUM',
    detect: (code) => {
      const issues = [];
      const asyncPattern = /async\s+(?:function\s+)?(\w+)\s*\([^)]*\)\s*\{/g;
      let match;
      while ((match = asyncPattern.exec(code)) !== null) {
        const funcBody = _extractFunctionBody(code, match.index + match[0].length - 1);
        if (funcBody && !funcBody.includes('try') && !funcBody.includes('.catch(')) {
          issues.push({
            ruleId: 'MAINT_002',
            line: _getLineNumber(code, match.index),
            column: _getColumn(code, match.index),
            value: `async ${match[1]}`,
            message: `Async function ${match[1]}() lacks error handling — add try/catch or .catch()`,
            severity: 'MEDIUM',
            autoFixable: false
          });
        }
      }
      return issues;
    }
  },

  // ARCHITECTURE
  {
    id: 'ARCH_001',
    category: 'ARCHITECTURE',
    name: 'circular-import-detection',
    description: 'Detects potential circular import patterns',
    severity: 'HIGH',
    detect: (code, filePath) => {
      const issues = [];
      const importPattern = /import\s+.*from\s+['"]([^'"]+)['"]/g;
      const imports = [];
      let match;
      while ((match = importPattern.exec(code)) !== null) {
        imports.push(match[1]);
      }
      // Flag if file imports from a parent directory that likely imports it back
      for (const imp of imports) {
        if (imp.includes('../') && imp.split('../').length > 3) {
          issues.push({
            ruleId: 'ARCH_001',
            line: _getLineNumber(code, code.indexOf(imp)),
            column: 0,
            value: imp,
            message: `Deep relative import (${imp}) — potential circular dependency risk`,
            severity: 'MEDIUM',
            autoFixable: false
          });
        }
      }
      return issues;
    }
  }
];

/* ═══════════════════════════════════════════════════════════════
   §2 — Analysis Engine
   ═══════════════════════════════════════════════════════════════ */

/** LRU analysis cache */
const _analysisCache = new Map();

/**
 * Analyze code for refactoring opportunities
 * @param {string} code - Source code to analyze
 * @param {string} filePath - File path for context
 * @param {object} [options] - Analysis options
 * @returns {object} Analysis result with issues, score, and suggestions
 */
function analyze(code, filePath = 'unknown', options = {}) {
  const {
    categories = Object.keys(CATEGORIES),
    minSeverity = 'LOW',
    maxIssues = MAX_ISSUES_PER_FILE
  } = options;

  const cacheKey = `${filePath}:${_hashCode(code)}`;
  const cached = _analysisCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL_MS) {
    logger.info({ event: 'analysis_cache_hit', filePath });
    return cached.result;
  }

  const severityOrder = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
  const minSev = severityOrder[minSeverity] || 1;

  const allIssues = [];
  const activeRules = RULES.filter(r => categories.includes(r.category));

  for (const rule of activeRules) {
    try {
      const issues = rule.detect(code, filePath);
      for (const issue of issues) {
        if ((severityOrder[issue.severity] || 0) >= minSev) {
          allIssues.push(issue);
        }
      }
    } catch (err) {
      logger.error({ event: 'rule_error', ruleId: rule.id, error: err.message });
    }
  }

  // Sort by severity (highest first), then by line number
  allIssues.sort((a, b) => {
    const sevDiff = (severityOrder[b.severity] || 0) - (severityOrder[a.severity] || 0);
    return sevDiff !== 0 ? sevDiff : a.line - b.line;
  });

  // Truncate to max
  const issues = allIssues.slice(0, maxIssues);

  // Calculate phi-compliance score
  const score = _calculateComplianceScore(issues, code);

  const result = {
    filePath,
    issues,
    issueCount: issues.length,
    totalDetected: allIssues.length,
    truncated: allIssues.length > maxIssues,
    score,
    categories: _categorySummary(issues),
    autoFixable: issues.filter(i => i.autoFixable).length,
    timestamp: Date.now()
  };

  // Cache result
  if (_analysisCache.size >= CACHE_SIZE) {
    const oldest = _analysisCache.keys().next().value;
    _analysisCache.delete(oldest);
  }
  _analysisCache.set(cacheKey, { result, timestamp: Date.now() });

  logger.info({
    event: 'analysis_complete',
    filePath,
    issueCount: issues.length,
    score: score.overall.toFixed(3),
    autoFixable: result.autoFixable
  });

  return result;
}

/**
 * Calculate phi-weighted compliance score
 * @param {Array} issues - Detected issues
 * @param {string} code - Source code
 * @returns {object} Score breakdown by category
 */
function _calculateComplianceScore(issues, code) {
  const lines = code.split('\n').length;
  const weights = phiFusionWeights(Object.keys(CATEGORIES).length);
  const catKeys = Object.keys(CATEGORIES);
  const scores = {};

  for (let i = 0; i < catKeys.length; i++) {
    const cat = catKeys[i];
    const catIssues = issues.filter(iss => iss.ruleId.startsWith(cat.substring(0, 4).toUpperCase()) ||
      RULES.find(r => r.id === iss.ruleId)?.category === cat);
    
    // Score = 1 - (weighted issue density)
    const severityWeights = { CRITICAL: PHI2, HIGH: PHI, MEDIUM: 1, LOW: PSI };
    const weightedCount = catIssues.reduce((sum, iss) => sum + (severityWeights[iss.severity] || 1), 0);
    const density = lines > 0 ? weightedCount / (lines / fib(8)) : 0;
    const rawScore = Math.max(0, 1 - density * PSI);
    
    scores[cat] = {
      score: rawScore,
      weight: weights[i],
      issues: catIssues.length,
      weighted: rawScore * weights[i]
    };
  }

  const overall = Object.values(scores).reduce((sum, s) => sum + s.weighted, 0);

  return {
    overall,
    passing: overall >= CSL_THRESHOLDS.MEDIUM,
    grade: overall >= CSL_THRESHOLDS.HIGH ? 'A' :
           overall >= CSL_THRESHOLDS.MEDIUM ? 'B' :
           overall >= CSL_THRESHOLDS.LOW ? 'C' :
           overall >= PRESSURE_LEVELS.NOMINAL_MAX ? 'D' : 'F',
    categories: scores
  };
}

/* ═══════════════════════════════════════════════════════════════
   §3 — Refactoring Engine
   ═══════════════════════════════════════════════════════════════ */

/** Refactor history for undo support */
const _history = [];

/**
 * Apply auto-fixable refactorings to code
 * @param {string} code - Source code
 * @param {string} filePath - File path
 * @param {object} [options] - Refactoring options
 * @returns {object} Refactored code with changes log
 */
function refactor(code, filePath = 'unknown', options = {}) {
  const {
    autoApplyThreshold = HIGH_CONFIDENCE,
    dryRun = false,
    categories = Object.keys(CATEGORIES),
    rules: ruleFilter = null
  } = options;

  const analysis = analyze(code, filePath, { categories });
  const fixableIssues = analysis.issues.filter(i => {
    if (!i.autoFixable || !i.fix) return false;
    if (ruleFilter && !ruleFilter.includes(i.ruleId)) return false;
    return true;
  });

  if (fixableIssues.length === 0) {
    return {
      code,
      filePath,
      changed: false,
      changes: [],
      score: analysis.score,
      dryRun
    };
  }

  let refactoredCode = code;
  const changes = [];
  let offset = 0;

  // Apply fixes in reverse order (bottom-up) to preserve line positions
  const sortedIssues = [...fixableIssues].sort((a, b) => b.line - a.line);

  for (const issue of sortedIssues) {
    const { fix, ruleId, line, message } = issue;
    
    // Calculate confidence based on rule severity and category
    const rule = RULES.find(r => r.id === ruleId);
    const catWeight = rule ? CATEGORIES[rule.category]?.weight || PSI : PSI;
    const confidence = cslGate(catWeight, catWeight, CSL_THRESHOLDS.MINIMUM);

    if (confidence < MIN_CONFIDENCE) {
      changes.push({
        ruleId, line, message,
        status: 'skipped',
        reason: `Confidence ${confidence.toFixed(3)} below minimum ${MIN_CONFIDENCE.toFixed(3)}`
      });
      continue;
    }

    if (!dryRun && confidence >= autoApplyThreshold) {
      const before = refactoredCode;
      refactoredCode = refactoredCode.replace(fix.original, fix.replacement);
      
      if (refactoredCode !== before) {
        changes.push({
          ruleId, line, message,
          status: 'applied',
          original: fix.original,
          replacement: fix.replacement,
          confidence: confidence.toFixed(3)
        });
      }
    } else {
      changes.push({
        ruleId, line, message,
        status: dryRun ? 'dry-run' : 'suggested',
        original: fix.original,
        replacement: fix.replacement,
        confidence: confidence.toFixed(3)
      });
    }
  }

  // Save to history for undo
  if (!dryRun && changes.some(c => c.status === 'applied')) {
    _pushHistory(filePath, code, refactoredCode, changes);
  }

  // Re-score after refactoring
  const newScore = !dryRun ? _calculateComplianceScore(
    analyze(refactoredCode, filePath).issues,
    refactoredCode
  ) : analysis.score;

  logger.info({
    event: 'refactor_complete',
    filePath,
    changesApplied: changes.filter(c => c.status === 'applied').length,
    changesSuggested: changes.filter(c => c.status === 'suggested').length,
    scoreBefore: analysis.score.overall.toFixed(3),
    scoreAfter: newScore.overall.toFixed(3),
    dryRun
  });

  return {
    code: refactoredCode,
    filePath,
    changed: refactoredCode !== code,
    changes,
    scoreBefore: analysis.score,
    scoreAfter: newScore,
    improvement: newScore.overall - analysis.score.overall,
    dryRun
  };
}

/**
 * Batch analyze multiple files
 * @param {Array<{code: string, filePath: string}>} files - Files to analyze
 * @returns {object} Batch analysis results
 */
function batchAnalyze(files) {
  const batch = files.slice(0, MAX_BATCH_SIZE);
  const results = [];

  for (const file of batch) {
    results.push(analyze(file.code, file.filePath));
  }

  // Aggregate scores
  const weights = phiFusionWeights(results.length > 1 ? Math.min(results.length, fib(6)) : 1);
  const sortedResults = [...results].sort((a, b) => a.score.overall - b.score.overall);

  const overallScore = sortedResults.reduce((sum, r, i) => {
    const w = i < weights.length ? weights[i] : weights[weights.length - 1];
    return sum + r.score.overall * w;
  }, 0);

  const totalIssues = results.reduce((sum, r) => sum + r.issueCount, 0);
  const totalAutoFixable = results.reduce((sum, r) => sum + r.autoFixable, 0);

  logger.info({
    event: 'batch_analysis_complete',
    fileCount: batch.length,
    totalIssues,
    overallScore: overallScore.toFixed(3)
  });

  return {
    files: results,
    fileCount: batch.length,
    truncated: files.length > MAX_BATCH_SIZE,
    totalIssues,
    totalAutoFixable,
    overallScore,
    worstFile: results.reduce((worst, r) => r.score.overall < worst.score.overall ? r : worst, results[0]),
    bestFile: results.reduce((best, r) => r.score.overall > best.score.overall ? r : best, results[0])
  };
}

/**
 * Batch refactor multiple files
 * @param {Array<{code: string, filePath: string}>} files - Files to refactor
 * @param {object} [options] - Refactoring options
 * @returns {object} Batch refactoring results
 */
function batchRefactor(files, options = {}) {
  const batch = files.slice(0, MAX_BATCH_SIZE);
  const results = [];

  for (const file of batch) {
    results.push(refactor(file.code, file.filePath, options));
  }

  const changed = results.filter(r => r.changed);
  const totalChanges = results.reduce((sum, r) => sum + r.changes.filter(c => c.status === 'applied').length, 0);

  logger.info({
    event: 'batch_refactor_complete',
    fileCount: batch.length,
    filesChanged: changed.length,
    totalChanges
  });

  return {
    files: results,
    fileCount: batch.length,
    filesChanged: changed.length,
    totalChanges,
    totalSuggestions: results.reduce((sum, r) => sum + r.changes.filter(c => c.status === 'suggested').length, 0)
  };
}

/* ═══════════════════════════════════════════════════════════════
   §4 — Diff Generation
   ═══════════════════════════════════════════════════════════════ */

/**
 * Generate unified diff between original and refactored code
 * @param {string} original - Original code
 * @param {string} refactored - Refactored code
 * @param {string} [filePath] - File path for diff header
 * @returns {string} Unified diff
 */
function generateDiff(original, refactored, filePath = 'file.js') {
  const origLines = original.split('\n');
  const refLines = refactored.split('\n');
  const hunks = [];
  let i = 0;

  while (i < Math.max(origLines.length, refLines.length)) {
    if (i < origLines.length && i < refLines.length && origLines[i] === refLines[i]) {
      i++;
      continue;
    }

    // Found a difference — build a hunk
    const start = Math.max(0, i - DIFF_CONTEXT_LINES);
    let end = i;
    
    // Find end of difference block
    while (end < Math.max(origLines.length, refLines.length) &&
           (end >= origLines.length || end >= refLines.length || origLines[end] !== refLines[end])) {
      end++;
    }
    end = Math.min(end + DIFF_CONTEXT_LINES, Math.max(origLines.length, refLines.length));

    const hunkLines = [];
    for (let j = start; j < end; j++) {
      const origLine = j < origLines.length ? origLines[j] : null;
      const refLine = j < refLines.length ? refLines[j] : null;

      if (origLine === refLine) {
        hunkLines.push(` ${origLine}`);
      } else {
        if (origLine !== null) hunkLines.push(`-${origLine}`);
        if (refLine !== null) hunkLines.push(`+${refLine}`);
      }
    }

    hunks.push({
      origStart: start + 1,
      origCount: origLines.slice(start, end).length,
      refStart: start + 1,
      refCount: refLines.slice(start, end).length,
      lines: hunkLines
    });

    i = end;
  }

  if (hunks.length === 0) return '';

  let diff = `--- a/${filePath}\n+++ b/${filePath}\n`;
  for (const hunk of hunks) {
    diff += `@@ -${hunk.origStart},${hunk.origCount} +${hunk.refStart},${hunk.refCount} @@\n`;
    diff += hunk.lines.join('\n') + '\n';
  }

  return diff;
}

/* ═══════════════════════════════════════════════════════════════
   §5 — History & Undo
   ═══════════════════════════════════════════════════════════════ */

/**
 * Push refactoring to history
 */
function _pushHistory(filePath, before, after, changes) {
  if (_history.length >= MAX_HISTORY_BUFFER) {
    _history.shift();
  }
  _history.push({
    filePath,
    before,
    after,
    changes,
    timestamp: Date.now()
  });
}

/**
 * Undo last refactoring for a file
 * @param {string} filePath - File to undo
 * @returns {object|null} Previous code version or null
 */
function undo(filePath) {
  for (let i = _history.length - 1; i >= 0; i--) {
    if (_history[i].filePath === filePath) {
      const entry = _history.splice(i, 1)[0];
      logger.info({ event: 'undo', filePath, changesReverted: entry.changes.length });
      return { code: entry.before, changes: entry.changes };
    }
  }
  return null;
}

/**
 * Get refactoring history
 * @param {string} [filePath] - Filter by file path
 * @returns {Array} History entries
 */
function getHistory(filePath) {
  if (filePath) {
    return _history.filter(h => h.filePath === filePath);
  }
  return [..._history];
}

/* ═══════════════════════════════════════════════════════════════
   §6 — Utility Functions
   ═══════════════════════════════════════════════════════════════ */

function _getLineNumber(code, index) {
  return code.substring(0, index).split('\n').length;
}

function _getColumn(code, index) {
  const lastNewline = code.lastIndexOf('\n', index);
  return index - lastNewline;
}

function _hashCode(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const chr = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + chr;
    hash |= 0;
  }
  return hash;
}

function _nearestFib(n) {
  const fibs = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765];
  let nearest = fibs[0];
  let minDiff = Math.abs(n - nearest);
  for (const f of fibs) {
    const diff = Math.abs(n - f);
    if (diff < minDiff) {
      minDiff = diff;
      nearest = f;
    }
  }
  return nearest;
}

function _fibIndex(val) {
  const fibs = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765];
  const idx = fibs.indexOf(val);
  return idx >= 0 ? idx + 1 : '?';
}

function _nearestPhiThreshold(val) {
  const levels = [
    { level: 0, value: 0.500 },
    { level: 1, value: 0.691 },
    { level: 2, value: 0.809 },
    { level: 3, value: 0.882 },
    { level: 4, value: 0.927 }
  ];
  let nearest = levels[0];
  let minDiff = Math.abs(val - nearest.value);
  for (const l of levels) {
    const diff = Math.abs(val - l.value);
    if (diff < minDiff) {
      minDiff = diff;
      nearest = l;
    }
  }
  return nearest;
}

function _categorySummary(issues) {
  const summary = {};
  for (const issue of issues) {
    const rule = RULES.find(r => r.id === issue.ruleId);
    const cat = rule ? rule.category : 'UNKNOWN';
    if (!summary[cat]) {
      summary[cat] = { count: 0, critical: 0, high: 0, medium: 0, low: 0 };
    }
    summary[cat].count++;
    summary[cat][issue.severity.toLowerCase()]++;
  }
  return summary;
}

function _findFunctionEnd(code, startIndex) {
  let depth = 0;
  let started = false;
  let lineCount = 0;
  for (let i = startIndex; i < code.length; i++) {
    if (code[i] === '{') { depth++; started = true; }
    if (code[i] === '}') { depth--; }
    if (code[i] === '\n') lineCount++;
    if (started && depth === 0) return lineCount;
  }
  return lineCount;
}

function _extractFunctionBody(code, braceIndex) {
  let depth = 0;
  let start = braceIndex;
  for (let i = braceIndex; i < code.length; i++) {
    if (code[i] === '{') depth++;
    if (code[i] === '}') { depth--; if (depth === 0) return code.substring(start, i + 1); }
  }
  return null;
}

/* ═══════════════════════════════════════════════════════════════
   §7 — Health & Export
   ═══════════════════════════════════════════════════════════════ */

const health = createHealthCheck('heady-refactor', () => ({
  rulesLoaded: RULES.length,
  categories: Object.keys(CATEGORIES).length,
  cacheSize: _analysisCache.size,
  cacheMax: CACHE_SIZE,
  historySize: _history.length,
  historyMax: MAX_HISTORY_BUFFER
}));



module.exports = {
  analyze,
  refactor,
  batchAnalyze,
  batchRefactor,
  generateDiff,
  undo,
  getHistory,
  health,
  RULES,
  CATEGORIES
};
