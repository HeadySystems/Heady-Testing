/**
 * Heady™ HeadyCodex — Documentation Generation & API Reference Builder
 * 
 * Production-ready documentation engine with:
 * - JSDoc extraction and parsing from source files
 * - API reference generation (OpenAPI-aligned)
 * - Module dependency graph construction
 * - Architecture documentation generation
 * - Change log compilation from git history
 * - Cross-reference linking between modules
 * - Search-optimized documentation index
 * - Markdown and HTML output formats
 * 
 * All thresholds derived from φ (phi). Zero magic numbers.
 * Zero console.log — structured JSON logging only.
 * 
 * @module HeadyCodex
 * @version 1.0.0
 * @author Eric Haywood
 */

'use strict';

const {
  PHI, PSI,
  fib,
  phiThreshold, CSL_THRESHOLDS,
  phiFusionWeights,
  SIZING,
  TIMING,
  cosineSimilarity,
} = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');

const logger = createLogger('heady-codex');

/* ─────────────────────── Constants ─────────────────────── */

/** Documentation categories */
const DOC_CATEGORIES = Object.freeze({
  API: 'api',
  MODULE: 'module',
  CLASS: 'class',
  FUNCTION: 'function',
  CONSTANT: 'constant',
  TYPE: 'type',
  ARCHITECTURE: 'architecture',
  RUNBOOK: 'runbook',
  ADR: 'adr',
});

/** JSDoc tag parsers */
const JSDOC_TAGS = Object.freeze([
  'param', 'returns', 'return', 'throws', 'type', 'typedef',
  'property', 'prop', 'module', 'class', 'constructor',
  'extends', 'implements', 'fires', 'listens', 'emits',
  'version', 'author', 'deprecated', 'since', 'see',
  'example', 'default', 'enum', 'readonly', 'private',
  'protected', 'public', 'static', 'async', 'generator',
]);

/** Maximum documentation entries — Fibonacci-sized */
const MAX_ENTRIES = fib(16); // 987

/** Maximum cross-references per entry */
const MAX_XREFS = fib(8); // 21

/** Index batch size */
const INDEX_BATCH_SIZE = fib(8); // 21

/** Search relevance threshold */
const SEARCH_THRESHOLD = CSL_THRESHOLDS.LOW; // ≈ 0.691

/** Documentation completeness weights (description, params, returns, examples) */
const COMPLETENESS_WEIGHTS = phiFusionWeights(4); // [0.447, 0.276, 0.171, 0.106]

/* ─────────────────────── JSDoc Parser ─────────────────────── */

/**
 * Parse JSDoc comments from source code
 * @param {string} content - Source file content
 * @returns {Array} Parsed JSDoc blocks
 */
function parseJSDoc(content) {
  const blocks = [];
  const jsdocRegex = /\/\*\*\s*([\s\S]*?)\s*\*\//g;
  let match;

  while ((match = jsdocRegex.exec(content)) !== null) {
    const rawBlock = match[1];
    const blockStart = content.substring(0, match.index).split('\n').length;

    // Get the code declaration following the JSDoc
    const afterBlock = content.substring(match.index + match[0].length).trimStart();
    const declaration = extractDeclaration(afterBlock);

    const parsed = parseJSDocBlock(rawBlock, blockStart);
    parsed.declaration = declaration;
    parsed.sourceOffset = match.index;

    blocks.push(parsed);
  }

  return blocks;
}

/**
 * Parse a single JSDoc block into structured data
 * @param {string} raw - Raw JSDoc content (between delimiters)
 * @param {number} lineNumber - Starting line number
 * @returns {object} Parsed block
 */
function parseJSDocBlock(raw, lineNumber) {
  // Clean up lines
  const lines = raw
    .split('\n')
    .map(line => line.replace(/^\s*\*\s?/, '').trim())
    .filter(line => line.length > 0);

  const result = {
    description: '',
    tags: [],
    params: [],
    returns: null,
    throws: [],
    examples: [],
    metadata: {},
    line: lineNumber,
  };

  let currentTag = null;
  let descriptionLines = [];

  for (const line of lines) {
    const tagMatch = line.match(/^@(\w+)\s*(.*)/);

    if (tagMatch) {
      // Flush description
      if (descriptionLines.length > 0 && !result.description) {
        result.description = descriptionLines.join(' ').trim();
        descriptionLines = [];
      }

      const tagName = tagMatch[1];
      const tagContent = tagMatch[2].trim();

      currentTag = { name: tagName, content: tagContent };

      switch (tagName) {
        case 'param': {
          const paramMatch = tagContent.match(/\{([^}]+)\}\s+(\[?\w+(?:\.\w+)*\]?)\s*-?\s*(.*)/);
          if (paramMatch) {
            const isOptional = paramMatch[2].startsWith('[');
            result.params.push({
              type: paramMatch[1],
              name: paramMatch[2].replace(/[\[\]]/g, ''),
              description: paramMatch[3],
              optional: isOptional,
            });
          }
          break;
        }
        case 'returns':
        case 'return': {
          const returnMatch = tagContent.match(/\{([^}]+)\}\s*(.*)/);
          if (returnMatch) {
            result.returns = { type: returnMatch[1], description: returnMatch[2] };
          }
          break;
        }
        case 'throws': {
          const throwMatch = tagContent.match(/\{([^}]+)\}\s*(.*)/);
          if (throwMatch) {
            result.throws.push({ type: throwMatch[1], description: throwMatch[2] });
          }
          break;
        }
        case 'example':
          result.examples.push(tagContent);
          break;
        case 'module':
        case 'class':
        case 'version':
        case 'author':
        case 'since':
        case 'deprecated':
        case 'see':
          result.metadata[tagName] = tagContent;
          break;
        default:
          result.tags.push({ name: tagName, content: tagContent });
      }
    } else if (currentTag && currentTag.name === 'example') {
      // Continuation of example
      result.examples[result.examples.length - 1] += '\n' + line;
    } else {
      descriptionLines.push(line);
    }
  }

  // Flush remaining description
  if (descriptionLines.length > 0 && !result.description) {
    result.description = descriptionLines.join(' ').trim();
  }

  return result;
}

/**
 * Extract code declaration following a JSDoc block
 * @param {string} code - Code after JSDoc
 * @returns {object} Declaration info
 */
function extractDeclaration(code) {
  const firstLine = code.split('\n')[0].trim();

  // Class declaration
  const classMatch = firstLine.match(/(?:class|export\s+class)\s+(\w+)(?:\s+extends\s+(\w+))?/);
  if (classMatch) {
    return { type: 'class', name: classMatch[1], extends: classMatch[2] || null };
  }

  // Function declaration
  const funcMatch = firstLine.match(/(?:async\s+)?(?:function\s+)?(\w+)\s*\(/);
  if (funcMatch) {
    return { type: 'function', name: funcMatch[1] };
  }

  // Method declaration
  const methodMatch = firstLine.match(/(?:async\s+)?(\w+)\s*\([^)]*\)\s*\{/);
  if (methodMatch) {
    return { type: 'method', name: methodMatch[1] };
  }

  // Constant/variable
  const constMatch = firstLine.match(/(?:const|let|var|export\s+const)\s+(\w+)\s*=/);
  if (constMatch) {
    return { type: 'constant', name: constMatch[1] };
  }

  // Module.exports
  const exportMatch = firstLine.match(/module\.exports\s*=\s*\{?\s*(\w+)?/);
  if (exportMatch) {
    return { type: 'export', name: exportMatch[1] || 'module' };
  }

  return { type: 'unknown', name: null };
}

/* ─────────────────────── Dependency Graph ─────────────────────── */

/**
 * Build module dependency graph from require/import statements
 * @param {Array<{path: string, content: string}>} files - Source files
 * @returns {object} Dependency graph
 */
function buildDependencyGraph(files) {
  const graph = {
    nodes: {},
    edges: [],
    clusters: {},
  };

  for (const file of files) {
    const moduleName = file.path.replace(/^.*\//, '').replace(/\.\w+$/, '');
    graph.nodes[file.path] = {
      name: moduleName,
      path: file.path,
      imports: [],
      importedBy: [],
      size: file.content.split('\n').length,
    };

    // Extract require() calls
    const requireRegex = /require\(\s*['"`]([^'"`]+)['"`]\s*\)/g;
    let match;
    while ((match = requireRegex.exec(file.content)) !== null) {
      const imported = match[1];
      graph.nodes[file.path].imports.push(imported);
      graph.edges.push({ from: file.path, to: imported, type: 'require' });
    }

    // Extract ES import statements
    const importRegex = /import\s+.*?\s+from\s+['"`]([^'"`]+)['"`]/g;
    while ((match = importRegex.exec(file.content)) !== null) {
      const imported = match[1];
      graph.nodes[file.path].imports.push(imported);
      graph.edges.push({ from: file.path, to: imported, type: 'import' });
    }
  }

  // Build reverse lookup (importedBy)
  for (const edge of graph.edges) {
    // Find the target node
    for (const [path, node] of Object.entries(graph.nodes)) {
      if (edge.to.includes(node.name) || path.includes(edge.to)) {
        node.importedBy.push(edge.from);
      }
    }
  }

  // Cluster by directory
  for (const [path, node] of Object.entries(graph.nodes)) {
    const dir = path.split('/').slice(0, -1).join('/');
    if (!graph.clusters[dir]) {
      graph.clusters[dir] = [];
    }
    graph.clusters[dir].push(path);
  }

  return graph;
}

/* ─────────────────────── Documentation Generator ─────────────────────── */

/**
 * HeadyCodex — Documentation Generation Engine
 * 
 * Extracts, indexes, and generates comprehensive documentation
 * from source code with cross-references and search capabilities.
 */
class HeadyCodex {
  /**
   * @param {object} opts
   * @param {object} [opts.vectorMemory] - HeadyMemory for semantic search
   * @param {object} [opts.embedder] - HeadyEmbed for generating search embeddings
   * @param {string} [opts.projectName] - Project name for documentation
   * @param {string} [opts.baseUrl] - Base URL for documentation links
   */
  constructor(opts = {}) {
    this.vectorMemory = opts.vectorMemory || null;
    this.embedder = opts.embedder || null;
    this.projectName = opts.projectName || 'Heady™';
    this.baseUrl = opts.baseUrl || '/docs';

    /** Documentation index — Fibonacci-sized capacity */
    this.index = new Map();
    this.maxIndexSize = MAX_ENTRIES;

    /** Cross-reference map */
    this.crossRefs = new Map();

    /** Module dependency graph */
    this.dependencyGraph = null;

    /** Search index (text → entry IDs) */
    this.searchIndex = new Map();

    /** File-to-entries map */
    this.fileEntries = new Map();

    /** Statistics */
    this.stats = {
      totalEntries: 0,
      modulesDocumented: 0,
      classesDocumented: 0,
      functionsDocumented: 0,
      averageCompleteness: 0,
      lastGeneratedAt: null,
    };

    logger.info({ component: 'HeadyCodex', action: 'initialized', projectName: this.projectName });
  }

  /* ─────────────── Source Ingestion ─────────────── */

  /**
   * Ingest source files and extract documentation
   * @param {Array<{path: string, content: string}>} files - Source files
   * @returns {object} Ingestion report
   */
  async ingest(files) {
    const startTime = Date.now();
    let totalBlocks = 0;
    let totalEntries = 0;

    logger.info({ component: 'HeadyCodex', action: 'ingest_start', fileCount: files.length });

    // Build dependency graph
    this.dependencyGraph = buildDependencyGraph(files);

    // Process files in batches
    for (let i = 0; i < files.length; i += INDEX_BATCH_SIZE) {
      const batch = files.slice(i, i + INDEX_BATCH_SIZE);

      for (const file of batch) {
        // Skip non-JS files for JSDoc parsing
        if (!file.path.match(/\.(js|ts|mjs|cjs)$/)) continue;

        const blocks = parseJSDoc(file.content);
        totalBlocks += blocks.length;

        // Create module-level entry
        const moduleEntry = this._createModuleEntry(file, blocks);
        if (moduleEntry) {
          this._addToIndex(moduleEntry);
          totalEntries++;
        }

        // Create entries for each documented item
        for (const block of blocks) {
          const entry = this._createEntry(file.path, block);
          if (entry) {
            this._addToIndex(entry);
            totalEntries++;
          }
        }

        // Extract exports for cross-referencing
        this._extractExports(file);
      }
    }

    // Build cross-references
    this._buildCrossRefs();

    // Build search index
    await this._buildSearchIndex();

    // Compute stats
    this._computeStats();

    const duration = Date.now() - startTime;

    logger.info({
      component: 'HeadyCodex',
      action: 'ingest_complete',
      duration_ms: duration,
      filesProcessed: files.length,
      jsdocBlocks: totalBlocks,
      entries: totalEntries,
    });

    return {
      duration_ms: duration,
      filesProcessed: files.length,
      jsdocBlocks: totalBlocks,
      entries: totalEntries,
      stats: this.stats,
    };
  }

  /**
   * Create a module-level documentation entry
   * @param {object} file - File object
   * @param {Array} blocks - JSDoc blocks in the file
   * @returns {object|null} Module entry
   */
  _createModuleEntry(file, blocks) {
    // Find the @module block
    const moduleBlock = blocks.find(b => b.metadata.module);

    const moduleName = moduleBlock?.metadata.module ||
      file.path.replace(/^.*\//, '').replace(/\.\w+$/, '');

    const deps = this.dependencyGraph?.nodes[file.path];

    return {
      id: `module:${file.path}`,
      category: DOC_CATEGORIES.MODULE,
      name: moduleName,
      path: file.path,
      description: moduleBlock?.description || `Module: ${moduleName}`,
      version: moduleBlock?.metadata.version || null,
      author: moduleBlock?.metadata.author || null,
      lineCount: file.content.split('\n').length,
      imports: deps?.imports || [],
      importedBy: deps?.importedBy || [],
      exports: this._extractModuleExports(file.content),
      completeness: this._computeCompleteness(moduleBlock),
    };
  }

  /**
   * Create a documentation entry from a JSDoc block
   * @param {string} filePath - Source file path
   * @param {object} block - Parsed JSDoc block
   * @returns {object|null} Documentation entry
   */
  _createEntry(filePath, block) {
    if (!block.declaration || block.declaration.type === 'unknown') return null;
    if (!block.declaration.name) return null;

    const entryType = block.declaration.type === 'class' ? DOC_CATEGORIES.CLASS :
      block.declaration.type === 'constant' ? DOC_CATEGORIES.CONSTANT :
        DOC_CATEGORIES.FUNCTION;

    return {
      id: `${entryType}:${filePath}:${block.declaration.name}`,
      category: entryType,
      name: block.declaration.name,
      path: filePath,
      line: block.line,
      description: block.description,
      params: block.params,
      returns: block.returns,
      throws: block.throws,
      examples: block.examples,
      deprecated: block.metadata.deprecated || null,
      since: block.metadata.since || null,
      see: block.metadata.see || null,
      extends: block.declaration.extends || null,
      tags: block.tags,
      completeness: this._computeCompleteness(block),
    };
  }

  /**
   * Extract module.exports from file content
   * @param {string} content - File content
   * @returns {string[]} Exported names
   */
  _extractModuleExports(content) {
    const exports = [];

    // CommonJS: module.exports = { A, B, C }
    const cjsMatch = content.match(/module\.exports\s*=\s*\{([^}]+)\}/);
    if (cjsMatch) {
      const names = cjsMatch[1].split(',').map(n => n.trim().split(':')[0].trim());
      exports.push(...names.filter(n => n.length > 0));
    }

    // ES: export { A, B, C }
    const esMatch = content.match(/export\s*\{([^}]+)\}/);
    if (esMatch) {
      const names = esMatch[1].split(',').map(n => n.trim().split(' as ')[0].trim());
      exports.push(...names.filter(n => n.length > 0));
    }

    // Named exports
    const namedExportRegex = /export\s+(?:const|let|var|function|class|async\s+function)\s+(\w+)/g;
    let match;
    while ((match = namedExportRegex.exec(content)) !== null) {
      exports.push(match[1]);
    }

    return [...new Set(exports)];
  }

  /**
   * Extract exports for cross-referencing
   * @param {object} file - File object
   */
  _extractExports(file) {
    const entries = [];
    const exportNames = this._extractModuleExports(file.content);

    for (const name of exportNames) {
      entries.push(name);
    }

    if (entries.length > 0) {
      this.fileEntries.set(file.path, entries);
    }
  }

  /* ─────────────── Index Management ─────────────── */

  /**
   * Add entry to documentation index
   * @param {object} entry - Documentation entry
   */
  _addToIndex(entry) {
    if (this.index.size >= this.maxIndexSize) {
      // Evict lowest completeness entry
      let minKey = null;
      let minCompleteness = 1;
      for (const [key, val] of this.index) {
        if (val.completeness < minCompleteness) {
          minCompleteness = val.completeness;
          minKey = key;
        }
      }
      if (minKey) this.index.delete(minKey);
    }

    this.index.set(entry.id, entry);
  }

  /* ─────────────── Cross-References ─────────────── */

  /**
   * Build cross-reference links between documentation entries
   */
  _buildCrossRefs() {
    const allEntries = [...this.index.values()];

    for (const entry of allEntries) {
      const refs = [];

      // Find entries that reference this entry's name
      for (const other of allEntries) {
        if (other.id === entry.id) continue;

        const nameInDesc = other.description?.includes(entry.name);
        const nameInParams = other.params?.some(p => p.type?.includes(entry.name));
        const nameInReturns = other.returns?.type?.includes(entry.name);

        if (nameInDesc || nameInParams || nameInReturns) {
          refs.push({
            targetId: other.id,
            targetName: other.name,
            relationship: nameInParams ? 'parameter_type' :
              nameInReturns ? 'return_type' : 'reference',
          });
        }

        if (refs.length >= MAX_XREFS) break;
      }

      // Add dependency graph references
      if (entry.category === DOC_CATEGORIES.MODULE && this.dependencyGraph) {
        const node = this.dependencyGraph.nodes[entry.path];
        if (node) {
          for (const imp of node.imports.slice(0, MAX_XREFS)) {
            refs.push({
              targetId: `import:${imp}`,
              targetName: imp,
              relationship: 'imports',
            });
          }
        }
      }

      if (refs.length > 0) {
        this.crossRefs.set(entry.id, refs);
      }
    }
  }

  /* ─────────────── Search Index ─────────────── */

  /**
   * Build search index from documentation entries
   */
  async _buildSearchIndex() {
    this.searchIndex.clear();

    for (const [id, entry] of this.index) {
      // Tokenize searchable fields
      const searchText = [
        entry.name,
        entry.description,
        entry.category,
        ...(entry.params?.map(p => `${p.name} ${p.type} ${p.description}`) || []),
        entry.returns?.type,
        entry.returns?.description,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();

      // Build inverted index
      const tokens = searchText.split(/\W+/).filter(t => t.length > 2);
      for (const token of tokens) {
        if (!this.searchIndex.has(token)) {
          this.searchIndex.set(token, new Set());
        }
        this.searchIndex.get(token).add(id);
      }
    }

    logger.info({
      component: 'HeadyCodex',
      action: 'search_index_built',
      tokens: this.searchIndex.size,
      entries: this.index.size,
    });
  }

  /**
   * Search documentation
   * @param {string} query - Search query
   * @param {object} [opts] - Search options
   * @param {string} [opts.category] - Filter by category
   * @param {number} [opts.limit] - Maximum results
   * @returns {Array} Search results
   */
  search(query, opts = {}) {
    const limit = opts.limit || fib(8); // 21
    const tokens = query.toLowerCase().split(/\W+/).filter(t => t.length > 2);

    // Score entries by token match frequency
    const scores = new Map();

    for (const token of tokens) {
      // Exact match
      if (this.searchIndex.has(token)) {
        for (const id of this.searchIndex.get(token)) {
          scores.set(id, (scores.get(id) || 0) + 1);
        }
      }

      // Prefix match (for partial queries)
      for (const [indexed, ids] of this.searchIndex) {
        if (indexed.startsWith(token) && indexed !== token) {
          for (const id of ids) {
            scores.set(id, (scores.get(id) || 0) + PSI); // Partial match weighted lower
          }
        }
      }
    }

    // Rank results
    const results = [...scores.entries()]
      .map(([id, score]) => {
        const entry = this.index.get(id);
        if (!entry) return null;
        if (opts.category && entry.category !== opts.category) return null;

        return {
          id,
          name: entry.name,
          category: entry.category,
          path: entry.path,
          description: entry.description?.slice(0, fib(12)), // 144 chars
          score: score / tokens.length, // Normalize by query length
          completeness: entry.completeness,
        };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);

    logger.info({
      component: 'HeadyCodex',
      action: 'search',
      query,
      results: results.length,
    });

    return results;
  }

  /* ─────────────── Documentation Generation ─────────────── */

  /**
   * Generate complete documentation as Markdown
   * @param {object} [opts] - Generation options
   * @param {string} [opts.format] - Output format ('markdown'|'html')
   * @param {boolean} [opts.includePrivate] - Include private members
   * @param {boolean} [opts.includeDeprecated] - Include deprecated items
   * @returns {string} Generated documentation
   */
  generate(opts = {}) {
    const format = opts.format || 'markdown';

    logger.info({ component: 'HeadyCodex', action: 'generate_start', format, entries: this.index.size });

    const sections = [];

    // Title and overview
    sections.push(this._generateHeader());

    // Table of contents
    sections.push(this._generateTOC());

    // Module documentation
    const modules = this._getEntriesByCategory(DOC_CATEGORIES.MODULE);
    if (modules.length > 0) {
      sections.push('\n## Modules\n');
      for (const mod of modules) {
        sections.push(this._generateModuleDoc(mod, opts));
      }
    }

    // Class documentation
    const classes = this._getEntriesByCategory(DOC_CATEGORIES.CLASS);
    if (classes.length > 0) {
      sections.push('\n## Classes\n');
      for (const cls of classes) {
        sections.push(this._generateClassDoc(cls, opts));
      }
    }

    // Function documentation
    const functions = this._getEntriesByCategory(DOC_CATEGORIES.FUNCTION);
    if (functions.length > 0) {
      sections.push('\n## Functions\n');
      for (const func of functions) {
        sections.push(this._generateFunctionDoc(func));
      }
    }

    // Constants
    const constants = this._getEntriesByCategory(DOC_CATEGORIES.CONSTANT);
    if (constants.length > 0) {
      sections.push('\n## Constants\n');
      for (const c of constants) {
        sections.push(this._generateConstantDoc(c));
      }
    }

    // Dependency graph
    if (this.dependencyGraph) {
      sections.push(this._generateDependencyDoc());
    }

    // Index
    sections.push(this._generateIndex());

    this.stats.lastGeneratedAt = new Date().toISOString();

    const doc = sections.join('\n');

    logger.info({
      component: 'HeadyCodex',
      action: 'generate_complete',
      format,
      length: doc.length,
    });

    return format === 'html' ? this._markdownToHtml(doc) : doc;
  }

  /**
   * Generate documentation header
   * @returns {string}
   */
  _generateHeader() {
    return [
      `# ${this.projectName} API Reference`,
      '',
      `Generated: ${new Date().toISOString()}`,
      `Modules: ${this.stats.modulesDocumented} | Classes: ${this.stats.classesDocumented} | Functions: ${this.stats.functionsDocumented}`,
      `Average Documentation Completeness: ${(this.stats.averageCompleteness * 100).toFixed(1)}%`,
      '',
      '---',
    ].join('\n');
  }

  /**
   * Generate table of contents
   * @returns {string}
   */
  _generateTOC() {
    const lines = ['\n## Table of Contents\n'];

    const modules = this._getEntriesByCategory(DOC_CATEGORIES.MODULE);
    if (modules.length > 0) {
      lines.push('### Modules');
      for (const mod of modules) {
        lines.push(`- [${mod.name}](#${this._anchorize(mod.name)})`);
      }
    }

    const classes = this._getEntriesByCategory(DOC_CATEGORIES.CLASS);
    if (classes.length > 0) {
      lines.push('\n### Classes');
      for (const cls of classes) {
        lines.push(`- [${cls.name}](#${this._anchorize(cls.name)})`);
      }
    }

    return lines.join('\n');
  }

  /**
   * Generate module documentation
   * @param {object} mod - Module entry
   * @param {object} opts - Options
   * @returns {string}
   */
  _generateModuleDoc(mod, opts = {}) {
    const lines = [
      `### ${mod.name}`,
      '',
      mod.description,
      '',
      `**Path:** \`${mod.path}\``,
      `**Lines:** ${mod.lineCount}`,
    ];

    if (mod.version) lines.push(`**Version:** ${mod.version}`);
    if (mod.author) lines.push(`**Author:** ${mod.author}`);

    // Exports
    if (mod.exports && mod.exports.length > 0) {
      lines.push('\n**Exports:**');
      for (const exp of mod.exports) {
        lines.push(`- \`${exp}\``);
      }
    }

    // Dependencies
    if (mod.imports && mod.imports.length > 0) {
      lines.push('\n**Dependencies:**');
      for (const dep of mod.imports) {
        lines.push(`- \`${dep}\``);
      }
    }

    // Cross-references
    const refs = this.crossRefs.get(mod.id);
    if (refs && refs.length > 0) {
      lines.push('\n**Related:**');
      for (const ref of refs.slice(0, fib(6))) { // Max 8
        lines.push(`- ${ref.relationship}: [${ref.targetName}](#${this._anchorize(ref.targetName)})`);
      }
    }

    lines.push('\n---\n');
    return lines.join('\n');
  }

  /**
   * Generate class documentation
   * @param {object} cls - Class entry
   * @param {object} opts - Options
   * @returns {string}
   */
  _generateClassDoc(cls, opts = {}) {
    const lines = [
      `### ${cls.name}`,
      '',
      cls.description,
      '',
      `**Path:** \`${cls.path}\` (line ${cls.line})`,
    ];

    if (cls.extends) lines.push(`**Extends:** \`${cls.extends}\``);
    if (cls.deprecated) lines.push(`**Deprecated:** ${cls.deprecated}`);
    if (cls.since) lines.push(`**Since:** ${cls.since}`);

    // Constructor params
    if (cls.params && cls.params.length > 0) {
      lines.push('\n**Constructor Parameters:**');
      lines.push('| Name | Type | Description | Optional |');
      lines.push('|------|------|-------------|----------|');
      for (const p of cls.params) {
        lines.push(`| \`${p.name}\` | \`${p.type}\` | ${p.description} | ${p.optional ? 'Yes' : 'No'} |`);
      }
    }

    // Examples
    if (cls.examples && cls.examples.length > 0) {
      lines.push('\n**Examples:**');
      for (const ex of cls.examples) {
        lines.push('```javascript');
        lines.push(ex);
        lines.push('```');
      }
    }

    lines.push('\n---\n');
    return lines.join('\n');
  }

  /**
   * Generate function documentation
   * @param {object} func - Function entry
   * @returns {string}
   */
  _generateFunctionDoc(func) {
    const lines = [
      `#### ${func.name}`,
      '',
      func.description,
      '',
    ];

    // Parameters table
    if (func.params && func.params.length > 0) {
      lines.push('**Parameters:**');
      lines.push('| Name | Type | Description | Optional |');
      lines.push('|------|------|-------------|----------|');
      for (const p of func.params) {
        lines.push(`| \`${p.name}\` | \`${p.type}\` | ${p.description} | ${p.optional ? 'Yes' : 'No'} |`);
      }
    }

    // Returns
    if (func.returns) {
      lines.push(`\n**Returns:** \`${func.returns.type}\` — ${func.returns.description}`);
    }

    // Throws
    if (func.throws && func.throws.length > 0) {
      lines.push('\n**Throws:**');
      for (const t of func.throws) {
        lines.push(`- \`${t.type}\` — ${t.description}`);
      }
    }

    // Examples
    if (func.examples && func.examples.length > 0) {
      lines.push('\n**Example:**');
      for (const ex of func.examples) {
        lines.push('```javascript');
        lines.push(ex);
        lines.push('```');
      }
    }

    return lines.join('\n');
  }

  /**
   * Generate constant documentation
   * @param {object} c - Constant entry
   * @returns {string}
   */
  _generateConstantDoc(c) {
    return [
      `#### ${c.name}`,
      '',
      c.description,
      '',
    ].join('\n');
  }

  /**
   * Generate dependency graph documentation
   * @returns {string}
   */
  _generateDependencyDoc() {
    if (!this.dependencyGraph) return '';

    const lines = ['\n## Module Dependencies\n'];

    // Sort clusters by size
    const clusters = Object.entries(this.dependencyGraph.clusters)
      .sort((a, b) => b[1].length - a[1].length);

    for (const [dir, paths] of clusters) {
      const dirName = dir.split('/').pop() || dir;
      lines.push(`### ${dirName}/`);

      for (const path of paths) {
        const node = this.dependencyGraph.nodes[path];
        if (!node) continue;

        lines.push(`- **${node.name}** (${node.size} lines)`);
        if (node.imports.length > 0) {
          lines.push(`  - imports: ${node.imports.slice(0, fib(6)).join(', ')}`);
        }
        if (node.importedBy.length > 0) {
          lines.push(`  - imported by: ${node.importedBy.length} modules`);
        }
      }
      lines.push('');
    }

    return lines.join('\n');
  }

  /**
   * Generate alphabetical index
   * @returns {string}
   */
  _generateIndex() {
    const entries = [...this.index.values()]
      .sort((a, b) => a.name.localeCompare(b.name));

    const lines = ['\n## Index\n'];

    let currentLetter = '';
    for (const entry of entries) {
      const letter = (entry.name[0] || '').toUpperCase();
      if (letter !== currentLetter) {
        currentLetter = letter;
        lines.push(`\n### ${letter}`);
      }
      lines.push(`- \`${entry.name}\` (${entry.category}) — ${entry.path}`);
    }

    return lines.join('\n');
  }

  /* ─────────────── Completeness Scoring ─────────────── */

  /**
   * Compute documentation completeness score
   * Uses phi-weighted fusion of description, params, returns, examples
   * @param {object} block - JSDoc block
   * @returns {number} Completeness 0-1
   */
  _computeCompleteness(block) {
    if (!block) return 0;

    const scores = [
      block.description && block.description.length > fib(7) ? 1 : (block.description?.length || 0) / fib(7), // 13 chars min
      block.params && block.params.length > 0 ? Math.min(1, block.params.filter(p => p.description).length / Math.max(1, block.params.length)) : 0,
      block.returns ? 1 : 0,
      block.examples && block.examples.length > 0 ? 1 : 0,
    ];

    // Phi-weighted fusion
    let total = 0;
    for (let i = 0; i < scores.length; i++) {
      total += scores[i] * COMPLETENESS_WEIGHTS[i];
    }

    return Math.min(1, total);
  }

  /* ─────────────── Utilities ─────────────── */

  /**
   * Get entries by category
   * @param {string} category - Category to filter
   * @returns {Array} Filtered entries
   */
  _getEntriesByCategory(category) {
    return [...this.index.values()].filter(e => e.category === category);
  }

  /**
   * Convert name to anchor-safe string
   * @param {string} name - Name to anchorize
   * @returns {string}
   */
  _anchorize(name) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  /**
   * Simple Markdown to HTML conversion
   * @param {string} md - Markdown content
   * @returns {string} HTML content
   */
  _markdownToHtml(md) {
    return md
      .replace(/^### (.+)$/gm, '<h3>$1</h3>')
      .replace(/^## (.+)$/gm, '<h2>$1</h2>')
      .replace(/^# (.+)$/gm, '<h1>$1</h1>')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/\n/g, '<br>\n');
  }

  /**
   * Compute and update statistics
   */
  _computeStats() {
    const entries = [...this.index.values()];

    this.stats.totalEntries = entries.length;
    this.stats.modulesDocumented = entries.filter(e => e.category === DOC_CATEGORIES.MODULE).length;
    this.stats.classesDocumented = entries.filter(e => e.category === DOC_CATEGORIES.CLASS).length;
    this.stats.functionsDocumented = entries.filter(e => e.category === DOC_CATEGORIES.FUNCTION).length;
    this.stats.averageCompleteness = entries.length > 0
      ? entries.reduce((sum, e) => sum + (e.completeness || 0), 0) / entries.length
      : 0;
  }

  /**
   * Get documentation statistics
   * @returns {object} Stats
   */
  getStats() {
    return { ...this.stats };
  }

  /**
   * Health check
   * @returns {object} Health status
   */
  health() {
    return {
      service: 'heady-codex',
      status: 'healthy',
      indexSize: this.index.size,
      searchTerms: this.searchIndex.size,
      crossRefs: this.crossRefs.size,
      stats: this.stats,
      timestamp: new Date().toISOString(),
    };
  }
}

module.exports = {
  HeadyCodex,
  DOC_CATEGORIES,
  parseJSDoc,
  parseJSDocBlock,
  extractDeclaration,
  buildDependencyGraph,
};
