/**
 * Heady™ HeadyBuddy — Companion Chat Interface
 * User-facing conversational interface to the conductor. Manages conversation
 * history, user preference learning, anticipatory suggestions, and context
 * assembly for conductor routing.
 *
 * All numeric constants derived from φ — zero magic numbers.
 *
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder — 60+ Provisional Patents
 * @module heady-buddy
 * @version 1.0.0
 */

'use strict';

const {
  PHI, PSI, PSI_SQ,
  fibonacci, phiFusionWeights, phiThreshold,
  CSL_THRESHOLDS, TIMING, SERVICE_PORTS,
  cosineSimilarity, cslGate, cslBlend, PHI_TEMPERATURE,
  SIZING, phiPriorityScore, phiTokenBudgets,
  COMPRESSION_TRIGGER,
} = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');

const logger = createLogger('heady-buddy');

// ═══════════════════════════════════════════════════════════
// CONSTANTS
// ═══════════════════════════════════════════════════════════

const MAX_CONVERSATION_TURNS = fibonacci(11);        // 89 turns per conversation
const MAX_CONVERSATIONS = fibonacci(8);              // 21 concurrent conversations
const PREFERENCE_STORE_SIZE = fibonacci(13);          // 233 preference entries per user
const SUGGESTION_CACHE_SIZE = fibonacci(10);          // 55 pre-computed suggestions
const CONTEXT_BUDGET = phiTokenBudgets(8192);        // Tiered token budgets
const INTENT_CONFIDENCE_THRESHOLD = CSL_THRESHOLDS.MEDIUM; // ≈ 0.809
const ANTICIPATION_THRESHOLD = CSL_THRESHOLDS.LOW;   // ≈ 0.691

// Intent categories for conductor routing
const INTENT = Object.freeze({
  CODE_GENERATE:   'code_generate',
  CODE_REVIEW:     'code_review',
  ANALYZE:         'analyze',
  RESEARCH:        'research',
  DEPLOY:          'deploy',
  MONITOR:         'monitor',
  SECURITY:        'security',
  DOCUMENT:        'document',
  CREATIVE:        'creative',
  CONVERSATION:    'conversation',
  SYSTEM_STATUS:   'system_status',
  MEMORY_QUERY:    'memory_query',
  ARCHITECTURE:    'architecture',
});

// ═══════════════════════════════════════════════════════════
// CONVERSATION MANAGER
// ═══════════════════════════════════════════════════════════

class Conversation {
  /**
   * @param {string} userId
   * @param {string} [sessionId]
   */
  constructor(userId, sessionId = null) {
    this.id = sessionId || `conv-${Date.now()}-${Math.random().toString(36).substring(2, fibonacci(6))}`;
    this.userId = userId;
    this.turns = [];
    this.context = { working: [], session: [] };
    this.startedAt = Date.now();
    this.lastActivity = Date.now();
    this.metadata = {};
    this._intentHistory = [];
  }

  addTurn(role, content, metadata = {}) {
    const turn = {
      role,       // 'user' | 'assistant' | 'system'
      content,
      timestamp: Date.now(),
      metadata,
    };

    this.turns.push(turn);
    this.lastActivity = Date.now();

    // Trim oldest turns if over max
    if (this.turns.length > MAX_CONVERSATION_TURNS) {
      // Compress older turns before discarding
      const removed = this.turns.splice(0, this.turns.length - MAX_CONVERSATION_TURNS);
      this.context.session.push({
        type: 'compressed_turns',
        count: removed.length,
        summary: `${removed.length} earlier turns compressed`,
        timestamp: Date.now(),
      });
    }

    return turn;
  }

  getRecentTurns(count = fibonacci(8)) {
    return this.turns.slice(-count);
  }

  recordIntent(intent, confidence) {
    this._intentHistory.push({ intent, confidence, timestamp: Date.now() });
    if (this._intentHistory.length > fibonacci(8)) {
      this._intentHistory = this._intentHistory.slice(-fibonacci(8));
    }
  }

  getDominantIntent() {
    if (this._intentHistory.length === 0) return null;
    const counts = {};
    for (const { intent, confidence } of this._intentHistory) {
      counts[intent] = (counts[intent] || 0) + confidence;
    }
    return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || null;
  }

  get turnCount() { return this.turns.length; }
  get isActive() { return Date.now() - this.lastActivity < TIMING.SESSION_TTL_MS; }

  toJSON() {
    return {
      id: this.id,
      userId: this.userId,
      turnCount: this.turns.length,
      startedAt: this.startedAt,
      lastActivity: this.lastActivity,
      dominantIntent: this.getDominantIntent(),
    };
  }
}

// ═══════════════════════════════════════════════════════════
// USER PREFERENCE STORE
// ═══════════════════════════════════════════════════════════

class PreferenceStore {
  constructor() {
    this._preferences = new Map(); // userId → Map<key, {value, confidence, lastUpdated}>
  }

  /**
   * Learn a user preference from interaction.
   * @param {string} userId
   * @param {string} key — preference key
   * @param {*} value — preference value
   * @param {number} [confidence=PSI] — learning confidence
   */
  learn(userId, key, value, confidence = PSI) {
    if (!this._preferences.has(userId)) {
      this._preferences.set(userId, new Map());
    }

    const userPrefs = this._preferences.get(userId);
    const existing = userPrefs.get(key);

    if (existing) {
      // Blend with existing — phi-weighted moving average
      const blendedConfidence = cslBlend(
        confidence,
        existing.confidence,
        confidence,
        CSL_THRESHOLDS.MINIMUM
      );
      userPrefs.set(key, { value, confidence: blendedConfidence, lastUpdated: Date.now() });
    } else {
      userPrefs.set(key, { value, confidence, lastUpdated: Date.now() });
    }

    // Evict low-confidence entries if over capacity
    if (userPrefs.size > PREFERENCE_STORE_SIZE) {
      let lowestKey = null;
      let lowestConfidence = Infinity;
      for (const [k, v] of userPrefs) {
        if (v.confidence < lowestConfidence) {
          lowestConfidence = v.confidence;
          lowestKey = k;
        }
      }
      if (lowestKey) userPrefs.delete(lowestKey);
    }
  }

  /**
   * Retrieve a user preference.
   * @param {string} userId
   * @param {string} key
   * @returns {Object|null} — { value, confidence } or null
   */
  get(userId, key) {
    return this._preferences.get(userId)?.get(key) || null;
  }

  /**
   * Get all preferences for a user above a confidence threshold.
   * @param {string} userId
   * @param {number} [minConfidence=CSL_THRESHOLDS.LOW]
   * @returns {Object}
   */
  getAll(userId, minConfidence = CSL_THRESHOLDS.LOW) {
    const userPrefs = this._preferences.get(userId);
    if (!userPrefs) return {};

    const result = {};
    for (const [key, pref] of userPrefs) {
      if (pref.confidence >= minConfidence) {
        result[key] = pref;
      }
    }
    return result;
  }
}

// ═══════════════════════════════════════════════════════════
// ANTICIPATION ENGINE
// ═══════════════════════════════════════════════════════════

class AnticipationEngine {
  constructor(preferenceStore) {
    this.preferences = preferenceStore;
    this._patterns = new Map(); // pattern → { suggestion, confidence, hitCount }
  }

  /**
   * Generate anticipatory suggestions based on conversation context and user preferences.
   * @param {string} userId
   * @param {Conversation} conversation
   * @returns {Array<Object>} — suggestions
   */
  suggest(userId, conversation) {
    const suggestions = [];
    const prefs = this.preferences.getAll(userId);
    const recentTurns = conversation.getRecentTurns(fibonacci(5));
    const dominantIntent = conversation.getDominantIntent();

    // Time-based suggestions
    const hour = new Date().getHours();
    if (hour >= fibonacci(6) && hour < fibonacci(7)) { // 8-13: morning
      suggestions.push({
        type: 'time_based',
        text: 'Good morning — would you like a system health summary?',
        intent: INTENT.SYSTEM_STATUS,
        confidence: PSI_SQ,
      });
    }

    // Intent-based suggestions
    if (dominantIntent === INTENT.CODE_GENERATE) {
      suggestions.push({
        type: 'intent_followup',
        text: 'Would you like me to run quality checks on the generated code?',
        intent: INTENT.CODE_REVIEW,
        confidence: PSI,
      });
    }

    if (dominantIntent === INTENT.DEPLOY) {
      suggestions.push({
        type: 'intent_followup',
        text: 'Should I verify deployment health across all services?',
        intent: INTENT.MONITOR,
        confidence: PSI,
      });
    }

    // Preference-based suggestions
    if (prefs.preferred_coding_style) {
      suggestions.push({
        type: 'preference',
        text: `Using your preferred style: ${prefs.preferred_coding_style.value}`,
        intent: INTENT.CODE_GENERATE,
        confidence: prefs.preferred_coding_style.confidence,
      });
    }

    // Pattern-based suggestions
    for (const [pattern, data] of this._patterns) {
      if (data.confidence >= ANTICIPATION_THRESHOLD) {
        suggestions.push({
          type: 'pattern',
          text: data.suggestion,
          confidence: data.confidence,
        });
      }
    }

    // Filter by confidence threshold and sort
    return suggestions
      .filter(s => s.confidence >= ANTICIPATION_THRESHOLD * PSI)
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, fibonacci(5)); // Max 5 suggestions
  }

  /**
   * Record a pattern for future anticipation.
   */
  recordPattern(pattern, suggestion, confidence) {
    const existing = this._patterns.get(pattern);
    if (existing) {
      existing.hitCount++;
      existing.confidence = cslBlend(confidence, existing.confidence, confidence, CSL_THRESHOLDS.MINIMUM);
    } else {
      this._patterns.set(pattern, { suggestion, confidence, hitCount: 1 });
    }

    // Evict if over capacity
    if (this._patterns.size > SUGGESTION_CACHE_SIZE) {
      let lowestKey = null;
      let lowestScore = Infinity;
      for (const [k, v] of this._patterns) {
        const score = v.confidence * v.hitCount;
        if (score < lowestScore) {
          lowestScore = score;
          lowestKey = k;
        }
      }
      if (lowestKey) this._patterns.delete(lowestKey);
    }
  }
}

// ═══════════════════════════════════════════════════════════
// INTENT CLASSIFIER
// ═══════════════════════════════════════════════════════════

class IntentClassifier {
  constructor() {
    // Keyword → intent mapping with confidence
    this._keywords = {
      [INTENT.CODE_GENERATE]: ['build', 'create', 'generate', 'write', 'implement', 'scaffold', 'code'],
      [INTENT.CODE_REVIEW]: ['review', 'check', 'audit', 'inspect', 'validate', 'lint'],
      [INTENT.ANALYZE]: ['analyze', 'diagnose', 'investigate', 'root cause', 'debug', 'why'],
      [INTENT.RESEARCH]: ['research', 'find', 'search', 'lookup', 'what is', 'explain'],
      [INTENT.DEPLOY]: ['deploy', 'release', 'push', 'ship', 'launch', 'rollout'],
      [INTENT.MONITOR]: ['monitor', 'health', 'status', 'metrics', 'dashboard', 'check'],
      [INTENT.SECURITY]: ['security', 'vulnerability', 'risk', 'threat', 'CVE', 'audit'],
      [INTENT.DOCUMENT]: ['document', 'docs', 'README', 'JSDoc', 'API spec', 'describe'],
      [INTENT.CREATIVE]: ['design', 'UI', 'UX', 'visual', 'style', 'layout'],
      [INTENT.SYSTEM_STATUS]: ['system', 'status', 'health', 'uptime', 'services'],
      [INTENT.MEMORY_QUERY]: ['remember', 'recall', 'memory', 'history', 'context'],
      [INTENT.ARCHITECTURE]: ['architecture', 'design', 'structure', 'refactor', 'pattern'],
    };
  }

  /**
   * Classify user intent from message text.
   * @param {string} message
   * @returns {{ intent: string, confidence: number }}
   */
  classify(message) {
    const lower = message.toLowerCase();
    const scores = {};

    for (const [intent, keywords] of Object.entries(this._keywords)) {
      let matchCount = 0;
      for (const kw of keywords) {
        if (lower.includes(kw)) matchCount++;
      }
      if (matchCount > 0) {
        scores[intent] = matchCount / keywords.length;
      }
    }

    // Find best match
    const entries = Object.entries(scores).sort((a, b) => b[1] - a[1]);
    if (entries.length === 0) {
      return { intent: INTENT.CONVERSATION, confidence: PSI_SQ };
    }

    const [bestIntent, bestScore] = entries[0];
    // Scale confidence using CSL gate
    const confidence = cslGate(bestScore, bestScore, CSL_THRESHOLDS.MINIMUM, PHI_TEMPERATURE);

    return { intent: bestIntent, confidence: Math.min(confidence * PHI, 1.0) };
  }
}

// ═══════════════════════════════════════════════════════════
// HEADY BUDDY — MAIN CLASS
// ═══════════════════════════════════════════════════════════

class HeadyBuddy {
  /**
   * @param {Object} options
   * @param {Object} [options.conductor] — HeadyConductor for routing
   * @param {Object} [options.brains] — HeadyBrains for context assembly
   * @param {Object} [options.memoryService] — HeadyMemory for recall
   */
  constructor(options = {}) {
    this.conductor = options.conductor || null;
    this.brains = options.brains || null;
    this.memoryService = options.memoryService || null;

    this.conversations = new Map(); // conversationId → Conversation
    this.preferences = new PreferenceStore();
    this.anticipation = new AnticipationEngine(this.preferences);
    this.classifier = new IntentClassifier();
    this._active = false;

    logger.info({ msg: 'HeadyBuddy initialized' });
  }

  /**
   * Process a user message.
   * @param {string} userId
   * @param {string} message
   * @param {string} [conversationId] — resume existing conversation
   * @returns {Object} — { response, suggestions, intent, conversationId }
   */
  async chat(userId, message, conversationId = null) {
    const startTime = Date.now();

    // Get or create conversation
    let conversation;
    if (conversationId && this.conversations.has(conversationId)) {
      conversation = this.conversations.get(conversationId);
    } else {
      conversation = new Conversation(userId);
      this.conversations.set(conversation.id, conversation);

      // Evict oldest conversations if over max
      if (this.conversations.size > MAX_CONVERSATIONS) {
        let oldestId = null;
        let oldestTime = Infinity;
        for (const [id, conv] of this.conversations) {
          if (conv.lastActivity < oldestTime) {
            oldestTime = conv.lastActivity;
            oldestId = id;
          }
        }
        if (oldestId) this.conversations.delete(oldestId);
      }
    }

    // Record user turn
    conversation.addTurn('user', message);

    // Classify intent
    const { intent, confidence } = this.classifier.classify(message);
    conversation.recordIntent(intent, confidence);

    // Assemble context for conductor
    const context = {
      userId,
      conversationId: conversation.id,
      message,
      intent,
      intentConfidence: confidence,
      recentHistory: conversation.getRecentTurns(fibonacci(5)),
      preferences: this.preferences.getAll(userId),
      turnCount: conversation.turnCount,
    };

    // Route through conductor if available and confident
    let response;
    if (this.conductor && confidence >= INTENT_CONFIDENCE_THRESHOLD) {
      try {
        response = await this._routeToConductor(context);
      } catch (err) {
        logger.info({
          err: err.message,
          intent,
          msg: 'Conductor routing failed, using fallback',
        });
        response = this._generateFallbackResponse(intent, message);
      }
    } else {
      response = this._generateFallbackResponse(intent, message);
    }

    // Record assistant turn
    conversation.addTurn('assistant', response.text, { intent, confidence });

    // Learn preferences from interaction
    this._learnFromInteraction(userId, message, intent);

    // Generate suggestions
    const suggestions = this.anticipation.suggest(userId, conversation);

    const result = {
      conversationId: conversation.id,
      response: response.text,
      intent,
      intentConfidence: Math.round(confidence * 1000) / 1000,
      suggestions,
      duration: Date.now() - startTime,
    };

    logger.info({
      conversationId: conversation.id,
      intent,
      confidence: result.intentConfidence,
      duration: result.duration,
      msg: 'Chat turn processed',
    });

    return result;
  }

  async _routeToConductor(context) {
    // Forward to conductor for intelligent routing
    if (typeof this.conductor.route === 'function') {
      const result = await this.conductor.route({
        type: context.intent,
        query: context.message,
        userId: context.userId,
        context: context.recentHistory,
      });
      return { text: result.response || result.output || 'Task routed successfully.' };
    }
    return { text: 'Processing your request...' };
  }

  _generateFallbackResponse(intent, message) {
    const responses = {
      [INTENT.SYSTEM_STATUS]: { text: 'Checking system health across all services...' },
      [INTENT.CODE_GENERATE]: { text: 'I will generate the requested code. Let me assemble the context...' },
      [INTENT.CODE_REVIEW]: { text: 'I will review the code for quality, security, and phi-compliance...' },
      [INTENT.ANALYZE]: { text: 'Starting deep analysis — I will trace root causes and provide a diagnosis...' },
      [INTENT.DEPLOY]: { text: 'Preparing deployment — running quality gates and assurance checks...' },
      [INTENT.SECURITY]: { text: 'Running security scan — checking vulnerabilities, dependencies, and CVEs...' },
      [INTENT.DOCUMENT]: { text: 'Generating documentation from code analysis...' },
      [INTENT.CONVERSATION]: { text: 'I am Heady — your companion intelligence. How can I help you build today?' },
    };
    return responses[intent] || { text: 'I am processing your request through the conductor...' };
  }

  _learnFromInteraction(userId, message, intent) {
    // Learn communication style preference
    if (message.length < fibonacci(8) * 3) { // Short messages → user prefers brevity
      this.preferences.learn(userId, 'response_style', 'concise', PSI_SQ);
    } else {
      this.preferences.learn(userId, 'response_style', 'detailed', PSI_SQ);
    }

    // Learn domain preference
    this.preferences.learn(userId, `frequent_intent_${intent}`, true, PSI);
  }

  /**
   * Get conversation history for a user.
   */
  getConversations(userId) {
    const convos = [];
    for (const conv of this.conversations.values()) {
      if (conv.userId === userId) convos.push(conv.toJSON());
    }
    return convos.sort((a, b) => b.lastActivity - a.lastActivity);
  }

  health() {
    return {
      service: 'heady-buddy',
      status: this._active ? 'healthy' : 'ready',
      activeConversations: this.conversations.size,
      totalTurns: [...this.conversations.values()].reduce((s, c) => s + c.turnCount, 0),
    };
  }
}

module.exports = { HeadyBuddy, Conversation, PreferenceStore, AnticipationEngine, IntentClassifier, INTENT };
