/**
 * GraphRAG Module — LightRAG-style Knowledge Graph with Community Detection
 * 
 * Incremental entity extraction, relationship graph construction, Louvain
 * community detection, and hybrid query modes (local/global/hybrid/naive).
 * Integrates with HeadyMemory for vector search and HeadyEmbed for embeddings.
 * 
 * Features:
 * - LLM-based entity extraction with regex NER fallback
 * - Relationship graph with weighted edges
 * - Louvain community detection with modularity optimization
 * - 4 query modes: local (entity hops), global (community summaries), hybrid, naive
 * - Phi-fusion weighted blending for hybrid queries
 * - Incremental graph updates (no full re-index required)
 * - Entity deduplication via DEDUP_THRESHOLD (≈ 0.972)
 * 
 * @module graph-rag
 * @version 1.0.0
 * @author Eric Haywood
 */

const {
  PHI,
  PSI,
  PHI2,
  PHI3,
  fib,
  fibonacci,
  phiThreshold,
  phiFusionWeights,
  phiBackoff,
  CSL_THRESHOLDS,
  PRESSURE_LEVELS,
  SIZING,
  cslGate,
  cosineSimilarity,
  DEDUP_THRESHOLD
} = require('../../shared/phi-math.js');
const { createLogger } = require('../../shared/logger.js');
const { createHealthCheck } = require('../../shared/health.js');

const logger = createLogger('graph-rag');

/* ═══════════════════════════════════════════════════════════════
   §1 — Constants (all phi-derived)
   ═══════════════════════════════════════════════════════════════ */

const MAX_ENTITIES_PER_DOC = fib(10);    // 55 entities per document
const MAX_RELATIONSHIPS_PER_DOC = fib(11); // 89 relationships per document
const DEFAULT_RESULT_LIMIT = fib(7);     // 13 results
const DEFAULT_HOP_DEPTH = fib(4);        // 3 hops for graph traversal
const MIN_EDGE_WEIGHT = Math.pow(PSI, 4); // ≈ 0.146
const MAX_COMMUNITY_ITERATIONS = fib(7); // 13 iterations for Louvain
const ENTITY_CACHE_SIZE = fib(16);       // 987 cached entities
const COMMUNITY_CACHE_SIZE = fib(14);    // 377 cached community summaries
const OVERSAMPLE_FACTOR = PHI;           // 1.618× oversample for retrieval
const HYBRID_WEIGHTS = phiFusionWeights(2); // [0.618 local, 0.382 global]
const BATCH_SIZE = fib(8);               // 21 entities per batch
const ENTITY_DEDUP = DEDUP_THRESHOLD || CSL_THRESHOLDS.CRITICAL + 0.045; // ≈ 0.972

/** Entity types for NER extraction */
const ENTITY_TYPES = [
  'PERSON', 'ORGANIZATION', 'TECHNOLOGY', 'CONCEPT', 'SERVICE',
  'LOCATION', 'EVENT', 'METRIC', 'PROTOCOL', 'COMPONENT'
];

/** Relationship types */
const RELATIONSHIP_TYPES = [
  'USES', 'DEPENDS_ON', 'EXTENDS', 'IMPLEMENTS', 'CONTAINS',
  'PRODUCES', 'CONSUMES', 'COMMUNICATES_WITH', 'MANAGES',
  'AUTHORED_BY', 'LOCATED_IN', 'PART_OF', 'RELATED_TO'
];

/* ═══════════════════════════════════════════════════════════════
   §2 — Graph Data Structures
   ═══════════════════════════════════════════════════════════════ */

class KnowledgeGraph {
  constructor(graphId = 'default') {
    this._graphId = graphId;
    this._entities = new Map();       // id -> entity
    this._relationships = new Map();  // id -> relationship
    this._adjacency = new Map();      // entityId -> Set<relationshipId>
    this._communities = new Map();    // communityId -> community
    this._entityIndex = new Map();    // name -> entityId (normalized)
    this._embeddings = new Map();     // entityId -> embedding vector
    this._stats = {
      entitiesAdded: 0,
      relationshipsAdded: 0,
      documentsProcessed: 0,
      queriesExecuted: 0,
      communityDetections: 0,
      deduplicatedEntities: 0
    };
  }

  /* ── Entity Management ── */

  /**
   * Add or merge an entity into the graph
   * @param {object} entity - Entity to add
   * @returns {object} Added/merged entity
   */
  addEntity(entity) {
    const { name, type, description, embedding, metadata = {} } = entity;
    const normalizedName = name.toLowerCase().trim();
    
    // Check for duplicate via name index
    const existingId = this._entityIndex.get(normalizedName);
    if (existingId) {
      return this._mergeEntity(existingId, entity);
    }

    // Check for semantic duplicate via embedding
    if (embedding) {
      const duplicate = this._findSemanticDuplicate(embedding);
      if (duplicate) {
        this._stats.deduplicatedEntities++;
        return this._mergeEntity(duplicate.id, entity);
      }
    }

    const id = _generateId();
    const newEntity = {
      id,
      graphId: this._graphId,
      name,
      normalizedName,
      type: type || 'CONCEPT',
      description: description || '',
      embedding,
      metadata,
      communityId: null,
      degree: 0,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    this._entities.set(id, newEntity);
    this._entityIndex.set(normalizedName, id);
    this._adjacency.set(id, new Set());
    if (embedding) this._embeddings.set(id, embedding);
    this._stats.entitiesAdded++;

    logger.info({ event: 'entity_added', entityId: id, name, type });
    return newEntity;
  }

  _mergeEntity(existingId, newData) {
    const existing = this._entities.get(existingId);
    if (!existing) return null;

    // Merge descriptions
    if (newData.description && !existing.description.includes(newData.description)) {
      existing.description = existing.description
        ? `${existing.description} ${newData.description}`
        : newData.description;
    }

    // Update embedding if provided
    if (newData.embedding) {
      existing.embedding = newData.embedding;
      this._embeddings.set(existingId, newData.embedding);
    }

    // Merge metadata
    existing.metadata = { ...existing.metadata, ...newData.metadata };
    existing.updatedAt = Date.now();

    return existing;
  }

  _findSemanticDuplicate(embedding) {
    for (const [entityId, existingEmb] of this._embeddings) {
      const sim = cosineSimilarity(embedding, existingEmb);
      if (sim >= ENTITY_DEDUP) {
        return this._entities.get(entityId);
      }
    }
    return null;
  }

  /* ── Relationship Management ── */

  /**
   * Add a relationship between two entities
   * @param {object} rel - Relationship to add
   * @returns {object} Added relationship
   */
  addRelationship(rel) {
    const { sourceId, targetId, type, weight = PSI, description = '' } = rel;
    
    if (!this._entities.has(sourceId) || !this._entities.has(targetId)) {
      logger.warn({ event: 'relationship_skip', reason: 'entity_not_found', sourceId, targetId });
      return null;
    }

    if (weight < MIN_EDGE_WEIGHT) {
      logger.info({ event: 'relationship_skip', reason: 'below_min_weight', weight, min: MIN_EDGE_WEIGHT });
      return null;
    }

    // Check for existing relationship
    const existingKey = `${sourceId}-${type}-${targetId}`;
    for (const [id, existing] of this._relationships) {
      if (existing.sourceId === sourceId && existing.targetId === targetId && existing.type === type) {
        // Strengthen existing relationship
        existing.weight = Math.min(1, existing.weight + weight * PSI);
        existing.updatedAt = Date.now();
        return existing;
      }
    }

    const id = _generateId();
    const newRel = {
      id,
      graphId: this._graphId,
      sourceId,
      targetId,
      type: type || 'RELATED_TO',
      weight,
      description,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    this._relationships.set(id, newRel);
    this._adjacency.get(sourceId)?.add(id);
    this._adjacency.get(targetId)?.add(id);
    
    // Update degree
    const source = this._entities.get(sourceId);
    const target = this._entities.get(targetId);
    if (source) source.degree++;
    if (target) target.degree++;

    this._stats.relationshipsAdded++;
    return newRel;
  }

  /* ── Graph Traversal ── */

  /**
   * Get neighbors of an entity within N hops
   * @param {string} entityId - Starting entity
   * @param {number} [maxHops] - Max traversal depth
   * @returns {Array} Entities within hop distance
   */
  getNeighbors(entityId, maxHops = DEFAULT_HOP_DEPTH) {
    const visited = new Set();
    const results = [];
    const queue = [{ id: entityId, depth: 0 }];

    while (queue.length > 0) {
      const { id, depth } = queue.shift();
      if (visited.has(id) || depth > maxHops) continue;
      visited.add(id);

      const entity = this._entities.get(id);
      if (entity && id !== entityId) {
        results.push({ ...entity, hopDistance: depth });
      }

      if (depth < maxHops) {
        const edges = this._adjacency.get(id) || new Set();
        for (const relId of edges) {
          const rel = this._relationships.get(relId);
          if (!rel) continue;
          const nextId = rel.sourceId === id ? rel.targetId : rel.sourceId;
          if (!visited.has(nextId)) {
            queue.push({ id: nextId, depth: depth + 1 });
          }
        }
      }
    }

    return results;
  }

  /**
   * Find shortest path between two entities
   * @param {string} fromId - Source entity
   * @param {string} toId - Target entity
   * @returns {Array|null} Path of entity IDs or null
   */
  findPath(fromId, toId) {
    const visited = new Set();
    const queue = [{ id: fromId, path: [fromId] }];

    while (queue.length > 0) {
      const { id, path } = queue.shift();
      if (id === toId) return path;
      if (visited.has(id)) continue;
      visited.add(id);

      const edges = this._adjacency.get(id) || new Set();
      for (const relId of edges) {
        const rel = this._relationships.get(relId);
        if (!rel) continue;
        const nextId = rel.sourceId === id ? rel.targetId : rel.sourceId;
        if (!visited.has(nextId)) {
          queue.push({ id: nextId, path: [...path, nextId] });
        }
      }
    }

    return null;
  }
}

/* ═══════════════════════════════════════════════════════════════
   §3 — Entity Extraction Engine
   ═══════════════════════════════════════════════════════════════ */

/**
 * Extract entities from text using regex NER (LLM-free fallback)
 * @param {string} text - Text to extract from
 * @param {object} [options] - Extraction options
 * @returns {Array} Extracted entities
 */
function extractEntities(text, options = {}) {
  const { maxEntities = MAX_ENTITIES_PER_DOC } = options;
  const entities = [];
  const seen = new Set();

  // Pattern-based extraction for each entity type
  const patterns = [
    // Technology: PascalCase or known tech patterns
    { type: 'TECHNOLOGY', pattern: /\b(?:Node\.js|JavaScript|TypeScript|Python|Rust|Go|React|Vue|Express|PostgreSQL|Redis|NATS|Docker|Kubernetes|Cloudflare|Firebase|GCP|AWS|Azure)\b/gi },
    // Components: Heady-specific patterns
    { type: 'COMPONENT', pattern: /\b(?:Heady(?:Soul|Brains|Memory|Embed|Vinci|Buddy|Battle|Conductor|Manager|Bee|Swarm|Check|Assure|Codex|Risks|MC|Patterns|Refactor|Copilot|Maid|Maintenance)|LiquidNode|LiquidMesh|LiquidDeploy|GraphRAG|BeeFactory|TaskDecomposer|BackpressureManager|ContextWindowManager|SocraticLoop|DurableObjectManager|EmbeddingRouter)\b/g },
    // Services: known service names
    { type: 'SERVICE', pattern: /\b(?:auth[- ]?service|notification[- ]?service|analytics[- ]?service|scheduler[- ]?service|rate[- ]?limiter|backup[- ]?service|edge[- ]?worker|website[- ]?server)\b/gi },
    // Protocols: uppercase abbreviations
    { type: 'PROTOCOL', pattern: /\b(?:HTTP|HTTPS|WebSocket|SSE|gRPC|mTLS|JSON[- ]?RPC|OAuth|OIDC|JWT|CORS|CSP|HSTS|MCP)\b/g },
    // Concepts: phi-math and CSL terms
    { type: 'CONCEPT', pattern: /\b(?:golden ratio|Fibonacci|phi-math|CSL|Continuous Semantic Logic|cosine similarity|vector space|embedding|384[Dd]|HNSW|pgvector|self-healing|liquid architecture|backpressure|circuit breaker|graceful shutdown)\b/gi },
    // Metrics
    { type: 'METRIC', pattern: /\b(?:latency|throughput|availability|uptime|error rate|cache hit|p\d+|SLA|SLO|SLI)\b/gi },
    // Capitalized multi-word names (potential entities)
    { type: 'CONCEPT', pattern: /\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b/g }
  ];

  for (const { type, pattern } of patterns) {
    const regex = new RegExp(pattern.source, pattern.flags);
    let match;
    while ((match = regex.exec(text)) !== null) {
      const name = match[0].trim();
      const normalizedName = name.toLowerCase();
      if (!seen.has(normalizedName) && name.length > 1) {
        seen.add(normalizedName);
        entities.push({
          name,
          type,
          description: _extractContext(text, match.index),
          metadata: { source: 'regex-ner', confidence: CSL_THRESHOLDS.MEDIUM }
        });
      }
      if (entities.length >= maxEntities) break;
    }
    if (entities.length >= maxEntities) break;
  }

  logger.info({ event: 'entities_extracted', count: entities.length });
  return entities;
}

/**
 * Extract relationships from text between known entities
 * @param {string} text - Text to analyze
 * @param {Array} entities - Known entities
 * @returns {Array} Extracted relationships
 */
function extractRelationships(text, entities, options = {}) {
  const { maxRelationships = MAX_RELATIONSHIPS_PER_DOC } = options;
  const relationships = [];
  const entityNames = new Map(entities.map(e => [e.name.toLowerCase(), e]));
  
  // Relationship verb patterns
  const verbPatterns = [
    { type: 'USES', pattern: /\buses\b|\butilizes\b|\bleverages\b|\bemploys\b/i },
    { type: 'DEPENDS_ON', pattern: /\bdepends on\b|\brequires\b|\bneeds\b|\brelies on\b/i },
    { type: 'EXTENDS', pattern: /\bextends\b|\binherits\b|\bbuilds on\b/i },
    { type: 'IMPLEMENTS', pattern: /\bimplements\b|\brealizes\b|\bprovides\b/i },
    { type: 'CONTAINS', pattern: /\bcontains\b|\bincludes\b|\bcomprises\b/i },
    { type: 'PRODUCES', pattern: /\bproduces\b|\bgenerates\b|\bcreates\b|\boutputs\b/i },
    { type: 'CONSUMES', pattern: /\bconsumes\b|\breads\b|\bingests\b|\bprocesses\b/i },
    { type: 'COMMUNICATES_WITH', pattern: /\bcommunicates with\b|\bsends to\b|\breceives from\b|\bconnects to\b/i },
    { type: 'MANAGES', pattern: /\bmanages\b|\bcontrols\b|\borchestrates\b|\bcoordinates\b/i }
  ];

  // Sentence-level relationship extraction
  const sentences = text.split(/[.!?\n]+/).filter(s => s.trim().length > 0);
  
  for (const sentence of sentences) {
    const lowerSentence = sentence.toLowerCase();
    const foundEntities = [];

    for (const [name, entity] of entityNames) {
      if (lowerSentence.includes(name)) {
        foundEntities.push(entity);
      }
    }

    // For each pair of entities in the sentence, find relationships
    for (let i = 0; i < foundEntities.length - 1; i++) {
      for (let j = i + 1; j < foundEntities.length; j++) {
        let relType = 'RELATED_TO';
        let weight = PSI; // default 0.618

        for (const { type, pattern } of verbPatterns) {
          if (pattern.test(sentence)) {
            relType = type;
            weight = CSL_THRESHOLDS.MEDIUM * PSI; // ≈ 0.500
            break;
          }
        }

        relationships.push({
          source: foundEntities[i].name,
          target: foundEntities[j].name,
          type: relType,
          weight,
          description: sentence.trim().substring(0, fib(11)) // 89 char context
        });

        if (relationships.length >= maxRelationships) break;
      }
      if (relationships.length >= maxRelationships) break;
    }
    if (relationships.length >= maxRelationships) break;
  }

  logger.info({ event: 'relationships_extracted', count: relationships.length });
  return relationships;
}

function _extractContext(text, index) {
  const contextChars = fib(11); // 89 characters
  const start = Math.max(0, index - contextChars);
  const end = Math.min(text.length, index + contextChars);
  return text.substring(start, end).replace(/\s+/g, ' ').trim();
}

/* ═══════════════════════════════════════════════════════════════
   §4 — Louvain Community Detection
   ═══════════════════════════════════════════════════════════════ */

/**
 * Detect communities using Louvain modularity optimization
 * @param {KnowledgeGraph} graph - Knowledge graph
 * @returns {object} Community detection results
 */
function detectCommunities(graph) {
  const entities = Array.from(graph._entities.values());
  const relationships = Array.from(graph._relationships.values());
  
  if (entities.length === 0) return { communities: [], modularity: 0 };

  // Initialize: each entity in its own community
  const communityOf = new Map();
  entities.forEach((e, i) => communityOf.set(e.id, i));

  // Build adjacency with weights
  const adjWeights = new Map();
  for (const e of entities) adjWeights.set(e.id, new Map());
  
  for (const rel of relationships) {
    const w = adjWeights.get(rel.sourceId);
    const v = adjWeights.get(rel.targetId);
    if (w) w.set(rel.targetId, (w.get(rel.targetId) || 0) + rel.weight);
    if (v) v.set(rel.sourceId, (v.get(rel.sourceId) || 0) + rel.weight);
  }

  // Total weight
  const totalWeight = relationships.reduce((sum, r) => sum + r.weight, 0) * 2 || 1;

  // Degree of each node
  const degree = new Map();
  for (const e of entities) {
    let d = 0;
    for (const w of (adjWeights.get(e.id)?.values() || [])) d += w;
    degree.set(e.id, d);
  }

  // Louvain iterations
  let improved = true;
  let iterations = 0;

  while (improved && iterations < MAX_COMMUNITY_ITERATIONS) {
    improved = false;
    iterations++;

    for (const entity of entities) {
      const nodeId = entity.id;
      const currentCommunity = communityOf.get(nodeId);
      const nodeDegree = degree.get(nodeId) || 0;

      // Calculate modularity gain for moving to each neighbor's community
      let bestCommunity = currentCommunity;
      let bestGain = 0;

      const neighbors = adjWeights.get(nodeId) || new Map();
      const neighborCommunities = new Set();
      for (const [nId] of neighbors) {
        neighborCommunities.add(communityOf.get(nId));
      }

      for (const targetCommunity of neighborCommunities) {
        if (targetCommunity === currentCommunity) continue;

        // Sum of weights from node to target community
        let sumTo = 0;
        for (const [nId, w] of neighbors) {
          if (communityOf.get(nId) === targetCommunity) sumTo += w;
        }

        // Sum of degrees in target community
        let communityDegree = 0;
        for (const [eId, comm] of communityOf) {
          if (comm === targetCommunity) communityDegree += degree.get(eId) || 0;
        }

        // Modularity gain
        const gain = sumTo / totalWeight - (communityDegree * nodeDegree) / (totalWeight * totalWeight);

        if (gain > bestGain) {
          bestGain = gain;
          bestCommunity = targetCommunity;
        }
      }

      if (bestCommunity !== currentCommunity) {
        communityOf.set(nodeId, bestCommunity);
        improved = true;
      }
    }
  }

  // Build community objects
  const communityEntities = new Map();
  for (const [entityId, commId] of communityOf) {
    if (!communityEntities.has(commId)) communityEntities.set(commId, []);
    communityEntities.get(commId).push(entityId);
  }

  const communities = [];
  for (const [commId, entityIds] of communityEntities) {
    if (entityIds.length < 2) continue; // Skip singleton communities

    const memberEntities = entityIds.map(id => graph._entities.get(id)).filter(Boolean);
    const summary = _generateCommunitySummary(memberEntities, graph);

    const community = {
      id: _generateId(),
      graphId: graph._graphId,
      level: 0,
      summary,
      entityIds,
      size: entityIds.length
    };

    communities.push(community);
    graph._communities.set(community.id, community);

    // Assign community to entities
    for (const eid of entityIds) {
      const entity = graph._entities.get(eid);
      if (entity) entity.communityId = community.id;
    }
  }

  // Calculate modularity
  const modularity = _calculateModularity(communityOf, adjWeights, degree, totalWeight);

  graph._stats.communityDetections++;
  logger.info({
    event: 'communities_detected',
    count: communities.length,
    iterations,
    modularity: modularity.toFixed(3)
  });

  return { communities, modularity, iterations };
}

function _generateCommunitySummary(entities, graph) {
  const types = new Map();
  const names = [];

  for (const entity of entities) {
    types.set(entity.type, (types.get(entity.type) || 0) + 1);
    names.push(entity.name);
  }

  const topType = [...types.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] || 'CONCEPT';
  const topNames = names.slice(0, fib(5)).join(', ');

  return `Community of ${entities.length} ${topType} entities including: ${topNames}`;
}

function _calculateModularity(communityOf, adjWeights, degree, totalWeight) {
  let Q = 0;
  for (const [nodeId, neighbors] of adjWeights) {
    for (const [neighborId, weight] of neighbors) {
      if (communityOf.get(nodeId) === communityOf.get(neighborId)) {
        const ki = degree.get(nodeId) || 0;
        const kj = degree.get(neighborId) || 0;
        Q += weight - (ki * kj) / totalWeight;
      }
    }
  }
  return Q / totalWeight;
}

/* ═══════════════════════════════════════════════════════════════
   §5 — Query Engine (4 modes)
   ═══════════════════════════════════════════════════════════════ */

/**
 * Query the knowledge graph
 * @param {KnowledgeGraph} graph - Knowledge graph to query
 * @param {string} query - Natural language query
 * @param {object} [options] - Query options
 * @returns {object} Query results
 */
function queryGraph(graph, query, options = {}) {
  const {
    mode = 'hybrid',
    limit = DEFAULT_RESULT_LIMIT,
    hops = DEFAULT_HOP_DEPTH,
    queryEmbedding = null
  } = options;

  graph._stats.queriesExecuted++;
  let results;

  switch (mode) {
    case 'local':
      results = _queryLocal(graph, query, queryEmbedding, limit, hops);
      break;
    case 'global':
      results = _queryGlobal(graph, query, queryEmbedding, limit);
      break;
    case 'hybrid':
      results = _queryHybrid(graph, query, queryEmbedding, limit, hops);
      break;
    case 'naive':
      results = _queryNaive(graph, query, queryEmbedding, limit);
      break;
    default:
      results = _queryHybrid(graph, query, queryEmbedding, limit, hops);
  }

  logger.info({ event: 'graph_query', mode, resultCount: results.items.length, limit });
  return results;
}

/**
 * Local query: Entity similarity + graph traversal
 */
function _queryLocal(graph, query, queryEmbedding, limit, hops) {
  const oversampleLimit = Math.ceil(limit * OVERSAMPLE_FACTOR);
  
  // Find nearest entities by embedding similarity
  let seedEntities = [];
  if (queryEmbedding) {
    seedEntities = _findSimilarEntities(graph, queryEmbedding, fib(5));
  } else {
    // Fallback: keyword matching
    seedEntities = _keywordSearch(graph, query, fib(5));
  }

  // Expand via graph traversal
  const expanded = new Map();
  for (const seed of seedEntities) {
    expanded.set(seed.id, { ...seed, source: 'seed' });
    const neighbors = graph.getNeighbors(seed.id, hops);
    for (const neighbor of neighbors) {
      if (!expanded.has(neighbor.id)) {
        const decayFactor = Math.pow(PSI, neighbor.hopDistance);
        expanded.set(neighbor.id, {
          ...neighbor,
          similarity: (seed.similarity || CSL_THRESHOLDS.LOW) * decayFactor,
          source: 'traversal'
        });
      }
    }
  }

  // Collect relationships between expanded entities
  const relevantRels = [];
  for (const [entityId] of expanded) {
    const edges = graph._adjacency.get(entityId) || new Set();
    for (const relId of edges) {
      const rel = graph._relationships.get(relId);
      if (rel && expanded.has(rel.sourceId) && expanded.has(rel.targetId)) {
        relevantRels.push(rel);
      }
    }
  }

  const items = [...expanded.values()]
    .sort((a, b) => (b.similarity || 0) - (a.similarity || 0))
    .slice(0, limit);

  return {
    mode: 'local',
    items,
    relationships: relevantRels.slice(0, fib(8)),
    seedCount: seedEntities.length,
    expandedCount: expanded.size
  };
}

/**
 * Global query: Community summaries + vector search
 */
function _queryGlobal(graph, query, queryEmbedding, limit) {
  const communities = Array.from(graph._communities.values());
  
  if (communities.length === 0) {
    return { mode: 'global', items: [], communities: [], message: 'No communities detected' };
  }

  // Rank communities by relevance to query
  const rankedCommunities = communities.map(comm => {
    const relevance = _textSimilarity(query.toLowerCase(), comm.summary.toLowerCase());
    return { ...comm, relevance };
  }).sort((a, b) => b.relevance - a.relevance);

  // Collect entities from top communities
  const items = [];
  for (const comm of rankedCommunities.slice(0, fib(5))) {
    for (const entityId of comm.entityIds) {
      const entity = graph._entities.get(entityId);
      if (entity) {
        items.push({ ...entity, communityRelevance: comm.relevance, source: 'community' });
      }
    }
  }

  return {
    mode: 'global',
    items: items.slice(0, limit),
    communities: rankedCommunities.slice(0, fib(5)).map(c => ({
      id: c.id,
      summary: c.summary,
      size: c.size,
      relevance: c.relevance
    }))
  };
}

/**
 * Hybrid query: Phi-weighted blend of local and global
 */
function _queryHybrid(graph, query, queryEmbedding, limit, hops) {
  const oversampleLimit = Math.ceil(limit * OVERSAMPLE_FACTOR);
  
  const localResults = _queryLocal(graph, query, queryEmbedding, oversampleLimit, hops);
  const globalResults = _queryGlobal(graph, query, queryEmbedding, oversampleLimit);

  // Merge with phi-fusion weights: [0.618 local, 0.382 global]
  const merged = new Map();

  for (const item of localResults.items) {
    merged.set(item.id, {
      ...item,
      hybridScore: (item.similarity || CSL_THRESHOLDS.LOW) * HYBRID_WEIGHTS[0]
    });
  }

  for (const item of globalResults.items) {
    const existing = merged.get(item.id);
    if (existing) {
      existing.hybridScore += (item.communityRelevance || CSL_THRESHOLDS.LOW) * HYBRID_WEIGHTS[1];
      existing.source = 'both';
    } else {
      merged.set(item.id, {
        ...item,
        hybridScore: (item.communityRelevance || CSL_THRESHOLDS.LOW) * HYBRID_WEIGHTS[1]
      });
    }
  }

  const items = [...merged.values()]
    .sort((a, b) => b.hybridScore - a.hybridScore)
    .slice(0, limit);

  return {
    mode: 'hybrid',
    items,
    localCount: localResults.items.length,
    globalCount: globalResults.items.length,
    communities: globalResults.communities
  };
}

/**
 * Naive query: Pure vector similarity (no graph traversal)
 */
function _queryNaive(graph, query, queryEmbedding, limit) {
  if (queryEmbedding) {
    const items = _findSimilarEntities(graph, queryEmbedding, limit);
    return { mode: 'naive', items };
  }

  // Fallback to keyword search
  const items = _keywordSearch(graph, query, limit);
  return { mode: 'naive', items };
}

/* ═══════════════════════════════════════════════════════════════
   §6 — Search Utilities
   ═══════════════════════════════════════════════════════════════ */

function _findSimilarEntities(graph, queryEmbedding, limit) {
  const results = [];
  
  for (const [entityId, embedding] of graph._embeddings) {
    const similarity = cosineSimilarity(queryEmbedding, embedding);
    if (similarity >= CSL_THRESHOLDS.MINIMUM) {
      const entity = graph._entities.get(entityId);
      if (entity) {
        results.push({ ...entity, similarity });
      }
    }
  }

  return results
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, limit);
}

function _keywordSearch(graph, query, limit) {
  const queryWords = query.toLowerCase().split(/\s+/).filter(w => w.length > 2);
  const results = [];

  for (const [, entity] of graph._entities) {
    let score = 0;
    const entityText = `${entity.name} ${entity.description} ${entity.type}`.toLowerCase();
    
    for (const word of queryWords) {
      if (entityText.includes(word)) score++;
    }

    if (score > 0) {
      const normalizedScore = score / queryWords.length;
      results.push({ ...entity, similarity: normalizedScore });
    }
  }

  return results
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, limit);
}

function _textSimilarity(a, b) {
  const wordsA = new Set(a.split(/\s+/).filter(w => w.length > 2));
  const wordsB = new Set(b.split(/\s+/).filter(w => w.length > 2));
  if (wordsA.size === 0 || wordsB.size === 0) return 0;
  
  let overlap = 0;
  for (const word of wordsA) {
    if (wordsB.has(word)) overlap++;
  }
  
  return (2 * overlap) / (wordsA.size + wordsB.size);
}

/* ═══════════════════════════════════════════════════════════════
   §7 — Document Ingestion Pipeline
   ═══════════════════════════════════════════════════════════════ */

/**
 * Ingest a document into the knowledge graph
 * @param {KnowledgeGraph} graph - Target graph
 * @param {string} text - Document text
 * @param {object} [options] - Ingestion options
 * @returns {object} Ingestion results
 */
function ingestDocument(graph, text, options = {}) {
  const { documentId = _generateId(), embedFn = null } = options;

  // Step 1: Extract entities
  const rawEntities = extractEntities(text, options);
  
  // Step 2: Add entities to graph (with optional embedding)
  const addedEntities = [];
  for (const rawEntity of rawEntities) {
    let embedding = null;
    if (embedFn) {
      try { embedding = embedFn(rawEntity.name); } catch (_) { /* fallback: no embedding */ }
    }
    const entity = graph.addEntity({ ...rawEntity, embedding });
    addedEntities.push(entity);
  }

  // Step 3: Extract relationships
  const rawRelationships = extractRelationships(text, addedEntities, options);

  // Step 4: Add relationships to graph
  const addedRels = [];
  for (const rawRel of rawRelationships) {
    const sourceEntity = addedEntities.find(e => e.name === rawRel.source);
    const targetEntity = addedEntities.find(e => e.name === rawRel.target);
    if (sourceEntity && targetEntity) {
      const rel = graph.addRelationship({
        sourceId: sourceEntity.id,
        targetId: targetEntity.id,
        type: rawRel.type,
        weight: rawRel.weight,
        description: rawRel.description
      });
      if (rel) addedRels.push(rel);
    }
  }

  graph._stats.documentsProcessed++;

  logger.info({
    event: 'document_ingested',
    documentId,
    entities: addedEntities.length,
    relationships: addedRels.length
  });

  return {
    documentId,
    entitiesAdded: addedEntities.length,
    relationshipsAdded: addedRels.length,
    entities: addedEntities.map(e => ({ id: e.id, name: e.name, type: e.type })),
    relationships: addedRels.map(r => ({ sourceId: r.sourceId, targetId: r.targetId, type: r.type }))
  };
}

/* ═══════════════════════════════════════════════════════════════
   §8 — Graph Statistics & Export
   ═══════════════════════════════════════════════════════════════ */

function getGraphStats(graph) {
  return {
    graphId: graph._graphId,
    entities: graph._entities.size,
    relationships: graph._relationships.size,
    communities: graph._communities.size,
    embeddings: graph._embeddings.size,
    ...graph._stats
  };
}

function exportGraph(graph) {
  return {
    graphId: graph._graphId,
    entities: Array.from(graph._entities.values()).map(({ embedding, ...rest }) => rest),
    relationships: Array.from(graph._relationships.values()),
    communities: Array.from(graph._communities.values()),
    stats: getGraphStats(graph)
  };
}

/* ═══════════════════════════════════════════════════════════════
   §9 — Utility
   ═══════════════════════════════════════════════════════════════ */

let _idCounter = 0;
function _generateId() {
  return `grag_${Date.now().toString(36)}_${(++_idCounter).toString(36)}`;
}

/* ═══════════════════════════════════════════════════════════════
   §10 — Health & Export
   ═══════════════════════════════════════════════════════════════ */

const health = createHealthCheck('graph-rag', () => ({
  entityTypes: ENTITY_TYPES.length,
  relationshipTypes: RELATIONSHIP_TYPES.length,
  maxEntitiesPerDoc: MAX_ENTITIES_PER_DOC,
  maxRelationshipsPerDoc: MAX_RELATIONSHIPS_PER_DOC,
  hybridWeights: HYBRID_WEIGHTS
}));



module.exports = {
  KnowledgeGraph,
  extractEntities,
  extractRelationships,
  detectCommunities,
  queryGraph,
  ingestDocument,
  getGraphStats,
  exportGraph,
  health,
  ENTITY_TYPES,
  RELATIONSHIP_TYPES
};
