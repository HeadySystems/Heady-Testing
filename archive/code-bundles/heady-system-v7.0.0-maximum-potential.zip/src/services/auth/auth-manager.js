/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Auth Manager v2.0
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Firebase Auth + httpOnly cookie sessions. ZERO localStorage tokens.
 * JWT via __Host-heady_session httpOnly secure cookie.
 * RBAC with admin/operator/user/guest hierarchy.
 * API key management with SHA-256 hashing.
 * OAuth2/OIDC flow support.
 *
 * © 2026 HeadySystems Inc. — Eric Haywood
 */

'use strict';

const crypto = require('crypto');
const { PHI, fib, CSL_THRESHOLDS } = require('../../../shared/phi-math');
const { createLogger } = require('../../../shared/logger');
const logger = createLogger('auth-manager');

const ROLES = Object.freeze({ ADMIN: 'admin', OPERATOR: 'operator', USER: 'user', GUEST: 'guest' });
const ROLE_HIERARCHY = { [ROLES.ADMIN]: 4, [ROLES.OPERATOR]: 3, [ROLES.USER]: 2, [ROLES.GUEST]: 1 };

const SESSION_TTL_MS = fib(8) * 60 * 60 * 1000;  // 21 hours (fib(8)=21)
const REFRESH_TTL_MS = fib(9) * 24 * 60 * 60 * 1000; // 34 days (fib(9)=34)
const ACCESS_TTL_S   = fib(7) * 60 * 5;            // 13 × 5min = 65 min
const COOKIE_NAME    = '__Host-heady_session';
const API_KEY_PREFIX = 'hdy_';

class AuthManager {
  constructor(opts = {}) {
    this._sessions = new Map();
    this._apiKeys = new Map();
    this._refreshIndex = new Map();
    this.sessionTtlMs = opts.sessionTtlMs || SESSION_TTL_MS;
    this._firebaseAdmin = opts.firebaseAdmin || null;
    logger.info({ event: 'auth_manager_init', sessionTtlMs: this.sessionTtlMs });
  }

  async createSession(user) {
    _validateUser(user);
    const sessionId = _randomId();
    const now = Date.now();
    const refreshToken = _randomId(64);
    const refreshHash = _hashSecret(refreshToken);

    const session = {
      userId: user.id, email: user.email,
      role: user.role || ROLES.USER,
      refreshHash,
      createdAt: now,
      expiresAt: now + this.sessionTtlMs,
      meta: user.meta || {},
    };

    this._sessions.set(sessionId, session);
    this._refreshIndex.set(refreshHash, sessionId);

    // Cleanup expired sessions periodically
    this._cleanupExpired();

    logger.info({ event: 'session_created', userId: user.id, sessionId, role: session.role });
    return { sessionId, refreshToken, expiresIn: ACCESS_TTL_S, cookieName: COOKIE_NAME };
  }

  async verifySession(sessionId) {
    if (!sessionId) return { valid: false, error: 'Session ID required' };
    const session = this._sessions.get(sessionId);
    if (!session) return { valid: false, error: 'Session not found' };
    if (Date.now() > session.expiresAt) {
      this._sessions.delete(sessionId);
      return { valid: false, error: 'Session expired' };
    }
    return { valid: true, payload: { sub: session.userId, email: session.email, role: session.role, sessionId } };
  }

  async verifyFirebaseToken(idToken) {
    if (!this._firebaseAdmin) throw new Error('Firebase Admin not configured');
    try {
      const decoded = await this._firebaseAdmin.auth().verifyIdToken(idToken);
      return { valid: true, payload: { sub: decoded.uid, email: decoded.email, role: ROLES.USER } };
    } catch (err) {
      return { valid: false, error: err.message };
    }
  }

  async refreshSession(refreshToken) {
    if (!refreshToken) throw new Error('Refresh token required');
    const hash = _hashSecret(refreshToken);
    const sessionId = this._refreshIndex.get(hash);
    if (!sessionId) throw new Error('Invalid refresh token');
    const session = this._sessions.get(sessionId);
    if (!session) throw new Error('Session not found');

    // Rotate tokens
    this._sessions.delete(sessionId);
    this._refreshIndex.delete(hash);
    return this.createSession({ id: session.userId, email: session.email, role: session.role, meta: session.meta });
  }

  async revokeSession(sessionId) {
    const session = this._sessions.get(sessionId);
    if (session) {
      this._refreshIndex.delete(session.refreshHash);
      this._sessions.delete(sessionId);
      logger.info({ event: 'session_revoked', sessionId });
      return true;
    }
    return false;
  }

  async createApiKey(userId, opts = {}) {
    const rawKey = API_KEY_PREFIX + _randomId(40);
    const keyId = _randomId(16);
    const hash = _hashSecret(rawKey);
    const record = {
      userId, keyId, hash, role: opts.role || ROLES.USER,
      description: opts.description || '', createdAt: Date.now(),
      expiresAt: opts.ttlMs ? Date.now() + opts.ttlMs : null, lastUsed: null,
    };
    this._apiKeys.set(keyId, record);
    logger.info({ event: 'api_key_created', userId, keyId, role: record.role });
    return { apiKey: rawKey, keyId };
  }

  async validateApiKey(apiKey) {
    if (!apiKey || !apiKey.startsWith(API_KEY_PREFIX)) return { valid: false, error: 'Invalid format' };
    const hash = _hashSecret(apiKey);
    for (const [keyId, record] of this._apiKeys) {
      if (record.hash === hash) {
        if (record.expiresAt && Date.now() > record.expiresAt) return { valid: false, error: 'Expired' };
        record.lastUsed = Date.now();
        return { valid: true, record };
      }
    }
    return { valid: false, error: 'Not found' };
  }

  hasRole(userRole, requiredRole) {
    return (ROLE_HIERARCHY[userRole] || 0) >= (ROLE_HIERARCHY[requiredRole] || Infinity);
  }

  requireRole(requiredRole) {
    return async (req, res, next) => {
      try {
        const sessionId = _extractSessionFromCookie(req);
        const { valid, payload, error } = await this.verifySession(sessionId);
        if (!valid) return res.status(401).json({ error: error || 'Unauthorized' });
        if (!this.hasRole(payload.role, requiredRole)) return res.status(403).json({ error: 'Insufficient permissions' });
        req.user = payload;
        next();
      } catch (err) { next(err); }
    };
  }

  setCookieHeader(sessionId, maxAgeSec = ACCESS_TTL_S) {
    return COOKIE_NAME + '=' + sessionId + '; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=' + maxAgeSec;
  }

  _cleanupExpired() {
    const now = Date.now();
    for (const [id, session] of this._sessions) {
      if (now > session.expiresAt) {
        this._refreshIndex.delete(session.refreshHash);
        this._sessions.delete(id);
      }
    }
  }
}

function _extractSessionFromCookie(req) {
  const cookies = req.headers.cookie || '';
  const match = cookies.match(new RegExp(COOKIE_NAME + '=([^;]+)'));
  return match ? match[1] : null;
}

function _validateUser(user) {
  if (!user || typeof user !== 'object') throw new Error('user must be an object');
  if (!user.id) throw new Error('user.id is required');
  if (!user.email) throw new Error('user.email is required');
  if (user.role && !ROLE_HIERARCHY[user.role]) throw new Error('Invalid role: ' + user.role);
}

function _randomId(bytes = 32) { return crypto.randomBytes(bytes).toString('hex'); }
function _hashSecret(value) { return crypto.createHash('sha256').update(value).digest('hex'); }

module.exports = { AuthManager, ROLES, ROLE_HIERARCHY, COOKIE_NAME, SESSION_TTL_MS, ACCESS_TTL_S };
