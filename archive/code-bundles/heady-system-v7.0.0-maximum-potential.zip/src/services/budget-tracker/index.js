/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Service: budget-tracker
 * ═══════════════════════════════════════════════════════════════════════════════
 * Per-request AI provider spend tracking
 * © 2026 HeadySystems Inc. — Eric Haywood
 */

'use strict';

const express = require('express');
const { SERVICE_PORTS, fib, PHI, CSL_THRESHOLDS, phiBackoff } = require('../../../shared/phi-math');
const { createHealthCheck } = require('../../../shared/health');
const { createLogger } = require('../../../shared/logger');
const logger = createLogger('budget-tracker');
const { corsMiddleware } = require('../../../shared/middleware/cors');
const { errorHandler } = require('../../../shared/middleware/error-handler');
const { requestValidator } = require('../../../shared/middleware/request-validator');

const SERVICE_NAME = 'budget-tracker';
const PORT = SERVICE_PORTS[SERVICE_NAME] || 3312;

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use(corsMiddleware());
app.use(requestValidator());

// ─── Health Check ────────────────────────────────────────────────────────────

const healthCheck = createHealthCheck(SERVICE_NAME);
app.get('/health', (req, res) => res.json(healthCheck.getStatus()));
app.get('/healthz', (req, res) => {
  const status = healthCheck.getStatus();
  res.status(status.healthy ? 200 : 503).json(status);
});

// ─── Service Routes ──────────────────────────────────────────────────────────

app.get('/api/v1/status', (req, res) => {
  res.json({
    service: SERVICE_NAME,
    version: '7.0.0',
    status: 'operational',
    uptime: process.uptime(),
    phi: { threshold: CSL_THRESHOLDS.MEDIUM, backoff: phiBackoff(0) },
    ts: Date.now(),
  });
});

app.post('/api/v1/execute', async (req, res, next) => {
  try {
    const { action, payload } = req.body;
    if (!action) return res.status(400).json({ error: 'action is required' });
    
    logger.info({ event: 'service_execute', service: SERVICE_NAME, action });
    
    res.json({
      service: SERVICE_NAME,
      action,
      result: { processed: true, ts: Date.now() },
      csl: { gate: CSL_THRESHOLDS.MEDIUM },
    });
  } catch (err) { next(err); }
});

// ─── Error Handler ───────────────────────────────────────────────────────────

app.use(errorHandler());

// ─── Server ──────────────────────────────────────────────────────────────────

function start() {
  const server = app.listen(PORT, () => {
    logger.info({ event: 'service_started', service: SERVICE_NAME, port: PORT });
  });
  
  // Graceful shutdown
  const shutdown = () => {
    logger.info({ event: 'service_shutdown', service: SERVICE_NAME });
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(1), fib(8) * 1000).unref(); // 21s grace
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
  
  return server;
}

module.exports = { app, start, SERVICE_NAME, PORT };

if (require.main === module) start();
