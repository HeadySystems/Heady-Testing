/**
 * Heady™ LiquidDeploy v1.0
 * Latent-to-physical code projection engine.
 * Projects JSON ASTs and design artifacts from the 384D vector space
 * into physical files in the GitHub monorepo (HeadyMe/Heady-pre-production).
 *
 * Validates every projection through the 3 Unbreakable Laws:
 *   1. Structural Integrity — code compiles, respects module boundaries
 *   2. Semantic Coherence — embedding stays within tolerance of design intent
 *   3. Mission Alignment — serves HeadyConnection's community mission
 *
 * All numeric values derived from φ (phi) and Fibonacci sequences.
 * Zero magic numbers.
 *
 * @author Eric Haywood — HeadySystems Inc.
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  EMBEDDING_DIM,
  fib, nearestFib,
  CSL_THRESHOLDS,
  phiThreshold,
  phiBackoff,
  phiFusionWeights,
  cslGate,
  cslBlend,
  PRESSURE_LEVELS,
  ALERT_THRESHOLDS,
} = require('../../shared/phi-math.js');
const { createLogger } = require('../../shared/logger.js');
const logger = createLogger('liquid-deploy');
const { createHealthCheck } = require('../../shared/health.js');

// ═══════════════════════════════════════════════════════════
// CONSTANTS — All phi-derived
// ═══════════════════════════════════════════════════════════

/** Maximum files in a single projection batch — fib(8) = 21 */
const MAX_BATCH_SIZE = fib(8);

/** Maximum pending projections in queue — fib(13) = 233 */
const MAX_QUEUE_DEPTH = fib(13);

/** Projection validation timeout — fib(9) × 1000 = 34s */
const VALIDATION_TIMEOUT_MS = fib(9) * 1000;

/** Maximum retries per projection — fib(5) = 5 */
const MAX_RETRIES = fib(5);

/** Structural integrity minimum threshold */
const STRUCTURAL_THRESHOLD = CSL_THRESHOLDS.HIGH; // ≈ 0.882

/** Semantic coherence minimum threshold */
const SEMANTIC_THRESHOLD = CSL_THRESHOLDS.MEDIUM; // ≈ 0.809

/** Mission alignment minimum threshold */
const MISSION_THRESHOLD = CSL_THRESHOLDS.LOW; // ≈ 0.691

/** Diff size limit (lines) before requiring staged deploy — fib(12) = 144 */
const STAGED_DEPLOY_THRESHOLD = fib(12);

/** Git branch prefix for projection branches */
const BRANCH_PREFIX = 'liquid-deploy/';

/** Cooldown between deployments — fib(7) × 1000 = 13s */
const DEPLOY_COOLDOWN_MS = fib(7) * 1000;

/** Projection history buffer — fib(11) = 89 */
const HISTORY_BUFFER = fib(11);

/** Rollback window — fib(14) × 1000 ≈ 6.28 min */
const ROLLBACK_WINDOW_MS = fib(14) * 1000;

// ═══════════════════════════════════════════════════════════
// PROJECTION UNIT — A single file projection from latent to physical
// ═══════════════════════════════════════════════════════════

/**
 * @typedef {object} ProjectionUnit
 * @property {string} id — unique projection ID
 * @property {string} targetPath — relative file path in the repo
 * @property {string} content — projected file content
 * @property {Float32Array} designEmbedding — 384D embedding of the design intent
 * @property {Float32Array} [resultEmbedding] — 384D embedding of the projected code
 * @property {object} ast — JSON AST representation (optional)
 * @property {string} status — 'pending' | 'validated' | 'projected' | 'failed' | 'rolled_back'
 * @property {object} validation — validation results
 */

class ProjectionUnit {
  /**
   * @param {object} opts
   * @param {string} opts.targetPath — repo-relative path
   * @param {string} opts.content — file content
   * @param {Float32Array} opts.designEmbedding — design intent vector
   * @param {object} [opts.ast] — parsed AST
   * @param {object} [opts.metadata] — additional context
   */
  constructor({ targetPath, content, designEmbedding, ast = null, metadata = {} }) {
    this.id = `proj_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
    this.targetPath = targetPath;
    this.content = content;
    this.designEmbedding = designEmbedding;
    this.resultEmbedding = null;
    this.ast = ast;
    this.metadata = metadata;
    this.status = 'pending';
    this.validation = null;
    this.retries = 0;
    this.created = Date.now();
    this.projected = null;
    this.previousContent = null;
  }

  toJSON() {
    return {
      id: this.id,
      targetPath: this.targetPath,
      status: this.status,
      validation: this.validation,
      retries: this.retries,
      created: this.created,
      projected: this.projected,
      contentLength: this.content.length,
    };
  }
}

// ═══════════════════════════════════════════════════════════
// 3 UNBREAKABLE LAWS VALIDATOR
// ═══════════════════════════════════════════════════════════

class UnbreakableLawsValidator {
  /**
   * Validate a projection unit against all 3 laws.
   *
   * @param {ProjectionUnit} unit
   * @param {object} [context] — { moduleMap, missionEmbedding }
   * @returns {object} — { valid, law1, law2, law3, compositeScore }
   */
  validate(unit, context = {}) {
    const law1 = this._validateStructuralIntegrity(unit, context);
    const law2 = this._validateSemanticCoherence(unit, context);
    const law3 = this._validateMissionAlignment(unit, context);

    // Composite score: phi-fusion of 3 law scores
    const weights = phiFusionWeights(3); // [0.528, 0.326, 0.146]
    const compositeScore = (
      weights[0] * law1.score +
      weights[1] * law2.score +
      weights[2] * law3.score
    );

    const valid = (
      law1.score >= STRUCTURAL_THRESHOLD &&
      law2.score >= SEMANTIC_THRESHOLD &&
      law3.score >= MISSION_THRESHOLD
    );

    const result = {
      valid,
      compositeScore: Number(compositeScore.toFixed(6)),
      law1: { name: 'Structural Integrity', ...law1 },
      law2: { name: 'Semantic Coherence', ...law2 },
      law3: { name: 'Mission Alignment', ...law3 },
      timestamp: Date.now(),
    };

    logger.info({
      component: 'LiquidDeploy',
      action: 'validate_laws',
      projectionId: unit.id,
      targetPath: unit.targetPath,
      valid,
      compositeScore: result.compositeScore,
      law1Score: law1.score,
      law2Score: law2.score,
      law3Score: law3.score,
    });

    return result;
  }

  /**
   * Law 1: Structural Integrity
   * - Code can be parsed (valid syntax)
   * - Respects module boundaries (imports only allowed dependencies)
   * - File path matches expected project structure
   */
  _validateStructuralIntegrity(unit, context) {
    let score = 1.0;
    const issues = [];

    // 1a. Syntax validation (basic checks)
    if (unit.targetPath.endsWith('.js')) {
      try {
        // Check for common syntax issues
        const content = unit.content;
        const openBraces = (content.match(/\{/g) || []).length;
        const closeBraces = (content.match(/\}/g) || []).length;
        if (Math.abs(openBraces - closeBraces) > fib(3)) {
          score -= PSI_SQ;
          issues.push('Brace mismatch detected');
        }

        const openParens = (content.match(/\(/g) || []).length;
        const closeParens = (content.match(/\)/g) || []).length;
        if (Math.abs(openParens - closeParens) > fib(3)) {
          score -= PSI_CUBE;
          issues.push('Parenthesis mismatch detected');
        }

        // Check for 'use strict'
        if (!content.includes("'use strict'") && !content.includes('"use strict"')) {
          score -= PSI_FOURTH;
          issues.push('Missing strict mode');
        }

        // Check for console.log (forbidden in Heady system)
        if (/console\.(log|warn|error|info|debug)/.test(content)) {
          score -= PSI_CUBE;
          issues.push('console.log detected — use structured logger');
        }

        // Check for localStorage (forbidden)
        if (/localStorage/.test(content)) {
          score -= PSI_SQ;
          issues.push('localStorage detected — use httpOnly cookies');
        }

      } catch (err) {
        score -= PSI;
        issues.push(`Parse error: ${err.message}`);
      }
    }

    // 1b. Module boundary check
    if (context.moduleMap) {
      const dir = unit.targetPath.split('/').slice(0, -1).join('/');
      const imports = extractImports(unit.content);
      for (const imp of imports) {
        if (!isAllowedImport(dir, imp, context.moduleMap)) {
          score -= PSI_CUBE;
          issues.push(`Unauthorized import: ${imp}`);
        }
      }
    }

    // 1c. Path structure check
    if (!isValidPath(unit.targetPath)) {
      score -= PSI_SQ;
      issues.push('Path does not match expected project structure');
    }

    return {
      score: Math.max(0, Number(score.toFixed(6))),
      passed: score >= STRUCTURAL_THRESHOLD,
      issues,
    };
  }

  /**
   * Law 2: Semantic Coherence
   * - Result embedding is within tolerance of design intent embedding
   * - No "meaning drift" from what was designed to what was coded
   */
  _validateSemanticCoherence(unit, context) {
    const issues = [];

    if (!unit.designEmbedding || !unit.resultEmbedding) {
      // If no result embedding yet, estimate from content characteristics
      const estimatedScore = estimateSemanticScore(unit.content, unit.targetPath);
      return {
        score: Number(estimatedScore.toFixed(6)),
        passed: estimatedScore >= SEMANTIC_THRESHOLD,
        issues: unit.resultEmbedding ? [] : ['Result embedding not yet computed'],
      };
    }

    const similarity = cosineSimilarity(unit.designEmbedding, unit.resultEmbedding);

    if (similarity < SEMANTIC_THRESHOLD) {
      issues.push(`Semantic drift: similarity ${similarity.toFixed(4)} < threshold ${SEMANTIC_THRESHOLD.toFixed(4)}`);
    }

    return {
      score: Number(similarity.toFixed(6)),
      passed: similarity >= SEMANTIC_THRESHOLD,
      issues,
      similarity: Number(similarity.toFixed(6)),
    };
  }

  /**
   * Law 3: Mission Alignment
   * - Code serves HeadyConnection's mission (community, equity, empowerment)
   * - No harmful patterns, no dark patterns, no exploitative logic
   */
  _validateMissionAlignment(unit, context) {
    let score = 1.0;
    const issues = [];

    // Check for mission-hostile patterns
    const hostilePatterns = [
      { regex: /dark.?pattern/i, penalty: PSI, msg: 'Dark pattern reference detected' },
      { regex: /track.?user.?without/i, penalty: PSI, msg: 'Unauthorized tracking detected' },
      { regex: /sell.?data/i, penalty: PSI, msg: 'Data selling reference detected' },
      { regex: /discriminat/i, penalty: PSI_SQ, msg: 'Potential discrimination logic' },
      { regex: /paywall.?essential/i, penalty: PSI_CUBE, msg: 'Essential service paywall detected' },
    ];

    for (const { regex, penalty, msg } of hostilePatterns) {
      if (regex.test(unit.content)) {
        score -= penalty;
        issues.push(msg);
      }
    }

    // Check for positive mission indicators
    const missionIndicators = [
      /community/i, /equity/i, /empower/i, /access/i,
      /headyconnection/i, /mission/i, /inclusive/i,
    ];
    const indicatorCount = missionIndicators.filter(r => r.test(unit.content)).length;
    const missionBonus = cslGate(PSI_FOURTH, indicatorCount / missionIndicators.length, PSI_SQ, PSI);
    score = Math.min(1.0, score + missionBonus);

    // If mission embedding is available, use it
    if (context.missionEmbedding && unit.resultEmbedding) {
      const missionSim = cosineSimilarity(unit.resultEmbedding, context.missionEmbedding);
      const blendedScore = cslBlend(score, missionSim, missionSim, CSL_THRESHOLDS.MEDIUM);
      score = blendedScore;
    }

    return {
      score: Math.max(0, Number(score.toFixed(6))),
      passed: score >= MISSION_THRESHOLD,
      issues,
    };
  }
}

// ═══════════════════════════════════════════════════════════
// PROJECTION QUEUE — Manages pending projections
// ═══════════════════════════════════════════════════════════

class ProjectionQueue {
  constructor(maxDepth = MAX_QUEUE_DEPTH) {
    /** @type {Array<ProjectionUnit>} */
    this._queue = [];
    this._maxDepth = maxDepth;
    this._processing = false;
  }

  get size() { return this._queue.length; }
  get isProcessing() { return this._processing; }

  /**
   * Add a projection unit to the queue.
   * @param {ProjectionUnit} unit
   * @returns {boolean} — true if added
   */
  enqueue(unit) {
    if (this._queue.length >= this._maxDepth) {
      logger.info({
        component: 'LiquidDeploy',
        action: 'queue_full',
        depth: this._queue.length,
        rejected: unit.targetPath,
      });
      return false;
    }
    this._queue.push(unit);
    return true;
  }

  /**
   * Take up to N items from the queue for batch processing.
   * @param {number} [n=MAX_BATCH_SIZE]
   * @returns {Array<ProjectionUnit>}
   */
  takeBatch(n = MAX_BATCH_SIZE) {
    const batch = this._queue.splice(0, n);
    return batch;
  }

  /**
   * Return units to the front of the queue (for retry).
   */
  requeue(units) {
    this._queue.unshift(...units);
    // Trim if over max
    while (this._queue.length > this._maxDepth) {
      this._queue.pop();
    }
  }

  /**
   * Get queue status.
   */
  status() {
    return {
      depth: this._queue.length,
      maxDepth: this._maxDepth,
      processing: this._processing,
      utilization: Number((this._queue.length / this._maxDepth).toFixed(6)),
    };
  }
}

// ═══════════════════════════════════════════════════════════
// DEPLOYMENT MANIFEST — Records what was deployed
// ═══════════════════════════════════════════════════════════

class DeploymentManifest {
  /**
   * @param {string} branchName — git branch for this deployment
   */
  constructor(branchName) {
    this.id = `deploy_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
    this.branchName = branchName;
    this.created = Date.now();
    this.completed = null;
    this.status = 'building'; // building → validating → projecting → committed → merged | failed | rolled_back
    this.units = [];
    this.validationResults = [];
    this.compositeScore = 0;
  }

  addUnit(unit, validation) {
    this.units.push(unit.toJSON());
    if (validation) {
      this.validationResults.push(validation);
    }
  }

  /**
   * Compute overall deployment score.
   */
  computeScore() {
    if (this.validationResults.length === 0) return 0;
    const total = this.validationResults.reduce((s, v) => s + v.compositeScore, 0);
    this.compositeScore = Number((total / this.validationResults.length).toFixed(6));
    return this.compositeScore;
  }

  complete(status) {
    this.status = status;
    this.completed = Date.now();
  }

  toJSON() {
    return {
      id: this.id,
      branchName: this.branchName,
      created: this.created,
      completed: this.completed,
      status: this.status,
      unitCount: this.units.length,
      compositeScore: this.compositeScore,
      units: this.units,
    };
  }
}

// ═══════════════════════════════════════════════════════════
// LIQUID DEPLOY ENGINE — Main orchestrator
// ═══════════════════════════════════════════════════════════

class LiquidDeployEngine {
  /**
   * @param {object} [opts]
   * @param {string} [opts.repo] — GitHub repo (owner/name)
   * @param {function} [opts.gitClient] — Git operations client
   * @param {function} [opts.embedder] — function to compute embeddings
   */
  constructor({ repo = 'HeadyMe/Heady-pre-production', gitClient = null, embedder = null } = {}) {
    this._repo = repo;
    this._gitClient = gitClient;
    this._embedder = embedder;
    this._validator = new UnbreakableLawsValidator();
    this._queue = new ProjectionQueue();
    this._history = [];
    this._lastDeployTime = 0;
    this._started = false;
    this._processInterval = null;
  }

  /**
   * Start the deploy engine with periodic queue processing.
   */
  start() {
    if (this._started) return;
    this._started = true;

    // Process queue every fib(8) × 1000 = 21s
    this._processInterval = setInterval(() => {
      this._processQueue().catch(err => {
        logger.error({
          component: 'LiquidDeploy',
          action: 'process_queue_error',
          error: err.message,
        });
      });
    }, fib(8) * 1000);

    logger.info({
      component: 'LiquidDeploy',
      action: 'engine_started',
      repo: this._repo,
      processIntervalMs: fib(8) * 1000,
    });
  }

  /**
   * Stop the deploy engine.
   */
  stop() {
    if (!this._started) return;
    this._started = false;
    if (this._processInterval) clearInterval(this._processInterval);
    logger.info({ component: 'LiquidDeploy', action: 'engine_stopped' });
  }

  /**
   * Submit a projection unit for deployment.
   *
   * @param {object} opts — ProjectionUnit constructor args
   * @returns {ProjectionUnit}
   */
  submit(opts) {
    const unit = new ProjectionUnit(opts);
    const enqueued = this._queue.enqueue(unit);

    if (!enqueued) {
      unit.status = 'failed';
      unit.validation = { valid: false, issues: ['Queue full — backpressure applied'] };
    }

    logger.info({
      component: 'LiquidDeploy',
      action: 'submit',
      projectionId: unit.id,
      targetPath: unit.targetPath,
      enqueued,
    });

    return unit;
  }

  /**
   * Submit a batch of projection units.
   *
   * @param {Array<object>} unitOpts — array of ProjectionUnit constructor args
   * @returns {Array<ProjectionUnit>}
   */
  submitBatch(unitOpts) {
    return unitOpts.map(opts => this.submit(opts));
  }

  /**
   * Process the projection queue — validate and project a batch.
   * @private
   */
  async _processQueue() {
    if (this._queue.size === 0) return;

    // Enforce cooldown
    const now = Date.now();
    if (now - this._lastDeployTime < DEPLOY_COOLDOWN_MS) return;

    const batch = this._queue.takeBatch();
    if (batch.length === 0) return;

    const branchName = `${BRANCH_PREFIX}${now}`;
    const manifest = new DeploymentManifest(branchName);

    logger.info({
      component: 'LiquidDeploy',
      action: 'process_batch',
      batchSize: batch.length,
      branch: branchName,
    });

    // Phase 1: Validate all units
    manifest.status = 'validating';
    const validUnits = [];
    const failedUnits = [];

    for (const unit of batch) {
      // Compute result embedding if embedder available
      if (this._embedder && !unit.resultEmbedding) {
        try {
          unit.resultEmbedding = await this._embedder(unit.content);
        } catch (err) {
          logger.error({
            component: 'LiquidDeploy',
            action: 'embedding_error',
            projectionId: unit.id,
            error: err.message,
          });
        }
      }

      const validation = this._validator.validate(unit);
      unit.validation = validation;

      if (validation.valid) {
        unit.status = 'validated';
        validUnits.push(unit);
      } else {
        if (unit.retries < MAX_RETRIES) {
          unit.retries++;
          unit.status = 'pending';
          failedUnits.push(unit);
        } else {
          unit.status = 'failed';
        }
      }

      manifest.addUnit(unit, validation);
    }

    // Requeue retriable failures
    if (failedUnits.length > 0) {
      this._queue.requeue(failedUnits);
    }

    // Phase 2: Project valid units
    if (validUnits.length === 0) {
      manifest.complete('failed');
      this._recordManifest(manifest);
      return;
    }

    manifest.status = 'projecting';

    // Determine if staged deploy is needed
    const totalLines = validUnits.reduce((s, u) => s + u.content.split('\n').length, 0);
    const staged = totalLines > STAGED_DEPLOY_THRESHOLD;

    if (this._gitClient) {
      try {
        // Create branch
        await this._gitClient.createBranch(branchName);

        // Write files
        for (const unit of validUnits) {
          await this._gitClient.writeFile(branchName, unit.targetPath, unit.content);
          unit.status = 'projected';
          unit.projected = Date.now();
        }

        // Commit
        const commitMsg = `[LiquidDeploy] Project ${validUnits.length} file(s)\n\n` +
          validUnits.map(u => `- ${u.targetPath}`).join('\n') +
          `\n\nManifest: ${manifest.id}\n` +
          `Composite Score: ${manifest.computeScore()}\n` +
          `Staged: ${staged}`;

        await this._gitClient.commit(branchName, commitMsg);

        // Auto-merge if not staged and score is high
        if (!staged && manifest.computeScore() >= CSL_THRESHOLDS.HIGH) {
          await this._gitClient.merge(branchName);
          manifest.complete('merged');
        } else {
          manifest.complete('committed');
        }

      } catch (err) {
        logger.error({
          component: 'LiquidDeploy',
          action: 'git_error',
          branch: branchName,
          error: err.message,
        });
        manifest.complete('failed');
      }
    } else {
      // No git client — mark as projected (dry run mode)
      for (const unit of validUnits) {
        unit.status = 'projected';
        unit.projected = Date.now();
      }
      manifest.computeScore();
      manifest.complete('committed');
    }

    this._lastDeployTime = Date.now();
    this._recordManifest(manifest);

    logger.info({
      component: 'LiquidDeploy',
      action: 'batch_complete',
      manifestId: manifest.id,
      status: manifest.status,
      projected: validUnits.length,
      failed: batch.length - validUnits.length,
      compositeScore: manifest.compositeScore,
    });
  }

  /**
   * Rollback a deployment by manifest ID.
   *
   * @param {string} manifestId
   * @returns {boolean}
   */
  async rollback(manifestId) {
    const manifest = this._history.find(m => m.id === manifestId);
    if (!manifest) return false;

    // Check rollback window
    if (Date.now() - manifest.completed > ROLLBACK_WINDOW_MS) {
      logger.info({
        component: 'LiquidDeploy',
        action: 'rollback_expired',
        manifestId,
        windowMs: ROLLBACK_WINDOW_MS,
      });
      return false;
    }

    if (this._gitClient && manifest.branchName) {
      try {
        await this._gitClient.revert(manifest.branchName);
        manifest.status = 'rolled_back';
        logger.info({
          component: 'LiquidDeploy',
          action: 'rollback_success',
          manifestId,
          branch: manifest.branchName,
        });
        return true;
      } catch (err) {
        logger.error({
          component: 'LiquidDeploy',
          action: 'rollback_error',
          manifestId,
          error: err.message,
        });
        return false;
      }
    }

    manifest.status = 'rolled_back';
    return true;
  }

  /**
   * Get deployment history.
   */
  getHistory() {
    return this._history.map(m => m.toJSON ? m.toJSON() : m);
  }

  /**
   * Get engine status.
   */
  status() {
    return {
      started: this._started,
      repo: this._repo,
      queue: this._queue.status(),
      recentDeployments: this._history.length,
      lastDeployTime: this._lastDeployTime,
      hasGitClient: !!this._gitClient,
      hasEmbedder: !!this._embedder,
    };
  }

  _recordManifest(manifest) {
    this._history.push(manifest);
    while (this._history.length > HISTORY_BUFFER) {
      this._history.shift();
    }
  }
}

// ═══════════════════════════════════════════════════════════
// UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════

function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom > 0 ? dot / denom : 0;
}

/**
 * Extract import paths from JS content.
 */
function extractImports(content) {
  const imports = [];
  const requireRegex = /require\s*\(\s*['"]([^'"]+)['"]\s*\)/g;
  let match;
  while ((match = requireRegex.exec(content)) !== null) {
    imports.push(match[1]);
  }
  const importRegex = /import\s+.*?\s+from\s+['"]([^'"]+)['"]/g;
  while ((match = importRegex.exec(content)) !== null) {
    imports.push(match[1]);
  }
  return imports;
}

/**
 * Check if an import is allowed from a given directory.
 */
function isAllowedImport(fromDir, importPath, moduleMap) {
  // Relative imports within same module are always allowed
  if (importPath.startsWith('./') || importPath.startsWith('../')) return true;

  // Shared modules are always allowed
  if (importPath.includes('shared/')) return true;

  // Check module map
  if (moduleMap && moduleMap[fromDir]) {
    return moduleMap[fromDir].allowedImports.includes(importPath);
  }

  // Node built-ins are allowed
  const nodeBuiltins = ['path', 'fs', 'crypto', 'http', 'https', 'stream', 'url', 'util', 'os', 'events', 'buffer'];
  if (nodeBuiltins.includes(importPath)) return true;

  return true; // Default allow if no module map
}

/**
 * Validate that a file path matches expected project structure.
 */
function isValidPath(filePath) {
  const validPrefixes = [
    'src/', 'shared/', 'migrations/', 'tests/', 'infrastructure/',
    'docs/', 'scripts/', 'config/',
  ];
  const validExtensions = ['.js', '.json', '.yaml', '.yml', '.sql', '.toml', '.md', '.html', '.css'];

  const hasValidPrefix = validPrefixes.some(p => filePath.startsWith(p)) || !filePath.includes('/');
  const ext = filePath.substring(filePath.lastIndexOf('.'));
  const hasValidExt = validExtensions.includes(ext);

  return hasValidPrefix && hasValidExt;
}

/**
 * Estimate semantic score from content characteristics (when no embeddings available).
 */
function estimateSemanticScore(content, targetPath) {
  let score = CSL_THRESHOLDS.MEDIUM; // Start at medium

  // Well-structured code signals
  if (content.includes('module.exports')) score += PSI_FOURTH;
  if (content.includes('@author')) score += PSI_FOURTH * PSI;
  if (content.includes('@license')) score += PSI_FOURTH * PSI;
  if (content.includes("'use strict'")) score += PSI_FOURTH;
  if (/\/\*\*[\s\S]*?\*\//.test(content)) score += PSI_CUBE; // JSDoc present

  // Path-content coherence
  const filename = targetPath.split('/').pop().replace('.js', '');
  const dashedName = filename.replace(/-/g, '').toLowerCase();
  if (content.toLowerCase().includes(dashedName)) score += PSI_FOURTH;

  return Math.min(1.0, score);
}

// ═══════════════════════════════════════════════════════════
// HEALTH CHECK
// ═══════════════════════════════════════════════════════════

const healthCheck = createHealthCheck('liquid-deploy', () => {
  const engine = getSharedEngine();
  return engine.status();
});

// ═══════════════════════════════════════════════════════════
// SINGLETON
// ═══════════════════════════════════════════════════════════

let _sharedEngine = null;

function getSharedEngine() {
  if (!_sharedEngine) {
    _sharedEngine = new LiquidDeployEngine();
  }
  return _sharedEngine;
}

// ═══════════════════════════════════════════════════════════
// EXPORTS
// ═══════════════════════════════════════════════════════════

module.exports = {
  // Core
  LiquidDeployEngine,
  ProjectionUnit,
  DeploymentManifest,
  UnbreakableLawsValidator,
  ProjectionQueue,

  // Singleton
  getSharedEngine,

  // Health
  healthCheck,

  // Utilities
  extractImports,
  isAllowedImport,
  isValidPath,
  estimateSemanticScore,
  cosineSimilarity,

  // Constants (for testing)
  MAX_BATCH_SIZE,
  MAX_QUEUE_DEPTH,
  VALIDATION_TIMEOUT_MS,
  MAX_RETRIES,
  STRUCTURAL_THRESHOLD,
  SEMANTIC_THRESHOLD,
  MISSION_THRESHOLD,
  STAGED_DEPLOY_THRESHOLD,
  DEPLOY_COOLDOWN_MS,
  HISTORY_BUFFER,
  ROLLBACK_WINDOW_MS,
  BRANCH_PREFIX,
};
