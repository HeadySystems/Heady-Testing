/**
 * MonetizationEngine — Stripe Integration with Phi-Scaled Usage Metering
 * 
 * Subscription management, usage-based billing, feature gates, plan tier
 * enforcement, and revenue analytics. All thresholds, limits, and pricing
 * parameters derive from phi/Fibonacci.
 * 
 * Features:
 * - 4 plan tiers: Community (free), Developer ($29/mo), Team ($99/seat/mo), Enterprise (custom)
 * - 5 usage metric types: API calls, vector ops, LLM tokens, agent hours, storage GB
 * - Phi-scaled alert thresholds (warning ψ, caution 1-ψ², critical 1-ψ³, exceeded 1-ψ⁴)
 * - CSL-gated feature gates with graceful degradation
 * - Stripe webhook handler for subscription lifecycle
 * - Revenue analytics with phi-weighted projections
 * 
 * @module monetization-engine
 * @version 1.0.0
 * @author Eric Haywood
 */

const {
  PHI,
  PSI,
  PHI2,
  PHI3,
  fib,
  fibonacci,
  phiThreshold,
  phiFusionWeights,
  phiBackoff,
  CSL_THRESHOLDS,
  PRESSURE_LEVELS,
  ALERT_THRESHOLDS,
  SIZING,
  cslGate,
  cosineSimilarity,
  SERVICE_PORTS
} = require('../../shared/phi-math.js');
const { createLogger } = require('../../shared/logger.js');
const { createHealthCheck } = require('../../shared/health.js');

const logger = createLogger('monetization-engine');

/* ═══════════════════════════════════════════════════════════════
   §1 — Constants (all phi-derived)
   ═══════════════════════════════════════════════════════════════ */

const TRIAL_DAYS = fib(7);               // 13 days
const ANNUAL_DISCOUNT_PCT = fib(8);       // 21%
const CACHE_SIZE = fib(16);               // 987 cached subscription states
const CACHE_TTL_MS = fib(11) * 1000;      // 89 seconds
const METERING_WINDOW_MS = fib(11) * 1000; // 89-second metering windows
const MAX_OVERAGE_BUFFER = PHI;           // 1.618× soft limit before hard stop
const GRACE_PERIOD_HOURS = fib(8);        // 21 hours grace period
const WEBHOOK_TOLERANCE_MS = fib(12) * 1000; // 144 seconds timestamp tolerance

/** Plan tiers with phi-derived limits */
const PLANS = {
  community: {
    name: 'Community',
    price: 0,
    priceAnnual: 0,
    limits: {
      apiCalls:    fib(14),    // 377/day
      vectorOps:   fib(12),    // 144/day
      llmTokens:   fib(16),    // 987 tokens/day
      agentHours:  PSI,        // 0.618 hours/day
      storageGB:   fib(3)      // 2 GB
    },
    features: ['basic_rag', 'single_agent', 'community_support'],
    rateLimit: fib(8),          // 21 req/min
    seats: 1
  },
  developer: {
    name: 'Developer',
    price: 29,
    priceAnnual: Math.round(29 * 12 * (1 - ANNUAL_DISCOUNT_PCT / 100)),
    limits: {
      apiCalls:    fib(17),    // 1597/day
      vectorOps:   fib(16),    // 987/day
      llmTokens:   fib(20),    // 6765 tokens/day
      agentHours:  fib(5),     // 5 hours/day
      storageGB:   fib(8)      // 21 GB
    },
    features: ['basic_rag', 'advanced_rag', 'graph_rag', 'multi_agent', 'copilot', 'email_support'],
    rateLimit: fib(11),         // 89 req/min
    seats: 1
  },
  team: {
    name: 'Team',
    price: 99,
    priceAnnual: Math.round(99 * 12 * (1 - ANNUAL_DISCOUNT_PCT / 100)),
    limits: {
      apiCalls:    fib(20),    // 6765/day
      vectorOps:   fib(17),    // 1597/day
      llmTokens:   fib(20) * fib(5), // 33825 tokens/day
      agentHours:  fib(8),     // 21 hours/day
      storageGB:   fib(11)     // 89 GB
    },
    features: ['basic_rag', 'advanced_rag', 'graph_rag', 'multi_agent', 'copilot', 'arena_mode', 'team_collab', 'priority_support', 'analytics'],
    rateLimit: fib(13),         // 233 req/min
    seats: null // per-seat
  },
  enterprise: {
    name: 'Enterprise',
    price: null, // custom
    priceAnnual: null,
    limits: {
      apiCalls:    Infinity,
      vectorOps:   Infinity,
      llmTokens:   Infinity,
      agentHours:  Infinity,
      storageGB:   fib(16)     // 987 GB
    },
    features: ['basic_rag', 'advanced_rag', 'graph_rag', 'multi_agent', 'copilot', 'arena_mode', 'team_collab', 'priority_support', 'analytics', 'sso', 'sla', 'air_gapped', 'custom_models', 'dedicated_support'],
    rateLimit: fib(16),         // 987 req/min
    seats: null
  }
};

/** Usage metric types */
const METRIC_TYPES = ['apiCalls', 'vectorOps', 'llmTokens', 'agentHours', 'storageGB'];

/** Alert thresholds for usage (phi-derived) */
const USAGE_ALERTS = {
  warning:  ALERT_THRESHOLDS.warning,   // ψ ≈ 0.618 (61.8%)
  caution:  ALERT_THRESHOLDS.caution,   // 1-ψ² ≈ 0.764 (76.4%)
  critical: ALERT_THRESHOLDS.critical,  // 1-ψ³ ≈ 0.854 (85.4%)
  exceeded: ALERT_THRESHOLDS.exceeded,  // 1-ψ⁴ ≈ 0.910 (91.0%)
  hardMax:  1.0                          // 100%
};

/* ═══════════════════════════════════════════════════════════════
   §2 — Usage Metering
   ═══════════════════════════════════════════════════════════════ */

class UsageMeter {
  constructor() {
    this._counters = new Map();  // userId -> { metric -> count }
    this._windows = new Map();   // userId -> { metric -> { windowStart, count } }
    this._alerts = new Map();    // userId -> Set<alertType>
    this._cache = new Map();     // subscription cache
  }

  /**
   * Record a usage event
   * @param {string} userId - User ID
   * @param {string} metric - Metric type (apiCalls, vectorOps, etc.)
   * @param {number} [amount] - Amount to record (default: 1)
   * @param {string} plan - User's plan tier
   * @returns {object} Usage status
   */
  record(userId, metric, amount = 1, plan = 'community') {
    if (!METRIC_TYPES.includes(metric)) {
      return { error: 'Invalid metric type', valid: METRIC_TYPES };
    }

    // Initialize counters
    if (!this._counters.has(userId)) {
      this._counters.set(userId, Object.fromEntries(METRIC_TYPES.map(m => [m, 0])));
    }
    if (!this._windows.has(userId)) {
      this._windows.set(userId, Object.fromEntries(
        METRIC_TYPES.map(m => [m, { windowStart: Date.now(), count: 0 }])
      ));
    }

    const counters = this._counters.get(userId);
    const windows = this._windows.get(userId);

    // Reset window if expired
    const window = windows[metric];
    if (Date.now() - window.windowStart > METERING_WINDOW_MS * fib(12)) {
      // Daily reset (METERING_WINDOW_MS * 144 ≈ 3.56 hours, adjusted for daily)
      window.windowStart = Date.now();
      window.count = 0;
      counters[metric] = 0;
    }

    counters[metric] += amount;
    window.count += amount;

    // Check against plan limits
    const planConfig = PLANS[plan] || PLANS.community;
    const limit = planConfig.limits[metric];
    const usage = counters[metric];
    const ratio = limit === Infinity ? 0 : usage / limit;

    // Generate alerts
    const alerts = this._checkAlerts(userId, metric, ratio, plan);

    // Check if blocked
    const blocked = ratio >= USAGE_ALERTS.hardMax && limit !== Infinity;
    const throttled = ratio >= USAGE_ALERTS.exceeded && limit !== Infinity;

    const status = {
      userId,
      metric,
      usage,
      limit: limit === Infinity ? 'unlimited' : limit,
      ratio: ratio.toFixed(3),
      blocked,
      throttled,
      alerts,
      plan
    };

    if (alerts.length > 0) {
      logger.info({ event: 'usage_alert', ...status });
    }

    return status;
  }

  _checkAlerts(userId, metric, ratio, plan) {
    if (!this._alerts.has(userId)) {
      this._alerts.set(userId, new Set());
    }
    const userAlerts = this._alerts.get(userId);
    const newAlerts = [];
    const key = (level) => `${metric}:${level}`;

    for (const [level, threshold] of Object.entries(USAGE_ALERTS)) {
      if (ratio >= threshold && !userAlerts.has(key(level))) {
        userAlerts.add(key(level));
        newAlerts.push({
          level,
          metric,
          threshold: threshold.toFixed(3),
          ratio: ratio.toFixed(3),
          message: _alertMessage(level, metric, ratio)
        });
      }
    }

    return newAlerts;
  }

  /**
   * Get usage summary for a user
   * @param {string} userId - User ID
   * @param {string} plan - Plan tier
   * @returns {object} Usage summary
   */
  getSummary(userId, plan = 'community') {
    const counters = this._counters.get(userId);
    if (!counters) return { userId, metrics: {}, plan };

    const planConfig = PLANS[plan] || PLANS.community;
    const metrics = {};

    for (const metric of METRIC_TYPES) {
      const usage = counters[metric] || 0;
      const limit = planConfig.limits[metric];
      const ratio = limit === Infinity ? 0 : usage / limit;

      metrics[metric] = {
        usage,
        limit: limit === Infinity ? 'unlimited' : limit,
        ratio: ratio.toFixed(3),
        level: ratio >= USAGE_ALERTS.exceeded ? 'exceeded' :
               ratio >= USAGE_ALERTS.critical ? 'critical' :
               ratio >= USAGE_ALERTS.caution ? 'caution' :
               ratio >= USAGE_ALERTS.warning ? 'warning' : 'normal'
      };
    }

    return { userId, metrics, plan };
  }

  /**
   * Reset daily counters for a user
   */
  resetDaily(userId) {
    this._counters.delete(userId);
    this._windows.delete(userId);
    this._alerts.delete(userId);
    logger.info({ event: 'usage_reset', userId });
  }
}

function _alertMessage(level, metric, ratio) {
  const pct = (ratio * 100).toFixed(1);
  switch (level) {
    case 'warning': return `${metric} at ${pct}% — approaching limit`;
    case 'caution': return `${metric} at ${pct}% — consider upgrading`;
    case 'critical': return `${metric} at ${pct}% — near limit`;
    case 'exceeded': return `${metric} at ${pct}% — throttling active`;
    case 'hardMax': return `${metric} at ${pct}% — hard limit reached`;
    default: return `${metric} at ${pct}%`;
  }
}

/* ═══════════════════════════════════════════════════════════════
   §3 — Feature Gates (CSL-gated)
   ═══════════════════════════════════════════════════════════════ */

class FeatureGate {
  constructor() {
    this._overrides = new Map();  // userId -> { feature -> boolean }
    this._cache = new Map();      // key -> { result, expiry }
  }

  /**
   * Check if a feature is available for a user
   * @param {string} userId - User ID
   * @param {string} feature - Feature name
   * @param {string} plan - User's plan tier
   * @returns {object} Gate result
   */
  check(userId, feature, plan = 'community') {
    // Check override first
    const override = this._overrides.get(userId)?.get(feature);
    if (override !== undefined) {
      return {
        allowed: override,
        source: 'override',
        plan,
        feature,
        degradation: null
      };
    }

    // Check cache
    const cacheKey = `${userId}:${feature}:${plan}`;
    const cached = this._cache.get(cacheKey);
    if (cached && Date.now() < cached.expiry) {
      return cached.result;
    }

    // Check plan features
    const planConfig = PLANS[plan] || PLANS.community;
    const allowed = planConfig.features.includes(feature);

    // CSL-gated degradation score
    let degradation = null;
    if (!allowed) {
      // Find the minimum plan that includes this feature
      const upgradePlan = _findUpgradePlan(feature);
      degradation = {
        available: false,
        upgradeTo: upgradePlan?.name || 'Enterprise',
        message: `${feature} requires ${upgradePlan?.name || 'Enterprise'} plan`
      };
    }

    const result = {
      allowed,
      source: 'plan',
      plan,
      feature,
      degradation
    };

    // Cache result
    if (this._cache.size >= CACHE_SIZE) {
      const oldest = this._cache.keys().next().value;
      this._cache.delete(oldest);
    }
    this._cache.set(cacheKey, { result, expiry: Date.now() + CACHE_TTL_MS });

    return result;
  }

  /**
   * Set a feature override for a user
   */
  setOverride(userId, feature, allowed) {
    if (!this._overrides.has(userId)) {
      this._overrides.set(userId, new Map());
    }
    this._overrides.get(userId).set(feature, allowed);
    logger.info({ event: 'feature_override', userId, feature, allowed });
  }

  /**
   * Remove a feature override
   */
  removeOverride(userId, feature) {
    this._overrides.get(userId)?.delete(feature);
  }

  /**
   * Get all features for a plan
   */
  getFeatures(plan) {
    const planConfig = PLANS[plan] || PLANS.community;
    return {
      plan,
      features: planConfig.features,
      rateLimit: planConfig.rateLimit,
      limits: planConfig.limits
    };
  }
}

function _findUpgradePlan(feature) {
  const planOrder = ['community', 'developer', 'team', 'enterprise'];
  for (const planKey of planOrder) {
    if (PLANS[planKey].features.includes(feature)) {
      return { key: planKey, name: PLANS[planKey].name };
    }
  }
  return null;
}

/* ═══════════════════════════════════════════════════════════════
   §4 — Subscription Manager
   ═══════════════════════════════════════════════════════════════ */

class SubscriptionManager {
  constructor() {
    this._subscriptions = new Map(); // userId -> subscription
    this._trials = new Map();        // userId -> trial info
  }

  /**
   * Create a new subscription
   * @param {object} params - Subscription parameters
   * @returns {object} Created subscription
   */
  create(params) {
    const {
      userId, plan, seats = 1, billing = 'monthly',
      stripeCustomerId = null, stripeSubscriptionId = null
    } = params;

    const planConfig = PLANS[plan];
    if (!planConfig) return { error: `Invalid plan: ${plan}` };

    const price = billing === 'annual' ? planConfig.priceAnnual : planConfig.price * 12;
    const monthlyPrice = billing === 'annual' ? Math.round(price / 12) : planConfig.price;

    const subscription = {
      id: `sub_${Date.now().toString(36)}_${userId.substring(0, 8)}`,
      userId,
      plan,
      seats,
      billing,
      monthlyPrice,
      annualPrice: price,
      status: 'active',
      stripeCustomerId,
      stripeSubscriptionId,
      trialEnd: null,
      currentPeriodStart: Date.now(),
      currentPeriodEnd: Date.now() + (billing === 'annual' ? 365.25 * 24 * 3600 * 1000 : 30 * 24 * 3600 * 1000),
      createdAt: Date.now(),
      updatedAt: Date.now()
    };

    this._subscriptions.set(userId, subscription);

    logger.info({
      event: 'subscription_created',
      userId,
      plan,
      billing,
      monthlyPrice,
      seats
    });

    return subscription;
  }

  /**
   * Start a trial for a user
   */
  startTrial(userId, plan = 'developer') {
    const trialEnd = Date.now() + TRIAL_DAYS * 24 * 3600 * 1000;
    
    const trial = {
      userId,
      plan,
      startedAt: Date.now(),
      endsAt: trialEnd,
      daysRemaining: TRIAL_DAYS,
      converted: false
    };

    this._trials.set(userId, trial);

    // Create trial subscription
    const sub = this.create({
      userId,
      plan,
      billing: 'monthly'
    });
    sub.status = 'trialing';
    sub.trialEnd = trialEnd;

    logger.info({ event: 'trial_started', userId, plan, trialDays: TRIAL_DAYS });
    return { trial, subscription: sub };
  }

  /**
   * Upgrade a subscription
   */
  upgrade(userId, newPlan) {
    const sub = this._subscriptions.get(userId);
    if (!sub) return { error: 'No subscription found' };

    const oldPlan = sub.plan;
    const planOrder = ['community', 'developer', 'team', 'enterprise'];
    
    if (planOrder.indexOf(newPlan) <= planOrder.indexOf(oldPlan)) {
      return { error: 'Can only upgrade to a higher tier' };
    }

    const newPlanConfig = PLANS[newPlan];
    sub.plan = newPlan;
    sub.monthlyPrice = newPlanConfig.price;
    sub.updatedAt = Date.now();

    logger.info({ event: 'subscription_upgraded', userId, from: oldPlan, to: newPlan });
    return sub;
  }

  /**
   * Cancel a subscription
   */
  cancel(userId, immediate = false) {
    const sub = this._subscriptions.get(userId);
    if (!sub) return { error: 'No subscription found' };

    if (immediate) {
      sub.status = 'canceled';
      sub.plan = 'community';
    } else {
      sub.status = 'cancel_at_period_end';
    }

    sub.updatedAt = Date.now();
    logger.info({ event: 'subscription_canceled', userId, immediate, endsAt: sub.currentPeriodEnd });
    return sub;
  }

  /**
   * Get subscription for a user
   */
  get(userId) {
    return this._subscriptions.get(userId) || {
      userId,
      plan: 'community',
      status: 'active',
      limits: PLANS.community.limits,
      features: PLANS.community.features
    };
  }

  /**
   * Handle Stripe webhook events
   */
  handleWebhook(event) {
    const { type, data } = event;

    switch (type) {
      case 'customer.subscription.created': {
        const subData = data.object;
        logger.info({ event: 'stripe_subscription_created', subscriptionId: subData.id });
        return { processed: true, action: 'created' };
      }

      case 'customer.subscription.updated': {
        const subData = data.object;
        const userId = subData.metadata?.userId;
        if (userId) {
          const sub = this._subscriptions.get(userId);
          if (sub) {
            sub.status = subData.status;
            sub.updatedAt = Date.now();
          }
        }
        logger.info({ event: 'stripe_subscription_updated', subscriptionId: subData.id });
        return { processed: true, action: 'updated' };
      }

      case 'customer.subscription.deleted': {
        const subData = data.object;
        const userId = subData.metadata?.userId;
        if (userId) {
          const sub = this._subscriptions.get(userId);
          if (sub) {
            sub.status = 'canceled';
            sub.plan = 'community';
            sub.updatedAt = Date.now();
          }
        }
        logger.info({ event: 'stripe_subscription_deleted', subscriptionId: subData.id });
        return { processed: true, action: 'deleted' };
      }

      case 'invoice.payment_succeeded': {
        logger.info({ event: 'stripe_payment_succeeded', invoiceId: data.object?.id });
        return { processed: true, action: 'payment_succeeded' };
      }

      case 'invoice.payment_failed': {
        const invoiceData = data.object;
        const userId = invoiceData.subscription_details?.metadata?.userId;
        if (userId) {
          const sub = this._subscriptions.get(userId);
          if (sub) {
            sub.status = 'past_due';
            sub.updatedAt = Date.now();
          }
        }
        logger.info({ event: 'stripe_payment_failed', invoiceId: invoiceData.id });
        return { processed: true, action: 'payment_failed' };
      }

      default:
        logger.info({ event: 'stripe_webhook_unhandled', type });
        return { processed: false, type };
    }
  }
}

/* ═══════════════════════════════════════════════════════════════
   §5 — Revenue Analytics
   ═══════════════════════════════════════════════════════════════ */

class RevenueAnalytics {
  constructor(subscriptionManager) {
    this._subManager = subscriptionManager;
  }

  /**
   * Calculate Monthly Recurring Revenue
   * @returns {object} MRR breakdown
   */
  calculateMRR() {
    const subs = this._subManager._subscriptions;
    let totalMRR = 0;
    const breakdown = { community: 0, developer: 0, team: 0, enterprise: 0 };
    let activeCount = 0;

    for (const [, sub] of subs) {
      if (sub.status === 'active' || sub.status === 'trialing') {
        const monthlyRevenue = sub.monthlyPrice * (sub.seats || 1);
        totalMRR += monthlyRevenue;
        breakdown[sub.plan] = (breakdown[sub.plan] || 0) + monthlyRevenue;
        activeCount++;
      }
    }

    return {
      total: totalMRR,
      breakdown,
      activeSubscriptions: activeCount,
      arr: totalMRR * 12,
      arpu: activeCount > 0 ? totalMRR / activeCount : 0
    };
  }

  /**
   * Project revenue using phi-weighted growth
   * @param {number} months - Months to project
   * @param {number} monthlyGrowthRate - Monthly growth rate (default PSI²)
   * @returns {Array} Monthly projections
   */
  projectRevenue(months = fib(7), monthlyGrowthRate = Math.pow(PSI, 2)) {
    const currentMRR = this.calculateMRR().total;
    const projections = [];

    for (let i = 0; i < months; i++) {
      // Phi-weighted growth: base growth + phi-modulated acceleration
      const growthFactor = 1 + monthlyGrowthRate * (1 + i / fib(7) * PSI);
      const projected = i === 0 ? currentMRR : projections[i - 1].mrr * growthFactor;

      projections.push({
        month: i + 1,
        mrr: Math.round(projected),
        arr: Math.round(projected * 12),
        growthRate: (growthFactor - 1).toFixed(3)
      });
    }

    return projections;
  }

  /**
   * Calculate churn metrics
   * @returns {object} Churn metrics
   */
  getChurnMetrics() {
    const subs = this._subManager._subscriptions;
    let active = 0;
    let churned = 0;
    let trial = 0;

    for (const [, sub] of subs) {
      if (sub.status === 'active') active++;
      else if (sub.status === 'canceled' || sub.status === 'cancel_at_period_end') churned++;
      else if (sub.status === 'trialing') trial++;
    }

    const total = active + churned + trial;
    return {
      active,
      churned,
      trialing: trial,
      churnRate: total > 0 ? (churned / total).toFixed(3) : '0.000',
      retentionRate: total > 0 ? (active / total).toFixed(3) : '1.000',
      trialConversionTarget: (PSI * PSI * PSI).toFixed(3) // ψ³ ≈ 23.6%
    };
  }
}

/* ═══════════════════════════════════════════════════════════════
   §6 — Pricing Page Data
   ═══════════════════════════════════════════════════════════════ */

function getPricingData() {
  return Object.entries(PLANS).map(([key, plan]) => ({
    key,
    name: plan.name,
    price: plan.price === null ? 'Custom' : plan.price === 0 ? 'Free' : `$${plan.price}/mo`,
    priceAnnual: plan.priceAnnual === null ? 'Custom' :
                 plan.priceAnnual === 0 ? 'Free' :
                 `$${Math.round(plan.priceAnnual / 12)}/mo (billed annually)`,
    annualDiscount: `${ANNUAL_DISCOUNT_PCT}%`,
    features: plan.features,
    limits: Object.fromEntries(
      Object.entries(plan.limits).map(([k, v]) => [k, v === Infinity ? 'Unlimited' : v])
    ),
    rateLimit: `${plan.rateLimit} req/min`,
    seats: plan.seats === null ? 'Per seat' : plan.seats === 1 ? 'Single user' : `${plan.seats} seats`,
    trialDays: key !== 'community' ? TRIAL_DAYS : null,
    recommended: key === 'developer'
  }));
}

/* ═══════════════════════════════════════════════════════════════
   §7 — Health & Export
   ═══════════════════════════════════════════════════════════════ */

const health = createHealthCheck('monetization-engine', () => ({
  plans: Object.keys(PLANS).length,
  metrics: METRIC_TYPES.length,
  trialDays: TRIAL_DAYS,
  annualDiscount: ANNUAL_DISCOUNT_PCT,
  alertLevels: Object.keys(USAGE_ALERTS).length
}));



module.exports = {
  UsageMeter,
  FeatureGate,
  SubscriptionManager,
  RevenueAnalytics,
  getPricingData,
  health,
  PLANS,
  METRIC_TYPES,
  USAGE_ALERTS,
  TRIAL_DAYS,
  ANNUAL_DISCOUNT_PCT
};
