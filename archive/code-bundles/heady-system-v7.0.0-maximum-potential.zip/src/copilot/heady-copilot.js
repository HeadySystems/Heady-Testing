/**
 * HeadyCopilot — IDE Integration Layer for Real-Time Code Suggestions
 * 
 * LSP-compatible code intelligence server providing context-aware completions,
 * inline suggestions, diagnostics, and code actions. Integrates with HeadyRefactor
 * for phi-compliance enforcement and HeadyCodex for documentation generation.
 * 
 * Features:
 * - LSP-compatible JSON-RPC interface (textDocument/completion, hover, codeAction)
 * - Context-aware completions using embedding similarity
 * - Phi-compliance inline diagnostics
 * - Quick-fix code actions for auto-fixable issues
 * - Snippet generation for Heady patterns (liquid nodes, bees, CSL gates)
 * - Real-time file watching with debounced analysis
 * 
 * @module heady-copilot
 * @version 1.0.0
 * @author Eric Haywood
 */

const {
  PHI,
  PSI,
  PHI2,
  PHI3,
  fib,
  fibonacci,
  phiThreshold,
  phiFusionWeights,
  phiBackoff,
  CSL_THRESHOLDS,
  PRESSURE_LEVELS,
  SIZING,
  cslGate,
  cosineSimilarity,
  SERVICE_PORTS
} = require('../../shared/phi-math.js');
const { createLogger } = require('../../shared/logger.js');
const { createHealthCheck } = require('../../shared/health.js');

const logger = createLogger('heady-copilot');

/* ═══════════════════════════════════════════════════════════════
   §1 — Constants (all phi-derived)
   ═══════════════════════════════════════════════════════════════ */

const MAX_COMPLETIONS = fib(8);          // 21 completion items
const MAX_DIAGNOSTICS_PER_FILE = fib(10); // 55 diagnostics
const DEBOUNCE_MS = fib(9) * 10;         // 340ms debounce for diagnostics
const COMPLETION_CACHE_SIZE = fib(16);    // 987 cached completions
const COMPLETION_CACHE_TTL = fib(11) * 1000; // 89 seconds
const CONTEXT_WINDOW_TOKENS = fib(12);   // 144 tokens of context
const SNIPPET_CACHE_SIZE = fib(14);      // 377 cached snippets
const MAX_HOVER_LINES = fib(8);          // 21 lines in hover preview
const SUGGESTION_THRESHOLD = CSL_THRESHOLDS.LOW; // 0.691 minimum relevance

/** LSP Diagnostic Severity mapping */
const SEVERITY_MAP = {
  CRITICAL: 1, // Error
  HIGH: 1,     // Error
  MEDIUM: 2,   // Warning
  LOW: 3       // Information
};

/** LSP Completion Item Kinds */
const COMPLETION_KINDS = {
  SNIPPET: 15,
  FUNCTION: 3,
  CONSTANT: 21,
  MODULE: 9,
  PROPERTY: 10,
  VALUE: 12
};

/* ═══════════════════════════════════════════════════════════════
   §2 — Snippet Library (Heady Patterns)
   ═══════════════════════════════════════════════════════════════ */

const SNIPPETS = [
  // Liquid Node Pattern
  {
    label: 'heady-liquid-node',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'Heady Liquid Node boilerplate',
    insertText: [
      "import { LiquidNode } from '../liquid/liquid-node.js';",
      "const { createLogger } = require('../../shared/logger.js');",
      "const { createHealthCheck } = require('../../shared/health.js');",
      "import { PHI, PSI, fib, CSL_THRESHOLDS } from '../../shared/phi-math.js';",
      "",
      "const logger = createLogger('${1:node-name}');",
      "",
      "class ${2:NodeName}Node extends LiquidNode {",
      "  constructor(config = {}) {",
      "    super({",
      "      id: '${1:node-name}',",
      "      type: '${3:intelligence}',",
      "      ...config",
      "    });",
      "    this._cache = new Map();",
      "  }",
      "",
      "  async process(input) {",
      "    try {",
      "      ${4:// Implementation}",
      "      return { success: true, data: null };",
      "    } catch (err) {",
      "      logger.error({ event: 'process_error', error: err.message });",
      "      return { success: false, error: err.message };",
      "    }",
      "  }",
      "",
      "  async shutdown() {",
      "    this._cache.clear();",
      "    await super.shutdown();",
      "  }",
      "}",
      "",
      "const health = createHealthCheck('${1:node-name}', () => ({",
      "  cacheSize: ${2:NodeName}Node._cache?.size || 0",
      "}));",
      "",
      "export { ${2:NodeName}Node, health };"
    ].join('\n'),
    documentation: 'Creates a full Liquid Node with phi-math imports, structured logging, health checks, and error handling.',
    sortText: '0001',
    tags: ['liquid', 'node', 'heady']
  },

  // HeadyBee Worker Pattern
  {
    label: 'heady-bee-worker',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'HeadyBee worker boilerplate',
    insertText: [
      "import { HeadyBee } from '../bees/heady-bee.js';",
      "const { createLogger } = require('../../shared/logger.js');",
      "import { PHI, PSI, fib } from '../../shared/phi-math.js';",
      "",
      "const logger = createLogger('${1:bee-name}');",
      "",
      "class ${2:BeeClassName} extends HeadyBee {",
      "  constructor(config = {}) {",
      "    super({",
      "      name: '${1:bee-name}',",
      "      domain: '${3:general}',",
      "      pool: '${4|hot,warm,cold|}',",
      "      interval: fib(${5:8}) * 1000,",
      "      ...config",
      "    });",
      "  }",
      "",
      "  async execute(task) {",
      "    try {",
      "      logger.info({ event: 'task_start', taskId: task.id });",
      "      ${6:// Implementation}",
      "      return { success: true };",
      "    } catch (err) {",
      "      logger.error({ event: 'task_error', taskId: task.id, error: err.message });",
      "      throw err;",
      "    }",
      "  }",
      "}",
      "",
      "export { ${2:BeeClassName} };"
    ].join('\n'),
    documentation: 'Creates a HeadyBee worker with phi-scaled intervals, structured logging, and pool assignment.',
    sortText: '0002',
    tags: ['bee', 'worker', 'swarm']
  },

  // CSL Gate Pattern
  {
    label: 'heady-csl-gate',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'CSL sigmoid gate pattern',
    insertText: [
      "const gatedValue = cslGate(",
      "  ${1:inputValue},",
      "  ${2:gateScore},",
      "  CSL_THRESHOLDS.${3|MEDIUM,LOW,HIGH,CRITICAL|}",
      ");",
      "",
      "if (gatedValue >= CSL_THRESHOLDS.${4|LOW,MEDIUM,HIGH|}) {",
      "  ${5:// Action when gate passes}",
      "}"
    ].join('\n'),
    documentation: 'CSL sigmoid gate with phi-derived threshold. Uses smooth transition instead of hard if/else.',
    sortText: '0003',
    tags: ['csl', 'gate', 'threshold']
  },

  // Phi-Math Import Pattern
  {
    label: 'heady-phi-import',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'Standard phi-math imports',
    insertText: [
      "import {",
      "  PHI, PSI, PHI2, PHI3,",
      "  fib, fibonacci, phiThreshold,",
      "  phiFusionWeights, phiBackoff,",
      "  CSL_THRESHOLDS, PRESSURE_LEVELS,",
      "  SIZING, ALERT_THRESHOLDS,",
      "  cslGate, cosineSimilarity",
      "} from '${1:../../shared/phi-math.js}';"
    ].join('\n'),
    documentation: 'Standard phi-math.js v5.1 import block with all commonly used exports.',
    sortText: '0004',
    tags: ['import', 'phi', 'math']
  },

  // Health Check Pattern
  {
    label: 'heady-health-check',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'Kubernetes health check export',
    insertText: [
      "const health = createHealthCheck('${1:service-name}', () => ({",
      "  ${2:cacheSize}: ${3:0},",
      "  ${4:activeConnections}: ${5:0},",
      "  uptime: process.uptime()",
      "}));",
      "",
      ""
    ].join('\n'),
    documentation: 'Creates a Kubernetes-compatible health check with custom metrics.',
    sortText: '0005',
    tags: ['health', 'kubernetes', 'probe']
  },

  // Circuit Breaker Pattern
  {
    label: 'heady-circuit-breaker',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'Phi-scaled circuit breaker',
    insertText: [
      "class CircuitBreaker {",
      "  constructor(name) {",
      "    this._name = name;",
      "    this._state = 'CLOSED';",
      "    this._failures = 0;",
      "    this._threshold = fib(5); // 5 failures",
      "    this._resetMs = fib(8) * PSI * 1000; // ~12.978s",
      "    this._lastFailure = 0;",
      "    this._probeCount = 0;",
      "    this._probeMax = fib(3); // 2 probes",
      "  }",
      "",
      "  async call(fn) {",
      "    if (this._state === 'OPEN') {",
      "      if (Date.now() - this._lastFailure > this._resetMs) {",
      "        this._state = 'HALF_OPEN';",
      "        this._probeCount = 0;",
      "      } else {",
      "        throw new Error(`Circuit ${this._name} is OPEN`);",
      "      }",
      "    }",
      "",
      "    try {",
      "      const result = await fn();",
      "      this._onSuccess();",
      "      return result;",
      "    } catch (err) {",
      "      this._onFailure();",
      "      throw err;",
      "    }",
      "  }",
      "",
      "  _onSuccess() {",
      "    if (this._state === 'HALF_OPEN') {",
      "      this._probeCount++;",
      "      if (this._probeCount >= this._probeMax) {",
      "        this._state = 'CLOSED';",
      "        this._failures = 0;",
      "      }",
      "    } else {",
      "      this._failures = 0;",
      "    }",
      "  }",
      "",
      "  _onFailure() {",
      "    this._failures++;",
      "    this._lastFailure = Date.now();",
      "    if (this._failures >= this._threshold) {",
      "      this._state = 'OPEN';",
      "    }",
      "  }",
      "}"
    ].join('\n'),
    documentation: 'Phi-scaled circuit breaker with CLOSED -> OPEN -> HALF_OPEN states. Fibonacci failure threshold, PSI-derived reset timeout.',
    sortText: '0006',
    tags: ['circuit', 'breaker', 'resilience']
  },

  // Express Route with Auth
  {
    label: 'heady-express-route',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'Express route with auth & error handling',
    insertText: [
      "router.${1|get,post,put,delete|}('/${2:path}', async (req, res) => {",
      "  try {",
      "    const session = req.cookies?.['__Host-heady_session'];",
      "    if (!session) {",
      "      return res.status(401).json({ error: 'Unauthorized', code: 'AUTH_REQUIRED' });",
      "    }",
      "",
      "    ${3:// Implementation}",
      "",
      "    res.json({ success: true, data: null });",
      "  } catch (err) {",
      "    logger.error({ event: 'route_error', path: '/${2:path}', error: err.message });",
      "    res.status(500).json({ error: 'Internal error', code: 'INTERNAL_ERROR' });",
      "  }",
      "});"
    ].join('\n'),
    documentation: 'Express route with httpOnly cookie auth (no localStorage), structured error response, and logging.',
    sortText: '0007',
    tags: ['express', 'route', 'auth']
  },

  // Structured Logger Pattern
  {
    label: 'heady-logger',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'Structured JSON logger setup',
    insertText: [
      "import { createLogger } from '${1:../../shared/logger.js}';",
      "",
      "const logger = createLogger('${2:module-name}');",
      "",
      "// Usage:",
      "logger.info({ event: '${3:event_name}', ${4:key}: ${5:value} });",
      "logger.error({ event: '${3:event_name}_error', error: err.message });"
    ].join('\n'),
    documentation: 'Structured JSON logger — zero console.log, Heady standard.',
    sortText: '0008',
    tags: ['logger', 'logging', 'structured']
  },

  // Phi-Backoff Retry Pattern
  {
    label: 'heady-phi-retry',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'Phi-scaled retry with backoff',
    insertText: [
      "async function withRetry(fn, maxAttempts = fib(5)) {",
      "  for (let attempt = 0; attempt < maxAttempts; attempt++) {",
      "    try {",
      "      return await fn();",
      "    } catch (err) {",
      "      if (attempt === maxAttempts - 1) throw err;",
      "      const delayMs = phiBackoff(attempt);",
      "      logger.info({ event: 'retry', attempt, delayMs, error: err.message });",
      "      await new Promise(r => setTimeout(r, delayMs));",
      "    }",
      "  }",
      "}"
    ].join('\n'),
    documentation: 'Phi-scaled exponential backoff retry with Fibonacci max attempts.',
    sortText: '0009',
    tags: ['retry', 'backoff', 'resilience']
  },

  // Graceful Shutdown Hook
  {
    label: 'heady-shutdown-hook',
    kind: COMPLETION_KINDS.SNIPPET,
    detail: 'Graceful shutdown registration',
    insertText: [
      "import { registerShutdownHook } from '../lifecycle/graceful-shutdown.js';",
      "",
      "registerShutdownHook({",
      "  name: '${1:resource-name}',",
      "  phase: '${2|APPLICATION,CONNECTIONS,PERSISTENCE,INFRASTRUCTURE|}',",
      "  fn: async () => {",
      "    logger.info({ event: 'shutdown', resource: '${1:resource-name}' });",
      "    ${3:// Cleanup logic}",
      "  }",
      "});"
    ].join('\n'),
    documentation: 'Registers a LIFO graceful shutdown hook in the correct phase.',
    sortText: '0010',
    tags: ['shutdown', 'lifecycle', 'cleanup']
  }
];

/* ═══════════════════════════════════════════════════════════════
   §3 — Completion Engine
   ═══════════════════════════════════════════════════════════════ */

const _completionCache = new Map();

/**
 * Get context-aware completions at a position
 * @param {object} params - LSP-style completion params
 * @param {string} params.code - Current file content
 * @param {number} params.line - Cursor line (0-based)
 * @param {number} params.character - Cursor character (0-based)
 * @param {string} [params.filePath] - File path for context
 * @param {string} [params.trigger] - Trigger character (e.g., '.', '(')
 * @returns {object} LSP CompletionList
 */
function getCompletions(params) {
  const { code, line, character, filePath = 'unknown', trigger = null } = params;
  
  const cacheKey = `${filePath}:${line}:${character}:${_hashPrefix(code, line)}`;
  const cached = _completionCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < COMPLETION_CACHE_TTL) {
    return cached.result;
  }

  const lines = code.split('\n');
  const currentLine = lines[line] || '';
  const prefix = currentLine.substring(0, character).trim();
  
  const items = [];

  // 1. Snippet completions based on prefix
  const snippetItems = _matchSnippets(prefix);
  items.push(...snippetItems);

  // 2. Phi-math constant completions
  if (prefix.includes('fib(') || prefix.includes('fibonacci(')) {
    items.push(..._getFibCompletions());
  }
  if (prefix.includes('phiThreshold(') || prefix.includes('CSL_THRESHOLDS.')) {
    items.push(..._getThresholdCompletions());
  }
  if (prefix.includes('PRESSURE_LEVELS.') || prefix.includes('ALERT_THRESHOLDS.')) {
    items.push(..._getLevelCompletions());
  }

  // 3. Import completions
  if (prefix.includes('import') && prefix.includes('from')) {
    items.push(..._getImportCompletions(prefix));
  }

  // 4. Common Heady API completions
  if (trigger === '.') {
    items.push(..._getDotCompletions(prefix));
  }

  // Limit and sort
  const result = {
    isIncomplete: items.length > MAX_COMPLETIONS,
    items: items.slice(0, MAX_COMPLETIONS)
  };

  // Cache
  if (_completionCache.size >= COMPLETION_CACHE_SIZE) {
    const oldest = _completionCache.keys().next().value;
    _completionCache.delete(oldest);
  }
  _completionCache.set(cacheKey, { result, timestamp: Date.now() });

  logger.info({
    event: 'completions',
    filePath,
    line,
    itemCount: result.items.length,
    trigger
  });

  return result;
}

function _matchSnippets(prefix) {
  const items = [];
  const lowerPrefix = prefix.toLowerCase();
  
  for (const snippet of SNIPPETS) {
    const relevance = _snippetRelevance(lowerPrefix, snippet);
    if (relevance >= SUGGESTION_THRESHOLD) {
      items.push({
        label: snippet.label,
        kind: snippet.kind,
        detail: snippet.detail,
        documentation: snippet.documentation,
        insertText: snippet.insertText,
        insertTextFormat: 2, // Snippet format
        sortText: snippet.sortText,
        data: { relevance }
      });
    }
  }

  return items.sort((a, b) => a.sortText.localeCompare(b.sortText));
}

function _snippetRelevance(prefix, snippet) {
  if (!prefix || prefix.length < 2) return 0;
  
  // Check if any tag matches prefix
  for (const tag of snippet.tags) {
    if (prefix.includes(tag)) return CSL_THRESHOLDS.HIGH;
  }
  
  // Check label match
  if (snippet.label.toLowerCase().includes(prefix)) return CSL_THRESHOLDS.MEDIUM;
  
  // Check partial match
  const prefixWords = prefix.split(/[\s\-_./]+/).filter(w => w.length > 1);
  let matches = 0;
  for (const word of prefixWords) {
    if (snippet.label.toLowerCase().includes(word) ||
        snippet.tags.some(t => t.includes(word))) {
      matches++;
    }
  }
  
  return matches > 0 ? matches / prefixWords.length : 0;
}

function _getFibCompletions() {
  const fibs = [
    { n: 5, v: 5, use: 'failure thresholds' },
    { n: 6, v: 8, use: 'batch sizes' },
    { n: 7, v: 13, use: 'small limits' },
    { n: 8, v: 21, use: 'HNSW M, medium limits' },
    { n: 9, v: 34, use: 'sliding windows' },
    { n: 10, v: 55, use: 'max entities' },
    { n: 11, v: 89, use: 'retention days' },
    { n: 12, v: 144, use: 'ef_construction' },
    { n: 13, v: 233, use: 'queue depths' },
    { n: 14, v: 377, use: 'pattern stores' },
    { n: 16, v: 987, use: 'cache sizes' },
    { n: 17, v: 1597, use: 'history buffers' },
    { n: 20, v: 6765, use: 'large LRU caches' }
  ];

  return fibs.map(f => ({
    label: `fib(${f.n})`,
    kind: COMPLETION_KINDS.VALUE,
    detail: `= ${f.v} — ${f.use}`,
    insertText: `fib(${f.n})`,
    documentation: `Fibonacci(${f.n}) = ${f.v}\nCommon use: ${f.use}`,
    sortText: String(f.n).padStart(3, '0')
  }));
}

function _getThresholdCompletions() {
  return [
    { label: 'CSL_THRESHOLDS.CRITICAL', detail: '≈ 0.927', doc: 'Near-certain alignment' },
    { label: 'CSL_THRESHOLDS.HIGH', detail: '≈ 0.882', doc: 'Strong alignment' },
    { label: 'CSL_THRESHOLDS.MEDIUM', detail: '≈ 0.809', doc: 'Moderate alignment' },
    { label: 'CSL_THRESHOLDS.LOW', detail: '≈ 0.691', doc: 'Weak alignment' },
    { label: 'CSL_THRESHOLDS.MINIMUM', detail: '≈ 0.500', doc: 'Noise floor' }
  ].map((t, i) => ({
    label: t.label,
    kind: COMPLETION_KINDS.CONSTANT,
    detail: t.detail,
    documentation: t.doc,
    insertText: t.label,
    sortText: String(i).padStart(3, '0')
  }));
}

function _getLevelCompletions() {
  return [
    { label: 'PRESSURE_LEVELS.NOMINAL_MAX', detail: '≈ 0.382 (ψ²)' },
    { label: 'PRESSURE_LEVELS.ELEVATED_MAX', detail: '≈ 0.618 (ψ)' },
    { label: 'PRESSURE_LEVELS.HIGH_MAX', detail: '≈ 0.854 (1-ψ³)' },
    { label: 'PRESSURE_LEVELS.CRITICAL_MIN', detail: '≈ 0.910 (1-ψ⁴)' },
    { label: 'ALERT_THRESHOLDS.warning', detail: '≈ 0.618' },
    { label: 'ALERT_THRESHOLDS.caution', detail: '≈ 0.764' },
    { label: 'ALERT_THRESHOLDS.critical', detail: '≈ 0.854' },
    { label: 'ALERT_THRESHOLDS.exceeded', detail: '≈ 0.910' }
  ].map((t, i) => ({
    label: t.label,
    kind: COMPLETION_KINDS.CONSTANT,
    detail: t.detail,
    insertText: t.label,
    sortText: String(i).padStart(3, '0')
  }));
}

function _getImportCompletions(prefix) {
  const modules = [
    { path: '../../shared/phi-math.js', desc: 'Phi-math foundation v5.1' },
    { path: '../../shared/logger.js', desc: 'Structured JSON logger' },
    { path: '../../shared/health.js', desc: 'Health check factory' },
    { path: '../../shared/pgvector-client.js', desc: 'pgvector database client' },
    { path: '../../shared/nats-client.js', desc: 'NATS JetStream client' },
    { path: '../../shared/firebase-admin.js', desc: 'Firebase Auth admin' },
    { path: '../../shared/secret-manager.js', desc: 'GCP Secret Manager' },
    { path: '../../shared/security/encryption.js', desc: 'AES-256-GCM encryption' },
    { path: '../../shared/security/zero-trust.js', desc: 'Zero-trust validation' }
  ];

  return modules.map((m, i) => ({
    label: m.path,
    kind: COMPLETION_KINDS.MODULE,
    detail: m.desc,
    insertText: `'${m.path}'`,
    sortText: String(i).padStart(3, '0')
  }));
}

function _getDotCompletions(prefix) {
  const items = [];
  
  if (prefix.endsWith('logger.')) {
    for (const method of ['info', 'warn', 'error', 'debug']) {
      items.push({
        label: method,
        kind: COMPLETION_KINDS.FUNCTION,
        detail: `logger.${method}({ event, ... })`,
        insertText: `${method}({ event: '\${1:event_name}', \${2:key}: \${3:value} })`,
        insertTextFormat: 2,
        sortText: '0001'
      });
    }
  }
  
  if (prefix.endsWith('health.')) {
    items.push({
      label: 'check',
      kind: COMPLETION_KINDS.FUNCTION,
      detail: 'Run health check',
      insertText: 'check()',
      sortText: '0001'
    });
  }

  return items;
}

/* ═══════════════════════════════════════════════════════════════
   §4 — Diagnostics Engine
   ═══════════════════════════════════════════════════════════════ */

const _diagnosticTimers = new Map();

/**
 * Get diagnostics for a file (phi-compliance issues as LSP diagnostics)
 * @param {string} code - File content
 * @param {string} filePath - File path
 * @returns {Array} LSP Diagnostic array
 */
function getDiagnostics(code, filePath = 'unknown') {
  // Import analysis from HeadyRefactor
  const issues = _analyzeForDiagnostics(code, filePath);
  
  const diagnostics = issues.slice(0, MAX_DIAGNOSTICS_PER_FILE).map(issue => ({
    range: {
      start: { line: Math.max(0, issue.line - 1), character: Math.max(0, issue.column - 1) },
      end: { line: Math.max(0, issue.line - 1), character: issue.column + (issue.value?.length || 1) }
    },
    severity: SEVERITY_MAP[issue.severity] || 3,
    code: issue.ruleId,
    source: 'heady-copilot',
    message: issue.message,
    data: issue.autoFixable ? { fix: issue.fix } : undefined
  }));

  logger.info({
    event: 'diagnostics',
    filePath,
    count: diagnostics.length,
    errors: diagnostics.filter(d => d.severity === 1).length,
    warnings: diagnostics.filter(d => d.severity === 2).length
  });

  return diagnostics;
}

/**
 * Get diagnostics with debouncing for real-time editing
 * @param {string} code - File content
 * @param {string} filePath - File path
 * @param {function} callback - Called with diagnostics when debounce completes
 */
function getDiagnosticsDebounced(code, filePath, callback) {
  const existing = _diagnosticTimers.get(filePath);
  if (existing) clearTimeout(existing);

  const timer = setTimeout(() => {
    const diagnostics = getDiagnostics(code, filePath);
    _diagnosticTimers.delete(filePath);
    callback(diagnostics);
  }, DEBOUNCE_MS);

  _diagnosticTimers.set(filePath, timer);
}

/**
 * Inline analysis for diagnostics (lightweight version of HeadyRefactor)
 */
function _analyzeForDiagnostics(code, filePath) {
  const issues = [];

  // Console.log detection
  const consolePattern = /console\.(log|warn|error|info|debug)\s*\(/g;
  let match;
  while ((match = consolePattern.exec(code)) !== null) {
    issues.push({
      ruleId: 'SEC_001',
      line: _getLineNumber(code, match.index),
      column: _getColumn(code, match.index),
      value: match[0],
      message: `console.${match[1]}() — use structured logger`,
      severity: 'HIGH',
      autoFixable: true,
      fix: { original: `console.${match[1]}(`, replacement: `logger.${match[1] === 'log' ? 'info' : match[1]}({` }
    });
  }

  // localStorage detection
  const lsPattern = /(?:localStorage|sessionStorage)\./g;
  while ((match = lsPattern.exec(code)) !== null) {
    issues.push({
      ruleId: 'SEC_002',
      line: _getLineNumber(code, match.index),
      column: _getColumn(code, match.index),
      value: match[0],
      message: 'Use __Host-heady_session httpOnly cookie instead',
      severity: 'CRITICAL',
      autoFixable: false
    });
  }

  // TODO/FIXME detection
  const todoPattern = /\/\/\s*(TODO|FIXME|HACK)\b[:\s]*(.*)/gi;
  while ((match = todoPattern.exec(code)) !== null) {
    issues.push({
      ruleId: 'READ_001',
      line: _getLineNumber(code, match.index),
      column: _getColumn(code, match.index),
      value: match[0],
      message: `${match[1]}: ${match[2].trim()} — resolve for production`,
      severity: 'LOW',
      autoFixable: false
    });
  }

  // Magic number detection (lightweight)
  const magicPattern = /(?<!\w)(?:100|500|1000|5000|10000)\b(?!\s*[;,\]})])/g;
  while ((match = magicPattern.exec(code)) !== null) {
    // Skip if inside a comment or string
    const lineStart = code.lastIndexOf('\n', match.index);
    const lineText = code.substring(lineStart + 1, code.indexOf('\n', match.index));
    if (lineText.trimStart().startsWith('//') || lineText.trimStart().startsWith('*')) continue;

    issues.push({
      ruleId: 'PHI_001',
      line: _getLineNumber(code, match.index),
      column: _getColumn(code, match.index),
      value: match[0],
      message: `Magic number ${match[0]} — derive from phi/Fibonacci`,
      severity: 'MEDIUM',
      autoFixable: false
    });
  }

  return issues;
}

/* ═══════════════════════════════════════════════════════════════
   §5 — Code Actions (Quick Fixes)
   ═══════════════════════════════════════════════════════════════ */

/**
 * Get code actions for diagnostics at a range
 * @param {string} code - File content
 * @param {object} range - LSP Range
 * @param {Array} diagnostics - Active diagnostics in range
 * @returns {Array} LSP CodeAction array
 */
function getCodeActions(code, range, diagnostics) {
  const actions = [];

  for (const diag of diagnostics) {
    if (diag.data?.fix) {
      actions.push({
        title: `Fix: ${diag.message.substring(0, 55)}`,
        kind: 'quickfix',
        diagnostics: [diag],
        edit: {
          changes: {
            [diag.source]: [{
              range: diag.range,
              newText: diag.data.fix.replacement
            }]
          }
        },
        isPreferred: true
      });
    }

    // Rule-specific actions
    if (diag.code === 'SEC_001') {
      actions.push({
        title: 'Import HeadyLogger',
        kind: 'quickfix',
        diagnostics: [diag],
        edit: {
          changes: {
            [diag.source]: [{
              range: { start: { line: 0, character: 0 }, end: { line: 0, character: 0 } },
              newText: "const { createLogger } = require('../../shared/logger.js');\nconst logger = createLogger('module-name');\n\n"
            }]
          }
        }
      });
    }
  }

  // Add Heady-specific refactoring actions
  const lineContent = code.split('\n')[range.start.line] || '';
  
  if (lineContent.includes('function') || lineContent.includes('=>')) {
    actions.push({
      title: 'Add error handling (try/catch)',
      kind: 'refactor.rewrite',
      command: {
        title: 'Wrap in try/catch',
        command: 'heady.wrapTryCatch',
        arguments: [range]
      }
    });
  }

  if (!lineContent.includes('/**') && (lineContent.includes('export function') || lineContent.includes('export async'))) {
    actions.push({
      title: 'Generate JSDoc documentation',
      kind: 'refactor.inline',
      command: {
        title: 'Generate JSDoc',
        command: 'heady.generateJSDoc',
        arguments: [range]
      }
    });
  }

  return actions;
}

/* ═══════════════════════════════════════════════════════════════
   §6 — Hover Provider
   ═══════════════════════════════════════════════════════════════ */

/**
 * Get hover information at a position
 * @param {string} code - File content
 * @param {number} line - Cursor line (0-based)
 * @param {number} character - Cursor character (0-based)
 * @returns {object|null} LSP Hover result
 */
function getHover(code, line, character) {
  const lines = code.split('\n');
  const lineText = lines[line] || '';
  
  // Extract word at cursor
  const word = _getWordAtPosition(lineText, character);
  if (!word) return null;

  // Check phi-math constants
  const phiHovers = {
    'PHI': { value: '≈ 1.6180339887', desc: 'Golden ratio (1 + √5) / 2' },
    'PSI': { value: '≈ 0.6180339887', desc: 'Conjugate golden ratio (1/φ = φ - 1)' },
    'PHI2': { value: '≈ 2.6180339887', desc: 'φ² = φ + 1' },
    'PHI3': { value: '≈ 4.2360679775', desc: 'φ³ = 2φ + 1' },
    'PHI_TEMPERATURE': { value: '≈ 0.236', desc: 'ψ³ — canonical CSL gate temperature' },
    'DEDUP_THRESHOLD': { value: '≈ 0.972', desc: 'Above CRITICAL, for semantic identity' }
  };

  if (phiHovers[word]) {
    const h = phiHovers[word];
    return {
      contents: {
        kind: 'markdown',
        value: `**${word}** = ${h.value}\n\n${h.desc}\n\n*Source: shared/phi-math.js v5.1*`
      }
    };
  }

  // Check fib() calls
  const fibMatch = lineText.match(/fib\((\d+)\)/);
  if (fibMatch && character >= lineText.indexOf(fibMatch[0]) && character <= lineText.indexOf(fibMatch[0]) + fibMatch[0].length) {
    const n = parseInt(fibMatch[1], 10);
    const val = _fibValue(n);
    return {
      contents: {
        kind: 'markdown',
        value: `**fib(${n})** = ${val}\n\nFibonacci number at index ${n}`
      }
    };
  }

  // Check CSL threshold references
  const cslMatch = lineText.match(/CSL_THRESHOLDS\.(\w+)/);
  if (cslMatch) {
    const thresholds = {
      CRITICAL: { value: '≈ 0.927', desc: 'phiThreshold(4) — near-certain alignment' },
      HIGH: { value: '≈ 0.882', desc: 'phiThreshold(3) — strong alignment' },
      MEDIUM: { value: '≈ 0.809', desc: 'phiThreshold(2) — moderate alignment' },
      LOW: { value: '≈ 0.691', desc: 'phiThreshold(1) — weak alignment' },
      MINIMUM: { value: '≈ 0.500', desc: 'phiThreshold(0) — noise floor' }
    };
    const t = thresholds[cslMatch[1]];
    if (t) {
      return {
        contents: {
          kind: 'markdown',
          value: `**CSL_THRESHOLDS.${cslMatch[1]}** = ${t.value}\n\n${t.desc}\n\nFormula: \`1 - ψ^level × 0.5\``
        }
      };
    }
  }

  return null;
}

/* ═══════════════════════════════════════════════════════════════
   §7 — LSP Server (JSON-RPC)
   ═══════════════════════════════════════════════════════════════ */

/**
 * Handle LSP JSON-RPC request
 * @param {object} request - JSON-RPC request
 * @returns {object} JSON-RPC response
 */
function handleLSPRequest(request) {
  const { id, method, params } = request;

  try {
    let result = null;

    switch (method) {
      case 'initialize':
        result = {
          capabilities: {
            completionProvider: { triggerCharacters: ['.', '(', "'", '"'], resolveProvider: false },
            hoverProvider: true,
            codeActionProvider: { codeActionKinds: ['quickfix', 'refactor.rewrite', 'refactor.inline'] },
            textDocumentSync: { openClose: true, change: 2, save: { includeText: true } },
            diagnosticProvider: { interFileDependencies: false, workspaceDiagnostics: false }
          },
          serverInfo: { name: 'HeadyCopilot', version: '1.0.0' }
        };
        break;

      case 'textDocument/completion':
        result = getCompletions({
          code: params.textDocument?.text || '',
          line: params.position?.line || 0,
          character: params.position?.character || 0,
          filePath: params.textDocument?.uri || 'unknown',
          trigger: params.context?.triggerCharacter
        });
        break;

      case 'textDocument/hover':
        result = getHover(
          params.textDocument?.text || '',
          params.position?.line || 0,
          params.position?.character || 0
        );
        break;

      case 'textDocument/codeAction':
        result = getCodeActions(
          params.textDocument?.text || '',
          params.range,
          params.context?.diagnostics || []
        );
        break;

      case 'textDocument/diagnostic':
        result = {
          kind: 'full',
          items: getDiagnostics(
            params.textDocument?.text || '',
            params.textDocument?.uri || 'unknown'
          )
        };
        break;

      case 'shutdown':
        _cleanup();
        result = null;
        break;

      default:
        return { jsonrpc: '2.0', id, error: { code: -32601, message: `Method not found: ${method}` } };
    }

    return { jsonrpc: '2.0', id, result };
  } catch (err) {
    logger.error({ event: 'lsp_error', method, error: err.message });
    return { jsonrpc: '2.0', id, error: { code: -32603, message: err.message } };
  }
}

/* ═══════════════════════════════════════════════════════════════
   §8 — Utility Functions
   ═══════════════════════════════════════════════════════════════ */

function _getLineNumber(code, index) {
  return code.substring(0, index).split('\n').length;
}

function _getColumn(code, index) {
  const lastNewline = code.lastIndexOf('\n', index);
  return index - lastNewline;
}

function _hashPrefix(code, line) {
  const lines = code.split('\n');
  const start = Math.max(0, line - fib(5));
  const end = Math.min(lines.length, line + fib(5));
  return lines.slice(start, end).join('').length;
}

function _getWordAtPosition(lineText, character) {
  const left = lineText.substring(0, character).match(/[\w$]+$/)?.[0] || '';
  const right = lineText.substring(character).match(/^[\w$]+/)?.[0] || '';
  return left + right || null;
}

function _fibValue(n) {
  const fibs = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765];
  return n < fibs.length ? fibs[n] : '(large)';
}

function _cleanup() {
  _completionCache.clear();
  for (const timer of _diagnosticTimers.values()) clearTimeout(timer);
  _diagnosticTimers.clear();
}

/* ═══════════════════════════════════════════════════════════════
   §9 — Health & Export
   ═══════════════════════════════════════════════════════════════ */

const health = createHealthCheck('heady-copilot', () => ({
  snippets: SNIPPETS.length,
  completionCacheSize: _completionCache.size,
  completionCacheMax: COMPLETION_CACHE_SIZE,
  activeDiagnosticTimers: _diagnosticTimers.size
}));



module.exports = {
  getCompletions,
  getDiagnostics,
  getDiagnosticsDebounced,
  getCodeActions,
  getHover,
  handleLSPRequest,
  health,
  SNIPPETS
};
