/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Colab Runtime Manager v2.0 — 4 Pro+ Runtimes
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Manages 4 Google Colab Pro+ runtimes as the latent space operations layer:
 * - Alpha: Embedding & Inference (φ-weighted largest GPU share)
 * - Beta:  Training & Fine-tuning
 * - Gamma: Vector Space Ops & Spatial Memory
 * - Delta: Monte Carlo Simulation & Batch Processing
 *
 * © 2026 HeadySystems Inc. — Eric Haywood
 */

'use strict';

const { PHI, PSI, PSI2, fib, CSL_THRESHOLDS, COLAB_RUNTIMES,
  phiBackoff, phiFusionWeights, cosineSimilarity, normalize } = require('../../shared/phi-math');
const { resonanceGate, routeGate } = require('../../shared/csl-engine');
const { createLogger } = require('../../shared/logger');
const logger = createLogger('colab-runtime-manager');

const RUNTIME_STATUS = Object.freeze({
  CONNECTED: 'connected',
  DISCONNECTED: 'disconnected',
  BUSY: 'busy',
  ERROR: 'error',
  WARMING: 'warming',
});

const MAX_RETRIES = fib(4);           // 3
const HEALTH_INTERVAL_MS = fib(9) * 1000; // 34s
const TASK_TIMEOUT_MS = fib(11) * 1000;   // 89s

class ColabRuntimeManager {
  constructor(opts = {}) {
    this._runtimes = new Map();
    this._taskQueue = [];
    this._maxQueueDepth = fib(13);    // 233
    this._healthTimer = null;
    this._stats = { dispatched: 0, completed: 0, failed: 0, retried: 0 };

    // Initialize all 4 runtimes
    for (const [key, config] of Object.entries(COLAB_RUNTIMES)) {
      const url = opts[config.envVar] || process.env[config.envVar] || null;
      this._runtimes.set(key, {
        ...config,
        key,
        url,
        status: url ? RUNTIME_STATUS.DISCONNECTED : RUNTIME_STATUS.DISCONNECTED,
        lastHealthCheck: null,
        lastError: null,
        taskCount: 0,
        totalLatencyMs: 0,
        avgLatencyMs: 0,
      });
    }

    logger.info({
      event: 'colab_manager_init',
      runtimes: Array.from(this._runtimes.keys()),
      configured: Array.from(this._runtimes.values()).filter(r => r.url).length,
    });
  }

  /**
   * Route a task to the best runtime using CSL scoring.
   */
  async dispatch(task) {
    const { type, payload, priority = CSL_THRESHOLDS.MEDIUM } = task;

    // Find matching runtimes by capability
    const candidates = [];
    for (const [key, runtime] of this._runtimes) {
      if (runtime.status === RUNTIME_STATUS.ERROR) continue;
      const hasCapability = runtime.capabilities.some(cap =>
        type.toLowerCase().includes(cap) || cap.includes(type.toLowerCase())
      );
      if (hasCapability) {
        candidates.push({
          id: key,
          runtime,
          score: hasCapability ? runtime.priority : 0,
          load: runtime.taskCount,
        });
      }
    }

    if (candidates.length === 0) {
      // Fallback: any available runtime
      for (const [key, runtime] of this._runtimes) {
        if (runtime.status !== RUNTIME_STATUS.ERROR && runtime.url) {
          candidates.push({ id: key, runtime, score: CSL_THRESHOLDS.LOW, load: runtime.taskCount });
        }
      }
    }

    if (candidates.length === 0) {
      throw new Error('No Colab runtimes available for task type: ' + type);
    }

    // CSL-scored selection: capability match * (1/load) * priority
    candidates.sort((a, b) => {
      const scoreA = a.score * (1 / (a.load + 1)) * resonanceGate(priority, CSL_THRESHOLDS.MEDIUM);
      const scoreB = b.score * (1 / (b.load + 1)) * resonanceGate(priority, CSL_THRESHOLDS.MEDIUM);
      return scoreB - scoreA;
    });

    const selected = candidates[0];
    selected.runtime.taskCount++;
    this._stats.dispatched++;

    logger.info({
      event: 'colab_dispatch',
      runtime: selected.id,
      taskType: type,
      priority,
    });

    try {
      const startTime = Date.now();
      const result = await this._executeOnRuntime(selected.runtime, task);
      const latency = Date.now() - startTime;

      selected.runtime.taskCount--;
      selected.runtime.totalLatencyMs += latency;
      selected.runtime.avgLatencyMs = selected.runtime.totalLatencyMs / (this._stats.completed + 1);
      this._stats.completed++;

      return { runtime: selected.id, result, latencyMs: latency };
    } catch (err) {
      selected.runtime.taskCount--;
      selected.runtime.lastError = err.message;
      this._stats.failed++;

      // Retry with phi-backoff
      for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
        const delay = phiBackoff(attempt);
        await new Promise(resolve => setTimeout(resolve, delay));
        this._stats.retried++;

        try {
          const result = await this._executeOnRuntime(selected.runtime, task);
          this._stats.completed++;
          return { runtime: selected.id, result, retried: attempt + 1 };
        } catch (retryErr) {
          logger.warn({ event: 'colab_retry', runtime: selected.id, attempt, error: retryErr.message });
        }
      }

      selected.runtime.status = RUNTIME_STATUS.ERROR;
      throw new Error('Colab runtime ' + selected.id + ' failed after ' + MAX_RETRIES + ' retries: ' + err.message);
    }
  }

  async _executeOnRuntime(runtime, task) {
    if (!runtime.url) throw new Error('Runtime ' + runtime.name + ' has no URL configured');

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), TASK_TIMEOUT_MS);

    try {
      const response = await fetch(runtime.url + '/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(task),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error('Runtime returned ' + response.status);
      }

      return response.json();
    } catch (err) {
      clearTimeout(timeoutId);
      throw err;
    }
  }

  startHealthChecks() {
    this._healthTimer = setInterval(() => this._checkAllHealth(), HEALTH_INTERVAL_MS);
    if (this._healthTimer.unref) this._healthTimer.unref();
    logger.info({ event: 'colab_health_checks_started', intervalMs: HEALTH_INTERVAL_MS });
    return this;
  }

  stopHealthChecks() {
    if (this._healthTimer) { clearInterval(this._healthTimer); this._healthTimer = null; }
    return this;
  }

  async _checkAllHealth() {
    for (const [key, runtime] of this._runtimes) {
      if (!runtime.url) continue;
      try {
        const response = await fetch(runtime.url + '/health', {
          signal: AbortSignal.timeout(fib(8) * 1000), // 21s timeout
        });
        runtime.status = response.ok ? RUNTIME_STATUS.CONNECTED : RUNTIME_STATUS.ERROR;
        runtime.lastHealthCheck = Date.now();
      } catch (err) {
        runtime.status = RUNTIME_STATUS.DISCONNECTED;
        runtime.lastError = err.message;
        runtime.lastHealthCheck = Date.now();
      }
    }
  }

  getStatus() {
    const runtimes = {};
    for (const [key, runtime] of this._runtimes) {
      runtimes[key] = {
        name: runtime.name,
        role: runtime.role,
        status: runtime.status,
        configured: !!runtime.url,
        taskCount: runtime.taskCount,
        avgLatencyMs: Math.round(runtime.avgLatencyMs),
        capabilities: runtime.capabilities,
        gpuAllocation: +(runtime.gpuAllocation * 100).toFixed(1) + '%',
      };
    }
    return { runtimes, stats: { ...this._stats } };
  }

  getRuntime(key) { return this._runtimes.get(key) || null; }
  getAllRuntimes() { return new Map(this._runtimes); }
}

module.exports = { ColabRuntimeManager, RUNTIME_STATUS, COLAB_RUNTIMES };
