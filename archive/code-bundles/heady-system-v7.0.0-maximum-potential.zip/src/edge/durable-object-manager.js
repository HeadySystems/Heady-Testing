/**
 * DurableObjectManager — Cloudflare Durable Objects Edge State Manager
 * 
 * Persistent agent state on Cloudflare's edge using Durable Objects with
 * hibernatable WebSockets, agent lifecycle state machine, edge-origin routing,
 * and Vectorize/pgvector sync.
 * 
 * Features:
 * - Agent lifecycle state machine (init → active → thinking → responding → idle → hibernating → expired)
 * - Hibernatable WebSocket sessions (zero cost when idle)
 * - SQLite-backed durable storage
 * - Edge-origin complexity-based routing
 * - Two-tier embedding cache (L1 in-memory LRU + L2 KV)
 * - Fibonacci-triggered conversation compression
 * - Vectorize ↔ pgvector bidirectional sync
 * 
 * @module durable-object-manager
 * @version 1.0.0
 * @author Eric Haywood
 */

const {
  PHI,
  PSI,
  PHI2,
  PHI3,
  fib,
  fibonacci,
  phiThreshold,
  phiFusionWeights,
  phiBackoff,
  CSL_THRESHOLDS,
  PRESSURE_LEVELS,
  SIZING,
  ALERT_THRESHOLDS,
  cslGate,
  cosineSimilarity,
  SERVICE_PORTS
} = require('../../shared/phi-math.js');
const { createLogger } = require('../../shared/logger.js');
const { createHealthCheck } = require('../../shared/health.js');

const logger = createLogger('durable-object-manager');

/* ═══════════════════════════════════════════════════════════════
   §1 — Constants (all phi-derived)
   ═══════════════════════════════════════════════════════════════ */

/** Agent lifecycle states */
const AGENT_STATES = {
  INIT: 'init',
  ACTIVE: 'active',
  THINKING: 'thinking',
  RESPONDING: 'responding',
  IDLE: 'idle',
  HIBERNATING: 'hibernating',
  EXPIRED: 'expired'
};

/** Valid state transitions */
const STATE_TRANSITIONS = {
  [AGENT_STATES.INIT]:         [AGENT_STATES.ACTIVE, AGENT_STATES.EXPIRED],
  [AGENT_STATES.ACTIVE]:       [AGENT_STATES.THINKING, AGENT_STATES.IDLE, AGENT_STATES.EXPIRED],
  [AGENT_STATES.THINKING]:     [AGENT_STATES.RESPONDING, AGENT_STATES.ACTIVE, AGENT_STATES.EXPIRED],
  [AGENT_STATES.RESPONDING]:   [AGENT_STATES.ACTIVE, AGENT_STATES.IDLE, AGENT_STATES.EXPIRED],
  [AGENT_STATES.IDLE]:         [AGENT_STATES.ACTIVE, AGENT_STATES.HIBERNATING, AGENT_STATES.EXPIRED],
  [AGENT_STATES.HIBERNATING]:  [AGENT_STATES.ACTIVE, AGENT_STATES.EXPIRED],
  [AGENT_STATES.EXPIRED]:      []
};

/** Fibonacci compression triggers — compress at these message counts */
const COMPRESSION_TRIGGERS = [fib(6), fib(7), fib(8), fib(9), fib(10), fib(11)];
// = [8, 13, 21, 34, 55, 89]

/** Edge-origin routing thresholds */
const ROUTING_THRESHOLDS = {
  EDGE_ONLY: Math.pow(PSI, 2),          // < 0.382 — simple lookups, embeddings
  EDGE_PREFERRED: PSI,                   // 0.382 - 0.618 — moderate queries
  ORIGIN_REQUIRED: PSI                   // > 0.618 — complex reasoning
};

/** Cache settings */
const L1_CACHE_SIZE = fib(16);           // 987 entries (in-memory LRU)
const L2_CACHE_TTL_S = fib(14);          // 377 seconds (KV)
const EVICTION_BATCH = fib(6);           // 8 entries per eviction
const IDLE_TIMEOUT_MS = fib(12) * 1000;  // 144 seconds before hibernation
const EXPIRE_TIMEOUT_MS = fib(17) * 1000; // 1597 seconds before expiration
const SYNC_BATCH_SIZE = fib(16);         // 987 vectors per sync batch
const ALARM_INTERVAL_MS = fib(11) * 1000; // 89 seconds

/** Resource allocation (Fibonacci ratios) */
const RESOURCE_ALLOCATION = {
  edge: 55,      // fib(10) — 55%
  origin: 34,    // fib(9) — 34%
  hybrid: 8,     // fib(6) — 8%
  reserved: 3    // fib(4) — 3%
};

/* ═══════════════════════════════════════════════════════════════
   §2 — Agent State Machine
   ═══════════════════════════════════════════════════════════════ */

class AgentStateMachine {
  constructor(agentId) {
    this._agentId = agentId;
    this._state = AGENT_STATES.INIT;
    this._stateHistory = [];
    this._messageCount = 0;
    this._lastActivity = Date.now();
    this._createdAt = Date.now();
    this._metadata = {};
    this._conversationBuffer = [];
    this._compressedHistory = [];
  }

  /**
   * Transition to a new state
   * @param {string} newState - Target state
   * @param {string} [reason] - Transition reason
   * @returns {boolean} Whether transition succeeded
   */
  transition(newState, reason = '') {
    const allowed = STATE_TRANSITIONS[this._state] || [];
    if (!allowed.includes(newState)) {
      logger.warn({
        event: 'invalid_transition',
        agentId: this._agentId,
        from: this._state,
        to: newState,
        allowed
      });
      return false;
    }

    const previousState = this._state;
    this._state = newState;
    this._lastActivity = Date.now();
    
    this._stateHistory.push({
      from: previousState,
      to: newState,
      reason,
      timestamp: Date.now()
    });

    // Keep history bounded at fib(11) = 89 entries
    if (this._stateHistory.length > fib(11)) {
      this._stateHistory = this._stateHistory.slice(-fib(11));
    }

    logger.info({
      event: 'state_transition',
      agentId: this._agentId,
      from: previousState,
      to: newState,
      reason,
      messageCount: this._messageCount
    });

    return true;
  }

  /**
   * Record a message and check for compression trigger
   * @param {object} message - Message to record
   * @returns {boolean} Whether compression was triggered
   */
  recordMessage(message) {
    this._messageCount++;
    this._lastActivity = Date.now();
    this._conversationBuffer.push({
      ...message,
      index: this._messageCount,
      timestamp: Date.now()
    });

    // Check Fibonacci compression triggers
    if (COMPRESSION_TRIGGERS.includes(this._messageCount)) {
      this._compress();
      return true;
    }

    return false;
  }

  /**
   * Compress conversation buffer
   */
  _compress() {
    if (this._conversationBuffer.length < fib(5)) return;

    // Keep last fib(5)=5 messages as-is, compress the rest
    const toCompress = this._conversationBuffer.slice(0, -fib(5));
    const kept = this._conversationBuffer.slice(-fib(5));

    // Create summary of compressed messages
    const summary = {
      messageRange: [toCompress[0]?.index, toCompress[toCompress.length - 1]?.index],
      count: toCompress.length,
      topics: _extractTopics(toCompress),
      compressedAt: Date.now()
    };

    this._compressedHistory.push(summary);
    this._conversationBuffer = kept;

    logger.info({
      event: 'conversation_compressed',
      agentId: this._agentId,
      compressed: toCompress.length,
      kept: kept.length,
      trigger: this._messageCount
    });
  }

  /**
   * Check if idle timeout has been reached
   * @returns {boolean} Whether agent should hibernate
   */
  shouldHibernate() {
    if (this._state !== AGENT_STATES.IDLE) return false;
    return Date.now() - this._lastActivity > IDLE_TIMEOUT_MS;
  }

  /**
   * Check if session should expire
   * @returns {boolean} Whether agent should expire
   */
  shouldExpire() {
    if (this._state === AGENT_STATES.EXPIRED) return false;
    return this._state === AGENT_STATES.HIBERNATING &&
           Date.now() - this._lastActivity > EXPIRE_TIMEOUT_MS;
  }

  /**
   * Get current state snapshot
   */
  getSnapshot() {
    return {
      agentId: this._agentId,
      state: this._state,
      messageCount: this._messageCount,
      lastActivity: this._lastActivity,
      createdAt: this._createdAt,
      conversationLength: this._conversationBuffer.length,
      compressedChunks: this._compressedHistory.length,
      stateHistoryLength: this._stateHistory.length,
      metadata: this._metadata
    };
  }

  /**
   * Serialize for SQLite storage
   */
  serialize() {
    return JSON.stringify({
      agentId: this._agentId,
      state: this._state,
      stateHistory: this._stateHistory,
      messageCount: this._messageCount,
      lastActivity: this._lastActivity,
      createdAt: this._createdAt,
      metadata: this._metadata,
      conversationBuffer: this._conversationBuffer,
      compressedHistory: this._compressedHistory
    });
  }

  /**
   * Deserialize from SQLite storage
   */
  static deserialize(json) {
    const data = JSON.parse(json);
    const agent = new AgentStateMachine(data.agentId);
    agent._state = data.state;
    agent._stateHistory = data.stateHistory || [];
    agent._messageCount = data.messageCount || 0;
    agent._lastActivity = data.lastActivity || Date.now();
    agent._createdAt = data.createdAt || Date.now();
    agent._metadata = data.metadata || {};
    agent._conversationBuffer = data.conversationBuffer || [];
    agent._compressedHistory = data.compressedHistory || [];
    return agent;
  }
}

/* ═══════════════════════════════════════════════════════════════
   §3 — Edge-Origin Router
   ═══════════════════════════════════════════════════════════════ */

/**
 * Route a request to edge or origin based on complexity scoring
 * @param {object} request - Incoming request
 * @returns {object} Routing decision
 */
function routeRequest(request) {
  const { type, tokenCount = 0, toolCalls = 0, contextLength = 0, requiresReasoning = false } = request;

  // Fibonacci-weighted complexity factors
  const factors = [
    { name: 'tokenCount', value: Math.min(1, tokenCount / fib(12)), weight: fib(5) },    // 5
    { name: 'toolCalls', value: Math.min(1, toolCalls / fib(6)), weight: fib(6) },         // 8
    { name: 'contextLength', value: Math.min(1, contextLength / fib(16)), weight: fib(7) }, // 13
    { name: 'reasoning', value: requiresReasoning ? 1 : 0, weight: fib(8) }                // 21
  ];

  const totalWeight = factors.reduce((sum, f) => sum + f.weight, 0);
  const complexityScore = factors.reduce((sum, f) => sum + (f.value * f.weight), 0) / totalWeight;

  let target;
  let model;

  if (complexityScore < ROUTING_THRESHOLDS.EDGE_ONLY) {
    target = 'edge';
    model = 'workers-ai'; // llama-3.1-8b, bge-base
  } else if (complexityScore < ROUTING_THRESHOLDS.ORIGIN_REQUIRED) {
    target = 'edge-preferred';
    model = 'workers-ai'; // Try edge first, fallback to origin
  } else {
    target = 'origin';
    model = 'origin-llm'; // Claude, GPT-4o, Gemini on Cloud Run
  }

  const decision = {
    target,
    model,
    complexityScore,
    factors: factors.map(f => ({ name: f.name, value: f.value.toFixed(3), weight: f.weight })),
    fallbackTarget: target === 'edge' ? 'origin' : null,
    allocation: RESOURCE_ALLOCATION[target === 'edge-preferred' ? 'edge' : target === 'origin' ? 'origin' : 'edge']
  };

  logger.info({
    event: 'route_decision',
    target: decision.target,
    complexityScore: complexityScore.toFixed(3),
    model: decision.model
  });

  return decision;
}

/* ═══════════════════════════════════════════════════════════════
   §4 — Durable Object (Cloudflare DO pattern)
   ═══════════════════════════════════════════════════════════════ */

/**
 * DurableAgentState — Cloudflare Durable Object class
 * Manages persistent agent state with hibernatable WebSockets
 */
class DurableAgentState {
  constructor() {
    this._agent = null;
    this._storage = null;
    this._webSockets = new Set();
    this._alarmScheduled = false;
  }

  /**
   * Initialize the Durable Object
   * @param {object} state - DO state (ctx in production)
   * @param {object} env - Environment bindings
   */
  async initialize(state, env) {
    this._storage = state.storage || new InMemoryStorage();

    // Restore agent state
    const stored = await this._storage.get('agent');
    if (stored) {
      this._agent = AgentStateMachine.deserialize(stored);
      logger.info({ event: 'agent_restored', agentId: this._agent._agentId, state: this._agent._state });
    }
  }

  /**
   * Handle HTTP request (used for initial connection and REST API)
   * @param {object} request - HTTP request
   * @returns {object} HTTP response
   */
  async handleRequest(request) {
    const url = new URL(request.url || 'http://localhost');
    const path = url.pathname;

    // WebSocket upgrade
    if (request.headers?.get?.('Upgrade') === 'websocket' || request.upgrade === 'websocket') {
      return this._handleWebSocketUpgrade(request);
    }

    // REST API
    switch (path) {
      case '/state':
        return _jsonResponse(this._agent?.getSnapshot() || { error: 'No agent' });

      case '/create': {
        const body = request.body || {};
        const agentId = body.agentId || `agent_${Date.now().toString(36)}`;
        this._agent = new AgentStateMachine(agentId);
        this._agent.transition(AGENT_STATES.ACTIVE, 'created');
        await this._persist();
        await this._scheduleAlarm();
        return _jsonResponse({ created: true, agentId, state: this._agent._state });
      }

      case '/message': {
        if (!this._agent) return _jsonResponse({ error: 'No agent' }, 404);
        const msg = request.body || {};
        
        this._agent.transition(AGENT_STATES.ACTIVE, 'message_received');
        const compressed = this._agent.recordMessage(msg);
        this._agent.transition(AGENT_STATES.THINKING, 'processing');

        // Route to edge or origin
        const routing = routeRequest({
          type: msg.type,
          tokenCount: msg.text?.length || 0,
          toolCalls: msg.toolCalls?.length || 0,
          contextLength: this._agent._conversationBuffer.length,
          requiresReasoning: msg.requiresReasoning || false
        });

        this._agent.transition(AGENT_STATES.RESPONDING, 'routing_complete');

        // Broadcast to WebSocket clients
        this._broadcast({
          type: 'agent_state',
          state: this._agent._state,
          routing: routing.target
        });

        await this._persist();
        return _jsonResponse({ processed: true, routing, compressed, state: this._agent.getSnapshot() });
      }

      case '/route': {
        const routeReq = request.body || {};
        const decision = routeRequest(routeReq);
        return _jsonResponse(decision);
      }

      default:
        return _jsonResponse({ error: 'Not found' }, 404);
    }
  }

  /**
   * Handle WebSocket upgrade for hibernatable connections
   */
  _handleWebSocketUpgrade(request) {
    const pair = { server: { send: () => {}, close: () => {}, readyState: 1 }, client: {} };
    // In Cloudflare runtime: const pair = new WebSocketPair();

    const ws = pair.server;
    this._webSockets.add(ws);

    // Send current state
    _wsSend(ws, {
      type: 'connected',
      state: this._agent?.getSnapshot() || null,
      timestamp: Date.now()
    });

    logger.info({ event: 'ws_connected', clients: this._webSockets.size });

    return {
      status: 101,
      webSocket: pair.client,
      headers: { 'Sec-WebSocket-Protocol': 'heady-agent' }
    };
  }

  /**
   * Handle WebSocket message (hibernation-compatible)
   */
  async webSocketMessage(ws, message) {
    try {
      const data = typeof message === 'string' ? JSON.parse(message) : message;
      
      // Wake from hibernation
      if (this._agent?._state === AGENT_STATES.HIBERNATING) {
        this._agent.transition(AGENT_STATES.ACTIVE, 'ws_message_wake');
      }

      switch (data.type) {
        case 'ping':
          _wsSend(ws, { type: 'pong', timestamp: Date.now() });
          break;
        case 'message':
          const result = await this.handleRequest({ url: 'http://localhost/message', body: data });
          _wsSend(ws, result);
          break;
        case 'state':
          _wsSend(ws, { type: 'state', state: this._agent?.getSnapshot() });
          break;
        default:
          _wsSend(ws, { type: 'error', message: `Unknown message type: ${data.type}` });
      }
    } catch (err) {
      logger.error({ event: 'ws_message_error', error: err.message });
      _wsSend(ws, { type: 'error', message: err.message });
    }
  }

  /**
   * Handle WebSocket close
   */
  async webSocketClose(ws, code, reason) {
    this._webSockets.delete(ws);
    logger.info({ event: 'ws_closed', code, reason, remaining: this._webSockets.size });

    if (this._webSockets.size === 0 && this._agent) {
      this._agent.transition(AGENT_STATES.IDLE, 'all_clients_disconnected');
      await this._persist();
    }
  }

  /**
   * Alarm handler — runs periodic maintenance
   */
  async alarm() {
    if (!this._agent) return;

    // Check hibernation
    if (this._agent.shouldHibernate()) {
      this._agent.transition(AGENT_STATES.HIBERNATING, 'idle_timeout');
      await this._persist();
      logger.info({ event: 'agent_hibernated', agentId: this._agent._agentId });
      return; // Don't reschedule — zero cost when hibernated
    }

    // Check expiration
    if (this._agent.shouldExpire()) {
      this._agent.transition(AGENT_STATES.EXPIRED, 'session_expired');
      await this._persist();
      logger.info({ event: 'agent_expired', agentId: this._agent._agentId });
      return;
    }

    // Reschedule alarm
    await this._scheduleAlarm();
  }

  /* ── Internal helpers ── */

  async _persist() {
    if (this._agent && this._storage) {
      await this._storage.put('agent', this._agent.serialize());
    }
  }

  async _scheduleAlarm() {
    if (this._storage?.setAlarm) {
      await this._storage.setAlarm(Date.now() + ALARM_INTERVAL_MS);
      this._alarmScheduled = true;
    }
  }

  _broadcast(data) {
    const msg = JSON.stringify(data);
    for (const ws of this._webSockets) {
      try {
        if (ws.readyState === 1) ws.send(msg);
      } catch (_) {
        this._webSockets.delete(ws);
      }
    }
  }
}

/* ═══════════════════════════════════════════════════════════════
   §5 — Embedding Cache (Two-Tier: L1 LRU + L2 KV)
   ═══════════════════════════════════════════════════════════════ */

class EdgeEmbeddingCache {
  constructor() {
    this._l1 = new Map();        // In-memory LRU
    this._l1Order = [];          // LRU order
    this._stats = { l1Hits: 0, l2Hits: 0, misses: 0, evictions: 0 };
  }

  /**
   * Get embedding from cache
   * @param {string} key - Content hash key
   * @param {object} [kvNamespace] - Cloudflare KV namespace for L2
   * @returns {Float32Array|null} Cached embedding or null
   */
  async get(key, kvNamespace = null) {
    // L1: in-memory
    if (this._l1.has(key)) {
      this._stats.l1Hits++;
      this._touchL1(key);
      return this._l1.get(key);
    }

    // L2: KV store
    if (kvNamespace) {
      try {
        const stored = await kvNamespace.get(key, 'arrayBuffer');
        if (stored) {
          this._stats.l2Hits++;
          const embedding = new Float32Array(stored);
          this._setL1(key, embedding);
          return embedding;
        }
      } catch (err) {
        logger.warn({ event: 'l2_cache_error', error: err.message });
      }
    }

    this._stats.misses++;
    return null;
  }

  /**
   * Store embedding in cache
   * @param {string} key - Content hash key
   * @param {Float32Array} embedding - Embedding vector
   * @param {object} [kvNamespace] - Cloudflare KV namespace for L2
   */
  async set(key, embedding, kvNamespace = null) {
    this._setL1(key, embedding);

    // L2: KV store
    if (kvNamespace) {
      try {
        await kvNamespace.put(key, embedding.buffer, { expirationTtl: L2_CACHE_TTL_S });
      } catch (err) {
        logger.warn({ event: 'l2_cache_write_error', error: err.message });
      }
    }
  }

  _setL1(key, value) {
    if (this._l1.size >= L1_CACHE_SIZE) {
      this._evictL1();
    }
    this._l1.set(key, value);
    this._l1Order.push(key);
  }

  _touchL1(key) {
    const idx = this._l1Order.indexOf(key);
    if (idx >= 0) {
      this._l1Order.splice(idx, 1);
      this._l1Order.push(key);
    }
  }

  _evictL1() {
    const batch = Math.min(EVICTION_BATCH, this._l1Order.length);
    for (let i = 0; i < batch; i++) {
      const key = this._l1Order.shift();
      this._l1.delete(key);
      this._stats.evictions++;
    }
  }

  getStats() {
    const total = this._stats.l1Hits + this._stats.l2Hits + this._stats.misses;
    return {
      ...this._stats,
      l1Size: this._l1.size,
      l1Max: L1_CACHE_SIZE,
      hitRate: total > 0 ? ((this._stats.l1Hits + this._stats.l2Hits) / total).toFixed(3) : '0.000'
    };
  }
}

/* ═══════════════════════════════════════════════════════════════
   §6 — Vectorize ↔ pgvector Sync
   ═══════════════════════════════════════════════════════════════ */

class VectorSync {
  constructor() {
    this._syncState = {
      lastSyncTimestamp: 0,
      pendingUpserts: [],
      pendingDeletes: [],
      syncInProgress: false,
      syncCount: 0,
      errorCount: 0
    };
  }

  /**
   * Sync vectors from edge Vectorize to origin pgvector
   * @param {object} vectorize - Cloudflare Vectorize index
   * @param {object} pgClient - pgvector database client
   * @param {object} [options] - Sync options
   * @returns {object} Sync results
   */
  async syncToOrigin(vectorize, pgClient, options = {}) {
    if (this._syncState.syncInProgress) {
      return { skipped: true, reason: 'sync_in_progress' };
    }

    this._syncState.syncInProgress = true;
    const { batchSize = SYNC_BATCH_SIZE } = options;
    let synced = 0;
    let errors = 0;

    try {
      // Process pending upserts
      const batches = _chunk(this._syncState.pendingUpserts, batchSize);
      for (const batch of batches) {
        try {
          // Write to pgvector (origin is source of truth)
          for (const vector of batch) {
            await pgClient.upsert(vector);
          }
          synced += batch.length;
        } catch (err) {
          errors += batch.length;
          logger.error({ event: 'sync_batch_error', error: err.message, batchSize: batch.length });
          // Phi-backoff on failure
          await new Promise(r => setTimeout(r, phiBackoff(errors)));
        }
      }

      // Process pending deletes
      for (const id of this._syncState.pendingDeletes) {
        try {
          await pgClient.delete(id);
          synced++;
        } catch (err) {
          errors++;
        }
      }

      // Clear processed items
      this._syncState.pendingUpserts = [];
      this._syncState.pendingDeletes = [];
      this._syncState.lastSyncTimestamp = Date.now();
      this._syncState.syncCount++;
      this._syncState.errorCount += errors;

      logger.info({ event: 'sync_complete', synced, errors, direction: 'edge_to_origin' });
    } finally {
      this._syncState.syncInProgress = false;
    }

    return { synced, errors, timestamp: Date.now() };
  }

  /**
   * Queue a vector for sync
   * @param {object} vector - Vector to sync
   */
  queueUpsert(vector) {
    this._syncState.pendingUpserts.push(vector);
    
    // Auto-trigger sync at batch threshold
    if (this._syncState.pendingUpserts.length >= SYNC_BATCH_SIZE) {
      logger.info({ event: 'sync_threshold_reached', pending: this._syncState.pendingUpserts.length });
    }
  }

  /**
   * Queue a deletion for sync
   * @param {string} id - Vector ID to delete
   */
  queueDelete(id) {
    this._syncState.pendingDeletes.push(id);
  }

  getSyncState() {
    return {
      ...this._syncState,
      pendingUpserts: this._syncState.pendingUpserts.length,
      pendingDeletes: this._syncState.pendingDeletes.length
    };
  }
}

/* ═══════════════════════════════════════════════════════════════
   §7 — In-Memory Storage (for local/testing)
   ═══════════════════════════════════════════════════════════════ */

class InMemoryStorage {
  constructor() {
    this._data = new Map();
    this._alarm = null;
  }

  async get(key) { return this._data.get(key) || null; }
  async put(key, value) { this._data.set(key, value); }
  async delete(key) { this._data.delete(key); }
  async list(options = {}) { return new Map([...this._data]); }
  async setAlarm(ms) { this._alarm = ms; }
  async getAlarm() { return this._alarm; }
  async deleteAlarm() { this._alarm = null; }
}

/* ═══════════════════════════════════════════════════════════════
   §8 — Utility Functions
   ═══════════════════════════════════════════════════════════════ */

function _extractTopics(messages) {
  const wordFreq = new Map();
  for (const msg of messages) {
    const text = (msg.text || msg.content || '').toLowerCase();
    const words = text.split(/\s+/).filter(w => w.length > 3);
    for (const word of words) {
      wordFreq.set(word, (wordFreq.get(word) || 0) + 1);
    }
  }
  return [...wordFreq.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, fib(5))
    .map(([word]) => word);
}

function _jsonResponse(data, status = 200) {
  return {
    status,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  };
}

function _wsSend(ws, data) {
  try {
    if (ws.readyState === 1) ws.send(JSON.stringify(data));
  } catch (_) { /* ignore send errors */ }
}

function _chunk(arr, size) {
  const chunks = [];
  for (let i = 0; i < arr.length; i += size) {
    chunks.push(arr.slice(i, i + size));
  }
  return chunks;
}

/* ═══════════════════════════════════════════════════════════════
   §9 — Health & Export
   ═══════════════════════════════════════════════════════════════ */

const health = createHealthCheck('durable-object-manager', () => ({
  agentStates: Object.keys(AGENT_STATES).length,
  compressionTriggers: COMPRESSION_TRIGGERS,
  routingThresholds: ROUTING_THRESHOLDS,
  l1CacheMax: L1_CACHE_SIZE,
  syncBatchSize: SYNC_BATCH_SIZE,
  resourceAllocation: RESOURCE_ALLOCATION
}));



module.exports = {
  DurableAgentState,
  AgentStateMachine,
  EdgeEmbeddingCache,
  VectorSync,
  InMemoryStorage,
  routeRequest,
  health,
  AGENT_STATES,
  STATE_TRANSITIONS,
  COMPRESSION_TRIGGERS,
  ROUTING_THRESHOLDS,
  RESOURCE_ALLOCATION
};
