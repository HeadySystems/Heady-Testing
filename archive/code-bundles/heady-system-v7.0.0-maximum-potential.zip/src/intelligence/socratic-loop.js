/**
 * Socratic Loop — Pre-Commit Reasoning Validator
 * 
 * The philosophical guardian of the Heady codebase. Before any code projection
 * from latent space to physical repos, the Socratic Loop validates that the
 * change satisfies the 3 Unbreakable Laws through dialectical reasoning.
 * 
 * 3 Unbreakable Laws:
 * 1. Structural Integrity — code compiles, passes types, respects module boundaries
 * 2. Semantic Coherence — change embedding stays within tolerance of intended design
 * 3. Mission Alignment — change serves HeadyConnection mission (community, equity, empowerment)
 * 
 * Process:
 * 1. THESIS — What does this change claim to do?
 * 2. ANTITHESIS — What could go wrong? What are the counter-arguments?
 * 3. SYNTHESIS — Does the change survive scrutiny? Does it satisfy all 3 Laws?
 * 
 * @module SocraticLoop
 * @author Eric Haywood
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { PHI, PSI, PSI_SQ, fibonacci, phiThreshold, phiFusionWeights,
  CSL_THRESHOLDS } = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');

const logger = createLogger('socratic-loop');

// ─── Constants ──────────────────────────────────────────────────────────────
const MAX_REASONING_DEPTH = fibonacci(5);     // 5 levels of dialectical depth
const MAX_OBJECTIONS = fibonacci(7);           // 13 objections per validation
const VALIDATION_TIMEOUT = fibonacci(10) * 1000; // 55 seconds
const COHERENCE_THRESHOLD = CSL_THRESHOLDS.MEDIUM; // 0.809 — minimum for passage

// Validation dimensions
const VALIDATION_DIMENSIONS = {
  STRUCTURAL_INTEGRITY: {
    name: 'Structural Integrity',
    description: 'Code compiles, passes type checks, respects module boundaries',
    weight: phiFusionWeights(3)[0],  // 0.528
    checks: [
      'module_boundaries',
      'import_resolution',
      'type_safety',
      'syntax_validity',
      'dependency_graph'
    ]
  },
  SEMANTIC_COHERENCE: {
    name: 'Semantic Coherence',
    description: 'Change embedding stays within tolerance of intended design',
    weight: phiFusionWeights(3)[1],  // 0.326
    checks: [
      'embedding_drift',
      'naming_consistency',
      'pattern_adherence',
      'api_contract',
      'behavior_preservation'
    ]
  },
  MISSION_ALIGNMENT: {
    name: 'Mission Alignment',
    description: 'Change serves HeadyConnection mission: community, equity, empowerment',
    weight: phiFusionWeights(3)[2],  // 0.146
    checks: [
      'accessibility',
      'privacy_preservation',
      'equitable_access',
      'community_benefit',
      'no_harm'
    ]
  }
};

// Reasoning stages
const STAGE = {
  THESIS:     'thesis',
  ANTITHESIS: 'antithesis',
  SYNTHESIS:  'synthesis'
};

/**
 * Validation Result — outcome of a Socratic validation
 */
class ValidationResult {
  constructor() {
    this.id = crypto.randomUUID();
    this.timestamp = Date.now();
    this.passed = false;
    this.overallScore = 0;
    this.dimensions = {};
    this.thesis = null;
    this.antithesis = { objections: [] };
    this.synthesis = null;
    this.reasoning = [];
    this.duration = null;
  }

  toJSON() {
    return {
      id: this.id,
      timestamp: this.timestamp,
      passed: this.passed,
      overallScore: Math.round(this.overallScore * 1000) / 1000,
      dimensions: this.dimensions,
      thesis: this.thesis,
      objections: this.antithesis.objections.length,
      synthesis: this.synthesis,
      reasoningDepth: this.reasoning.length,
      duration: this.duration
    };
  }
}

/**
 * Objection — a counter-argument raised during antithesis
 */
class Objection {
  constructor({ dimension, check, description, severity = 'medium', resolution = null }) {
    this.id = crypto.randomUUID();
    this.dimension = dimension;
    this.check = check;
    this.description = description;
    this.severity = severity;    // low | medium | high | blocking
    this.resolution = resolution;
    this.resolved = false;
  }
}

/**
 * SocraticLoop — Dialectical Reasoning Validator
 */
class SocraticLoop {
  constructor(config = {}) {
    this.embeddingFn = config.embeddingFn || null;
    this.soul = config.soul || null;           // HeadySoul reference
    this.history = [];                          // Validation history
    this.stats = {
      totalValidations: 0,
      passed: 0,
      failed: 0,
      averageScore: 0,
      commonObjections: {}
    };

    logger.info({ msg: 'SocraticLoop initialized' });
  }

  /**
   * Validate a proposed change through the Socratic dialectic
   * 
   * @param {Object} proposal - The change to validate
   * @param {string} proposal.description - What the change does
   * @param {Array} proposal.files - Files being changed [{path, before, after}]
   * @param {string} proposal.rationale - Why the change is being made
   * @param {Object} proposal.context - Additional context
   * @returns {ValidationResult} - The validation outcome
   */
  async validate(proposal) {
    const startTime = Date.now();
    const result = new ValidationResult();

    logger.info({
      validationId: result.id,
      description: proposal.description?.substring(0, fibonacci(11)),
      fileCount: proposal.files?.length || 0,
      msg: 'Socratic validation started'
    });

    try {
      // ─── THESIS: What does this change claim? ───────────────────────
      result.thesis = await this._thesis(proposal);

      // ─── ANTITHESIS: What could go wrong? ───────────────────────────
      result.antithesis = await this._antithesis(proposal, result.thesis);

      // ─── SYNTHESIS: Does it survive scrutiny? ───────────────────────
      result.synthesis = await this._synthesis(result.thesis, result.antithesis);

      // ─── Score each dimension ───────────────────────────────────────
      for (const [dimKey, dim] of Object.entries(VALIDATION_DIMENSIONS)) {
        const dimScore = this._scoreDimension(dimKey, result);
        result.dimensions[dimKey] = {
          name: dim.name,
          score: Math.round(dimScore * 1000) / 1000,
          weight: dim.weight,
          passed: dimScore >= COHERENCE_THRESHOLD
        };
      }

      // ─── Overall score (phi-weighted) ───────────────────────────────
      result.overallScore = Object.entries(result.dimensions).reduce((score, [key, dim]) => {
        return score + dim.score * VALIDATION_DIMENSIONS[key].weight;
      }, 0);

      result.passed = result.overallScore >= COHERENCE_THRESHOLD &&
        Object.values(result.dimensions).every(d => d.score >= CSL_THRESHOLDS.LOW);

      // Check for blocking objections
      const blocking = result.antithesis.objections.filter(o => o.severity === 'blocking' && !o.resolved);
      if (blocking.length > 0) {
        result.passed = false;
        result.reasoning.push({
          stage: STAGE.SYNTHESIS,
          depth: MAX_REASONING_DEPTH,
          conclusion: `Blocked by ${blocking.length} unresolved blocking objections`
        });
      }

    } catch (err) {
      result.passed = false;
      result.overallScore = 0;
      result.reasoning.push({
        stage: 'error',
        depth: 0,
        conclusion: `Validation error: ${err.message}`
      });
      logger.error({ validationId: result.id, err: err.message, msg: 'Validation error' });
    }

    result.duration = Date.now() - startTime;

    // Update stats
    this.stats.totalValidations++;
    if (result.passed) this.stats.passed++;
    else this.stats.failed++;
    this.stats.averageScore =
      (this.stats.averageScore * (this.stats.totalValidations - 1) + result.overallScore) /
      this.stats.totalValidations;

    // Store in history
    this.history.push(result);
    if (this.history.length > fibonacci(8)) {
      this.history.shift();
    }

    logger.info({
      validationId: result.id,
      passed: result.passed,
      score: Math.round(result.overallScore * 1000) / 1000,
      objections: result.antithesis.objections.length,
      blocking: result.antithesis.objections.filter(o => o.severity === 'blocking').length,
      duration: result.duration,
      msg: 'Socratic validation complete'
    });

    return result;
  }

  // ─── THESIS ─────────────────────────────────────────────────────────

  async _thesis(proposal) {
    const thesis = {
      claim: proposal.description || 'Unnamed change',
      rationale: proposal.rationale || 'No rationale provided',
      scope: {
        filesChanged: proposal.files?.length || 0,
        filePaths: (proposal.files || []).map(f => f.path),
        estimatedImpact: this._estimateImpact(proposal)
      },
      assumptions: this._identifyAssumptions(proposal)
    };

    this._addReasoning(STAGE.THESIS, 1, `Thesis established: "${thesis.claim}"`);
    return thesis;
  }

  _estimateImpact(proposal) {
    const files = proposal.files || [];
    if (files.length === 0) return 'none';
    if (files.length <= fibonacci(3)) return 'minimal';     // ≤ 2
    if (files.length <= fibonacci(5)) return 'moderate';     // ≤ 5
    if (files.length <= fibonacci(7)) return 'significant';  // ≤ 13
    return 'extensive';
  }

  _identifyAssumptions(proposal) {
    const assumptions = [];
    const files = proposal.files || [];

    // Check for common assumptions
    if (files.some(f => f.path?.includes('shared/'))) {
      assumptions.push('Shared modules are modified — all consumers must be compatible');
    }
    if (files.some(f => f.path?.includes('migration'))) {
      assumptions.push('Database migration — assumes backwards-compatible schema change');
    }
    if (files.some(f => f.path?.includes('security') || f.path?.includes('auth'))) {
      assumptions.push('Security-sensitive change — requires extra scrutiny');
    }
    if (files.some(f => f.path?.includes('package.json'))) {
      assumptions.push('Dependency change — supply chain risk must be assessed');
    }

    return assumptions;
  }

  // ─── ANTITHESIS ─────────────────────────────────────────────────────

  async _antithesis(proposal, thesis) {
    const antithesis = { objections: [] };
    const files = proposal.files || [];

    // Structural Integrity checks
    for (const file of files) {
      // Check: module boundaries
      if (file.after && file.path) {
        const isShared = file.path.includes('shared/');
        const importPattern = /require\(['"]\.\.\/\.\.\//g;
        const matches = (file.after.match(importPattern) || []).length;
        if (isShared && matches > fibonacci(5)) {
          antithesis.objections.push(new Objection({
            dimension: 'STRUCTURAL_INTEGRITY',
            check: 'module_boundaries',
            description: `Shared module ${file.path} has ${matches} deep relative imports`,
            severity: 'medium'
          }));
        }

        // Check: no console.log
        if (/console\.(log|warn|error|info)/.test(file.after)) {
          antithesis.objections.push(new Objection({
            dimension: 'STRUCTURAL_INTEGRITY',
            check: 'logging_standard',
            description: `File ${file.path} contains console.log — must use structured logger`,
            severity: 'high'
          }));
        }

        // Check: no localStorage
        if (/localStorage|sessionStorage/.test(file.after)) {
          antithesis.objections.push(new Objection({
            dimension: 'STRUCTURAL_INTEGRITY',
            check: 'storage_standard',
            description: `File ${file.path} uses localStorage — must use httpOnly cookies`,
            severity: 'blocking'
          }));
        }

        // Check: no hardcoded secrets
        if (/['"]sk[-_]|['"]pk[-_]|password\s*=\s*['"]/.test(file.after)) {
          antithesis.objections.push(new Objection({
            dimension: 'STRUCTURAL_INTEGRITY',
            check: 'secret_detection',
            description: `File ${file.path} may contain hardcoded secrets`,
            severity: 'blocking'
          }));
        }

        // Check: no magic numbers (non-phi, non-fib)
        const magicPattern = /\b(?:100|200|500|1000|5000|10000)\b/g;
        const magicMatches = file.after.match(magicPattern);
        if (magicMatches && magicMatches.length > fibonacci(5)) {
          antithesis.objections.push(new Objection({
            dimension: 'STRUCTURAL_INTEGRITY',
            check: 'magic_numbers',
            description: `File ${file.path} has ${magicMatches.length} potential magic numbers — should use phi-derived constants`,
            severity: 'medium'
          }));
        }
      }
    }

    // Semantic Coherence checks
    if (thesis.scope.estimatedImpact === 'extensive') {
      antithesis.objections.push(new Objection({
        dimension: 'SEMANTIC_COHERENCE',
        check: 'scope_creep',
        description: 'Extensive change scope — high risk of semantic drift from original design intent',
        severity: 'medium'
      }));
    }

    // Check naming consistency
    for (const file of files) {
      if (file.after && /Eric Head(?!y)/.test(file.after)) {
        antithesis.objections.push(new Objection({
          dimension: 'SEMANTIC_COHERENCE',
          check: 'naming_consistency',
          description: `File ${file.path} contains "Eric Head" — should be "Eric Haywood"`,
          severity: 'high'
        }));
      }
    }

    // Mission Alignment checks
    for (const file of files) {
      if (file.after) {
        // Check: no discriminatory patterns
        if (/whitelist|blacklist|master(?:\/|branch)|slave/i.test(file.after)) {
          antithesis.objections.push(new Objection({
            dimension: 'MISSION_ALIGNMENT',
            check: 'inclusive_language',
            description: `File ${file.path} uses non-inclusive terminology`,
            severity: 'medium'
          }));
        }

        // Check: accessibility considerations for UI code
        if (file.path?.includes('website') || file.path?.includes('ui')) {
          if (!file.after.includes('aria-') && file.after.includes('<button') && file.after.includes('<div')) {
            antithesis.objections.push(new Objection({
              dimension: 'MISSION_ALIGNMENT',
              check: 'accessibility',
              description: `File ${file.path} may lack ARIA attributes for accessibility`,
              severity: 'medium'
            }));
          }
        }
      }
    }

    // Limit objections
    if (antithesis.objections.length > MAX_OBJECTIONS) {
      antithesis.objections = antithesis.objections
        .sort((a, b) => {
          const severityOrder = { blocking: 3, high: 2, medium: 1, low: 0 };
          return severityOrder[b.severity] - severityOrder[a.severity];
        })
        .slice(0, MAX_OBJECTIONS);
    }

    this._addReasoning(STAGE.ANTITHESIS, 2,
      `${antithesis.objections.length} objections raised (${antithesis.objections.filter(o => o.severity === 'blocking').length} blocking)`
    );

    return antithesis;
  }

  // ─── SYNTHESIS ──────────────────────────────────────────────────────

  async _synthesis(thesis, antithesis) {
    const blocking = antithesis.objections.filter(o => o.severity === 'blocking');
    const high = antithesis.objections.filter(o => o.severity === 'high');
    const medium = antithesis.objections.filter(o => o.severity === 'medium');

    const synthesis = {
      verdict: 'pending',
      rationale: '',
      recommendations: [],
      requiredFixes: blocking.map(o => o.description),
      advisoryFixes: high.map(o => o.description),
      suggestions: medium.map(o => o.description)
    };

    if (blocking.length > 0) {
      synthesis.verdict = 'rejected';
      synthesis.rationale = `${blocking.length} blocking issues must be resolved before this change can proceed.`;
    } else if (high.length > fibonacci(3)) {
      synthesis.verdict = 'needs_revision';
      synthesis.rationale = `${high.length} high-severity issues should be addressed. Change can proceed but quality is at risk.`;
    } else if (antithesis.objections.length === 0) {
      synthesis.verdict = 'approved';
      synthesis.rationale = 'Change passes all Socratic checks with no objections.';
    } else {
      synthesis.verdict = 'approved_with_notes';
      synthesis.rationale = `Change approved with ${antithesis.objections.length} advisory notes.`;
    }

    this._addReasoning(STAGE.SYNTHESIS, 3,
      `Synthesis: ${synthesis.verdict} — ${synthesis.rationale}`
    );

    return synthesis;
  }

  // ─── Scoring ────────────────────────────────────────────────────────

  _scoreDimension(dimensionKey, result) {
    const objections = result.antithesis.objections.filter(o => o.dimension === dimensionKey);
    if (objections.length === 0) return 1.0;

    // Deduct based on severity
    const deductions = {
      blocking: 1.0 - CSL_THRESHOLDS.MINIMUM,  // 0.5 deduction
      high:     1.0 - CSL_THRESHOLDS.HIGH,      // 0.118 deduction
      medium:   1.0 - CSL_THRESHOLDS.CRITICAL,  // 0.073 deduction
      low:      1.0 - phiThreshold(5)            // ~0.045 deduction
    };

    let score = 1.0;
    for (const obj of objections) {
      if (!obj.resolved) {
        score -= deductions[obj.severity] || 0.05;
      }
    }

    return Math.max(0, Math.min(1, score));
  }

  _addReasoning(stage, depth, conclusion) {
    this._reasoning = this._reasoning || [];
    this._reasoning.push({ stage, depth, conclusion, timestamp: Date.now() });
  }

  // ─── Health & Stats ───────────────────────────────────────────────

  health() {
    return {
      status: 'healthy',
      service: 'socratic-loop',
      stats: { ...this.stats },
      historySize: this.history.length,
      dimensions: Object.keys(VALIDATION_DIMENSIONS)
    };
  }

  getHistory() {
    return this.history.map(r => r.toJSON());
  }

  shutdown() {
    logger.info({
      totalValidations: this.stats.totalValidations,
      passRate: this.stats.totalValidations > 0
        ? `${Math.round((this.stats.passed / this.stats.totalValidations) * 100)}%`
        : 'N/A',
      msg: 'SocraticLoop shutting down'
    });
  }
}

module.exports = {
  SocraticLoop,
  ValidationResult,
  Objection,
  VALIDATION_DIMENSIONS,
  STAGE,
  COHERENCE_THRESHOLD
};
