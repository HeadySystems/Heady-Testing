/**
 * HeadyVinci — Session Planner & Topology Maintainer
 * 
 * The "architect" intelligence that plans multi-step sessions,
 * maintains the global system topology, and coordinates complex
 * workflows across nodes. HeadyVinci decomposes high-level goals
 * into executable task DAGs and manages their lifecycle.
 * 
 * Features:
 * - Multi-step session planning with dependency DAGs
 * - Topological sort with cycle detection
 * - CSL-scored node capability matching
 * - Parallel execution of independent subtasks
 * - Session state tracking across steps
 * - Topology map of all system components
 * - Phi-scaled time estimates and resource allocation
 * - Rollback planning for failed steps
 * 
 * @module HeadyVinci
 * @author Eric Haywood
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { PHI, PSI, PSI_SQ, fibonacci, phiThreshold, phiBackoff,
  phiFusionWeights, CSL_THRESHOLDS } = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');

const logger = createLogger('heady-vinci');

// ─── Constants ──────────────────────────────────────────────────────────────
const MAX_STEPS_PER_SESSION = fibonacci(8);       // 21 steps max
const MAX_PARALLEL_BRANCHES = fibonacci(6);        // 8 parallel branches
const SESSION_TTL_MS = fibonacci(14) * 60 * 1000;  // 377 minutes
const STEP_TIMEOUT_HOT = fibonacci(9) * 1000;      // 34 seconds
const STEP_TIMEOUT_WARM = fibonacci(12) * 1000;    // 144 seconds
const STEP_TIMEOUT_COLD = fibonacci(14) * 1000;    // 377 seconds

// Node capability domains (for CSL routing)
const NODE_CAPABILITIES = {
  'JULES':           { domains: ['code_generation', 'refactoring'], pool: 'hot' },
  'BUILDER':         { domains: ['code_generation', 'scaffolding'], pool: 'hot' },
  'HeadyCoder':      { domains: ['code_generation', 'code_review'], pool: 'hot' },
  'OBSERVER':        { domains: ['code_review', 'monitoring'], pool: 'hot' },
  'HeadyAnalyze':    { domains: ['code_review', 'analysis'], pool: 'hot' },
  'MURPHY':          { domains: ['security', 'testing'], pool: 'hot' },
  'CIPHER':          { domains: ['security', 'encryption'], pool: 'hot' },
  'HeadyRisks':      { domains: ['security', 'risk_assessment'], pool: 'hot' },
  'ATLAS':           { domains: ['architecture', 'documentation'], pool: 'hot' },
  'PYTHIA':          { domains: ['architecture', 'prediction'], pool: 'hot' },
  'HeadyVinci':      { domains: ['architecture', 'planning'], pool: 'hot' },
  'HeadyResearch':   { domains: ['research', 'analysis'], pool: 'warm' },
  'SOPHIA':          { domains: ['research', 'knowledge'], pool: 'warm' },
  'HeadyCodex':      { domains: ['documentation', 'code_review'], pool: 'warm' },
  'MUSE':            { domains: ['creative', 'ux_design'], pool: 'warm' },
  'NOVA':            { domains: ['creative', 'innovation'], pool: 'warm' },
  'BRIDGE':          { domains: ['translation', 'integration'], pool: 'warm' },
  'SENTINEL':        { domains: ['monitoring', 'alerting'], pool: 'warm' },
  'LENS':            { domains: ['monitoring', 'visualization'], pool: 'warm' },
  'JANITOR':         { domains: ['cleanup', 'optimization'], pool: 'cold' },
  'HeadyMaid':       { domains: ['cleanup', 'maintenance'], pool: 'cold' },
  'HeadyPatterns':   { domains: ['analytics', 'pattern_detection'], pool: 'cold' },
  'HeadyMC':         { domains: ['analytics', 'simulation'], pool: 'cold' },
  'HeadyMaintenance':{ domains: ['maintenance', 'healing'], pool: 'cold' }
};

// Pool timeouts
const POOL_TIMEOUTS = {
  hot: STEP_TIMEOUT_HOT,
  warm: STEP_TIMEOUT_WARM,
  cold: STEP_TIMEOUT_COLD
};

/**
 * Task Step — a single unit of work in a session plan
 */
class TaskStep {
  constructor({ id, name, description, domain, dependencies = [], metadata = {} }) {
    this.id = id || crypto.randomUUID();
    this.name = name;
    this.description = description;
    this.domain = domain;
    this.dependencies = dependencies; // Step IDs this depends on
    this.assignedNode = null;
    this.pool = null;
    this.status = 'pending';           // pending | running | completed | failed | skipped
    this.result = null;
    this.error = null;
    this.startedAt = null;
    this.completedAt = null;
    this.timeout = null;
    this.rollbackFn = null;
    this.metadata = metadata;
  }

  duration() {
    if (!this.startedAt || !this.completedAt) return null;
    return this.completedAt - this.startedAt;
  }

  toJSON() {
    return {
      id: this.id,
      name: this.name,
      description: this.description,
      domain: this.domain,
      dependencies: this.dependencies,
      assignedNode: this.assignedNode,
      pool: this.pool,
      status: this.status,
      duration: this.duration(),
      error: this.error,
      metadata: this.metadata
    };
  }
}

/**
 * Session Plan — a DAG of task steps
 */
class SessionPlan {
  constructor({ goal, sessionId = null }) {
    this.sessionId = sessionId || crypto.randomUUID();
    this.goal = goal;
    this.steps = new Map();       // id -> TaskStep
    this.createdAt = Date.now();
    this.startedAt = null;
    this.completedAt = null;
    this.status = 'planning';      // planning | ready | executing | completed | failed | rolled_back
  }

  addStep(stepData) {
    if (this.steps.size >= MAX_STEPS_PER_SESSION) {
      throw new Error(`Maximum steps (${MAX_STEPS_PER_SESSION}) exceeded`);
    }
    const step = new TaskStep(stepData);
    this.steps.set(step.id, step);
    return step;
  }

  /**
   * Topological sort — returns steps in valid execution order
   * Detects cycles and throws if found
   */
  topologicalSort() {
    const sorted = [];
    const visited = new Set();
    const visiting = new Set(); // For cycle detection

    const visit = (stepId) => {
      if (visiting.has(stepId)) {
        throw new Error(`Cycle detected involving step: ${stepId}`);
      }
      if (visited.has(stepId)) return;

      visiting.add(stepId);
      const step = this.steps.get(stepId);
      if (!step) throw new Error(`Step not found: ${stepId}`);

      for (const depId of step.dependencies) {
        visit(depId);
      }

      visiting.delete(stepId);
      visited.add(stepId);
      sorted.push(step);
    };

    for (const [id] of this.steps) {
      if (!visited.has(id)) visit(id);
    }

    return sorted;
  }

  /**
   * Get steps that are ready to execute (all dependencies met)
   */
  getReadySteps() {
    const ready = [];
    for (const [, step] of this.steps) {
      if (step.status !== 'pending') continue;

      const depsComplete = step.dependencies.every(depId => {
        const dep = this.steps.get(depId);
        return dep && dep.status === 'completed';
      });

      const depsFailed = step.dependencies.some(depId => {
        const dep = this.steps.get(depId);
        return dep && dep.status === 'failed';
      });

      if (depsFailed) {
        step.status = 'skipped';
        step.error = 'Dependency failed';
        continue;
      }

      if (depsComplete) ready.push(step);
    }

    // Limit parallel branches
    return ready.slice(0, MAX_PARALLEL_BRANCHES);
  }

  isComplete() {
    return Array.from(this.steps.values()).every(
      s => s.status === 'completed' || s.status === 'failed' || s.status === 'skipped'
    );
  }

  successRate() {
    const steps = Array.from(this.steps.values());
    const completed = steps.filter(s => s.status === 'completed').length;
    return steps.length > 0 ? completed / steps.length : 0;
  }

  toJSON() {
    return {
      sessionId: this.sessionId,
      goal: this.goal,
      status: this.status,
      stepCount: this.steps.size,
      steps: Array.from(this.steps.values()).map(s => s.toJSON()),
      successRate: Math.round(this.successRate() * 1000) / 1000,
      createdAt: this.createdAt,
      startedAt: this.startedAt,
      completedAt: this.completedAt,
      duration: this.completedAt ? this.completedAt - this.startedAt : null
    };
  }
}

/**
 * HeadyVinci — Session Planning & Topology Engine
 */
class HeadyVinci {
  constructor(config = {}) {
    this.sessions = new Map();           // sessionId -> SessionPlan
    this.topologyMap = new Map();         // nodeId -> { capabilities, health, load }
    this.executionHistory = [];
    this.conductor = config.conductor || null;
    this.autobiographer = config.autobiographer || null;

    // Initialize topology from known nodes
    this._initializeTopology();

    logger.info({
      nodes: this.topologyMap.size,
      msg: 'HeadyVinci initialized'
    });
  }

  /**
   * Plan a multi-step session from a high-level goal
   */
  planSession(goal, steps = []) {
    const plan = new SessionPlan({ goal });

    // If steps provided, add them directly
    for (const stepData of steps) {
      const step = plan.addStep(stepData);
      // Auto-assign node based on domain
      const assignment = this._assignNode(step.domain);
      if (assignment) {
        step.assignedNode = assignment.node;
        step.pool = assignment.pool;
        step.timeout = POOL_TIMEOUTS[assignment.pool] || STEP_TIMEOUT_WARM;
      }
    }

    // Validate DAG (topological sort will throw on cycles)
    try {
      plan.topologicalSort();
    } catch (err) {
      logger.error({ err: err.message, sessionId: plan.sessionId, msg: 'Plan has cycle' });
      throw err;
    }

    plan.status = 'ready';
    this.sessions.set(plan.sessionId, plan);

    logger.info({
      sessionId: plan.sessionId,
      goal: goal.substring(0, fibonacci(11)), // 89 chars
      stepCount: plan.steps.size,
      msg: 'Session planned'
    });

    return plan;
  }

  /**
   * Decompose a goal into steps automatically
   * Uses domain analysis to generate a task DAG
   */
  decomposeGoal(goal, domains = []) {
    const steps = [];
    const stepMap = new Map();

    // Phase 1: Analysis (always first)
    const analysisStep = {
      id: crypto.randomUUID(),
      name: 'Analyze Requirements',
      description: `Analyze: ${goal.substring(0, fibonacci(11))}`,
      domain: 'analysis',
      dependencies: []
    };
    steps.push(analysisStep);
    stepMap.set('analysis', analysisStep.id);

    // Phase 2: Domain-specific steps (parallel after analysis)
    for (const domain of domains) {
      const domainStep = {
        id: crypto.randomUUID(),
        name: `Execute: ${domain}`,
        description: `${domain} implementation for: ${goal.substring(0, fibonacci(8) * 3)}`,
        domain,
        dependencies: [analysisStep.id]
      };
      steps.push(domainStep);
      stepMap.set(domain, domainStep.id);
    }

    // Phase 3: Quality gate (after all domain steps)
    const domainStepIds = steps.filter(s => s.id !== analysisStep.id).map(s => s.id);
    const qualityStep = {
      id: crypto.randomUUID(),
      name: 'Quality Gate',
      description: 'Validate all outputs against quality standards',
      domain: 'code_review',
      dependencies: domainStepIds
    };
    steps.push(qualityStep);
    stepMap.set('quality', qualityStep.id);

    // Phase 4: Assurance (after quality gate)
    const assuranceStep = {
      id: crypto.randomUUID(),
      name: 'Assurance Gate',
      description: 'Certify outputs for deployment readiness',
      domain: 'security',
      dependencies: [qualityStep.id]
    };
    steps.push(assuranceStep);

    return this.planSession(goal, steps);
  }

  /**
   * Execute a session plan
   */
  async executeSession(sessionId) {
    const plan = this.sessions.get(sessionId);
    if (!plan) throw new Error(`Session not found: ${sessionId}`);
    if (plan.status === 'executing') throw new Error('Session already executing');

    plan.status = 'executing';
    plan.startedAt = Date.now();

    logger.info({ sessionId, goal: plan.goal.substring(0, fibonacci(11)), msg: 'Session execution started' });

    try {
      // Execute in waves — each wave processes all ready steps in parallel
      let wave = 0;
      while (!plan.isComplete()) {
        wave++;
        const readySteps = plan.getReadySteps();

        if (readySteps.length === 0 && !plan.isComplete()) {
          // Deadlock — no steps ready but not complete
          logger.error({ sessionId, wave, msg: 'Session deadlocked — no ready steps' });
          plan.status = 'failed';
          break;
        }

        logger.info({
          sessionId,
          wave,
          readyCount: readySteps.length,
          msg: `Executing wave ${wave}`
        });

        // Execute ready steps in parallel
        const results = await Promise.allSettled(
          readySteps.map(step => this._executeStep(step, plan))
        );

        // Process results
        for (let i = 0; i < results.length; i++) {
          const step = readySteps[i];
          const result = results[i];

          if (result.status === 'fulfilled') {
            step.status = 'completed';
            step.result = result.value;
            step.completedAt = Date.now();
          } else {
            step.status = 'failed';
            step.error = result.reason?.message || 'Unknown error';
            step.completedAt = Date.now();
          }
        }

        // Safety: prevent infinite loops
        if (wave > MAX_STEPS_PER_SESSION) {
          logger.error({ sessionId, wave, msg: 'Maximum waves exceeded' });
          break;
        }
      }

      plan.completedAt = Date.now();
      plan.status = plan.successRate() >= CSL_THRESHOLDS.MEDIUM ? 'completed' : 'failed';

      // Record in history
      this.executionHistory.push({
        sessionId,
        goal: plan.goal,
        status: plan.status,
        successRate: plan.successRate(),
        duration: plan.completedAt - plan.startedAt,
        waves: wave,
        steps: plan.steps.size
      });

      // Keep last fib(8) = 21 executions
      if (this.executionHistory.length > fibonacci(8)) {
        this.executionHistory.shift();
      }

      // Log to autobiographer
      if (this.autobiographer) {
        this.autobiographer.recordMilestone(
          `Session ${plan.status}`,
          `"${plan.goal.substring(0, fibonacci(8) * 3)}" — ${plan.steps.size} steps, ${Math.round(plan.successRate() * 100)}% success`,
          { sessionId, duration: plan.completedAt - plan.startedAt }
        );
      }

      logger.info({
        sessionId,
        status: plan.status,
        successRate: plan.successRate(),
        duration: plan.completedAt - plan.startedAt,
        waves: wave,
        msg: 'Session execution complete'
      });

      return plan.toJSON();
    } catch (err) {
      plan.status = 'failed';
      plan.completedAt = Date.now();
      logger.error({ sessionId, err: err.message, msg: 'Session execution failed' });
      throw err;
    }
  }

  /**
   * Execute a single step
   */
  async _executeStep(step, plan) {
    step.status = 'running';
    step.startedAt = Date.now();

    logger.info({
      stepId: step.id,
      name: step.name,
      node: step.assignedNode,
      pool: step.pool,
      msg: 'Step executing'
    });

    // If conductor is available, dispatch to actual node
    if (this.conductor) {
      return await Promise.race([
        this.conductor.dispatch({
          taskId: step.id,
          query: step.description,
          targetNode: step.assignedNode,
          pool: step.pool,
          sessionId: plan.sessionId
        }),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Step timeout')), step.timeout || STEP_TIMEOUT_WARM)
        )
      ]);
    }

    // Simulated execution for testing
    return { status: 'completed', node: step.assignedNode, simulated: true };
  }

  /**
   * Rollback a failed session
   */
  async rollbackSession(sessionId) {
    const plan = this.sessions.get(sessionId);
    if (!plan) throw new Error(`Session not found: ${sessionId}`);

    const completedSteps = Array.from(plan.steps.values())
      .filter(s => s.status === 'completed')
      .reverse(); // LIFO rollback

    let rolledBack = 0;
    for (const step of completedSteps) {
      if (step.rollbackFn) {
        try {
          await step.rollbackFn(step.result);
          rolledBack++;
          logger.info({ stepId: step.id, name: step.name, msg: 'Step rolled back' });
        } catch (err) {
          logger.error({ stepId: step.id, err: err.message, msg: 'Rollback failed' });
        }
      }
    }

    plan.status = 'rolled_back';

    logger.info({ sessionId, rolledBack, total: completedSteps.length, msg: 'Session rollback complete' });
    return { rolledBack, total: completedSteps.length };
  }

  // ─── Topology Management ──────────────────────────────────────────────

  _initializeTopology() {
    for (const [nodeId, caps] of Object.entries(NODE_CAPABILITIES)) {
      this.topologyMap.set(nodeId, {
        id: nodeId,
        capabilities: caps.domains,
        pool: caps.pool,
        health: 1.0,
        load: 0,
        lastSeen: Date.now()
      });
    }
  }

  /**
   * Assign the best node for a domain using CSL-scored matching
   */
  _assignNode(domain) {
    let bestNode = null;
    let bestScore = 0;

    for (const [nodeId, node] of this.topologyMap) {
      if (node.health < CSL_THRESHOLDS.LOW) continue; // Skip unhealthy nodes

      const domainMatch = node.capabilities.includes(domain) ? 1.0 : 0;
      const healthFactor = node.health;
      const loadFactor = 1 - Math.min(node.load, 1);

      // CSL-scored: capability match * health * (1-load)
      const weights = phiFusionWeights(3);
      const score = weights[0] * domainMatch +
                    weights[1] * healthFactor +
                    weights[2] * loadFactor;

      if (score > bestScore) {
        bestScore = score;
        bestNode = nodeId;
      }
    }

    if (!bestNode) return null;
    const node = this.topologyMap.get(bestNode);
    return { node: bestNode, pool: node.pool, score: bestScore };
  }

  /**
   * Update node health in topology
   */
  updateNodeHealth(nodeId, health) {
    const node = this.topologyMap.get(nodeId);
    if (node) {
      node.health = health;
      node.lastSeen = Date.now();
    }
  }

  /**
   * Get full topology map
   */
  getTopology() {
    const topology = {};
    for (const [id, node] of this.topologyMap) {
      topology[id] = { ...node };
    }
    return topology;
  }

  // ─── Health & Status ──────────────────────────────────────────────────

  health() {
    const activeSessions = Array.from(this.sessions.values())
      .filter(s => s.status === 'executing').length;
    const healthyNodes = Array.from(this.topologyMap.values())
      .filter(n => n.health >= CSL_THRESHOLDS.MEDIUM).length;

    return {
      status: 'healthy',
      service: 'heady-vinci',
      activeSessions,
      totalSessions: this.sessions.size,
      topologyNodes: this.topologyMap.size,
      healthyNodes,
      executionHistory: this.executionHistory.length
    };
  }

  shutdown() {
    logger.info({
      sessions: this.sessions.size,
      history: this.executionHistory.length,
      msg: 'HeadyVinci shutting down'
    });
  }
}

module.exports = {
  HeadyVinci,
  SessionPlan,
  TaskStep,
  NODE_CAPABILITIES,
  MAX_STEPS_PER_SESSION,
  MAX_PARALLEL_BRANCHES
};
