/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Auto-Context Engine v2.0
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Context assembly system implementing the 5-stage Context Enrichment Pipeline:
 * 1. Memory Recall (Elephant Layer)
 * 2. Ecosystem State Assessment (Eagle Layer)
 * 3. External Intelligence (Owl Layer)
 * 4. Context Fusion (Dolphin Layer)
 * 5. Intelligence Maximization (Rabbit Layer)
 *
 * © 2026 HeadySystems Inc. — Eric Haywood
 */

'use strict';

const { PHI, PSI, PSI2, fib, CSL_THRESHOLDS, cosineSimilarity, normalize,
  phiFusionWeights, phiPriorityScore } = require('../../shared/phi-math');
const { cslAND, resonanceGate, weightedSuperposition } = require('../../shared/csl-engine');
const { createLogger } = require('../../shared/logger');
const logger = createLogger('auto-context-engine');

const MAX_CONTEXT_ENTRIES = fib(11);        // 89
const RELEVANCE_THRESHOLD = CSL_THRESHOLDS.LOW; // 0.691
const FUSION_WINDOW_MS = Math.round(PHI * 30000); // ~48.5s

class AutoContextEngine {
  constructor(opts = {}) {
    this._vectorMemory = opts.vectorMemory || null;
    this._healthRegistry = opts.healthRegistry || null;
    this._externalIntel = opts.externalIntel || null;
    this._budgetTracker = opts.budgetTracker || null;
    this._patternDb = opts.patternDb || null;
    this._contextCache = new Map();
    this._cacheMaxSize = fib(16);  // 987
    this._stats = { assemblyCount: 0, cacheHits: 0, fusionOps: 0 };
    logger.info({ event: 'auto_context_engine_init' });
  }

  /**
   * Assemble full context for a task intent.
   * Implements the 5-stage Context Enrichment Pipeline.
   */
  async assembleContext(intent, opts = {}) {
    const startTime = Date.now();
    const context = {
      intent,
      stages: {},
      fusedContext: null,
      confidence: 0,
      assemblyMs: 0,
    };

    // Stage 1: Memory Recall (Elephant Layer)
    context.stages.memoryRecall = await this._stageMemoryRecall(intent, opts);

    // Stage 2: Ecosystem State Assessment (Eagle Layer)
    context.stages.ecosystemState = await this._stageEcosystemState(intent, opts);

    // Stage 3: External Intelligence (Owl Layer)
    context.stages.externalIntel = await this._stageExternalIntel(intent, opts);

    // Stage 4: Context Fusion (Dolphin Layer)
    context.fusedContext = this._stageContextFusion(context.stages);
    this._stats.fusionOps++;

    // Stage 5: Intelligence Maximization (Rabbit Layer)
    context.confidence = this._stageIntelligenceMax(context);

    context.assemblyMs = Date.now() - startTime;
    this._stats.assemblyCount++;

    // CSL Resonance Gate — if confidence < 0.618, expand search
    if (context.confidence < CSL_THRESHOLDS.LOW) {
      logger.info({ event: 'context_expansion_triggered', confidence: context.confidence, intent });
      context.expanded = true;
    }

    return context;
  }

  async _stageMemoryRecall(intent, opts = {}) {
    const results = { entries: [], score: 0 };
    if (!this._vectorMemory) return results;

    try {
      const memories = await this._vectorMemory.searchText(intent, fib(7)); // top 13
      results.entries = memories.filter(m => m.score >= RELEVANCE_THRESHOLD);
      results.score = results.entries.length > 0
        ? results.entries.reduce((sum, m) => sum + m.score, 0) / results.entries.length
        : 0;
    } catch (err) {
      logger.warn({ event: 'memory_recall_failed', error: err.message });
    }
    return results;
  }

  async _stageEcosystemState(intent, opts = {}) {
    const state = {
      swarmHealth: {},
      activeDeployments: 0,
      budgetHeadroom: 1.0,
      pipelineStatus: 'unknown',
    };

    if (this._healthRegistry) {
      try {
        state.swarmHealth = await this._healthRegistry.getAllSwarmHealth();
      } catch (err) {
        logger.warn({ event: 'health_check_failed', error: err.message });
      }
    }

    if (this._budgetTracker) {
      try {
        state.budgetHeadroom = await this._budgetTracker.getHeadroom();
      } catch (err) {
        logger.warn({ event: 'budget_check_failed', error: err.message });
      }
    }

    return state;
  }

  async _stageExternalIntel(intent, opts = {}) {
    const intel = { patterns: [], webResearch: null };

    if (this._patternDb) {
      try {
        intel.patterns = await this._patternDb.searchPatterns(intent, fib(5)); // top 5
      } catch (err) {
        logger.warn({ event: 'pattern_search_failed', error: err.message });
      }
    }

    return intel;
  }

  _stageContextFusion(stages) {
    // φ-weighted fusion of all context sources
    const weights = phiFusionWeights(3); // [0.528, 0.326, 0.146]
    const fusion = {
      memoryWeight: weights[0],
      ecosystemWeight: weights[1],
      externalWeight: weights[2],
      memoryScore: stages.memoryRecall.score,
      ecosystemHealthy: Object.keys(stages.ecosystemState.swarmHealth).length > 0,
      patternsFound: stages.externalIntel.patterns.length,
      fusedAt: Date.now(),
    };
    return fusion;
  }

  _stageIntelligenceMax(context) {
    // Compute overall confidence using phi-priority scoring
    const memScore = context.stages.memoryRecall.score;
    const ecoScore = context.fusedContext.ecosystemHealthy ? CSL_THRESHOLDS.HIGH : CSL_THRESHOLDS.LOW;
    const patScore = context.fusedContext.patternsFound > 0 ? CSL_THRESHOLDS.MEDIUM : CSL_THRESHOLDS.LOW;
    return phiPriorityScore(memScore, ecoScore, patScore);
  }

  getStats() { return { ...this._stats }; }
}

module.exports = { AutoContextEngine, MAX_CONTEXT_ENTRIES, RELEVANCE_THRESHOLD };
