/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Auto-Success Engine v2.0
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Dynamic φ⁷-derived cycle (29,034ms) running CSL-discovered categories
 * with parallel background tasks. Task counts computed at runtime using
 * Sacred Geometry φ-scaling.
 *
 * © 2026 HeadySystems Inc. — Eric Haywood
 */

'use strict';

const { PHI, PSI, PSI2, PSI3, PSI4, fib, AUTO_SUCCESS, CSL_THRESHOLDS,
  phiBackoff, phiFusionWeights } = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');
const logger = createLogger('auto-success-engine');

const CATEGORIES = Object.freeze({
  // Tier 1 Critical (38.2%)
  security:       { tier: 1, weight: PSI2 / 3 },
  intelligence:   { tier: 1, weight: PSI2 / 3 },
  availability:   { tier: 1, weight: PSI2 / 3 },
  // Tier 2 High (23.6%)
  performance:    { tier: 2, weight: (PSI3 + PSI4 / 2) / 3 },
  code_quality:   { tier: 2, weight: (PSI3 + PSI4 / 2) / 3 },
  learning:       { tier: 2, weight: (PSI3 + PSI4 / 2) / 3 },
  // Tier 3 Standard (14.6%)
  communication:  { tier: 3, weight: PSI3 / 3 },
  infrastructure: { tier: 3, weight: PSI3 / 3 },
  compliance:     { tier: 3, weight: PSI3 / 3 },
  // Tier 4 Growth (9.0%)
  cost_optimization: { tier: 4, weight: PSI4 / 4 },
  discovery:         { tier: 4, weight: PSI4 / 4 },
  evolution:         { tier: 4, weight: PSI4 / 4 },
  self_assessment:   { tier: 4, weight: PSI4 / 4 },
});

class AutoSuccessEngine {
  constructor(opts = {}) {
    this._taskHandlers = new Map();
    this._cycleTimer = null;
    this._running = false;
    this._cycleCount = 0;
    this._stats = { cycles: 0, tasksRun: 0, tasksFailed: 0, avgCycleMs: 0, totalCycleMs: 0 };

    // Register default handlers
    for (const category of Object.keys(CATEGORIES)) {
      this._taskHandlers.set(category, opts.handlers?.[category] || _defaultCategoryHandler(category));
    }

    logger.info({
      event: 'auto_success_init',
      cycleMs: AUTO_SUCCESS.CYCLE_MS,
      categories: Object.keys(CATEGORIES).length,
    });
  }

  start() {
    if (this._running) return this;
    this._running = true;
    this._scheduleCycle();
    logger.info({ event: 'auto_success_started', cycleMs: AUTO_SUCCESS.CYCLE_MS });
    return this;
  }

  stop() {
    this._running = false;
    if (this._cycleTimer) { clearTimeout(this._cycleTimer); this._cycleTimer = null; }
    logger.info({ event: 'auto_success_stopped', totalCycles: this._stats.cycles });
    return this;
  }

  _scheduleCycle() {
    if (!this._running) return;
    this._cycleTimer = setTimeout(async () => {
      await this._runCycle();
      this._scheduleCycle();
    }, AUTO_SUCCESS.CYCLE_MS);
    if (this._cycleTimer.unref) this._cycleTimer.unref();
  }

  async _runCycle() {
    const cycleStart = Date.now();
    this._cycleCount++;

    // Run all categories in parallel, respecting φ-weighted allocation
    const categoryEntries = Object.entries(CATEGORIES);
    const tasks = categoryEntries.map(async ([category, config]) => {
      const handler = this._taskHandlers.get(category);
      if (!handler) return null;

      try {
        const result = await Promise.race([
          handler({ category, tier: config.tier, weight: config.weight, cycle: this._cycleCount }),
          new Promise((_, reject) => setTimeout(() => reject(new Error('Task timeout')), AUTO_SUCCESS.TASK_TIMEOUT_MS)),
        ]);
        this._stats.tasksRun++;
        return { category, status: 'ok', result };
      } catch (err) {
        this._stats.tasksFailed++;
        logger.warn({ event: 'auto_success_task_failed', category, error: err.message });
        return { category, status: 'error', error: err.message };
      }
    });

    const results = await Promise.allSettled(tasks);
    const cycleMs = Date.now() - cycleStart;

    this._stats.cycles++;
    this._stats.totalCycleMs += cycleMs;
    this._stats.avgCycleMs = Math.round(this._stats.totalCycleMs / this._stats.cycles);

    if (cycleMs > AUTO_SUCCESS.TASK_TIMEOUT_MS) {
      logger.warn({ event: 'auto_success_cycle_slow', cycleMs, threshold: AUTO_SUCCESS.TASK_TIMEOUT_MS });
    }
  }

  registerHandler(category, handler) {
    if (!CATEGORIES[category]) throw new Error('Unknown category: ' + category);
    this._taskHandlers.set(category, handler);
    return this;
  }

  getStatus() {
    return {
      running: this._running,
      cycleMs: AUTO_SUCCESS.CYCLE_MS,
      cycleCount: this._cycleCount,
      categories: Object.keys(CATEGORIES).length,
      stats: { ...this._stats },
    };
  }
}

function _defaultCategoryHandler(category) {
  return async (ctx) => ({ category, checked: true, ts: Date.now(), cycle: ctx.cycle });
}

module.exports = { AutoSuccessEngine, CATEGORIES, AUTO_SUCCESS };
