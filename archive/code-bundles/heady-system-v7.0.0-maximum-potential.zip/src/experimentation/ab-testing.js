/**
 * ABTestingFramework — Phi-Weighted Variant Experimentation Engine
 * 
 * A/B testing with phi-derived variant distribution, Fibonacci gradual rollout,
 * statistical significance testing, and CSL-gated winner selection.
 * 
 * Features:
 * - Phi-weighted variant split (0.618 control / 0.382 variant by default)
 * - Fibonacci gradual rollout (1% → 2% → 3% → 5% → ... → 100%)
 * - Z-test and chi-squared statistical significance
 * - CSL-gated experiment maturity scoring
 * - Multi-variant support (up to fib(5)=5 variants)
 * - User-sticky assignment via deterministic hashing
 * - Experiment lifecycle management
 * 
 * @module ab-testing
 * @version 1.0.0
 * @author Eric Haywood
 */

const {
  PHI,
  PSI,
  PHI2,
  PHI3,
  fib,
  fibonacci,
  phiThreshold,
  phiFusionWeights,
  phiBackoff,
  CSL_THRESHOLDS,
  PRESSURE_LEVELS,
  SIZING,
  cslGate,
  SERVICE_PORTS
} = require('../../shared/phi-math.js');
const { createLogger } = require('../../shared/logger.js');
const { createHealthCheck } = require('../../shared/health.js');

const logger = createLogger('ab-testing');

/* ═══════════════════════════════════════════════════════════════
   §1 — Constants (all phi-derived)
   ═══════════════════════════════════════════════════════════════ */

const MAX_EXPERIMENTS = fib(11);          // 89 active experiments
const MAX_VARIANTS = fib(5);              // 5 variants per experiment
const MIN_SAMPLE_SIZE = fib(11);          // 89 samples for significance
const MAX_EVENTS_BUFFER = fib(17);        // 1597 events before flush
const CACHE_SIZE = fib(16);               // 987 cached assignments
const SIGNIFICANCE_THRESHOLD = CSL_THRESHOLDS.MEDIUM; // 0.809 (≈ p < 0.05 equivalent)
const MATURITY_THRESHOLD = CSL_THRESHOLDS.HIGH;       // 0.882 — experiment mature enough to call

/** Fibonacci gradual rollout percentages */
const ROLLOUT_STEPS = [1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 100];
// Maps to fib(2) through fib(11), plus 100%

/** Experiment states */
const STATES = {
  DRAFT: 'draft',
  RUNNING: 'running',
  PAUSED: 'paused',
  COMPLETED: 'completed',
  ROLLED_BACK: 'rolled_back'
};

/** Default phi-split for 2-variant */
const DEFAULT_SPLIT = phiFusionWeights(2); // [0.618 control, 0.382 variant]

/* ═══════════════════════════════════════════════════════════════
   §2 — Experiment Manager
   ═══════════════════════════════════════════════════════════════ */

class ExperimentManager {
  constructor() {
    this._experiments = new Map();   // experimentId -> experiment
    this._assignments = new Map();   // `${userId}:${experimentId}` -> variant
    this._events = new Map();        // experimentId -> events[]
    this._rollouts = new Map();      // experimentId -> current rollout step
  }

  /**
   * Create a new experiment
   * @param {object} config - Experiment configuration
   * @returns {object} Created experiment
   */
  create(config) {
    const {
      name,
      description = '',
      variants = ['control', 'variant'],
      weights = null,
      targetMetric,
      secondaryMetrics = [],
      rollout = false,
      targeting = null
    } = config;

    if (this._experiments.size >= MAX_EXPERIMENTS) {
      return { error: `Maximum ${MAX_EXPERIMENTS} active experiments reached` };
    }
    if (variants.length > MAX_VARIANTS) {
      return { error: `Maximum ${MAX_VARIANTS} variants per experiment` };
    }

    // Calculate weights — use phi-fusion for the number of variants
    const variantWeights = weights || phiFusionWeights(variants.length);

    const experiment = {
      id: `exp_${Date.now().toString(36)}_${name.replace(/\s+/g, '_').substring(0, 13)}`,
      name,
      description,
      variants: variants.map((v, i) => ({
        id: typeof v === 'string' ? v : v.id,
        name: typeof v === 'string' ? v : v.name,
        weight: variantWeights[i],
        conversions: 0,
        impressions: 0
      })),
      targetMetric,
      secondaryMetrics,
      state: STATES.DRAFT,
      rollout,
      rolloutStep: rollout ? 0 : null,
      rolloutPct: rollout ? ROLLOUT_STEPS[0] : 100,
      targeting,
      createdAt: Date.now(),
      startedAt: null,
      endedAt: null,
      totalImpressions: 0,
      totalConversions: 0,
      winner: null
    };

    this._experiments.set(experiment.id, experiment);
    this._events.set(experiment.id, []);

    logger.info({
      event: 'experiment_created',
      experimentId: experiment.id,
      name,
      variants: variants.length,
      weights: variantWeights.map(w => w.toFixed(3))
    });

    return experiment;
  }

  /**
   * Start an experiment
   */
  start(experimentId) {
    const exp = this._experiments.get(experimentId);
    if (!exp) return { error: 'Experiment not found' };
    if (exp.state !== STATES.DRAFT && exp.state !== STATES.PAUSED) {
      return { error: `Cannot start from state: ${exp.state}` };
    }

    exp.state = STATES.RUNNING;
    exp.startedAt = exp.startedAt || Date.now();

    logger.info({ event: 'experiment_started', experimentId, name: exp.name });
    return exp;
  }

  /**
   * Pause an experiment
   */
  pause(experimentId) {
    const exp = this._experiments.get(experimentId);
    if (!exp || exp.state !== STATES.RUNNING) return { error: 'Cannot pause' };

    exp.state = STATES.PAUSED;
    logger.info({ event: 'experiment_paused', experimentId });
    return exp;
  }

  /**
   * Complete an experiment with winner
   */
  complete(experimentId, winnerId = null) {
    const exp = this._experiments.get(experimentId);
    if (!exp) return { error: 'Experiment not found' };

    exp.state = STATES.COMPLETED;
    exp.endedAt = Date.now();
    
    if (winnerId) {
      exp.winner = winnerId;
    } else {
      // Auto-determine winner
      const analysis = this.analyze(experimentId);
      exp.winner = analysis.recommendedWinner;
    }

    logger.info({ event: 'experiment_completed', experimentId, winner: exp.winner });
    return exp;
  }

  /**
   * Advance rollout to next Fibonacci step
   */
  advanceRollout(experimentId) {
    const exp = this._experiments.get(experimentId);
    if (!exp || !exp.rollout) return { error: 'Not a rollout experiment' };

    const currentStep = exp.rolloutStep || 0;
    if (currentStep >= ROLLOUT_STEPS.length - 1) {
      return { done: true, pct: 100, message: 'Rollout complete' };
    }

    exp.rolloutStep = currentStep + 1;
    exp.rolloutPct = ROLLOUT_STEPS[exp.rolloutStep];

    logger.info({
      event: 'rollout_advanced',
      experimentId,
      step: exp.rolloutStep,
      pct: exp.rolloutPct,
      nextPct: ROLLOUT_STEPS[exp.rolloutStep + 1] || 'complete'
    });

    return {
      step: exp.rolloutStep,
      pct: exp.rolloutPct,
      nextPct: ROLLOUT_STEPS[exp.rolloutStep + 1] || null,
      remaining: ROLLOUT_STEPS.length - 1 - exp.rolloutStep
    };
  }

  /* ═══════════════════════════════════════════════════════════════
     §3 — Assignment Engine
     ═══════════════════════════════════════════════════════════════ */

  /**
   * Assign a user to an experiment variant (sticky)
   * @param {string} userId - User ID
   * @param {string} experimentId - Experiment ID
   * @returns {object} Assignment result
   */
  assign(userId, experimentId) {
    const exp = this._experiments.get(experimentId);
    if (!exp || exp.state !== STATES.RUNNING) {
      return { variant: null, reason: 'experiment_not_running' };
    }

    // Check targeting rules
    if (exp.targeting && !this._matchesTargeting(userId, exp.targeting)) {
      return { variant: null, reason: 'not_targeted' };
    }

    // Check rollout eligibility
    if (exp.rollout) {
      const hash = _deterministicHash(`${userId}:${experimentId}:rollout`);
      const pctBucket = (hash % 100) + 1;
      if (pctBucket > exp.rolloutPct) {
        return { variant: exp.variants[0].id, reason: 'rollout_excluded', rolloutPct: exp.rolloutPct };
      }
    }

    // Check sticky assignment
    const assignKey = `${userId}:${experimentId}`;
    const existing = this._assignments.get(assignKey);
    if (existing) {
      return { variant: existing, reason: 'sticky', experimentId };
    }

    // Deterministic assignment based on hash
    const hash = _deterministicHash(`${userId}:${experimentId}`);
    const normalized = (hash % 10000) / 10000; // 0.0000 - 0.9999

    let cumulative = 0;
    let assignedVariant = exp.variants[0].id;
    for (const variant of exp.variants) {
      cumulative += variant.weight;
      if (normalized < cumulative) {
        assignedVariant = variant.id;
        break;
      }
    }

    // Record assignment
    this._assignments.set(assignKey, assignedVariant);

    // Update impressions
    const variant = exp.variants.find(v => v.id === assignedVariant);
    if (variant) variant.impressions++;
    exp.totalImpressions++;

    logger.info({
      event: 'experiment_assignment',
      userId,
      experimentId,
      variant: assignedVariant
    });

    return { variant: assignedVariant, reason: 'assigned', experimentId };
  }

  /**
   * Record a conversion event
   * @param {string} userId - User ID
   * @param {string} experimentId - Experiment ID
   * @param {object} [eventData] - Additional event data
   */
  recordConversion(userId, experimentId, eventData = {}) {
    const exp = this._experiments.get(experimentId);
    if (!exp || exp.state !== STATES.RUNNING) return { recorded: false };

    const assignKey = `${userId}:${experimentId}`;
    const variantId = this._assignments.get(assignKey);
    if (!variantId) return { recorded: false, reason: 'not_assigned' };

    const variant = exp.variants.find(v => v.id === variantId);
    if (variant) variant.conversions++;
    exp.totalConversions++;

    // Buffer event
    const events = this._events.get(experimentId) || [];
    events.push({
      userId,
      variant: variantId,
      type: 'conversion',
      data: eventData,
      timestamp: Date.now()
    });
    
    // Flush if buffer full
    if (events.length >= MAX_EVENTS_BUFFER) {
      events.splice(0, events.length - fib(14)); // Keep last 377
    }
    this._events.set(experimentId, events);

    return { recorded: true, variant: variantId };
  }

  _matchesTargeting(userId, targeting) {
    if (!targeting) return true;
    // Simple targeting: percentage-based
    if (targeting.percentage) {
      const hash = _deterministicHash(`${userId}:targeting`);
      return (hash % 100) < targeting.percentage;
    }
    return true;
  }

  /* ═══════════════════════════════════════════════════════════════
     §4 — Statistical Analysis
     ═══════════════════════════════════════════════════════════════ */

  /**
   * Analyze experiment results with statistical significance
   * @param {string} experimentId - Experiment ID
   * @returns {object} Analysis results
   */
  analyze(experimentId) {
    const exp = this._experiments.get(experimentId);
    if (!exp) return { error: 'Experiment not found' };

    const variants = exp.variants.map(v => ({
      id: v.id,
      name: v.name,
      impressions: v.impressions,
      conversions: v.conversions,
      conversionRate: v.impressions > 0 ? v.conversions / v.impressions : 0,
      weight: v.weight
    }));

    // Statistical significance between control and each variant
    const control = variants[0];
    const comparisons = [];

    for (let i = 1; i < variants.length; i++) {
      const variant = variants[i];
      const significance = _zTestSignificance(control, variant);
      const lift = control.conversionRate > 0 
        ? (variant.conversionRate - control.conversionRate) / control.conversionRate 
        : 0;

      comparisons.push({
        variant: variant.id,
        controlRate: control.conversionRate.toFixed(4),
        variantRate: variant.conversionRate.toFixed(4),
        lift: (lift * 100).toFixed(2) + '%',
        zScore: significance.zScore.toFixed(3),
        pValue: significance.pValue.toFixed(4),
        significant: significance.significant,
        confidence: significance.confidence.toFixed(3)
      });
    }

    // Maturity score — CSL-gated
    const minSamples = Math.min(...variants.map(v => v.impressions));
    const sampleRatio = Math.min(1, minSamples / MIN_SAMPLE_SIZE);
    const maturity = cslGate(sampleRatio, sampleRatio, CSL_THRESHOLDS.LOW);
    const mature = maturity >= MATURITY_THRESHOLD;

    // Recommended winner
    let recommendedWinner = null;
    if (mature) {
      const best = variants.reduce((a, b) => a.conversionRate > b.conversionRate ? a : b);
      const isSignificant = comparisons.some(c => c.significant && c.variant === best.id);
      if (isSignificant || best.id === control.id) {
        recommendedWinner = best.id;
      }
    }

    const analysis = {
      experimentId,
      name: exp.name,
      state: exp.state,
      totalImpressions: exp.totalImpressions,
      totalConversions: exp.totalConversions,
      overallConversionRate: exp.totalImpressions > 0
        ? (exp.totalConversions / exp.totalImpressions).toFixed(4)
        : '0.0000',
      variants,
      comparisons,
      maturity: maturity.toFixed(3),
      mature,
      recommendedWinner,
      rollout: exp.rollout ? {
        step: exp.rolloutStep,
        pct: exp.rolloutPct,
        steps: ROLLOUT_STEPS
      } : null
    };

    logger.info({
      event: 'experiment_analyzed',
      experimentId,
      maturity: maturity.toFixed(3),
      mature,
      winner: recommendedWinner
    });

    return analysis;
  }

  /**
   * Get all experiments summary
   */
  list() {
    return Array.from(this._experiments.values()).map(exp => ({
      id: exp.id,
      name: exp.name,
      state: exp.state,
      variants: exp.variants.length,
      totalImpressions: exp.totalImpressions,
      totalConversions: exp.totalConversions,
      rollout: exp.rollout ? `${exp.rolloutPct}%` : null,
      winner: exp.winner,
      createdAt: exp.createdAt,
      startedAt: exp.startedAt,
      endedAt: exp.endedAt
    }));
  }
}

/* ═══════════════════════════════════════════════════════════════
   §5 — Statistical Utilities
   ═══════════════════════════════════════════════════════════════ */

/**
 * Z-test for two proportions
 */
function _zTestSignificance(control, variant) {
  const n1 = control.impressions;
  const n2 = variant.impressions;
  const p1 = control.conversionRate;
  const p2 = variant.conversionRate;

  if (n1 < fib(5) || n2 < fib(5)) {
    return { zScore: 0, pValue: 1, significant: false, confidence: 0 };
  }

  const pPooled = (control.conversions + variant.conversions) / (n1 + n2);
  const se = Math.sqrt(pPooled * (1 - pPooled) * (1/n1 + 1/n2));

  if (se === 0) {
    return { zScore: 0, pValue: 1, significant: false, confidence: 0 };
  }

  const zScore = Math.abs(p2 - p1) / se;
  
  // Approximate p-value from z-score
  const pValue = _zToPValue(zScore);
  
  // CSL-gated confidence
  const confidence = cslGate(1 - pValue, 1 - pValue, CSL_THRESHOLDS.MINIMUM);
  const significant = confidence >= SIGNIFICANCE_THRESHOLD;

  return { zScore, pValue, significant, confidence };
}

/**
 * Approximate z-score to p-value (two-tailed)
 * Using Abramowitz and Stegun approximation
 */
function _zToPValue(z) {
  const absZ = Math.abs(z);
  if (absZ > 8) return 0;
  
  // Rational approximation
  const b0 = 0.2316419;
  const b1 = 0.319381530;
  const b2 = -0.356563782;
  const b3 = 1.781477937;
  const b4 = -1.821255978;
  const b5 = 1.330274429;
  
  const t = 1 / (1 + b0 * absZ);
  const phi = Math.exp(-0.5 * absZ * absZ) / Math.sqrt(2 * Math.PI);
  const cdf = phi * (b1*t + b2*t*t + b3*t*t*t + b4*t*t*t*t + b5*t*t*t*t*t);
  
  return 2 * cdf; // Two-tailed
}

/**
 * Deterministic hash for sticky assignment
 */
function _deterministicHash(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const chr = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + chr;
    hash |= 0;
  }
  return Math.abs(hash);
}

/* ═══════════════════════════════════════════════════════════════
   §6 — Health & Export
   ═══════════════════════════════════════════════════════════════ */

const health = createHealthCheck('ab-testing', () => ({
  maxExperiments: MAX_EXPERIMENTS,
  maxVariants: MAX_VARIANTS,
  minSampleSize: MIN_SAMPLE_SIZE,
  significanceThreshold: SIGNIFICANCE_THRESHOLD,
  rolloutSteps: ROLLOUT_STEPS,
  defaultSplit: DEFAULT_SPLIT
}));



module.exports = {
  ExperimentManager,
  health,
  STATES,
  ROLLOUT_STEPS,
  DEFAULT_SPLIT,
  SIGNIFICANCE_THRESHOLD,
  MATURITY_THRESHOLD
};
