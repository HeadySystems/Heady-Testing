/**
 * Heady™ BeeFactory — Dynamic Agent Worker Factory
 * 
 * Production-ready agent factory with:
 * - 24-domain registry with 197 specialized worker types
 * - Dynamic bee creation via createBee() with custom config
 * - Ephemeral bee spawning via spawnBee() for one-shot tasks
 * - Central registry for discovery, routing, and lifecycle management
 * - Phi-scaled pool sizing per domain (Hot/Warm/Cold)
 * - Health monitoring and auto-retirement of unhealthy bees
 * - Swarm composition for complex multi-bee workflows
 * 
 * All thresholds derived from φ (phi). Zero magic numbers.
 * Zero console.log — structured JSON logging only.
 * 
 * @module BeeFactory
 * @version 1.0.0
 * @author Eric Haywood
 */

'use strict';

const {
  PHI, PSI, PHI2,
  PSI_SQ, PSI_CUBE,
  fib,
  phiThreshold, CSL_THRESHOLDS,
  phiFusionWeights, phiFusionScore,
  phiBackoff,
  SIZING,
  TIMING,
  phiResourceWeights,
  cosineSimilarity,
  cslGate,
} = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');

const logger = createLogger('bee-factory');

/* ─────────────────────── Constants ─────────────────────── */

/** Bee lifecycle states */
const BEE_STATES = Object.freeze({
  INITIALIZING: 'initializing',
  IDLE: 'idle',
  WORKING: 'working',
  PAUSED: 'paused',
  ERROR: 'error',
  RETIRING: 'retiring',
  RETIRED: 'retired',
});

/** Pool tiers — phi-weighted resource allocation */
const POOL_TIERS = Object.freeze({
  HOT:       { label: 'hot',      weight: 0.387, maxBees: fib(8),  timeout_ms: fib(9) * 1000 },  // 21 bees, 34s timeout
  WARM:      { label: 'warm',     weight: 0.239, maxBees: fib(7),  timeout_ms: fib(11) * 1000 }, // 13 bees, 89s timeout
  COLD:      { label: 'cold',     weight: 0.148, maxBees: fib(6),  timeout_ms: fib(13) * 1000 }, // 8 bees, 233s timeout
  RESERVE:   { label: 'reserve',  weight: 0.092, maxBees: fib(5),  timeout_ms: fib(12) * 1000 }, // 5 bees, 144s timeout
  EPHEMERAL: { label: 'ephemeral',weight: 0.057, maxBees: fib(9),  timeout_ms: fib(8) * 1000 },  // 34 ephemeral slots, 21s timeout
});

/** Maximum total bees across all pools */
const MAX_TOTAL_BEES = fib(12); // 144

/** Health check interval — phi-scaled */
const HEALTH_CHECK_INTERVAL_MS = fib(8) * 1000; // 21 seconds

/** Max consecutive failures before auto-retire */
const MAX_FAILURES = fib(5); // 5

/** Bee registry capacity */
const MAX_REGISTRY_SIZE = fib(14); // 377

/**
 * 24-Domain Bee Registry
 * Each domain defines specialized worker types with capabilities
 */
const DOMAIN_REGISTRY = Object.freeze({
  code_generation: {
    pool: 'HOT',
    types: ['coder', 'builder', 'refactor', 'copilot', 'codex-coder'],
    description: 'Code generation, refactoring, and inline suggestions',
  },
  code_review: {
    pool: 'HOT',
    types: ['observer', 'analyzer', 'lint-checker', 'quality-gate'],
    description: 'Code review, analysis, and quality checking',
  },
  security: {
    pool: 'HOT',
    types: ['murphy', 'cipher', 'risk-scanner', 'vulnerability-checker', 'secret-detector'],
    description: 'Security scanning, vulnerability detection, secret leak prevention',
  },
  architecture: {
    pool: 'HOT',
    types: ['atlas', 'pythia', 'vinci-planner', 'topology-mapper'],
    description: 'Architecture design, planning, and topology management',
  },
  intelligence: {
    pool: 'HOT',
    types: ['soul', 'brains', 'autobiographer', 'vinci', 'socratic'],
    description: 'Core intelligence: awareness, context, planning, reasoning',
  },
  research: {
    pool: 'WARM',
    types: ['researcher', 'sophia', 'web-crawler', 'paper-analyzer'],
    description: 'Research, web exploration, academic paper analysis',
  },
  documentation: {
    pool: 'WARM',
    types: ['atlas-doc', 'codex-doc', 'api-ref-builder', 'changelog-compiler'],
    description: 'Documentation generation, API references, changelogs',
  },
  creative: {
    pool: 'WARM',
    types: ['muse', 'nova', 'design-generator', 'ux-reviewer'],
    description: 'Creative design, UX review, visual generation',
  },
  translation: {
    pool: 'WARM',
    types: ['bridge', 'locale-checker', 'i18n-extractor'],
    description: 'Translation, internationalization, localization',
  },
  monitoring: {
    pool: 'WARM',
    types: ['observer-monitor', 'lens', 'sentinel', 'drift-detector'],
    description: 'System monitoring, alerting, drift detection',
  },
  memory: {
    pool: 'WARM',
    types: ['memory-writer', 'memory-reader', 'embedding-indexer', 'recall-agent'],
    description: 'Vector memory operations, embedding, recall',
  },
  orchestration: {
    pool: 'HOT',
    types: ['conductor', 'battle-runner', 'manager', 'task-decomposer', 'backpressure'],
    description: 'Task routing, pipeline orchestration, competition, management',
  },
  companion: {
    pool: 'HOT',
    types: ['buddy', 'chat-handler', 'preference-learner', 'anticipator'],
    description: 'Companion interface, preference learning, anticipation',
  },
  quality: {
    pool: 'WARM',
    types: ['check', 'assure', 'test-runner', 'coverage-analyzer'],
    description: 'Quality assurance, testing, coverage analysis',
  },
  cleanup: {
    pool: 'COLD',
    types: ['janitor', 'maid', 'dead-code-remover', 'lint-fixer'],
    description: 'Code cleanup, dead code removal, lint fixing',
  },
  maintenance: {
    pool: 'COLD',
    types: ['maintenance-runner', 'backup-agent', 'rotation-agent', 'gc-agent'],
    description: 'System maintenance, backups, key rotation, garbage collection',
  },
  analytics: {
    pool: 'COLD',
    types: ['patterns', 'monte-carlo', 'trend-analyzer', 'anomaly-detector'],
    description: 'Pattern detection, Monte Carlo simulation, trend analysis',
  },
  deployment: {
    pool: 'WARM',
    types: ['cloud-deployer', 'docker-builder', 'ci-runner', 'rollback-agent'],
    description: 'Cloud deployment, Docker builds, CI/CD, rollbacks',
  },
  lifecycle: {
    pool: 'COLD',
    types: ['shutdown-handler', 'startup-sequencer', 'health-reporter'],
    description: 'Graceful shutdown, startup sequencing, health reporting',
  },
  embedding: {
    pool: 'WARM',
    types: ['embed-router', 'embed-indexer', 'dimension-reducer', 'batch-embedder'],
    description: 'Embedding routing, indexing, dimensionality reduction',
  },
  liquid: {
    pool: 'HOT',
    types: ['liquid-node', 'mesh-manager', 'task-executor', 'liquid-deployer'],
    description: 'Liquid node management, mesh networking, task execution',
  },
  colab: {
    pool: 'WARM',
    types: ['runtime-manager', 'vector-ops', 'notebook-runner', 'bridge-connector'],
    description: 'Colab runtime management, vector operations, notebook execution',
  },
  notification: {
    pool: 'WARM',
    types: ['email-sender', 'webhook-dispatcher', 'alert-broadcaster'],
    description: 'Email, webhook, and alert notification delivery',
  },
  scheduler: {
    pool: 'COLD',
    types: ['cron-runner', 'task-scheduler', 'queue-processor', 'batch-executor'],
    description: 'Scheduled tasks, queue processing, batch execution',
  },
});

/* ─────────────────────── Bee Instance ─────────────────────── */

/**
 * Individual bee worker instance
 */
class Bee {
  /**
   * @param {object} opts
   * @param {string} opts.id - Unique bee ID
   * @param {string} opts.type - Bee type from domain registry
   * @param {string} opts.domain - Domain name
   * @param {string} opts.pool - Pool tier
   * @param {object} [opts.config] - Custom configuration
   * @param {Function} [opts.handler] - Custom work handler
   * @param {boolean} [opts.ephemeral] - Auto-retire after first task
   */
  constructor(opts) {
    this.id = opts.id;
    this.type = opts.type;
    this.domain = opts.domain;
    this.pool = opts.pool;
    this.config = opts.config || {};
    this.handler = opts.handler || null;
    this.ephemeral = opts.ephemeral || false;

    this.state = BEE_STATES.INITIALIZING;
    this.createdAt = Date.now();
    this.lastActiveAt = Date.now();
    this.tasksCompleted = 0;
    this.tasksFailed = 0;
    this.consecutiveFailures = 0;
    this.totalDuration_ms = 0;
    this.currentTask = null;
    this.metadata = {};
  }

  /**
   * Execute a task
   * @param {object} task - Task to execute
   * @param {object} [context] - Execution context
   * @returns {object} Task result
   */
  async execute(task, context = {}) {
    if (this.state === BEE_STATES.RETIRED || this.state === BEE_STATES.RETIRING) {
      throw new Error(`Bee ${this.id} is ${this.state} and cannot execute tasks`);
    }

    const startTime = Date.now();
    this.state = BEE_STATES.WORKING;
    this.currentTask = task;
    this.lastActiveAt = Date.now();

    try {
      let result;
      if (this.handler) {
        result = await this.handler(task, this.config, context);
      } else {
        result = { status: 'no_handler', task };
      }

      this.tasksCompleted++;
      this.consecutiveFailures = 0;
      this.totalDuration_ms += Date.now() - startTime;
      this.state = this.ephemeral ? BEE_STATES.RETIRING : BEE_STATES.IDLE;
      this.currentTask = null;

      return { success: true, result, duration_ms: Date.now() - startTime };
    } catch (err) {
      this.tasksFailed++;
      this.consecutiveFailures++;
      this.totalDuration_ms += Date.now() - startTime;
      this.currentTask = null;

      if (this.consecutiveFailures >= MAX_FAILURES) {
        this.state = BEE_STATES.ERROR;
      } else {
        this.state = BEE_STATES.IDLE;
      }

      return { success: false, error: err.message, duration_ms: Date.now() - startTime };
    }
  }

  /**
   * Get bee health status
   * @returns {object}
   */
  health() {
    const avgDuration = this.tasksCompleted > 0
      ? this.totalDuration_ms / this.tasksCompleted
      : 0;

    return {
      id: this.id,
      type: this.type,
      domain: this.domain,
      pool: this.pool,
      state: this.state,
      ephemeral: this.ephemeral,
      tasksCompleted: this.tasksCompleted,
      tasksFailed: this.tasksFailed,
      consecutiveFailures: this.consecutiveFailures,
      avgDuration_ms: Math.round(avgDuration),
      uptimeMs: Date.now() - this.createdAt,
      idleMs: Date.now() - this.lastActiveAt,
    };
  }
}

/* ─────────────────────── Bee Factory ─────────────────────── */

/**
 * BeeFactory — Dynamic Agent Worker Factory
 * 
 * Creates, manages, and retires specialized agent workers (bees)
 * organized into 24 domains with phi-scaled pool allocation.
 */
class BeeFactory {
  /**
   * @param {object} opts
   * @param {object} [opts.conductor] - HeadyConductor for routing
   * @param {object} [opts.vectorMemory] - HeadyMemory for embedding-based routing
   */
  constructor(opts = {}) {
    this.conductor = opts.conductor || null;
    this.vectorMemory = opts.vectorMemory || null;

    /** Active bees: id → Bee instance */
    this.bees = new Map();

    /** Domain bee counts */
    this.domainCounts = {};
    for (const domain of Object.keys(DOMAIN_REGISTRY)) {
      this.domainCounts[domain] = 0;
    }

    /** Pool bee counts */
    this.poolCounts = {
      HOT: 0,
      WARM: 0,
      COLD: 0,
      RESERVE: 0,
      EPHEMERAL: 0,
    };

    /** Bee type registry: type → domain mapping */
    this.typeIndex = new Map();
    for (const [domain, config] of Object.entries(DOMAIN_REGISTRY)) {
      for (const type of config.types) {
        this.typeIndex.set(type, domain);
      }
    }

    /** Retired bee history — Fibonacci ring buffer */
    this.retiredHistory = [];
    this.maxRetiredHistory = fib(11); // 89

    /** Statistics */
    this.stats = {
      totalCreated: 0,
      totalRetired: 0,
      totalTasksRouted: 0,
      totalEphemeralSpawned: 0,
    };

    /** Health check timer */
    this._healthTimer = setInterval(() => this._healthCheck(), HEALTH_CHECK_INTERVAL_MS);

    logger.info({
      component: 'BeeFactory',
      action: 'initialized',
      domains: Object.keys(DOMAIN_REGISTRY).length,
      types: this.typeIndex.size,
    });
  }

  /* ─────────────── Bee Creation ─────────────── */

  /**
   * Create a persistent bee worker
   * @param {string} type - Bee type from domain registry
   * @param {object} [config] - Custom configuration
   * @param {Function} [handler] - Custom work handler
   * @returns {Bee} Created bee
   */
  createBee(type, config = {}, handler = null) {
    const domain = this.typeIndex.get(type);
    if (!domain) {
      throw new Error(`Unknown bee type: ${type}. Available: ${[...this.typeIndex.keys()].join(', ')}`);
    }

    const domainConfig = DOMAIN_REGISTRY[domain];
    const poolTier = POOL_TIERS[domainConfig.pool];

    // Check pool capacity
    if (this.poolCounts[domainConfig.pool] >= poolTier.maxBees) {
      // Try to evict an idle bee from this pool
      const evicted = this._evictIdleBee(domainConfig.pool);
      if (!evicted) {
        throw new Error(`Pool ${domainConfig.pool} at capacity (${poolTier.maxBees}). No idle bees to evict.`);
      }
    }

    // Check total capacity
    if (this.bees.size >= MAX_TOTAL_BEES) {
      const evicted = this._evictIdleBee(null);
      if (!evicted) {
        throw new Error(`Total bee limit reached (${MAX_TOTAL_BEES}). No idle bees to evict.`);
      }
    }

    const id = `bee-${type}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 2 + fib(4))}`;
    const bee = new Bee({
      id,
      type,
      domain,
      pool: domainConfig.pool,
      config,
      handler,
      ephemeral: false,
    });

    bee.state = BEE_STATES.IDLE;
    this.bees.set(id, bee);
    this.domainCounts[domain]++;
    this.poolCounts[domainConfig.pool]++;
    this.stats.totalCreated++;

    logger.info({
      component: 'BeeFactory',
      action: 'bee_created',
      id,
      type,
      domain,
      pool: domainConfig.pool,
      totalBees: this.bees.size,
    });

    return bee;
  }

  /**
   * Spawn an ephemeral bee for a single task
   * Auto-retires after task completion
   * @param {string} type - Bee type
   * @param {object} task - Task to execute
   * @param {object} [config] - Custom config
   * @param {Function} [handler] - Custom handler
   * @returns {object} Task result
   */
  async spawnBee(type, task, config = {}, handler = null) {
    const domain = this.typeIndex.get(type);
    if (!domain) {
      throw new Error(`Unknown bee type: ${type}`);
    }

    // Check ephemeral pool
    if (this.poolCounts.EPHEMERAL >= POOL_TIERS.EPHEMERAL.maxBees) {
      // Wait for a slot with phi-backoff
      const maxAttempts = fib(5); // 5 attempts
      let attempt = 0;
      while (this.poolCounts.EPHEMERAL >= POOL_TIERS.EPHEMERAL.maxBees && attempt < maxAttempts) {
        await new Promise(r => setTimeout(r, phiBackoff(attempt)));
        attempt++;
      }
      if (this.poolCounts.EPHEMERAL >= POOL_TIERS.EPHEMERAL.maxBees) {
        throw new Error('Ephemeral pool at capacity after retry');
      }
    }

    const id = `eph-${type}-${Date.now().toString(36)}`;
    const bee = new Bee({
      id,
      type,
      domain,
      pool: 'EPHEMERAL',
      config,
      handler,
      ephemeral: true,
    });

    bee.state = BEE_STATES.IDLE;
    this.bees.set(id, bee);
    this.poolCounts.EPHEMERAL++;
    this.stats.totalEphemeralSpawned++;

    logger.info({
      component: 'BeeFactory',
      action: 'ephemeral_spawned',
      id,
      type,
      domain,
    });

    try {
      const result = await bee.execute(task);

      // Auto-retire ephemeral
      this._retireBee(id, 'ephemeral_complete');

      return result;
    } catch (err) {
      this._retireBee(id, 'ephemeral_error');
      throw err;
    }
  }

  /* ─────────────── Task Routing ─────────────── */

  /**
   * Route a task to the best available bee
   * @param {string} type - Preferred bee type
   * @param {object} task - Task to execute
   * @param {object} [context] - Context
   * @returns {object} Execution result
   */
  async route(type, task, context = {}) {
    this.stats.totalTasksRouted++;

    // Find an idle bee of the requested type
    let targetBee = this._findIdleBee(type);

    if (!targetBee) {
      // Try to find any idle bee in the same domain
      const domain = this.typeIndex.get(type);
      if (domain) {
        targetBee = this._findIdleBeeInDomain(domain);
      }
    }

    if (!targetBee) {
      // Create a new bee if possible
      try {
        targetBee = this.createBee(type);
      } catch {
        // Fall back to ephemeral spawn
        return this.spawnBee(type, task);
      }
    }

    return targetBee.execute(task, context);
  }

  /**
   * Find an idle bee of a specific type
   * @param {string} type - Bee type
   * @returns {Bee|null}
   */
  _findIdleBee(type) {
    for (const bee of this.bees.values()) {
      if (bee.type === type && bee.state === BEE_STATES.IDLE) {
        return bee;
      }
    }
    return null;
  }

  /**
   * Find an idle bee in a specific domain
   * @param {string} domain - Domain name
   * @returns {Bee|null}
   */
  _findIdleBeeInDomain(domain) {
    for (const bee of this.bees.values()) {
      if (bee.domain === domain && bee.state === BEE_STATES.IDLE) {
        return bee;
      }
    }
    return null;
  }

  /* ─────────────── Lifecycle Management ─────────────── */

  /**
   * Retire a bee
   * @param {string} id - Bee ID
   * @param {string} reason - Retirement reason
   */
  _retireBee(id, reason) {
    const bee = this.bees.get(id);
    if (!bee) return;

    bee.state = BEE_STATES.RETIRED;

    // Update counters
    this.domainCounts[bee.domain] = Math.max(0, (this.domainCounts[bee.domain] || 0) - 1);
    this.poolCounts[bee.pool] = Math.max(0, (this.poolCounts[bee.pool] || 0) - 1);

    // Record in history
    this.retiredHistory.push({
      id: bee.id,
      type: bee.type,
      domain: bee.domain,
      pool: bee.pool,
      reason,
      tasksCompleted: bee.tasksCompleted,
      tasksFailed: bee.tasksFailed,
      uptimeMs: Date.now() - bee.createdAt,
      retiredAt: Date.now(),
    });
    if (this.retiredHistory.length > this.maxRetiredHistory) {
      this.retiredHistory.shift();
    }

    this.bees.delete(id);
    this.stats.totalRetired++;

    logger.info({
      component: 'BeeFactory',
      action: 'bee_retired',
      id,
      type: bee.type,
      reason,
      tasksCompleted: bee.tasksCompleted,
      totalBees: this.bees.size,
    });
  }

  /**
   * Evict an idle bee from a pool
   * @param {string|null} pool - Pool to evict from (null = any)
   * @returns {boolean} True if evicted
   */
  _evictIdleBee(pool) {
    let oldestIdle = null;
    let oldestTime = Infinity;

    for (const bee of this.bees.values()) {
      if (bee.state !== BEE_STATES.IDLE) continue;
      if (pool && bee.pool !== pool) continue;
      if (bee.lastActiveAt < oldestTime) {
        oldestTime = bee.lastActiveAt;
        oldestIdle = bee;
      }
    }

    if (oldestIdle) {
      this._retireBee(oldestIdle.id, 'evicted_for_capacity');
      return true;
    }

    return false;
  }

  /**
   * Periodic health check — auto-retire error bees
   */
  _healthCheck() {
    const now = Date.now();
    const toRetire = [];

    for (const [id, bee] of this.bees) {
      // Auto-retire bees in error state
      if (bee.state === BEE_STATES.ERROR) {
        toRetire.push({ id, reason: 'max_failures_exceeded' });
        continue;
      }

      // Auto-retire idle bees that have been idle too long
      const maxIdleMs = POOL_TIERS[bee.pool]?.timeout_ms || fib(9) * 1000;
      if (bee.state === BEE_STATES.IDLE && (now - bee.lastActiveAt) > maxIdleMs * PHI2) {
        toRetire.push({ id, reason: 'idle_timeout' });
        continue;
      }

      // Auto-retire stuck working bees
      if (bee.state === BEE_STATES.WORKING) {
        const workTimeout = POOL_TIERS[bee.pool]?.timeout_ms || fib(9) * 1000;
        if ((now - bee.lastActiveAt) > workTimeout * PHI) {
          toRetire.push({ id, reason: 'work_timeout' });
        }
      }
    }

    for (const { id, reason } of toRetire) {
      this._retireBee(id, reason);
    }

    if (toRetire.length > 0) {
      logger.info({
        component: 'BeeFactory',
        action: 'health_check',
        retired: toRetire.length,
        activeBees: this.bees.size,
      });
    }
  }

  /* ─────────────── Query API ─────────────── */

  /**
   * Get a specific bee by ID
   * @param {string} id - Bee ID
   * @returns {Bee|null}
   */
  getBee(id) {
    return this.bees.get(id) || null;
  }

  /**
   * List bees by domain
   * @param {string} domain - Domain name
   * @returns {Array} Bees in domain
   */
  listByDomain(domain) {
    return [...this.bees.values()]
      .filter(b => b.domain === domain)
      .map(b => b.health());
  }

  /**
   * List bees by pool
   * @param {string} pool - Pool name
   * @returns {Array} Bees in pool
   */
  listByPool(pool) {
    return [...this.bees.values()]
      .filter(b => b.pool === pool)
      .map(b => b.health());
  }

  /**
   * List all registered bee types across all domains
   * @returns {Array} Type definitions
   */
  listTypes() {
    const types = [];
    for (const [domain, config] of Object.entries(DOMAIN_REGISTRY)) {
      for (const type of config.types) {
        types.push({
          type,
          domain,
          pool: config.pool,
          description: config.description,
          activeBees: [...this.bees.values()].filter(b => b.type === type).length,
        });
      }
    }
    return types;
  }

  /**
   * Get domain summary
   * @returns {object} Domain counts and status
   */
  getDomainSummary() {
    const summary = {};
    for (const [domain, config] of Object.entries(DOMAIN_REGISTRY)) {
      const domainBees = [...this.bees.values()].filter(b => b.domain === domain);
      summary[domain] = {
        pool: config.pool,
        typeCount: config.types.length,
        activeBees: domainBees.length,
        idleBees: domainBees.filter(b => b.state === BEE_STATES.IDLE).length,
        workingBees: domainBees.filter(b => b.state === BEE_STATES.WORKING).length,
        errorBees: domainBees.filter(b => b.state === BEE_STATES.ERROR).length,
      };
    }
    return summary;
  }

  /**
   * Get pool utilization
   * @returns {object} Pool usage stats
   */
  getPoolUtilization() {
    const utilization = {};
    for (const [name, tier] of Object.entries(POOL_TIERS)) {
      utilization[name] = {
        current: this.poolCounts[name] || 0,
        max: tier.maxBees,
        utilization: (this.poolCounts[name] || 0) / tier.maxBees,
        weight: tier.weight,
      };
    }
    return utilization;
  }

  /**
   * Get factory statistics
   * @returns {object}
   */
  getStats() {
    return {
      ...this.stats,
      activeBees: this.bees.size,
      maxBees: MAX_TOTAL_BEES,
      utilization: this.bees.size / MAX_TOTAL_BEES,
      pools: this.getPoolUtilization(),
      domains: Object.keys(DOMAIN_REGISTRY).length,
      registeredTypes: this.typeIndex.size,
    };
  }

  /**
   * Health check
   * @returns {object}
   */
  health() {
    return {
      service: 'bee-factory',
      status: this.bees.size < MAX_TOTAL_BEES ? 'healthy' : 'saturated',
      stats: this.getStats(),
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Graceful shutdown — retire all bees
   */
  async shutdown() {
    clearInterval(this._healthTimer);

    const beeIds = [...this.bees.keys()];
    for (const id of beeIds) {
      this._retireBee(id, 'factory_shutdown');
    }

    logger.info({
      component: 'BeeFactory',
      action: 'shutdown_complete',
      retired: beeIds.length,
    });
  }
}

module.exports = {
  BeeFactory,
  Bee,
  BEE_STATES,
  POOL_TIERS,
  DOMAIN_REGISTRY,
  MAX_TOTAL_BEES,
};
