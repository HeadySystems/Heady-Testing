/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ Bee Factory v2.0 — Dynamic Agent Worker Factory
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * Creates any type of bee on the fly at runtime. CSL-powered routing,
 * 24 domains, 197+ workers, support for createBee, spawnBee, routeBee,
 * createSwarm, and template-based generation.
 *
 * © 2026 HeadySystems Inc. — Eric Haywood
 */

'use strict';

const crypto = require('crypto');
const { PHI, PSI, fib, CSL_THRESHOLDS, cosineSimilarity, normalize, phiFusionWeights } = require('../../shared/phi-math');
const { resonanceGate, softGate, ternaryGate, routeGate, multiResonance,
  weightedSuperposition, consensusSuperposition, batchOrthogonal } = require('../../shared/csl-engine');
const { createLogger } = require('../../shared/logger');
const logger = createLogger('bee-factory-v2');

// ─── Registry ────────────────────────────────────────────────────────────────

const _dynamicRegistry = new Map();
const _ephemeralBees = new Map();
const _vecCache = new Map();
const VEC_DIM = 64; // Lightweight local dim; production uses 384D via HeadyEmbed

// ─── 24 Canonical Domains ────────────────────────────────────────────────────

const BEE_DOMAINS = Object.freeze([
  'deploy', 'battle', 'research', 'security', 'memory',
  'creative', 'trading', 'health', 'governance', 'documentation',
  'testing', 'migration', 'monitoring', 'cleanup', 'onboarding',
  'analytics', 'emergency', 'embedding', 'inference', 'scheduler',
  'notification', 'backup', 'rate-limiter', 'content-engine',
]);

// ─── Vector Helpers ──────────────────────────────────────────────────────────

function _domainToVec(text, dim = VEC_DIM) {
  if (_vecCache.has(text)) return _vecCache.get(text);
  const v = new Float64Array(dim);
  let hash = 5381;
  for (let i = 0; i < text.length; i++) {
    hash = ((hash << 5) + hash + text.charCodeAt(i)) >>> 0;
  }
  for (let i = 0; i < dim; i++) {
    hash = ((hash << 5) + hash + i) >>> 0;
    v[i] = ((hash % 2000) - 1000) / 1000;
  }
  const result = normalize(v);
  _vecCache.set(text, result);
  return result;
}

function _buildBeeVector(domain, description) {
  const domainVec = _domainToVec(domain);
  const descVec = _domainToVec(description || domain);
  return weightedSuperposition(domainVec, descVec, PSI);
}

// ─── Core API ────────────────────────────────────────────────────────────────

function createBee(domain, config = {}) {
  const {
    description = 'Dynamic ' + domain + ' bee',
    csl_relevance = 0.5,
    workers = [],
    persist = false,
    isSwarm = false,
  } = config;

  const vector = _buildBeeVector(domain, description);
  const relevanceClass = ternaryGate(csl_relevance, CSL_THRESHOLDS.MEDIUM, CSL_THRESHOLDS.LOW);

  const entry = {
    domain,
    description,
    csl_relevance,
    isSwarm,
    createdAt: Date.now(),
    dynamic: true,
    validated: true,
    file: 'dynamic:' + domain,
    vector,
    csl: {
      relevanceState: relevanceClass.state,
      relevanceActivation: relevanceClass.resonanceActivation,
    },
    getWork: (ctx = {}) => workers.map(w => {
      if (typeof w === 'function') return w;
      if (typeof w.fn === 'function') return async () => {
        try {
          const result = await w.fn(ctx);
          return { bee: domain, action: w.name || 'work', ...result };
        } catch (err) {
          return { bee: domain, action: w.name || 'work', error: err.message };
        }
      };
      return async () => ({ bee: domain, action: w.name || 'noop', status: 'no-handler' });
    }),
  };

  _dynamicRegistry.set(domain, entry);
  logger.info({ event: 'bee_created', domain, csl_relevance, isSwarm });
  return entry;
}

function spawnBee(name, work, csl_relevance = CSL_THRESHOLDS.MEDIUM) {
  const workFns = Array.isArray(work) ? work : [work];
  const id = 'ephemeral-' + name + '-' + crypto.randomBytes(3).toString('hex');
  const vector = _buildBeeVector(id, 'Ephemeral bee: ' + name);

  const entry = {
    domain: id,
    description: 'Ephemeral bee: ' + name,
    csl_relevance,
    ephemeral: true,
    createdAt: Date.now(),
    file: 'ephemeral:' + id,
    vector,
    csl: { relevanceState: ternaryGate(csl_relevance, CSL_THRESHOLDS.MEDIUM, CSL_THRESHOLDS.LOW).state },
    getWork: () => workFns.map(fn => async (ctx) => {
      const result = await fn(ctx);
      return { bee: id, action: name, ...(typeof result === 'object' ? result : { result }) };
    }),
  };

  _ephemeralBees.set(id, entry);
  logger.info({ event: 'bee_spawned', id, name, csl_relevance });
  return entry;
}

function routeBee(taskDescription, options = {}) {
  const { threshold = CSL_THRESHOLDS.LOW, exclude = [], topK = fib(4) } = options;
  let intentVec = _domainToVec(taskDescription);

  if (exclude.length > 0) {
    intentVec = batchOrthogonal(intentVec, exclude.map(e => _domainToVec(e)));
  }

  const allBees = [];
  for (const [, entry] of _dynamicRegistry) { if (entry.vector) allBees.push(entry); }
  for (const [, entry] of _ephemeralBees) { if (entry.vector) allBees.push(entry); }

  if (allBees.length === 0) {
    return { best: null, ranked: [], csl: { error: 'No bees registered' } };
  }

  const candidates = allBees.map(b => ({ id: b.domain, vector: b.vector }));
  const routeResult = routeGate(intentVec, candidates, threshold);

  const ranked = routeResult.scores.map(s => {
    const bee = allBees.find(b => b.domain === s.id);
    const relevanceActivation = softGate(bee.csl_relevance, 0.5, 10);
    const composite = s.score * PSI + relevanceActivation * (1 - PSI);
    return {
      domain: s.id, description: bee.description,
      resonance: s.score, activation: s.activation,
      csl_relevance: bee.csl_relevance,
      composite: +composite.toFixed(6),
    };
  }).sort((a, b) => b.composite - a.composite).slice(0, topK);

  return {
    best: ranked.length > 0 ? allBees.find(b => b.domain === ranked[0].domain) : null,
    ranked,
    csl: { intentDim: intentVec.length, candidatesScored: allBees.length, fallback: routeResult.fallback },
  };
}

function createSwarm(name, beeConfigs = [], policy = {}) {
  const { mode = 'parallel', requireConsensus = false, timeoutMs = Math.round(PHI * 18541) } = policy;

  const bees = beeConfigs.map(({ domain, config }) => createBee(domain, config || {}));
  const swarmIntentVec = _domainToVec(name);
  const beeVectors = bees.map(b => b.vector);
  const affinityScores = beeVectors.length > 0
    ? multiResonance(swarmIntentVec, beeVectors, CSL_THRESHOLDS.LOW)
    : [];
  const swarmVector = beeVectors.length > 0
    ? consensusSuperposition(beeVectors)
    : swarmIntentVec;

  const swarmBee = createBee('swarm-' + name, {
    description: 'Swarm: ' + name + ' (' + mode + ', ' + bees.length + ' bees, CSL-scored)',
    csl_relevance: 1.0,
    isSwarm: true,
    workers: [{
      name: 'orchestrate',
      fn: async (ctx = {}) => {
        const results = {};
        const startTime = Date.now();
        const orderedBees = affinityScores.length > 0
          ? affinityScores.map(s => bees[s.index])
          : bees;

        if (mode === 'parallel') {
          const settled = await Promise.allSettled(
            orderedBees.map(async (bee) => {
              const workFns = bee.getWork(ctx);
              const beeResults = [];
              for (const fn of workFns) {
                const result = await Promise.race([
                  fn(ctx),
                  new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), timeoutMs)),
                ]);
                beeResults.push(result);
              }
              return { domain: bee.domain, results: beeResults };
            })
          );
          for (const s of settled) {
            if (s.status === 'fulfilled') results[s.value.domain] = { status: 'ok', results: s.value.results };
            else results['error'] = { status: 'error', error: s.reason?.message };
          }
        } else {
          let pipelineCtx = { ...ctx };
          for (const bee of orderedBees) {
            try {
              const workFns = bee.getWork(pipelineCtx);
              const beeResults = [];
              for (const fn of workFns) {
                const result = await fn(pipelineCtx);
                beeResults.push(result);
                if (mode === 'pipeline' && typeof result === 'object') pipelineCtx = { ...pipelineCtx, ...result };
              }
              results[bee.domain] = { status: 'ok', results: beeResults };
            } catch (err) {
              results[bee.domain] = { status: 'error', error: err.message };
              if (requireConsensus) break;
            }
          }
        }
        return { swarm: name, mode, beeCount: bees.length, durationMs: Date.now() - startTime, results };
      },
    }],
  });

  swarmBee.vector = swarmVector;
  return swarmBee;
}

function createFromTemplate(template, config = {}) {
  const templates = {
    'health-check': (cfg) => ({
      domain: cfg.domain || 'health-' + cfg.target,
      description: 'Health checker for ' + cfg.target,
      csl_relevance: CSL_THRESHOLDS.HIGH,
      workers: [{
        name: 'probe', fn: async () => {
          const url = cfg.url || 'https://' + cfg.target + '/api/health';
          const start = Date.now();
          try {
            const res = await fetch(url, { signal: AbortSignal.timeout(cfg.timeout || 5000) });
            return { target: cfg.target, status: res.ok ? 'healthy' : 'degraded', latency: Date.now() - start };
          } catch (err) {
            return { target: cfg.target, status: 'down', error: err.message, latency: Date.now() - start };
          }
        },
      }],
    }),
    'monitor': (cfg) => ({
      domain: cfg.domain || 'monitor-' + cfg.target,
      description: 'Monitor for ' + cfg.target,
      csl_relevance: CSL_THRESHOLDS.MEDIUM,
      workers: [{
        name: 'metrics', fn: async () => {
          const mem = process.memoryUsage();
          return {
            target: cfg.target,
            heapUsedMB: Math.round(mem.heapUsed / 1048576 * 10) / 10,
            rssMB: Math.round(mem.rss / 1048576 * 10) / 10,
            uptimeSeconds: Math.round(process.uptime()),
            ts: Date.now(),
          };
        },
      }],
    }),
    'scanner': (cfg) => ({
      domain: cfg.domain || 'scanner-' + cfg.target,
      description: 'Scanner for ' + cfg.target,
      csl_relevance: CSL_THRESHOLDS.HIGH,
      workers: [{ name: 'scan', fn: cfg.scanFn || (async () => ({ scanned: cfg.target, findings: 0, ts: Date.now() })) }],
    }),
    'alerter': (cfg) => ({
      domain: cfg.domain || 'alerter-' + cfg.target,
      description: 'Threshold alerter for ' + cfg.target,
      csl_relevance: CSL_THRESHOLDS.CRITICAL,
      workers: [{
        name: 'check-thresholds', fn: async () => {
          const mem = process.memoryUsage();
          const heapPercent = (mem.heapUsed / mem.heapTotal) * 100;
          const alerts = [];
          if (heapPercent > (cfg.heapThreshold || fib(11))) {
            alerts.push({ type: 'heap', level: 'warning', value: heapPercent.toFixed(1) + '%' });
          }
          return { target: cfg.target, alerts, alertCount: alerts.length, ts: Date.now() };
        },
      }],
    }),
  };

  const templateFn = templates[template];
  if (!templateFn) throw new Error('Unknown bee template: ' + template + '. Available: ' + Object.keys(templates).join(', '));
  return createBee(config.domain || template + '-' + (config.target || config.name || 'dynamic'), templateFn(config));
}

function createWorkUnit(domain, name, fn) {
  const existing = _dynamicRegistry.get(domain);
  if (existing) {
    const oldGetWork = existing.getWork;
    existing.getWork = (ctx = {}) => {
      const work = oldGetWork(ctx);
      work.push(async () => {
        const result = await fn(ctx);
        return { bee: domain, action: name, ...(typeof result === 'object' ? result : { result }) };
      });
      return work;
    };
    return existing;
  }
  return createBee(domain, { workers: [{ name, fn }] });
}

function listDynamicBees() {
  const bees = [];
  for (const [id, entry] of _dynamicRegistry) {
    bees.push({ domain: id, description: entry.description, csl_relevance: entry.csl_relevance, type: 'dynamic', csl: entry.csl });
  }
  for (const [id, entry] of _ephemeralBees) {
    bees.push({ domain: id, description: entry.description, csl_relevance: entry.csl_relevance, type: 'ephemeral', csl: entry.csl });
  }
  return bees;
}

function dissolveBee(domain) {
  _dynamicRegistry.delete(domain);
  _ephemeralBees.delete(domain);
  _vecCache.delete(domain);
  logger.info({ event: 'bee_dissolved', domain });
}

module.exports = {
  createBee, spawnBee, routeBee, createWorkUnit,
  createFromTemplate, createSwarm, listDynamicBees, dissolveBee,
  BEE_DOMAINS,
  dynamicRegistry: _dynamicRegistry,
  ephemeralBees: _ephemeralBees,
  _domainToVec,
};
