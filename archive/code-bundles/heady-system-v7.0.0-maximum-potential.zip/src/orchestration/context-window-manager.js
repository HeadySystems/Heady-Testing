/**
 * Heady™ ContextWindowManager — Tiered Context & Token Budget Manager
 * 
 * Production-ready context management with:
 * - 4-tier context hierarchy (Working/Session/Memory/Artifacts)
 * - Phi-scaled token budgets per tier
 * - LLM-based compression when approaching limits
 * - Context capsules for inter-agent transfer
 * - Priority-based eviction with phi-weighted scoring
 * - Token counting and budget tracking
 * - Automatic tier promotion/demotion
 * 
 * All thresholds derived from φ (phi). Zero magic numbers.
 * Zero console.log — structured JSON logging only.
 * 
 * @module ContextWindowManager
 * @version 1.0.0
 * @author Eric Haywood
 */

'use strict';

const {
  PHI, PSI, PHI2,
  PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  phiThreshold, CSL_THRESHOLDS,
  phiFusionWeights, phiFusionScore,
  phiTokenBudgets, COMPRESSION_TRIGGER,
  EVICTION_WEIGHTS,
  SIZING,
  TIMING,
  cosineSimilarity,
  cslGate,
} = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');

const logger = createLogger('context-window-manager');

/* ─────────────────────── Constants ─────────────────────── */

/** Context tiers — phi-geometric scaling */
const TIERS = Object.freeze({
  WORKING:   { name: 'working',   level: 0, label: 'Hot' },
  SESSION:   { name: 'session',   level: 1, label: 'Warm' },
  MEMORY:    { name: 'memory',    level: 2, label: 'Cold' },
  ARTIFACTS: { name: 'artifacts', level: 3, label: 'Archive' },
});

/** Default base budget */
const DEFAULT_BASE_BUDGET = 8192;

/** Entry types */
const ENTRY_TYPES = Object.freeze({
  SYSTEM: 'system',
  USER: 'user',
  ASSISTANT: 'assistant',
  TOOL_RESULT: 'tool_result',
  CONTEXT: 'context',
  MEMORY: 'memory_recall',
});

/** Entry priority levels — aligns with CSL thresholds */
const PRIORITY = Object.freeze({
  CRITICAL: { level: 4, weight: phiThreshold(4) },  // ≈ 0.927
  HIGH:     { level: 3, weight: phiThreshold(3) },  // ≈ 0.882
  MEDIUM:   { level: 2, weight: phiThreshold(2) },  // ≈ 0.809
  LOW:      { level: 1, weight: phiThreshold(1) },  // ≈ 0.691
  MINIMUM:  { level: 0, weight: phiThreshold(0) },  // ≈ 0.500
});

/** Maximum entries per tier — Fibonacci-sized */
const MAX_ENTRIES = Object.freeze({
  working:   fib(9),  // 34
  session:   fib(11), // 89
  memory:    fib(13), // 233
  artifacts: fib(14), // 377
});

/** Token estimation: ~4 chars per token (English average) */
const CHARS_PER_TOKEN = 4;

/** Compression summary target ratio */
const COMPRESSION_RATIO = PSI; // ≈ 0.618 — compress to 61.8% of original

/** Memory retrieval defaults */
const MEMORY_RETRIEVAL_TOP_K = fib(5); // 5
const MEMORY_SIMILARITY_THRESHOLD = PSI; // ≈ 0.618

/** Maximum capsule size — Fibonacci tokens */
const MAX_CAPSULE_TOKENS = fib(16); // 987

/* ─────────────────────── Context Entry ─────────────────────── */

/**
 * A single context entry
 */
class ContextEntry {
  /**
   * @param {object} opts
   * @param {string} opts.content - Text content
   * @param {string} opts.type - Entry type
   * @param {string} [opts.role] - Message role
   * @param {string} [opts.priority] - Priority level name
   * @param {object} [opts.metadata] - Additional metadata
   */
  constructor(opts) {
    this.id = `ctx-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 2 + fib(4))}`;
    this.content = opts.content;
    this.type = opts.type || ENTRY_TYPES.CONTEXT;
    this.role = opts.role || null;
    this.priority = opts.priority || 'MEDIUM';
    this.metadata = opts.metadata || {};

    this.tokens = this._estimateTokens(opts.content);
    this.createdAt = Date.now();
    this.lastAccessedAt = Date.now();
    this.accessCount = 0;
    this.compressed = false;
    this.originalTokens = this.tokens;
  }

  /**
   * Estimate token count
   * @param {string} text - Input text
   * @returns {number} Estimated tokens
   */
  _estimateTokens(text) {
    if (!text) return 0;
    return Math.ceil(text.length / CHARS_PER_TOKEN);
  }

  /**
   * Mark as accessed
   */
  touch() {
    this.lastAccessedAt = Date.now();
    this.accessCount++;
  }

  /**
   * Compute eviction score (lower = more likely to evict)
   * Uses phi-weighted fusion of importance, recency, relevance
   * @param {number} [relevanceScore] - External relevance score
   * @returns {number} Eviction score 0-1
   */
  evictionScore(relevanceScore = null) {
    const now = Date.now();

    // Importance — based on priority level and access count
    const priorityWeight = PRIORITY[this.priority]?.weight || PRIORITY.MEDIUM.weight;
    const accessFactor = Math.min(1, this.accessCount / fib(7)); // 13 access cap
    const importance = priorityWeight * PSI + accessFactor * (1 - PSI);

    // Recency — phi-decay from last access
    const ageMs = now - this.lastAccessedAt;
    const decayHalfLife = fib(12) * 1000; // 144 seconds
    const recency = Math.exp(-ageMs / (decayHalfLife * PHI));

    // Relevance — external score or default
    const relevance = relevanceScore !== null ? relevanceScore : PSI;

    // Phi-weighted fusion
    return phiFusionScore(
      [importance, recency, relevance],
      [EVICTION_WEIGHTS.importance, EVICTION_WEIGHTS.recency, EVICTION_WEIGHTS.relevance]
    );
  }
}

/* ─────────────────────── Context Window Manager ─────────────────────── */

/**
 * ContextWindowManager — Tiered Context Management
 * 
 * Manages a multi-tier context window with automatic compression,
 * eviction, and inter-agent context transfer via capsules.
 */
class ContextWindowManager {
  /**
   * @param {object} opts
   * @param {number} [opts.baseBudget] - Base token budget (default 8192)
   * @param {object} [opts.vectorMemory] - HeadyMemory for semantic retrieval
   * @param {object} [opts.embedder] - HeadyEmbed for generating query embeddings
   * @param {Function} [opts.compressor] - LLM summarization function(text) => summary
   */
  constructor(opts = {}) {
    this.baseBudget = opts.baseBudget || DEFAULT_BASE_BUDGET;
    this.vectorMemory = opts.vectorMemory || null;
    this.embedder = opts.embedder || null;
    this.compressor = opts.compressor || null;

    /** Compute phi-scaled budgets */
    const budgets = phiTokenBudgets(this.baseBudget);
    this.budgets = {
      working:   budgets.working,
      session:   budgets.session,
      memory:    budgets.memory,
      artifacts: budgets.artifacts,
    };

    /** Context tiers — each is an ordered array of ContextEntry */
    this.tiers = {
      working:   [],
      session:   [],
      memory:    [],
      artifacts: [], // Handles only — not actual content
    };

    /** Token usage per tier */
    this.tokenUsage = {
      working:   0,
      session:   0,
      memory:    0,
      artifacts: 0,
    };

    /** Statistics */
    this.stats = {
      totalEntries: 0,
      totalTokens: 0,
      compressions: 0,
      evictions: 0,
      promotions: 0,
      demotions: 0,
      capsulesSent: 0,
      capsulesReceived: 0,
    };

    logger.info({
      component: 'ContextWindowManager',
      action: 'initialized',
      budgets: this.budgets,
    });
  }

  /* ─────────────── Entry Management ─────────────── */

  /**
   * Add a context entry to the working tier
   * Automatically triggers compression/eviction if budget exceeded
   * @param {string} content - Text content
   * @param {object} [opts] - Entry options
   * @param {string} [opts.type] - Entry type
   * @param {string} [opts.role] - Message role
   * @param {string} [opts.priority] - Priority level
   * @param {object} [opts.metadata] - Metadata
   * @returns {ContextEntry} Added entry
   */
  async add(content, opts = {}) {
    const entry = new ContextEntry({
      content,
      type: opts.type || ENTRY_TYPES.CONTEXT,
      role: opts.role,
      priority: opts.priority || 'MEDIUM',
      metadata: opts.metadata,
    });

    // Check if adding this entry would exceed working budget
    if (this.tokenUsage.working + entry.tokens > this.budgets.working) {
      await this._handleOverflow('working');
    }

    // Add to working tier
    this.tiers.working.push(entry);
    this.tokenUsage.working += entry.tokens;
    this.stats.totalEntries++;
    this.stats.totalTokens += entry.tokens;

    // Check capacity limit
    if (this.tiers.working.length > MAX_ENTRIES.working) {
      await this._evictLowest('working');
    }

    // Check compression trigger
    const utilization = this.tokenUsage.working / this.budgets.working;
    if (utilization >= COMPRESSION_TRIGGER) {
      await this._compress('working');
    }

    logger.info({
      component: 'ContextWindowManager',
      action: 'entry_added',
      tier: 'working',
      tokens: entry.tokens,
      totalTokens: this.tokenUsage.working,
      budget: this.budgets.working,
      utilization: (this.tokenUsage.working / this.budgets.working).toFixed(3),
    });

    return entry;
  }

  /**
   * Get all entries in the working context (for LLM prompt assembly)
   * @returns {Array<ContextEntry>} Working context entries
   */
  getWorkingContext() {
    // Touch all entries
    for (const entry of this.tiers.working) {
      entry.touch();
    }
    return [...this.tiers.working];
  }

  /**
   * Get the current token usage summary
   * @returns {object} Usage per tier
   */
  getUsage() {
    const usage = {};
    for (const tier of Object.keys(this.tiers)) {
      usage[tier] = {
        tokens: this.tokenUsage[tier],
        budget: this.budgets[tier],
        utilization: this.budgets[tier] > 0 ? this.tokenUsage[tier] / this.budgets[tier] : 0,
        entries: this.tiers[tier].length,
        maxEntries: MAX_ENTRIES[tier],
      };
    }
    return usage;
  }

  /* ─────────────── Overflow & Compression ─────────────── */

  /**
   * Handle tier overflow — demote entries to next tier
   * @param {string} tierName - Overflowing tier
   */
  async _handleOverflow(tierName) {
    const tier = this.tiers[tierName];
    if (tier.length === 0) return;

    const nextTierName = this._getNextTier(tierName);
    if (!nextTierName) {
      // At the bottom tier — just evict
      await this._evictLowest(tierName);
      return;
    }

    // Find the lowest-scored entry
    let lowestIdx = 0;
    let lowestScore = Infinity;

    for (let i = 0; i < tier.length; i++) {
      const score = tier[i].evictionScore();
      if (score < lowestScore) {
        lowestScore = score;
        lowestIdx = i;
      }
    }

    // Demote to next tier
    const [demoted] = tier.splice(lowestIdx, 1);
    this.tokenUsage[tierName] -= demoted.tokens;

    // If demoting to artifacts, store only a handle
    if (nextTierName === 'artifacts') {
      const handle = new ContextEntry({
        content: `[Archived: ${demoted.id}] ${demoted.content.slice(0, fib(9))}...`,
        type: demoted.type,
        priority: 'MINIMUM',
        metadata: { originalId: demoted.id, originalTokens: demoted.tokens },
      });
      this.tiers.artifacts.push(handle);
      this.tokenUsage.artifacts += handle.tokens;
    } else {
      this.tiers[nextTierName].push(demoted);
      this.tokenUsage[nextTierName] += demoted.tokens;
    }

    this.stats.demotions++;

    logger.info({
      component: 'ContextWindowManager',
      action: 'entry_demoted',
      from: tierName,
      to: nextTierName,
      entryId: demoted.id,
      tokens: demoted.tokens,
    });

    // Check if next tier also overflowing
    if (this.tokenUsage[nextTierName] > this.budgets[nextTierName]) {
      await this._handleOverflow(nextTierName);
    }
  }

  /**
   * Compress entries in a tier using LLM summarization
   * @param {string} tierName - Tier to compress
   */
  async _compress(tierName) {
    if (!this.compressor) {
      // No compressor available — fall back to eviction
      await this._evictLowest(tierName);
      return;
    }

    const tier = this.tiers[tierName];
    if (tier.length <= 1) return;

    // Find compressible entries (non-critical, non-system)
    const compressible = tier.filter(e =>
      !e.compressed &&
      e.priority !== 'CRITICAL' &&
      e.type !== ENTRY_TYPES.SYSTEM
    );

    if (compressible.length === 0) {
      await this._evictLowest(tierName);
      return;
    }

    // Group compressible entries by type
    const toCompress = compressible
      .sort((a, b) => a.evictionScore() - b.evictionScore())
      .slice(0, fib(6)); // Compress up to 8 at a time

    if (toCompress.length <= 1) return;

    // Combine and compress
    const combinedText = toCompress.map(e => e.content).join('\n\n');

    try {
      const summary = await this.compressor(combinedText);
      const summaryTokens = Math.ceil(summary.length / CHARS_PER_TOKEN);

      // Remove original entries
      for (const entry of toCompress) {
        const idx = tier.indexOf(entry);
        if (idx >= 0) {
          tier.splice(idx, 1);
          this.tokenUsage[tierName] -= entry.tokens;
        }
      }

      // Add compressed entry
      const compressed = new ContextEntry({
        content: summary,
        type: ENTRY_TYPES.CONTEXT,
        priority: 'MEDIUM',
        metadata: {
          compressed: true,
          originalEntries: toCompress.length,
          originalTokens: toCompress.reduce((sum, e) => sum + e.tokens, 0),
        },
      });
      compressed.compressed = true;

      tier.push(compressed);
      this.tokenUsage[tierName] += compressed.tokens;
      this.stats.compressions++;

      logger.info({
        component: 'ContextWindowManager',
        action: 'compressed',
        tier: tierName,
        entriesCompressed: toCompress.length,
        tokensBefore: toCompress.reduce((sum, e) => sum + e.tokens, 0),
        tokensAfter: compressed.tokens,
        ratio: (compressed.tokens / toCompress.reduce((sum, e) => sum + e.tokens, 0)).toFixed(3),
      });
    } catch (err) {
      logger.error({
        component: 'ContextWindowManager',
        action: 'compression_failed',
        tier: tierName,
        error: err.message,
      });
      // Fall back to eviction
      await this._evictLowest(tierName);
    }
  }

  /**
   * Evict the lowest-scored entry from a tier
   * @param {string} tierName - Tier name
   */
  async _evictLowest(tierName) {
    const tier = this.tiers[tierName];
    if (tier.length === 0) return;

    let lowestIdx = 0;
    let lowestScore = Infinity;

    for (let i = 0; i < tier.length; i++) {
      // Never evict system messages
      if (tier[i].type === ENTRY_TYPES.SYSTEM) continue;
      if (tier[i].priority === 'CRITICAL') continue;

      const score = tier[i].evictionScore();
      if (score < lowestScore) {
        lowestScore = score;
        lowestIdx = i;
      }
    }

    const [evicted] = tier.splice(lowestIdx, 1);
    this.tokenUsage[tierName] -= evicted.tokens;
    this.stats.evictions++;

    logger.info({
      component: 'ContextWindowManager',
      action: 'entry_evicted',
      tier: tierName,
      entryId: evicted.id,
      tokens: evicted.tokens,
      score: lowestScore,
    });
  }

  /* ─────────────── Memory Retrieval ─────────────── */

  /**
   * Retrieve relevant memories and inject into working context
   * @param {string} query - Query text
   * @param {number} [topK] - Number of memories to retrieve
   * @returns {Array} Retrieved memory entries
   */
  async retrieveMemories(query, topK = MEMORY_RETRIEVAL_TOP_K) {
    if (!this.vectorMemory) return [];

    try {
      const results = await this.vectorMemory.search(query, {
        topK,
        threshold: MEMORY_SIMILARITY_THRESHOLD,
        namespace: 'conversation',
      });

      const entries = [];
      for (const result of results) {
        const entry = await this.add(result.content || result.text, {
          type: ENTRY_TYPES.MEMORY,
          priority: result.score >= CSL_THRESHOLDS.HIGH ? 'HIGH' : 'MEDIUM',
          metadata: { source: 'memory', score: result.score },
        });
        entries.push(entry);
      }

      return entries;
    } catch (err) {
      logger.error({
        component: 'ContextWindowManager',
        action: 'memory_retrieval_failed',
        error: err.message,
      });
      return [];
    }
  }

  /* ─────────────── Context Capsules ─────────────── */

  /**
   * Create a context capsule for inter-agent transfer
   * @param {object} opts
   * @param {string} opts.targetAgent - Target agent identifier
   * @param {number} [opts.maxTokens] - Max capsule tokens
   * @param {boolean} [opts.includeSystem] - Include system messages
   * @param {boolean} [opts.summarize] - Summarize if over budget
   * @returns {object} Context capsule
   */
  async createCapsule(opts = {}) {
    const maxTokens = opts.maxTokens || MAX_CAPSULE_TOKENS;
    const includeSystem = opts.includeSystem !== false;
    const summarize = opts.summarize !== false;

    // Collect entries from working and session tiers
    const candidates = [
      ...(includeSystem ? this.tiers.working.filter(e => e.type === ENTRY_TYPES.SYSTEM) : []),
      ...this.tiers.working.filter(e => e.type !== ENTRY_TYPES.SYSTEM),
      ...this.tiers.session,
    ];

    // Sort by eviction score descending (most important first)
    candidates.sort((a, b) => b.evictionScore() - a.evictionScore());

    // Select entries within budget
    const selected = [];
    let totalTokens = 0;

    for (const entry of candidates) {
      if (totalTokens + entry.tokens <= maxTokens) {
        selected.push(entry);
        totalTokens += entry.tokens;
      }
    }

    // If over budget and summarization available, compress
    let capsuleContent;
    if (totalTokens > maxTokens && summarize && this.compressor) {
      const combined = selected.map(e => e.content).join('\n\n');
      capsuleContent = await this.compressor(combined);
    } else {
      capsuleContent = selected.map(e => ({
        content: e.content,
        type: e.type,
        role: e.role,
        priority: e.priority,
      }));
    }

    const capsule = {
      capsuleId: `capsule-${Date.now().toString(36)}`,
      targetAgent: opts.targetAgent,
      entries: capsuleContent,
      totalTokens: typeof capsuleContent === 'string'
        ? Math.ceil(capsuleContent.length / CHARS_PER_TOKEN)
        : totalTokens,
      createdAt: Date.now(),
      source: 'context-window-manager',
      metadata: {
        workingEntries: this.tiers.working.length,
        sessionEntries: this.tiers.session.length,
        selectedEntries: selected.length,
      },
    };

    this.stats.capsulesSent++;

    logger.info({
      component: 'ContextWindowManager',
      action: 'capsule_created',
      capsuleId: capsule.capsuleId,
      targetAgent: opts.targetAgent,
      entries: selected.length,
      tokens: capsule.totalTokens,
    });

    return capsule;
  }

  /**
   * Receive and inject a context capsule
   * @param {object} capsule - Context capsule
   */
  async receiveCapsule(capsule) {
    if (!capsule || !capsule.entries) return;

    const entries = Array.isArray(capsule.entries) ? capsule.entries : [{ content: capsule.entries }];

    for (const entry of entries) {
      await this.add(entry.content, {
        type: entry.type || ENTRY_TYPES.CONTEXT,
        role: entry.role,
        priority: entry.priority || 'MEDIUM',
        metadata: {
          source: 'capsule',
          capsuleId: capsule.capsuleId,
          sourceAgent: capsule.source,
        },
      });
    }

    this.stats.capsulesReceived++;

    logger.info({
      component: 'ContextWindowManager',
      action: 'capsule_received',
      capsuleId: capsule.capsuleId,
      entries: entries.length,
    });
  }

  /* ─────────────── Tier Navigation ─────────────── */

  /**
   * Get next lower tier name
   * @param {string} tierName - Current tier
   * @returns {string|null} Next tier or null
   */
  _getNextTier(tierName) {
    const order = ['working', 'session', 'memory', 'artifacts'];
    const idx = order.indexOf(tierName);
    return idx >= 0 && idx < order.length - 1 ? order[idx + 1] : null;
  }

  /**
   * Get next higher tier name
   * @param {string} tierName - Current tier
   * @returns {string|null} Previous tier or null
   */
  _getPrevTier(tierName) {
    const order = ['working', 'session', 'memory', 'artifacts'];
    const idx = order.indexOf(tierName);
    return idx > 0 ? order[idx - 1] : null;
  }

  /* ─────────────── Query API ─────────────── */

  /**
   * Search across all tiers for entries matching a query
   * @param {string} query - Search query
   * @param {number} [limit] - Max results
   * @returns {Array} Matching entries
   */
  search(query, limit = fib(7)) {
    const queryLower = query.toLowerCase();
    const results = [];

    for (const [tierName, tier] of Object.entries(this.tiers)) {
      for (const entry of tier) {
        if (entry.content.toLowerCase().includes(queryLower)) {
          results.push({
            entry,
            tier: tierName,
            score: entry.evictionScore(),
          });
        }
      }
    }

    return results
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  /**
   * Clear all context
   */
  clear() {
    for (const tier of Object.keys(this.tiers)) {
      this.tiers[tier] = [];
      this.tokenUsage[tier] = 0;
    }

    logger.info({ component: 'ContextWindowManager', action: 'cleared' });
  }

  /**
   * Get context statistics
   * @returns {object}
   */
  getStats() {
    return {
      ...this.stats,
      usage: this.getUsage(),
      totalActiveTokens: Object.values(this.tokenUsage).reduce((a, b) => a + b, 0),
      totalActiveEntries: Object.values(this.tiers).reduce((a, b) => a + b.length, 0),
    };
  }

  /**
   * Health check
   * @returns {object}
   */
  health() {
    const usage = this.getUsage();
    const workingUtil = usage.working.utilization;

    let status = 'healthy';
    if (workingUtil >= COMPRESSION_TRIGGER) {
      status = 'pressure';
    }
    if (workingUtil >= 1) {
      status = 'overflow';
    }

    return {
      service: 'context-window-manager',
      status,
      usage,
      stats: this.stats,
      timestamp: new Date().toISOString(),
    };
  }
}

module.exports = {
  ContextWindowManager,
  ContextEntry,
  TIERS,
  PRIORITY,
  ENTRY_TYPES,
  MAX_ENTRIES,
};
