/**
 * ═══════════════════════════════════════════════════════════════════════════════
 * Heady™ HCFullPipeline v2.0 — 21-Stage Cognitive State Machine
 * ═══════════════════════════════════════════════════════════════════════════════
 *
 * The nervous system of Heady™. All critical tasks flow through this pipeline.
 * 21 stages = fib(8) — Sacred Geometry aligned.
 *
 * Pipeline Variants:
 * - Fast Path:     0→1→2→7→12→13→20 (LOW risk, pre-approved)
 * - Full Path:     All 21 stages (HIGH/CRITICAL or novel)
 * - Arena Path:    0→1→2→3→4→8→9→10→20 (competitive eval)
 * - Learning Path: 0→1→16→17→18→19→20 (continuous improvement)
 *
 * © 2026 HeadySystems Inc. — Eric Haywood
 */

'use strict';

const crypto = require('crypto');
const { PHI, PSI, fib, CSL_THRESHOLDS, HCFP_STAGES, phiBackoff } = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');
const logger = createLogger('hcfull-pipeline');

const STAGE_TIMEOUT_MS = {
  CHANNEL_ENTRY:    fib(8) * 1000,  // 21s
  RECON:            fib(9) * 1000,  // 34s
  INTAKE:           fib(8) * 1000,  // 21s
  CLASSIFY:         fib(7) * 1000,  // 13s
  TRIAGE:           fib(7) * 1000,  // 13s
  DECOMPOSE:        fib(9) * 1000,  // 34s
  TRIAL_AND_ERROR:  fib(10) * 1000, // 55s
  ORCHESTRATE:      fib(9) * 1000,  // 34s
  MONTE_CARLO:      fib(10) * 1000, // 55s
  ARENA:            fib(10) * 1000, // 55s
  JUDGE:            fib(8) * 1000,  // 21s
  APPROVE:          fib(12) * 1000, // 144s (human gate)
  EXECUTE:          fib(11) * 1000, // 89s
  VERIFY:           fib(9) * 1000,  // 34s
  SELF_AWARENESS:   fib(8) * 1000,  // 21s
  SELF_CRITIQUE:    fib(8) * 1000,  // 21s
  MISTAKE_ANALYSIS: fib(8) * 1000,  // 21s
  OPTIMIZATION_OPS: fib(9) * 1000,  // 34s
  CONTINUOUS_SEARCH: fib(9) * 1000, // 34s
  EVOLUTION:        fib(9) * 1000,  // 34s
  RECEIPT:          fib(7) * 1000,  // 13s
};

const PIPELINE_VARIANTS = Object.freeze({
  FAST:     [0, 1, 2, 7, 12, 13, 20],
  FULL:     HCFP_STAGES.map((_, i) => i),
  ARENA:    [0, 1, 2, 3, 4, 8, 9, 10, 20],
  LEARNING: [0, 1, 16, 17, 18, 19, 20],
});

const PIPELINE_STATUS = Object.freeze({
  PENDING: 'pending', RUNNING: 'running', COMPLETED: 'completed',
  FAILED: 'failed', CANCELLED: 'cancelled',
});

class HCFullPipeline {
  constructor(opts = {}) {
    this._stageHandlers = new Map();
    this._runs = new Map();
    this._maxRetries = fib(4);  // 3
    this._stats = { started: 0, completed: 0, failed: 0, avgDurationMs: 0, totalDurationMs: 0 };

    // Register default stage handlers
    for (const stage of HCFP_STAGES) {
      this._stageHandlers.set(stage, opts.handlers?.[stage] || _defaultHandler(stage));
    }

    logger.info({ event: 'hcfp_init', stages: HCFP_STAGES.length, variants: Object.keys(PIPELINE_VARIANTS) });
  }

  async execute(task, variant = 'FULL') {
    const runId = crypto.randomUUID();
    const stageIndices = PIPELINE_VARIANTS[variant] || PIPELINE_VARIANTS.FULL;
    const stages = stageIndices.map(i => HCFP_STAGES[i]);

    const run = {
      id: runId, task, variant, stages,
      status: PIPELINE_STATUS.RUNNING,
      currentStage: null, stageResults: {},
      startedAt: Date.now(), completedAt: null,
      error: null,
    };

    this._runs.set(runId, run);
    this._stats.started++;

    logger.info({ event: 'hcfp_start', runId, variant, stageCount: stages.length, taskType: task.type });

    try {
      for (const stage of stages) {
        run.currentStage = stage;
        const handler = this._stageHandlers.get(stage);
        const timeout = STAGE_TIMEOUT_MS[stage] || fib(9) * 1000;

        let result;
        let lastError;
        for (let attempt = 0; attempt <= this._maxRetries; attempt++) {
          try {
            result = await Promise.race([
              handler(task, run),
              new Promise((_, reject) => setTimeout(() => reject(new Error('Stage timeout: ' + stage)), timeout)),
            ]);
            break;
          } catch (err) {
            lastError = err;
            if (attempt < this._maxRetries) {
              const delay = phiBackoff(attempt);
              logger.warn({ event: 'hcfp_stage_retry', runId, stage, attempt, delay });
              await new Promise(r => setTimeout(r, delay));
            }
          }
        }

        if (!result && lastError) {
          throw new Error('Stage ' + stage + ' failed after ' + this._maxRetries + ' retries: ' + lastError.message);
        }

        run.stageResults[stage] = { result, completedAt: Date.now() };
      }

      run.status = PIPELINE_STATUS.COMPLETED;
      run.completedAt = Date.now();
      const duration = run.completedAt - run.startedAt;
      this._stats.completed++;
      this._stats.totalDurationMs += duration;
      this._stats.avgDurationMs = Math.round(this._stats.totalDurationMs / this._stats.completed);

      logger.info({ event: 'hcfp_complete', runId, variant, durationMs: duration });
      return run;

    } catch (err) {
      run.status = PIPELINE_STATUS.FAILED;
      run.error = err.message;
      run.completedAt = Date.now();
      this._stats.failed++;

      logger.error({ event: 'hcfp_failed', runId, stage: run.currentStage, error: err.message });
      throw err;
    }
  }

  registerHandler(stage, handler) {
    if (!HCFP_STAGES.includes(stage)) throw new Error('Unknown stage: ' + stage);
    this._stageHandlers.set(stage, handler);
    return this;
  }

  getRun(runId) { return this._runs.get(runId) || null; }

  getStatus() {
    return {
      totalStages: HCFP_STAGES.length,
      variants: Object.keys(PIPELINE_VARIANTS),
      activeRuns: Array.from(this._runs.values()).filter(r => r.status === PIPELINE_STATUS.RUNNING).length,
      stats: { ...this._stats },
    };
  }

  cancel(runId) {
    const run = this._runs.get(runId);
    if (run && run.status === PIPELINE_STATUS.RUNNING) {
      run.status = PIPELINE_STATUS.CANCELLED;
      run.completedAt = Date.now();
      return true;
    }
    return false;
  }
}

function _defaultHandler(stage) {
  return async (task, run) => {
    return { stage, processed: true, taskId: task.id || 'unknown', ts: Date.now() };
  };
}

module.exports = {
  HCFullPipeline, HCFP_STAGES, PIPELINE_VARIANTS, PIPELINE_STATUS, STAGE_TIMEOUT_MS,
};
