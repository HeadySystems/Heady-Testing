/**
 * Heady™ HeadyManager — HTTP/MCP Server & JSON-RPC Transport
 * 
 * Production-ready management server with:
 * - JSON-RPC 2.0 request handling
 * - Server-Sent Events (SSE) streaming
 * - MCP (Model Context Protocol) compatible tool interface
 * - Health/readiness/liveness probes
 * - Request validation and rate limiting
 * - Structured JSON logging with request tracing
 * - httpOnly cookie session management
 * - Zero localStorage tokens
 * 
 * All thresholds derived from φ (phi). Zero magic numbers.
 * Zero console.log — structured JSON logging only.
 * 
 * @module HeadyManager
 * @version 1.0.0
 * @author Eric Haywood
 */

'use strict';

const http = require('http');
const { URL } = require('url');
const crypto = require('crypto');
const {
  PHI, PSI,
  fib,
  phiThreshold, CSL_THRESHOLDS,
  phiBackoff,
  SIZING,
  TIMING,
  SERVICE_PORTS,
} = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');

const logger = createLogger('heady-manager');

/* ─────────────────────── Constants ─────────────────────── */

/** Server configuration */
const CONFIG = Object.freeze({
  PORT: SERVICE_PORTS?.MANAGER || 3310,
  HOST: '0.0.0.0',
  MAX_BODY_SIZE: fib(17) * 1024,      // 1597 KB
  REQUEST_TIMEOUT_MS: fib(9) * 1000,   // 34 seconds
  KEEP_ALIVE_TIMEOUT_MS: fib(10) * 1000, // 55 seconds
  MAX_HEADERS_COUNT: fib(11),           // 89
  SSE_HEARTBEAT_MS: fib(9) * 1000,     // 34 seconds
  MAX_SSE_CLIENTS: fib(12),            // 144
  MAX_CONCURRENT_REQUESTS: fib(13),     // 233
});

/** JSON-RPC error codes */
const RPC_ERRORS = Object.freeze({
  PARSE_ERROR: -32700,
  INVALID_REQUEST: -32600,
  METHOD_NOT_FOUND: -32601,
  INVALID_PARAMS: -32602,
  INTERNAL_ERROR: -32603,
  SERVER_ERROR: -32000,
  RATE_LIMITED: -32029,
  UNAUTHORIZED: -32001,
  FORBIDDEN: -32003,
});

/** Rate limit windows — phi-scaled */
const RATE_LIMIT = Object.freeze({
  WINDOW_MS: fib(10) * 1000,          // 55 seconds
  MAX_REQUESTS: fib(14),               // 377 per window
  BURST_LIMIT: fib(11),                // 89 immediate burst
});

/** Cookie settings */
const COOKIE_CONFIG = Object.freeze({
  NAME: '__Host-heady_session',
  MAX_AGE_S: fib(17) * 60,             // 1597 minutes ≈ 26.6 hours
  SAME_SITE: 'Strict',
  HTTP_ONLY: true,
  SECURE: true,
  PATH: '/',
});

/** CORS configuration */
const CORS_ORIGINS = Object.freeze([
  'https://headyme.com',
  'https://headysystems.com',
  'https://heady-ai.com',
  'https://headyos.com',
  'https://headyconnection.org',
  'https://headyconnection.com',
  'https://headyex.com',
  'https://headyfinance.com',
  'https://admin.headysystems.com',
]);

/* ─────────────────────── Helpers ─────────────────────── */

/**
 * Generate a unique request ID
 * @returns {string}
 */
function generateRequestId() {
  return `req-${Date.now().toString(36)}-${crypto.randomBytes(fib(5)).toString('hex')}`;
}

/**
 * Parse JSON body from request
 * @param {http.IncomingMessage} req - HTTP request
 * @param {number} maxSize - Maximum body size in bytes
 * @returns {Promise<object>} Parsed body
 */
function parseBody(req, maxSize) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;

    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > maxSize) {
        req.destroy();
        reject(new Error('Request body too large'));
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => {
      const body = Buffer.concat(chunks).toString('utf-8');
      if (!body) {
        resolve(null);
        return;
      }
      try {
        resolve(JSON.parse(body));
      } catch {
        reject(new Error('Invalid JSON'));
      }
    });

    req.on('error', reject);
  });
}

/**
 * Set CORS headers
 * @param {http.ServerResponse} res - HTTP response
 * @param {string} origin - Request origin
 */
function setCorsHeaders(res, origin) {
  if (CORS_ORIGINS.includes(origin)) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Request-Id');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Max-Age', String(fib(12))); // 144 seconds
  }
}

/**
 * Set security headers
 * @param {http.ServerResponse} res - HTTP response
 */
function setSecurityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '0');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Content-Security-Policy', "default-src 'none'; frame-ancestors 'none'");
  res.setHeader('Strict-Transport-Security', `max-age=${fib(20)}; includeSubDomains; preload`); // 6765 seconds
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Pragma', 'no-cache');
}

/**
 * Send JSON response
 * @param {http.ServerResponse} res - HTTP response
 * @param {number} status - HTTP status code
 * @param {object} body - Response body
 */
function sendJson(res, status, body) {
  const json = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(json),
  });
  res.end(json);
}

/**
 * Create JSON-RPC response
 * @param {*} id - Request ID
 * @param {*} result - Result data
 * @returns {object}
 */
function rpcResponse(id, result) {
  return { jsonrpc: '2.0', id, result };
}

/**
 * Create JSON-RPC error response
 * @param {*} id - Request ID
 * @param {number} code - Error code
 * @param {string} message - Error message
 * @param {*} [data] - Additional data
 * @returns {object}
 */
function rpcError(id, code, message, data = undefined) {
  return { jsonrpc: '2.0', id, error: { code, message, data } };
}

/* ─────────────────────── Rate Limiter ─────────────────────── */

/**
 * In-memory sliding window rate limiter
 */
class RateLimiter {
  constructor() {
    /** Client windows: IP → {requests: [], burstCount} */
    this.windows = new Map();
    this.maxWindowSize = fib(16); // 987 tracked clients

    // Cleanup interval
    this._cleanupTimer = setInterval(() => this._cleanup(), RATE_LIMIT.WINDOW_MS);
  }

  /**
   * Check if request is allowed
   * @param {string} clientId - Client identifier (IP or session)
   * @returns {object} {allowed: boolean, remaining: number, retryAfterMs: number}
   */
  check(clientId) {
    const now = Date.now();
    const windowStart = now - RATE_LIMIT.WINDOW_MS;

    if (!this.windows.has(clientId)) {
      if (this.windows.size >= this.maxWindowSize) {
        // Evict oldest
        const oldest = this.windows.keys().next().value;
        this.windows.delete(oldest);
      }
      this.windows.set(clientId, { requests: [], burstCount: 0 });
    }

    const client = this.windows.get(clientId);

    // Prune old requests
    client.requests = client.requests.filter(ts => ts > windowStart);

    if (client.requests.length >= RATE_LIMIT.MAX_REQUESTS) {
      const oldestInWindow = client.requests[0];
      const retryAfterMs = oldestInWindow + RATE_LIMIT.WINDOW_MS - now;
      return {
        allowed: false,
        remaining: 0,
        retryAfterMs: Math.max(0, retryAfterMs),
      };
    }

    client.requests.push(now);
    return {
      allowed: true,
      remaining: RATE_LIMIT.MAX_REQUESTS - client.requests.length,
      retryAfterMs: 0,
    };
  }

  _cleanup() {
    const cutoff = Date.now() - RATE_LIMIT.WINDOW_MS * 2;
    for (const [id, client] of this.windows) {
      if (client.requests.length === 0 || client.requests[client.requests.length - 1] < cutoff) {
        this.windows.delete(id);
      }
    }
  }

  destroy() {
    clearInterval(this._cleanupTimer);
    this.windows.clear();
  }
}

/* ─────────────────────── SSE Manager ─────────────────────── */

/**
 * Server-Sent Events connection manager
 */
class SSEManager {
  constructor() {
    /** Active SSE clients */
    this.clients = new Map();
    this.maxClients = CONFIG.MAX_SSE_CLIENTS;

    // Heartbeat interval
    this._heartbeatTimer = setInterval(() => this._heartbeat(), CONFIG.SSE_HEARTBEAT_MS);
  }

  /**
   * Register a new SSE client
   * @param {string} clientId - Client identifier
   * @param {http.ServerResponse} res - Response stream
   * @param {string[]} [channels] - Subscribed channels
   * @returns {boolean} True if registered
   */
  register(clientId, res, channels = ['*']) {
    if (this.clients.size >= this.maxClients) {
      return false;
    }

    // Set SSE headers
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    });

    // Send initial connection event
    res.write(`event: connected\ndata: ${JSON.stringify({ clientId, channels })}\n\n`);

    this.clients.set(clientId, {
      res,
      channels: new Set(channels),
      connectedAt: Date.now(),
      messagesSent: 0,
    });

    res.on('close', () => {
      this.clients.delete(clientId);
      logger.info({
        component: 'SSEManager',
        action: 'client_disconnected',
        clientId,
      });
    });

    logger.info({
      component: 'SSEManager',
      action: 'client_connected',
      clientId,
      channels,
      totalClients: this.clients.size,
    });

    return true;
  }

  /**
   * Send event to specific client
   * @param {string} clientId - Target client
   * @param {string} event - Event name
   * @param {object} data - Event data
   */
  sendTo(clientId, event, data) {
    const client = this.clients.get(clientId);
    if (!client) return;

    try {
      client.res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
      client.messagesSent++;
    } catch (err) {
      this.clients.delete(clientId);
      logger.error({
        component: 'SSEManager',
        action: 'send_failed',
        clientId,
        error: err.message,
      });
    }
  }

  /**
   * Broadcast event to channel subscribers
   * @param {string} channel - Channel name
   * @param {string} event - Event name
   * @param {object} data - Event data
   */
  broadcast(channel, event, data) {
    for (const [clientId, client] of this.clients) {
      if (client.channels.has('*') || client.channels.has(channel)) {
        this.sendTo(clientId, event, data);
      }
    }
  }

  _heartbeat() {
    for (const [clientId, client] of this.clients) {
      try {
        client.res.write(`:heartbeat ${Date.now()}\n\n`);
      } catch {
        this.clients.delete(clientId);
      }
    }
  }

  getStats() {
    return {
      activeClients: this.clients.size,
      maxClients: this.maxClients,
      clients: [...this.clients.entries()].map(([id, c]) => ({
        id,
        channels: [...c.channels],
        messagesSent: c.messagesSent,
        connectedAt: new Date(c.connectedAt).toISOString(),
      })),
    };
  }

  destroy() {
    clearInterval(this._heartbeatTimer);
    for (const [, client] of this.clients) {
      try { client.res.end(); } catch { /* closed */ }
    }
    this.clients.clear();
  }
}

/* ─────────────────────── MCP Tool Registry ─────────────────────── */

/**
 * MCP-compatible tool registry
 */
class ToolRegistry {
  constructor() {
    this.tools = new Map();
  }

  /**
   * Register a tool
   * @param {string} name - Tool name
   * @param {object} schema - JSON Schema for parameters
   * @param {Function} handler - Async handler function
   * @param {object} [opts] - Tool options
   */
  register(name, schema, handler, opts = {}) {
    this.tools.set(name, {
      name,
      description: opts.description || '',
      inputSchema: schema,
      handler,
      category: opts.category || 'general',
      requiresAuth: opts.requiresAuth !== false,
      timeout_ms: opts.timeout_ms || CONFIG.REQUEST_TIMEOUT_MS,
    });

    logger.info({ component: 'ToolRegistry', action: 'tool_registered', name, category: opts.category });
  }

  /**
   * Execute a tool
   * @param {string} name - Tool name
   * @param {object} params - Tool parameters
   * @param {object} context - Execution context
   * @returns {object} Tool result
   */
  async execute(name, params, context) {
    const tool = this.tools.get(name);
    if (!tool) {
      throw { code: RPC_ERRORS.METHOD_NOT_FOUND, message: `Tool not found: ${name}` };
    }

    // Timeout wrapper
    const result = await Promise.race([
      tool.handler(params, context),
      new Promise((_, reject) =>
        setTimeout(() => reject({ code: RPC_ERRORS.INTERNAL_ERROR, message: 'Tool execution timeout' }), tool.timeout_ms)
      ),
    ]);

    return result;
  }

  /**
   * List all registered tools (MCP tools/list format)
   * @returns {Array} Tool definitions
   */
  list() {
    return [...this.tools.values()].map(t => ({
      name: t.name,
      description: t.description,
      inputSchema: t.inputSchema,
      category: t.category,
    }));
  }
}

/* ─────────────────────── HeadyManager Server ─────────────────────── */

/**
 * HeadyManager — HTTP/MCP Management Server
 * 
 * Central management server providing JSON-RPC transport,
 * SSE streaming, MCP tool execution, and health probes.
 */
class HeadyManager {
  /**
   * @param {object} opts
   * @param {object} [opts.conductor] - HeadyConductor for task routing
   * @param {object} [opts.auth] - Auth service for session validation
   * @param {number} [opts.port] - Override port
   */
  constructor(opts = {}) {
    this.conductor = opts.conductor || null;
    this.auth = opts.auth || null;
    this.port = opts.port || CONFIG.PORT;

    /** Core subsystems */
    this.rateLimiter = new RateLimiter();
    this.sseManager = new SSEManager();
    this.toolRegistry = new ToolRegistry();

    /** HTTP server */
    this.server = null;

    /** Request tracking */
    this.activeRequests = 0;
    this.maxConcurrent = CONFIG.MAX_CONCURRENT_REQUESTS;

    /** Statistics */
    this.stats = {
      totalRequests: 0,
      totalErrors: 0,
      totalRpcCalls: 0,
      totalToolCalls: 0,
      startedAt: null,
      uptimeMs: 0,
    };

    // Register built-in tools
    this._registerBuiltInTools();

    logger.info({ component: 'HeadyManager', action: 'initialized', port: this.port });
  }

  /* ─────────────── Server Lifecycle ─────────────── */

  /**
   * Start the HTTP server
   * @returns {Promise<void>}
   */
  async start() {
    return new Promise((resolve, reject) => {
      this.server = http.createServer((req, res) => this._handleRequest(req, res));

      this.server.maxHeadersCount = CONFIG.MAX_HEADERS_COUNT;
      this.server.keepAliveTimeout = CONFIG.KEEP_ALIVE_TIMEOUT_MS;
      this.server.headersTimeout = CONFIG.REQUEST_TIMEOUT_MS;

      this.server.on('error', (err) => {
        logger.error({ component: 'HeadyManager', action: 'server_error', error: err.message });
        reject(err);
      });

      this.server.listen(this.port, CONFIG.HOST, () => {
        this.stats.startedAt = Date.now();
        logger.info({
          component: 'HeadyManager',
          action: 'server_started',
          port: this.port,
          host: CONFIG.HOST,
        });
        resolve();
      });
    });
  }

  /**
   * Graceful shutdown
   * @param {number} [graceMs] - Grace period
   */
  async stop(graceMs = fib(7) * 1000) {
    logger.info({ component: 'HeadyManager', action: 'shutdown_start', graceMs });

    // Stop accepting new connections
    this.server?.close();

    // Close SSE clients
    this.sseManager.destroy();

    // Wait for active requests to drain
    const deadline = Date.now() + graceMs;
    while (this.activeRequests > 0 && Date.now() < deadline) {
      await new Promise(r => setTimeout(r, fib(5) * 100)); // 500ms poll
    }

    // Cleanup
    this.rateLimiter.destroy();

    this.stats.uptimeMs = Date.now() - (this.stats.startedAt || Date.now());

    logger.info({
      component: 'HeadyManager',
      action: 'shutdown_complete',
      uptimeMs: this.stats.uptimeMs,
      totalRequests: this.stats.totalRequests,
    });
  }

  /* ─────────────── Request Handler ─────────────── */

  /**
   * Main HTTP request handler
   * @param {http.IncomingMessage} req
   * @param {http.ServerResponse} res
   */
  async _handleRequest(req, res) {
    const requestId = req.headers['x-request-id'] || generateRequestId();
    const startTime = Date.now();
    const origin = req.headers.origin || '';
    const clientIp = req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.socket.remoteAddress;

    // Set common headers
    setSecurityHeaders(res);
    setCorsHeaders(res, origin);
    res.setHeader('X-Request-Id', requestId);

    // Handle CORS preflight
    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }

    // Concurrent request limit
    if (this.activeRequests >= this.maxConcurrent) {
      sendJson(res, 503, rpcError(null, RPC_ERRORS.SERVER_ERROR, 'Server overloaded'));
      return;
    }

    // Rate limiting
    const rateCheck = this.rateLimiter.check(clientIp);
    res.setHeader('X-RateLimit-Remaining', String(rateCheck.remaining));
    if (!rateCheck.allowed) {
      res.setHeader('Retry-After', String(Math.ceil(rateCheck.retryAfterMs / 1000)));
      sendJson(res, 429, rpcError(null, RPC_ERRORS.RATE_LIMITED, 'Rate limit exceeded'));
      return;
    }

    this.activeRequests++;
    this.stats.totalRequests++;

    try {
      const url = new URL(req.url, `http://${req.headers.host}`);
      const path = url.pathname;

      // Route to handler
      switch (true) {
        case path === '/health' || path === '/healthz':
          await this._handleHealth(req, res);
          break;
        case path === '/ready' || path === '/readyz':
          await this._handleReady(req, res);
          break;
        case path === '/live' || path === '/livez':
          await this._handleLive(req, res);
          break;
        case path === '/rpc' && req.method === 'POST':
          await this._handleRpc(req, res, requestId, clientIp);
          break;
        case path === '/sse' && req.method === 'GET':
          await this._handleSse(req, res, requestId, clientIp);
          break;
        case path === '/mcp/tools/list' && req.method === 'GET':
          await this._handleToolsList(req, res);
          break;
        case path === '/mcp/tools/call' && req.method === 'POST':
          await this._handleToolCall(req, res, requestId, clientIp);
          break;
        case path === '/stats' && req.method === 'GET':
          await this._handleStats(req, res);
          break;
        default:
          sendJson(res, 404, rpcError(null, RPC_ERRORS.METHOD_NOT_FOUND, `Not found: ${path}`));
      }
    } catch (err) {
      this.stats.totalErrors++;
      logger.error({
        component: 'HeadyManager',
        action: 'request_error',
        requestId,
        error: err.message,
        stack: err.stack,
      });
      if (!res.headersSent) {
        sendJson(res, 500, rpcError(null, RPC_ERRORS.INTERNAL_ERROR, 'Internal server error'));
      }
    } finally {
      this.activeRequests--;
      const duration = Date.now() - startTime;
      logger.info({
        component: 'HeadyManager',
        action: 'request_complete',
        requestId,
        method: req.method,
        path: req.url,
        status: res.statusCode,
        duration_ms: duration,
        clientIp,
      });
    }
  }

  /* ─────────────── JSON-RPC Handler ─────────────── */

  /**
   * Handle JSON-RPC 2.0 requests
   */
  async _handleRpc(req, res, requestId, clientIp) {
    const body = await parseBody(req, CONFIG.MAX_BODY_SIZE);

    if (!body) {
      sendJson(res, 400, rpcError(null, RPC_ERRORS.PARSE_ERROR, 'Empty request body'));
      return;
    }

    // Batch support
    if (Array.isArray(body)) {
      const results = await Promise.all(
        body.slice(0, fib(8)).map(rpcReq => this._processRpcRequest(rpcReq, requestId, clientIp))
      );
      sendJson(res, 200, results);
      return;
    }

    // Single request
    const result = await this._processRpcRequest(body, requestId, clientIp);

    // Notification (no id) — no response
    if (body.id === undefined || body.id === null) {
      res.writeHead(204);
      res.end();
      return;
    }

    sendJson(res, result.error ? 400 : 200, result);
  }

  /**
   * Process a single JSON-RPC request
   * @param {object} rpcReq - JSON-RPC request
   * @param {string} requestId - HTTP request ID
   * @param {string} clientIp - Client IP
   * @returns {object} JSON-RPC response
   */
  async _processRpcRequest(rpcReq, requestId, clientIp) {
    this.stats.totalRpcCalls++;

    // Validate JSON-RPC structure
    if (rpcReq.jsonrpc !== '2.0') {
      return rpcError(rpcReq.id, RPC_ERRORS.INVALID_REQUEST, 'Invalid JSON-RPC version');
    }
    if (!rpcReq.method || typeof rpcReq.method !== 'string') {
      return rpcError(rpcReq.id, RPC_ERRORS.INVALID_REQUEST, 'Missing or invalid method');
    }

    // Route to method handler
    const method = rpcReq.method;
    const params = rpcReq.params || {};

    try {
      // Check if it's a registered tool
      if (this.toolRegistry.tools.has(method)) {
        const result = await this.toolRegistry.execute(method, params, { requestId, clientIp });
        return rpcResponse(rpcReq.id, result);
      }

      // Built-in RPC methods
      switch (method) {
        case 'heady.ping':
          return rpcResponse(rpcReq.id, { pong: true, timestamp: Date.now() });

        case 'heady.health':
          return rpcResponse(rpcReq.id, this.health());

        case 'heady.stats':
          return rpcResponse(rpcReq.id, this.getStats());

        case 'heady.tools.list':
          return rpcResponse(rpcReq.id, { tools: this.toolRegistry.list() });

        case 'heady.conductor.dispatch':
          if (!this.conductor) {
            return rpcError(rpcReq.id, RPC_ERRORS.SERVER_ERROR, 'Conductor not available');
          }
          const dispatchResult = await this.conductor.dispatch(params);
          return rpcResponse(rpcReq.id, dispatchResult);

        default:
          return rpcError(rpcReq.id, RPC_ERRORS.METHOD_NOT_FOUND, `Method not found: ${method}`);
      }
    } catch (err) {
      const code = err.code || RPC_ERRORS.INTERNAL_ERROR;
      const message = err.message || 'Internal error';
      return rpcError(rpcReq.id, code, message);
    }
  }

  /* ─────────────── SSE Handler ─────────────── */

  /**
   * Handle SSE connection
   */
  async _handleSse(req, res, requestId, clientIp) {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const channels = url.searchParams.get('channels')?.split(',') || ['*'];

    const registered = this.sseManager.register(requestId, res, channels);
    if (!registered) {
      sendJson(res, 503, { error: 'SSE connections at capacity' });
    }
    // SSE connection stays open — no res.end()
  }

  /* ─────────────── MCP Tool Handlers ─────────────── */

  /**
   * Handle MCP tools/list
   */
  async _handleToolsList(req, res) {
    sendJson(res, 200, { tools: this.toolRegistry.list() });
  }

  /**
   * Handle MCP tools/call
   */
  async _handleToolCall(req, res, requestId, clientIp) {
    const body = await parseBody(req, CONFIG.MAX_BODY_SIZE);

    if (!body || !body.name) {
      sendJson(res, 400, { error: 'Missing tool name' });
      return;
    }

    this.stats.totalToolCalls++;

    try {
      const result = await this.toolRegistry.execute(body.name, body.arguments || {}, { requestId, clientIp });
      sendJson(res, 200, {
        content: [{ type: 'text', text: typeof result === 'string' ? result : JSON.stringify(result) }],
        isError: false,
      });
    } catch (err) {
      sendJson(res, 200, {
        content: [{ type: 'text', text: err.message }],
        isError: true,
      });
    }
  }

  /* ─────────────── Health Probes ─────────────── */

  async _handleHealth(req, res) {
    sendJson(res, 200, this.health());
  }

  async _handleReady(req, res) {
    const ready = this.conductor !== null || true; // Ready if initialized
    sendJson(res, ready ? 200 : 503, {
      status: ready ? 'ready' : 'not_ready',
      timestamp: new Date().toISOString(),
    });
  }

  async _handleLive(req, res) {
    sendJson(res, 200, { status: 'alive', timestamp: new Date().toISOString() });
  }

  async _handleStats(req, res) {
    sendJson(res, 200, this.getStats());
  }

  /* ─────────────── Built-in Tools ─────────────── */

  /**
   * Register built-in MCP tools
   */
  _registerBuiltInTools() {
    // Ping tool
    this.toolRegistry.register('heady_ping', {
      type: 'object',
      properties: {},
    }, async () => ({ pong: true, timestamp: Date.now() }), {
      description: 'Ping the Heady system',
      requiresAuth: false,
    });

    // Health tool
    this.toolRegistry.register('heady_health', {
      type: 'object',
      properties: {
        service: { type: 'string', description: 'Specific service to check' },
      },
    }, async (params) => this.health(), {
      description: 'Check Heady system health',
      requiresAuth: false,
    });

    // SSE broadcast tool
    this.toolRegistry.register('heady_broadcast', {
      type: 'object',
      properties: {
        channel: { type: 'string', description: 'Channel to broadcast to' },
        event: { type: 'string', description: 'Event name' },
        data: { type: 'object', description: 'Event data' },
      },
      required: ['channel', 'event', 'data'],
    }, async (params) => {
      this.sseManager.broadcast(params.channel, params.event, params.data);
      return { sent: true, clients: this.sseManager.clients.size };
    }, {
      description: 'Broadcast event to SSE clients',
      category: 'messaging',
    });

    // Tool list (MCP meta)
    this.toolRegistry.register('heady_tools_list', {
      type: 'object',
      properties: {},
    }, async () => ({ tools: this.toolRegistry.list() }), {
      description: 'List all available tools',
      requiresAuth: false,
    });

    logger.info({
      component: 'HeadyManager',
      action: 'built_in_tools_registered',
      count: this.toolRegistry.tools.size,
    });
  }

  /* ─────────────── Public API ─────────────── */

  /**
   * Register a custom tool
   * @param {string} name - Tool name
   * @param {object} schema - Input schema
   * @param {Function} handler - Handler function
   * @param {object} [opts] - Options
   */
  registerTool(name, schema, handler, opts = {}) {
    this.toolRegistry.register(name, schema, handler, opts);
  }

  /**
   * Broadcast an event to SSE clients
   * @param {string} channel - Channel
   * @param {string} event - Event name
   * @param {object} data - Data
   */
  broadcast(channel, event, data) {
    this.sseManager.broadcast(channel, event, data);
  }

  /**
   * Get server statistics
   * @returns {object}
   */
  getStats() {
    return {
      ...this.stats,
      uptimeMs: this.stats.startedAt ? Date.now() - this.stats.startedAt : 0,
      activeRequests: this.activeRequests,
      sseClients: this.sseManager.clients.size,
      registeredTools: this.toolRegistry.tools.size,
      rateLimitWindows: this.rateLimiter.windows.size,
    };
  }

  /**
   * Health check
   * @returns {object}
   */
  health() {
    return {
      service: 'heady-manager',
      status: 'healthy',
      version: '1.0.0',
      port: this.port,
      stats: this.getStats(),
      conductor: this.conductor ? 'connected' : 'disconnected',
      timestamp: new Date().toISOString(),
    };
  }
}

module.exports = {
  HeadyManager,
  ToolRegistry,
  SSEManager,
  RateLimiter,
  RPC_ERRORS,
  COOKIE_CONFIG,
  CONFIG,
};
