/**
 * Heady™ HeadyBattle — Arena Mode Competitive Evaluation Engine
 * 
 * Production-ready competitive evaluation with:
 * - Multi-configuration arena matchups
 * - Parallel execution of competing solutions
 * - Phi-weighted multi-dimensional scoring
 * - ELO-style rating system for persistent node ranking
 * - Statistical significance testing
 * - Automated winner selection with confidence scoring
 * - Tournament bracket generation
 * - Historical performance tracking
 * 
 * All thresholds derived from φ (phi). Zero magic numbers.
 * Zero console.log — structured JSON logging only.
 * 
 * @module HeadyBattle
 * @version 1.0.0
 * @author Eric Haywood
 */

'use strict';

const {
  PHI, PSI, PHI2, PHI3,
  PSI_SQ, PSI_CUBE,
  fib,
  phiThreshold, CSL_THRESHOLDS,
  phiFusionWeights, phiFusionScore,
  phiBackoff,
  SIZING,
  TIMING,
  cosineSimilarity,
  cslGate,
} = require('../../shared/phi-math');
const { createLogger } = require('../../shared/logger');

const logger = createLogger('heady-battle');

/* ─────────────────────── Constants ─────────────────────── */

/** Arena modes */
const ARENA_MODES = Object.freeze({
  HEAD_TO_HEAD: 'head_to_head',
  ROUND_ROBIN: 'round_robin',
  TOURNAMENT: 'tournament',
  FREE_FOR_ALL: 'free_for_all',
});

/** Scoring dimensions */
const SCORING_DIMENSIONS = Object.freeze({
  QUALITY: 'quality',
  SPEED: 'speed',
  COST: 'cost',
  CORRECTNESS: 'correctness',
  CREATIVITY: 'creativity',
  SAFETY: 'safety',
});

/** Dimension weights — phi-fusion for 6 dimensions */
const DIMENSION_WEIGHTS = Object.freeze({
  [SCORING_DIMENSIONS.QUALITY]: PHI3 / (PHI3 + PHI2 + PHI + 1 + PSI + PSI_SQ),       // ≈ 0.382
  [SCORING_DIMENSIONS.CORRECTNESS]: PHI2 / (PHI3 + PHI2 + PHI + 1 + PSI + PSI_SQ),    // ≈ 0.236
  [SCORING_DIMENSIONS.SAFETY]: PHI / (PHI3 + PHI2 + PHI + 1 + PSI + PSI_SQ),           // ≈ 0.146
  [SCORING_DIMENSIONS.SPEED]: 1 / (PHI3 + PHI2 + PHI + 1 + PSI + PSI_SQ),              // ≈ 0.090
  [SCORING_DIMENSIONS.COST]: PSI / (PHI3 + PHI2 + PHI + 1 + PSI + PSI_SQ),             // ≈ 0.056
  [SCORING_DIMENSIONS.CREATIVITY]: PSI_SQ / (PHI3 + PHI2 + PHI + 1 + PSI + PSI_SQ),   // ≈ 0.034
});

/** ELO constants — phi-derived */
const ELO = Object.freeze({
  INITIAL_RATING: fib(16),     // 987
  K_FACTOR: fib(8) * PSI,     // 21 × 0.618 ≈ 12.978
  K_FACTOR_NEW: fib(8),       // 21 (higher K for new/unrated contestants)
  RATING_FLOOR: fib(12),      // 144
  GAMES_FOR_ESTABLISHED: fib(7), // 13 games before considered established
});

/** Maximum concurrent battles */
const MAX_CONCURRENT = fib(6); // 8

/** Battle timeout — phi-scaled */
const BATTLE_TIMEOUT_MS = fib(9) * 1000; // 34 seconds

/** Maximum contestants per battle */
const MAX_CONTESTANTS = fib(8); // 21

/** Confidence threshold for auto-declaring winner */
const CONFIDENCE_THRESHOLD = CSL_THRESHOLDS.HIGH; // ≈ 0.882

/** Statistical significance threshold */
const SIGNIFICANCE_THRESHOLD = 1 - PSI; // ≈ 0.382 (p-value threshold)

/** History ring buffer size */
const MAX_HISTORY = fib(12); // 144

/* ─────────────────────── Types ─────────────────────── */

/**
 * @typedef {object} Contestant
 * @property {string} id - Unique contestant ID
 * @property {string} name - Display name
 * @property {object} config - Configuration for this contestant
 * @property {Function} executor - Async function to execute the task
 * @property {number} rating - Current ELO rating
 * @property {number} gamesPlayed - Total games played
 * @property {number} wins - Total wins
 * @property {number} losses - Total losses
 * @property {number} draws - Total draws
 */

/**
 * @typedef {object} BattleResult
 * @property {string} battleId - Unique battle ID
 * @property {string} mode - Arena mode used
 * @property {string} winnerId - Winner contestant ID (null if draw)
 * @property {Array} scores - Per-contestant scores
 * @property {number} confidence - Winner confidence 0-1
 * @property {number} duration_ms - Total battle time
 * @property {object} dimensionBreakdown - Scores per dimension
 */

/* ─────────────────────── Battle Engine ─────────────────────── */

/**
 * HeadyBattle — Arena Mode Competitive Evaluation
 * 
 * Pits multiple node configurations against each other to find
 * optimal solutions through competitive evaluation.
 */
class HeadyBattle {
  /**
   * @param {object} opts
   * @param {object} [opts.conductor] - HeadyConductor for dispatching work
   * @param {object} [opts.vectorMemory] - HeadyMemory for storing results
   * @param {object} [opts.patterns] - HeadyPatterns for learning from results
   * @param {object} [opts.judge] - External judge function for quality scoring
   */
  constructor(opts = {}) {
    this.conductor = opts.conductor || null;
    this.vectorMemory = opts.vectorMemory || null;
    this.patterns = opts.patterns || null;
    this.judge = opts.judge || null;

    /** Contestant registry */
    this.contestants = new Map();

    /** Active battles */
    this.activeBattles = new Map();

    /** Battle history — Fibonacci-sized ring buffer */
    this.history = [];
    this.maxHistory = MAX_HISTORY;

    /** ELO leaderboard */
    this.leaderboard = new Map();

    /** Statistics */
    this.stats = {
      totalBattles: 0,
      totalRounds: 0,
      averageDuration: 0,
      decisiveRate: 0, // percentage with clear winner
    };

    logger.info({ component: 'HeadyBattle', action: 'initialized' });
  }

  /* ─────────────── Contestant Management ─────────────── */

  /**
   * Register a contestant for battles
   * @param {string} id - Unique ID
   * @param {string} name - Display name
   * @param {object} config - Contestant configuration
   * @param {Function} executor - Async function(task, config) => result
   * @returns {object} Registered contestant
   */
  registerContestant(id, name, config, executor) {
    if (typeof executor !== 'function') {
      throw new Error(`Contestant ${id}: executor must be a function`);
    }

    const contestant = {
      id,
      name,
      config,
      executor,
      rating: this.leaderboard.get(id)?.rating || ELO.INITIAL_RATING,
      gamesPlayed: this.leaderboard.get(id)?.gamesPlayed || 0,
      wins: this.leaderboard.get(id)?.wins || 0,
      losses: this.leaderboard.get(id)?.losses || 0,
      draws: this.leaderboard.get(id)?.draws || 0,
      registeredAt: Date.now(),
    };

    this.contestants.set(id, contestant);

    if (!this.leaderboard.has(id)) {
      this.leaderboard.set(id, {
        id,
        name,
        rating: ELO.INITIAL_RATING,
        gamesPlayed: 0,
        wins: 0,
        losses: 0,
        draws: 0,
      });
    }

    logger.info({
      component: 'HeadyBattle',
      action: 'contestant_registered',
      id,
      name,
      rating: contestant.rating,
    });

    return contestant;
  }

  /**
   * Unregister a contestant
   * @param {string} id - Contestant ID
   */
  unregisterContestant(id) {
    this.contestants.delete(id);
    logger.info({ component: 'HeadyBattle', action: 'contestant_unregistered', id });
  }

  /* ─────────────── Battle Execution ─────────────── */

  /**
   * Run an arena battle
   * @param {object} task - The task to compete on
   * @param {string[]} contestantIds - IDs of contestants to include
   * @param {object} [opts] - Battle options
   * @param {string} [opts.mode] - Arena mode (default: head_to_head)
   * @param {object} [opts.dimensionWeights] - Custom dimension weights
   * @param {number} [opts.rounds] - Number of rounds (for tournament/round_robin)
   * @param {number} [opts.timeoutMs] - Custom timeout per execution
   * @returns {object} Battle result
   */
  async battle(task, contestantIds, opts = {}) {
    const mode = opts.mode || ARENA_MODES.HEAD_TO_HEAD;
    const timeoutMs = opts.timeoutMs || BATTLE_TIMEOUT_MS;
    const dimensionWeights = opts.dimensionWeights || DIMENSION_WEIGHTS;
    const battleId = `battle-${Date.now()}-${Math.random().toString(36).slice(2, 2 + fib(5))}`;

    // Validate contestants
    const contestants = contestantIds
      .map(id => this.contestants.get(id))
      .filter(Boolean);

    if (contestants.length < 2) {
      throw new Error('Battle requires at least 2 registered contestants');
    }
    if (contestants.length > MAX_CONTESTANTS) {
      throw new Error(`Maximum ${MAX_CONTESTANTS} contestants per battle`);
    }

    logger.info({
      component: 'HeadyBattle',
      action: 'battle_start',
      battleId,
      mode,
      contestants: contestants.length,
    });

    this.activeBattles.set(battleId, {
      startTime: Date.now(),
      mode,
      contestants: contestantIds,
      status: 'running',
    });

    let result;
    try {
      switch (mode) {
        case ARENA_MODES.HEAD_TO_HEAD:
          result = await this._headToHead(battleId, task, contestants, dimensionWeights, timeoutMs);
          break;
        case ARENA_MODES.ROUND_ROBIN:
          result = await this._roundRobin(battleId, task, contestants, dimensionWeights, timeoutMs, opts.rounds);
          break;
        case ARENA_MODES.TOURNAMENT:
          result = await this._tournament(battleId, task, contestants, dimensionWeights, timeoutMs);
          break;
        case ARENA_MODES.FREE_FOR_ALL:
          result = await this._freeForAll(battleId, task, contestants, dimensionWeights, timeoutMs);
          break;
        default:
          throw new Error(`Unknown arena mode: ${mode}`);
      }

      // Update ELO ratings
      this._updateRatings(result);

      // Record in history
      this._recordHistory(result);

      // Store in vector memory for pattern learning
      if (this.vectorMemory) {
        await this._storeResult(result);
      }

      // Notify patterns engine
      if (this.patterns) {
        await this._notifyPatterns(result);
      }

      logger.info({
        component: 'HeadyBattle',
        action: 'battle_complete',
        battleId,
        winnerId: result.winnerId,
        confidence: result.confidence,
        duration_ms: result.duration_ms,
      });
    } finally {
      this.activeBattles.delete(battleId);
    }

    return result;
  }

  /* ─────────────── Head-to-Head ─────────────── */

  /**
   * Run a head-to-head battle (2 contestants, 1 round)
   */
  async _headToHead(battleId, task, contestants, dimensionWeights, timeoutMs) {
    const startTime = Date.now();
    const [a, b] = contestants.slice(0, 2);

    // Execute both in parallel
    const [resultA, resultB] = await Promise.all([
      this._executeWithTimeout(a, task, timeoutMs),
      this._executeWithTimeout(b, task, timeoutMs),
    ]);

    // Score both
    const scoreA = await this._scoreResult(resultA, task, dimensionWeights);
    const scoreB = await this._scoreResult(resultB, task, dimensionWeights);

    // Determine winner
    const { winnerId, confidence } = this._determineWinner(
      [{ id: a.id, score: scoreA }, { id: b.id, score: scoreB }]
    );

    return {
      battleId,
      mode: ARENA_MODES.HEAD_TO_HEAD,
      winnerId,
      confidence,
      duration_ms: Date.now() - startTime,
      scores: [
        { contestantId: a.id, name: a.name, totalScore: scoreA.total, dimensions: scoreA.dimensions },
        { contestantId: b.id, name: b.name, totalScore: scoreB.total, dimensions: scoreB.dimensions },
      ],
      dimensionBreakdown: this._buildDimensionBreakdown([
        { id: a.id, score: scoreA },
        { id: b.id, score: scoreB },
      ]),
      rounds: 1,
    };
  }

  /* ─────────────── Round Robin ─────────────── */

  /**
   * Round robin — every contestant faces every other
   */
  async _roundRobin(battleId, task, contestants, dimensionWeights, timeoutMs, rounds = 1) {
    const startTime = Date.now();
    const matchResults = [];
    const winCounts = {};

    for (const c of contestants) winCounts[c.id] = 0;

    // Generate all pairs
    const pairs = [];
    for (let i = 0; i < contestants.length; i++) {
      for (let j = i + 1; j < contestants.length; j++) {
        pairs.push([contestants[i], contestants[j]]);
      }
    }

    // Execute each pair
    for (let round = 0; round < rounds; round++) {
      for (const [a, b] of pairs) {
        const [resultA, resultB] = await Promise.all([
          this._executeWithTimeout(a, task, timeoutMs),
          this._executeWithTimeout(b, task, timeoutMs),
        ]);

        const scoreA = await this._scoreResult(resultA, task, dimensionWeights);
        const scoreB = await this._scoreResult(resultB, task, dimensionWeights);

        const { winnerId } = this._determineWinner([
          { id: a.id, score: scoreA },
          { id: b.id, score: scoreB },
        ]);

        if (winnerId) {
          winCounts[winnerId]++;
        }

        matchResults.push({
          round: round + 1,
          contestants: [a.id, b.id],
          scores: [scoreA.total, scoreB.total],
          winnerId,
        });
      }
    }

    // Overall winner by win count
    const sorted = Object.entries(winCounts).sort((a, b) => b[1] - a[1]);
    const overallWinnerId = sorted[0][1] > sorted[1][1] ? sorted[0][0] : null;
    const confidence = sorted[0][1] > 0
      ? sorted[0][1] / (pairs.length * rounds)
      : 0;

    return {
      battleId,
      mode: ARENA_MODES.ROUND_ROBIN,
      winnerId: overallWinnerId,
      confidence,
      duration_ms: Date.now() - startTime,
      scores: sorted.map(([id, wins]) => ({
        contestantId: id,
        name: this.contestants.get(id)?.name || id,
        wins,
        winRate: wins / (pairs.length * rounds),
      })),
      matches: matchResults,
      rounds: rounds * pairs.length,
    };
  }

  /* ─────────────── Tournament (Single Elimination) ─────────────── */

  /**
   * Single-elimination tournament bracket
   */
  async _tournament(battleId, task, contestants, dimensionWeights, timeoutMs) {
    const startTime = Date.now();
    const bracket = [];
    let currentRound = [...contestants];

    // Pad to nearest power of 2 with byes
    while ((currentRound.length & (currentRound.length - 1)) !== 0) {
      currentRound.push(null); // bye
    }

    let roundNum = 0;
    while (currentRound.length > 1) {
      roundNum++;
      const nextRound = [];
      const roundMatches = [];

      for (let i = 0; i < currentRound.length; i += 2) {
        const a = currentRound[i];
        const b = currentRound[i + 1];

        if (!b) {
          // Bye — a advances automatically
          nextRound.push(a);
          roundMatches.push({ contestants: [a?.id, null], winnerId: a?.id, bye: true });
          continue;
        }

        const [resultA, resultB] = await Promise.all([
          this._executeWithTimeout(a, task, timeoutMs),
          this._executeWithTimeout(b, task, timeoutMs),
        ]);

        const scoreA = await this._scoreResult(resultA, task, dimensionWeights);
        const scoreB = await this._scoreResult(resultB, task, dimensionWeights);

        const { winnerId } = this._determineWinner([
          { id: a.id, score: scoreA },
          { id: b.id, score: scoreB },
        ]);

        const winner = winnerId === a.id ? a : b;
        nextRound.push(winner);

        roundMatches.push({
          contestants: [a.id, b.id],
          scores: [scoreA.total, scoreB.total],
          winnerId,
        });
      }

      bracket.push({ round: roundNum, matches: roundMatches });
      currentRound = nextRound;
    }

    const champion = currentRound[0];

    return {
      battleId,
      mode: ARENA_MODES.TOURNAMENT,
      winnerId: champion?.id || null,
      confidence: CONFIDENCE_THRESHOLD, // Tournament winner is definitive
      duration_ms: Date.now() - startTime,
      champion: champion ? { id: champion.id, name: champion.name } : null,
      bracket,
      rounds: roundNum,
    };
  }

  /* ─────────────── Free-for-All ─────────────── */

  /**
   * All contestants execute simultaneously, best score wins
   */
  async _freeForAll(battleId, task, contestants, dimensionWeights, timeoutMs) {
    const startTime = Date.now();

    // Execute all in parallel (limited concurrency)
    const results = [];
    for (let i = 0; i < contestants.length; i += MAX_CONCURRENT) {
      const batch = contestants.slice(i, i + MAX_CONCURRENT);
      const batchResults = await Promise.all(
        batch.map(c => this._executeWithTimeout(c, task, timeoutMs))
      );
      results.push(...batchResults.map((r, idx) => ({ contestant: batch[idx], result: r })));
    }

    // Score all
    const scored = [];
    for (const { contestant, result } of results) {
      const score = await this._scoreResult(result, task, dimensionWeights);
      scored.push({ id: contestant.id, name: contestant.name, score });
    }

    // Sort by total score
    scored.sort((a, b) => b.score.total - a.score.total);

    const { winnerId, confidence } = this._determineWinner(scored);

    return {
      battleId,
      mode: ARENA_MODES.FREE_FOR_ALL,
      winnerId,
      confidence,
      duration_ms: Date.now() - startTime,
      scores: scored.map((s, rank) => ({
        rank: rank + 1,
        contestantId: s.id,
        name: s.name,
        totalScore: s.score.total,
        dimensions: s.score.dimensions,
      })),
      dimensionBreakdown: this._buildDimensionBreakdown(scored),
      rounds: 1,
    };
  }

  /* ─────────────── Execution ─────────────── */

  /**
   * Execute a contestant's task with timeout
   * @param {object} contestant - Contestant object
   * @param {object} task - Task to execute
   * @param {number} timeoutMs - Timeout in ms
   * @returns {object} Execution result
   */
  async _executeWithTimeout(contestant, task, timeoutMs) {
    const startTime = Date.now();

    try {
      const result = await Promise.race([
        contestant.executor(task, contestant.config),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Execution timeout')), timeoutMs)
        ),
      ]);

      return {
        contestantId: contestant.id,
        success: true,
        output: result,
        duration_ms: Date.now() - startTime,
        error: null,
      };
    } catch (err) {
      return {
        contestantId: contestant.id,
        success: false,
        output: null,
        duration_ms: Date.now() - startTime,
        error: err.message,
      };
    }
  }

  /* ─────────────── Scoring ─────────────── */

  /**
   * Score an execution result across all dimensions
   * @param {object} execResult - Execution result
   * @param {object} task - Original task
   * @param {object} weights - Dimension weights
   * @returns {object} Multi-dimensional score
   */
  async _scoreResult(execResult, task, weights) {
    const dimensions = {};

    // Quality — judge-based or heuristic
    dimensions[SCORING_DIMENSIONS.QUALITY] = await this._scoreQuality(execResult, task);

    // Correctness — did it succeed and produce valid output?
    dimensions[SCORING_DIMENSIONS.CORRECTNESS] = this._scoreCorrectness(execResult, task);

    // Safety — no errors, no violations
    dimensions[SCORING_DIMENSIONS.SAFETY] = this._scoreSafety(execResult);

    // Speed — faster is better, phi-normalized
    dimensions[SCORING_DIMENSIONS.SPEED] = this._scoreSpeed(execResult.duration_ms);

    // Cost — lower is better (if cost data available)
    dimensions[SCORING_DIMENSIONS.COST] = this._scoreCost(execResult);

    // Creativity — output diversity/novelty
    dimensions[SCORING_DIMENSIONS.CREATIVITY] = await this._scoreCreativity(execResult, task);

    // Compute weighted total
    let total = 0;
    for (const [dim, weight] of Object.entries(weights)) {
      total += (dimensions[dim] || 0) * weight;
    }

    return { total, dimensions };
  }

  /**
   * Score quality — uses external judge if available, else heuristic
   */
  async _scoreQuality(execResult, task) {
    if (!execResult.success) return 0;

    if (this.judge) {
      try {
        const judgeScore = await this.judge(execResult.output, task);
        return Math.max(0, Math.min(1, judgeScore));
      } catch {
        // Fallback to heuristic
      }
    }

    // Heuristic quality: output length and structure
    const output = execResult.output;
    if (!output) return 0;

    const str = typeof output === 'string' ? output : JSON.stringify(output);
    const hasContent = str.length > fib(7); // > 13 chars
    const hasStructure = typeof output === 'object' && Object.keys(output).length > 0;

    return hasContent ? (hasStructure ? CSL_THRESHOLDS.HIGH : CSL_THRESHOLDS.MEDIUM) : CSL_THRESHOLDS.LOW;
  }

  /**
   * Score correctness — binary success + validation
   */
  _scoreCorrectness(execResult, task) {
    if (!execResult.success) return 0;
    if (!execResult.output) return CSL_THRESHOLDS.LOW;

    // If task has expected output, compare
    if (task.expectedOutput) {
      const actual = JSON.stringify(execResult.output);
      const expected = JSON.stringify(task.expectedOutput);
      return actual === expected ? 1 : CSL_THRESHOLDS.MEDIUM;
    }

    return execResult.success ? CSL_THRESHOLDS.HIGH : 0;
  }

  /**
   * Score safety — no errors, no exceptions
   */
  _scoreSafety(execResult) {
    if (!execResult.success) return 0;
    if (execResult.error) return CSL_THRESHOLDS.LOW;
    return 1;
  }

  /**
   * Score speed — phi-normalized, faster is better
   */
  _scoreSpeed(duration_ms) {
    // Ideal time: BATTLE_TIMEOUT_MS / PHI²
    const idealMs = BATTLE_TIMEOUT_MS / PHI2;

    if (duration_ms <= idealMs) return 1;
    if (duration_ms >= BATTLE_TIMEOUT_MS) return 0;

    // Phi-decay from ideal to timeout
    const ratio = (BATTLE_TIMEOUT_MS - duration_ms) / (BATTLE_TIMEOUT_MS - idealMs);
    return Math.pow(ratio, PSI); // Gentler decay via phi conjugate exponent
  }

  /**
   * Score cost — normalized by available data
   */
  _scoreCost(execResult) {
    if (execResult.output?.cost !== undefined) {
      // Lower cost = higher score, normalized against max expected cost
      const maxCost = fib(7); // 13 credits
      return Math.max(0, 1 - (execResult.output.cost / maxCost));
    }
    return PSI; // Default middle score if no cost data
  }

  /**
   * Score creativity — output novelty
   */
  async _scoreCreativity(execResult, task) {
    if (!execResult.success || !execResult.output) return 0;

    // If we have vector memory, check novelty against past results
    if (this.vectorMemory) {
      try {
        const outputText = typeof execResult.output === 'string'
          ? execResult.output
          : JSON.stringify(execResult.output);

        const similar = await this.vectorMemory.search(outputText, {
          topK: fib(5),
          namespace: 'battle-results',
        });

        if (similar.length === 0) return 1; // Completely novel

        const maxSimilarity = Math.max(...similar.map(s => s.score || 0));
        return 1 - maxSimilarity; // Less similar = more creative
      } catch {
        return PSI; // Default
      }
    }

    return PSI; // Default middle score
  }

  /* ─────────────── Winner Determination ─────────────── */

  /**
   * Determine winner from scored contestants
   * @param {Array} scored - [{id, score}]
   * @returns {object} {winnerId, confidence}
   */
  _determineWinner(scored) {
    if (scored.length === 0) return { winnerId: null, confidence: 0 };
    if (scored.length === 1) return { winnerId: scored[0].id, confidence: 1 };

    const sorted = [...scored].sort((a, b) => {
      const scoreA = typeof b.score === 'number' ? b.score : b.score.total;
      const scoreB = typeof a.score === 'number' ? a.score : a.score.total;
      return scoreA - scoreB;
    });

    const firstScore = typeof sorted[0].score === 'number' ? sorted[0].score : sorted[0].score.total;
    const secondScore = typeof sorted[1].score === 'number' ? sorted[1].score : sorted[1].score.total;

    // Compute confidence as margin ratio
    const margin = firstScore - secondScore;
    const maxPossible = Math.max(firstScore, 1);
    const confidence = Math.min(1, margin / (maxPossible * PSI)); // Normalized by phi conjugate

    // Only declare winner if confidence exceeds threshold
    if (confidence >= SIGNIFICANCE_THRESHOLD) {
      return { winnerId: sorted[0].id, confidence };
    }

    return { winnerId: null, confidence }; // Draw
  }

  /**
   * Build dimension-by-dimension breakdown
   * @param {Array} scored - Scored contestants
   * @returns {object} Dimension breakdown
   */
  _buildDimensionBreakdown(scored) {
    const breakdown = {};

    for (const dim of Object.values(SCORING_DIMENSIONS)) {
      breakdown[dim] = scored.map(s => ({
        contestantId: s.id,
        score: s.score?.dimensions?.[dim] || 0,
      }));
    }

    return breakdown;
  }

  /* ─────────────── ELO Rating System ─────────────── */

  /**
   * Update ELO ratings based on battle result
   * @param {object} result - Battle result
   */
  _updateRatings(result) {
    if (!result.scores || result.scores.length < 2) return;

    const contestants = result.scores.map(s => {
      const entry = this.leaderboard.get(s.contestantId);
      return entry || { id: s.contestantId, name: s.name || s.contestantId, rating: ELO.INITIAL_RATING, gamesPlayed: 0, wins: 0, losses: 0, draws: 0 };
    });

    for (let i = 0; i < contestants.length; i++) {
      for (let j = i + 1; j < contestants.length; j++) {
        const a = contestants[i];
        const b = contestants[j];

        // Expected scores
        const expectedA = 1 / (1 + Math.pow(10, (b.rating - a.rating) / (fib(12) * PHI))); // 144 × φ ≈ 232.8
        const expectedB = 1 - expectedA;

        // Actual scores (1 = win, 0.5 = draw, 0 = loss)
        let actualA, actualB;
        if (result.winnerId === a.id) {
          actualA = 1; actualB = 0;
          a.wins++; b.losses++;
        } else if (result.winnerId === b.id) {
          actualA = 0; actualB = 1;
          b.wins++; a.losses++;
        } else {
          actualA = 0.5; actualB = 0.5;
          a.draws++; b.draws++;
        }

        // K-factor: higher for new contestants
        const kA = a.gamesPlayed < ELO.GAMES_FOR_ESTABLISHED ? ELO.K_FACTOR_NEW : ELO.K_FACTOR;
        const kB = b.gamesPlayed < ELO.GAMES_FOR_ESTABLISHED ? ELO.K_FACTOR_NEW : ELO.K_FACTOR;

        a.rating = Math.max(ELO.RATING_FLOOR, Math.round(a.rating + kA * (actualA - expectedA)));
        b.rating = Math.max(ELO.RATING_FLOOR, Math.round(b.rating + kB * (actualB - expectedB)));

        a.gamesPlayed++;
        b.gamesPlayed++;
      }
    }

    // Update leaderboard
    for (const c of contestants) {
      this.leaderboard.set(c.id, c);
    }

    logger.info({
      component: 'HeadyBattle',
      action: 'ratings_updated',
      updates: contestants.map(c => ({ id: c.id, rating: c.rating, games: c.gamesPlayed })),
    });
  }

  /* ─────────────── History & Persistence ─────────────── */

  /**
   * Record battle in history
   * @param {object} result - Battle result
   */
  _recordHistory(result) {
    this.history.push({
      battleId: result.battleId,
      mode: result.mode,
      winnerId: result.winnerId,
      confidence: result.confidence,
      duration_ms: result.duration_ms,
      contestants: result.scores?.map(s => s.contestantId || s.id) || [],
      timestamp: Date.now(),
    });

    if (this.history.length > this.maxHistory) {
      this.history.shift();
    }

    // Update stats
    this.stats.totalBattles++;
    this.stats.totalRounds += result.rounds || 1;
    this.stats.averageDuration = this.history.reduce((sum, h) => sum + h.duration_ms, 0) / this.history.length;
    this.stats.decisiveRate = this.history.filter(h => h.winnerId !== null).length / this.history.length;
  }

  /**
   * Store result in vector memory for pattern learning
   * @param {object} result - Battle result
   */
  async _storeResult(result) {
    if (!this.vectorMemory) return;

    try {
      await this.vectorMemory.store({
        content: JSON.stringify({
          battleId: result.battleId,
          mode: result.mode,
          winnerId: result.winnerId,
          confidence: result.confidence,
        }),
        namespace: 'battle-results',
        metadata: {
          type: 'battle_result',
          mode: result.mode,
          winnerId: result.winnerId,
        },
      });
    } catch (err) {
      logger.error({
        component: 'HeadyBattle',
        action: 'store_result_failed',
        error: err.message,
      });
    }
  }

  /**
   * Notify patterns engine of battle result
   * @param {object} result - Battle result
   */
  async _notifyPatterns(result) {
    if (!this.patterns) return;

    try {
      await this.patterns.record({
        type: 'battle_outcome',
        data: {
          mode: result.mode,
          winnerId: result.winnerId,
          confidence: result.confidence,
          contestants: result.scores?.length || 0,
        },
      });
    } catch (err) {
      logger.error({
        component: 'HeadyBattle',
        action: 'notify_patterns_failed',
        error: err.message,
      });
    }
  }

  /* ─────────────── Query API ─────────────── */

  /**
   * Get current leaderboard
   * @param {number} [limit] - Maximum entries
   * @returns {Array} Sorted leaderboard
   */
  getLeaderboard(limit = fib(8)) {
    return [...this.leaderboard.values()]
      .sort((a, b) => b.rating - a.rating)
      .slice(0, limit)
      .map((entry, rank) => ({ rank: rank + 1, ...entry }));
  }

  /**
   * Get contestant stats
   * @param {string} id - Contestant ID
   * @returns {object|null} Contestant stats
   */
  getContestantStats(id) {
    const entry = this.leaderboard.get(id);
    if (!entry) return null;

    const recentBattles = this.history
      .filter(h => h.contestants.includes(id))
      .slice(-fib(7)); // Last 13

    const recentWinRate = recentBattles.length > 0
      ? recentBattles.filter(h => h.winnerId === id).length / recentBattles.length
      : 0;

    return {
      ...entry,
      recentWinRate,
      recentBattles: recentBattles.length,
      isRegistered: this.contestants.has(id),
    };
  }

  /**
   * Get battle history
   * @param {number} [limit] - Maximum entries
   * @returns {Array} Recent battles
   */
  getHistory(limit = fib(8)) {
    return this.history.slice(-limit).reverse();
  }

  /**
   * Get arena statistics
   * @returns {object} Stats
   */
  getStats() {
    return {
      ...this.stats,
      registeredContestants: this.contestants.size,
      leaderboardSize: this.leaderboard.size,
      activeBattles: this.activeBattles.size,
      historyLength: this.history.length,
    };
  }

  /**
   * Health check
   * @returns {object} Health status
   */
  health() {
    return {
      service: 'heady-battle',
      status: 'healthy',
      stats: this.getStats(),
      topRated: this.getLeaderboard(fib(5)),
      timestamp: new Date().toISOString(),
    };
  }
}

module.exports = { HeadyBattle, ARENA_MODES, SCORING_DIMENSIONS, DIMENSION_WEIGHTS, ELO };
