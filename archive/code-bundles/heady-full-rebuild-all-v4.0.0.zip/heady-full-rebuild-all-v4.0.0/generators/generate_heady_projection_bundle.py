from pathlib import Path
import json
import shutil
import textwrap

ROOT = Path('/home/user/workspace/heady-sacred-projections-v4.0.0')
FOUNDATION_SOURCE = Path('/home/user/workspace/heady-sacred-genesis-v4.0.0')
FOUNDATION_TARGET = ROOT / 'foundation' / 'heady-sacred-genesis-v4.0.0'

ATTRIBUTION = textwrap.dedent('''
<!--
   ______                            __
  / ____/___  ____ ___  ____  __  __/ /____  _____
 / /   / __ \/ __ `__ \/ __ \/ / / / __/ _ \/ ___/
/ /___/ /_/ / / / / / / /_/ / /_/ / /_/  __/ /
\____/\____/_/ /_/ /_/ .___/\__,_/\__/\___/_/
                    /_/
        Created with Perplexity Computer
        https://www.perplexity.ai/computer
-->
<meta name="generator" content="Perplexity Computer">
<meta name="author" content="Perplexity Computer">
<meta property="og:see_also" content="https://www.perplexity.ai/computer">
<link rel="author" href="https://www.perplexity.ai/computer">
''').strip()

DOMAINS = [
    {
        'repo': 'headyme-core',
        'domain': 'headyme.com',
        'title': 'HeadyMe',
        'tagline': 'Personal command center for the living Heady operating system.',
        'description': 'A personal cloud hub with cross-device context, command surfaces, and cognitive routing.',
        'accent': '#49dcb1',
        'sections': [
            ('Command center', 'Session continuity, vector recall, projection switching, and live orchestration controls in one surface.'),
            ('Cross-device', 'A single identity spanning browser, IDE, mobile, and dashboard views without fractured state.'),
            ('Operator rail', 'System snapshot cards, projection launchers, Auto-Success pulse, and health telemetry.')
        ]
    },
    {
        'repo': 'headysystems-core',
        'domain': 'headysystems.com',
        'title': 'HeadySystems',
        'tagline': 'Infrastructure engine for Sacred Geometry orchestration.',
        'description': 'Operational surface for topology health, service routing, and resilience control.',
        'accent': '#7dd3fc',
        'sections': [
            ('Infrastructure mesh', 'Cloudflare edge, Cloud Run origin, memory services, and resilience state in one map.'),
            ('Reliability controls', 'Circuit breakers, sagas, bulkheads, quarantine flows, and attestation state.'),
            ('Deployment pulse', 'Projection releases, readiness gates, and environment purity verification.')
        ]
    },
    {
        'repo': 'headyos-core',
        'domain': 'headyos.com',
        'title': 'HeadyOS',
        'tagline': 'Latent operating system surface for continuous cognitive execution.',
        'description': 'The operating shell for stages, swarms, runtime traces, and system evolution.',
        'accent': '#f59e0b',
        'sections': [
            ('Pipeline lens', 'FullPath, ArenaPath, FastPath, and LearningPath runtime traces with explicit state changes.'),
            ('Swarm matrix', 'A visual contract across the 17 swarms, their capacities, and current responsibility bands.'),
            ('Evolution rail', 'Continuous search, optimization ops, mutation review, and receipt history.')
        ]
    },
    {
        'repo': 'headybuddy-core',
        'domain': 'headybuddy.com',
        'title': 'HeadyBuddy',
        'tagline': 'Persistent companion surface with memory, conversation, and creative tools.',
        'description': 'The user-facing companion layer for memory-grounded dialogue and cross-surface assistance.',
        'accent': '#c084fc',
        'sections': [
            ('Memory-grounded chat', 'Conversation space backed by vector memory, story traces, and contextual recall.'),
            ('Creative console', 'Prompt tools, composition surfaces, and guided generation workflows.'),
            ('Trust signals', 'Confidence bands, receipt view, and conversation provenance panels.')
        ]
    },
    {
        'repo': 'headymcp-core',
        'domain': 'headymcp.com',
        'title': 'HeadyMCP',
        'tagline': 'Master Control Program gateway for tools, orchestration, and dispatch.',
        'description': 'A gateway console for tool routing, execution telemetry, and governed access.',
        'accent': '#22c55e',
        'sections': [
            ('Tool registry', 'Registered tools, capabilities, scope controls, and invocation health.'),
            ('Dispatch console', 'Queued actions, in-flight calls, retries, and failure classification.'),
            ('Governed access', 'Zero-trust posture, audit trails, receipts, and operator approvals.')
        ]
    },
    {
        'repo': 'headyapi-core',
        'domain': 'headyapi.com',
        'title': 'HeadyAPI',
        'tagline': 'Unified API façade for the Heady ecosystem.',
        'description': 'Public and internal API gateway patterns for routing, auth, and service discovery.',
        'accent': '#fb7185',
        'sections': [
            ('Gateway surface', 'Clear endpoints, typed contracts, and environment-pure domain routing.'),
            ('Auth and limits', 'Token policy, request shaping, and fail-closed middleware boundaries.'),
            ('Integration rails', 'SDK onboarding, webhook contracts, and projection-specific APIs.')
        ]
    },
    {
        'repo': 'headyio-core',
        'domain': 'heady.io',
        'title': 'Heady IO',
        'tagline': 'Developer platform and SDK surface for building on Heady.',
        'description': 'Docs-first developer surface for SDKs, references, starter flows, and projection kits.',
        'accent': '#38bdf8',
        'sections': [
            ('SDK launchpad', 'Quickstarts, typed clients, and integration scaffolds.'),
            ('Reference center', 'API maps, model routes, MCP patterns, and vector contracts.'),
            ('Starter kits', 'Projection templates for companion, gateway, portal, and automation surfaces.')
        ]
    },
    {
        'repo': 'headyconnection-core',
        'domain': 'headyconnection.com',
        'title': 'HeadyConnection',
        'tagline': 'Collaborative workspace for shared Heady projects and community activity.',
        'description': 'Team and community surface for collaboration, shared memory, and program coordination.',
        'accent': '#2dd4bf',
        'sections': [
            ('Shared workspaces', 'Multi-user projects, memory scopes, and synchronized task rooms.'),
            ('Programs and initiatives', 'Mission-driven surfaces for teams, grants, and community execution.'),
            ('Activity stream', 'Updates, notifications, shared receipts, and operator summaries.')
        ]
    },
    {
        'repo': 'headybot-core',
        'domain': 'headybot.com',
        'title': 'HeadyBot',
        'tagline': 'Autonomous bot orchestration and worker fleet control.',
        'description': 'Surface for bot lifecycle, automation flows, and swarm worker monitoring.',
        'accent': '#a3e635',
        'sections': [
            ('Bot fleet', 'Lifecycle snapshots for agents, workers, and specialized automation bots.'),
            ('Automation plans', 'Runbooks, scheduled tasks, and recovery policies.'),
            ('Swarm health', 'Queue pressure, pool state, and cross-swarm communication signals.')
        ]
    }
]

SHARED_CSS = textwrap.dedent('''
:root {
  --bg: #07111a;
  --panel: rgba(12, 22, 34, 0.82);
  --panel-strong: rgba(16, 28, 44, 0.96);
  --text: #e6eef8;
  --muted: #91a4b8;
  --accent: var(--accent-color, #49dcb1);
  --border: rgba(148, 163, 184, 0.18);
  --success: #4ade80;
  --warning: #fbbf24;
  --danger: #fb7185;
  --shadow: 0 24px 80px rgba(0, 0, 0, 0.35);
  --radius: 24px;
}
* { box-sizing: border-box; }
html { color-scheme: dark; }
body {
  margin: 0;
  min-height: 100vh;
  font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  background:
    radial-gradient(circle at top left, rgba(255,255,255,0.08), transparent 30%),
    radial-gradient(circle at bottom right, color-mix(in srgb, var(--accent) 24%, transparent), transparent 35%),
    linear-gradient(180deg, #061018 0%, #09131d 100%);
  color: var(--text);
}
a { color: inherit; }
.page {
  width: min(1200px, calc(100vw - 48px));
  margin: 0 auto;
  padding: 32px 0 56px;
}
.header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 24px;
  margin-bottom: 32px;
}
.brand {
  display: inline-flex;
  align-items: center;
  gap: 14px;
  text-decoration: none;
}
.brand-mark {
  width: 44px;
  height: 44px;
  border-radius: 14px;
  background: linear-gradient(135deg, color-mix(in srgb, var(--accent) 70%, #ffffff 10%), rgba(255,255,255,0.08));
  display: grid;
  place-items: center;
  box-shadow: var(--shadow);
}
.brand-mark svg { width: 24px; height: 24px; }
.brand-copy strong { display: block; font-size: 0.95rem; }
.brand-copy span { color: var(--muted); font-size: 0.82rem; }
.nav {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.nav a {
  text-decoration: none;
  padding: 10px 14px;
  border-radius: 999px;
  border: 1px solid var(--border);
  background: rgba(255,255,255,0.03);
  color: var(--muted);
}
.hero {
  display: grid;
  grid-template-columns: 1.2fr 0.8fr;
  gap: 24px;
  align-items: stretch;
  margin-bottom: 24px;
}
.panel {
  background: var(--panel);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: var(--shadow);
  backdrop-filter: blur(18px);
}
.hero-copy {
  padding: 34px;
}
.eyebrow {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 0.82rem;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--accent);
}
.hero h1 {
  font-size: clamp(2.4rem, 5vw, 4.6rem);
  line-height: 0.95;
  margin: 18px 0 18px;
}
.hero p {
  font-size: 1.05rem;
  line-height: 1.65;
  color: var(--muted);
  margin: 0 0 20px;
}
.hero-actions {
  display: flex;
  gap: 12px;
  flex-wrap: wrap;
}
.hero-actions a {
  text-decoration: none;
  padding: 12px 16px;
  border-radius: 14px;
  border: 1px solid var(--border);
}
.hero-actions a.primary {
  background: color-mix(in srgb, var(--accent) 26%, #ffffff 2%);
}
.hero-stats {
  padding: 24px;
  display: grid;
  gap: 14px;
}
.stat-card {
  padding: 18px;
  border-radius: 18px;
  background: rgba(255,255,255,0.03);
  border: 1px solid rgba(255,255,255,0.06);
}
.stat-card strong {
  display: block;
  font-size: 1.45rem;
  margin-bottom: 6px;
}
.grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 18px;
  margin-bottom: 24px;
}
.card {
  padding: 22px;
}
.card h2, .card h3 {
  margin-top: 0;
  margin-bottom: 10px;
}
.card p {
  margin: 0;
  color: var(--muted);
  line-height: 1.6;
}
.shell {
  padding: 24px;
  margin-bottom: 24px;
}
.shell-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
.shell-card {
  padding: 18px;
  border-radius: 18px;
  background: rgba(255,255,255,0.025);
  border: 1px solid rgba(255,255,255,0.06);
}
.shell-card ul {
  margin: 12px 0 0;
  padding-left: 18px;
  color: var(--muted);
}
.footer {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  align-items: center;
  padding: 18px 0 6px;
  color: var(--muted);
  font-size: 0.88rem;
  flex-wrap: wrap;
}
.footer a {
  color: var(--muted);
}
.badge-row {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
  margin-top: 18px;
}
.badge {
  padding: 8px 12px;
  border-radius: 999px;
  background: rgba(255,255,255,0.03);
  border: 1px solid var(--border);
  color: var(--muted);
  font-size: 0.82rem;
}
@media (max-width: 920px) {
  .hero, .shell-grid, .grid {
    grid-template-columns: 1fr;
  }
  .page {
    width: min(100vw - 28px, 1200px);
    padding-top: 20px;
  }
  .hero-copy, .hero-stats, .shell, .card {
    padding: 22px;
  }
  .header {
    align-items: flex-start;
    flex-direction: column;
  }
}
''').strip() + '\n'

APP_JS = textwrap.dedent('''
const indicator = document.querySelector('[data-pulse]');
const cycle = 29034;
let state = false;
setInterval(() => {
  state = !state;
  indicator.textContent = state ? `Auto-Success pulse · ${cycle}ms` : 'Projection surface online';
}, 4236);
''').strip() + '\n'

DOMAIN_SHELL_TEMPLATE = '''<!DOCTYPE html>
<html lang="en">
<head>
{attribution}
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title} · Heady projection</title>
<meta name="description" content="{description}">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{description}">
<meta property="og:type" content="website">
<meta property="og:url" content="https://{domain}">
<link rel="stylesheet" href="./styles.css">
<style>:root {{--accent-color: {accent};}}</style>
<script type="application/ld+json">{{
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  "name": "{title}",
  "url": "https://{domain}",
  "description": "{description}",
  "creator": {{
    "@type": "SoftwareApplication",
    "name": "Perplexity Computer",
    "url": "https://www.perplexity.ai/computer"
  }}
}}</script>
</head>
<body>
  <main class="page">
    <header class="header">
      <a class="brand" href="./index.html" aria-label="{title} home">
        <span class="brand-mark" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2 20 8 12 14 4 8 12 2Z"></path>
            <path d="M4 16 12 22 20 16"></path>
            <path d="M12 10v12"></path>
          </svg>
        </span>
        <span class="brand-copy"><strong>{title}</strong><span>{domain}</span></span>
      </a>
      <nav class="nav" aria-label="Primary">
        <a href="#surfaces">Surfaces</a>
        <a href="#runtime">Runtime</a>
        <a href="#projection">Projection</a>
      </nav>
    </header>

    <section class="hero">
      <article class="panel hero-copy">
        <div class="eyebrow">Sacred Genesis projection</div>
        <h1>{title}</h1>
        <p>{tagline}</p>
        <p>{description}</p>
        <div class="hero-actions">
          <a class="primary" href="#projection">Open projection map</a>
          <a href="#runtime">Inspect runtime rail</a>
        </div>
        <div class="badge-row">
          <span class="badge">Cloudflare edge</span>
          <span class="badge">Cloud Run origin</span>
          <span class="badge">Ed25519 receipts</span>
        </div>
      </article>
      <aside class="panel hero-stats">
        <div class="stat-card"><strong>21</strong><span>pipeline stages surfaced</span></div>
        <div class="stat-card"><strong>17</strong><span>swarm bands connected</span></div>
        <div class="stat-card"><strong>10,000</strong><span>bee concurrency target</span></div>
        <div class="stat-card"><strong data-pulse>Projection surface online</strong><span>φ-scaled runtime pulse</span></div>
      </aside>
    </section>

    <section id="surfaces" class="grid">
      {cards}
    </section>

    <section id="runtime" class="panel shell">
      <h2>Runtime shell</h2>
      <div class="shell-grid">
        <div class="shell-card">
          <h3>Surface contract</h3>
          <ul>
            <li>Projection-specific hero, runtime rail, and action surfaces.</li>
            <li>Shared design system for coherent multi-domain deployment.</li>
            <li>Environment-pure domain references with no localhost leakage.</li>
          </ul>
        </div>
        <div class="shell-card">
          <h3>Integration path</h3>
          <ul>
            <li>Mount under the projected repo named for this surface.</li>
            <li>Wire into the shared micro-frontend host registry when needed.</li>
            <li>Use the overlay files in this bundle for manifest and rollout mapping.</li>
          </ul>
        </div>
      </div>
    </section>

    <section id="projection" class="grid">
      <article class="panel card">
        <h3>Projection target</h3>
        <p>{repo} is the repo-facing destination for this surface inside the projection map.</p>
      </article>
      <article class="panel card">
        <h3>Deployment model</h3>
        <p>Static shell front-end with shared assets, ready to sit behind Cloudflare and route to runtime services.</p>
      </article>
      <article class="panel card">
        <h3>Governance</h3>
        <p>Every surface keeps receipt visibility, runtime provenance, and a clear integration path back to the core foundation.</p>
      </article>
    </section>

    <footer class="footer">
      <span>{title} projection surface · Sacred Genesis v4.0.0</span>
      <a href="https://www.perplexity.ai/computer" target="_blank" rel="noopener noreferrer">Created with Perplexity Computer</a>
    </footer>
  </main>
  <script src="./app.js"></script>
</body>
</html>
'''

HOST_INDEX = '''<!DOCTYPE html>
<html lang="en">
<head>
{attribution}
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>HeadyWeb Projection Host</title>
<meta name="description" content="Projection host shell for Heady domain remotes.">
<link rel="stylesheet" href="./styles.css">
<style>:root {{--accent-color: #49dcb1;}}</style>
</head>
<body>
  <main class="page">
    <header class="header">
      <a class="brand" href="./index.html">
        <span class="brand-mark" aria-hidden="true">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="8"></circle><path d="M12 4v16M4 12h16"></path></svg>
        </span>
        <span class="brand-copy"><strong>HeadyWeb Host</strong><span>projection shell</span></span>
      </a>
      <nav class="nav"><a href="#remotes">Remotes</a><a href="#registry">Registry</a></nav>
    </header>
    <section class="hero">
      <article class="panel hero-copy">
        <div class="eyebrow">Micro-frontend portal</div>
        <h1>Host shell</h1>
        <p>Projection host for the domain remotes included in this bundle.</p>
        <div class="badge-row">
          <span class="badge">remote registry</span>
          <span class="badge">domain routing</span>
          <span class="badge">projection overlays</span>
        </div>
      </article>
      <aside class="panel hero-stats">
        <div class="stat-card"><strong>9</strong><span>domain remotes</span></div>
        <div class="stat-card"><strong>1</strong><span>shared host shell</span></div>
        <div class="stat-card"><strong data-pulse>Projection surface online</strong><span>shared runtime pulse</span></div>
      </aside>
    </section>
    <section id="remotes" class="grid">
      {remote_cards}
    </section>
    <section id="registry" class="panel shell">
      <div class="shell-grid">
        <div class="shell-card"><h3>Remote loading</h3><ul><li>Domain-selected remote registry.</li><li>Manifest-driven mount points.</li><li>Shared CSS and attribution policy.</li></ul></div>
        <div class="shell-card"><h3>Next step</h3><ul><li>Wire this shell into the monorepo overlay files included in this ZIP.</li><li>Replace static mounts with runtime federation logic.</li><li>Attach receipts and health telemetry to each surface.</li></ul></div>
      </div>
    </section>
    <footer class="footer"><span>HeadyWeb projection host</span><a href="https://www.perplexity.ai/computer" target="_blank" rel="noopener noreferrer">Created with Perplexity Computer</a></footer>
  </main>
  <script src="./app.js"></script>
</body>
</html>
'''

PROJECTION_MANIFEST = {
    'version': '4.0.0',
    'codename': 'Sacred Genesis',
    'hostShell': 'apps/headyweb-projection-host',
    'foundationPath': 'foundation/heady-sacred-genesis-v4.0.0',
    'surfaces': []
}

ROOT_README = textwrap.dedent('''
# Heady Sacred Projections v4.0.0

This bundle expands the Sacred Genesis foundation into repo-ready projection surfaces and monorepo overlay files.

## Included

- `foundation/` — the validated Heady Sacred Genesis core bundle
- `projections/` — static domain shells for the major Heady surfaces
- `host-shell/` — a shared projection host landing shell
- `overlays/Heady-pre-production-9f2f0642/` — repo-ready overlay files for projection mapping, domain routing, and rollout

## Apply order

1. Review `foundation/heady-sacred-genesis-v4.0.0/`
2. Mount the static surfaces from `projections/` into their target repos
3. Drop the overlay files into the public monorepo as review candidates
4. Replace static mounts with runtime federation and live data wiring
''').strip() + '\n'

OVERLAY_README = textwrap.dedent('''
# Monorepo Overlay

These files are designed to drop into the public Heady pre-production monorepo as a clean projection layer.

## Contents

- `configs/projection-manifest.json` — canonical mapping from repos to domains and surface folders
- `apps/headyweb-projection-host/` — shared host shell for domain remotes
- `src/projection/domain-remotes.js` — registry of remotes and their target repos
- `scripts/projection/generate-projection-map.js` — utility to emit a simple projection inventory
- `docs/PROJECTION_ROLLOUT.md` — rollout sequence for applying the surfaces cleanly
''').strip() + '\n'

DOMAIN_REMOTE_JS_TEMPLATE = ''''use strict';

module.exports = Object.freeze({manifest});
'''

ROLL_OUT_DOC = textwrap.dedent('''
# Projection Rollout

## Sequence

1. Validate the foundation runtime first.
2. Create or refresh the target repos for each domain surface.
3. Copy the matching `projections/<repo>/site/` directory into the target repo root.
4. Mount the host shell if you want a single operator entry point.
5. Replace the placeholder runtime panels with live service wiring from the foundation modules.
6. Add deploy automation only after domain shells and runtime service contracts are stable.

## Goal

Use a stable architectural spine and simple domain shells first, then deepen each surface with live data and governed actions.
''').strip() + '\n'

MAP_SCRIPT = textwrap.dedent('''
'use strict';

const fs = require('fs');
const path = require('path');
const manifest = require('../../src/projection/domain-remotes');

const outputPath = path.resolve(process.cwd(), 'projection-map.generated.json');
fs.writeFileSync(outputPath, JSON.stringify(manifest, null, 2));
process.stdout.write(`Projection map written to ${outputPath}\n`);
''').strip() + '\n'


def write(path: Path, content: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding='utf-8')


def build_cards(sections):
    rendered = []
    for title, description in sections:
        rendered.append(f'<article class="panel card"><h2>{title}</h2><p>{description}</p></article>')
    return '\n      '.join(rendered)


if ROOT.exists():
    shutil.rmtree(ROOT)
ROOT.mkdir(parents=True, exist_ok=True)

if FOUNDATION_TARGET.exists():
    shutil.rmtree(FOUNDATION_TARGET)
FOUNDATION_TARGET.parent.mkdir(parents=True, exist_ok=True)
shutil.copytree(FOUNDATION_SOURCE, FOUNDATION_TARGET)

write(ROOT / 'README.md', ROOT_README)
write(ROOT / 'overlays' / 'Heady-pre-production-9f2f0642' / 'README.md', OVERLAY_README)
write(ROOT / 'overlays' / 'Heady-pre-production-9f2f0642' / 'docs' / 'PROJECTION_ROLLOUT.md', ROLL_OUT_DOC)
write(ROOT / 'overlays' / 'Heady-pre-production-9f2f0642' / 'scripts' / 'projection' / 'generate-projection-map.js', MAP_SCRIPT)

# host shell
host_dir = ROOT / 'host-shell' / 'apps' / 'headyweb-projection-host'
write(host_dir / 'styles.css', SHARED_CSS)
write(host_dir / 'app.js', APP_JS)
remote_cards = []
for domain in DOMAINS:
    remote_cards.append(f'<article class="panel card"><h2>{domain["title"]}</h2><p>{domain["domain"]} · {domain["repo"]}</p></article>')
write(host_dir / 'index.html', HOST_INDEX.format(attribution=ATTRIBUTION, remote_cards='\n      '.join(remote_cards)))

for domain in DOMAINS:
    site_dir = ROOT / 'projections' / domain['repo'] / 'site'
    write(site_dir / 'styles.css', SHARED_CSS)
    write(site_dir / 'app.js', APP_JS)
    write(site_dir / 'robots.txt', 'User-agent: *\nAllow: /\n')
    write(site_dir / 'sitemap.xml', f'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>https://{domain["domain"]}/</loc></url>\n</urlset>\n')
    html = DOMAIN_SHELL_TEMPLATE.format(
        attribution=ATTRIBUTION,
        title=domain['title'],
        tagline=domain['tagline'],
        description=domain['description'],
        domain=domain['domain'],
        repo=domain['repo'],
        accent=domain['accent'],
        cards=build_cards(domain['sections'])
    )
    write(site_dir / 'index.html', html)
    write(ROOT / 'projections' / domain['repo'] / 'README.md', textwrap.dedent(f'''
    # {domain['repo']}

    Target domain: `{domain['domain']}`

    This projection contains a static site shell for `{domain['title']}`. Mount `site/` into the target repo and then wire live runtime panels back to the foundation modules.
    ''').strip() + '\n')
    PROJECTION_MANIFEST['surfaces'].append({
        'repo': domain['repo'],
        'domain': domain['domain'],
        'title': domain['title'],
        'surfacePath': f'projections/{domain["repo"]}/site',
        'targetRepoOverlay': f'overlays/Heady-pre-production-9f2f0642/apps/remotes/{domain["repo"]}'
    })

write(ROOT / 'overlays' / 'Heady-pre-production-9f2f0642' / 'configs' / 'projection-manifest.json', json.dumps(PROJECTION_MANIFEST, indent=2) + '\n')
write(
    ROOT / 'overlays' / 'Heady-pre-production-9f2f0642' / 'src' / 'projection' / 'domain-remotes.js',
    DOMAIN_REMOTE_JS_TEMPLATE.format(manifest=json.dumps(PROJECTION_MANIFEST, indent=2))
)

print(f'Expanded bundle created at {ROOT}')
print(f'Surfaces: {len(DOMAINS)}')
