# Heady Full Rebuild All v4.0.0

This master bundle consolidates the generated Heady rebuild deliverables into a single ZIP.

## Included

- foundation/heady-sacred-genesis-v4.0.0/
- projections/heady-sacred-projections-v4.0.0/
- artifacts/heady-sacred-genesis-run.json
- artifacts/heady-sacred-genesis-summary.json
- generators/generate_heady_bundle.py
- generators/generate_heady_projection_bundle.py
- context/heady-full-rebuild-context.zip

## Notes

- The foundation bundle is the validated core rebuild.
- The projections bundle adds 9 domain shells, a host shell, and monorepo overlays.
- The projections layer is structured for the next live wiring phase rather than fully attached runtime services.
