# Heady™ Sovereign AI Platform v4.0.0

> **Codename: Sovereign** — Autonomous multi-agent AI operating system with 384D vector space, Sacred Geometry orchestration, and liquid dynamic intelligence.

## Architecture

Heady is a **Latent OS** — a self-aware, self-healing, continuously reasoning AI platform that exists as a living system in 384-dimensional vector space.

### Layers

```
┌─────────────────────────────────────────────────────┐
│  EDGE LAYER — Cloudflare Workers, Domain Routing    │
├─────────────────────────────────────────────────────┤
│  INTELLIGENCE — LLM Router, Monte Carlo, Patterns   │
├─────────────────────────────────────────────────────┤
│  ORCHESTRATION — Conductor, Swarm, Cognitive Runtime│
├─────────────────────────────────────────────────────┤
│  PIPELINE — HCFullPipeline (9-stage execution)      │
├─────────────────────────────────────────────────────┤
│  RESILIENCE — Circuit Breaker, Auto-Heal, Pools     │
├─────────────────────────────────────────────────────┤
│  BEES — Dynamic Agent Workers (24 domains, 197+)    │
├─────────────────────────────────────────────────────┤
│  LATENT CORE — Vector Memory, Self-Awareness, RAG   │
├─────────────────────────────────────────────────────┤
│  KERNEL — HeadyCore (zero-dep runtime modules)      │
└─────────────────────────────────────────────────────┘
```

### Sacred Geometry Topology

```
                    ┌─ Governance Shell ─┐
                    │  HeadyCheck        │
                    │  HeadyAssure       │
                    │  HeadyPatterns     │
               ┌────┴──────────────────┴────┐
               │     Outer Ring             │
               │  BRIDGE · MUSE · SENTINEL  │
               │  NOVA · JANITOR · SOPHIA   │
          ┌────┴──────────────────────────┴────┐
          │        Middle Ring                 │
          │  JULES · BUILDER · OBSERVER        │
          │  MURPHY · ATLAS · PYTHIA           │
     ┌────┴──────────────────────────────────┴────┐
     │           Inner Ring                       │
     │  HeadyBrains · HeadyConductor · HeadyVinci │
     │              ┌──────────┐                  │
     │              │ HeadySoul│ ← Origin         │
     │              └──────────┘                  │
     └────────────────────────────────────────────┘
```

Resource allocation follows **Fibonacci ratios**: Hot 34% · Warm 21% · Cold 13% · Reserve 8% · Governance 5%

## Quick Start

```bash
# Install (only 3 real dependencies)
npm install

# Start the platform
npm start

# Start in MCP mode
npm run start:mcp

# Start in dev mode (auto-reload)
npm run dev

# Run HCFullPipeline
npm run hcfp
```

## Project Structure

```
heady-rebuild/
├── heady-manager.js          # Thin orchestrator shell (10-phase boot)
├── heady-registry.json       # Single source of truth
├── package.json              # v4.0.0 Sovereign
├── configs/
│   ├── system.yaml           # Consolidated system config
│   ├── domains.yaml          # Domain routing config
│   └── sacred-geometry.yaml  # Sacred Geometry topology
├── src/
│   ├── core/                 # HeadyCore kernel (zero-dep runtime)
│   │   ├── heady-env.js      # Environment loader
│   │   ├── heady-logger.js   # Structured colorful logger
│   │   ├── heady-fetch.js    # Native fetch with retry/cache
│   │   ├── heady-server.js   # Express-compatible HTTP server
│   │   ├── heady-jwt.js      # JWT via Node.js crypto
│   │   ├── heady-crypt.js    # Crypto utilities
│   │   ├── heady-yaml.js     # YAML parser/serializer
│   │   ├── heady-kv.js       # In-memory KV store
│   │   ├── heady-scheduler.js# Cron/interval scheduler
│   │   └── event-bus.js      # Enhanced EventEmitter
│   ├── bootstrap/            # 10-phase boot sequence
│   │   ├── config-globals.js # Phase 1: env, logger, event bus
│   │   ├── middleware-stack.js# Phase 2: security, CORS, rate limit
│   │   ├── auth-engine.js    # Phase 3: JWT auth, RBAC
│   │   ├── vector-stack.js   # Phase 4: vector memory, bees
│   │   ├── engine-wiring.js  # Phase 5: MC, patterns, QA
│   │   ├── pipeline-wiring.js# Phase 6: HCFullPipeline
│   │   ├── service-registry.js# Phase 7: 40+ services
│   │   ├── inline-routes.js  # Phase 8: health, telemetry
│   │   ├── voice-relay.js    # Phase 9: WebSocket voice
│   │   └── server-boot.js    # Phase 10: HTTP + graceful shutdown
│   ├── latent/               # Latent OS core (the brain)
│   │   ├── vector-memory.js  # RAM-first 384D memory
│   │   ├── vector-space-ops.js# Vector math (cosine, Fibonacci)
│   │   ├── vector-federation.js# Distributed memory
│   │   ├── vector-pipeline.js# Ingestion pipeline
│   │   ├── self-awareness.js # System self-model
│   │   ├── drift-detector.js # Coherence monitoring
│   │   ├── embedding-provider.js# Multi-backend embeddings
│   │   ├── spatial-mapper.js # 3D topology + Sacred Geometry
│   │   ├── memory-consolidator.js# STM→LTM engine
│   │   ├── graph-rag.js      # Knowledge graph + RAG
│   │   └── index.js          # Factory + barrel exports
│   ├── orchestration/        # Task routing + coordination
│   │   ├── heady-conductor.js# Central dispatch
│   │   ├── swarm-consensus.js# Byzantine-tolerant voting
│   │   ├── swarm-intelligence.js# Stigmergy + ACO
│   │   ├── cognitive-runtime.js# Context + reasoning
│   │   ├── buddy-core.js     # AI companion
│   │   └── buddy-watchdog.js # Hallucination detection
│   ├── resilience/           # Fault tolerance
│   │   ├── circuit-breaker.js# CLOSED/OPEN/HALF_OPEN
│   │   ├── exponential-backoff.js# φ-based backoff
│   │   ├── auto-heal.js      # Self-healing engine
│   │   ├── pool.js           # Fibonacci resource pools
│   │   ├── rate-limiter.js   # Token bucket limiter
│   │   └── cache.js          # L1/L2 multi-tier cache
│   ├── pipeline/             # HCFullPipeline
│   │   ├── pipeline-core.js  # 9-stage execution engine
│   │   ├── pipeline-pools.js # Pool-based dispatch
│   │   └── pipeline-handlers.js# Stage implementations
│   ├── intelligence/         # AI routing + reasoning
│   │   ├── llm-router.js     # Multi-provider LLM routing
│   │   ├── monte-carlo.js    # MC simulation engine
│   │   ├── pattern-engine.js # Pattern recognition
│   │   ├── inference-gateway.js# Unified inference
│   │   └── story-driver.js   # HeadyAutobiographer
│   ├── edge/                 # Edge + gateway
│   │   ├── domain-router.js  # Multi-domain routing
│   │   ├── cloudflare-integration.js# CF Workers/Tunnel
│   │   └── mcp-server.js     # MCP server (31 tools)
│   ├── bees/                 # Dynamic agent workers
│   │   ├── bee-factory.js    # Agent factory
│   │   ├── registry.js       # Bee registry
│   │   └── session-templates.js# Workflow templates
│   └── config/               # Configuration
│       ├── config-loader.js  # Unified config loader
│       └── domain-registry.js# Domain config
└── tests/                    # Test suite
```

## HeadyCore — Zero-Dependency Runtime

HeadyCore replaces 25+ npm packages with built-in Node.js modules:

| HeadyCore Module | Replaces |
|---|---|
| `heady-fetch` | node-fetch, axios |
| `heady-env` | dotenv |
| `heady-yaml` | js-yaml, yaml |
| `heady-jwt` | jsonwebtoken |
| `heady-crypt` | bcrypt |
| `heady-scheduler` | node-cron, commander |
| `heady-server` | express, cors, helmet, compression |
| `heady-kv` | redis (for local use) |

## The 3 Unbreakable Laws

Every code mutation must satisfy:

1. **Structural Integrity** — Code compiles, passes type checks, respects module boundaries
2. **Semantic Coherence** — The change's embedding stays within tolerance of intended design
3. **Mission Alignment** — The change serves HeadyConnection's mission: community, equity, empowerment

## Domains

| Domain | Role |
|---|---|
| headyme.com | Command center |
| headysystems.com | Core architecture engine |
| headyconnection.org | Nonprofit and community |
| headybuddy.org | AI companion experience |
| headymcp.com | MCP layer |
| headyio.com | Developer platform |
| headybot.com | Automation and agents |
| headyapi.com | Public intelligence interface |
| headyai.com | Intelligence routing hub |

## License

Proprietary — © 2026 HeadySystems Inc.

---

> ⚡ Made with 💜 Love by the HeadySystems™ & HeadyConnection™ Team
> Sacred Geometry :: Organic Systems :: Breathing Interfaces
