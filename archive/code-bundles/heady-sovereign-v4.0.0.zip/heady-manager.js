/**
 * ∞ Heady™ Manager — Thin orchestrator shell: 10-phase bootstrap for Sovereign AI Platform
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 *
 * ╔══════════════════════════════════════════════════════════════════════════╗
 * ║  HeadySystems™ Sovereign AI Platform v4.0.0 "Sovereign"                ║
 * ║  Latent OS — Liquid, Dynamic, Intelligent, Autonomous                  ║
 * ║  ∞ Everything flows through HeadyConductor + HeadyOrchestrator         ║
 * ╚══════════════════════════════════════════════════════════════════════════╝
 *
 * Boot sequence:
 *   Phase 1  → config-globals    (env, logger, event bus, edge cache)
 *   Phase 2  → middleware-stack  (CORS, security headers, rate limiting, body parsing)
 *   Phase 3  → auth-engine       (JWT, API keys, RBAC, Cloudflare Access)
 *   Phase 4  → vector-stack      (384D memory, pipeline, federation, bees, buddies)
 *   Phase 5  → engine-wiring     (Monte Carlo, Patterns, AutoSuccess, QA, Story)
 *   Phase 6  → pipeline-wiring   (HCFullPipeline, self-healing mesh)
 *   Phase 7  → service-registry  (40+ services mounted with graceful degradation)
 *   Phase 8  → inline-routes     (health, pulse, layer, CSL, edge, telemetry, principles)
 *   Phase 9  → voice-relay       (WebSocket voice relay with session management)
 *   Phase 10 → server-boot       (HTTP + WS server, LIFO graceful shutdown)
 */

import { createApp } from './src/core/heady-server.js';
import { rootLogger } from './src/core/heady-logger.js';

// ─── Bootstrap Phase Imports ──────────────────────────────────────────────────
import { initConfigGlobals }    from './src/bootstrap/config-globals.js';
import { initMiddlewareStack }  from './src/bootstrap/middleware-stack.js';
import { initAuthEngine }       from './src/bootstrap/auth-engine.js';
import { initVectorStack }      from './src/bootstrap/vector-stack.js';
import { initEngineWiring }     from './src/bootstrap/engine-wiring.js';
import { initPipelineWiring }   from './src/bootstrap/pipeline-wiring.js';
import { initServiceRegistry }  from './src/bootstrap/service-registry.js';
import { initInlineRoutes }     from './src/bootstrap/inline-routes.js';
import { initVoiceRelay }       from './src/bootstrap/voice-relay.js';
import { initServerBoot }       from './src/bootstrap/server-boot.js';

const log = rootLogger.child('HeadyManager');

/**
 * Banner displayed on boot
 */
function printBanner() {
  const banner = `
∞ ═══════════════════════════════════════════════════════════════════════════════ ∞
   HeadySystems™ Sovereign AI Platform v4.0.0 "Sovereign"
   Latent OS — Liquid · Dynamic · Intelligent · Autonomous
   
   ∞  384D Vector Memory  ·  Fibonacci Sharding  ·  Sacred Geometry Topology
   ∞  HeadyConductor  ·  HeadyOrchestrator  ·  HeadySoul Awareness Layer
   ∞  Zero Localhost  ·  Zero Unnecessary Dependencies  ·  Cloud Native
   
   © 2026 HeadySystems Inc. — https://heady.ai
∞ ═══════════════════════════════════════════════════════════════════════════════ ∞
`;
  process.stdout.write(banner + '\n');
}

/**
 * Runs a single bootstrap phase with timing and error handling
 * @param {number} phaseNum
 * @param {string} phaseName
 * @param {function(): Promise<object>} fn
 * @returns {Promise<object>}
 */
async function runPhase(phaseNum, phaseName, fn) {
  const start = Date.now();
  try {
    const result = await fn();
    const elapsed = Date.now() - start;
    log.info(`  ✓ Phase ${phaseNum}: ${phaseName}`, { elapsed_ms: elapsed });
    return result || {};
  } catch (err) {
    const elapsed = Date.now() - start;
    log.error(`  ✗ Phase ${phaseNum}: ${phaseName} FAILED`, {
      error: err.message,
      elapsed_ms: elapsed,
    });
    throw err;
  }
}

/**
 * Main bootstrap orchestrator — runs all 10 phases sequentially.
 * Each phase receives the accumulated globals from all previous phases.
 * @returns {Promise<object>} Final platform state
 */
async function boot() {
  printBanner();
  const bootStart = Date.now();

  log.info('∞ HeadySovereign boot sequence initiated...');
  log.info(`  Node.js ${process.version}  ·  PID ${process.pid}  ·  ENV ${process.env.NODE_ENV || 'development'}`);

  // Create the central HeadyApp (Express-compatible, zero external deps)
  const app = createApp();

  // Accumulated globals — each phase merges its outputs in
  let G = { app };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 1: Config Globals
  // Loads env, creates structured logger, event bus, remote config, secrets, CF manager
  // ────────────────────────────────────────────────────────────────────────────
  const phase1 = await runPhase(1, 'config-globals', () => initConfigGlobals());
  G = { ...G, ...phase1 };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 2: Middleware Stack
  // CORS, helmet-equivalent headers, rate limiting, body parser, compression, request ID
  // ────────────────────────────────────────────────────────────────────────────
  const phase2 = await runPhase(2, 'middleware-stack', () => initMiddlewareStack(app, G));
  G = { ...G, ...phase2 };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 3: Auth Engine
  // JWT creation/verification, API key validation, RBAC, Cloudflare Access integration
  // ────────────────────────────────────────────────────────────────────────────
  const phase3 = await runPhase(3, 'auth-engine', () => initAuthEngine(app, G));
  G = { ...G, ...phase3 };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 4: Vector Stack
  // 384D RAM-first vector memory, Fibonacci-sharded, federated across 4 namespaces
  // VectorPipeline, BeeFactory, BuddyCore, SelfAwareness, Watchdog
  // ────────────────────────────────────────────────────────────────────────────
  const phase4 = await runPhase(4, 'vector-stack', () => initVectorStack(app, G));
  G = { ...G, ...phase4 };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 5: Engine Wiring
  // MonteCarloScheduler, PatternEngine, AutoSuccess, Scientist, QA, StoryDriver
  // ────────────────────────────────────────────────────────────────────────────
  const phase5 = await runPhase(5, 'engine-wiring', () => initEngineWiring(app, G));
  G = { ...G, ...phase5 };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 6: Pipeline Wiring
  // HCFullPipeline (7 stages), self-healing mesh, vector context binding
  // ────────────────────────────────────────────────────────────────────────────
  const phase6 = await runPhase(6, 'pipeline-wiring', () => initPipelineWiring(app, G));
  G = { ...G, ...phase6 };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 7: Service Registry
  // 40+ service route modules mounted with graceful degradation (try/require)
  // ────────────────────────────────────────────────────────────────────────────
  const phase7 = await runPhase(7, 'service-registry', () => initServiceRegistry(app, G));
  G = { ...G, ...phase7 };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 8: Inline Routes
  // /health/live, /health/ready, /health/deep, /pulse, /layer, /csl,
  // /edge, /telemetry, /principles, /version, 404 catch-all
  // ────────────────────────────────────────────────────────────────────────────
  const phase8 = await runPhase(8, 'inline-routes', () => initInlineRoutes(app, G));
  G = { ...G, ...phase8 };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 9: Voice Relay
  // WebSocket voice relay on /voice with session management, audio buffering
  // Note: server not available yet — voice relay attaches to server in Phase 10
  // ────────────────────────────────────────────────────────────────────────────
  const phase9 = await runPhase(9, 'voice-relay', () => initVoiceRelay(null, G));
  G = { ...G, ...phase9 };

  // ────────────────────────────────────────────────────────────────────────────
  // PHASE 10: Server Boot
  // HTTP server creation, WebSocket upgrade wiring, port binding with retry,
  // signal handlers (SIGTERM/SIGINT), LIFO graceful shutdown registration
  // ────────────────────────────────────────────────────────────────────────────
  const phase10 = await runPhase(10, 'server-boot', () => initServerBoot(app, G));
  G = { ...G, ...phase10 };

  // ─── Voice relay attachment to live server ────────────────────────────────
  // Re-attach voice relay now that we have the real HTTP server
  if (G.voiceRelay && G.server) {
    G.server.on('upgrade', (req, socket, head) => {
      G.voiceRelay.handleUpgrade(req, socket, head).catch(err => {
        log.error('WS upgrade error', { error: err.message });
        socket.destroy();
      });
    });
  }

  // ─── Boot Complete ────────────────────────────────────────────────────────
  const bootElapsed = Date.now() - bootStart;
  log.info('');
  log.info('∞ ═══════════════════════════════════════════════════════ ∞');
  log.info(`  HeadySovereign v4.0.0 "Sovereign" is ALIVE`);
  log.info(`  Port: ${G.port}  ·  PID: ${process.pid}  ·  Boot: ${bootElapsed}ms`);
  log.info(`  Vectors: ${G.vectorMemory?._vectors?.size ?? 0} loaded`);
  log.info(`  Services: ${G.serviceStats?.mounted ?? 0} mounted, ${G.serviceStats?.stubbed ?? 0} stubbed`);
  log.info(`  API: https://api.heady.ai/health/live`);
  log.info('∞ ═══════════════════════════════════════════════════════ ∞');
  log.info('');

  G.bus?.emit('platform:boot-complete', {
    version: '4.0.0',
    codename: 'Sovereign',
    port: G.port,
    bootElapsed,
    pid: process.pid,
  });

  return G;
}

// ─── Entry Point ──────────────────────────────────────────────────────────────
boot().catch(err => {
  log.fatal('Boot sequence failed', { error: err.message, stack: err.stack });
  process.exit(1);
});
