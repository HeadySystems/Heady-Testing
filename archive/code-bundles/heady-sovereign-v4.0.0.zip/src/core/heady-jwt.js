/**
 * ∞ Heady™ JWT — JWT creation and verification using Node.js crypto (zero external deps)
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createHmac, createSign, createVerify, randomBytes } from 'crypto';

/**
 * @typedef {object} JwtPayload
 * @property {string} [iss] - Issuer
 * @property {string} [sub] - Subject
 * @property {string|string[]} [aud] - Audience
 * @property {number} [exp] - Expiration time (Unix seconds)
 * @property {number} [iat] - Issued at (Unix seconds)
 * @property {number} [nbf] - Not before (Unix seconds)
 * @property {string} [jti] - JWT ID
 * @property {string} [role] - Heady role
 * @property {string} [scope] - Permission scope
 * @property {string} [component] - Originating Heady component
 */

/**
 * @typedef {object} JwtHeader
 * @property {string} alg - Algorithm: 'HS256' | 'HS384' | 'HS512' | 'RS256'
 * @property {string} typ - Token type: 'JWT'
 * @property {string} [kid] - Key ID
 */

/**
 * @typedef {object} SignOptions
 * @property {string} [algorithm='HS256'] - Signing algorithm
 * @property {string|number} [expiresIn='1h'] - Expiry: '30m', '2h', '7d' or seconds
 * @property {string} [issuer='heady.ai'] - JWT issuer
 * @property {string} [audience] - Intended audience
 * @property {string} [subject] - Subject claim
 * @property {string} [keyId] - Key ID for kid header
 * @property {boolean} [noTimestamp=false] - Skip iat claim
 */

/**
 * @typedef {object} VerifyOptions
 * @property {string} [algorithm='HS256'] - Expected algorithm
 * @property {string} [issuer] - Expected issuer
 * @property {string|string[]} [audience] - Expected audience
 * @property {number} [clockTolerance=30] - Clock skew tolerance in seconds
 * @property {boolean} [ignoreExpiration=false] - Skip expiry check
 */

/** Algorithm map to Node.js crypto names */
const ALGO_MAP = {
  HS256: 'sha256',
  HS384: 'sha384',
  HS512: 'sha512',
};

/** HMAC algorithms */
const HMAC_ALGOS = new Set(['HS256', 'HS384', 'HS512']);

/**
 * Encodes data as base64url (URL-safe, no padding)
 * @param {Buffer|string} data
 * @returns {string}
 */
function base64url(data) {
  const buf = Buffer.isBuffer(data) ? data : Buffer.from(JSON.stringify(data));
  return buf.toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

/**
 * Decodes a base64url string to a Buffer
 * @param {string} str
 * @returns {Buffer}
 */
function base64urlDecode(str) {
  // Re-pad
  const padded = str + '='.repeat((4 - (str.length % 4)) % 4);
  return Buffer.from(padded.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
}

/**
 * Parses a duration string to seconds
 * @param {string|number} duration - e.g. '1h', '30m', '7d', '60s', or seconds as number
 * @returns {number} seconds
 */
function parseDuration(duration) {
  if (typeof duration === 'number') return duration;
  const match = String(duration).match(/^(\d+(?:\.\d+)?)\s*(s|m|h|d|w)?$/i);
  if (!match) throw new Error(`[HeadyJwt] Invalid duration: ${duration}`);
  const num = parseFloat(match[1]);
  const unit = (match[2] || 's').toLowerCase();
  const units = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 };
  return Math.floor(num * (units[unit] || 1));
}

/**
 * Creates an HMAC signature for a JWT
 * @param {string} input - header.payload
 * @param {string|Buffer} secret
 * @param {string} algorithm - e.g. 'HS256'
 * @returns {string} base64url signature
 */
function signHmac(input, secret, algorithm) {
  const nodeAlgo = ALGO_MAP[algorithm];
  if (!nodeAlgo) throw new Error(`[HeadyJwt] Unsupported HMAC algorithm: ${algorithm}`);
  const key = typeof secret === 'string' ? Buffer.from(secret, 'utf8') : secret;
  return createHmac(nodeAlgo, key).update(input).digest('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

/**
 * Signs a JWT token
 * @param {JwtPayload} payload
 * @param {string|Buffer} secret - Secret key (for HMAC) or private key (for RSA)
 * @param {SignOptions} [options]
 * @returns {string} Signed JWT string
 */
export function sign(payload, secret, options = {}) {
  if (!payload || typeof payload !== 'object') {
    throw new TypeError('[HeadyJwt] Payload must be an object');
  }
  if (!secret) throw new Error('[HeadyJwt] Secret is required');

  const algorithm = options.algorithm || 'HS256';
  const now = Math.floor(Date.now() / 1000);

  /** @type {JwtHeader} */
  const header = {
    alg: algorithm,
    typ: 'JWT',
    ...(options.keyId ? { kid: options.keyId } : {}),
  };

  /** @type {JwtPayload} */
  const claims = {
    ...payload,
    iss: options.issuer || payload.iss || 'heady.ai',
    ...(options.subject ? { sub: options.subject } : {}),
    ...(options.audience ? { aud: options.audience } : {}),
    ...(options.noTimestamp ? {} : { iat: now }),
    jti: payload.jti || randomBytes(12).toString('hex'),
  };

  if (options.expiresIn !== undefined) {
    claims.exp = now + parseDuration(options.expiresIn);
  }

  const headerEncoded = base64url(header);
  const payloadEncoded = base64url(claims);
  const signingInput = `${headerEncoded}.${payloadEncoded}`;

  let signature;
  if (HMAC_ALGOS.has(algorithm)) {
    signature = signHmac(signingInput, secret, algorithm);
  } else {
    throw new Error(`[HeadyJwt] Unsupported algorithm: ${algorithm}`);
  }

  return `${signingInput}.${signature}`;
}

/**
 * Verifies a JWT token and returns the decoded payload
 * @param {string} token - JWT string
 * @param {string|Buffer} secret - Secret key
 * @param {VerifyOptions} [options]
 * @returns {JwtPayload} Decoded and verified payload
 * @throws {Error} If token is invalid, expired, or signature fails
 */
export function verify(token, secret, options = {}) {
  if (typeof token !== 'string') throw new TypeError('[HeadyJwt] Token must be a string');
  if (!secret) throw new Error('[HeadyJwt] Secret is required');

  const parts = token.split('.');
  if (parts.length !== 3) {
    throw new Error('[HeadyJwt] Invalid token structure: expected 3 parts');
  }

  const [headerEncoded, payloadEncoded, signatureEncoded] = parts;

  // Decode header
  let header;
  try {
    header = JSON.parse(base64urlDecode(headerEncoded).toString('utf8'));
  } catch {
    throw new Error('[HeadyJwt] Invalid token: could not decode header');
  }

  if (header.typ && header.typ !== 'JWT') {
    throw new Error(`[HeadyJwt] Invalid token type: ${header.typ}`);
  }

  const algorithm = options.algorithm || header.alg || 'HS256';

  // Verify signature
  const signingInput = `${headerEncoded}.${payloadEncoded}`;
  let expectedSig;

  if (HMAC_ALGOS.has(algorithm)) {
    expectedSig = signHmac(signingInput, secret, algorithm);
  } else {
    throw new Error(`[HeadyJwt] Unsupported algorithm: ${algorithm}`);
  }

  // Constant-time comparison
  const expected = Buffer.from(expectedSig, 'utf8');
  const actual = Buffer.from(signatureEncoded, 'utf8');
  if (expected.length !== actual.length) {
    throw new Error('[HeadyJwt] Invalid signature');
  }
  let mismatch = 0;
  for (let i = 0; i < expected.length; i++) {
    mismatch |= expected[i] ^ actual[i];
  }
  if (mismatch !== 0) {
    throw new Error('[HeadyJwt] Invalid signature');
  }

  // Decode payload
  let payload;
  try {
    payload = JSON.parse(base64urlDecode(payloadEncoded).toString('utf8'));
  } catch {
    throw new Error('[HeadyJwt] Invalid token: could not decode payload');
  }

  const now = Math.floor(Date.now() / 1000);
  const tolerance = options.clockTolerance ?? 30;

  // Check expiration
  if (!options.ignoreExpiration && payload.exp !== undefined) {
    if (now > payload.exp + tolerance) {
      throw new Error(`[HeadyJwt] Token expired at ${new Date(payload.exp * 1000).toISOString()}`);
    }
  }

  // Check not before
  if (payload.nbf !== undefined && now < payload.nbf - tolerance) {
    throw new Error(`[HeadyJwt] Token not yet valid until ${new Date(payload.nbf * 1000).toISOString()}`);
  }

  // Check issuer
  if (options.issuer && payload.iss !== options.issuer) {
    throw new Error(`[HeadyJwt] Invalid issuer: expected "${options.issuer}", got "${payload.iss}"`);
  }

  // Check audience
  if (options.audience) {
    const expected = Array.isArray(options.audience) ? options.audience : [options.audience];
    const actual = Array.isArray(payload.aud) ? payload.aud : [payload.aud];
    if (!expected.some(e => actual.includes(e))) {
      throw new Error(`[HeadyJwt] Invalid audience: "${actual.join(',')}"`);
    }
  }

  return payload;
}

/**
 * Decodes a JWT without verification (for inspection only)
 * @param {string} token
 * @returns {{ header: JwtHeader, payload: JwtPayload, signature: string }}
 */
export function decode(token) {
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('[HeadyJwt] Invalid token structure');
  return {
    header: JSON.parse(base64urlDecode(parts[0]).toString('utf8')),
    payload: JSON.parse(base64urlDecode(parts[1]).toString('utf8')),
    signature: parts[2],
  };
}

/**
 * Checks if a token is expired (without verifying signature)
 * @param {string} token
 * @returns {boolean}
 */
export function isExpired(token) {
  try {
    const { payload } = decode(token);
    if (payload.exp === undefined) return false;
    return Date.now() / 1000 > payload.exp;
  } catch {
    return true;
  }
}

/**
 * Returns seconds until token expires, or -1 if expired/no expiry
 * @param {string} token
 * @returns {number}
 */
export function expiresIn(token) {
  try {
    const { payload } = decode(token);
    if (payload.exp === undefined) return Infinity;
    return Math.max(0, payload.exp - Math.floor(Date.now() / 1000));
  } catch {
    return -1;
  }
}

/**
 * Generates a secure API key string
 * @param {number} [bytes=32]
 * @returns {string} Hex-encoded key prefixed with 'hky_'
 */
export function generateApiKey(bytes = 32) {
  return `hky_${randomBytes(bytes).toString('hex')}`;
}

export default { sign, verify, decode, isExpired, expiresIn, generateApiKey };
