/**
 * ∞ Heady™ Server — Express-compatible HTTP server factory using Node.js built-in http
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createServer } from 'http';
import { EventEmitter } from 'events';
import { createLogger } from './heady-logger.js';
import { uuid } from './heady-crypt.js';

const log = createLogger('HeadyServer');

/**
 * @typedef {object} HeadyRequest
 * @property {string} method
 * @property {string} url
 * @property {string} path
 * @property {Record<string, string>} query
 * @property {Record<string, string>} headers
 * @property {Record<string, string>} params
 * @property {unknown} body
 * @property {string} requestId
 * @property {number} startTime
 * @property {string} ip
 */

/**
 * @typedef {object} HeadyResponse
 * @property {function(number): HeadyResponse} status
 * @property {function(object): void} json
 * @property {function(string): void} send
 * @property {function(string, string): HeadyResponse} setHeader
 * @property {function(): void} end
 * @property {function(string, string): void} redirect
 * @property {number} statusCode
 * @property {boolean} headersSent
 */

/**
 * @typedef {Function} Middleware
 * @param {HeadyRequest} req
 * @param {HeadyResponse} res
 * @param {function(Error?): void} next
 */

/**
 * @typedef {object} RouteDefinition
 * @property {'GET'|'POST'|'PUT'|'PATCH'|'DELETE'|'OPTIONS'|'HEAD'|'ALL'} method
 * @property {string} path - Route path, supports :param tokens
 * @property {Middleware[]} handlers
 */

/**
 * Parses a URL query string into a plain object
 * @param {string} queryStr
 * @returns {Record<string, string>}
 */
function parseQuery(queryStr) {
  if (!queryStr) return {};
  const result = {};
  for (const part of queryStr.split('&')) {
    const idx = part.indexOf('=');
    if (idx === -1) {
      result[decodeURIComponent(part)] = '';
    } else {
      result[decodeURIComponent(part.slice(0, idx))] = decodeURIComponent(part.slice(idx + 1));
    }
  }
  return result;
}

/**
 * Converts a route path pattern to a RegExp and extracts param names
 * @param {string} pattern - e.g. '/api/:version/users/:id'
 * @returns {{ regex: RegExp, paramNames: string[] }}
 */
function compileRoute(pattern) {
  const paramNames = [];
  const escaped = pattern
    .replace(/[.+*?^${}()|[\]\\]/g, '\\$&') // escape regex chars except ':'
    .replace(/:([a-zA-Z_][a-zA-Z0-9_]*)/g, (_, name) => {
      paramNames.push(name);
      return '([^/]+)';
    });
  return {
    regex: new RegExp(`^${escaped}(?:\\/|$)`),
    paramNames,
  };
}

/**
 * Wraps Node.js http.ServerResponse with Express-like helpers
 * @param {import('http').ServerResponse} rawRes
 * @returns {HeadyResponse}
 */
function wrapResponse(rawRes) {
  const res = rawRes;

  res.status = (code) => {
    res.statusCode = code;
    return res;
  };

  res.setHeader = (name, value) => {
    rawRes.setHeader(name, value);
    return res;
  };

  res.json = (data) => {
    if (!rawRes.headersSent) {
      rawRes.setHeader('Content-Type', 'application/json; charset=utf-8');
    }
    rawRes.end(JSON.stringify(data));
  };

  res.send = (body) => {
    if (!rawRes.headersSent) {
      if (typeof body === 'string') {
        rawRes.setHeader('Content-Type', 'text/plain; charset=utf-8');
      }
    }
    rawRes.end(body);
  };

  res.redirect = (url, code = 302) => {
    rawRes.statusCode = code;
    rawRes.setHeader('Location', url);
    rawRes.end();
  };

  return res;
}

/**
 * @class HeadyApp
 * @extends EventEmitter
 * Express-compatible HTTP application built on Node.js built-ins.
 */
export class HeadyApp extends EventEmitter {
  constructor() {
    super();
    /** @type {Middleware[]} Global middleware stack */
    this._middleware = [];
    /** @type {RouteDefinition[]} Registered routes */
    this._routes = [];
    /** @type {Map<string, HeadyApp>} Sub-routers by prefix */
    this._routers = new Map();
    /** @type {Middleware|null} Error handler */
    this._errorHandler = null;
  }

  /**
   * Registers a global middleware
   * @param {string|Middleware} pathOrFn
   * @param {Middleware} [fn]
   * @returns {this}
   */
  use(pathOrFn, fn) {
    if (typeof pathOrFn === 'function') {
      this._middleware.push(pathOrFn);
    } else if (typeof fn === 'function') {
      // Sub-router mount
      const prefix = pathOrFn.replace(/\/$/, '');
      if (fn instanceof HeadyRouter || fn instanceof HeadyApp) {
        this._routers.set(prefix, fn);
      } else {
        this._middleware.push((req, res, next) => {
          if (req.path.startsWith(prefix)) {
            const savedPath = req.path;
            req.path = req.path.slice(prefix.length) || '/';
            fn(req, res, (err) => {
              req.path = savedPath;
              next(err);
            });
          } else {
            next();
          }
        });
      }
    }
    return this;
  }

  /**
   * Registers a route
   * @param {string} method
   * @param {string} path
   * @param {...Middleware} handlers
   * @returns {this}
   */
  _addRoute(method, path, ...handlers) {
    this._routes.push({ method, path, handlers });
    return this;
  }

  /** @param {string} path @param {...Middleware} handlers */
  get(path, ...handlers) { return this._addRoute('GET', path, ...handlers); }
  /** @param {string} path @param {...Middleware} handlers */
  post(path, ...handlers) { return this._addRoute('POST', path, ...handlers); }
  /** @param {string} path @param {...Middleware} handlers */
  put(path, ...handlers) { return this._addRoute('PUT', path, ...handlers); }
  /** @param {string} path @param {...Middleware} handlers */
  patch(path, ...handlers) { return this._addRoute('PATCH', path, ...handlers); }
  /** @param {string} path @param {...Middleware} handlers */
  delete(path, ...handlers) { return this._addRoute('DELETE', path, ...handlers); }
  /** @param {string} path @param {...Middleware} handlers */
  options(path, ...handlers) { return this._addRoute('OPTIONS', path, ...handlers); }
  /** @param {string} path @param {...Middleware} handlers */
  all(path, ...handlers) { return this._addRoute('ALL', path, ...handlers); }

  /**
   * Registers a 4-argument error handler
   * @param {function(Error, HeadyRequest, HeadyResponse, Function): void} fn
   */
  setErrorHandler(fn) {
    this._errorHandler = fn;
    return this;
  }

  /**
   * Core request dispatcher
   * @param {HeadyRequest} req
   * @param {HeadyResponse} res
   */
  async dispatch(req, res) {
    const allMiddleware = [...this._middleware];

    // Check sub-routers
    for (const [prefix, router] of this._routers) {
      if (req.path.startsWith(prefix)) {
        allMiddleware.push((r, s, next) => {
          const saved = r.path;
          r.path = r.path.slice(prefix.length) || '/';
          router.dispatch(r, s, next).finally(() => { r.path = saved; });
        });
      }
    }

    // Route matching
    const matchedRoute = this._matchRoute(req.method, req.path);
    if (matchedRoute) {
      req.params = matchedRoute.params;
      allMiddleware.push(...matchedRoute.handlers);
    }

    // Error handler
    if (this._errorHandler) {
      allMiddleware.push((err, r, s, next) => this._errorHandler(err, r, s, next));
    }

    await this._runMiddleware(allMiddleware, req, res);
  }

  /**
   * Finds a matching route
   * @param {string} method
   * @param {string} path
   * @returns {{ handlers: Middleware[], params: Record<string, string> }|null}
   */
  _matchRoute(method, path) {
    for (const route of this._routes) {
      if (route.method !== method && route.method !== 'ALL') continue;
      const { regex, paramNames } = compileRoute(route.path);
      const match = path.match(regex);
      if (match) {
        const params = {};
        paramNames.forEach((name, i) => { params[name] = match[i + 1]; });
        return { handlers: route.handlers, params };
      }
    }
    return null;
  }

  /**
   * Runs a middleware chain sequentially
   * @param {Middleware[]} stack
   * @param {HeadyRequest} req
   * @param {HeadyResponse} res
   */
  async _runMiddleware(stack, req, res) {
    let i = 0;
    const next = async (err) => {
      if (res.writableEnded) return;
      if (i >= stack.length) {
        // 404 if no route matched
        if (!res.writableEnded) {
          res.statusCode = 404;
          res.json({ error: 'Not Found', path: req.path });
        }
        return;
      }
      const fn = stack[i++];
      try {
        if (err && fn.length === 4) {
          await fn(err, req, res, next);
        } else if (!err && fn.length !== 4) {
          await fn(req, res, next);
        } else {
          await next(err);
        }
      } catch (e) {
        await next(e);
      }
    };
    await next();
  }

  /**
   * Creates and returns the underlying HTTP server
   * @returns {import('http').Server}
   */
  listen(port, host, callback) {
    const server = createServer((rawReq, rawRes) => {
      const urlParsed = new URL(rawReq.url || '/', `http://heady.ai`);

      /** @type {HeadyRequest} */
      const req = Object.assign(rawReq, {
        method: rawReq.method?.toUpperCase() || 'GET',
        url: rawReq.url || '/',
        path: urlParsed.pathname,
        query: parseQuery(urlParsed.search.slice(1)),
        headers: rawReq.headers,
        params: {},
        body: null,
        requestId: uuid(),
        startTime: Date.now(),
        ip: rawReq.socket?.remoteAddress || 'unknown',
      });

      const res = wrapResponse(rawRes);

      this.dispatch(req, res).catch(err => {
        log.error('Unhandled dispatch error', { error: err.message, path: req.path });
        if (!rawRes.headersSent) {
          rawRes.statusCode = 500;
          rawRes.setHeader('Content-Type', 'application/json');
          rawRes.end(JSON.stringify({ error: 'Internal Server Error' }));
        }
      });
    });

    if (typeof host === 'function') {
      callback = host;
      host = '0.0.0.0';
    }

    server.listen(port, host || '0.0.0.0', () => {
      log.info('HeadyServer listening', { port, host: host || '0.0.0.0' });
      if (callback) callback(server);
    });

    return server;
  }
}

/**
 * @class HeadyRouter
 * Mountable sub-router (same interface as HeadyApp)
 */
export class HeadyRouter extends HeadyApp {
  constructor() {
    super();
  }
}

/**
 * Creates a new HeadyApp instance
 * @returns {HeadyApp}
 */
export function createApp() {
  return new HeadyApp();
}

/**
 * Creates a new HeadyRouter instance
 * @returns {HeadyRouter}
 */
export function createRouter() {
  return new HeadyRouter();
}

export default { HeadyApp, HeadyRouter, createApp, createRouter };
