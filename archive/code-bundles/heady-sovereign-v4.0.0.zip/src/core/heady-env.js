/**
 * ∞ Heady™ Env — Environment variable loader with typed getters and domain validation
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { readFileSync, existsSync } from 'fs';
import { resolve, join } from 'path';

/** Approved branded domains — no localhost allowed */
const HEADY_APPROVED_DOMAINS = [
  'heady.ai',
  'headysystems.ai',
  'headyme.ai',
  'headyconnection.org',
  'headyapi.ai',
  'heady.app',
  'heady.io',
  'heady.network',
  'api.heady.ai',
  'edge.heady.ai',
  'voice.heady.ai',
  'vector.heady.ai',
  'auth.heady.ai',
  'mcp.heady.ai',
  'tunnel.heady.ai',
  '*.heady.ai',
  '*.headysystems.ai',
  '*.cloudflare.com',
  '*.cfargotunnel.com',
  '*.workers.dev',
  'neon.tech',
  '*.neon.tech',
];

/**
 * Validates that a URL string does not reference localhost or private network addresses
 * @param {string} value
 * @param {string} key
 * @throws {Error} if the URL contains a forbidden hostname
 */
function assertNoLocalhost(value, key) {
  const FORBIDDEN = [
    'localhost',
    '127.0.0.1',
    '0.0.0.0',
    '::1',
    '192.168.',
    '10.',
    '172.16.',
    '172.17.',
    '172.18.',
    '172.19.',
    '172.20.',
    '172.21.',
    '172.22.',
    '172.23.',
    '172.24.',
    '172.25.',
    '172.26.',
    '172.27.',
    '172.28.',
    '172.29.',
    '172.30.',
    '172.31.',
  ];
  const lower = value.toLowerCase();
  for (const forbidden of FORBIDDEN) {
    if (lower.includes(forbidden)) {
      throw new Error(
        `[HeadyEnv] CRITICAL: ${key} contains forbidden local address "${forbidden}". ` +
        `Only branded Heady domains are permitted. Value: ${value}`
      );
    }
  }
}

/**
 * Parses a .env file content into key-value pairs
 * Supports: comments (#), quoted values, multiline values with \n
 * @param {string} content
 * @returns {Record<string, string>}
 */
function parseDotEnv(content) {
  const result = {};
  const lines = content.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    // Skip blanks and comments
    if (!line || line.startsWith('#')) continue;

    const eqIdx = line.indexOf('=');
    if (eqIdx === -1) continue;

    const key = line.substring(0, eqIdx).trim();
    let value = line.substring(eqIdx + 1).trim();

    // Handle quoted values
    if ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1)
        .replace(/\\n/g, '\n')
        .replace(/\\r/g, '\r')
        .replace(/\\t/g, '\t')
        .replace(/\\\\/g, '\\')
        .replace(/\\"/g, '"')
        .replace(/\\'/g, "'");
    } else {
      // Strip inline comments
      const commentIdx = value.indexOf(' #');
      if (commentIdx !== -1) {
        value = value.substring(0, commentIdx).trim();
      }
    }

    if (key) result[key] = value;
  }

  return result;
}

/**
 * @class HeadyEnv
 * Central environment manager for the Heady platform.
 * Loads .env files, exposes typed getters, enforces domain policy.
 */
export class HeadyEnv {
  /**
   * @param {object} [options]
   * @param {string[]} [options.envFiles] - Ordered list of .env file paths to load
   * @param {boolean} [options.strict=false] - Throw on missing required variables
   * @param {boolean} [options.validate=true] - Validate URL variables for localhost
   * @param {string} [options.prefix='HEADY_'] - Prefix filter for platform variables
   */
  constructor(options = {}) {
    this._loaded = {};
    this._strict = options.strict ?? false;
    this._validate = options.validate ?? true;
    this._prefix = options.prefix ?? 'HEADY_';

    const envFiles = options.envFiles ?? this._defaultEnvFiles();
    this._loadFiles(envFiles);

    // Merge with process.env (process.env takes precedence)
    this._env = { ...this._loaded, ...process.env };
  }

  /**
   * Returns default .env file candidates in load order
   * @returns {string[]}
   */
  _defaultEnvFiles() {
    const cwd = process.cwd();
    const nodeEnv = process.env.NODE_ENV || 'development';
    return [
      join(cwd, '.env'),
      join(cwd, `.env.${nodeEnv}`),
      join(cwd, '.env.local'),
      join(cwd, `.env.${nodeEnv}.local`),
    ];
  }

  /**
   * Loads env files in order (later files override earlier ones)
   * @param {string[]} files
   */
  _loadFiles(files) {
    for (const file of files) {
      const absPath = resolve(file);
      if (!existsSync(absPath)) continue;
      try {
        const content = readFileSync(absPath, 'utf8');
        const parsed = parseDotEnv(content);
        Object.assign(this._loaded, parsed);
      } catch (err) {
        // Non-fatal: log and continue
        if (process.env.HEADY_LOG_LEVEL === 'debug') {
          process.stderr.write(`[HeadyEnv] Warning: could not load ${absPath}: ${err.message}\n`);
        }
      }
    }
  }

  /**
   * Retrieves a raw string value
   * @param {string} key
   * @param {string} [defaultValue]
   * @returns {string|undefined}
   */
  getRaw(key, defaultValue) {
    return this._env[key] ?? defaultValue;
  }

  /**
   * Gets a string value
   * @param {string} key
   * @param {string} [defaultValue]
   * @returns {string}
   */
  getString(key, defaultValue = '') {
    const value = this._env[key];
    if (value === undefined || value === '') {
      if (this._strict && defaultValue === '') {
        throw new Error(`[HeadyEnv] Required variable "${key}" is not set`);
      }
      return defaultValue;
    }
    return value;
  }

  /**
   * Gets an integer value
   * @param {string} key
   * @param {number} [defaultValue=0]
   * @returns {number}
   */
  getInt(key, defaultValue = 0) {
    const value = this._env[key];
    if (value === undefined || value === '') return defaultValue;
    const parsed = parseInt(value, 10);
    if (isNaN(parsed)) {
      throw new Error(`[HeadyEnv] Variable "${key}" is not a valid integer: ${value}`);
    }
    return parsed;
  }

  /**
   * Gets a float value
   * @param {string} key
   * @param {number} [defaultValue=0.0]
   * @returns {number}
   */
  getFloat(key, defaultValue = 0.0) {
    const value = this._env[key];
    if (value === undefined || value === '') return defaultValue;
    const parsed = parseFloat(value);
    if (isNaN(parsed)) {
      throw new Error(`[HeadyEnv] Variable "${key}" is not a valid float: ${value}`);
    }
    return parsed;
  }

  /**
   * Gets a boolean value. Truthy strings: 'true', '1', 'yes', 'on'
   * @param {string} key
   * @param {boolean} [defaultValue=false]
   * @returns {boolean}
   */
  getBool(key, defaultValue = false) {
    const value = this._env[key];
    if (value === undefined || value === '') return defaultValue;
    return ['true', '1', 'yes', 'on', 'enabled'].includes(value.toLowerCase());
  }

  /**
   * Gets a URL value with domain validation (no localhost)
   * @param {string} key
   * @param {string} [defaultValue='']
   * @returns {string}
   */
  getUrl(key, defaultValue = '') {
    const value = this.getString(key, defaultValue);
    if (!value) return value;

    if (this._validate) {
      assertNoLocalhost(value, key);
    }

    // Validate URL format
    try {
      new URL(value);
    } catch {
      throw new Error(`[HeadyEnv] Variable "${key}" is not a valid URL: ${value}`);
    }

    return value;
  }

  /**
   * Gets a JSON-parsed value
   * @template T
   * @param {string} key
   * @param {T} [defaultValue]
   * @returns {T}
   */
  getJson(key, defaultValue = null) {
    const value = this._env[key];
    if (value === undefined || value === '') return defaultValue;
    try {
      return JSON.parse(value);
    } catch {
      throw new Error(`[HeadyEnv] Variable "${key}" is not valid JSON: ${value}`);
    }
  }

  /**
   * Gets a comma-separated list as an array
   * @param {string} key
   * @param {string[]} [defaultValue=[]]
   * @returns {string[]}
   */
  getList(key, defaultValue = []) {
    const value = this._env[key];
    if (value === undefined || value === '') return defaultValue;
    return value.split(',').map(s => s.trim()).filter(Boolean);
  }

  /**
   * Returns all variables with the HEADY_ prefix as a plain object
   * @returns {Record<string, string>}
   */
  getAll() {
    const result = {};
    for (const [k, v] of Object.entries(this._env)) {
      if (k.startsWith(this._prefix)) {
        result[k] = v;
      }
    }
    return result;
  }

  /**
   * Checks required variables and returns a validation report
   * @param {string[]} required
   * @returns {{ valid: boolean, missing: string[], present: string[] }}
   */
  validate(required = []) {
    const missing = [];
    const present = [];
    for (const key of required) {
      if (this._env[key]) {
        present.push(key);
      } else {
        missing.push(key);
      }
    }
    return { valid: missing.length === 0, missing, present };
  }

  /**
   * Common typed accessors for well-known Heady platform variables
   */
  get nodeEnv() { return this.getString('NODE_ENV', 'development'); }
  get isProduction() { return this.nodeEnv === 'production'; }
  get isDevelopment() { return this.nodeEnv === 'development'; }
  get port() { return this.getInt('HEADY_PORT', 3000); }
  get headyMode() { return this.getString('HEADY_MODE', 'sovereign'); }
  get apiUrl() { return this.getUrl('HEADY_API_URL', 'https://api.heady.ai'); }
  get edgeUrl() { return this.getUrl('HEADY_EDGE_URL', 'https://edge.heady.ai'); }
  get vectorUrl() { return this.getUrl('HEADY_VECTOR_URL', 'https://vector.heady.ai'); }
  get authUrl() { return this.getUrl('HEADY_AUTH_URL', 'https://auth.heady.ai'); }
  get logLevel() { return this.getString('HEADY_LOG_LEVEL', 'info'); }
  get logFormat() { return this.getString('HEADY_LOG_FORMAT', 'pretty'); }
  get jwtSecret() { return this.getString('HEADY_JWT_SECRET', ''); }
  get jwtIssuer() { return this.getString('HEADY_JWT_ISSUER', 'heady.ai'); }
  get cfAccountId() { return this.getString('CLOUDFLARE_ACCOUNT_ID', ''); }
  get cfTunnelToken() { return this.getString('CLOUDFLARE_TUNNEL_TOKEN', ''); }
  get neonConnectionString() { return this.getString('NEON_DATABASE_URL', ''); }
}

/** Singleton HeadyEnv instance */
export const env = new HeadyEnv();

export default HeadyEnv;
