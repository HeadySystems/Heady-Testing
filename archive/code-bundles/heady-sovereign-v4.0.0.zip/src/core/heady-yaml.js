/**
 * ∞ Heady™ YAML — Zero-dependency YAML parser and serializer
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

/**
 * @typedef {'string'|'number'|'boolean'|'null'|'array'|'object'} YamlValueType
 */

/**
 * Minimal but robust YAML parser for the Heady platform.
 * Supports: scalars, block mappings, block sequences, inline arrays,
 * inline objects, multi-line strings (| and >), comments, anchors/aliases (basic).
 */

const INDENT_SIZE = 2;

// ─── Serializer ──────────────────────────────────────────────────────────────

/**
 * Determines if a string needs quoting in YAML
 * @param {string} str
 * @returns {boolean}
 */
function needsQuoting(str) {
  if (str === '') return true;
  if (/^[\s]|[\s]$/.test(str)) return true;
  if (/^(true|false|null|yes|no|on|off)$/i.test(str)) return true;
  if (/^-?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(str)) return true;
  if (/^[{[\]},:#*&!|>'"%@`]/.test(str)) return true;
  if (/[\n\r]/.test(str)) return true;
  if (/: /.test(str) || str.endsWith(':')) return true;
  if (str.includes(' #')) return true;
  return false;
}

/**
 * Escapes a string for double-quoted YAML
 * @param {string} str
 * @returns {string}
 */
function escapeString(str) {
  return str
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '\\r')
    .replace(/\t/g, '\\t');
}

/**
 * Serializes a JS value to YAML string
 * @param {unknown} value
 * @param {number} [indent=0]
 * @param {boolean} [inlineMode=false]
 * @returns {string}
 */
function serializeValue(value, indent = 0, inlineMode = false) {
  if (value === null || value === undefined) return 'null';
  if (typeof value === 'boolean') return value ? 'true' : 'false';
  if (typeof value === 'number') {
    if (!isFinite(value)) return value > 0 ? '.inf' : '-.inf';
    if (isNaN(value)) return '.nan';
    return String(value);
  }
  if (typeof value === 'string') {
    if (needsQuoting(value)) return `"${escapeString(value)}"`;
    return value;
  }
  if (value instanceof Date) {
    return value.toISOString();
  }
  if (Array.isArray(value)) {
    if (inlineMode || value.length === 0) {
      const items = value.map(v => serializeValue(v, 0, true)).join(', ');
      return `[${items}]`;
    }
    const pad = ' '.repeat(indent);
    return value.map(v => {
      const serialized = serializeValue(v, indent + INDENT_SIZE);
      if (typeof v === 'object' && v !== null && !Array.isArray(v)) {
        return `${pad}- ${serialized.trimStart()}`;
      }
      return `${pad}- ${serialized}`;
    }).join('\n');
  }
  if (typeof value === 'object') {
    const entries = Object.entries(value);
    if (entries.length === 0) return '{}';
    if (inlineMode) {
      const pairs = entries.map(([k, v]) => `${k}: ${serializeValue(v, 0, true)}`).join(', ');
      return `{${pairs}}`;
    }
    const pad = ' '.repeat(indent);
    return entries.map(([k, v]) => {
      const keyStr = needsQuoting(String(k)) ? `"${escapeString(String(k))}"` : String(k);
      if (Array.isArray(v)) {
        if (v.length === 0) return `${pad}${keyStr}: []`;
        return `${pad}${keyStr}:\n${serializeValue(v, indent + INDENT_SIZE)}`;
      }
      if (typeof v === 'object' && v !== null) {
        const entries2 = Object.entries(v);
        if (entries2.length === 0) return `${pad}${keyStr}: {}`;
        return `${pad}${keyStr}:\n${serializeValue(v, indent + INDENT_SIZE)}`;
      }
      return `${pad}${keyStr}: ${serializeValue(v, indent + INDENT_SIZE)}`;
    }).join('\n');
  }
  return String(value);
}

/**
 * Serializes a JS object/array to a YAML string
 * @param {unknown} data
 * @returns {string}
 */
export function stringify(data) {
  if (data === null || data === undefined) return 'null\n';
  const result = serializeValue(data, 0);
  return result.endsWith('\n') ? result : result + '\n';
}

// ─── Parser ───────────────────────────────────────────────────────────────────

/**
 * Casts a raw scalar string to its JS type
 * @param {string} raw
 * @returns {unknown}
 */
function castScalar(raw) {
  const trimmed = raw.trim();

  // Null
  if (trimmed === '' || trimmed === 'null' || trimmed === '~') return null;

  // Boolean
  if (/^(true|yes|on)$/i.test(trimmed)) return true;
  if (/^(false|no|off)$/i.test(trimmed)) return false;

  // Number
  if (/^-?0x[0-9a-fA-F]+$/.test(trimmed)) return parseInt(trimmed, 16);
  if (/^-?0o[0-7]+$/.test(trimmed)) return parseInt(trimmed.replace('0o', ''), 8);
  if (/^-?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$/.test(trimmed)) return Number(trimmed);
  if (trimmed === '.inf' || trimmed === '+.inf') return Infinity;
  if (trimmed === '-.inf') return -Infinity;
  if (trimmed === '.nan') return NaN;

  // Quoted strings
  if ((trimmed.startsWith('"') && trimmed.endsWith('"')) ||
      (trimmed.startsWith("'") && trimmed.endsWith("'"))) {
    const inner = trimmed.slice(1, -1);
    if (trimmed.startsWith('"')) {
      return inner
        .replace(/\\n/g, '\n').replace(/\\r/g, '\r').replace(/\\t/g, '\t')
        .replace(/\\"/g, '"').replace(/\\\\/g, '\\');
    }
    return inner.replace(/''/g, "'");
  }

  return trimmed;
}

/**
 * Parses a YAML document string into a JS value
 * @param {string} yamlStr
 * @returns {unknown}
 */
export function parse(yamlStr) {
  if (typeof yamlStr !== 'string') throw new TypeError('[HeadyYaml] Input must be a string');

  // Remove BOM and normalize line endings
  const cleaned = yamlStr.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
  const lines = cleaned.split('\n');

  // Strip document markers
  const filteredLines = lines.filter(l => l !== '---' && l !== '...');

  const result = parseBlock(filteredLines, 0);
  return result.value;
}

/**
 * Parses a block of YAML lines starting at a given indent level
 * @param {string[]} lines
 * @param {number} baseIndent
 * @returns {{ value: unknown }}
 */
function parseBlock(lines, baseIndent) {
  // Find first non-empty, non-comment line
  let firstLineIdx = -1;
  for (let i = 0; i < lines.length; i++) {
    const stripped = lines[i].replace(/#.*$/, '').trimEnd();
    if (stripped.trim() !== '') {
      firstLineIdx = i;
      break;
    }
  }
  if (firstLineIdx === -1) return { value: null };

  const firstLine = lines[firstLineIdx];
  const firstIndent = firstLine.search(/\S/);
  const content = firstLine.trim().replace(/#.*$/, '').trim();

  // Sequence (block list)
  if (content.startsWith('- ') || content === '-') {
    return { value: parseSequence(lines, firstIndent) };
  }

  // Mapping (block object)
  if (/^[\w"'].*:/.test(content)) {
    return { value: parseMapping(lines, firstIndent) };
  }

  // Scalar fallback
  return { value: castScalar(content) };
}

/**
 * Parses a YAML block sequence
 * @param {string[]} lines
 * @param {number} indent
 * @returns {Array<unknown>}
 */
function parseSequence(lines, indent) {
  const result = [];
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];
    if (line.trim() === '' || line.trim().startsWith('#')) { i++; continue; }
    const lineIndent = line.search(/\S/);
    if (lineIndent < indent) break;
    if (lineIndent === indent && line.trim().startsWith('- ')) {
      const valueStr = line.trim().substring(2).trim();

      if (valueStr === '' || valueStr === '|' || valueStr === '>') {
        // Block scalar or nested structure — collect child lines
        const childLines = [];
        i++;
        while (i < lines.length) {
          const cl = lines[i];
          if (cl.trim() === '' || cl.search(/\S/) > indent) {
            childLines.push(cl);
            i++;
          } else break;
        }
        if (valueStr === '|' || valueStr === '>') {
          result.push(parseBlockScalar(childLines, indent + INDENT_SIZE, valueStr === '|'));
        } else {
          result.push(parseBlock(childLines, indent + INDENT_SIZE).value);
        }
      } else if (valueStr.startsWith('{') || valueStr.startsWith('[')) {
        result.push(parseInline(valueStr));
        i++;
      } else if (valueStr.includes(': ')) {
        // Inline mapping on same line as -
        const childLines = [' '.repeat(indent + INDENT_SIZE) + valueStr];
        i++;
        while (i < lines.length && lines[i].search(/\S/) > indent) {
          childLines.push(lines[i]);
          i++;
        }
        result.push(parseMapping(childLines, indent + INDENT_SIZE));
      } else {
        result.push(castScalar(valueStr));
        i++;
      }
    } else {
      i++;
    }
  }
  return result;
}

/**
 * Parses a YAML block mapping
 * @param {string[]} lines
 * @param {number} indent
 * @returns {Record<string, unknown>}
 */
function parseMapping(lines, indent) {
  const result = {};
  let i = 0;

  while (i < lines.length) {
    const line = lines[i];
    if (line.trim() === '' || line.trim().startsWith('#')) { i++; continue; }
    const lineIndent = line.search(/\S/);
    if (lineIndent < indent) break;
    if (lineIndent !== indent) { i++; continue; }

    const colonIdx = findMappingColon(line.trim());
    if (colonIdx === -1) { i++; continue; }

    const rawKey = line.trim().substring(0, colonIdx).trim();
    const key = String(castScalar(rawKey));
    const rawValue = line.trim().substring(colonIdx + 1).trim();

    i++;

    if (rawValue === '|' || rawValue === '>') {
      // Block scalar
      const childLines = [];
      while (i < lines.length && (lines[i].trim() === '' || lines[i].search(/\S/) > indent)) {
        childLines.push(lines[i]);
        i++;
      }
      result[key] = parseBlockScalar(childLines, indent + INDENT_SIZE, rawValue === '|');
    } else if (rawValue === '' || rawValue === null) {
      // Nested block
      const childLines = [];
      while (i < lines.length && (lines[i].trim() === '' || lines[i].trim().startsWith('#') || lines[i].search(/\S/) > indent)) {
        childLines.push(lines[i]);
        i++;
      }
      if (childLines.length > 0) {
        result[key] = parseBlock(childLines, indent + INDENT_SIZE).value;
      } else {
        result[key] = null;
      }
    } else if (rawValue.startsWith('{') || rawValue.startsWith('[')) {
      result[key] = parseInline(rawValue);
    } else {
      result[key] = castScalar(rawValue.replace(/#.*$/, '').trim());
    }
  }

  return result;
}

/**
 * Finds the colon index for a mapping key (skips colons in quoted strings)
 * @param {string} line
 * @returns {number}
 */
function findMappingColon(line) {
  let inQuote = false;
  let quoteChar = '';
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (inQuote) {
      if (ch === quoteChar && line[i - 1] !== '\\') inQuote = false;
    } else if (ch === '"' || ch === "'") {
      inQuote = true;
      quoteChar = ch;
    } else if (ch === ':' && (i + 1 >= line.length || line[i + 1] === ' ' || line[i + 1] === '\n')) {
      return i;
    }
  }
  return -1;
}

/**
 * Parses block scalar (| literal or > folded)
 * @param {string[]} lines
 * @param {number} indent
 * @param {boolean} literal
 * @returns {string}
 */
function parseBlockScalar(lines, indent, literal) {
  const filtered = lines.map(l => {
    const li = l.search(/\S/);
    return li >= indent ? l.substring(indent) : l.trim() === '' ? '' : l;
  });
  if (literal) {
    return filtered.join('\n').replace(/\n+$/, '\n');
  }
  // Folded: join non-empty lines with space, preserve blank line paragraphs
  const result = [];
  for (const line of filtered) {
    if (line === '') result.push('\n');
    else result.push(line);
  }
  return result.join(' ').replace(/ \n /g, '\n').replace(/\n+$/, '\n').trim();
}

/**
 * Parses inline YAML (JSON-compatible subset)
 * @param {string} str
 * @returns {unknown}
 */
function parseInline(str) {
  try {
    // Try JSON first (handles most inline cases)
    return JSON.parse(str);
  } catch {
    // Fall back to manual scalar
    return castScalar(str);
  }
}

/**
 * Parses multiple YAML documents separated by ---
 * @param {string} yamlStr
 * @returns {unknown[]}
 */
export function parseAll(yamlStr) {
  const docs = yamlStr.split(/^---\s*$/m).filter(d => d.trim());
  return docs.map(doc => parse(doc));
}

/**
 * Loads and parses a YAML file synchronously
 * @param {string} filePath
 * @returns {unknown}
 */
export async function load(filePath) {
  const { readFileSync } = await import('fs');
  return parse(readFileSync(filePath, 'utf8'));
}

export default { parse, stringify, parseAll };
