/**
 * ∞ Heady™ Crypt — Crypto utilities: hashing, HMAC, AES-256-GCM, key derivation
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import {
  createHash,
  createHmac,
  createCipheriv,
  createDecipheriv,
  randomBytes,
  scrypt,
  pbkdf2,
  timingSafeEqual,
} from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(scrypt);
const pbkdf2Async = promisify(pbkdf2);

/** AES-256-GCM constants */
const AES_ALGO = 'aes-256-gcm';
const IV_LENGTH = 12;       // 96 bits recommended for GCM
const AUTH_TAG_LENGTH = 16; // 128-bit auth tag
const KEY_LENGTH = 32;      // 256-bit key

/** Default scrypt parameters */
const SCRYPT_N = 16384;
const SCRYPT_R = 8;
const SCRYPT_P = 1;

// ─── Hashing ──────────────────────────────────────────────────────────────────

/**
 * Computes a SHA-256 hash
 * @param {string|Buffer} data
 * @param {'hex'|'base64'|'base64url'} [encoding='hex']
 * @returns {string}
 */
export function sha256(data, encoding = 'hex') {
  const hash = createHash('sha256').update(data).digest('base64');
  if (encoding === 'base64url') return hash.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
  if (encoding === 'base64') return hash;
  return createHash('sha256').update(data).digest('hex');
}

/**
 * Computes a SHA-384 hash
 * @param {string|Buffer} data
 * @param {'hex'|'base64'} [encoding='hex']
 * @returns {string}
 */
export function sha384(data, encoding = 'hex') {
  return createHash('sha384').update(data).digest(encoding);
}

/**
 * Computes a SHA-512 hash
 * @param {string|Buffer} data
 * @param {'hex'|'base64'} [encoding='hex']
 * @returns {string}
 */
export function sha512(data, encoding = 'hex') {
  return createHash('sha512').update(data).digest(encoding);
}

/**
 * Computes a BLAKE2b512 hash (if supported by OpenSSL build)
 * Falls back to SHA-512
 * @param {string|Buffer} data
 * @returns {string} hex hash
 */
export function blake2b(data) {
  try {
    return createHash('blake2b512').update(data).digest('hex');
  } catch {
    return sha512(data);
  }
}

// ─── HMAC ─────────────────────────────────────────────────────────────────────

/**
 * Computes an HMAC-SHA256 signature
 * @param {string|Buffer} data
 * @param {string|Buffer} key
 * @param {'hex'|'base64'|'base64url'} [encoding='hex']
 * @returns {string}
 */
export function hmac256(data, key, encoding = 'hex') {
  const sig = createHmac('sha256', key).update(data).digest('base64');
  if (encoding === 'base64url') return sig.replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
  if (encoding === 'base64') return sig;
  return createHmac('sha256', key).update(data).digest('hex');
}

/**
 * Computes an HMAC-SHA512 signature
 * @param {string|Buffer} data
 * @param {string|Buffer} key
 * @param {'hex'|'base64'} [encoding='hex']
 * @returns {string}
 */
export function hmac512(data, key, encoding = 'hex') {
  return createHmac('sha512', key).update(data).digest(encoding);
}

/**
 * Verifies an HMAC-SHA256 signature using constant-time comparison
 * @param {string|Buffer} data
 * @param {string|Buffer} key
 * @param {string} signature - Expected signature (hex)
 * @returns {boolean}
 */
export function verifyHmac(data, key, signature) {
  const expected = createHmac('sha256', key).update(data).digest();
  const actual = Buffer.from(signature, 'hex');
  if (expected.length !== actual.length) return false;
  return timingSafeEqual(expected, actual);
}

// ─── AES-256-GCM Encryption ───────────────────────────────────────────────────

/**
 * Encrypts data using AES-256-GCM
 * @param {string|Buffer} plaintext - Data to encrypt
 * @param {string|Buffer} key - 32-byte key (or string that will be hashed to 32 bytes)
 * @param {object} [options]
 * @param {string|Buffer} [options.aad] - Additional authenticated data
 * @returns {{ ciphertext: string, iv: string, tag: string }} All hex-encoded
 */
export function encrypt(plaintext, key, options = {}) {
  const keyBuf = normalizeKey(key);
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv(AES_ALGO, keyBuf, iv, { authTagLength: AUTH_TAG_LENGTH });

  if (options.aad) {
    cipher.setAAD(Buffer.isBuffer(options.aad) ? options.aad : Buffer.from(options.aad));
  }

  const data = typeof plaintext === 'string' ? Buffer.from(plaintext, 'utf8') : plaintext;
  const encrypted = Buffer.concat([cipher.update(data), cipher.final()]);
  const tag = cipher.getAuthTag();

  return {
    ciphertext: encrypted.toString('hex'),
    iv: iv.toString('hex'),
    tag: tag.toString('hex'),
  };
}

/**
 * Decrypts data using AES-256-GCM
 * @param {object} envelope - Result from encrypt()
 * @param {string} envelope.ciphertext - Hex-encoded ciphertext
 * @param {string} envelope.iv - Hex-encoded IV
 * @param {string} envelope.tag - Hex-encoded auth tag
 * @param {string|Buffer} key - 32-byte key
 * @param {object} [options]
 * @param {string|Buffer} [options.aad] - Additional authenticated data (must match encryption)
 * @returns {string} Decrypted plaintext
 * @throws {Error} If auth tag verification fails (tampered data)
 */
export function decrypt({ ciphertext, iv, tag }, key, options = {}) {
  const keyBuf = normalizeKey(key);
  const decipher = createDecipheriv(
    AES_ALGO,
    keyBuf,
    Buffer.from(iv, 'hex'),
    { authTagLength: AUTH_TAG_LENGTH }
  );

  decipher.setAuthTag(Buffer.from(tag, 'hex'));

  if (options.aad) {
    decipher.setAAD(Buffer.isBuffer(options.aad) ? options.aad : Buffer.from(options.aad));
  }

  try {
    const decrypted = Buffer.concat([
      decipher.update(Buffer.from(ciphertext, 'hex')),
      decipher.final(),
    ]);
    return decrypted.toString('utf8');
  } catch (err) {
    throw new Error(`[HeadyCrypt] Decryption failed — data may be tampered: ${err.message}`);
  }
}

/**
 * Encrypts to a compact string format: base64url(iv + ciphertext + tag)
 * @param {string} plaintext
 * @param {string|Buffer} key
 * @returns {string} Compact encrypted string
 */
export function encryptCompact(plaintext, key) {
  const { ciphertext, iv, tag } = encrypt(plaintext, key);
  const combined = Buffer.concat([
    Buffer.from(iv, 'hex'),
    Buffer.from(tag, 'hex'),
    Buffer.from(ciphertext, 'hex'),
  ]);
  return combined.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

/**
 * Decrypts a compact encrypted string from encryptCompact()
 * @param {string} compact
 * @param {string|Buffer} key
 * @returns {string}
 */
export function decryptCompact(compact, key) {
  const padded = compact + '='.repeat((4 - (compact.length % 4)) % 4);
  const combined = Buffer.from(padded.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
  const iv = combined.subarray(0, IV_LENGTH).toString('hex');
  const tag = combined.subarray(IV_LENGTH, IV_LENGTH + AUTH_TAG_LENGTH).toString('hex');
  const ciphertext = combined.subarray(IV_LENGTH + AUTH_TAG_LENGTH).toString('hex');
  return decrypt({ ciphertext, iv, tag }, key);
}

// ─── Key Derivation ───────────────────────────────────────────────────────────

/**
 * Derives a key from a password using scrypt (async)
 * @param {string} password
 * @param {string|Buffer} [salt] - Hex salt or Buffer (auto-generated if not provided)
 * @param {object} [options]
 * @param {number} [options.N=16384] - CPU/memory cost
 * @param {number} [options.r=8] - Block size
 * @param {number} [options.p=1] - Parallelization
 * @returns {Promise<{ key: string, salt: string }>} Hex-encoded key and salt
 */
export async function deriveKey(password, salt, options = {}) {
  const saltBuf = salt
    ? (Buffer.isBuffer(salt) ? salt : Buffer.from(salt, 'hex'))
    : randomBytes(16);

  const N = options.N || SCRYPT_N;
  const r = options.r || SCRYPT_R;
  const p = options.p || SCRYPT_P;

  const key = await scryptAsync(password, saltBuf, KEY_LENGTH, { N, r, p });
  return {
    key: key.toString('hex'),
    salt: saltBuf.toString('hex'),
  };
}

/**
 * Derives a key using PBKDF2-HMAC-SHA256 (async)
 * @param {string} password
 * @param {string|Buffer} [salt]
 * @param {number} [iterations=100000]
 * @returns {Promise<{ key: string, salt: string }>}
 */
export async function pbkdf2Key(password, salt, iterations = 100000) {
  const saltBuf = salt
    ? (Buffer.isBuffer(salt) ? salt : Buffer.from(salt, 'hex'))
    : randomBytes(16);
  const key = await pbkdf2Async(password, saltBuf, iterations, KEY_LENGTH, 'sha256');
  return {
    key: key.toString('hex'),
    salt: saltBuf.toString('hex'),
  };
}

// ─── Utilities ────────────────────────────────────────────────────────────────

/**
 * Normalizes a key to a 32-byte Buffer (hashes string keys to 32 bytes)
 * @param {string|Buffer} key
 * @returns {Buffer}
 */
function normalizeKey(key) {
  if (Buffer.isBuffer(key)) {
    if (key.length === KEY_LENGTH) return key;
    return createHash('sha256').update(key).digest();
  }
  if (typeof key === 'string') {
    if (key.length === KEY_LENGTH * 2 && /^[0-9a-f]+$/i.test(key)) {
      // Hex key of correct length
      return Buffer.from(key, 'hex');
    }
    // Hash string key to 32 bytes
    return createHash('sha256').update(key, 'utf8').digest();
  }
  throw new TypeError('[HeadyCrypt] Key must be a string or Buffer');
}

/**
 * Generates cryptographically secure random bytes
 * @param {number} [bytes=32]
 * @param {'hex'|'base64'|'base64url'} [encoding='hex']
 * @returns {string}
 */
export function randomHex(bytes = 32, encoding = 'hex') {
  const buf = randomBytes(bytes);
  if (encoding === 'base64url') {
    return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
  }
  return buf.toString(encoding);
}

/**
 * Generates a random UUID v4
 * @returns {string}
 */
export function uuid() {
  const bytes = randomBytes(16);
  bytes[6] = (bytes[6] & 0x0f) | 0x40; // version 4
  bytes[8] = (bytes[8] & 0x3f) | 0x80; // variant bits
  const hex = bytes.toString('hex');
  return [
    hex.substring(0, 8),
    hex.substring(8, 12),
    hex.substring(12, 16),
    hex.substring(16, 20),
    hex.substring(20, 32),
  ].join('-');
}

/**
 * Constant-time string comparison (prevents timing attacks)
 * @param {string} a
 * @param {string} b
 * @returns {boolean}
 */
export function safeEqual(a, b) {
  const bufA = Buffer.from(String(a), 'utf8');
  const bufB = Buffer.from(String(b), 'utf8');
  if (bufA.length !== bufB.length) {
    // Still do the comparison to avoid timing leak on length
    timingSafeEqual(bufA, Buffer.alloc(bufA.length));
    return false;
  }
  return timingSafeEqual(bufA, bufB);
}

/**
 * Hashes a password for storage (using scrypt)
 * @param {string} password
 * @returns {Promise<string>} Stored hash string: 'scrypt$N$r$p$salt$key'
 */
export async function hashPassword(password) {
  const { key, salt } = await deriveKey(password);
  return `scrypt$${SCRYPT_N}$${SCRYPT_R}$${SCRYPT_P}$${salt}$${key}`;
}

/**
 * Verifies a password against a stored hash from hashPassword()
 * @param {string} password
 * @param {string} stored
 * @returns {Promise<boolean>}
 */
export async function verifyPassword(password, stored) {
  const parts = stored.split('$');
  if (parts[0] !== 'scrypt' || parts.length !== 6) {
    throw new Error('[HeadyCrypt] Invalid hash format');
  }
  const [, N, r, p, salt, expectedKey] = parts;
  const { key } = await deriveKey(password, salt, {
    N: parseInt(N, 10),
    r: parseInt(r, 10),
    p: parseInt(p, 10),
  });
  return safeEqual(key, expectedKey);
}

export default {
  sha256, sha384, sha512, blake2b,
  hmac256, hmac512, verifyHmac,
  encrypt, decrypt, encryptCompact, decryptCompact,
  deriveKey, pbkdf2Key,
  randomHex, uuid, safeEqual,
  hashPassword, verifyPassword,
};
