/**
 * ∞ Heady™ Scheduler — Cron-like task scheduler with interval and cron expression support
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { EventEmitter } from 'events';
import { createLogger } from './heady-logger.js';

const log = createLogger('HeadyScheduler');

/**
 * @typedef {object} TaskDefinition
 * @property {string} name - Unique task identifier
 * @property {string} [cron] - Cron expression in standard 5-field format (min hour day month weekday)
 * @property {number} [interval] - Interval in ms (alternative to cron)
 * @property {function(): Promise<void>|void} fn - Task function
 * @property {boolean} [runOnStart=false] - Run immediately on register
 * @property {boolean} [exclusive=true] - Prevent overlapping runs
 * @property {number} [timeout] - Max execution time in ms (0 = unlimited)
 * @property {string} [component] - Owning component for logging
 */

/**
 * @typedef {object} TaskRecord
 * @property {string} name
 * @property {TaskDefinition} def
 * @property {boolean} running
 * @property {number} runs
 * @property {number} errors
 * @property {number|null} lastRun - Unix ms
 * @property {number|null} nextRun - Unix ms
 * @property {number|null} lastDuration - ms
 * @property {NodeJS.Timeout|null} timer
 * @property {boolean} enabled
 */

/**
 * Parses a cron field (e.g. step, range, list, or wildcard) to a Set of valid values
 * @param {string} field
 * @param {number} min
 * @param {number} max
 * @returns {Set<number>}
 */
function parseCronField(field, min, max) {
  const result = new Set();

  for (const part of field.split(',')) {
    if (part === '*') {
      for (let i = min; i <= max; i++) result.add(i);
    } else if (part.startsWith('*/')) {
      const step = parseInt(part.slice(2), 10);
      for (let i = min; i <= max; i += step) result.add(i);
    } else if (part.includes('-')) {
      const [start, end] = part.split('-').map(Number);
      const [lo, hi] = [Math.max(start, min), Math.min(end, max)];
      for (let i = lo; i <= hi; i++) result.add(i);
    } else if (part.includes('/')) {
      const [range, step] = part.split('/');
      const [rStart, rEnd] = range.split('-').map(Number);
      const s = parseInt(step, 10);
      const lo = isNaN(rStart) ? min : rStart;
      const hi = isNaN(rEnd) ? max : rEnd;
      for (let i = lo; i <= hi; i += s) result.add(i);
    } else {
      const n = parseInt(part, 10);
      if (!isNaN(n) && n >= min && n <= max) result.add(n);
    }
  }
  return result;
}

/**
 * Parsed cron schedule
 * @typedef {object} CronSchedule
 * @property {Set<number>} minutes
 * @property {Set<number>} hours
 * @property {Set<number>} days
 * @property {Set<number>} months
 * @property {Set<number>} weekdays
 */

/**
 * Parses a cron expression string into sets of valid values
 * Supports standard 5-field cron: 'min hour day month weekday'
 * @param {string} expression
 * @returns {CronSchedule}
 */
function parseCron(expression) {
  // Named shortcuts
  const shortcuts = {
    '@yearly': '0 0 1 1 *',
    '@annually': '0 0 1 1 *',
    '@monthly': '0 0 1 * *',
    '@weekly': '0 0 * * 0',
    '@daily': '0 0 * * *',
    '@midnight': '0 0 * * *',
    '@hourly': '0 * * * *',
  };

  const expr = shortcuts[expression] || expression;
  const fields = expr.trim().split(/\s+/);

  if (fields.length !== 5) {
    throw new Error(`[HeadyScheduler] Invalid cron expression "${expression}": expected 5 fields`);
  }

  return {
    minutes: parseCronField(fields[0], 0, 59),
    hours: parseCronField(fields[1], 0, 23),
    days: parseCronField(fields[2], 1, 31),
    months: parseCronField(fields[3], 1, 12),
    weekdays: parseCronField(fields[4], 0, 6),
  };
}

/**
 * Checks if a Date matches a cron schedule
 * @param {CronSchedule} schedule
 * @param {Date} date
 * @returns {boolean}
 */
function cronMatches(schedule, date) {
  return (
    schedule.minutes.has(date.getMinutes()) &&
    schedule.hours.has(date.getHours()) &&
    schedule.days.has(date.getDate()) &&
    schedule.months.has(date.getMonth() + 1) &&
    schedule.weekdays.has(date.getDay())
  );
}

/**
 * Calculates ms until the next minute boundary
 * @returns {number}
 */
function msUntilNextMinute() {
  const now = new Date();
  const next = new Date(now);
  next.setSeconds(0, 0);
  next.setMinutes(now.getMinutes() + 1);
  return next.getTime() - now.getTime();
}

/**
 * @class HeadyScheduler
 * @extends EventEmitter
 * Cron + interval task scheduler for the Heady platform.
 */
export class HeadyScheduler extends EventEmitter {
  constructor() {
    super();
    /** @type {Map<string, TaskRecord>} */
    this._tasks = new Map();
    /** @type {NodeJS.Timeout|null} Cron tick timer */
    this._cronTimer = null;
    /** @type {boolean} */
    this._running = false;
  }

  /**
   * Registers and optionally starts a task
   * @param {TaskDefinition} def
   * @returns {this}
   */
  register(def) {
    if (!def.name) throw new Error('[HeadyScheduler] Task must have a name');
    if (!def.fn) throw new Error('[HeadyScheduler] Task must have a fn');
    if (!def.cron && !def.interval) {
      throw new Error('[HeadyScheduler] Task must have either cron or interval');
    }

    // Validate cron expression early
    if (def.cron) {
      parseCron(def.cron); // throws on invalid
    }

    const record = {
      name: def.name,
      def,
      running: false,
      runs: 0,
      errors: 0,
      lastRun: null,
      nextRun: null,
      lastDuration: null,
      timer: null,
      enabled: true,
    };

    this._tasks.set(def.name, record);
    log.debug('Task registered', { name: def.name, cron: def.cron, interval: def.interval });

    // Start interval task immediately
    if (def.interval) {
      this._startInterval(record);
    }

    // Run on start if requested
    if (def.runOnStart) {
      setImmediate(() => this._runTask(record));
    }

    return this;
  }

  /**
   * Starts the scheduler (activates cron ticking)
   * @returns {this}
   */
  start() {
    if (this._running) return this;
    this._running = true;
    log.info('Scheduler started');
    this._scheduleCronTick();
    return this;
  }

  /**
   * Stops all tasks and the cron ticker
   * @returns {this}
   */
  stop() {
    this._running = false;
    if (this._cronTimer) {
      clearTimeout(this._cronTimer);
      this._cronTimer = null;
    }
    for (const record of this._tasks.values()) {
      if (record.timer) {
        clearInterval(record.timer);
        record.timer = null;
      }
    }
    log.info('Scheduler stopped');
    return this;
  }

  /**
   * Runs a named task immediately (regardless of schedule)
   * @param {string} name
   * @returns {Promise<void>}
   */
  async runNow(name) {
    const record = this._tasks.get(name);
    if (!record) throw new Error(`[HeadyScheduler] Unknown task: ${name}`);
    await this._runTask(record);
  }

  /**
   * Enables a previously disabled task
   * @param {string} name
   */
  enable(name) {
    const record = this._tasks.get(name);
    if (record) { record.enabled = true; log.debug('Task enabled', { name }); }
  }

  /**
   * Disables a task (skips future runs without removing it)
   * @param {string} name
   */
  disable(name) {
    const record = this._tasks.get(name);
    if (record) { record.enabled = false; log.debug('Task disabled', { name }); }
  }

  /**
   * Removes a task completely
   * @param {string} name
   * @returns {boolean}
   */
  remove(name) {
    const record = this._tasks.get(name);
    if (!record) return false;
    if (record.timer) clearInterval(record.timer);
    this._tasks.delete(name);
    return true;
  }

  /**
   * Returns stats for all tasks
   * @returns {Array<object>}
   */
  status() {
    return Array.from(this._tasks.values()).map(r => ({
      name: r.name,
      enabled: r.enabled,
      running: r.running,
      runs: r.runs,
      errors: r.errors,
      lastRun: r.lastRun ? new Date(r.lastRun).toISOString() : null,
      lastDuration: r.lastDuration,
      cron: r.def.cron,
      interval: r.def.interval,
    }));
  }

  /**
   * Internal: starts an interval-based task
   * @param {TaskRecord} record
   */
  _startInterval(record) {
    record.timer = setInterval(() => {
      if (record.enabled && this._running) this._runTask(record);
    }, record.def.interval);
    record.timer.unref?.();
  }

  /**
   * Internal: schedules the next cron minute tick
   */
  _scheduleCronTick() {
    if (!this._running) return;
    const delay = msUntilNextMinute();
    this._cronTimer = setTimeout(() => {
      this._tickCron();
      this._scheduleCronTick();
    }, delay);
    this._cronTimer.unref?.();
  }

  /**
   * Internal: fires all cron tasks that match the current minute
   */
  _tickCron() {
    const now = new Date();
    for (const record of this._tasks.values()) {
      if (!record.enabled || !record.def.cron) continue;
      try {
        const schedule = parseCron(record.def.cron);
        if (cronMatches(schedule, now)) {
          this._runTask(record).catch(() => {});
        }
      } catch (err) {
        log.error('Cron parse error', { name: record.name, error: err.message });
      }
    }
  }

  /**
   * Internal: executes a task with exclusive lock, timeout, and error handling
   * @param {TaskRecord} record
   * @returns {Promise<void>}
   */
  async _runTask(record) {
    if (record.def.exclusive && record.running) {
      log.debug('Task skipped (running)', { name: record.name });
      return;
    }

    record.running = true;
    record.lastRun = Date.now();
    record.runs++;

    const timer = record.def.timeout > 0
      ? setTimeout(() => {
        log.warn('Task timeout', { name: record.name, timeout: record.def.timeout });
      }, record.def.timeout)
      : null;

    const start = Date.now();
    try {
      await record.def.fn();
      record.lastDuration = Date.now() - start;
      this.emit('task:success', { name: record.name, duration: record.lastDuration });
    } catch (err) {
      record.errors++;
      record.lastDuration = Date.now() - start;
      log.error('Task error', {
        name: record.name,
        error: err.message,
        component: record.def.component || 'scheduler',
      });
      this.emit('task:error', { name: record.name, error: err });
    } finally {
      if (timer) clearTimeout(timer);
      record.running = false;
    }
  }
}

/** Singleton global scheduler */
export const globalScheduler = new HeadyScheduler();

export default HeadyScheduler;
