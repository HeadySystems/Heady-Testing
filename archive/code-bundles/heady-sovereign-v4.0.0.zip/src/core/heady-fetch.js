/**
 * ∞ Heady™ Fetch — Native fetch wrapper with retry, timeout, circuit breaker, and caching
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createLogger } from './heady-logger.js';

const log = createLogger('HeadyFetch');

/**
 * @typedef {object} FetchOptions
 * @property {number} [timeout=30000] - Request timeout in ms
 * @property {number} [retries=3] - Max retry attempts
 * @property {number} [retryDelay=500] - Base delay between retries (ms), doubles each attempt
 * @property {number[]} [retryOn=[429, 500, 502, 503, 504]] - Status codes to retry on
 * @property {boolean} [cache=false] - Enable response caching
 * @property {number} [cacheTtl=60000] - Cache TTL in ms
 * @property {string} [cacheKey] - Custom cache key (defaults to URL + method)
 * @property {boolean} [circuitBreaker=true] - Enable circuit breaker
 * @property {string} [component] - Caller component name for logging
 * @property {HeadersInit} [headers] - Additional headers
 * @property {'json'|'text'|'buffer'|'stream'} [responseType='json'] - Response parsing mode
 */

/** @type {Map<string, {status: string, failures: number, openedAt: number, halfOpenAt: number}>} */
const circuits = new Map();

/** @type {Map<string, {data: unknown, expiresAt: number}>} */
const responseCache = new Map();

const CIRCUIT_FAILURE_THRESHOLD = 5;
const CIRCUIT_OPEN_TIMEOUT = 30000;    // 30s before trying half-open
const CIRCUIT_HALF_OPEN_TIMEOUT = 5000; // 5s to test in half-open state

/**
 * Gets or creates a circuit breaker entry for a given host
 * @param {string} host
 * @returns {{status: string, failures: number, openedAt: number, halfOpenAt: number}}
 */
function getCircuit(host) {
  if (!circuits.has(host)) {
    circuits.set(host, { status: 'closed', failures: 0, openedAt: 0, halfOpenAt: 0 });
  }
  return circuits.get(host);
}

/**
 * Checks if a circuit allows a request through
 * @param {string} host
 * @returns {boolean}
 */
function circuitAllows(host) {
  const circuit = getCircuit(host);
  const now = Date.now();

  if (circuit.status === 'closed') return true;

  if (circuit.status === 'open') {
    if (now - circuit.openedAt >= CIRCUIT_OPEN_TIMEOUT) {
      circuit.status = 'half-open';
      circuit.halfOpenAt = now;
      log.debug('Circuit half-open', { host });
      return true;
    }
    return false;
  }

  if (circuit.status === 'half-open') {
    // Allow one probe request
    return now - circuit.halfOpenAt < CIRCUIT_HALF_OPEN_TIMEOUT;
  }

  return true;
}

/**
 * Records a circuit success
 * @param {string} host
 */
function circuitSuccess(host) {
  const circuit = getCircuit(host);
  if (circuit.status === 'half-open') {
    circuit.status = 'closed';
    circuit.failures = 0;
    log.info('Circuit closed (recovered)', { host });
  } else if (circuit.status === 'closed') {
    circuit.failures = Math.max(0, circuit.failures - 1);
  }
}

/**
 * Records a circuit failure
 * @param {string} host
 */
function circuitFailure(host) {
  const circuit = getCircuit(host);
  circuit.failures++;
  if (circuit.status === 'half-open' || circuit.failures >= CIRCUIT_FAILURE_THRESHOLD) {
    circuit.status = 'open';
    circuit.openedAt = Date.now();
    log.warn('Circuit opened', { host, failures: circuit.failures });
  }
}

/**
 * Returns cached response if valid
 * @param {string} key
 * @returns {unknown|null}
 */
function getCached(key) {
  const entry = responseCache.get(key);
  if (!entry) return null;
  if (Date.now() > entry.expiresAt) {
    responseCache.delete(key);
    return null;
  }
  return entry.data;
}

/**
 * Stores a response in cache
 * @param {string} key
 * @param {unknown} data
 * @param {number} ttl
 */
function setCached(key, data, ttl) {
  // Evict oldest if cache is large
  if (responseCache.size > 500) {
    const first = responseCache.keys().next().value;
    responseCache.delete(first);
  }
  responseCache.set(key, { data, expiresAt: Date.now() + ttl });
}

/**
 * Sleep helper
 * @param {number} ms
 * @returns {Promise<void>}
 */
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/**
 * Parses a response based on responseType
 * @param {Response} response
 * @param {string} responseType
 * @returns {Promise<unknown>}
 */
async function parseResponse(response, responseType) {
  switch (responseType) {
    case 'text': return response.text();
    case 'buffer': return response.arrayBuffer();
    case 'stream': return response;
    case 'json':
    default: {
      const text = await response.text();
      try {
        return JSON.parse(text);
      } catch {
        return text; // Return as text if not valid JSON
      }
    }
  }
}

/**
 * Heady-branded fetch with retry, circuit breaker, timeout, and caching
 * @param {string} url - The URL to fetch (must be a Heady or approved external domain)
 * @param {RequestInit & FetchOptions} [options]
 * @returns {Promise<unknown>} Parsed response body
 */
export async function headyFetch(url, options = {}) {
  const {
    timeout = 30000,
    retries = 3,
    retryDelay = 500,
    retryOn = [429, 500, 502, 503, 504],
    cache = false,
    cacheTtl = 60000,
    cacheKey,
    circuitBreaker = true,
    component = 'HeadyFetch',
    responseType = 'json',
    // Pull out non-standard options before passing to fetch
    ...fetchOptions
  } = options;

  const urlObj = new URL(url);
  const host = urlObj.hostname;

  // Cache check
  const ck = cacheKey || `${fetchOptions.method || 'GET'}:${url}`;
  if (cache && (fetchOptions.method || 'GET') === 'GET') {
    const cached = getCached(ck);
    if (cached !== null) {
      log.debug('Cache hit', { component, url: urlObj.pathname });
      return cached;
    }
  }

  // Circuit breaker check
  if (circuitBreaker && !circuitAllows(host)) {
    throw Object.assign(
      new Error(`[HeadyFetch] Circuit breaker OPEN for ${host} — request blocked`),
      { code: 'CIRCUIT_OPEN', host }
    );
  }

  let lastError;
  let attempt = 0;

  while (attempt <= retries) {
    attempt++;
    const attemptStart = Date.now();

    try {
      // Create abort controller for timeout
      const controller = new AbortController();
      const timer = timeout > 0
        ? setTimeout(() => controller.abort(new Error('Request timeout')), timeout)
        : null;

      let response;
      try {
        response = await fetch(url, {
          ...fetchOptions,
          signal: controller.signal,
          headers: {
            'User-Agent': 'HeadySystems/4.0.0 Sovereign',
            'X-Heady-Platform': 'sovereign',
            'Accept': 'application/json',
            ...fetchOptions.headers,
          },
        });
      } finally {
        if (timer) clearTimeout(timer);
      }

      const elapsed = Date.now() - attemptStart;

      // Handle retry-eligible status codes
      if (retryOn.includes(response.status) && attempt <= retries) {
        const delay = retryDelay * Math.pow(2, attempt - 1);
        log.warn('Retrying request', {
          component, url: urlObj.pathname,
          status: response.status, attempt, delay_ms: delay,
        });
        if (circuitBreaker) circuitFailure(host);
        await sleep(delay);
        continue;
      }

      // Non-retryable error
      if (!response.ok && !retryOn.includes(response.status)) {
        if (circuitBreaker) circuitFailure(host);
        const text = await response.text().catch(() => '');
        throw Object.assign(
          new Error(`[HeadyFetch] HTTP ${response.status} ${response.statusText}: ${urlObj.pathname}`),
          { status: response.status, body: text, url }
        );
      }

      // Success
      if (circuitBreaker) circuitSuccess(host);

      log.debug('Request complete', {
        component, url: urlObj.pathname,
        status: response.status, elapsed_ms: elapsed,
      });

      const data = await parseResponse(response, responseType);

      if (cache && (fetchOptions.method || 'GET') === 'GET') {
        setCached(ck, data, cacheTtl);
      }

      return data;

    } catch (err) {
      lastError = err;

      // Don't retry on abort (timeout) or circuit open
      if (err.name === 'AbortError' || err.code === 'CIRCUIT_OPEN') {
        if (circuitBreaker && err.name === 'AbortError') circuitFailure(host);
        throw err;
      }

      if (attempt > retries) break;

      const delay = retryDelay * Math.pow(2, attempt - 1);
      log.warn('Request failed, retrying', {
        component, url: urlObj.pathname,
        error: err.message, attempt, delay_ms: delay,
      });
      if (circuitBreaker) circuitFailure(host);
      await sleep(delay);
    }
  }

  throw lastError || new Error(`[HeadyFetch] Failed after ${retries} retries: ${url}`);
}

/**
 * Convenience GET wrapper
 * @param {string} url
 * @param {FetchOptions} [options]
 * @returns {Promise<unknown>}
 */
export const get = (url, options) =>
  headyFetch(url, { ...options, method: 'GET' });

/**
 * Convenience POST wrapper
 * @param {string} url
 * @param {unknown} body
 * @param {FetchOptions} [options]
 * @returns {Promise<unknown>}
 */
export const post = (url, body, options) =>
  headyFetch(url, {
    ...options,
    method: 'POST',
    body: JSON.stringify(body),
    headers: { 'Content-Type': 'application/json', ...(options?.headers || {}) },
  });

/**
 * Returns current circuit breaker states for diagnostics
 * @returns {Record<string, object>}
 */
export function circuitStats() {
  const result = {};
  for (const [host, state] of circuits) {
    result[host] = { ...state };
  }
  return result;
}

/**
 * Clears the response cache
 */
export function clearCache() {
  responseCache.clear();
}

export default headyFetch;
