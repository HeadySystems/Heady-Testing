/**
 * ∞ Heady™ KV — In-memory key-value store with TTL, LRU eviction, and optional disk persistence
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { EventEmitter } from 'events';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { dirname } from 'path';
import { createLogger } from './heady-logger.js';

const log = createLogger('HeadyKV');

/**
 * @typedef {object} KVEntry
 * @property {unknown} value
 * @property {number} expiresAt - 0 = no expiry
 * @property {number} createdAt
 * @property {number} accessedAt
 * @property {number} hits
 */

/**
 * @typedef {object} KVOptions
 * @property {number} [maxSize=10000] - Max number of entries before LRU eviction
 * @property {number} [defaultTtl=0] - Default TTL in ms (0 = no expiry)
 * @property {string} [persistPath] - File path for disk persistence
 * @property {number} [persistInterval=60000] - Auto-save interval in ms (0 = disabled)
 * @property {boolean} [evictOnFull=true] - Enable LRU eviction when full
 * @property {string} [namespace] - Namespace prefix for all keys
 */

/**
 * @class HeadyKV
 * @extends EventEmitter
 * High-performance in-memory KV store with TTL, LRU eviction, namespacing, and persistence.
 */
export class HeadyKV extends EventEmitter {
  /**
   * @param {KVOptions} [options]
   */
  constructor(options = {}) {
    super();
    this._maxSize = options.maxSize ?? 10000;
    this._defaultTtl = options.defaultTtl ?? 0;
    this._persistPath = options.persistPath ?? null;
    this._persistInterval = options.persistInterval ?? 60000;
    this._evictOnFull = options.evictOnFull ?? true;
    this._namespace = options.namespace ?? '';

    /** @type {Map<string, KVEntry>} Main storage */
    this._store = new Map();

    /** @type {Map<string, NodeJS.Timeout>} Per-key TTL timers */
    this._timers = new Map();

    this._hits = 0;
    this._misses = 0;
    this._evictions = 0;

    // Load persisted data
    if (this._persistPath) {
      this._loadFromDisk();
    }

    // Start auto-persist
    if (this._persistPath && this._persistInterval > 0) {
      this._persistTimer = setInterval(() => this._saveToDisk(), this._persistInterval);
      this._persistTimer.unref?.();
    }
  }

  /**
   * Prefixes key with namespace if set
   * @param {string} key
   * @returns {string}
   */
  _ns(key) {
    return this._namespace ? `${this._namespace}:${key}` : key;
  }

  /**
   * Sets a key-value pair with optional TTL
   * @param {string} key
   * @param {unknown} value
   * @param {number} [ttl] - TTL in ms (overrides defaultTtl)
   * @returns {this}
   */
  set(key, value, ttl) {
    const nsKey = this._ns(key);
    const now = Date.now();
    const effectiveTtl = ttl !== undefined ? ttl : this._defaultTtl;
    const expiresAt = effectiveTtl > 0 ? now + effectiveTtl : 0;

    // Evict LRU if at capacity
    if (!this._store.has(nsKey) && this._store.size >= this._maxSize) {
      if (this._evictOnFull) {
        this._evictLRU();
      } else {
        throw new Error(`[HeadyKV] Store full (${this._maxSize} entries)`);
      }
    }

    // Clear existing timer
    if (this._timers.has(nsKey)) {
      clearTimeout(this._timers.get(nsKey));
      this._timers.delete(nsKey);
    }

    this._store.set(nsKey, {
      value,
      expiresAt,
      createdAt: now,
      accessedAt: now,
      hits: 0,
    });

    // Set TTL timer for auto-expiry
    if (effectiveTtl > 0) {
      const timer = setTimeout(() => this._expire(nsKey), effectiveTtl);
      timer.unref?.();
      this._timers.set(nsKey, timer);
    }

    this.emit('set', { key, nsKey, value, ttl: effectiveTtl });
    return this;
  }

  /**
   * Gets a value by key
   * @param {string} key
   * @param {unknown} [defaultValue] - Returned if key is missing or expired
   * @returns {unknown}
   */
  get(key, defaultValue = undefined) {
    const nsKey = this._ns(key);
    const entry = this._store.get(nsKey);

    if (!entry) {
      this._misses++;
      return defaultValue;
    }

    // Lazy expiry check
    if (entry.expiresAt > 0 && Date.now() > entry.expiresAt) {
      this._expire(nsKey);
      this._misses++;
      return defaultValue;
    }

    entry.accessedAt = Date.now();
    entry.hits++;
    this._hits++;
    return entry.value;
  }

  /**
   * Gets a value, computing and storing it if missing
   * @param {string} key
   * @param {function(): Promise<unknown>|unknown} factory
   * @param {number} [ttl]
   * @returns {Promise<unknown>}
   */
  async getOrSet(key, factory, ttl) {
    const existing = this.get(key);
    if (existing !== undefined) return existing;
    const value = await factory();
    this.set(key, value, ttl);
    return value;
  }

  /**
   * Checks if a key exists and is not expired
   * @param {string} key
   * @returns {boolean}
   */
  has(key) {
    return this.get(key) !== undefined;
  }

  /**
   * Deletes a key
   * @param {string} key
   * @returns {boolean} true if key existed
   */
  delete(key) {
    const nsKey = this._ns(key);
    if (this._timers.has(nsKey)) {
      clearTimeout(this._timers.get(nsKey));
      this._timers.delete(nsKey);
    }
    const existed = this._store.delete(nsKey);
    if (existed) this.emit('delete', { key, nsKey });
    return existed;
  }

  /**
   * Clears all entries (or only those matching a prefix)
   * @param {string} [prefix]
   */
  clear(prefix) {
    if (prefix) {
      const nsPrefix = this._ns(prefix);
      for (const key of this._store.keys()) {
        if (key.startsWith(nsPrefix)) {
          this._timers.get(key) && clearTimeout(this._timers.get(key));
          this._timers.delete(key);
          this._store.delete(key);
        }
      }
    } else {
      for (const timer of this._timers.values()) clearTimeout(timer);
      this._timers.clear();
      this._store.clear();
    }
    this.emit('clear', { prefix });
  }

  /**
   * Returns TTL remaining in ms for a key (-1 if no expiry, 0 if expired/missing)
   * @param {string} key
   * @returns {number}
   */
  ttl(key) {
    const entry = this._store.get(this._ns(key));
    if (!entry) return 0;
    if (entry.expiresAt === 0) return -1;
    return Math.max(0, entry.expiresAt - Date.now());
  }

  /**
   * Extends the TTL of an existing key
   * @param {string} key
   * @param {number} ttl - New TTL in ms
   * @returns {boolean} true if key existed
   */
  expire(key, ttl) {
    const existing = this.get(key);
    if (existing === undefined) return false;
    this.set(key, existing, ttl);
    return true;
  }

  /**
   * Returns all keys (optionally filtered by prefix)
   * @param {string} [prefix]
   * @returns {string[]}
   */
  keys(prefix) {
    const nsPrefix = prefix ? this._ns(prefix) : this._namespace;
    const result = [];
    for (const key of this._store.keys()) {
      if (!nsPrefix || key.startsWith(nsPrefix)) {
        const stripped = this._namespace ? key.slice(this._namespace.length + 1) : key;
        result.push(stripped);
      }
    }
    return result;
  }

  /**
   * Returns the number of entries
   * @returns {number}
   */
  get size() {
    return this._store.size;
  }

  /**
   * Atomically increments a numeric value
   * @param {string} key
   * @param {number} [by=1]
   * @param {number} [ttl]
   * @returns {number} New value
   */
  incr(key, by = 1, ttl) {
    const current = this.get(key) ?? 0;
    if (typeof current !== 'number') {
      throw new TypeError(`[HeadyKV] Cannot increment non-numeric value for key "${key}"`);
    }
    const next = current + by;
    this.set(key, next, ttl);
    return next;
  }

  /**
   * Returns diagnostics/stats
   * @returns {object}
   */
  stats() {
    return {
      size: this._store.size,
      maxSize: this._maxSize,
      hits: this._hits,
      misses: this._misses,
      evictions: this._evictions,
      hitRate: this._hits + this._misses > 0
        ? (this._hits / (this._hits + this._misses) * 100).toFixed(1) + '%'
        : 'n/a',
      timers: this._timers.size,
      namespace: this._namespace || '(none)',
    };
  }

  /**
   * Creates a namespaced sub-store that shares the same underlying store
   * @param {string} namespace
   * @returns {HeadyKV}
   */
  scope(namespace) {
    const child = new HeadyKV({
      maxSize: this._maxSize,
      defaultTtl: this._defaultTtl,
      namespace: this._namespace ? `${this._namespace}:${namespace}` : namespace,
    });
    // Share the underlying store
    child._store = this._store;
    child._timers = this._timers;
    return child;
  }

  /**
   * Handles key expiry
   * @param {string} nsKey
   */
  _expire(nsKey) {
    this._store.delete(nsKey);
    this._timers.delete(nsKey);
    this.emit('expire', { nsKey });
  }

  /**
   * Evicts the least recently used entry
   */
  _evictLRU() {
    let lruKey = null;
    let lruTime = Infinity;
    for (const [k, v] of this._store) {
      if (v.accessedAt < lruTime) {
        lruTime = v.accessedAt;
        lruKey = k;
      }
    }
    if (lruKey) {
      this._timers.get(lruKey) && clearTimeout(this._timers.get(lruKey));
      this._timers.delete(lruKey);
      this._store.delete(lruKey);
      this._evictions++;
      this.emit('evict', { nsKey: lruKey });
    }
  }

  /**
   * Saves current state to disk (serializable values only)
   */
  _saveToDisk() {
    if (!this._persistPath) return;
    try {
      mkdirSync(dirname(this._persistPath), { recursive: true });
      const snapshot = {};
      const now = Date.now();
      for (const [k, v] of this._store) {
        if (v.expiresAt > 0 && now > v.expiresAt) continue;
        try {
          JSON.stringify(v.value); // Skip non-serializable
          snapshot[k] = { value: v.value, expiresAt: v.expiresAt, createdAt: v.createdAt };
        } catch {}
      }
      writeFileSync(this._persistPath, JSON.stringify(snapshot), 'utf8');
    } catch (err) {
      log.warn('KV persist failed', { error: err.message, path: this._persistPath });
    }
  }

  /**
   * Loads state from disk on startup
   */
  _loadFromDisk() {
    if (!this._persistPath || !existsSync(this._persistPath)) return;
    try {
      const raw = readFileSync(this._persistPath, 'utf8');
      const snapshot = JSON.parse(raw);
      const now = Date.now();
      for (const [k, v] of Object.entries(snapshot)) {
        if (v.expiresAt > 0 && now > v.expiresAt) continue;
        const ttl = v.expiresAt > 0 ? v.expiresAt - now : 0;
        this._store.set(k, {
          value: v.value,
          expiresAt: v.expiresAt,
          createdAt: v.createdAt,
          accessedAt: now,
          hits: 0,
        });
        if (ttl > 0) {
          const timer = setTimeout(() => this._expire(k), ttl);
          timer.unref?.();
          this._timers.set(k, timer);
        }
      }
      log.debug('KV loaded from disk', { path: this._persistPath, entries: this._store.size });
    } catch (err) {
      log.warn('KV load from disk failed', { error: err.message, path: this._persistPath });
    }
  }

  /**
   * Persists and destroys the store
   */
  destroy() {
    if (this._persistTimer) clearInterval(this._persistTimer);
    this._saveToDisk();
    for (const timer of this._timers.values()) clearTimeout(timer);
    this._timers.clear();
    this._store.clear();
    this.removeAllListeners();
  }
}

/** Singleton global KV store */
export const globalKV = new HeadyKV({ maxSize: 50000 });

/** Edge cache with 60s default TTL */
export const edgeCache = new HeadyKV({
  maxSize: 5000,
  defaultTtl: 60000,
  namespace: 'edge',
});

export default HeadyKV;
