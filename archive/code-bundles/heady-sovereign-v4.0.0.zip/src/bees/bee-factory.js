/**
 * ∞ Heady™ Bee Factory — Dynamic Agent Worker Factory
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

const EventEmitter = require('events');

// ─────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────

/**
 * Bee lifecycle states.
 * @enum {string}
 */
const BEE_STATES = {
  CREATED:     'created',
  INITIALIZING:'initializing',
  ACTIVE:      'active',
  PAUSED:      'paused',
  DRAINING:    'draining',
  TERMINATED:  'terminated',
  ERROR:       'error',
};

/**
 * Bee domain specializations (24 domains).
 * @enum {string}
 */
const BEE_DOMAINS = {
  // Core platform
  ORCHESTRATION: 'orchestration',
  PIPELINE:      'pipeline',
  INFERENCE:     'inference',
  MEMORY:        'memory',
  VECTOR:        'vector',

  // Development
  CODE_GEN:      'code_generation',
  CODE_REVIEW:   'code_review',
  SECURITY:      'security',
  TESTING:       'testing',
  DEVOPS:        'devops',

  // Content & Communication
  RESEARCH:      'research',
  DOCUMENTATION: 'documentation',
  CREATIVE:      'creative',
  TRANSLATION:   'translation',
  SUMMARIZATION: 'summarization',

  // Operations
  MONITORING:    'monitoring',
  HEALING:       'healing',
  DEPLOYMENT:    'deployment',
  ROUTING:       'routing',
  SCHEDULING:    'scheduling',

  // Data & Analytics
  ANALYTICS:     'analytics',
  EMBEDDING:     'embedding',
  PATTERN:       'pattern',

  // General
  GENERAL:       'general',
};

/** Default resource limits per bee */
const DEFAULT_RESOURCE_LIMITS = {
  maxCpuMs:       5_000,    // 5 seconds of CPU time per task
  maxMemoryMb:    128,      // 128 MB heap
  maxTaskTimeMs:  30_000,   // 30 seconds per task
  maxLifetimeMs:  3_600_000, // 1 hour (ephemeral bees)
  maxTasks:       null,     // unlimited
};

// ─────────────────────────────────────────────
// Bee Resource Monitor
// ─────────────────────────────────────────────

/**
 * Tracks resource consumption for a single bee.
 */
class BeeResourceMonitor {
  /**
   * @param {object} limits
   */
  constructor(limits = {}) {
    this.limits   = { ...DEFAULT_RESOURCE_LIMITS, ...limits };
    this.cpu      = 0;        // accumulated CPU ms
    this.tasks    = 0;        // completed tasks
    this.errors   = 0;        // error count
    this.createdAt = Date.now();
  }

  /**
   * Record a completed task.
   * @param {number} cpuMs    Time consumed
   * @param {boolean} errored
   */
  record(cpuMs, errored = false) {
    this.cpu += cpuMs;
    this.tasks++;
    if (errored) this.errors++;
  }

  /**
   * Check if any resource limit has been exceeded.
   * @returns {{exceeded: boolean, reason: string|null}}
   */
  check() {
    const lifetime = Date.now() - this.createdAt;
    if (this.limits.maxLifetimeMs && lifetime > this.limits.maxLifetimeMs)
      return { exceeded: true, reason: `lifetime exceeded (${lifetime}ms > ${this.limits.maxLifetimeMs}ms)` };
    if (this.limits.maxTasks !== null && this.tasks >= this.limits.maxTasks)
      return { exceeded: true, reason: `max tasks reached (${this.tasks})` };
    return { exceeded: false, reason: null };
  }

  /** @returns {object} Current metrics snapshot */
  snapshot() {
    return {
      cpuMs:     this.cpu,
      tasks:     this.tasks,
      errors:    this.errors,
      lifetimeMs: Date.now() - this.createdAt,
      errorRate:  this.tasks > 0 ? this.errors / this.tasks : 0,
    };
  }
}

// ─────────────────────────────────────────────
// Bee
// ─────────────────────────────────────────────

/**
 * @typedef {object} BeeConfig
 * @property {string}  [id]             Custom bee ID (auto-generated if absent)
 * @property {string}  [domain]         One of BEE_DOMAINS
 * @property {string}  [name]           Human-readable name
 * @property {boolean} [ephemeral]      If true, bee terminates after one task
 * @property {object}  [resourceLimits] Override DEFAULT_RESOURCE_LIMITS
 * @property {object}  [behavior]       Initial behavior definition
 * @property {string}  [task]           Task description (ephemeral bees)
 * @property {object}  [context]        Shared context/state
 * @property {object}  [dependencies]   Injected service deps (inference, memory, …)
 */

/**
 * @typedef {object} BeeMetrics
 * @property {string}  id
 * @property {string}  domain
 * @property {string}  state
 * @property {number}  cpuMs
 * @property {number}  tasks
 * @property {number}  errors
 * @property {number}  lifetimeMs
 * @property {number}  errorRate
 */

/**
 * A Heady Bee — a persistent or ephemeral AI worker agent.
 *
 * Bees are domain-specialized workers that execute tasks autonomously.
 * They carry state, manage their own lifecycle, support hot-swapping,
 * and report health and metrics.
 *
 * @extends EventEmitter
 */
class Bee extends EventEmitter {
  /**
   * @param {BeeConfig} config
   */
  constructor(config = {}) {
    super();
    this.id        = config.id ?? _uuid();
    this.name      = config.name     ?? `Bee-${this.id.slice(0, 8)}`;
    this.domain    = config.domain   ?? BEE_DOMAINS.GENERAL;
    this.ephemeral = config.ephemeral ?? false;
    this.task      = config.task     ?? null;
    this.context   = config.context  ?? {};
    this.deps      = config.dependencies ?? {};

    this._state    = BEE_STATES.CREATED;
    this._behavior = config.behavior ?? this._defaultBehavior();
    this._monitor  = new BeeResourceMonitor(config.resourceLimits ?? {});
    this._currentTask = null;
    this._stateHistory = [{ state: BEE_STATES.CREATED, ts: Date.now() }];
  }

  // ── State Management ──

  /** @returns {string} Current state */
  get state() { return this._state; }

  /**
   * Transition to a new state.
   * @param {string} newState
   * @param {string} [reason]
   */
  _transition(newState, reason) {
    const prev = this._state;
    this._state = newState;
    this._stateHistory.push({ state: newState, ts: Date.now(), from: prev, reason });
    this.emit('state_change', { beeId: this.id, from: prev, to: newState, reason });
  }

  // ── Lifecycle ──

  /**
   * Initialize the bee (async setup).
   * @returns {Promise<void>}
   */
  async initialize() {
    this._transition(BEE_STATES.INITIALIZING);
    try {
      if (this._behavior.onInit) await this._behavior.onInit(this);
      this._transition(BEE_STATES.ACTIVE);
      this.emit('ready', { beeId: this.id, domain: this.domain });
    } catch (err) {
      this._transition(BEE_STATES.ERROR, err.message);
      throw err;
    }
  }

  /**
   * Pause the bee (stop accepting new tasks).
   */
  pause() {
    if (this._state !== BEE_STATES.ACTIVE) return;
    this._transition(BEE_STATES.PAUSED);
  }

  /**
   * Resume a paused bee.
   */
  resume() {
    if (this._state !== BEE_STATES.PAUSED) return;
    this._transition(BEE_STATES.ACTIVE);
  }

  /**
   * Gracefully terminate the bee.
   * Waits for any active task to complete before terminating.
   * @param {string} [reason]
   * @returns {Promise<void>}
   */
  async terminate(reason = 'requested') {
    if (this._state === BEE_STATES.TERMINATED) return;
    this._transition(BEE_STATES.DRAINING, reason);

    // Wait for active task
    if (this._currentTask) {
      try { await this._currentTask; } catch { /* ignore */ }
    }

    if (this._behavior.onDestroy) {
      try { await this._behavior.onDestroy(this); } catch { /* ignore */ }
    }

    this._transition(BEE_STATES.TERMINATED, reason);
    this.emit('terminated', {
      beeId:    this.id,
      reason,
      metrics:  this.metrics(),
    });
  }

  // ── Task Execution ──

  /**
   * Execute a task on this bee.
   * @param {object} task
   * @param {string} task.type      Task type (domain-specific)
   * @param {object} task.payload   Task input data
   * @param {string} [task.id]      Task ID for tracing
   * @returns {Promise<object>} Task result
   */
  async execute(task) {
    if (this._state === BEE_STATES.PAUSED) {
      throw new Error(`Bee ${this.id} is paused`);
    }
    if (this._state === BEE_STATES.DRAINING || this._state === BEE_STATES.TERMINATED) {
      throw new Error(`Bee ${this.id} is ${this._state}`);
    }
    if (this._state !== BEE_STATES.ACTIVE) {
      throw new Error(`Bee ${this.id} is not active (state: ${this._state})`);
    }

    // Resource pre-check
    const limitCheck = this._monitor.check();
    if (limitCheck.exceeded) {
      await this.terminate(limitCheck.reason);
      throw new Error(`Bee ${this.id} terminated: ${limitCheck.reason}`);
    }

    const taskId = task.id ?? _uuid();
    const start  = Date.now();

    this.emit('task_start', { beeId: this.id, taskId, type: task.type });

    const taskPromise = this._runTask(task);
    this._currentTask = taskPromise;

    let result;
    let errored = false;
    try {
      result = await taskPromise;
    } catch (err) {
      errored = true;
      this.emit('task_error', { beeId: this.id, taskId, err });
      throw err;
    } finally {
      this._currentTask = null;
      const elapsed = Date.now() - start;
      this._monitor.record(elapsed, errored);
      this.emit('task_complete', { beeId: this.id, taskId, latencyMs: elapsed, errored });
    }

    // Ephemeral bees self-terminate after one task
    if (this.ephemeral) {
      await this.terminate('ephemeral task complete');
    }

    return result;
  }

  async _runTask(task) {
    const handler = this._behavior.handlers?.[task.type] ?? this._behavior.defaultHandler;
    if (!handler) throw new Error(`Bee ${this.id}: no handler for task type "${task.type}"`);
    return handler(task.payload, this);
  }

  // ── Hot-Swap ──

  /**
   * Hot-swap the bee's behavior without restarting.
   * New tasks will use the new behavior; any active task continues with the old one.
   * @param {object} newBehavior
   */
  hotSwap(newBehavior) {
    const prev = this._behavior;
    this._behavior = newBehavior;
    this.emit('hot_swapped', { beeId: this.id, prevHandlers: Object.keys(prev.handlers ?? {}), newHandlers: Object.keys(newBehavior.handlers ?? {}) });
  }

  // ── Health ──

  /**
   * Run a self health check.
   * @returns {{healthy: boolean, state: string, reason?: string}>}
   */
  health() {
    const bad = [BEE_STATES.ERROR, BEE_STATES.TERMINATED];
    const limitCheck = this._monitor.check();
    return {
      healthy: !bad.includes(this._state) && !limitCheck.exceeded,
      state:   this._state,
      reason:  limitCheck.exceeded ? limitCheck.reason : undefined,
      metrics: this._monitor.snapshot(),
    };
  }

  /**
   * Get current metrics.
   * @returns {BeeMetrics}
   */
  metrics() {
    return {
      id:     this.id,
      name:   this.name,
      domain: this.domain,
      state:  this._state,
      ...this._monitor.snapshot(),
    };
  }

  // ── Default Behavior ──

  _defaultBehavior() {
    return {
      onInit:   null,
      onDestroy: null,
      handlers: {},
      async defaultHandler(payload, bee) {
        // Default: route through inference if available
        if (bee.deps.inference) {
          return bee.deps.inference.infer({
            prompt:   typeof payload === 'string' ? payload : JSON.stringify(payload),
            taskType: bee.domain in { research: 1, documentation: 1 } ? bee.domain : 'quick',
            sessionId: bee.id,
          });
        }
        return { result: 'no handler defined', payload };
      },
    };
  }
}

// ─────────────────────────────────────────────
// Bee Factory
// ─────────────────────────────────────────────

/**
 * @typedef {object} FactoryConfig
 * @property {number}  [maxBees=100]       Maximum concurrent bees
 * @property {object}  [defaultDeps]       Default dependencies injected to all bees
 * @property {object}  [defaultResourceLimits] Default resource limits
 * @property {object}  [registry]          BeeRegistry instance for registration
 */

/**
 * Dynamic Agent Worker Factory.
 *
 * Creates and manages Heady Bee agents across 24 domains.
 * Supports both persistent (long-lived) and ephemeral (one-shot) bees.
 * Integrates with BeeRegistry for discovery.
 *
 * @extends EventEmitter
 */
class BeeFactory extends EventEmitter {
  /**
   * @param {FactoryConfig} [config]
   */
  constructor(config = {}) {
    super();
    this.config      = config;
    this.maxBees     = config.maxBees ?? 100;
    this.defaultDeps = config.defaultDeps ?? {};
    this.defaultLimits = config.defaultResourceLimits ?? {};
    this._registry   = config.registry ?? null;

    /** @type {Map<string, Bee>} All active bees */
    this._bees = new Map();
  }

  // ── Injection ──

  /**
   * Set the BeeRegistry instance.
   * @param {object} registry
   */
  setRegistry(registry) { this._registry = registry; }

  // ── Creation ──

  /**
   * Create a persistent Bee with custom configuration.
   * The bee is initialized and registered immediately.
   *
   * @param {BeeConfig} config
   * @returns {Promise<Bee>}
   */
  async createBee(config = {}) {
    this._checkCapacity();

    const bee = new Bee({
      ...config,
      dependencies:   { ...this.defaultDeps, ...(config.dependencies ?? {}) },
      resourceLimits: { ...this.defaultLimits, ...(config.resourceLimits ?? {}) },
      ephemeral:      false,
    });

    this._register(bee);
    await bee.initialize();

    return bee;
  }

  /**
   * Spawn an ephemeral Bee for a one-time task.
   * The bee auto-terminates after its task completes.
   *
   * @param {BeeConfig} config
   * @returns {Promise<Bee>}
   */
  async spawnBee(config = {}) {
    this._checkCapacity();

    const bee = new Bee({
      ...config,
      dependencies:   { ...this.defaultDeps, ...(config.dependencies ?? {}) },
      resourceLimits: {
        ...this.defaultLimits,
        maxLifetimeMs: 300_000, // 5 min max for ephemeral
        maxTasks:      1,
        ...(config.resourceLimits ?? {}),
      },
      ephemeral: true,
    });

    this._register(bee);
    await bee.initialize();

    return bee;
  }

  /**
   * Spawn and immediately execute a one-shot task.
   * @param {BeeConfig} config
   * @param {object} task
   * @returns {Promise<object>} Task result
   */
  async spawnAndExecute(config, task) {
    const bee = await this.spawnBee(config);
    return bee.execute(task);
  }

  // ── Retrieval ──

  /**
   * Get a bee by ID.
   * @param {string} id
   * @returns {Bee|undefined}
   */
  get(id) { return this._bees.get(id); }

  /**
   * List all active bees, optionally filtered by domain.
   * @param {string} [domain]
   * @returns {Bee[]}
   */
  listBees(domain) {
    const all = [...this._bees.values()];
    if (domain) return all.filter(b => b.domain === domain);
    return all;
  }

  /**
   * Find bees matching a predicate.
   * @param {function} predicate
   * @returns {Bee[]}
   */
  find(predicate) {
    return [...this._bees.values()].filter(predicate);
  }

  /**
   * Find the first healthy bee for a given domain.
   * @param {string} domain
   * @returns {Bee|null}
   */
  findHealthy(domain) {
    return this.listBees(domain).find(b => b.health().healthy) ?? null;
  }

  // ── Termination ──

  /**
   * Terminate a specific bee.
   * @param {string} id
   * @param {string} [reason]
   */
  async terminateBee(id, reason = 'factory_request') {
    const bee = this._bees.get(id);
    if (!bee) return;
    await bee.terminate(reason);
  }

  /**
   * Terminate all bees for a domain.
   * @param {string} domain
   * @param {string} [reason]
   */
  async terminateDomain(domain, reason = 'domain_shutdown') {
    const bees = this.listBees(domain);
    await Promise.all(bees.map(b => b.terminate(reason)));
  }

  /**
   * Gracefully shut down all bees.
   */
  async shutdown() {
    const all = [...this._bees.values()];
    await Promise.all(all.map(b => b.terminate('factory_shutdown')));
    this._bees.clear();
    this.emit('shutdown');
  }

  // ── Hot-Swap ──

  /**
   * Hot-swap the behavior of an existing bee.
   * @param {string} id
   * @param {object} newBehavior
   */
  hotSwap(id, newBehavior) {
    const bee = this._bees.get(id);
    if (!bee) throw new Error(`Bee "${id}" not found`);
    bee.hotSwap(newBehavior);
  }

  // ── Metrics & Health ──

  /**
   * Collect health and metrics for all bees.
   * @returns {BeeMetrics[]}
   */
  healthReport() {
    return [...this._bees.values()].map(b => ({
      ...b.metrics(),
      health: b.health(),
    }));
  }

  /**
   * Factory-level statistics.
   * @returns {object}
   */
  stats() {
    const all     = [...this._bees.values()];
    const byState = {};
    for (const s of Object.values(BEE_STATES)) {
      byState[s] = all.filter(b => b.state === s).length;
    }
    const byDomain = {};
    for (const b of all) {
      byDomain[b.domain] = (byDomain[b.domain] ?? 0) + 1;
    }
    return {
      total:   all.length,
      capacity: this.maxBees,
      byState,
      byDomain,
    };
  }

  // ── Private ──

  _checkCapacity() {
    const active = [...this._bees.values()].filter(
      b => ![BEE_STATES.TERMINATED, BEE_STATES.ERROR].includes(b.state)
    ).length;
    if (active >= this.maxBees) {
      throw new Error(`BeeFactory: capacity limit reached (${active}/${this.maxBees})`);
    }
  }

  _register(bee) {
    this._bees.set(bee.id, bee);

    // Forward lifecycle events
    bee.on('state_change',  e => this.emit('bee_state_change', e));
    bee.on('task_start',    e => this.emit('bee_task_start', e));
    bee.on('task_complete', e => this.emit('bee_task_complete', e));
    bee.on('task_error',    e => this.emit('bee_task_error', e));
    bee.on('hot_swapped',   e => this.emit('bee_hot_swapped', e));

    // Cleanup on termination
    bee.on('terminated', (e) => {
      setTimeout(() => this._bees.delete(bee.id), 5000); // 5s grace
      this.emit('bee_terminated', e);
      this._registry?.deregister(bee.id);
    });

    // Register in registry
    this._registry?.register({
      id:       bee.id,
      name:     bee.name,
      domain:   bee.domain,
      ephemeral: bee.ephemeral,
      factory:  this,
    });

    this.emit('bee_created', { beeId: bee.id, domain: bee.domain, ephemeral: bee.ephemeral });
  }
}

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

function _uuid() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

// ─────────────────────────────────────────────
// Exports
// ─────────────────────────────────────────────

export {

  BeeFactory,
  Bee,
  BeeResourceMonitor,
  BEE_STATES,
  BEE_DOMAINS,
  DEFAULT_RESOURCE_LIMITS,
};
