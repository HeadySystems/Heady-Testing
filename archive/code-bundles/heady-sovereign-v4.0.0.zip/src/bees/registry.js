/**
 * ∞ Heady™ Bee Registry — Central Bee Discovery & Lifecycle Registry
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

const EventEmitter = require('events');
const fs           = require('fs');
const path         = require('path');

// ─────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────

/** Registry event types */
const REGISTRY_EVENTS = {
  REGISTERED:     'bee_registered',
  DEREGISTERED:   'bee_deregistered',
  UPDATED:        'bee_updated',
  DISCOVERED:     'bee_discovered',
  DEPENDENCY_SET: 'bee_dependency_set',
};

// ─────────────────────────────────────────────
// Registry Entry
// ─────────────────────────────────────────────

/**
 * @typedef {object} BeeRegistryEntry
 * @property {string}   id            Bee ID
 * @property {string}   name          Bee name
 * @property {string}   domain        Bee domain
 * @property {boolean}  ephemeral     Whether the bee is ephemeral
 * @property {string}   state         Current lifecycle state
 * @property {string[]} capabilities  Declared capabilities
 * @property {string[]} dependencies  IDs of services/bees this bee depends on
 * @property {object}   factory       Reference to creating factory
 * @property {object}   metadata      Arbitrary key-value metadata
 * @property {number}   registeredAt  Unix ms
 * @property {number}   updatedAt     Unix ms
 */

// ─────────────────────────────────────────────
// Dependency Graph
// ─────────────────────────────────────────────

/**
 * Minimal directed dependency graph for tracking bee→service relationships.
 */
class DependencyGraph {
  constructor() {
    /** @type {Map<string, Set<string>>} node → set of dependencies */
    this._edges = new Map();
  }

  /**
   * Add an edge: `from` depends on `to`.
   * @param {string} from
   * @param {string} to
   */
  addEdge(from, to) {
    if (!this._edges.has(from)) this._edges.set(from, new Set());
    this._edges.get(from).add(to);
  }

  /**
   * Remove all edges from a node.
   * @param {string} from
   */
  removeNode(from) {
    this._edges.delete(from);
    // Also remove as a dependency target
    for (const deps of this._edges.values()) deps.delete(from);
  }

  /**
   * Get direct dependencies of a node.
   * @param {string} node
   * @returns {string[]}
   */
  depsOf(node) {
    return [...(this._edges.get(node) ?? [])];
  }

  /**
   * Get all nodes that depend on a given node.
   * @param {string} target
   * @returns {string[]}
   */
  dependantsOf(target) {
    const result = [];
    for (const [node, deps] of this._edges) {
      if (deps.has(target)) result.push(node);
    }
    return result;
  }

  /**
   * Check if there's a path from `from` to `to` (cycle detection).
   * @param {string} from
   * @param {string} to
   * @returns {boolean}
   */
  hasPath(from, to) {
    const visited = new Set();
    const queue   = [from];
    while (queue.length) {
      const node = queue.shift();
      if (node === to) return true;
      if (visited.has(node)) continue;
      visited.add(node);
      for (const dep of (this._edges.get(node) ?? [])) queue.push(dep);
    }
    return false;
  }

  /** @returns {object} Adjacency snapshot */
  snapshot() {
    const snap = {};
    for (const [node, deps] of this._edges) snap[node] = [...deps];
    return snap;
  }
}

// ─────────────────────────────────────────────
// Bee Registry
// ─────────────────────────────────────────────

/**
 * @typedef {object} BeeRegistryConfig
 * @property {string}  [persistPath]  File path for JSON persistence
 * @property {number}  [maxEntries]   Max registered bees
 */

/**
 * @typedef {object} DiscoveryQuery
 * @property {string}   [domain]      Filter by domain
 * @property {string}   [state]       Filter by lifecycle state
 * @property {string}   [capability]  Filter by declared capability
 * @property {boolean}  [healthy]     Filter by health
 * @property {boolean}  [ephemeral]   Filter by ephemeral flag
 */

/**
 * Central Bee Registry.
 *
 * Responsibilities:
 * - Register/deregister bees and track their entry
 * - Discover bees by domain, capability, or state
 * - Track inter-bee and bee-service dependencies
 * - Emit lifecycle events for observability
 * - Persist registry state to disk
 *
 * @extends EventEmitter
 */
class BeeRegistry extends EventEmitter {
  /**
   * @param {BeeRegistryConfig} [config]
   */
  constructor(config = {}) {
    super();
    this.config      = config;
    this.persistPath = config.persistPath ?? null;
    this.maxEntries  = config.maxEntries  ?? 1_000;

    /** @type {Map<string, BeeRegistryEntry>} */
    this._entries    = new Map();

    /** Dependency graph: beeId → service/beeId dependencies */
    this._deps       = new DependencyGraph();

    if (this.persistPath) this._load();
  }

  // ── Registration ──

  /**
   * Register a bee.
   * @param {Partial<BeeRegistryEntry> & {id: string}} entry
   * @returns {BeeRegistryEntry}
   */
  register(entry) {
    if (!entry.id) throw new Error('BeeRegistry: entry must have an id');
    if (this._entries.size >= this.maxEntries) {
      throw new Error(`BeeRegistry: max entries (${this.maxEntries}) reached`);
    }

    const now   = Date.now();
    const full  = {
      id:           entry.id,
      name:         entry.name         ?? entry.id,
      domain:       entry.domain       ?? 'general',
      ephemeral:    entry.ephemeral    ?? false,
      state:        entry.state        ?? 'created',
      capabilities: entry.capabilities ?? this._inferCapabilities(entry.domain),
      dependencies: entry.dependencies ?? [],
      factory:      entry.factory      ?? null,
      metadata:     entry.metadata     ?? {},
      registeredAt: now,
      updatedAt:    now,
    };

    this._entries.set(full.id, full);

    // Add dependencies to graph
    for (const dep of full.dependencies) {
      this._deps.addEdge(full.id, dep);
    }

    this._persist();
    this.emit(REGISTRY_EVENTS.REGISTERED, full);
    return full;
  }

  /**
   * Update an existing entry.
   * @param {string} id
   * @param {Partial<BeeRegistryEntry>} updates
   * @returns {BeeRegistryEntry}
   */
  update(id, updates) {
    const entry = this._entries.get(id);
    if (!entry) throw new Error(`BeeRegistry: bee "${id}" not found`);

    // Update dependency graph if dependencies changed
    if (updates.dependencies) {
      this._deps.removeNode(id);
      for (const dep of updates.dependencies) this._deps.addEdge(id, dep);
    }

    const updated = { ...entry, ...updates, updatedAt: Date.now() };
    this._entries.set(id, updated);
    this._persist();
    this.emit(REGISTRY_EVENTS.UPDATED, updated);
    return updated;
  }

  /**
   * Deregister a bee.
   * @param {string} id
   */
  deregister(id) {
    const entry = this._entries.get(id);
    if (!entry) return;
    this._entries.delete(id);
    this._deps.removeNode(id);
    this._persist();
    this.emit(REGISTRY_EVENTS.DEREGISTERED, { id, domain: entry.domain });
  }

  // ── Discovery ──

  /**
   * Discover bees matching a query.
   * @param {DiscoveryQuery} [query]
   * @returns {BeeRegistryEntry[]}
   */
  discover(query = {}) {
    let results = [...this._entries.values()];

    if (query.domain)     results = results.filter(e => e.domain === query.domain);
    if (query.state)      results = results.filter(e => e.state  === query.state);
    if (query.capability) results = results.filter(e => e.capabilities.includes(query.capability));
    if (query.ephemeral !== undefined) results = results.filter(e => e.ephemeral === query.ephemeral);

    if (query.healthy !== undefined) {
      results = results.filter(e => {
        const isHealthy = !['error', 'terminated'].includes(e.state);
        return query.healthy ? isHealthy : !isHealthy;
      });
    }

    this.emit(REGISTRY_EVENTS.DISCOVERED, { query, count: results.length });
    return results;
  }

  /**
   * Find a single bee by ID.
   * @param {string} id
   * @returns {BeeRegistryEntry|null}
   */
  findById(id) {
    return this._entries.get(id) ?? null;
  }

  /**
   * Find all bees for a specific domain.
   * @param {string} domain
   * @returns {BeeRegistryEntry[]}
   */
  byDomain(domain) {
    return this.discover({ domain });
  }

  /**
   * Find bees with a specific capability.
   * @param {string} capability
   * @returns {BeeRegistryEntry[]}
   */
  byCapability(capability) {
    return this.discover({ capability });
  }

  /**
   * Find bees in a specific state.
   * @param {string} state
   * @returns {BeeRegistryEntry[]}
   */
  byState(state) {
    return this.discover({ state });
  }

  // ── Dependencies ──

  /**
   * Set dependencies for a bee.
   * @param {string} beeId
   * @param {string[]} deps  IDs of services or bees this bee depends on
   */
  setDependencies(beeId, deps) {
    this.update(beeId, { dependencies: deps });
    this.emit(REGISTRY_EVENTS.DEPENDENCY_SET, { beeId, deps });
  }

  /**
   * Get all dependencies of a bee.
   * @param {string} beeId
   * @returns {string[]}
   */
  getDependencies(beeId) {
    return this._deps.depsOf(beeId);
  }

  /**
   * Get all bees that depend on a given service/bee.
   * @param {string} targetId
   * @returns {string[]} IDs of dependent bees
   */
  getDependants(targetId) {
    return this._deps.dependantsOf(targetId);
  }

  /**
   * Detect circular dependency chains.
   * @param {string} fromId
   * @param {string} toId
   * @returns {boolean}
   */
  wouldCreateCycle(fromId, toId) {
    return this._deps.hasPath(toId, fromId);
  }

  /**
   * Dependency graph snapshot.
   * @returns {object}
   */
  dependencyGraph() {
    return this._deps.snapshot();
  }

  // ── Bulk Update (State Sync) ──

  /**
   * Sync state from a live Bee instance into the registry.
   * @param {object} bee  Live Bee instance
   */
  syncBeeState(bee) {
    if (!this._entries.has(bee.id)) return;
    this.update(bee.id, { state: bee.state });
  }

  // ── Statistics ──

  /**
   * Registry statistics.
   * @returns {object}
   */
  stats() {
    const all      = [...this._entries.values()];
    const byDomain = {};
    const byState  = {};

    for (const e of all) {
      byDomain[e.domain] = (byDomain[e.domain] ?? 0) + 1;
      byState[e.state]   = (byState[e.state]   ?? 0) + 1;
    }

    return {
      total:    all.length,
      byDomain,
      byState,
      ephemeral: all.filter(e => e.ephemeral).length,
      persistent: all.filter(e => !e.ephemeral).length,
    };
  }

  /**
   * Full registry dump.
   * @returns {BeeRegistryEntry[]}
   */
  all() {
    return [...this._entries.values()];
  }

  // ── Persistence ──

  _persist() {
    if (!this.persistPath) return;
    try {
      fs.mkdirSync(path.dirname(this.persistPath), { recursive: true });
      const data = JSON.stringify([...this._entries.values()].map(e => ({
        ...e,
        factory: null, // don't serialize factory references
      })), null, 2);
      fs.writeFileSync(this.persistPath, data, 'utf8');
    } catch { /* non-fatal */ }
  }

  _load() {
    try {
      const raw   = fs.readFileSync(this.persistPath, 'utf8');
      const list  = JSON.parse(raw);
      for (const entry of list) {
        this._entries.set(entry.id, entry);
        for (const dep of entry.dependencies ?? []) {
          this._deps.addEdge(entry.id, dep);
        }
      }
    } catch { /* no prior state */ }
  }

  // ── Helpers ──

  /**
   * Infer capabilities from a domain name.
   * @param {string} [domain]
   * @returns {string[]}
   */
  _inferCapabilities(domain) {
    const capMap = {
      code_generation: ['generate', 'code', 'javascript', 'python'],
      code_review:     ['review', 'lint', 'audit'],
      security:        ['scan', 'audit', 'vulnerability'],
      research:        ['search', 'summarize', 'analyze'],
      documentation:   ['document', 'write', 'generate'],
      deployment:      ['deploy', 'rollback', 'release'],
      monitoring:      ['observe', 'alert', 'metric'],
      healing:         ['diagnose', 'repair', 'recover'],
      creative:        ['write', 'ideate', 'generate'],
      orchestration:   ['coordinate', 'route', 'schedule'],
      inference:       ['infer', 'embed', 'generate'],
      memory:          ['store', 'retrieve', 'search'],
      vector:          ['embed', 'search', 'index'],
      analytics:       ['analyze', 'report', 'aggregate'],
      pattern:         ['learn', 'match', 'predict'],
    };
    return capMap[domain] ?? ['execute', 'process'];
  }
}

// ─────────────────────────────────────────────
// Exports
// ─────────────────────────────────────────────

export {

  BeeRegistry,
  DependencyGraph,
  REGISTRY_EVENTS,
};
