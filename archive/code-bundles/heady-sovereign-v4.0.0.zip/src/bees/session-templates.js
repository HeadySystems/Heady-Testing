/**
 * ∞ Heady™ Session Templates — Pre-Configured Bee Session Templates
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

const EventEmitter = require('events');
const { BEE_DOMAINS, BEE_STATES } = require('./bee-factory');

// ─────────────────────────────────────────────
// Template Definitions
// ─────────────────────────────────────────────

/**
 * @typedef {object} BeeSpec
 * @property {string}   role        Logical role in the workflow
 * @property {string}   domain      Bee domain from BEE_DOMAINS
 * @property {boolean}  [required]  If true, abort workflow if this bee fails to init
 * @property {object}   [config]    Additional bee config overrides
 */

/**
 * @typedef {object} DataFlow
 * @property {string}   from        Source role or '$input'
 * @property {string}   to          Target role or '$output'
 * @property {string}   [field]     Specific field to pass (default: entire result)
 * @property {function} [transform] Optional transformation function
 */

/**
 * @typedef {object} SessionTemplate
 * @property {string}     id           Unique template ID
 * @property {string}     name         Human-readable name
 * @property {string}     description  What this template does
 * @property {string[]}   tags         Searchable tags
 * @property {BeeSpec[]}  bees         Required bee definitions
 * @property {DataFlow[]} dataFlow     How data flows between bees
 * @property {object}     [options]    Template-level options
 */

/**
 * The built-in session templates library.
 * @type {SessionTemplate[]}
 */
const TEMPLATES = [
  // ── Deploy Template ─────────────────────────────────────────────────
  {
    id:          'deploy',
    name:        'Deployment Pipeline',
    description: 'Full deployment workflow: scan → review → test → deploy → verify',
    tags:        ['deployment', 'release', 'cicd'],
    bees: [
      { role: 'security_scanner', domain: BEE_DOMAINS.SECURITY,    required: true  },
      { role: 'code_reviewer',    domain: BEE_DOMAINS.CODE_REVIEW,  required: true  },
      { role: 'test_runner',      domain: BEE_DOMAINS.TESTING,      required: true  },
      { role: 'deployer',         domain: BEE_DOMAINS.DEPLOYMENT,   required: true  },
      { role: 'health_checker',   domain: BEE_DOMAINS.MONITORING,   required: false },
    ],
    dataFlow: [
      { from: '$input',          to: 'security_scanner', field: 'code' },
      { from: '$input',          to: 'code_reviewer',    field: 'code' },
      { from: 'security_scanner', to: 'deployer',        field: 'scanReport' },
      { from: 'code_reviewer',   to: 'deployer',         field: 'reviewReport' },
      { from: 'test_runner',     to: 'deployer',         field: 'testResults' },
      { from: 'deployer',        to: 'health_checker',   field: 'deploymentId' },
      { from: 'health_checker',  to: '$output' },
    ],
    options: {
      failFast:         true,
      parallelScan:     true,  // security + code review run in parallel
      rollbackOnFailure: true,
    },
  },

  // ── Scan Template ────────────────────────────────────────────────────
  {
    id:          'scan',
    name:        'Security + Quality Scan',
    description: 'Multi-layer scan: security vulnerabilities, code quality, dependency audit',
    tags:        ['security', 'audit', 'quality', 'scan'],
    bees: [
      { role: 'security_bee',    domain: BEE_DOMAINS.SECURITY,        required: true },
      { role: 'code_review_bee', domain: BEE_DOMAINS.CODE_REVIEW,     required: true },
      { role: 'pattern_bee',     domain: BEE_DOMAINS.PATTERN,         required: false },
      { role: 'doc_bee',         domain: BEE_DOMAINS.DOCUMENTATION,   required: false },
    ],
    dataFlow: [
      { from: '$input',         to: 'security_bee',    field: 'target' },
      { from: '$input',         to: 'code_review_bee', field: 'code' },
      { from: '$input',         to: 'pattern_bee',     field: 'executionRecord' },
      { from: 'security_bee',   to: '$output',         field: 'securityReport' },
      { from: 'code_review_bee', to: '$output',        field: 'qualityReport' },
      { from: 'pattern_bee',    to: '$output',         field: 'patternReport' },
    ],
    options: {
      parallel:  true,
      aggregate: true,
    },
  },

  // ── Heal Template ─────────────────────────────────────────────────────
  {
    id:          'heal',
    name:        'Self-Healing Response',
    description: 'Automated healing: diagnose → propose fix → apply → verify',
    tags:        ['healing', 'recovery', 'resilience', 'ops'],
    bees: [
      { role: 'diagnostician',  domain: BEE_DOMAINS.MONITORING,    required: true  },
      { role: 'code_fixer',     domain: BEE_DOMAINS.CODE_GEN,      required: false },
      { role: 'healer',         domain: BEE_DOMAINS.HEALING,       required: true  },
      { role: 'verifier',       domain: BEE_DOMAINS.MONITORING,    required: true  },
    ],
    dataFlow: [
      { from: '$input',       to: 'diagnostician', field: 'incident' },
      { from: 'diagnostician', to: 'code_fixer',   field: 'diagnosis' },
      { from: 'diagnostician', to: 'healer',       field: 'diagnosis' },
      { from: 'code_fixer',   to: 'healer',        field: 'patch' },
      { from: 'healer',       to: 'verifier',      field: 'healingResult' },
      { from: 'verifier',     to: '$output' },
    ],
    options: {
      timeout:          120_000,
      rollbackOnFailure: true,
      notifyOnComplete:  true,
    },
  },

  // ── Research Template ─────────────────────────────────────────────────
  {
    id:          'research',
    name:        'Deep Research Workflow',
    description: 'Multi-source research: search → synthesize → document → store in memory',
    tags:        ['research', 'knowledge', 'memory', 'content'],
    bees: [
      { role: 'researcher',    domain: BEE_DOMAINS.RESEARCH,       required: true  },
      { role: 'synthesizer',   domain: BEE_DOMAINS.SUMMARIZATION,  required: true  },
      { role: 'writer',        domain: BEE_DOMAINS.DOCUMENTATION,  required: false },
      { role: 'memory_bee',    domain: BEE_DOMAINS.MEMORY,         required: false },
    ],
    dataFlow: [
      { from: '$input',      to: 'researcher',  field: 'query' },
      { from: 'researcher',  to: 'synthesizer', field: 'rawResults' },
      { from: 'synthesizer', to: 'writer',      field: 'synthesis' },
      { from: 'writer',      to: 'memory_bee',  field: 'document' },
      { from: 'writer',      to: '$output' },
    ],
    options: {
      maxDepth:   3,
      storeResult: true,
    },
  },

  // ── Build Template ────────────────────────────────────────────────────
  {
    id:          'build',
    name:        'AI-Assisted Build',
    description: 'Generate, review, test, and package code using AI bees',
    tags:        ['build', 'codegen', 'testing', 'development'],
    bees: [
      { role: 'architect',    domain: BEE_DOMAINS.CODE_GEN,     required: true },
      { role: 'coder',        domain: BEE_DOMAINS.CODE_GEN,     required: true },
      { role: 'reviewer',     domain: BEE_DOMAINS.CODE_REVIEW,  required: true },
      { role: 'tester',       domain: BEE_DOMAINS.TESTING,      required: true },
      { role: 'documenter',   domain: BEE_DOMAINS.DOCUMENTATION, required: false },
    ],
    dataFlow: [
      { from: '$input',    to: 'architect', field: 'requirements' },
      { from: 'architect', to: 'coder',    field: 'design' },
      { from: 'coder',     to: 'reviewer', field: 'code' },
      { from: 'coder',     to: 'tester',   field: 'code' },
      { from: 'reviewer',  to: 'coder',    field: 'feedback',
        transform: (feedback) => ({ refinement: feedback }) },
      { from: 'tester',    to: 'documenter', field: 'testReport' },
      { from: 'coder',     to: 'documenter', field: 'code' },
      { from: 'documenter', to: '$output' },
    ],
    options: {
      iterativeRefinement: true,
      maxIterations:       3,
    },
  },

  // ── Monitor Template ──────────────────────────────────────────────────
  {
    id:          'monitor',
    name:        'Continuous Monitoring',
    description: 'Persistent monitoring loop: collect metrics → detect anomalies → alert',
    tags:        ['monitoring', 'observability', 'alerts', 'drift'],
    bees: [
      { role: 'metric_collector', domain: BEE_DOMAINS.MONITORING,  required: true  },
      { role: 'anomaly_detector', domain: BEE_DOMAINS.PATTERN,     required: true  },
      { role: 'alert_bee',        domain: BEE_DOMAINS.ORCHESTRATION, required: false },
    ],
    dataFlow: [
      { from: '$input',           to: 'metric_collector', field: 'target' },
      { from: 'metric_collector', to: 'anomaly_detector', field: 'metrics' },
      { from: 'anomaly_detector', to: 'alert_bee',        field: 'anomalies' },
      { from: 'alert_bee',        to: '$output' },
    ],
    options: {
      persistent:    true,    // bees stay alive; don't auto-terminate
      intervalMs:    10_000,  // polling interval
      alertThreshold: 0.8,
    },
  },

  // ── Embed + Store Template ────────────────────────────────────────────
  {
    id:          'embed-and-store',
    name:        'Embed & Store',
    description: 'Embed content into vector memory for semantic retrieval',
    tags:        ['memory', 'embedding', 'vector', 'storage'],
    bees: [
      { role: 'embedder',    domain: BEE_DOMAINS.EMBEDDING, required: true },
      { role: 'memory_bee',  domain: BEE_DOMAINS.MEMORY,    required: true },
    ],
    dataFlow: [
      { from: '$input',   to: 'embedder',   field: 'content' },
      { from: 'embedder', to: 'memory_bee', field: 'embedding' },
      { from: 'memory_bee', to: '$output' },
    ],
    options: { batchSize: 10 },
  },

  // ── Creative Studio Template ──────────────────────────────────────────
  {
    id:          'creative-studio',
    name:        'Creative Studio',
    description: 'Multi-agent creative workflow: ideate → write → refine → deliver',
    tags:        ['creative', 'writing', 'content', 'marketing'],
    bees: [
      { role: 'ideator',   domain: BEE_DOMAINS.CREATIVE,       required: true  },
      { role: 'writer',    domain: BEE_DOMAINS.CREATIVE,       required: true  },
      { role: 'editor',    domain: BEE_DOMAINS.DOCUMENTATION,  required: false },
      { role: 'translator', domain: BEE_DOMAINS.TRANSLATION,   required: false },
    ],
    dataFlow: [
      { from: '$input',  to: 'ideator', field: 'brief' },
      { from: 'ideator', to: 'writer',  field: 'ideas' },
      { from: 'writer',  to: 'editor',  field: 'draft' },
      { from: 'editor',  to: 'translator', field: 'refinedContent' },
      { from: 'editor',  to: '$output',    field: 'refinedContent' },
    ],
    options: { iterations: 2 },
  },
];

// ─────────────────────────────────────────────
// Template Registry
// ─────────────────────────────────────────────

/**
 * Registry of session templates with composition support.
 */
class TemplateRegistry {
  constructor() {
    /** @type {Map<string, SessionTemplate>} */
    this._templates = new Map();
    // Load built-ins
    for (const t of TEMPLATES) this._templates.set(t.id, t);
  }

  /**
   * Register a custom template.
   * @param {SessionTemplate} template
   */
  register(template) {
    if (!template.id) throw new Error('Template must have an id');
    this._templates.set(template.id, template);
  }

  /**
   * Get a template by ID.
   * @param {string} id
   * @returns {SessionTemplate|undefined}
   */
  get(id) { return this._templates.get(id); }

  /**
   * List all templates.
   * @param {string} [tag]  Optional tag filter
   * @returns {SessionTemplate[]}
   */
  list(tag) {
    const all = [...this._templates.values()];
    if (!tag) return all;
    return all.filter(t => t.tags?.includes(tag));
  }

  /**
   * Compose two or more templates into a new combined template.
   * The composed template runs each sub-template in sequence,
   * passing the output of each as the input to the next.
   *
   * @param {string}   id          ID for the composed template
   * @param {string[]} templateIds IDs to compose in order
   * @param {object}   [meta]      Override name/description/tags
   * @returns {SessionTemplate}
   */
  compose(id, templateIds, meta = {}) {
    const templates = templateIds.map(tid => {
      const t = this._templates.get(tid);
      if (!t) throw new Error(`Template not found: ${tid}`);
      return t;
    });

    const allBees = [];
    const allFlows = [];
    const seen = new Set();

    for (let i = 0; i < templates.length; i++) {
      const t      = templates[i];
      const prefix = `stage${i}_`;

      // Prefix bee roles to avoid collisions
      for (const bee of t.bees) {
        const prefixed = { ...bee, role: `${prefix}${bee.role}` };
        allBees.push(prefixed);
      }

      for (const flow of t.dataFlow) {
        const prefixedFrom = flow.from === '$input'  ? (i === 0 ? '$input' : `stage${i - 1}_$output`) : `${prefix}${flow.from}`;
        const prefixedTo   = flow.to   === '$output' ? (i === templates.length - 1 ? '$output' : `stage${i}_$output`) : `${prefix}${flow.to}`;
        allFlows.push({ ...flow, from: prefixedFrom, to: prefixedTo });
      }
    }

    const composed = {
      id,
      name:        meta.name        ?? `Composed: ${templateIds.join(' → ')}`,
      description: meta.description ?? `Composed workflow: ${templateIds.join(', ')}`,
      tags:        meta.tags        ?? [...new Set(templates.flatMap(t => t.tags ?? []))],
      bees:        allBees,
      dataFlow:    allFlows,
      options:     meta.options ?? {},
      _composed:   templateIds,
    };

    this._templates.set(id, composed);
    return composed;
  }
}

// ─────────────────────────────────────────────
// Session Runner
// ─────────────────────────────────────────────

/**
 * @typedef {object} SessionRunConfig
 * @property {string}   templateId
 * @property {object}   input         Initial input data passed to '$input'
 * @property {object}   [factory]     BeeFactory instance
 * @property {object}   [beeConfigs]  Per-role bee config overrides (keyed by role)
 * @property {boolean}  [dryRun]      If true, just validate template without executing
 */

/**
 * @typedef {object} SessionResult
 * @property {string}   sessionId
 * @property {string}   templateId
 * @property {boolean}  success
 * @property {object}   output        Final output ($output value)
 * @property {object}   stageResults  Per-bee results
 * @property {number}   durationMs
 * @property {string[]} errors
 */

/**
 * Executes a session template: spawns required bees, wires data flow,
 * and runs the workflow to completion.
 *
 * @extends EventEmitter
 */
class SessionRunner extends EventEmitter {
  /**
   * @param {object} [config]
   * @param {object} [config.factory]   BeeFactory instance
   * @param {object} [config.registry]  TemplateRegistry instance
   */
  constructor(config = {}) {
    super();
    this.factory  = config.factory  ?? null;
    this.registry = config.registry ?? new TemplateRegistry();
  }

  /**
   * Run a session template.
   * @param {SessionRunConfig} runConfig
   * @returns {Promise<SessionResult>}
   */
  async run(runConfig) {
    const sessionId = _sessionId();
    const start     = Date.now();
    const errors    = [];

    const template = this.registry.get(runConfig.templateId);
    if (!template) throw new Error(`Template not found: ${runConfig.templateId}`);

    if (runConfig.dryRun) {
      return { sessionId, templateId: runConfig.templateId, success: true, dryRun: true, template };
    }

    this.emit('session_start', { sessionId, templateId: template.id });

    const factory = runConfig.factory ?? this.factory;
    if (!factory) throw new Error('SessionRunner: factory is required');

    // ─ Spawn bees ─
    const bees = new Map(); // role → Bee
    for (const spec of template.bees) {
      try {
        const beeConfig = {
          domain:    spec.domain,
          name:      spec.role,
          ephemeral: !template.options?.persistent,
          ...(runConfig.beeConfigs?.[spec.role] ?? {}),
          ...(spec.config ?? {}),
        };
        const bee = await factory.createBee(beeConfig);
        bees.set(spec.role, bee);
        this.emit('bee_ready', { sessionId, role: spec.role, beeId: bee.id });
      } catch (err) {
        if (spec.required) {
          errors.push(`Required bee "${spec.role}" failed to init: ${err.message}`);
          await this._cleanup(bees, template.options?.persistent);
          return {
            sessionId,
            templateId: template.id,
            success:    false,
            output:     null,
            stageResults: {},
            durationMs: Date.now() - start,
            errors,
          };
        }
        errors.push(`Optional bee "${spec.role}" failed: ${err.message}`);
      }
    }

    // ─ Execute data flow ─
    const context = new Map([['$input', runConfig.input]]);
    const stageResults = {};

    // Build role → dataFlow dependencies (topological execution order)
    const executionOrder = this._buildExecutionOrder(template);

    for (const role of executionOrder) {
      const bee = bees.get(role);
      if (!bee) continue;

      // Gather inputs for this role
      const inputs = this._gatherInputs(role, template.dataFlow, context);

      try {
        const result = await bee.execute({
          type:    'process',
          payload: inputs,
          id:      `${sessionId}:${role}`,
        });
        context.set(role, result);
        stageResults[role] = result;
        this.emit('stage_complete', { sessionId, role, result });
      } catch (err) {
        errors.push(`Stage "${role}" failed: ${err.message}`);
        stageResults[role] = { error: err.message };
        // Continue unless failFast
        if (template.options?.failFast) break;
      }
    }

    // Gather $output
    const outputFlow = template.dataFlow.find(f => f.to === '$output');
    const output     = outputFlow
      ? (context.get(outputFlow.from) ?? null)
      : this._aggregateOutput(context, template);

    // ─ Cleanup ─
    if (!template.options?.persistent) {
      await this._cleanup(bees);
    }

    const result = {
      sessionId,
      templateId:   template.id,
      success:      errors.length === 0,
      output,
      stageResults,
      durationMs:   Date.now() - start,
      errors,
    };

    this.emit('session_complete', result);
    return result;
  }

  _buildExecutionOrder(template) {
    // Simple topological sort based on data flow
    const roles   = new Set(template.bees.map(b => b.role));
    const inDegree = new Map([...roles].map(r => [r, 0]));
    const edges    = new Map([...roles].map(r => [r, []]));

    for (const flow of template.dataFlow) {
      if (flow.from !== '$input' && roles.has(flow.from) && roles.has(flow.to)) {
        edges.get(flow.from).push(flow.to);
        inDegree.set(flow.to, (inDegree.get(flow.to) ?? 0) + 1);
      }
    }

    const queue  = [...inDegree.entries()].filter(([, d]) => d === 0).map(([r]) => r);
    const order  = [];
    while (queue.length) {
      const role = queue.shift();
      order.push(role);
      for (const next of (edges.get(role) ?? [])) {
        inDegree.set(next, inDegree.get(next) - 1);
        if (inDegree.get(next) === 0) queue.push(next);
      }
    }
    // Append any roles not reached by topological sort (disconnected)
    for (const role of roles) {
      if (!order.includes(role)) order.push(role);
    }
    return order;
  }

  _gatherInputs(role, dataFlow, context) {
    const inputs = {};
    for (const flow of dataFlow) {
      if (flow.to !== role) continue;
      const sourceValue = flow.field
        ? context.get(flow.from)?.[flow.field]
        : context.get(flow.from);
      const value = flow.transform ? flow.transform(sourceValue) : sourceValue;
      if (value !== undefined) inputs[flow.field ?? flow.from] = value;
    }
    return inputs;
  }

  _aggregateOutput(context, template) {
    // Collect all terminal role results (not feeding into another role)
    const targets = new Set(template.dataFlow.filter(f => f.to !== '$output').map(f => f.to));
    const terminals = template.bees.filter(b => !targets.has(b.role)).map(b => b.role);
    const out = {};
    for (const role of terminals) {
      if (context.has(role)) out[role] = context.get(role);
    }
    return out;
  }

  async _cleanup(bees, persistent = false) {
    if (persistent) return;
    await Promise.all([...bees.values()].map(b =>
      b.terminate('session_complete').catch(() => {})
    ));
  }
}

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

function _sessionId() {
  return `sess_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

// ─────────────────────────────────────────────
// Exports
// ─────────────────────────────────────────────

export {

  TemplateRegistry,
  SessionRunner,
  TEMPLATES,
  BEE_DOMAINS,
};
