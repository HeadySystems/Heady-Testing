/**
 * ∞ Heady™ RateLimiter — Intelligent Rate Limiting
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';

// ─── Constants ───────────────────────────────────────────────────────────────

/** Time windows available for rate limit configuration */
const WINDOW = Object.freeze({
  SECOND: 1_000,
  MINUTE: 60_000,
  HOUR:   3_600_000,
  DAY:    86_400_000,
});

/** Default rate limit configuration */
const DEFAULTS = Object.freeze({
  windowMs:       60_000,     // Default: 1-minute window
  maxRequests:    100,        // Max requests per window
  burstAllowance: 20,         // Extra burst tokens on top of base limit
  refillRateMs:   600,        // Refill 1 token every 600ms (100/min baseline)
  keyPrefix:      'ratelimit',
});

// ─── RateLimiter ─────────────────────────────────────────────────────────────

/**
 * RateLimiter implements a token-bucket algorithm with per-endpoint and
 * per-user limits, burst allowance, and configurable time windows.
 *
 * Token Bucket mechanics:
 * - Each bucket starts at `maxRequests + burstAllowance` tokens.
 * - Each request consumes 1 token.
 * - Tokens refill at `refillRateMs` per token up to the burst ceiling.
 * - When the bucket is empty, the request is rejected with rate-limit info.
 *
 * Multi-dimension limiting:
 * - Global limits (all traffic to an endpoint)
 * - Per-user limits (keyed by userId)
 * - Combined limits (endpoint × user)
 *
 * @extends EventEmitter
 *
 * @fires RateLimiter#request:allowed
 * @fires RateLimiter#request:limited
 * @fires RateLimiter#bucket:refilled
 *
 * @example
 * const rl = new RateLimiter();
 * rl.define('api/search', { maxRequests: 30, windowMs: WINDOW.MINUTE });
 *
 * const result = rl.check('api/search', 'user-42');
 * if (!result.allowed) {
 *   res.set(result.headers).status(429).send('Rate limited');
 * }
 */
class RateLimiter extends EventEmitter {
  /**
   * @param {Object}   [options={}]
   * @param {Object}   [options.defaults]     - Default limit config for undefined endpoints
   * @param {Function} [options.keyFn]        - (endpoint, userId) → bucketKey — custom key generator
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._defaults = { ...DEFAULTS, ...(options.defaults ?? {}) };
    this._keyFn    = options.keyFn ?? this._defaultKeyFn;
    this._logger   = options.logger ?? console;

    /**
     * Endpoint configurations: Map<endpoint, LimitConfig>
     * @type {Map<string, LimitConfig>}
     */
    this._configs = new Map();

    /**
     * Token buckets: Map<bucketKey, Bucket>
     * @type {Map<string, Bucket>}
     */
    this._buckets = new Map();

    /**
     * Global metrics
     * @type {RateLimiterMetrics}
     */
    this._metrics = {
      totalAllowed:  0,
      totalLimited:  0,
      totalRequests: 0,
      byEndpoint:    {},
    };
  }

  // ─── Configuration ───────────────────────────────────────────────────────────

  /**
   * Defines rate limit rules for an endpoint.
   *
   * @param {string}  endpoint
   * @param {Object}  config
   * @param {number}  [config.maxRequests=100]
   * @param {number}  [config.windowMs=60000]
   * @param {number}  [config.burstAllowance=20]
   * @param {number}  [config.refillRateMs]       - If omitted, derived from maxRequests/windowMs
   * @param {boolean} [config.perUser=true]        - Whether to also track per-user buckets
   * @returns {RateLimiter} (chainable)
   */
  define(endpoint, config = {}) {
    const maxRequests    = config.maxRequests    ?? this._defaults.maxRequests;
    const windowMs       = config.windowMs       ?? this._defaults.windowMs;
    const burstAllowance = config.burstAllowance ?? this._defaults.burstAllowance;
    const refillRateMs   = config.refillRateMs   ?? Math.floor(windowMs / maxRequests);

    this._configs.set(endpoint, {
      endpoint,
      maxRequests,
      windowMs,
      burstAllowance,
      refillRateMs,
      perUser: config.perUser !== false,
    });

    this._logger.info(
      `[RateLimiter] Defined: "${endpoint}" → ${maxRequests} req/${windowMs}ms, burst +${burstAllowance}`
    );
    return this;
  }

  // ─── Check ───────────────────────────────────────────────────────────────────

  /**
   * Checks whether a request should be allowed and consumes a token if so.
   *
   * Returns a result object that includes HTTP rate-limit headers for
   * easy response injection.
   *
   * @param {string}  endpoint
   * @param {string}  [userId='anonymous']
   * @param {number}  [cost=1]             - Token cost of this request (default 1)
   * @returns {RateLimitResult}
   */
  check(endpoint, userId = 'anonymous', cost = 1) {
    const config = this._configs.get(endpoint) ?? this._buildDefaultConfig(endpoint);
    this._metrics.totalRequests++;

    // Global endpoint bucket
    const globalKey   = this._keyFn(endpoint, '*');
    const globalBucket = this._getOrCreateBucket(globalKey, config);
    this._refill(globalBucket, config);

    // Per-user bucket (if enabled)
    let userBucket = null;
    if (config.perUser && userId !== '*') {
      const userKey = this._keyFn(endpoint, userId);
      userBucket    = this._getOrCreateBucket(userKey, config);
      this._refill(userBucket, config);
    }

    // Check both buckets
    const globalTokens = globalBucket.tokens;
    const userTokens   = userBucket ? userBucket.tokens : Infinity;
    const available    = Math.min(globalTokens, userTokens);
    const allowed      = available >= cost;

    if (allowed) {
      globalBucket.tokens -= cost;
      if (userBucket) userBucket.tokens -= cost;
      this._metrics.totalAllowed++;
      this._incrementEndpointMetric(endpoint, 'allowed');
      this.emit('request:allowed', { endpoint, userId, tokens: Math.floor(available - cost) });
    } else {
      this._metrics.totalLimited++;
      this._incrementEndpointMetric(endpoint, 'limited');
      this.emit('request:limited', { endpoint, userId, remaining: Math.floor(available) });
    }

    const limit   = config.maxRequests + config.burstAllowance;
    const remaining = Math.max(0, Math.floor(allowed ? available - cost : available));
    const resetMs = this._nextResetMs(globalBucket, config);

    return {
      allowed,
      endpoint,
      userId,
      limit,
      remaining,
      resetAt:   globalBucket.windowStart + config.windowMs,
      resetMs,
      retryAfterMs: allowed ? 0 : config.refillRateMs * Math.ceil(cost - available),
      headers:   this._buildHeaders(limit, remaining, resetMs, allowed),
    };
  }

  /**
   * Express/Fastify-compatible middleware factory.
   *
   * @param {string}  endpoint
   * @param {Object}  [opts={}]
   * @param {Function} [opts.getUserId]  - (req) → string — extract user identifier
   * @param {Function} [opts.onLimited]  - (req, res, result) → void — custom 429 handler
   * @returns {Function} middleware(req, res, next)
   */
  middleware(endpoint, opts = {}) {
    const getUserId  = opts.getUserId  ?? (req => req.user?.id ?? req.ip ?? 'anonymous');
    const onLimited  = opts.onLimited  ?? this._defaultLimitedHandler;

    return (req, res, next) => {
      const userId = getUserId(req);
      const result = this.check(endpoint, userId);

      // Always set headers
      Object.entries(result.headers).forEach(([k, v]) => res.setHeader(k, v));

      if (result.allowed) {
        next();
      } else {
        onLimited(req, res, result);
      }
    };
  }

  // ─── Metrics + Introspection ─────────────────────────────────────────────────

  /**
   * Returns current metrics snapshot.
   * @returns {RateLimiterMetrics}
   */
  getMetrics() {
    return {
      ...this._metrics,
      bucketCount: this._buckets.size,
    };
  }

  /**
   * Returns the current token count for a bucket (informational).
   * @param {string} endpoint
   * @param {string} [userId='*']
   * @returns {number}
   */
  getTokens(endpoint, userId = '*') {
    const config = this._configs.get(endpoint) ?? this._buildDefaultConfig(endpoint);
    const key    = this._keyFn(endpoint, userId);
    const bucket = this._buckets.get(key);
    if (!bucket) return config.maxRequests + config.burstAllowance;
    this._refill(bucket, config);
    return Math.floor(bucket.tokens);
  }

  /**
   * Resets a specific bucket (e.g. after a quota increase).
   * @param {string} endpoint
   * @param {string} [userId='*']
   */
  resetBucket(endpoint, userId = '*') {
    const key = this._keyFn(endpoint, userId);
    this._buckets.delete(key);
  }

  /**
   * Clears all buckets (full reset).
   */
  resetAll() {
    this._buckets.clear();
  }

  // ─── Token Bucket Internals ──────────────────────────────────────────────────

  /**
   * Gets or creates a token bucket for a key.
   * @param {string}      key
   * @param {LimitConfig} config
   * @returns {Bucket}
   */
  _getOrCreateBucket(key, config) {
    if (!this._buckets.has(key)) {
      this._buckets.set(key, {
        key,
        tokens:      config.maxRequests + config.burstAllowance,
        maxTokens:   config.maxRequests + config.burstAllowance,
        windowStart: Date.now(),
        lastRefillAt: Date.now(),
      });
    }
    return this._buckets.get(key);
  }

  /**
   * Refills tokens based on elapsed time since last refill.
   * Uses gradual refill (1 token per refillRateMs), not window-based reset,
   * to prevent thundering herd at window boundaries.
   *
   * @param {Bucket}      bucket
   * @param {LimitConfig} config
   */
  _refill(bucket, config) {
    const now      = Date.now();
    const elapsed  = now - bucket.lastRefillAt;
    const newTokens = Math.floor(elapsed / config.refillRateMs);

    if (newTokens > 0) {
      bucket.tokens       = Math.min(bucket.maxTokens, bucket.tokens + newTokens);
      bucket.lastRefillAt = now;
      if (newTokens > 1) {
        this.emit('bucket:refilled', { key: bucket.key, added: newTokens, total: bucket.tokens });
      }
    }
  }

  /**
   * Computes milliseconds until the bucket resets to full.
   * @param {Bucket}      bucket
   * @param {LimitConfig} config
   * @returns {number}
   */
  _nextResetMs(bucket, config) {
    const deficit = bucket.maxTokens - bucket.tokens;
    if (deficit <= 0) return 0;
    return deficit * config.refillRateMs;
  }

  /**
   * Builds the standard rate-limit response headers.
   * @param {number}  limit
   * @param {number}  remaining
   * @param {number}  resetMs
   * @param {boolean} allowed
   * @returns {Object}
   */
  _buildHeaders(limit, remaining, resetMs, allowed) {
    const headers = {
      'X-RateLimit-Limit':     String(limit),
      'X-RateLimit-Remaining': String(remaining),
      'X-RateLimit-Reset':     String(Math.ceil(Date.now() / 1000) + Math.ceil(resetMs / 1000)),
    };
    if (!allowed) {
      headers['Retry-After'] = String(Math.ceil(resetMs / 1000));
    }
    return headers;
  }

  /**
   * Builds a default config for an endpoint that has no explicit definition.
   * @param {string} endpoint
   * @returns {LimitConfig}
   */
  _buildDefaultConfig(endpoint) {
    return {
      endpoint,
      maxRequests:    this._defaults.maxRequests,
      windowMs:       this._defaults.windowMs,
      burstAllowance: this._defaults.burstAllowance,
      refillRateMs:   this._defaults.refillRateMs,
      perUser:        true,
    };
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  /**
   * Default bucket key generator.
   * @param {string} endpoint
   * @param {string} userId
   * @returns {string}
   */
  _defaultKeyFn(endpoint, userId) {
    return `${endpoint}::${userId}`;
  }

  /**
   * Increments a per-endpoint metric counter.
   * @param {string} endpoint
   * @param {'allowed'|'limited'} type
   */
  _incrementEndpointMetric(endpoint, type) {
    if (!this._metrics.byEndpoint[endpoint]) {
      this._metrics.byEndpoint[endpoint] = { allowed: 0, limited: 0 };
    }
    this._metrics.byEndpoint[endpoint][type]++;
  }

  /**
   * Default 429 handler for the middleware.
   * @param {Object} req
   * @param {Object} res
   * @param {RateLimitResult} result
   */
  _defaultLimitedHandler(req, res, result) {
    res.status(429).json({
      error:       'Too Many Requests',
      retryAfterMs: result.retryAfterMs,
      remaining:   0,
    });
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  RateLimiter,
  WINDOW,
  DEFAULTS,
};
