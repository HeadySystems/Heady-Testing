/**
 * ∞ Heady™ ResourcePool — Fibonacci-Ratio Resource Pool Manager
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';
import crypto from 'crypto';

// ─── Constants ───────────────────────────────────────────────────────────────

/**
 * Fibonacci ratios for pool allocation.
 * Sequence: 34, 21, 13, 8, 5 → sum = 81 (normalised to 1.0)
 * Maps to: Hot, Warm, Cold, Reserve, Governance
 */
const FIBONACCI_RATIOS = Object.freeze({
  hot:        34 / 81,  // ≈ 0.4198
  warm:       21 / 81,  // ≈ 0.2593
  cold:       13 / 81,  // ≈ 0.1605
  reserve:     8 / 81,  // ≈ 0.0988
  governance:  5 / 81,  // ≈ 0.0617
});

/** Pool overflow strategies */
const OVERFLOW = Object.freeze({
  QUEUE:   'queue',   // Buffer the request and serve when capacity frees
  REJECT:  'reject',  // Immediately reject with an error
  STEAL:   'steal',   // Steal capacity from the nearest lower-priority pool
  SPILL:   'spill',   // Overflow into a fallback pool
});

/** Resource lifecycle states */
const RESOURCE_STATE = Object.freeze({
  IDLE:     'idle',
  ACQUIRED: 'acquired',
  DRAINING: 'draining',
});

// ─── ResourcePool ─────────────────────────────────────────────────────────────

/**
 * ResourcePool manages a set of named sub-pools with Fibonacci-proportioned
 * capacity allocation.
 *
 * Features:
 * - **Fibonacci Allocation**: Total capacity is split across pools in Fibonacci
 *   proportions (34/21/13/8/5), matching Heady's priority pool design.
 * - **Dynamic Rebalancing**: When a pool's utilisation is low for an extended
 *   period, its excess capacity is temporarily donated to high-utilisation pools.
 * - **Overflow Handling**: Configurable per-pool overflow strategy (queue, reject,
 *   steal, spill).
 * - **Connection Lifecycle**: Resources are created lazily and tracked through
 *   idle → acquired → draining lifecycle.
 * - **Health Monitoring**: Per-pool utilisation, queue depth, and acquisition
 *   latency are tracked.
 *
 * @extends EventEmitter
 *
 * @fires ResourcePool#resource:acquired
 * @fires ResourcePool#resource:released
 * @fires ResourcePool#pool:overflow
 * @fires ResourcePool#pool:rebalanced
 * @fires ResourcePool#resource:created
 * @fires ResourcePool#resource:destroyed
 */
class ResourcePool extends EventEmitter {
  /**
   * @param {Object}   options
   * @param {number}   options.totalCapacity          - Total resource slots across all pools
   * @param {Function} options.factory                - async() → resource — Creates a resource
   * @param {Function} [options.destroyer]            - async(resource) → void — Destroys a resource
   * @param {Function} [options.validate]             - async(resource) → boolean — Tests if resource is alive
   * @param {Object}   [options.overflowStrategies]   - poolName → OVERFLOW constant
   * @param {number}   [options.rebalanceIntervalMs=30000]
   * @param {number}   [options.acquireTimeoutMs=5000]
   * @param {Function} [options.logger=console]
   */
  constructor(options) {
    super();
    if (!options?.totalCapacity) throw new Error('[ResourcePool] totalCapacity is required');
    if (typeof options.factory !== 'function') throw new Error('[ResourcePool] factory function is required');

    this._totalCapacity     = options.totalCapacity;
    this._factory           = options.factory;
    this._destroyer         = options.destroyer   ?? (async () => {});
    this._validate          = options.validate    ?? (async () => true);
    this._overflowStrategies = options.overflowStrategies ?? {};
    this._rebalanceInterval  = options.rebalanceIntervalMs ?? 30_000;
    this._acquireTimeout     = options.acquireTimeoutMs    ?? 5_000;
    this._logger             = options.logger              ?? console;

    /**
     * Pool definitions: Map<poolName, PoolState>
     * @type {Map<string, PoolState>}
     */
    this._pools = this._initPools();

    /** @type {NodeJS.Timeout|null} */
    this._rebalanceTick = null;

    this._startRebalancing();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Acquires a resource from the named pool.
   *
   * @param {string}  poolName            - 'hot' | 'warm' | 'cold' | 'reserve' | 'governance'
   * @param {Object}  [opts={}]
   * @param {number}  [opts.timeoutMs]    - Acquisition timeout override
   * @returns {Promise<AcquiredResource>}
   * @throws {Error} When pool is full and overflow strategy is REJECT, or timeout expires
   */
  async acquire(poolName, opts = {}) {
    const pool = this._requirePool(poolName);
    const startMs = Date.now();

    // Fast path: idle resource available
    const resource = await this._tryAcquire(pool, opts.timeoutMs ?? this._acquireTimeout);
    const latencyMs = Date.now() - startMs;

    pool.metrics.acquisitions++;
    pool.metrics.totalAcquireMs += latencyMs;

    this.emit('resource:acquired', { poolName, resourceId: resource.id, latencyMs });
    return resource;
  }

  /**
   * Releases a previously acquired resource back to its pool.
   *
   * @param {AcquiredResource} resource
   * @returns {Promise<void>}
   */
  async release(resource) {
    const pool = this._pools.get(resource.poolName);
    if (!pool) return;

    const entry = pool.resources.get(resource.id);
    if (!entry) return;

    // Validate resource before returning to idle
    const alive = await this._validate(entry.raw).catch(() => false);
    if (!alive) {
      await this._destroyResource(pool, entry);
      return;
    }

    entry.state    = RESOURCE_STATE.IDLE;
    entry.acquiredAt = null;
    pool.metrics.releases++;

    // Drain waiting queue
    this._drainQueue(pool);

    this.emit('resource:released', { poolName: resource.poolName, resourceId: resource.id });
  }

  /**
   * Returns a snapshot of all pool statistics.
   * @returns {PoolStats[]}
   */
  getStats() {
    return Array.from(this._pools.entries()).map(([name, pool]) => ({
      name,
      capacity:     pool.capacity,
      allocated:    pool.resources.size,
      idle:         this._countIdle(pool),
      acquired:     this._countAcquired(pool),
      queueDepth:   pool.queue.length,
      utilisation:  +(pool.resources.size > 0
        ? this._countAcquired(pool) / pool.capacity
        : 0).toFixed(4),
      avgAcquireMs: pool.metrics.acquisitions > 0
        ? Math.round(pool.metrics.totalAcquireMs / pool.metrics.acquisitions)
        : 0,
      ...pool.metrics,
    }));
  }

  /**
   * Gracefully drains and destroys all resources in a pool.
   * @param {string} poolName
   * @returns {Promise<void>}
   */
  async drain(poolName) {
    const pool = this._requirePool(poolName);
    for (const entry of pool.resources.values()) {
      entry.state = RESOURCE_STATE.DRAINING;
      await this._destroyResource(pool, entry);
    }
    this._logger.info(`[ResourcePool] Pool "${poolName}" drained`);
  }

  /**
   * Shuts down all pools.
   * @returns {Promise<void>}
   */
  async shutdown() {
    if (this._rebalanceTick) {
      clearInterval(this._rebalanceTick);
      this._rebalanceTick = null;
    }
    for (const name of this._pools.keys()) {
      await this.drain(name).catch(() => {});
    }
    this._logger.info('[ResourcePool] Shutdown complete');
  }

  // ─── Rebalancing ─────────────────────────────────────────────────────────────

  /**
   * Runs dynamic capacity rebalancing.
   * Pools below 30% utilisation donate excess to pools above 90% utilisation.
   */
  rebalance() {
    const stats = this.getStats();
    const donors     = stats.filter(s => s.utilisation < 0.30 && s.capacity > 1);
    const recipients = stats.filter(s => s.utilisation > 0.90);

    if (donors.length === 0 || recipients.length === 0) return;

    for (const donor of donors) {
      const donorPool = this._pools.get(donor.name);
      const transfer  = Math.floor((donor.capacity - Math.ceil(donor.capacity * 0.50)));
      if (transfer <= 0) continue;

      for (const recipient of recipients) {
        const recipPool = this._pools.get(recipient.name);
        donorPool.capacity  -= transfer;
        recipPool.capacity  += transfer;

        this._logger.info(
          `[ResourcePool] Rebalanced: ${transfer} slots from "${donor.name}" → "${recipient.name}"`
        );
        this.emit('pool:rebalanced', {
          from:     donor.name,
          to:       recipient.name,
          transfer,
          timestamp: Date.now(),
        });
        break;
      }
    }
  }

  // ─── Private Helpers ─────────────────────────────────────────────────────────

  /**
   * Initialises pool states from the Fibonacci ratio map.
   * @returns {Map<string, PoolState>}
   */
  _initPools() {
    const map = new Map();
    for (const [name, ratio] of Object.entries(FIBONACCI_RATIOS)) {
      map.set(name, {
        name,
        capacity:   Math.max(1, Math.floor(this._totalCapacity * ratio)),
        resources:  new Map(),
        queue:      [],
        overflow:   this._overflowStrategies[name] ?? OVERFLOW.QUEUE,
        metrics: {
          acquisitions:    0,
          releases:        0,
          overflows:       0,
          totalAcquireMs:  0,
        },
      });
    }
    return map;
  }

  /**
   * Attempts to acquire an idle resource, creating one if capacity allows,
   * or handles overflow.
   *
   * @param {PoolState} pool
   * @param {number}    timeoutMs
   * @returns {Promise<AcquiredResource>}
   */
  async _tryAcquire(pool, timeoutMs) {
    // 1. Find an existing idle resource
    for (const [id, entry] of pool.resources.entries()) {
      if (entry.state === RESOURCE_STATE.IDLE) {
        entry.state      = RESOURCE_STATE.ACQUIRED;
        entry.acquiredAt = Date.now();
        return { id, poolName: pool.name, raw: entry.raw, acquiredAt: entry.acquiredAt };
      }
    }

    // 2. Create a new resource if under capacity
    if (pool.resources.size < pool.capacity) {
      const raw = await this._factory();
      const id  = crypto.randomUUID();
      pool.resources.set(id, { id, raw, state: RESOURCE_STATE.ACQUIRED, acquiredAt: Date.now() });
      this.emit('resource:created', { poolName: pool.name, resourceId: id });
      return { id, poolName: pool.name, raw, acquiredAt: Date.now() };
    }

    // 3. Handle overflow
    return this._handleOverflow(pool, timeoutMs);
  }

  /**
   * Dispatches overflow based on pool's configured strategy.
   * @param {PoolState} pool
   * @param {number}    timeoutMs
   * @returns {Promise<AcquiredResource>}
   */
  async _handleOverflow(pool, timeoutMs) {
    pool.metrics.overflows++;
    this.emit('pool:overflow', { poolName: pool.name, strategy: pool.overflow });

    switch (pool.overflow) {
      case OVERFLOW.REJECT:
        throw new Error(`[ResourcePool] Pool "${pool.name}" is full — request rejected`);

      case OVERFLOW.QUEUE:
        return this._enqueue(pool, timeoutMs);

      case OVERFLOW.STEAL: {
        const stolen = this._stealFromLowerPool(pool);
        if (stolen) return stolen;
        return this._enqueue(pool, timeoutMs);
      }

      case OVERFLOW.SPILL: {
        const fallback = this._findSpillPool(pool);
        if (fallback) return this._tryAcquire(fallback, timeoutMs);
        return this._enqueue(pool, timeoutMs);
      }

      default:
        return this._enqueue(pool, timeoutMs);
    }
  }

  /**
   * Enqueues a waiter and resolves when a resource becomes available.
   * @param {PoolState} pool
   * @param {number}    timeoutMs
   * @returns {Promise<AcquiredResource>}
   */
  _enqueue(pool, timeoutMs) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        const idx = pool.queue.findIndex(w => w.resolve === resolve);
        if (idx !== -1) pool.queue.splice(idx, 1);
        reject(new Error(`[ResourcePool] Acquire timeout after ${timeoutMs}ms for pool "${pool.name}"`));
      }, timeoutMs);

      pool.queue.push({ resolve, reject, timer });
    });
  }

  /**
   * Processes the waiting queue after a resource is released.
   * @param {PoolState} pool
   */
  _drainQueue(pool) {
    if (pool.queue.length === 0) return;

    const waiter = pool.queue.shift();
    if (!waiter) return;
    clearTimeout(waiter.timer);

    // Acquire for the next waiter
    this._tryAcquire(pool, this._acquireTimeout)
      .then(waiter.resolve)
      .catch(waiter.reject);
  }

  /**
   * Attempts to steal a resource from a lower-priority pool.
   * @param {PoolState} callerPool
   * @returns {AcquiredResource|null}
   */
  _stealFromLowerPool(callerPool) {
    const names   = Object.keys(FIBONACCI_RATIOS);
    const callerIdx = names.indexOf(callerPool.name);
    // Steal from the next lower-priority pool
    for (let i = callerIdx + 1; i < names.length; i++) {
      const pool = this._pools.get(names[i]);
      if (!pool) continue;
      for (const [id, entry] of pool.resources.entries()) {
        if (entry.state === RESOURCE_STATE.IDLE) {
          pool.resources.delete(id);
          callerPool.resources.set(id, { ...entry, state: RESOURCE_STATE.ACQUIRED, acquiredAt: Date.now() });
          return { id, poolName: callerPool.name, raw: entry.raw, acquiredAt: Date.now() };
        }
      }
    }
    return null;
  }

  /**
   * Finds the nearest overflow (spill) pool.
   * @param {PoolState} pool
   * @returns {PoolState|null}
   */
  _findSpillPool(pool) {
    const names = Object.keys(FIBONACCI_RATIOS);
    const idx   = names.indexOf(pool.name);
    // Try next lower priority pool first
    for (let i = idx + 1; i < names.length; i++) {
      const fallback = this._pools.get(names[i]);
      if (fallback && fallback.resources.size < fallback.capacity) return fallback;
    }
    return null;
  }

  /**
   * Destroys a resource entry and removes it from the pool.
   * @param {PoolState} pool
   * @param {Object}    entry
   */
  async _destroyResource(pool, entry) {
    await this._destroyer(entry.raw).catch(() => {});
    pool.resources.delete(entry.id);
    this.emit('resource:destroyed', { poolName: pool.name, resourceId: entry.id });
  }

  /**
   * Counts idle resources in a pool.
   * @param {PoolState} pool
   * @returns {number}
   */
  _countIdle(pool) {
    let n = 0;
    for (const e of pool.resources.values()) {
      if (e.state === RESOURCE_STATE.IDLE) n++;
    }
    return n;
  }

  /**
   * Counts acquired resources in a pool.
   * @param {PoolState} pool
   * @returns {number}
   */
  _countAcquired(pool) {
    let n = 0;
    for (const e of pool.resources.values()) {
      if (e.state === RESOURCE_STATE.ACQUIRED) n++;
    }
    return n;
  }

  /**
   * Starts the periodic rebalance tick.
   */
  _startRebalancing() {
    this._rebalanceTick = setInterval(() => this.rebalance(), this._rebalanceInterval);
    if (this._rebalanceTick.unref) this._rebalanceTick.unref();
  }

  /**
   * Retrieves a pool or throws if not found.
   * @param {string} name
   * @returns {PoolState}
   */
  _requirePool(name) {
    const pool = this._pools.get(name);
    if (!pool) throw new Error(`[ResourcePool] Unknown pool: "${name}"`);
    return pool;
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  ResourcePool,
  FIBONACCI_RATIOS,
  OVERFLOW,
  RESOURCE_STATE,
};
