/**
 * ∞ Heady™ CircuitBreaker — Circuit Breaker Pattern
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';

// ─── Constants ───────────────────────────────────────────────────────────────

/** Circuit states */
const STATE = Object.freeze({
  CLOSED:    'CLOSED',     // Normal operation — requests flow through
  OPEN:      'OPEN',       // Failing — requests are rejected immediately
  HALF_OPEN: 'HALF_OPEN',  // Testing — single probe request allowed
});

/** Default configuration values */
const DEFAULTS = Object.freeze({
  failureThreshold:  5,      // Consecutive failures before opening
  successThreshold:  2,      // Consecutive successes in HALF_OPEN before closing
  resetTimeoutMs:    30_000, // Time in OPEN before testing (HALF_OPEN)
  volumeThreshold:   10,     // Minimum requests before statistics are evaluated
  errorRateThreshold: 0.50,  // 50% error rate triggers open (when volume met)
  halfOpenProbeMs:   5_000,  // Timeout for probe request
});

// ─── CircuitBreaker ───────────────────────────────────────────────────────────

/**
 * CircuitBreaker protects downstream services from cascade failures.
 *
 * State machine:
 *   CLOSED → OPEN   (when failureThreshold consecutive failures occur)
 *   OPEN   → HALF_OPEN  (after resetTimeoutMs)
 *   HALF_OPEN → CLOSED  (after successThreshold successes in HALF_OPEN)
 *   HALF_OPEN → OPEN    (on any failure in HALF_OPEN)
 *
 * Multiple named circuits can be created from a single instance via `forService()`.
 *
 * @extends EventEmitter
 *
 * @fires CircuitBreaker#state:change
 * @fires CircuitBreaker#call:rejected
 * @fires CircuitBreaker#call:success
 * @fires CircuitBreaker#call:failure
 *
 * @example
 * const cb = new CircuitBreaker({ failureThreshold: 3, resetTimeoutMs: 15000 });
 * const result = await cb.call('payments-api', () => fetch('/api/charge'));
 */
class CircuitBreaker extends EventEmitter {
  /**
   * @param {Object}   [options={}]
   * @param {number}   [options.failureThreshold=5]    - Consecutive failures before OPEN
   * @param {number}   [options.successThreshold=2]    - Successes in HALF_OPEN before CLOSE
   * @param {number}   [options.resetTimeoutMs=30000]  - OPEN→HALF_OPEN delay
   * @param {number}   [options.volumeThreshold=10]    - Minimum calls for error-rate check
   * @param {number}   [options.errorRateThreshold=0.5] - Error rate to trigger open
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._opts = { ...DEFAULTS, ...options };
    this._logger = options.logger ?? console;

    /**
     * Per-service circuit state map.
     * @type {Map<string, CircuitState>}
     */
    this._circuits = new Map();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Executes `fn` through the circuit breaker for a named service.
   *
   * - If CLOSED: executes fn, records success/failure
   * - If OPEN:   throws CircuitOpenError immediately
   * - If HALF_OPEN: executes a single probe; closes or re-opens based on result
   *
   * @template T
   * @param {string}    serviceName
   * @param {Function}  fn           - async () → T
   * @param {Object}    [opts={}]
   * @param {number}    [opts.timeoutMs]   - Override timeout for this call
   * @returns {Promise<T>}
   * @throws {CircuitOpenError}  When circuit is OPEN
   * @throws {Error}             When fn throws (also recorded as failure)
   */
  async call(serviceName, fn, opts = {}) {
    const circuit = this._getOrCreate(serviceName);
    circuit.totalCalls++;

    // ── OPEN: fast-fail
    if (circuit.state === STATE.OPEN) {
      // Check if it's time to probe
      if (Date.now() >= circuit.nextAttemptAt) {
        this._transition(circuit, STATE.HALF_OPEN);
      } else {
        circuit.rejectedCalls++;
        this.emit('call:rejected', { serviceName, state: circuit.state });
        const err = new CircuitOpenError(serviceName);
        throw err;
      }
    }

    // ── HALF_OPEN: only one probe at a time
    if (circuit.state === STATE.HALF_OPEN && circuit.halfOpenProbeInFlight) {
      circuit.rejectedCalls++;
      this.emit('call:rejected', { serviceName, state: circuit.state });
      throw new CircuitOpenError(serviceName);
    }

    if (circuit.state === STATE.HALF_OPEN) {
      circuit.halfOpenProbeInFlight = true;
    }

    // ── Execute
    try {
      const timeoutMs = opts.timeoutMs ?? this._opts.halfOpenProbeMs;
      const result = await Promise.race([
        fn(),
        this._timeoutReject(timeoutMs, serviceName),
      ]);

      this._recordSuccess(circuit);
      this.emit('call:success', { serviceName, state: circuit.state });
      return result;

    } catch (err) {
      this._recordFailure(circuit, err);
      this.emit('call:failure', { serviceName, state: circuit.state, error: err.message });
      throw err;

    } finally {
      if (circuit.state === STATE.HALF_OPEN) {
        circuit.halfOpenProbeInFlight = false;
      }
    }
  }

  /**
   * Returns a bound executor for a specific service — useful when passing the
   * circuit around without repeating the service name.
   *
   * @param {string} serviceName
   * @returns {{ call: (fn: Function, opts?: Object) => Promise<*>, getState: () => string, reset: () => void }}
   */
  forService(serviceName) {
    return {
      call:     (fn, opts) => this.call(serviceName, fn, opts),
      getState: ()         => this.getState(serviceName),
      getStats: ()         => this.getStats(serviceName),
      reset:    ()         => this.reset(serviceName),
    };
  }

  /**
   * Returns the current state of a named circuit.
   * @param {string} serviceName
   * @returns {string} STATE constant
   */
  getState(serviceName) {
    return this._getOrCreate(serviceName).state;
  }

  /**
   * Manually opens a circuit (e.g. during maintenance).
   * @param {string} serviceName
   */
  open(serviceName) {
    const circuit = this._getOrCreate(serviceName);
    this._transition(circuit, STATE.OPEN);
  }

  /**
   * Manually closes a circuit (resets all counters).
   * @param {string} serviceName
   */
  reset(serviceName) {
    const circuit = this._getOrCreate(serviceName);
    this._resetCounters(circuit);
    this._transition(circuit, STATE.CLOSED);
  }

  /**
   * Returns current statistics for a named circuit.
   * @param {string} serviceName
   * @returns {CircuitStats}
   */
  getStats(serviceName) {
    const c = this._getOrCreate(serviceName);
    const totalDecisive = c.successCalls + c.failureCalls;
    return {
      serviceName,
      state:             c.state,
      totalCalls:        c.totalCalls,
      successCalls:      c.successCalls,
      failureCalls:      c.failureCalls,
      rejectedCalls:     c.rejectedCalls,
      consecutiveFailures: c.consecutiveFailures,
      consecutiveSuccesses: c.consecutiveSuccesses,
      errorRate:         totalDecisive > 0 ? +(c.failureCalls / totalDecisive).toFixed(4) : 0,
      stateTransitions:  c.stateTransitions,
      openDurationMs:    c.state === STATE.OPEN
        ? Date.now() - c.openedAt
        : c.lastOpenDurationMs,
      lastStateChangeAt: c.lastStateChangeAt,
    };
  }

  /**
   * Returns stats for all registered circuits.
   * @returns {CircuitStats[]}
   */
  getAllStats() {
    return Array.from(this._circuits.keys()).map(name => this.getStats(name));
  }

  // ─── Private Helpers ─────────────────────────────────────────────────────────

  /**
   * Records a successful call and potentially closes the circuit.
   * @param {CircuitState} circuit
   */
  _recordSuccess(circuit) {
    circuit.successCalls++;
    circuit.consecutiveFailures = 0;
    circuit.consecutiveSuccesses++;

    if (circuit.state === STATE.HALF_OPEN) {
      if (circuit.consecutiveSuccesses >= this._opts.successThreshold) {
        this._transition(circuit, STATE.CLOSED);
      }
    }
  }

  /**
   * Records a failed call and potentially opens the circuit.
   * @param {CircuitState} circuit
   * @param {Error}        err
   */
  _recordFailure(circuit, err) {
    circuit.failureCalls++;
    circuit.consecutiveFailures++;
    circuit.consecutiveSuccesses = 0;
    circuit.lastError = err?.message ?? String(err);

    if (circuit.state === STATE.HALF_OPEN) {
      // Any failure in HALF_OPEN → immediately re-open
      this._transition(circuit, STATE.OPEN);
      return;
    }

    // Check consecutive failure threshold
    if (circuit.consecutiveFailures >= this._opts.failureThreshold) {
      this._transition(circuit, STATE.OPEN);
      return;
    }

    // Check error rate threshold (only when volume threshold met)
    if (circuit.totalCalls >= this._opts.volumeThreshold) {
      const decisive = circuit.successCalls + circuit.failureCalls;
      const rate = decisive > 0 ? circuit.failureCalls / decisive : 0;
      if (rate >= this._opts.errorRateThreshold) {
        this._transition(circuit, STATE.OPEN);
      }
    }
  }

  /**
   * Transitions a circuit to a new state, recording metrics.
   * @param {CircuitState} circuit
   * @param {string}       newState
   */
  _transition(circuit, newState) {
    const prev = circuit.state;
    if (prev === newState) return;

    // Compute open duration when leaving OPEN
    if (prev === STATE.OPEN && circuit.openedAt) {
      circuit.lastOpenDurationMs = Date.now() - circuit.openedAt;
    }

    circuit.state          = newState;
    circuit.lastStateChangeAt = Date.now();
    circuit.stateTransitions++;

    if (newState === STATE.OPEN) {
      circuit.openedAt      = Date.now();
      circuit.nextAttemptAt = Date.now() + this._opts.resetTimeoutMs;
      // Reset consecutive successes
      circuit.consecutiveSuccesses = 0;
    }

    if (newState === STATE.CLOSED) {
      this._resetCounters(circuit);
    }

    this._logger.info(`[CircuitBreaker] ${circuit.name}: ${prev} → ${newState}`);
    this.emit('state:change', {
      serviceName: circuit.name,
      from:        prev,
      to:          newState,
      timestamp:   Date.now(),
    });
  }

  /**
   * Resets failure/success counters (but not totals).
   * @param {CircuitState} circuit
   */
  _resetCounters(circuit) {
    circuit.consecutiveFailures  = 0;
    circuit.consecutiveSuccesses = 0;
    circuit.openedAt             = null;
    circuit.nextAttemptAt        = null;
    circuit.halfOpenProbeInFlight = false;
  }

  /**
   * Gets or creates the circuit state for a named service.
   * @param {string} name
   * @returns {CircuitState}
   */
  _getOrCreate(name) {
    if (!this._circuits.has(name)) {
      this._circuits.set(name, {
        name,
        state:                STATE.CLOSED,
        totalCalls:           0,
        successCalls:         0,
        failureCalls:         0,
        rejectedCalls:        0,
        consecutiveFailures:  0,
        consecutiveSuccesses: 0,
        stateTransitions:     0,
        lastError:            null,
        openedAt:             null,
        nextAttemptAt:        null,
        lastOpenDurationMs:   0,
        lastStateChangeAt:    Date.now(),
        halfOpenProbeInFlight: false,
      });
    }
    return this._circuits.get(name);
  }

  /**
   * Returns a promise that rejects after `ms` with a timeout error.
   * @param {number} ms
   * @param {string} serviceName
   * @returns {Promise<never>}
   */
  _timeoutReject(ms, serviceName) {
    return new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`[CircuitBreaker] Timeout after ${ms}ms for ${serviceName}`)), ms)
    );
  }
}

// ─── CircuitOpenError ────────────────────────────────────────────────────────

/**
 * Error thrown when a call is rejected because the circuit is OPEN.
 */
class CircuitOpenError extends Error {
  /**
   * @param {string} serviceName
   */
  constructor(serviceName) {
    super(`Circuit OPEN for service: ${serviceName}`);
    this.name        = 'CircuitOpenError';
    this.serviceName = serviceName;
    this.code        = 'CIRCUIT_OPEN';
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  CircuitBreaker,
  CircuitOpenError,
  STATE,
  DEFAULTS,
};
