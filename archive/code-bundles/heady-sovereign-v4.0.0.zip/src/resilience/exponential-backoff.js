/**
 * ∞ Heady™ ExponentialBackoff — Golden Ratio (φ) Backoff Strategy
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';

// ─── Constants ───────────────────────────────────────────────────────────────

/**
 * The golden ratio φ = (1 + √5) / 2 ≈ 1.618033…
 * Used as the base multiplier instead of 2 (standard exponential backoff).
 * This produces a gentler, more natural progression:
 *   attempt 0: base * φ^0 = base
 *   attempt 1: base * φ^1 ≈ base * 1.618
 *   attempt 2: base * φ^2 ≈ base * 2.618
 *   attempt 3: base * φ^3 ≈ base * 4.236
 *   ...
 */
const PHI = (1 + Math.sqrt(5)) / 2; // 1.6180339887…

const DEFAULTS = Object.freeze({
  baseDelayMs:  200,        // Initial delay before first retry
  maxDelayMs:   30_000,     // Hard cap on any single wait
  maxRetries:   7,          // Maximum number of attempts (including initial)
  jitterFactor: 0.20,       // ±20% random jitter on each delay
  multiplier:   PHI,        // Growth multiplier (φ by default)
});

// ─── ExponentialBackoff ───────────────────────────────────────────────────────

/**
 * ExponentialBackoff retries async operations with golden-ratio backoff,
 * jitter, and optional circuit-breaker integration.
 *
 * Delay formula:
 *   rawDelay(attempt) = baseDelayMs * multiplier^attempt
 *   jitter            = rawDelay * jitterFactor * (Math.random() * 2 - 1)
 *   delay(attempt)    = clamp(rawDelay + jitter, 0, maxDelayMs)
 *
 * @extends EventEmitter
 *
 * @fires ExponentialBackoff#retry:attempt
 * @fires ExponentialBackoff#retry:success
 * @fires ExponentialBackoff#retry:exhausted
 * @fires ExponentialBackoff#retry:aborted  (circuit breaker open)
 *
 * @example
 * const backoff = new ExponentialBackoff({ maxRetries: 5, baseDelayMs: 300 });
 * const result = await backoff.run(() => callExternalApi());
 */
class ExponentialBackoff extends EventEmitter {
  /**
   * @param {Object}  [options={}]
   * @param {number}  [options.baseDelayMs=200]     - First delay in ms
   * @param {number}  [options.maxDelayMs=30000]    - Max delay per attempt
   * @param {number}  [options.maxRetries=7]        - Max total attempts
   * @param {number}  [options.jitterFactor=0.20]   - Jitter ±fraction (0–1)
   * @param {number}  [options.multiplier=PHI]      - Growth multiplier (default φ)
   * @param {Object}  [options.circuitBreaker]      - CircuitBreaker-compatible object
   * @param {string}  [options.circuitServiceName]  - Service name for circuit breaker
   * @param {Function} [options.shouldRetry]        - (error, attempt) → boolean
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._opts           = { ...DEFAULTS, ...options };
    this._circuitBreaker = options.circuitBreaker ?? null;
    this._cbService      = options.circuitServiceName ?? 'default';
    this._shouldRetry    = options.shouldRetry ?? (() => true);
    this._logger         = options.logger ?? console;
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Runs `fn` with automatic retry using golden-ratio backoff.
   *
   * @template T
   * @param {Function}  fn             - async () → T — The operation to retry
   * @param {Object}    [ctx={}]       - Arbitrary context passed to events
   * @returns {Promise<T>}
   * @throws {BackoffExhaustedError}   When all retries are consumed
   * @throws {Error}                   Original error if shouldRetry returns false
   */
  async run(fn, ctx = {}) {
    const { maxRetries } = this._opts;
    let lastError;

    for (let attempt = 0; attempt < maxRetries; attempt++) {
      // Check circuit breaker before each attempt
      if (this._circuitBreaker) {
        const state = this._circuitBreaker.getState?.(this._cbService);
        if (state === 'OPEN') {
          const cbErr = new Error(`[ExponentialBackoff] Circuit OPEN for ${this._cbService} — aborting retries`);
          this.emit('retry:aborted', { attempt, reason: 'circuit_open', context: ctx });
          throw cbErr;
        }
      }

      try {
        const result = await fn();
        this.emit('retry:success', { attempt, context: ctx });
        if (attempt > 0) {
          this._logger.info(`[ExponentialBackoff] Succeeded on attempt ${attempt + 1}`);
        }
        return result;

      } catch (err) {
        lastError = err;

        // Check shouldRetry hook
        if (!this._shouldRetry(err, attempt)) {
          this._logger.info(`[ExponentialBackoff] Not retrying: ${err.message}`);
          throw err;
        }

        const isLastAttempt = attempt === maxRetries - 1;
        if (isLastAttempt) break;

        const delayMs = this.computeDelay(attempt);
        this._logger.warn(
          `[ExponentialBackoff] Attempt ${attempt + 1}/${maxRetries} failed: ${err.message} — retrying in ${delayMs}ms`
        );
        this.emit('retry:attempt', { attempt, delayMs, error: err.message, context: ctx });
        await this._sleep(delayMs);
      }
    }

    this.emit('retry:exhausted', { attempts: maxRetries, error: lastError?.message, context: ctx });
    throw new BackoffExhaustedError(maxRetries, lastError);
  }

  /**
   * Computes the retry delay for a given attempt index.
   *
   * @param {number} attempt - Zero-based attempt index (0 = first retry delay)
   * @returns {number} Delay in milliseconds (0 ≤ result ≤ maxDelayMs)
   */
  computeDelay(attempt) {
    const { baseDelayMs, maxDelayMs, multiplier, jitterFactor } = this._opts;
    const raw    = baseDelayMs * Math.pow(multiplier, attempt);
    const jitter = raw * jitterFactor * (Math.random() * 2 - 1);
    return Math.min(maxDelayMs, Math.max(0, Math.round(raw + jitter)));
  }

  /**
   * Returns a pre-computed schedule of delays for informational purposes.
   * @param {number} [attempts] - Number of delays to compute (defaults to maxRetries - 1)
   * @returns {number[]} Array of delay values in ms
   */
  getDelaySchedule(attempts) {
    const n = attempts ?? this._opts.maxRetries - 1;
    // Use deterministic (no jitter) values for the schedule
    return Array.from({ length: n }, (_, i) => {
      const raw = this._opts.baseDelayMs * Math.pow(this._opts.multiplier, i);
      return Math.min(this._opts.maxDelayMs, Math.round(raw));
    });
  }

  /**
   * Wraps a function with backoff, returning a new async function.
   * Useful for creating pre-configured retry wrappers.
   *
   * @template T
   * @param {Function} fn - async (...args) → T
   * @returns {Function} async (...args) → T with backoff applied
   */
  wrap(fn) {
    return (...args) => this.run(() => fn(...args));
  }

  /**
   * Returns current configuration.
   * @returns {Object}
   */
  getConfig() {
    return { ...this._opts, phi: PHI };
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  /**
   * Returns a promise that resolves after `ms` milliseconds.
   * @param {number} ms
   * @returns {Promise<void>}
   */
  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ─── BackoffExhaustedError ────────────────────────────────────────────────────

/**
 * Error thrown when all retry attempts have been consumed.
 */
class BackoffExhaustedError extends Error {
  /**
   * @param {number} attempts  - Total attempts made
   * @param {Error}  lastError - The last underlying error
   */
  constructor(attempts, lastError) {
    super(
      `All ${attempts} retry attempts exhausted. Last error: ${lastError?.message ?? 'unknown'}`
    );
    this.name      = 'BackoffExhaustedError';
    this.attempts  = attempts;
    this.lastError = lastError;
    this.code      = 'BACKOFF_EXHAUSTED';
  }
}

// ─── Factory ─────────────────────────────────────────────────────────────────

/**
 * Convenience factory: creates and immediately runs a backoff sequence.
 *
 * @param {Function} fn
 * @param {Object}   [options={}]
 * @returns {Promise<*>}
 *
 * @example
 * const data = await withBackoff(() => fetch('/api/data'), { maxRetries: 3 });
 */
function withBackoff(fn, options = {}) {
  return new ExponentialBackoff(options).run(fn);
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  ExponentialBackoff,
  BackoffExhaustedError,
  withBackoff,
  PHI,
  DEFAULTS,
};
