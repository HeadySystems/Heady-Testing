/**
 * ∞ Heady™ Cache — Multi-Tier Caching System
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

// ─── Constants ───────────────────────────────────────────────────────────────

/** Default L1 (in-memory LRU) capacity in number of entries */
const DEFAULT_L1_MAX = 1_000;

/** Default L2 (disk) directory */
const DEFAULT_L2_DIR = '/tmp/heady-cache';

/** Default TTL (5 minutes) */
const DEFAULT_TTL_MS = 300_000;

/** Tier constants */
const TIER = Object.freeze({
  L1: 'L1', // In-memory LRU
  L2: 'L2', // Disk-based
  MISS: 'MISS',
});

// ─── HeadyCache ──────────────────────────────────────────────────────────────

/**
 * HeadyCache is a multi-tier cache with:
 *
 * - **L1**: In-memory LRU cache for the fastest access. Bounded by `l1MaxEntries`.
 *   Uses a doubly-linked list + Map for O(1) get/put/eviction.
 * - **L2**: Disk-based cache for larger, less-frequently accessed data.
 *   Serialised as JSON files with TTL and metadata headers.
 * - **TTL**: Per-entry TTL with lazy eviction (checked on access).
 * - **Cache-Aside**: `getOrSet(key, loader, ttl)` for automatic population.
 * - **Statistics**: Hit/miss rates, eviction counts, per-tier breakdowns.
 *
 * @extends EventEmitter
 *
 * @fires HeadyCache#hit     - { key, tier }
 * @fires HeadyCache#miss    - { key }
 * @fires HeadyCache#set     - { key, tier, ttlMs }
 * @fires HeadyCache#evict   - { key, reason } reason: 'lru' | 'ttl'
 * @fires HeadyCache#promote - { key, from, to }
 */
class HeadyCache extends EventEmitter {
  /**
   * @param {Object}   [options={}]
   * @param {number}   [options.l1MaxEntries=1000]    - L1 LRU capacity
   * @param {string}   [options.l2Dir]                - L2 disk directory
   * @param {number}   [options.defaultTtlMs=300000]  - Default TTL in ms
   * @param {boolean}  [options.enableL2=true]        - Enable disk tier
   * @param {boolean}  [options.promotionEnabled=true] - Promote L2 hits to L1
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._l1Max     = options.l1MaxEntries    ?? DEFAULT_L1_MAX;
    this._l2Dir     = options.l2Dir           ?? DEFAULT_L2_DIR;
    this._defaultTtl = options.defaultTtlMs  ?? DEFAULT_TTL_MS;
    this._enableL2  = options.enableL2        !== false;
    this._promote   = options.promotionEnabled !== false;
    this._logger    = options.logger          ?? console;

    // ── L1: Map-backed LRU ──────────────────────────────────────────────────
    /** @type {Map<string, L1Entry>} Ordered Map acts as LRU (move-to-end on access) */
    this._l1  = new Map();

    // ── Stats ───────────────────────────────────────────────────────────────
    this._stats = {
      l1:   { hits: 0, misses: 0, evictions: 0, sets: 0 },
      l2:   { hits: 0, misses: 0, evictions: 0, sets: 0 },
      totalHits:   0,
      totalMisses: 0,
      totalSets:   0,
    };

    if (this._enableL2) {
      this._ensureL2Dir();
    }
  }

  // ─── Core API ────────────────────────────────────────────────────────────────

  /**
   * Retrieves a value from the cache (L1 first, then L2).
   * Returns `undefined` on miss.
   *
   * @param {string} key
   * @returns {Promise<*>}
   */
  async get(key) {
    // L1 lookup
    const l1Entry = this._l1Get(key);
    if (l1Entry !== undefined) {
      this._stats.l1.hits++;
      this._stats.totalHits++;
      this.emit('hit', { key, tier: TIER.L1 });
      return l1Entry;
    }

    // L2 lookup
    if (this._enableL2) {
      const l2Entry = await this._l2Get(key);
      if (l2Entry !== undefined) {
        this._stats.l2.hits++;
        this._stats.totalHits++;
        this.emit('hit', { key, tier: TIER.L2 });

        // Promote to L1
        if (this._promote) {
          this._l1Set(key, l2Entry.value, l2Entry.ttlMs);
          this.emit('promote', { key, from: TIER.L2, to: TIER.L1 });
        }

        return l2Entry.value;
      }
      this._stats.l2.misses++;
    }

    this._stats.l1.misses++;
    this._stats.totalMisses++;
    this.emit('miss', { key });
    return undefined;
  }

  /**
   * Stores a value in both L1 and L2 tiers.
   *
   * @param {string}  key
   * @param {*}       value      - Must be JSON-serialisable for L2
   * @param {number}  [ttlMs]    - TTL override (uses defaultTtlMs if omitted)
   * @returns {Promise<void>}
   */
  async set(key, value, ttlMs) {
    const ttl = ttlMs ?? this._defaultTtl;
    this._l1Set(key, value, ttl);
    if (this._enableL2) {
      await this._l2Set(key, value, ttl);
      this._stats.l2.sets++;
    }
    this._stats.totalSets++;
    this.emit('set', { key, tier: this._enableL2 ? 'L1+L2' : TIER.L1, ttlMs: ttl });
  }

  /**
   * Deletes a key from both tiers.
   * @param {string} key
   * @returns {Promise<void>}
   */
  async delete(key) {
    this._l1.delete(key);
    if (this._enableL2) await this._l2Delete(key);
  }

  /**
   * Cache-aside pattern: get or compute+store.
   *
   * @template T
   * @param {string}   key
   * @param {Function} loader    - async() → T — called on cache miss
   * @param {number}   [ttlMs]   - TTL for the stored value
   * @returns {Promise<T>}
   */
  async getOrSet(key, loader, ttlMs) {
    const cached = await this.get(key);
    if (cached !== undefined) return cached;

    const value = await loader();
    await this.set(key, value, ttlMs);
    return value;
  }

  /**
   * Invalidates all keys matching a prefix.
   * @param {string} prefix
   * @returns {Promise<number>} Number of keys invalidated
   */
  async invalidatePrefix(prefix) {
    let count = 0;

    for (const key of this._l1.keys()) {
      if (key.startsWith(prefix)) {
        this._l1.delete(key);
        count++;
      }
    }

    if (this._enableL2) {
      count += await this._l2InvalidatePrefix(prefix);
    }

    return count;
  }

  /**
   * Evicts all expired entries from L1 (lazy eviction sweep).
   * L2 expiry is handled lazily on access.
   * @returns {number} Number of expired entries evicted
   */
  evictExpired() {
    const now = Date.now();
    let evicted = 0;

    for (const [key, entry] of this._l1.entries()) {
      if (entry.expiresAt && now > entry.expiresAt) {
        this._l1.delete(key);
        this._stats.l1.evictions++;
        evicted++;
        this.emit('evict', { key, reason: 'ttl' });
      }
    }

    return evicted;
  }

  /**
   * Clears all caches.
   * @returns {Promise<void>}
   */
  async clear() {
    this._l1.clear();
    if (this._enableL2) await this._l2Clear();
  }

  /**
   * Returns a snapshot of cache statistics.
   * @returns {CacheStats}
   */
  getStats() {
    const total = this._stats.totalHits + this._stats.totalMisses;
    return {
      ...this._stats,
      l1Size:     this._l1.size,
      l1MaxSize:  this._l1Max,
      hitRate:    total > 0 ? +(this._stats.totalHits / total).toFixed(4)   : 0,
      missRate:   total > 0 ? +(this._stats.totalMisses / total).toFixed(4) : 0,
    };
  }

  // ─── L1: LRU Implementation ───────────────────────────────────────────────────

  /**
   * Gets a value from L1, refreshing its LRU position.
   * Returns `undefined` on miss or TTL expiry.
   *
   * @param {string} key
   * @returns {*|undefined}
   */
  _l1Get(key) {
    const entry = this._l1.get(key);
    if (!entry) return undefined;

    // TTL check (lazy eviction)
    if (entry.expiresAt && Date.now() > entry.expiresAt) {
      this._l1.delete(key);
      this._stats.l1.evictions++;
      this.emit('evict', { key, reason: 'ttl' });
      return undefined;
    }

    // LRU: move to end (most recently used)
    this._l1.delete(key);
    this._l1.set(key, entry);

    return entry.value;
  }

  /**
   * Sets a value in L1, evicting the LRU entry if over capacity.
   *
   * @param {string} key
   * @param {*}      value
   * @param {number} ttlMs
   */
  _l1Set(key, value, ttlMs) {
    // If key already exists, delete to update LRU position
    if (this._l1.has(key)) this._l1.delete(key);

    // Evict LRU (first/oldest) entry if at capacity
    if (this._l1.size >= this._l1Max) {
      const lruKey = this._l1.keys().next().value;
      this._l1.delete(lruKey);
      this._stats.l1.evictions++;
      this.emit('evict', { key: lruKey, reason: 'lru' });
    }

    this._l1.set(key, {
      value,
      expiresAt: ttlMs > 0 ? Date.now() + ttlMs : null,
      ttlMs,
    });
    this._stats.l1.sets++;
  }

  // ─── L2: Disk Implementation ──────────────────────────────────────────────────

  /**
   * Reads a value from the L2 disk cache.
   * @param {string} key
   * @returns {Promise<{value: *, ttlMs: number}|undefined>}
   */
  async _l2Get(key) {
    const filePath = this._l2Path(key);
    try {
      const raw  = fs.readFileSync(filePath, 'utf8');
      const data = JSON.parse(raw);

      // TTL check
      if (data.expiresAt && Date.now() > data.expiresAt) {
        fs.unlinkSync(filePath);
        this._stats.l2.evictions++;
        this.emit('evict', { key, reason: 'ttl' });
        return undefined;
      }

      return { value: data.value, ttlMs: data.ttlMs };
    } catch {
      return undefined;
    }
  }

  /**
   * Writes a value to the L2 disk cache.
   * @param {string} key
   * @param {*}      value
   * @param {number} ttlMs
   * @returns {Promise<void>}
   */
  async _l2Set(key, value, ttlMs) {
    const filePath = this._l2Path(key);
    const data = JSON.stringify({
      key,
      value,
      ttlMs,
      expiresAt: ttlMs > 0 ? Date.now() + ttlMs : null,
      storedAt:  Date.now(),
    });
    try {
      fs.writeFileSync(filePath, data, 'utf8');
    } catch (err) {
      this._logger.warn(`[HeadyCache] L2 write failed for ${key}: ${err.message}`);
    }
  }

  /**
   * Deletes a key from L2.
   * @param {string} key
   * @returns {Promise<void>}
   */
  async _l2Delete(key) {
    const filePath = this._l2Path(key);
    try { fs.unlinkSync(filePath); } catch { /* file may not exist */ }
  }

  /**
   * Invalidates L2 entries matching a key prefix.
   * @param {string} prefix
   * @returns {Promise<number>}
   */
  async _l2InvalidatePrefix(prefix) {
    let count = 0;
    try {
      const files = fs.readdirSync(this._l2Dir);
      for (const file of files) {
        if (file.endsWith('.json')) {
          const filePath = path.join(this._l2Dir, file);
          try {
            const raw  = fs.readFileSync(filePath, 'utf8');
            const data = JSON.parse(raw);
            if (data.key?.startsWith(prefix)) {
              fs.unlinkSync(filePath);
              count++;
            }
          } catch { /* corrupted file */ }
        }
      }
    } catch { /* directory error */ }
    return count;
  }

  /**
   * Clears all L2 cache files.
   * @returns {Promise<void>}
   */
  async _l2Clear() {
    try {
      const files = fs.readdirSync(this._l2Dir);
      for (const file of files) {
        if (file.endsWith('.json')) {
          fs.unlinkSync(path.join(this._l2Dir, file));
        }
      }
    } catch { /* ignore */ }
  }

  /**
   * Computes the L2 file path for a key using a stable hash.
   * @param {string} key
   * @returns {string}
   */
  _l2Path(key) {
    const hash = crypto.createHash('sha256').update(key).digest('hex').slice(0, 32);
    return path.join(this._l2Dir, `${hash}.json`);
  }

  /**
   * Ensures the L2 directory exists.
   */
  _ensureL2Dir() {
    try {
      fs.mkdirSync(this._l2Dir, { recursive: true });
    } catch (err) {
      this._logger.warn(`[HeadyCache] Could not create L2 dir ${this._l2Dir}: ${err.message}`);
    }
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  HeadyCache,
  TIER,
  DEFAULT_L1_MAX,
  DEFAULT_TTL_MS,
};
