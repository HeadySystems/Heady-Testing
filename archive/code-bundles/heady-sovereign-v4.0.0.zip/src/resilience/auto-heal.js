/**
 * ∞ Heady™ AutoHeal — Self-Healing Engine
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';
import crypto from 'crypto';
import { ExponentialBackoff } from './exponential-backoff.js';

// ─── Constants ───────────────────────────────────────────────────────────────

/** Failure classification types */
const FAILURE_TYPE = Object.freeze({
  TRANSIENT:    'transient',     // Likely transient — retry with backoff
  PERSISTENT:   'persistent',   // Service is down — restart
  CATASTROPHIC: 'catastrophic', // Unrecoverable — quarantine + alert
});

/** Healing action types */
const HEAL_ACTION = Object.freeze({
  RETRY:      'retry',
  RESTART:    'restart',
  QUARANTINE: 'quarantine',
  ALERT:      'alert',
  NOOP:       'noop',
});

/** Service health states */
const HEALTH_STATE = Object.freeze({
  HEALTHY:     'healthy',
  DEGRADED:    'degraded',
  FAILING:     'failing',
  QUARANTINED: 'quarantined',
});

/** Default healing configuration */
const DEFAULTS = Object.freeze({
  healthCheckIntervalMs:  10_000,  // How often to run checks
  transientThreshold:     3,       // Failures before reclassifying as persistent
  persistentThreshold:    6,       // Failures before reclassifying as catastrophic
  cooldownMs:             60_000,  // Minimum time between heal attempts for same service
  maxHealHistory:         100,     // Max heal events to retain per service
  patternWindowMs:        300_000, // Rolling window for pattern detection (5 min)
});

// ─── AutoHeal ────────────────────────────────────────────────────────────────

/**
 * AutoHeal is the self-healing engine for HeadySystems.
 *
 * It continuously health-checks registered services and applies the
 * appropriate healing strategy based on the failure classification:
 *
 * | Failure Type | Strategy                                        |
 * |--------------|--------------------------------------------------|
 * | Transient    | Retry with φ-backoff                            |
 * | Persistent   | Restart the service via `restarter` function    |
 * | Catastrophic | Quarantine service + emit alert to HeadySoul    |
 *
 * Pattern detection prevents heal loops by enforcing cooldowns and
 * detecting when a service oscillates between FAILING and DEGRADED.
 *
 * @extends EventEmitter
 *
 * @fires AutoHeal#service:registered
 * @fires AutoHeal#health:checked
 * @fires AutoHeal#failure:detected
 * @fires AutoHeal#heal:started
 * @fires AutoHeal#heal:completed
 * @fires AutoHeal#heal:failed
 * @fires AutoHeal#service:quarantined
 * @fires AutoHeal#alert:headsoul
 * @fires AutoHeal#pattern:detected
 */
class AutoHeal extends EventEmitter {
  /**
   * @param {Object}   [options={}]
   * @param {number}   [options.healthCheckIntervalMs=10000]
   * @param {number}   [options.transientThreshold=3]
   * @param {number}   [options.persistentThreshold=6]
   * @param {number}   [options.cooldownMs=60000]
   * @param {Function} [options.onAlert]    - async(ctx) — HeadySoul alert handler
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._opts     = { ...DEFAULTS, ...options };
    this._onAlert  = options.onAlert ?? null;
    this._logger   = options.logger  ?? console;

    /**
     * Registered services: Map<serviceId, ServiceRecord>
     * @type {Map<string, ServiceRecord>}
     */
    this._services = new Map();

    /** @type {NodeJS.Timeout|null} */
    this._checkInterval = null;

    /** @type {boolean} */
    this._running = false;
  }

  // ─── Lifecycle ───────────────────────────────────────────────────────────────

  /**
   * Starts the automatic health check loop.
   */
  start() {
    if (this._running) return;
    this._running = true;
    this._checkInterval = setInterval(
      () => this._runHealthChecks(),
      this._opts.healthCheckIntervalMs
    );
    if (this._checkInterval.unref) this._checkInterval.unref();
    this._logger.info('[AutoHeal] Health check loop started');
  }

  /**
   * Stops the automatic health check loop.
   */
  stop() {
    if (!this._running) return;
    this._running = false;
    if (this._checkInterval) {
      clearInterval(this._checkInterval);
      this._checkInterval = null;
    }
    this._logger.info('[AutoHeal] Health check loop stopped');
  }

  // ─── Service Registration ─────────────────────────────────────────────────────

  /**
   * Registers a service for monitoring and self-healing.
   *
   * @param {string}   serviceId
   * @param {Object}   descriptor
   * @param {Function} descriptor.healthCheck  - async() → { healthy: boolean, detail?: string }
   * @param {Function} [descriptor.restart]    - async() → void — restart action
   * @param {Object}   [descriptor.meta={}]    - Arbitrary metadata
   * @returns {ServiceRecord}
   */
  registerService(serviceId, descriptor) {
    if (this._services.has(serviceId)) {
      this._logger.warn(`[AutoHeal] Service already registered: ${serviceId}`);
      return this._services.get(serviceId);
    }

    /** @type {ServiceRecord} */
    const record = {
      serviceId,
      healthCheck:   descriptor.healthCheck,
      restart:       descriptor.restart ?? null,
      meta:          descriptor.meta ?? {},
      state:         HEALTH_STATE.HEALTHY,
      failureCount:  0,
      failureType:   null,
      healHistory:   [],
      lastCheckAt:   null,
      lastHealAt:    null,
      quarantinedAt: null,
    };

    this._services.set(serviceId, record);
    this.emit('service:registered', { serviceId });
    this._logger.info(`[AutoHeal] Service registered: ${serviceId}`);
    return record;
  }

  /**
   * Deregisters a service.
   * @param {string} serviceId
   */
  deregisterService(serviceId) {
    this._services.delete(serviceId);
    this._logger.info(`[AutoHeal] Service deregistered: ${serviceId}`);
  }

  /**
   * Unquarantines a service and resets its failure count.
   * @param {string} serviceId
   */
  unquarantine(serviceId) {
    const svc = this._requireService(serviceId);
    svc.state         = HEALTH_STATE.HEALTHY;
    svc.failureCount  = 0;
    svc.failureType   = null;
    svc.quarantinedAt = null;
    this._logger.info(`[AutoHeal] Service unquarantined: ${serviceId}`);
  }

  // ─── Manual Trigger ───────────────────────────────────────────────────────────

  /**
   * Manually triggers a health check for a specific service.
   * @param {string} serviceId
   * @returns {Promise<HealthCheckResult>}
   */
  async checkService(serviceId) {
    const svc = this._requireService(serviceId);
    return this._checkOne(svc);
  }

  /**
   * Runs all health checks immediately (one-shot, outside the interval).
   * @returns {Promise<HealthCheckResult[]>}
   */
  async checkAll() {
    return this._runHealthChecks();
  }

  // ─── Status ───────────────────────────────────────────────────────────────────

  /**
   * Returns the current status of all registered services.
   * @returns {Array<ServiceStatus>}
   */
  getStatus() {
    return Array.from(this._services.values()).map(svc => ({
      serviceId:     svc.serviceId,
      state:         svc.state,
      failureCount:  svc.failureCount,
      failureType:   svc.failureType,
      lastCheckAt:   svc.lastCheckAt,
      lastHealAt:    svc.lastHealAt,
      quarantinedAt: svc.quarantinedAt,
      healCount:     svc.healHistory.length,
      meta:          svc.meta,
    }));
  }

  /**
   * Returns the full heal history for a service.
   * @param {string} serviceId
   * @returns {HealEvent[]}
   */
  getHealHistory(serviceId) {
    return this._requireService(serviceId).healHistory;
  }

  // ─── Core Loop ────────────────────────────────────────────────────────────────

  /**
   * Runs health checks across all registered (non-quarantined) services.
   * @returns {Promise<HealthCheckResult[]>}
   */
  async _runHealthChecks() {
    const results = [];
    for (const svc of this._services.values()) {
      if (svc.state === HEALTH_STATE.QUARANTINED) continue;
      const result = await this._checkOne(svc).catch(err => ({
        serviceId: svc.serviceId,
        healthy:   false,
        error:     err.message,
      }));
      results.push(result);
    }
    return results;
  }

  /**
   * Checks a single service and dispatches healing if needed.
   * @param {ServiceRecord} svc
   * @returns {Promise<HealthCheckResult>}
   */
  async _checkOne(svc) {
    const checkId = crypto.randomUUID();
    let checkResult;

    try {
      checkResult = await svc.healthCheck();
    } catch (err) {
      checkResult = { healthy: false, detail: err.message };
    }

    svc.lastCheckAt = Date.now();
    this.emit('health:checked', {
      checkId,
      serviceId: svc.serviceId,
      healthy:   checkResult.healthy,
      detail:    checkResult.detail,
    });

    const result = { serviceId: svc.serviceId, checkId, ...checkResult };

    if (checkResult.healthy) {
      this._onHealthy(svc);
    } else {
      await this._onUnhealthy(svc, checkResult);
    }

    return result;
  }

  // ─── Health Transitions ───────────────────────────────────────────────────────

  /**
   * Handles a passing health check — resets counters if recovering.
   * @param {ServiceRecord} svc
   */
  _onHealthy(svc) {
    if (svc.failureCount > 0) {
      this._logger.info(`[AutoHeal] Service ${svc.serviceId} recovered`);
    }
    svc.failureCount = 0;
    svc.failureType  = null;
    svc.state        = HEALTH_STATE.HEALTHY;
  }

  /**
   * Handles a failing health check — classifies failure and applies strategy.
   * @param {ServiceRecord} svc
   * @param {Object}        checkResult
   * @returns {Promise<void>}
   */
  async _onUnhealthy(svc, checkResult) {
    svc.failureCount++;

    // Classify failure
    const failureType = this._classifyFailure(svc);
    svc.failureType   = failureType;
    svc.state         = HEALTH_STATE.FAILING;

    this.emit('failure:detected', {
      serviceId:   svc.serviceId,
      failureType,
      failureCount: svc.failureCount,
      detail:      checkResult.detail,
    });

    // Cooldown guard — don't heal too frequently
    if (svc.lastHealAt && Date.now() - svc.lastHealAt < this._opts.cooldownMs) {
      this._logger.info(`[AutoHeal] ${svc.serviceId} in cooldown — skipping heal`);
      this._detectPattern(svc);
      return;
    }

    await this._applyStrategy(svc, failureType);
  }

  // ─── Classification ───────────────────────────────────────────────────────────

  /**
   * Classifies the current failure based on failure count.
   * @param {ServiceRecord} svc
   * @returns {string} FAILURE_TYPE constant
   */
  _classifyFailure(svc) {
    if (svc.failureCount >= this._opts.persistentThreshold) return FAILURE_TYPE.CATASTROPHIC;
    if (svc.failureCount >= this._opts.transientThreshold)  return FAILURE_TYPE.PERSISTENT;
    return FAILURE_TYPE.TRANSIENT;
  }

  // ─── Healing Strategies ──────────────────────────────────────────────────────

  /**
   * Dispatches the appropriate healing strategy.
   * @param {ServiceRecord} svc
   * @param {string}        failureType
   * @returns {Promise<void>}
   */
  async _applyStrategy(svc, failureType) {
    const healId = crypto.randomUUID();
    const event  = {
      healId,
      serviceId:   svc.serviceId,
      failureType,
      action:      null,
      success:     false,
      startedAt:   Date.now(),
      completedAt: null,
      error:       null,
    };

    this.emit('heal:started', event);
    svc.lastHealAt = Date.now();

    try {
      switch (failureType) {
        case FAILURE_TYPE.TRANSIENT:
          event.action = HEAL_ACTION.RETRY;
          await this._strategyRetry(svc);
          break;

        case FAILURE_TYPE.PERSISTENT:
          event.action = HEAL_ACTION.RESTART;
          await this._strategyRestart(svc);
          break;

        case FAILURE_TYPE.CATASTROPHIC:
          event.action = HEAL_ACTION.QUARANTINE;
          await this._strategyCatastrophic(svc);
          break;

        default:
          event.action = HEAL_ACTION.NOOP;
      }

      event.success = true;

    } catch (err) {
      event.error = err.message;
      this._logger.error(`[AutoHeal] Heal failed for ${svc.serviceId}: ${err.message}`);
      this.emit('heal:failed', event);
    } finally {
      event.completedAt = Date.now();
      this._recordHealEvent(svc, event);
      if (event.success) this.emit('heal:completed', event);
    }
  }

  /**
   * Strategy: TRANSIENT — retry health check with φ-backoff.
   * @param {ServiceRecord} svc
   */
  async _strategyRetry(svc) {
    const backoff = new ExponentialBackoff({ maxRetries: 3, baseDelayMs: 200 });
    await backoff.run(() => svc.healthCheck().then(r => {
      if (!r.healthy) throw new Error(`Still unhealthy: ${r.detail ?? ''}`);
    }));
    this._onHealthy(svc);
    this._logger.info(`[AutoHeal] ${svc.serviceId} recovered via retry`);
  }

  /**
   * Strategy: PERSISTENT — restart the service.
   * @param {ServiceRecord} svc
   */
  async _strategyRestart(svc) {
    if (typeof svc.restart !== 'function') {
      this._logger.warn(`[AutoHeal] No restart function for ${svc.serviceId} — escalating`);
      await this._alertHeadySoul(svc, 'No restart function registered');
      return;
    }

    this._logger.info(`[AutoHeal] Restarting service: ${svc.serviceId}`);
    await svc.restart();
    svc.failureCount = 0;
    svc.state        = HEALTH_STATE.DEGRADED; // Watch for recovery
  }

  /**
   * Strategy: CATASTROPHIC — quarantine and alert HeadySoul.
   * @param {ServiceRecord} svc
   */
  async _strategyCatastrophic(svc) {
    svc.state         = HEALTH_STATE.QUARANTINED;
    svc.quarantinedAt = Date.now();

    this._logger.error(`[AutoHeal] *** QUARANTINING *** service: ${svc.serviceId}`);
    this.emit('service:quarantined', {
      serviceId:   svc.serviceId,
      failureCount: svc.failureCount,
      timestamp:   Date.now(),
    });

    await this._alertHeadySoul(svc, `Catastrophic failure after ${svc.failureCount} attempts`);
  }

  // ─── Pattern Detection ────────────────────────────────────────────────────────

  /**
   * Detects healing loops: if a service has had >3 heal events in the pattern
   * window, emit a pattern:detected event.
   * @param {ServiceRecord} svc
   */
  _detectPattern(svc) {
    const window  = this._opts.patternWindowMs;
    const cutoff  = Date.now() - window;
    const recent  = svc.healHistory.filter(e => e.startedAt >= cutoff);

    if (recent.length >= 3) {
      this._logger.warn(
        `[AutoHeal] Heal loop pattern detected for ${svc.serviceId}: ${recent.length} events in ${window}ms`
      );
      this.emit('pattern:detected', {
        serviceId:    svc.serviceId,
        eventCount:   recent.length,
        windowMs:     window,
        timestamp:    Date.now(),
      });
    }
  }

  // ─── Alerting ─────────────────────────────────────────────────────────────────

  /**
   * Alerts HeadySoul about a catastrophic service failure.
   * @param {ServiceRecord} svc
   * @param {string}        reason
   * @returns {Promise<void>}
   */
  async _alertHeadySoul(svc, reason) {
    const alertCtx = {
      serviceId:    svc.serviceId,
      reason,
      failureCount: svc.failureCount,
      failureType:  svc.failureType,
      state:        svc.state,
      timestamp:    Date.now(),
    };

    this.emit('alert:headsoul', alertCtx);

    if (typeof this._onAlert === 'function') {
      await this._onAlert(alertCtx).catch(err =>
        this._logger.error(`[AutoHeal] Alert callback failed: ${err.message}`)
      );
    }
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  /**
   * Appends a heal event to the service's history, trimming to max.
   * @param {ServiceRecord} svc
   * @param {Object}        event
   */
  _recordHealEvent(svc, event) {
    svc.healHistory.push(event);
    if (svc.healHistory.length > this._opts.maxHealHistory) {
      svc.healHistory.splice(0, svc.healHistory.length - this._opts.maxHealHistory);
    }
  }

  /**
   * Retrieves a service record or throws if not found.
   * @param {string} serviceId
   * @returns {ServiceRecord}
   */
  _requireService(serviceId) {
    const svc = this._services.get(serviceId);
    if (!svc) throw new Error(`[AutoHeal] Unknown service: ${serviceId}`);
    return svc;
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  AutoHeal,
  FAILURE_TYPE,
  HEAL_ACTION,
  HEALTH_STATE,
  DEFAULTS,
};
