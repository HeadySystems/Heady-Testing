/**
 * ∞ Heady™ BuddyCore — AI Companion Core
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';
import crypto from 'crypto';

// ─── Constants ───────────────────────────────────────────────────────────────

/** Maximum conversation turns stored in session context */
const MAX_SESSION_TURNS = 200;

/** Maximum long-term memory entries per user */
const MAX_LONG_TERM_MEMORIES = 500;

/** Modalities supported by the companion */
const MODALITIES = Object.freeze({
  TEXT:  'text',
  VOICE: 'voice',
  CODE:  'code',
  IMAGE: 'image',
});

/** Personality tones */
const TONE = Object.freeze({
  PROFESSIONAL: 'professional',
  CASUAL:       'casual',
  TECHNICAL:    'technical',
  CREATIVE:     'creative',
  SUPPORTIVE:   'supportive',
});

/** Session states */
const SESSION_STATE = Object.freeze({
  ACTIVE:   'active',
  IDLE:     'idle',
  PAUSED:   'paused',
  ENDED:    'ended',
});

// ─── BuddyCore ────────────────────────────────────────────────────────────────

/**
 * BuddyCore is the AI companion system for HeadySystems.
 *
 * It provides:
 * - **Persistent Conversation Context**: Full turn history per session with
 *   configurable retention and summarization triggers.
 * - **Memory Integration**: Long-term memory store per user with semantic
 *   recall of relevant past interactions.
 * - **Personality Layer**: Tone, style, and preference settings that shape
 *   response generation across all modalities.
 * - **Multi-Modal Support**: Handles text, voice (audio transcript), code
 *   blocks, and image descriptions in a unified turn structure.
 * - **Session Management**: Creates, resumes, and ends sessions with full
 *   state persistence.
 * - **Proactive Suggestions**: Analyzes user patterns to surface timely
 *   suggestions before they're asked.
 *
 * @extends EventEmitter
 *
 * @fires BuddyCore#session:created
 * @fires BuddyCore#session:resumed
 * @fires BuddyCore#session:ended
 * @fires BuddyCore#turn:added
 * @fires BuddyCore#memory:stored
 * @fires BuddyCore#memory:recalled
 * @fires BuddyCore#suggestion:generated
 * @fires BuddyCore#personality:updated
 */
class BuddyCore extends EventEmitter {
  /**
   * @param {Object}   [options={}]
   * @param {Function} [options.llm]               - async(messages, opts) → {text} — LLM inference fn
   * @param {Function} [options.embedder]          - async(text) → number[] — embedding function
   * @param {Object}   [options.defaultPersonality] - Initial personality config
   * @param {number}   [options.idleTimeoutMs=300000] - Session idle before auto-pause
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._llm        = options.llm      ?? this._stubLLM.bind(this);
    this._embedder   = options.embedder ?? this._stubEmbedder.bind(this);
    this._logger     = options.logger   ?? console;
    this._idleTimeout = options.idleTimeoutMs ?? 300_000;

    /**
     * Sessions: Map<sessionId, BuddySession>
     * @type {Map<string, BuddySession>}
     */
    this._sessions = new Map();

    /**
     * Long-term memory per user: Map<userId, MemoryEntry[]>
     * @type {Map<string, MemoryEntry[]>}
     */
    this._memory = new Map();

    /**
     * Per-user interaction patterns for proactive suggestions.
     * Map<userId, { topicCounts: Map<string, number>, lastActive: number }>
     * @type {Map<string, UserPattern>}
     */
    this._patterns = new Map();

    /**
     * Per-user personality config.
     * Map<userId, PersonalityConfig>
     * @type {Map<string, PersonalityConfig>}
     */
    this._personalities = new Map();

    /** @type {Map<string, NodeJS.Timeout>} Idle timers per session */
    this._idleTimers = new Map();
  }

  // ─── Session Management ──────────────────────────────────────────────────────

  /**
   * Creates a new companion session for a user.
   *
   * @param {Object}  params
   * @param {string}  params.userId
   * @param {string}  [params.modality=MODALITIES.TEXT]
   * @param {Object}  [params.meta={}]
   * @returns {BuddySession}
   */
  createSession({ userId, modality = MODALITIES.TEXT, meta = {} }) {
    const sessionId = crypto.randomUUID();

    /** @type {BuddySession} */
    const session = {
      sessionId,
      userId,
      modality,
      state:     SESSION_STATE.ACTIVE,
      turns:     [],
      summary:   null,
      meta,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    this._sessions.set(sessionId, session);
    this._resetIdleTimer(sessionId);
    this.emit('session:created', { sessionId, userId, modality });
    return session;
  }

  /**
   * Resumes a previously created session.
   * @param {string} sessionId
   * @returns {BuddySession}
   */
  resumeSession(sessionId) {
    const session = this._requireSession(sessionId);
    if (session.state === SESSION_STATE.ENDED) {
      throw new Error(`[BuddyCore] Cannot resume ended session ${sessionId}`);
    }
    session.state     = SESSION_STATE.ACTIVE;
    session.updatedAt = Date.now();
    this._resetIdleTimer(sessionId);
    this.emit('session:resumed', { sessionId, userId: session.userId });
    return session;
  }

  /**
   * Ends a session, flushing any unprocessed context to long-term memory.
   * @param {string} sessionId
   * @param {Object} [opts={}]
   * @param {boolean} [opts.extractMemories=true] - Whether to extract memories before ending
   * @returns {Promise<void>}
   */
  async endSession(sessionId, opts = {}) {
    const session = this._requireSession(sessionId);
    const shouldExtract = opts.extractMemories !== false;

    if (shouldExtract && session.turns.length > 0) {
      await this._extractMemoriesFromSession(session);
    }

    session.state     = SESSION_STATE.ENDED;
    session.updatedAt = Date.now();
    this._clearIdleTimer(sessionId);
    this.emit('session:ended', { sessionId, userId: session.userId, turns: session.turns.length });
  }

  /**
   * Returns a session by ID.
   * @param {string} sessionId
   * @returns {BuddySession|undefined}
   */
  getSession(sessionId) {
    return this._sessions.get(sessionId);
  }

  /**
   * Lists all active sessions for a user.
   * @param {string} userId
   * @returns {BuddySession[]}
   */
  getUserSessions(userId) {
    return Array.from(this._sessions.values())
      .filter(s => s.userId === userId && s.state !== SESSION_STATE.ENDED);
  }

  // ─── Turn Management ─────────────────────────────────────────────────────────

  /**
   * Processes a user turn, returns the companion's response.
   *
   * Flow:
   * 1. Record user turn
   * 2. Recall relevant memories
   * 3. Build message list (personality system prompt + context + history)
   * 4. Call LLM
   * 5. Record assistant turn
   * 6. Update patterns
   *
   * @param {string}  sessionId
   * @param {Object}  userInput
   * @param {string}  userInput.content    - The user's message content
   * @param {string}  [userInput.modality] - Override session modality for this turn
   * @param {Object}  [userInput.meta={}]
   * @returns {Promise<CompanionResponse>}
   */
  async chat(sessionId, userInput) {
    const session = this._requireSession(sessionId);
    if (session.state !== SESSION_STATE.ACTIVE) {
      throw new Error(`[BuddyCore] Session ${sessionId} is not active (state: ${session.state})`);
    }

    const modality = userInput.modality ?? session.modality;
    const startMs  = Date.now();

    // 1. Record user turn
    this._addTurn(session, { role: 'user', content: userInput.content, modality, meta: userInput.meta });

    // 2. Recall relevant memories
    const memories = await this._recallRelevant(session.userId, userInput.content, 5);

    // 3. Build messages for LLM
    const messages = this._buildMessages(session, memories);

    // 4. Call LLM
    const llmResponse = await this._llm(messages, {
      userId:    session.userId,
      sessionId,
      modality,
    });

    const responseText = llmResponse?.text ?? llmResponse?.content ?? String(llmResponse ?? '');

    // 5. Record assistant turn
    this._addTurn(session, { role: 'assistant', content: responseText, modality });

    // 6. Update patterns
    this._updatePattern(session.userId, userInput.content);

    // 7. Reset idle timer
    session.updatedAt = Date.now();
    this._resetIdleTimer(sessionId);

    const response = {
      sessionId,
      turnIndex: session.turns.length - 1,
      content:   responseText,
      modality,
      memories:  memories.map(m => m.summary),
      latencyMs: Date.now() - startMs,
      timestamp: Date.now(),
    };

    this.emit('turn:added', { sessionId, role: 'assistant', latencyMs: response.latencyMs });
    return response;
  }

  // ─── Memory ───────────────────────────────────────────────────────────────────

  /**
   * Stores a memory entry for a user.
   *
   * @param {string}  userId
   * @param {Object}  entry
   * @param {string}  entry.summary     - Short human-readable summary
   * @param {string}  [entry.content]   - Full content
   * @param {string[]} [entry.tags=[]]  - Topic tags
   * @param {number}  [entry.importance=0.5] - Importance score (0–1)
   * @returns {Promise<MemoryEntry>}
   */
  async storeMemory(userId, entry) {
    const memories = this._getUserMemory(userId);

    const embedding = await this._embedder(entry.summary ?? entry.content ?? '').catch(() => []);

    /** @type {MemoryEntry} */
    const record = {
      memoryId:   crypto.randomUUID(),
      userId,
      summary:    entry.summary ?? '',
      content:    entry.content ?? entry.summary ?? '',
      tags:       entry.tags ?? [],
      importance: Math.min(1, Math.max(0, entry.importance ?? 0.5)),
      embedding,
      createdAt:  Date.now(),
      accessCount: 0,
    };

    memories.push(record);

    // Evict oldest low-importance memories if over cap
    if (memories.length > MAX_LONG_TERM_MEMORIES) {
      memories.sort((a, b) => (b.importance - a.importance) || (b.accessCount - a.accessCount));
      memories.splice(MAX_LONG_TERM_MEMORIES);
    }

    this.emit('memory:stored', { userId, memoryId: record.memoryId, summary: record.summary });
    return record;
  }

  /**
   * Recalls memories relevant to a query using cosine similarity on embeddings.
   * Falls back to keyword matching when embeddings are unavailable.
   *
   * @param {string} userId
   * @param {string} query
   * @param {number} [topK=5]
   * @returns {Promise<MemoryEntry[]>}
   */
  async recallMemories(userId, query, topK = 5) {
    return this._recallRelevant(userId, query, topK);
  }

  /**
   * Returns all memories for a user.
   * @param {string} userId
   * @returns {MemoryEntry[]}
   */
  listMemories(userId) {
    return this._getUserMemory(userId);
  }

  // ─── Personality ─────────────────────────────────────────────────────────────

  /**
   * Gets or initialises the personality config for a user.
   * @param {string} userId
   * @returns {PersonalityConfig}
   */
  getPersonality(userId) {
    if (!this._personalities.has(userId)) {
      this._personalities.set(userId, this._defaultPersonality());
    }
    return this._personalities.get(userId);
  }

  /**
   * Updates personality configuration for a user.
   *
   * @param {string}          userId
   * @param {Partial<PersonalityConfig>} updates
   * @returns {PersonalityConfig}
   */
  updatePersonality(userId, updates) {
    const current = this.getPersonality(userId);
    const merged  = { ...current, ...updates, updatedAt: Date.now() };
    this._personalities.set(userId, merged);
    this.emit('personality:updated', { userId, updates });
    return merged;
  }

  // ─── Proactive Suggestions ───────────────────────────────────────────────────

  /**
   * Generates proactive suggestions based on user patterns and recent activity.
   *
   * @param {string} userId
   * @returns {Promise<string[]>} Array of suggestion strings
   */
  async generateSuggestions(userId) {
    const pattern = this._patterns.get(userId);
    if (!pattern) return [];

    // Find top topics
    const topTopics = Array.from(pattern.topicCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([topic]) => topic);

    if (topTopics.length === 0) return [];

    const suggestions = topTopics.map(topic =>
      `Would you like to continue working on: ${topic}?`
    );

    this.emit('suggestion:generated', { userId, suggestions });
    return suggestions;
  }

  // ─── Private Helpers ─────────────────────────────────────────────────────────

  /**
   * Builds the LLM message array from session context + memories.
   * @param {BuddySession} session
   * @param {MemoryEntry[]} memories
   * @returns {Array<{role: string, content: string}>}
   */
  _buildMessages(session, memories) {
    const personality = this.getPersonality(session.userId);
    const systemPrompt = this._buildSystemPrompt(personality, memories);

    const messages = [{ role: 'system', content: systemPrompt }];

    // Include last N turns to stay within context budget
    const recentTurns = session.turns.slice(-50);
    for (const turn of recentTurns) {
      messages.push({ role: turn.role, content: turn.content });
    }

    return messages;
  }

  /**
   * Builds the system prompt from personality config and recalled memories.
   * @param {PersonalityConfig} personality
   * @param {MemoryEntry[]}     memories
   * @returns {string}
   */
  _buildSystemPrompt(personality, memories) {
    const lines = [
      `You are Heady™, an AI companion by HeadySystems™.`,
      `Tone: ${personality.tone}. Style: ${personality.style}.`,
    ];

    if (personality.userName) {
      lines.push(`You are speaking with ${personality.userName}.`);
    }

    if (personality.preferences?.length > 0) {
      lines.push(`User preferences: ${personality.preferences.join(', ')}.`);
    }

    if (memories.length > 0) {
      lines.push('\nRelevant past context:');
      for (const m of memories) {
        lines.push(`- ${m.summary}`);
      }
    }

    return lines.join('\n');
  }

  /**
   * Appends a turn to the session, trimming oldest if over capacity.
   * @param {BuddySession} session
   * @param {Object}       turn
   */
  _addTurn(session, turn) {
    session.turns.push({
      role:      turn.role,
      content:   turn.content,
      modality:  turn.modality,
      meta:      turn.meta ?? {},
      timestamp: Date.now(),
    });

    if (session.turns.length > MAX_SESSION_TURNS) {
      session.turns.splice(0, session.turns.length - MAX_SESSION_TURNS);
    }
  }

  /**
   * Recalls memories relevant to a query using cosine similarity.
   * @param {string} userId
   * @param {string} query
   * @param {number} topK
   * @returns {Promise<MemoryEntry[]>}
   */
  async _recallRelevant(userId, query, topK) {
    const memories = this._getUserMemory(userId);
    if (memories.length === 0) return [];

    const queryEmbed = await this._embedder(query).catch(() => null);

    let scored;
    if (queryEmbed && queryEmbed.length > 0) {
      scored = memories.map(m => ({
        memory: m,
        score:  m.embedding?.length > 0 ? this._cosineSim(queryEmbed, m.embedding) : 0,
      }));
    } else {
      // Keyword fallback
      const terms = query.toLowerCase().split(/\s+/);
      scored = memories.map(m => ({
        memory: m,
        score:  terms.filter(t => m.summary.toLowerCase().includes(t)).length,
      }));
    }

    const results = scored
      .filter(({ score }) => score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
      .map(({ memory }) => {
        memory.accessCount++;
        return memory;
      });

    if (results.length > 0) {
      this.emit('memory:recalled', { userId, query, count: results.length });
    }

    return results;
  }

  /**
   * Extracts memorable facts from a session's turns and stores them.
   * @param {BuddySession} session
   * @returns {Promise<void>}
   */
  async _extractMemoriesFromSession(session) {
    // Heuristic: store the last user message as a memory if meaningful
    const userTurns = session.turns.filter(t => t.role === 'user');
    for (const turn of userTurns.slice(-5)) {
      if (turn.content && turn.content.length > 20) {
        await this.storeMemory(session.userId, {
          summary:    turn.content.slice(0, 200),
          content:    turn.content,
          importance: 0.4,
        }).catch(() => {});
      }
    }
  }

  /**
   * Updates the interaction pattern for a user based on a message.
   * @param {string} userId
   * @param {string} content
   */
  _updatePattern(userId, content) {
    if (!this._patterns.has(userId)) {
      this._patterns.set(userId, { topicCounts: new Map(), lastActive: Date.now() });
    }
    const pattern = this._patterns.get(userId);
    pattern.lastActive = Date.now();

    // Simple topic extraction: significant words (len > 4)
    const words = content.toLowerCase().split(/\W+/).filter(w => w.length > 4);
    for (const word of words) {
      pattern.topicCounts.set(word, (pattern.topicCounts.get(word) ?? 0) + 1);
    }
  }

  /**
   * Gets or creates the memory array for a user.
   * @param {string} userId
   * @returns {MemoryEntry[]}
   */
  _getUserMemory(userId) {
    if (!this._memory.has(userId)) this._memory.set(userId, []);
    return this._memory.get(userId);
  }

  /**
   * Default personality configuration.
   * @returns {PersonalityConfig}
   */
  _defaultPersonality() {
    return {
      tone:        TONE.PROFESSIONAL,
      style:       'concise and helpful',
      userName:    null,
      preferences: [],
      createdAt:   Date.now(),
      updatedAt:   Date.now(),
    };
  }

  /**
   * Resets the idle timer for a session.
   * @param {string} sessionId
   */
  _resetIdleTimer(sessionId) {
    this._clearIdleTimer(sessionId);
    const timer = setTimeout(() => {
      const session = this._sessions.get(sessionId);
      if (session && session.state === SESSION_STATE.ACTIVE) {
        session.state = SESSION_STATE.IDLE;
        this._logger.info(`[BuddyCore] Session ${sessionId} went idle`);
      }
    }, this._idleTimeout);
    if (timer.unref) timer.unref();
    this._idleTimers.set(sessionId, timer);
  }

  /**
   * Clears the idle timer for a session.
   * @param {string} sessionId
   */
  _clearIdleTimer(sessionId) {
    if (this._idleTimers.has(sessionId)) {
      clearTimeout(this._idleTimers.get(sessionId));
      this._idleTimers.delete(sessionId);
    }
  }

  /**
   * Retrieves a session or throws if not found.
   * @param {string} sessionId
   * @returns {BuddySession}
   */
  _requireSession(sessionId) {
    const session = this._sessions.get(sessionId);
    if (!session) throw new Error(`[BuddyCore] Session not found: ${sessionId}`);
    return session;
  }

  /**
   * Computes cosine similarity between two numeric vectors.
   * @param {number[]} a
   * @param {number[]} b
   * @returns {number} 0–1
   */
  _cosineSim(a, b) {
    const len = Math.min(a.length, b.length);
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < len; i++) {
      dot   += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    const denom = Math.sqrt(normA) * Math.sqrt(normB);
    return denom === 0 ? 0 : dot / denom;
  }

  // ─── Stubs ───────────────────────────────────────────────────────────────────

  /**
   * Stub LLM — echoes the last user message. Replace with real inference.
   * @param {Array} messages
   * @returns {Promise<{text: string}>}
   */
  async _stubLLM(messages) {
    const last = messages.filter(m => m.role === 'user').pop();
    return { text: `[BuddyCore stub] Received: "${last?.content ?? ''}"` };
  }

  /**
   * Stub embedder — returns a deterministic pseudo-embedding.
   * @param {string} text
   * @returns {Promise<number[]>}
   */
  async _stubEmbedder(text) {
    const vec = new Array(8).fill(0);
    for (let i = 0; i < text.length; i++) {
      vec[i % 8] += text.charCodeAt(i) / 1000;
    }
    return vec;
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  BuddyCore,
  MODALITIES,
  TONE,
  SESSION_STATE,
  MAX_SESSION_TURNS,
  MAX_LONG_TERM_MEMORIES,
};
