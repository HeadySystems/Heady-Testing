/**
 * ∞ Heady™ HeavyConductor — Central Task Routing and Dispatch
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';
import crypto from 'crypto';

// ─── Constants ───────────────────────────────────────────────────────────────

/** Task domains supported by the conductor */
const DOMAINS = Object.freeze({
  CODE:         'code',
  SECURITY:     'security',
  ARCHITECTURE: 'architecture',
  RESEARCH:     'research',
  CREATIVE:     'creative',
  MONITORING:   'monitoring',
  CLEANUP:      'cleanup',
  ANALYTICS:    'analytics',
  MAINTENANCE:  'maintenance',
});

/** Priority pools with Fibonacci-inspired allocation ratios */
const POOLS = Object.freeze({
  HOT:        { name: 'hot',        ratio: 0.34, timeoutMs: 30_000 },
  WARM:       { name: 'warm',       ratio: 0.21, timeoutMs: 300_000 },
  COLD:       { name: 'cold',       ratio: 0.13, timeoutMs: 1_800_000 },
  RESERVE:    { name: 'reserve',    ratio: 0.08, timeoutMs: 600_000 },
  GOVERNANCE: { name: 'governance', ratio: 0.05, timeoutMs: 120_000 },
});

/** Task lifecycle states */
const TASK_STATE = Object.freeze({
  RECEIVED:   'received',
  CLASSIFIED: 'classified',
  ROUTED:     'routed',
  EXECUTING:  'executing',
  COMPLETED:  'completed',
  FAILED:     'failed',
  TIMED_OUT:  'timed_out',
});

/** Domain → pool mapping (default assignment) */
const DOMAIN_POOL_MAP = Object.freeze({
  [DOMAINS.SECURITY]:     POOLS.HOT,
  [DOMAINS.MONITORING]:   POOLS.HOT,
  [DOMAINS.CODE]:         POOLS.WARM,
  [DOMAINS.ARCHITECTURE]: POOLS.WARM,
  [DOMAINS.RESEARCH]:     POOLS.COLD,
  [DOMAINS.ANALYTICS]:    POOLS.COLD,
  [DOMAINS.CREATIVE]:     POOLS.WARM,
  [DOMAINS.CLEANUP]:      POOLS.RESERVE,
  [DOMAINS.MAINTENANCE]:  POOLS.GOVERNANCE,
});

/** Keyword signatures used for domain classification */
const DOMAIN_SIGNATURES = Object.freeze({
  [DOMAINS.CODE]:         /\b(code|function|class|bug|lint|refactor|test|deploy|build|compile|debug|script|api|module|package)\b/i,
  [DOMAINS.SECURITY]:     /\b(security|auth|vulnerability|exploit|cve|xss|injection|token|cert|tls|ssl|pentest|audit|threat)\b/i,
  [DOMAINS.ARCHITECTURE]: /\b(architect|design|pattern|system|infra|topology|schema|model|diagram|spec|blueprint|service mesh)\b/i,
  [DOMAINS.RESEARCH]:     /\b(research|analyze|investigate|study|survey|explore|discover|hypothesis|evaluate|benchmark)\b/i,
  [DOMAINS.CREATIVE]:     /\b(write|draft|create|generate|compose|brainstorm|design|brand|copy|content|story|narrative)\b/i,
  [DOMAINS.MONITORING]:   /\b(monitor|alert|metric|health|status|uptime|latency|trace|log|observe|dashboard|probe)\b/i,
  [DOMAINS.CLEANUP]:      /\b(clean|purge|delete|remove|archive|gc|garbage|sweep|prune|evict|trim|clear)\b/i,
  [DOMAINS.ANALYTICS]:    /\b(analytic|report|insight|trend|forecast|predict|stat|chart|visuali|kpi|dashboard|data)\b/i,
  [DOMAINS.MAINTENANCE]:  /\b(maintain|update|patch|upgrade|migrate|rotate|backup|restore|sync|reconcile|housekeep)\b/i,
});

// ─── Task Record ─────────────────────────────────────────────────────────────

/**
 * Represents a single task managed by the conductor.
 * @typedef {Object} ConductorTask
 * @property {string}   id          - Unique task identifier (UUIDv4)
 * @property {string}   domain      - Classified domain
 * @property {Object}   pool        - Assigned priority pool descriptor
 * @property {string}   state       - Current lifecycle state
 * @property {number}   priority    - Numeric priority (0 = highest)
 * @property {string}   nodeId      - Assigned node identifier
 * @property {Object}   payload     - Task-specific data
 * @property {number}   createdAt   - Unix timestamp (ms) of creation
 * @property {number}   startedAt   - Unix timestamp (ms) when execution began
 * @property {number}   completedAt - Unix timestamp (ms) when finished
 * @property {number}   attempts    - Retry count
 * @property {Error}    error       - Last error if failed
 * @property {*}        result      - Task result when completed
 */

// ─── Conductor Class ──────────────────────────────────────────────────────────

/**
 * HeavyConductor — Central task routing, dispatch, and lifecycle manager.
 *
 * Emits lifecycle events for every state transition so observers (monitoring,
 * autobiographer, HeadySoul) can react without coupling.
 *
 * @extends EventEmitter
 *
 * @fires HeavyConductor#task:received
 * @fires HeavyConductor#task:classified
 * @fires HeavyConductor#task:routed
 * @fires HeavyConductor#task:executing
 * @fires HeavyConductor#task:completed
 * @fires HeavyConductor#task:failed
 * @fires HeavyConductor#task:timeout
 *
 * @example
 * const conductor = new HeavyConductor({ nodes: myNodeRegistry });
 * conductor.on('task:completed', ({ task }) => console.log('Done:', task.id));
 * const result = await conductor.dispatch({ payload: { text: 'fix bug in auth' } });
 */
class HeavyConductor extends EventEmitter {
  /**
   * @param {Object}   options
   * @param {Object}   [options.nodes={}]            - Registry: nodeId → { domain[], execute(task) }
   * @param {number}   [options.maxRetries=3]         - Max retry attempts before marking failed
   * @param {boolean}  [options.enableMetrics=true]   - Collect latency and routing metrics
   * @param {Function} [options.logger=console]       - Logger interface { info, warn, error }
   */
  constructor(options = {}) {
    super();
    this._nodes       = options.nodes       ?? {};
    this._maxRetries  = options.maxRetries  ?? 3;
    this._logger      = options.logger      ?? console;
    this._enableMetrics = options.enableMetrics !== false;

    /** @type {Map<string, ConductorTask>} Active and recent tasks */
    this._tasks = new Map();

    /** @type {Map<string, NodeJS.Timeout>} Task timeout handles */
    this._timeouts = new Map();

    /** @type {ConductorMetrics} Rolling metrics store */
    this._metrics = this._initMetrics();

    this._logger.info('[HeavyConductor] Initialized');
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Dispatches a task through the full classification → routing → execution lifecycle.
   *
   * @param {Object}  options
   * @param {Object}  options.payload            - Task data (must have at least `text` or `type`)
   * @param {number}  [options.priority=50]      - Caller-supplied urgency hint (0–100)
   * @param {string}  [options.forceDomain]      - Skip classification, use this domain
   * @param {string}  [options.forcePool]        - Skip pool assignment, use this pool key
   * @param {string}  [options.forceNodeId]      - Skip routing, use this node
   * @param {Object}  [options.meta={}]          - Arbitrary metadata attached to the task
   * @returns {Promise<*>} Resolved with the task result on success
   */
  async dispatch(options = {}) {
    const { payload, priority = 50, forceDomain, forcePool, forceNodeId, meta = {} } = options;

    // 1. Create task record
    const task = this._createTask({ payload, priority, meta });
    this._tasks.set(task.id, task);
    this._emit('task:received', task);

    try {
      // 2. Classify
      const domain = forceDomain ?? this._classify(task);
      this._transition(task, TASK_STATE.CLASSIFIED, { domain });
      this._emit('task:classified', task);

      // 3. Assign pool
      const pool = forcePool
        ? Object.values(POOLS).find(p => p.name === forcePool) ?? POOLS.WARM
        : this._assignPool(task);
      task.pool = pool;

      // 4. Route to node
      const nodeId = forceNodeId ?? this._route(task);
      task.nodeId = nodeId;
      this._transition(task, TASK_STATE.ROUTED);
      this._emit('task:routed', task);

      // 5. Execute with timeout + retry
      const result = await this._executeWithRetry(task);
      this._transition(task, TASK_STATE.COMPLETED, { result, completedAt: Date.now() });
      this._emit('task:completed', task);
      this._recordMetric(task, 'success');
      return result;

    } catch (err) {
      this._transition(task, TASK_STATE.FAILED, { error: err, completedAt: Date.now() });
      this._emit('task:failed', task);
      this._recordMetric(task, 'failure');
      throw err;
    } finally {
      this._clearTimeout(task.id);
    }
  }

  /**
   * Returns a snapshot of the current metrics.
   * @returns {ConductorMetrics}
   */
  getMetrics() {
    const snapshot = { ...this._metrics };
    // Compute derived averages
    for (const poolName of Object.keys(snapshot.avgLatencyMs)) {
      const { total, count } = this._metrics._latencyAccum[poolName] ?? { total: 0, count: 0 };
      snapshot.avgLatencyMs[poolName] = count > 0 ? Math.round(total / count) : 0;
    }
    return snapshot;
  }

  /**
   * Returns task record by ID (or undefined if not found).
   * @param {string} taskId
   * @returns {ConductorTask|undefined}
   */
  getTask(taskId) {
    return this._tasks.get(taskId);
  }

  /**
   * Lists tasks filtered by state.
   * @param {string} [state] - If omitted, returns all tasks
   * @returns {ConductorTask[]}
   */
  listTasks(state) {
    const all = Array.from(this._tasks.values());
    return state ? all.filter(t => t.state === state) : all;
  }

  /**
   * Registers a node with the conductor.
   * @param {string}   nodeId
   * @param {Object}   descriptor
   * @param {string[]} descriptor.domains  - Domains this node handles
   * @param {Function} descriptor.execute  - async execute(task) → result
   * @param {number}   [descriptor.weight=1] - Load-balancing weight
   */
  registerNode(nodeId, descriptor) {
    this._nodes[nodeId] = { weight: 1, ...descriptor };
    this._logger.info(`[HeavyConductor] Node registered: ${nodeId}`);
  }

  /**
   * Deregisters a node, cancelling any running tasks assigned to it.
   * @param {string} nodeId
   */
  deregisterNode(nodeId) {
    delete this._nodes[nodeId];
    this._logger.info(`[HeavyConductor] Node deregistered: ${nodeId}`);
  }

  // ─── Classification ──────────────────────────────────────────────────────────

  /**
   * Classifies a task into a domain using keyword signature matching.
   * Falls back to RESEARCH when no signature matches.
   *
   * @param {ConductorTask} task
   * @returns {string} Domain constant
   */
  _classify(task) {
    const text = this._extractText(task.payload);
    const scores = {};

    for (const [domain, regex] of Object.entries(DOMAIN_SIGNATURES)) {
      const matches = (text.match(regex) ?? []).length;
      if (matches > 0) scores[domain] = matches;
    }

    if (Object.keys(scores).length === 0) return DOMAINS.RESEARCH;

    return Object.entries(scores)
      .sort((a, b) => b[1] - a[1])[0][0];
  }

  /**
   * Extracts searchable text from a task payload.
   * @param {Object} payload
   * @returns {string}
   */
  _extractText(payload) {
    if (!payload) return '';
    if (typeof payload === 'string') return payload;
    const parts = [];
    if (payload.text)        parts.push(payload.text);
    if (payload.type)        parts.push(payload.type);
    if (payload.description) parts.push(payload.description);
    if (payload.title)       parts.push(payload.title);
    if (payload.query)       parts.push(payload.query);
    return parts.join(' ');
  }

  // ─── Pool Assignment ─────────────────────────────────────────────────────────

  /**
   * Assigns a task to a priority pool based on its domain and caller priority.
   * High-priority tasks (0–20) always land in HOT regardless of domain.
   *
   * @param {ConductorTask} task
   * @returns {Object} Pool descriptor
   */
  _assignPool(task) {
    if (task.priority <= 20) return POOLS.HOT;
    if (task.priority >= 80) return POOLS.COLD;
    return DOMAIN_POOL_MAP[task.domain] ?? POOLS.WARM;
  }

  // ─── Routing ─────────────────────────────────────────────────────────────────

  /**
   * Routes a task to the optimal node using skill-matching + weighted selection.
   * Falls back to any available node if no domain-specialist exists.
   *
   * @param {ConductorTask} task
   * @returns {string} nodeId
   * @throws {Error} When no nodes are available at all
   */
  _route(task) {
    const specialists = Object.entries(this._nodes)
      .filter(([, n]) => n.domains?.includes(task.domain));

    const pool = specialists.length > 0
      ? specialists
      : Object.entries(this._nodes);

    if (pool.length === 0) {
      throw new Error(`[HeavyConductor] No nodes available for domain: ${task.domain}`);
    }

    // Weighted random selection
    const totalWeight = pool.reduce((s, [, n]) => s + (n.weight ?? 1), 0);
    let rnd = Math.random() * totalWeight;
    for (const [nodeId, n] of pool) {
      rnd -= (n.weight ?? 1);
      if (rnd <= 0) return nodeId;
    }
    return pool[pool.length - 1][0];
  }

  // ─── Execution ───────────────────────────────────────────────────────────────

  /**
   * Executes a task with retry and timeout logic.
   * On each failure, attempts fallback routing before retrying.
   *
   * @param {ConductorTask} task
   * @returns {Promise<*>}
   */
  async _executeWithRetry(task) {
    let lastErr;

    for (let attempt = 0; attempt < this._maxRetries; attempt++) {
      task.attempts = attempt + 1;

      // Re-route on retry (except first attempt)
      if (attempt > 0) {
        try {
          task.nodeId = this._route(task);
        } catch (_) { /* no fallback nodes */ }
      }

      try {
        this._transition(task, TASK_STATE.EXECUTING, { startedAt: Date.now() });
        this._emit('task:executing', task);
        this._armTimeout(task);

        const node = this._nodes[task.nodeId];
        if (!node || typeof node.execute !== 'function') {
          throw new Error(`[HeavyConductor] Node ${task.nodeId} has no execute() method`);
        }

        const result = await node.execute(task);
        return result;

      } catch (err) {
        lastErr = err;
        this._clearTimeout(task.id);
        this._logger.warn(
          `[HeavyConductor] Task ${task.id} attempt ${attempt + 1} failed: ${err.message}`
        );
        if (attempt < this._maxRetries - 1) {
          await this._sleep(200 * (attempt + 1)); // Linear back-off between retries
        }
      }
    }

    throw lastErr;
  }

  // ─── Timeout Management ──────────────────────────────────────────────────────

  /**
   * Arms a timeout for the task based on its pool's timeout configuration.
   * @param {ConductorTask} task
   */
  _armTimeout(task) {
    this._clearTimeout(task.id);
    const ms = task.pool?.timeoutMs ?? 60_000;
    const handle = setTimeout(() => {
      this._transition(task, TASK_STATE.TIMED_OUT, { completedAt: Date.now() });
      this.emit('task:timeout', { task });
      this._logger.warn(`[HeavyConductor] Task ${task.id} timed out after ${ms}ms`);
    }, ms);
    this._timeouts.set(task.id, handle);
  }

  /**
   * Clears the timeout for a task.
   * @param {string} taskId
   */
  _clearTimeout(taskId) {
    if (this._timeouts.has(taskId)) {
      clearTimeout(this._timeouts.get(taskId));
      this._timeouts.delete(taskId);
    }
  }

  // ─── State Machine ───────────────────────────────────────────────────────────

  /**
   * Transitions a task to a new state, merging optional extra fields.
   * @param {ConductorTask} task
   * @param {string}        newState
   * @param {Object}        [extra={}]
   */
  _transition(task, newState, extra = {}) {
    task.state = newState;
    Object.assign(task, extra);
  }

  // ─── Event Emission ──────────────────────────────────────────────────────────

  /**
   * Emits a namespaced lifecycle event with the task payload.
   * @param {string}        eventName
   * @param {ConductorTask} task
   */
  _emit(eventName, task) {
    this.emit(eventName, { task, timestamp: Date.now() });
  }

  // ─── Metrics ─────────────────────────────────────────────────────────────────

  /**
   * Initialises a blank metrics object.
   * @returns {ConductorMetrics}
   */
  _initMetrics() {
    const perPool = {};
    const latency = {};
    for (const p of Object.values(POOLS)) {
      perPool[p.name] = { routed: 0, success: 0, failure: 0 };
      latency[p.name] = { total: 0, count: 0 };
    }
    return {
      tasksRouted:     0,
      tasksSucceeded:  0,
      tasksFailed:     0,
      avgLatencyMs:    Object.fromEntries(Object.values(POOLS).map(p => [p.name, 0])),
      successRate:     0,
      byPool:          perPool,
      _latencyAccum:   latency,
    };
  }

  /**
   * Records a task outcome into the metrics store.
   * @param {ConductorTask} task
   * @param {'success'|'failure'} outcome
   */
  _recordMetric(task, outcome) {
    if (!this._enableMetrics) return;
    const poolName = task.pool?.name ?? 'warm';
    this._metrics.tasksRouted++;
    this._metrics.byPool[poolName].routed++;

    if (outcome === 'success') {
      this._metrics.tasksSucceeded++;
      this._metrics.byPool[poolName].success++;
    } else {
      this._metrics.tasksFailed++;
      this._metrics.byPool[poolName].failure++;
    }

    // Latency
    if (task.startedAt && task.completedAt) {
      const latencyMs = task.completedAt - task.startedAt;
      this._metrics._latencyAccum[poolName].total += latencyMs;
      this._metrics._latencyAccum[poolName].count++;
    }

    // Derived success rate
    this._metrics.successRate = this._metrics.tasksRouted > 0
      ? +(this._metrics.tasksSucceeded / this._metrics.tasksRouted).toFixed(4)
      : 0;
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  /**
   * Creates a blank task record.
   * @param {Object} opts
   * @returns {ConductorTask}
   */
  _createTask({ payload, priority, meta }) {
    return {
      id:          crypto.randomUUID(),
      domain:      null,
      pool:        null,
      state:       TASK_STATE.RECEIVED,
      priority:    Math.min(100, Math.max(0, priority ?? 50)),
      nodeId:      null,
      payload:     payload ?? {},
      meta:        meta ?? {},
      createdAt:   Date.now(),
      startedAt:   null,
      completedAt: null,
      attempts:    0,
      error:       null,
      result:      null,
    };
  }

  /**
   * Returns a promise that resolves after `ms` milliseconds.
   * @param {number} ms
   * @returns {Promise<void>}
   */
  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  HeavyConductor,
  DOMAINS,
  POOLS,
  TASK_STATE,
  DOMAIN_POOL_MAP,
};
