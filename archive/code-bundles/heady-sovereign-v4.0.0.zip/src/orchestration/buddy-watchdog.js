/**
 * ∞ Heady™ BuddyWatchdog — Companion Health Monitor
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';

// ─── Constants ───────────────────────────────────────────────────────────────

/** Cosine similarity threshold below which a response is flagged as incoherent */
const COHERENCE_THRESHOLD = 0.30;

/** Quality score below which escalation is triggered */
const QUALITY_ESCALATION_THRESHOLD = 0.40;

/** Latency (ms) above which a slow-response alert fires */
const LATENCY_ALERT_MS = 5_000;

/** Maximum hallucination score (0–1) before escalation */
const HALLUCINATION_THRESHOLD = 0.60;

/** Sliding window size for quality metrics */
const WINDOW_SIZE = 50;

// ─── BuddyWatchdog ────────────────────────────────────────────────────────────

/**
 * BuddyWatchdog monitors companion response quality, coherence, and latency.
 *
 * It provides:
 * - **Hallucination Detection**: Embeds consecutive responses and checks that
 *   their cosine similarity stays within plausible range. Abrupt semantic
 *   shifts in flat conversation contexts are flagged as potential hallucinations.
 * - **Response Quality Scoring**: Scores each response on length appropriateness,
 *   relevance to the prompt, and vocabulary consistency.
 * - **Latency Monitoring**: Tracks per-interaction latency and fires alerts
 *   when response time exceeds the threshold.
 * - **Conversation Coherence**: Maintains a rolling coherence score across the
 *   session turn window.
 * - **Automatic Escalation**: Escalates to the HeadySoul governance layer when
 *   quality degrades below threshold.
 *
 * @extends EventEmitter
 *
 * @fires BuddyWatchdog#hallucination:detected
 * @fires BuddyWatchdog#quality:degraded
 * @fires BuddyWatchdog#quality:recovered
 * @fires BuddyWatchdog#latency:high
 * @fires BuddyWatchdog#coherence:low
 * @fires BuddyWatchdog#escalation:triggered
 */
class BuddyWatchdog extends EventEmitter {
  /**
   * @param {Object}   [options={}]
   * @param {Function} [options.embedder]           - async(text) → number[] — for hallucination detection
   * @param {Function} [options.onEscalate]         - async(ctx) → void — called on quality escalation
   * @param {number}   [options.coherenceThreshold=0.30]
   * @param {number}   [options.qualityThreshold=0.40]
   * @param {number}   [options.latencyAlertMs=5000]
   * @param {number}   [options.hallucinationThreshold=0.60]
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._embedder            = options.embedder            ?? this._stubEmbedder.bind(this);
    this._onEscalate          = options.onEscalate          ?? null;
    this._coherenceThreshold  = options.coherenceThreshold  ?? COHERENCE_THRESHOLD;
    this._qualityThreshold    = options.qualityThreshold    ?? QUALITY_ESCALATION_THRESHOLD;
    this._latencyAlertMs      = options.latencyAlertMs      ?? LATENCY_ALERT_MS;
    this._hallucinationThresh = options.hallucinationThreshold ?? HALLUCINATION_THRESHOLD;
    this._logger              = options.logger              ?? console;

    /**
     * Per-session state: Map<sessionId, SessionHealth>
     * @type {Map<string, SessionHealth>}
     */
    this._sessions = new Map();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Evaluates a companion response and updates session health state.
   * This should be called after every assistant turn.
   *
   * @param {Object}  params
   * @param {string}  params.sessionId
   * @param {string}  params.userId
   * @param {string}  params.prompt       - The user's original message
   * @param {string}  params.response     - The assistant's response
   * @param {number}  params.latencyMs    - Round-trip latency in ms
   * @returns {Promise<EvaluationResult>}
   */
  async evaluate({ sessionId, userId, prompt, response, latencyMs }) {
    const health = this._getOrCreateHealth(sessionId, userId);
    const startMs = Date.now();

    // Run all checks in parallel
    const [qualityScore, hallucinationScore, coherenceScore] = await Promise.all([
      this._scoreQuality(prompt, response),
      this._detectHallucination(health, response),
      this._checkCoherence(health, response),
    ]);

    // Record latency
    health.latencies.push(latencyMs);
    if (health.latencies.length > WINDOW_SIZE) health.latencies.shift();

    // Record scores
    health.qualityScores.push(qualityScore);
    if (health.qualityScores.length > WINDOW_SIZE) health.qualityScores.shift();

    // Update rolling averages
    health.avgQuality    = this._avg(health.qualityScores);
    health.avgLatencyMs  = this._avg(health.latencies);
    health.lastEvalAt    = Date.now();

    const result = {
      sessionId,
      userId,
      qualityScore,
      hallucinationScore,
      coherenceScore,
      latencyMs,
      avgQuality:   health.avgQuality,
      avgLatencyMs: health.avgLatencyMs,
      evaluatedAt:  Date.now(),
      flags:        [],
    };

    // ── Latency alert
    if (latencyMs > this._latencyAlertMs) {
      result.flags.push('HIGH_LATENCY');
      this.emit('latency:high', { sessionId, latencyMs, threshold: this._latencyAlertMs });
    }

    // ── Hallucination alert
    if (hallucinationScore >= this._hallucinationThresh) {
      result.flags.push('HALLUCINATION');
      this._logger.warn(`[BuddyWatchdog] Hallucination detected in session ${sessionId} (score: ${hallucinationScore.toFixed(3)})`);
      this.emit('hallucination:detected', { sessionId, userId, score: hallucinationScore, response });
    }

    // ── Coherence alert
    if (coherenceScore < this._coherenceThreshold) {
      result.flags.push('LOW_COHERENCE');
      this.emit('coherence:low', { sessionId, coherenceScore, threshold: this._coherenceThreshold });
    }

    // ── Quality degradation
    if (health.avgQuality < this._qualityThreshold && health.qualityScores.length >= 5) {
      result.flags.push('QUALITY_DEGRADED');
      if (!health.escalated) {
        health.escalated = true;
        await this._escalate({ sessionId, userId, result, health });
      }
      this.emit('quality:degraded', { sessionId, avgQuality: health.avgQuality });
    } else if (health.escalated && health.avgQuality >= this._qualityThreshold * 1.2) {
      // Recovery hysteresis: need 20% above threshold before resetting
      health.escalated = false;
      this.emit('quality:recovered', { sessionId, avgQuality: health.avgQuality });
    }

    // Update last response embedding for next hallucination check
    health.lastResponseEmbed = await this._embedder(response).catch(() => null);

    return result;
  }

  /**
   * Returns the current health state for a session.
   * @param {string} sessionId
   * @returns {SessionHealth|undefined}
   */
  getHealth(sessionId) {
    return this._sessions.get(sessionId);
  }

  /**
   * Returns a summary health report for a session.
   * @param {string} sessionId
   * @returns {HealthReport}
   */
  getReport(sessionId) {
    const h = this._sessions.get(sessionId);
    if (!h) return null;

    return {
      sessionId,
      userId:         h.userId,
      turnCount:      h.turnCount,
      avgQuality:     +h.avgQuality.toFixed(3),
      avgLatencyMs:   +h.avgLatencyMs.toFixed(1),
      escalated:      h.escalated,
      escalationCount: h.escalationCount,
      createdAt:      h.createdAt,
      lastEvalAt:     h.lastEvalAt,
      status:         this._overallStatus(h),
    };
  }

  /**
   * Resets a session's health record.
   * @param {string} sessionId
   */
  resetSession(sessionId) {
    this._sessions.delete(sessionId);
  }

  // ─── Quality Scoring ─────────────────────────────────────────────────────────

  /**
   * Scores response quality on a 0–1 scale.
   *
   * Factors:
   * - Length appropriateness (non-zero, not empty, not excessively long)
   * - Lexical overlap with prompt (relevance signal)
   * - Absence of obvious refusal/error patterns
   *
   * @param {string} prompt
   * @param {string} response
   * @returns {Promise<number>} 0–1
   */
  async _scoreQuality(prompt, response) {
    if (!response || response.trim().length === 0) return 0;

    let score = 0;

    // 1. Length score: penalise very short (<10 chars) or very long (>4000 chars)
    const len = response.trim().length;
    if (len >= 10 && len <= 4000) score += 0.35;
    else if (len > 4000) score += 0.20;
    else score += 0.05;

    // 2. Relevance: lexical overlap between prompt and response
    const promptWords    = new Set(prompt.toLowerCase().split(/\W+/).filter(w => w.length > 3));
    const responseWords  = response.toLowerCase().split(/\W+/).filter(w => w.length > 3);
    const overlap        = responseWords.filter(w => promptWords.has(w)).length;
    const relevanceScore = promptWords.size > 0 ? Math.min(1, overlap / promptWords.size) : 0.5;
    score += relevanceScore * 0.35;

    // 3. Penalise known failure patterns
    const refusalPatterns = /I (cannot|can't|am unable|don't know|apologize)|Error:|undefined|null|NaN|\[object Object\]/i;
    if (!refusalPatterns.test(response)) score += 0.30;

    return Math.min(1, Math.max(0, score));
  }

  // ─── Hallucination Detection ──────────────────────────────────────────────────

  /**
   * Detects potential hallucination via embedding consistency.
   * A sudden semantic shift (low cosine similarity to previous response) in
   * a context that doesn't warrant it is treated as a hallucination signal.
   *
   * Returns a hallucination score 0–1 (higher = more suspicious).
   *
   * @param {SessionHealth} health
   * @param {string}        response
   * @returns {Promise<number>}
   */
  async _detectHallucination(health, response) {
    health.turnCount++;

    // Can't detect on first turn — no prior embedding
    if (!health.lastResponseEmbed || health.lastResponseEmbed.length === 0) return 0;

    const currentEmbed = await this._embedder(response).catch(() => null);
    if (!currentEmbed || currentEmbed.length === 0) return 0;

    const similarity = this._cosineSim(health.lastResponseEmbed, currentEmbed);

    // High semantic drift (low similarity) is suspicious
    // Very low similarity (<0.1) in a conversation context is a red flag
    const suspicion = Math.max(0, (0.15 - similarity) / 0.15);

    return Math.min(1, suspicion);
  }

  // ─── Coherence Tracking ──────────────────────────────────────────────────────

  /**
   * Checks conversation coherence by computing the rolling average similarity
   * across the last N responses stored in health.embedHistory.
   *
   * @param {SessionHealth} health
   * @param {string}        response
   * @returns {Promise<number>} Coherence score 0–1
   */
  async _checkCoherence(health, response) {
    const embed = await this._embedder(response).catch(() => null);
    if (!embed) return 1.0; // Unknown → assume coherent

    health.embedHistory.push(embed);
    if (health.embedHistory.length > 10) health.embedHistory.shift();
    if (health.embedHistory.length < 2) return 1.0;

    // Average pairwise cosine similarity across history window
    let total = 0, pairs = 0;
    for (let i = 0; i < health.embedHistory.length - 1; i++) {
      total += this._cosineSim(health.embedHistory[i], health.embedHistory[i + 1]);
      pairs++;
    }

    return pairs > 0 ? total / pairs : 1.0;
  }

  // ─── Escalation ───────────────────────────────────────────────────────────────

  /**
   * Triggers the escalation path (HeadySoul alert).
   * @param {Object} ctx
   */
  async _escalate(ctx) {
    ctx.health.escalationCount++;
    this._logger.warn(
      `[BuddyWatchdog] Escalating session ${ctx.sessionId} — avg quality ${ctx.health.avgQuality.toFixed(3)}`
    );
    this.emit('escalation:triggered', {
      sessionId:  ctx.sessionId,
      userId:     ctx.userId,
      avgQuality: ctx.health.avgQuality,
      result:     ctx.result,
      timestamp:  Date.now(),
    });

    if (typeof this._onEscalate === 'function') {
      await this._onEscalate(ctx).catch(err =>
        this._logger.error(`[BuddyWatchdog] Escalation callback failed: ${err.message}`)
      );
    }
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  /**
   * Gets or creates a SessionHealth record.
   * @param {string} sessionId
   * @param {string} userId
   * @returns {SessionHealth}
   */
  _getOrCreateHealth(sessionId, userId) {
    if (!this._sessions.has(sessionId)) {
      this._sessions.set(sessionId, {
        sessionId,
        userId,
        turnCount:           0,
        qualityScores:       [],
        latencies:           [],
        embedHistory:        [],
        lastResponseEmbed:   null,
        avgQuality:          1.0,
        avgLatencyMs:        0,
        escalated:           false,
        escalationCount:     0,
        createdAt:           Date.now(),
        lastEvalAt:          null,
      });
    }
    return this._sessions.get(sessionId);
  }

  /**
   * Derives an overall health status string.
   * @param {SessionHealth} h
   * @returns {'healthy'|'degraded'|'critical'}
   */
  _overallStatus(h) {
    if (h.avgQuality >= 0.70) return 'healthy';
    if (h.avgQuality >= 0.40) return 'degraded';
    return 'critical';
  }

  /**
   * Computes the mean of a numeric array.
   * @param {number[]} arr
   * @returns {number}
   */
  _avg(arr) {
    if (arr.length === 0) return 0;
    return arr.reduce((s, v) => s + v, 0) / arr.length;
  }

  /**
   * Cosine similarity between two vectors.
   * @param {number[]} a
   * @param {number[]} b
   * @returns {number}
   */
  _cosineSim(a, b) {
    const len = Math.min(a.length, b.length);
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < len; i++) {
      dot   += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    const denom = Math.sqrt(normA) * Math.sqrt(normB);
    return denom === 0 ? 0 : dot / denom;
  }

  /**
   * Stub embedder — deterministic pseudo-embedding from text.
   * @param {string} text
   * @returns {Promise<number[]>}
   */
  async _stubEmbedder(text) {
    const dim = 16;
    const vec = new Array(dim).fill(0);
    for (let i = 0; i < text.length; i++) {
      vec[i % dim] += text.charCodeAt(i) / 1000;
    }
    // Normalise
    const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0)) || 1;
    return vec.map(v => v / norm);
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  BuddyWatchdog,
  COHERENCE_THRESHOLD,
  QUALITY_ESCALATION_THRESHOLD,
  LATENCY_ALERT_MS,
  HALLUCINATION_THRESHOLD,
};
