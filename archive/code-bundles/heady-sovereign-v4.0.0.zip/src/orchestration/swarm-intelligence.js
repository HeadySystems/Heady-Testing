/**
 * ∞ Heady™ SwarmIntelligence — Collective Intelligence Patterns
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';
import crypto from 'crypto';

// ─── Constants ───────────────────────────────────────────────────────────────

/** Pheromone evaporation rate (per tick) — higher = faster forgetting */
const DEFAULT_EVAPORATION = 0.05;

/** Pheromone reinforcement per successful traversal */
const DEFAULT_DEPOSIT     = 1.0;

/** Emergence threshold: swarm score / best individual score */
const EMERGENCE_THRESHOLD = 1.15;

/** Minimum pheromone level (prevents paths going dark entirely) */
const MIN_PHEROMONE = 0.01;

// ─── SwarmIntelligence ────────────────────────────────────────────────────────

/**
 * SwarmIntelligence implements bio-inspired collective intelligence patterns:
 *
 * 1. **Stigmergy** — indirect coordination via shared pheromone trails in a
 *    vector-space memory graph. Nodes deposit signals on successful paths;
 *    other nodes read these to bias routing decisions.
 *
 * 2. **Pheromone Trails** — ACO (Ant Colony Optimisation) style reinforcement.
 *    Each edge (fromNode → toNode) carries a pheromone level that:
 *    - Increases when a task traverses it successfully
 *    - Decreases (evaporates) each time tick
 *    - Biases route selection toward proven paths
 *
 * 3. **Ant Colony Optimisation** — Probabilistic path selection based on
 *    pheromone level + heuristic desirability (η).
 *
 * 4. **Emergence Detection** — Detects when collective swarm performance
 *    consistently exceeds the best individual node's benchmark.
 *
 * @extends EventEmitter
 *
 * @fires SwarmIntelligence#pheromone:deposited
 * @fires SwarmIntelligence#pheromone:evaporated
 * @fires SwarmIntelligence#path:selected
 * @fires SwarmIntelligence#emergence:detected
 */
class SwarmIntelligence extends EventEmitter {
  /**
   * @param {Object}   [options={}]
   * @param {number}   [options.evaporationRate=0.05]  - Pheromone decay per tick (0–1)
   * @param {number}   [options.depositAmount=1.0]     - Pheromone deposited per success
   * @param {number}   [options.alpha=1.0]             - Pheromone influence exponent
   * @param {number}   [options.beta=2.0]              - Heuristic influence exponent
   * @param {number}   [options.evictionIntervalMs=10000] - Tick interval for evaporation
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._evaporation     = options.evaporationRate    ?? DEFAULT_EVAPORATION;
    this._deposit         = options.depositAmount      ?? DEFAULT_DEPOSIT;
    this._alpha           = options.alpha              ?? 1.0;
    this._beta            = options.beta               ?? 2.0;
    this._logger          = options.logger             ?? console;
    this._tickIntervalMs  = options.evictionIntervalMs ?? 10_000;

    /**
     * Pheromone graph: Map<`${from}→${to}`, { level: number, traversals: number }>
     * @type {Map<string, {level: number, traversals: number}>}
     */
    this._pheromones = new Map();

    /**
     * Heuristic desirability cache: Map<`${from}→${to}`, number>
     * Provided externally (e.g. latency inverse, success rate).
     * @type {Map<string, number>}
     */
    this._heuristics = new Map();

    /**
     * Individual node performance benchmarks (for emergence detection).
     * @type {Map<string, { totalScore: number, count: number }>}
     */
    this._nodeBenchmarks = new Map();

    /**
     * Rolling swarm performance window.
     * @type {Array<number>}
     */
    this._swarmScores = [];

    /** @type {boolean} Whether emergence is currently active */
    this._emergenceActive = false;

    /** @type {NodeJS.Timeout|null} */
    this._evaporationTick = null;

    this._startEvaporation();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Records a successful path traversal, depositing pheromone on the edge.
   * This is the primary stigmergy signal.
   *
   * @param {string} fromNode     - Source node ID
   * @param {string} toNode       - Target node ID
   * @param {number} [score=1.0]  - Quality score of the outcome (0–∞, higher = better)
   */
  depositPheromone(fromNode, toNode, score = 1.0) {
    const key    = this._edgeKey(fromNode, toNode);
    const entry  = this._pheromones.get(key) ?? { level: MIN_PHEROMONE, traversals: 0 };
    const delta  = this._deposit * score;
    entry.level += delta;
    entry.traversals++;
    this._pheromones.set(key, entry);

    this._logger.info(
      `[SwarmIntelligence] Pheromone deposited ${fromNode}→${toNode}: +${delta.toFixed(3)} → ${entry.level.toFixed(3)}`
    );
    this.emit('pheromone:deposited', { fromNode, toNode, delta, level: entry.level });
  }

  /**
   * Returns the current pheromone level on an edge.
   * @param {string} fromNode
   * @param {string} toNode
   * @returns {number}
   */
  getPheromoneLevel(fromNode, toNode) {
    return this._pheromones.get(this._edgeKey(fromNode, toNode))?.level ?? MIN_PHEROMONE;
  }

  /**
   * Sets the heuristic desirability (η) for a directed edge.
   * Typically set from observed latency inverse: η = 1 / avg_latency_ms.
   *
   * @param {string} fromNode
   * @param {string} toNode
   * @param {number} eta - Desirability score (higher = more preferred)
   */
  setHeuristic(fromNode, toNode, eta) {
    this._heuristics.set(this._edgeKey(fromNode, toNode), eta);
  }

  /**
   * Ant Colony Optimisation: selects the next node probabilistically from
   * a set of candidates using pheromone + heuristic weights.
   *
   * P(i→j) = [τ(i,j)^α · η(i,j)^β] / Σ[τ(i,k)^α · η(i,k)^β]
   *
   * @param {string}   fromNode   - Current node
   * @param {string[]} candidates - Possible next nodes
   * @returns {string} Selected next node ID
   */
  selectPath(fromNode, candidates) {
    if (candidates.length === 0) throw new Error('[SwarmIntelligence] No candidates provided');
    if (candidates.length === 1) return candidates[0];

    const weights = candidates.map(to => {
      const tau = this.getPheromoneLevel(fromNode, to);
      const eta = this._heuristics.get(this._edgeKey(fromNode, to)) ?? 1.0;
      return Math.pow(tau, this._alpha) * Math.pow(eta, this._beta);
    });

    const total = weights.reduce((s, w) => s + w, 0);
    let   rnd   = Math.random() * total;

    for (let i = 0; i < candidates.length; i++) {
      rnd -= weights[i];
      if (rnd <= 0) {
        const selected = candidates[i];
        this.emit('path:selected', { fromNode, selected, candidates, weights });
        return selected;
      }
    }

    return candidates[candidates.length - 1];
  }

  /**
   * Records a node's individual performance score for emergence detection.
   *
   * @param {string} nodeId
   * @param {number} score - Performance score this run
   */
  recordNodePerformance(nodeId, score) {
    const bench = this._nodeBenchmarks.get(nodeId) ?? { totalScore: 0, count: 0 };
    bench.totalScore += score;
    bench.count++;
    this._nodeBenchmarks.set(nodeId, bench);
  }

  /**
   * Records a swarm-level performance score and checks for emergence.
   *
   * Emergence is detected when the swarm's rolling average score exceeds
   * the best individual node's average by EMERGENCE_THRESHOLD.
   *
   * @param {number} swarmScore - Collective performance score for this run
   * @returns {boolean} Whether emergence was detected on this call
   */
  recordSwarmPerformance(swarmScore) {
    this._swarmScores.push(swarmScore);
    if (this._swarmScores.length > 100) this._swarmScores.shift(); // rolling window

    return this._checkEmergence();
  }

  /**
   * Returns a snapshot of the pheromone graph (sorted by level descending).
   * @returns {Array<{from: string, to: string, level: number, traversals: number}>}
   */
  getPheromoneSnapshot() {
    return Array.from(this._pheromones.entries())
      .map(([key, v]) => {
        const [from, to] = key.split('→');
        return { from, to, ...v };
      })
      .sort((a, b) => b.level - a.level);
  }

  /**
   * Returns the optimal path from `start` to `end` through a node graph,
   * using ACO greedy selection.
   *
   * @param {string}   start       - Starting node ID
   * @param {string}   end         - Target node ID
   * @param {Object}   graph       - Adjacency list: { nodeId: [neighborId, ...] }
   * @param {number}   [maxDepth=20]
   * @returns {string[]} Ordered path from start to end, or [] if unreachable
   */
  findOptimalPath(start, end, graph, maxDepth = 20) {
    if (start === end) return [start];
    const visited = new Set([start]);
    const path = [start];

    let current = start;
    for (let depth = 0; depth < maxDepth; depth++) {
      const neighbors = (graph[current] ?? []).filter(n => !visited.has(n));
      if (neighbors.length === 0) break;

      current = this.selectPath(current, neighbors);
      visited.add(current);
      path.push(current);

      if (current === end) return path;
    }

    return []; // Unreachable within maxDepth
  }

  /**
   * Stops the evaporation tick (call when shutting down).
   */
  destroy() {
    if (this._evaporationTick) {
      clearInterval(this._evaporationTick);
      this._evaporationTick = null;
    }
  }

  // ─── Emergence Detection ─────────────────────────────────────────────────────

  /**
   * Checks whether swarm performance exceeds individual benchmarks by the threshold.
   * @returns {boolean}
   */
  _checkEmergence() {
    if (this._swarmScores.length < 10) return false;

    const swarmAvg = this._swarmScores.reduce((s, v) => s + v, 0) / this._swarmScores.length;

    let bestIndividual = 0;
    for (const bench of this._nodeBenchmarks.values()) {
      if (bench.count > 0) {
        bestIndividual = Math.max(bestIndividual, bench.totalScore / bench.count);
      }
    }

    if (bestIndividual === 0) return false;
    const ratio = swarmAvg / bestIndividual;

    if (ratio >= EMERGENCE_THRESHOLD && !this._emergenceActive) {
      this._emergenceActive = true;
      this._logger.info(
        `[SwarmIntelligence] *** EMERGENCE DETECTED *** swarm/individual ratio = ${ratio.toFixed(3)}`
      );
      this.emit('emergence:detected', {
        swarmAvg,
        bestIndividual,
        ratio,
        timestamp: Date.now(),
      });
      return true;
    }

    if (ratio < EMERGENCE_THRESHOLD && this._emergenceActive) {
      this._emergenceActive = false;
    }

    return false;
  }

  // ─── Evaporation ─────────────────────────────────────────────────────────────

  /**
   * Starts the periodic evaporation tick. Decreases all pheromone levels by
   * evaporationRate per tick. Levels below MIN_PHEROMONE are clamped, not removed.
   */
  _startEvaporation() {
    this._evaporationTick = setInterval(() => {
      let evaporated = 0;
      for (const [key, entry] of this._pheromones.entries()) {
        entry.level = Math.max(MIN_PHEROMONE, entry.level * (1 - this._evaporation));
        evaporated++;
      }
      if (evaporated > 0) {
        this.emit('pheromone:evaporated', { edgeCount: evaporated, rate: this._evaporation });
      }
    }, this._tickIntervalMs);

    // Don't block process exit
    if (this._evaporationTick.unref) this._evaporationTick.unref();
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────

  /**
   * Generates a canonical edge key.
   * @param {string} from
   * @param {string} to
   * @returns {string}
   */
  _edgeKey(from, to) {
    return `${from}→${to}`;
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  SwarmIntelligence,
  EMERGENCE_THRESHOLD,
  DEFAULT_EVAPORATION,
};
