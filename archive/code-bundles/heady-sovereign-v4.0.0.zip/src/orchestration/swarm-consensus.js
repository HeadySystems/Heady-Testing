/**
 * ∞ Heady™ SwarmConsensus — Multi-Agent Consensus Protocol
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';
import crypto from 'crypto';

// ─── Constants ───────────────────────────────────────────────────────────────

/** Consensus round states */
const ROUND_STATE = Object.freeze({
  PENDING:    'pending',
  VOTING:     'voting',
  TALLYING:   'tallying',
  AGREED:     'agreed',
  DEADLOCKED: 'deadlocked',
  TIE_BROKEN: 'tie_broken',
  FAILED:     'failed',
});

/** Vote values */
const VOTE = Object.freeze({
  APPROVE: 'approve',
  REJECT:  'reject',
  ABSTAIN: 'abstain',
});

// ─── SwarmConsensus ───────────────────────────────────────────────────────────

/**
 * SwarmConsensus implements a Byzantine-fault-tolerant voting protocol for
 * multi-agent task outcome agreement.
 *
 * Key properties:
 * - Quorum: strict majority (> n/2 participating nodes must agree)
 * - BFT tolerance: up to f = floor((n-1)/3) faulty/Byzantine nodes
 * - Tie-breaking: HeadySoul (designated authority node) casts the deciding vote
 * - All rounds are auditable via event emissions
 *
 * @extends EventEmitter
 *
 * @fires SwarmConsensus#round:started
 * @fires SwarmConsensus#vote:cast
 * @fires SwarmConsensus#round:agreed
 * @fires SwarmConsensus#round:deadlocked
 * @fires SwarmConsensus#round:tie_broken
 * @fires SwarmConsensus#round:failed
 *
 * @example
 * const consensus = new SwarmConsensus({
 *   nodes: ['node-1', 'node-2', 'node-3', 'node-4', 'node-5'],
 *   tieBreaker: 'heady-soul',
 * });
 * const result = await consensus.propose('task-xyz', { outcome: 'success', data: {...} });
 */
class SwarmConsensus extends EventEmitter {
  /**
   * @param {Object}   options
   * @param {string[]} options.nodes              - Participating node IDs
   * @param {string}   options.tieBreaker         - HeadySoul node ID for tie-breaking
   * @param {number}   [options.voteTimeoutMs=5000] - Per-node vote deadline
   * @param {Function} [options.voteResolver]     - async(nodeId, proposal) → VOTE value
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._nodes         = options.nodes ?? [];
    this._tieBreaker    = options.tieBreaker ?? 'heady-soul';
    this._voteTimeout   = options.voteTimeoutMs ?? 5_000;
    this._voteResolver  = options.voteResolver ?? this._defaultVoteResolver.bind(this);
    this._logger        = options.logger ?? console;

    /** @type {Map<string, ConsensusRound>} All rounds keyed by roundId */
    this._rounds = new Map();

    /** @type {ConsensusMetrics} */
    this._metrics = {
      totalRounds:      0,
      agreedRounds:     0,
      deadlockRounds:   0,
      tieBrokenRounds:  0,
      failedRounds:     0,
      agreementRate:    0,
      avgTimeToConsensusMs: 0,
      _consensusTimeAccum: { total: 0, count: 0 },
    };
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Proposes an outcome for consensus among registered nodes.
   *
   * @param {string} topicId   - Unique identifier for the topic being voted on
   * @param {Object} proposal  - The proposed outcome object
   * @param {Object} [opts={}]
   * @param {string[]} [opts.participants] - Override default node list for this round
   * @returns {Promise<ConsensusResult>}
   */
  async propose(topicId, proposal, opts = {}) {
    const roundId = crypto.randomUUID();
    const participants = opts.participants ?? [...this._nodes];
    const startedAt = Date.now();

    const round = {
      roundId,
      topicId,
      proposal,
      state:     ROUND_STATE.PENDING,
      participants,
      votes:     new Map(),
      startedAt,
      endedAt:   null,
      result:    null,
    };

    this._rounds.set(roundId, round);
    this._metrics.totalRounds++;
    this.emit('round:started', { roundId, topicId, participantCount: participants.length });

    try {
      round.state = ROUND_STATE.VOTING;
      await this._collectVotes(round);

      round.state = ROUND_STATE.TALLYING;
      const tally = this._tally(round);

      const outcome = await this._resolve(round, tally);

      round.endedAt = Date.now();
      round.result  = outcome;

      this._updateMetrics(round);
      return outcome;

    } catch (err) {
      round.state  = ROUND_STATE.FAILED;
      round.endedAt = Date.now();
      this.emit('round:failed', { roundId, topicId, error: err.message });
      this._metrics.failedRounds++;
      throw err;
    }
  }

  /**
   * Returns the stored round record for a given roundId.
   * @param {string} roundId
   * @returns {ConsensusRound|undefined}
   */
  getRound(roundId) {
    return this._rounds.get(roundId);
  }

  /**
   * Returns current consensus metrics snapshot.
   * @returns {ConsensusMetrics}
   */
  getMetrics() {
    return { ...this._metrics };
  }

  /**
   * Checks Byzantine fault tolerance: maximum faulty nodes that can be tolerated.
   * f = floor((n - 1) / 3)
   *
   * @param {number} [n] - Node count (defaults to registered nodes)
   * @returns {number} f — max faulty nodes
   */
  bftTolerance(n) {
    const total = n ?? this._nodes.length;
    return Math.floor((total - 1) / 3);
  }

  // ─── Vote Collection ─────────────────────────────────────────────────────────

  /**
   * Collects votes from all participants concurrently, respecting per-node timeout.
   * Timed-out or errored nodes have their votes counted as ABSTAIN.
   *
   * @param {ConsensusRound} round
   * @returns {Promise<void>}
   */
  async _collectVotes(round) {
    const votePromises = round.participants.map(async (nodeId) => {
      try {
        const vote = await Promise.race([
          this._voteResolver(nodeId, round.proposal, round.topicId),
          this._timeout(this._voteTimeout, VOTE.ABSTAIN),
        ]);
        const validated = Object.values(VOTE).includes(vote) ? vote : VOTE.ABSTAIN;
        round.votes.set(nodeId, validated);
        this.emit('vote:cast', { roundId: round.roundId, nodeId, vote: validated });
      } catch {
        round.votes.set(nodeId, VOTE.ABSTAIN);
        this.emit('vote:cast', { roundId: round.roundId, nodeId, vote: VOTE.ABSTAIN });
      }
    });

    await Promise.allSettled(votePromises);
  }

  // ─── Tallying ────────────────────────────────────────────────────────────────

  /**
   * Tallies collected votes.
   * @param {ConsensusRound} round
   * @returns {{ approve: number, reject: number, abstain: number, total: number }}
   */
  _tally(round) {
    const counts = { [VOTE.APPROVE]: 0, [VOTE.REJECT]: 0, [VOTE.ABSTAIN]: 0 };
    for (const vote of round.votes.values()) {
      counts[vote] = (counts[vote] ?? 0) + 1;
    }
    return {
      approve: counts[VOTE.APPROVE],
      reject:  counts[VOTE.REJECT],
      abstain: counts[VOTE.ABSTAIN],
      total:   round.votes.size,
    };
  }

  // ─── Resolution ──────────────────────────────────────────────────────────────

  /**
   * Resolves a tally to a final consensus decision.
   * Quorum = strict majority of (approve + reject) votes.
   * Tie → HeadySoul tie-break.
   *
   * @param {ConsensusRound} round
   * @param {Object}         tally
   * @returns {Promise<ConsensusResult>}
   */
  async _resolve(round, tally) {
    const decisive = tally.approve + tally.reject;
    const quorum   = Math.floor(decisive / 2) + 1; // strict majority

    const makeResult = (agreed, state, tieBroken = false) => ({
      roundId:    round.roundId,
      topicId:    round.topicId,
      agreed,
      state,
      tally,
      tieBroken,
      proposal:   round.proposal,
      durationMs: Date.now() - round.startedAt,
    });

    // Clear majority
    if (tally.approve >= quorum) {
      round.state = ROUND_STATE.AGREED;
      this.emit('round:agreed', { roundId: round.roundId, tally });
      return makeResult(true, ROUND_STATE.AGREED);
    }

    if (tally.reject >= quorum) {
      round.state = ROUND_STATE.AGREED;
      this.emit('round:agreed', { roundId: round.roundId, tally });
      return makeResult(false, ROUND_STATE.AGREED);
    }

    // Tied — escalate to HeadySoul
    if (tally.approve === tally.reject && tally.approve > 0) {
      this._logger.info(
        `[SwarmConsensus] Tie detected (${tally.approve}–${tally.reject}). HeadySoul breaking.`
      );
      const tiebreakerVote = await this._voteResolver(
        this._tieBreaker, round.proposal, round.topicId
      ).catch(() => VOTE.APPROVE); // HeadySoul defaults to APPROVE on error

      const agreed = tiebreakerVote === VOTE.APPROVE;
      round.state = ROUND_STATE.TIE_BROKEN;
      this.emit('round:tie_broken', { roundId: round.roundId, tieBreaker: this._tieBreaker, agreed });
      return makeResult(agreed, ROUND_STATE.TIE_BROKEN, true);
    }

    // Deadlock (no quorum reached, no tie)
    round.state = ROUND_STATE.DEADLOCKED;
    this.emit('round:deadlocked', { roundId: round.roundId, tally });
    return makeResult(false, ROUND_STATE.DEADLOCKED);
  }

  // ─── Default Vote Resolver ───────────────────────────────────────────────────

  /**
   * Stub vote resolver. In production, replaced by an options.voteResolver that
   * calls the actual agent node's evaluation API.
   *
   * @param {string} nodeId
   * @param {Object} proposal
   * @returns {Promise<string>} VOTE constant
   */
  async _defaultVoteResolver(nodeId, proposal) {
    // Simulate ~80% approval for integration testing
    return Math.random() < 0.8 ? VOTE.APPROVE : VOTE.REJECT;
  }

  // ─── Metrics ─────────────────────────────────────────────────────────────────

  /**
   * Updates rolling metrics after a round completes.
   * @param {ConsensusRound} round
   */
  _updateMetrics(round) {
    const m = this._metrics;
    const duration = (round.endedAt ?? Date.now()) - round.startedAt;

    switch (round.state) {
      case ROUND_STATE.AGREED:      m.agreedRounds++;    break;
      case ROUND_STATE.TIE_BROKEN:  m.tieBrokenRounds++; m.agreedRounds++; break;
      case ROUND_STATE.DEADLOCKED:  m.deadlockRounds++;  break;
    }

    m._consensusTimeAccum.total += duration;
    m._consensusTimeAccum.count++;
    m.avgTimeToConsensusMs = Math.round(
      m._consensusTimeAccum.total / m._consensusTimeAccum.count
    );
    m.agreementRate = m.totalRounds > 0
      ? +(m.agreedRounds / m.totalRounds).toFixed(4)
      : 0;
  }

  // ─── Utilities ───────────────────────────────────────────────────────────────

  /**
   * Returns a promise that resolves with `value` after `ms` milliseconds.
   * Used as a race timeout.
   *
   * @param {number} ms
   * @param {*}      value
   * @returns {Promise<*>}
   */
  _timeout(ms, value) {
    return new Promise(resolve => setTimeout(() => resolve(value), ms));
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  SwarmConsensus,
  ROUND_STATE,
  VOTE,
};
