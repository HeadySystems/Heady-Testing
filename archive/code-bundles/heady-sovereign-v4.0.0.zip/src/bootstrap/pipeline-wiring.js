/**
 * ∞ Heady™ PipelineWiring — Phase 6 bootstrap: HCFullPipeline, self-healing mesh, vector context
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createLogger } from '../core/heady-logger.js';
import { uuid } from '../core/heady-crypt.js';

const log = createLogger('PipelineWiring');

/**
 * @typedef {object} PipelineContext
 * @property {string} runId - Unique run identifier
 * @property {string} traceId - Trace ID for distributed tracing
 * @property {object} input - Pipeline input data
 * @property {object} output - Accumulated pipeline output
 * @property {object} metadata - Context metadata
 * @property {object} vectorContext - Vector memory context
 * @property {object} buddyContext - Buddy relationship context
 * @property {number} startTime - Run start timestamp
 * @property {Array<object>} stages - Stage execution records
 * @property {string} status - 'running'|'success'|'failed'|'healing'
 */

/**
 * @typedef {object} StageDefinition
 * @property {string} name - Stage name
 * @property {function(PipelineContext): Promise<object>} fn - Stage function
 * @property {number} [timeout] - Stage timeout in ms
 * @property {boolean} [critical=false] - If true, failure halts pipeline
 * @property {number} [retries=0] - Number of retries on failure
 * @property {function} [fallback] - Fallback function on failure
 */

/**
 * @class HCFullPipeline
 * Heady Conductor Full Pipeline — the main processing pipeline that runs all platform stages.
 */
export class HCFullPipeline {
  /**
   * @param {object} [options]
   * @param {number} [options.maxConcurrency=5] - Max parallel stage groups
   * @param {number} [options.timeout=120000] - Total pipeline timeout
   */
  constructor(options = {}) {
    this._maxConcurrency = options.maxConcurrency || 5;
    this._timeout = options.timeout || 120000;
    /** @type {StageDefinition[]} */
    this._stages = [];
    this._runCount = 0;
    this._successCount = 0;
    this._failCount = 0;
    this._healCount = 0;
    log.debug('HCFullPipeline initialized', { timeout: this._timeout });
  }

  /**
   * Adds a stage to the pipeline
   * @param {StageDefinition} stage
   * @returns {this}
   */
  addStage(stage) {
    this._stages.push(stage);
    return this;
  }

  /**
   * Adds multiple stages at once
   * @param {StageDefinition[]} stages
   * @returns {this}
   */
  addStages(stages) {
    for (const s of stages) this.addStage(s);
    return this;
  }

  /**
   * Runs the full pipeline with a given input
   * @param {object} input
   * @param {object} [contextOverrides]
   * @returns {Promise<PipelineContext>}
   */
  async run(input, contextOverrides = {}) {
    this._runCount++;
    const runId = uuid();
    const traceId = contextOverrides.traceId || uuid();

    /** @type {PipelineContext} */
    const ctx = {
      runId,
      traceId,
      input,
      output: {},
      metadata: { version: '4.0.0', codename: 'Sovereign' },
      vectorContext: {},
      buddyContext: {},
      startTime: Date.now(),
      stages: [],
      status: 'running',
      ...contextOverrides,
    };

    log.debug('Pipeline run started', { runId, traceId, stages: this._stages.length });

    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`Pipeline timeout after ${this._timeout}ms`)), this._timeout)
    );

    try {
      await Promise.race([this._executeStages(ctx), timeoutPromise]);
      ctx.status = 'success';
      ctx.duration = Date.now() - ctx.startTime;
      this._successCount++;
      log.debug('Pipeline run complete', { runId, duration: ctx.duration });
    } catch (err) {
      ctx.status = 'failed';
      ctx.error = err.message;
      ctx.duration = Date.now() - ctx.startTime;
      this._failCount++;
      log.error('Pipeline run failed', { runId, error: err.message, duration: ctx.duration });
    }

    return ctx;
  }

  /**
   * Executes all pipeline stages sequentially
   * @param {PipelineContext} ctx
   */
  async _executeStages(ctx) {
    for (const stage of this._stages) {
      const stageRecord = {
        name: stage.name,
        startTime: Date.now(),
        status: 'running',
      };
      ctx.stages.push(stageRecord);

      let retries = stage.retries || 0;
      let lastError;

      while (retries >= 0) {
        try {
          const stageTimeout = stage.timeout || 30000;
          const result = await Promise.race([
            stage.fn(ctx),
            new Promise((_, reject) =>
              setTimeout(() => reject(new Error(`Stage "${stage.name}" timeout`)), stageTimeout)
            ),
          ]);

          // Merge stage output into pipeline context
          if (result && typeof result === 'object') {
            Object.assign(ctx.output, result.output || {});
            Object.assign(ctx.metadata, result.metadata || {});
            if (result.vectorContext) Object.assign(ctx.vectorContext, result.vectorContext);
            if (result.buddyContext) Object.assign(ctx.buddyContext, result.buddyContext);
          }

          stageRecord.status = 'success';
          stageRecord.duration = Date.now() - stageRecord.startTime;
          lastError = null;
          break; // Success — stop retrying

        } catch (err) {
          lastError = err;
          retries--;

          if (retries >= 0) {
            log.warn('Stage retry', { stage: stage.name, error: err.message, retriesLeft: retries });
            await new Promise(r => setTimeout(r, 500));
          }
        }
      }

      if (lastError) {
        stageRecord.status = 'failed';
        stageRecord.error = lastError.message;
        stageRecord.duration = Date.now() - stageRecord.startTime;

        if (stage.fallback) {
          try {
            const fallbackResult = await stage.fallback(ctx, lastError);
            if (fallbackResult) Object.assign(ctx.output, fallbackResult.output || {});
            stageRecord.status = 'fallback';
            log.info('Stage fallback succeeded', { stage: stage.name });
          } catch (fallbackErr) {
            log.error('Stage fallback failed', { stage: stage.name, error: fallbackErr.message });
            if (stage.critical) throw lastError;
          }
        } else if (stage.critical) {
          throw lastError;
        }
      }
    }
  }

  /**
   * Returns pipeline run statistics
   * @returns {object}
   */
  stats() {
    return {
      stages: this._stages.length,
      runCount: this._runCount,
      successCount: this._successCount,
      failCount: this._failCount,
      healCount: this._healCount,
      successRate: this._runCount > 0
        ? (this._successCount / this._runCount * 100).toFixed(1) + '%'
        : 'n/a',
    };
  }
}

/**
 * @class SelfHealingMesh
 * Monitors pipeline health and automatically attempts recovery on failure.
 */
export class SelfHealingMesh {
  /**
   * @param {object} options
   * @param {import('../core/event-bus.js').HeadyEventBus} options.bus
   * @param {HCFullPipeline} options.pipeline
   * @param {object} [options.vectorMemory]
   */
  constructor({ bus, pipeline, vectorMemory } = {}) {
    this._bus = bus;
    this._pipeline = pipeline;
    this._vectorMemory = vectorMemory;
    /** @type {Map<string, number>} Failure counts per stage */
    this._stageFailures = new Map();
    /** @type {Array<object>} Heal history */
    this._healHistory = [];
    this._healCount = 0;
    this._maxHealAttempts = 3;
    log.debug('SelfHealingMesh initialized');
  }

  /**
   * Attaches healing logic to pipeline events
   */
  attach() {
    if (!this._bus) return this;

    // Listen for pipeline failures
    this._bus.on('pipeline:stage:failed', async ({ stage, error, ctx }) => {
      await this._onStageFailed(stage, error, ctx);
    });

    // Listen for system-wide failures
    this._bus.onPattern('*.fatal', async (event, data) => {
      log.warn('Fatal event detected, initiating self-heal', { event });
      await this._healSystem(event, data);
    });

    // Periodic health check
    setInterval(async () => {
      await this._periodicHeal();
    }, 30000).unref?.();

    log.info('SelfHealingMesh attached to pipeline');
    return this;
  }

  /**
   * Handles a stage failure
   * @param {string} stageName
   * @param {Error} error
   * @param {PipelineContext} ctx
   */
  async _onStageFailed(stageName, error, ctx) {
    const failures = (this._stageFailures.get(stageName) || 0) + 1;
    this._stageFailures.set(stageName, failures);

    const healRecord = {
      type: 'stage-failure',
      stage: stageName,
      error: error.message,
      runId: ctx?.runId,
      ts: Date.now(),
      action: null,
    };

    if (failures <= this._maxHealAttempts) {
      // Emit heal event
      this._bus?.emit('selfheal:attempt', { stage: stageName, attempt: failures });

      // Memory pressure relief
      if (error.message.includes('memory') || error.message.includes('heap')) {
        if (global.gc) global.gc();
        healRecord.action = 'gc-triggered';
      }

      // Circuit reset for network errors
      if (error.message.includes('ECONNREFUSED') || error.message.includes('timeout')) {
        healRecord.action = 'circuit-reset';
      }

      this._healCount++;
      log.info('Self-heal action taken', { stage: stageName, action: healRecord.action, attempt: failures });
    } else {
      log.error('Stage exceeded max heal attempts', { stage: stageName, failures });
      healRecord.action = 'escalate';
      this._bus?.emit('selfheal:escalate', { stage: stageName, failures });
    }

    this._healHistory.push(healRecord);
    if (this._healHistory.length > 100) this._healHistory.shift();
  }

  /**
   * System-level heal attempt
   * @param {string} event
   * @param {unknown} data
   */
  async _healSystem(event, data) {
    log.warn('System self-heal initiated', { trigger: event });
    this._bus?.emit('selfheal:system', { trigger: event, ts: Date.now() });
  }

  /**
   * Periodic proactive healing check
   */
  async _periodicHeal() {
    const usage = process.memoryUsage();
    const heapRatio = usage.heapUsed / usage.heapTotal;

    if (heapRatio > 0.85) {
      log.warn('High heap usage — triggering proactive GC', {
        heapRatio: heapRatio.toFixed(2),
        heapMb: (usage.heapUsed / 1024 / 1024).toFixed(1),
      });
      if (global.gc) global.gc();
      this._healCount++;
      this._bus?.emit('selfheal:gc', { heapRatio });
    }
  }

  /** @returns {object} */
  stats() {
    return {
      healCount: this._healCount,
      stageFailures: Object.fromEntries(this._stageFailures),
      recentHeals: this._healHistory.slice(-5),
    };
  }
}

/**
 * Builds the default HCFullPipeline with all standard stages
 * @param {object} components - { vectorMemory, vectorPipeline, buddyCore, selfAwareness, qa, autoSuccess, storyDriver }
 * @returns {HCFullPipeline}
 */
function buildDefaultPipeline(components) {
  const pipeline = new HCFullPipeline({ timeout: 120000 });

  pipeline.addStages([
    {
      name: 'context-hydration',
      critical: false,
      fn: async (ctx) => {
        // Inject vector memory context into pipeline run
        const { vectorMemory } = components;
        if (vectorMemory && ctx.input?.contextVector) {
          const related = vectorMemory.query(ctx.input.contextVector, { k: 5, threshold: 0.7 });
          ctx.vectorContext.related = related;
        }
        return { output: { contextHydrated: true } };
      },
    },
    {
      name: 'input-validation',
      critical: true,
      fn: async (ctx) => {
        const { qa } = components;
        if (qa && ctx.input) {
          const results = qa.check(ctx.input);
          const errors = results.filter(r => !r.pass && r.severity === 'error');
          if (errors.length > 0) {
            throw new Error(`QA validation failed: ${errors.map(e => e.rule).join(', ')}`);
          }
        }
        return { output: { validated: true } };
      },
    },
    {
      name: 'buddy-enrichment',
      critical: false,
      fn: async (ctx) => {
        const { buddyCore } = components;
        if (buddyCore && ctx.input?.userId) {
          const buddies = buddyCore.findBuddies(ctx.input.userId, 3);
          ctx.buddyContext.buddies = buddies;
        }
        return { output: { buddyEnriched: true } };
      },
    },
    {
      name: 'vector-indexing',
      critical: false,
      fn: async (ctx) => {
        const { vectorPipeline } = components;
        if (vectorPipeline && ctx.input?.vector) {
          const id = await vectorPipeline.process(
            ctx.runId,
            ctx.input.vector,
            { runId: ctx.runId, ts: ctx.startTime }
          );
          return { output: { vectorId: id } };
        }
        return {};
      },
    },
    {
      name: 'awareness-observation',
      critical: false,
      fn: async (ctx) => {
        const { selfAwareness } = components;
        if (selfAwareness) {
          selfAwareness.observe('pipeline_run', 1);
          selfAwareness.observe('pipeline_duration', Date.now() - ctx.startTime);
        }
        return {};
      },
    },
    {
      name: 'success-evaluation',
      critical: false,
      fn: async (ctx) => {
        const { autoSuccess } = components;
        if (autoSuccess) {
          const evaluation = autoSuccess.evaluate(ctx.runId, ctx.output);
          ctx.metadata.successEvaluation = evaluation;
        }
        return {};
      },
    },
    {
      name: 'narrative-record',
      critical: false,
      fn: async (ctx) => {
        const { storyDriver } = components;
        if (storyDriver) {
          storyDriver.narrate('pipeline-run', {
            runId: ctx.runId,
            status: ctx.status,
            duration: Date.now() - ctx.startTime,
          });
        }
        return {};
      },
    },
  ]);

  return pipeline;
}

/**
 * Phase 6: Wire the HCFullPipeline and self-healing mesh
 * @param {import('../core/heady-server.js').HeadyApp} app
 * @param {object} globals - All previous phase outputs
 * @returns {Promise<{ pipeline: HCFullPipeline, selfHealingMesh: SelfHealingMesh }>}
 */
export async function initPipelineWiring(app, globals) {
  log.info('∞ Phase 6: Initializing pipeline-wiring...');
  const start = Date.now();

  const { bus, vectorMemory, vectorPipeline, buddyCore, selfAwareness, qa, autoSuccess, storyDriver } = globals;

  // Build pipeline with all stage components
  const pipeline = buildDefaultPipeline({
    vectorMemory,
    vectorPipeline,
    buddyCore,
    selfAwareness,
    qa,
    autoSuccess,
    storyDriver,
  });

  // Self-healing mesh
  const selfHealingMesh = new SelfHealingMesh({ bus, pipeline, vectorMemory });
  selfHealingMesh.attach();

  // Connect pipeline events to bus
  const originalRun = pipeline.run.bind(pipeline);
  pipeline.run = async (input, contextOverrides = {}) => {
    bus?.emit('pipeline:start', { runId: contextOverrides.runId || 'pending', input });
    const ctx = await originalRun(input, contextOverrides);
    bus?.emit(`pipeline:${ctx.status}`, { runId: ctx.runId, duration: ctx.duration, stages: ctx.stages.length });
    return ctx;
  };

  const elapsed = Date.now() - start;
  log.info('✓ Phase 6 complete', {
    elapsed_ms: elapsed,
    stages: pipeline._stages.length,
  });
  bus?.emit('phase:complete', { phase: 6, name: 'pipeline-wiring', elapsed });

  return { pipeline, selfHealingMesh };
}

export default initPipelineWiring;
