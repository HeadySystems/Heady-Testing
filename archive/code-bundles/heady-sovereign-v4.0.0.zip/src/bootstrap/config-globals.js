/**
 * ∞ Heady™ ConfigGlobals — Phase 1 bootstrap: env, logger, event bus, edge cache, remote config
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { HeadyEnv, env as defaultEnv } from '../core/heady-env.js';
import { HeadyLogger, createLogger } from '../core/heady-logger.js';
import { HeadyEventBus, globalEventBus } from '../core/event-bus.js';
import { HeadyKV, edgeCache as defaultEdgeCache } from '../core/heady-kv.js';

const log = createLogger('ConfigGlobals');

/** @type {Record<string, string>} Approved CORS origins */
const APPROVED_ORIGINS = [
  'https://heady.ai',
  'https://www.heady.ai',
  'https://app.heady.ai',
  'https://api.heady.ai',
  'https://edge.heady.ai',
  'https://voice.heady.ai',
  'https://vector.heady.ai',
  'https://auth.heady.ai',
  'https://mcp.heady.ai',
  'https://headysystems.ai',
  'https://www.headysystems.ai',
  'https://headyme.ai',
  'https://headyconnection.org',
  'https://www.headyconnection.org',
];

/**
 * Secrets manager stub — in production, backed by Cloudflare KV or Vault
 * @typedef {object} SecretsManager
 * @property {function(string): Promise<string|null>} get
 * @property {function(string, string): Promise<void>} set
 * @property {function(string): Promise<void>} delete
 * @property {function(): Promise<string[]>} list
 */

/**
 * Creates the secrets manager
 * @param {HeadyEnv} env
 * @param {HeadyKV} kv
 * @returns {SecretsManager}
 */
function createSecretsManager(env, kv) {
  const secretsKv = kv.scope('secrets');

  return {
    /**
     * Retrieves a secret by name (env → KV → null)
     * @param {string} name
     * @returns {Promise<string|null>}
     */
    async get(name) {
      // Check env first (highest priority)
      const envVal = env.getRaw(name) || env.getRaw(`HEADY_SECRET_${name}`);
      if (envVal) return envVal;
      // Fall back to KV store
      return secretsKv.get(name) ?? null;
    },

    /**
     * Stores a secret in KV (encrypted in production via heady-crypt)
     * @param {string} name
     * @param {string} value
     */
    async set(name, value) {
      secretsKv.set(name, value);
      log.debug('Secret stored', { name: name.replace(/./g, '*').slice(-4) });
    },

    /**
     * Deletes a secret
     * @param {string} name
     */
    async delete(name) {
      secretsKv.delete(name);
    },

    /**
     * Lists secret names (not values)
     * @returns {Promise<string[]>}
     */
    async list() {
      return secretsKv.keys();
    },
  };
}

/**
 * Cloudflare manager stub — wires to CF API, tunnels, Access, KV
 * @typedef {object} CloudflareManager
 * @property {string} accountId
 * @property {boolean} connected
 * @property {function(): Promise<object>} status
 * @property {function(string): Promise<string|null>} kvGet
 * @property {function(string, string): Promise<void>} kvSet
 * @property {function(string): Promise<void>} purgeCache
 */

/**
 * Creates the Cloudflare manager
 * @param {HeadyEnv} env
 * @returns {CloudflareManager}
 */
function createCloudflareManager(env) {
  const accountId = env.cfAccountId;
  const tunnelToken = env.cfTunnelToken;
  const connected = Boolean(accountId && tunnelToken);

  if (!connected) {
    log.warn('Cloudflare manager initialized without credentials — operating in stub mode');
  } else {
    log.info('Cloudflare manager ready', { accountId: accountId.slice(0, 8) + '...' });
  }

  return {
    accountId,
    connected,

    /**
     * Returns Cloudflare integration status
     */
    async status() {
      return {
        connected,
        accountId: accountId ? accountId.slice(0, 8) + '...' : null,
        tunnel: Boolean(tunnelToken),
        mode: env.isProduction ? 'production' : 'development',
      };
    },

    /**
     * Reads from Cloudflare KV (stub — real impl via heady-fetch to CF API)
     * @param {string} key
     */
    async kvGet(key) {
      if (!connected) return null;
      // Real impl: headyFetch(`https://api.cloudflare.com/client/v4/accounts/${accountId}/storage/kv/namespaces/${NS}/values/${key}`)
      log.debug('CF KV get (stub)', { key });
      return null;
    },

    /**
     * Writes to Cloudflare KV
     * @param {string} key
     * @param {string} value
     */
    async kvSet(key, value) {
      if (!connected) return;
      log.debug('CF KV set (stub)', { key });
    },

    /**
     * Purges a URL from Cloudflare cache
     * @param {string} url
     */
    async purgeCache(url) {
      if (!connected) return;
      log.debug('CF purge cache (stub)', { url });
    },
  };
}

/**
 * Remote config loader — fetches config from edge, merges with local
 * @typedef {object} RemoteConfigLoader
 * @property {function(): Promise<object>} load
 * @property {function(): object} get
 * @property {function(string): unknown} getKey
 */

/**
 * Creates the remote config loader
 * @param {HeadyEnv} env
 * @param {HeadyKV} cache
 * @returns {RemoteConfigLoader}
 */
function createRemoteConfigLoader(env, cache) {
  let _config = {};

  return {
    /**
     * Loads remote config from edge (with local cache fallback)
     * @returns {Promise<object>}
     */
    async load() {
      const cacheKey = 'remote-config:v1';
      const cached = cache.get(cacheKey);
      if (cached) {
        _config = cached;
        return _config;
      }

      try {
        // Real impl: const raw = await headyFetch(`${env.edgeUrl}/config`, { cache: true, cacheTtl: 300000 });
        // For now return defaults
        _config = {
          version: '4.0.0',
          platform: 'sovereign',
          features: {
            vectorMemory: true,
            selfHealing: true,
            soulAwareness: true,
            monteCarlo: true,
            autoSuccess: true,
          },
          limits: {
            maxRequestSize: 10 * 1024 * 1024, // 10MB
            rateLimitPerMinute: 1000,
            vectorDimensions: 384,
          },
          domains: {
            approved: APPROVED_ORIGINS,
          },
        };
        cache.set(cacheKey, _config, 300000); // 5 min TTL
        log.debug('Remote config loaded (defaults)', { keys: Object.keys(_config).length });
      } catch (err) {
        log.warn('Remote config load failed, using defaults', { error: err.message });
      }

      return _config;
    },

    /** @returns {object} */
    get() { return _config; },

    /**
     * @param {string} key - Dot-separated path e.g. 'features.vectorMemory'
     * @returns {unknown}
     */
    getKey(key) {
      return key.split('.').reduce((obj, k) => obj?.[k], _config);
    },
  };
}

/**
 * Phase 1: Initialize all global platform singletons
 * Returns the fully initialized config globals object.
 *
 * @param {object} [overrides] - Optional overrides for testing
 * @returns {Promise<{
 *   env: HeadyEnv,
 *   log: HeadyLogger,
 *   bus: HeadyEventBus,
 *   edgeCache: HeadyKV,
 *   secrets: SecretsManager,
 *   cloudflare: CloudflareManager,
 *   remoteConfig: RemoteConfigLoader,
 *   config: object,
 *   approvedOrigins: string[],
 * }>}
 */
export async function initConfigGlobals(overrides = {}) {
  log.info('∞ Phase 1: Initializing config-globals...');
  const start = Date.now();

  // Environment
  const env = overrides.env || defaultEnv;

  // Logger (reconfigure from env)
  const platformLog = new HeadyLogger({
    component: 'HeadySovereign',
    level: env.logLevel,
    json: env.logFormat === 'json',
  });

  // Event bus
  const bus = overrides.bus || globalEventBus;
  bus.use(async (event, args, next) => {
    // Global event logging (debug level only)
    if (platformLog.levelValue <= 20) {
      platformLog.trace(`bus:emit ${event}`);
    }
    await next();
  });

  // Edge cache
  const edgeCacheInst = overrides.edgeCache || defaultEdgeCache;

  // Secrets manager
  const secrets = createSecretsManager(env, edgeCacheInst);

  // Cloudflare manager
  const cloudflare = createCloudflareManager(env);

  // Remote config
  const remoteConfig = createRemoteConfigLoader(env, edgeCacheInst);
  const config = await remoteConfig.load();

  const elapsed = Date.now() - start;
  log.info(`✓ Phase 1 complete`, { elapsed_ms: elapsed });
  bus.emit('phase:complete', { phase: 1, name: 'config-globals', elapsed });

  return {
    env,
    log: platformLog,
    bus,
    edgeCache: edgeCacheInst,
    secrets,
    cloudflare,
    remoteConfig,
    config,
    approvedOrigins: APPROVED_ORIGINS,
  };
}

export { APPROVED_ORIGINS };
export default initConfigGlobals;
