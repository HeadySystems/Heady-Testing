/**
 * ∞ Heady™ MiddlewareStack — Phase 2 bootstrap: CORS, security headers, rate limiting, body parsing
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createLogger } from '../core/heady-logger.js';
import { HeadyKV } from '../core/heady-kv.js';
import { uuid } from '../core/heady-crypt.js';

const log = createLogger('MiddlewareStack');

/** Default security headers (helmet-equivalent) */
const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'X-XSS-Protection': '1; mode=block',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(self)',
  'Cross-Origin-Embedder-Policy': 'require-corp',
  'Cross-Origin-Opener-Policy': 'same-origin',
  'Cross-Origin-Resource-Policy': 'same-site',
  'X-Powered-By-Override': null, // Remove X-Powered-By
  'Server': 'HeadySovereign/4.0',
  'X-Heady-Platform': 'sovereign',
  'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload',
  'Content-Security-Policy': [
    "default-src 'self' https://*.heady.ai https://*.headysystems.ai",
    "script-src 'self' https://*.heady.ai 'unsafe-inline'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data: https:",
    "connect-src 'self' https://*.heady.ai wss://*.heady.ai",
    "frame-ancestors 'none'",
    "base-uri 'self'",
    "form-action 'self'",
  ].join('; '),
};

/**
 * Applies security headers to every response
 * @param {object} req
 * @param {object} res
 * @param {function} next
 */
function securityHeaders(req, res, next) {
  for (const [header, value] of Object.entries(SECURITY_HEADERS)) {
    if (value === null) {
      res.removeHeader?.(header);
    } else {
      res.setHeader(header, value);
    }
  }
  next();
}

/**
 * CORS middleware with Heady domain whitelist
 * @param {string[]} approvedOrigins
 * @returns {function}
 */
function createCorsMiddleware(approvedOrigins) {
  const originSet = new Set(approvedOrigins);

  return function corsMiddleware(req, res, next) {
    const origin = req.headers['origin'];

    if (!origin) {
      next();
      return;
    }

    // Check exact match
    if (originSet.has(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
    } else {
      // Check wildcard subdomain matching (*.heady.ai)
      const isApproved = approvedOrigins.some(approved => {
        if (!approved.startsWith('*.')) return false;
        const base = approved.slice(2);
        return origin.endsWith(`.${base}`) || origin === `https://${base}`;
      });

      if (isApproved) {
        res.setHeader('Access-Control-Allow-Origin', origin);
        res.setHeader('Vary', 'Origin');
      } else {
        // Reject non-approved origins
        log.warn('CORS rejected', { origin, ip: req.ip });
        if (req.method === 'OPTIONS') {
          res.statusCode = 403;
          res.json({ error: 'CORS policy: origin not permitted' });
          return;
        }
        // Continue (response will still go through — no Origin header set)
      }
    }

    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS, HEAD');
    res.setHeader(
      'Access-Control-Allow-Headers',
      'Content-Type, Authorization, X-Heady-Key, X-Request-ID, X-Heady-Platform, X-Trace-ID'
    );
    res.setHeader('Access-Control-Max-Age', '86400');
    res.setHeader('Access-Control-Expose-Headers', 'X-Request-ID, X-Trace-ID, X-Heady-Version');

    // Handle preflight
    if (req.method === 'OPTIONS') {
      res.statusCode = 204;
      res.end();
      return;
    }

    next();
  };
}

/**
 * Request ID injection middleware
 * @param {object} req
 * @param {object} res
 * @param {function} next
 */
function requestIdMiddleware(req, res, next) {
  const reqId = req.headers['x-request-id'] || req.headers['x-trace-id'] || uuid();
  req.requestId = reqId;
  req.traceId = req.headers['x-trace-id'] || reqId;
  res.setHeader('X-Request-ID', reqId);
  res.setHeader('X-Trace-ID', req.traceId);
  next();
}

/**
 * Rate limiter implementation using HeadyKV
 * @param {object} options
 * @param {number} [options.windowMs=60000] - Time window in ms
 * @param {number} [options.max=1000] - Max requests per window
 * @param {string} [options.keyFn] - How to derive the rate limit key
 * @param {string} [options.message]
 * @returns {function}
 */
function createRateLimiter(options = {}) {
  const windowMs = options.windowMs || 60000;
  const max = options.max || 1000;
  const message = options.message || 'Too Many Requests';

  const store = new HeadyKV({ maxSize: 100000, namespace: 'ratelimit' });

  return function rateLimiter(req, res, next) {
    // Determine key: IP + path prefix
    const ip = req.ip || req.headers['x-forwarded-for'] || 'unknown';
    const key = `${ip}`;

    const current = store.get(key) ?? 0;

    if (current >= max) {
      const ttl = store.ttl(key);
      res.setHeader('X-RateLimit-Limit', String(max));
      res.setHeader('X-RateLimit-Remaining', '0');
      res.setHeader('X-RateLimit-Reset', String(Math.ceil(Date.now() / 1000) + Math.ceil(ttl / 1000)));
      res.setHeader('Retry-After', String(Math.ceil(ttl / 1000)));
      res.statusCode = 429;
      res.json({ error: message, retryAfter: Math.ceil(ttl / 1000) });
      log.warn('Rate limit exceeded', { ip, count: current, max });
      return;
    }

    const newCount = store.incr(key, 1, current === 0 ? windowMs : undefined);
    const remaining = Math.max(0, max - newCount);

    res.setHeader('X-RateLimit-Limit', String(max));
    res.setHeader('X-RateLimit-Remaining', String(remaining));
    res.setHeader('X-RateLimit-Reset', String(Math.ceil((Date.now() + store.ttl(key)) / 1000)));

    next();
  };
}

/**
 * JSON body parser with size limiting
 * @param {object} [options]
 * @param {number} [options.limit=10485760] - Max body size in bytes (10MB)
 * @returns {function}
 */
function createBodyParser(options = {}) {
  const limit = options.limit || 10 * 1024 * 1024;

  return function bodyParser(req, res, next) {
    const contentType = req.headers['content-type'] || '';
    if (!contentType.includes('application/json') && !contentType.includes('text/')) {
      next();
      return;
    }

    const chunks = [];
    let size = 0;

    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        req.destroy(new Error('Request body too large'));
        res.statusCode = 413;
        res.json({ error: 'Request Entity Too Large', maxSize: limit });
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => {
      if (chunks.length === 0) {
        next();
        return;
      }
      const raw = Buffer.concat(chunks).toString('utf8');
      if (contentType.includes('application/json')) {
        try {
          req.body = JSON.parse(raw);
        } catch (err) {
          res.statusCode = 400;
          res.json({ error: 'Invalid JSON body', detail: err.message });
          return;
        }
      } else {
        req.body = raw;
      }
      next();
    });

    req.on('error', (err) => {
      log.warn('Body parse error', { error: err.message, requestId: req.requestId });
      next(err);
    });
  };
}

/**
 * Simple compression middleware using zlib for large responses
 * @returns {function}
 */
function createCompression() {
  return function compression(req, res, next) {
    const acceptEncoding = req.headers['accept-encoding'] || '';

    if (!acceptEncoding.includes('gzip') && !acceptEncoding.includes('br')) {
      next();
      return;
    }

    // For streaming compression, we would intercept res.json / res.send
    // and pipe through zlib.createGzip(). This stub records the preference.
    req._acceptsGzip = acceptEncoding.includes('gzip');
    req._acceptsBrotli = acceptEncoding.includes('br');
    next();
  };
}

/**
 * Request logging middleware
 * @param {import('../core/heady-logger.js').HeadyLogger} logger
 * @returns {function}
 */
function createRequestLogger(logger) {
  const reqLog = logger.child ? logger.child('HTTP') : createLogger('HTTP');

  return function requestLogger(req, res, next) {
    const start = Date.now();

    res.on('finish', () => {
      const elapsed = Date.now() - start;
      const level = res.statusCode >= 500 ? 'error'
        : res.statusCode >= 400 ? 'warn'
        : 'info';

      reqLog[level](`${req.method} ${req.path}`, {
        status: res.statusCode,
        elapsed_ms: elapsed,
        requestId: req.requestId,
        ip: req.ip,
        size: res.getHeader?.('content-length'),
      });
    });

    next();
  };
}

/**
 * URL form-data parser (application/x-www-form-urlencoded)
 * @returns {function}
 */
function createFormParser() {
  return function formParser(req, res, next) {
    const contentType = req.headers['content-type'] || '';
    if (!contentType.includes('application/x-www-form-urlencoded')) {
      next();
      return;
    }

    const chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      const params = {};
      for (const pair of raw.split('&')) {
        const [k, v] = pair.split('=').map(decodeURIComponent);
        if (k) params[k] = v || '';
      }
      req.body = params;
      next();
    });
  };
}

/**
 * Phase 2: Mount the complete middleware stack onto the app
 * @param {import('../core/heady-server.js').HeadyApp} app
 * @param {object} globals - Output from Phase 1 config-globals
 * @returns {Promise<{ middlewares: string[] }>}
 */
export async function initMiddlewareStack(app, globals) {
  log.info('∞ Phase 2: Initializing middleware-stack...');
  const start = Date.now();

  const { env, approvedOrigins, bus } = globals;
  const logger = globals.log || createLogger('HTTP');

  // 1. Request ID (must be first)
  app.use(requestIdMiddleware);

  // 2. Security headers
  app.use(securityHeaders);

  // 3. CORS
  app.use(createCorsMiddleware(approvedOrigins));

  // 4. Compression
  app.use(createCompression());

  // 5. Body parsers
  app.use(createBodyParser({ limit: env.getInt('HEADY_MAX_BODY_SIZE', 10 * 1024 * 1024) }));
  app.use(createFormParser());

  // 6. Rate limiting (different limits per environment)
  const rateLimitMax = env.isProduction
    ? env.getInt('HEADY_RATE_LIMIT', 1000)
    : 10000;

  app.use(createRateLimiter({
    windowMs: 60000,
    max: rateLimitMax,
    message: 'Heady rate limit exceeded. Please slow down.',
  }));

  // 7. Request logging
  app.use(createRequestLogger(logger));

  // 8. Platform version header
  app.use((req, res, next) => {
    res.setHeader('X-Heady-Version', '4.0.0');
    res.setHeader('X-Heady-Codename', 'Sovereign');
    next();
  });

  const elapsed = Date.now() - start;
  log.info('✓ Phase 2 complete', { elapsed_ms: elapsed });
  bus.emit('phase:complete', { phase: 2, name: 'middleware-stack', elapsed });

  return {
    middlewares: [
      'requestId', 'securityHeaders', 'cors', 'compression',
      'bodyParser', 'formParser', 'rateLimit', 'requestLogger', 'platformHeaders',
    ],
  };
}

export {
  createCorsMiddleware,
  createRateLimiter,
  createBodyParser,
  createCompression,
  createRequestLogger,
  securityHeaders,
  requestIdMiddleware,
  SECURITY_HEADERS,
};

export default initMiddlewareStack;
