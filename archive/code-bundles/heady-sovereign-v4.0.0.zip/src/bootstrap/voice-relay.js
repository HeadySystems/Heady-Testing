/**
 * ∞ Heady™ VoiceRelay — Phase 9 bootstrap: WebSocket voice relay with session management
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createLogger } from '../core/heady-logger.js';
import { uuid } from '../core/heady-crypt.js';

const log = createLogger('VoiceRelay');

/**
 * @typedef {object} VoiceSession
 * @property {string} id - Session ID
 * @property {import('stream').Duplex} socket - Raw TCP socket
 * @property {object} ws - WebSocket connection
 * @property {string} state - 'connecting'|'active'|'speaking'|'listening'|'closed'
 * @property {string|null} userId - Authenticated user ID
 * @property {string} ip - Client IP address
 * @property {number} createdAt - Session creation timestamp
 * @property {number} lastActivity - Last activity timestamp
 * @property {number} bytesReceived - Total bytes received
 * @property {number} bytesSent - Total bytes sent
 * @property {Buffer[]} audioBuffer - Buffered audio chunks
 * @property {number} audioBufferSize - Current buffer size in bytes
 */

const MAX_AUDIO_BUFFER = 1 * 1024 * 1024; // 1MB per session
const SESSION_TIMEOUT = 300000;            // 5 minutes idle
const MAX_SESSIONS = 1000;
const WS_MAGIC = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const WS_OPCODE_TEXT = 0x01;
const WS_OPCODE_BINARY = 0x02;
const WS_OPCODE_CLOSE = 0x08;
const WS_OPCODE_PING = 0x09;
const WS_OPCODE_PONG = 0x0a;

/**
 * Computes the WebSocket accept key for the handshake
 * @param {string} key
 * @returns {string}
 */
async function computeAcceptKey(key) {
  const { createHash } = await import('crypto');
  return createHash('sha1')
    .update(key + WS_MAGIC)
    .digest('base64');
}

/**
 * Parses a WebSocket frame from a Buffer
 * @param {Buffer} buf
 * @returns {{ opcode: number, payload: Buffer, fin: boolean, masked: boolean }|null}
 */
function parseFrame(buf) {
  if (buf.length < 2) return null;

  const fin = (buf[0] & 0x80) !== 0;
  const opcode = buf[0] & 0x0f;
  const masked = (buf[1] & 0x80) !== 0;
  let payloadLen = buf[1] & 0x7f;
  let offset = 2;

  if (payloadLen === 126) {
    if (buf.length < 4) return null;
    payloadLen = buf.readUInt16BE(2);
    offset = 4;
  } else if (payloadLen === 127) {
    if (buf.length < 10) return null;
    payloadLen = Number(buf.readBigUInt64BE(2));
    offset = 10;
  }

  if (masked) {
    const maskKey = buf.slice(offset, offset + 4);
    const payload = buf.slice(offset + 4, offset + 4 + payloadLen);
    for (let i = 0; i < payload.length; i++) {
      payload[i] ^= maskKey[i % 4];
    }
    return { fin, opcode, payload, masked };
  }

  return { fin, opcode, payload: buf.slice(offset, offset + payloadLen), masked };
}

/**
 * Builds a WebSocket frame
 * @param {Buffer|string} data
 * @param {number} [opcode=0x02] - Binary by default
 * @returns {Buffer}
 */
function buildFrame(data, opcode = WS_OPCODE_BINARY) {
  const payload = Buffer.isBuffer(data) ? data : Buffer.from(data, 'utf8');
  const len = payload.length;

  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[0] = 0x80 | opcode;
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }

  return Buffer.concat([header, payload]);
}

/**
 * @class VoiceRelay
 * WebSocket-based voice relay for real-time audio streaming.
 * Handles session management, audio buffering, and voice transcription routing.
 */
export class VoiceRelay {
  /**
   * @param {object} [options]
   * @param {import('../core/event-bus.js').HeadyEventBus} [options.bus]
   * @param {import('./auth-engine.js').HeadyAuth} [options.auth]
   * @param {string} [options.path='/voice'] - WebSocket upgrade path
   */
  constructor(options = {}) {
    this._bus = options.bus;
    this._auth = options.auth;
    this._path = options.path || '/voice';

    /** @type {Map<string, VoiceSession>} Active sessions */
    this._sessions = new Map();

    this._totalSessions = 0;
    this._totalBytesReceived = 0;
    this._totalBytesSent = 0;

    // Session cleanup interval
    this._cleanupTimer = setInterval(() => this._cleanupExpired(), 30000);
    this._cleanupTimer.unref?.();

    log.debug('VoiceRelay initialized', { path: this._path });
  }

  /**
   * Handles an HTTP upgrade request (WebSocket handshake)
   * @param {import('http').IncomingMessage} req
   * @param {import('stream').Duplex} socket
   * @param {Buffer} head
   */
  async handleUpgrade(req, socket, head) {
    // Path check
    const urlPath = req.url?.split('?')[0];
    if (urlPath !== this._path) {
      socket.destroy();
      return;
    }

    // Rate limiting by IP
    const ip = req.socket?.remoteAddress || 'unknown';
    if (this._sessions.size >= MAX_SESSIONS) {
      socket.write('HTTP/1.1 503 Service Unavailable\r\n\r\n');
      socket.destroy();
      log.warn('VoiceRelay: max sessions reached', { ip });
      return;
    }

    // WebSocket handshake validation
    const key = req.headers['sec-websocket-key'];
    const version = req.headers['sec-websocket-version'];

    if (!key || version !== '13') {
      socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
      socket.destroy();
      return;
    }

    // Auth check (optional — allow guest sessions with limited features)
    let userId = null;
    const authHeader = req.headers['authorization'];
    if (authHeader?.startsWith('Bearer ') && this._auth) {
      try {
        const user = this._auth.verifyToken(authHeader.slice(7));
        userId = user.sub;
      } catch {
        // Continue as guest
      }
    }

    // Complete WebSocket handshake
    const acceptKey = await computeAcceptKey(key);
    const handshake = [
      'HTTP/1.1 101 Switching Protocols',
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Accept: ${acceptKey}`,
      'Sec-WebSocket-Protocol: heady-voice',
      '',
      '',
    ].join('\r\n');

    socket.write(handshake);

    // Create session
    const sessionId = uuid();
    /** @type {VoiceSession} */
    const session = {
      id: sessionId,
      socket,
      ws: null,
      state: 'active',
      userId,
      ip,
      createdAt: Date.now(),
      lastActivity: Date.now(),
      bytesReceived: 0,
      bytesSent: 0,
      audioBuffer: [],
      audioBufferSize: 0,
    };

    this._sessions.set(sessionId, session);
    this._totalSessions++;
    log.info('Voice session opened', { sessionId, userId: userId || 'guest', ip });
    this._bus?.emit('voice:session:open', { sessionId, userId, ip });

    // Send welcome message
    this._sendText(session, JSON.stringify({
      type: 'session',
      sessionId,
      state: 'active',
      platform: 'HeadySovereign/4.0.0',
      capabilities: ['audio-stream', 'transcription', 'synthesis', 'commands'],
    }));

    // Handle incoming data
    let frameBuffer = Buffer.alloc(0);

    socket.on('data', (data) => {
      session.lastActivity = Date.now();
      session.bytesReceived += data.length;
      this._totalBytesReceived += data.length;

      frameBuffer = Buffer.concat([frameBuffer, data]);

      // Parse frames from buffer
      let offset = 0;
      while (offset < frameBuffer.length) {
        const remaining = frameBuffer.slice(offset);
        const frame = parseFrame(remaining);
        if (!frame) break;

        this._handleFrame(session, frame);
        offset += this._frameSize(remaining);
      }
      frameBuffer = frameBuffer.slice(offset);
    });

    socket.on('close', () => this._closeSession(sessionId, 'socket-close'));
    socket.on('error', (err) => {
      log.warn('Voice socket error', { sessionId, error: err.message });
      this._closeSession(sessionId, 'socket-error');
    });
  }

  /**
   * Calculates the total frame size from a buffer
   * @param {Buffer} buf
   * @returns {number}
   */
  _frameSize(buf) {
    if (buf.length < 2) return buf.length;
    const masked = (buf[1] & 0x80) !== 0;
    let payloadLen = buf[1] & 0x7f;
    let offset = 2;
    if (payloadLen === 126) offset = 4;
    else if (payloadLen === 127) {
      payloadLen = Number(buf.readBigUInt64BE(2));
      offset = 10;
    }
    return offset + (masked ? 4 : 0) + payloadLen;
  }

  /**
   * Handles a parsed WebSocket frame
   * @param {VoiceSession} session
   * @param {object} frame
   */
  _handleFrame(session, frame) {
    switch (frame.opcode) {
      case WS_OPCODE_TEXT: {
        // Command message
        try {
          const msg = JSON.parse(frame.payload.toString('utf8'));
          this._handleCommand(session, msg);
        } catch (err) {
          log.warn('VoiceRelay: invalid JSON message', { sessionId: session.id });
        }
        break;
      }

      case WS_OPCODE_BINARY: {
        // Audio data
        this._handleAudio(session, frame.payload);
        break;
      }

      case WS_OPCODE_CLOSE: {
        this._closeSession(session.id, 'client-close');
        break;
      }

      case WS_OPCODE_PING: {
        // Send pong
        session.socket.write(buildFrame(frame.payload, WS_OPCODE_PONG));
        break;
      }
    }
  }

  /**
   * Handles a command message from client
   * @param {VoiceSession} session
   * @param {object} msg
   */
  _handleCommand(session, msg) {
    log.debug('Voice command', { sessionId: session.id, type: msg.type });

    switch (msg.type) {
      case 'start-listening':
        session.state = 'listening';
        this._bus?.emit('voice:start-listening', { sessionId: session.id });
        this._sendText(session, JSON.stringify({ type: 'ack', state: 'listening' }));
        break;

      case 'stop-listening':
        session.state = 'active';
        // Flush buffered audio for transcription
        if (session.audioBuffer.length > 0) {
          const audio = Buffer.concat(session.audioBuffer);
          session.audioBuffer = [];
          session.audioBufferSize = 0;
          this._bus?.emit('voice:audio-ready', { sessionId: session.id, audio, userId: session.userId });
        }
        this._sendText(session, JSON.stringify({ type: 'ack', state: 'active' }));
        break;

      case 'ping':
        this._sendText(session, JSON.stringify({ type: 'pong', ts: Date.now() }));
        break;

      case 'session-info':
        this._sendText(session, JSON.stringify({
          type: 'session-info',
          sessionId: session.id,
          state: session.state,
          userId: session.userId,
          bytesReceived: session.bytesReceived,
          bytesSent: session.bytesSent,
          uptime: Date.now() - session.createdAt,
        }));
        break;
    }
  }

  /**
   * Handles incoming audio data
   * @param {VoiceSession} session
   * @param {Buffer} audio
   */
  _handleAudio(session, audio) {
    if (session.state !== 'listening') return;

    if (session.audioBufferSize + audio.length > MAX_AUDIO_BUFFER) {
      log.warn('Voice session audio buffer overflow', { sessionId: session.id });
      this._sendText(session, JSON.stringify({ type: 'error', message: 'Audio buffer overflow' }));
      return;
    }

    session.audioBuffer.push(audio);
    session.audioBufferSize += audio.length;
    this._bus?.emit('voice:audio-chunk', { sessionId: session.id, bytes: audio.length });
  }

  /**
   * Sends a text message to a session
   * @param {VoiceSession} session
   * @param {string} text
   */
  _sendText(session, text) {
    if (session.socket.destroyed) return;
    const frame = buildFrame(Buffer.from(text, 'utf8'), WS_OPCODE_TEXT);
    session.socket.write(frame);
    session.bytesSent += frame.length;
    this._totalBytesSent += frame.length;
  }

  /**
   * Sends binary audio data to a session
   * @param {string} sessionId
   * @param {Buffer} audio
   */
  sendAudio(sessionId, audio) {
    const session = this._sessions.get(sessionId);
    if (!session || session.socket.destroyed) return;
    const frame = buildFrame(audio, WS_OPCODE_BINARY);
    session.socket.write(frame);
    session.bytesSent += frame.length;
    this._totalBytesSent += frame.length;
  }

  /**
   * Broadcasts a text message to all active sessions
   * @param {object} msg
   */
  broadcast(msg) {
    const text = JSON.stringify(msg);
    for (const session of this._sessions.values()) {
      this._sendText(session, text);
    }
  }

  /**
   * Closes a session gracefully
   * @param {string} sessionId
   * @param {string} reason
   */
  _closeSession(sessionId, reason) {
    const session = this._sessions.get(sessionId);
    if (!session) return;

    session.state = 'closed';
    if (!session.socket.destroyed) {
      // Send close frame
      try {
        session.socket.write(buildFrame(Buffer.alloc(0), WS_OPCODE_CLOSE));
        session.socket.destroy();
      } catch {}
    }

    this._sessions.delete(sessionId);
    this._bus?.emit('voice:session:close', {
      sessionId,
      reason,
      duration: Date.now() - session.createdAt,
      bytesReceived: session.bytesReceived,
      bytesSent: session.bytesSent,
    });
    log.info('Voice session closed', { sessionId, reason });
  }

  /**
   * Removes idle sessions that have exceeded the timeout
   */
  _cleanupExpired() {
    const now = Date.now();
    for (const [id, session] of this._sessions) {
      if (now - session.lastActivity > SESSION_TIMEOUT) {
        log.debug('Closing idle voice session', { sessionId: id });
        this._closeSession(id, 'idle-timeout');
      }
    }
  }

  /**
   * Returns relay statistics
   * @returns {object}
   */
  stats() {
    return {
      activeSessions: this._sessions.size,
      totalSessions: this._totalSessions,
      totalBytesReceived: this._totalBytesReceived,
      totalBytesSent: this._totalBytesSent,
      path: this._path,
    };
  }

  /**
   * Destroys the relay and all sessions
   */
  destroy() {
    clearInterval(this._cleanupTimer);
    for (const id of this._sessions.keys()) {
      this._closeSession(id, 'shutdown');
    }
  }
}

/**
 * Phase 9: Initialize voice relay
 * @param {import('http').Server} server - HTTP server for WebSocket upgrade
 * @param {object} globals
 * @returns {Promise<{ voiceRelay: VoiceRelay }>}
 */
export async function initVoiceRelay(server, globals) {
  log.info('∞ Phase 9: Initializing voice-relay...');
  const start = Date.now();

  const { bus, auth, env } = globals;
  const voicePath = env?.getString?.('HEADY_VOICE_PATH', '/voice') || '/voice';

  const voiceRelay = new VoiceRelay({ bus, auth, path: voicePath });

  // Attach to HTTP server upgrade events
  if (server) {
    server.on('upgrade', (req, socket, head) => {
      voiceRelay.handleUpgrade(req, socket, head).catch(err => {
        log.error('Voice upgrade error', { error: err.message });
        socket.destroy();
      });
    });
  }

  const elapsed = Date.now() - start;
  log.info('✓ Phase 9 complete', { elapsed_ms: elapsed, path: voicePath });
  bus?.emit('phase:complete', { phase: 9, name: 'voice-relay', elapsed });

  return { voiceRelay };
}

export default initVoiceRelay;
