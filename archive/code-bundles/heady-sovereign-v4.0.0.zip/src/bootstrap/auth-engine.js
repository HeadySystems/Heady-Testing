/**
 * ∞ Heady™ AuthEngine — Phase 3 bootstrap: JWT auth, API keys, RBAC, Cloudflare Access
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createLogger } from '../core/heady-logger.js';
import { sign, verify, decode, generateApiKey } from '../core/heady-jwt.js';
import { safeEqual, sha256 } from '../core/heady-crypt.js';
import { HeadyKV } from '../core/heady-kv.js';
import { createRouter } from '../core/heady-server.js';

const log = createLogger('AuthEngine');

/**
 * @typedef {object} HeadyUser
 * @property {string} sub - Subject (user ID)
 * @property {string} role - User role
 * @property {string[]} scopes - Permission scopes
 * @property {string} [iss] - Issuer
 * @property {string} [component] - Originating component
 */

/**
 * @typedef {'sovereign'|'admin'|'operator'|'service'|'user'|'guest'} Role
 */

/** Role hierarchy — higher index = more permissions */
const ROLES = ['guest', 'user', 'service', 'operator', 'admin', 'sovereign'];

/**
 * All recognized permission scopes
 */
const SCOPES = {
  READ: 'read',
  WRITE: 'write',
  ADMIN: 'admin',
  VECTOR: 'vector',
  PIPELINE: 'pipeline',
  AUTH: 'auth',
  SECRETS: 'secrets',
  SOUL: 'soul',
  CONDUCTOR: 'conductor',
  ORCHESTRATOR: 'orchestrator',
  MONITORING: 'monitoring',
};

/**
 * Default scope grants per role
 */
const ROLE_SCOPES = {
  guest: ['read'],
  user: ['read', 'write', 'vector'],
  service: ['read', 'write', 'vector', 'pipeline', 'monitoring'],
  operator: ['read', 'write', 'vector', 'pipeline', 'monitoring', 'admin'],
  admin: ['read', 'write', 'vector', 'pipeline', 'monitoring', 'admin', 'auth', 'orchestrator'],
  sovereign: Object.values(SCOPES),
};

/**
 * Checks if roleA has at least the permissions of roleB
 * @param {Role} roleA
 * @param {Role} roleB
 * @returns {boolean}
 */
function hasRoleOrHigher(roleA, roleB) {
  return ROLES.indexOf(roleA) >= ROLES.indexOf(roleB);
}

/**
 * Checks if a user has a specific scope
 * @param {HeadyUser} user
 * @param {string} scope
 * @returns {boolean}
 */
function hasScope(user, scope) {
  if (!user) return false;
  const roleScopes = ROLE_SCOPES[user.role] || [];
  const userScopes = user.scopes || [];
  return roleScopes.includes(scope) || userScopes.includes(scope);
}

/**
 * @class HeadyAuth
 * Central authentication and authorization engine.
 */
export class HeadyAuth {
  /**
   * @param {object} options
   * @param {string} options.secret - JWT secret
   * @param {string} [options.issuer='heady.ai']
   * @param {string|number} [options.expiresIn='1h']
   * @param {string} [options.cfTeamDomain] - Cloudflare Access team domain
   * @param {string} [options.cfAudience] - Cloudflare Access audience tag
   */
  constructor(options = {}) {
    this._secret = options.secret;
    this._issuer = options.issuer || 'heady.ai';
    this._expiresIn = options.expiresIn || '1h';
    this._cfTeamDomain = options.cfTeamDomain;
    this._cfAudience = options.cfAudience;

    /** @type {HeadyKV} API key store: hash(key) -> {role, scopes, name} */
    this._apiKeys = new HeadyKV({ namespace: 'apikeys', maxSize: 10000 });

    /** @type {HeadyKV} Revoked JWT IDs */
    this._revokedJtis = new HeadyKV({ namespace: 'revoked', maxSize: 50000 });

    /** @type {HeadyKV} CF Access public key cache */
    this._cfKeyCache = new HeadyKV({ namespace: 'cfkeys', maxSize: 100, defaultTtl: 3600000 });

    if (!this._secret) {
      log.warn('HeadyAuth initialized without JWT secret — auth will fail in production');
    }
  }

  /**
   * Signs a JWT for a user/service
   * @param {Partial<HeadyUser>} payload
   * @param {object} [options]
   * @returns {string} JWT token
   */
  signToken(payload, options = {}) {
    if (!this._secret) throw new Error('[HeadyAuth] Cannot sign: JWT secret not configured');
    return sign(
      {
        ...payload,
        role: payload.role || 'user',
        scopes: payload.scopes || ROLE_SCOPES[payload.role || 'user'] || [],
      },
      this._secret,
      {
        issuer: this._issuer,
        expiresIn: options.expiresIn || this._expiresIn,
        algorithm: 'HS256',
      }
    );
  }

  /**
   * Verifies a JWT and returns the user payload
   * @param {string} token
   * @returns {HeadyUser}
   * @throws {Error} if invalid/expired/revoked
   */
  verifyToken(token) {
    if (!this._secret) throw new Error('[HeadyAuth] Cannot verify: JWT secret not configured');
    const payload = verify(token, this._secret, { issuer: this._issuer });

    if (this._revokedJtis.has(payload.jti)) {
      throw new Error('[HeadyAuth] Token has been revoked');
    }

    return payload;
  }

  /**
   * Revokes a JWT by its JTI
   * @param {string} token
   */
  revokeToken(token) {
    try {
      const { payload } = decode(token);
      if (payload.jti) {
        const ttl = payload.exp ? (payload.exp * 1000 - Date.now()) : 3600000;
        this._revokedJtis.set(payload.jti, true, Math.max(ttl, 0));
        log.info('Token revoked', { jti: payload.jti });
      }
    } catch (err) {
      log.warn('Token revoke failed', { error: err.message });
    }
  }

  /**
   * Registers a new API key
   * @param {object} options
   * @param {string} options.name - Human-readable key name
   * @param {Role} [options.role='service']
   * @param {string[]} [options.scopes]
   * @param {number} [options.ttl] - TTL in ms (0 = no expiry)
   * @returns {{ key: string, hash: string, name: string, role: string }}
   */
  createApiKey(options = {}) {
    const key = generateApiKey(32);
    const hash = sha256(key);
    const meta = {
      name: options.name || 'Unnamed Key',
      role: options.role || 'service',
      scopes: options.scopes || ROLE_SCOPES[options.role || 'service'],
      createdAt: new Date().toISOString(),
    };
    this._apiKeys.set(hash, meta, options.ttl || 0);
    log.info('API key created', { name: meta.name, role: meta.role });
    return { key, hash, ...meta };
  }

  /**
   * Validates an API key and returns user-like identity
   * @param {string} key
   * @returns {HeadyUser|null}
   */
  validateApiKey(key) {
    if (!key) return null;
    const hash = sha256(key);
    const meta = this._apiKeys.get(hash);
    if (!meta) return null;
    return {
      sub: `apikey:${hash.slice(0, 8)}`,
      role: meta.role,
      scopes: meta.scopes,
      name: meta.name,
      iss: this._issuer,
    };
  }

  /**
   * Revokes an API key by its raw value
   * @param {string} key
   */
  revokeApiKey(key) {
    const hash = sha256(key);
    this._apiKeys.delete(hash);
    log.info('API key revoked', { hash: hash.slice(0, 8) });
  }

  /**
   * Express-compatible authentication middleware
   * Checks: Authorization: Bearer <jwt>, X-Heady-Key: <apikey>, CF-Access-JWT-Assertion header
   * @param {object} [options]
   * @param {boolean} [options.required=true] - If false, auth failure falls through as guest
   * @param {string} [options.minRole] - Minimum required role
   * @param {string[]} [options.scopes] - Required scopes
   * @returns {function}
   */
  middleware(options = {}) {
    const required = options.required !== false;
    const minRole = options.minRole;
    const requiredScopes = options.scopes || [];

    return (req, res, next) => {
      let user = null;
      let authError = null;

      // 1. Try Bearer JWT
      const authHeader = req.headers['authorization'];
      if (authHeader?.startsWith('Bearer ')) {
        const token = authHeader.slice(7);
        try {
          user = this.verifyToken(token);
        } catch (err) {
          authError = err.message;
        }
      }

      // 2. Try API key
      if (!user) {
        const apiKey = req.headers['x-heady-key'];
        if (apiKey) {
          user = this.validateApiKey(apiKey);
          if (!user) authError = 'Invalid API key';
        }
      }

      // 3. Try Cloudflare Access header
      if (!user && this._cfAudience) {
        const cfJwt = req.headers['cf-access-jwt-assertion'];
        if (cfJwt) {
          try {
            // Stub: in production, verify against CF public keys
            const { payload } = decode(cfJwt);
            user = {
              sub: payload.email || payload.sub,
              role: 'user',
              scopes: ROLE_SCOPES.user,
              iss: 'cloudflare-access',
            };
          } catch {
            authError = 'Invalid CF Access token';
          }
        }
      }

      // Auth failure
      if (!user) {
        if (required) {
          log.warn('Auth required but missing', {
            path: req.path, ip: req.ip, error: authError,
          });
          res.statusCode = 401;
          res.json({
            error: 'Unauthorized',
            message: authError || 'Authentication required',
            platform: 'heady.ai',
          });
          return;
        }
        // Guest fallback
        user = { sub: 'guest', role: 'guest', scopes: ROLE_SCOPES.guest, iss: this._issuer };
      }

      // Role check
      if (minRole && !hasRoleOrHigher(user.role, minRole)) {
        log.warn('Insufficient role', { role: user.role, required: minRole, sub: user.sub });
        res.statusCode = 403;
        res.json({ error: 'Forbidden', message: `Requires role: ${minRole}` });
        return;
      }

      // Scope check
      for (const scope of requiredScopes) {
        if (!hasScope(user, scope)) {
          log.warn('Missing scope', { scope, role: user.role, sub: user.sub });
          res.statusCode = 403;
          res.json({ error: 'Forbidden', message: `Requires scope: ${scope}` });
          return;
        }
      }

      req.user = user;
      req.auth = { user, authenticated: true };
      next();
    };
  }

  /**
   * Creates authorization middleware requiring a minimum role
   * @param {Role} role
   * @returns {function}
   */
  requireRole(role) {
    return this.middleware({ required: true, minRole: role });
  }

  /**
   * Creates authorization middleware requiring specific scopes
   * @param {...string} scopes
   * @returns {function}
   */
  requireScopes(...scopes) {
    return this.middleware({ required: true, scopes });
  }
}

/**
 * Mounts secrets management routes onto the app
 * @param {import('../core/heady-server.js').HeadyRouter} router
 * @param {object} secrets - SecretsManager from Phase 1
 * @param {HeadyAuth} auth
 */
function mountSecretsRoutes(router, secrets, auth) {
  // List secret names (admin only)
  router.get('/list', auth.requireRole('admin'), async (req, res) => {
    const names = await secrets.list();
    res.json({ secrets: names.map(n => ({ name: n })), count: names.length });
  });

  // Get a secret (sovereign only)
  router.get('/:name', auth.requireRole('sovereign'), async (req, res) => {
    const value = await secrets.get(req.params.name);
    if (value === null) {
      res.statusCode = 404;
      res.json({ error: 'Secret not found' });
      return;
    }
    res.json({ name: req.params.name, value });
  });

  // Set a secret (sovereign only)
  router.post('/:name', auth.requireRole('sovereign'), async (req, res) => {
    await secrets.set(req.params.name, req.body?.value);
    res.json({ ok: true, name: req.params.name });
  });

  // Delete a secret (sovereign only)
  router.delete('/:name', auth.requireRole('sovereign'), async (req, res) => {
    await secrets.delete(req.params.name);
    res.json({ ok: true, name: req.params.name });
  });
}

/**
 * Phase 3: Initialize the auth engine and mount auth routes
 * @param {import('../core/heady-server.js').HeadyApp} app
 * @param {object} globals - Phase 1 output
 * @returns {Promise<{ auth: HeadyAuth }>}
 */
export async function initAuthEngine(app, globals) {
  log.info('∞ Phase 3: Initializing auth-engine...');
  const start = Date.now();

  const { env, secrets, bus } = globals;

  const jwtSecret = await secrets.get('HEADY_JWT_SECRET') || env.jwtSecret;

  if (!jwtSecret) {
    log.warn('JWT secret not configured — generate one with: node -e "require(\'crypto\').randomBytes(64).toString(\'hex\')"');
  }

  const auth = new HeadyAuth({
    secret: jwtSecret,
    issuer: env.jwtIssuer,
    expiresIn: env.getString('HEADY_JWT_EXPIRES_IN', '1h'),
    cfTeamDomain: env.getString('CLOUDFLARE_TEAM_DOMAIN', ''),
    cfAudience: env.getString('CLOUDFLARE_ACCESS_AUDIENCE', ''),
  });

  // Mount auth routes
  const authRouter = createRouter();

  authRouter.post('/token', async (req, res) => {
    // API key -> JWT exchange
    const apiKey = req.headers['x-heady-key'] || req.body?.apiKey;
    const user = auth.validateApiKey(apiKey);
    if (!user) {
      res.statusCode = 401;
      res.json({ error: 'Invalid API key' });
      return;
    }
    const token = auth.signToken(user);
    res.json({ token, expiresIn: env.getString('HEADY_JWT_EXPIRES_IN', '1h') });
  });

  authRouter.post('/revoke', auth.middleware({ required: true }), (req, res) => {
    const token = req.headers['authorization']?.slice(7) || req.body?.token;
    if (token) auth.revokeToken(token);
    res.json({ ok: true });
  });

  authRouter.get('/whoami', auth.middleware({ required: false }), (req, res) => {
    res.json({ user: req.user, authenticated: req.user?.role !== 'guest' });
  });

  app.use('/auth', authRouter);

  // Mount secrets routes (admin-protected)
  const secretsRouter = createRouter();
  mountSecretsRoutes(secretsRouter, secrets, auth);
  app.use('/_secrets', secretsRouter);

  const elapsed = Date.now() - start;
  log.info('✓ Phase 3 complete', { elapsed_ms: elapsed });
  bus.emit('phase:complete', { phase: 3, name: 'auth-engine', elapsed });

  return { auth };
}

export { ROLES, SCOPES, ROLE_SCOPES, hasRoleOrHigher, hasScope };
export default initAuthEngine;
