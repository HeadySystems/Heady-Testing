/**
 * ∞ Heady™ InlineRoutes — Phase 8 bootstrap: health, pulse, CSL, edge, telemetry, principles
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createLogger } from '../core/heady-logger.js';

const log = createLogger('InlineRoutes');

/** Platform start time */
const BOOT_TIME = Date.now();

/** Platform principles — the immutable values of HeadySovereign */
const HEADY_PRINCIPLES = [
  {
    id: 'P1',
    name: 'Sovereign Intelligence',
    description: 'The system maintains autonomous decision-making capability without human micromanagement.',
  },
  {
    id: 'P2',
    name: 'Zero Localhost',
    description: 'All communication flows through branded Heady domains. No localhost references permitted.',
  },
  {
    id: 'P3',
    name: 'Vector-First Memory',
    description: '384-dimensional RAM-resident vector space is the primary state store. Databases are backups.',
  },
  {
    id: 'P4',
    name: 'Self-Healing Mesh',
    description: 'Every component monitors itself and initiates recovery without external prompting.',
  },
  {
    id: 'P5',
    name: 'Sacred Geometry',
    description: 'Fibonacci sharding and golden ratio distributions govern spatial data organization.',
  },
  {
    id: 'P6',
    name: 'Soul Awareness',
    description: 'HeadySoul maintains the supreme values layer. All decisions must align with soul principles.',
  },
  {
    id: 'P7',
    name: 'Minimal Dependencies',
    description: 'HeadyCore replaces external npm packages. Fewer dependencies = greater sovereignty.',
  },
  {
    id: 'P8',
    name: 'Cloud Native',
    description: 'Cloudflare tunneling for ingress. No direct port exposure. Zero trust by default.',
  },
  {
    id: 'P9',
    name: 'Continuous Auto-Success',
    description: 'The system actively drives toward positive outcomes through Monte Carlo-guided scheduling.',
  },
  {
    id: 'P10',
    name: 'Latent OS',
    description: 'Heady is not an app — it is a liquid, dynamic, intelligent operating system for reality.',
  },
];

/**
 * Computes process uptime in a human-readable format
 * @returns {string}
 */
function formatUptime(ms) {
  const totalSec = Math.floor(ms / 1000);
  const d = Math.floor(totalSec / 86400);
  const h = Math.floor((totalSec % 86400) / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${s}s`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}

/**
 * Collects process memory stats
 * @returns {object}
 */
function memoryStats() {
  const usage = process.memoryUsage();
  return {
    heapUsedMb: (usage.heapUsed / 1024 / 1024).toFixed(2),
    heapTotalMb: (usage.heapTotal / 1024 / 1024).toFixed(2),
    rssMb: (usage.rss / 1024 / 1024).toFixed(2),
    externalMb: (usage.external / 1024 / 1024).toFixed(2),
    heapRatio: (usage.heapUsed / usage.heapTotal).toFixed(3),
  };
}

/**
 * Phase 8: Mount all inline platform routes
 * @param {import('../core/heady-server.js').HeadyApp} app
 * @param {object} globals - All previous phase outputs
 * @returns {Promise<{ routes: string[] }>}
 */
export async function initInlineRoutes(app, globals) {
  log.info('∞ Phase 8: Initializing inline-routes...');
  const start = Date.now();

  const {
    bus, env, vectorMemory, vectorFederation, pipeline, selfHealingMesh,
    serviceRegistry, watchdog, selfAwareness, beeFactory, edgeCache,
    mcScheduler, patternEngine, autoSuccess, qa, storyDriver,
    auth, cloudflare, remoteConfig,
  } = globals;

  // ─── Health Routes ────────────────────────────────────────────────────────

  /**
   * GET /health/live — Kubernetes liveness probe
   * Returns 200 if process is alive
   */
  app.get('/health/live', (req, res) => {
    res.json({
      status: 'alive',
      platform: 'HeadySovereign',
      version: '4.0.0',
      ts: new Date().toISOString(),
    });
  });

  /**
   * GET /health/ready — Kubernetes readiness probe
   * Returns 200 if platform is ready to serve traffic
   */
  app.get('/health/ready', (req, res) => {
    const uptime = Date.now() - BOOT_TIME;
    const isReady = uptime > 1000; // Ready after 1 second of uptime

    if (!isReady) {
      res.statusCode = 503;
      res.json({ status: 'not-ready', reason: 'still-booting', uptime });
      return;
    }

    res.json({
      status: 'ready',
      uptime,
      uptimeHuman: formatUptime(uptime),
      platform: 'HeadySovereign/4.0.0',
      ts: new Date().toISOString(),
    });
  });

  /**
   * GET /health/deep — Deep health check (runs all watchdog checks)
   */
  app.get('/health/deep', async (req, res) => {
    const startTime = Date.now();
    let checks = {};

    try {
      if (watchdog) {
        checks = await watchdog.runAll();
      } else {
        checks = {
          process: { healthy: true, latency: 0 },
          memory: { healthy: process.memoryUsage().heapUsed < 900 * 1024 * 1024, latency: 0 },
        };
      }
    } catch (err) {
      log.warn('Deep health check error', { error: err.message });
      checks.error = { healthy: false, error: err.message, latency: 0 };
    }

    const allHealthy = Object.values(checks).every(c => c.healthy);
    const latency = Date.now() - startTime;

    res.statusCode = allHealthy ? 200 : 503;
    res.json({
      status: allHealthy ? 'healthy' : 'degraded',
      checks,
      latency,
      memory: memoryStats(),
      uptime: formatUptime(Date.now() - BOOT_TIME),
      ts: new Date().toISOString(),
    });
  });

  // ─── Pulse Route ──────────────────────────────────────────────────────────

  /**
   * GET /pulse — Platform heartbeat with lightweight system stats
   */
  app.get('/pulse', (req, res) => {
    const uptime = Date.now() - BOOT_TIME;
    const mem = memoryStats();

    res.json({
      alive: true,
      platform: 'HeadySovereign',
      version: '4.0.0',
      codename: 'Sovereign',
      uptime,
      uptimeHuman: formatUptime(uptime),
      memory: mem,
      vectors: vectorMemory?.stats?.() || null,
      bees: beeFactory?.status?.() || null,
      pipeline: pipeline?.stats?.() || null,
      bus: bus?.stats?.() || null,
      ts: new Date().toISOString(),
    });
  });

  // ─── Layer Info ───────────────────────────────────────────────────────────

  /**
   * GET /layer — Platform layer architecture info
   */
  app.get('/layer', (req, res) => {
    res.json({
      platform: 'HeadySovereign',
      version: '4.0.0',
      codename: 'Sovereign',
      architecture: 'Latent OS',
      layers: [
        { id: 'kernel', name: 'HeadyCore Kernel', status: 'active', components: ['heady-env', 'heady-fetch', 'heady-yaml', 'heady-jwt', 'heady-crypt', 'heady-server', 'heady-kv', 'heady-scheduler', 'heady-logger', 'event-bus'] },
        { id: 'bootstrap', name: 'Bootstrap Orchestration', status: 'active', components: ['config-globals', 'middleware-stack', 'auth-engine', 'vector-stack', 'engine-wiring', 'pipeline-wiring', 'service-registry', 'inline-routes', 'voice-relay', 'server-boot'] },
        { id: 'vector', name: 'Vector Memory Layer', status: vectorMemory ? 'active' : 'offline', dimensions: 384, shards: 144 },
        { id: 'soul', name: 'HeadySoul Awareness Layer', status: 'active', description: 'Supreme values and alignment' },
        { id: 'conductor', name: 'HeadyConductor', status: 'active', description: 'All system operations management' },
        { id: 'bees', name: 'Bee Worker Swarm', status: beeFactory ? 'active' : 'offline', count: beeFactory?._registry?.size || 0 },
        { id: 'edge', name: 'Edge Cache + CDN', status: edgeCache ? 'active' : 'offline', entries: edgeCache?.size || 0 },
      ],
      dependencies: {
        real: ['@modelcontextprotocol/sdk', '@octokit/auth-app', '@octokit/rest'],
        replaced: ['express', 'jsonwebtoken', 'dotenv', 'js-yaml', 'node-fetch', 'ioredis', 'winston', 'cors', 'helmet', 'express-rate-limit', 'body-parser', 'uuid', 'bcrypt', 'node-cron', 'eventemitter2'],
      },
    });
  });

  // ─── CSL Status ───────────────────────────────────────────────────────────

  /**
   * GET /csl — Continuous Spatial Lattice status
   */
  app.get('/csl', (req, res) => {
    const fedStats = vectorFederation?.stats?.() || {};
    const vecStats = vectorMemory?.stats?.() || {};

    res.json({
      name: 'Continuous Spatial Lattice',
      description: 'Heady 384D vector space organized via Fibonacci sharding across sacred geometry topology',
      status: 'operational',
      geometry: {
        dimensions: 384,
        shards: 144,
        phi: 1.6180339887,
        fibonacciNumbers: [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144],
      },
      namespaces: Object.keys(fedStats.nodes || {}),
      totalVectors: vecStats.count || 0,
      distribution: {
        primary: vecStats.count || 0,
        episodic: fedStats.nodes?.episodic?.count || 0,
        semantic: fedStats.nodes?.semantic?.count || 0,
        working: fedStats.nodes?.working?.count || 0,
      },
      federation: fedStats,
      ts: new Date().toISOString(),
    });
  });

  // ─── Edge Stats ───────────────────────────────────────────────────────────

  /**
   * GET /edge — Edge cache and CDN statistics
   */
  app.get('/edge', (req, res) => {
    const cacheStats = edgeCache?.stats?.() || {};
    const cfStatus = cloudflare?.status ? 'checking' : 'unconfigured';

    res.json({
      edge: {
        cache: cacheStats,
        cloudflare: {
          status: cfStatus,
          accountId: cloudflare?.accountId ? cloudflare.accountId.slice(0, 8) + '...' : null,
          tunnelEnabled: Boolean(cloudflare?.connected),
        },
        domains: [
          'https://api.heady.ai',
          'https://edge.heady.ai',
          'https://voice.heady.ai',
          'https://vector.heady.ai',
          'https://auth.heady.ai',
          'https://mcp.heady.ai',
        ],
      },
      ts: new Date().toISOString(),
    });
  });

  // ─── Telemetry ────────────────────────────────────────────────────────────

  /**
   * GET /telemetry — Full platform telemetry snapshot
   */
  app.get('/telemetry', (req, res) => {
    const uptime = Date.now() - BOOT_TIME;

    res.json({
      platform: 'HeadySovereign/4.0.0',
      uptime,
      uptimeHuman: formatUptime(uptime),
      memory: memoryStats(),
      process: {
        pid: process.pid,
        nodeVersion: process.version,
        platform: process.platform,
        arch: process.arch,
        env: env?.nodeEnv || 'unknown',
      },
      vector: vectorMemory?.stats?.() || null,
      federation: vectorFederation?.stats?.() || null,
      pipeline: pipeline?.stats?.() || null,
      engines: {
        monteCarlo: mcScheduler?.stats?.() || null,
        patterns: patternEngine?.status?.() || null,
        autoSuccess: autoSuccess?.stats?.() || null,
        qa: qa?.stats?.() || null,
        story: storyDriver?.currentArc?.() || null,
      },
      selfHeal: selfHealingMesh?.stats?.() || null,
      awareness: selfAwareness?.report?.() || null,
      bus: bus?.stats?.() || null,
      services: serviceRegistry?.status?.() || null,
      ts: new Date().toISOString(),
    });
  });

  // ─── Principles ───────────────────────────────────────────────────────────

  /**
   * GET /principles — Platform design principles
   */
  app.get('/principles', (req, res) => {
    res.json({
      platform: 'HeadySovereign',
      version: '4.0.0',
      description: 'The immutable values of the HeadySovereign Latent OS',
      principles: HEADY_PRINCIPLES,
      count: HEADY_PRINCIPLES.length,
    });
  });

  // ─── Version ──────────────────────────────────────────────────────────────

  /**
   * GET /version — Platform version info
   */
  app.get('/version', (req, res) => {
    res.json({
      platform: 'HeadySovereign',
      version: '4.0.0',
      codename: 'Sovereign',
      previousVersion: '3.0.1',
      previousCodename: 'Aether',
      nodeVersion: process.version,
      buildDate: new Date().toISOString(),
      commitHash: process.env.HEADY_COMMIT_HASH || 'dev',
    });
  });

  // ─── 404 Catch-all ────────────────────────────────────────────────────────
  app.all('/*', (req, res) => {
    res.statusCode = 404;
    res.json({
      error: 'Not Found',
      path: req.path,
      method: req.method,
      platform: 'HeadySovereign/4.0.0',
      docs: 'https://docs.heady.ai/api/v4',
      ts: new Date().toISOString(),
    });
  });

  const routes = [
    '/health/live', '/health/ready', '/health/deep',
    '/pulse', '/layer', '/csl', '/edge',
    '/telemetry', '/principles', '/version',
  ];

  const elapsed = Date.now() - start;
  log.info('✓ Phase 8 complete', { elapsed_ms: elapsed, routes: routes.length });
  bus?.emit('phase:complete', { phase: 8, name: 'inline-routes', elapsed, routes });

  return { routes };
}

export { HEADY_PRINCIPLES, formatUptime, memoryStats, BOOT_TIME };
export default initInlineRoutes;
