/**
 * ∞ Heady™ EngineWiring — Phase 5 bootstrap: Monte Carlo, Patterns, AutoSuccess, QA, StoryDriver
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createLogger } from '../core/heady-logger.js';
import { uuid } from '../core/heady-crypt.js';
import { HeadyKV } from '../core/heady-kv.js';

const log = createLogger('EngineWiring');

// ─── Monte Carlo Scheduler ────────────────────────────────────────────────────

/**
 * @class MonteCarloScheduler
 * Uses Monte Carlo simulation to prioritize and schedule tasks based on
 * probability distributions of outcomes.
 */
export class MonteCarloScheduler {
  /**
   * @param {object} [options]
   * @param {number} [options.simulations=1000] - MC simulations per decision
   * @param {number} [options.timeHorizon=3600000] - Planning horizon in ms (1h)
   * @param {number} [options.confidenceLevel=0.95] - Required confidence for scheduling
   */
  constructor(options = {}) {
    this._simulations = options.simulations || 1000;
    this._timeHorizon = options.timeHorizon || 3600000;
    this._confidenceLevel = options.confidenceLevel || 0.95;
    /** @type {Map<string, object>} Task probability models */
    this._models = new Map();
    /** @type {Array<object>} Simulation history */
    this._history = [];
    log.debug('MonteCarloScheduler initialized', {
      simulations: this._simulations,
      confidence: this._confidenceLevel,
    });
  }

  /**
   * Registers a task with its probability distribution model
   * @param {string} id
   * @param {object} model - { meanDuration, stdDev, successRate, priority, dependencies }
   */
  registerTask(id, model) {
    this._models.set(id, {
      id,
      meanDuration: model.meanDuration || 5000,
      stdDev: model.stdDev || 1000,
      successRate: model.successRate || 0.95,
      priority: model.priority || 1,
      dependencies: model.dependencies || [],
      ...model,
    });
    return this;
  }

  /**
   * Box-Muller transform: normal distribution sample
   * @param {number} mean
   * @param {number} std
   * @returns {number}
   */
  _normalSample(mean, std) {
    const u1 = Math.random();
    const u2 = Math.random();
    const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return mean + z * std;
  }

  /**
   * Runs Monte Carlo simulation and returns optimal execution order
   * @param {string[]} taskIds
   * @returns {Array<{ id: string, expectedDuration: number, confidence: number, priority: number }>}
   */
  simulate(taskIds) {
    const results = taskIds.map(id => {
      const model = this._models.get(id);
      if (!model) return { id, expectedDuration: 5000, confidence: 0.5, priority: 1 };

      const durations = [];
      let successes = 0;

      for (let i = 0; i < this._simulations; i++) {
        const duration = Math.max(0, this._normalSample(model.meanDuration, model.stdDev));
        const succeeded = Math.random() < model.successRate;
        durations.push(duration);
        if (succeeded) successes++;
      }

      durations.sort((a, b) => a - b);
      const p95Idx = Math.floor(this._simulations * 0.95);
      const expectedDuration = durations.reduce((s, d) => s + d, 0) / this._simulations;
      const p95Duration = durations[p95Idx];
      const confidence = successes / this._simulations;

      return {
        id,
        expectedDuration: Math.round(expectedDuration),
        p95Duration: Math.round(p95Duration),
        confidence,
        priority: model.priority,
        feasible: confidence >= this._confidenceLevel,
      };
    });

    // Sort by priority * confidence / expected_duration (efficiency score)
    return results.sort((a, b) => {
      const scoreA = (a.priority * a.confidence) / (a.expectedDuration + 1);
      const scoreB = (b.priority * b.confidence) / (b.expectedDuration + 1);
      return scoreB - scoreA;
    });
  }

  /** @returns {object} */
  stats() {
    return {
      models: this._models.size,
      simulations: this._simulations,
      confidenceLevel: this._confidenceLevel,
    };
  }
}

// ─── Pattern Engine ───────────────────────────────────────────────────────────

/**
 * @class PatternEngine
 * Detects and responds to behavioral patterns in system events and data flows.
 */
export class PatternEngine {
  constructor(bus) {
    this._bus = bus;
    /** @type {Map<string, object>} Pattern definitions */
    this._patterns = new Map();
    /** @type {Array<object>} Recent observations */
    this._observations = [];
    this._maxObservations = 10000;
    log.debug('PatternEngine initialized');
  }

  /**
   * Registers a pattern definition
   * @param {string} name
   * @param {object} def - { detect: fn(obs) -> bool, respond: fn(matches) -> void, window? }
   */
  register(name, def) {
    this._patterns.set(name, { name, ...def, matches: 0, lastMatch: null });
    return this;
  }

  /**
   * Records an observation and checks all patterns
   * @param {string} type
   * @param {unknown} data
   * @param {object} [tags]
   */
  observe(type, data, tags = {}) {
    const obs = { type, data, tags, ts: Date.now() };
    this._observations.push(obs);
    if (this._observations.length > this._maxObservations) this._observations.shift();

    for (const [name, pattern] of this._patterns) {
      try {
        const window = pattern.window || 60000;
        const recent = this._observations.filter(o => o.ts > Date.now() - window);
        if (pattern.detect(recent, obs)) {
          pattern.matches++;
          pattern.lastMatch = Date.now();
          pattern.respond?.(recent, obs);
          this._bus?.emit(`pattern:${name}`, { pattern: name, observation: obs });
        }
      } catch (err) {
        log.warn('Pattern detection error', { name, error: err.message });
      }
    }
  }

  /**
   * Returns pattern stats
   */
  status() {
    return Array.from(this._patterns.values()).map(p => ({
      name: p.name,
      matches: p.matches,
      lastMatch: p.lastMatch ? new Date(p.lastMatch).toISOString() : null,
    }));
  }
}

// ─── AutoSuccess ──────────────────────────────────────────────────────────────

/**
 * @class AutoSuccess
 * Automated success detection and celebration system.
 * Monitors pipeline outputs and marks successes for downstream learning.
 */
export class AutoSuccess {
  /**
   * @param {object} [options]
   * @param {number} [options.threshold=0.8] - Success confidence threshold
   */
  constructor(options = {}) {
    this._threshold = options.threshold || 0.8;
    this._successCount = 0;
    this._failureCount = 0;
    this._successHistory = [];
    log.debug('AutoSuccess initialized', { threshold: this._threshold });
  }

  /**
   * Evaluates an outcome and records success/failure
   * @param {string} taskId
   * @param {unknown} result
   * @param {object} [context]
   * @returns {{ success: boolean, confidence: number, message: string }}
   */
  evaluate(taskId, result, context = {}) {
    const confidence = this._computeConfidence(result, context);
    const success = confidence >= this._threshold;

    if (success) {
      this._successCount++;
      this._successHistory.push({ taskId, confidence, ts: Date.now() });
      if (this._successHistory.length > 500) this._successHistory.shift();
    } else {
      this._failureCount++;
    }

    return {
      success,
      confidence,
      message: success
        ? `✓ Task ${taskId} succeeded (${(confidence * 100).toFixed(0)}% confidence)`
        : `✗ Task ${taskId} below threshold (${(confidence * 100).toFixed(0)}%)`,
    };
  }

  /**
   * Computes a confidence score from result properties
   * @param {unknown} result
   * @param {object} context
   * @returns {number} [0, 1]
   */
  _computeConfidence(result, context) {
    if (result === null || result === undefined) return 0;
    if (typeof result === 'boolean') return result ? 1 : 0;
    if (typeof result === 'number') return Math.max(0, Math.min(1, result));
    if (typeof result === 'object') {
      if ('confidence' in result) return Number(result.confidence);
      if ('score' in result) return Number(result.score);
      if ('success' in result) return result.success ? 1 : 0;
      if ('error' in result) return 0;
    }
    return 0.5; // Unknown result type — neutral confidence
  }

  /** @returns {object} */
  stats() {
    const total = this._successCount + this._failureCount;
    return {
      successCount: this._successCount,
      failureCount: this._failureCount,
      successRate: total > 0 ? (this._successCount / total * 100).toFixed(1) + '%' : 'n/a',
      threshold: this._threshold,
    };
  }
}

// ─── Scientist ────────────────────────────────────────────────────────────────

/**
 * @class Scientist
 * A/B testing and experiment runner for the Heady platform.
 * Inspired by GitHub Scientist pattern.
 */
export class Scientist {
  constructor(bus) {
    this._bus = bus;
    /** @type {Map<string, object>} Active experiments */
    this._experiments = new Map();
    log.debug('Scientist initialized');
  }

  /**
   * Registers an experiment
   * @param {string} name
   * @param {object} def
   * @param {function} def.control - Control (production) path
   * @param {function} def.candidate - Candidate (experimental) path
   * @param {number} [def.sampleRate=0.1] - Fraction of requests to run candidate
   * @param {function} [def.compare] - Custom comparison function
   */
  experiment(name, def) {
    this._experiments.set(name, {
      name,
      control: def.control,
      candidate: def.candidate,
      sampleRate: def.sampleRate ?? 0.1,
      compare: def.compare || ((a, b) => JSON.stringify(a) === JSON.stringify(b)),
      runs: 0,
      matches: 0,
      mismatches: 0,
    });
    return this;
  }

  /**
   * Runs an experiment, always returning the control result
   * @param {string} name
   * @param {...unknown} args
   * @returns {Promise<unknown>} Control result
   */
  async run(name, ...args) {
    const exp = this._experiments.get(name);
    if (!exp) throw new Error(`[Scientist] Unknown experiment: ${name}`);

    exp.runs++;

    // Run control (always)
    const controlResult = await exp.control(...args);

    // Run candidate (sampled)
    if (Math.random() < exp.sampleRate) {
      try {
        const candidateResult = await exp.candidate(...args);
        const matched = exp.compare(controlResult, candidateResult);

        if (matched) {
          exp.matches++;
        } else {
          exp.mismatches++;
          this._bus?.emit('experiment:mismatch', {
            name,
            control: controlResult,
            candidate: candidateResult,
          });
        }
      } catch (err) {
        exp.mismatches++;
        this._bus?.emit('experiment:error', { name, error: err.message });
      }
    }

    return controlResult;
  }

  /** @returns {Array<object>} */
  status() {
    return Array.from(this._experiments.values()).map(e => ({
      name: e.name,
      sampleRate: e.sampleRate,
      runs: e.runs,
      matches: e.matches,
      mismatches: e.mismatches,
      matchRate: e.runs > 0 ? (e.matches / e.runs * 100).toFixed(1) + '%' : 'n/a',
    }));
  }
}

// ─── QA Engine ────────────────────────────────────────────────────────────────

/**
 * @class QAEngine
 * Automated quality assurance for pipeline outputs.
 */
export class QAEngine {
  constructor(bus) {
    this._bus = bus;
    /** @type {Map<string, { rule: function, severity: string }>} */
    this._rules = new Map();
    this._passCount = 0;
    this._failCount = 0;
    log.debug('QAEngine initialized');
  }

  /**
   * Registers a QA rule
   * @param {string} name
   * @param {function} rule - (data) -> boolean or { pass: boolean, reason: string }
   * @param {'error'|'warning'|'info'} [severity='warning']
   */
  addRule(name, rule, severity = 'warning') {
    this._rules.set(name, { rule, severity });
    return this;
  }

  /**
   * Runs all QA rules against data
   * @param {unknown} data
   * @returns {Array<{ rule: string, pass: boolean, severity: string, reason?: string }>}
   */
  check(data) {
    const results = [];
    for (const [name, { rule, severity }] of this._rules) {
      try {
        const result = rule(data);
        const pass = typeof result === 'boolean' ? result : result.pass;
        const reason = typeof result === 'object' ? result.reason : undefined;

        if (pass) this._passCount++;
        else {
          this._failCount++;
          this._bus?.emit('qa:fail', { rule: name, severity, reason, data });
        }

        results.push({ rule: name, pass, severity, reason });
      } catch (err) {
        results.push({ rule: name, pass: false, severity: 'error', reason: err.message });
        this._failCount++;
      }
    }
    return results;
  }

  /** @returns {object} */
  stats() {
    return {
      rules: this._rules.size,
      passCount: this._passCount,
      failCount: this._failCount,
    };
  }
}

// ─── StoryDriver ──────────────────────────────────────────────────────────────

/**
 * @class StoryDriver
 * Narrative coherence engine — ensures system actions form coherent stories.
 */
export class StoryDriver {
  constructor(vectorMemory) {
    this._vectorMemory = vectorMemory;
    /** @type {Array<object>} Current narrative arc */
    this._arc = [];
    this._arcMax = 100;
    log.debug('StoryDriver initialized');
  }

  /**
   * Records a narrative event
   * @param {string} event
   * @param {object} [context]
   */
  narrate(event, context = {}) {
    this._arc.push({ event, context, ts: Date.now() });
    if (this._arc.length > this._arcMax) this._arc.shift();
  }

  /**
   * Returns the current narrative arc summary
   */
  currentArc() {
    return {
      length: this._arc.length,
      recent: this._arc.slice(-5).map(e => e.event),
      start: this._arc[0]?.ts ? new Date(this._arc[0].ts).toISOString() : null,
    };
  }
}

/**
 * Phase 5: Wire all engines
 * @param {import('../core/heady-server.js').HeadyApp} app
 * @param {object} globals - Phase 1-4 outputs
 * @returns {Promise<{
 *   mcScheduler: MonteCarloScheduler,
 *   patternEngine: PatternEngine,
 *   autoSuccess: AutoSuccess,
 *   scientist: Scientist,
 *   qa: QAEngine,
 *   storyDriver: StoryDriver,
 * }>}
 */
export async function initEngineWiring(app, globals) {
  log.info('∞ Phase 5: Initializing engine-wiring...');
  const start = Date.now();

  const { bus, vectorMemory } = globals;

  // Monte Carlo Scheduler
  const mcScheduler = new MonteCarloScheduler({
    simulations: 500,
    confidenceLevel: 0.90,
  });

  // Register common task models
  mcScheduler
    .registerTask('vector-ingest', { meanDuration: 50, stdDev: 10, successRate: 0.99, priority: 3 })
    .registerTask('pipeline-run', { meanDuration: 500, stdDev: 100, successRate: 0.97, priority: 2 })
    .registerTask('self-healing', { meanDuration: 2000, stdDev: 500, successRate: 0.95, priority: 5 })
    .registerTask('soul-align', { meanDuration: 1000, stdDev: 200, successRate: 0.99, priority: 4 });

  // Pattern Engine
  const patternEngine = new PatternEngine(bus);

  patternEngine
    .register('high-error-rate', {
      window: 60000,
      detect: (recent) => {
        const errors = recent.filter(o => o.type === 'error');
        return errors.length > 10 && errors.length / recent.length > 0.2;
      },
      respond: (recent) => {
        log.warn('High error rate pattern detected', { count: recent.filter(o => o.type === 'error').length });
      },
    })
    .register('memory-pressure', {
      window: 30000,
      detect: () => process.memoryUsage().heapUsed > 500 * 1024 * 1024,
      respond: () => {
        log.warn('Memory pressure detected — consider GC');
        if (global.gc) global.gc();
      },
    });

  // Wire pattern engine to bus events
  bus.onPattern('*:error', (event, data) => {
    patternEngine.observe('error', data, { event });
  });

  // AutoSuccess
  const autoSuccess = new AutoSuccess({ threshold: 0.85 });

  // Scientist
  const scientist = new Scientist(bus);

  // QA Engine
  const qa = new QAEngine(bus);
  qa
    .addRule('non-null-result', (data) => data !== null && data !== undefined, 'error')
    .addRule('no-error-field', (data) => typeof data !== 'object' || !('error' in data), 'warning')
    .addRule('reasonable-size', (data) => {
      const str = JSON.stringify(data) || '';
      return { pass: str.length < 1024 * 1024, reason: `Result too large: ${str.length} bytes` };
    }, 'warning');

  // Story Driver
  const storyDriver = new StoryDriver(vectorMemory);
  storyDriver.narrate('platform-boot', { version: '4.0.0', codename: 'Sovereign' });

  // Subscribe to bus to narrate key events
  bus.onPattern('phase:complete', (event, data) => {
    storyDriver.narrate('phase-complete', data);
  });

  const elapsed = Date.now() - start;
  log.info('✓ Phase 5 complete', { elapsed_ms: elapsed });
  bus.emit('phase:complete', { phase: 5, name: 'engine-wiring', elapsed });

  return { mcScheduler, patternEngine, autoSuccess, scientist, qa, storyDriver };
}

export default initEngineWiring;
