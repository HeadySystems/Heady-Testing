/**
 * ∞ Heady™ VectorStack — Phase 4 bootstrap: 384D vector memory, pipeline, federation, bees
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createLogger } from '../core/heady-logger.js';
import { HeadyKV } from '../core/heady-kv.js';
import { uuid, sha256 } from '../core/heady-crypt.js';

const log = createLogger('VectorStack');

/** Vector space dimensionality */
const VECTOR_DIM = 384;

/** Fibonacci sharding parameters */
const PHI = (1 + Math.sqrt(5)) / 2;
const SHARD_COUNT = 144; // F(12) — Fibonacci number

/**
 * Determines the shard index for a vector using Fibonacci hashing
 * @param {Float32Array} vector
 * @returns {number} Shard index [0, SHARD_COUNT)
 */
function fibonacciShard(vector) {
  // Use first 4 components of the vector as a composite key
  const key = vector.slice(0, 4).reduce((acc, v, i) => acc + v * Math.pow(PHI, i), 0);
  return Math.abs(Math.floor(key * SHARD_COUNT)) % SHARD_COUNT;
}

/**
 * Computes cosine similarity between two vectors
 * @param {Float32Array} a
 * @param {Float32Array} b
 * @returns {number} Similarity in [-1, 1]
 */
function cosineSimilarity(a, b) {
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

/**
 * @class VectorMemory
 * RAM-first 384-dimensional vector store with Fibonacci sharding and pgvector backup stub.
 */
export class VectorMemory {
  /**
   * @param {object} [options]
   * @param {number} [options.dimensions=384]
   * @param {number} [options.maxVectors=1000000]
   * @param {string} [options.namespace]
   */
  constructor(options = {}) {
    this.dimensions = options.dimensions || VECTOR_DIM;
    this.maxVectors = options.maxVectors || 1_000_000;
    this.namespace = options.namespace || 'default';

    /** @type {Map<string, { id: string, vector: Float32Array, metadata: object, createdAt: number }>} */
    this._vectors = new Map();

    /** @type {Map<number, Set<string>>} Shard -> vector ID set */
    this._shards = new Map();
    for (let i = 0; i < SHARD_COUNT; i++) this._shards.set(i, new Set());

    this._totalInserts = 0;
    this._totalQueries = 0;
  }

  /**
   * Inserts or updates a vector
   * @param {string} id - Unique vector ID
   * @param {number[]|Float32Array} vector - Must be VECTOR_DIM dimensions
   * @param {object} [metadata]
   * @returns {string} The ID
   */
  upsert(id, vector, metadata = {}) {
    if (vector.length !== this.dimensions) {
      throw new Error(`[VectorMemory] Vector must be ${this.dimensions}D, got ${vector.length}D`);
    }

    const vecId = id || uuid();
    const f32 = vector instanceof Float32Array ? vector : new Float32Array(vector);

    // Remove from old shard if updating
    if (this._vectors.has(vecId)) {
      const old = this._vectors.get(vecId);
      const oldShard = fibonacciShard(old.vector);
      this._shards.get(oldShard)?.delete(vecId);
    }

    const shard = fibonacciShard(f32);
    this._shards.get(shard)?.add(vecId);

    this._vectors.set(vecId, {
      id: vecId,
      vector: f32,
      metadata: { ...metadata, namespace: this.namespace },
      createdAt: Date.now(),
    });

    this._totalInserts++;
    return vecId;
  }

  /**
   * Performs approximate nearest-neighbor search
   * @param {number[]|Float32Array} queryVector
   * @param {object} [options]
   * @param {number} [options.k=10] - Top-k results
   * @param {number} [options.threshold=0.5] - Minimum similarity
   * @param {object} [options.filter] - Metadata filter
   * @returns {Array<{ id: string, score: number, metadata: object }>}
   */
  query(queryVector, options = {}) {
    const k = options.k || 10;
    const threshold = options.threshold || 0.0;
    const filter = options.filter;

    const q = queryVector instanceof Float32Array
      ? queryVector
      : new Float32Array(queryVector);

    if (q.length !== this.dimensions) {
      throw new Error(`[VectorMemory] Query must be ${this.dimensions}D`);
    }

    this._totalQueries++;

    // Fibonacci shard pruning: only search relevant shards
    const queryShard = fibonacciShard(q);
    const nearbyShards = new Set([
      queryShard,
      (queryShard + 1) % SHARD_COUNT,
      (queryShard - 1 + SHARD_COUNT) % SHARD_COUNT,
      Math.floor(queryShard / 2),
      (queryShard * 2) % SHARD_COUNT,
    ]);

    const candidates = [];
    for (const shard of nearbyShards) {
      for (const id of (this._shards.get(shard) || [])) {
        candidates.push(id);
      }
    }

    // If too few candidates, scan all
    const searchIds = candidates.length < k * 3
      ? [...this._vectors.keys()]
      : candidates;

    const results = [];
    for (const id of searchIds) {
      const entry = this._vectors.get(id);
      if (!entry) continue;

      // Apply metadata filter
      if (filter) {
        const meta = entry.metadata;
        if (!Object.entries(filter).every(([k, v]) => meta[k] === v)) continue;
      }

      const score = cosineSimilarity(q, entry.vector);
      if (score >= threshold) {
        results.push({ id, score, metadata: entry.metadata });
      }
    }

    return results
      .sort((a, b) => b.score - a.score)
      .slice(0, k);
  }

  /**
   * Retrieves a vector entry by ID
   * @param {string} id
   * @returns {object|null}
   */
  get(id) {
    return this._vectors.get(id) || null;
  }

  /**
   * Deletes a vector
   * @param {string} id
   * @returns {boolean}
   */
  delete(id) {
    const entry = this._vectors.get(id);
    if (!entry) return false;
    const shard = fibonacciShard(entry.vector);
    this._shards.get(shard)?.delete(id);
    return this._vectors.delete(id);
  }

  /** @returns {object} Diagnostics */
  stats() {
    return {
      dimensions: this.dimensions,
      count: this._vectors.size,
      maxVectors: this.maxVectors,
      shards: SHARD_COUNT,
      totalInserts: this._totalInserts,
      totalQueries: this._totalQueries,
      namespace: this.namespace,
    };
  }
}

/**
 * @class VectorPipeline
 * Transforms and routes data through the vector space.
 */
export class VectorPipeline {
  constructor(memory) {
    this._memory = memory;
    this._transforms = [];
    log.debug('VectorPipeline initialized');
  }

  /**
   * Adds a transform function to the pipeline
   * @param {function} fn - (vector, metadata) -> { vector, metadata }
   */
  addTransform(fn) {
    this._transforms.push(fn);
    return this;
  }

  /**
   * Processes a vector through all transforms and upserts
   * @param {string} id
   * @param {number[]} vector
   * @param {object} [metadata]
   */
  async process(id, vector, metadata = {}) {
    let v = vector;
    let m = metadata;

    for (const transform of this._transforms) {
      const result = await transform(v, m);
      v = result.vector ?? v;
      m = result.metadata ?? m;
    }

    return this._memory.upsert(id, v, m);
  }
}

/**
 * @class VectorFederation
 * Coordinates vector memory across multiple namespaces/nodes.
 */
export class VectorFederation {
  constructor() {
    /** @type {Map<string, VectorMemory>} */
    this._nodes = new Map();
    log.debug('VectorFederation initialized');
  }

  /**
   * Registers a VectorMemory node under a namespace
   * @param {string} namespace
   * @param {VectorMemory} memory
   */
  register(namespace, memory) {
    this._nodes.set(namespace, memory);
    log.debug('Federation node registered', { namespace });
    return this;
  }

  /**
   * Federated query across all registered nodes
   * @param {number[]} vector
   * @param {object} [options]
   * @returns {Array<{ id: string, score: number, metadata: object, namespace: string }>}
   */
  query(vector, options = {}) {
    const k = options.k || 10;
    const allResults = [];

    for (const [namespace, memory] of this._nodes) {
      const results = memory.query(vector, { ...options, k });
      for (const r of results) {
        allResults.push({ ...r, namespace });
      }
    }

    return allResults
      .sort((a, b) => b.score - a.score)
      .slice(0, k);
  }

  /** @returns {object} */
  stats() {
    const nodes = {};
    for (const [ns, mem] of this._nodes) nodes[ns] = mem.stats();
    return { nodes, count: this._nodes.size };
  }
}

/**
 * @class BeeFactory
 * Manages worker bee instances for distributed vector tasks.
 */
export class BeeFactory {
  constructor(bus) {
    this._bus = bus;
    /** @type {Map<string, object>} */
    this._bees = new Map();
    this._registry = new Map();
    log.debug('BeeFactory initialized');
  }

  /**
   * Registers a bee worker definition
   * @param {string} name
   * @param {object} def - { fn, schedule?, concurrency? }
   */
  register(name, def) {
    this._registry.set(name, { name, ...def, active: false, runs: 0, errors: 0 });
    log.debug('Bee registered', { name });
    return this;
  }

  /**
   * Dispatches a task to a bee
   * @param {string} beeName
   * @param {object} payload
   * @returns {Promise<unknown>}
   */
  async dispatch(beeName, payload) {
    const bee = this._registry.get(beeName);
    if (!bee) throw new Error(`[BeeFactory] Unknown bee: ${beeName}`);
    bee.runs++;
    try {
      const result = await bee.fn(payload, { bus: this._bus });
      this._bus?.emit(`bee:${beeName}:success`, { payload, result });
      return result;
    } catch (err) {
      bee.errors++;
      this._bus?.emit(`bee:${beeName}:error`, { payload, error: err.message });
      throw err;
    }
  }

  /**
   * Returns all registered bees and their stats
   */
  status() {
    return Array.from(this._registry.values()).map(b => ({
      name: b.name,
      runs: b.runs,
      errors: b.errors,
      active: b.active,
    }));
  }
}

/**
 * @class BuddyCore
 * Social intelligence layer — manages buddy relationships and shared context.
 */
export class BuddyCore {
  constructor(memory) {
    this._memory = memory;
    this._relationships = new Map();
    log.debug('BuddyCore initialized');
  }

  /**
   * Records a buddy relationship
   * @param {string} fromId
   * @param {string} toId
   * @param {number} strength - Affinity [0, 1]
   */
  relate(fromId, toId, strength = 0.5) {
    const key = `${fromId}:${toId}`;
    this._relationships.set(key, { fromId, toId, strength, updatedAt: Date.now() });
  }

  /**
   * Finds buddies related to a given vector ID
   * @param {string} id
   * @param {number} [k=5]
   * @returns {Array<object>}
   */
  findBuddies(id, k = 5) {
    const results = [];
    for (const [, rel] of this._relationships) {
      if (rel.fromId === id) results.push(rel);
    }
    return results.sort((a, b) => b.strength - a.strength).slice(0, k);
  }
}

/**
 * @class SelfAwareness
 * Platform introspection layer — monitors its own state.
 */
export class SelfAwareness {
  constructor(bus, kv) {
    this._bus = bus;
    this._kv = kv;
    this._metrics = new Map();
    this._startTime = Date.now();
    log.debug('SelfAwareness initialized');
  }

  /**
   * Records a metric observation
   * @param {string} name
   * @param {number} value
   * @param {object} [tags]
   */
  observe(name, value, tags = {}) {
    const series = this._metrics.get(name) || [];
    series.push({ value, ts: Date.now(), tags });
    if (series.length > 1000) series.shift(); // ring buffer
    this._metrics.set(name, series);
  }

  /**
   * Returns platform self-awareness report
   */
  report() {
    const uptime = Date.now() - this._startTime;
    const metricsSnapshot = {};
    for (const [name, series] of this._metrics) {
      const last = series[series.length - 1];
      const avg = series.slice(-10).reduce((s, m) => s + m.value, 0) / Math.min(series.length, 10);
      metricsSnapshot[name] = { last: last?.value, avg: avg.toFixed(2), count: series.length };
    }
    return {
      uptime,
      uptimeHuman: `${Math.floor(uptime / 3600000)}h ${Math.floor((uptime % 3600000) / 60000)}m`,
      metrics: metricsSnapshot,
      memoryMb: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2),
    };
  }
}

/**
 * @class Watchdog
 * Health monitoring and automatic recovery.
 */
export class Watchdog {
  constructor(bus) {
    this._bus = bus;
    this._checks = new Map();
    this._failures = new Map();
    log.debug('Watchdog initialized');
  }

  /**
   * Registers a health check
   * @param {string} name
   * @param {function(): Promise<boolean>} fn
   * @param {object} [options]
   */
  register(name, fn, options = {}) {
    this._checks.set(name, { fn, options, lastResult: null, lastRun: null });
    return this;
  }

  /**
   * Runs all health checks
   * @returns {Promise<Record<string, { healthy: boolean, error?: string, latency: number }>>}
   */
  async runAll() {
    const results = {};
    for (const [name, check] of this._checks) {
      const start = Date.now();
      try {
        const healthy = await check.fn();
        const latency = Date.now() - start;
        results[name] = { healthy: Boolean(healthy), latency };
        check.lastResult = healthy;
        check.lastRun = Date.now();
        if (!healthy) {
          this._bus?.emit('watchdog:unhealthy', { name, latency });
        }
      } catch (err) {
        const latency = Date.now() - start;
        results[name] = { healthy: false, error: err.message, latency };
        this._bus?.emit('watchdog:error', { name, error: err.message, latency });
      }
    }
    return results;
  }
}

/**
 * Phase 4: Initialize and wire the vector stack
 * @param {import('../core/heady-server.js').HeadyApp} app
 * @param {object} globals - Phase 1 + 3 outputs
 * @returns {Promise<{
 *   vectorMemory: VectorMemory,
 *   vectorPipeline: VectorPipeline,
 *   vectorFederation: VectorFederation,
 *   beeFactory: BeeFactory,
 *   buddyCore: BuddyCore,
 *   selfAwareness: SelfAwareness,
 *   watchdog: Watchdog,
 * }>}
 */
export async function initVectorStack(app, globals) {
  log.info('∞ Phase 4: Initializing vector-stack...');
  const start = Date.now();

  const { bus, env, edgeCache } = globals;

  // Primary vector memory (RAM-first)
  const vectorMemory = new VectorMemory({
    dimensions: VECTOR_DIM,
    maxVectors: env.getInt('HEADY_VECTOR_MAX', 1_000_000),
    namespace: 'primary',
  });

  // Secondary namespaced memories
  const episodicMemory = new VectorMemory({ dimensions: VECTOR_DIM, namespace: 'episodic' });
  const semanticMemory = new VectorMemory({ dimensions: VECTOR_DIM, namespace: 'semantic' });
  const workingMemory = new VectorMemory({ dimensions: VECTOR_DIM, namespace: 'working' });

  // Pipeline
  const vectorPipeline = new VectorPipeline(vectorMemory);
  vectorPipeline.addTransform(async (vector, metadata) => {
    // Normalize vector (L2 normalization)
    const norm = Math.sqrt(vector.reduce((s, v) => s + v * v, 0));
    const normalized = norm > 0 ? vector.map(v => v / norm) : vector;
    return { vector: normalized, metadata: { ...metadata, normalized: true } };
  });

  // Federation
  const vectorFederation = new VectorFederation();
  vectorFederation
    .register('primary', vectorMemory)
    .register('episodic', episodicMemory)
    .register('semantic', semanticMemory)
    .register('working', workingMemory);

  // Bee factory
  const beeFactory = new BeeFactory(bus);

  // Register built-in bees
  beeFactory.register('vector-ingest', {
    fn: async ({ id, vector, metadata }) => vectorPipeline.process(id, vector, metadata),
  });
  beeFactory.register('vector-query', {
    fn: async ({ vector, k, threshold }) => vectorMemory.query(vector, { k, threshold }),
  });
  beeFactory.register('vector-federated-query', {
    fn: async ({ vector, k }) => vectorFederation.query(vector, { k }),
  });

  // BuddyCore
  const buddyCore = new BuddyCore(vectorMemory);

  // SelfAwareness
  const selfAwareness = new SelfAwareness(bus, edgeCache);

  // Start self-monitoring interval
  const monitorInterval = setInterval(() => {
    const usage = process.memoryUsage();
    selfAwareness.observe('heap_used', usage.heapUsed);
    selfAwareness.observe('heap_total', usage.heapTotal);
    selfAwareness.observe('vector_count', vectorMemory._vectors.size);
    bus.emit('awareness:pulse', selfAwareness.report());
  }, 30000);
  monitorInterval.unref?.();

  // Watchdog
  const watchdog = new Watchdog(bus);
  watchdog.register('vector-memory', async () => vectorMemory._vectors !== null);
  watchdog.register('bus', async () => bus !== null);
  watchdog.register('event-loop', async () => {
    const start = Date.now();
    await new Promise(r => setImmediate(r));
    return (Date.now() - start) < 1000; // Event loop healthy if lag < 1s
  });

  const elapsed = Date.now() - start;
  log.info('✓ Phase 4 complete', {
    elapsed_ms: elapsed,
    dimensions: VECTOR_DIM,
    shards: SHARD_COUNT,
    namespaces: 4,
  });
  bus.emit('phase:complete', { phase: 4, name: 'vector-stack', elapsed });

  return {
    vectorMemory,
    vectorPipeline,
    vectorFederation,
    episodicMemory,
    semanticMemory,
    workingMemory,
    beeFactory,
    buddyCore,
    selfAwareness,
    watchdog,
  };
}

export { VECTOR_DIM, SHARD_COUNT, fibonacciShard, cosineSimilarity };
export default initVectorStack;
