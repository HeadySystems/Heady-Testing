/**
 * ∞ Heady™ ServiceRegistry — Phase 7 bootstrap: graceful service module mounting (40+ routes)
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createLogger } from '../core/heady-logger.js';
import { createRouter } from '../core/heady-server.js';

const log = createLogger('ServiceRegistry');

/**
 * @typedef {object} ServiceDefinition
 * @property {string} name - Service name for logging
 * @property {string} mount - URL path prefix (e.g. '/api/v4/vectors')
 * @property {string} module - Module path (relative to project root)
 * @property {boolean} [required=false] - If true, failure halts bootstrap
 * @property {string} [description] - Human-readable description
 */

/** Ordered list of all services to mount */
const SERVICE_CATALOG = [
  // Core API
  { name: 'vectors', mount: '/api/v4/vectors', module: './services/vectors.js', description: 'Vector memory CRUD + query' },
  { name: 'pipeline', mount: '/api/v4/pipeline', module: './services/pipeline.js', description: 'Pipeline execution and status' },
  { name: 'memory', mount: '/api/v4/memory', module: './services/memory.js', description: 'Episodic/semantic/working memory' },
  { name: 'bees', mount: '/api/v4/bees', module: './services/bees.js', description: 'Bee worker dispatch and status' },
  { name: 'buddies', mount: '/api/v4/buddies', module: './services/buddies.js', description: 'Buddy relationships' },
  { name: 'soul', mount: '/api/v4/soul', module: './services/soul.js', description: 'HeadySoul values and awareness' },
  { name: 'conductor', mount: '/api/v4/conductor', module: './services/conductor.js', description: 'HeadyConductor orchestration' },
  { name: 'orchestrator', mount: '/api/v4/orchestrator', module: './services/orchestrator.js', description: 'HeadyOrchestrator operations' },

  // Intelligence
  { name: 'patterns', mount: '/api/v4/patterns', module: './services/patterns.js', description: 'Pattern detection and rules' },
  { name: 'monte-carlo', mount: '/api/v4/monte-carlo', module: './services/monte-carlo.js', description: 'Monte Carlo scheduler' },
  { name: 'auto-success', mount: '/api/v4/auto-success', module: './services/auto-success.js', description: 'AutoSuccess evaluator' },
  { name: 'scientist', mount: '/api/v4/scientist', module: './services/scientist.js', description: 'A/B experiment runner' },
  { name: 'qa', mount: '/api/v4/qa', module: './services/qa.js', description: 'QA rule engine' },
  { name: 'story', mount: '/api/v4/story', module: './services/story.js', description: 'Narrative arc engine' },

  // Platform
  { name: 'scheduler', mount: '/api/v4/scheduler', module: './services/scheduler.js', description: 'Cron/interval scheduler' },
  { name: 'events', mount: '/api/v4/events', module: './services/events.js', description: 'Event bus and history' },
  { name: 'kv', mount: '/api/v4/kv', module: './services/kv.js', description: 'Key-value store API' },
  { name: 'config', mount: '/api/v4/config', module: './services/config.js', description: 'Runtime config management' },
  { name: 'secrets', mount: '/api/v4/secrets', module: './services/secrets.js', description: 'Secrets management API' },

  // Integrations
  { name: 'github', mount: '/api/v4/github', module: './services/github.js', description: 'GitHub/Octokit integration' },
  { name: 'mcp', mount: '/api/v4/mcp', module: './services/mcp.js', description: 'Model Context Protocol bridge' },
  { name: 'cloudflare', mount: '/api/v4/cloudflare', module: './services/cloudflare.js', description: 'Cloudflare integration' },
  { name: 'neon', mount: '/api/v4/neon', module: './services/neon.js', description: 'Neon database bridge' },
  { name: 'openai', mount: '/api/v4/models/openai', module: './services/openai.js', description: 'OpenAI model bridge' },
  { name: 'anthropic', mount: '/api/v4/models/anthropic', module: './services/anthropic.js', description: 'Anthropic model bridge' },

  // Voice
  { name: 'voice', mount: '/api/v4/voice', module: './services/voice.js', description: 'Voice relay and synthesis' },
  { name: 'transcription', mount: '/api/v4/transcription', module: './services/transcription.js', description: 'Speech-to-text' },

  // Content
  { name: 'strains', mount: '/api/v4/strains', module: './services/strains.js', description: 'Strain catalog' },
  { name: 'dispensaries', mount: '/api/v4/dispensaries', module: './services/dispensaries.js', description: 'Dispensary data' },
  { name: 'menus', mount: '/api/v4/menus', module: './services/menus.js', description: 'Dispensary menu ingestion' },
  { name: 'deals', mount: '/api/v4/deals', module: './services/deals.js', description: 'Deals and promotions' },
  { name: 'reviews', mount: '/api/v4/reviews', module: './services/reviews.js', description: 'User reviews' },
  { name: 'recommendations', mount: '/api/v4/recommendations', module: './services/recommendations.js', description: 'AI recommendations' },
  { name: 'search', mount: '/api/v4/search', module: './services/search.js', description: 'Semantic search' },
  { name: 'categories', mount: '/api/v4/categories', module: './services/categories.js', description: 'Product categories' },
  { name: 'brands', mount: '/api/v4/brands', module: './services/brands.js', description: 'Brand registry' },

  // Users
  { name: 'users', mount: '/api/v4/users', module: './services/users.js', description: 'User profiles' },
  { name: 'preferences', mount: '/api/v4/preferences', module: './services/preferences.js', description: 'User preferences' },
  { name: 'history', mount: '/api/v4/history', module: './services/history.js', description: 'User history' },
  { name: 'notifications', mount: '/api/v4/notifications', module: './services/notifications.js', description: 'Notifications' },

  // Analytics
  { name: 'analytics', mount: '/api/v4/analytics', module: './services/analytics.js', description: 'Platform analytics' },
  { name: 'metrics', mount: '/api/v4/metrics', module: './services/metrics.js', description: 'Prometheus-compatible metrics' },
  { name: 'traces', mount: '/api/v4/traces', module: './services/traces.js', description: 'Distributed traces' },
  { name: 'logs', mount: '/api/v4/logs', module: './services/logs.js', description: 'Log streaming API' },

  // Resilience
  { name: 'circuit-breakers', mount: '/api/v4/circuit-breakers', module: './services/circuit-breakers.js', description: 'Circuit breaker states' },
  { name: 'self-healing', mount: '/api/v4/self-healing', module: './services/self-healing.js', description: 'Self-healing status' },
  { name: 'watchdog', mount: '/api/v4/watchdog', module: './services/watchdog.js', description: 'Watchdog health checks' },
];

/**
 * Creates a stub router for a service that isn't yet implemented.
 * Returns informative 503 responses with service metadata.
 * @param {ServiceDefinition} service
 * @returns {import('../core/heady-server.js').HeadyRouter}
 */
function createStubRouter(service) {
  const router = createRouter();
  router.all('/*', (req, res) => {
    res.statusCode = 503;
    res.json({
      error: 'Service Not Implemented',
      service: service.name,
      description: service.description,
      mount: service.mount,
      platform: 'HeadySovereign/4.0.0',
      doc: `https://docs.heady.ai/api/v4/${service.name}`,
    });
  });
  return router;
}

/**
 * Attempts to dynamically import a service module
 * @param {string} modulePath
 * @returns {Promise<object|null>}
 */
async function tryImport(modulePath) {
  try {
    // Convert relative path to absolute for dynamic import
    const { createRequire } = await import('module');
    const require = createRequire(import.meta.url);
    // Try require first (sync CJS fallback)
    return require(modulePath);
  } catch {
    try {
      // Try dynamic ESM import
      return await import(modulePath);
    } catch {
      return null;
    }
  }
}

/**
 * @class ServiceRegistry
 * Manages service module mounting with graceful degradation.
 */
export class ServiceRegistry {
  constructor(app, globals) {
    this._app = app;
    this._globals = globals;
    /** @type {Map<string, { mounted: boolean, error?: string, stub: boolean }>} */
    this._registry = new Map();
  }

  /**
   * Mounts all services from the catalog
   * @returns {Promise<{ mounted: number, stubbed: number, errors: string[] }>}
   */
  async mountAll() {
    let mounted = 0;
    let stubbed = 0;
    const errors = [];

    for (const service of SERVICE_CATALOG) {
      try {
        // Try to load the real module
        const mod = await tryImport(service.module);

        if (mod && (mod.router || mod.default?.router || typeof mod.default === 'function')) {
          const router = mod.router || mod.default?.router || mod.default;
          this._app.use(service.mount, router);
          this._registry.set(service.name, { mounted: true, stub: false });
          mounted++;
          log.debug('Service mounted', { name: service.name, mount: service.mount });
        } else {
          // Module loaded but no router — use stub
          this._app.use(service.mount, createStubRouter(service));
          this._registry.set(service.name, { mounted: true, stub: true });
          stubbed++;
          log.debug('Service stubbed (no router)', { name: service.name });
        }
      } catch (err) {
        // Graceful degradation — stub any service that fails to load
        const errMsg = `${service.name}: ${err.message}`;
        errors.push(errMsg);

        if (service.required) {
          log.error('Required service failed to mount', { name: service.name, error: err.message });
          throw new Error(`[ServiceRegistry] Required service failed: ${errMsg}`);
        }

        this._app.use(service.mount, createStubRouter(service));
        this._registry.set(service.name, { mounted: true, stub: true, error: err.message });
        stubbed++;
        log.debug('Service stubbed (load error)', { name: service.name });
      }
    }

    return { mounted, stubbed, errors, total: SERVICE_CATALOG.length };
  }

  /**
   * Returns the current service registry state
   * @returns {Array<object>}
   */
  status() {
    return SERVICE_CATALOG.map(s => ({
      name: s.name,
      mount: s.mount,
      description: s.description,
      ...(this._registry.get(s.name) || { mounted: false, stub: true }),
    }));
  }
}

/**
 * Phase 7: Mount all service route modules
 * @param {import('../core/heady-server.js').HeadyApp} app
 * @param {object} globals
 * @returns {Promise<{ serviceRegistry: ServiceRegistry, serviceStats: object }>}
 */
export async function initServiceRegistry(app, globals) {
  log.info('∞ Phase 7: Initializing service-registry...');
  const start = Date.now();

  const { bus } = globals;
  const registry = new ServiceRegistry(app, globals);
  const serviceStats = await registry.mountAll();

  const elapsed = Date.now() - start;
  log.info('✓ Phase 7 complete', {
    elapsed_ms: elapsed,
    total: serviceStats.total,
    mounted: serviceStats.mounted,
    stubbed: serviceStats.stubbed,
    errors: serviceStats.errors.length,
  });

  bus?.emit('phase:complete', { phase: 7, name: 'service-registry', elapsed, ...serviceStats });

  return { serviceRegistry: registry, serviceStats };
}

export { SERVICE_CATALOG, createStubRouter };
export default initServiceRegistry;
