/**
 * ∞ Heady™ ServerBoot — Phase 10 bootstrap: HTTP + WS server, graceful shutdown, port retry
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

import { createServer } from 'http';
import { createLogger } from '../core/heady-logger.js';

const log = createLogger('ServerBoot');

/**
 * @typedef {object} ShutdownTask
 * @property {string} name - Task name for logging
 * @property {number} order - Priority order (higher = runs first — LIFO)
 * @property {function(): Promise<void>|void} fn - Cleanup function
 * @property {number} [timeout=5000] - Max time for this task
 */

/**
 * @class GracefulShutdown
 * Manages LIFO (Last In, First Out) cleanup of all platform components on shutdown.
 */
export class GracefulShutdown {
  /**
   * @param {object} [options]
   * @param {number} [options.hardTimeout=30000] - Maximum total shutdown time in ms
   */
  constructor(options = {}) {
    this._hardTimeout = options.hardTimeout || 30000;
    /** @type {ShutdownTask[]} */
    this._tasks = [];
    this._isShuttingDown = false;
    this._shutdownPromise = null;
  }

  /**
   * Registers a shutdown task
   * @param {string} name
   * @param {function(): Promise<void>|void} fn
   * @param {object} [options]
   * @param {number} [options.order=0] - Higher order runs first
   * @param {number} [options.timeout=5000]
   * @returns {this}
   */
  register(name, fn, options = {}) {
    this._tasks.push({
      name,
      fn,
      order: options.order ?? 0,
      timeout: options.timeout ?? 5000,
    });
    return this;
  }

  /**
   * Executes graceful shutdown (LIFO by order)
   * @param {string} [signal='SIGTERM']
   * @returns {Promise<void>}
   */
  async shutdown(signal = 'SIGTERM') {
    if (this._shutdownPromise) return this._shutdownPromise;

    this._isShuttingDown = true;
    this._shutdownPromise = this._execute(signal);
    return this._shutdownPromise;
  }

  /**
   * @param {string} signal
   */
  async _execute(signal) {
    log.info('∞ Graceful shutdown initiated', { signal, tasks: this._tasks.length });

    // Sort LIFO: highest order first
    const sorted = [...this._tasks].sort((a, b) => b.order - a.order);

    // Hard timeout
    const hardTimer = setTimeout(() => {
      log.fatal('Shutdown hard timeout — forcing exit', { timeout: this._hardTimeout });
      process.exit(1);
    }, this._hardTimeout);
    hardTimer.unref?.();

    for (const task of sorted) {
      const taskStart = Date.now();
      try {
        await Promise.race([
          Promise.resolve(task.fn()),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error(`Shutdown task timeout: ${task.name}`)), task.timeout)
          ),
        ]);
        log.debug('Shutdown task complete', {
          name: task.name,
          elapsed_ms: Date.now() - taskStart,
        });
      } catch (err) {
        log.warn('Shutdown task failed', { name: task.name, error: err.message });
      }
    }

    clearTimeout(hardTimer);
    log.info('✓ Graceful shutdown complete');
  }

  /** @returns {boolean} */
  get isShuttingDown() { return this._isShuttingDown; }
}

/**
 * Attempts to start an HTTP server on the given port.
 * Retries on EADDRINUSE with incrementing port numbers.
 * @param {import('http').Server} server
 * @param {number} port
 * @param {string} host
 * @param {number} [maxRetries=5]
 * @returns {Promise<number>} The actual port bound
 */
function bindWithRetry(server, port, host, maxRetries = 5) {
  return new Promise((resolve, reject) => {
    let attempt = 0;
    let currentPort = port;

    const tryBind = () => {
      attempt++;

      const errorHandler = (err) => {
        if (err.code === 'EADDRINUSE') {
          if (attempt >= maxRetries) {
            reject(new Error(`[ServerBoot] All ports ${port}-${port + maxRetries - 1} in use`));
            return;
          }
          log.warn('Port in use, retrying', { port: currentPort, nextPort: currentPort + 1 });
          currentPort++;
          server.removeListener('error', errorHandler);
          setTimeout(tryBind, 100);
        } else {
          reject(err);
        }
      };

      server.once('error', errorHandler);
      server.listen(currentPort, host, () => {
        server.removeListener('error', errorHandler);
        resolve(currentPort);
      });
    };

    tryBind();
  });
}

/**
 * Phase 10: Boot the HTTP server and wire graceful shutdown
 * @param {import('../core/heady-server.js').HeadyApp} app
 * @param {object} globals - All previous phase outputs
 * @returns {Promise<{ server: import('http').Server, shutdown: GracefulShutdown, port: number }>}
 */
export async function initServerBoot(app, globals) {
  log.info('∞ Phase 10: Initializing server-boot...');
  const start = Date.now();

  const { env, bus, voiceRelay } = globals;

  const port = env?.port || 3000;
  const host = env?.getString?.('HEADY_HOST', '0.0.0.0') || '0.0.0.0';

  // Create HTTP server using the HeadyApp dispatcher
  const server = createServer((req, res) => {
    app.dispatch(req, res).catch(err => {
      log.error('Server dispatch error', { error: err.message });
      if (!res.headersSent) {
        res.statusCode = 500;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({ error: 'Internal Server Error', platform: 'HeadySovereign/4.0.0' }));
      }
    });
  });

  // WebSocket upgrade handling
  server.on('upgrade', (req, socket, head) => {
    if (voiceRelay) {
      voiceRelay.handleUpgrade(req, socket, head).catch(err => {
        log.error('WS upgrade error', { error: err.message });
        socket.destroy();
      });
    } else {
      socket.write('HTTP/1.1 501 Not Implemented\r\n\r\n');
      socket.destroy();
    }
  });

  // Bind with retry logic
  const boundPort = await bindWithRetry(server, port, host, 5);

  // ─── Graceful Shutdown Setup ───────────────────────────────────────────────

  const gracefulShutdown = new GracefulShutdown({ hardTimeout: 30000 });

  // LIFO shutdown tasks — registered in boot order, executed in reverse

  // Phase 10: Stop accepting new connections (first to shut down)
  gracefulShutdown.register('http-server', async () => {
    await new Promise((resolve) => server.close(resolve));
    log.info('HTTP server closed');
  }, { order: 10, timeout: 10000 });

  // Phase 9: Voice relay
  gracefulShutdown.register('voice-relay', async () => {
    voiceRelay?.destroy?.();
    log.info('Voice relay destroyed');
  }, { order: 9, timeout: 5000 });

  // Phase 8: Services (flush any pending operations)
  gracefulShutdown.register('services', async () => {
    log.info('Services flushed');
  }, { order: 8, timeout: 5000 });

  // Phase 7: Pipeline (complete in-flight runs)
  gracefulShutdown.register('pipeline', async () => {
    const p = globals.pipeline;
    if (p) {
      log.info('Pipeline shutdown', { inFlight: p._runCount });
    }
  }, { order: 7, timeout: 10000 });

  // Phase 6: Self-healing mesh
  gracefulShutdown.register('self-healing', async () => {
    log.info('Self-healing mesh shutdown');
  }, { order: 6, timeout: 3000 });

  // Phase 5: Engines
  gracefulShutdown.register('engines', async () => {
    globals.mcScheduler && log.debug('MC scheduler shutdown');
  }, { order: 5, timeout: 3000 });

  // Phase 4: Vector stack (flush to pgvector backup)
  gracefulShutdown.register('vector-stack', async () => {
    const stats = globals.vectorMemory?.stats?.();
    log.info('Vector stack shutdown', { vectors: stats?.count });
  }, { order: 4, timeout: 10000 });

  // Phase 3: Auth engine
  gracefulShutdown.register('auth-engine', async () => {
    log.info('Auth engine shutdown');
  }, { order: 3, timeout: 2000 });

  // Phase 2: Middleware
  gracefulShutdown.register('middleware', async () => {
    log.info('Middleware stack shutdown');
  }, { order: 2, timeout: 2000 });

  // Phase 1: Event bus (last — flush all pending events)
  gracefulShutdown.register('event-bus', async () => {
    globals.bus?.destroy?.();
    log.info('Event bus shutdown');
  }, { order: 1, timeout: 3000 });

  // Phase 0: Logger flush
  gracefulShutdown.register('logger', () => {
    log.info('∞ HeadySovereign shutdown complete — may your vectors live on');
  }, { order: 0, timeout: 1000 });

  // Signal handlers
  const handleSignal = async (signal) => {
    if (gracefulShutdown.isShuttingDown) return;
    log.info(`Signal received: ${signal}`);
    await gracefulShutdown.shutdown(signal);
    process.exit(0);
  };

  process.once('SIGTERM', () => handleSignal('SIGTERM'));
  process.once('SIGINT', () => handleSignal('SIGINT'));
  process.once('SIGUSR2', () => handleSignal('SIGUSR2')); // nodemon restart

  // Unhandled rejection handler
  process.on('unhandledRejection', (reason, promise) => {
    log.error('Unhandled promise rejection', {
      reason: reason instanceof Error ? reason.message : String(reason),
    });
    bus?.emit('process:unhandledRejection', { reason, promise });
  });

  process.on('uncaughtException', (err) => {
    log.fatal('Uncaught exception', { error: err.message, stack: err.stack });
    bus?.emit('process:uncaughtException', { error: err });
    // Attempt graceful shutdown
    gracefulShutdown.shutdown('uncaughtException').finally(() => process.exit(1));
  });

  const elapsed = Date.now() - start;
  log.info(`✓ Phase 10 complete — HeadySovereign v4.0.0 "Sovereign" is alive`, {
    port: boundPort,
    host,
    elapsed_ms: elapsed,
    pid: process.pid,
    node: process.version,
  });

  bus?.emit('phase:complete', { phase: 10, name: 'server-boot', elapsed });
  bus?.emit('platform:ready', {
    version: '4.0.0',
    codename: 'Sovereign',
    port: boundPort,
    host,
    pid: process.pid,
  });

  return { server, shutdown: gracefulShutdown, port: boundPort, host };
}

export default initServerBoot;
