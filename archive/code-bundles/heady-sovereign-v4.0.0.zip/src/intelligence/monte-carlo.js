/**
 * ∞ Heady™ Monte Carlo — Monte Carlo Simulation Engine
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

const EventEmitter = require('events');

// ─────────────────────────────────────────────
// Probability Distributions
// ─────────────────────────────────────────────

/**
 * Seeded pseudo-random number generator (mulberry32).
 * @param {number} [seed]
 * @returns {() => number} Returns a function producing [0, 1)
 */
function createRng(seed) {
  let s = (seed ?? Date.now()) >>> 0;
  return function rng() {
    s += 0x6D2B79F5;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Probability distribution samplers.
 * Each factory returns a function that samples from the distribution.
 */
const Distributions = {
  /**
   * Uniform distribution U(min, max).
   * @param {number} min
   * @param {number} max
   * @param {()=>number} rng
   * @returns {()=>number}
   */
  uniform(min, max, rng = Math.random) {
    if (min >= max) throw new RangeError(`uniform: min (${min}) must be < max (${max})`);
    return () => min + rng() * (max - min);
  },

  /**
   * Normal (Gaussian) distribution N(mean, stddev) via Box-Muller transform.
   * @param {number} mean
   * @param {number} stddev
   * @param {()=>number} rng
   * @returns {()=>number}
   */
  normal(mean, stddev, rng = Math.random) {
    if (stddev < 0) throw new RangeError(`normal: stddev must be >= 0`);
    let spare = null;
    return () => {
      if (spare !== null) { const v = spare; spare = null; return mean + stddev * v; }
      let u, v, s;
      do {
        u = rng() * 2 - 1;
        v = rng() * 2 - 1;
        s = u * u + v * v;
      } while (s >= 1 || s === 0);
      const mul = Math.sqrt(-2 * Math.log(s) / s);
      spare = v * mul;
      return mean + stddev * u * mul;
    };
  },

  /**
   * Exponential distribution Exp(lambda).
   * @param {number} lambda  Rate parameter
   * @param {()=>number} rng
   * @returns {()=>number}
   */
  exponential(lambda, rng = Math.random) {
    if (lambda <= 0) throw new RangeError(`exponential: lambda must be > 0`);
    return () => -Math.log(1 - rng()) / lambda;
  },

  /**
   * Poisson distribution Poisson(lambda) via Knuth algorithm.
   * @param {number} lambda  Expected count
   * @param {()=>number} rng
   * @returns {()=>number}
   */
  poisson(lambda, rng = Math.random) {
    if (lambda <= 0) throw new RangeError(`poisson: lambda must be > 0`);
    const L = Math.exp(-lambda);
    return () => {
      let k = 0, p = 1;
      do { k++; p *= rng(); } while (p > L);
      return k - 1;
    };
  },

  /**
   * Bernoulli distribution Bernoulli(p).
   * @param {number} probability  Success probability [0, 1]
   * @param {()=>number} rng
   * @returns {()=>boolean}
   */
  bernoulli(probability, rng = Math.random) {
    if (probability < 0 || probability > 1) throw new RangeError(`bernoulli: probability must be in [0, 1]`);
    return () => rng() < probability;
  },

  /**
   * Triangular distribution Tri(min, mode, max).
   * @param {number} min
   * @param {number} mode
   * @param {number} max
   * @param {()=>number} rng
   * @returns {()=>number}
   */
  triangular(min, mode, max, rng = Math.random) {
    if (min > mode || mode > max) throw new RangeError(`triangular: must have min <= mode <= max`);
    const fc = (mode - min) / (max - min);
    return () => {
      const u = rng();
      if (u < fc) return min + Math.sqrt(u * (max - min) * (mode - min));
      return max - Math.sqrt((1 - u) * (max - min) * (max - mode));
    };
  },
};

// ─────────────────────────────────────────────
// Statistics
// ─────────────────────────────────────────────

/**
 * Compute descriptive statistics from a sorted array.
 * @param {number[]} samples
 * @returns {object}
 */
function computeStats(samples) {
  if (samples.length === 0) return {};
  const sorted = [...samples].sort((a, b) => a - b);
  const n      = sorted.length;

  const mean = sorted.reduce((s, v) => s + v, 0) / n;
  const variance = sorted.reduce((s, v) => s + (v - mean) ** 2, 0) / n;
  const stddev   = Math.sqrt(variance);

  const pct = (p) => {
    const idx = p / 100 * (n - 1);
    const lo  = Math.floor(idx);
    const hi  = Math.ceil(idx);
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
  };

  return {
    count:    n,
    min:      sorted[0],
    max:      sorted[n - 1],
    mean:     mean,
    median:   pct(50),
    stddev:   stddev,
    variance: variance,
    p5:       pct(5),
    p25:      pct(25),
    p75:      pct(75),
    p95:      pct(95),
    p99:      pct(99),
  };
}

/**
 * Compute a 95% confidence interval for the mean.
 * @param {number} mean
 * @param {number} stddev
 * @param {number} n
 * @returns {{lower: number, upper: number, width: number}}
 */
function confidenceInterval95(mean, stddev, n) {
  // z = 1.96 for 95% CI
  const margin = 1.96 * (stddev / Math.sqrt(n));
  return { lower: mean - margin, upper: mean + margin, width: 2 * margin };
}

// ─────────────────────────────────────────────
// Histogram Builder
// ─────────────────────────────────────────────

/**
 * Build histogram data for visualization.
 * @param {number[]} samples
 * @param {number} [bins=20]
 * @returns {{bins: Array<{min: number, max: number, count: number, frequency: number}>}}
 */
function buildHistogram(samples, bins = 20) {
  if (samples.length === 0) return { bins: [] };
  const min  = Math.min(...samples);
  const max  = Math.max(...samples);
  const step = (max - min) / bins || 1;

  const counts = Array.from({ length: bins }, (_, i) => ({
    min: min + i * step,
    max: min + (i + 1) * step,
    count: 0,
    frequency: 0,
  }));

  for (const v of samples) {
    const i = Math.min(Math.floor((v - min) / step), bins - 1);
    counts[i].count++;
  }

  const total = samples.length;
  for (const b of counts) b.frequency = b.count / total;

  return { bins: counts };
}

/**
 * Build Cumulative Distribution Function data.
 * @param {number[]} samples
 * @param {number} [points=100]
 * @returns {Array<{x: number, cdf: number}>}
 */
function buildCDF(samples, points = 100) {
  if (samples.length === 0) return [];
  const sorted = [...samples].sort((a, b) => a - b);
  const min    = sorted[0];
  const max    = sorted[sorted.length - 1];
  const step   = (max - min) / points || 1;
  const result = [];
  for (let i = 0; i <= points; i++) {
    const x     = min + i * step;
    const below = sorted.filter(v => v <= x).length;
    result.push({ x, cdf: below / sorted.length });
  }
  return result;
}

// ─────────────────────────────────────────────
// Scenario Builders
// ─────────────────────────────────────────────

/**
 * Built-in scenario definitions for common Heady use-cases.
 */
const SCENARIOS = {
  /**
   * Deployment risk scenario.
   * Estimates probability of a deployment failing based on:
   * - Service dependency count
   * - Code change size
   * - Test coverage fraction
   * @param {object} [params]
   */
  deploymentRisk(params = {}) {
    const {
      dependencyCount = 5,
      changeSize      = 500,   // lines
      testCoverage    = 0.8,   // 0-1
    } = params;
    return {
      name: 'deployment_risk',
      variables: {
        depFailureRate: {
          type: 'uniform',
          min: 0.01,
          max: 0.05 * (dependencyCount / 5),
        },
        bugRate: {
          type: 'normal',
          mean: changeSize * 0.001,
          stddev: changeSize * 0.0005,
        },
        coverageFactor: {
          type: 'normal',
          mean: 1 - testCoverage,
          stddev: 0.05,
        },
      },
      /**
       * @param {{depFailureRate: number, bugRate: number, coverageFactor: number}} vars
       * @returns {number} 0 = success, 1 = failure
       */
      compute(vars) {
        const risk = vars.depFailureRate + vars.bugRate * Math.max(0, vars.coverageFactor);
        return Math.min(1, Math.max(0, risk));
      },
    };
  },

  /**
   * Resource allocation scenario.
   * Estimates total resource cost given demand variability.
   * @param {object} [params]
   */
  resourceAllocation(params = {}) {
    const {
      baseLoad       = 100,   // requests/sec
      peakMultiplier = 3,
      resourceCost   = 0.01,  // per unit per request
    } = params;
    return {
      name: 'resource_allocation',
      variables: {
        load:         { type: 'normal',  mean: baseLoad, stddev: baseLoad * 0.2 },
        peakSpike:    { type: 'poisson', lambda: peakMultiplier },
        costVariance: { type: 'uniform', min: 0.8, max: 1.2 },
      },
      compute(vars) {
        return Math.max(0, vars.load * vars.peakSpike * resourceCost * vars.costVariance);
      },
    };
  },

  /**
   * Routing optimization scenario.
   * Simulates end-to-end latency across the LLM routing chain.
   * @param {object} [params]
   */
  routingOptimization(params = {}) {
    const {
      primaryLatencyMs  = 250,
      failoverLatencyMs = 600,
      failoverProbability = 0.1,
    } = params;
    return {
      name: 'routing_optimization',
      variables: {
        primaryLatency:  { type: 'normal',    mean: primaryLatencyMs,  stddev: primaryLatencyMs * 0.15 },
        failoverLatency: { type: 'exponential', lambda: 1 / failoverLatencyMs },
        needsFailover:   { type: 'bernoulli', probability: failoverProbability },
      },
      compute(vars) {
        return vars.needsFailover
          ? vars.primaryLatency + vars.failoverLatency
          : vars.primaryLatency;
      },
    };
  },
};

// ─────────────────────────────────────────────
// Monte Carlo Engine
// ─────────────────────────────────────────────

/**
 * @typedef {object} SimulationConfig
 * @property {number}  [maxTrials=10000]         Maximum number of trials
 * @property {number}  [minTrials=100]            Minimum trials before convergence check
 * @property {number}  [convergenceThreshold=0.01] Stop when CI width / mean < this
 * @property {number}  [histogramBins=30]
 * @property {number}  [seed]                     RNG seed for reproducibility
 * @property {boolean} [emitProgress=false]       Emit progress events
 * @property {number}  [progressInterval=1000]    Emit progress every N trials
 */

/**
 * @typedef {object} ScenarioDefinition
 * @property {string}  name
 * @property {object}  variables  Map of variable name → distribution config
 * @property {function} compute   (vars: object) => number — the output value to simulate
 */

/**
 * @typedef {object} SimulationResult
 * @property {string}  scenarioName
 * @property {number}  trialsRun
 * @property {object}  stats         Descriptive statistics
 * @property {object}  ci95          95% confidence interval
 * @property {boolean} converged
 * @property {object}  histogram     Visualization-ready histogram data
 * @property {Array}   cdf           Visualization-ready CDF data
 * @property {number}  durationMs
 */

/**
 * Monte Carlo Simulation Engine.
 *
 * Usage:
 * ```js
 * const engine = new MonteCarloEngine();
 * const result = await engine.run(SCENARIOS.deploymentRisk({ dependencyCount: 8 }));
 * console.log(result.stats.p95, result.converged);
 * ```
 *
 * @extends EventEmitter
 */
class MonteCarloEngine extends EventEmitter {
  /**
   * @param {SimulationConfig} [config]
   */
  constructor(config = {}) {
    super();
    this.maxTrials           = config.maxTrials           ?? 10_000;
    this.minTrials           = config.minTrials           ?? 100;
    this.convergenceThreshold = config.convergenceThreshold ?? 0.01;
    this.histogramBins       = config.histogramBins       ?? 30;
    this.seed                = config.seed;
    this.emitProgress        = config.emitProgress        ?? false;
    this.progressInterval    = config.progressInterval    ?? 1000;
  }

  /**
   * Build sampler functions from a variables map.
   * @param {object} variables
   * @param {()=>number} rng
   * @returns {object} Map of name → sampler function
   */
  _buildSamplers(variables, rng) {
    const samplers = {};
    for (const [name, def] of Object.entries(variables)) {
      switch (def.type) {
        case 'uniform':
          samplers[name] = Distributions.uniform(def.min, def.max, rng);
          break;
        case 'normal':
          samplers[name] = Distributions.normal(def.mean, def.stddev, rng);
          break;
        case 'exponential':
          samplers[name] = Distributions.exponential(def.lambda, rng);
          break;
        case 'poisson':
          samplers[name] = Distributions.poisson(def.lambda, rng);
          break;
        case 'bernoulli':
          samplers[name] = Distributions.bernoulli(def.probability, rng);
          break;
        case 'triangular':
          samplers[name] = Distributions.triangular(def.min, def.mode, def.max, rng);
          break;
        default:
          throw new Error(`Unknown distribution type: ${def.type}`);
      }
    }
    return samplers;
  }

  /**
   * Run a simulation scenario.
   * Supports an optional AbortSignal for cancellation.
   *
   * @param {ScenarioDefinition} scenario
   * @param {object} [opts]
   * @param {AbortSignal} [opts.signal]   Optional cancellation signal
   * @param {number}      [opts.maxTrials] Override instance maxTrials
   * @returns {Promise<SimulationResult>}
   */
  async run(scenario, opts = {}) {
    const maxTrials = opts.maxTrials ?? this.maxTrials;
    const rng       = createRng(this.seed);
    const samplers  = this._buildSamplers(scenario.variables, rng);

    const samples   = [];
    let converged   = false;
    const startMs   = Date.now();

    for (let t = 0; t < maxTrials; t++) {
      // Cancellation support
      if (opts.signal?.aborted) break;

      // Sample all variables
      const vars = {};
      for (const [name, sampler] of Object.entries(samplers)) {
        vars[name] = sampler();
      }

      // Compute outcome
      const outcome = scenario.compute(vars);
      samples.push(outcome);

      // Progress events
      if (this.emitProgress && (t + 1) % this.progressInterval === 0) {
        this.emit('progress', { scenario: scenario.name, trial: t + 1, maxTrials });
      }

      // Convergence check (after minTrials, every 100 trials)
      if (t >= this.minTrials && t % 100 === 0) {
        const stats = computeStats(samples);
        if (stats.mean !== 0) {
          const ci = confidenceInterval95(stats.mean, stats.stddev, samples.length);
          if (ci.width / Math.abs(stats.mean) < this.convergenceThreshold) {
            converged = true;
            this.emit('converged', { scenario: scenario.name, trial: t + 1 });
            break;
          }
        }
      }
    }

    const stats    = computeStats(samples);
    const ci95     = confidenceInterval95(stats.mean ?? 0, stats.stddev ?? 0, samples.length);
    const histogram = buildHistogram(samples, this.histogramBins);
    const cdf       = buildCDF(samples);

    const result = {
      scenarioName: scenario.name,
      trialsRun:    samples.length,
      stats,
      ci95,
      converged,
      histogram,
      cdf,
      durationMs:   Date.now() - startMs,
    };

    this.emit('complete', result);
    return result;
  }

  /**
   * Run multiple scenarios in parallel.
   * @param {ScenarioDefinition[]} scenarios
   * @param {object} [opts]
   * @returns {Promise<SimulationResult[]>}
   */
  async runAll(scenarios, opts = {}) {
    return Promise.all(scenarios.map(s => this.run(s, opts)));
  }

  /**
   * Convenience: run the deployment risk scenario.
   * @param {object} [params]
   * @returns {Promise<SimulationResult>}
   */
  async simulateDeploymentRisk(params = {}) {
    return this.run(SCENARIOS.deploymentRisk(params));
  }

  /**
   * Convenience: run the resource allocation scenario.
   * @param {object} [params]
   * @returns {Promise<SimulationResult>}
   */
  async simulateResourceAllocation(params = {}) {
    return this.run(SCENARIOS.resourceAllocation(params));
  }

  /**
   * Convenience: run the routing optimization scenario.
   * @param {object} [params]
   * @returns {Promise<SimulationResult>}
   */
  async simulateRoutingOptimization(params = {}) {
    return this.run(SCENARIOS.routingOptimization(params));
  }

  /**
   * Pipeline MONTE_CARLO stage integration handler.
   * Accepts a pipeline stage context and returns an enriched context.
   *
   * @param {object} stageCtx
   * @param {string} stageCtx.scenarioType   One of 'deployment_risk' | 'resource_allocation' | 'routing'
   * @param {object} [stageCtx.params]
   * @returns {Promise<object>} Updated stage context with simulation results
   */
  async handlePipelineStage(stageCtx = {}) {
    let scenario;
    switch (stageCtx.scenarioType) {
      case 'deployment_risk':
        scenario = SCENARIOS.deploymentRisk(stageCtx.params);
        break;
      case 'resource_allocation':
        scenario = SCENARIOS.resourceAllocation(stageCtx.params);
        break;
      case 'routing':
        scenario = SCENARIOS.routingOptimization(stageCtx.params);
        break;
      default:
        throw new Error(`handlePipelineStage: unknown scenarioType ${stageCtx.scenarioType}`);
    }

    const result = await this.run(scenario);
    return {
      ...stageCtx,
      monteCarlo: result,
      riskP95:    result.stats.p95,
      riskMean:   result.stats.mean,
    };
  }
}

// ─────────────────────────────────────────────
// Exports
// ─────────────────────────────────────────────

export {

  MonteCarloEngine,
  Distributions,
  SCENARIOS,
  createRng,
  computeStats,
  confidenceInterval95,
  buildHistogram,
  buildCDF,
};
