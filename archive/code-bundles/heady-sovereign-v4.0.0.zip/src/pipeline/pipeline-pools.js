/**
 * ∞ Heady™ PipelinePools — Pipeline Resource Allocation
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';
import crypto from 'crypto';

// ─── Constants ───────────────────────────────────────────────────────────────

/**
 * Pipeline pool definitions with concurrency limits and queue thresholds.
 * Ratios mirror the Fibonacci allocation from the broader HeadySystems design.
 */
const PIPELINE_POOLS = Object.freeze({
  hot: {
    name:            'hot',
    maxConcurrency:  20,   // Max simultaneous pipeline runs
    maxQueueDepth:   100,  // Max queued runs before rejection
    escalationMs:    10_000, // Escalate priority if waiting > 10s
    timeoutMs:       30_000,
  },
  warm: {
    name:            'warm',
    maxConcurrency:  12,
    maxQueueDepth:   500,
    escalationMs:    60_000,
    timeoutMs:       300_000,
  },
  cold: {
    name:            'cold',
    maxConcurrency:  7,
    maxQueueDepth:   1000,
    escalationMs:    300_000,
    timeoutMs:       1_800_000,
  },
  reserve: {
    name:            'reserve',
    maxConcurrency:  4,
    maxQueueDepth:   200,
    escalationMs:    120_000,
    timeoutMs:       600_000,
  },
  governance: {
    name:            'governance',
    maxConcurrency:  2,
    maxQueueDepth:   50,
    escalationMs:    60_000,
    timeoutMs:       120_000,
  },
});

// ─── PipelinePools ────────────────────────────────────────────────────────────

/**
 * PipelinePools manages the assignment and execution of pipeline runs across
 * priority pools (hot/warm/cold/reserve/governance).
 *
 * Features:
 * - **Pool Assignment**: Routes pipeline runs to the appropriate pool based
 *   on caller-specified priority or metadata.
 * - **Queue Management**: Each pool has a bounded FIFO queue with overflow
 *   rejection and priority escalation.
 * - **Concurrency Limits**: Hard concurrency cap per pool to prevent resource
 *   exhaustion. Runs exceeding the cap are queued.
 * - **Priority Escalation**: Runs that have been waiting longer than
 *   `escalationMs` are automatically upgraded to the next higher pool.
 * - **Metrics**: Per-pool throughput, queue depth, wait time, and concurrency.
 *
 * @extends EventEmitter
 *
 * @fires PipelinePools#run:queued
 * @fires PipelinePools#run:dispatched
 * @fires PipelinePools#run:completed
 * @fires PipelinePools#run:escalated
 * @fires PipelinePools#pool:overflow
 * @fires PipelinePools#pool:full
 */
class PipelinePools extends EventEmitter {
  /**
   * @param {Object}   [options={}]
   * @param {Object}   [options.poolOverrides]      - Partial pool config overrides
   * @param {number}   [options.escalationCheckMs=5000] - Interval for escalation checks
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._logger          = options.logger ?? console;
    this._escalationCheck = options.escalationCheckMs ?? 5_000;

    /**
     * Pool states: Map<poolName, PoolState>
     * @type {Map<string, PoolState>}
     */
    this._pools = this._initPools(options.poolOverrides ?? {});

    /** @type {NodeJS.Timeout|null} */
    this._escalationTimer = null;

    this._startEscalationLoop();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Submits a pipeline run for execution in the given pool.
   * If the pool is at capacity, the run is queued. If the queue is full,
   * the run is rejected with an overflow error.
   *
   * @param {Object}   runSpec
   * @param {string}   runSpec.runId        - Unique run identifier
   * @param {Function} runSpec.execute      - async() → void — the pipeline executor
   * @param {string}   [runSpec.poolName='warm'] - Target pool
   * @param {number}   [runSpec.priority=50] - Numeric priority (0 = highest)
   * @param {Object}   [runSpec.meta={}]
   * @returns {Promise<RunTicket>}          - Resolves when the run is dispatched (not necessarily completed)
   */
  async submit(runSpec) {
    const poolName = runSpec.poolName ?? 'warm';
    const pool     = this._requirePool(poolName);

    const ticket = {
      ticketId:   crypto.randomUUID(),
      runId:      runSpec.runId,
      poolName,
      priority:   runSpec.priority ?? 50,
      meta:       runSpec.meta ?? {},
      queuedAt:   Date.now(),
      startedAt:  null,
      completedAt: null,
      escalated:  false,
    };

    // Check queue overflow
    if (pool.queue.length >= pool.config.maxQueueDepth) {
      pool.metrics.overflows++;
      this.emit('pool:overflow', { poolName, queueDepth: pool.queue.length });
      throw new Error(
        `[PipelinePools] Pool "${poolName}" queue is full (${pool.config.maxQueueDepth} max)`
      );
    }

    // Attach executor to ticket
    ticket._execute = runSpec.execute;

    // If capacity available: dispatch immediately
    if (pool.running < pool.config.maxConcurrency) {
      this._dispatch(pool, ticket);
    } else {
      // Enqueue, sorted by priority (lower number = higher priority)
      pool.queue.push(ticket);
      pool.queue.sort((a, b) => a.priority - b.priority);
      pool.metrics.queued++;
      this.emit('run:queued', { runId: ticket.runId, poolName, queueDepth: pool.queue.length });
      this._logger.info(
        `[PipelinePools] Run ${ticket.runId} queued in "${poolName}" (depth: ${pool.queue.length})`
      );
    }

    return ticket;
  }

  /**
   * Returns the current status of all pools.
   * @returns {PoolStatus[]}
   */
  getStatus() {
    return Array.from(this._pools.entries()).map(([name, pool]) => ({
      name,
      running:       pool.running,
      maxConcurrency: pool.config.maxConcurrency,
      queueDepth:    pool.queue.length,
      maxQueueDepth: pool.config.maxQueueDepth,
      utilisation:   +(pool.running / pool.config.maxConcurrency).toFixed(4),
      metrics:       { ...pool.metrics },
    }));
  }

  /**
   * Returns the status of a specific pool.
   * @param {string} poolName
   * @returns {PoolStatus}
   */
  getPoolStatus(poolName) {
    const pool = this._requirePool(poolName);
    return {
      name:          poolName,
      running:       pool.running,
      maxConcurrency: pool.config.maxConcurrency,
      queueDepth:    pool.queue.length,
      maxQueueDepth: pool.config.maxQueueDepth,
      utilisation:   +(pool.running / pool.config.maxConcurrency).toFixed(4),
      metrics:       { ...pool.metrics },
    };
  }

  /**
   * Stops the escalation timer (call on shutdown).
   */
  destroy() {
    if (this._escalationTimer) {
      clearInterval(this._escalationTimer);
      this._escalationTimer = null;
    }
  }

  // ─── Dispatch ────────────────────────────────────────────────────────────────

  /**
   * Dispatches a ticket to a pool for immediate execution.
   * @param {PoolState} pool
   * @param {RunTicket} ticket
   */
  _dispatch(pool, ticket) {
    pool.running++;
    ticket.startedAt = Date.now();
    pool.metrics.dispatched++;

    const waitMs = ticket.startedAt - ticket.queuedAt;
    pool.metrics.totalWaitMs += waitMs;

    this.emit('run:dispatched', {
      runId:    ticket.runId,
      poolName: pool.config.name,
      waitMs,
    });

    this._logger.info(
      `[PipelinePools] Dispatching run ${ticket.runId} in "${pool.config.name}" (wait: ${waitMs}ms)`
    );

    // Execute async, then handle completion
    Promise.resolve()
      .then(() => ticket._execute())
      .then(() => this._onComplete(pool, ticket, null))
      .catch(err => this._onComplete(pool, ticket, err));
  }

  /**
   * Handles a run completion (success or failure).
   * @param {PoolState} pool
   * @param {RunTicket} ticket
   * @param {Error|null} err
   */
  _onComplete(pool, ticket, err) {
    pool.running = Math.max(0, pool.running - 1);
    ticket.completedAt = Date.now();

    const durationMs = ticket.completedAt - ticket.startedAt;
    pool.metrics.completed++;
    pool.metrics.totalRunMs += durationMs;

    if (err) pool.metrics.failures++;

    this.emit('run:completed', {
      runId:      ticket.runId,
      poolName:   pool.config.name,
      durationMs,
      error:      err?.message ?? null,
    });

    // Drain queue: dispatch next waiting run
    this._drainQueue(pool);
  }

  /**
   * Dequeues and dispatches the next ticket from a pool's queue.
   * @param {PoolState} pool
   */
  _drainQueue(pool) {
    if (pool.queue.length === 0) return;
    if (pool.running >= pool.config.maxConcurrency) return;

    const next = pool.queue.shift();
    if (next) this._dispatch(pool, next);
  }

  // ─── Priority Escalation ──────────────────────────────────────────────────────

  /**
   * Starts the periodic escalation check loop.
   */
  _startEscalationLoop() {
    this._escalationTimer = setInterval(
      () => this._checkEscalations(),
      this._escalationCheck
    );
    if (this._escalationTimer.unref) this._escalationTimer.unref();
  }

  /**
   * Scans all pool queues for tickets that have been waiting too long,
   * and escalates them to the next higher-priority pool.
   */
  _checkEscalations() {
    const poolOrder = ['governance', 'reserve', 'cold', 'warm', 'hot'];

    for (let i = 0; i < poolOrder.length - 1; i++) {
      const poolName  = poolOrder[i];
      const nextPool  = poolOrder[i + 1];
      const pool      = this._pools.get(poolName);
      const targetPool = this._pools.get(nextPool);
      if (!pool || !targetPool) continue;

      const now = Date.now();
      const escalationMs = pool.config.escalationMs;
      let escalated = 0;

      pool.queue = pool.queue.filter(ticket => {
        const wait = now - ticket.queuedAt;
        if (wait < escalationMs) return true;

        // Escalate: move to higher pool's queue
        ticket.escalated = true;
        ticket.poolName  = nextPool;

        if (targetPool.queue.length < targetPool.config.maxQueueDepth) {
          targetPool.queue.push(ticket);
          targetPool.queue.sort((a, b) => a.priority - b.priority);
          escalated++;
          this.emit('run:escalated', {
            runId:    ticket.runId,
            from:     poolName,
            to:       nextPool,
            waitMs:   wait,
          });
          this._logger.info(
            `[PipelinePools] Escalated run ${ticket.runId}: "${poolName}" → "${nextPool}" (waited ${wait}ms)`
          );
        }
        return false;
      });

      if (escalated > 0) {
        // Drain the target pool in case capacity is now available
        this._drainQueue(targetPool);
      }
    }
  }

  // ─── Initialisation ──────────────────────────────────────────────────────────

  /**
   * Creates the pool state map from PIPELINE_POOLS definitions.
   * @param {Object} overrides
   * @returns {Map<string, PoolState>}
   */
  _initPools(overrides) {
    const map = new Map();
    for (const [name, config] of Object.entries(PIPELINE_POOLS)) {
      map.set(name, {
        config:   { ...config, ...(overrides[name] ?? {}) },
        running:  0,
        queue:    [],
        metrics:  {
          queued:       0,
          dispatched:   0,
          completed:    0,
          failures:     0,
          overflows:    0,
          totalWaitMs:  0,
          totalRunMs:   0,
        },
      });
    }
    return map;
  }

  /**
   * Gets a pool or throws.
   * @param {string} name
   * @returns {PoolState}
   */
  _requirePool(name) {
    const pool = this._pools.get(name);
    if (!pool) throw new Error(`[PipelinePools] Unknown pool: "${name}"`);
    return pool;
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  PipelinePools,
  PIPELINE_POOLS,
};
