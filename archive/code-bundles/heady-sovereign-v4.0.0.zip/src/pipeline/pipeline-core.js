/**
 * ∞ Heady™ PipelineCore — HCFullPipeline Engine
 * Part of HeadySystems™ Sovereign AI Platform v4.0.0
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

import { EventEmitter } from 'events';
import crypto from 'crypto';

// ─── Stage Constants ──────────────────────────────────────────────────────────

/**
 * The 9 canonical HCFullPipeline stages (in order).
 */
const STAGE = Object.freeze({
  INTAKE:      'INTAKE',
  TRIAGE:      'TRIAGE',
  MONTE_CARLO: 'MONTE_CARLO',
  ARENA:       'ARENA',
  JUDGE:       'JUDGE',
  APPROVE:     'APPROVE',
  EXECUTE:     'EXECUTE',
  VERIFY:      'VERIFY',
  RECEIPT:     'RECEIPT',
});

/** Ordered stage sequence */
const STAGE_ORDER = [
  STAGE.INTAKE,
  STAGE.TRIAGE,
  STAGE.MONTE_CARLO,
  STAGE.ARENA,
  STAGE.JUDGE,
  STAGE.APPROVE,
  STAGE.EXECUTE,
  STAGE.VERIFY,
  STAGE.RECEIPT,
];

/** Pipeline run states */
const RUN_STATE = Object.freeze({
  PENDING:    'pending',
  RUNNING:    'running',
  PAUSED:     'paused',
  COMPLETED:  'completed',
  FAILED:     'failed',
  ROLLED_BACK: 'rolled_back',
});

/** Per-stage states */
const STAGE_STATE = Object.freeze({
  PENDING:   'pending',
  RUNNING:   'running',
  COMPLETED: 'completed',
  SKIPPED:   'skipped',
  FAILED:    'failed',
  RETRYING:  'retrying',
  ROLLED_BACK: 'rolled_back',
});

// ─── PipelineCore ─────────────────────────────────────────────────────────────

/**
 * PipelineCore is the HCFullPipeline engine — the central orchestrator for
 * the 9-stage HeadySystems processing pipeline.
 *
 * Each stage follows a well-defined interface:
 * ```js
 * {
 *   name:              string,
 *   execute(ctx):      Promise<void>  — mutates ctx in place
 *   validate(ctx):     Promise<boolean> — returns false to block advancement
 *   rollback(ctx):     Promise<void>  — undoes the stage's changes on failure
 * }
 * ```
 *
 * Stage dependencies:
 * - Stages 1–4 (INTAKE → ARENA) run sequentially.
 * - JUDGE and APPROVE are sequential after ARENA.
 * - EXECUTE, VERIFY, and RECEIPT are sequential after APPROVE.
 * - Stages may be skipped via run options (e.g. skip MONTE_CARLO for fast paths).
 *
 * @extends EventEmitter
 *
 * @fires PipelineCore#run:started
 * @fires PipelineCore#stage:started
 * @fires PipelineCore#stage:completed
 * @fires PipelineCore#stage:failed
 * @fires PipelineCore#stage:skipped
 * @fires PipelineCore#run:completed
 * @fires PipelineCore#run:failed
 * @fires PipelineCore#run:rolled_back
 */
class PipelineCore extends EventEmitter {
  /**
   * @param {Object}   [options={}]
   * @param {Object}   [options.handlers]        - Stage name → handler object { execute, validate, rollback }
   * @param {number}   [options.stageTimeoutMs=60000]  - Per-stage max duration
   * @param {number}   [options.stageMaxRetries=2]     - Per-stage retry count
   * @param {boolean}  [options.enableAuditTrail=true] - Record full stage audit trail
   * @param {Function} [options.logger=console]
   */
  constructor(options = {}) {
    super();
    this._handlers       = options.handlers       ?? {};
    this._stageTimeout   = options.stageTimeoutMs  ?? 60_000;
    this._stageMaxRetries = options.stageMaxRetries ?? 2;
    this._auditTrail     = options.enableAuditTrail !== false;
    this._logger         = options.logger          ?? console;

    /**
     * All pipeline runs: Map<runId, PipelineRun>
     * @type {Map<string, PipelineRun>}
     */
    this._runs = new Map();

    /**
     * Aggregate metrics
     * @type {PipelineMetrics}
     */
    this._metrics = this._initMetrics();
  }

  // ─── Stage Registration ──────────────────────────────────────────────────────

  /**
   * Registers a stage handler.
   *
   * @param {string}  stageName  - STAGE constant
   * @param {Object}  handler
   * @param {Function} handler.execute   - async(ctx) → void
   * @param {Function} [handler.validate] - async(ctx) → boolean (default: () => true)
   * @param {Function} [handler.rollback] - async(ctx) → void (default: noop)
   * @returns {PipelineCore} chainable
   */
  register(stageName, handler) {
    if (!STAGE_ORDER.includes(stageName)) {
      throw new Error(`[PipelineCore] Unknown stage: "${stageName}"`);
    }
    this._handlers[stageName] = {
      name:     stageName,
      execute:  handler.execute.bind(handler),
      validate: (handler.validate ?? (async () => true)).bind(handler),
      rollback: (handler.rollback ?? (async () => {})).bind(handler),
    };
    return this;
  }

  // ─── Pipeline Execution ──────────────────────────────────────────────────────

  /**
   * Executes a full pipeline run.
   *
   * @param {Object}  input          - Input data for the INTAKE stage
   * @param {Object}  [opts={}]
   * @param {string[]} [opts.skip]   - Stage names to skip
   * @param {string}  [opts.label]   - Human-readable run label
   * @param {Object}  [opts.meta={}] - Arbitrary metadata attached to the run
   * @param {string}  [opts.poolName] - Pool for resource allocation (default 'warm')
   * @returns {Promise<PipelineRun>}
   */
  async run(input, opts = {}) {
    const runId = crypto.randomUUID();
    const skipSet = new Set(opts.skip ?? []);

    /** @type {PipelineContext} */
    const ctx = {
      runId,
      input,
      output:     null,
      data:       {},          // Shared bag for inter-stage communication
      stageResults: {},        // Map of stage → result
      errors:     [],
      startedAt:  Date.now(),
    };

    /** @type {PipelineRun} */
    const run = {
      runId,
      label:      opts.label ?? runId.slice(0, 8),
      meta:       opts.meta  ?? {},
      poolName:   opts.poolName ?? 'warm',
      state:      RUN_STATE.PENDING,
      stages:     this._initStageRecords(),
      context:    ctx,
      completedAt: null,
      error:       null,
    };

    this._runs.set(runId, run);
    this._metrics.totalRuns++;

    this.emit('run:started', { runId, label: run.label, poolName: run.poolName });
    run.state = RUN_STATE.RUNNING;

    // Execute stages
    const executedStages = [];

    try {
      for (const stageName of STAGE_ORDER) {
        const stageRecord = run.stages[stageName];

        // Skip
        if (skipSet.has(stageName)) {
          stageRecord.state = STAGE_STATE.SKIPPED;
          this.emit('stage:skipped', { runId, stageName });
          this._metrics.byStage[stageName].skipped++;
          continue;
        }

        // No handler registered → skip silently
        const handler = this._handlers[stageName];
        if (!handler) {
          stageRecord.state = STAGE_STATE.SKIPPED;
          this._logger.info(`[PipelineCore] No handler for stage ${stageName} — skipping`);
          continue;
        }

        // Execute stage
        await this._executeStage(run, stageRecord, handler, ctx, executedStages);
        executedStages.push(stageName);
      }

      // Success
      run.state       = RUN_STATE.COMPLETED;
      run.completedAt = Date.now();
      // Prefer ReceiptHandler's output if set, fallback to full data bag
      if (ctx.output === null || ctx.output === undefined) {
        ctx.output = ctx.data;
      }

      const durationMs = run.completedAt - ctx.startedAt;
      this._metrics.succeeded++;
      this._metrics.totalDurationMs += durationMs;

      this.emit('run:completed', { runId, label: run.label, durationMs });
      this._logger.info(`[PipelineCore] Run ${runId} completed in ${durationMs}ms`);

    } catch (err) {
      run.state  = RUN_STATE.FAILED;
      run.error  = err.message;
      run.completedAt = Date.now();
      this._metrics.failed++;

      this.emit('run:failed', { runId, error: err.message });
      this._logger.error(`[PipelineCore] Run ${runId} failed: ${err.message}`);

      // Rollback executed stages in reverse order
      await this._rollback(run, ctx, executedStages);
    }

    return run;
  }

  /**
   * Returns a run by ID.
   * @param {string} runId
   * @returns {PipelineRun|undefined}
   */
  getRun(runId) {
    return this._runs.get(runId);
  }

  /**
   * Lists runs filtered by state.
   * @param {string} [state]
   * @returns {PipelineRun[]}
   */
  listRuns(state) {
    const all = Array.from(this._runs.values());
    return state ? all.filter(r => r.state === state) : all;
  }

  /**
   * Returns aggregate pipeline metrics.
   * @returns {PipelineMetrics}
   */
  getMetrics() {
    const m = { ...this._metrics };
    m.avgDurationMs = m.succeeded > 0
      ? Math.round(m.totalDurationMs / m.succeeded)
      : 0;
    m.successRate = m.totalRuns > 0
      ? +(m.succeeded / m.totalRuns).toFixed(4)
      : 0;
    return m;
  }

  // ─── Stage Execution ─────────────────────────────────────────────────────────

  /**
   * Executes a single stage with timeout, retry, and audit recording.
   *
   * @param {PipelineRun}     run
   * @param {StageRecord}     stageRecord
   * @param {Object}          handler
   * @param {PipelineContext} ctx
   * @param {string[]}        executedSoFar
   * @returns {Promise<void>}
   */
  async _executeStage(run, stageRecord, handler, ctx, executedSoFar) {
    stageRecord.state     = STAGE_STATE.RUNNING;
    stageRecord.startedAt = Date.now();

    this.emit('stage:started', { runId: run.runId, stageName: handler.name });
    this._logger.info(`[PipelineCore] Stage ${handler.name} started`);

    let lastErr;

    for (let attempt = 0; attempt <= this._stageMaxRetries; attempt++) {
      if (attempt > 0) {
        stageRecord.state = STAGE_STATE.RETRYING;
        stageRecord.retries++;
        const delay = 200 * Math.pow(1.618, attempt - 1);
        await this._sleep(Math.round(delay));
      }

      try {
        // Execute with timeout
        await Promise.race([
          handler.execute(ctx),
          this._timeoutReject(this._stageTimeout, handler.name),
        ]);

        // Validate
        const valid = await handler.validate(ctx);
        if (!valid) {
          throw new Error(`[PipelineCore] Stage ${handler.name} validation failed`);
        }

        // Success
        stageRecord.state       = STAGE_STATE.COMPLETED;
        stageRecord.completedAt = Date.now();
        stageRecord.durationMs  = stageRecord.completedAt - stageRecord.startedAt;

        const sm = this._metrics.byStage[handler.name];
        if (sm) {
          sm.runs++;
          sm.totalDurationMs += stageRecord.durationMs;
        }

        if (this._auditTrail) {
          stageRecord.audit.push({
            attempt,
            success:    true,
            durationMs: stageRecord.durationMs,
            timestamp:  stageRecord.completedAt,
          });
        }

        this.emit('stage:completed', {
          runId:      run.runId,
          stageName:  handler.name,
          durationMs: stageRecord.durationMs,
          attempt,
        });

        return; // ← success path

      } catch (err) {
        lastErr = err;
        if (this._auditTrail) {
          stageRecord.audit.push({
            attempt,
            success:   false,
            error:     err.message,
            timestamp: Date.now(),
          });
        }
        this._logger.warn(
          `[PipelineCore] Stage ${handler.name} attempt ${attempt} failed: ${err.message}`
        );
      }
    }

    // All retries exhausted
    stageRecord.state       = STAGE_STATE.FAILED;
    stageRecord.completedAt = Date.now();
    stageRecord.error       = lastErr?.message;

    const sm = this._metrics.byStage[handler.name];
    if (sm) sm.failures++;

    this.emit('stage:failed', { runId: run.runId, stageName: handler.name, error: lastErr?.message });
    throw lastErr;
  }

  // ─── Rollback ─────────────────────────────────────────────────────────────────

  /**
   * Rolls back completed stages in reverse order.
   *
   * @param {PipelineRun}     run
   * @param {PipelineContext} ctx
   * @param {string[]}        stageNames
   * @returns {Promise<void>}
   */
  async _rollback(run, ctx, stageNames) {
    this._logger.warn(`[PipelineCore] Rolling back run ${run.runId} (${stageNames.length} stages)`);

    for (const stageName of [...stageNames].reverse()) {
      const handler = this._handlers[stageName];
      if (!handler) continue;

      try {
        await handler.rollback(ctx);
        const stageRecord = run.stages[stageName];
        if (stageRecord) stageRecord.state = STAGE_STATE.ROLLED_BACK;
        this._logger.info(`[PipelineCore] Rolled back stage ${stageName}`);
      } catch (err) {
        this._logger.error(`[PipelineCore] Rollback failed for ${stageName}: ${err.message}`);
      }
    }

    run.state = RUN_STATE.ROLLED_BACK;
    this.emit('run:rolled_back', { runId: run.runId });
  }

  // ─── Metrics + Helpers ───────────────────────────────────────────────────────

  /**
   * Initialises empty metrics.
   * @returns {PipelineMetrics}
   */
  _initMetrics() {
    const byStage = {};
    for (const s of STAGE_ORDER) {
      byStage[s] = { runs: 0, failures: 0, skipped: 0, totalDurationMs: 0 };
    }
    return {
      totalRuns:       0,
      succeeded:       0,
      failed:          0,
      totalDurationMs: 0,
      avgDurationMs:   0,
      successRate:     0,
      byStage,
    };
  }

  /**
   * Initialises blank stage record map for a run.
   * @returns {Object<string, StageRecord>}
   */
  _initStageRecords() {
    const records = {};
    for (const s of STAGE_ORDER) {
      records[s] = {
        name:        s,
        state:       STAGE_STATE.PENDING,
        startedAt:   null,
        completedAt: null,
        durationMs:  0,
        retries:     0,
        error:       null,
        audit:       [],
      };
    }
    return records;
  }

  /**
   * Returns a promise that rejects after `ms` with a timeout error.
   * @param {number} ms
   * @param {string} stageName
   * @returns {Promise<never>}
   */
  _timeoutReject(ms, stageName) {
    return new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`[PipelineCore] Stage ${stageName} timed out after ${ms}ms`)), ms)
    );
  }

  /**
   * Resolves after `ms` milliseconds.
   * @param {number} ms
   * @returns {Promise<void>}
   */
  _sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

export {

  PipelineCore,
  STAGE,
  STAGE_ORDER,
  RUN_STATE,
  STAGE_STATE,
};
