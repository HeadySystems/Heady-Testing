'use strict';

/**
 * @module resilience/phi-backoff
 * @description Phi-exponential backoff implementation with optional PSI²-jitter
 *   (±38.2%). Supports deterministic mode for testing, Fibonacci-bounded
 *   max attempts, and schedule preview.
 *
 *   delay(n) = clamp(base × φⁿ, 0, maxMs) × (1 ± ψ²·random)
 */

const {
  PHI,
  PSI,
  PSI_SQ,
  fib,
  phiBackoff,
  phiBackoffDeterministic,
} = require('../shared/phi-math');

// ─── Constants ────────────────────────────────────────────────────────────────

/** Maximum attempts before isDone() returns true: fib(7) = 13 */
const MAX_ATTEMPTS = fib(7); // 13

/** Default base delay in ms: 1000 */
const DEFAULT_BASE_MS = fib(10) * fib(3); // 55×2=110; use round 1000
// Override to spec-required 1000ms
const BASE_MS = 1000;

/** Default max delay in ms: fib(11) × fib(5) × 1000 / fib(3) ~= 89×5×500 → spec says 60000 */
const MAX_MS = fib(9) * fib(5) * fib(3) * fib(4) * PHI | 0; // close to 60000
// Use spec-required 60000ms
const MAX_DELAY_MS = 60000;

/** Jitter fraction: ψ² ≈ 0.382 → ±38.2% */
const JITTER_FRACTION = PSI_SQ; // ≈ 0.382

// ─── PhiBackoff ───────────────────────────────────────────────────────────────

/**
 * @class PhiBackoff
 * @description Stateful phi-exponential backoff calculator.
 *
 * @example
 * const bo = new PhiBackoff();
 * while (!bo.isDone()) {
 *   const delay = bo.next();
 *   await sleep(delay);
 *   if (await tryOperation()) { bo.reset(); break; }
 * }
 */
class PhiBackoff {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.baseMs=1000]         base delay in milliseconds
   * @param {number}  [opts.maxMs=60000]          ceiling delay in milliseconds
   * @param {number}  [opts.maxAttempts=13]       max attempts (fib(7))
   * @param {boolean} [opts.deterministic=false]  disable jitter for testing
   */
  constructor(opts = {}) {
    this._baseMs        = opts.baseMs        ?? BASE_MS;
    this._maxMs         = opts.maxMs         ?? MAX_DELAY_MS;
    this._maxAttempts   = opts.maxAttempts   ?? MAX_ATTEMPTS;
    this._deterministic = opts.deterministic ?? false;

    this._attempt       = 0;
    this._lastDelay     = 0;
    this._totalDelay    = 0;
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Advance to the next attempt and return the delay in ms.
   * Returns 0 and does not advance if isDone().
   * @returns {number} delay in milliseconds
   */
  next() {
    if (this.isDone()) return 0;

    const delay = this._calculate(this._attempt);
    this._attempt++;
    this._lastDelay  = delay;
    this._totalDelay += delay;
    return delay;
  }

  /**
   * Return current delay for the current attempt WITHOUT advancing.
   * @returns {number} delay in milliseconds for the current attempt
   */
  current() {
    return this._calculate(this._attempt);
  }

  /**
   * Reset the backoff sequence (call after a successful operation).
   */
  reset() {
    this._attempt    = 0;
    this._lastDelay  = 0;
    this._totalDelay = 0;
  }

  /**
   * @returns {boolean} true if max attempts have been exhausted
   */
  isDone() {
    return this._attempt >= this._maxAttempts;
  }

  /**
   * Get the current attempt count (0-based).
   * @returns {number}
   */
  getAttempt() {
    return this._attempt;
  }

  /**
   * Preview the full delay schedule from attempt 0 to maxAttempts.
   * Uses deterministic (no-jitter) values for reproducibility.
   * @returns {Array<{ attempt: number, delayMs: number, cumulative: number }>}
   */
  getSchedule() {
    let cumulative = 0;
    return Array.from({ length: this._maxAttempts }, (_, i) => {
      const delayMs = this._calculateDeterministic(i);
      cumulative += delayMs;
      return { attempt: i + 1, delayMs, cumulative };
    });
  }

  /**
   * Summary stats for current backoff state.
   * @returns {{
   *   attempt: number,
   *   maxAttempts: number,
   *   lastDelayMs: number,
   *   totalDelayMs: number,
   *   nextDelayMs: number,
   *   done: boolean,
   *   jitterFraction: number
   * }}
   */
  getStats() {
    return {
      attempt:        this._attempt,
      maxAttempts:    this._maxAttempts,
      lastDelayMs:    this._lastDelay,
      totalDelayMs:   this._totalDelay,
      nextDelayMs:    this.isDone() ? 0 : this._calculate(this._attempt),
      done:           this.isDone(),
      jitterFraction: this._deterministic ? 0 : JITTER_FRACTION,
    };
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * Compute delay for a given attempt index.
   * delay = clamp(base × φ^attempt, 0, maxMs) × (1 + jitter)
   * @param {number} attempt  0-based attempt index
   * @returns {number} delay in ms (integer)
   */
  _calculate(attempt) {
    const base = this._calculateDeterministic(attempt);
    if (this._deterministic) return base;

    // Jitter: ±PSI_SQ (±38.2%) using Math.random
    // Range: [(1 - PSI_SQ) × base, (1 + PSI_SQ) × base]
    const jitterRange = JITTER_FRACTION * fib(2); // PSI_SQ * 1 range width
    const jitterMult  = 1 - JITTER_FRACTION + (Math.random() * JITTER_FRACTION * fib(3));
    // Equivalent: uniform in [1-0.382, 1+0.382]
    return Math.min(Math.round(base * jitterMult), this._maxMs);
  }

  /**
   * Deterministic (no-jitter) delay for a given attempt index.
   * delay = clamp(base × φ^attempt, 0, maxMs)
   * @param {number} attempt
   * @returns {number} delay in ms
   */
  _calculateDeterministic(attempt) {
    // φ^attempt: use repeated multiplication to avoid float drift
    let phiPow = 1;
    for (let i = 0; i < attempt; i++) phiPow *= PHI;
    return Math.min(Math.round(this._baseMs * phiPow), this._maxMs);
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports = {
  PhiBackoff,
  MAX_ATTEMPTS,
  BASE_MS,
  MAX_DELAY_MS,
  JITTER_FRACTION,
};
