'use strict';

/**
 * @module resilience/circuit-breaker
 * @description Phi-native circuit breaker using Fibonacci failure thresholds,
 *   phi-exponential recovery backoff, and half-open probe gating.
 *   Extends EventEmitter to broadcast state transitions.
 */

const { EventEmitter } = require('events');
const {
  PHI,
  fib,
  phiBackoff,
  phiBackoffDeterministic,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

// ─── State Constants ──────────────────────────────────────────────────────────

/** @enum {string} Circuit states */
const STATE = Object.freeze({
  CLOSED:    'CLOSED',    // normal operation
  OPEN:      'OPEN',      // failing, rejecting all calls
  HALF_OPEN: 'HALF_OPEN', // probing for recovery
});

// ─── Phi/Fibonacci Thresholds ─────────────────────────────────────────────────

/** Consecutive failures to trip breaker: fib(5) = 5 */
const FAILURE_THRESHOLD = fib(5);        // 5

/** Probe requests in HALF_OPEN before closing: fib(4) = 3 */
const HALF_OPEN_PROBES  = fib(4);        // 3

/** Base recovery timeout (ms): fib(10) × fib(3) = 55 × 2 = 110ms base */
const BASE_RECOVERY_MS  = fib(10) * fib(3); // 110ms

/** Maximum recovery timeout: fib(11) × 1000ms = 89 000ms (~89s) */
const MAX_RECOVERY_MS   = fib(11) * 1000;   // 89 000ms

/** Successive OPEN cycles before alerting: from ALERT_THRESHOLDS */
const MAX_OPEN_CYCLES   = ALERT_THRESHOLDS.CRITICAL | 0 || fib(6); // 8

// ─── CircuitBreaker ───────────────────────────────────────────────────────────

/**
 * @class CircuitBreaker
 * @extends EventEmitter
 *
 * Events emitted:
 *   'stateChange'  – { from, to, reason }
 *   'failure'      – { error, failureCount }
 *   'success'      – { probeCount } (while HALF_OPEN)
 *   'rejected'     – { state }
 *   'alert'        – { message, openCycles }
 */
class CircuitBreaker extends EventEmitter {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.failureThreshold=5]   consecutive failures to open
   * @param {number}  [opts.halfOpenProbes=3]      successes to close from half-open
   * @param {number}  [opts.baseRecoveryMs=110]    base phi-backoff timeout (ms)
   * @param {number}  [opts.maxRecoveryMs=89000]   maximum backoff ceiling (ms)
   * @param {boolean} [opts.deterministic=false]   disable jitter (testing mode)
   */
  constructor(opts = {}) {
    super();

    this._failureThreshold = opts.failureThreshold ?? FAILURE_THRESHOLD;
    this._halfOpenProbes   = opts.halfOpenProbes   ?? HALF_OPEN_PROBES;
    this._baseRecoveryMs   = opts.baseRecoveryMs   ?? BASE_RECOVERY_MS;
    this._maxRecoveryMs    = opts.maxRecoveryMs    ?? MAX_RECOVERY_MS;
    this._deterministic    = opts.deterministic    ?? false;

    this._state          = STATE.CLOSED;
    this._failureCount   = 0;
    this._successCount   = 0; // probes in HALF_OPEN
    this._recoveryAttempt = 0; // phi-backoff exponent
    this._openAt         = null;
    this._recoveryDelay  = 0;
    this._openCycles     = 0;
    this._totalCalls     = 0;
    this._totalFailures  = 0;
    this._totalSuccesses = 0;
    this._lastError      = null;
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Execute a function through the circuit breaker.
   * @param {function(): Promise<*>} fn  async function to guard
   * @returns {Promise<*>}
   * @throws {Error} when circuit is OPEN or fn throws
   */
  async execute(fn) {
    this._totalCalls++;
    this._maybeTransitionHalfOpen();

    if (this._state === STATE.OPEN) {
      const err = new Error(`CircuitBreaker OPEN (attempt ${this._recoveryAttempt}, retry in ${this._recoveryDelay}ms)`);
      err.code = 'CIRCUIT_OPEN';
      this.emit('rejected', { state: STATE.OPEN, recoveryDelay: this._recoveryDelay });
      throw err;
    }

    try {
      const result = await fn();
      this._onSuccess();
      return result;
    } catch (err) {
      this._onFailure(err);
      throw err;
    }
  }

  /** @returns {string} current circuit state */
  getState() {
    return this._state;
  }

  /** Hard-reset to CLOSED, clearing all counters. */
  reset() {
    const prev = this._state;
    this._state           = STATE.CLOSED;
    this._failureCount    = 0;
    this._successCount    = 0;
    this._recoveryAttempt = 0;
    this._openAt          = null;
    this._recoveryDelay   = 0;
    this._openCycles      = 0;
    this._lastError       = null;
    if (prev !== STATE.CLOSED) {
      this.emit('stateChange', { from: prev, to: STATE.CLOSED, reason: 'manual reset' });
    }
  }

  /**
   * @returns {{
   *   state: string,
   *   failureCount: number,
   *   successCount: number,
   *   totalCalls: number,
   *   totalFailures: number,
   *   totalSuccesses: number,
   *   recoveryAttempt: number,
   *   recoveryDelay: number,
   *   openCycles: number,
   *   lastError: string|null
   * }}
   */
  getStats() {
    return {
      state:           this._state,
      failureCount:    this._failureCount,
      successCount:    this._successCount,
      totalCalls:      this._totalCalls,
      totalFailures:   this._totalFailures,
      totalSuccesses:  this._totalSuccesses,
      recoveryAttempt: this._recoveryAttempt,
      recoveryDelay:   this._recoveryDelay,
      openCycles:      this._openCycles,
      lastError:       this._lastError ? this._lastError.message : null,
    };
  }

  // ─── Internal Helpers ────────────────────────────────────────────────────────

  /** Called on a successful execution. */
  _onSuccess() {
    this._totalSuccesses++;
    this._lastError = null;

    if (this._state === STATE.HALF_OPEN) {
      this._successCount++;
      this.emit('success', { probeCount: this._successCount });

      if (this._successCount >= this._halfOpenProbes) {
        this._transitionTo(STATE.CLOSED, `${this._halfOpenProbes} probes passed`);
      }
    } else if (this._state === STATE.CLOSED) {
      // Successful call resets rolling failure count
      this._failureCount = 0;
    }
  }

  /** Called on a failed execution. */
  _onFailure(err) {
    this._totalFailures++;
    this._failureCount++;
    this._lastError = err;
    this.emit('failure', { error: err, failureCount: this._failureCount });

    if (this._state === STATE.HALF_OPEN) {
      // Probe failed → back to OPEN with incremented backoff
      this._recoveryAttempt++;
      this._transitionTo(STATE.OPEN, `HALF_OPEN probe failed: ${err.message}`);
    } else if (this._state === STATE.CLOSED && this._failureCount >= this._failureThreshold) {
      this._transitionTo(STATE.OPEN, `${this._failureCount} consecutive failures (threshold: ${this._failureThreshold})`);
    }
  }

  /**
   * Check if enough time has passed to probe recovery from OPEN → HALF_OPEN.
   */
  _maybeTransitionHalfOpen() {
    if (this._state !== STATE.OPEN) return;
    if (this._openAt === null) return;

    const elapsed = Date.now() - this._openAt;
    if (elapsed >= this._recoveryDelay) {
      this._transitionTo(STATE.HALF_OPEN, `recovery timeout elapsed (${elapsed}ms >= ${this._recoveryDelay}ms)`);
    }
  }

  /**
   * Centralized state machine transition with event emission.
   * @param {string} newState
   * @param {string} reason
   */
  _transitionTo(newState, reason) {
    const prev = this._state;
    this._state = newState;

    if (newState === STATE.OPEN) {
      this._openAt       = Date.now();
      this._successCount = 0;
      this._openCycles++;

      // Phi-backoff for recovery delay
      const backoffFn = this._deterministic ? phiBackoffDeterministic : phiBackoff;
      this._recoveryDelay = backoffFn(this._recoveryAttempt, this._baseRecoveryMs, this._maxRecoveryMs);

      if (this._openCycles >= MAX_OPEN_CYCLES) {
        this.emit('alert', {
          message:    `CircuitBreaker has cycled OPEN ${this._openCycles} times`,
          openCycles: this._openCycles,
        });
      }
    }

    if (newState === STATE.CLOSED) {
      this._failureCount    = 0;
      this._successCount    = 0;
      this._recoveryAttempt = 0;
      this._openAt          = null;
      this._recoveryDelay   = 0;
    }

    if (newState === STATE.HALF_OPEN) {
      this._successCount = 0;
    }

    this.emit('stateChange', { from: prev, to: newState, reason });
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports = { CircuitBreaker, STATE, FAILURE_THRESHOLD, HALF_OPEN_PROBES };
