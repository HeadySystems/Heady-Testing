'use strict';

/**
 * @module resilience/self-healing-lifecycle
 * @description Phi-native self-healing lifecycle manager for autonomous agents/units.
 *   Manages state transitions between healthy → suspect → quarantined → recovering
 *   → restored with cryptographic attestation, phi-scaled cooldowns, and
 *   recovery action orchestration.
 */

const { EventEmitter } = require('events');
const crypto = require('crypto');
const {
  PHI,
  PSI,
  fib,
  phiBackoff,
  phiAdaptiveInterval,
  PRESSURE_LEVELS,
  classifyPressure,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');
const { cosineSimilarity } = require('../shared/sacred-geometry');

// ─── Lifecycle State Constants ────────────────────────────────────────────────

/** @enum {string} Unit lifecycle states */
const LIFECYCLE = Object.freeze({
  HEALTHY:      'healthy',
  SUSPECT:      'suspect',
  QUARANTINED:  'quarantined',
  RECOVERING:   'recovering',
  RESTORED:     'restored',
});

// ─── Phi/Fibonacci Limits ─────────────────────────────────────────────────────

/** Max consecutive suspect-to-quarantine cycles before escalation: fib(5)=5 */
const MAX_QUARANTINE_CYCLES = fib(5);

/** Phi-scaled cooldown base (ms): fib(8)=21 × 1000ms = 21 000ms */
const COOLDOWN_BASE_MS = fib(8) * 1000;

/** Maximum cooldown ceiling (ms): fib(11)=89 × 1000ms */
const COOLDOWN_MAX_MS = fib(11) * 1000;

/** Max recovery attempts before escalating to human: fib(4)=3 */
const MAX_AUTO_RECOVERY = fib(4);

/** Drift tolerance ratio using PSI: 1 - PSI ≈ 0.382 (38.2%) */
const DRIFT_TOLERANCE = PSI;

// ─── Valid State Transitions ──────────────────────────────────────────────────

const VALID_TRANSITIONS = new Map([
  [LIFECYCLE.HEALTHY,     new Set([LIFECYCLE.SUSPECT])],
  [LIFECYCLE.SUSPECT,     new Set([LIFECYCLE.HEALTHY, LIFECYCLE.QUARANTINED])],
  [LIFECYCLE.QUARANTINED, new Set([LIFECYCLE.RECOVERING, LIFECYCLE.SUSPECT])],
  [LIFECYCLE.RECOVERING,  new Set([LIFECYCLE.RESTORED, LIFECYCLE.QUARANTINED])],
  [LIFECYCLE.RESTORED,    new Set([LIFECYCLE.HEALTHY, LIFECYCLE.SUSPECT])],
]);

// ─── SelfHealingLifecycle ─────────────────────────────────────────────────────

/**
 * @class SelfHealingLifecycle
 * @extends EventEmitter
 *
 * Events emitted:
 *   'transition'       – { unit, from, to, reason, ts }
 *   'quarantine'       – { unit, reason, cooldownMs }
 *   'recovery:start'   – { unit, action, attempt }
 *   'recovery:success' – { unit, action, attempt }
 *   'recovery:fail'    – { unit, action, attempt, error }
 *   'attestation'      – { unit, attestationHash }
 *   'escalate'         – { unit, reason, cycleCount }
 *   'drift'            – { unit, driftRatio }
 *   'canary:fail'      – { unit, reason }
 */
class SelfHealingLifecycle extends EventEmitter {
  constructor() {
    super();
    /** @type {Map<string, object>} unit metadata keyed by unitId */
    this._units = new Map();
    /** @type {Array<object>} immutable audit log */
    this._auditLog = [];
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Register a new unit into the lifecycle system.
   * @param {string} unitId  unique identifier for the unit
   * @param {object} [meta]  optional metadata (version, capabilities, etc.)
   * @returns {object} unit record
   */
  register(unitId, meta = {}) {
    if (this._units.has(unitId)) throw new Error(`Unit ${unitId} already registered`);
    const record = {
      unitId,
      state:            LIFECYCLE.HEALTHY,
      meta,
      quarantineCycles: 0,
      recoveryAttempts: 0,
      cooldownUntil:    0,
      attestationHash:  null,
      baselineVector:   meta.vector || null,
      history:          [],
      registeredAt:     Date.now(),
    };
    this._units.set(unitId, record);
    return record;
  }

  /**
   * Transition a unit to a new lifecycle state.
   * @param {string} unitId
   * @param {string} newState  one of LIFECYCLE values
   * @param {string} [reason]
   * @returns {object} updated unit record
   * @throws {Error} on invalid transition or unknown unit
   */
  transition(unitId, newState, reason = '') {
    const unit = this._getUnit(unitId);
    const allowed = VALID_TRANSITIONS.get(unit.state);

    if (!allowed || !allowed.has(newState)) {
      throw new Error(
        `Invalid transition ${unit.state} → ${newState} for unit ${unitId}`
      );
    }

    const from = unit.state;
    unit.state = newState;
    const entry = { from, to: newState, reason, ts: Date.now() };
    unit.history.push(entry);
    this._auditLog.push({ unitId, ...entry });

    this.emit('transition', { unit: unitId, ...entry });
    this._handleTransitionSideEffects(unit, from, newState, reason);
    return unit;
  }

  /**
   * Quarantine a unit: move to QUARANTINED with phi-scaled cooldown.
   * @param {string} unitId
   * @param {string} [reason]
   */
  quarantine(unitId, reason = 'threshold exceeded') {
    const unit = this._getUnit(unitId);
    unit.quarantineCycles++;
    unit.recoveryAttempts = 0;
    unit.attestationHash  = null;

    // Phi-backoff cooldown scales with quarantine cycle count
    const cooldownMs = phiBackoff(unit.quarantineCycles, COOLDOWN_BASE_MS, COOLDOWN_MAX_MS);
    unit.cooldownUntil = Date.now() + cooldownMs;

    this.transition(unitId, LIFECYCLE.QUARANTINED, reason);
    this.emit('quarantine', { unit: unitId, reason, cooldownMs });

    if (unit.quarantineCycles >= MAX_QUARANTINE_CYCLES) {
      this.emit('escalate', {
        unit:       unitId,
        reason:     `Quarantine cycle limit (${MAX_QUARANTINE_CYCLES}) reached`,
        cycleCount: unit.quarantineCycles,
      });
    }
  }

  /**
   * Initiate recovery for a quarantined unit.
   * Automatically selects recovery action based on attempt count.
   * @param {string} unitId
   * @param {object} [recoveryCtx]  optional context passed to actions
   * @returns {Promise<boolean>} true if recovery succeeded
   */
  async recover(unitId, recoveryCtx = {}) {
    const unit = this._getUnit(unitId);

    if (unit.state !== LIFECYCLE.QUARANTINED) {
      throw new Error(`Unit ${unitId} must be QUARANTINED to begin recovery (current: ${unit.state})`);
    }

    const now = Date.now();
    if (now < unit.cooldownUntil) {
      const remaining = unit.cooldownUntil - now;
      throw new Error(`Unit ${unitId} still in cooldown for ${remaining}ms`);
    }

    unit.recoveryAttempts++;
    const action = this._selectRecoveryAction(unit);
    this.emit('recovery:start', { unit: unitId, action, attempt: unit.recoveryAttempts });

    this.transition(unitId, LIFECYCLE.RECOVERING, `Action: ${action}`);

    try {
      await this._executeRecoveryAction(unit, action, recoveryCtx);
      this.emit('recovery:success', { unit: unitId, action, attempt: unit.recoveryAttempts });
      return true;
    } catch (err) {
      this.emit('recovery:fail', { unit: unitId, action, attempt: unit.recoveryAttempts, error: err });
      this.transition(unitId, LIFECYCLE.QUARANTINED, `Recovery action "${action}" failed: ${err.message}`);
      return false;
    }
  }

  /**
   * Attest a recovering unit before restoration.
   * @param {string} unitId
   * @param {Buffer|string} attestationPayload  signed proof of health
   * @returns {string} attestation hash
   */
  attest(unitId, attestationPayload) {
    const unit = this._getUnit(unitId);
    if (unit.state !== LIFECYCLE.RECOVERING) {
      throw new Error(`Unit ${unitId} must be RECOVERING to attest (current: ${unit.state})`);
    }

    const hash = crypto
      .createHash('sha256')
      .update(unitId)
      .update(String(Date.now()))
      .update(attestationPayload instanceof Buffer ? attestationPayload : Buffer.from(String(attestationPayload)))
      .digest('hex');

    unit.attestationHash = hash;
    this.emit('attestation', { unit: unitId, attestationHash: hash });

    // Attestation clears path to RESTORED
    this.transition(unitId, LIFECYCLE.RESTORED, `Attested: ${hash.slice(0, 16)}…`);
    return hash;
  }

  /**
   * Check canary validation for a unit (drift detection).
   * @param {string} unitId
   * @param {number[]} currentVector  current behavior embedding
   */
  checkDrift(unitId, currentVector) {
    const unit = this._getUnit(unitId);
    if (!unit.baselineVector) {
      unit.baselineVector = currentVector;
      return;
    }

    const similarity = cosineSimilarity(unit.baselineVector, currentVector);
    const driftRatio  = 1 - similarity;

    if (driftRatio > DRIFT_TOLERANCE) {
      this.emit('drift', { unit: unitId, driftRatio });
      if (unit.state === LIFECYCLE.HEALTHY) {
        this.transition(unitId, LIFECYCLE.SUSPECT, `Drift detected: ${(driftRatio * 100).toFixed(1)}% (tolerance: ${(DRIFT_TOLERANCE * 100).toFixed(1)}%)`);
      }
    }
  }

  /**
   * Mark a RESTORED unit as HEALTHY (requires prior attestation).
   * @param {string} unitId
   */
  restore(unitId) {
    const unit = this._getUnit(unitId);
    if (unit.state !== LIFECYCLE.RESTORED) {
      throw new Error(`Unit ${unitId} must be in RESTORED state (current: ${unit.state})`);
    }
    if (!unit.attestationHash) {
      throw new Error(`Unit ${unitId} has not been attested`);
    }
    this.transition(unitId, LIFECYCLE.HEALTHY, 'Restoration validated');
    unit.quarantineCycles = 0;
    unit.recoveryAttempts = 0;
  }

  /**
   * @returns {Map<string, object>} full lifecycle map of all registered units
   */
  getLifecycleMap() {
    return new Map(this._units);
  }

  // ─── Internal Helpers ────────────────────────────────────────────────────────

  _getUnit(unitId) {
    const unit = this._units.get(unitId);
    if (!unit) throw new Error(`Unit ${unitId} not registered`);
    return unit;
  }

  /**
   * Select recovery action based on attempt count (fib-indexed escalation).
   * @param {object} unit
   * @returns {string} action name
   */
  _selectRecoveryAction(unit) {
    const attempt = unit.recoveryAttempts;
    if (attempt <= fib(2))        return 'retry';      // attempt 1: retry
    if (attempt <= fib(3))        return 'respawn';    // attempt 2: respawn
    if (attempt <= fib(4))        return 'rollback';   // attempts 3: rollback
    if (attempt < MAX_AUTO_RECOVERY) return 'rollback'; // attempts until max
    return 'escalateToHuman';                          // beyond auto limit
  }

  /**
   * Execute recovery action with phi-backoff delay.
   * @param {object} unit
   * @param {string} action
   * @param {object} ctx
   */
  async _executeRecoveryAction(unit, action, ctx) {
    const delay = phiBackoff(unit.recoveryAttempts, fib(6) * 100, fib(11) * 1000);

    switch (action) {
      case 'retry':
        await this._delay(delay);
        if (ctx.retryFn) await ctx.retryFn(unit, ctx);
        break;
      case 'respawn':
        await this._delay(delay);
        if (ctx.respawnFn) await ctx.respawnFn(unit, ctx);
        break;
      case 'rollback':
        await this._delay(delay);
        if (ctx.rollbackFn) await ctx.rollbackFn(unit, ctx);
        break;
      case 'escalateToHuman':
        this.emit('escalate', {
          unit:       unit.unitId,
          reason:     'Max auto-recovery attempts exhausted',
          cycleCount: unit.quarantineCycles,
        });
        if (ctx.escalateFn) await ctx.escalateFn(unit, ctx);
        break;
      default:
        throw new Error(`Unknown recovery action: ${action}`);
    }
  }

  /**
   * Side effects on state entry.
   * @param {object} unit
   * @param {string} from
   * @param {string} to
   * @param {string} reason
   */
  _handleTransitionSideEffects(unit, from, to, reason) {
    if (to === LIFECYCLE.HEALTHY) {
      // Reset drift baseline on return to health
      unit.baselineVector = null;
    }
    if (to === LIFECYCLE.SUSPECT && from === LIFECYCLE.RESTORED) {
      // Re-quarantine immediately if suspect after restoration
      this.emit('canary:fail', { unit: unit.unitId, reason });
    }
  }

  /** @param {number} ms */
  _delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports = {
  SelfHealingLifecycle,
  LIFECYCLE,
  MAX_QUARANTINE_CYCLES,
  MAX_AUTO_RECOVERY,
  DRIFT_TOLERANCE,
};
