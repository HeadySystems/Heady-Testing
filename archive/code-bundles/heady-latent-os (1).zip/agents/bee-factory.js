/**
 * @fileoverview BeeFactory — Dynamic Agent Worker Factory
 *
 * 91 bee type definitions across 24 domains. Creates persistent and ephemeral
 * bee workers, maintains a central registry, and applies φ-scaled load balancing
 * with adaptive heartbeat intervals.
 *
 * @module agents/bee-factory
 * @version 3.0.0
 */

'use strict';

const events = require('events');
const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib, CSL_THRESHOLDS, DEDUP_THRESHOLD,
  phiFusionWeights, phiBackoff, phiResourceWeights, phiMultiSplit,
  cslGate, sigmoid, POOL_ALLOCATION, PRESSURE_LEVELS,
  classifyPressure, phiPriorityScore, phiAdaptiveInterval,
} = require('../shared/phi-math');
const { cosineSimilarity, RINGS } = require('../shared/sacred-geometry');
const { cslAND, cslCONSENSUS, cslPhiGATE, normalize, hdcRandomVector, EMBEDDING_DIM } = require('../shared/csl-engine');

// ─── DOMAIN DEFINITIONS ────────────────────────────────────────────────────────

/** 24 bee capability domains */
const BEE_DOMAINS = Object.freeze([
  'code', 'deploy', 'research', 'security', 'monitor', 'creative',
  'translation', 'analytics', 'maintenance', 'documentation', 'cloud',
  'testing', 'data', 'ui', 'devops', 'ai', 'mobile', 'db', 'api',
  'integration', 'performance', 'accessibility', 'compliance', 'community',
]);

// ─── BEE TYPE DEFINITIONS ──────────────────────────────────────────────────────
// 91 bees spread across 24 domains. Priority weights use Fibonacci numbers.
// pool: 'Hot' | 'Warm' | 'Cold'

const BEE_DEFINITIONS = Object.freeze([
  // ── code (fib(4)=4 bees — keeps total at 91) ──
  { name: 'CodeSynth',       domain: 'code',          pool: 'Hot',  priority: fib(7) },
  { name: 'CodeReview',      domain: 'code',          pool: 'Hot',  priority: fib(6) },
  { name: 'CodeRefactor',    domain: 'code',          pool: 'Warm', priority: fib(5) },
  { name: 'CodeDebug',       domain: 'code',          pool: 'Hot',  priority: fib(7) },

  // ── deploy (4 bees) ──
  { name: 'DeployOrch',      domain: 'deploy',        pool: 'Hot',  priority: fib(7) },
  { name: 'DeployRollback',  domain: 'deploy',        pool: 'Hot',  priority: fib(6) },
  { name: 'DeployCanary',    domain: 'deploy',        pool: 'Warm', priority: fib(5) },
  { name: 'DeployVerify',    domain: 'deploy',        pool: 'Warm', priority: fib(5) },

  // ── research (4 bees) ──
  { name: 'ResearchQuery',   domain: 'research',      pool: 'Warm', priority: fib(6) },
  { name: 'ResearchSynth',   domain: 'research',      pool: 'Warm', priority: fib(5) },
  { name: 'ResearchCite',    domain: 'research',      pool: 'Cold', priority: fib(4) },
  { name: 'ResearchFact',    domain: 'research',      pool: 'Warm', priority: fib(5) },

  // ── security (4 bees) ──
  { name: 'SecScan',         domain: 'security',      pool: 'Hot',  priority: fib(8) },
  { name: 'SecPatch',        domain: 'security',      pool: 'Hot',  priority: fib(7) },
  { name: 'SecAudit',        domain: 'security',      pool: 'Warm', priority: fib(6) },
  { name: 'SecThreat',       domain: 'security',      pool: 'Hot',  priority: fib(8) },

  // ── monitor (4 bees) ──
  { name: 'MonMetric',       domain: 'monitor',       pool: 'Hot',  priority: fib(7) },
  { name: 'MonAlert',        domain: 'monitor',       pool: 'Hot',  priority: fib(7) },
  { name: 'MonLog',          domain: 'monitor',       pool: 'Warm', priority: fib(5) },
  { name: 'MonTrace',        domain: 'monitor',       pool: 'Warm', priority: fib(6) },

  // ── creative (4 bees) ──
  { name: 'CreativeWrite',   domain: 'creative',      pool: 'Warm', priority: fib(5) },
  { name: 'CreativeDesign',  domain: 'creative',      pool: 'Warm', priority: fib(5) },
  { name: 'CreativeBrand',   domain: 'creative',      pool: 'Cold', priority: fib(4) },
  { name: 'CreativeVideo',   domain: 'creative',      pool: 'Cold', priority: fib(3) },

  // ── translation (3 bees) ──
  { name: 'TransLang',       domain: 'translation',   pool: 'Warm', priority: fib(5) },
  { name: 'TransLocal',      domain: 'translation',   pool: 'Cold', priority: fib(4) },
  { name: 'TransFormat',     domain: 'translation',   pool: 'Cold', priority: fib(4) },

  // ── analytics (4 bees) ──
  { name: 'AnalyticsStat',   domain: 'analytics',     pool: 'Warm', priority: fib(6) },
  { name: 'AnalyticsViz',    domain: 'analytics',     pool: 'Warm', priority: fib(5) },
  { name: 'AnalyticsReport', domain: 'analytics',     pool: 'Warm', priority: fib(5) },
  { name: 'AnalyticsPredict',domain: 'analytics',     pool: 'Hot',  priority: fib(6) },

  // ── maintenance (4 bees) ──
  { name: 'MaintClean',      domain: 'maintenance',   pool: 'Cold', priority: fib(4) },
  { name: 'MaintHealth',     domain: 'maintenance',   pool: 'Warm', priority: fib(5) },
  { name: 'MaintUpgrade',    domain: 'maintenance',   pool: 'Warm', priority: fib(5) },
  { name: 'MaintBackup',     domain: 'maintenance',   pool: 'Cold', priority: fib(4) },

  // ── documentation (4 bees) ──
  { name: 'DocGen',          domain: 'documentation', pool: 'Warm', priority: fib(5) },
  { name: 'DocUpdate',       domain: 'documentation', pool: 'Warm', priority: fib(4) },
  { name: 'DocSearch',       domain: 'documentation', pool: 'Cold', priority: fib(3) },
  { name: 'DocReview',       domain: 'documentation', pool: 'Warm', priority: fib(5) },

  // ── cloud (4 bees) ──
  { name: 'CloudProvision',  domain: 'cloud',         pool: 'Hot',  priority: fib(7) },
  { name: 'CloudScale',      domain: 'cloud',         pool: 'Hot',  priority: fib(7) },
  { name: 'CloudCost',       domain: 'cloud',         pool: 'Warm', priority: fib(5) },
  { name: 'CloudDR',         domain: 'cloud',         pool: 'Warm', priority: fib(6) },

  // ── testing (4 bees) ──
  { name: 'TestUnit',        domain: 'testing',       pool: 'Hot',  priority: fib(7) },
  { name: 'TestInteg',       domain: 'testing',       pool: 'Hot',  priority: fib(6) },
  { name: 'TestE2E',         domain: 'testing',       pool: 'Warm', priority: fib(6) },
  { name: 'TestFuzz',        domain: 'testing',       pool: 'Warm', priority: fib(5) },

  // ── data (4 bees) ──
  { name: 'DataIngest',      domain: 'data',          pool: 'Hot',  priority: fib(7) },
  { name: 'DataTransform',   domain: 'data',          pool: 'Hot',  priority: fib(6) },
  { name: 'DataValidate',    domain: 'data',          pool: 'Warm', priority: fib(5) },
  { name: 'DataLineage',     domain: 'data',          pool: 'Warm', priority: fib(5) },

  // ── ui (4 bees) ──
  { name: 'UIBuild',         domain: 'ui',            pool: 'Warm', priority: fib(6) },
  { name: 'UITest',          domain: 'ui',            pool: 'Warm', priority: fib(5) },
  { name: 'UIPerf',          domain: 'ui',            pool: 'Warm', priority: fib(5) },
  { name: 'UIDesignToken',   domain: 'ui',            pool: 'Cold', priority: fib(4) },

  // ── devops (4 bees) ──
  { name: 'DevOpsCICD',      domain: 'devops',        pool: 'Hot',  priority: fib(7) },
  { name: 'DevOpsIaC',       domain: 'devops',        pool: 'Hot',  priority: fib(7) },
  { name: 'DevOpsSecret',    domain: 'devops',        pool: 'Hot',  priority: fib(8) },
  { name: 'DevOpsRelease',   domain: 'devops',        pool: 'Hot',  priority: fib(7) },

  // ── ai (4 bees) ──
  { name: 'AITrain',         domain: 'ai',            pool: 'Hot',  priority: fib(8) },
  { name: 'AIInfer',         domain: 'ai',            pool: 'Hot',  priority: fib(8) },
  { name: 'AIEval',          domain: 'ai',            pool: 'Warm', priority: fib(6) },
  { name: 'AITune',          domain: 'ai',            pool: 'Warm', priority: fib(6) },

  // ── mobile (3 bees) ──
  { name: 'MobileBuild',     domain: 'mobile',        pool: 'Warm', priority: fib(5) },
  { name: 'MobileTest',      domain: 'mobile',        pool: 'Warm', priority: fib(5) },
  { name: 'MobileRelease',   domain: 'mobile',        pool: 'Warm', priority: fib(5) },

  // ── db (4 bees) ──
  { name: 'DBQuery',         domain: 'db',            pool: 'Hot',  priority: fib(7) },
  { name: 'DBMigrate',       domain: 'db',            pool: 'Hot',  priority: fib(7) },
  { name: 'DBIndex',         domain: 'db',            pool: 'Warm', priority: fib(5) },
  { name: 'DBBackup',        domain: 'db',            pool: 'Warm', priority: fib(5) },

  // ── api (4 bees) ──
  { name: 'APIDesign',       domain: 'api',           pool: 'Warm', priority: fib(6) },
  { name: 'APITest',         domain: 'api',           pool: 'Hot',  priority: fib(6) },
  { name: 'APIDoc',          domain: 'api',           pool: 'Warm', priority: fib(5) },
  { name: 'APIGateway',      domain: 'api',           pool: 'Hot',  priority: fib(7) },

  // ── integration (3 bees) ──
  { name: 'IntegWebhook',    domain: 'integration',   pool: 'Hot',  priority: fib(6) },
  { name: 'IntegETL',        domain: 'integration',   pool: 'Hot',  priority: fib(6) },
  { name: 'IntegEvent',      domain: 'integration',   pool: 'Hot',  priority: fib(6) },

  // ── performance (4 bees) ──
  { name: 'PerfProfile',     domain: 'performance',   pool: 'Warm', priority: fib(6) },
  { name: 'PerfBench',       domain: 'performance',   pool: 'Warm', priority: fib(6) },
  { name: 'PerfOptimize',    domain: 'performance',   pool: 'Warm', priority: fib(6) },
  { name: 'PerfLoad',        domain: 'performance',   pool: 'Hot',  priority: fib(7) },

  // ── accessibility (3 bees) ──
  { name: 'A11yAudit',       domain: 'accessibility', pool: 'Warm', priority: fib(5) },
  { name: 'A11yFix',         domain: 'accessibility', pool: 'Warm', priority: fib(5) },
  { name: 'A11yScreen',      domain: 'accessibility', pool: 'Cold', priority: fib(4) },

  // ── compliance (4 bees) ──
  { name: 'ComplianceScan',  domain: 'compliance',    pool: 'Hot',  priority: fib(7) },
  { name: 'ComplianceReport',domain: 'compliance',    pool: 'Warm', priority: fib(6) },
  { name: 'ComplianceAudit', domain: 'compliance',    pool: 'Warm', priority: fib(6) },
  { name: 'CompliancePolicy',domain: 'compliance',    pool: 'Cold', priority: fib(5) },

  // ── community (3 bees) ──
  { name: 'CommForumMod',    domain: 'community',     pool: 'Warm', priority: fib(5) },
  { name: 'CommOutreach',    domain: 'community',     pool: 'Cold', priority: fib(4) },
  { name: 'CommFeedback',    domain: 'community',     pool: 'Warm', priority: fib(5) },
]);

// Heartbeat base interval: fib(7) * fib(4) * 1000 = 13 * 3 * 1000 = 39 000 ms
const HEARTBEAT_BASE_MS = fib(7) * fib(4) * 1000;

// ─── BEE FACTORY ───────────────────────────────────────────────────────────────

/**
 * BeeFactory — creates, registers, and balances bee worker instances.
 * @extends events.EventEmitter
 */
class BeeFactory extends events.EventEmitter {
  constructor() {
    super();

    /** @type {Map<string, object>} Central bee registry: id → beeRecord */
    this._registry = new Map();

    /** Running counter for unique IDs — starts at fib(1)=1 */
    this._idCounter = fib(1);

    /** Pool capacity split using phi: [Hot, Warm, Cold] from phiMultiSplit */
    this._poolCapacity = phiMultiSplit(fib(11), fib(3)); // fib(11)=89 across 3 pools

    this.emit('init', { domains: BEE_DOMAINS.length, types: BEE_DEFINITIONS.length });
  }

  // ─── LIFECYCLE HOOKS ─────────────────────────────────────────────────────────

  /** Called once a bee is fully initialised. */
  onInit(bee) {
    this.emit('bee:init', { id: bee.id, type: bee.type, domain: bee.domain });
  }

  /** Called on each heartbeat tick for a bee. */
  onHeartbeat(bee) {
    bee.health.lastHeartbeat = Date.now();
    bee.health.heartbeatInterval = phiAdaptiveInterval(
      HEARTBEAT_BASE_MS,
      bee.health.healthy,
      bee.health.heartbeatInterval,
    );
    this.emit('bee:heartbeat', { id: bee.id, healthy: bee.health.healthy });
  }

  /** Called when a bee is being shut down. */
  onShutdown(bee) {
    bee.status = 'shutdown';
    this.emit('bee:shutdown', { id: bee.id });
  }

  // ─── CORE FACTORY METHODS ────────────────────────────────────────────────────

  /**
   * Create a persistent bee worker that remains in the registry.
   * @param {string} type - Bee type name (must exist in BEE_DEFINITIONS)
   * @param {object} [config={}] - Optional configuration overrides
   * @returns {object} Bee record
   */
  createBee(type, config = {}) {
    const def = BEE_DEFINITIONS.find(d => d.name === type);
    if (!def) throw new Error(`Unknown bee type: ${type}`);

    const id = `bee-${type}-${this._idCounter++}`;
    const embedding = hdcRandomVector(EMBEDDING_DIM);

    // φ-fusion load weight: domain index × ψ-decay
    const domainIdx = BEE_DOMAINS.indexOf(def.domain);
    const fusionWeights = phiFusionWeights(BEE_DOMAINS.length);
    const loadWeight = fusionWeights[domainIdx] * def.priority;

    const bee = {
      id,
      type,
      domain: def.domain,
      pool: def.pool,
      priority: def.priority,
      loadWeight,
      embedding,
      status: 'active',
      ephemeral: false,
      config: Object.assign({}, config),
      health: {
        healthy: true,
        heartbeatInterval: HEARTBEAT_BASE_MS,
        lastHeartbeat: Date.now(),
        failureCount: fib(0), // starts at 0
        successCount: fib(0),
      },
      createdAt: Date.now(),
    };

    this.register(bee);
    this.onInit(bee);
    return bee;
  }

  /**
   * Spawn an ephemeral bee for a one-time task.
   * Not stored in the registry after completion.
   * @param {string} type - Bee type name
   * @param {object} context - Task context
   * @returns {object} Ephemeral bee record
   */
  spawnBee(type, context = {}) {
    const def = BEE_DEFINITIONS.find(d => d.name === type);
    if (!def) throw new Error(`Unknown bee type: ${type}`);

    const id = `ephemeral-${type}-${this._idCounter++}`;
    const embedding = hdcRandomVector(EMBEDDING_DIM);

    const bee = {
      id,
      type,
      domain: def.domain,
      pool: def.pool,
      priority: def.priority,
      loadWeight: def.priority * PSI,
      embedding,
      status: 'spawned',
      ephemeral: true,
      context: Object.assign({}, context),
      health: {
        healthy: true,
        heartbeatInterval: HEARTBEAT_BASE_MS * PSI, // faster for ephemeral
        lastHeartbeat: Date.now(),
        failureCount: fib(0),
        successCount: fib(0),
      },
      createdAt: Date.now(),
    };

    this.emit('bee:spawned', { id, type, domain: def.domain });
    return bee;
  }

  /**
   * Destroy a bee — unregisters and emits shutdown.
   * @param {string} id - Bee ID
   */
  destroyBee(id) {
    const bee = this._registry.get(id);
    if (!bee) return;
    this.onShutdown(bee);
    this.unregister(id);
  }

  // ─── REGISTRY OPERATIONS ─────────────────────────────────────────────────────

  /**
   * Register a bee in the central registry.
   * @param {object} bee
   */
  register(bee) {
    this._registry.set(bee.id, bee);
    this.emit('registry:add', { id: bee.id, total: this._registry.size });
  }

  /**
   * Unregister a bee by ID.
   * @param {string} id
   */
  unregister(id) {
    this._registry.delete(id);
    this.emit('registry:remove', { id, total: this._registry.size });
  }

  /**
   * Find bees matching a query object (domain, pool, status).
   * @param {object} query
   * @returns {object[]}
   */
  find(query = {}) {
    const results = [];
    for (const bee of this._registry.values()) {
      if (query.domain && bee.domain !== query.domain) continue;
      if (query.pool   && bee.pool   !== query.pool)   continue;
      if (query.status && bee.status !== query.status) continue;
      if (query.type   && bee.type   !== query.type)   continue;
      results.push(bee);
    }
    return results;
  }

  /**
   * List all registered bees.
   * @returns {object[]}
   */
  listAll() {
    return Array.from(this._registry.values());
  }

  // ─── STATUS & HEALTH ─────────────────────────────────────────────────────────

  /**
   * Get health and status for a single bee.
   * @param {string} id
   * @returns {object|null}
   */
  getBeeStatus(id) {
    const bee = this._registry.get(id);
    if (!bee) return null;
    return {
      id: bee.id,
      type: bee.type,
      domain: bee.domain,
      pool: bee.pool,
      status: bee.status,
      health: bee.health,
      loadWeight: bee.loadWeight,
      uptime: Date.now() - bee.createdAt,
    };
  }

  /**
   * Aggregate registry statistics.
   * @returns {object}
   */
  getRegistryStats() {
    const bees = this.listAll();
    const byPool = { Hot: fib(0), Warm: fib(0), Cold: fib(0) };
    const byDomain = {};
    let healthy = fib(0);

    for (const bee of bees) {
      byPool[bee.pool] = (byPool[bee.pool] || fib(0)) + fib(1);
      byDomain[bee.domain] = (byDomain[bee.domain] || fib(0)) + fib(1);
      if (bee.health.healthy) healthy++;
    }

    const total = bees.length;
    const healthRatio = total > fib(0) ? healthy / total : fib(1);

    return {
      total,
      healthy,
      healthRatio,
      pressure: classifyPressure(fib(1) - healthRatio),
      byPool,
      byDomain,
      poolCapacity: this._poolCapacity,
    };
  }

  // ─── PHI-SCALED LOAD BALANCING ───────────────────────────────────────────────

  /**
   * Rebalance load weights across all active bees using phiFusionWeights.
   * Bees in hotter pools receive higher weights.
   */
  rebalance() {
    const bees = this.find({ status: 'active' });
    if (bees.length === fib(0)) return;

    const weights = phiFusionWeights(bees.length);
    // Sort by priority descending so highest-priority bees get the heaviest φ-weights
    bees.sort((a, b) => b.priority - a.priority);

    bees.forEach((bee, idx) => {
      bee.loadWeight = weights[idx];
    });

    this.emit('rebalance', { count: bees.length, timestamp: Date.now() });
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  BeeFactory,
  BEE_DOMAINS,
  BEE_DEFINITIONS,
  HEARTBEAT_BASE_MS,
};
