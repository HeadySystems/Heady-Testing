/**
 * @fileoverview SemanticBackpressure — SRE Adaptive Throttle + Semantic Dedup
 *
 * Implements:
 *  • Google SRE adaptive throttle: P(reject) = max(0, (K·requests - accepts) / (K·requests + 1))
 *    where K = PHI (golden-ratio multiplier instead of the standard K=2)
 *  • Semantic deduplication: cosine ≥ DEDUP_THRESHOLD → return cached
 *  • LRU dedup cache: fib(17)=1597 entries, TTL = fib(11)*1000 = 89 000 ms
 *  • Priority scoring via phiPriorityScore with Fibonacci criticality weights
 *  • Pressure classification via classifyPressure
 *  • Circuit breaker: failureThreshold=fib(5)=5, halfOpenProbes=fib(4)=3
 *  • Load shedding at HIGH/CRITICAL pressure by criticality tier
 *  • Queue maxDepth = fib(13) = 233
 *
 * @module agents/semantic-backpressure
 * @version 3.0.0
 */

'use strict';

const events = require('events');
const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib, CSL_THRESHOLDS, DEDUP_THRESHOLD,
  phiFusionWeights, phiBackoff, phiResourceWeights, phiMultiSplit,
  cslGate, sigmoid, POOL_ALLOCATION, PRESSURE_LEVELS,
  classifyPressure, phiPriorityScore, phiAdaptiveInterval,
} = require('../shared/phi-math');
const { cosineSimilarity, RINGS } = require('../shared/sacred-geometry');
const { cslAND, cslCONSENSUS, cslPhiGATE, normalize, hdcRandomVector, EMBEDDING_DIM } = require('../shared/csl-engine');

// ─── MODULE-LEVEL CONSTANTS (ALL φ / FIBONACCI) ───────────────────────────────

/** SRE throttle multiplier K — golden ratio instead of standard K=2 */
const SRE_K = PHI; // ≈ 1.618

/**
 * Rolling window duration (ms).
 * Math.round(fib(11) * PHI * 1000) = Math.round(89 * 1.618 * 1000) ≈ 144 000 ms ≈ 2.4 min
 */
const WINDOW_MS = Math.round(fib(11) * PHI * 1000);

/** Dedup cache max entries: fib(17) = 1597 */
const CACHE_MAX_SIZE = fib(17);

/** Dedup TTL (ms): fib(11) * 1000 = 89 000 ms */
const CACHE_TTL_MS = fib(11) * 1000;

/** Queue max depth: fib(13) = 233 */
const QUEUE_MAX_DEPTH = fib(13);

/** Circuit breaker failure threshold: fib(5) = 5 */
const CB_FAILURE_THRESHOLD = fib(5);

/** Circuit breaker half-open probes: fib(4) = 3 */
const CB_HALF_OPEN_PROBES = fib(4);

/** Circuit breaker reset timeout (ms): fib(9) * 1000 = 34 000 ms */
const CB_RESET_TIMEOUT_MS = fib(9) * 1000;

/** Fibonacci criticality weights for priority scoring */
const CRITICALITY = Object.freeze({
  CRITICAL_PLUS: fib(7),   // 13
  CRITICAL:      fib(6),   // 8
  SHEDDABLE_PLUS: fib(5),  // 5
  SHEDDABLE:     fib(3),   // 2
});

/** Minimum priority score to survive HIGH-pressure shedding (ψ² ≈ 0.382) */
const SHED_HIGH_FLOOR = PSI_SQ;

/** Minimum priority score to survive CRITICAL-pressure shedding (ψ⁴ ≈ 0.146) */
const SHED_CRITICAL_FLOOR = PSI_FOURTH;

// ─── LRU CACHE ────────────────────────────────────────────────────────────────

/**
 * Minimal LRU cache backed by a Map (insertion-order).
 */
class LRUCache {
  /**
   * @param {number} maxSize - Maximum number of entries
   * @param {number} ttlMs   - Entry TTL in milliseconds
   */
  constructor(maxSize, ttlMs) {
    this._maxSize = maxSize;
    this._ttlMs = ttlMs;
    this._store = new Map(); // key → { value, expiresAt }
  }

  /**
   * Get a cached entry, returning undefined if absent or expired.
   * @param {string} key
   * @returns {*}
   */
  get(key) {
    const entry = this._store.get(key);
    if (!entry) return undefined;
    if (Date.now() > entry.expiresAt) {
      this._store.delete(key);
      return undefined;
    }
    // Refresh recency: delete + re-insert
    this._store.delete(key);
    this._store.set(key, entry);
    return entry.value;
  }

  /**
   * Set a cache entry, evicting LRU if at capacity.
   * @param {string} key
   * @param {*} value
   */
  set(key, value) {
    if (this._store.has(key)) this._store.delete(key);
    else if (this._store.size >= this._maxSize) {
      // Evict oldest (first inserted)
      this._store.delete(this._store.keys().next().value);
    }
    this._store.set(key, { value, expiresAt: Date.now() + this._ttlMs });
  }

  /** @returns {number} */
  get size() { return this._store.size; }

  /** Purge expired entries. */
  purgeExpired() {
    const now = Date.now();
    for (const [k, e] of this._store) {
      if (now > e.expiresAt) this._store.delete(k);
    }
  }
}

// ─── SEMANTIC BACKPRESSURE ────────────────────────────────────────────────────

/**
 * SemanticBackpressure — adaptive throttle, dedup, circuit breaker, shedding.
 * @extends events.EventEmitter
 */
class SemanticBackpressure extends events.EventEmitter {
  constructor() {
    super();

    // ── SRE Rolling-window counters ──
    /** Sliding window of request timestamps */
    this._requestWindow = [];
    /** Sliding window of accepted request timestamps */
    this._acceptWindow = [];

    // ── Dedup cache ──
    /** LRU dedup cache: taskHash → cached result */
    this._dedupCache = new LRUCache(CACHE_MAX_SIZE, CACHE_TTL_MS);

    /**
     * Recent embedding store for cosine-based dedup.
     * LRU of { embedding: number[], result: *, insertedAt: number }
     */
    this._embeddingStore = new LRUCache(CACHE_MAX_SIZE, CACHE_TTL_MS);

    // ── Task queue ──
    /** @type {object[]} Bounded FIFO queue */
    this._queue = [];

    // ── Circuit breaker ──
    this._cb = {
      state: 'CLOSED',  // CLOSED | OPEN | HALF_OPEN
      failures: fib(0),
      successesInHalfOpen: fib(0),
      openedAt: null,
    };

    // ── Lifetime counters ──
    this._counters = {
      totalRequests: fib(0),
      totalAccepts: fib(0),
      totalRejects: fib(0),
      totalDedup: fib(0),
      totalShed: fib(0),
      totalCBTrips: fib(0),
    };

    // Periodic cache GC: every fib(10) * 1000 = 55 000 ms
    this._gcTimer = setInterval(() => this._dedupCache.purgeExpired(), fib(10) * 1000);
    if (this._gcTimer.unref) this._gcTimer.unref();

    this.emit('backpressure:init', {
      windowMs: WINDOW_MS,
      cacheMax: CACHE_MAX_SIZE,
      cacheTtl: CACHE_TTL_MS,
      queueMax: QUEUE_MAX_DEPTH,
    });
  }

  // ─── SRE ADAPTIVE THROTTLE ───────────────────────────────────────────────────

  /**
   * Prune timestamps outside the current rolling window.
   * @private
   */
  _pruneWindow() {
    const cutoff = Date.now() - WINDOW_MS;
    this._requestWindow = this._requestWindow.filter(t => t > cutoff);
    this._acceptWindow  = this._acceptWindow.filter(t => t > cutoff);
  }

  /**
   * Compute current SRE reject probability.
   * P(reject) = max(0, (K×requests - accepts) / (K×requests + 1))
   * Uses K = PHI ≈ 1.618
   *
   * @returns {number} Reject probability [0, 1]
   */
  _sреRejectProb() {
    this._pruneWindow();
    const requests = this._requestWindow.length;
    const accepts  = this._acceptWindow.length;
    const numerator = SRE_K * requests - accepts;
    const denominator = SRE_K * requests + fib(1); // fib(1)=1
    return Math.max(0, numerator / denominator);
  }

  // ─── CIRCUIT BREAKER ─────────────────────────────────────────────────────────

  /**
   * Evaluate circuit breaker state, transitioning as needed.
   * @returns {'CLOSED'|'OPEN'|'HALF_OPEN'}
   */
  _cbState() {
    if (this._cb.state === 'OPEN') {
      const elapsed = Date.now() - this._cb.openedAt;
      if (elapsed >= CB_RESET_TIMEOUT_MS) {
        this._cb.state = 'HALF_OPEN';
        this._cb.successesInHalfOpen = fib(0);
        this.emit('cb:halfopen');
      }
    }
    return this._cb.state;
  }

  /**
   * Record a downstream success for circuit breaker accounting.
   */
  recordSuccess() {
    if (this._cb.state === 'HALF_OPEN') {
      this._cb.successesInHalfOpen++;
      if (this._cb.successesInHalfOpen >= CB_HALF_OPEN_PROBES) {
        this._cb.state = 'CLOSED';
        this._cb.failures = fib(0);
        this.emit('cb:closed');
      }
    } else {
      this._cb.failures = Math.max(fib(0), this._cb.failures - fib(1));
    }
  }

  /**
   * Record a downstream failure for circuit breaker accounting.
   */
  recordFailure() {
    this._cb.failures++;
    if (this._cb.state !== 'OPEN' && this._cb.failures >= CB_FAILURE_THRESHOLD) {
      this._cb.state = 'OPEN';
      this._cb.openedAt = Date.now();
      this._counters.totalCBTrips++;
      this.emit('cb:open', { failures: this._cb.failures });
    }
  }

  // ─── SEMANTIC DEDUP ──────────────────────────────────────────────────────────

  /**
   * Check if a task embedding is semantically identical to a recent entry.
   * Returns the cached result if cosine ≥ DEDUP_THRESHOLD, otherwise null.
   *
   * @param {number[]} taskEmbedding - Unit vector of task
   * @returns {{ hit: boolean, result: * }}
   */
  dedup(taskEmbedding) {
    // Walk all stored embeddings (bounded by CACHE_MAX_SIZE)
    for (const [key, entry] of this._embeddingStore._store) {
      if (!entry || Date.now() > entry.expiresAt) continue;
      const sim = cosineSimilarity(taskEmbedding, entry.value.embedding);
      if (sim >= DEDUP_THRESHOLD) {
        this._counters.totalDedup++;
        this.emit('dedup:hit', { similarity: sim });
        return { hit: true, result: entry.value.result };
      }
    }
    return { hit: false, result: null };
  }

  /**
   * Store a task result in the dedup embedding store.
   * @param {number[]} embedding
   * @param {*} result
   */
  storeResult(embedding, result) {
    // Use timestamp as key — uniqueness guaranteed within TTL window
    const key = `emb-${Date.now()}-${Math.random().toString(fib(5)).slice(fib(3))}`;
    this._embeddingStore.set(key, { embedding, result });
  }

  // ─── PRIORITY SCORING ────────────────────────────────────────────────────────

  /**
   * Compute φ-priority score for a task.
   * @param {number} criticality - Raw criticality value (use CRITICALITY.*)
   * @param {number} urgency     - Urgency [0, 1]
   * @param {number} impact      - Impact [0, 1]
   * @returns {number} Priority score [0, 1]
   */
  scorePriority(criticality, urgency, impact) {
    // Normalise criticality using CRITICAL_PLUS as ceiling
    const normCrit = Math.min(criticality / CRITICALITY.CRITICAL_PLUS, fib(1));
    return phiPriorityScore(normCrit, urgency, impact);
  }

  // ─── LOAD SHEDDING ───────────────────────────────────────────────────────────

  /**
   * Shed tasks in a criticality tier from the queue.
   * Removes tasks whose priorityScore falls below the pressure floor.
   *
   * @param {string} tier - 'SHEDDABLE' | 'SHEDDABLE_PLUS' | 'CRITICAL' | 'CRITICAL_PLUS'
   * @returns {number} Number of tasks shed
   */
  shed(tier) {
    const pressure = this.getPressure();
    let floor;

    if (pressure === 'CRITICAL') {
      floor = SHED_CRITICAL_FLOOR; // drop almost everything
    } else if (pressure === 'HIGH') {
      floor = SHED_HIGH_FLOOR;     // drop low-priority
    } else {
      return fib(0); // no shedding below HIGH
    }

    const before = this._queue.length;
    this._queue = this._queue.filter(task => {
      const score = task.priorityScore || fib(0);
      return score >= floor;
    });
    const shed = before - this._queue.length;
    this._counters.totalShed += shed;
    if (shed > fib(0)) this.emit('shed', { tier, shed, pressure });
    return shed;
  }

  // ─── PRESSURE ────────────────────────────────────────────────────────────────

  /**
   * Return current system pressure based on queue fill ratio.
   * @returns {'NOMINAL'|'ELEVATED'|'HIGH'|'CRITICAL'}
   */
  getPressure() {
    const ratio = this._queue.length / QUEUE_MAX_DEPTH;
    return classifyPressure(ratio);
  }

  // ─── MAIN ACCEPT GATE ────────────────────────────────────────────────────────

  /**
   * Decide whether to accept or reject a task.
   *
   * Decision order:
   *  1. Circuit breaker OPEN → reject
   *  2. Semantic dedup hit → return cached
   *  3. Queue full → reject
   *  4. SRE throttle: P(reject) → probabilistic drop
   *  5. Pressure-based shedding
   *  6. Accept
   *
   * @param {object} task - Task object with { id, embedding?, criticality?, urgency?, impact? }
   * @returns {{ accepted: boolean, reason: string, dedupResult?: * }}
   */
  shouldAccept(task) {
    this._counters.totalRequests++;
    const now = Date.now();
    this._requestWindow.push(now);

    // 1. Circuit breaker
    const cbState = this._cbState();
    if (cbState === 'OPEN') {
      this._counters.totalRejects++;
      this.emit('reject', { taskId: task.id, reason: 'circuit-breaker-open' });
      return { accepted: false, reason: 'circuit-breaker-open' };
    }

    // 2. Semantic dedup
    if (task.embedding && task.embedding.length === EMBEDDING_DIM) {
      const { hit, result } = this.dedup(task.embedding);
      if (hit) {
        this._counters.totalAccepts++;
        this._acceptWindow.push(now);
        return { accepted: true, reason: 'dedup-cache-hit', dedupResult: result };
      }
    }

    // 3. Queue depth guard
    if (this._queue.length >= QUEUE_MAX_DEPTH) {
      this._counters.totalRejects++;
      this.emit('reject', { taskId: task.id, reason: 'queue-full' });
      return { accepted: false, reason: 'queue-full' };
    }

    // 4. SRE probabilistic throttle
    const rejectProb = this._sреRejectProb();
    if (Math.random() < rejectProb) {
      this._counters.totalRejects++;
      this.emit('reject', { taskId: task.id, reason: 'sre-throttle', rejectProb });
      return { accepted: false, reason: 'sre-throttle', rejectProb };
    }

    // 5. Pressure-based pre-admission shedding
    const pressure = this.getPressure();
    if (pressure === 'HIGH' || pressure === 'CRITICAL') {
      const criticality = task.criticality || CRITICALITY.SHEDDABLE;
      const urgency     = task.urgency     || PSI_SQ;
      const impact      = task.impact      || PSI_CUBE;
      const score = this.scorePriority(criticality, urgency, impact);
      task.priorityScore = score;

      const floor = pressure === 'CRITICAL' ? SHED_CRITICAL_FLOOR : SHED_HIGH_FLOOR;
      if (score < floor) {
        this._counters.totalRejects++;
        this.emit('reject', { taskId: task.id, reason: 'load-shed', pressure, score });
        return { accepted: false, reason: 'load-shed', pressure, score };
      }
    }

    // 6. Accept
    this._counters.totalAccepts++;
    this._acceptWindow.push(now);
    this._queue.push(Object.assign({ priorityScore: fib(1) }, task));

    this.emit('accept', { taskId: task.id, pressure });
    return { accepted: true, reason: 'accepted' };
  }

  // ─── METRICS ─────────────────────────────────────────────────────────────────

  /**
   * Return comprehensive backpressure metrics snapshot.
   * @returns {object}
   */
  getMetrics() {
    this._pruneWindow();
    const rejectProb = this._sреRejectProb();
    const pressure   = this.getPressure();

    return {
      pressure,
      rejectProbability: rejectProb,
      windowMs: WINDOW_MS,
      requests: this._requestWindow.length,
      accepts:  this._acceptWindow.length,
      queue: {
        depth: this._queue.length,
        maxDepth: QUEUE_MAX_DEPTH,
        fillRatio: this._queue.length / QUEUE_MAX_DEPTH,
      },
      dedupCache: {
        size: this._dedupCache.size,
        maxSize: CACHE_MAX_SIZE,
        ttlMs: CACHE_TTL_MS,
      },
      circuitBreaker: {
        state: this._cb.state,
        failures: this._cb.failures,
        failureThreshold: CB_FAILURE_THRESHOLD,
        halfOpenProbes: CB_HALF_OPEN_PROBES,
      },
      lifetime: Object.assign({}, this._counters),
      thresholds: {
        dedupThreshold: DEDUP_THRESHOLD,
        sreK: SRE_K,
        shedHighFloor: SHED_HIGH_FLOOR,
        shedCriticalFloor: SHED_CRITICAL_FLOOR,
      },
    };
  }

  /**
   * Drain the task queue — returns all queued tasks and clears the queue.
   * @returns {object[]}
   */
  drainQueue() {
    const drained = this._queue.slice();
    this._queue = [];
    this.emit('queue:drained', { count: drained.length });
    return drained;
  }

  /**
   * Graceful shutdown — clear GC timer.
   */
  destroy() {
    clearInterval(this._gcTimer);
    this.emit('backpressure:destroy');
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  SemanticBackpressure,
  LRUCache,
  SRE_K,
  WINDOW_MS,
  CACHE_MAX_SIZE,
  CACHE_TTL_MS,
  QUEUE_MAX_DEPTH,
  CB_FAILURE_THRESHOLD,
  CB_HALF_OPEN_PROBES,
  CB_RESET_TIMEOUT_MS,
  CRITICALITY,
  SHED_HIGH_FLOOR,
  SHED_CRITICAL_FLOOR,
};
