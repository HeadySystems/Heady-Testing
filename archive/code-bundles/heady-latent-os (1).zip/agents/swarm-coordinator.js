/**
 * @fileoverview SwarmCoordinator — 17-Swarm φ-Scaled Coordination Layer
 *
 * Manages 17 named swarms arranged across sacred-geometry rings. Assigns tasks
 * via CSL cosine scoring, aggregates results through consensus, allocates
 * resources with phiResourceWeights, and supports cross-swarm channels.
 *
 * @module agents/swarm-coordinator
 * @version 3.0.0
 */

'use strict';

const events = require('events');
const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib, CSL_THRESHOLDS, DEDUP_THRESHOLD,
  phiFusionWeights, phiBackoff, phiResourceWeights, phiMultiSplit,
  cslGate, sigmoid, POOL_ALLOCATION, PRESSURE_LEVELS,
  classifyPressure, phiPriorityScore, phiAdaptiveInterval,
} = require('../shared/phi-math');
const { cosineSimilarity, RINGS } = require('../shared/sacred-geometry');
const { cslAND, cslCONSENSUS, cslPhiGATE, normalize, hdcRandomVector, EMBEDDING_DIM } = require('../shared/csl-engine');

// ─── SWARM CAPACITY CONSTANTS ─────────────────────────────────────────────────

/** Default max concurrency per swarm: fib(6) = 8 */
const SWARM_MAX_CONCURRENCY = fib(6);

/** Min concurrency per swarm: fib(4) = 3 */
const SWARM_MIN_CONCURRENCY = fib(4);

/** Max scale factor (φ³ ≈ 4.24) */
const SWARM_SCALE_MAX = PHI * PHI * PHI;

/** Scale-down floor (ψ³ ≈ 0.24) */
const SWARM_SCALE_MIN = PSI_CUBE;

// ─── 17 SWARM DEFINITIONS ─────────────────────────────────────────────────────
// primaryNodes drawn from RINGS definitions. Capability embeddings are seeded
// deterministically by swarm index using phiFusionWeights for spread.

const SWARM_DEFS = Object.freeze([
  {
    name: 'coding-swarm',
    primaryNodes: [...RINGS.MIDDLE.nodes.slice(0, fib(3))],   // JULES, BUILDER
    pool: 'Hot',
    maxConcurrency: fib(6),   // 8
    description: 'Source code generation, review, and refactoring',
  },
  {
    name: 'deploy-swarm',
    primaryNodes: [...RINGS.MIDDLE.nodes.slice(0, fib(2))],   // JULES
    pool: 'Hot',
    maxConcurrency: fib(6),
    description: 'CI/CD orchestration, blue-green and canary deployments',
  },
  {
    name: 'research-swarm',
    primaryNodes: [...RINGS.OUTER.nodes.slice(0, fib(3))],    // BRIDGE, MUSE
    pool: 'Warm',
    maxConcurrency: fib(5),   // 5
    description: 'Knowledge retrieval, synthesis, and citation',
  },
  {
    name: 'security-swarm',
    primaryNodes: [...RINGS.OUTER.nodes.slice(fib(3), fib(3) + fib(2))], // SENTINEL
    pool: 'Hot',
    maxConcurrency: fib(6),
    description: 'Threat detection, vulnerability scanning, patch management',
  },
  {
    name: 'architecture-swarm',
    primaryNodes: [...RINGS.INNER.nodes],                      // HeadyBrains, HeadyConductor, HeadyVinci
    pool: 'Hot',
    maxConcurrency: fib(5),
    description: 'System design, ADR authoring, dependency analysis',
  },
  {
    name: 'creative-swarm',
    primaryNodes: [RINGS.OUTER.nodes[fib(2) - 1]],            // MUSE
    pool: 'Warm',
    maxConcurrency: fib(5),
    description: 'Content creation, brand voice, multimedia production',
  },
  {
    name: 'documentation-swarm',
    primaryNodes: [RINGS.MIDDLE.nodes[fib(5) - 1]],           // PYTHIA
    pool: 'Warm',
    maxConcurrency: fib(5),
    description: 'Auto-doc generation, changelog, runbook authoring',
  },
  {
    name: 'testing-swarm',
    primaryNodes: [...RINGS.MIDDLE.nodes.slice(0, fib(3))],   // JULES, BUILDER
    pool: 'Hot',
    maxConcurrency: fib(6),
    description: 'Unit, integration, E2E, fuzz, and load testing',
  },
  {
    name: 'data-swarm',
    primaryNodes: [RINGS.MIDDLE.nodes[fib(4) - 1]],           // ATLAS
    pool: 'Hot',
    maxConcurrency: fib(6),
    description: 'ETL pipelines, validation, lineage tracking',
  },
  {
    name: 'monitoring-swarm',
    primaryNodes: [RINGS.MIDDLE.nodes[fib(3) - 1]],           // OBSERVER
    pool: 'Hot',
    maxConcurrency: fib(7),   // 13 — highest, always watching
    description: 'Metrics, alerts, distributed tracing, SLO tracking',
  },
  {
    name: 'communication-swarm',
    primaryNodes: [RINGS.OUTER.nodes[0]],                      // BRIDGE
    pool: 'Warm',
    maxConcurrency: fib(5),
    description: 'Inter-swarm messaging, notifications, escalations',
  },
  {
    name: 'governance-swarm',
    primaryNodes: [...RINGS.GOVERNANCE.nodes.slice(0, fib(3))], // HeadyCheck, HeadyAssure
    pool: 'Warm',
    maxConcurrency: fib(4),   // 3 — constrained by design
    description: 'Policy enforcement, ethics review, audit trails',
  },
  {
    name: 'memory-swarm',
    primaryNodes: [RINGS.CENTRAL.nodes[0]],                    // HeadySoul
    pool: 'Hot',
    maxConcurrency: fib(5),
    description: 'Vector store ops, context retrieval, cache management',
  },
  {
    name: 'reasoning-swarm',
    primaryNodes: [RINGS.INNER.nodes[0]],                      // HeadyBrains
    pool: 'Hot',
    maxConcurrency: fib(5),
    description: 'Multi-step inference, CoT, hypothesis generation',
  },
  {
    name: 'synthesis-swarm',
    primaryNodes: [RINGS.INNER.nodes[fib(3) - 1]],            // HeadyVinci
    pool: 'Warm',
    maxConcurrency: fib(5),
    description: 'Cross-domain synthesis, innovation, pattern fusion',
  },
  {
    name: 'integration-swarm',
    primaryNodes: [RINGS.OUTER.nodes[0], RINGS.OUTER.nodes[fib(2)]],   // BRIDGE, NOVA
    pool: 'Hot',
    maxConcurrency: fib(6),
    description: 'Webhook routing, event streaming, ETL orchestration',
  },
  {
    name: 'maintenance-swarm',
    primaryNodes: [RINGS.MIDDLE.nodes[fib(4) - 2]],           // MURPHY
    pool: 'Warm',
    maxConcurrency: fib(5),
    description: 'Cleanup, health sweeps, dependency upgrades, backup',
  },
]);

// ─── SWARM COORDINATOR ────────────────────────────────────────────────────────

/**
 * SwarmCoordinator — manages the 17-swarm topology with φ-scaling.
 * @extends events.EventEmitter
 */
class SwarmCoordinator extends events.EventEmitter {
  constructor() {
    super();

    /** @type {Map<string, object>} Swarm state by name */
    this._swarms = new Map();

    /** @type {Map<string, Set<string>>} Cross-swarm communication channels */
    this._channels = new Map();

    /** φ-resource weights for the 17 swarms */
    this._resourceWeights = phiResourceWeights(SWARM_DEFS.length);

    this._initSwarms();
    this.emit('coordinator:init', { swarms: this._swarms.size });
  }

  // ─── INITIALISATION ──────────────────────────────────────────────────────────

  /** Initialise all swarm state objects with capability embeddings. */
  _initSwarms() {
    SWARM_DEFS.forEach((def, idx) => {
      // Capability embedding: seeded by swarm index for deterministic spread
      const embedding = this._seedEmbedding(idx);

      const swarm = {
        name: def.name,
        primaryNodes: def.primaryNodes,
        pool: def.pool,
        maxConcurrency: def.maxConcurrency,
        description: def.description,
        embedding,
        resourceWeight: this._resourceWeights[idx],
        activeTasks: [],
        completedCount: fib(0),
        failedCount: fib(0),
        scaleFactor: fib(1),  // 1× by default
        health: {
          healthy: true,
          load: 0,
          lastActivity: Date.now(),
        },
      };

      this._swarms.set(def.name, swarm);
      this._channels.set(def.name, new Set());
    });

    // Wire default communication channels (each swarm ↔ communication-swarm)
    for (const name of this._swarms.keys()) {
      if (name !== 'communication-swarm') {
        this._channels.get('communication-swarm').add(name);
        this._channels.get(name).add('communication-swarm');
      }
    }
  }

  /**
   * Seed a deterministic unit embedding for a swarm using φ-offset.
   * @param {number} idx - Swarm index
   * @returns {number[]}
   */
  _seedEmbedding(idx) {
    const v = new Array(EMBEDDING_DIM);
    for (let d = 0; d < EMBEDDING_DIM; d++) {
      // φ-irrational phase spread: each swarm occupies a unique sector
      const phase = (idx * PHI + d * PSI) % fib(2); // mod 1
      v[d] = Math.sin(phase * Math.PI * fib(2));
    }
    return normalize(v);
  }

  // ─── TASK ASSIGNMENT ─────────────────────────────────────────────────────────

  /**
   * Assign a task to the best-matching swarm using CSL cosine scoring.
   * Threshold: CSL_THRESHOLDS.LOW ≈ 0.691
   *
   * @param {object} task - Task object with { id, embedding, priority? }
   * @returns {{ swarm: object, score: number } | null} Assigned swarm or null
   */
  assignTask(task) {
    if (!task.embedding || task.embedding.length !== EMBEDDING_DIM) {
      task.embedding = hdcRandomVector(EMBEDDING_DIM);
    }

    let bestSwarm = null;
    let bestScore = CSL_THRESHOLDS.LOW; // must exceed LOW to qualify

    for (const swarm of this._swarms.values()) {
      // Skip over-capacity swarms
      const capacity = swarm.maxConcurrency * swarm.scaleFactor;
      if (swarm.activeTasks.length >= capacity) continue;
      if (!swarm.health.healthy) continue;

      const score = cosineSimilarity(task.embedding, swarm.embedding);
      const gated = cslPhiGATE(score, score, fib(2)); // level=2, MEDIUM gate

      if (gated > bestScore) {
        bestScore = gated;
        bestSwarm = swarm;
      }
    }

    if (!bestSwarm) {
      this.emit('task:unassigned', { taskId: task.id });
      return null;
    }

    bestSwarm.activeTasks.push({ taskId: task.id, assignedAt: Date.now() });
    bestSwarm.health.load = bestSwarm.activeTasks.length / (bestSwarm.maxConcurrency * bestSwarm.scaleFactor);
    bestSwarm.health.lastActivity = Date.now();

    this.emit('task:assigned', {
      taskId: task.id,
      swarm: bestSwarm.name,
      score: bestScore,
    });

    return { swarm: bestSwarm, score: bestScore };
  }

  // ─── MULTI-SWARM COORDINATION ────────────────────────────────────────────────

  /**
   * Coordinate multiple tasks across swarms in one pass.
   * @param {object[]} tasks
   * @returns {Array<{ task: object, assignment: object|null }>}
   */
  coordinateMultiSwarm(tasks) {
    return tasks.map(task => ({
      task,
      assignment: this.assignTask(task),
    }));
  }

  // ─── CONSENSUS ───────────────────────────────────────────────────────────────

  /**
   * Aggregate results from multiple swarm embeddings via cslCONSENSUS.
   * @param {Array<{ swarmName: string, resultEmbedding: number[] }>} swarmResults
   * @returns {number[]} Consensus embedding
   */
  consensus(swarmResults) {
    if (swarmResults.length === fib(0)) throw new Error('No swarm results to aggregate');

    const vectors = swarmResults.map(r => normalize(r.resultEmbedding));
    const weights = phiFusionWeights(vectors.length);
    const result = cslCONSENSUS(vectors, weights);

    this.emit('consensus:complete', { swarms: swarmResults.length });
    return result;
  }

  // ─── RESOURCE ALLOCATION ─────────────────────────────────────────────────────

  /**
   * Return current resource allocation for all swarms.
   * @returns {Array<{ name: string, weight: number, pool: string }>}
   */
  _getResourceAllocation() {
    const result = [];
    let idx = fib(0);
    for (const swarm of this._swarms.values()) {
      result.push({
        name: swarm.name,
        weight: this._resourceWeights[idx++],
        pool: swarm.pool,
      });
    }
    return result;
  }

  // ─── SWARM HEALTH ────────────────────────────────────────────────────────────

  /**
   * Get health summary for all swarms.
   * @returns {object[]}
   */
  getSwarmHealth() {
    const health = [];
    for (const swarm of this._swarms.values()) {
      const load = swarm.activeTasks.length /
        Math.max(swarm.maxConcurrency * swarm.scaleFactor, fib(1));
      health.push({
        name: swarm.name,
        pool: swarm.pool,
        load,
        pressure: classifyPressure(load),
        healthy: swarm.health.healthy,
        activeTasks: swarm.activeTasks.length,
        completedCount: swarm.completedCount,
        scaleFactor: swarm.scaleFactor,
      });
    }
    return health;
  }

  // ─── SCALING ─────────────────────────────────────────────────────────────────

  /**
   * Scale a swarm's effective concurrency by a φ-bounded factor.
   * factor is clamped to [SWARM_SCALE_MIN, SWARM_SCALE_MAX].
   *
   * @param {string} name - Swarm name
   * @param {number} factor - Desired scale factor
   * @returns {number} Applied scale factor
   */
  scaleSwarm(name, factor) {
    const swarm = this._swarms.get(name);
    if (!swarm) throw new Error(`Unknown swarm: ${name}`);

    const clamped = Math.max(SWARM_SCALE_MIN, Math.min(SWARM_SCALE_MAX, factor));
    swarm.scaleFactor = clamped;

    this.emit('swarm:scaled', { name, factor: clamped });
    return clamped;
  }

  // ─── CHANNEL MANAGEMENT ──────────────────────────────────────────────────────

  /**
   * Open a communication channel between two swarms.
   * @param {string} a
   * @param {string} b
   */
  openChannel(a, b) {
    if (!this._swarms.has(a) || !this._swarms.has(b)) return;
    this._channels.get(a).add(b);
    this._channels.get(b).add(a);
    this.emit('channel:open', { a, b });
  }

  /**
   * Send a message through the swarm channel.
   * @param {string} from
   * @param {string} to
   * @param {object} message
   */
  sendMessage(from, to, message) {
    const peers = this._channels.get(from);
    if (!peers || !peers.has(to)) {
      throw new Error(`No channel from ${from} to ${to}`);
    }
    this.emit('channel:message', { from, to, message, timestamp: Date.now() });
  }

  /**
   * Complete a task in a swarm and update counters.
   * @param {string} swarmName
   * @param {string} taskId
   * @param {boolean} [success=true]
   */
  completeTask(swarmName, taskId, success = true) {
    const swarm = this._swarms.get(swarmName);
    if (!swarm) return;

    swarm.activeTasks = swarm.activeTasks.filter(t => t.taskId !== taskId);
    if (success) {
      swarm.completedCount++;
    } else {
      swarm.failedCount++;
    }
    swarm.health.load = swarm.activeTasks.length /
      Math.max(swarm.maxConcurrency * swarm.scaleFactor, fib(1));

    this.emit('task:complete', { swarmName, taskId, success });
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  SwarmCoordinator,
  SWARM_DEFS,
  SWARM_MAX_CONCURRENCY,
  SWARM_MIN_CONCURRENCY,
  SWARM_SCALE_MAX,
  SWARM_SCALE_MIN,
};
