'use strict';

/**
 * @module edge/durable-agent-state
 * @description Cloudflare Durable Object–inspired stateful agent lifecycle
 *   manager. Uses an in-memory Map for portability (swap for SQLite/D1 in
 *   production). Applies Fibonacci compression triggers, hibernatable
 *   WebSocket simulation, and phi-scheduled alarms.
 */

const { EventEmitter } = require('events');
const crypto = require('crypto');
const {
  PHI,
  PSI,
  fib,
  phiBackoff,
  phiAdaptiveInterval,
  PRESSURE_LEVELS,
  classifyPressure,
} = require('../shared/phi-math');

// ─── Agent Lifecycle States ───────────────────────────────────────────────────

/** @enum {string} Agent lifecycle states (ordered) */
const AGENT_STATE = Object.freeze({
  INIT:        'init',
  ACTIVE:      'active',
  THINKING:    'thinking',
  RESPONDING:  'responding',
  IDLE:        'idle',
  HIBERNATING: 'hibernating',
  EXPIRED:     'expired',
});

// ─── Fibonacci Compression Trigger Points ─────────────────────────────────────

/**
 * Message count thresholds that trigger context compression.
 * [fib(6), fib(7), fib(8), fib(9), fib(10), fib(11)] = [8, 13, 21, 34, 55, 89]
 */
const COMPRESSION_TRIGGERS = Object.freeze([
  fib(6),   //  8
  fib(7),   // 13
  fib(8),   // 21
  fib(9),   // 34
  fib(10),  // 55
  fib(11),  // 89
]);

/** Max messages before hard-rolloff (fib(12) = 144) */
const MAX_MESSAGES = fib(12); // 144

/** Idle timeout before hibernation: fib(9) × 1000ms = 34 000ms */
const IDLE_TIMEOUT_MS = fib(9) * 1000; // 34 000ms

/** Expiry timeout from hibernation: fib(11) × 60 000ms = 89 min */
const EXPIRY_TIMEOUT_MS = fib(11) * 60000; // ~89 min

/** Alarm base interval: fib(7) × 1000ms = 13 000ms */
const ALARM_BASE_MS = fib(7) * 1000; // 13 000ms

// ─── Valid Transitions ────────────────────────────────────────────────────────

const VALID_TRANSITIONS = new Map([
  [AGENT_STATE.INIT,        new Set([AGENT_STATE.ACTIVE])],
  [AGENT_STATE.ACTIVE,      new Set([AGENT_STATE.THINKING, AGENT_STATE.IDLE, AGENT_STATE.HIBERNATING])],
  [AGENT_STATE.THINKING,    new Set([AGENT_STATE.RESPONDING, AGENT_STATE.ACTIVE])],
  [AGENT_STATE.RESPONDING,  new Set([AGENT_STATE.ACTIVE, AGENT_STATE.IDLE])],
  [AGENT_STATE.IDLE,        new Set([AGENT_STATE.ACTIVE, AGENT_STATE.HIBERNATING])],
  [AGENT_STATE.HIBERNATING, new Set([AGENT_STATE.ACTIVE, AGENT_STATE.EXPIRED])],
  [AGENT_STATE.EXPIRED,     new Set()],
]);

// ─── DurableAgentState ────────────────────────────────────────────────────────

/**
 * @class DurableAgentState
 * @extends EventEmitter
 *
 * Events emitted:
 *   'transition'    – { agentId, from, to, reason }
 *   'message'       – { agentId, message, count }
 *   'compress'      – { agentId, trigger, before, after }
 *   'hibernate'     – { agentId }
 *   'wake'          – { agentId }
 *   'alarm'         – { agentId, alarmId, scheduledAt }
 *   'persist'       – { agentId, snapshotId }
 *   'websocket'     – { agentId, event, data }
 *   'expired'       – { agentId }
 */
class DurableAgentState extends EventEmitter {
  /**
   * @param {string} agentId   unique identifier for this durable object
   * @param {object} [opts]
   * @param {number} [opts.idleTimeoutMs=34000]   ms of inactivity before hibernation
   * @param {number} [opts.expiryTimeoutMs]       ms in hibernation before expiry
   */
  constructor(agentId, opts = {}) {
    super();
    this._agentId         = agentId;
    this._idleTimeoutMs   = opts.idleTimeoutMs   ?? IDLE_TIMEOUT_MS;
    this._expiryTimeoutMs = opts.expiryTimeoutMs ?? EXPIRY_TIMEOUT_MS;

    // Simulated Durable Object storage (replace with D1/SQLite in production)
    this._store = new Map();

    // Core state
    this._state           = AGENT_STATE.INIT;
    this._messages        = [];
    this._compressedChunks = [];
    this._messageCount    = 0;
    this._lastActivityAt  = Date.now();
    this._hibernatedAt    = null;

    // WebSocket simulation
    this._wsConnected     = false;
    this._wsBuffer        = [];

    // Alarms
    this._alarms          = new Map();
    this._alarmSeq        = 0;

    // Idle/expiry timers
    this._idleTimer       = null;
    this._expiryTimer     = null;

    // Initialize storage
    this._persist();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Process an incoming message through the agent state machine.
   * @param {object} msg   message payload
   * @returns {Promise<object>} result or null if not active
   */
  async handleMessage(msg) {
    if (this._state === AGENT_STATE.EXPIRED) {
      throw new Error(`Agent ${this._agentId} has expired`);
    }
    if (this._state === AGENT_STATE.HIBERNATING) {
      await this.wake();
    }
    if (this._state === AGENT_STATE.INIT) {
      this.transition(AGENT_STATE.ACTIVE, 'first message');
    }

    this._lastActivityAt = Date.now();
    this._resetIdleTimer();

    this._messageCount++;
    const record = {
      id:        crypto.randomBytes(fib(4)).toString('hex'), // 3 bytes → 6-char hex
      seq:       this._messageCount,
      content:   msg,
      ts:        Date.now(),
    };
    this._messages.push(record);
    this.emit('message', { agentId: this._agentId, message: record, count: this._messageCount });

    // Check Fibonacci compression triggers
    if (COMPRESSION_TRIGGERS.includes(this._messageCount)) {
      await this.compress();
    }

    // Simulate think→respond cycle
    this.transition(AGENT_STATE.THINKING, 'processing message');

    const result = await this._processMessage(record);

    this.transition(AGENT_STATE.RESPONDING, 'emitting response');
    this.transition(AGENT_STATE.ACTIVE, 'response complete');

    // WebSocket relay
    if (this._wsConnected) {
      this._wsBuffer.push(result);
      this.emit('websocket', { agentId: this._agentId, event: 'message', data: result });
    }

    await this._persist();
    return result;
  }

  /**
   * Transition to a new agent lifecycle state.
   * @param {string} newState  one of AGENT_STATE values
   * @param {string} [reason]
   */
  transition(newState, reason = '') {
    const allowed = VALID_TRANSITIONS.get(this._state);
    if (!allowed || !allowed.has(newState)) {
      throw new Error(`Invalid agent state transition: ${this._state} → ${newState}`);
    }
    const from = this._state;
    this._state = newState;
    this.emit('transition', { agentId: this._agentId, from, to: newState, reason });
  }

  /**
   * Compress accumulated messages into a summary chunk.
   * Triggered automatically at Fibonacci message counts.
   * @returns {Promise<object>} compression stats
   */
  async compress() {
    const before = this._messages.length;
    if (before === 0) return { before: 0, after: 0, chunks: this._compressedChunks.length };

    // Create a summary chunk (in production: LLM summarization)
    const chunk = {
      id:        `chunk-${this._compressedChunks.length + 1}`,
      summary:   `[Compressed ${before} messages at seq ${this._messageCount}]`,
      messageIds: this._messages.map(m => m.id),
      compressedAt: Date.now(),
      hash:      crypto.createHash('sha256')
                       .update(JSON.stringify(this._messages))
                       .digest('hex'),
    };

    this._compressedChunks.push(chunk);
    this._messages = []; // Clear compressed messages

    const after = this._messages.length;
    this.emit('compress', {
      agentId: this._agentId,
      trigger: this._messageCount,
      before,
      after,
      chunkId: chunk.id,
    });

    return { before, after, chunks: this._compressedChunks.length, chunkId: chunk.id };
  }

  /**
   * Hibernate the agent (suspend WebSocket, cancel timers, persist state).
   */
  async hibernate() {
    if (this._state === AGENT_STATE.HIBERNATING) return;

    this._wsConnected  = false;
    this._hibernatedAt = Date.now();
    this._clearIdleTimer();

    this.transition(AGENT_STATE.HIBERNATING, 'hibernate called');
    this.emit('hibernate', { agentId: this._agentId });

    // Schedule expiry alarm
    this._scheduleAlarm('expiry', this._expiryTimeoutMs, () => this._onExpiry());

    await this._persist();
  }

  /**
   * Wake the agent from hibernation.
   * @returns {Promise<void>}
   */
  async wake() {
    if (this._state !== AGENT_STATE.HIBERNATING) return;

    this._cancelAlarm('expiry');
    this._hibernatedAt = null;
    this.transition(AGENT_STATE.ACTIVE, 'wake called');
    this.emit('wake', { agentId: this._agentId });

    this._wsConnected = true;
    this._resetIdleTimer();
    await this._persist();
  }

  /**
   * Snapshot current state to durable storage.
   * @returns {Promise<string>} snapshot ID
   */
  async persist() {
    return this._persist();
  }

  /**
   * @returns {{
   *   agentId: string,
   *   state: string,
   *   messageCount: number,
   *   compressedChunks: number,
   *   wsConnected: boolean,
   *   alarmCount: number,
   *   lastActivityAt: number,
   *   compressionTriggers: number[]
   * }}
   */
  getState() {
    return {
      agentId:             this._agentId,
      state:               this._state,
      messageCount:        this._messageCount,
      activeMessages:      this._messages.length,
      compressedChunks:    this._compressedChunks.length,
      wsConnected:         this._wsConnected,
      alarmCount:          this._alarms.size,
      lastActivityAt:      this._lastActivityAt,
      hibernatedAt:        this._hibernatedAt,
      compressionTriggers: COMPRESSION_TRIGGERS,
    };
  }

  // ─── Internal Helpers ────────────────────────────────────────────────────────

  /**
   * Simulate message processing (stub for real LLM/logic).
   * @param {object} record
   * @returns {Promise<object>}
   */
  async _processMessage(record) {
    // Phi-adaptive processing latency simulation (disabled by default)
    return {
      respondTo: record.id,
      seq:       record.seq,
      processed: true,
      ts:        Date.now(),
    };
  }

  /**
   * Snapshot to internal Map store with SHA-256 integrity hash.
   * @returns {Promise<string>} snapshotId
   */
  async _persist() {
    const snapshot = {
      agentId:          this._agentId,
      state:            this._state,
      messageCount:     this._messageCount,
      compressedChunks: this._compressedChunks.length,
      ts:               Date.now(),
    };
    const snapshotId = crypto.createHash('sha256')
                              .update(JSON.stringify(snapshot))
                              .digest('hex')
                              .slice(0, 16);
    this._store.set(`snapshot:${snapshotId}`, snapshot);
    this.emit('persist', { agentId: this._agentId, snapshotId });
    return snapshotId;
  }

  /** Schedule a named alarm callback after delayMs. */
  _scheduleAlarm(name, delayMs, callback) {
    this._cancelAlarm(name);
    const alarmId = `${name}-${++this._alarmSeq}`;
    const handle  = setTimeout(() => {
      this._alarms.delete(name);
      this.emit('alarm', { agentId: this._agentId, alarmId, scheduledAt: Date.now() });
      callback();
    }, delayMs);
    this._alarms.set(name, { alarmId, handle, scheduledAt: Date.now() + delayMs });
  }

  /** Cancel a named alarm if pending. */
  _cancelAlarm(name) {
    const alarm = this._alarms.get(name);
    if (alarm) {
      clearTimeout(alarm.handle);
      this._alarms.delete(name);
    }
  }

  /** Reset idle inactivity timer. */
  _resetIdleTimer() {
    this._clearIdleTimer();
    this._idleTimer = setTimeout(() => {
      if (this._state === AGENT_STATE.ACTIVE || this._state === AGENT_STATE.IDLE) {
        if (this._state === AGENT_STATE.ACTIVE) {
          this.transition(AGENT_STATE.IDLE, 'idle timeout');
        }
        this.hibernate().catch(() => {});
      }
    }, this._idleTimeoutMs);
  }

  /** Clear idle timer. */
  _clearIdleTimer() {
    if (this._idleTimer) {
      clearTimeout(this._idleTimer);
      this._idleTimer = null;
    }
  }

  /** Handle expiry after hibernation timeout. */
  _onExpiry() {
    if (this._state === AGENT_STATE.HIBERNATING) {
      this._state = AGENT_STATE.EXPIRED;
      this._persist().catch(() => {});
      this.emit('expired', { agentId: this._agentId });
    }
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports = {
  DurableAgentState,
  AGENT_STATE,
  COMPRESSION_TRIGGERS,
  MAX_MESSAGES,
  IDLE_TIMEOUT_MS,
  EXPIRY_TIMEOUT_MS,
};
