'use strict';

/**
 * @module edge/edge-origin-router
 * @description Phi-scored request router with edge/origin/hybrid tiers,
 *   Fibonacci-based resource allocation, LRU embedding cache, and
 *   Vectorize↔pgvector sync batching.
 *
 *   Routing tiers:
 *     edge-only      complexity < PSI²  (< 0.382)
 *     edge-preferred PSI² ≤ complexity < PSI (0.382–0.618)
 *     origin-required complexity ≥ PSI  (≥ 0.618)
 */

const crypto = require('crypto');
const {
  PHI,
  PSI,
  PSI_SQ,
  fib,
  phiBackoff,
  phiAdaptiveInterval,
  DEDUP_THRESHOLD,
} = require('../shared/phi-math');
const { cosineSimilarity } = require('../shared/sacred-geometry');

// ─── Routing Tier Constants ───────────────────────────────────────────────────

/** @enum {string} Routing tier identifiers */
const TIER = Object.freeze({
  EDGE_ONLY:        'edge-only',
  EDGE_PREFERRED:   'edge-preferred',
  ORIGIN_REQUIRED:  'origin-required',
  HYBRID:           'hybrid',
});

/** Complexity threshold boundaries */
const COMPLEXITY = Object.freeze({
  EDGE_CEILING:   PSI_SQ,  // 0.382 — below this → edge-only
  HYBRID_CEILING: PSI,     // 0.618 — below this → edge-preferred, at/above → origin
});

// ─── Resource Allocation (Fibonacci-scaled) ───────────────────────────────────
// Total denominator: fib(10)+fib(9)+fib(6)+fib(4) = 55+34+8+3 = 100
// edge: 55/100 = 55%,  origin: 34/100 = 34%,  hybrid: 8/100 = 8%,  reserved: 3/100 = 3%

const ALLOC_DENOMINATOR = fib(10) + fib(9) + fib(6) + fib(4); // 100
const ALLOC = Object.freeze({
  edge:     fib(10) / ALLOC_DENOMINATOR,  // 0.55
  origin:   fib(9)  / ALLOC_DENOMINATOR,  // 0.34
  hybrid:   fib(6)  / ALLOC_DENOMINATOR,  // 0.08
  reserved: fib(4)  / ALLOC_DENOMINATOR,  // 0.03
});

// ─── Cache Parameters (Fibonacci-scaled) ─────────────────────────────────────

/** Edge embedding LRU cache capacity: fib(16) = 987 */
const CACHE_CAPACITY = fib(16); // 987

/** LRU eviction batch size: fib(6) = 8 */
const EVICTION_BATCH = fib(6); // 8

/** Vector sync batch size: fib(16) = 987 */
const SYNC_BATCH = fib(16); // 987

// ─── LRU Cache ────────────────────────────────────────────────────────────────

/**
 * @class LRUCache
 * Simple LRU cache backed by a Map (insertion-order iteration).
 */
class LRUCache {
  /** @param {number} capacity */
  constructor(capacity) {
    this._capacity = capacity;
    this._map      = new Map();
    this._hits     = 0;
    this._misses   = 0;
    this._evictions = 0;
  }

  get(key) {
    if (!this._map.has(key)) { this._misses++; return undefined; }
    // Move to end (most recently used)
    const value = this._map.get(key);
    this._map.delete(key);
    this._map.set(key, value);
    this._hits++;
    return value;
  }

  set(key, value) {
    if (this._map.has(key)) this._map.delete(key);
    this._map.set(key, value);
    if (this._map.size > this._capacity) this._evict();
  }

  has(key) { return this._map.has(key); }

  _evict() {
    // Evict EVICTION_BATCH oldest entries
    let count = 0;
    for (const k of this._map.keys()) {
      if (count >= EVICTION_BATCH) break;
      this._map.delete(k);
      this._evictions++;
      count++;
    }
  }

  getStats() {
    return {
      size:      this._map.size,
      capacity:  this._capacity,
      hits:      this._hits,
      misses:    this._misses,
      evictions: this._evictions,
      hitRate:   this._hits + this._misses > 0
                   ? this._hits / (this._hits + this._misses)
                   : 0,
    };
  }
}

// ─── EdgeOriginRouter ─────────────────────────────────────────────────────────

/**
 * @class EdgeOriginRouter
 * @description Routes requests to edge, origin, or hybrid based on phi-scored
 *   complexity. Manages a Fibonacci-sized embedding LRU cache and batches
 *   vector sync operations.
 */
class EdgeOriginRouter {
  /**
   * @param {object} [opts]
   * @param {number} [opts.cacheCapacity=987]   LRU cache capacity
   * @param {number} [opts.syncBatch=987]        Vectorize sync batch size
   */
  constructor(opts = {}) {
    this._cache       = new LRUCache(opts.cacheCapacity ?? CACHE_CAPACITY);
    this._syncBatch   = opts.syncBatch ?? SYNC_BATCH;

    // Pending sync queue (edge→origin)
    this._syncQueue   = [];
    this._syncConflicts = 0;
    this._totalRouted = 0;
    this._tierCounts  = {
      [TIER.EDGE_ONLY]:       0,
      [TIER.EDGE_PREFERRED]:  0,
      [TIER.ORIGIN_REQUIRED]: 0,
      [TIER.HYBRID]:          0,
    };

    // Resource allocation tracking
    this._allocUsed = { edge: 0, origin: 0, hybrid: 0, reserved: 0 };
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Route a request to the appropriate tier.
   * @param {object} request
   * @param {string} [request.id]          unique request identifier
   * @param {string} [request.query]       raw query string
   * @param {number[]} [request.vector]    pre-computed embedding vector
   * @param {object} [request.metadata]   arbitrary metadata
   * @returns {{
   *   tier: string,
   *   complexity: number,
   *   cacheHit: boolean,
   *   allocation: object,
   *   requestId: string
   * }}
   */
  route(request) {
    this._totalRouted++;

    const requestId = request.id
      || crypto.createHash('sha256')
               .update(request.query || JSON.stringify(request))
               .digest('hex')
               .slice(0, 16);

    // Check embedding cache first
    const cacheKey = requestId;
    const cached   = this._cache.get(cacheKey);
    if (cached) {
      this._tierCounts[cached.tier]++;
      return { ...cached, cacheHit: true, requestId };
    }

    const complexity  = this.scoreComplexity(request);
    const tier        = this._assignTier(complexity);
    const allocation  = this._allocateResources(tier);

    const result = { tier, complexity, allocation, cacheHit: false, requestId };

    // Cache if vector is present
    if (request.vector) {
      this._cache.set(cacheKey, result);
    }

    // Queue for vector sync
    if (request.vector) {
      this._syncQueue.push({ requestId, vector: request.vector, tier, ts: Date.now() });
      if (this._syncQueue.length >= this._syncBatch) {
        this.sync(); // fire-and-forget flush
      }
    }

    this._tierCounts[tier]++;
    return result;
  }

  /**
   * Score request complexity as a value in [0, 1].
   * Combines: vector density, token count proxy, metadata flags.
   * @param {object} request
   * @returns {number} complexity in [0, 1]
   */
  scoreComplexity(request) {
    let score = 0;
    let components = 0;

    // Vector magnitude as density proxy
    if (request.vector && request.vector.length > 0) {
      const magnitude = Math.sqrt(request.vector.reduce((s, v) => s + v * v, 0));
      // Normalize using PHI: magnitude/(magnitude+PHI) maps (0,∞) to (0,1)
      score += magnitude / (magnitude + PHI);
      components++;
    }

    // Token count: normalize using fib(16) ceiling
    if (request.query) {
      const tokenProxy = Math.min(request.query.length / (fib(16) * fib(3)), 1);
      score += tokenProxy;
      components++;
    }

    // Metadata complexity flags
    if (request.metadata) {
      const flags = [
        request.metadata.requiresTools,
        request.metadata.multiStep,
        request.metadata.streaming,
        request.metadata.sensitiveData,
      ].filter(Boolean).length;
      score += flags / fib(3); // normalise over fib(3)=2 max meaningful flags
      components++;
    }

    if (components === 0) return PSI_SQ; // default to edge-preferred boundary

    // Phi-weighted average clamped to [0, 1]
    return Math.min(score / components, 1);
  }

  /**
   * Flush pending vector sync queue (Vectorize→pgvector).
   * Origin wins on conflict (origin vector is authoritative).
   * @returns {{ synced: number, conflicts: number }}
   */
  sync() {
    const batch = this._syncQueue.splice(0, this._syncBatch);
    let conflicts = 0;

    for (const entry of batch) {
      // Simulate origin-wins conflict resolution:
      // If origin cache already has this vector at higher version, discard edge copy
      const originKey = `origin:${entry.requestId}`;
      if (this._cache.has(originKey)) {
        conflicts++;
        this._syncConflicts++;
        // Origin wins — no update
      }
      // In production: write to pgvector via D1/R2 binding
    }

    return { synced: batch.length, conflicts };
  }

  /**
   * @returns {{
   *   cache: object,
   *   sync: { queued: number, conflicts: number },
   *   tiers: object,
   *   allocation: object,
   *   totalRouted: number
   * }}
   */
  getCacheStats() {
    return {
      cache:        this._cache.getStats(),
      sync:         { queued: this._syncQueue.length, conflicts: this._syncConflicts },
      tiers:        { ...this._tierCounts },
      allocation:   ALLOC,
      totalRouted:  this._totalRouted,
    };
  }

  // ─── Internal Helpers ────────────────────────────────────────────────────────

  /**
   * Assign routing tier based on complexity score.
   * @param {number} complexity  value in [0, 1]
   * @returns {string} TIER value
   */
  _assignTier(complexity) {
    if (complexity < COMPLEXITY.EDGE_CEILING)   return TIER.EDGE_ONLY;
    if (complexity < COMPLEXITY.HYBRID_CEILING) return TIER.EDGE_PREFERRED;
    return TIER.ORIGIN_REQUIRED;
  }

  /**
   * Map a tier to resource allocation percentages.
   * @param {string} tier
   * @returns {object} allocation fractions
   */
  _allocateResources(tier) {
    switch (tier) {
      case TIER.EDGE_ONLY:
        return { edge: ALLOC.edge, origin: 0, hybrid: 0, reserved: ALLOC.reserved };
      case TIER.EDGE_PREFERRED:
        return { edge: ALLOC.edge * PSI, origin: ALLOC.origin * PSI_SQ, hybrid: ALLOC.hybrid, reserved: ALLOC.reserved };
      case TIER.ORIGIN_REQUIRED:
        return { edge: 0, origin: ALLOC.origin, hybrid: ALLOC.hybrid, reserved: ALLOC.reserved };
      case TIER.HYBRID:
        return { edge: ALLOC.edge * PSI_SQ, origin: ALLOC.origin * PSI_SQ, hybrid: ALLOC.hybrid, reserved: ALLOC.reserved };
      default:
        return ALLOC;
    }
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports = {
  EdgeOriginRouter,
  TIER,
  COMPLEXITY,
  ALLOC,
  CACHE_CAPACITY,
  EVICTION_BATCH,
  SYNC_BATCH,
};
