/**
 * @fileoverview Vector Memory — 384D RAM-First Phi-Harmonic Memory Store
 *
 * Two-tier RAM-only vector memory using JavaScript Maps for zero-latency access.
 * Short-term memory (STM) holds fib(16)=987 entries; long-term memory (LTM)
 * holds fib(20)=6765 entries. Consolidation promotes STM entries when importance
 * exceeds CSL_THRESHOLDS.MEDIUM and age exceeds PHI × sessionTTL.
 *
 * Eviction score = importance×w.importance + recency×w.recency + relevance×w.relevance
 * where weights come from EVICTION_WEIGHTS. Lowest score evicted first.
 *
 * Heartbeat drift detection: re-computes cosine similarity between stored and
 * live embeddings, flags entries drifting below COHERENCE_DRIFT_THRESHOLD.
 *
 * @module memory/vector-memory
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  EVICTION_WEIGHTS,
  COHERENCE_DRIFT_THRESHOLD,
  phiAdaptiveInterval,
  phiPriorityScore,
  ALERT_THRESHOLDS,
  nearestFib,
} = require('../shared/phi-math');

const {
  cosineSimilarity,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, dot, norm, vecAdd, vecSub, vecScale,
  hdcBIND, hdcBUNDLE, hdcRandomVector,
  moeRoute, isSemanticDuplicate, hashVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── CONSTANTS ──────────────────────────────────────────────────────────────────

/** Short-term memory capacity = fib(16) = 987 */
const STM_CAPACITY = fib(16);

/** Long-term memory capacity = fib(20) = 6765 */
const LTM_CAPACITY = fib(20);

/** Cosine similarity search threshold = PSI ≈ 0.618 */
const SEARCH_THRESHOLD = PSI;

/** Default top-K results for search = fib(5) = 5 */
const DEFAULT_TOP_K = fib(5);

/** Consolidation age multiplier: PHI × sessionTTL */
const CONSOLIDATION_AGE_FACTOR = PHI;

/** Session TTL = fib(12) * 1000 ms = 144,000 ms ≈ 2.4 min */
const SESSION_TTL_MS = fib(12) * 1000;

/** Heartbeat interval base = fib(10) * 1000 ms = 55,000 ms */
const HEARTBEAT_BASE_MS = fib(10) * 1000;

/** Consolidation age threshold = PHI × SESSION_TTL_MS */
const CONSOLIDATION_AGE_THRESHOLD_MS = CONSOLIDATION_AGE_FACTOR * SESSION_TTL_MS;

/** Importance minimum for STM→LTM promotion = CSL_THRESHOLDS.MEDIUM ≈ 0.809 */
const CONSOLIDATION_IMPORTANCE_MIN = CSL_THRESHOLDS.MEDIUM;

/** Max entries evicted per eviction pass = fib(5) = 5 */
const EVICTION_BATCH_SIZE = fib(5);

/** Memory tiers */
const MEMORY_TIER = Object.freeze({ STM: 'STM', LTM: 'LTM' });

// ─── CLASS ─────────────────────────────────────────────────────────────────────

/**
 * @class VectorMemory
 * @extends EventEmitter
 *
 * RAM-first 384D vector memory store with two-tier STM/LTM architecture,
 * cosine-similarity search, phi-weighted eviction, and heartbeat drift detection.
 *
 * @fires VectorMemory#store - On entry stored (tier, id)
 * @fires VectorMemory#consolidate - On STM→LTM consolidation (count)
 * @fires VectorMemory#evict - On eviction (tier, count)
 * @fires VectorMemory#drift - On heartbeat drift detected (id, similarity)
 * @fires VectorMemory#full - When a tier reaches capacity and eviction is triggered
 */
class VectorMemory extends EventEmitter {
  /**
   * @param {object} [options={}]
   * @param {number}  [options.stmCapacity=fib(16)] - Short-term memory capacity
   * @param {number}  [options.ltmCapacity=fib(20)] - Long-term memory capacity
   * @param {number}  [options.searchThreshold=PSI] - Cosine threshold for search
   * @param {boolean} [options.enableHeartbeat=true] - Start background drift check
   * @param {number}  [options.sessionTtlMs] - Override session TTL
   */
  constructor(options = {}) {
    super();

    this._stmCapacity   = options.stmCapacity    || STM_CAPACITY;
    this._ltmCapacity   = options.ltmCapacity    || LTM_CAPACITY;
    this._searchThresh  = options.searchThreshold || SEARCH_THRESHOLD;
    this._sessionTtl    = options.sessionTtlMs   || SESSION_TTL_MS;

    /** @type {Map<string, object>} Short-term memory: id → entry */
    this._stm = new Map();

    /** @type {Map<string, object>} Long-term memory: id → entry */
    this._ltm = new Map();

    /** Counters and telemetry */
    this._stats = {
      totalStored:       0,
      totalConsolidated: 0,
      totalEvicted:      0,
      searchCount:       0,
      driftEvents:       0,
    };

    /** Current heartbeat interval (adaptive) */
    this._heartbeatIntervalMs = HEARTBEAT_BASE_MS;

    if (options.enableHeartbeat !== false) {
      this._heartbeatTimer = setInterval(
        () => this.heartbeat(),
        this._heartbeatIntervalMs,
      );
      if (this._heartbeatTimer.unref) this._heartbeatTimer.unref();
    }
  }

  // ─── PRIVATE: ENTRY BUILDER ────────────────────────────────────────────────

  /**
   * Build a complete memory entry, assigning defaults and timestamps.
   * @private
   * @param {object} input
   * @returns {object}
   */
  _buildEntry(input) {
    const id = input.id || crypto.randomUUID();
    const now = Date.now();
    return {
      id,
      embedding:   normalize(input.embedding),
      content:     input.content || '',
      metadata:    input.metadata || {},
      timestamp:   input.timestamp || now,
      lastAccessed: now,
      importance:  typeof input.importance === 'number'
        ? Math.max(0, Math.min(1, input.importance))
        : PSI_SQ,             // Default importance ≈ 0.382
      tier:        MEMORY_TIER.STM,
      vectorHash:  hashVector(input.embedding),
    };
  }

  // ─── PRIVATE: EVICTION SCORE ───────────────────────────────────────────────

  /**
   * Compute eviction score for an entry. Higher score = keep; lower = evict.
   * Score = importance×w.importance + recency×w.recency + relevance×w.relevance
   *
   * Recency: normalized time since last access (inverted — recent = high).
   * Relevance: passed in from search context or defaulted to PSI_SQ.
   *
   * @private
   * @param {object} entry
   * @param {number} [relevance=PSI_SQ] - External relevance score
   * @returns {number} Eviction score ∈ [0, 1], lower = more evict-worthy
   */
  _evictionScore(entry, relevance = PSI_SQ) {
    const now        = Date.now();
    const ageMs      = now - entry.lastAccessed;
    const maxAgeMs   = this._sessionTtl * PHI * PHI;
    const recency    = Math.max(0, 1 - ageMs / maxAgeMs);

    return (
      entry.importance * EVICTION_WEIGHTS.importance +
      recency          * EVICTION_WEIGHTS.recency    +
      relevance        * EVICTION_WEIGHTS.relevance
    );
  }

  // ─── PRIVATE: TIER MANAGEMENT ──────────────────────────────────────────────

  /**
   * Get the appropriate Map for a tier.
   * @private
   */
  _tierMap(tier) {
    return tier === MEMORY_TIER.LTM ? this._ltm : this._stm;
  }

  /**
   * Check and trigger eviction if a tier is at/near capacity.
   * @private
   * @param {string} tier - MEMORY_TIER.*
   */
  _checkCapacity(tier) {
    const store = this._tierMap(tier);
    const cap   = tier === MEMORY_TIER.LTM ? this._ltmCapacity : this._stmCapacity;
    if (store.size >= cap) {
      this.emit('full', { tier, size: store.size });
      this.evict(tier);
    }
  }

  // ─── PUBLIC: STORE ─────────────────────────────────────────────────────────

  /**
   * Store a memory entry in STM.
   * Triggers capacity check (eviction) before inserting.
   *
   * @param {object} entry - Memory entry
   * @param {string}   [entry.id]          - Optional ID (auto-generated if absent)
   * @param {number[]}  entry.embedding     - 384D embedding vector
   * @param {string}   [entry.content]     - Original text content
   * @param {object}   [entry.metadata]    - Arbitrary metadata
   * @param {number}   [entry.importance]  - Importance score [0, 1]
   * @param {number}   [entry.timestamp]   - Override timestamp (ms)
   * @returns {string} Stored entry ID
   */
  store(entry) {
    if (!entry.embedding || entry.embedding.length !== EMBEDDING_DIM) {
      throw new Error(`embedding must be ${EMBEDDING_DIM}D, got ${entry.embedding?.length}`);
    }

    this._checkCapacity(MEMORY_TIER.STM);

    const built = this._buildEntry(entry);
    this._stm.set(built.id, built);
    this._stats.totalStored++;

    this.emit('store', { tier: MEMORY_TIER.STM, id: built.id });
    return built.id;
  }

  // ─── PUBLIC: SEARCH ────────────────────────────────────────────────────────

  /**
   * Search both STM and LTM for entries similar to queryEmbedding.
   * Returns top-K results above the cosine threshold.
   *
   * @param {number[]} queryEmbedding - 384D query vector
   * @param {number}   [topK=fib(5)]  - Maximum results
   * @param {number}   [threshold=PSI] - Cosine similarity threshold
   * @returns {Array<{ id: string, similarity: number, entry: object }>}
   */
  search(queryEmbedding, topK = DEFAULT_TOP_K, threshold = this._searchThresh) {
    if (!queryEmbedding || queryEmbedding.length !== EMBEDDING_DIM) {
      throw new Error(`queryEmbedding must be ${EMBEDDING_DIM}D`);
    }

    this._stats.searchCount++;
    const queryNorm = normalize(queryEmbedding);
    const results   = [];

    // Search STM
    for (const entry of this._stm.values()) {
      const sim = cosineSimilarity(queryNorm, entry.embedding);
      if (sim >= threshold) {
        results.push({ id: entry.id, similarity: sim, entry, tier: MEMORY_TIER.STM });
        // Update last accessed
        entry.lastAccessed = Date.now();
      }
    }

    // Search LTM
    for (const entry of this._ltm.values()) {
      const sim = cosineSimilarity(queryNorm, entry.embedding);
      if (sim >= threshold) {
        results.push({ id: entry.id, similarity: sim, entry, tier: MEMORY_TIER.LTM });
        entry.lastAccessed = Date.now();
      }
    }

    // Sort descending by similarity, return top-K
    results.sort((a, b) => b.similarity - a.similarity);
    return results.slice(0, topK);
  }

  // ─── PUBLIC: CONSOLIDATE ───────────────────────────────────────────────────

  /**
   * Consolidate eligible STM entries into LTM.
   *
   * Promotion criteria:
   *   - importance > CONSOLIDATION_IMPORTANCE_MIN (≈ CSL_THRESHOLDS.MEDIUM)
   *   - age > CONSOLIDATION_AGE_THRESHOLD_MS (PHI × sessionTTL)
   *
   * @returns {number} Count of promoted entries
   */
  consolidate() {
    const now       = Date.now();
    const promoted  = [];

    for (const [id, entry] of this._stm.entries()) {
      const age       = now - entry.timestamp;
      const qualified = entry.importance >= CONSOLIDATION_IMPORTANCE_MIN
        && age >= CONSOLIDATION_AGE_THRESHOLD_MS;

      if (qualified) {
        promoted.push(id);
      }
    }

    let count = 0;
    for (const id of promoted) {
      const entry = this._stm.get(id);
      if (!entry) continue;

      this._checkCapacity(MEMORY_TIER.LTM);
      entry.tier = MEMORY_TIER.LTM;
      this._ltm.set(id, entry);
      this._stm.delete(id);
      count++;
    }

    this._stats.totalConsolidated += count;
    if (count > 0) this.emit('consolidate', { count });
    return count;
  }

  // ─── PUBLIC: EVICT ─────────────────────────────────────────────────────────

  /**
   * Evict the lowest-scoring entries from a tier.
   * Eviction score = importance×w.importance + recency×w.recency + relevance×w.relevance.
   * Lowest score evicted first.
   *
   * @param {string} tier - MEMORY_TIER.STM or MEMORY_TIER.LTM
   * @param {number} [batchSize=fib(5)] - Number of entries to evict
   * @returns {number} Count evicted
   */
  evict(tier = MEMORY_TIER.STM, batchSize = EVICTION_BATCH_SIZE) {
    const store = this._tierMap(tier);
    if (store.size === 0) return 0;

    // Score all entries
    const scored = Array.from(store.entries()).map(([id, entry]) => ({
      id,
      score: this._evictionScore(entry),
    }));

    // Sort ascending (lowest score = most evict-worthy)
    scored.sort((a, b) => a.score - b.score);

    const toEvict = scored.slice(0, batchSize);
    for (const { id } of toEvict) {
      store.delete(id);
    }

    const count = toEvict.length;
    this._stats.totalEvicted += count;
    this.emit('evict', { tier, count });
    return count;
  }

  // ─── PUBLIC: HEARTBEAT ─────────────────────────────────────────────────────

  /**
   * Run heartbeat: detect drift by comparing current embedding hashes.
   * If content has changed since storage, the hash will differ — flag as drift.
   *
   * Also adapts the heartbeat interval using phiAdaptiveInterval:
   * if no drift detected, interval grows (less frequent); if drift, shrinks.
   *
   * @returns {{ driftCount: number, driftIds: string[] }}
   */
  heartbeat() {
    const driftIds = [];

    const checkStore = (store) => {
      for (const [id, entry] of store.entries()) {
        const currentHash = hashVector(entry.embedding);
        if (currentHash !== entry.vectorHash) {
          driftIds.push(id);
          const sim = cosineSimilarity(entry.embedding, normalize(entry.embedding));
          this.emit('drift', { id, similarity: sim, tier: entry.tier });
          this._stats.driftEvents++;
          // Update hash to current
          entry.vectorHash = currentHash;
        }
      }
    };

    checkStore(this._stm);
    checkStore(this._ltm);

    const healthy = driftIds.length === 0;
    this._heartbeatIntervalMs = phiAdaptiveInterval(
      HEARTBEAT_BASE_MS,
      healthy,
      this._heartbeatIntervalMs,
    );

    return { driftCount: driftIds.length, driftIds };
  }

  // ─── PUBLIC: STATS ─────────────────────────────────────────────────────────

  /**
   * Get memory statistics.
   * @returns {object}
   */
  getStats() {
    return {
      stm: {
        size:     this._stm.size,
        capacity: this._stmCapacity,
        ratio:    this._stm.size / this._stmCapacity,
      },
      ltm: {
        size:     this._ltm.size,
        capacity: this._ltmCapacity,
        ratio:    this._ltm.size / this._ltmCapacity,
      },
      totals: { ...this._stats },
      thresholds: {
        search:            this._searchThresh,
        consolidation:     CONSOLIDATION_IMPORTANCE_MIN,
        consolidationAge:  CONSOLIDATION_AGE_THRESHOLD_MS,
      },
      heartbeatIntervalMs: this._heartbeatIntervalMs,
    };
  }

  /**
   * Gracefully stop background timers.
   */
  destroy() {
    if (this._heartbeatTimer) clearInterval(this._heartbeatTimer);
    this.removeAllListeners();
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  VectorMemory,
  MEMORY_TIER,
  STM_CAPACITY,
  LTM_CAPACITY,
  SEARCH_THRESHOLD,
  CONSOLIDATION_IMPORTANCE_MIN,
};
