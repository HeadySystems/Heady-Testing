/**
 * @fileoverview Graph RAG — Knowledge Graph with Louvain Community Detection
 *
 * Entity-relationship graph store enabling four query modes:
 *   - local:  entity similarity + depth-limited graph traversal
 *   - global: community summary vectors
 *   - hybrid: phi-fusion (PSI local + PSI_SQ global ≈ 0.618 / 0.382)
 *   - naive:  pure vector search (no graph structure)
 *
 * Community detection uses Louvain modularity optimization with
 * maxIterations = fib(7) = 13. Entity dedup fires at DEDUP_THRESHOLD ≈ 0.972.
 *
 * @module memory/graph-rag
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  phiFusionWeights,
  nearestFib,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

const {
  cosineSimilarity,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, dot, norm, vecAdd, vecSub, vecScale,
  hdcBIND, hdcBUNDLE, hdcRandomVector,
  moeRoute, isSemanticDuplicate, hashVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── CONSTANTS ──────────────────────────────────────────────────────────────────

/** Louvain max iterations = fib(7) = 13 */
const LOUVAIN_MAX_ITERATIONS = fib(7);

/** Max entities per document = fib(10) = 55 */
const MAX_ENTITIES_PER_DOC = fib(10);

/** Max relationships per document = fib(11) = 89 */
const MAX_RELATIONSHIPS_PER_DOC = fib(11);

/** Entity deduplication threshold ≈ 0.972 */
const ENTITY_DEDUP_THRESHOLD = DEDUP_THRESHOLD;

/** Default query result limit = fib(7) = 13 */
const DEFAULT_RESULT_LIMIT = fib(7);

/** Default relationship edge weight = PSI ≈ 0.618 */
const DEFAULT_EDGE_WEIGHT = PSI;

/** Max graph traversal hops = fib(3) = 2 */
const DEFAULT_MAX_HOPS = fib(3);

/** Result cache capacity = fib(16) = 987 */
const CACHE_CAPACITY = fib(16);

/** Phi-fusion weights for hybrid mode: [PSI, PSI_SQ] ≈ [0.618, 0.382] */
const HYBRID_WEIGHTS = Object.freeze({
  local:  PSI,
  global: PSI_SQ,
});

/** Query modes */
const QUERY_MODE = Object.freeze({
  LOCAL:  'local',
  GLOBAL: 'global',
  HYBRID: 'hybrid',
  NAIVE:  'naive',
});

// ─── CLASS ─────────────────────────────────────────────────────────────────────

/**
 * @class GraphRAG
 *
 * Knowledge graph with entity nodes, typed relationships, Louvain community
 * detection, and four-mode retrieval (local/global/hybrid/naive).
 *
 * @example
 * const rag = new GraphRAG();
 * rag.addEntity({ id: 'e1', name: 'Phi', type: 'concept', embedding: vec384D });
 * rag.addRelationship({ source: 'e1', target: 'e2', type: 'relates_to' });
 * const results = await rag.query('golden ratio', { mode: 'hybrid' });
 */
class GraphRAG {
  /**
   * @param {object} [options={}]
   * @param {number}  [options.resultLimit=fib(7)] - Default result limit
   * @param {number}  [options.maxHops=fib(3)] - Default max traversal hops
   * @param {number}  [options.dedupThreshold] - Entity dedup threshold
   */
  constructor(options = {}) {
    /** @type {Map<string, object>} Entity registry: id → entity */
    this._entities = new Map();

    /** @type {Map<string, object[]>} Adjacency list: entityId → [edges] */
    this._adj = new Map();

    /** @type {Map<string, object>} Edge registry: `${src}:${rel}:${tgt}` → edge */
    this._edges = new Map();

    /** @type {Map<string, number>} Community assignments: entityId → communityId */
    this._communities = new Map();

    /** @type {Map<number, { members: string[], summaryVector: number[] }>} Community summaries */
    this._communitySummaries = new Map();

    this._resultLimit     = options.resultLimit    || DEFAULT_RESULT_LIMIT;
    this._maxHops         = options.maxHops        || DEFAULT_MAX_HOPS;
    this._dedupThreshold  = options.dedupThreshold || ENTITY_DEDUP_THRESHOLD;

    /** @type {Map<string, { results: object[], ts: number }>} Query result cache */
    this._queryCache  = new Map();

    this._stats = {
      entityCount:       0,
      edgeCount:         0,
      communityCount:    0,
      queryCount:        0,
      cacheHits:         0,
    };
  }

  // ─── PRIVATE: CACHE ────────────────────────────────────────────────────────

  /**
   * Generate a cache key for a query.
   * @private
   */
  _cacheKey(text, mode) {
    return crypto.createHash('sha256')
      .update(`${text}:${mode}`)
      .digest('hex');
  }

  /**
   * Get cached query result (TTL = SESSION_TTL_MS = fib(12)*1000).
   * @private
   */
  _getCached(key) {
    const entry = this._queryCache.get(key);
    if (!entry) return null;
    const TTL = fib(12) * 1000;
    if (Date.now() - entry.ts > TTL) {
      this._queryCache.delete(key);
      return null;
    }
    this._stats.cacheHits++;
    return entry.results;
  }

  /**
   * Store query results in cache. Evict LRU if at capacity.
   * @private
   */
  _setCached(key, results) {
    if (this._queryCache.size >= CACHE_CAPACITY) {
      const oldest = this._queryCache.keys().next().value;
      this._queryCache.delete(oldest);
    }
    this._queryCache.set(key, { results, ts: Date.now() });
  }

  // ─── PRIVATE: DEDUP CHECK ──────────────────────────────────────────────────

  /**
   * Find an existing entity semantically identical to a candidate embedding.
   * @private
   * @param {number[]} embedding
   * @returns {string|null} Existing entity ID or null
   */
  _findDuplicate(embedding) {
    for (const [id, entity] of this._entities.entries()) {
      if (cosineSimilarity(embedding, entity.embedding) >= this._dedupThreshold) {
        return id;
      }
    }
    return null;
  }

  // ─── PUBLIC: ENTITY MANAGEMENT ────────────────────────────────────────────

  /**
   * Add an entity node to the graph.
   * Deduplication: if an entity with cos ≥ DEDUP_THRESHOLD exists, returns existing ID.
   *
   * @param {object}   entity
   * @param {string}   entity.id          - Unique identifier
   * @param {string}   entity.name        - Human-readable name
   * @param {string}   entity.type        - Entity type (person/org/concept/etc.)
   * @param {string}   [entity.description]
   * @param {number[]} entity.embedding   - 384D embedding vector
   * @param {object}   [entity.metadata]
   * @returns {string} Entity ID (may be existing ID if deduplicated)
   */
  addEntity(entity) {
    if (!entity.embedding || entity.embedding.length !== EMBEDDING_DIM) {
      throw new Error(`Entity embedding must be ${EMBEDDING_DIM}D`);
    }

    const normEmbedding = normalize(entity.embedding);
    const dupId = this._findDuplicate(normEmbedding);
    if (dupId) return dupId;

    const id = entity.id || crypto.randomUUID();
    this._entities.set(id, {
      id,
      name:        entity.name        || '',
      type:        entity.type        || 'concept',
      description: entity.description || '',
      embedding:   normEmbedding,
      metadata:    entity.metadata    || {},
      createdAt:   Date.now(),
    });

    this._adj.set(id, []);
    this._stats.entityCount++;
    return id;
  }

  /**
   * Add a directed relationship (edge) between two entities.
   * Default weight = PSI ≈ 0.618.
   *
   * @param {object} rel
   * @param {string} rel.source       - Source entity ID
   * @param {string} rel.target       - Target entity ID
   * @param {string} rel.type         - Relationship type
   * @param {number} [rel.weight=PSI] - Edge weight ∈ [0, 1]
   * @param {string} [rel.description]
   * @returns {string} Edge key
   */
  addRelationship(rel) {
    const src = rel.source;
    const tgt = rel.target;
    if (!this._entities.has(src)) throw new Error(`Source entity not found: ${src}`);
    if (!this._entities.has(tgt)) throw new Error(`Target entity not found: ${tgt}`);

    const edgeKey = `${src}:${rel.type}:${tgt}`;
    this._edges.set(edgeKey, {
      source:      src,
      target:      tgt,
      type:        rel.type        || 'relates_to',
      weight:      typeof rel.weight === 'number' ? rel.weight : DEFAULT_EDGE_WEIGHT,
      description: rel.description || '',
      createdAt:   Date.now(),
    });

    this._adj.get(src).push({ target: tgt, type: rel.type, weight: rel.weight || DEFAULT_EDGE_WEIGHT });
    this._stats.edgeCount++;
    return edgeKey;
  }

  // ─── PUBLIC: TRAVERSAL ─────────────────────────────────────────────────────

  /**
   * BFS graph traversal from a starting entity up to maxHops hops.
   * Returns all reachable entities with traversal metadata.
   *
   * @param {string} entityId  - Starting entity ID
   * @param {number} [maxHops=fib(3)] - Maximum traversal depth
   * @returns {Array<{ entity: object, hops: number, pathWeight: number }>}
   */
  traverseHops(entityId, maxHops = DEFAULT_MAX_HOPS) {
    if (!this._entities.has(entityId)) return [];

    const visited = new Set([entityId]);
    const queue   = [{ id: entityId, hops: 0, pathWeight: 1.0 }];
    const results = [];

    while (queue.length > 0) {
      const { id, hops, pathWeight } = queue.shift();
      const entity = this._entities.get(id);
      if (!entity) continue;

      if (id !== entityId) {
        results.push({ entity, hops, pathWeight });
      }

      if (hops >= maxHops) continue;

      const neighbors = this._adj.get(id) || [];
      for (const edge of neighbors) {
        if (!visited.has(edge.target)) {
          visited.add(edge.target);
          // Decay path weight by edge weight, phi-scaled
          const newWeight = pathWeight * edge.weight * PSI;
          queue.push({ id: edge.target, hops: hops + 1, pathWeight: newWeight });
        }
      }
    }

    return results.sort((a, b) => b.pathWeight - a.pathWeight);
  }

  // ─── PUBLIC: COMMUNITY DETECTION ──────────────────────────────────────────

  /**
   * Run Louvain community detection on the graph.
   *
   * Simplified Louvain: iteratively reassign each node to the community
   * that maximizes local modularity gain (neighbor weight sum heuristic).
   * Runs up to fib(7)=13 iterations.
   *
   * @returns {Map<number, string[]>} communityId → [entityIds]
   */
  detectCommunities() {
    const entities = Array.from(this._entities.keys());
    if (entities.length === 0) return new Map();

    // Initialize: each entity in its own community
    const communityOf = new Map(entities.map((id, i) => [id, i]));
    let   changed     = true;
    let   iteration   = 0;

    while (changed && iteration < LOUVAIN_MAX_ITERATIONS) {
      changed    = false;
      iteration++;

      for (const nodeId of entities) {
        const neighbors   = this._adj.get(nodeId) || [];
        const currentComm = communityOf.get(nodeId);

        // Count weighted connections to each community
        const commWeights = new Map();
        commWeights.set(currentComm, 0);

        for (const edge of neighbors) {
          const neighborComm = communityOf.get(edge.target);
          if (neighborComm === undefined) continue;
          commWeights.set(neighborComm, (commWeights.get(neighborComm) || 0) + edge.weight);
        }

        // Also check reverse edges (undirected treatment)
        for (const [otherId, otherAdj] of this._adj.entries()) {
          for (const edge of otherAdj) {
            if (edge.target === nodeId) {
              const otherComm = communityOf.get(otherId);
              if (otherComm !== undefined) {
                commWeights.set(otherComm, (commWeights.get(otherComm) || 0) + edge.weight * PSI_SQ);
              }
            }
          }
        }

        // Assign to community with highest connection weight
        let bestComm   = currentComm;
        let bestWeight = commWeights.get(currentComm) || 0;

        for (const [comm, weight] of commWeights.entries()) {
          if (weight > bestWeight) {
            bestWeight = weight;
            bestComm   = comm;
          }
        }

        if (bestComm !== currentComm) {
          communityOf.set(nodeId, bestComm);
          changed = true;
        }
      }
    }

    // Build community → members map
    const communities = new Map();
    for (const [nodeId, commId] of communityOf.entries()) {
      if (!communities.has(commId)) communities.set(commId, []);
      communities.get(commId).push(nodeId);
      this._communities.set(nodeId, commId);
    }

    // Compute community summary vectors (centroid of member embeddings)
    for (const [commId, members] of communities.entries()) {
      const embeddings = members
        .map(id => this._entities.get(id)?.embedding)
        .filter(Boolean);

      const summaryVector = embeddings.length > 0
        ? cslCONSENSUS(embeddings, phiFusionWeights(embeddings.length))
        : hdcRandomVector(EMBEDDING_DIM);

      this._communitySummaries.set(commId, { members, summaryVector });
    }

    this._stats.communityCount = communities.size;
    return communities;
  }

  // ─── PRIVATE: QUERY MODES ──────────────────────────────────────────────────

  /**
   * Local query: entity similarity + graph traversal expansion.
   * @private
   */
  _queryLocal(queryEmbedding, limit) {
    const queryNorm = normalize(queryEmbedding);
    const scored    = [];

    for (const entity of this._entities.values()) {
      const sim = cosineSimilarity(queryNorm, entity.embedding);
      if (sim >= CSL_THRESHOLDS.LOW) {
        scored.push({ entity, score: sim, source: 'local' });
      }
    }

    scored.sort((a, b) => b.score - a.score);
    const topEntities = scored.slice(0, limit);

    // Expand via traversal
    const expanded   = new Map(topEntities.map(r => [r.entity.id, r]));
    for (const { entity } of topEntities.slice(0, fib(3))) {
      const neighbors = this.traverseHops(entity.id, DEFAULT_MAX_HOPS);
      for (const { entity: ne, pathWeight } of neighbors) {
        if (!expanded.has(ne.id)) {
          const sim = cosineSimilarity(queryNorm, ne.embedding);
          expanded.set(ne.id, { entity: ne, score: sim * pathWeight, source: 'traversal' });
        }
      }
    }

    return Array.from(expanded.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  /**
   * Global query: community summary vectors.
   * @private
   */
  _queryGlobal(queryEmbedding, limit) {
    if (this._communitySummaries.size === 0) {
      this.detectCommunities();
    }

    const queryNorm = normalize(queryEmbedding);
    const results   = [];

    for (const [commId, { members, summaryVector }] of this._communitySummaries.entries()) {
      const sim = cosineSimilarity(queryNorm, summaryVector);
      if (sim >= CSL_THRESHOLDS.LOW) {
        // Return representative members of matching communities
        for (const memberId of members.slice(0, fib(3))) {
          const entity = this._entities.get(memberId);
          if (entity) results.push({ entity, score: sim * PSI, source: 'global', communityId: commId });
        }
      }
    }

    return results.sort((a, b) => b.score - a.score).slice(0, limit);
  }

  /**
   * Hybrid query: phi-fusion of local (PSI weight) and global (PSI_SQ weight).
   * @private
   */
  _queryHybrid(queryEmbedding, limit) {
    const localResults  = this._queryLocal(queryEmbedding, limit);
    const globalResults = this._queryGlobal(queryEmbedding, limit);

    // Merge with phi-fusion scores
    const merged = new Map();

    for (const r of localResults) {
      merged.set(r.entity.id, { ...r, score: r.score * HYBRID_WEIGHTS.local });
    }

    for (const r of globalResults) {
      if (merged.has(r.entity.id)) {
        merged.get(r.entity.id).score += r.score * HYBRID_WEIGHTS.global;
      } else {
        merged.set(r.entity.id, { ...r, score: r.score * HYBRID_WEIGHTS.global });
      }
    }

    return Array.from(merged.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, limit);
  }

  /**
   * Naive query: pure vector search, no graph structure.
   * @private
   */
  _queryNaive(queryEmbedding, limit) {
    const queryNorm = normalize(queryEmbedding);
    const results   = [];

    for (const entity of this._entities.values()) {
      const sim = cosineSimilarity(queryNorm, entity.embedding);
      results.push({ entity, score: sim, source: 'naive' });
    }

    return results.sort((a, b) => b.score - a.score).slice(0, limit);
  }

  // ─── PUBLIC: QUERY ─────────────────────────────────────────────────────────

  /**
   * Query the graph using the specified mode.
   *
   * @param {number[]} queryEmbedding - 384D query embedding vector
   * @param {object}   [options={}]
   * @param {string}   [options.mode='hybrid'] - Query mode (local/global/hybrid/naive)
   * @param {number}   [options.limit=fib(7)]  - Result limit
   * @param {boolean}  [options.useCache=true]
   * @returns {Array<{ entity: object, score: number, source: string }>}
   */
  query(queryEmbedding, options = {}) {
    const mode   = options.mode   || QUERY_MODE.HYBRID;
    const limit  = options.limit  || this._resultLimit;
    const useCache = options.useCache !== false;

    if (!queryEmbedding || queryEmbedding.length !== EMBEDDING_DIM) {
      throw new Error(`queryEmbedding must be ${EMBEDDING_DIM}D`);
    }

    const cacheKey = useCache ? this._cacheKey(hashVector(queryEmbedding), mode) : null;
    if (cacheKey) {
      const cached = this._getCached(cacheKey);
      if (cached) return cached;
    }

    this._stats.queryCount++;

    let results;
    switch (mode) {
      case QUERY_MODE.LOCAL:   results = this._queryLocal(queryEmbedding, limit);  break;
      case QUERY_MODE.GLOBAL:  results = this._queryGlobal(queryEmbedding, limit); break;
      case QUERY_MODE.HYBRID:  results = this._queryHybrid(queryEmbedding, limit); break;
      case QUERY_MODE.NAIVE:   results = this._queryNaive(queryEmbedding, limit);  break;
      default:                 results = this._queryHybrid(queryEmbedding, limit);
    }

    if (cacheKey) this._setCached(cacheKey, results);
    return results;
  }

  // ─── PUBLIC: STATS ─────────────────────────────────────────────────────────

  /**
   * Get graph and query statistics.
   * @returns {object}
   */
  getStats() {
    return {
      entities:       this._entities.size,
      edges:          this._edges.size,
      communities:    this._communitySummaries.size,
      queryCount:     this._stats.queryCount,
      cacheHits:      this._stats.cacheHits,
      cacheSize:      this._queryCache.size,
      dedupThreshold: this._dedupThreshold,
      limits: {
        maxEntitiesPerDoc:      MAX_ENTITIES_PER_DOC,
        maxRelationshipsPerDoc: MAX_RELATIONSHIPS_PER_DOC,
        defaultResultLimit:     DEFAULT_RESULT_LIMIT,
        defaultMaxHops:         DEFAULT_MAX_HOPS,
        louvainMaxIterations:   LOUVAIN_MAX_ITERATIONS,
      },
    };
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  GraphRAG,
  QUERY_MODE,
  LOUVAIN_MAX_ITERATIONS,
  MAX_ENTITIES_PER_DOC,
  MAX_RELATIONSHIPS_PER_DOC,
  DEFAULT_RESULT_LIMIT,
  HYBRID_WEIGHTS,
};
