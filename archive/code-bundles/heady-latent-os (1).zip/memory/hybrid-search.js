/**
 * @fileoverview Hybrid Search — BM25 + Dense HNSW + SPLADE with RRF Fusion
 *
 * Three-retriever hybrid search fusing keyword (BM25), dense vector (HNSW cosine),
 * and sparse learned (SPLADE) results via Reciprocal Rank Fusion (RRF).
 *
 * RRF formula: score(d) = Σᵢ weight_i / (k + rankᵢ(d)),  k = 60
 *
 * 2-way fusion (dense + BM25): phiFusionWeights(2) → [0.618, 0.382]
 * 3-way fusion (dense + BM25 + SPLADE): phiFusionWeights(3) → [0.528, 0.326, 0.146]
 *
 * CSL-gated dynamic weight modulation adjusts dense weight in real time based
 * on cslGate(denseWeight, cslScore, CSL_THRESHOLDS.MEDIUM).
 *
 * HNSW parameters are configured by index scale (small/medium/large) using
 * Fibonacci numbers for m, ef_construction, and ef_search.
 *
 * @module memory/hybrid-search
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  phiFusionWeights,
  cslGate,
  cslBlend,
  sigmoid,
  adaptiveTemperature,
  nearestFib,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

const {
  cosineSimilarity,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, dot, norm, vecAdd, vecSub, vecScale,
  hdcBIND, hdcBUNDLE, hdcRandomVector,
  moeRoute, isSemanticDuplicate, hashVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── CONSTANTS ──────────────────────────────────────────────────────────────────

/** RRF rank smoothing constant k = 60 (standard RRF value) */
const RRF_K = 60;

/** 2-way phi-fusion weights: [dense ≈ 0.618, bm25 ≈ 0.382] */
const WEIGHTS_2WAY = Object.freeze({
  dense: phiFusionWeights(2)[0],  // PSI    ≈ 0.618
  bm25:  phiFusionWeights(2)[1],  // PSI_SQ ≈ 0.382
});

/** 3-way phi-fusion weights: [dense ≈ 0.528, bm25 ≈ 0.326, sparse ≈ 0.146] */
const WEIGHTS_3WAY = Object.freeze({
  dense:  phiFusionWeights(3)[0],
  bm25:   phiFusionWeights(3)[1],
  sparse: phiFusionWeights(3)[2],
});

/**
 * HNSW index parameters by scale. All values are Fibonacci numbers.
 *  m            = connectivity (edges per node)
 *  ef_c         = ef_construction (index-time beam width)
 *  ef_s         = ef_search (query-time beam width)
 */
const HNSW_PARAMS = Object.freeze({
  small: {
    m:    fib(7),   // 13
    ef_c: fib(9),   // 34
    ef_s: fib(8),   // 21
  },
  medium: {
    m:    fib(8),   // 21
    ef_c: fib(11),  // 89
    ef_s: fib(10),  // 55
  },
  large: {
    m:    fib(8),   // 21
    ef_c: fib(12),  // 144
    ef_s: fib(11),  // 89
  },
});

/** Rerank top-K = fib(8) = 21 */
const RERANK_TOP_K = fib(8);

/** Slow query threshold = Math.round(1000 * PSI) = 618 ms */
const SLOW_QUERY_THRESHOLD_MS = Math.round(1000 * PSI);

/** BM25 term frequency saturation parameter k1 = PHI ≈ 1.618 */
const BM25_K1 = PHI;

/** BM25 length normalization b = PSI_SQ ≈ 0.382 */
const BM25_B = PSI_SQ;

/** Index scale identifiers */
const INDEX_SCALE = Object.freeze({ SMALL: 'small', MEDIUM: 'medium', LARGE: 'large' });

// ─── BM25 ENGINE ───────────────────────────────────────────────────────────────

/**
 * @class BM25Index
 * Lightweight in-memory BM25 keyword retriever.
 * k1 = PHI ≈ 1.618,  b = PSI_SQ ≈ 0.382
 */
class BM25Index {
  constructor() {
    /** @type {Array<{ id: string, tokens: string[], length: number }>} */
    this._docs      = [];
    /** @type {Map<string, Map<number, number>>} term → Map<docIdx, tf> */
    this._index     = new Map();
    this._avgDocLen = 0;
    this._totalDocs = 0;
  }

  /**
   * Tokenize text into lowercase word tokens.
   * @param {string} text
   * @returns {string[]}
   */
  _tokenize(text) {
    return String(text).toLowerCase().match(/\b\w+\b/g) || [];
  }

  /**
   * Add a document to the BM25 index.
   * @param {string} id   - Document ID
   * @param {string} text - Document text
   */
  addDocument(id, text) {
    const tokens  = this._tokenize(text);
    const docIdx  = this._docs.length;
    this._docs.push({ id, tokens, length: tokens.length });

    // Count term frequencies
    const tf = new Map();
    for (const token of tokens) {
      tf.set(token, (tf.get(token) || 0) + 1);
    }

    for (const [term, freq] of tf.entries()) {
      if (!this._index.has(term)) this._index.set(term, new Map());
      this._index.get(term).set(docIdx, freq);
    }

    // Update average document length
    this._totalDocs++;
    this._avgDocLen = (this._avgDocLen * (this._totalDocs - 1) + tokens.length) / this._totalDocs;
  }

  /**
   * Retrieve documents scored by BM25 for a query.
   * @param {string} query
   * @param {number} [topK=RERANK_TOP_K]
   * @returns {Array<{ id: string, score: number, rank: number }>}
   */
  search(query, topK = RERANK_TOP_K) {
    if (this._totalDocs === 0) return [];
    const queryTokens = this._tokenize(query);
    const scores      = new Array(this._docs.length).fill(0);

    for (const term of queryTokens) {
      const postings = this._index.get(term);
      if (!postings) continue;

      const df  = postings.size;
      const idf = Math.log(1 + (this._totalDocs - df + PSI) / (df + PSI));

      for (const [docIdx, tf] of postings.entries()) {
        const doc    = this._docs[docIdx];
        const tfNorm = (tf * (BM25_K1 + 1)) /
          (tf + BM25_K1 * (1 - BM25_B + BM25_B * (doc.length / this._avgDocLen)));
        scores[docIdx] += idf * tfNorm;
      }
    }

    return scores
      .map((score, i) => ({ id: this._docs[i].id, score }))
      .filter(r => r.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
      .map((r, rank) => ({ ...r, rank: rank + 1 }));
  }

  /** @returns {number} Document count */
  get size() { return this._totalDocs; }
}

// ─── DENSE INDEX (HNSW STUB) ───────────────────────────────────────────────────

/**
 * @class DenseIndex
 * RAM-based dense vector index using brute-force cosine similarity.
 * In production, replace with a native HNSW library (hnswlib-node).
 * HNSW parameters are stored for configuration handoff.
 */
class DenseIndex {
  /**
   * @param {object} [params=HNSW_PARAMS.small] - HNSW parameters
   */
  constructor(params = HNSW_PARAMS.small) {
    /** @type {Array<{ id: string, embedding: number[] }>} */
    this._vectors = [];
    this._params  = params;
  }

  /**
   * Add a vector to the index.
   * @param {string}   id
   * @param {number[]} embedding - 384D vector
   */
  add(id, embedding) {
    this._vectors.push({ id, embedding: normalize(embedding) });
  }

  /**
   * Search for the top-K most similar vectors.
   * @param {number[]} queryEmbedding
   * @param {number}   [topK=RERANK_TOP_K]
   * @returns {Array<{ id: string, score: number, rank: number }>}
   */
  search(queryEmbedding, topK = RERANK_TOP_K) {
    if (this._vectors.length === 0) return [];
    const queryNorm = normalize(queryEmbedding);
    return this._vectors
      .map(v => ({ id: v.id, score: cosineSimilarity(queryNorm, v.embedding) }))
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
      .map((r, rank) => ({ ...r, rank: rank + 1 }));
  }

  /** @returns {{ m: number, ef_c: number, ef_s: number }} */
  get params() { return this._params; }

  /** @returns {number} */
  get size() { return this._vectors.length; }
}

// ─── SPARSE INDEX (SPLADE STUB) ────────────────────────────────────────────────

/**
 * @class SparseIndex
 * Sparse inverted index simulating SPLADE expanded representations.
 * Sparse vectors are stored as Map<token → weight> and scored via inner product.
 */
class SparseIndex {
  constructor() {
    /** @type {Array<{ id: string, sparseVec: Map<string, number> }>} */
    this._docs = [];
  }

  /**
   * Add a document with its sparse expansion.
   * @param {string}            id
   * @param {Map<string,number>|object} sparseVec - token→weight sparse representation
   */
  add(id, sparseVec) {
    const vec = sparseVec instanceof Map ? sparseVec : new Map(Object.entries(sparseVec));
    this._docs.push({ id, sparseVec: vec });
  }

  /**
   * Score documents by sparse inner product with query sparse vector.
   * @param {Map<string,number>|object} querySparse
   * @param {number} [topK=RERANK_TOP_K]
   * @returns {Array<{ id: string, score: number, rank: number }>}
   */
  search(querySparse, topK = RERANK_TOP_K) {
    if (this._docs.length === 0) return [];
    const queryVec = querySparse instanceof Map ? querySparse : new Map(Object.entries(querySparse));

    return this._docs
      .map(doc => {
        let score = 0;
        for (const [token, qw] of queryVec.entries()) {
          const dw = doc.sparseVec.get(token);
          if (dw) score += qw * dw;
        }
        return { id: doc.id, score };
      })
      .filter(r => r.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, topK)
      .map((r, rank) => ({ ...r, rank: rank + 1 }));
  }

  /** @returns {number} */
  get size() { return this._docs.length; }
}

// ─── CLASS ─────────────────────────────────────────────────────────────────────

/**
 * @class HybridSearch
 *
 * Three-retriever hybrid search with phi-weighted RRF fusion, CSL-gated dynamic
 * weights, and per-scale HNSW configuration.
 *
 * @example
 * const hs = new HybridSearch();
 * hs.configureIndex('medium');
 * hs.addDocument('doc1', 'text', embedding, sparseVec);
 * const results = await hs.search('query text', { embedding: vec, mode: '3way' });
 */
class HybridSearch {
  /**
   * @param {object} [options={}]
   * @param {string}  [options.scale='small'] - HNSW scale (small/medium/large)
   * @param {boolean} [options.useCslGating=true] - Enable CSL weight modulation
   */
  constructor(options = {}) {
    const scale      = options.scale || INDEX_SCALE.SMALL;
    const hnswParams = HNSW_PARAMS[scale] || HNSW_PARAMS.small;

    /** @type {BM25Index} Keyword retriever */
    this._bm25   = new BM25Index();

    /** @type {DenseIndex} Dense HNSW retriever */
    this._dense  = new DenseIndex(hnswParams);

    /** @type {SparseIndex} SPLADE sparse retriever */
    this._sparse = new SparseIndex();

    this._scale       = scale;
    this._useCslGating = options.useCslGating !== false;

    this._stats = {
      searchCount: 0,
      slowQueries: 0,
      totalLatencyMs: 0,
    };
  }

  // ─── PUBLIC: DOCUMENT MANAGEMENT ──────────────────────────────────────────

  /**
   * Add a document to all three retrievers.
   * @param {string}                id         - Document ID
   * @param {string}                text       - Document text (for BM25)
   * @param {number[]}              [embedding] - 384D embedding (for Dense)
   * @param {Map<string,number>|object} [sparse] - SPLADE sparse vector
   */
  addDocument(id, text, embedding = null, sparse = null) {
    this._bm25.addDocument(id, text);
    if (embedding) this._dense.add(id, embedding);
    if (sparse)    this._sparse.add(id, sparse);
  }

  // ─── PRIVATE: RRF FUSION ──────────────────────────────────────────────────

  /**
   * Reciprocal Rank Fusion across multiple ranked lists.
   *
   * score(d) = Σᵢ weightᵢ / (k + rankᵢ(d))
   *
   * @private
   * @param {Array<Array<{ id: string, score: number, rank: number }>>} rankedLists
   * @param {number[]} weights - Per-list fusion weights (must sum to 1)
   * @param {number}   [cslScore=CSL_THRESHOLDS.MEDIUM] - CSL score for dynamic weight
   * @returns {Array<{ id: string, rrfScore: number }>}
   */
  _rrf(rankedLists, weights, cslScore = CSL_THRESHOLDS.MEDIUM) {
    const docScores = new Map();
    const effectiveWeights = [...weights];

    // CSL-gated dynamic weight modulation
    if (this._useCslGating && rankedLists.length >= 2) {
      const rawDense    = effectiveWeights[0];
      const gatedDense  = cslGate(rawDense, cslScore, CSL_THRESHOLDS.MEDIUM);
      // Redistribute excess/deficit proportionally to other weights
      const delta        = rawDense - gatedDense;
      effectiveWeights[0] = gatedDense;
      const otherSum      = effectiveWeights.slice(1).reduce((s, w) => s + w, 0);
      for (let i = 1; i < effectiveWeights.length; i++) {
        effectiveWeights[i] += delta * (effectiveWeights[i] / otherSum);
      }
    }

    for (let listIdx = 0; listIdx < rankedLists.length; listIdx++) {
      const list   = rankedLists[listIdx];
      const weight = effectiveWeights[listIdx] || 0;

      for (const { id, rank } of list) {
        const contrib = weight / (RRF_K + rank);
        docScores.set(id, (docScores.get(id) || 0) + contrib);
      }
    }

    return Array.from(docScores.entries())
      .map(([id, rrfScore]) => ({ id, rrfScore }))
      .sort((a, b) => b.rrfScore - a.rrfScore);
  }

  // ─── PUBLIC: FUSE RESULTS ─────────────────────────────────────────────────

  /**
   * Fuse pre-computed ranked lists via phi-weighted RRF.
   *
   * @param {Array<{ id: string, score: number, rank: number }>} bm25Results
   * @param {Array<{ id: string, score: number, rank: number }>} denseResults
   * @param {Array<{ id: string, score: number, rank: number }>} [sparseResults]
   * @param {object} [options={}]
   * @param {number}  [options.cslScore] - CSL gating score
   * @returns {Array<{ id: string, rrfScore: number }>}
   */
  fuseResults(bm25Results, denseResults, sparseResults = null, options = {}) {
    const cslScore = options.cslScore || CSL_THRESHOLDS.MEDIUM;

    if (sparseResults && sparseResults.length > 0) {
      // 3-way fusion
      return this._rrf(
        [denseResults, bm25Results, sparseResults],
        [WEIGHTS_3WAY.dense, WEIGHTS_3WAY.bm25, WEIGHTS_3WAY.sparse],
        cslScore,
      );
    }

    // 2-way fusion
    return this._rrf(
      [denseResults, bm25Results],
      [WEIGHTS_2WAY.dense, WEIGHTS_2WAY.bm25],
      cslScore,
    );
  }

  // ─── PUBLIC: SEARCH ────────────────────────────────────────────────────────

  /**
   * Execute hybrid search across all retrievers and return RRF-fused results.
   *
   * @param {string}   queryText - Query string (for BM25)
   * @param {object}   [options={}]
   * @param {number[]} [options.embedding]  - Query embedding (for Dense)
   * @param {Map<string,number>|object} [options.sparse] - Query sparse vector (for SPLADE)
   * @param {string}   [options.mode='3way'] - Fusion mode ('2way' or '3way')
   * @param {number}   [options.topK=RERANK_TOP_K] - Final result count
   * @param {number}   [options.cslScore]  - Override CSL gating score
   * @returns {Promise<Array<{ id: string, rrfScore: number, rank: number }>>}
   */
  async search(queryText, options = {}) {
    const t0        = Date.now();
    const topK      = options.topK    || RERANK_TOP_K;
    const mode      = options.mode    || '3way';
    const cslScore  = options.cslScore || CSL_THRESHOLDS.MEDIUM;

    this._stats.searchCount++;

    // Run all retrievers in parallel
    const [bm25Res, denseRes, sparseRes] = await Promise.all([
      Promise.resolve(this._bm25.search(queryText, topK)),
      options.embedding
        ? Promise.resolve(this._dense.search(options.embedding, topK))
        : Promise.resolve([]),
      (options.sparse && mode === '3way')
        ? Promise.resolve(this._sparse.search(options.sparse, topK))
        : Promise.resolve([]),
    ]);

    const useSparse = mode === '3way' && sparseRes.length > 0;
    const fused     = this.fuseResults(bm25Res, denseRes, useSparse ? sparseRes : null, { cslScore });

    // Final top-K with rank assignment
    const results = fused
      .slice(0, topK)
      .map((r, idx) => ({ ...r, rank: idx + 1 }));

    const latencyMs = Date.now() - t0;
    this._stats.totalLatencyMs += latencyMs;
    if (latencyMs > SLOW_QUERY_THRESHOLD_MS) {
      this._stats.slowQueries++;
    }

    return results;
  }

  // ─── PUBLIC: INDEX CONFIGURATION ──────────────────────────────────────────

  /**
   * Configure the HNSW index parameters for a given scale.
   * Returns the selected parameter set for informational purposes.
   *
   * @param {string} scale - 'small', 'medium', or 'large'
   * @returns {{ m: number, ef_c: number, ef_s: number }}
   */
  configureIndex(scale) {
    const params = HNSW_PARAMS[scale];
    if (!params) throw new Error(`Unknown scale: ${scale}. Use 'small', 'medium', or 'large'`);
    this._scale = scale;
    this._dense._params = params;
    return params;
  }

  // ─── PUBLIC: STATS ─────────────────────────────────────────────────────────

  /**
   * Get search statistics and current configuration.
   * @returns {object}
   */
  getStats() {
    const avg = this._stats.searchCount > 0
      ? this._stats.totalLatencyMs / this._stats.searchCount
      : 0;

    return {
      scale:            this._scale,
      hnswParams:       this._dense.params,
      docCounts: {
        bm25:   this._bm25.size,
        dense:  this._dense.size,
        sparse: this._sparse.size,
      },
      weights: {
        twoWay:   WEIGHTS_2WAY,
        threeWay: WEIGHTS_3WAY,
      },
      performance: {
        searchCount:        this._stats.searchCount,
        slowQueries:        this._stats.slowQueries,
        avgLatencyMs:       Math.round(avg),
        slowQueryThreshMs:  SLOW_QUERY_THRESHOLD_MS,
      },
      cslGating:      this._useCslGating,
      rerankTopK:     RERANK_TOP_K,
      rrfK:           RRF_K,
    };
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  HybridSearch,
  BM25Index,
  DenseIndex,
  SparseIndex,
  HNSW_PARAMS,
  WEIGHTS_2WAY,
  WEIGHTS_3WAY,
  RRF_K,
  RERANK_TOP_K,
  SLOW_QUERY_THRESHOLD_MS,
  INDEX_SCALE,
};
