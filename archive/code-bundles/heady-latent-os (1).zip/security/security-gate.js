/**
 * @fileoverview SecurityGate — CSL-gated access control with phi-derived trust levels
 *
 * Implements a cryptographically-anchored access control layer using Continuous
 * Superposition Logic (CSL) gates. Every authorization decision is scored via
 * cslPhiGATE, thresholded by trust level, and recorded to an immutable SHA-256
 * hash chain that simulates a Web3 audit ledger.
 *
 * Trust hierarchy (phi-derived thresholds from CSL_THRESHOLDS):
 *   SOVEREIGN  ≥ CRITICAL  ≈ 0.927
 *   PRIVILEGED ≥ HIGH      ≈ 0.882
 *   TRUSTED    ≥ MEDIUM    ≈ 0.809
 *   VERIFIED   ≥ LOW       ≈ 0.691
 *   BASIC      ≥ MINIMUM   ≈ 0.500
 *   UNTRUSTED  < MINIMUM
 *
 * @module security/security-gate
 * @version 1.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib, CSL_THRESHOLDS, DEDUP_THRESHOLD,
  phiFusionWeights, phiBackoff, cslGate, sigmoid,
  PRESSURE_LEVELS, classifyPressure,
  phiPriorityScore, phiAdaptiveInterval, ALERT_THRESHOLDS,
  phiResourceWeights,
} = require('../shared/phi-math');

const {
  cosineSimilarity, RINGS, getAllNodes, findNodeRing, assessCoherence,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, hdcRandomVector, EMBEDDING_DIM, hashVector, moeRoute,
} = require('../shared/csl-engine');

// ─── TRUST LEVEL DEFINITIONS ──────────────────────────────────────────────────

/**
 * Trust level ordinals and their CSL thresholds.
 * Zero magic numbers — all thresholds sourced from CSL_THRESHOLDS.
 */
const TRUST_LEVELS = Object.freeze({
  UNTRUSTED:  { ordinal: 0, threshold: 0 },
  BASIC:      { ordinal: 1, threshold: CSL_THRESHOLDS.MINIMUM },   // ≈ 0.500
  VERIFIED:   { ordinal: 2, threshold: CSL_THRESHOLDS.LOW },       // ≈ 0.691
  TRUSTED:    { ordinal: 3, threshold: CSL_THRESHOLDS.MEDIUM },    // ≈ 0.809
  PRIVILEGED: { ordinal: 4, threshold: CSL_THRESHOLDS.HIGH },      // ≈ 0.882
  SOVEREIGN:  { ordinal: 5, threshold: CSL_THRESHOLDS.CRITICAL },  // ≈ 0.927
});

// ─── SANITIZATION PATTERNS ────────────────────────────────────────────────────

/** SQL injection patterns to reject */
const SQL_INJECTION_PATTERNS = [
  /(\bSELECT\b|\bINSERT\b|\bUPDATE\b|\bDELETE\b|\bDROP\b|\bUNION\b)/i,
  /(-{2}|\/\*|\*\/|;{1})/,
  /(\bOR\b\s+['"\d]|'OR'|"OR")/i,
  /xp_\w+/i,
];

/** Path traversal patterns to reject */
const PATH_TRAVERSAL_PATTERNS = [
  /\.\.(\/|\\)/,
  /%2e%2e(%2f|%5c)/i,
  /\.\.(\/|\\|%2f|%5c)/i,
];

/** XSS patterns to reject */
const XSS_PATTERNS = [
  /<script[\s\S]*?>[\s\S]*?<\/script>/i,
  /javascript\s*:/i,
  /on\w+\s*=/i,
  /<iframe[\s\S]*?>/i,
];

// ─── RATE LIMIT CONSTANTS (all Fibonacci) ────────────────────────────────────

const RATE_WINDOW_MS      = fib(17) * 1000;  // fib(17)=1597 → ~26.6 min window
const RATE_LIMIT_BASIC    = fib(8);           // 21 requests / window for BASIC
const RATE_LIMIT_VERIFIED = fib(10);          // 55 requests / window for VERIFIED
const RATE_LIMIT_TRUSTED  = fib(12);          // 144 requests / window for TRUSTED
const RATE_LIMIT_PRIVILEGED = fib(14);        // 377 requests
const RATE_LIMIT_SOVEREIGN  = fib(16);        // 987 requests

// ─── SECURITY GATE CLASS ──────────────────────────────────────────────────────

/**
 * CSL-gated access control with Web3-style hash-chain audit trail.
 *
 * @extends EventEmitter
 * @fires SecurityGate#access_granted
 * @fires SecurityGate#access_denied
 * @fires SecurityGate#audit_entry
 * @fires SecurityGate#rate_limit_exceeded
 */
class SecurityGate extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {string} [options.gateName='primary'] - Logical gate identifier
   * @param {number} [options.minGateScore=CSL_THRESHOLDS.MINIMUM] - Absolute floor
   */
  constructor(options = {}) {
    super();
    this.gateName = options.gateName || 'primary';
    this.minGateScore = options.minGateScore || CSL_THRESHOLDS.MINIMUM;

    /** SHA-256 hash chain — each entry includes hash of previous */
    this._auditChain = [];
    this._genesisHash = crypto
      .createHash('sha256')
      .update(`genesis:${this.gateName}:${Date.now()}`)
      .digest('hex');

    /** Rate limit state: Map<clientId, { count, windowStart }> */
    this._rateLimits = new Map();

    /** Cached policy embeddings: Map<policyId, Float64Array> */
    this._policyEmbeddings = new Map();

    this._initDefaultPolicies();
  }

  // ─── PRIVATE: INIT ──────────────────────────────────────────────────────────

  /**
   * Seed default policy embeddings using HDC random vectors.
   * @private
   */
  _initDefaultPolicies() {
    for (const [level] of Object.entries(TRUST_LEVELS)) {
      const vec = hdcRandomVector(EMBEDDING_DIM);
      this._policyEmbeddings.set(level, normalize(vec));
    }
  }

  // ─── PRIVATE: HASH CHAIN ────────────────────────────────────────────────────

  /**
   * Compute SHA-256 of a serialisable object.
   * @param {object} data
   * @returns {string} hex digest
   * @private
   */
  _sha256(data) {
    return crypto
      .createHash('sha256')
      .update(JSON.stringify(data))
      .digest('hex');
  }

  /**
   * Append an entry to the immutable audit hash chain.
   * @param {object} entry - Audit record
   * @returns {string} Chained SHA-256 digest
   * @private
   */
  _appendChain(entry) {
    const prev = this._auditChain.length > 0
      ? this._auditChain[this._auditChain.length - 1].hash
      : this._genesisHash;
    const payload = { ...entry, prev };
    const hash = this._sha256(payload);
    this._auditChain.push({ ...payload, hash });
    return hash;
  }

  // ─── PRIVATE: RATE LIMITING ─────────────────────────────────────────────────

  /**
   * Check and update rate limit for a client.
   * @param {string} clientId
   * @param {string} trustLevel
   * @returns {boolean} true if within limit
   * @private
   */
  _checkRateLimit(clientId, trustLevel) {
    const limit = {
      SOVEREIGN:  RATE_LIMIT_SOVEREIGN,
      PRIVILEGED: RATE_LIMIT_PRIVILEGED,
      TRUSTED:    RATE_LIMIT_TRUSTED,
      VERIFIED:   RATE_LIMIT_VERIFIED,
      BASIC:      RATE_LIMIT_BASIC,
      UNTRUSTED:  0,
    }[trustLevel] || 0;

    const now = Date.now();
    const state = this._rateLimits.get(clientId) || { count: 0, windowStart: now };

    if (now - state.windowStart > RATE_WINDOW_MS) {
      state.count = 1;
      state.windowStart = now;
    } else {
      state.count += 1;
    }

    this._rateLimits.set(clientId, state);
    return state.count <= limit;
  }

  // ─── PUBLIC: TRUST LEVEL RESOLUTION ─────────────────────────────────────────

  /**
   * Derive trust level from credentials embedding.
   * Score = cosineSimilarity(credEmbed, policyEmbed) for each level.
   *
   * @param {Float64Array|number[]} credentialEmbedding - Normalized HDC vector
   * @returns {{ level: string, score: number }} Highest matching trust level
   */
  getTrustLevel(credentialEmbedding) {
    const embed = normalize(credentialEmbedding);
    let bestLevel = 'UNTRUSTED';
    let bestScore = 0;

    for (const [level, def] of Object.entries(TRUST_LEVELS)) {
      if (level === 'UNTRUSTED') continue;
      const policyVec = this._policyEmbeddings.get(level);
      const sim = cosineSimilarity(embed, policyVec);
      const gateScore = cslGate(1.0, sim, def.threshold, PSI_CUBE);
      if (gateScore > bestScore) {
        bestScore = gateScore;
        bestLevel = level;
      }
    }

    return { level: bestLevel, score: bestScore };
  }

  // ─── PUBLIC: AUTHORIZATION ───────────────────────────────────────────────────

  /**
   * Authorize a request against a required trust level.
   *
   * CSL gate score = cslGate(1.0, cosineSimilarity(requestEmbed, policyEmbed), threshold, PSI_CUBE)
   * Decision: GRANT if gateScore ≥ requiredThreshold AND rate limit OK.
   *
   * @param {object} request
   * @param {string} request.clientId - Unique client identifier
   * @param {Float64Array|number[]} request.embedding - Request semantic embedding
   * @param {object} [request.metadata] - Arbitrary metadata (sanitized)
   * @param {string} requiredLevel - One of TRUST_LEVELS keys
   * @returns {{ granted: boolean, score: number, hash: string, reason: string }}
   */
  authorize(request, requiredLevel) {
    const { clientId, embedding, metadata = {} } = request;
    const levelDef = TRUST_LEVELS[requiredLevel];

    if (!levelDef) {
      throw new Error(`Unknown trust level: ${requiredLevel}`);
    }

    // Input sanitization on metadata
    const sanitizeResult = this.validateInput(JSON.stringify(metadata));
    if (!sanitizeResult.valid) {
      const auditHash = this._appendChain({
        type: 'SANITIZATION_FAILURE',
        clientId,
        requiredLevel,
        reason: sanitizeResult.reason,
        ts: Date.now(),
      });
      this.emit('access_denied', { clientId, reason: sanitizeResult.reason });
      return { granted: false, score: 0, hash: auditHash, reason: sanitizeResult.reason };
    }

    // Rate limit check
    const { level: clientTrust } = this.getTrustLevel(embedding);
    if (!this._checkRateLimit(clientId, clientTrust)) {
      this.emit('rate_limit_exceeded', { clientId });
      const auditHash = this._appendChain({
        type: 'RATE_LIMIT_EXCEEDED', clientId, ts: Date.now(),
      });
      return { granted: false, score: 0, hash: auditHash, reason: 'RATE_LIMIT' };
    }

    // CSL gate scoring
    const norm = normalize(embedding);
    const policyVec = this._policyEmbeddings.get(requiredLevel);
    const sim = cosineSimilarity(norm, policyVec);
    const gateScore = cslGate(1.0, sim, levelDef.threshold, PSI_CUBE);
    const granted = gateScore >= levelDef.threshold && gateScore >= this.minGateScore;

    const auditEntry = {
      type: granted ? 'ACCESS_GRANTED' : 'ACCESS_DENIED',
      clientId,
      requiredLevel,
      clientTrustLevel: clientTrust,
      gateScore,
      similarity: sim,
      ts: Date.now(),
    };
    const auditHash = this._appendChain(auditEntry);

    this.emit(granted ? 'access_granted' : 'access_denied', {
      clientId, gateScore, requiredLevel,
    });

    return {
      granted,
      score: gateScore,
      hash: auditHash,
      reason: granted ? 'AUTHORIZED' : 'INSUFFICIENT_TRUST',
    };
  }

  // ─── PUBLIC: INPUT VALIDATION ────────────────────────────────────────────────

  /**
   * Validate and sanitize user input against known attack patterns.
   *
   * @param {string} input - Raw user input string
   * @returns {{ valid: boolean, sanitized: string, reason: string|null }}
   */
  validateInput(input) {
    if (typeof input !== 'string') {
      return { valid: false, sanitized: '', reason: 'NON_STRING_INPUT' };
    }

    for (const pattern of SQL_INJECTION_PATTERNS) {
      if (pattern.test(input)) {
        return { valid: false, sanitized: '', reason: 'SQL_INJECTION_DETECTED' };
      }
    }

    for (const pattern of PATH_TRAVERSAL_PATTERNS) {
      if (pattern.test(input)) {
        return { valid: false, sanitized: '', reason: 'PATH_TRAVERSAL_DETECTED' };
      }
    }

    for (const pattern of XSS_PATTERNS) {
      if (pattern.test(input)) {
        return { valid: false, sanitized: '', reason: 'XSS_DETECTED' };
      }
    }

    // Sanitize: strip null bytes and control characters
    const sanitized = input
      .replace(/\0/g, '')
      .replace(/[\x01-\x08\x0b\x0c\x0e-\x1f\x7f]/g, '');

    return { valid: true, sanitized, reason: null };
  }

  // ─── PUBLIC: AUDIT ACCESS ───────────────────────────────────────────────────

  /**
   * Manually record an audit event to the hash chain.
   *
   * @param {object} event - Arbitrary event data to record
   * @returns {{ hash: string, chainLength: number }}
   */
  auditAccess(event) {
    const hash = this._appendChain({
      type: 'MANUAL_AUDIT',
      ...event,
      ts: Date.now(),
    });
    this.emit('audit_entry', { hash, chainLength: this._auditChain.length });
    return { hash, chainLength: this._auditChain.length };
  }

  // ─── PUBLIC: CHAIN INSPECTION ───────────────────────────────────────────────

  /**
   * Verify the integrity of the audit chain by re-computing hashes.
   * @returns {{ valid: boolean, firstBrokenIndex: number|null }}
   */
  verifyChain() {
    for (let i = 0; i < this._auditChain.length; i++) {
      const entry = this._auditChain[i];
      const { hash, ...payload } = entry;
      const expected = this._sha256(payload);
      if (expected !== hash) {
        return { valid: false, firstBrokenIndex: i };
      }
    }
    return { valid: true, firstBrokenIndex: null };
  }

  /**
   * Get the full audit chain.
   * @returns {Array<object>} Immutable copy
   */
  getAuditChain() {
    return [...this._auditChain];
  }

  /**
   * Expose trust level constants for external use.
   * @returns {object}
   */
  static getTrustLevels() {
    return TRUST_LEVELS;
  }
}

// ─── EXPORTS ─────────────────────────────────────────────────────────────────

module.exports = {
  SecurityGate,
  TRUST_LEVELS,
  RATE_WINDOW_MS,
  RATE_LIMIT_BASIC,
  RATE_LIMIT_VERIFIED,
  RATE_LIMIT_TRUSTED,
  RATE_LIMIT_PRIVILEGED,
  RATE_LIMIT_SOVEREIGN,
};
