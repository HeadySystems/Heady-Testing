/**
 * @fileoverview Heady Latent OS — Unified Entry Point
 * 
 * The complete Alive Software Architecture: self-aware, self-improving,
 * Sacred Geometry orchestrated, phi-continuous scaled, liquid dynamic OS.
 * 
 * ZERO magic numbers. Every constant derives from φ = (1+√5)/2.
 * Temperature = 0, seed = 42 (fib(9)+fib(6)) for deterministic execution.
 * 
 * @module heady-latent-os
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 * @author Eric Head — HeadySystems Inc. / HeadyConnection Inc.
 */

'use strict';

// ─── SHARED FOUNDATION ─────────────────────────────────────────────────────────

const PhiMath = require('./shared/phi-math');
const SacredGeometry = require('./shared/sacred-geometry');
const CSLEngine = require('./shared/csl-engine');

// ─── CORE ORCHESTRATION ────────────────────────────────────────────────────────

const { HeadyConductor } = require('./core/heady-conductor');
const { HeadySoul } = require('./core/heady-soul');
const { HeadyVinci } = require('./core/heady-vinci');
const { ContextWindowManager } = require('./core/context-window-manager');
const { TaskDecompositionEngine } = require('./core/task-decomposition-engine');
const { LiquidGateway } = require('./core/liquid-gateway');

// ─── AGENTS ────────────────────────────────────────────────────────────────────

const { BeeFactory } = require('./agents/bee-factory');
const { SwarmCoordinator } = require('./agents/swarm-coordinator');
const { SemanticBackpressure } = require('./agents/semantic-backpressure');

// ─── ROUTING ───────────────────────────────────────────────────────────────────

const { LLMRouter } = require('./routing/llm-router');
const { EmbeddingRouter } = require('./routing/embedding-router');
const { MoECSLRouter } = require('./routing/moe-csl-router');

// ─── MEMORY ────────────────────────────────────────────────────────────────────

const { VectorMemory } = require('./memory/vector-memory');
const { GraphRAG } = require('./memory/graph-rag');
const { HybridSearch } = require('./memory/hybrid-search');

// ─── RESILIENCE ────────────────────────────────────────────────────────────────

const { CircuitBreaker } = require('./resilience/circuit-breaker');
const { SelfHealingLifecycle } = require('./resilience/self-healing-lifecycle');
const { PhiBackoff } = require('./resilience/phi-backoff');

// ─── EDGE ──────────────────────────────────────────────────────────────────────

const { DurableAgentState } = require('./edge/durable-agent-state');
const { EdgeOriginRouter } = require('./edge/edge-origin-router');

// ─── MCP ───────────────────────────────────────────────────────────────────────

const { MCPGateway } = require('./mcp/mcp-gateway');
const { AuditLogger } = require('./mcp/audit-logger');
const { RateLimiter } = require('./mcp/rate-limiter');

// ─── SECURITY ──────────────────────────────────────────────────────────────────

const { SecurityGate } = require('./security/security-gate');
const { ZeroTrustSandbox } = require('./security/zero-trust-sandbox');

// ─── BATTLE ARENA ──────────────────────────────────────────────────────────────

const { ArenaEngine } = require('./battle/arena-engine');

// ─── GENERATIVE UI ─────────────────────────────────────────────────────────────

const { GenerativeUIEngine } = require('./ui/generative-ui-engine');

// ─── PATENT & IP ───────────────────────────────────────────────────────────────

const { PatentRegistry } = require('./patent/patent-registry');

// ─── DETERMINISTIC EXECUTION ───────────────────────────────────────────────────

const { DeterministicPromptExecutor } = require('./deterministic/prompt-executor');
const { MonteCarlo } = require('./deterministic/monte-carlo');

// ─── LATENT OS ORCHESTRATOR ────────────────────────────────────────────────────

/**
 * HeadyLatentOS — The living, self-aware operating system.
 * 
 * Initializes and wires together all subsystems following Sacred Geometry
 * topology and phi-continuous scaling principles.
 */
class HeadyLatentOS {
  constructor(config = {}) {
    /** @type {string} */
    this.version = '3.0.0';

    /** @type {number} Deterministic seed: fib(9) + fib(6) = 34 + 8 = 42 */
    this.seed = PhiMath.fib(9) + PhiMath.fib(6); // = 42

    /** @type {number} Temperature: always 0 for deterministic execution */
    this.temperature = 0;

    // ── Foundation ──────────────────────────────────────────────────────
    this.phi = PhiMath;
    this.geometry = SacredGeometry;
    this.csl = CSLEngine;

    // ── Core ───────────────────────────────────────────────────────────
    this.soul = new HeadySoul(config.soul);
    this.conductor = new HeadyConductor(config.conductor);
    this.vinci = new HeadyVinci(config.vinci);
    this.contextManager = new ContextWindowManager(config.context);
    this.taskEngine = new TaskDecompositionEngine(config.taskEngine);
    this.gateway = new LiquidGateway(config.gateway);

    // ── Agents ─────────────────────────────────────────────────────────
    this.beeFactory = new BeeFactory(config.bees);
    this.swarmCoordinator = new SwarmCoordinator(config.swarms);
    this.backpressure = new SemanticBackpressure(config.backpressure);

    // ── Routing ────────────────────────────────────────────────────────
    this.llmRouter = new LLMRouter(config.llm);
    this.embeddingRouter = new EmbeddingRouter(config.embedding);
    this.moeRouter = new MoECSLRouter(config.moe);

    // ── Memory ─────────────────────────────────────────────────────────
    this.vectorMemory = new VectorMemory(config.memory);
    this.graphRAG = new GraphRAG(config.graphRAG);
    this.hybridSearch = new HybridSearch(config.search);

    // ── Resilience ─────────────────────────────────────────────────────
    this.circuitBreaker = new CircuitBreaker(config.circuitBreaker);
    this.selfHealing = new SelfHealingLifecycle(config.healing);
    this.backoff = new PhiBackoff(config.backoff);

    // ── Edge ───────────────────────────────────────────────────────────
    this.durableState = new DurableAgentState(config.durable);
    this.edgeRouter = new EdgeOriginRouter(config.edge);

    // ── MCP ────────────────────────────────────────────────────────────
    this.mcpGateway = new MCPGateway(config.mcp);
    this.auditLogger = new AuditLogger(config.audit);
    this.rateLimiter = new RateLimiter(config.rateLimit);

    // ── Security ───────────────────────────────────────────────────────
    this.securityGate = new SecurityGate(config.security);
    this.sandbox = new ZeroTrustSandbox(config.sandbox);

    // ── Specialized ────────────────────────────────────────────────────
    this.arena = new ArenaEngine(config.arena);
    this.generativeUI = new GenerativeUIEngine(config.ui);
    this.patentRegistry = new PatentRegistry(config.patents);
    this.promptExecutor = new DeterministicPromptExecutor(config.executor);
    this.monteCarlo = new MonteCarlo(config.monteCarlo);

    // ── Wire event connections ─────────────────────────────────────────
    this._wireEvents();
  }

  /**
   * Wire inter-component event connections following Sacred Geometry routing.
   * @private
   */
  _wireEvents() {
    // Soul monitors all drift events
    if (this.conductor.on) {
      this.conductor.on('taskRouted', (task) => {
        this.auditLogger.log({
          tool: 'conductor',
          user: task.user || 'system',
          input: task,
          output: { routed: true },
        });
      });
    }

    // Self-healing listens for circuit breaker opens
    if (this.circuitBreaker.on) {
      this.circuitBreaker.on('stateChange', ({ from, to }) => {
        if (to === 'OPEN') {
          this.selfHealing.transition('circuit-breaker', 'suspect', `Circuit breaker opened from ${from}`);
        }
      });
    }

    // Backpressure alerts soul on critical pressure
    if (this.backpressure.on) {
      this.backpressure.on('pressureChange', ({ level }) => {
        if (level === 'CRITICAL') {
          this.soul.emit('alert', { type: 'backpressure', level: 'CRITICAL' });
        }
      });
    }
  }

  /**
   * Get comprehensive system health report.
   * @returns {object} Health report with phi-scored metrics
   */
  getSystemHealth() {
    const pools = this.conductor.getPoolStatus ? this.conductor.getPoolStatus() : {};
    const memStats = this.vectorMemory.getStats ? this.vectorMemory.getStats() : {};
    const auditStats = this.auditLogger.getStats ? this.auditLogger.getStats() : {};

    return {
      version: this.version,
      seed: this.seed,
      temperature: this.temperature,
      phi: PhiMath.PHI,
      timestamp: new Date().toISOString(),
      subsystems: {
        core: { conductor: 'active', soul: 'active', vinci: 'active' },
        agents: { bees: 'active', swarms: 'active', backpressure: 'active' },
        routing: { llm: 'active', embedding: 'active', moe: 'active' },
        memory: { vector: 'active', graphRAG: 'active', hybridSearch: 'active' },
        resilience: { circuitBreaker: 'active', selfHealing: 'active' },
        edge: { durableState: 'active', edgeRouter: 'active' },
        mcp: { gateway: 'active', auditLogger: 'active', rateLimiter: 'active' },
        security: { gate: 'active', sandbox: 'active' },
        specialized: { arena: 'active', ui: 'active', patent: 'active', executor: 'active', monteCarlo: 'active' },
      },
      pools,
      memory: memStats,
      audit: auditStats,
    };
  }

  /**
   * Execute a task through the full HCFullPipeline.
   * @param {object} task - Task to execute
   * @returns {Promise<object>} Pipeline result
   */
  async execute(task) {
    // 1. Security gate
    const authorized = this.securityGate.authorize
      ? this.securityGate.authorize(task, 'BASIC')
      : { authorized: true };
    if (!authorized.authorized) {
      throw new Error(`Security gate denied: ${authorized.reason}`);
    }

    // 2. Rate limit check
    const limited = this.rateLimiter.check
      ? this.rateLimiter.check(task)
      : { allowed: true };
    if (!limited.allowed) {
      throw new Error('Rate limit exceeded');
    }

    // 3. Backpressure check
    const accepted = this.backpressure.shouldAccept
      ? this.backpressure.shouldAccept(task)
      : { accepted: true };
    if (!accepted.accepted) {
      throw new Error(`Backpressure rejected: ${accepted.reason}`);
    }

    // 4. Route through conductor
    const routed = this.conductor.classify
      ? this.conductor.classify(task)
      : { domain: 'general', pool: 'WARM' };

    // 5. Decompose if complex
    const complexity = this.vinci.estimateComplexity
      ? this.vinci.estimateComplexity(task)
      : { score: PhiMath.PSI_SQ };
    
    if (complexity.score > PhiMath.PSI) {
      // Complex: decompose into subtasks
      const subtasks = this.taskEngine.decompose
        ? this.taskEngine.decompose(task)
        : [task];
      return { pipeline: 'decomposed', subtasks, routed, complexity };
    }

    // 6. Direct execution
    return { pipeline: 'direct', routed, complexity, timestamp: new Date().toISOString() };
  }

  /**
   * Graceful shutdown with LIFO cleanup.
   */
  async shutdown() {
    const components = [
      'arena', 'generativeUI', 'patentRegistry', 'promptExecutor', 'monteCarlo',
      'sandbox', 'securityGate',
      'rateLimiter', 'auditLogger', 'mcpGateway',
      'edgeRouter', 'durableState',
      'backoff', 'selfHealing', 'circuitBreaker',
      'hybridSearch', 'graphRAG', 'vectorMemory',
      'moeRouter', 'embeddingRouter', 'llmRouter',
      'backpressure', 'swarmCoordinator', 'beeFactory',
      'gateway', 'taskEngine', 'contextManager', 'vinci', 'conductor', 'soul',
    ];

    for (const name of components) {
      const component = this[name];
      if (component && typeof component.shutdown === 'function') {
        await component.shutdown();
      }
    }
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  // Entry point
  HeadyLatentOS,

  // Foundation
  PhiMath, SacredGeometry, CSLEngine,

  // Core
  HeadyConductor, HeadySoul, HeadyVinci,
  ContextWindowManager, TaskDecompositionEngine, LiquidGateway,

  // Agents
  BeeFactory, SwarmCoordinator, SemanticBackpressure,

  // Routing
  LLMRouter, EmbeddingRouter, MoECSLRouter,

  // Memory
  VectorMemory, GraphRAG, HybridSearch,

  // Resilience
  CircuitBreaker, SelfHealingLifecycle, PhiBackoff,

  // Edge
  DurableAgentState, EdgeOriginRouter,

  // MCP
  MCPGateway, AuditLogger, RateLimiter,

  // Security
  SecurityGate, ZeroTrustSandbox,

  // Specialized
  ArenaEngine, GenerativeUIEngine, PatentRegistry,
  DeterministicPromptExecutor, MonteCarlo,
};
