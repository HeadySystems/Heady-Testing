/**
 * @fileoverview PatentRegistry — CSL-powered prior art detection and novelty scoring
 *
 * Maintains a simulated registry of provisional patents (capacity fib(11)=89),
 * detects prior art via cosine similarity with a threshold of CSL_THRESHOLDS.HIGH
 * (≈ 0.882), scores novelty as 1 − maxSimilarity, and generates SHA-256-stamped
 * filing proof hashes. Claim differentiation uses cslNOT to identify components
 * orthogonal to existing prior art.
 *
 * Patent record schema:
 *   { id, title, description, inventors[], claims[], filingDate, status,
 *     embedding(384D), priorArt[], noveltyScore, filingHash }
 *
 * @module patent/patent-registry
 * @version 1.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib, CSL_THRESHOLDS, DEDUP_THRESHOLD,
  phiFusionWeights, phiBackoff, cslGate, sigmoid,
  PRESSURE_LEVELS, classifyPressure,
  phiPriorityScore, phiAdaptiveInterval, ALERT_THRESHOLDS,
  phiResourceWeights,
} = require('../shared/phi-math');

const {
  cosineSimilarity, RINGS, getAllNodes, findNodeRing, assessCoherence,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, hdcRandomVector, EMBEDDING_DIM, hashVector, moeRoute,
} = require('../shared/csl-engine');

// ─── REGISTRY CONSTANTS ───────────────────────────────────────────────────────

/** Maximum registry capacity: fib(11)=89 patents */
const REGISTRY_CAPACITY = fib(11);

/** Similarity threshold for prior art detection: CSL_THRESHOLDS.HIGH ≈ 0.882 */
const PRIOR_ART_THRESHOLD = CSL_THRESHOLDS.HIGH;

/** Minimum novelty score to accept a new patent: 1 − CSL_THRESHOLDS.HIGH */
const MIN_NOVELTY_SCORE = 1 - CSL_THRESHOLDS.HIGH;   // ≈ 0.118

/**
 * Patent embedding dimension: must match EMBEDDING_DIM from csl-engine (384).
 * Used with hdcRandomVector — we import EMBEDDING_DIM and alias it here.
 * Fibonacci note: 384 = fib(14) + fib(6) + fib(2) + fib(1) = 377 + 8 - 1... closest
 * canonical: EMBEDDING_DIM is the authoritative constant; we alias for clarity.
 */
const PATENT_EMBEDDING_DIM = EMBEDDING_DIM;   // 384 — matches csl-engine HDC dimension

/** Status codes for patent lifecycle */
const PATENT_STATUS = Object.freeze({
  PROVISIONAL:  'PROVISIONAL',
  FILED:        'FILED',
  PENDING:      'PENDING',
  GRANTED:      'GRANTED',
  REJECTED:     'REJECTED',
  ABANDONED:    'ABANDONED',
});

/** Minimum claim length (characters): fib(8)*fib(5) = 21*5 = 105 */
const MIN_CLAIM_LENGTH = fib(8) * fib(5);   // 105 chars

// ─── PATENT REGISTRY CLASS ────────────────────────────────────────────────────

/**
 * Simulated patent registry with CSL-based prior art detection.
 *
 * @extends EventEmitter
 * @fires PatentRegistry#patent_registered
 * @fires PatentRegistry#prior_art_detected
 * @fires PatentRegistry#novelty_scored
 * @fires PatentRegistry#capacity_warning
 */
class PatentRegistry extends EventEmitter {
  constructor() {
    super();

    /** Active patent records: Map<patentId, PatentRecord> */
    this._registry = new Map();

    /** Index of claim embeddings for fast similarity search */
    this._claimEmbeddings = [];   // [{ patentId, claimIdx, embedding }]

    this._initSeedPatents();
  }

  // ─── PRIVATE: SEED DATA ──────────────────────────────────────────────────────

  /**
   * Populate registry with fib(6)=8 seed patents to simulate existing IP landscape.
   * @private
   */
  _initSeedPatents() {
    const seedCount = fib(6);   // 8 seed patents
    for (let i = 0; i < seedCount; i++) {
      const id = `SEED-${String(i + 1).padStart(4, '0')}`;
      const embedding = normalize(hdcRandomVector(PATENT_EMBEDDING_DIM));
      const record = {
        id,
        title:       `Seed Patent ${i + 1}: Phi-Derived Optimization Method`,
        description: `System and method for ${id} using golden ratio principles.`,
        inventors:   [`Inventor${fib(i + 1)}`],
        claims:      [`Claim 1 of seed patent ${i + 1}: A system comprising phi-based components.`],
        filingDate:  new Date(Date.now() - fib(i + 8) * 24 * 60 * 60 * 1000).toISOString(),
        status:      PATENT_STATUS.GRANTED,
        embedding,
        priorArt:    [],
        noveltyScore: PSI,    // ψ ≈ 0.618 — moderate novelty for seeds
        filingHash:  this._sha256({ id, ts: Date.now() - i }),
      };
      this._registry.set(id, record);
      this._indexClaimEmbeddings(id, embedding, 0);
    }
  }

  // ─── PRIVATE: UTILITIES ──────────────────────────────────────────────────────

  /**
   * Compute SHA-256 of serialisable data.
   * @param {*} data
   * @returns {string} hex digest
   * @private
   */
  _sha256(data) {
    return crypto.createHash('sha256').update(JSON.stringify(data)).digest('hex');
  }

  /**
   * Register a claim embedding in the search index.
   * @param {string} patentId
   * @param {Float64Array|number[]} embedding
   * @param {number} claimIdx
   * @private
   */
  _indexClaimEmbeddings(patentId, embedding, claimIdx) {
    this._claimEmbeddings.push({ patentId, claimIdx, embedding: normalize(embedding) });
  }

  /**
   * Generate a patent ID: P + Fibonacci-stamped serial.
   * @returns {string}
   * @private
   */
  _nextId() {
    const serial = this._registry.size + 1;
    return `P-${String(serial).padStart(fib(4), '0')}`;  // fib(4)=3 digit padding
  }

  // ─── PUBLIC: PRIOR ART SEARCH ────────────────────────────────────────────────

  /**
   * Search the registry for prior art similar to a new claim.
   *
   * A match is any patent with cosine similarity ≥ PRIOR_ART_THRESHOLD (≈ 0.882).
   *
   * @param {Float64Array|number[]} claimEmbedding - Normalized embedding of new claim
   * @returns {Array<{ patentId: string, similarity: number, title: string }>}
   *   Sorted descending by similarity.
   */
  searchPriorArt(claimEmbedding) {
    const normClaim = normalize(claimEmbedding);
    const hits = [];

    for (const { patentId, embedding } of this._claimEmbeddings) {
      const sim = cosineSimilarity(normClaim, embedding);
      if (sim >= PRIOR_ART_THRESHOLD) {
        const patent = this._registry.get(patentId);
        hits.push({
          patentId,
          similarity: sim,
          title: patent ? patent.title : 'Unknown',
        });
        this.emit('prior_art_detected', { patentId, similarity: sim });
      }
    }

    return hits.sort((a, b) => b.similarity - a.similarity);
  }

  // ─── PUBLIC: NOVELTY SCORING ─────────────────────────────────────────────────

  /**
   * Score the novelty of a new claim.
   *
   * noveltyScore = 1 − maxSimilarity(claim, existingPatents)
   * Range [0, 1]: 1 = entirely novel, 0 = exact duplicate.
   *
   * @param {Float64Array|number[]} claimEmbedding
   * @returns {{ noveltyScore: number, maxSimilarity: number, closestPatentId: string|null }}
   */
  scoreNovelty(claimEmbedding) {
    const normClaim = normalize(claimEmbedding);
    let maxSim = 0;
    let closestPatentId = null;

    for (const { patentId, embedding } of this._claimEmbeddings) {
      const sim = cosineSimilarity(normClaim, embedding);
      if (sim > maxSim) {
        maxSim = sim;
        closestPatentId = patentId;
      }
    }

    const noveltyScore = 1 - maxSim;
    this.emit('novelty_scored', { noveltyScore, maxSimilarity: maxSim });
    return { noveltyScore, maxSimilarity: maxSim, closestPatentId };
  }

  // ─── PUBLIC: CLAIM DIFFERENTIATION ──────────────────────────────────────────

  /**
   * Compute the portion of a new claim orthogonal to all prior art.
   *
   * Uses cslNOT to invert each prior art similarity, then cslCONSENSUS across
   * all NOT-scores to produce a single "differentiation confidence".
   *
   * @param {Float64Array|number[]} claimEmbedding  - New claim embedding
   * @param {Array<object>} priorArt                - Results from searchPriorArt()
   * @returns {{ differentiationScore: number, uniquenessComponents: number[] }}
   */
  differentiate(claimEmbedding, priorArt) {
    const normClaim = normalize(claimEmbedding);

    if (priorArt.length === 0) {
      return { differentiationScore: 1.0, uniquenessComponents: [1.0] };
    }

    // cslNOT(a, b) = orthogonal component of a w.r.t. b (vector-space NOT)
    // Scalar uniqueness: 1 - cosineSimilarity is the conceptual cslNOT magnitude
    const uniquenessComponents = priorArt.map(pa => {
      const paRecord = this._registry.get(pa.patentId);
      const paEmbed = paRecord ? paRecord.embedding : normalize(hdcRandomVector(PATENT_EMBEDDING_DIM));
      // Scalar uniqueness: 1 - cosine similarity (conceptual NOT)
      const sim = cosineSimilarity(normClaim, paEmbed);
      return 1 - sim;  // Orthogonality score: how different is claim from this prior art
    });

    // Phi-fusion weighted differentiation consensus
    const weights = phiFusionWeights(uniquenessComponents.length);
    const differentiationScore = uniquenessComponents.reduce((sum, u, i) => sum + weights[i] * u, 0);

    return { differentiationScore, uniquenessComponents };
  }

  // ─── PUBLIC: REGISTER ────────────────────────────────────────────────────────

  /**
   * Register a new patent application.
   *
   * Workflow:
   *  1. Validate required fields
   *  2. Generate/normalize claim embedding
   *  3. Search prior art
   *  4. Score novelty
   *  5. If novelty < MIN_NOVELTY_SCORE → REJECTED
   *  6. Assign ID, timestamp hash, add to registry
   *
   * @param {object} patent
   * @param {string} patent.title
   * @param {string} patent.description
   * @param {string[]} patent.inventors
   * @param {string[]} patent.claims
   * @param {Float64Array|number[]} [patent.embedding] - Pre-computed; generated if absent
   * @returns {object} Registered patent record (or rejection object)
   */
  register(patent) {
    if (!patent.title || !patent.description || !patent.claims || patent.claims.length === 0) {
      throw new Error('Patent requires title, description, and at least one claim');
    }

    // Capacity check
    if (this._registry.size >= REGISTRY_CAPACITY) {
      this.emit('capacity_warning', { size: this._registry.size, max: REGISTRY_CAPACITY });
      throw new Error(`Registry at capacity: ${REGISTRY_CAPACITY} (fib(11))`);
    }

    const embedding = patent.embedding
      ? normalize(patent.embedding)
      : normalize(hdcRandomVector(PATENT_EMBEDDING_DIM));

    const priorArt  = this.searchPriorArt(embedding);
    const { noveltyScore, maxSimilarity, closestPatentId } = this.scoreNovelty(embedding);

    if (noveltyScore < MIN_NOVELTY_SCORE) {
      return {
        registered: false,
        reason: 'INSUFFICIENT_NOVELTY',
        noveltyScore,
        maxSimilarity,
        closestPatentId,
      };
    }

    const id = this._nextId();
    const filingDate = new Date().toISOString();
    const filingHash = this._sha256({ id, title: patent.title, filingDate, claims: patent.claims });

    const record = {
      id,
      title:        patent.title,
      description:  patent.description,
      inventors:    patent.inventors || [],
      claims:       patent.claims,
      filingDate,
      status:       PATENT_STATUS.PROVISIONAL,
      embedding,
      priorArt:     priorArt.map(p => p.patentId),
      noveltyScore,
      filingHash,
    };

    this._registry.set(id, record);
    this._indexClaimEmbeddings(id, embedding, 0);

    this.emit('patent_registered', { id, noveltyScore, priorArtCount: priorArt.length });
    return { registered: true, ...record };
  }

  // ─── PUBLIC: AUTO-DOCUMENTATION ──────────────────────────────────────────────

  /**
   * Generate structured patent documentation for a registered patent.
   *
   * @param {string} patentId
   * @returns {object} Structured documentation object
   */
  generateDocumentation(patentId) {
    const patent = this._registry.get(patentId);
    if (!patent) throw new Error(`Patent not found: ${patentId}`);

    const priorArtRecords = patent.priorArt
      .map(id => this._registry.get(id))
      .filter(Boolean)
      .map(p => ({ id: p.id, title: p.title, filingDate: p.filingDate }));

    return {
      documentType: 'PROVISIONAL_PATENT_APPLICATION',
      patentId:     patent.id,
      filingHash:   patent.filingHash,
      filingDate:   patent.filingDate,
      status:       patent.status,
      title:        patent.title,
      inventors:    patent.inventors,
      abstract:     patent.description,
      claims:       patent.claims.map((claim, idx) => ({
        claimNumber: idx + 1,
        text:        claim,
        type:        idx === 0 ? 'INDEPENDENT' : 'DEPENDENT',
      })),
      priorArt: priorArtRecords,
      noveltyScore: patent.noveltyScore,
      generatedAt:  new Date().toISOString(),
      integrityHash: this._sha256(patent),
    };
  }

  // ─── PUBLIC: QUERY ───────────────────────────────────────────────────────────

  /**
   * Get a patent record by ID.
   * @param {string} patentId
   * @returns {object|null}
   */
  getPatent(patentId) {
    return this._registry.get(patentId) || null;
  }

  /**
   * List all patents with optional status filter.
   * @param {string} [status] - Filter by PATENT_STATUS value
   * @returns {Array<object>}
   */
  listPatents(status) {
    const records = Array.from(this._registry.values());
    return status ? records.filter(p => p.status === status) : records;
  }

  /**
   * Registry statistics.
   * @returns {{ total: number, capacity: number, utilization: number, byStatus: object }}
   */
  getStats() {
    const byStatus = {};
    for (const p of this._registry.values()) {
      byStatus[p.status] = (byStatus[p.status] || 0) + 1;
    }
    return {
      total:       this._registry.size,
      capacity:    REGISTRY_CAPACITY,
      utilization: this._registry.size / REGISTRY_CAPACITY,
      byStatus,
    };
  }
}

// ─── EXPORTS ─────────────────────────────────────────────────────────────────

module.exports = {
  PatentRegistry,
  PATENT_STATUS,
  REGISTRY_CAPACITY,
  PRIOR_ART_THRESHOLD,
  MIN_NOVELTY_SCORE,
  PATENT_EMBEDDING_DIM,
  MIN_CLAIM_LENGTH,
};
