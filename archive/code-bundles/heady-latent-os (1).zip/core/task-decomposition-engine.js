/**
 * @fileoverview TaskDecompositionEngine — DAG-Based Task Decomposition
 *
 * Breaks complex tasks into typed subtasks, assigns each to the best swarm
 * capability via CSL cosine scoring, constructs a DAG, applies Kahn's
 * topological sort, and executes concurrently up to fib(6)=8 parallel workers.
 *
 * Subtask types: research, coding, data, reasoning, synthesis, validation,
 *                retrieval, integration, planning, communication
 * Swarm capabilities: 17 agents across all rings.
 * Minimum assignment threshold: CSL_THRESHOLDS.LOW ≈ 0.691.
 * maxConcurrent = fib(6) = 8, maxSubtasks = fib(10) = 55.
 *
 * All constants derive from φ (golden ratio) or Fibonacci sequence.
 * Temperature = 0, seed = 42 for deterministic execution.
 *
 * @module core/task-decomposition-engine
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  phiFusionWeights,
  phiBackoff,
  phiResourceWeights,
  phiMultiSplit,
  phiTokenBudgets,
  cslGate,
  cslBlend,
  sigmoid,
  adaptiveTemperature,
  POOL_ALLOCATION,
  PRESSURE_LEVELS,
  EVICTION_WEIGHTS,
  classifyPressure,
  phiPriorityScore,
  COHERENCE_DRIFT_THRESHOLD,
  phiAdaptiveInterval,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

const {
  RINGS,
  cosineSimilarity,
  geometricRoute,
  measureCoherence,
  assessCoherence,
  getAllNodes,
  findNodeRing,
} = require('../shared/sacred-geometry');

const {
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslCONSENSUS,
  cslPhiGATE,
  normalize,
  moeRoute,
  hdcRandomVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── DETERMINISTIC SEED ────────────────────────────────────────────────────────

/** Deterministic seed = fib(9) = 34 */
const SEED = fib(9);

/** Temperature sentinel = 0 */
const TEMPERATURE_ZERO = 0;

// ─── SUBTASK TYPE DEFINITIONS ─────────────────────────────────────────────────

/**
 * 10 subtask types covering the full cognitive range.
 * Ordered by typical execution sequence (but DAG allows any order).
 */
const SUBTASK_TYPES = Object.freeze([
  'research',       // Information gathering, web lookups
  'coding',         // Code generation, debugging, refactoring
  'data',           // Data processing, transformations
  'reasoning',      // Logical inference, analysis
  'synthesis',      // Combining results, integration
  'validation',     // QA, testing, verification
  'retrieval',      // Memory/document retrieval
  'integration',    // API calls, system integration
  'planning',       // Strategic planning, roadmapping
  'communication',  // Summarization, explanation, output formatting
]);

// ─── SWARM CAPABILITIES (17) ──────────────────────────────────────────────────

/**
 * 17 swarm capability descriptors — one per unique swarm agent.
 * Derived from getAllNodes() at module load time.
 * Each capability has a deterministic 384D embedding.
 */
const SWARM_CAPABILITIES = Object.freeze(getAllNodes().slice(0, fib(8)));  // First 21 → capped at 17 later

// Verify exactly fib(8)=21 nodes exist; in practice RINGS define fib(8)=21:
// Central(1) + Inner(3) + Middle(6) + Outer(8) + Governance(6) = 24 total
// We use all 24 for broader coverage, capped at MAX_SUBTASKS safety check
const ALL_SWARM_CAPABILITIES = Object.freeze(getAllNodes());  // All 24 nodes

/**
 * Pre-computed capability embeddings: Map<capabilityName, number[]>
 * Built once at module load for O(1) lookup during scoring.
 */
const CAPABILITY_EMBEDDINGS = Object.freeze(
  (() => {
    const map = new Map();
    for (const cap of ALL_SWARM_CAPABILITIES) {
      map.set(cap, buildCapabilityEmbedding(cap));
    }
    return map;
  })()
);

/**
 * Build deterministic 384D embedding for a swarm capability.
 * @param {string} capName
 * @returns {number[]}
 */
function buildCapabilityEmbedding(capName) {
  const hash = crypto.createHash('sha256')
    .update(`${SEED}:capability:${capName}`)
    .digest();
  const v = new Array(EMBEDDING_DIM);
  for (let i = 0; i < EMBEDDING_DIM; i++) {
    v[i] = ((hash[i % hash.length] / fib(7)) - PSI) * PHI;
  }
  return normalize(v);
}

// ─── EXECUTION CONSTANTS ──────────────────────────────────────────────────────

/** Maximum concurrent subtasks = fib(6) = 8 */
const MAX_CONCURRENT = fib(6);   // 8

/** Maximum subtasks per decomposition = fib(10) = 55 */
const MAX_SUBTASKS = fib(10);    // 55

/** Minimum CSL score for assignment = CSL_THRESHOLDS.LOW ≈ 0.691 */
const ASSIGNMENT_THRESHOLD = CSL_THRESHOLDS.LOW;   // ≈ 0.691

// ─── TaskDecompositionEngine CLASS ────────────────────────────────────────────

/**
 * @class TaskDecompositionEngine
 *
 * Decomposes complex tasks into typed subtasks, builds a DAG, sorts
 * topologically using Kahn's algorithm, and executes in parallel waves.
 *
 * @example
 * const tde = new TaskDecompositionEngine();
 * const subtasks = tde.decompose({ description: 'Build a REST API' });
 * const dag = tde.buildDAG(subtasks);
 * const sorted = tde.topoSort(dag);
 * const results = await tde.execute(sorted);
 */
class TaskDecompositionEngine {
  /**
   * @param {object} [options]
   * @param {number} [options.seed=34]         - Deterministic seed
   * @param {number} [options.temperature=0]   - Execution temperature
   * @param {number} [options.maxConcurrent=8] - Max parallel workers (default fib(6))
   * @param {number} [options.maxSubtasks=55]  - Max subtasks per decomposition (fib(10))
   */
  constructor(options = {}) {
    this._seed          = options.seed          ?? SEED;
    this._temperature   = options.temperature   ?? TEMPERATURE_ZERO;
    this._maxConcurrent = options.maxConcurrent ?? MAX_CONCURRENT;
    this._maxSubtasks   = options.maxSubtasks   ?? MAX_SUBTASKS;

    /** Decomposition counter for deterministic IDs */
    this._counter = 0;

    /** Execution result cache: Map<subtaskId, result> */
    this._resultCache = new Map();
  }

  // ─── DECOMPOSE ────────────────────────────────────────────────────────────────

  /**
   * Decompose a complex task into typed, dependency-annotated subtasks.
   *
   * Strategy:
   * 1. Estimate complexity to determine subtask count.
   * 2. For each subtask type relevant to the task, generate a subtask.
   * 3. Assign swarm capabilities via CSL scoring.
   * 4. Set dependency chains based on task flow.
   *
   * @param {object} complexTask
   * @param {string} complexTask.description  - Human-readable task description
   * @param {number[]} [complexTask.embedding] - Pre-computed 384D embedding
   * @param {string[]} [complexTask.types]    - Forced subtask types (override auto-select)
   * @param {number} [complexTask.maxSubtasks] - Override maxSubtasks for this task
   * @returns {{
   *   taskId: string,
   *   subtasks: Array<object>,
   *   swarmAssignments: Map<string, {capability: string, score: number}[]>
   * }}
   */
  decompose(complexTask) {
    const taskId    = this._mintTaskId(complexTask);
    const embedding = complexTask.embedding || this._embed(complexTask.description || '');
    const maxSubs   = Math.min(complexTask.maxSubtasks || this._maxSubtasks, MAX_SUBTASKS);

    // Determine which subtask types are relevant via CSL scoring
    const typeEmbeddings = SUBTASK_TYPES.map(t => this._embed(`subtask:${t}:${complexTask.description || ''}`));
    const typeScores     = typeEmbeddings.map((te, i) => ({
      type:  SUBTASK_TYPES[i],
      score: cslPhiGATE(cosineSimilarity(embedding, te), cosineSimilarity(embedding, te), 1),
    }));

    // Sort by score and take top N types (N = phi-split of maxSubs into type groups)
    typeScores.sort((a, b) => b.score - a.score);
    const topTypes = typeScores.slice(0, Math.min(SUBTASK_TYPES.length, fib(5)));  // Top 5

    // Generate subtasks — distribute maxSubs across top types
    const typeAlloc   = phiMultiSplit(Math.min(maxSubs, fib(8)), topTypes.length);  // fib(8)=21 baseline
    const subtasks    = [];
    let subtaskIdx    = 0;

    for (let t = 0; t < topTypes.length; t++) {
      const { type } = topTypes[t];
      const count    = typeAlloc[t] || 1;

      for (let c = 0; c < count; c++) {
        const subtaskId   = this._mintSubtaskId(taskId, subtaskIdx);
        const description = `[${type}] ${complexTask.description || 'task'} — step ${subtaskIdx + 1}`;
        const subEmbedding = this._embed(description);

        // Score against all swarm capabilities
        const capabilityScores = this.scoreSubtask(
          { description, embedding: subEmbedding },
          ALL_SWARM_CAPABILITIES
        );

        subtasks.push({
          id:                subtaskId,
          index:             subtaskIdx,
          type,
          description,
          embedding:         subEmbedding,
          capabilityScores,
          assignedTo:        capabilityScores[0]?.capability || null,   // Best capability
          dependsOn:         [],   // Populated in buildDAG
          status:            'pending',
          priority:          topTypes[t].score,
          tokenBudget:       Math.floor((complexTask.tokenBudget || fib(13) * 1000) / maxSubs),
        });

        subtaskIdx++;
        if (subtaskIdx >= maxSubs) break;
      }
      if (subtaskIdx >= maxSubs) break;
    }

    // Build assignments map
    const swarmAssignments = new Map(
      subtasks.map(s => [s.id, s.capabilityScores.slice(0, fib(3))])  // Top fib(3)=2 per subtask
    );

    return { taskId, subtasks, swarmAssignments };
  }

  // ─── BUILD DAG ────────────────────────────────────────────────────────────────

  /**
   * Build a Directed Acyclic Graph (DAG) from subtask dependency declarations.
   *
   * Dependency heuristics (when not explicitly provided):
   * - research → precedes all other types
   * - planning → follows research, precedes coding/data/reasoning
   * - validation → follows coding, data, and synthesis
   * - communication → follows synthesis and validation (always last)
   * - retrieval → precedes synthesis
   *
   * @param {Array<object>} subtasks - Subtasks from decompose()
   * @returns {{
   *   nodes: Map<string, object>,
   *   edges: Map<string, string[]>,
   *   inDegree: Map<string, number>
   * }}
   */
  buildDAG(subtasks) {
    // Sort by type dependency order for auto-wiring
    const TYPE_ORDER = {
      research:      0,
      retrieval:     1,
      planning:      2,
      data:          3,
      coding:        3,
      reasoning:     4,
      integration:   5,
      synthesis:     fib(6), // 8 — synthesis priority
      validation:    fib(7), // 13 — validation priority
      communication: 8,
    };

    const sorted = subtasks.slice().sort(
      (a, b) => (TYPE_ORDER[a.type] ?? fib(4)) - (TYPE_ORDER[b.type] ?? fib(4))
    );

    const nodes    = new Map(sorted.map(s => [s.id, s]));
    const edges    = new Map(sorted.map(s => [s.id, []]));
    const inDegree = new Map(sorted.map(s => [s.id, 0]));

    // Wire explicit dependsOn
    for (const s of sorted) {
      if (s.dependsOn && s.dependsOn.length > 0) {
        for (const depId of s.dependsOn) {
          if (nodes.has(depId)) {
            edges.get(depId).push(s.id);
            inDegree.set(s.id, (inDegree.get(s.id) || 0) + 1);
          }
        }
      }
    }

    // Auto-wire sequential dependency within same type group (when no explicit deps)
    const typeGroups = new Map();
    for (const s of sorted) {
      if (!typeGroups.has(s.type)) typeGroups.set(s.type, []);
      typeGroups.get(s.type).push(s.id);
    }

    for (const [, ids] of typeGroups.entries()) {
      for (let i = 1; i < ids.length; i++) {
        const from = ids[i - 1];
        const to   = ids[i];
        // Only wire if not already wired
        if (!edges.get(from).includes(to)) {
          edges.get(from).push(to);
          inDegree.set(to, (inDegree.get(to) || 0) + 1);
        }
      }
    }

    // Cross-type wiring: research → others, communication is last
    const researchIds     = typeGroups.get('research')     || [];
    const communicationIds = typeGroups.get('communication') || [];

    for (const s of sorted) {
      // All non-research subtasks depend on last research subtask
      if (s.type !== 'research' && researchIds.length > 0) {
        const lastResearch = researchIds[researchIds.length - 1];
        if (!edges.get(lastResearch).includes(s.id) && lastResearch !== s.id) {
          edges.get(lastResearch).push(s.id);
          inDegree.set(s.id, (inDegree.get(s.id) || 0) + 1);
        }
      }
      // All non-communication subtasks are prerequisites for communication
      if (s.type !== 'communication' && communicationIds.length > 0) {
        for (const commId of communicationIds) {
          if (!edges.get(s.id).includes(commId)) {
            edges.get(s.id).push(commId);
            inDegree.set(commId, (inDegree.get(commId) || 0) + 1);
          }
        }
      }
    }

    // Verify no cycles (cycle = sorted < nodes after Kahn's — checked in topoSort)
    return { nodes, edges, inDegree };
  }

  // ─── TOPO SORT ────────────────────────────────────────────────────────────────

  /**
   * Topological sort of the DAG using Kahn's algorithm with cycle detection.
   *
   * Kahn's algorithm:
   * 1. Build in-degree map.
   * 2. Initialize queue with all 0-in-degree nodes.
   * 3. Process queue: emit node, decrement neighbors' in-degree, enqueue if 0.
   * 4. If result count < node count → cycle detected.
   *
   * @param {{ nodes: Map, edges: Map, inDegree: Map }} dag - Output of buildDAG()
   * @returns {{
   *   sorted: Array<object>,
   *   hasCycle: boolean,
   *   cycleNodes: string[]
   * }}
   */
  topoSort(dag) {
    const { nodes, edges, inDegree } = dag;

    // Copy in-degree (Kahn's modifies it)
    const deg    = new Map(inDegree);
    const queue  = [];
    const sorted = [];

    // Seed queue with 0-in-degree nodes
    for (const [id, d] of deg.entries()) {
      if (d === 0) queue.push(id);
    }

    while (queue.length > 0) {
      // For determinism: process smallest id first
      queue.sort();
      const current = queue.shift();
      const node    = nodes.get(current);
      if (node) sorted.push(node);

      for (const nextId of (edges.get(current) || [])) {
        const nextDeg = (deg.get(nextId) || 0) - 1;
        deg.set(nextId, nextDeg);
        if (nextDeg === 0) queue.push(nextId);
      }
    }

    const hasCycle   = sorted.length < nodes.size;
    const sortedIds  = new Set(sorted.map(s => s.id));
    const cycleNodes = hasCycle
      ? Array.from(nodes.keys()).filter(id => !sortedIds.has(id))
      : [];

    // If cycle detected, append remaining nodes to avoid blocking execution
    if (hasCycle) {
      for (const id of cycleNodes) {
        const node = nodes.get(id);
        if (node) sorted.push(node);
      }
    }

    return { sorted, hasCycle, cycleNodes };
  }

  // ─── EXECUTE ─────────────────────────────────────────────────────────────────

  /**
   * Execute topologically sorted subtasks in phi-concurrent waves.
   *
   * - Waves respect dependency completion.
   * - Up to MAX_CONCURRENT = fib(6) = 8 subtasks run concurrently per wave.
   * - Results cached for dedup across re-runs.
   *
   * @param {Array<object>} sortedTasks - Sorted output from topoSort()
   * @returns {Promise<{
   *   completed: number,
   *   failed: number,
   *   results: Array<{id: string, status: string, output: any}>,
   *   durationMs: number
   * }>}
   */
  async execute(sortedTasks) {
    const startMs   = Date.now();
    const completed = new Set();
    const results   = [];
    let failedCount = 0;

    let remaining = sortedTasks.slice();

    while (remaining.length > 0) {
      // Build wave: ready tasks (all deps satisfied) up to MAX_CONCURRENT
      const wave = [];
      for (const task of remaining) {
        if (wave.length >= this._maxConcurrent) break;
        const depsOk = (task.dependsOn || []).every(d => completed.has(d));
        if (depsOk) wave.push(task);
      }

      if (wave.length === 0) {
        // All remaining are blocked — advance one to avoid deadlock
        wave.push(remaining[0]);
      }

      // Execute wave concurrently
      const waveResults = await Promise.allSettled(
        wave.map(task => this._executeSubtask(task))
      );

      for (let i = 0; i < wave.length; i++) {
        const task   = wave[i];
        const result = waveResults[i];

        if (result.status === 'fulfilled') {
          completed.add(task.id);
          task.status = 'completed';
          results.push({ id: task.id, status: 'completed', output: result.value });
          this._resultCache.set(task.id, result.value);
        } else {
          failedCount++;
          task.status = 'failed';
          results.push({ id: task.id, status: 'failed', error: result.reason?.message });
        }
      }

      // Remove processed tasks from remaining
      const waveIds = new Set(wave.map(t => t.id));
      remaining     = remaining.filter(t => !waveIds.has(t.id));
    }

    return {
      completed: completed.size,
      failed:    failedCount,
      results,
      durationMs: Date.now() - startMs,
    };
  }

  // ─── SCORE SUBTASK ────────────────────────────────────────────────────────────

  /**
   * Score a subtask against all swarm capabilities using cosine similarity
   * gated by cslPhiGATE at LOW level.
   *
   * Assignment threshold: CSL_THRESHOLDS.LOW ≈ 0.691.
   * Only capabilities scoring above threshold are returned.
   *
   * @param {object} subtask
   * @param {string} subtask.description  - Subtask description
   * @param {number[]} [subtask.embedding] - Pre-computed embedding
   * @param {string[]} swarmCapabilities  - Array of capability names
   * @returns {Array<{
   *   capability: string,
   *   score: number,
   *   rawScore: number,
   *   qualified: boolean
   * }>} Sorted descending by score, filtered to qualified candidates
   */
  scoreSubtask(subtask, swarmCapabilities) {
    const subEmb = subtask.embedding || this._embed(subtask.description || '');

    const scores = swarmCapabilities.map(cap => {
      const capEmb  = CAPABILITY_EMBEDDINGS.get(cap) || buildCapabilityEmbedding(cap);
      const rawScore = cosineSimilarity(subEmb, capEmb);
      const gated    = cslPhiGATE(rawScore, rawScore, 1);  // LOW gate level
      return {
        capability: cap,
        score:      gated,
        rawScore,
        qualified:  gated >= ASSIGNMENT_THRESHOLD,  // ≈ 0.691
      };
    });

    // Sort descending and return qualified candidates
    scores.sort((a, b) => b.score - a.score);
    const qualified = scores.filter(s => s.qualified);

    // Always return at least the top-1 even if below threshold
    return qualified.length > 0 ? qualified : [scores[0]];
  }

  // ─── PRIVATE METHODS ─────────────────────────────────────────────────────────

  /**
   * Mint deterministic task ID using SHA-256.
   * @param {object} task
   * @returns {string} 13-char hex (fib(7))
   * @private
   */
  _mintTaskId(task) {
    const n = ++this._counter;
    return crypto.createHash('sha256')
      .update(`${this._seed}:task:${n}:${task.description || ''}`)
      .digest('hex')
      .slice(0, fib(7));   // 13 chars
  }

  /**
   * Mint deterministic subtask ID.
   * @param {string} taskId - Parent task ID
   * @param {number} idx    - Subtask index
   * @returns {string} 8-char hex (fib(6))
   * @private
   */
  _mintSubtaskId(taskId, idx) {
    return crypto.createHash('sha256')
      .update(`${this._seed}:subtask:${taskId}:${idx}`)
      .digest('hex')
      .slice(0, fib(6));   // 8 chars
  }

  /**
   * Deterministic 384D embedding from text.
   * @param {string} text
   * @returns {number[]}
   * @private
   */
  _embed(text) {
    const hash = crypto.createHash('sha256')
      .update(`${this._seed}:${text}`)
      .digest();
    const v = new Array(EMBEDDING_DIM);
    for (let i = 0; i < EMBEDDING_DIM; i++) {
      v[i] = ((hash[i % hash.length] / fib(7)) - PSI) * PHI;
    }
    return normalize(v);
  }

  /**
   * Execute a single subtask (stub — real impl dispatches to assigned agent).
   * @param {object} subtask
   * @returns {Promise<object>}
   * @private
   */
  async _executeSubtask(subtask) {
    // Deterministic stub: quality proportional to priority and capability score
    const capScore    = subtask.capabilityScores?.[0]?.score || PSI_SQ;
    const qualityScore = phiPriorityScore(subtask.priority || PSI, capScore, PSI_SQ);
    return {
      subtaskId:     subtask.id,
      type:          subtask.type,
      quality:       qualityScore,
      assignedTo:    subtask.assignedTo,
      tokensUsed:    Math.floor((subtask.tokenBudget || fib(9)) * PSI),
      status:        'executed',
    };
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  TaskDecompositionEngine,
  SUBTASK_TYPES,
  ALL_SWARM_CAPABILITIES,
  CAPABILITY_EMBEDDINGS,
  MAX_CONCURRENT,
  MAX_SUBTASKS,
  ASSIGNMENT_THRESHOLD,
  SEED,
  buildCapabilityEmbedding,
};
