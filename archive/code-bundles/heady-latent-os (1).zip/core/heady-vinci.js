/**
 * @fileoverview HeadyVinci — Session Planner & Topology Maintainer
 *
 * HeadyVinci is the strategic mind of the Heady Latent OS: it designs session
 * plans with phi-proportioned resource budgets, maintains the sacred-geometry
 * topology map, orchestrates multi-step sessions with dependency resolution,
 * and classifies task complexity via PSI thresholds.
 *
 * All constants derive from φ (golden ratio) or Fibonacci sequence.
 * Temperature = 0, seed = 42 for deterministic execution.
 *
 * @module core/heady-vinci
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  phiFusionWeights,
  phiBackoff,
  phiResourceWeights,
  phiMultiSplit,
  phiTokenBudgets,
  cslGate,
  cslBlend,
  sigmoid,
  adaptiveTemperature,
  POOL_ALLOCATION,
  PRESSURE_LEVELS,
  EVICTION_WEIGHTS,
  classifyPressure,
  phiPriorityScore,
  COHERENCE_DRIFT_THRESHOLD,
  phiAdaptiveInterval,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

const {
  RINGS,
  cosineSimilarity,
  geometricRoute,
  measureCoherence,
  assessCoherence,
  getAllNodes,
  findNodeRing,
  getNodePosition,
} = require('../shared/sacred-geometry');

const {
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslCONSENSUS,
  cslPhiGATE,
  normalize,
  moeRoute,
  hdcRandomVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── DETERMINISTIC SEED ────────────────────────────────────────────────────────

/** Deterministic seed = fib(9) = 34 */
const SEED = fib(9);

/** Temperature sentinel = 0 */
const TEMPERATURE_ZERO = 0;

// ─── COMPLEXITY THRESHOLDS ─────────────────────────────────────────────────────

/**
 * Complexity classification thresholds derived from ψ.
 *   simple:   score < PSI_SQ    ≈ 0.382
 *   moderate: PSI_SQ ≤ score < PSI   (0.382 – 0.618)
 *   complex:  score ≥ PSI        ≈ 0.618
 */
const COMPLEXITY_THRESHOLDS = Object.freeze({
  simple:   { max: PSI_SQ, label: 'simple' },       // < 0.382
  moderate: { min: PSI_SQ, max: PSI, label: 'moderate' }, // 0.382 – 0.618
  complex:  { min: PSI, label: 'complex' },          // ≥ 0.618
});

// ─── SESSION BUDGET CONSTANTS ─────────────────────────────────────────────────

/**
 * Session budget tiers (token allocations) derived via phiTokenBudgets.
 * Base = 8192 (working memory).
 * session ≈ 21,450 | memory ≈ 56,131 | artifacts ≈ 146,920
 */
const TOKEN_BUDGETS = Object.freeze(phiTokenBudgets(8192));

/**
 * Default session token budget = TOKEN_BUDGETS.session ≈ 21,450.
 * Bounded by fib(21) = 10946 on the lower end for minimal sessions.
 */
const DEFAULT_SESSION_BUDGET = TOKEN_BUDGETS.session;

/**
 * Maximum concurrent plan steps = fib(6) = 8 (matches maxConcurrent in TDE).
 * Topology supports fib(6) parallel active sessions in a ring.
 */
const MAX_CONCURRENT_STEPS = fib(6);  // 8

/**
 * Maximum plan steps per session = fib(10) = 55 (matches TDE maxSubtasks).
 */
const MAX_PLAN_STEPS = fib(10);  // 55

// ─── HeadyVinci CLASS ─────────────────────────────────────────────────────────

/**
 * @class HeadyVinci
 * @extends EventEmitter
 *
 * Session planner and topology maintainer for the Heady Latent OS.
 * Plans sessions with phi-proportioned budgets, maintains the ring topology
 * map, and orchestrates multi-step execution with dependency graphs.
 *
 * @fires HeadyVinci#session:planned
 * @fires HeadyVinci#resources:allocated
 * @fires HeadyVinci#topology:maintained
 * @fires HeadyVinci#step:executing
 * @fires HeadyVinci#session:complete
 */
class HeadyVinci extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.seed=34]        - Deterministic seed
   * @param {number} [options.temperature=0]  - Execution temperature
   */
  constructor(options = {}) {
    super();
    this._seed        = options.seed        ?? SEED;
    this._temperature = options.temperature ?? TEMPERATURE_ZERO;

    /**
     * Active session registry: Map<sessionId, SessionState>
     * @type {Map<string, object>}
     */
    this._sessions = new Map();

    /**
     * Topology snapshot: Map<nodeName, {position, ring, ring key}>
     * Maintained by maintainTopology().
     * @type {Map<string, object>}
     */
    this._topology = new Map();

    /** Session counter for deterministic ID generation */
    this._sessionCounter = 0;

    // Seed topology from sacred geometry
    this.maintainTopology();
  }

  // ─── PLAN SESSION ─────────────────────────────────────────────────────────────

  /**
   * Plan a complete session for a given objective.
   *
   * Planning process:
   * 1. Estimate complexity of the objective.
   * 2. Split the token budget using phiMultiSplit (phi-proportioned sub-budgets).
   * 3. Generate plan steps ordered by phi-priority.
   * 4. Build a dependency graph between steps.
   * 5. Assign nodes to steps using MoE routing.
   *
   * @param {object} objective
   * @param {string} objective.description     - Human-readable objective
   * @param {string} [objective.domain]        - Task domain hint
   * @param {number[]} [objective.embedding]   - Pre-computed embedding
   * @param {number} [objective.tokenBudget]   - Override token budget
   * @returns {{
   *   sessionId: string,
   *   steps: Array<object>,
   *   budget: object,
   *   complexity: object,
   *   nodeAssignments: Map<string, string[]>,
   *   estimatedMs: number
   * }}
   */
  planSession(objective) {
    const sessionId  = this._mintSessionId(objective);
    const embedding  = objective.embedding || this._embed(objective.description || '');
    const complexity = this.estimateComplexity({ ...objective, embedding });

    // Total token budget for this session
    const totalTokens = objective.tokenBudget || DEFAULT_SESSION_BUDGET;

    // Determine step count based on complexity
    const baseStepCount = complexity.label === 'simple'   ? fib(4)  // 3
      : complexity.label === 'moderate' ? fib(6)  // 8
      : fib(8);                                            // 21

    const stepCount = Math.min(baseStepCount, MAX_PLAN_STEPS);

    // Allocate tokens across steps via phiMultiSplit
    const budget = this.allocateResources({
      sessionId,
      totalTokens,
      stepCount,
      complexity,
    });

    // Generate steps
    const steps = this._generatePlanSteps(objective, stepCount, budget, embedding);

    // Build dependency graph
    const dependencyGraph = this._buildDependencies(steps);

    // Assign nodes to steps
    const nodeAssignments = this._assignNodesToSteps(steps, embedding);

    // Estimate total execution time (phi-scaled by complexity)
    const baseMs = fib(10) * 1000;  // 55s base
    const complexityFactor = complexity.label === 'simple'   ? PSI_SQ
      : complexity.label === 'moderate' ? PSI
      : PHI;
    const estimatedMs = Math.round(baseMs * complexityFactor * stepCount);

    const session = {
      sessionId,
      objective,
      steps,
      budget,
      complexity,
      dependencyGraph,
      nodeAssignments,
      estimatedMs,
      status: 'planned',
      createdAt: Date.now(),
    };

    this._sessions.set(sessionId, session);

    /**
     * @event HeadyVinci#session:planned
     * @type {object}
     */
    this.emit('session:planned', session);
    return session;
  }

  // ─── ALLOCATE RESOURCES ───────────────────────────────────────────────────────

  /**
   * Allocate token budget across session steps using Fibonacci ratios.
   *
   * Strategy:
   * - Split total into N parts via phiMultiSplit.
   * - Each part is a phi-proportioned sub-budget for one step.
   * - Reserve 1/φ of step[0] budget as a contingency buffer.
   *
   * @param {object} session
   * @param {string} session.sessionId
   * @param {number} session.totalTokens   - Total token budget
   * @param {number} session.stepCount     - Number of steps
   * @param {object} session.complexity    - Complexity assessment
   * @returns {{
   *   total: number,
   *   perStep: number[],
   *   contingency: number,
   *   overhead: number,
   *   breakdown: object
   * }}
   */
  allocateResources(session) {
    const { totalTokens, stepCount } = session;

    // Reserve PSI_SQ (≈ 38.2%) as overhead + contingency
    const usable    = Math.floor(totalTokens * (1 - PSI_SQ));       // ≈ 61.8% of total
    const overhead  = totalTokens - usable;

    // Split contingency from overhead: PSI of overhead
    const contingency = Math.floor(overhead * PSI);                 // ≈ 61.8% of overhead
    const fixed       = overhead - contingency;                     // ≈ 38.2% of overhead

    // Distribute usable tokens across steps via phiMultiSplit
    const perStep = phiMultiSplit(usable, stepCount);

    const budget = {
      total:       totalTokens,
      usable,
      overhead,
      contingency,
      fixed,
      perStep,
      breakdown: {
        usablePct:      (usable / totalTokens).toFixed(fib(3)),
        contingencyPct: (contingency / totalTokens).toFixed(fib(3)),
        fixedPct:       (fixed / totalTokens).toFixed(fib(3)),
      },
    };

    /**
     * @event HeadyVinci#resources:allocated
     * @type {object}
     */
    this.emit('resources:allocated', { session: session.sessionId, budget });
    return budget;
  }

  // ─── MAINTAIN TOPOLOGY ────────────────────────────────────────────────────────

  /**
   * Refresh the internal topology map from sacred-geometry definitions.
   *
   * Snapshot:
   * - All node names → ring key, ring metadata, 2D position, geometry distance.
   * - Central hub = HeadySoul (radius 0), all others at phi-scaled radii.
   *
   * @returns {Map<string, {
   *   name: string,
   *   ringKey: string,
   *   ringName: string,
   *   radius: number,
   *   position: {x: number, y: number} | null,
   *   role: string
   * }>}
   */
  maintainTopology() {
    this._topology.clear();

    const allNodes = getAllNodes();
    for (const nodeName of allNodes) {
      const ringInfo = findNodeRing(nodeName);
      if (!ringInfo) continue;

      const { ringKey, ring } = ringInfo;
      const position = typeof getNodePosition === 'function'
        ? getNodePosition(nodeName)
        : null;

      this._topology.set(nodeName, {
        name:     nodeName,
        ringKey,
        ringName: ring.name,
        radius:   ring.radius,
        position: position ? { x: position.x, y: position.y } : null,
        role:     ring.role,
        angle:    position ? position.angle : null,
      });
    }

    /**
     * @event HeadyVinci#topology:maintained
     * @type {object}
     */
    this.emit('topology:maintained', {
      nodeCount: this._topology.size,
      rings: Object.keys(RINGS),
    });

    return this._topology;
  }

  // ─── ESTIMATE COMPLEXITY ─────────────────────────────────────────────────────

  /**
   * Estimate the complexity of a task.
   *
   * Complexity score is computed as phi-priority of 4 dimensions:
   *   1. Token density  — estimated output length vs working memory
   *   2. Dependency fan-out — width of likely dependency graph
   *   3. Domain spread  — number of domains involved
   *   4. Embedding entropy — distributional diversity of the task embedding
   *
   * Classification:
   *   simple:   score < PSI_SQ   (< 0.382)
   *   moderate: PSI_SQ ≤ score < PSI (0.382 – 0.618)
   *   complex:  score ≥ PSI    (≥ 0.618)
   *
   * @param {object} task
   * @param {string} [task.description] - Task text
   * @param {number[]} [task.embedding] - Pre-computed embedding
   * @param {number} [task.estimatedTokens] - Expected output length
   * @param {string[]} [task.domains]   - Involved domains
   * @returns {{
   *   score: number,
   *   label: string,
   *   tokenDensity: number,
   *   dependencyWidth: number,
   *   domainSpread: number,
   *   embeddingEntropy: number
   * }}
   */
  estimateComplexity(task) {
    const desc    = task.description || '';
    const emb     = task.embedding || this._embed(desc);
    const domains = task.domains || [];

    // 1. Token density: ratio of estimated tokens to working budget
    const estTokens   = task.estimatedTokens || Math.max(desc.length * fib(4), fib(13));
    const tokenDensity = Math.min(estTokens / TOKEN_BUDGETS.memory, 1);

    // 2. Dependency fan-out: heuristic from description word count
    const wordCount      = desc.split(/\s+/).filter(Boolean).length;
    const dependencyWidth = Math.min(wordCount / (fib(9) * PHI), 1);   // normalize to fib(9)*φ≈55

    // 3. Domain spread: 0 = 1 domain, 1 = all 12 domains
    const domainSpread = Math.min(
      (domains.length || 1) / fib(7),   // fib(7)=13 ≈ num domains
      1
    );

    // 4. Embedding entropy: average |component| deviation from mean
    const embMean    = emb.reduce((s, v) => s + v, 0) / emb.length;
    const embVariance = emb.reduce((s, v) => s + (v - embMean) ** 2, 0) / emb.length;
    const embeddingEntropy = Math.min(Math.sqrt(embVariance) * PHI, 1);

    // Phi-priority weighted composite score (4 factors)
    const score = phiPriorityScore(tokenDensity, dependencyWidth, domainSpread, embeddingEntropy);

    let label;
    if (score < PSI_SQ)     label = 'simple';
    else if (score < PSI)   label = 'moderate';
    else                     label = 'complex';

    return {
      score, label,
      tokenDensity, dependencyWidth, domainSpread, embeddingEntropy,
    };
  }

  // ─── EXECUTE SESSION ─────────────────────────────────────────────────────────

  /**
   * Orchestrate execution of a planned session.
   *
   * Execution follows topological order of the dependency graph.
   * Concurrent steps up to MAX_CONCURRENT_STEPS = fib(6) = 8 run in parallel.
   *
   * @param {object} session - Session returned by planSession()
   * @returns {Promise<{
   *   sessionId: string,
   *   results: object[],
   *   completedSteps: number,
   *   failedSteps: number,
   *   durationMs: number
   * }>}
   */
  async executeSession(session) {
    const { sessionId, steps, dependencyGraph } = session;
    const startMs = Date.now();

    if (!this._sessions.has(sessionId)) {
      this._sessions.set(sessionId, { ...session, status: 'executing' });
    } else {
      this._sessions.get(sessionId).status = 'executing';
    }

    // Topological ordering (Kahn's algorithm, same as TDE)
    const sortedSteps = this._topoSort(steps, dependencyGraph);

    const results        = [];
    const completed      = new Set();
    let failedSteps      = 0;

    // Process in waves up to MAX_CONCURRENT_STEPS
    let i = 0;
    while (i < sortedSteps.length) {
      // Collect wave: steps whose deps are all completed
      const wave = [];
      for (let j = i; j < sortedSteps.length && wave.length < MAX_CONCURRENT_STEPS; j++) {
        const step = sortedSteps[j];
        const depsOk = (step.dependsOn || []).every(d => completed.has(d));
        if (depsOk) wave.push(step);
      }

      if (wave.length === 0) {
        // Safety: advance past blocked steps to avoid infinite loop
        i++;
        continue;
      }

      // Execute wave concurrently
      const waveResults = await Promise.allSettled(
        wave.map(step => this._executeStep(step, session))
      );

      for (let w = 0; w < wave.length; w++) {
        const step   = wave[w];
        const result = waveResults[w];

        /**
         * @event HeadyVinci#step:executing
         * @type {object}
         */
        this.emit('step:executing', { sessionId, step, status: result.status });

        if (result.status === 'fulfilled') {
          completed.add(step.id);
          results.push({ stepId: step.id, status: 'completed', output: result.value });
        } else {
          failedSteps++;
          results.push({ stepId: step.id, status: 'failed', error: result.reason?.message });
        }
      }

      i += wave.length;
    }

    const sessionState = this._sessions.get(sessionId);
    if (sessionState) sessionState.status = 'complete';

    const summary = {
      sessionId,
      results,
      completedSteps: completed.size,
      failedSteps,
      durationMs: Date.now() - startMs,
    };

    /**
     * @event HeadyVinci#session:complete
     * @type {object}
     */
    this.emit('session:complete', summary);
    return summary;
  }

  // ─── GET TOPOLOGY SNAPSHOT ───────────────────────────────────────────────────

  /**
   * Return the current topology snapshot as a plain object.
   * @returns {object[]} Array of node topology records
   */
  getTopologySnapshot() {
    return Array.from(this._topology.values());
  }

  /**
   * Get an active session by ID.
   * @param {string} sessionId
   * @returns {object|null}
   */
  getSession(sessionId) {
    return this._sessions.get(sessionId) || null;
  }

  // ─── PRIVATE METHODS ─────────────────────────────────────────────────────────

  /**
   * Mint deterministic session ID using SHA-256.
   * @param {object} objective
   * @returns {string} 13-char hex (fib(7))
   * @private
   */
  _mintSessionId(objective) {
    const n = ++this._sessionCounter;
    return crypto.createHash('sha256')
      .update(`${this._seed}:session:${n}:${objective.description || ''}`)
      .digest('hex')
      .slice(0, fib(7));  // 13 chars
  }

  /**
   * Deterministic 384D embedding from text.
   * @param {string} text
   * @returns {number[]}
   * @private
   */
  _embed(text) {
    const hash = crypto.createHash('sha256')
      .update(`${this._seed}:${text}`)
      .digest();
    const v = new Array(EMBEDDING_DIM);
    for (let i = 0; i < EMBEDDING_DIM; i++) {
      v[i] = ((hash[i % hash.length] / fib(7)) - PSI) * PHI;
    }
    return normalize(v);
  }

  /**
   * Generate plan steps for a session.
   * @param {object} objective
   * @param {number} stepCount
   * @param {object} budget
   * @param {number[]} embedding
   * @returns {Array<object>}
   * @private
   */
  _generatePlanSteps(objective, stepCount, budget, embedding) {
    const STEP_TYPES = [
      'research', 'planning', 'coding', 'reasoning', 'synthesis',
      'validation', 'integration', 'communication',
    ];

    const steps = [];
    for (let i = 0; i < stepCount; i++) {
      const stepType = STEP_TYPES[i % STEP_TYPES.length];
      const stepId   = crypto.createHash('sha256')
        .update(`${this._seed}:step:${i}:${objective.description || ''}`)
        .digest('hex')
        .slice(0, fib(6));  // 8 chars

      steps.push({
        id:          stepId,
        index:       i,
        type:        stepType,
        description: `${stepType}: ${objective.description || 'objective'} [step ${i + 1}/${stepCount}]`,
        tokenBudget: budget.perStep[i] || budget.perStep[0],
        dependsOn:   i > 0 ? [steps[i - 1].id] : [],       // Linear by default
        priority:    phiPriorityScore(
          1 - (i / stepCount),                               // Earlier = higher priority
          budget.perStep[i] / Math.max(...budget.perStep),   // More tokens = higher priority
          PSI_SQ                                             // Baseline factor
        ),
        status: 'pending',
      });
    }
    return steps;
  }

  /**
   * Build dependency graph from step definitions.
   * @param {Array<object>} steps
   * @returns {Map<string, string[]>} stepId → [dependencyIds]
   * @private
   */
  _buildDependencies(steps) {
    const graph = new Map();
    for (const step of steps) {
      graph.set(step.id, step.dependsOn || []);
    }
    return graph;
  }

  /**
   * Assign nodes to steps via MoE routing on step embeddings.
   * @param {Array<object>} steps
   * @param {number[]} sessionEmbedding
   * @returns {Map<string, string[]>} stepId → [nodeName, ...]
   * @private
   */
  _assignNodesToSteps(steps, sessionEmbedding) {
    const allNodes  = getAllNodes();
    const nodeGates = allNodes.map(n => this._embed(n));
    const assignments = new Map();

    for (const step of steps) {
      const stepEmb  = this._embed(step.description);
      // Select top fib(3)=2 nodes per step
      const selected = moeRoute(stepEmb, nodeGates, fib(3), PSI_CUBE);
      assignments.set(step.id, selected.map(e => allNodes[e.expertIdx]));
    }

    return assignments;
  }

  /**
   * Topological sort (Kahn's algorithm) on steps with dependency graph.
   * @param {Array<object>} steps
   * @param {Map<string, string[]>} depGraph
   * @returns {Array<object>} Steps in topological order
   * @private
   */
  _topoSort(steps, depGraph) {
    const stepMap   = new Map(steps.map(s => [s.id, s]));
    const inDegree  = new Map(steps.map(s => [s.id, 0]));
    const adjOut    = new Map(steps.map(s => [s.id, []]));

    // Build adjacency + in-degree
    for (const [stepId, deps] of depGraph.entries()) {
      inDegree.set(stepId, deps.length);
      for (const dep of deps) {
        const outList = adjOut.get(dep) || [];
        outList.push(stepId);
        adjOut.set(dep, outList);
      }
    }

    // Initialize queue with zero in-degree nodes
    const queue  = steps.filter(s => (inDegree.get(s.id) || 0) === 0);
    const sorted = [];

    while (queue.length > 0) {
      const current = queue.shift();
      sorted.push(current);

      for (const nextId of (adjOut.get(current.id) || [])) {
        const deg = (inDegree.get(nextId) || 0) - 1;
        inDegree.set(nextId, deg);
        if (deg === 0) {
          const next = stepMap.get(nextId);
          if (next) queue.push(next);
        }
      }
    }

    // If sorted length < steps length, there was a cycle — append remaining
    if (sorted.length < steps.length) {
      const sortedIds = new Set(sorted.map(s => s.id));
      for (const step of steps) {
        if (!sortedIds.has(step.id)) sorted.push(step);
      }
    }

    return sorted;
  }

  /**
   * Execute a single plan step (stub — real impl dispatches to agents).
   * @param {object} step
   * @param {object} session
   * @returns {Promise<object>}
   * @private
   */
  async _executeStep(step, session) {
    // Deterministic stub: returns phi-scored output
    const qualityScore = phiPriorityScore(step.priority, PSI, PSI_SQ);
    return {
      stepId:  step.id,
      type:    step.type,
      quality: qualityScore,
      tokensUsed: Math.floor(step.tokenBudget * PSI),  // Use ≈ 61.8% of budget
      status:  'executed',
    };
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  HeadyVinci,
  COMPLEXITY_THRESHOLDS,
  TOKEN_BUDGETS,
  DEFAULT_SESSION_BUDGET,
  MAX_CONCURRENT_STEPS,
  MAX_PLAN_STEPS,
  SEED,
};
