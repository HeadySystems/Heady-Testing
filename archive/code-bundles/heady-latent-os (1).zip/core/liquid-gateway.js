/**
 * @fileoverview LiquidGateway — Multi-Provider Race Routing Gateway
 *
 * Routes LLM requests across multiple providers using a race-based strategy:
 * fire to N providers, accept the fastest successful response.
 * Implements phi-backoff health-aware failover, streaming with partial frames,
 * phi-scaled cost caps, BYOK (bring-your-own-key) support, and an LRU cache
 * with fib(20)=6765 max entries and TTL=fib(17)*1000=1597000ms.
 *
 * Workload classes: fastInteractive, deepReasoning, toolExecution, backgroundBatch
 *
 * All constants derive from φ (golden ratio) or Fibonacci sequence.
 * Temperature = 0, seed = 42 for deterministic execution.
 *
 * @module core/liquid-gateway
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  phiFusionWeights,
  phiBackoff,
  phiResourceWeights,
  phiMultiSplit,
  phiTokenBudgets,
  cslGate,
  cslBlend,
  sigmoid,
  adaptiveTemperature,
  POOL_ALLOCATION,
  PRESSURE_LEVELS,
  EVICTION_WEIGHTS,
  classifyPressure,
  phiPriorityScore,
  COHERENCE_DRIFT_THRESHOLD,
  phiAdaptiveInterval,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

const {
  RINGS,
  cosineSimilarity,
  geometricRoute,
  measureCoherence,
  assessCoherence,
  getAllNodes,
  findNodeRing,
} = require('../shared/sacred-geometry');

const {
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslCONSENSUS,
  cslPhiGATE,
  normalize,
  moeRoute,
  hdcRandomVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── DETERMINISTIC SEED ────────────────────────────────────────────────────────

/** Deterministic seed = fib(9) = 34 */
const SEED = fib(9);

/** Temperature sentinel = 0 */
const TEMPERATURE_ZERO = 0;

// ─── WORKLOAD CLASSES ─────────────────────────────────────────────────────────

/**
 * 4 workload classes with phi-scaled timeout and concurrency parameters.
 *
 * Timeouts from POOL_TIMEOUTS:
 *   fastInteractive  → fib(9)*1000  = 34s   (interactive user responses)
 *   deepReasoning    → fib(14)*1000 = 377s  (complex reasoning chains)
 *   toolExecution    → fib(8)*1000  = 21s   (tool calls, structured output)
 *   backgroundBatch  → fib(17)*1000 = 1597s (bulk processing)
 */
const WORKLOAD_CLASSES = Object.freeze({
  fastInteractive: {
    name:           'fastInteractive',
    timeoutMs:      fib(9)  * 1000,    // 34,000ms
    maxProviders:   fib(4),             // 3 — race 3 providers
    priority:       phiFusionWeights(4)[0],  // Highest priority
    maxTokens:      fib(13) * fib(4),  // 233×3=699 → approx working budget / fib(3)
    costCapUsd:     PHI,                // $1.618 per request
  },
  toolExecution: {
    name:           'toolExecution',
    timeoutMs:      fib(8)  * 1000,    // 21,000ms
    maxProviders:   fib(3),             // 2 — race 2 providers
    priority:       phiFusionWeights(4)[1],
    maxTokens:      fib(14) * fib(3),  // 377×2=754
    costCapUsd:     PSI * PHI,          // ≈$1.000
  },
  deepReasoning: {
    name:           'deepReasoning',
    timeoutMs:      fib(14) * 1000,    // 377,000ms
    maxProviders:   fib(4),             // 3 — race 3 providers
    priority:       phiFusionWeights(4)[2],
    maxTokens:      fib(17),           // 1597 tokens
    costCapUsd:     PHI * PHI,          // ≈$2.618
  },
  backgroundBatch: {
    name:           'backgroundBatch',
    timeoutMs:      fib(17) * 1000,    // 1,597,000ms
    maxProviders:   1,                  // Single provider (no race overhead)
    priority:       phiFusionWeights(4)[3],
    maxTokens:      fib(19),           // 4181 tokens
    costCapUsd:     PSI_SQ * PHI,       // ≈$0.618
  },
});

// ─── CACHE CONSTANTS ──────────────────────────────────────────────────────────

/** Cache max entries = fib(20) = 6765 */
const CACHE_MAX_ENTRIES = fib(20);   // 6,765

/** Cache TTL = fib(17) * 1000 = 1,597,000 ms ≈ 26.6 minutes */
const CACHE_TTL_MS = fib(17) * 1000;  // 1,597,000ms

// ─── HEALTH SCORING CONSTANTS ─────────────────────────────────────────────────

/**
 * Provider health factors using phi-fusion weights for 3 factors.
 * [successRate, latency, errorRate] → phiFusionWeights(3) ≈ [0.545, 0.337, 0.208]
 * Applied inversely for latency and errorRate.
 */
const HEALTH_WEIGHTS = Object.freeze(
  (() => {
    const w = phiFusionWeights(3);
    return { successRate: w[0], latencyScore: w[1], errorRate: w[2] };
  })()
);

/**
 * Minimum health score to be considered active = CSL_THRESHOLDS.LOW ≈ 0.691.
 * Below this, provider is quarantined with phi-backoff.
 */
const MIN_HEALTH_SCORE = CSL_THRESHOLDS.LOW;

// ─── LiquidGateway CLASS ──────────────────────────────────────────────────────

/**
 * @class LiquidGateway
 * @extends EventEmitter
 *
 * Multi-provider race routing gateway with streaming, BYOK, caching,
 * phi-backoff failover, and cost tracking.
 *
 * @fires LiquidGateway#request:routed
 * @fires LiquidGateway#provider:health
 * @fires LiquidGateway#stream:frame
 * @fires LiquidGateway#stream:complete
 * @fires LiquidGateway#cache:hit
 * @fires LiquidGateway#cache:miss
 * @fires LiquidGateway#provider:failed
 * @fires LiquidGateway#provider:recovered
 */
class LiquidGateway extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.seed=34]          - Deterministic seed
   * @param {number} [options.temperature=0]    - Execution temperature
   * @param {number} [options.cacheMaxEntries]  - Override cache max (default fib(20)=6765)
   * @param {number} [options.cacheTtlMs]       - Override cache TTL (default fib(17)*1000)
   */
  constructor(options = {}) {
    super();
    this._seed           = options.seed          ?? SEED;
    this._temperature    = options.temperature   ?? TEMPERATURE_ZERO;
    this._cacheMaxEntries = options.cacheMaxEntries ?? CACHE_MAX_ENTRIES;
    this._cacheTtlMs     = options.cacheTtlMs    ?? CACHE_TTL_MS;

    /**
     * Provider registry: Map<providerId, ProviderRecord>
     * @type {Map<string, object>}
     */
    this._providers = new Map();

    /**
     * LRU cache: Map<cacheKey, {response, createdAt, tokens}>
     * Evicts LRU when size > _cacheMaxEntries.
     * @type {Map<string, object>}
     */
    this._cache = new Map();

    /**
     * Metrics accumulator.
     * @type {{
     *   totalRequests: number,
     *   cacheHits: number,
     *   cacheMisses: number,
     *   totalTokens: number,
     *   totalCostUsd: number,
     *   failovers: number
     * }}
     */
    this._metrics = {
      totalRequests: 0,
      cacheHits:     0,
      cacheMisses:   0,
      totalTokens:   0,
      totalCostUsd:  0,
      failovers:     0,
    };

    /** Request counter for deterministic ID generation */
    this._requestCounter = 0;

    // Seed default providers
    this._registerDefaultProviders();
  }

  // ─── REGISTER PROVIDER ────────────────────────────────────────────────────────

  /**
   * Register a provider with the gateway.
   *
   * @param {object} config
   * @param {string} config.id           - Unique provider ID
   * @param {string} config.name         - Human-readable name
   * @param {string[]} config.models     - Supported model IDs
   * @param {string[]} config.workloads  - Supported workload classes
   * @param {string} [config.apiKey]     - BYOK API key (optional)
   * @param {string} [config.baseUrl]    - Custom endpoint (BYOK)
   * @param {number} [config.costPerToken] - USD per token
   * @param {number} [config.maxRpm]     - Rate limit: requests per minute
   * @returns {{ id: string, registered: boolean }}
   */
  registerProvider(config) {
    if (!config.id || !config.name) {
      throw new Error('Provider config must include id and name');
    }

    const provider = {
      id:            config.id,
      name:          config.name,
      models:        config.models || [],
      workloads:     config.workloads || Object.keys(WORKLOAD_CLASSES),
      apiKey:        config.apiKey || null,   // BYOK
      baseUrl:       config.baseUrl || null,
      costPerToken:  config.costPerToken || PSI_CUBE,   // Default ψ³ ≈ 0.236 $/1k tokens
      maxRpm:        config.maxRpm || fib(9),            // Default fib(9)=34 rpm
      healthScore:   1.0,                                 // Start healthy
      successCount:  0,
      failureCount:  0,
      totalLatencyMs: 0,
      requestCount:  0,
      lastCheckedAt: Date.now(),
      quarantinedUntil: 0,
      failoverAttempts: 0,
      active:        true,
    };

    this._providers.set(config.id, provider);

    /**
     * @event LiquidGateway#provider:health
     * @type {object}
     */
    this.emit('provider:health', { providerId: config.id, health: 1.0, status: 'registered' });
    return { id: config.id, registered: true };
  }

  // ─── ROUTE ───────────────────────────────────────────────────────────────────

  /**
   * Route a request to the optimal provider(s) based on workload class.
   *
   * Flow:
   * 1. Check cache (TTL-validated LRU).
   * 2. Select workload class from request.
   * 3. Filter providers by workload support and health.
   * 4. Race top-N providers; return first successful response.
   * 5. Cache the result.
   *
   * @param {object} request
   * @param {string} request.prompt        - Input prompt
   * @param {string} [request.model]       - Preferred model ID
   * @param {string} [request.workload]    - Workload class name
   * @param {number} [request.maxTokens]   - Max response tokens
   * @param {boolean} [request.stream]     - Enable streaming
   * @param {string} [request.apiKey]      - BYOK override key
   * @param {object} [request.metadata]    - Extra metadata
   * @returns {Promise<{
   *   requestId: string,
   *   response: any,
   *   provider: string,
   *   latencyMs: number,
   *   tokens: number,
   *   costUsd: number,
   *   cacheHit: boolean
   * }>}
   */
  async route(request) {
    const requestId = this._mintRequestId(request);
    this._metrics.totalRequests++;

    // Check cache first
    const cacheKey   = this._cacheKey(request);
    const cached     = this._getCached(cacheKey);
    if (cached) {
      this._metrics.cacheHits++;
      /**
       * @event LiquidGateway#cache:hit
       */
      this.emit('cache:hit', { requestId, cacheKey });
      return { requestId, response: cached.response, provider: cached.provider,
               latencyMs: 0, tokens: cached.tokens, costUsd: 0, cacheHit: true };
    }
    this._metrics.cacheMisses++;
    this.emit('cache:miss', { requestId, cacheKey });

    // Determine workload class
    const workloadName = request.workload || this._classifyWorkload(request);
    const workload     = WORKLOAD_CLASSES[workloadName] || WORKLOAD_CLASSES.fastInteractive;

    // Get healthy providers for this workload
    const activeProviders = this._getActiveProviders(workloadName);
    if (activeProviders.length === 0) {
      throw new Error(`No healthy providers available for workload: ${workloadName}`);
    }

    /**
     * @event LiquidGateway#request:routed
     */
    this.emit('request:routed', { requestId, workload: workloadName, providerCount: activeProviders.length });

    // Race providers
    const result = await this.race(request, activeProviders.slice(0, workload.maxProviders));

    // Track metrics
    const tokens  = result.tokens || 0;
    const costUsd = tokens * (result.providerRecord?.costPerToken || PSI_CUBE) / 1000;
    this._metrics.totalTokens  += tokens;
    this._metrics.totalCostUsd += costUsd;

    // Cache result
    this._setCached(cacheKey, {
      response: result.response,
      provider: result.provider,
      tokens,
    });

    return {
      requestId,
      response:  result.response,
      provider:  result.provider,
      latencyMs: result.latencyMs,
      tokens,
      costUsd,
      cacheHit:  false,
    };
  }

  // ─── RACE ────────────────────────────────────────────────────────────────────

  /**
   * Race multiple providers: fire all concurrently, return the first success.
   *
   * Uses Promise.race() with a timeout wrapper per provider.
   * On provider failure, updates health score and phi-backoff quarantine.
   *
   * @param {object} request - Request object
   * @param {object[]} providers - Provider records to race
   * @returns {Promise<{
   *   response: any,
   *   provider: string,
   *   providerRecord: object,
   *   latencyMs: number,
   *   tokens: number
   * }>}
   */
  async race(request, providers) {
    if (providers.length === 0) {
      throw new Error('race() requires at least one provider');
    }

    // Build timeout promise for workload
    const workloadName = request.workload || this._classifyWorkload(request);
    const workload     = WORKLOAD_CLASSES[workloadName] || WORKLOAD_CLASSES.fastInteractive;

    const providerPromises = providers.map(provider => {
      const start = Date.now();
      return this._callProvider(provider, request)
        .then(response => ({
          response,
          provider:       provider.id,
          providerRecord: provider,
          latencyMs:      Date.now() - start,
          tokens:         response.tokens || 0,
        }))
        .catch(err => {
          // Record failure, return rejected
          this._recordFailure(provider, err);
          return Promise.reject(err);
        });
    });

    // Timeout wrapper
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(
        () => reject(new Error(`Race timeout after ${workload.timeoutMs}ms`)),
        workload.timeoutMs
      )
    );

    // Race: first fulfillment wins; if all fail, the last rejection propagates
    try {
      const winner = await Promise.race([
        // allSettled + find first fulfilled, wrapped in a promise
        new Promise((resolve, reject) => {
          let settled = 0;
          const errors = [];
          providerPromises.forEach(p =>
            p.then(resolve).catch(err => {
              errors.push(err);
              settled++;
              if (settled === providerPromises.length) {
                reject(errors[errors.length - 1]);
              }
            })
          );
        }),
        timeoutPromise,
      ]);

      // Record success for winning provider
      this._recordSuccess(winner.providerRecord, winner.latencyMs);
      return winner;

    } catch (finalErr) {
      this._metrics.failovers++;
      // Attempt fallback to any remaining active provider not in original race
      const fallback = this._getFallbackProvider(workloadName, new Set(providers.map(p => p.id)));
      if (fallback) {
        const start = Date.now();
        const response = await this._callProvider(fallback, request);
        const latencyMs = Date.now() - start;
        this._recordSuccess(fallback, latencyMs);
        return { response, provider: fallback.id, providerRecord: fallback, latencyMs, tokens: response.tokens || 0 };
      }
      throw finalErr;
    }
  }

  // ─── HEALTH CHECK ─────────────────────────────────────────────────────────────

  /**
   * Run a health check on all providers.
   *
   * Health score = successRate × w₀ + latencyScore × w₁ + (1-errorRate) × w₂
   * where w = HEALTH_WEIGHTS (phi-fusion for 3 factors).
   *
   * Providers below MIN_HEALTH_SCORE ≈ 0.691 are quarantined with phi-backoff.
   *
   * @returns {Map<string, {
   *   id: string,
   *   healthScore: number,
   *   status: string,
   *   quarantinedUntil: number
   * }>}
   */
  healthCheck() {
    const now    = Date.now();
    const report = new Map();

    for (const [id, provider] of this._providers.entries()) {
      // Compute success rate
      const total       = provider.successCount + provider.failureCount;

      // If no requests yet, retain existing health score (default 1.0 at registration)
      if (total === 0) {
        const rec0 = {
          id,
          name:             provider.name,
          healthScore:      Number(provider.healthScore.toFixed(fib(3))),
          status:           'healthy',
          successRate:      1.0,
          latencyScore:     1.0,
          avgLatencyMs:     0,
          quarantinedUntil: 0,
        };
        report.set(id, rec0);
        this.emit('provider:health', rec0);
        continue;
      }

      const successRate = total > 0 ? provider.successCount / total : PSI;  // Default ψ

      // Latency score: normalize to fib(9)*1000 = 34s max
      const avgLatency  = provider.requestCount > 0
        ? provider.totalLatencyMs / provider.requestCount
        : fib(9) * 1000;
      const latencyScore = Math.max(0, 1 - avgLatency / (fib(9) * 1000));

      // Error rate
      const errorRate = total > 0 ? provider.failureCount / total : 0;

      // Weighted health score
      const healthScore = (
        successRate  * HEALTH_WEIGHTS.successRate   +
        latencyScore * HEALTH_WEIGHTS.latencyScore  +
        (1 - errorRate) * HEALTH_WEIGHTS.errorRate
      );

      provider.healthScore    = healthScore;
      provider.lastCheckedAt  = now;

      // Quarantine if below threshold
      let status = 'healthy';
      if (healthScore < MIN_HEALTH_SCORE) {
        const backoffMs = phiBackoff(provider.failoverAttempts, fib(10));   // 55ms base
        provider.quarantinedUntil = now + backoffMs;
        provider.failoverAttempts++;
        status = 'quarantined';
      } else if (provider.quarantinedUntil > now) {
        status = 'quarantined';
      } else if (provider.failoverAttempts > 0) {
        provider.failoverAttempts = Math.max(0, provider.failoverAttempts - 1);
        status = 'recovering';
      }

      const rec = {
        id,
        name:             provider.name,
        healthScore:      Number(healthScore.toFixed(fib(3))),
        status,
        successRate:      Number(successRate.toFixed(fib(3))),
        latencyScore:     Number(latencyScore.toFixed(fib(3))),
        avgLatencyMs:     Math.round(avgLatency),
        quarantinedUntil: provider.quarantinedUntil,
      };

      report.set(id, rec);

      /**
       * @event LiquidGateway#provider:health
       */
      this.emit('provider:health', rec);
    }

    return report;
  }

  // ─── STREAM ──────────────────────────────────────────────────────────────────

  /**
   * Stream a request, emitting partial result frames as they arrive.
   *
   * Frames are emitted as `stream:frame` events with:
   *   { requestId, frame: string, frameIndex: number, provider: string }
   *
   * Completes with `stream:complete` event.
   *
   * @param {object} request - Request object (same as route())
   * @returns {Promise<{
   *   requestId: string,
   *   frameCount: number,
   *   totalTokens: number,
   *   provider: string,
   *   durationMs: number
   * }>}
   */
  async stream(request) {
    const requestId    = this._mintRequestId({ ...request, stream: true });
    const workloadName = request.workload || this._classifyWorkload(request);
    const workload     = WORKLOAD_CLASSES[workloadName] || WORKLOAD_CLASSES.fastInteractive;
    const startMs      = Date.now();

    const providers = this._getActiveProviders(workloadName);
    if (providers.length === 0) {
      throw new Error(`No healthy providers for streaming workload: ${workloadName}`);
    }

    // Use best-health provider for streaming (no race overhead)
    const provider = providers[0];

    // Simulate phi-chunked streaming: split response into fib(7)=13 chunks
    const CHUNK_COUNT = fib(7);  // 13 chunks
    const fullResponse = `[STREAM:${requestId}] Response for: ${(request.prompt || '').slice(0, fib(9))}`;
    const chunkSize    = Math.ceil(fullResponse.length / CHUNK_COUNT);

    let frameIndex  = 0;
    let totalTokens = 0;

    // Emit frames with phi-spaced delays (simulated)
    for (let i = 0; i < CHUNK_COUNT; i++) {
      const frame = fullResponse.slice(i * chunkSize, (i + 1) * chunkSize);
      if (!frame) continue;

      const tokenCount = Math.ceil(frame.length / fib(3));
      totalTokens     += tokenCount;

      /**
       * @event LiquidGateway#stream:frame
       * @type {object}
       */
      this.emit('stream:frame', {
        requestId,
        frame,
        frameIndex,
        provider:    provider.id,
        tokenCount,
        isFinal:     i === CHUNK_COUNT - 1,
      });

      frameIndex++;
    }

    const durationMs = Date.now() - startMs;

    const summary = {
      requestId,
      frameCount:  frameIndex,
      totalTokens,
      provider:    provider.id,
      durationMs,
    };

    /**
     * @event LiquidGateway#stream:complete
     * @type {object}
     */
    this.emit('stream:complete', summary);
    return summary;
  }

  // ─── GET METRICS ─────────────────────────────────────────────────────────────

  /**
   * Return aggregated gateway metrics.
   *
   * @returns {{
   *   totalRequests: number,
   *   cacheHits: number,
   *   cacheMisses: number,
   *   cacheHitRate: number,
   *   totalTokens: number,
   *   totalCostUsd: number,
   *   failovers: number,
   *   cacheSize: number,
   *   providerCount: number,
   *   healthyProviders: number
   * }}
   */
  getMetrics() {
    const total  = this._metrics.totalRequests;
    const hitRate = total > 0 ? this._metrics.cacheHits / total : 0;

    const healthyProviders = Array.from(this._providers.values())
      .filter(p => p.healthScore >= MIN_HEALTH_SCORE && !this._isQuarantined(p))
      .length;

    return {
      ...this._metrics,
      cacheHitRate:     Number(hitRate.toFixed(fib(3))),
      cacheSize:        this._cache.size,
      providerCount:    this._providers.size,
      healthyProviders,
    };
  }

  // ─── PRIVATE: PROVIDER MANAGEMENT ────────────────────────────────────────────

  /**
   * Seed built-in default providers (stubs for standard LLM providers).
   * @private
   */
  _registerDefaultProviders() {
    const defaults = [
      {
        id:          'openai',
        name:        'OpenAI',
        models:      ['gpt-4o', 'gpt-4o-mini', 'o3'],
        workloads:   Object.keys(WORKLOAD_CLASSES),
        costPerToken: PSI_SQ,   // ≈ $0.382/1k
        maxRpm:      fib(11),   // 89 rpm
      },
      {
        id:          'anthropic',
        name:        'Anthropic',
        models:      ['claude-opus-4', 'claude-sonnet-4', 'claude-haiku-4'],
        workloads:   Object.keys(WORKLOAD_CLASSES),
        costPerToken: PSI,      // ≈ $0.618/1k
        maxRpm:      fib(10),   // 55 rpm
      },
      {
        id:          'google',
        name:        'Google',
        models:      ['gemini-2.5-pro', 'gemini-2.5-flash'],
        workloads:   ['fastInteractive', 'deepReasoning', 'backgroundBatch'],
        costPerToken: PSI_CUBE,  // ≈ $0.236/1k
        maxRpm:      fib(12),   // 144 rpm
      },
      {
        id:          'local',
        name:        'Local Ollama',
        models:      ['llama3.3', 'phi4'],
        workloads:   ['fastInteractive', 'toolExecution'],
        costPerToken: 0,         // Free
        maxRpm:      fib(6),     // 8 rpm (hardware limited)
      },
    ];

    for (const cfg of defaults) this.registerProvider(cfg);
  }

  /**
   * Get active (healthy + not quarantined) providers for a workload class.
   * Sorted descending by health score.
   *
   * @param {string} workloadName
   * @returns {object[]} Provider records
   * @private
   */
  _getActiveProviders(workloadName) {
    const now = Date.now();
    return Array.from(this._providers.values())
      .filter(p =>
        p.active &&
        (p.workloads.includes(workloadName) || p.workloads.length === 0) &&
        p.healthScore >= MIN_HEALTH_SCORE &&
        p.quarantinedUntil <= now
      )
      .sort((a, b) => b.healthScore - a.healthScore);
  }

  /**
   * Get fallback provider not in the excluded set.
   * @param {string} workloadName
   * @param {Set<string>} excludedIds
   * @returns {object|null}
   * @private
   */
  _getFallbackProvider(workloadName, excludedIds) {
    const now = Date.now();
    return Array.from(this._providers.values())
      .filter(p =>
        p.active &&
        !excludedIds.has(p.id) &&
        p.workloads.includes(workloadName) &&
        p.quarantinedUntil <= now
      )
      .sort((a, b) => b.healthScore - a.healthScore)[0] || null;
  }

  /**
   * Check if a provider is currently quarantined.
   * @param {object} provider
   * @returns {boolean}
   * @private
   */
  _isQuarantined(provider) {
    return provider.quarantinedUntil > Date.now();
  }

  /**
   * Record a successful provider call.
   * @param {object} provider
   * @param {number} latencyMs
   * @private
   */
  _recordSuccess(provider, latencyMs) {
    provider.successCount++;
    provider.requestCount++;
    provider.totalLatencyMs += latencyMs;
    // Phi-weighted health update: new = PSI × new + (1-PSI) × old
    const prevHealth     = provider.healthScore;
    provider.healthScore = Math.min(1.0, PSI * 1.0 + (1 - PSI) * prevHealth);
    provider.failoverAttempts = Math.max(0, provider.failoverAttempts - 1);

    this.emit('provider:recovered', { providerId: provider.id, healthScore: provider.healthScore });
  }

  /**
   * Record a failed provider call.
   * @param {object} provider
   * @param {Error} err
   * @private
   */
  _recordFailure(provider, err) {
    provider.failureCount++;
    provider.requestCount++;
    // Phi-weighted health degradation
    const prevHealth     = provider.healthScore;
    provider.healthScore = Math.max(0, PSI_SQ * 0.0 + (1 - PSI_SQ) * prevHealth);

    this.emit('provider:failed', { providerId: provider.id, error: err.message, healthScore: provider.healthScore });
  }

  // ─── PRIVATE: CALL PROVIDER ───────────────────────────────────────────────────

  /**
   * Dispatch a request to a single provider.
   * Real implementation would make an HTTP call; this stub is deterministic.
   *
   * @param {object} provider - Provider record
   * @param {object} request  - Request object
   * @returns {Promise<{text: string, tokens: number, model: string}>}
   * @private
   */
  async _callProvider(provider, request) {
    // Apply BYOK override if provided
    const apiKey = request.apiKey || provider.apiKey;  // BYOK support
    // Stub: deterministic response based on seed + provider + request hash
    const responseHash = crypto.createHash('sha256')
      .update(`${this._seed}:${provider.id}:${request.prompt || ''}`)
      .digest('hex')
      .slice(0, fib(8));  // 21 chars

    const tokenCount = Math.min(
      request.maxTokens || fib(13),
      WORKLOAD_CLASSES[request.workload || 'fastInteractive']?.maxTokens || fib(9)
    );

    return {
      text:   `[${provider.name}] Response ${responseHash}`,
      tokens: tokenCount,
      model:  provider.models[0] || 'unknown',
      apiKey: apiKey ? '***' : null,
    };
  }

  // ─── PRIVATE: WORKLOAD CLASSIFICATION ────────────────────────────────────────

  /**
   * Classify a request into a workload class based on prompt characteristics.
   *
   * Heuristics:
   * - Short prompt (< fib(7)=13 words) → fastInteractive
   * - Contains tool/function keywords → toolExecution
   * - Long prompt or reasoning keywords → deepReasoning
   * - Otherwise → backgroundBatch
   *
   * @param {object} request
   * @returns {string} Workload class name
   * @private
   */
  _classifyWorkload(request) {
    const prompt    = (request.prompt || '').toLowerCase();
    const wordCount = prompt.split(/\s+/).filter(Boolean).length;

    if (wordCount < fib(7)) return 'fastInteractive';             // < 13 words

    const toolKeywords = ['function', 'tool', 'call', 'execute', 'api', 'json', 'schema'];
    if (toolKeywords.some(k => prompt.includes(k))) return 'toolExecution';

    const reasoningKeywords = ['analyze', 'reason', 'compare', 'evaluate', 'step by step', 'think'];
    if (reasoningKeywords.some(k => prompt.includes(k))) return 'deepReasoning';

    if (wordCount > fib(10)) return 'backgroundBatch';            // > 55 words

    return 'fastInteractive';
  }

  // ─── PRIVATE: CACHE ───────────────────────────────────────────────────────────

  /**
   * Compute deterministic cache key for a request.
   * SHA-256 of normalized prompt + model + maxTokens.
   *
   * @param {object} request
   * @returns {string} 13-char hex cache key
   * @private
   */
  _cacheKey(request) {
    const input = JSON.stringify({
      p: (request.prompt || '').trim().toLowerCase(),
      m: request.model || '',
      t: request.maxTokens || 0,
    });
    return crypto.createHash('sha256').update(input).digest('hex').slice(0, fib(7));
  }

  /**
   * Get cached entry if within TTL.
   * Updates LRU access order (delete + re-insert).
   *
   * @param {string} key
   * @returns {object|null} Cached record or null
   * @private
   */
  _getCached(key) {
    const entry = this._cache.get(key);
    if (!entry) return null;

    if (Date.now() - entry.createdAt > this._cacheTtlMs) {
      this._cache.delete(key);
      return null;
    }

    // LRU refresh: move to end (most recently used)
    this._cache.delete(key);
    this._cache.set(key, entry);
    return entry;
  }

  /**
   * Store a response in the LRU cache.
   * Evicts LRU entry when size > _cacheMaxEntries.
   *
   * @param {string} key
   * @param {object} value - { response, provider, tokens }
   * @private
   */
  _setCached(key, value) {
    // Evict LRU if at capacity
    if (this._cache.size >= this._cacheMaxEntries) {
      const firstKey = this._cache.keys().next().value;
      this._cache.delete(firstKey);
    }

    this._cache.set(key, { ...value, createdAt: Date.now() });
  }

  // ─── PRIVATE: ID GENERATION ──────────────────────────────────────────────────

  /**
   * Mint deterministic request ID using SHA-256.
   * @param {object} request
   * @returns {string} 8-char hex (fib(6))
   * @private
   */
  _mintRequestId(request) {
    const n = ++this._requestCounter;
    return crypto.createHash('sha256')
      .update(`${this._seed}:req:${n}:${request.prompt || ''}`)
      .digest('hex')
      .slice(0, fib(6));  // 8 chars
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  LiquidGateway,
  WORKLOAD_CLASSES,
  CACHE_MAX_ENTRIES,
  CACHE_TTL_MS,
  HEALTH_WEIGHTS,
  MIN_HEALTH_SCORE,
  SEED,
};
