/**
 * @fileoverview ContextWindowManager — Tiered Context Management
 *
 * Manages a 4-tier context hierarchy derived from phi-geometric token budgets:
 *   working   ≈ 8,192   tokens  (active task context)
 *   session   ≈ 21,450  tokens  (current session accumulation)
 *   memory    ≈ 56,131  tokens  (long-term working memory)
 *   artifacts ≈ 146,920 tokens  (large-scale persistent artifacts)
 *
 * Compression fires at 1 - PSI_FOURTH ≈ 91% capacity.
 * Eviction scoring: importance×0.486 + recency×0.300 + relevance×0.214.
 * Context capsules enable inter-agent transfer.
 *
 * All constants derive from φ (golden ratio) or Fibonacci sequence.
 * Temperature = 0, seed = 42 for deterministic execution.
 *
 * @module core/context-window-manager
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  phiFusionWeights,
  phiBackoff,
  phiResourceWeights,
  phiMultiSplit,
  phiTokenBudgets,
  cslGate,
  cslBlend,
  sigmoid,
  adaptiveTemperature,
  POOL_ALLOCATION,
  PRESSURE_LEVELS,
  EVICTION_WEIGHTS,
  classifyPressure,
  phiPriorityScore,
  COHERENCE_DRIFT_THRESHOLD,
  phiAdaptiveInterval,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

const {
  RINGS,
  cosineSimilarity,
  geometricRoute,
  measureCoherence,
  assessCoherence,
  getAllNodes,
  findNodeRing,
} = require('../shared/sacred-geometry');

const {
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslCONSENSUS,
  cslPhiGATE,
  normalize,
  moeRoute,
  hdcRandomVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── DETERMINISTIC SEED ────────────────────────────────────────────────────────

/** Deterministic seed = fib(9) = 34 */
const SEED = fib(9);

/** Temperature sentinel = 0 */
const TEMPERATURE_ZERO = 0;

// ─── TIER DEFINITIONS ─────────────────────────────────────────────────────────

/**
 * Token budget structure from phi-geometric series (base = 8192).
 * @type {{ working: number, session: number, memory: number, artifacts: number }}
 */
const TIER_BUDGETS = Object.freeze(phiTokenBudgets(8192));

/**
 * Tier configuration: capacity, compression trigger, max entries.
 *
 * Compression fires at 1 - PSI_FOURTH ≈ 91% of capacity (ALERT_THRESHOLDS.exceeded).
 * Max entries per tier = phi-scaled Fibonacci numbers.
 */
const TIERS = Object.freeze({
  working:   {
    name:        'working',
    capacity:    TIER_BUDGETS.working,          // 8,192 tokens
    compressAt:  1 - PSI_FOURTH,               // ≈ 0.854 → fire at ~7,000 tokens
    maxEntries:  fib(9),                        // 34 entries
    evictBatch:  fib(4),                        // 3 at a time
    promoteTo:   'session',
    demoteFrom:  null,
  },
  session:   {
    name:        'session',
    capacity:    TIER_BUDGETS.session,          // 21,450 tokens
    compressAt:  1 - PSI_FOURTH,               // ≈ 0.854
    maxEntries:  fib(10),                       // 55 entries
    evictBatch:  fib(5),                        // 5 at a time
    promoteTo:   'memory',
    demoteFrom:  'working',
  },
  memory:    {
    name:        'memory',
    capacity:    TIER_BUDGETS.memory,           // 56,131 tokens
    compressAt:  1 - PSI_FOURTH,               // ≈ 0.854
    maxEntries:  fib(12),                       // 144 entries
    evictBatch:  fib(6),                        // 8 at a time
    promoteTo:   'artifacts',
    demoteFrom:  'session',
  },
  artifacts: {
    name:        'artifacts',
    capacity:    TIER_BUDGETS.artifacts,        // 146,920 tokens
    compressAt:  1 - PSI_FOURTH,               // ≈ 0.854
    maxEntries:  fib(14),                       // 377 entries
    evictBatch:  fib(7),                        // 13 at a time
    promoteTo:   null,
    demoteFrom:  'memory',
  },
});

/** Valid tier names in ascending capacity order */
const TIER_ORDER = ['working', 'session', 'memory', 'artifacts'];

// ─── ContextWindowManager CLASS ───────────────────────────────────────────────

/**
 * @class ContextWindowManager
 *
 * Manages 4-tier context hierarchy with phi-scaled capacities, compression,
 * eviction, and inter-agent context capsule transfer.
 *
 * @example
 * const cwm = new ContextWindowManager();
 * cwm.add({ text: 'result', tokens: 120, importance: 0.9 }, 'working');
 * const usage = cwm.getUsage();
 */
class ContextWindowManager {
  /**
   * @param {object} [options]
   * @param {number} [options.seed=34]         - Deterministic seed
   * @param {number} [options.temperature=0]   - Execution temperature
   * @param {boolean} [options.autoCompress=true] - Auto-compress on add
   */
  constructor(options = {}) {
    this._seed          = options.seed        ?? SEED;
    this._temperature   = options.temperature ?? TEMPERATURE_ZERO;
    this._autoCompress  = options.autoCompress ?? true;

    /**
     * Tier stores: tier name → Map<entryId, ContextEntry>
     * @type {Map<string, Map<string, object>>}
     */
    this._tiers = new Map(
      TIER_ORDER.map(t => [t, new Map()])
    );

    /**
     * Tier token counters.
     * @type {Map<string, number>}
     */
    this._tokenCounts = new Map(TIER_ORDER.map(t => [t, 0]));

    /** Entry counter for deterministic ID generation */
    this._entryCounter = 0;

    /** Compression log: last fib(7)=13 compression events */
    this._compressionLog = [];

    /** Eviction log: last fib(7)=13 eviction events */
    this._evictionLog = [];
  }

  // ─── ADD ─────────────────────────────────────────────────────────────────────

  /**
   * Add a context entry to a specific tier.
   *
   * Auto-compresses if the tier reaches 1 - PSI_FOURTH ≈ 85.4% capacity.
   *
   * @param {object} entry - Context entry
   * @param {string} entry.text       - Entry content (text or summary)
   * @param {number} [entry.tokens]   - Token count (estimated from text.length / 4 if omitted)
   * @param {number} [entry.importance=PSI]  - Importance score [0, 1]
   * @param {number} [entry.relevance=PSI_SQ] - Relevance score [0, 1]
   * @param {number[]} [entry.embedding]      - 384D embedding (optional)
   * @param {object} [entry.metadata]         - Arbitrary metadata
   * @param {string} [tier='working']         - Target tier
   * @returns {{ id: string, tier: string, tokens: number, evictionScore: number }}
   */
  add(entry, tier = 'working') {
    if (!TIERS[tier]) throw new Error(`Invalid tier: ${tier}. Must be one of: ${TIER_ORDER.join(', ')}`);

    const tokens = entry.tokens || Math.ceil((entry.text || '').length / fib(3));  // Rough: chars/4
    const id     = this._mintEntryId(entry);
    const now    = Date.now();

    const record = {
      id,
      tier,
      text:          entry.text || '',
      tokens,
      importance:    entry.importance ?? PSI,      // Default ψ ≈ 0.618
      recency:       1.0,                           // New = max recency
      relevance:     entry.relevance ?? PSI_SQ,    // Default ψ² ≈ 0.382
      embedding:     entry.embedding || null,
      metadata:      entry.metadata || {},
      addedAt:       now,
      lastAccessedAt: now,
      evictionScore: this._computeEvictionScore({
        importance: entry.importance ?? PSI,
        recency: 1.0,
        relevance: entry.relevance ?? PSI_SQ,
      }),
    };

    this._tiers.get(tier).set(id, record);
    this._tokenCounts.set(tier, this._tokenCounts.get(tier) + tokens);

    // Auto-compress if above threshold
    if (this._autoCompress) {
      const usage = this._tokenCounts.get(tier) / TIERS[tier].capacity;
      if (usage >= TIERS[tier].compressAt) {
        this.compress(tier);
      }
    }

    return { id, tier, tokens, evictionScore: record.evictionScore };
  }

  // ─── COMPRESS ────────────────────────────────────────────────────────────────

  /**
   * Compress a tier by summarizing low-priority entries.
   *
   * Compression strategy:
   * 1. Sort entries by eviction score (ascending = lowest priority first).
   * 2. Group the bottom PSI_SQ (38.2%) of entries by semantic similarity.
   * 3. Merge each group into a single summary entry.
   * 4. Replace original entries with the summary.
   *
   * @param {string} tier - Tier to compress
   * @returns {{
   *   compressed: number,
   *   tokensSaved: number,
   *   summaryCount: number
   * }}
   */
  compress(tier) {
    if (!TIERS[tier]) throw new Error(`Invalid tier: ${tier}`);

    const store    = this._tiers.get(tier);
    const entries  = Array.from(store.values());
    if (entries.length < fib(3)) return { compressed: 0, tokensSaved: 0, summaryCount: 0 };  // Need >= 2

    // Sort ascending by eviction score (lowest = first candidate for compression)
    entries.sort((a, b) => a.evictionScore - b.evictionScore);

    // Take bottom PSI_SQ (≈ 38.2%) fraction of entries
    const compressCount = Math.max(Math.floor(entries.length * PSI_SQ), fib(3) - 1);
    const candidates    = entries.slice(0, compressCount);

    if (candidates.length < fib(3) - 1) return { compressed: 0, tokensSaved: 0, summaryCount: 0 };

    // Group candidates into batches of fib(5)=5
    const batchSize   = fib(5);
    const batches     = [];
    for (let i = 0; i < candidates.length; i += batchSize) {
      batches.push(candidates.slice(i, i + batchSize));
    }

    let totalTokensSaved = 0;
    let summaryCount     = 0;

    for (const batch of batches) {
      const originalTokens = batch.reduce((s, e) => s + e.tokens, 0);
      // Summary token count = originalTokens × ψ² ≈ 38.2% of original
      const summaryTokens  = Math.max(Math.round(originalTokens * PSI_SQ), 1);
      const tokensSaved    = originalTokens - summaryTokens;

      // Build summary record
      const summaryText = `[SUMMARY:${tier}] ${batch.map(e => e.text.slice(0, fib(7))).join(' | ')}`;
      const summaryId   = this._mintEntryId({ text: summaryText });
      const now         = Date.now();

      // Aggregate importance/relevance using phi-fusion weights
      const weights       = phiFusionWeights(batch.length);
      const aggImportance = batch.reduce((s, e, i) => s + e.importance * weights[i], 0);
      const aggRelevance  = batch.reduce((s, e, i) => s + e.relevance  * weights[i], 0);

      const summary = {
        id:             summaryId,
        tier,
        text:           summaryText,
        tokens:         summaryTokens,
        importance:     aggImportance,
        recency:        batch[batch.length - 1].recency,  // Recency of newest in batch
        relevance:      aggRelevance,
        embedding:      null,
        metadata:       { compressed: true, originalCount: batch.length, originalIds: batch.map(e => e.id) },
        addedAt:        now,
        lastAccessedAt: now,
        evictionScore:  this._computeEvictionScore({
          importance: aggImportance,
          recency:    batch[batch.length - 1].recency,
          relevance:  aggRelevance,
        }),
      };

      // Remove originals and insert summary
      for (const e of batch) {
        store.delete(e.id);
      }
      store.set(summaryId, summary);

      this._tokenCounts.set(tier, this._tokenCounts.get(tier) - tokensSaved);
      totalTokensSaved += tokensSaved;
      summaryCount++;
    }

    const result = {
      tier,
      compressed: candidates.length,
      tokensSaved: totalTokensSaved,
      summaryCount,
    };

    this._compressionLog.push({ ...result, timestamp: Date.now() });
    if (this._compressionLog.length > fib(7)) this._compressionLog.shift();

    return result;
  }

  // ─── EVICT ───────────────────────────────────────────────────────────────────

  /**
   * Evict the lowest-scoring entries from a tier.
   *
   * Eviction scoring:
   *   score = importance × EVICTION_WEIGHTS.importance (≈ 0.486)
   *         + recency    × EVICTION_WEIGHTS.recency    (≈ 0.300)
   *         + relevance  × EVICTION_WEIGHTS.relevance  (≈ 0.214)
   *
   * Lower score = evict first.
   * Eviction batch size = TIERS[tier].evictBatch.
   * High-importance entries (importance > CSL_THRESHOLDS.HIGH ≈ 0.882) are protected.
   *
   * @param {string} tier - Tier to evict from
   * @returns {{
   *   evicted: number,
   *   tokensFreed: number,
   *   evictedIds: string[]
   * }}
   */
  evict(tier) {
    if (!TIERS[tier]) throw new Error(`Invalid tier: ${tier}`);

    const store    = this._tiers.get(tier);
    const entries  = Array.from(store.values());
    if (entries.length === 0) return { evicted: 0, tokensFreed: 0, evictedIds: [] };

    // Refresh recency scores before sorting
    const now = Date.now();
    for (const e of entries) {
      const ageMs      = now - e.lastAccessedAt;
      const maxAgeMs   = fib(17) * 1000;            // 1597s max age for recency decay
      e.recency        = Math.max(0, 1 - ageMs / maxAgeMs);
      e.evictionScore  = this._computeEvictionScore(e);
    }

    // Sort ascending (lowest score evicted first)
    entries.sort((a, b) => a.evictionScore - b.evictionScore);

    // Protect high-importance entries
    const evictable = entries.filter(e => e.importance < CSL_THRESHOLDS.HIGH);  // ≈ 0.882
    const batchSize  = TIERS[tier].evictBatch;
    const toEvict    = evictable.slice(0, batchSize);

    let tokensFreed = 0;
    const evictedIds = [];

    for (const e of toEvict) {
      store.delete(e.id);
      tokensFreed += e.tokens;
      evictedIds.push(e.id);
    }

    this._tokenCounts.set(tier, this._tokenCounts.get(tier) - tokensFreed);

    const result = { tier, evicted: toEvict.length, tokensFreed, evictedIds };
    this._evictionLog.push({ ...result, timestamp: Date.now() });
    if (this._evictionLog.length > fib(7)) this._evictionLog.shift();

    return result;
  }

  // ─── CREATE CAPSULE ──────────────────────────────────────────────────────────

  /**
   * Create a transferable context capsule for inter-agent handoff.
   *
   * Capsule structure:
   * - Header: session metadata, capsule hash, timestamp
   * - Core: top-K entries by eviction score from specified tiers
   * - Summary: compressed snapshot of remaining context
   * - Signature: SHA-256 of capsule content
   *
   * @param {object} [options]
   * @param {string[]} [options.tiers=['working','session']] - Tiers to include
   * @param {number} [options.topK=fib(5)]       - Max entries per tier (default fib(5)=5)
   * @param {boolean} [options.includeEmbeddings=false] - Include embeddings
   * @param {object} [options.metadata]           - Extra metadata
   * @returns {{
   *   capsuleId: string,
   *   header: object,
   *   entries: object[],
   *   summary: object,
   *   signature: string,
   *   totalTokens: number
   * }}
   */
  createCapsule(options = {}) {
    const {
      tiers            = ['working', 'session'],
      topK             = fib(5),                  // 5
      includeEmbeddings = false,
      metadata         = {},
    } = options;

    const now    = Date.now();
    const entries = [];

    for (const tier of tiers) {
      if (!TIERS[tier]) continue;
      const store     = this._tiers.get(tier);
      const all       = Array.from(store.values());

      // Sort descending by eviction score (most valuable first)
      all.sort((a, b) => b.evictionScore - a.evictionScore);
      const selected = all.slice(0, topK);

      for (const e of selected) {
        entries.push({
          id:          e.id,
          tier:        e.tier,
          text:        e.text,
          tokens:      e.tokens,
          importance:  e.importance,
          relevance:   e.relevance,
          recency:     e.recency,
          evictionScore: e.evictionScore,
          metadata:    e.metadata,
          embedding:   includeEmbeddings ? e.embedding : undefined,
        });
      }
    }

    const totalTokens  = entries.reduce((s, e) => s + e.tokens, 0);
    const summaryText  = `Capsule: ${entries.length} entries, ${totalTokens} tokens from tiers: ${tiers.join(',')}`;

    const content  = JSON.stringify({ entries, metadata, now });
    const signature = crypto.createHash('sha256').update(content).digest('hex').slice(0, fib(8));  // 21 chars

    const capsuleId = crypto.createHash('sha256')
      .update(`${this._seed}:capsule:${now}`)
      .digest('hex')
      .slice(0, fib(7));  // 13 chars

    return {
      capsuleId,
      header: {
        createdAt:   now,
        tiers,
        entryCount:  entries.length,
        totalTokens,
        metadata,
      },
      entries,
      summary: {
        text:   summaryText,
        tokens: Math.ceil(summaryText.length / fib(3)),
      },
      signature,
      totalTokens,
    };
  }

  // ─── RETRIEVE FROM MEMORY ─────────────────────────────────────────────────────

  /**
   * Retrieve top-K most relevant entries from the memory tier using
   * cosine similarity against a query embedding.
   *
   * Only entries with embeddings can be scored by similarity; entries
   * without embeddings are ranked by eviction score as fallback.
   *
   * @param {number[]} queryEmbedding - 384D query embedding
   * @param {number} [topK=fib(5)]    - Number of results (default fib(5)=5)
   * @param {number} [threshold=PSI]  - Minimum similarity threshold (default PSI≈0.618)
   * @returns {Array<{
   *   entry: object,
   *   similarity: number,
   *   rank: number
   * }>}
   */
  retrieveFromMemory(queryEmbedding, topK = fib(5), threshold = PSI) {
    const store   = this._tiers.get('memory');
    const entries = Array.from(store.values());
    const now     = Date.now();

    const scored = entries.map(e => {
      let similarity;
      if (e.embedding && e.embedding.length === queryEmbedding.length) {
        similarity = cosineSimilarity(queryEmbedding, e.embedding);
      } else {
        // Fallback: use eviction score as proxy for relevance
        similarity = e.evictionScore;
      }

      // Update last-accessed time
      e.lastAccessedAt = now;

      return { entry: e, similarity };
    });

    // Filter by threshold and sort descending
    const filtered = scored.filter(s => s.similarity >= threshold);
    filtered.sort((a, b) => b.similarity - a.similarity);

    const results = filtered.slice(0, topK).map((s, idx) => ({
      entry:      s.entry,
      similarity: s.similarity,
      rank:       idx + 1,
    }));

    return results;
  }

  // ─── GET USAGE ───────────────────────────────────────────────────────────────

  /**
   * Return current usage statistics for all tiers.
   *
   * @returns {{
   *   tiers: object,
   *   totalTokens: number,
   *   totalEntries: number,
   *   pressure: string
   * }}
   */
  getUsage() {
    const tierStats = {};
    let totalTokens  = 0;
    let totalEntries = 0;

    for (const tierName of TIER_ORDER) {
      const store    = this._tiers.get(tierName);
      const tokens   = this._tokenCounts.get(tierName);
      const capacity = TIERS[tierName].capacity;
      const ratio    = tokens / capacity;

      tierStats[tierName] = {
        tokens,
        capacity,
        entries:     store.size,
        maxEntries:  TIERS[tierName].maxEntries,
        ratio:       Number(ratio.toFixed(fib(3))),
        pressure:    classifyPressure(ratio),
        compressAt:  TIERS[tierName].compressAt,
        shouldCompress: ratio >= TIERS[tierName].compressAt,
      };

      totalTokens  += tokens;
      totalEntries += store.size;
    }

    const overallRatio = totalTokens / TIER_BUDGETS.artifacts;

    return {
      tiers: tierStats,
      totalTokens,
      totalEntries,
      pressure: classifyPressure(overallRatio),
    };
  }

  // ─── TIER PROMOTION / DEMOTION ────────────────────────────────────────────────

  /**
   * Promote an entry from its current tier to the next higher tier.
   * Promotion is triggered by high eviction score (very valuable content).
   *
   * @param {string} entryId - Entry ID to promote
   * @param {string} fromTier - Source tier
   * @returns {boolean} true if promoted successfully
   */
  promote(entryId, fromTier) {
    if (!TIERS[fromTier]) return false;
    const toTier = TIERS[fromTier].promoteTo;
    if (!toTier) return false;  // Already at artifacts

    const store  = this._tiers.get(fromTier);
    const entry  = store.get(entryId);
    if (!entry) return false;

    // Only promote if eviction score ≥ CSL_THRESHOLDS.HIGH ≈ 0.882
    if (entry.evictionScore < CSL_THRESHOLDS.HIGH) return false;

    // Move to higher tier
    store.delete(entryId);
    this._tokenCounts.set(fromTier, this._tokenCounts.get(fromTier) - entry.tokens);

    const updated = { ...entry, tier: toTier };
    this._tiers.get(toTier).set(entryId, updated);
    this._tokenCounts.set(toTier, this._tokenCounts.get(toTier) + entry.tokens);

    return true;
  }

  /**
   * Demote an entry from its current tier to the next lower tier.
   * Triggered by low eviction score (stale or low-value content).
   *
   * @param {string} entryId - Entry ID to demote
   * @param {string} fromTier - Source tier
   * @returns {boolean} true if demoted successfully
   */
  demote(entryId, fromTier) {
    if (!TIERS[fromTier]) return false;
    const toTier = TIERS[fromTier].demoteFrom;  // Demotion goes to lower tier
    if (!toTier) return false;  // Already at working

    const store = this._tiers.get(fromTier);
    const entry = store.get(entryId);
    if (!entry) return false;

    // Only demote if eviction score < CSL_THRESHOLDS.LOW ≈ 0.691
    if (entry.evictionScore >= CSL_THRESHOLDS.LOW) return false;

    store.delete(entryId);
    this._tokenCounts.set(fromTier, this._tokenCounts.get(fromTier) - entry.tokens);

    const updated = { ...entry, tier: toTier };
    this._tiers.get(toTier).set(entryId, updated);
    this._tokenCounts.set(toTier, this._tokenCounts.get(toTier) + entry.tokens);

    return true;
  }

  // ─── PRIVATE HELPERS ─────────────────────────────────────────────────────────

  /**
   * Compute eviction score for an entry.
   * score = importance × EVICTION_WEIGHTS.importance
   *       + recency    × EVICTION_WEIGHTS.recency
   *       + relevance  × EVICTION_WEIGHTS.relevance
   *
   * Higher score = more valuable = kept longer.
   *
   * @param {{ importance: number, recency: number, relevance: number }} factors
   * @returns {number} Eviction score ∈ [0, 1]
   * @private
   */
  _computeEvictionScore({ importance, recency, relevance }) {
    return (
      importance * EVICTION_WEIGHTS.importance  +  // ≈ 0.486
      recency    * EVICTION_WEIGHTS.recency     +  // ≈ 0.300
      relevance  * EVICTION_WEIGHTS.relevance      // ≈ 0.214
    );
  }

  /**
   * Mint deterministic entry ID using SHA-256.
   * @param {object} entry
   * @returns {string} 8-char hex (fib(6))
   * @private
   */
  _mintEntryId(entry) {
    const n = ++this._entryCounter;
    return crypto.createHash('sha256')
      .update(`${this._seed}:entry:${n}:${(entry.text || '').slice(0, fib(9))}`)
      .digest('hex')
      .slice(0, fib(6));  // 8 chars
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  ContextWindowManager,
  TIER_BUDGETS,
  TIERS,
  TIER_ORDER,
  SEED,
};
