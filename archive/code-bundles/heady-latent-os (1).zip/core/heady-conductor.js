/**
 * @fileoverview HeadyConductor — Central Orchestration Hub
 *
 * The HeadyConductor is the central dispatcher for the Heady Latent OS.
 * It classifies incoming tasks, routes them to the correct resource pool,
 * and drives execution through the 8-stage HCFullPipeline (HCFP).
 *
 * All constants derive from φ (golden ratio) or Fibonacci sequence.
 * Temperature = 0, seed = 42 for deterministic execution.
 *
 * @module core/heady-conductor
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  phiFusionWeights,
  phiBackoff,
  phiResourceWeights,
  phiMultiSplit,
  phiTokenBudgets,
  cslGate,
  cslBlend,
  sigmoid,
  adaptiveTemperature,
  POOL_ALLOCATION,
  PRESSURE_LEVELS,
  EVICTION_WEIGHTS,
  classifyPressure,
  phiPriorityScore,
  COHERENCE_DRIFT_THRESHOLD,
  phiAdaptiveInterval,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

const {
  RINGS,
  cosineSimilarity,
  geometricRoute,
  measureCoherence,
  assessCoherence,
  getAllNodes,
  findNodeRing,
} = require('../shared/sacred-geometry');

const {
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslCONSENSUS,
  cslPhiGATE,
  normalize,
  moeRoute,
  hdcRandomVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── DETERMINISTIC SEED ────────────────────────────────────────────────────────

/** Deterministic seed for all random operations */
const SEED = fib(9);  // 34 — chosen for phi-alignment (fib(9) = 34)

/** Temperature = 0 sentinel (functional temperature = PSI_CUBE for gates) */
const TEMPERATURE_ZERO = 0;

// ─── POOL SIZES (Fibonacci) ────────────────────────────────────────────────────

/**
 * Pool capacities derived from Fibonacci numbers.
 * Hot=fib(9)=34, Warm=fib(8)=21, Cold=fib(7)=13, Reserve=fib(6)=8, Gov=fib(5)=5
 */
const POOL_SIZES = Object.freeze({
  HOT:        fib(9),   // 34
  WARM:       fib(8),   // 21
  COLD:       fib(7),   // 13
  RESERVE:    fib(6),   // 8
  GOVERNANCE: fib(5),   // 5
});

/**
 * Pool timeouts in milliseconds derived from Fibonacci numbers.
 * Hot=fib(9)*1000=34s, Warm=fib(14)*1000=377s, Cold=fib(17)*1000=1597s
 */
const POOL_TIMEOUTS = Object.freeze({
  HOT:        fib(9)  * 1000,   // 34,000 ms  — 34s
  WARM:       fib(14) * 1000,   // 377,000 ms — 377s
  COLD:       fib(17) * 1000,   // 1,597,000 ms — 1597s
  RESERVE:    fib(19) * 1000,   // 4,181,000 ms — fallback
  GOVERNANCE: fib(20) * 1000,   // 6,765,000 ms — governance timeout
});

// ─── TASK DOMAINS ──────────────────────────────────────────────────────────────

/**
 * Task domain taxonomy — 12 domains covering all workloads.
 * Ordered by urgency (hot → cold) using phi-harmonic priority.
 * @type {string[]}
 */
const TASK_DOMAINS = Object.freeze([
  'code',           // Active coding, debugging
  'review',         // Code review, PR analysis
  'security',       // Vulnerability scanning, threat analysis
  'architecture',   // System design, ADRs
  'research',       // Deep information retrieval
  'docs',           // Documentation generation
  'creative',       // Creative writing, brainstorming
  'translation',    // Language translation
  'monitoring',     // System health checks
  'cleanup',        // Maintenance, refactoring
  'analytics',      // Data analysis, reporting
  'maintenance',    // Background upkeep tasks
]);

/**
 * Domain-to-pool mapping: assigns each domain to HOT/WARM/COLD tier.
 * Derives urgency from domain semantic priority.
 */
const DOMAIN_POOL_MAP = Object.freeze({
  code:         'HOT',
  review:       'HOT',
  security:     'HOT',
  architecture: 'WARM',
  research:     'WARM',
  docs:         'WARM',
  creative:     'WARM',
  translation:  'COLD',
  monitoring:   'HOT',
  cleanup:      'COLD',
  analytics:    'COLD',
  maintenance:  'COLD',
});

// ─── HCFP PIPELINE STAGES ──────────────────────────────────────────────────────

/**
 * 8-stage HCFullPipeline (HCFP) stage names.
 * Each stage is phi-timed and checkpointed.
 */
const HCFP_STAGES = Object.freeze([
  'contextAssembly',       // 1 — Gather task context, embeddings
  'intentClassification',  // 2 — Classify domain and intent
  'nodeSelection',         // 3 — Select optimal swarm nodes via CSL
  'execution',             // 4 — Dispatch to selected nodes
  'qualityGate',           // 5 — Validate output quality via cslPhiGATE
  'assuranceGate',         // 6 — Cross-check via HeadyAssure
  'patternCapture',        // 7 — Extract reusable patterns
  'storyUpdate',           // 8 — Update knowledge graph / story
]);

// ─── GATE VECTORS (deterministic) ─────────────────────────────────────────────

/**
 * Build a deterministic gate vector for a domain by seeding with
 * a SHA-256 hash of the domain name + SEED.
 * @param {string} domain
 * @returns {number[]} Normalized 384D gate vector
 */
function buildDomainGateVector(domain) {
  const hash = crypto.createHash('sha256')
    .update(`${domain}:${SEED}`)
    .digest();
  const v = new Array(EMBEDDING_DIM);
  for (let i = 0; i < EMBEDDING_DIM; i++) {
    // Map byte value to [-1, 1] using phi-scaled normalization
    v[i] = ((hash[i % hash.length] / fib(7)) - PSI) * PHI;
  }
  return normalize(v);
}

/** Pre-computed gate vectors for all domains */
const DOMAIN_GATE_VECTORS = Object.freeze(
  Object.fromEntries(TASK_DOMAINS.map(d => [d, buildDomainGateVector(d)]))
);

// ─── HeadyConductor CLASS ──────────────────────────────────────────────────────

/**
 * @class HeadyConductor
 * @extends EventEmitter
 *
 * Central orchestration hub for the Heady Latent OS.
 * Routes tasks through phi-scaled resource pools and the HCFP pipeline.
 *
 * @fires HeadyConductor#task:classified
 * @fires HeadyConductor#task:routed
 * @fires HeadyConductor#pipeline:stage
 * @fires HeadyConductor#pipeline:complete
 * @fires HeadyConductor#pool:pressure
 */
class HeadyConductor extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.seed=42]     - Deterministic seed
   * @param {number} [options.temperature=0] - Execution temperature
   */
  constructor(options = {}) {
    super();
    this._seed        = options.seed        ?? SEED;
    this._temperature = options.temperature ?? TEMPERATURE_ZERO;

    /** @type {Map<string, {active: number, capacity: number, queue: any[]}>} */
    this._pools = new Map(
      Object.entries(POOL_SIZES).map(([name, cap]) => [
        name,
        { active: 0, capacity: cap, queue: [], timeoutMs: POOL_TIMEOUTS[name] },
      ])
    );

    /** @type {Map<string, object>} Running task registry */
    this._activeTasks = new Map();

    /** @type {number} Monotonically increasing task counter */
    this._taskCounter = 0;
  }

  // ─── CLASSIFY ───────────────────────────────────────────────────────────────

  /**
   * Classify a task into one of the 12 domains using CSL cosine similarity
   * against pre-computed domain gate vectors.
   *
   * @param {object} task - Task descriptor
   * @param {string} task.prompt    - Natural language description
   * @param {number[]} [task.embedding] - Pre-computed 384D embedding (optional)
   * @returns {{ domain: string, confidence: number, pool: string }}
   */
  classify(task) {
    const embedding = task.embedding || this._embedTask(task.prompt || '');

    let bestDomain = TASK_DOMAINS[0];
    let bestScore  = -Infinity;

    for (const domain of TASK_DOMAINS) {
      const gateVec = DOMAIN_GATE_VECTORS[domain];
      const raw     = cosineSimilarity(embedding, gateVec);
      // Apply cslPhiGATE at MEDIUM threshold level (2)
      const gated   = cslPhiGATE(raw, raw, 2);
      if (gated > bestScore) {
        bestScore  = gated;
        bestDomain = domain;
      }
    }

    const pool       = DOMAIN_POOL_MAP[bestDomain];
    const confidence = Math.max(0, Math.min(1, bestScore));

    const result = { domain: bestDomain, confidence, pool };

    /**
     * @event HeadyConductor#task:classified
     * @type {object}
     */
    this.emit('task:classified', { task, result });
    return result;
  }

  // ─── ROUTE ──────────────────────────────────────────────────────────────────

  /**
   * Route a task to its target pool, respecting pressure levels and capacity.
   * Falls back through HOT → WARM → COLD → RESERVE under pressure.
   *
   * @param {object} task - Task descriptor with optional `.domain` and `.pool`
   * @returns {{ pool: string, slot: number, pressure: string, route: string[] }}
   */
  route(task) {
    const { domain, pool: preferredPool } = task.classification
      || this.classify(task);

    const pressure = this._poolPressure(preferredPool);
    let targetPool = preferredPool;

    // Overflow routing under CRITICAL pressure
    if (pressure === 'CRITICAL') {
      const fallback = { HOT: 'WARM', WARM: 'COLD', COLD: 'RESERVE', RESERVE: 'GOVERNANCE' };
      targetPool = fallback[preferredPool] || 'RESERVE';
    }

    const poolState = this._pools.get(targetPool);
    const slot      = poolState.active;
    poolState.active = Math.min(poolState.active + 1, poolState.capacity);

    const route = geometricRoute('HeadyConductor', RINGS.INNER.nodes[0]);

    /**
     * @event HeadyConductor#task:routed
     * @type {object}
     */
    this.emit('task:routed', { task, targetPool, pressure, slot });

    return { pool: targetPool, slot, pressure, route };
  }

  // ─── EXECUTE HCFP ───────────────────────────────────────────────────────────

  /**
   * Execute the full 8-stage HCFullPipeline (HCFP) for a task.
   * Each stage emits a `pipeline:stage` event with timing and result.
   *
   * @param {object} task - Task descriptor
   * @returns {Promise<{ taskId: string, stages: object[], result: any }>}
   */
  async executeHCFP(task) {
    const taskId = this._mintTaskId(task);
    const stages = [];
    let context  = { task, taskId, embedding: null, nodes: [], output: null };

    this._activeTasks.set(taskId, { taskId, startedAt: Date.now(), stages });

    for (let i = 0; i < HCFP_STAGES.length; i++) {
      const stageName = HCFP_STAGES[i];
      const stageStart = Date.now();

      try {
        context = await this._runStage(stageName, context, i);
      } catch (err) {
        const stageRecord = {
          stage: stageName, index: i, error: err.message,
          durationMs: Date.now() - stageStart, success: false,
        };
        stages.push(stageRecord);
        this.emit('pipeline:stage', stageRecord);
        break;
      }

      const stageRecord = {
        stage: stageName, index: i,
        durationMs: Date.now() - stageStart,
        success: true,
        // Phi-weighted quality score for the stage
        qualityScore: phiPriorityScore(
          context.coherence ?? PSI,
          context.confidence ?? PSI_SQ,
          context.completeness ?? PSI_CUBE
        ),
      };
      stages.push(stageRecord);

      /**
       * @event HeadyConductor#pipeline:stage
       * @type {object}
       */
      this.emit('pipeline:stage', stageRecord);
    }

    // Release pool slot
    const routing = task.routing;
    if (routing) {
      const poolState = this._pools.get(routing.pool);
      if (poolState) poolState.active = Math.max(0, poolState.active - 1);
    }

    this._activeTasks.delete(taskId);

    const pipelineResult = { taskId, stages, result: context.output };

    /**
     * @event HeadyConductor#pipeline:complete
     * @type {object}
     */
    this.emit('pipeline:complete', pipelineResult);
    return pipelineResult;
  }

  // ─── GET POOL STATUS ─────────────────────────────────────────────────────────

  /**
   * Return current status of all resource pools.
   *
   * @returns {object} Pool status map
   */
  getPoolStatus() {
    const status = {};
    for (const [name, state] of this._pools) {
      const ratio    = state.active / state.capacity;
      const pressure = classifyPressure(ratio);
      status[name] = {
        active:     state.active,
        capacity:   state.capacity,
        available:  state.capacity - state.active,
        ratio:      Number(ratio.toFixed(fib(3))),  // 3 decimal places = fib(3)-1? use 3
        pressure,
        timeoutMs:  state.timeoutMs,
        queueDepth: state.queue.length,
      };
    }

    /**
     * @event HeadyConductor#pool:pressure
     * @type {object}
     */
    this.emit('pool:pressure', status);
    return status;
  }

  // ─── PRIVATE METHODS ─────────────────────────────────────────────────────────

  /**
   * Mint a deterministic task ID using SHA-256.
   * @param {object} task
   * @returns {string} 16-char hex prefix of SHA-256
   * @private
   */
  _mintTaskId(task) {
    const n = ++this._taskCounter;
    const input = `${this._seed}:${n}:${task.prompt || task.id || ''}`;
    return crypto.createHash('sha256').update(input).digest('hex').slice(0, fib(8));
    // fib(8) = 21 chars
  }

  /**
   * Produce a deterministic 384D embedding for a text prompt.
   * Uses SHA-256 rolling hash — deterministic, no external model.
   * @param {string} text
   * @returns {number[]}
   * @private
   */
  _embedTask(text) {
    const v = new Array(EMBEDDING_DIM);
    const hash = crypto.createHash('sha256').update(`${this._seed}:${text}`).digest();
    for (let i = 0; i < EMBEDDING_DIM; i++) {
      v[i] = ((hash[i % hash.length] / fib(7)) - PSI) * PHI;
    }
    return normalize(v);
  }

  /**
   * Compute pool pressure level.
   * @param {string} poolName
   * @returns {string} NOMINAL | ELEVATED | HIGH | CRITICAL
   * @private
   */
  _poolPressure(poolName) {
    const state = this._pools.get(poolName);
    if (!state) return 'NOMINAL';
    return classifyPressure(state.active / state.capacity);
  }

  /**
   * Execute a single HCFP stage.
   * @param {string} stageName
   * @param {object} ctx - Current pipeline context
   * @param {number} stageIdx - 0-based stage index
   * @returns {Promise<object>} Updated context
   * @private
   */
  async _runStage(stageName, ctx, stageIdx) {
    switch (stageName) {
      case 'contextAssembly': {
        ctx.embedding    = ctx.task.embedding || this._embedTask(ctx.task.prompt || '');
        ctx.assembled    = true;
        ctx.completeness = PSI;   // ψ ≈ 0.618 baseline
        return ctx;
      }
      case 'intentClassification': {
        const cls        = this.classify({ ...ctx.task, embedding: ctx.embedding });
        ctx.domain       = cls.domain;
        ctx.confidence   = cls.confidence;
        ctx.pool         = cls.pool;
        ctx.classification = cls;
        return ctx;
      }
      case 'nodeSelection': {
        // Select top fib(3)=2 nodes via MoE from all swarm nodes
        const allNodes   = getAllNodes();
        const gateVecs   = allNodes.map(n => buildDomainGateVector(n));
        const topExperts = moeRoute(ctx.embedding, gateVecs, fib(3), PSI_CUBE);
        ctx.nodes        = topExperts.map(e => ({
          name:   allNodes[e.expertIdx],
          weight: e.weight,
        }));
        return ctx;
      }
      case 'execution': {
        // Simulate deterministic execution; real impl dispatches to agents
        ctx.output      = { status: 'executed', taskId: ctx.taskId, domain: ctx.domain };
        ctx.coherence   = PSI;   // Baseline coherence
        return ctx;
      }
      case 'qualityGate': {
        // Gate output quality using cslPhiGATE at HIGH threshold
        const cosScore   = ctx.confidence || PSI_SQ;
        const gated      = cslPhiGATE(cosScore, cosScore, fib(3)); // level=fib(3)=2 → MEDIUM
        ctx.qualityPassed = gated >= CSL_THRESHOLDS.LOW;
        ctx.qualityScore  = gated;
        return ctx;
      }
      case 'assuranceGate': {
        // Cross-check: phi-weighted blend of quality + coherence
        const assuranceScore = cslBlend(
          ctx.qualityScore || PSI_SQ,
          PSI_CUBE,
          ctx.confidence || PSI_SQ,
          CSL_THRESHOLDS.MEDIUM
        );
        ctx.assurancePassed = assuranceScore >= CSL_THRESHOLDS.LOW;
        ctx.assuranceScore  = assuranceScore;
        return ctx;
      }
      case 'patternCapture': {
        // Hash output for pattern dedup
        ctx.patternHash = crypto
          .createHash('sha256')
          .update(JSON.stringify(ctx.output || ''))
          .digest('hex')
          .slice(0, fib(7));   // fib(7)=13 char hash
        ctx.patternCaptured = true;
        return ctx;
      }
      case 'storyUpdate': {
        // Append to story log (in-memory; real impl writes to HeadyMC)
        ctx.storyEntry = {
          taskId:    ctx.taskId,
          domain:    ctx.domain,
          pattern:   ctx.patternHash,
          timestamp: Date.now(),
          quality:   ctx.qualityScore,
        };
        ctx.storyUpdated = true;
        return ctx;
      }
      default:
        throw new Error(`Unknown HCFP stage: ${stageName}`);
    }
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  HeadyConductor,
  POOL_SIZES,
  POOL_TIMEOUTS,
  TASK_DOMAINS,
  DOMAIN_POOL_MAP,
  HCFP_STAGES,
  DOMAIN_GATE_VECTORS,
  SEED,
};
