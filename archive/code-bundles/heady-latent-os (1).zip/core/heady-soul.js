/**
 * @fileoverview HeadySoul — Awareness & Values Guardian
 *
 * HeadySoul is the constitutional core of the Heady Latent OS. It enforces
 * the 3 Unbreakable Laws, monitors semantic coherence across all swarm nodes,
 * detects drift, and triggers self-healing when the swarm drifts below the
 * COHERENCE_DRIFT_THRESHOLD (≈ 0.809 = 1 - ψ² × 0.5 = CSL_THRESHOLDS.MEDIUM).
 *
 * All constants derive from φ (golden ratio) or Fibonacci sequence.
 * Temperature = 0, seed = 42 for deterministic execution.
 *
 * @module core/heady-soul
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
  phiFusionWeights,
  phiBackoff,
  phiResourceWeights,
  phiMultiSplit,
  phiTokenBudgets,
  cslGate,
  cslBlend,
  sigmoid,
  adaptiveTemperature,
  POOL_ALLOCATION,
  PRESSURE_LEVELS,
  EVICTION_WEIGHTS,
  classifyPressure,
  phiPriorityScore,
  COHERENCE_DRIFT_THRESHOLD,
  phiAdaptiveInterval,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

const {
  RINGS,
  cosineSimilarity,
  geometricRoute,
  measureCoherence,
  assessCoherence,
  getAllNodes,
  findNodeRing,
} = require('../shared/sacred-geometry');

const {
  cslAND,
  cslOR,
  cslNOT,
  cslIMPLY,
  cslCONSENSUS,
  cslPhiGATE,
  normalize,
  moeRoute,
  hdcRandomVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── DETERMINISTIC SEED ────────────────────────────────────────────────────────

/** Deterministic seed = fib(9) = 34 */
const SEED = fib(9);

/** Temperature sentinel = 0 (gate temperature = PSI_CUBE) */
const TEMPERATURE_ZERO = 0;

// ─── THE 3 UNBREAKABLE LAWS ────────────────────────────────────────────────────

/**
 * The 3 Unbreakable Laws of HeadySoul.
 * Laws are ordered by phi-fusion weight: structuralIntegrity receives the highest
 * weight (ψ⁰/Σ ≈ 0.545), semanticCoherence second (ψ¹/Σ ≈ 0.337),
 * missionAlignment third (ψ²/Σ ≈ 0.208).
 *
 * @enum {string}
 */
const UNBREAKABLE_LAWS = Object.freeze({
  structuralIntegrity:  'structuralIntegrity',   // Law 1 — weight ≈ 0.545
  semanticCoherence:    'semanticCoherence',      // Law 2 — weight ≈ 0.337
  missionAlignment:     'missionAlignment',       // Law 3 — weight ≈ 0.208 (but using 3-way phiFusionWeights)
});

/**
 * Phi-fusion weights for the 3 laws (sum to 1.0).
 * [w0, w1, w2] = phiFusionWeights(3) ≈ [0.545, 0.337, 0.208] using ψ-series.
 * Mapped to laws in priority order: structuralIntegrity, semanticCoherence, missionAlignment.
 */
const LAW_WEIGHTS = Object.freeze(
  (() => {
    const w = phiFusionWeights(3);
    return {
      [UNBREAKABLE_LAWS.structuralIntegrity]: w[0],
      [UNBREAKABLE_LAWS.semanticCoherence]:   w[1],
      [UNBREAKABLE_LAWS.missionAlignment]:    w[2],
    };
  })()
);

// ─── MISSION EMBEDDING ─────────────────────────────────────────────────────────

/**
 * Deterministic 384D mission embedding for HeadyConnection.
 * Derived from SHA-256 hash of the mission statement + SEED.
 * Represents: "empower cannabis community through transparent information,
 *              authentic reviews, phi-scaled recommendations."
 *
 * @returns {number[]} Normalized 384D mission embedding
 */
function buildMissionEmbedding() {
  const MISSION_STATEMENT = 'HeadyConnection: empower cannabis community transparent phi-scaled';
  const hash = crypto.createHash('sha256')
    .update(`${SEED}:${MISSION_STATEMENT}`)
    .digest();
  const v = new Array(EMBEDDING_DIM);
  for (let i = 0; i < EMBEDDING_DIM; i++) {
    // Scale hash bytes to [-1, 1] using phi-normalization
    v[i] = ((hash[i % hash.length] / fib(7)) - PSI) * PHI;
  }
  return normalize(v);
}

/** Pre-computed HeadyConnection mission embedding (deterministic) */
const MISSION_EMBEDDING = Object.freeze(buildMissionEmbedding());

// ─── HEARTBEAT CONFIG ──────────────────────────────────────────────────────────

/**
 * Base heartbeat interval = fib(14) * 1000 = 377,000 ms ≈ 6.28 min.
 * phi-adaptive: healthy → grows toward fib(14) * PHI_CUBE ≈ 1.6s,
 *               unhealthy → shrinks to fib(14) * PSI ≈ 3.87 min.
 */
const HEARTBEAT_BASE_MS = fib(14) * 1000;  // 377,000 ms

// ─── HeadySoul CLASS ──────────────────────────────────────────────────────────

/**
 * @class HeadySoul
 * @extends EventEmitter
 *
 * Awareness and values guardian for the Heady Latent OS.
 * Enforces the 3 Unbreakable Laws, monitors coherence across swarm nodes,
 * detects semantic drift, and triggers self-healing.
 *
 * @fires HeadySoul#law:evaluated
 * @fires HeadySoul#mutation:validated
 * @fires HeadySoul#coherence:measured
 * @fires HeadySoul#drift:detected
 * @fires HeadySoul#healing:triggered
 * @fires HeadySoul#heartbeat
 */
class HeadySoul extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.seed=34]         - Deterministic seed (fib(9))
   * @param {number} [options.temperature=0]   - Execution temperature
   * @param {number} [options.heartbeatMs=377000] - Heartbeat base interval (fib(14)*1000)
   */
  constructor(options = {}) {
    super();
    this._seed            = options.seed        ?? SEED;
    this._temperature     = options.temperature ?? TEMPERATURE_ZERO;
    this._heartbeatMs     = options.heartbeatMs ?? HEARTBEAT_BASE_MS;
    this._currentInterval = this._heartbeatMs;
    this._heartbeatTimer  = null;

    /**
     * Node embedding registry: Map<nodeName, number[]>
     * Updated by re-embedding during heartbeat checks.
     * @type {Map<string, number[]>}
     */
    this._nodeEmbeddings = new Map();

    /**
     * Coherence history ring buffer — last fib(7)=13 readings.
     * @type {number[]}
     */
    this._coherenceHistory = [];

    /**
     * Mutation audit log — last fib(10)=55 evaluations.
     * @type {Array<{hash: string, result: object, timestamp: number}>}
     */
    this._mutationLog = [];

    /** Healing attempt counter (resets on full recovery) */
    this._healingAttempts = 0;

    this._buildLawEmbeddings();
  }

  // ─── PRIVATE: LAW EMBEDDING CONSTRUCTION ─────────────────────────────────────

  /**
   * Build deterministic 384D embedding for each law.
   * Used to evaluate mutations against law semantics.
   * @private
   */
  _buildLawEmbeddings() {
    /** @type {Map<string, number[]>} */
    this._lawEmbeddings = new Map();

    const LAW_PHRASES = {
      [UNBREAKABLE_LAWS.structuralIntegrity]:
        'structural integrity consistency format schema type constraint preservation',
      [UNBREAKABLE_LAWS.semanticCoherence]:
        'semantic coherence meaning alignment phi cosine similarity drift',
      [UNBREAKABLE_LAWS.missionAlignment]:
        'mission alignment HeadyConnection cannabis community phi golden purpose',
    };

    for (const [law, phrase] of Object.entries(LAW_PHRASES)) {
      const hash = crypto.createHash('sha256')
        .update(`${this._seed}:law:${law}:${phrase}`)
        .digest();
      const v = new Array(EMBEDDING_DIM);
      for (let i = 0; i < EMBEDDING_DIM; i++) {
        v[i] = ((hash[i % hash.length] / fib(7)) - PSI) * PHI;
      }
      this._lawEmbeddings.set(law, normalize(v));
    }
  }

  /**
   * Embed arbitrary text deterministically using SHA-256 rolling hash.
   * @param {string} text
   * @returns {number[]} Normalized 384D embedding
   * @private
   */
  _embed(text) {
    const hash = crypto.createHash('sha256')
      .update(`${this._seed}:${text}`)
      .digest();
    const v = new Array(EMBEDDING_DIM);
    for (let i = 0; i < EMBEDDING_DIM; i++) {
      v[i] = ((hash[i % hash.length] / fib(7)) - PSI) * PHI;
    }
    return normalize(v);
  }

  // ─── EVALUATE LAW ────────────────────────────────────────────────────────────

  /**
   * Evaluate a mutation against a single Unbreakable Law using CSL scoring.
   *
   * Score = cslAND(mutationEmbedding, lawEmbedding) — cosine similarity.
   * Law compliance: score ≥ CSL_THRESHOLDS.MEDIUM (≈ 0.809).
   * CSL gate applied at MEDIUM level (level=2) via cslPhiGATE.
   *
   * @param {object} mutation - Proposed system mutation
   * @param {string} mutation.description - Text description of the mutation
   * @param {number[]} [mutation.embedding] - Pre-computed 384D embedding (optional)
   * @param {string} law - Law name (from UNBREAKABLE_LAWS)
   * @returns {{ law: string, score: number, compliant: boolean, weight: number }}
   */
  evaluateLaw(mutation, law) {
    if (!UNBREAKABLE_LAWS[law]) {
      throw new Error(`Unknown law: ${law}. Must be one of: ${Object.keys(UNBREAKABLE_LAWS).join(', ')}`);
    }

    const mutEmb   = mutation.embedding || this._embed(mutation.description || '');
    const lawEmb   = this._lawEmbeddings.get(law);
    const rawScore = cslAND(mutEmb, lawEmb);                       // cosine similarity
    const gated    = cslPhiGATE(rawScore, rawScore, 2);             // MEDIUM gate level
    const weight   = LAW_WEIGHTS[law];
    const compliant = gated >= CSL_THRESHOLDS.MEDIUM;              // ≈ 0.809

    const result = { law, score: gated, rawScore, compliant, weight };

    /**
     * @event HeadySoul#law:evaluated
     * @type {object}
     */
    this.emit('law:evaluated', { mutation, result });
    return result;
  }

  // ─── VALIDATE MUTATION ───────────────────────────────────────────────────────

  /**
   * Validate a proposed mutation against ALL 3 Unbreakable Laws.
   *
   * Composite score = Σ(lawScore × lawWeight) — phi-fusion weighted sum.
   * Mutation is approved if composite score ≥ CSL_THRESHOLDS.MEDIUM (≈ 0.809).
   *
   * @param {object} mutation - Proposed system mutation
   * @param {string} mutation.description - Text description
   * @param {number[]} [mutation.embedding] - Pre-computed embedding
   * @param {object} [mutation.metadata]   - Optional metadata
   * @returns {{
   *   approved: boolean,
   *   compositeScore: number,
   *   breakdown: object[],
   *   mutationHash: string,
   *   risk: string
   * }}
   */
  validateMutation(mutation) {
    const mutEmb  = mutation.embedding || this._embed(mutation.description || '');
    const mutHash = crypto.createHash('sha256')
      .update(JSON.stringify({ desc: mutation.description, meta: mutation.metadata }))
      .digest('hex')
      .slice(0, fib(7));  // fib(7)=13 char hash

    const breakdown = Object.keys(UNBREAKABLE_LAWS).map(law =>
      this.evaluateLaw({ ...mutation, embedding: mutEmb }, law)
    );

    // Phi-fusion weighted composite score
    const compositeScore = breakdown.reduce(
      (sum, { score, weight }) => sum + score * weight,
      0
    );

    const approved = compositeScore >= CSL_THRESHOLDS.MEDIUM;      // ≈ 0.809

    // Risk classification using CSL thresholds
    let risk;
    if (compositeScore >= CSL_THRESHOLDS.HIGH)     risk = 'LOW';
    else if (compositeScore >= CSL_THRESHOLDS.MEDIUM) risk = 'MEDIUM';
    else if (compositeScore >= CSL_THRESHOLDS.LOW)    risk = 'HIGH';
    else                                              risk = 'CRITICAL';

    const record = {
      hash: mutHash,
      result: { approved, compositeScore, risk },
      timestamp: Date.now(),
    };

    // Maintain audit log (ring buffer of fib(10)=55)
    this._mutationLog.push(record);
    if (this._mutationLog.length > fib(10)) {
      this._mutationLog.shift();
    }

    const outcome = { approved, compositeScore, breakdown, mutationHash: mutHash, risk };

    /**
     * @event HeadySoul#mutation:validated
     * @type {object}
     */
    this.emit('mutation:validated', { mutation, outcome });
    return outcome;
  }

  // ─── CHECK COHERENCE ─────────────────────────────────────────────────────────

  /**
   * Measure coherence across a set of node embeddings.
   * Detects drift pairs where pairwise similarity < COHERENCE_DRIFT_THRESHOLD (≈ 0.809).
   *
   * Updates internal coherence history ring buffer (last fib(7)=13 readings).
   *
   * @param {Map<string, number[]>} nodeEmbeddings - node name → 384D embedding
   * @returns {{
   *   score: number,
   *   assessment: object,
   *   driftPairs: Array<{a: string, b: string, sim: number}>,
   *   trend: string,
   *   alarmLevel: string
   * }}
   */
  checkCoherence(nodeEmbeddings) {
    if (!(nodeEmbeddings instanceof Map)) {
      throw new TypeError('nodeEmbeddings must be a Map<string, number[]>');
    }

    // Also update internal embedding registry
    for (const [name, emb] of nodeEmbeddings.entries()) {
      this._nodeEmbeddings.set(name, emb);
    }

    const { score, driftPairs } = measureCoherence(nodeEmbeddings);
    const assessment = assessCoherence(score);

    // Update history (ring buffer fib(7)=13)
    this._coherenceHistory.push(score);
    if (this._coherenceHistory.length > fib(7)) {
      this._coherenceHistory.shift();
    }

    // Trend: compare last 2 readings (require fib(3)=2 readings minimum)
    let trend = 'stable';
    const histLen = this._coherenceHistory.length;
    if (histLen >= fib(3)) {
      const recent  = this._coherenceHistory[histLen - 1];
      const prev    = this._coherenceHistory[histLen - 2];
      const delta   = recent - prev;
      if (delta > PSI_FOURTH)      trend = 'improving';
      else if (delta < -PSI_FOURTH) trend = 'degrading';
    }

    // Alarm level based on phi thresholds
    let alarmLevel = 'NONE';
    if (score < CSL_THRESHOLDS.MINIMUM)     alarmLevel = 'CRITICAL';
    else if (score < CSL_THRESHOLDS.LOW)    alarmLevel = 'HIGH';
    else if (score < COHERENCE_DRIFT_THRESHOLD) alarmLevel = 'MEDIUM';

    const result = { score, assessment, driftPairs, trend, alarmLevel };

    /**
     * @event HeadySoul#coherence:measured
     * @type {object}
     */
    this.emit('coherence:measured', result);

    // Auto-trigger drift detection event for drift pairs
    if (driftPairs.length > 0) {
      /**
       * @event HeadySoul#drift:detected
       * @type {object}
       */
      this.emit('drift:detected', { score, driftPairs });
    }

    return result;
  }

  // ─── TRIGGER HEALING ─────────────────────────────────────────────────────────

  /**
   * Trigger self-healing for drifted node pairs.
   *
   * Healing strategy:
   * 1. For each drift pair, compute the consensus vector (cslCONSENSUS) as the
   *    phi-weighted centroid of both embeddings.
   * 2. Score consensus alignment against mission embedding via cslAND.
   * 3. Emit healing action for each pair with phi-backoff delay.
   * 4. Re-embed pair nodes toward consensus using phi-fractional interpolation:
   *    healed = normalize(node + ψ × (consensus - node))
   *
   * @param {Array<{a: string, b: string, sim: number}>} driftPairs
   *   Pairs with similarity < COHERENCE_DRIFT_THRESHOLD
   * @returns {Array<{
   *   pair: {a: string, b: string},
   *   consensusScore: number,
   *   healingVector: number[],
   *   missionAlignment: number,
   *   backoffMs: number
   * }>}
   */
  triggerHealing(driftPairs) {
    if (!Array.isArray(driftPairs) || driftPairs.length === 0) {
      return [];
    }

    const healingActions = [];

    for (let i = 0; i < driftPairs.length; i++) {
      const { a, b, sim } = driftPairs[i];
      const embA = this._nodeEmbeddings.get(a);
      const embB = this._nodeEmbeddings.get(b);

      if (!embA || !embB) {
        // Can't heal without embeddings; record skip
        healingActions.push({
          pair: { a, b },
          consensusScore: 0,
          healingVector: [],
          missionAlignment: 0,
          backoffMs: phiBackoff(i, fib(10)),  // 55ms base backoff
          skipped: true,
          reason: 'missing_embedding',
        });
        continue;
      }

      // Phi-weighted consensus: w = phiFusionWeights(2) ≈ [0.618, 0.382]
      const consensus       = cslCONSENSUS([embA, embB], phiFusionWeights(2));
      const consensusScore  = cslAND(embA, embB);   // how close they are now

      // Phi-fractional healing: healed_A = normalize(embA + ψ×(consensus - embA))
      const healA = normalize(
        embA.map((v, idx) => v + PSI * (consensus[idx] - v))
      );
      const healB = normalize(
        embB.map((v, idx) => v + PSI * (consensus[idx] - v))
      );

      // Update embedding registry with healed vectors
      this._nodeEmbeddings.set(a, healA);
      this._nodeEmbeddings.set(b, healB);

      // Mission alignment of consensus
      const missionAlignment = cslAND(consensus, MISSION_EMBEDDING);

      // Phi-backoff delay for this healing action
      const backoffMs = phiBackoff(this._healingAttempts + i, fib(10));

      healingActions.push({
        pair:             { a, b },
        originalSim:      sim,
        consensusScore,
        healingVector:    consensus,
        healedVectors:    { [a]: healA, [b]: healB },
        missionAlignment,
        backoffMs,
        skipped:          false,
      });
    }

    this._healingAttempts++;

    /**
     * @event HeadySoul#healing:triggered
     * @type {object}
     */
    this.emit('healing:triggered', {
      driftPairs,
      actions:         healingActions,
      healingAttempts: this._healingAttempts,
    });

    return healingActions;
  }

  // ─── HEARTBEAT ───────────────────────────────────────────────────────────────

  /**
   * Perform a single heartbeat cycle:
   * 1. Re-embed all known nodes deterministically.
   * 2. Check coherence across all registered embeddings.
   * 3. If drift detected, trigger self-healing.
   * 4. Adjust next interval via phi-adaptive backoff.
   *
   * Called automatically if heartbeat is started via startHeartbeat().
   *
   * @returns {{
   *   timestamp: number,
   *   nodeCount: number,
   *   coherenceScore: number,
   *   healthy: boolean,
   *   driftPairs: number,
   *   healingTriggered: boolean,
   *   nextIntervalMs: number
   * }}
   */
  heartbeat() {
    const timestamp = Date.now();

    // Re-embed all known nodes if we have any; otherwise seed with topology
    const allNodes = getAllNodes();
    if (this._nodeEmbeddings.size === 0) {
      for (const node of allNodes) {
        this._nodeEmbeddings.set(node, this._embed(node));
      }
    }

    // Re-embed existing nodes (refresh embeddings)
    for (const [nodeName] of this._nodeEmbeddings.entries()) {
      // Mix node name with seed + timestamp-bucket (φ-rounded to 60s buckets)
      const timeBucket = Math.floor(timestamp / (fib(14) * 1000));  // ~6min buckets
      const refreshHash = crypto.createHash('sha256')
        .update(`${this._seed}:${nodeName}:${timeBucket}`)
        .digest();
      const v = new Array(EMBEDDING_DIM);
      for (let i = 0; i < EMBEDDING_DIM; i++) {
        v[i] = ((refreshHash[i % refreshHash.length] / fib(7)) - PSI) * PHI;
      }
      this._nodeEmbeddings.set(nodeName, normalize(v));
    }

    // Measure coherence
    const { score, driftPairs, assessment } = this.checkCoherence(this._nodeEmbeddings);
    const healthy = assessment.healthy;

    // Trigger healing if drift found
    let healingTriggered = false;
    if (driftPairs.length > 0) {
      this.triggerHealing(driftPairs);
      healingTriggered = true;
    } else {
      // Reset healing attempts on clean heartbeat
      this._healingAttempts = Math.max(0, this._healingAttempts - 1);
    }

    // Phi-adaptive interval adjustment
    this._currentInterval = phiAdaptiveInterval(
      this._heartbeatMs,
      healthy,
      this._currentInterval
    );

    const result = {
      timestamp,
      nodeCount:        this._nodeEmbeddings.size,
      coherenceScore:   score,
      healthy,
      driftPairs:       driftPairs.length,
      healingTriggered,
      nextIntervalMs:   this._currentInterval,
    };

    /**
     * @event HeadySoul#heartbeat
     * @type {object}
     */
    this.emit('heartbeat', result);
    return result;
  }

  // ─── START / STOP HEARTBEAT ──────────────────────────────────────────────────

  /**
   * Start the automated heartbeat loop.
   * First beat fires immediately; subsequent beats at phi-adaptive intervals.
   *
   * @returns {HeadySoul} this (chainable)
   */
  startHeartbeat() {
    this.stopHeartbeat();

    const tick = () => {
      this.heartbeat();
      // Reschedule with current (possibly adapted) interval
      this._heartbeatTimer = setTimeout(tick, this._currentInterval);
    };

    // Fire immediately then repeat
    tick();
    return this;
  }

  /**
   * Stop the automated heartbeat loop.
   * @returns {HeadySoul} this (chainable)
   */
  stopHeartbeat() {
    if (this._heartbeatTimer) {
      clearTimeout(this._heartbeatTimer);
      this._heartbeatTimer = null;
    }
    return this;
  }

  // ─── GETTERS ─────────────────────────────────────────────────────────────────

  /**
   * Get current mission alignment score of a mutation or arbitrary embedding.
   *
   * @param {number[]} embedding - 384D embedding to test
   * @returns {number} Cosine similarity to mission embedding ∈ [-1, 1]
   */
  missionAlignmentScore(embedding) {
    return cslAND(embedding, MISSION_EMBEDDING);
  }

  /**
   * Get current coherence history (last fib(7)=13 readings).
   * @returns {number[]}
   */
  getCoherenceHistory() {
    return this._coherenceHistory.slice();
  }

  /**
   * Get mutation audit log (last fib(10)=55 records).
   * @returns {Array<object>}
   */
  getMutationLog() {
    return this._mutationLog.slice();
  }

  /**
   * Get law weights (phi-fusion for 3 laws).
   * @returns {object}
   */
  getLawWeights() {
    return { ...LAW_WEIGHTS };
  }

  /**
   * Current phi-adaptive heartbeat interval in ms.
   * @returns {number}
   */
  getCurrentInterval() {
    return this._currentInterval;
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  HeadySoul,
  UNBREAKABLE_LAWS,
  LAW_WEIGHTS,
  MISSION_EMBEDDING,
  SEED,
  HEARTBEAT_BASE_MS,
};
