/**
 * @fileoverview MoE CSL Router — Mixture-of-Experts with CSL Cosine Routing
 *
 * Geometric expert routing using cosine similarity instead of learned linear
 * weights. Softmax temperature adapts to entropy; anti-collapse regularization
 * ensures expert diversity.
 *
 * Gate vectors live in 384D embedding space. Top-K = fib(3) = 2 experts selected
 * per forward pass. Collapse detection fires when max probability exceeds ψ⁹ ≈ 0.0081
 * above the safe zone.
 *
 * @module routing/moe-csl-router
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  phiFusionWeights,
  adaptiveTemperature,
  sigmoid,
  cslGate,
  nearestFib,
} = require('../shared/phi-math');

const {
  cosineSimilarity,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, dot, norm, vecAdd, vecSub, vecScale,
  hdcBIND, hdcBUNDLE, hdcRandomVector,
  moeRoute, isSemanticDuplicate, hashVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── CONSTANTS ──────────────────────────────────────────────────────────────────

/** Top-K experts selected per route = fib(3) = 2 */
const TOP_K = fib(3);

/** Base softmax temperature = PSI_CUBE ≈ 0.236 */
const BASE_TEMPERATURE = PSI_CUBE;

/** Anti-collapse regularization weight = ψ⁸ ≈ 0.0131 */
const ANTI_COLLAPSE_WEIGHT = Math.pow(PSI, 8);

/** Collapse detection threshold = ψ⁹ ≈ 0.0081 */
const COLLAPSE_THRESHOLD = Math.pow(PSI, 9);

/** Expert gate initialization scale: (Math.random() - PSI) * PHI */
const GATE_INIT_CENTER = PSI;   // Subtract this
const GATE_INIT_SCALE  = PHI;   // Multiply by this

/** Minimum number of experts before routing is valid = fib(3) = 2 */
const MIN_EXPERTS = fib(3);

/** Maximum experts before performance degrades = fib(9) = 34 */
const MAX_EXPERTS = fib(9);

/** Expert load balance window (recent calls tracked) = fib(8) = 21 */
const LOAD_WINDOW = fib(8);

// ─── CLASS ─────────────────────────────────────────────────────────────────────

/**
 * @class MoECSLRouter
 *
 * Mixture-of-Experts router using CSL cosine similarity for geometric routing.
 * No trainable weight matrices — all routing is computed via φ-math and geometry.
 *
 * Expert gate vectors encode semantic "territory". Inputs route to the experts
 * whose gate vectors are most cosine-similar to the input embedding.
 *
 * @example
 * const router = new MoECSLRouter();
 * router.addExpert(gateVector); // 384D unit vector
 * const { experts, distribution } = router.route(inputEmbedding);
 */
class MoECSLRouter {
  /**
   * @param {object} [options={}]
   * @param {number}  [options.topK=fib(3)] - Number of experts per route
   * @param {number}  [options.baseTemperature=PSI_CUBE] - Softmax temperature
   * @param {boolean} [options.adaptTemp=true] - Adaptive temperature via entropy
   */
  constructor(options = {}) {
    /** @type {Array<{ gateVector: number[], id: string, loadCount: number, recentLoads: number[] }>} */
    this._experts = [];

    this._topK            = options.topK            || TOP_K;
    this._baseTemp        = options.baseTemperature  || BASE_TEMPERATURE;
    this._adaptTemp       = options.adaptTemp        !== false;

    /** Running entropy for adaptive temperature */
    this._entropyHistory = [];
    this._routeCount     = 0;
  }

  // ─── PRIVATE: ENTROPY ──────────────────────────────────────────────────────

  /**
   * Compute Shannon entropy of a probability distribution.
   * H = -Σ p_i * log(p_i), normalized to [0, 1] by dividing by log(N).
   * @private
   * @param {number[]} probs - Probability values summing to 1
   * @returns {number} Normalized entropy ∈ [0, 1]
   */
  _entropy(probs) {
    const n = probs.length;
    if (n <= 1) return 0;
    const maxH = Math.log(n);
    let H = 0;
    for (const p of probs) {
      if (p > 0) H -= p * Math.log(p);
    }
    return H / maxH;
  }

  // ─── PRIVATE: ANTI-COLLAPSE REGULARIZATION ─────────────────────────────────

  /**
   * Apply anti-collapse regularization to raw logits.
   * Adds a uniform noise floor of ANTI_COLLAPSE_WEIGHT to prevent
   * all probability mass collapsing onto a single expert.
   *
   * @private
   * @param {number[]} logits - Raw cosine scores
   * @returns {number[]} Regularized logits
   */
  _applyAntiCollapse(logits) {
    return logits.map(l => l + ANTI_COLLAPSE_WEIGHT);
  }

  // ─── PRIVATE: SOFTMAX ──────────────────────────────────────────────────────

  /**
   * Numerically stable softmax with phi-temperature scaling.
   * @private
   * @param {number[]} scores - Raw cosine similarity scores
   * @param {number}   temp   - Temperature
   * @returns {number[]} Probability distribution
   */
  _softmax(scores, temp) {
    const scaledMax = Math.max(...scores.map(s => s / temp));
    const exps      = scores.map(s => Math.exp(s / temp - scaledMax));
    const expSum    = exps.reduce((a, b) => a + b, 0);
    return expSum > 0 ? exps.map(e => e / expSum) : exps.map(() => 1 / scores.length);
  }

  // ─── PRIVATE: LOAD TRACKING ────────────────────────────────────────────────

  /**
   * Record an expert activation for load balance monitoring.
   * @private
   * @param {number} idx - Expert index
   */
  _recordLoad(idx) {
    const expert = this._experts[idx];
    if (!expert) return;
    expert.loadCount++;
    expert.recentLoads.push(Date.now());
    if (expert.recentLoads.length > LOAD_WINDOW) {
      expert.recentLoads.shift();
    }
  }

  // ─── PUBLIC: EXPERT MANAGEMENT ─────────────────────────────────────────────

  /**
   * Add an expert with its gate vector.
   * Gate vector encodes the semantic "territory" this expert handles.
   *
   * Initialization if no gate vector provided: (Math.random() - PSI) * PHI, normalized.
   *
   * @param {number[]|null} [gateVector=null] - Pre-computed 384D gate vector (or null for random init)
   * @returns {number} Index of added expert
   */
  addExpert(gateVector = null) {
    if (this._experts.length >= MAX_EXPERTS) {
      throw new Error(`Cannot exceed MAX_EXPERTS = ${MAX_EXPERTS} (fib(9))`);
    }

    let gate;
    if (gateVector) {
      gate = normalize(gateVector);
    } else {
      // Phi-harmonic random initialization: (random - PSI) * PHI
      const raw = new Array(EMBEDDING_DIM).fill(0).map(
        () => (Math.random() - GATE_INIT_CENTER) * GATE_INIT_SCALE,
      );
      gate = normalize(raw);
    }

    const idx = this._experts.length;
    this._experts.push({
      gateVector:  gate,
      id:          `expert_${idx}_${Date.now().toString(fib(5))}`,
      loadCount:   0,
      recentLoads: [],
    });

    return idx;
  }

  /**
   * Remove an expert by index. Compacts the array.
   * @param {number} idx - Expert index to remove
   * @returns {boolean} True if removed
   */
  removeExpert(idx) {
    if (idx < 0 || idx >= this._experts.length) return false;
    this._experts.splice(idx, 1);
    return true;
  }

  // ─── PUBLIC: ROUTING ───────────────────────────────────────────────────────

  /**
   * Route an input embedding to the top-K experts.
   *
   * Algorithm:
   *   1. Compute cosine(input, expertGate[i]) for each expert
   *   2. Apply anti-collapse regularization
   *   3. Compute adaptive temperature from entropy history
   *   4. Softmax over regularized scores
   *   5. Select top-K experts
   *   6. Renormalize selected weights to sum to 1
   *
   * @param {number[]} input - 384D input embedding (will be normalized)
   * @returns {{
   *   experts: Array<{ idx: number, id: string, weight: number, score: number }>,
   *   distribution: number[],
   *   temperature: number,
   *   entropy: number,
   *   collapsed: boolean
   * }}
   */
  route(input) {
    if (this._experts.length < MIN_EXPERTS) {
      throw new Error(`Need at least ${MIN_EXPERTS} experts (fib(3)) to route`);
    }

    const inputNorm = normalize(input);
    this._routeCount++;

    // Step 1: Cosine scores
    const rawScores = this._experts.map(e => cosineSimilarity(inputNorm, e.gateVector));

    // Step 2: Anti-collapse regularization
    const regScores = this._applyAntiCollapse(rawScores);

    // Step 3: Adaptive temperature
    const prelimProbs  = this._softmax(regScores, this._baseTemp);
    const currentEntropy = this._entropy(prelimProbs);
    const maxEntropy     = 1.0;

    this._entropyHistory.push(currentEntropy);
    if (this._entropyHistory.length > LOAD_WINDOW) this._entropyHistory.shift();
    const avgEntropy = this._entropyHistory.reduce((a, b) => a + b, 0) / this._entropyHistory.length;

    const temperature = this._adaptTemp
      ? adaptiveTemperature(avgEntropy, maxEntropy)
      : this._baseTemp;

    // Step 4: Final softmax with adaptive temperature
    const probs = this._softmax(regScores, temperature);

    // Step 5: Select top-K
    const indexed = probs.map((p, i) => ({ i, p, score: rawScores[i] }));
    indexed.sort((a, b) => b.p - a.p);
    const topK = indexed.slice(0, Math.min(this._topK, this._experts.length));

    // Step 6: Renormalize
    const topKSum = topK.reduce((s, e) => s + e.p, 0);
    const experts = topK.map(e => {
      this._recordLoad(e.i);
      return {
        idx:    e.i,
        id:     this._experts[e.i].id,
        weight: e.p / topKSum,
        score:  e.score,
      };
    });

    const collapsed = this.detectCollapse(probs);

    return {
      experts,
      distribution: probs,
      temperature,
      entropy:   currentEntropy,
      collapsed,
    };
  }

  // ─── PUBLIC: COLLAPSE DETECTION ────────────────────────────────────────────

  /**
   * Detect expert collapse: distribution too concentrated on one expert.
   *
   * Collapse fires when max(probs) exceeds 1 - COLLAPSE_THRESHOLD.
   * COLLAPSE_THRESHOLD = ψ⁹ ≈ 0.0081, so threshold = 1 - ψ⁹ ≈ 0.9919.
   *
   * @param {number[]|null} [probs=null] - Probability distribution (uses last computed if null)
   * @returns {boolean} True if collapsed
   */
  detectCollapse(probs = null) {
    if (!probs || probs.length === 0) return false;
    const maxProb    = Math.max(...probs);
    const safeLimit  = 1 - COLLAPSE_THRESHOLD;
    return maxProb > safeLimit;
  }

  // ─── PUBLIC: DISTRIBUTION ──────────────────────────────────────────────────

  /**
   * Get expert load distribution (recent activation counts).
   * @returns {Array<{ idx: number, id: string, loadCount: number, recentRate: number }>}
   */
  getDistribution() {
    return this._experts.map((e, i) => ({
      idx:        i,
      id:         e.id,
      loadCount:  e.loadCount,
      recentRate: this._routeCount > 0 ? e.loadCount / this._routeCount : 0,
      gateNorm:   norm(e.gateVector),
    }));
  }

  /**
   * Get the cosine similarity matrix between all expert gate vectors.
   * Useful for detecting expert similarity/redundancy.
   * @returns {number[][]} N×N similarity matrix
   */
  getGateSimilarityMatrix() {
    const n = this._experts.length;
    return this._experts.map((e, i) =>
      this._experts.map((f, j) =>
        i === j ? 1.0 : cosineSimilarity(e.gateVector, f.gateVector),
      ),
    );
  }

  /**
   * Summary of router state.
   * @returns {object}
   */
  getStats() {
    return {
      expertCount:    this._experts.length,
      routeCount:     this._routeCount,
      topK:           this._topK,
      baseTemp:       this._baseTemp,
      adaptTemp:      this._adaptTemp,
      avgEntropy:     this._entropyHistory.length > 0
        ? this._entropyHistory.reduce((a, b) => a + b, 0) / this._entropyHistory.length
        : null,
      antiCollapseW:  ANTI_COLLAPSE_WEIGHT,
      collapseThresh: COLLAPSE_THRESHOLD,
    };
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  MoECSLRouter,
  TOP_K,
  BASE_TEMPERATURE,
  ANTI_COLLAPSE_WEIGHT,
  COLLAPSE_THRESHOLD,
};
