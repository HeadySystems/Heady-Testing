/**
 * @fileoverview LLM Router — Phi-Harmonic Multi-Provider LLM Routing
 *
 * Liquid failover across six LLM providers using Fibonacci retry limits,
 * PSI-threshold budget downgrade, and CSL-informed circuit breakers.
 *
 * @module routing/llm-router
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  ALERT_THRESHOLDS,
  phiFusionWeights,
  phiBackoff,
  phiBackoffDeterministic,
  adaptiveTemperature,
  sigmoid,
  cslGate,
  nearestFib,
} = require('../shared/phi-math');

const {
  cosineSimilarity,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, dot, norm, vecAdd, vecSub, vecScale,
  hdcBIND, hdcBUNDLE, hdcRandomVector,
  moeRoute, isSemanticDuplicate, hashVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── CONSTANTS ──────────────────────────────────────────────────────────────────

/** Maximum liquid failover retries on rate limit = fib(3) = 2 */
const MAX_RATE_LIMIT_RETRIES = fib(3);

/** Budget warning threshold = PSI ≈ 0.618 of cap */
const BUDGET_WARNING_RATIO = PSI;

/** Budget downgrade threshold — same as warning for auto-downgrade */
const BUDGET_DOWNGRADE_RATIO = PSI;

/** Circuit breaker failure threshold = fib(5) = 5 */
const CIRCUIT_FAILURE_THRESHOLD = fib(5);

/** Circuit breaker reset timeout = fib(8) * 1000 ms = 21000 ms */
const CIRCUIT_RESET_TIMEOUT_MS = fib(8) * 1000;

/** Circuit half-open probe count = fib(3) = 2 */
const CIRCUIT_HALF_OPEN_PROBES = fib(3);

/** Health check interval = fib(9) * 1000 ms = 34000 ms */
const HEALTH_CHECK_INTERVAL_MS = fib(9) * 1000;

/** Global monthly token cap (approximate) = fib(20) * 1000 = 6,765,000 */
const GLOBAL_MONTHLY_TOKEN_CAP = fib(20) * 1000;

/** Per-provider daily token cap = fib(17) * 1000 = 1,597,000 */
const PROVIDER_DAILY_TOKEN_CAP = fib(17) * 1000;

/** Circuit breaker states */
const CIRCUIT_STATE = Object.freeze({
  CLOSED:    'CLOSED',    // Normal operation
  OPEN:      'OPEN',      // Failing, reject all requests
  HALF_OPEN: 'HALF_OPEN', // Testing recovery
});

// ─── PROVIDER REGISTRY ─────────────────────────────────────────────────────────

/**
 * Default provider configurations.
 * costPerInputToken / costPerOutputToken in USD.
 * Tier 1 = highest quality, Tier 3 = economy.
 */
const DEFAULT_PROVIDERS = Object.freeze({
  anthropic: {
    id: 'anthropic',
    name: 'Anthropic Claude',
    tier: 1,
    costPerInputToken:  PSI_FOURTH * 0.001,   // ≈ $0.000146/tok
    costPerOutputToken: PSI_CUBE  * 0.001,     // ≈ $0.000236/tok
    maxContextTokens:   fib(18) * 10,          // ≈ 25,840
    defaultModel:       'claude-3-5-sonnet-20241022',
    fallbackModel:      'claude-3-haiku-20240307',
    strengths:          ['codeGeneration', 'codeReview', 'architecture', 'securityAudit'],
  },
  openai: {
    id: 'openai',
    name: 'OpenAI GPT',
    tier: 1,
    costPerInputToken:  PSI_CUBE  * 0.001,
    costPerOutputToken: PSI_SQ    * 0.001,
    maxContextTokens:   fib(18) * 10,
    defaultModel:       'gpt-4o',
    fallbackModel:      'gpt-4o-mini',
    strengths:          ['creative', 'documentation', 'research', 'quickTasks'],
  },
  google: {
    id: 'google',
    name: 'Google Gemini',
    tier: 1,
    costPerInputToken:  PSI_FOURTH * PSI_CUBE * 0.01,
    costPerOutputToken: PSI_FOURTH * PSI_SQ   * 0.01,
    maxContextTokens:   fib(22) * 10,
    defaultModel:       'gemini-2.0-flash',
    fallbackModel:      'gemini-1.5-flash-8b',
    strengths:          ['research', 'documentation', 'embeddings'],
  },
  groq: {
    id: 'groq',
    name: 'Groq Inference',
    tier: 2,
    costPerInputToken:  PSI_FOURTH * 0.0001,
    costPerOutputToken: PSI_CUBE   * 0.0001,
    maxContextTokens:   fib(16) * 10,
    defaultModel:       'llama-3.3-70b-versatile',
    fallbackModel:      'llama-3.1-8b-instant',
    strengths:          ['quickTasks', 'creative'],
  },
  perplexity: {
    id: 'perplexity',
    name: 'Perplexity',
    tier: 2,
    costPerInputToken:  PSI_SQ * 0.0001,
    costPerOutputToken: PSI    * 0.0001,
    maxContextTokens:   fib(16) * 10,
    defaultModel:       'llama-3.1-sonar-large-128k-online',
    fallbackModel:      'llama-3.1-sonar-small-128k-online',
    strengths:          ['research'],
  },
  local: {
    id: 'local',
    name: 'Local Model',
    tier: 3,
    costPerInputToken:  0,
    costPerOutputToken: 0,
    maxContextTokens:   fib(14) * 10,
    defaultModel:       'llama-3.2-3b',
    fallbackModel:      'phi-3-mini',
    strengths:          ['quickTasks'],
  },
});

// ─── ROUTING MATRIX ────────────────────────────────────────────────────────────

/**
 * Maps task types to ordered provider preferences: [primary, fallback1, fallback2].
 * Fallback chain follows phi-degradation: best → capable → economy.
 */
const ROUTING_MATRIX = Object.freeze({
  codeGeneration:  { primary: 'anthropic', fallback1: 'openai',      fallback2: 'groq'        },
  codeReview:      { primary: 'anthropic', fallback1: 'openai',      fallback2: 'google'      },
  architecture:    { primary: 'anthropic', fallback1: 'openai',      fallback2: 'google'      },
  research:        { primary: 'perplexity',fallback1: 'google',      fallback2: 'openai'      },
  quickTasks:      { primary: 'groq',      fallback1: 'openai',      fallback2: 'local'       },
  creative:        { primary: 'openai',    fallback1: 'anthropic',   fallback2: 'groq'        },
  securityAudit:   { primary: 'anthropic', fallback1: 'openai',      fallback2: 'google'      },
  documentation:   { primary: 'openai',    fallback1: 'google',      fallback2: 'anthropic'   },
  embeddings:      { primary: 'google',    fallback1: 'openai',      fallback2: 'local'       },
});

// ─── CLASS ─────────────────────────────────────────────────────────────────────

/**
 * @class LLMRouter
 * @extends EventEmitter
 *
 * Liquid multi-provider LLM router with phi-harmonic failover, budget tracking,
 * circuit breakers, and cost telemetry.
 *
 * @fires LLMRouter#route - Emitted on successful routing
 * @fires LLMRouter#failover - Emitted when failover occurs
 * @fires LLMRouter#budgetWarning - Emitted when usage approaches PSI threshold
 * @fires LLMRouter#selfHeal - Emitted when all providers fail and self-heal is triggered
 * @fires LLMRouter#circuitOpen - Emitted when a circuit breaker opens
 * @fires LLMRouter#circuitClose - Emitted when a circuit breaker closes
 */
class LLMRouter extends EventEmitter {
  /**
   * @param {object} [options={}]
   * @param {boolean} [options.enableHealthChecks=true] - Start background health polling
   * @param {number}  [options.dailyCapOverride] - Override default per-provider daily cap
   * @param {number}  [options.monthlyCapOverride] - Override global monthly cap
   */
  constructor(options = {}) {
    super();

    /** @type {Map<string, object>} Provider registry */
    this._providers = new Map();

    /** @type {Map<string, object>} Per-provider health state */
    this._health = new Map();

    /** @type {Map<string, object>} Per-provider circuit breaker state */
    this._circuits = new Map();

    /** @type {Map<string, object>} Per-provider daily usage tracker */
    this._dailyUsage = new Map();

    /** @type {{ tokens: number, cost: number, date: string }} Global monthly tracker */
    this._monthlyUsage = {
      tokens: 0,
      cost:   0.0,
      month:  new Date().toISOString().slice(0, 7), // "YYYY-MM"
    };

    /** @type {number} Per-provider daily token cap */
    this._dailyCap = options.dailyCapOverride || PROVIDER_DAILY_TOKEN_CAP;

    /** @type {number} Global monthly token cap */
    this._monthlyCap = options.monthlyCapOverride || GLOBAL_MONTHLY_TOKEN_CAP;

    // Register default providers
    for (const cfg of Object.values(DEFAULT_PROVIDERS)) {
      this._registerProvider(cfg);
    }

    // Background health monitoring
    if (options.enableHealthChecks !== false) {
      this._healthTimer = setInterval(
        () => this._runHealthChecks(),
        HEALTH_CHECK_INTERVAL_MS,
      );
      if (this._healthTimer.unref) this._healthTimer.unref();
    }
  }

  // ─── PRIVATE: PROVIDER INIT ────────────────────────────────────────────────

  /**
   * Register a provider with initial health and circuit state.
   * @private
   * @param {object} cfg - Provider configuration
   */
  _registerProvider(cfg) {
    this._providers.set(cfg.id, { ...cfg });

    this._health.set(cfg.id, {
      available:    true,
      latencyMs:    0,
      errorRate:    0.0,
      lastChecked:  Date.now(),
      successCount: 0,
      failureCount: 0,
    });

    this._circuits.set(cfg.id, {
      state:      CIRCUIT_STATE.CLOSED,
      failures:   0,
      lastOpened: null,
      probeCount: 0,
    });

    this._dailyUsage.set(cfg.id, {
      tokens: 0,
      cost:   0.0,
      date:   new Date().toISOString().slice(0, 10), // "YYYY-MM-DD"
    });
  }

  // ─── PRIVATE: CIRCUIT BREAKER ──────────────────────────────────────────────

  /**
   * Check if a provider is available for requests (circuit breaker logic).
   * @private
   * @param {string} providerId
   * @returns {boolean}
   */
  _isCircuitAllowing(providerId) {
    const cb = this._circuits.get(providerId);
    if (!cb) return false;

    if (cb.state === CIRCUIT_STATE.CLOSED) return true;

    if (cb.state === CIRCUIT_STATE.OPEN) {
      const elapsed = Date.now() - cb.lastOpened;
      if (elapsed >= CIRCUIT_RESET_TIMEOUT_MS) {
        cb.state = CIRCUIT_STATE.HALF_OPEN;
        cb.probeCount = 0;
      } else {
        return false;
      }
    }

    // HALF_OPEN: allow limited probes
    if (cb.state === CIRCUIT_STATE.HALF_OPEN) {
      return cb.probeCount < CIRCUIT_HALF_OPEN_PROBES;
    }

    return false;
  }

  /**
   * Record a provider success — potentially close circuit.
   * @private
   * @param {string} providerId
   */
  _recordSuccess(providerId) {
    const cb = this._circuits.get(providerId);
    const h  = this._health.get(providerId);
    if (!cb || !h) return;

    h.successCount++;
    cb.failures = 0;

    if (cb.state === CIRCUIT_STATE.HALF_OPEN) {
      cb.probeCount++;
      if (cb.probeCount >= CIRCUIT_HALF_OPEN_PROBES) {
        cb.state = CIRCUIT_STATE.CLOSED;
        this.emit('circuitClose', { providerId });
      }
    }
  }

  /**
   * Record a provider failure — potentially open circuit.
   * @private
   * @param {string} providerId
   */
  _recordFailure(providerId) {
    const cb = this._circuits.get(providerId);
    const h  = this._health.get(providerId);
    if (!cb || !h) return;

    h.failureCount++;
    cb.failures++;

    if (cb.failures >= CIRCUIT_FAILURE_THRESHOLD) {
      cb.state      = CIRCUIT_STATE.OPEN;
      cb.lastOpened = Date.now();
      this.emit('circuitOpen', { providerId, failures: cb.failures });
    }
  }

  // ─── PRIVATE: BUDGET TRACKING ──────────────────────────────────────────────

  /**
   * Reset daily usage if date has changed.
   * @private
   * @param {string} providerId
   */
  _resetDailyIfStale(providerId) {
    const usage = this._dailyUsage.get(providerId);
    const today = new Date().toISOString().slice(0, 10);
    if (usage && usage.date !== today) {
      usage.tokens = 0;
      usage.cost   = 0.0;
      usage.date   = today;
    }
  }

  /**
   * Check if a provider is within budget.
   * @private
   * @param {string} providerId
   * @returns {boolean}
   */
  _isBudgetOk(providerId) {
    this._resetDailyIfStale(providerId);
    const usage = this._dailyUsage.get(providerId);
    if (!usage) return false;
    return usage.tokens < this._dailyCap;
  }

  /**
   * Determine if provider should be downgraded to cheaper model.
   * @private
   * @param {string} providerId
   * @returns {boolean}
   */
  _shouldDowngrade(providerId) {
    this._resetDailyIfStale(providerId);
    const usage = this._dailyUsage.get(providerId);
    if (!usage) return false;
    return (usage.tokens / this._dailyCap) >= BUDGET_DOWNGRADE_RATIO;
  }

  // ─── PRIVATE: HEALTH CHECKS ────────────────────────────────────────────────

  /**
   * Run lightweight health checks across all providers.
   * In production this would ping provider status pages.
   * @private
   */
  _runHealthChecks() {
    const now = Date.now();
    for (const [id, h] of this._health.entries()) {
      h.lastChecked = now;
      // Compute rolling error rate from recent counts
      const total = h.successCount + h.failureCount;
      h.errorRate = total > 0 ? h.failureCount / total : 0;
      h.available = h.errorRate < PSI; // Available if error rate < ψ ≈ 0.618
    }
  }

  // ─── PUBLIC: PROVIDER MANAGEMENT ──────────────────────────────────────────

  /**
   * Add or update a provider at runtime.
   * @param {object} config - Provider configuration object
   * @param {string} config.id - Unique provider ID
   * @param {string} config.name - Display name
   * @param {number} config.tier - Quality tier (1=best)
   * @param {number} config.costPerInputToken - USD per input token
   * @param {number} config.costPerOutputToken - USD per output token
   * @param {number} config.maxContextTokens
   * @param {string} config.defaultModel
   * @param {string} config.fallbackModel
   * @param {string[]} config.strengths - Task type affinities
   */
  addProvider(config) {
    this._registerProvider(config);
    this.emit('providerAdded', { providerId: config.id });
  }

  // ─── PUBLIC: CORE ROUTING ──────────────────────────────────────────────────

  /**
   * Select the best available provider for a given task type.
   *
   * Priority: routing matrix primary → circuit available → budget ok →
   * fallback1 → fallback2. Auto-downgrades model at PSI threshold.
   *
   * @param {string} taskType - One of the ROUTING_MATRIX task types
   * @returns {{ providerId: string, model: string, downgraded: boolean } | null}
   */
  selectProvider(taskType) {
    const matrix = ROUTING_MATRIX[taskType] || ROUTING_MATRIX.quickTasks;
    const chain  = [matrix.primary, matrix.fallback1, matrix.fallback2];

    for (const id of chain) {
      if (!this._providers.has(id)) continue;
      if (!this._isCircuitAllowing(id)) continue;
      if (!this._isBudgetOk(id)) continue;

      const provider  = this._providers.get(id);
      const downgraded = this._shouldDowngrade(id);
      const model      = downgraded ? provider.fallbackModel : provider.defaultModel;

      return { providerId: id, model, downgraded };
    }

    return null; // All providers unavailable
  }

  /**
   * Route a task with liquid failover.
   *
   * Failover chain:
   *   1. Try primary → if rate-limited, retry up to fib(3)=2 times with phi-backoff
   *   2. Try fallback1 → then fallback2 → emit selfHeal event
   *
   * @param {object} task - Task descriptor
   * @param {string} task.type - Task type (see ROUTING_MATRIX keys)
   * @param {string} task.content - Task content/prompt
   * @param {object} [task.options={}] - Additional options (temperature, maxTokens, etc.)
   * @returns {Promise<{ provider: string, model: string, result: object }>}
   */
  async route(task) {
    const taskType = task.type || 'quickTasks';
    const matrix   = ROUTING_MATRIX[taskType] || ROUTING_MATRIX.quickTasks;
    const chain    = [matrix.primary, matrix.fallback1, matrix.fallback2];

    let lastError = null;

    for (let chainIdx = 0; chainIdx < chain.length; chainIdx++) {
      const providerId = chain[chainIdx];

      if (!this._providers.has(providerId)) continue;
      if (!this._isCircuitAllowing(providerId)) continue;
      if (!this._isBudgetOk(providerId)) continue;

      const provider   = this._providers.get(providerId);
      const downgraded = this._shouldDowngrade(providerId);
      const model      = downgraded ? provider.fallbackModel : provider.defaultModel;

      const maxRetries = chainIdx === 0 ? MAX_RATE_LIMIT_RETRIES : 0;

      for (let attempt = 0; attempt <= maxRetries; attempt++) {
        if (attempt > 0) {
          const delay = phiBackoff(attempt - 1, fib(9), fib(13) * 1000);
          await new Promise(resolve => setTimeout(resolve, delay));
          this.emit('failover', { providerId, attempt, taskType });
        }

        try {
          const result = await this._callProvider(providerId, model, task);
          this._recordSuccess(providerId);

          // Track cost
          const tokens = result.usage || { input: 0, output: 0 };
          this.trackCost(providerId, tokens.input || 0, tokens.output || 0);

          this.emit('route', { providerId, model, taskType, downgraded });
          return { provider: providerId, model, result };

        } catch (err) {
          lastError = err;

          const isRateLimit = err.code === 'RATE_LIMIT' || err.status === 429;
          if (!isRateLimit || attempt === maxRetries) {
            this._recordFailure(providerId);
            break; // Move to next provider in chain
          }
          // Rate limit: will retry
        }
      }
    }

    // All providers failed
    this.emit('selfHeal', { taskType, error: lastError });
    throw lastError || new Error(`All providers failed for task type: ${taskType}`);
  }

  /**
   * Simulate or dispatch a provider API call.
   * In production, this delegates to individual provider SDK clients.
   * @private
   * @param {string} providerId
   * @param {string} model
   * @param {object} task
   * @returns {Promise<object>}
   */
  async _callProvider(providerId, model, task) {
    // Placeholder: real implementation wires into SDK clients
    return {
      providerId,
      model,
      content: `[${providerId}:${model}] response for: ${String(task.content).slice(0, fib(6))}...`,
      usage: { input: fib(9), output: fib(8) },
    };
  }

  /**
   * Failover handler — explicitly invoke next provider in chain.
   * @param {object} task - Original task
   * @param {Error}  error - Error that triggered failover
   * @returns {Promise<object>}
   */
  async failover(task, error) {
    this.emit('failover', { task, error: error.message });
    return this.route(task);
  }

  // ─── PUBLIC: COST TRACKING ─────────────────────────────────────────────────

  /**
   * Record token usage and accumulate cost for a provider.
   *
   * @param {string} providerId
   * @param {number} inputTokens
   * @param {number} outputTokens
   * @returns {{ dailyCost: number, monthlyCost: number }}
   */
  trackCost(providerId, inputTokens, outputTokens) {
    const provider = this._providers.get(providerId);
    if (!provider) return { dailyCost: 0, monthlyCost: 0 };

    this._resetDailyIfStale(providerId);

    const inputCost  = inputTokens  * provider.costPerInputToken;
    const outputCost = outputTokens * provider.costPerOutputToken;
    const totalCost  = inputCost + outputCost;
    const totalTokens = inputTokens + outputTokens;

    const daily = this._dailyUsage.get(providerId);
    daily.tokens += totalTokens;
    daily.cost   += totalCost;

    this._monthlyUsage.tokens += totalTokens;
    this._monthlyUsage.cost   += totalCost;

    // Emit budget warnings
    const dailyRatio   = daily.tokens / this._dailyCap;
    const monthlyRatio = this._monthlyUsage.tokens / this._monthlyCap;

    if (dailyRatio >= BUDGET_WARNING_RATIO) {
      this.emit('budgetWarning', {
        scope:      'daily',
        providerId,
        ratio:      dailyRatio,
        threshold:  BUDGET_WARNING_RATIO,
      });
    }

    if (monthlyRatio >= BUDGET_WARNING_RATIO) {
      this.emit('budgetWarning', {
        scope:     'monthly',
        ratio:     monthlyRatio,
        threshold: BUDGET_WARNING_RATIO,
      });
    }

    return { dailyCost: daily.cost, monthlyCost: this._monthlyUsage.cost };
  }

  // ─── PUBLIC: STATUS ────────────────────────────────────────────────────────

  /**
   * Get current budget status across all providers.
   * @returns {{ providers: object[], global: object }}
   */
  getBudgetStatus() {
    const providers = [];

    for (const [id, usage] of this._dailyUsage.entries()) {
      this._resetDailyIfStale(id);
      const ratio     = usage.tokens / this._dailyCap;
      const cb        = this._circuits.get(id);
      const health    = this._health.get(id);

      providers.push({
        providerId:    id,
        dailyTokens:   usage.tokens,
        dailyCap:      this._dailyCap,
        dailyRatio:    ratio,
        dailyCost:     usage.cost,
        budgetLevel:   ratio >= PSI ? 'DOWNGRADE' : ratio >= PSI_SQ ? 'ELEVATED' : 'NOMINAL',
        circuitState:  cb?.state || CIRCUIT_STATE.CLOSED,
        errorRate:     health?.errorRate || 0,
        downgraded:    ratio >= BUDGET_DOWNGRADE_RATIO,
      });
    }

    const monthlyRatio = this._monthlyUsage.tokens / this._monthlyCap;

    return {
      providers,
      global: {
        monthlyTokens: this._monthlyUsage.tokens,
        monthlyCap:    this._monthlyCap,
        monthlyRatio,
        monthlyCost:   this._monthlyUsage.cost,
        budgetLevel:   monthlyRatio >= PSI ? 'CRITICAL' : 'OK',
      },
    };
  }

  /**
   * Get health summary for all providers.
   * @returns {Array<{ providerId: string, state: string, errorRate: number, available: boolean }>}
   */
  getProviderHealth() {
    const result = [];
    for (const [id, h] of this._health.entries()) {
      const cb = this._circuits.get(id);
      result.push({
        providerId:   id,
        available:    h.available,
        errorRate:    h.errorRate,
        circuitState: cb?.state || CIRCUIT_STATE.CLOSED,
        successCount: h.successCount,
        failureCount: h.failureCount,
        lastChecked:  new Date(h.lastChecked).toISOString(),
      });
    }
    return result;
  }

  /**
   * Gracefully shut down background timers.
   */
  destroy() {
    if (this._healthTimer) clearInterval(this._healthTimer);
    this.removeAllListeners();
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = { LLMRouter, ROUTING_MATRIX, DEFAULT_PROVIDERS, CIRCUIT_STATE };
