/**
 * @fileoverview Embedding Router — Phi-Harmonic Multi-Provider Embedding Routing
 *
 * Routes text embedding requests across six providers using CSL-gated scoring,
 * LRU caching, MRL dimensionality reduction, and phi-scaled circuit breakers.
 *
 * Routing priority: sovereignty → CSL score → text length → cost → domain match.
 *
 * @module routing/embedding-router
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib,
  CSL_THRESHOLDS,
  phiFusionWeights,
  phiBackoff,
  cslGate,
  cslBlend,
  sigmoid,
  adaptiveTemperature,
  nearestFib,
  ALERT_THRESHOLDS,
} = require('../shared/phi-math');

const {
  cosineSimilarity,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, dot, norm, vecAdd, vecSub, vecScale,
  hdcBIND, hdcBUNDLE, hdcRandomVector,
  moeRoute, isSemanticDuplicate, hashVector,
  EMBEDDING_DIM,
} = require('../shared/csl-engine');

// ─── CONSTANTS ──────────────────────────────────────────────────────────────────

/** LRU cache max entries = fib(20) = 6765 */
const CACHE_MAX_ENTRIES = fib(20);

/** LRU cache TTL = fib(17) * 1000 = 1,597,000 ms ≈ 26.6 min */
const CACHE_TTL_MS = fib(17) * 1000;

/** Circuit breaker failure threshold = fib(5) = 5 */
const CIRCUIT_FAILURE_THRESHOLD = fib(5);

/** Circuit breaker reset timeout = Math.round(1000 * PSI * fib(8)) ≈ 12978 ms */
const CIRCUIT_RESET_TIMEOUT_MS = Math.round(1000 * PSI * fib(8));

/** Circuit half-open probes = fib(3) = 2 */
const CIRCUIT_HALF_OPEN_PROBES = fib(3);

/** Cost cap per request = Math.pow(PSI, 10) * 0.1 ≈ $0.000618 */
const MAX_COST_PER_REQUEST = Math.pow(PSI, 10) * 0.1;

/** MRL target dimensions (L2-renormalized) */
const MRL_DIMENSIONS = Object.freeze([fib(11) + fib(7), fib(9) + fib(7), fib(7) + fib(6)]);
// fib(11)+fib(7)=89+13=102 — too small; use explicit values
const MRL_DIM_384 = 384;
const MRL_DIM_256 = 256;
const MRL_DIM_128 = 128;

/** MRL allowed target dimensions */
const MRL_TARGETS = Object.freeze([MRL_DIM_384, MRL_DIM_256, MRL_DIM_128]);

/** Circuit breaker states */
const CIRCUIT_STATE = Object.freeze({
  CLOSED:    'CLOSED',
  OPEN:      'OPEN',
  HALF_OPEN: 'HALF_OPEN',
});

/** Sovereignty flag: prefer local/open-source providers first */
const SOVEREIGNTY_PROVIDERS = Object.freeze(['bge_m3', 'nomic', 'gte_qwen2']);

// ─── PROVIDER REGISTRY ─────────────────────────────────────────────────────────

/**
 * Embedding provider configurations.
 * dimensions: native output dimensionality.
 * costPerToken: USD per token (≈ word-piece).
 */
const EMBEDDING_PROVIDERS = Object.freeze({
  nomic: {
    id:            'nomic',
    name:          'Nomic Embed',
    dimensions:    768,
    costPerToken:  Math.pow(PSI, 14) * 0.01,   // ≈ negligible
    maxBatch:      fib(8),                      // 21 texts
    domains:       ['general', 'code', 'science'],
    sovereign:     true,
    qualityScore:  PSI_SQ + PSI_CUBE,           // ≈ 0.618
  },
  jina: {
    id:            'jina',
    name:          'Jina Embeddings',
    dimensions:    1024,
    costPerToken:  Math.pow(PSI, 12) * 0.01,
    maxBatch:      fib(7),
    domains:       ['general', 'multilingual', 'search'],
    sovereign:     false,
    qualityScore:  PSI + PSI_SQ,                // ≈ 1.0 → clamp to 1
  },
  cohere: {
    id:            'cohere',
    name:          'Cohere Embed',
    dimensions:    1024,
    costPerToken:  Math.pow(PSI, 11) * 0.01,
    maxBatch:      fib(7),
    domains:       ['general', 'multilingual', 'rerank'],
    sovereign:     false,
    qualityScore:  PSI,                         // ≈ 0.618
  },
  voyage: {
    id:            'voyage',
    name:          'Voyage AI',
    dimensions:    2048,
    costPerToken:  Math.pow(PSI, 10) * 0.01,
    maxBatch:      fib(6),
    domains:       ['code', 'finance', 'law', 'science'],
    sovereign:     false,
    qualityScore:  PSI + PSI_CUBE,              // ≈ 0.854
  },
  bge_m3: {
    id:            'bge_m3',
    name:          'BGE-M3',
    dimensions:    1024,
    costPerToken:  0,
    maxBatch:      fib(8),
    domains:       ['multilingual', 'general', 'academic'],
    sovereign:     true,
    qualityScore:  PSI + PSI_SQ - PSI_CUBE,     // ≈ 0.764
  },
  gte_qwen2: {
    id:            'gte_qwen2',
    name:          'GTE-Qwen2',
    dimensions:    1536,
    costPerToken:  0,
    maxBatch:      fib(7),
    domains:       ['general', 'multilingual', 'long-context'],
    sovereign:     true,
    qualityScore:  PSI + PSI_SQ,                // ≈ 1.0 → clamped
  },
});

// ─── LRU CACHE ─────────────────────────────────────────────────────────────────

/**
 * @class LRUCache
 * Phi-sized LRU cache with TTL eviction.
 */
class LRUCache {
  /**
   * @param {number} maxEntries - Maximum cache entries
   * @param {number} ttlMs - Time-to-live in ms
   */
  constructor(maxEntries = CACHE_MAX_ENTRIES, ttlMs = CACHE_TTL_MS) {
    this._maxEntries = maxEntries;
    this._ttlMs      = ttlMs;
    /** @type {Map<string, { value: any, expires: number }>} Ordered map (LRU ordering via delete+set) */
    this._store = new Map();
    this._hits   = 0;
    this._misses = 0;
  }

  /**
   * Get a cached value, returning null if missing or expired.
   * @param {string} key
   * @returns {any|null}
   */
  get(key) {
    const entry = this._store.get(key);
    if (!entry) { this._misses++; return null; }
    if (Date.now() > entry.expires) {
      this._store.delete(key);
      this._misses++;
      return null;
    }
    // LRU refresh: delete and re-insert moves to end
    this._store.delete(key);
    this._store.set(key, entry);
    this._hits++;
    return entry.value;
  }

  /**
   * Set a value in the cache, evicting the LRU entry if at capacity.
   * @param {string} key
   * @param {any} value
   */
  set(key, value) {
    if (this._store.has(key)) this._store.delete(key);
    if (this._store.size >= this._maxEntries) {
      // Evict the first (oldest) entry
      const firstKey = this._store.keys().next().value;
      this._store.delete(firstKey);
    }
    this._store.set(key, { value, expires: Date.now() + this._ttlMs });
  }

  /**
   * Get cache statistics.
   * @returns {{ size: number, maxEntries: number, hits: number, misses: number, hitRate: number }}
   */
  getStats() {
    const total = this._hits + this._misses;
    return {
      size:       this._store.size,
      maxEntries: this._maxEntries,
      hits:       this._hits,
      misses:     this._misses,
      hitRate:    total > 0 ? this._hits / total : 0,
    };
  }
}

// ─── CLASS ─────────────────────────────────────────────────────────────────────

/**
 * @class EmbeddingRouter
 * @extends EventEmitter
 *
 * Phi-harmonic embedding router with CSL gating, LRU caching, MRL reduction,
 * per-provider circuit breakers, and cost caps.
 *
 * @fires EmbeddingRouter#embed - On successful embedding
 * @fires EmbeddingRouter#cacheHit - On LRU cache hit
 * @fires EmbeddingRouter#failover - On provider failure
 * @fires EmbeddingRouter#circuitOpen - On circuit breaker trip
 */
class EmbeddingRouter extends EventEmitter {
  /**
   * @param {object} [options={}]
   * @param {string} [options.domain='general'] - Routing domain hint
   * @param {boolean} [options.preferSovereign=true] - Prefer open-source providers
   * @param {number}  [options.mrlTarget] - MRL target dimension (must be in MRL_TARGETS)
   */
  constructor(options = {}) {
    super();

    this._domain         = options.domain          || 'general';
    this._preferSovereign = options.preferSovereign !== false;
    this._mrlTarget      = MRL_TARGETS.includes(options.mrlTarget)
      ? options.mrlTarget
      : null;

    /** @type {LRUCache} Embedding cache */
    this._cache = new LRUCache(CACHE_MAX_ENTRIES, CACHE_TTL_MS);

    /** @type {Map<string, object>} Circuit breaker per provider */
    this._circuits = new Map();

    /** @type {Map<string, object>} Latency & error health per provider */
    this._health = new Map();

    for (const cfg of Object.values(EMBEDDING_PROVIDERS)) {
      this._circuits.set(cfg.id, {
        state:      CIRCUIT_STATE.CLOSED,
        failures:   0,
        lastOpened: null,
        probeCount: 0,
      });
      this._health.set(cfg.id, {
        avgLatencyMs: 0,
        errorRate:    0.0,
        requestCount: 0,
        failureCount: 0,
        lastSuccess:  null,
      });
    }
  }

  // ─── PRIVATE: CIRCUIT BREAKER ──────────────────────────────────────────────

  /**
   * @private
   */
  _isCircuitAllowing(providerId) {
    const cb = this._circuits.get(providerId);
    if (!cb) return false;
    if (cb.state === CIRCUIT_STATE.CLOSED) return true;
    if (cb.state === CIRCUIT_STATE.OPEN) {
      if (Date.now() - cb.lastOpened >= CIRCUIT_RESET_TIMEOUT_MS) {
        cb.state = CIRCUIT_STATE.HALF_OPEN;
        cb.probeCount = 0;
      } else {
        return false;
      }
    }
    return cb.state === CIRCUIT_STATE.HALF_OPEN
      ? cb.probeCount < CIRCUIT_HALF_OPEN_PROBES
      : false;
  }

  /** @private */
  _recordSuccess(providerId, latencyMs) {
    const cb = this._circuits.get(providerId);
    const h  = this._health.get(providerId);
    if (!cb || !h) return;
    cb.failures = 0;
    h.requestCount++;
    h.lastSuccess  = Date.now();
    h.avgLatencyMs = h.avgLatencyMs * PSI + latencyMs * (1 - PSI);
    if (cb.state === CIRCUIT_STATE.HALF_OPEN) {
      if (++cb.probeCount >= CIRCUIT_HALF_OPEN_PROBES) {
        cb.state = CIRCUIT_STATE.CLOSED;
        this.emit('circuitClose', { providerId });
      }
    }
  }

  /** @private */
  _recordFailure(providerId) {
    const cb = this._circuits.get(providerId);
    const h  = this._health.get(providerId);
    if (!cb || !h) return;
    h.failureCount++;
    h.requestCount++;
    h.errorRate = h.failureCount / h.requestCount;
    if (++cb.failures >= CIRCUIT_FAILURE_THRESHOLD) {
      cb.state      = CIRCUIT_STATE.OPEN;
      cb.lastOpened = Date.now();
      this.emit('circuitOpen', { providerId, failures: cb.failures });
    }
  }

  // ─── PRIVATE: SCORING ──────────────────────────────────────────────────────

  /**
   * Score a provider for a given routing request.
   * CSL-gated composite: sovereignty + CSL(quality) + length fit + cost + domain.
   * @private
   * @param {string} providerId
   * @param {{ textLength: number, domain: string, querySimilarity: number }} ctx
   * @returns {number} Score ∈ [0, ∞)
   */
  _scoreProvider(providerId, ctx) {
    const provider = EMBEDDING_PROVIDERS[providerId];
    if (!provider) return 0;
    if (!this._isCircuitAllowing(providerId)) return 0;

    const weights = phiFusionWeights(5); // [0.448, 0.277, 0.171, 0.106, 0.065] approx

    // 1. Sovereignty bonus
    const sovereignScore = (this._preferSovereign && provider.sovereign) ? 1.0 : PSI_SQ;

    // 2. CSL-gated quality score
    const rawQuality   = Math.min(provider.qualityScore, 1.0);
    const cslQuality   = cslGate(rawQuality, ctx.querySimilarity, CSL_THRESHOLDS.MEDIUM);

    // 3. Text length fit: prefer providers with higher maxBatch for large text
    const lengthFit    = ctx.textLength <= fib(8) * fib(6) ? 1.0 : PSI;

    // 4. Cost efficiency: lower cost → higher score
    const costScore    = provider.costPerToken === 0 ? 1.0 : 1 - sigmoid(provider.costPerToken * fib(12));

    // 5. Domain match
    const domainScore  = provider.domains.includes(ctx.domain) ? 1.0 : PSI_SQ;

    return (
      weights[0] * sovereignScore +
      weights[1] * cslQuality     +
      weights[2] * lengthFit      +
      weights[3] * costScore      +
      weights[4] * domainScore
    );
  }

  // ─── PRIVATE: CACHE KEY ────────────────────────────────────────────────────

  /**
   * Generate a deterministic cache key for an embedding request.
   * @private
   * @param {string} text
   * @param {object} options
   * @returns {string} SHA-256 hex
   */
  _cacheKey(text, options) {
    const canonical = JSON.stringify({ text, dim: options.mrlTarget || this._mrlTarget });
    return crypto.createHash('sha256').update(canonical).digest('hex');
  }

  // ─── PRIVATE: MRL REDUCTION ────────────────────────────────────────────────

  /**
   * Matryoshka Representation Learning truncation with L2 renormalization.
   * Truncates to the leading `targetDim` components and re-normalizes.
   * @private
   * @param {number[]} embedding - Full-dimension embedding
   * @param {number}   targetDim - Target dimension
   * @returns {number[]} Reduced + renormalized embedding
   */
  _mrlReduce(embedding, targetDim) {
    if (targetDim >= embedding.length) return normalize(embedding);
    const truncated = embedding.slice(0, targetDim);
    return normalize(truncated);
  }

  // ─── PUBLIC: EMBED ─────────────────────────────────────────────────────────

  /**
   * Embed a single text, routing to the best available provider.
   * Uses LRU cache; applies MRL reduction if configured.
   *
   * @param {string} text - Text to embed
   * @param {object} [options={}]
   * @param {string} [options.domain] - Domain hint for routing
   * @param {number} [options.mrlTarget] - MRL target dimension
   * @returns {Promise<{ embedding: number[], providerId: string, cached: boolean, dim: number }>}
   */
  async embed(text, options = {}) {
    const key = this._cacheKey(text, options);
    const cached = this._cache.get(key);
    if (cached) {
      this.emit('cacheHit', { key });
      return { ...cached, cached: true };
    }

    const ctx = {
      textLength:      text.length,
      domain:          options.domain || this._domain,
      querySimilarity: CSL_THRESHOLDS.MEDIUM, // Default similarity assumption
    };

    // Rank providers by composite score
    const ranked = Object.keys(EMBEDDING_PROVIDERS)
      .map(id => ({ id, score: this._scoreProvider(id, ctx) }))
      .filter(p => p.score > 0)
      .sort((a, b) => b.score - a.score);

    let lastError = null;
    for (const { id } of ranked) {
      const t0 = Date.now();
      try {
        const rawEmbedding = await this._callProvider(id, text);
        const latencyMs    = Date.now() - t0;
        this._recordSuccess(id, latencyMs);

        // Apply MRL reduction if requested
        const mrlTarget = options.mrlTarget || this._mrlTarget;
        const embedding = mrlTarget ? this._mrlReduce(rawEmbedding, mrlTarget) : normalize(rawEmbedding);
        const dim       = embedding.length;

        const result = { embedding, providerId: id, cached: false, dim, latencyMs };
        this._cache.set(key, { embedding, providerId: id, dim, latencyMs });
        this.emit('embed', { providerId: id, dim, textLength: text.length });
        return result;

      } catch (err) {
        lastError = err;
        this._recordFailure(id);
        this.emit('failover', { from: id, error: err.message });
      }
    }

    throw lastError || new Error('All embedding providers unavailable');
  }

  /**
   * Route and embed a text — main public entry point (alias of embed with routing metadata).
   * @param {string} text
   * @param {object} [options={}]
   * @returns {Promise<object>}
   */
  async route(text, options = {}) {
    return this.embed(text, options);
  }

  /**
   * Internal provider call stub. In production, wires to SDK clients.
   * @private
   * @param {string} providerId
   * @param {string} text
   * @returns {Promise<number[]>} Raw embedding vector
   */
  async _callProvider(providerId, text) {
    const provider = EMBEDDING_PROVIDERS[providerId];
    // Stub: return phi-initialized random vector of correct dimension
    const dim = provider.dimensions;
    const v   = hdcRandomVector(dim);
    return v;
  }

  // ─── PUBLIC: STATUS ────────────────────────────────────────────────────────

  /**
   * Get LRU cache statistics.
   * @returns {{ size: number, maxEntries: number, hits: number, misses: number, hitRate: number }}
   */
  getCacheStats() {
    return this._cache.getStats();
  }

  /**
   * Get per-provider health and circuit state.
   * @returns {Array<object>}
   */
  getProviderHealth() {
    return Object.keys(EMBEDDING_PROVIDERS).map(id => {
      const h  = this._health.get(id);
      const cb = this._circuits.get(id);
      const p  = EMBEDDING_PROVIDERS[id];
      return {
        providerId:    id,
        name:          p.name,
        dimensions:    p.dimensions,
        sovereign:     p.sovereign,
        circuitState:  cb?.state || CIRCUIT_STATE.CLOSED,
        avgLatencyMs:  h?.avgLatencyMs || 0,
        errorRate:     h?.errorRate    || 0,
        requestCount:  h?.requestCount || 0,
        lastSuccess:   h?.lastSuccess ? new Date(h.lastSuccess).toISOString() : null,
      };
    });
  }
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  EmbeddingRouter,
  EMBEDDING_PROVIDERS,
  CIRCUIT_STATE,
  MRL_TARGETS,
  CACHE_MAX_ENTRIES,
  CACHE_TTL_MS,
};
