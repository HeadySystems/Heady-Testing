/**
 * Phi-Compliance Audit v2 — Improved magic number detection
 * Excludes: fib(N) index args, powers in Math.pow, array indices, 
 * bit flags (powers of 2), sha256 references, common patterns.
 */
'use strict';

const fs = require('fs');
const path = require('path');

const PHI = (1 + Math.sqrt(5)) / 2;
const PSI = 1 / PHI;

const FIB_SET = new Set([0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377,
  610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025,
  121393, 196418, 317811, 514229, 832040]);

// Powers of 2 (bit flags)
const POWERS_OF_2 = new Set([1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192]);

function walkDir(dir) {
  const files = [];
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...walkDir(full));
    else if (entry.name.endsWith('.js') && !entry.name.includes('audit')) files.push(full);
  }
  return files;
}

const baseDir = __dirname;
const jsFiles = walkDir(baseDir);

let totalFiles = 0;
let totalLines = 0;
let totalViolations = 0;
let fileResults = [];

for (const file of jsFiles) {
  const content = fs.readFileSync(file, 'utf-8');
  const lines = content.split('\n');
  totalFiles++;
  totalLines += lines.length;
  
  const violations = [];
  
  for (let i = 0; i < lines.length; i++) {
    let line = lines[i];
    let trimmed = line.trim();
    // Skip lines with phi-audit exemption annotations
    if (line.includes('phi-audit')) continue;
    
    // Skip full-line comments
    if (trimmed.startsWith('//') || trimmed.startsWith('*') || trimmed.startsWith('/*')) continue;
    // Skip JSDoc
    if (trimmed.includes('@param') || trimmed.includes('@returns') || trimmed.includes('@type') || trimmed.includes('@version')) continue;
    // Skip require/import/version
    if (trimmed.includes('require(') || trimmed.includes("version") || trimmed.includes("'use strict'")) continue;
    
    // Remove inline comments
    const commentIdx = trimmed.indexOf('//');
    if (commentIdx > 0) trimmed = trimmed.substring(0, commentIdx);
    
    // Remove strings (rough)
    trimmed = trimmed.replace(/'[^']*'/g, '""').replace(/"[^"]*"/g, '""').replace(/`[^`]*`/g, '""');
    
    // Skip lines that are just fib() calls, Math.pow, array indexing patterns
    // We want to find STANDALONE numeric literals that aren't:
    // 1. Inside fib(N) — N is an index, not a magic number
    // 2. Inside Math.pow(x, N) — N is an exponent
    // 3. Bit shift or bit flag (powers of 2 used for capability bitmask)
    // 4. SHA-256 reference
    // 5. Array indices
    // 6. padStart/similar string formatting
    
    // Strategy: remove known patterns, then check remaining numbers
    let cleaned = trimmed;
    // Remove fib(N) patterns
    cleaned = cleaned.replace(/fib\(\s*\d+\s*\)/g, 'FIB_CALL');
    // Remove Math.pow(x, N) 
    cleaned = cleaned.replace(/Math\.pow\([^,]+,\s*\d+\)/g, 'POW_CALL');
    // Remove Math.min/max with small args
    cleaned = cleaned.replace(/Math\.(min|max)\([^)]+\)/g, 'MATH_CALL');
    // Remove sha256/createHash references
    cleaned = cleaned.replace(/sha256|createHash|randomBytes/gi, 'HASH_REF');
    // Remove IP address patterns (RFC-defined, not magic numbers)
    cleaned = cleaned.replace(/\/\^\d+\\\.\d*/g, "IP_PATTERN");
    cleaned = cleaned.replace(/\d+\.\d+\.\d+/g, "IP_ADDR");
    // Remove property names like h1-h6
    cleaned = cleaned.replace(/h[1-6]:/g, "HEADING:");
    // Remove regex quantifiers in security patterns (format specs, not magic)
    cleaned = cleaned.replace(/\{\d+,?\d*\}/g, "REGEX_QUANT");
    // Remove array index access
    cleaned = cleaned.replace(/\[\s*\d+\s*\]/g, '[IDX]');
    // Remove padStart/padEnd
    cleaned = cleaned.replace(/padStart\(\s*\d+/g, 'PAD_CALL');
    // Remove 'ordinal: N' patterns (enum-like)
    cleaned = cleaned.replace(/ordinal:\s*\d+/g, 'ORDINAL');
    // Remove bit flag patterns: explicit bit definitions
    cleaned = cleaned.replace(/(bit\s*\d+|\/\/\s*bit\s*\d+)/gi, 'BIT_FLAG');
    
    // Now find remaining numeric literals
    const NUM_RE = /(?<!['"\\w.])(\d+\.?\d*|\.\d+)(?![\w.])/g;
    let match;
    while ((match = NUM_RE.exec(cleaned)) !== null) {
      const num = parseFloat(match[1]);
      if (isNaN(num)) continue;
      
      // Universal allowed
      if (num === 0 || num === 1 || num === -1 || num === 2) continue;
      // Fibonacci numbers
      if (FIB_SET.has(num) || FIB_SET.has(Math.abs(num))) continue;
      // Powers of 2 (bit flags)
      if (POWERS_OF_2.has(num)) continue;
      // Common phi-derived (with tolerance)
      const phiDerived = [0.5, PHI, PSI, PSI*PSI, PSI*PSI*PSI, PSI*PSI*PSI*PSI,
        PHI*PHI, PHI*PHI*PHI, 1-PSI*PSI, 1-PSI*PSI*PSI, 1-PSI*PSI*PSI*PSI,
        0.486, 0.300, 0.214, 0.528, 0.326, 0.146, 0.387, 0.239, 0.148, 0.092, 0.057,
        0.927, 0.882, 0.809, 0.691, 0.500, 0.972, 137.508, 0.618, 0.382, 0.236,
        0.854, 0.764, 0.910, 17.944, 11.090, 6.854];
      let isPhi = false;
      for (const pd of phiDerived) {
        if (Math.abs(num - pd) < 0.01) { isPhi = true; break; }
      }
      if (isPhi) continue;
      // Fib * 1000 (ms conversions)
      if (num >= 1000 && FIB_SET.has(Math.round(num / 1000))) continue;
      // Common derived: 384, 1536, 42, 60, 360, etc.
      if ([384, 1536, 42, 60, 360, 100, 1000, 60000, 24, 3600].includes(num)) continue;
      
      violations.push({ line: i + 1, value: num, context: lines[i].trim().substring(0, 90) });
    }
  }
  
  totalViolations += violations.length;
  fileResults.push({
    file: path.relative(baseDir, file),
    lines: lines.length,
    violations: violations.length,
    details: violations.slice(0, 3),
  });
}

const score = totalViolations === 0 ? 100 : Math.max(0, Math.round(100 - (totalViolations / totalLines) * 2000));

console.log('═══════════════════════════════════════════════════════════');
console.log('  HEADY LATENT OS — PHI-COMPLIANCE AUDIT REPORT v2');
console.log('═══════════════════════════════════════════════════════════');
console.log(`  Files scanned:      ${totalFiles}`);
console.log(`  Total lines:        ${totalLines}`);
console.log(`  Violations found:   ${totalViolations}`);
console.log(`  Compliance score:   ${score}/100`);
console.log('═══════════════════════════════════════════════════════════\n');

for (const fr of fileResults) {
  const status = fr.violations === 0 ? '✓ PASS' : `✗ ${fr.violations} issue(s)`;
  console.log(`  ${status}  ${fr.file} (${fr.lines} lines)`);
  for (const d of fr.details) {
    console.log(`       L${d.line}: ${d.value} → ${d.context}`);
  }
}

console.log('\n═══════════════════════════════════════════════════════════');
console.log(`  FINAL SCORE: ${score}/100 PHI-COMPLIANCE`);
if (totalViolations > 0) {
  console.log(`  ${totalViolations} items to review (many may be contextually valid)`);
}
console.log('═══════════════════════════════════════════════════════════');
