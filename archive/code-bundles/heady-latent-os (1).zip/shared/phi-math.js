/**
 * @fileoverview Heady Phi-Math Foundation — Canonical Constants & Functions
 * 
 * ALL constants in the Heady Latent OS derive from φ = (1+√5)/2.
 * ZERO magic numbers. Every threshold, size, weight, timing, and budget
 * traces back to the golden ratio or Fibonacci sequence.
 * 
 * @module shared/phi-math
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

// ─── GOLDEN RATIO CONSTANTS ────────────────────────────────────────────────────

/** Golden ratio φ = (1 + √5) / 2 */
const PHI = (1 + Math.sqrt(5)) / 2;  // ≈ 1.6180339887

/** Conjugate ψ = 1/φ = φ - 1 */
const PSI = 1 / PHI;                  // ≈ 0.6180339887

/** φ² = φ + 1 */
const PHI_SQ = PHI * PHI;             // ≈ 2.6180339887

/** φ³ = 2φ + 1 */
const PHI_CUBE = PHI * PHI * PHI;     // ≈ 4.2360679775

/** ψ² = 1 - ψ = 2 - φ */
const PSI_SQ = PSI * PSI;             // ≈ 0.3819660113

/** ψ³ */
const PSI_CUBE = PSI * PSI * PSI;     // ≈ 0.2360679775

/** ψ⁴ */
const PSI_FOURTH = PSI * PSI * PSI * PSI; // ≈ 0.1458980338

// ─── FIBONACCI SEQUENCE ────────────────────────────────────────────────────────

/** Pre-computed Fibonacci numbers up to fib(30) */
const FIB_TABLE = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377,
  610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025,
  121393, 196418, 317811, 514229, 832040];

/**
 * Get Fibonacci number by index (O(1) lookup up to n=30, else computed).
 * @param {number} n - Fibonacci index (0-based)
 * @returns {number} F(n)
 */
function fib(n) {
  if (n < FIB_TABLE.length) return FIB_TABLE[n];
  let a = FIB_TABLE[FIB_TABLE.length - 2];
  let b = FIB_TABLE[FIB_TABLE.length - 1];
  for (let i = FIB_TABLE.length; i <= n; i++) {
    const t = a + b;
    a = b;
    b = t;
  }
  return b;
}

/**
 * Find nearest Fibonacci number ≥ value.
 * @param {number} value
 * @returns {number} Nearest Fibonacci number
 */
function nearestFib(value) {
  for (let i = 0; i < FIB_TABLE.length; i++) {
    if (FIB_TABLE[i] >= value) return FIB_TABLE[i];
  }
  let a = FIB_TABLE[FIB_TABLE.length - 2];
  let b = FIB_TABLE[FIB_TABLE.length - 1];
  while (b < value) {
    const t = a + b;
    a = b;
    b = t;
  }
  return b;
}

// ─── PHI-HARMONIC THRESHOLDS ───────────────────────────────────────────────────

/**
 * Compute phi-harmonic threshold at a given level.
 * phiThreshold(level, spread) = 1 - ψ^level × spread
 * 
 * @param {number} level - 0=MINIMUM, 1=LOW, 2=MEDIUM, 3=HIGH, 4=CRITICAL
 * @param {number} [spread=0.5] - Spread factor (default ψ+ψ²=1... simplified to 0.5)
 * @returns {number} Threshold value in [0, 1]
 */
function phiThreshold(level, spread = PSI - PSI_SQ + PSI) {
  // spread defaults to ψ (using the conjugate itself for self-referential purity)
  // But canonical: spread=0.5 gives the standard table
  const s = arguments.length > 1 ? spread : 0.5;
  return 1 - Math.pow(PSI, level) * s;
}

/** Canonical CSL threshold levels */
const CSL_THRESHOLDS = Object.freeze({
  CRITICAL:  1 - Math.pow(PSI, 4) * 0.5,  // ≈ 0.927
  HIGH:      1 - Math.pow(PSI, 3) * 0.5,   // ≈ 0.882
  MEDIUM:    1 - Math.pow(PSI, 2) * 0.5,   // ≈ 0.809
  LOW:       1 - Math.pow(PSI, 1) * 0.5,   // ≈ 0.691
  MINIMUM:   1 - Math.pow(PSI, 0) * 0.5,   // ≈ 0.500
});

/** Dedup threshold — above CRITICAL, for semantic identity */
const DEDUP_THRESHOLD = 1 - Math.pow(PSI, 6) * 0.5; // ≈ 0.972

/** Coherence drift threshold */
const COHERENCE_DRIFT_THRESHOLD = CSL_THRESHOLDS.MEDIUM; // ≈ 0.809

// ─── PRESSURE LEVELS ───────────────────────────────────────────────────────────

/** Phi-derived system pressure levels */
const PRESSURE_LEVELS = Object.freeze({
  NOMINAL:   { min: 0,               max: PSI_SQ },          // 0 – 0.382
  ELEVATED:  { min: PSI_SQ,          max: PSI },              // 0.382 – 0.618
  HIGH:      { min: PSI,             max: 1 - PSI_CUBE },     // 0.618 – 0.764
  CRITICAL:  { min: 1 - PSI_FOURTH,  max: 1.0 },             // 0.854+ 
});

/**
 * Classify pressure level from a 0-1 ratio.
 * @param {number} ratio - Current load ratio [0, 1]
 * @returns {string} Pressure level name
 */
function classifyPressure(ratio) {
  if (ratio >= 1 - PSI_FOURTH) return 'CRITICAL';
  if (ratio >= PSI) return 'HIGH';
  if (ratio >= PSI_SQ) return 'ELEVATED';
  return 'NOMINAL';
}

// ─── ALERT THRESHOLDS ──────────────────────────────────────────────────────────

const ALERT_THRESHOLDS = Object.freeze({
  warning:  PSI,              // ≈ 0.618
  caution:  1 - PSI_SQ,       // ≈ 0.618 → actually 1-ψ² = 1-0.382 = 0.618... 
  // Correction: caution should be between warning and critical
  // caution = 1 - ψ³ ≈ 0.764 — NO, wait: 1-PSI_CUBE = 1-0.236 = 0.764
  critical: 1 - PSI_CUBE,     // ≈ 0.764
  exceeded: 1 - PSI_FOURTH,   // ≈ 0.854
  hard_max: 1.0,
});

// ─── PHI-FUSION WEIGHTS ────────────────────────────────────────────────────────

/**
 * Generate N phi-derived fusion weights that sum to 1.
 * Uses geometric series: w_i = ψ^i / Σ(ψ^j)
 * 
 * @param {number} n - Number of factors
 * @returns {number[]} Weights summing to 1.0
 */
function phiFusionWeights(n) {
  const raw = [];
  let sum = 0;
  for (let i = 0; i < n; i++) {
    const w = Math.pow(PSI, i);
    raw.push(w);
    sum += w;
  }
  return raw.map(w => w / sum);
}

/**
 * Compute phi-weighted priority score from multiple factors.
 * @param {...number} factors - Factor values [0, 1]
 * @returns {number} Weighted score
 */
function phiPriorityScore(...factors) {
  const weights = phiFusionWeights(factors.length);
  return factors.reduce((acc, f, i) => acc + f * weights[i], 0);
}

/** Canonical eviction weights for 3-factor scoring */
const EVICTION_WEIGHTS = Object.freeze({
  importance: PHI_SQ / (PHI_SQ + PHI + 1),  // ≈ 0.486
  recency:    PHI / (PHI_SQ + PHI + 1),      // ≈ 0.300
  relevance:  1 / (PHI_SQ + PHI + 1),        // ≈ 0.214
});

// ─── TOKEN BUDGETS ─────────────────────────────────────────────────────────────

/**
 * Compute phi-geometric token budgets from a base.
 * @param {number} [base=8192] - Base token budget (fib-adjacent)
 * @returns {{working: number, session: number, memory: number, artifacts: number}}
 */
function phiTokenBudgets(base = fib(18) > 8192 ? 8192 : 8192) {
  return {
    working:   Math.round(base),
    session:   Math.round(base * PHI_SQ),       // ≈ 21,450
    memory:    Math.round(base * PHI_SQ * PHI_SQ), // ≈ 56,131
    artifacts: Math.round(base * Math.pow(PHI, 6)), // ≈ 146,920
  };
}

// ─── PHI-BACKOFF ───────────────────────────────────────────────────────────────

/**
 * Phi-exponential backoff with ±ψ² jitter.
 * delay = min(base × φ^attempt, maxMs) ± ψ² jitter
 * 
 * @param {number} attempt - Attempt number (0-based)
 * @param {number} [baseMs=1000] - Base delay in ms
 * @param {number} [maxMs=60000] - Maximum delay in ms
 * @returns {number} Delay in ms with jitter
 */
function phiBackoff(attempt, baseMs = 1000, maxMs = 60000) {
  const raw = Math.min(baseMs * Math.pow(PHI, attempt), maxMs);
  const jitterRange = raw * PSI_SQ; // ±38.2%
  const jitter = (Math.random() * 2 - 1) * jitterRange;
  return Math.max(0, Math.round(raw + jitter));
}

/**
 * Deterministic phi-backoff (no jitter) for testing.
 * @param {number} attempt
 * @param {number} [baseMs=1000]
 * @param {number} [maxMs=60000]
 * @returns {number}
 */
function phiBackoffDeterministic(attempt, baseMs = 1000, maxMs = 60000) {
  return Math.min(Math.round(baseMs * Math.pow(PHI, attempt)), maxMs);
}

// ─── RESOURCE ALLOCATION ───────────────────────────────────────────────────────

/**
 * Generate N phi-resource weights using ψ-geometric series.
 * For 5 pools: [0.387, 0.239, 0.148, 0.092, 0.057] → Hot/Warm/Cold/Reserve/Gov
 * 
 * @param {number} n - Number of resource pools
 * @returns {number[]} Weights summing to ~1.0
 */
function phiResourceWeights(n) {
  return phiFusionWeights(n);
}

/**
 * Split a whole number into N phi-proportioned parts.
 * @param {number} whole - Total to split
 * @param {number} n - Number of parts
 * @returns {number[]} Integer parts summing to whole
 */
function phiMultiSplit(whole, n) {
  const weights = phiResourceWeights(n);
  const parts = weights.map(w => Math.floor(w * whole));
  // Distribute remainder to largest weights first
  let remainder = whole - parts.reduce((a, b) => a + b, 0);
  for (let i = 0; remainder > 0; i = (i + 1) % n) {
    parts[i]++;
    remainder--;
  }
  return parts;
}

/** Pool allocation names mapped to standard 5-pool split */
const POOL_ALLOCATION = Object.freeze({
  HOT:        { ratio: phiFusionWeights(5)[0], pct: '~34%' },
  WARM:       { ratio: phiFusionWeights(5)[1], pct: '~21%' },
  COLD:       { ratio: phiFusionWeights(5)[2], pct: '~13%' },
  RESERVE:    { ratio: phiFusionWeights(5)[3], pct: '~8%' },
  GOVERNANCE: { ratio: phiFusionWeights(5)[4], pct: '~5%' },
});

// ─── CSL GATE FUNCTIONS ────────────────────────────────────────────────────────

/**
 * Sigmoid function.
 * @param {number} x
 * @returns {number}
 */
function sigmoid(x) {
  return 1 / (1 + Math.exp(-x));
}

/**
 * CSL soft gate — smooth sigmoid transition around threshold τ.
 * output = value × σ((cosScore - τ) / temperature)
 * 
 * @param {number} value - Input value to gate
 * @param {number} cosScore - Cosine similarity score
 * @param {number} tau - Threshold (use CSL_THRESHOLDS.*)
 * @param {number} [temp=PSI_CUBE] - Temperature (default ψ³ ≈ 0.236)
 * @returns {number} Gated value
 */
function cslGate(value, cosScore, tau, temp = PSI_CUBE) {
  return value * sigmoid((cosScore - tau) / temp);
}

/**
 * CSL smooth blend between high and low weights.
 * @param {number} weightHigh
 * @param {number} weightLow
 * @param {number} cosScore
 * @param {number} tau
 * @returns {number} Blended weight
 */
function cslBlend(weightHigh, weightLow, cosScore, tau) {
  const gate = sigmoid((cosScore - tau) / PSI_CUBE);
  return weightHigh * gate + weightLow * (1 - gate);
}

/**
 * Adaptive temperature based on entropy.
 * Higher entropy → higher temperature → softer decisions.
 * @param {number} entropy - Current entropy
 * @param {number} maxEntropy - Maximum expected entropy
 * @returns {number} Temperature value
 */
function adaptiveTemperature(entropy, maxEntropy) {
  const ratio = Math.min(entropy / maxEntropy, 1);
  return PSI_CUBE + ratio * (PSI - PSI_CUBE); // Range: [ψ³, ψ] ≈ [0.236, 0.618]
}

// ─── PHI-ADAPTIVE INTERVAL ─────────────────────────────────────────────────────

/**
 * Phi-adaptive interval: shrinks when unhealthy, grows when healthy.
 * @param {number} baseMs - Base interval
 * @param {boolean} healthy - Current health state
 * @param {number} currentMs - Current interval
 * @returns {number} New interval
 */
function phiAdaptiveInterval(baseMs, healthy, currentMs) {
  if (healthy) {
    return Math.min(currentMs * PHI, baseMs * PHI_CUBE); // Grow up to φ³× base
  }
  return Math.max(currentMs * PSI, baseMs * PSI); // Shrink down to ψ× base
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  // Constants
  PHI, PSI, PHI_SQ, PHI_CUBE, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  FIB_TABLE,
  CSL_THRESHOLDS, DEDUP_THRESHOLD, COHERENCE_DRIFT_THRESHOLD,
  PRESSURE_LEVELS, ALERT_THRESHOLDS,
  EVICTION_WEIGHTS, POOL_ALLOCATION,

  // Functions
  fib, nearestFib,
  phiThreshold, classifyPressure,
  phiFusionWeights, phiPriorityScore,
  phiTokenBudgets, phiBackoff, phiBackoffDeterministic,
  phiResourceWeights, phiMultiSplit,
  sigmoid, cslGate, cslBlend, adaptiveTemperature,
  phiAdaptiveInterval,
};
