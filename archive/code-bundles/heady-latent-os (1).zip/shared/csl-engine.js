/**
 * @fileoverview CSL Engine — Continuous Semantic Logic Gates
 * 
 * Geometric logic using vector operations. Every gate parameter derives from φ.
 * Domain: unit vectors in ℝᴰ, D ∈ {384, 1536}.
 * Truth value: τ(a,b) = cos(θ) ∈ [-1, +1]
 * 
 * @module shared/csl-engine
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
        CSL_THRESHOLDS, DEDUP_THRESHOLD,
        sigmoid, cslGate, cslBlend, adaptiveTemperature,
        fib, phiFusionWeights } = require('./phi-math');
const { cosineSimilarity } = require('./sacred-geometry');

// ─── VECTOR UTILITIES ──────────────────────────────────────────────────────────

const EMBEDDING_DIM = fib(16) === 987 ? 384 : 384; // Standard: 384D
const EMBEDDING_DIM_LARGE = 1536;

/**
 * Normalize a vector to unit length.
 * @param {number[]} v
 * @returns {number[]}
 */
function normalize(v) {
  let norm = 0;
  for (let i = 0; i < v.length; i++) norm += v[i] * v[i];
  norm = Math.sqrt(norm);
  if (norm === 0) return v.slice();
  return v.map(x => x / norm);
}

/**
 * Dot product of two vectors.
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number}
 */
function dot(a, b) {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += a[i] * b[i];
  return s;
}

/**
 * L2 norm of a vector.
 * @param {number[]} v
 * @returns {number}
 */
function norm(v) {
  let s = 0;
  for (let i = 0; i < v.length; i++) s += v[i] * v[i];
  return Math.sqrt(s);
}

/**
 * Vector addition.
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number[]}
 */
function vecAdd(a, b) {
  return a.map((v, i) => v + b[i]);
}

/**
 * Vector subtraction.
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number[]}
 */
function vecSub(a, b) {
  return a.map((v, i) => v - b[i]);
}

/**
 * Scalar multiplication.
 * @param {number[]} v
 * @param {number} s
 * @returns {number[]}
 */
function vecScale(v, s) {
  return v.map(x => x * s);
}

// ─── CSL GATES ─────────────────────────────────────────────────────────────────

/**
 * CSL AND — Semantic alignment measure.
 * τ(a,b) = cos(a,b) = (a·b)/(‖a‖·‖b‖)
 * 
 * @param {number[]} a - Unit vector
 * @param {number[]} b - Unit vector
 * @returns {number} Truth value ∈ [-1, +1]
 */
function cslAND(a, b) {
  return cosineSimilarity(a, b);
}

/**
 * CSL OR — Superposition (soft union).
 * normalize(a + b)
 * 
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number[]} Normalized superposition vector
 */
function cslOR(a, b) {
  return normalize(vecAdd(a, b));
}

/**
 * CSL NOT — Orthogonal projection (semantic negation).
 * NOT(a, b) = a - proj_b(a) = a - (a·b/‖b‖²)·b
 * 
 * Properties: idempotent, result orthogonal to b.
 * 
 * @param {number[]} a - Vector to negate with respect to b
 * @param {number[]} b - Reference vector
 * @returns {number[]} Component of a orthogonal to b
 */
function cslNOT(a, b) {
  const bNormSq = dot(b, b);
  if (bNormSq === 0) return a.slice();
  const projScale = dot(a, b) / bNormSq;
  const proj = vecScale(b, projScale);
  return vecSub(a, proj);
}

/**
 * CSL IMPLY — Projection onto reference direction.
 * IMPLY(a, b) = proj_b(a) = (a·b/‖b‖²)·b
 * 
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number[]} Component of a in direction of b
 */
function cslIMPLY(a, b) {
  const bNormSq = dot(b, b);
  if (bNormSq === 0) return new Array(a.length).fill(0);
  const projScale = dot(a, b) / bNormSq;
  return vecScale(b, projScale);
}

/**
 * CSL XOR — Exclusive components.
 * Removes mutual projection, keeps what's unique to each.
 * 
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number[]} Normalized exclusive component
 */
function cslXOR(a, b) {
  const mutual = normalize(vecAdd(a, b));
  const combined = vecAdd(a, b);
  const mutualProj = cslIMPLY(combined, mutual);
  const exclusive = vecSub(combined, mutualProj);
  const n = norm(exclusive);
  return n > 0 ? normalize(exclusive) : exclusive;
}

/**
 * CSL CONSENSUS — Weighted centroid of multiple vectors.
 * consensus = normalize(Σ(wᵢ·vᵢ))
 * Uses phi-fusion weights by default.
 * 
 * @param {number[][]} vectors - Array of unit vectors
 * @param {number[]} [weights] - Optional weights (default: phi-fusion)
 * @returns {number[]} Normalized consensus vector
 */
function cslCONSENSUS(vectors, weights) {
  if (vectors.length === 0) throw new Error('Cannot compute consensus of empty set');
  const w = weights || phiFusionWeights(vectors.length);
  const dim = vectors[0].length;
  const sum = new Array(dim).fill(0);
  for (let i = 0; i < vectors.length; i++) {
    for (let d = 0; d < dim; d++) {
      sum[d] += w[i] * vectors[i][d];
    }
  }
  return normalize(sum);
}

/**
 * CSL GATE — Soft sigmoid gating with phi-scaled temperature.
 * output = value × σ((cosScore - τ) / temperature)
 * 
 * @param {number} value - Input value
 * @param {number} cosScore - Cosine similarity score
 * @param {number} [level=2] - CSL level (0-4)
 * @returns {number} Gated value
 */
function cslPhiGATE(value, cosScore, level = 2) {
  const thresholds = [
    CSL_THRESHOLDS.MINIMUM, CSL_THRESHOLDS.LOW,
    CSL_THRESHOLDS.MEDIUM, CSL_THRESHOLDS.HIGH,
    CSL_THRESHOLDS.CRITICAL,
  ];
  const tau = thresholds[Math.min(level, 4)];
  return cslGate(value, cosScore, tau, PSI_CUBE);
}

// ─── TERNARY LOGIC ─────────────────────────────────────────────────────────────

/**
 * Map continuous cosine to ternary truth: TRUE / UNKNOWN / FALSE.
 * TRUE: cos ≥ threshold, UNKNOWN: |cos| < threshold, FALSE: cos ≤ -threshold
 * 
 * @param {number} cosScore
 * @param {number} [threshold=CSL_THRESHOLDS.MINIMUM] ≈ 0.500
 * @returns {'TRUE'|'UNKNOWN'|'FALSE'}
 */
function ternaryClassify(cosScore, threshold = CSL_THRESHOLDS.MINIMUM) {
  if (cosScore >= threshold) return 'TRUE';
  if (cosScore <= -threshold) return 'FALSE';
  return 'UNKNOWN';
}

/** Kleene K3 ternary AND */
function ternaryAND_K3(a, b) {
  return Math.min(a, b);
}

/** Kleene K3 ternary OR */
function ternaryOR_K3(a, b) {
  return Math.max(a, b);
}

/** Łukasiewicz bounded AND */
function ternaryAND_Lukasiewicz(a, b) {
  return Math.max(a + b - 1, -1);
}

/** Łukasiewicz bounded OR */
function ternaryOR_Lukasiewicz(a, b) {
  return Math.min(a + b + 1, 1);
}

/** Gödel ternary AND (min) */
function ternaryAND_Godel(a, b) { return Math.min(a, b); }

/** Gödel ternary OR (max) */
function ternaryOR_Godel(a, b) { return Math.max(a, b); }

/** Product ternary AND */
function ternaryAND_Product(a, b) {
  return ((a + 1) / 2) * ((b + 1) / 2) * 2 - 1;
}

/** CSL-continuous AND: direct cosine composition */
function ternaryAND_CSL(a, b) {
  return a * b; // Maps [-1,1] × [-1,1] → [-1,1], preserves sign logic
}

// ─── HDC / VSA OPERATIONS ──────────────────────────────────────────────────────

/** HDC vector capacity at 384D: ~96 items */
const HDC_CAPACITY = Math.floor(Math.sqrt(384)); // ≈ 19.6, but analytical ~96

/**
 * HDC BIND — Create compositional representation.
 * For real-valued HRR: circular convolution approximated by element-wise multiply.
 * 
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number[]}
 */
function hdcBIND(a, b) {
  return a.map((v, i) => v * b[i]);
}

/**
 * HDC BUNDLE — Aggregate via normalized sum.
 * @param {number[][]} vectors
 * @returns {number[]}
 */
function hdcBUNDLE(vectors) {
  const dim = vectors[0].length;
  const sum = new Array(dim).fill(0);
  for (const v of vectors) {
    for (let i = 0; i < dim; i++) sum[i] += v[i];
  }
  return normalize(sum);
}

/**
 * HDC PERMUTE — Sequence encoding via cyclic shift.
 * @param {number[]} v
 * @param {number} n - Shift amount
 * @returns {number[]}
 */
function hdcPERMUTE(v, n) {
  const len = v.length;
  const shift = ((n % len) + len) % len;
  return [...v.slice(len - shift), ...v.slice(0, len - shift)];
}

/**
 * Generate a random hypervector for codebook entry.
 * Uses phi-scaled initialization.
 * 
 * @param {number} dim
 * @returns {number[]}
 */
function hdcRandomVector(dim = 384) {
  const v = new Array(dim);
  for (let i = 0; i < dim; i++) {
    v[i] = (Math.random() - PSI) * PHI; // Center around -ψ, scale by φ
  }
  return normalize(v);
}

// ─── MOE CSL ROUTER ────────────────────────────────────────────────────────────

/**
 * Mixture-of-Experts routing using CSL cosine similarity.
 * Replaces learned linear weights with geometric routing.
 * 
 * @param {number[]} input - Input embedding
 * @param {number[][]} expertGates - Expert gate vectors
 * @param {number} [k=2] - Top-k experts (fib(3) = 2)
 * @param {number} [temperature=PSI_CUBE] - Softmax temperature
 * @returns {Array<{expertIdx: number, weight: number}>}
 */
function moeRoute(input, expertGates, k = fib(3), temperature = PSI_CUBE) {
  // Compute cosine scores
  const scores = expertGates.map((gate, i) => ({
    expertIdx: i,
    score: cosineSimilarity(input, gate),
  }));

  // Softmax with phi-temperature
  const maxScore = Math.max(...scores.map(s => s.score));
  const expScores = scores.map(s => ({
    ...s,
    exp: Math.exp((s.score - maxScore) / temperature),
  }));
  const expSum = expScores.reduce((sum, s) => sum + s.exp, 0);
  const probs = expScores.map(s => ({ ...s, weight: s.exp / expSum }));

  // Top-K selection
  probs.sort((a, b) => b.weight - a.weight);
  const selected = probs.slice(0, k);

  // Renormalize selected weights
  const selSum = selected.reduce((sum, s) => sum + s.weight, 0);
  return selected.map(s => ({
    expertIdx: s.expertIdx,
    weight: s.weight / selSum,
  }));
}

/**
 * Detect MoE collapse: if max probability exceeds threshold, experts collapsed.
 * @param {number[]} probs - Expert probabilities
 * @returns {boolean}
 */
function detectMoeCollapse(probs) {
  const maxProb = Math.max(...probs);
  const antiCollapseThreshold = 1 - Math.pow(PSI, 8); // ≈ 0.987
  return maxProb > antiCollapseThreshold;
}

/** Anti-collapse regularization weight: ψ⁸ ≈ 0.0131 */
const MOE_ANTI_COLLAPSE_WEIGHT = Math.pow(PSI, 8);

/** Collapse detection threshold: ψ⁹ ≈ 0.0081 */
const MOE_COLLAPSE_THRESHOLD = Math.pow(PSI, 9);

// ─── SEMANTIC IDENTITY ─────────────────────────────────────────────────────────

/**
 * Check if two vectors are semantically identical (above dedup threshold).
 * @param {number[]} a
 * @param {number[]} b
 * @returns {boolean}
 */
function isSemanticDuplicate(a, b) {
  return cosineSimilarity(a, b) >= DEDUP_THRESHOLD;
}

/**
 * Hash a vector for deterministic identity.
 * @param {number[]} v
 * @returns {string} SHA-256 hex hash
 */
function hashVector(v) {
  const buf = Buffer.from(new Float64Array(v).buffer);
  return crypto.createHash('sha256').update(buf).digest('hex');
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  // Constants
  EMBEDDING_DIM, EMBEDDING_DIM_LARGE, HDC_CAPACITY,
  MOE_ANTI_COLLAPSE_WEIGHT, MOE_COLLAPSE_THRESHOLD,

  // Vector utilities
  normalize, dot, norm, vecAdd, vecSub, vecScale,

  // CSL Gates
  cslAND, cslOR, cslNOT, cslIMPLY, cslXOR, cslCONSENSUS, cslPhiGATE,

  // Ternary logic
  ternaryClassify,
  ternaryAND_K3, ternaryOR_K3,
  ternaryAND_Lukasiewicz, ternaryOR_Lukasiewicz,
  ternaryAND_Godel, ternaryOR_Godel,
  ternaryAND_Product, ternaryAND_CSL,

  // HDC/VSA
  hdcBIND, hdcBUNDLE, hdcPERMUTE, hdcRandomVector,

  // MoE Router
  moeRoute, detectMoeCollapse,

  // Identity
  isSemanticDuplicate, hashVector,
};
