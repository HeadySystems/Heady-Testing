/**
 * @fileoverview Sacred Geometry — Ring Topology, Node Placement, Coherence Scoring
 * 
 * Every node in the Heady Latent OS occupies a position in a Sacred Geometry
 * topology derived from φ. Ring placement, coherence measurement, and UI 
 * spacing all trace back to the golden ratio.
 * 
 * @module shared/sacred-geometry
 * @version 3.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const { PHI, PSI, PSI_SQ, fib, phiFusionWeights, CSL_THRESHOLDS, COHERENCE_DRIFT_THRESHOLD } = require('./phi-math');

// ─── RING TOPOLOGY ─────────────────────────────────────────────────────────────

/** Ring definitions: each ring at φ-scaled radius from center */
const RINGS = Object.freeze({
  CENTRAL: {
    name: 'Central Hub',
    radius: 0,
    nodes: ['HeadySoul'],
    role: 'Awareness, values, coherence guardian',
  },
  INNER: {
    name: 'Inner Ring',
    radius: PSI,              // ≈ 0.618
    nodes: ['HeadyBrains', 'HeadyConductor', 'HeadyVinci'],
    role: 'Processing core — orchestration, reasoning, planning',
  },
  MIDDLE: {
    name: 'Middle Ring',
    radius: 1.0,              // Unit radius
    nodes: ['JULES', 'BUILDER', 'OBSERVER', 'MURPHY', 'ATLAS', 'PYTHIA'],
    role: 'Execution layer — coding, building, monitoring, security, docs, analysis',
  },
  OUTER: {
    name: 'Outer Ring',
    radius: PHI,              // ≈ 1.618
    nodes: ['BRIDGE', 'MUSE', 'SENTINEL', 'NOVA', 'JANITOR', 'SOPHIA', 'CIPHER', 'LENS'],
    role: 'Specialized capabilities — translation, creativity, security, innovation',
  },
  GOVERNANCE: {
    name: 'Governance Shell',
    radius: PHI * PHI,        // φ² ≈ 2.618
    nodes: ['HeadyCheck', 'HeadyAssure', 'HeadyAware', 'HeadyPatterns', 'HeadyMC', 'HeadyRisk'],
    role: 'Quality, assurance, ethics, patterns, Monte Carlo, risk',
  },
});

/**
 * Get all nodes across all rings.
 * @returns {string[]}
 */
function getAllNodes() {
  const nodes = [];
  for (const ring of Object.values(RINGS)) {
    nodes.push(...ring.nodes);
  }
  return nodes;
}

/**
 * Find which ring a node belongs to.
 * @param {string} nodeName
 * @returns {{ ringKey: string, ring: object } | null}
 */
function findNodeRing(nodeName) {
  for (const [key, ring] of Object.entries(RINGS)) {
    if (ring.nodes.includes(nodeName)) {
      return { ringKey: key, ring };
    }
  }
  return null;
}

// ─── NODE PLACEMENT ────────────────────────────────────────────────────────────

/**
 * Compute 2D position of a node on its ring using golden angle distribution.
 * Golden angle = 2π / φ² ≈ 137.508° — ensures optimal spacing.
 * 
 * @param {string} nodeName
 * @returns {{ x: number, y: number, radius: number, angle: number } | null}
 */
function getNodePosition(nodeName) {
  const result = findNodeRing(nodeName);
  if (!result) return null;

  const { ring } = result;
  const idx = ring.nodes.indexOf(nodeName);
  const n = ring.nodes.length;

  if (ring.radius === 0) {
    return { x: 0, y: 0, radius: 0, angle: 0 };
  }

  // Golden angle distribution: angle_i = i × 2π/φ²
  const goldenAngle = (2 * Math.PI) / (PHI * PHI);
  const angle = idx * goldenAngle;

  return {
    x: ring.radius * Math.cos(angle),
    y: ring.radius * Math.sin(angle),
    radius: ring.radius,
    angle,
  };
}

/**
 * Compute geometric distance between two nodes.
 * @param {string} nodeA
 * @param {string} nodeB
 * @returns {number} Euclidean distance in topology space
 */
function nodeDistance(nodeA, nodeB) {
  const posA = getNodePosition(nodeA);
  const posB = getNodePosition(nodeB);
  if (!posA || !posB) return Infinity;
  const dx = posA.x - posB.x;
  const dy = posA.y - posB.y;
  return Math.sqrt(dx * dx + dy * dy);
}

// ─── COHERENCE SCORING ─────────────────────────────────────────────────────────

/**
 * Compute cosine similarity between two vectors.
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number} Cosine similarity [-1, 1]
 */
function cosineSimilarity(a, b) {
  if (a.length !== b.length) throw new Error('Vector dimension mismatch');
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

/**
 * Measure coherence of a set of node embeddings.
 * Returns average pairwise cosine similarity.
 * 
 * @param {Map<string, number[]>} nodeEmbeddings - Map of node name → embedding
 * @returns {{ score: number, driftPairs: Array<{a: string, b: string, sim: number}> }}
 */
function measureCoherence(nodeEmbeddings) {
  const entries = Array.from(nodeEmbeddings.entries());
  if (entries.length < 2) return { score: 1.0, driftPairs: [] };

  let totalSim = 0;
  let count = 0;
  const driftPairs = [];

  for (let i = 0; i < entries.length; i++) {
    for (let j = i + 1; j < entries.length; j++) {
      const sim = cosineSimilarity(entries[i][1], entries[j][1]);
      totalSim += sim;
      count++;
      if (sim < COHERENCE_DRIFT_THRESHOLD) {
        driftPairs.push({ a: entries[i][0], b: entries[j][0], sim });
      }
    }
  }

  return {
    score: count > 0 ? totalSim / count : 1.0,
    driftPairs,
  };
}

/**
 * Check if coherence is within acceptable bounds.
 * @param {number} score
 * @returns {{ healthy: boolean, level: string }}
 */
function assessCoherence(score) {
  if (score >= CSL_THRESHOLDS.HIGH) return { healthy: true, level: 'EXCELLENT' };
  if (score >= CSL_THRESHOLDS.MEDIUM) return { healthy: true, level: 'GOOD' };
  if (score >= CSL_THRESHOLDS.LOW) return { healthy: false, level: 'DEGRADED' };
  if (score >= CSL_THRESHOLDS.MINIMUM) return { healthy: false, level: 'POOR' };
  return { healthy: false, level: 'CRITICAL' };
}

// ─── FIBONACCI SPACING SYSTEM ──────────────────────────────────────────────────

/** UI spacing scale based on Fibonacci numbers (in px base units) */
const SPACING = Object.freeze({
  xs:   fib(2),   // 1
  sm:   fib(3),   // 2
  md:   fib(4),   // 3
  lg:   fib(5),   // 5
  xl:   fib(6),   // 8
  xxl:  fib(7),   // 13
  xxxl: fib(8),   // 21
  huge: fib(9),   // 34
});

/** Typography scale: each level = previous × φ */
const TYPOGRAPHY_SCALE = Object.freeze({
  base:  1.0,
  h6:    PHI,                        // ≈ 1.618
  h5:    PHI * PHI,                  // ≈ 2.618
  h4:    PHI * PHI * PHI,            // ≈ 4.236
  h3:    Math.pow(PHI, 4),           // ≈ 6.854
  h2:    Math.pow(PHI, 5),           // ≈ 11.090
  h1:    Math.pow(PHI, 6),           // ≈ 17.944
});

// ─── GEOMETRIC ROUTING ─────────────────────────────────────────────────────────

/**
 * Find shortest geometric path between two nodes through the ring topology.
 * Routes through HeadyConductor (inner ring) as the central dispatcher.
 * 
 * @param {string} from
 * @param {string} to
 * @returns {string[]} Path of node names
 */
function geometricRoute(from, to) {
  const fromRing = findNodeRing(from);
  const toRing = findNodeRing(to);
  if (!fromRing || !toRing) return [from, to];

  // Same ring: direct
  if (fromRing.ringKey === toRing.ringKey) return [from, to];

  // Always route through HeadyConductor for cross-ring
  const path = [from];
  if (from !== 'HeadyConductor') path.push('HeadyConductor');
  if (to !== 'HeadyConductor') path.push(to);
  return path;
}

/**
 * Compute phi-harmonic color wheel angles.
 * Uses golden angle (≈ 137.508°) for optimal color harmony.
 * @param {number} n - Number of colors
 * @returns {number[]} Angles in degrees
 */
function phiColorHarmony(n) {
  const goldenAngleDeg = 360 / (PHI * PHI); // ≈ 137.508°
  return Array.from({ length: n }, (_, i) => (i * goldenAngleDeg) % 360);
}

// ─── FRACTAL SELF-SIMILARITY ───────────────────────────────────────────────────

/**
 * Generate fractal subdivision of a region using φ-ratio.
 * Recursively splits region into φ:1 proportions.
 * 
 * @param {number} total - Total size
 * @param {number} depth - Recursion depth (Fibonacci-bounded)
 * @returns {number[]} Subdivision sizes
 */
function phiFractalSubdivision(total, depth = fib(5)) {
  if (depth <= 0 || total < 1) return [total];
  const major = total * PSI;  // ψ portion (larger)
  const minor = total - major;
  return [
    ...phiFractalSubdivision(major, depth - 1),
    ...phiFractalSubdivision(minor, depth - 1),
  ];
}

// ─── EXPORTS ───────────────────────────────────────────────────────────────────

module.exports = {
  RINGS, SPACING, TYPOGRAPHY_SCALE,
  getAllNodes, findNodeRing, getNodePosition, nodeDistance,
  cosineSimilarity, measureCoherence, assessCoherence,
  geometricRoute, phiColorHarmony, phiFractalSubdivision,
};
