'use strict';

/**
 * @module mcp/rate-limiter
 * @description 4-layer Fibonacci-scaled rate limiter combining token bucket
 *   (burst capacity) and sliding window (sustained rate). Integrates semantic
 *   dedup (cosine ≥ DEDUP_THRESHOLD → cached, not counted). Supports a
 *   phi-priority queue for backlogged requests and standard X-RateLimit headers.
 *
 *   Layers (requests/minute):
 *     global  = fib(16) = 987
 *     tool    = fib(12) = 144
 *     user    = fib(10) = 55
 *     session = fib(8)  = 21
 */

const {
  PHI,
  PSI,
  PSI_SQ,
  fib,
  phiBackoff,
  DEDUP_THRESHOLD,
} = require('../shared/phi-math');
const { cosineSimilarity } = require('../shared/sacred-geometry');

// ─── Fibonacci Rate Limits (requests per minute) ──────────────────────────────

const LIMITS = Object.freeze({
  global:  fib(16), // 987
  tool:    fib(12), // 144
  user:    fib(10), // 55
  session: fib(8),  // 21
});

/** All layer names in priority order (most restrictive last) */
const LAYERS = Object.freeze(['global', 'tool', 'user', 'session']);

/** Window duration in ms: 60 000ms (1 minute) */
const WINDOW_MS = fib(5) * fib(5) * fib(5) * fib(5); // 5^4 = 625 — use exact
// Exact window: 60 000ms
const WINDOW_EXACT_MS = 60000;

/** Token bucket refill interval: fib(6) × 1000ms = 8 000ms */
const REFILL_INTERVAL_MS = fib(6) * 1000; // 8 000ms

/** Priority queue max depth: fib(8) = 21 */
const QUEUE_DEPTH = fib(8); // 21

// ─── TokenBucket ─────────────────────────────────────────────────────────────

/**
 * @class TokenBucket
 * @description Simple token bucket for burst capacity control.
 *   Refills at rate tokens/window, capped at burst.
 */
class TokenBucket {
  /**
   * @param {number} capacity   maximum tokens (burst ceiling)
   * @param {number} refillRate tokens added per refill tick
   * @param {number} refillMs   ms between refills
   */
  constructor(capacity, refillRate, refillMs) {
    this._capacity   = capacity;
    this._refillRate = refillRate;
    this._refillMs   = refillMs;
    this._tokens     = capacity; // start full
    this._lastRefill = Date.now();
  }

  /**
   * Attempt to consume `count` tokens.
   * @param {number} [count=1]
   * @returns {boolean} true if tokens were consumed
   */
  consume(count = 1) {
    this._refill();
    if (this._tokens >= count) {
      this._tokens -= count;
      return true;
    }
    return false;
  }

  /** @returns {number} current token count */
  available() {
    this._refill();
    return this._tokens;
  }

  /** @returns {number} ms until at least 1 token is available */
  retryAfterMs() {
    this._refill();
    if (this._tokens >= 1) return 0;
    const elapsed = Date.now() - this._lastRefill;
    return Math.max(0, this._refillMs - elapsed);
  }

  _refill() {
    const now     = Date.now();
    const elapsed = now - this._lastRefill;
    if (elapsed >= this._refillMs) {
      const ticks   = Math.floor(elapsed / this._refillMs);
      this._tokens  = Math.min(this._capacity, this._tokens + ticks * this._refillRate);
      this._lastRefill = now - (elapsed % this._refillMs);
    }
  }
}

// ─── SlidingWindow ────────────────────────────────────────────────────────────

/**
 * @class SlidingWindow
 * @description Sliding window counter for sustained rate enforcement.
 */
class SlidingWindow {
  /**
   * @param {number} limit    max requests per window
   * @param {number} windowMs window duration in ms
   */
  constructor(limit, windowMs) {
    this._limit    = limit;
    this._windowMs = windowMs;
    this._log      = []; // timestamps of recent requests
  }

  /**
   * Check if a new request would exceed the limit.
   * @returns {boolean} true if within limit
   */
  check() {
    this._evict();
    return this._log.length < this._limit;
  }

  /** Record a new request timestamp. */
  record() {
    this._evict();
    this._log.push(Date.now());
  }

  /** @returns {number} remaining requests in this window */
  remaining() {
    this._evict();
    return Math.max(0, this._limit - this._log.length);
  }

  /** @returns {number} ms until the oldest request exits the window */
  resetMs() {
    this._evict();
    if (this._log.length === 0) return 0;
    return Math.max(0, this._log[0] + this._windowMs - Date.now());
  }

  _evict() {
    const cutoff = Date.now() - this._windowMs;
    let i = 0;
    while (i < this._log.length && this._log[i] <= cutoff) i++;
    if (i > 0) this._log.splice(0, i);
  }
}

// ─── RateLimiter ─────────────────────────────────────────────────────────────

/**
 * @class RateLimiter
 * @description 4-layer combined token bucket + sliding window rate limiter
 *   with semantic dedup integration and phi-priority queue.
 */
class RateLimiter {
  /**
   * @param {object} [opts]
   * @param {object} [opts.limits]        override per-layer limits (req/min)
   * @param {number} [opts.windowMs]      window duration in ms
   * @param {number} [opts.refillMs]      token bucket refill interval
   */
  constructor(opts = {}) {
    const limits      = opts.limits    ?? LIMITS;
    const windowMs    = opts.windowMs  ?? WINDOW_EXACT_MS;
    const refillMs    = opts.refillMs  ?? REFILL_INTERVAL_MS;

    // Buckets and windows per layer, keyed by layer→key
    this._buckets = new Map();   // `${layer}:${key}` → TokenBucket
    this._windows = new Map();   // `${layer}:${key}` → SlidingWindow
    this._limits  = limits;
    this._windowMs = windowMs;
    this._refillMs = refillMs;

    // Dedup cache: key → { vector, result, ts }
    this._dedupCache = new Map();

    // Priority queue: Array<{ request, priorityScore, enqueueTs }>
    this._queue = [];

    // Stats
    this._stats = {
      allowed:   0,
      denied:    0,
      dedupHits: 0,
      queued:    0,
    };
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Check if a request is allowed without consuming quota.
   * @param {object} request
   * @param {string} request.tool      tool identifier (per-tool layer key)
   * @param {string} request.user      user identifier (per-user layer key)
   * @param {string} request.session   session identifier (per-session layer key)
   * @param {number[]} [request.vector] embedding vector for dedup check
   * @returns {{ allowed: boolean, limitedBy: string|null, retryAfterMs: number }}
   */
  check(request) {
    // 1. Dedup check (doesn't consume quota)
    if (request.vector) {
      const hit = this._findDedupHit(request.vector);
      if (hit) {
        this._stats.dedupHits++;
        return { allowed: true, limitedBy: null, retryAfterMs: 0, dedupHit: true, cached: hit };
      }
    }

    // 2. Check all 4 layers
    for (const layer of LAYERS) {
      const key     = this._layerKey(layer, request);
      const bucket  = this._getBucket(layer, key);
      const window  = this._getWindow(layer, key);

      if (!bucket.available() > 0 || !window.check()) {
        const retryAfterMs = Math.max(bucket.retryAfterMs(), window.resetMs());
        return { allowed: false, limitedBy: layer, retryAfterMs, dedupHit: false };
      }
    }

    return { allowed: true, limitedBy: null, retryAfterMs: 0, dedupHit: false };
  }

  /**
   * Consume quota for a request (must call check() first).
   * @param {object} request
   * @returns {{ consumed: boolean, layers: string[] }}
   */
  consume(request) {
    const consumed = [];
    for (const layer of LAYERS) {
      const key    = this._layerKey(layer, request);
      const bucket = this._getBucket(layer, key);
      const window = this._getWindow(layer, key);

      if (!bucket.consume(1)) {
        return { consumed: false, layers: consumed };
      }
      window.record();
      consumed.push(layer);
    }
    this._stats.allowed++;
    return { consumed: true, layers: consumed };
  }

  /**
   * Check and consume quota atomically. Queues the request if limited.
   * @param {object} request
   * @returns {{
   *   allowed: boolean,
   *   dedupHit: boolean,
   *   cached: *,
   *   limitedBy: string|null,
   *   retryAfterMs: number,
   *   queued: boolean
   * }}
   */
  isLimited(request) {
    const result = this.check(request);

    if (result.dedupHit) return { ...result, queued: false };

    if (!result.allowed) {
      this._stats.denied++;
      const queued = this._enqueue(request);
      return { ...result, queued };
    }

    this.consume(request);
    return { ...result, queued: false };
  }

  /**
   * Get X-RateLimit headers for a specific layer and key.
   * @param {string} layer   one of LAYERS
   * @param {object} request request object for key extraction
   * @returns {{ 'X-RateLimit-Limit': number, 'X-RateLimit-Remaining': number, 'X-RateLimit-Reset': number }}
   */
  getHeaders(layer, request) {
    const key    = this._layerKey(layer, request);
    const window = this._getWindow(layer, key);
    const limit  = this._limits[layer];
    const reset  = Math.ceil((Date.now() + window.resetMs()) / 1000); // Unix epoch seconds

    return {
      'X-RateLimit-Limit':     limit,
      'X-RateLimit-Remaining': window.remaining(),
      'X-RateLimit-Reset':     reset,
    };
  }

  /**
   * Register a result in the dedup cache.
   * @param {number[]} vector  request embedding
   * @param {string}   key     cache key
   * @param {*}        result  cached result
   */
  cacheResult(vector, key, result) {
    this._dedupCache.set(key, { vector, result, ts: Date.now() });
    // Evict beyond fib(8)=21 cached entries
    if (this._dedupCache.size > fib(8)) {
      const oldest = this._dedupCache.keys().next().value;
      this._dedupCache.delete(oldest);
    }
  }

  /**
   * @returns {{
   *   allowed: number,
   *   denied: number,
   *   dedupHits: number,
   *   queued: number,
   *   queueDepth: number,
   *   limits: object
   * }}
   */
  getStats() {
    return {
      allowed:    this._stats.allowed,
      denied:     this._stats.denied,
      dedupHits:  this._stats.dedupHits,
      queued:     this._stats.queued,
      queueDepth: this._queue.length,
      limits:     { ...this._limits },
    };
  }

  // ─── Internal Helpers ────────────────────────────────────────────────────────

  /**
   * Resolve the rate limit key for a given layer.
   * @param {string} layer
   * @param {object} request
   * @returns {string}
   */
  _layerKey(layer, request) {
    switch (layer) {
      case 'global':  return 'GLOBAL';
      case 'tool':    return request.tool    || 'unknown_tool';
      case 'user':    return request.user    || 'anonymous';
      case 'session': return request.session || 'no_session';
      default:        return 'unknown';
    }
  }

  /**
   * Get or create a TokenBucket for the given layer+key.
   * @param {string} layer
   * @param {string} key
   * @returns {TokenBucket}
   */
  _getBucket(layer, key) {
    const id = `${layer}:${key}`;
    if (!this._buckets.has(id)) {
      const limit = this._limits[layer];
      // Burst capacity: fib(6)/fib(5) × limit ≈ 1.6× (phi-ratio burst)
      const burst = Math.ceil(limit * PSI_SQ + limit); // ≈ 1.382× limit
      const refillRate = Math.max(1, Math.floor(limit / (this._windowMs / this._refillMs)));
      this._buckets.set(id, new TokenBucket(burst, refillRate, this._refillMs));
    }
    return this._buckets.get(id);
  }

  /**
   * Get or create a SlidingWindow for the given layer+key.
   * @param {string} layer
   * @param {string} key
   * @returns {SlidingWindow}
   */
  _getWindow(layer, key) {
    const id = `${layer}:${key}`;
    if (!this._windows.has(id)) {
      this._windows.set(id, new SlidingWindow(this._limits[layer], this._windowMs));
    }
    return this._windows.get(id);
  }

  /**
   * Find a cached result via cosine similarity (≥ DEDUP_THRESHOLD).
   * @param {number[]} vector
   * @returns {*|null} cached result or null
   */
  _findDedupHit(vector) {
    for (const [, entry] of this._dedupCache) {
      const sim = cosineSimilarity(vector, entry.vector);
      if (sim >= DEDUP_THRESHOLD) return entry.result;
    }
    return null;
  }

  /**
   * Enqueue a rate-limited request by phi-priority score.
   * @param {object} request
   * @returns {boolean} true if enqueued, false if queue full
   */
  _enqueue(request) {
    if (this._queue.length >= QUEUE_DEPTH) return false;

    // phi-priority: higher-tier users (shorter user ID → older = higher priority)
    const score = this._phiPriorityScore(request);
    const item  = { request, priorityScore: score, enqueueTs: Date.now() };

    // Insert in sorted order (descending priority)
    let i = 0;
    while (i < this._queue.length && this._queue[i].priorityScore >= score) i++;
    this._queue.splice(i, 0, item);
    this._stats.queued++;
    return true;
  }

  /**
   * Compute phi-priority score for a request.
   * Higher score = processed first.
   * Score = PSI_SQ × (1/session_age) + PSI × user_tier
   * @param {object} request
   * @returns {number}
   */
  _phiPriorityScore(request) {
    // Simple heuristic: session age (older session = higher priority)
    const sessionWindow = this._getWindow('session', this._layerKey('session', request));
    const remaining     = sessionWindow.remaining();
    // Phi-weighted: lower remaining → higher pressure → higher priority
    return PSI_SQ * (1 - remaining / this._limits.session) + PSI * (request.priority || 0);
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports = {
  RateLimiter,
  TokenBucket,
  SlidingWindow,
  LIMITS,
  LAYERS,
  WINDOW_EXACT_MS,
  QUEUE_DEPTH,
};
