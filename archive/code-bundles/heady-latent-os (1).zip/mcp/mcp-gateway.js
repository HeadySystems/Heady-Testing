'use strict';

/**
 * @module mcp/mcp-gateway
 * @description Zero-trust MCP gateway with CSL-gated routing, phi-backoff
 *   connection pooling, multi-transport support, 4-layer rate limiting,
 *   semantic dedup, and namespace-prefixed meta-server aggregation.
 */

const { EventEmitter } = require('events');
const crypto = require('crypto');
const {
  PHI,
  PSI,
  PSI_SQ,
  fib,
  phiBackoff,
  phiAdaptiveInterval,
  CSL_THRESHOLDS,
  DEDUP_THRESHOLD,
} = require('../shared/phi-math');
const { cosineSimilarity } = require('../shared/sacred-geometry');

// ─── Connection Pool Constants ────────────────────────────────────────────────

/** Minimum pool connections: fib(3) = 2 */
const POOL_MIN = fib(3); // 2

/** Maximum pool connections: fib(7) = 13 */
const POOL_MAX = fib(7); // 13

/** Schema cache TTL (ms): fib(14) × 1000ms = 377 000ms */
const SCHEMA_CACHE_TTL = fib(14) * 1000; // 377 000ms

/** Heartbeat base interval (ms): fib(8) × 100ms = 2100ms */
const HEARTBEAT_BASE_MS = fib(8) * 100; // 2100ms

// ─── Transport Types ──────────────────────────────────────────────────────────

/** @enum {string} MCP transport identifiers */
const TRANSPORT = Object.freeze({
  STREAMABLE_HTTP: 'streamableHTTP',
  LEGACY_SSE:      'legacySSE',
  STDIO:           'stdio',
  WEBSOCKET:       'websocket',
});

// ─── Capability Bitmasks (Fibonacci-indexed) ─────────────────────────────────

const CAPABILITY = Object.freeze({
  READ:       1 << 0,  // 1
  WRITE:      1 << 1,  // 2
  EXECUTE:    1 << 2,  // 4
  ADMIN:      1 << 3,  // 8
  STREAM:     1 << 4,  // 16
  AGGREGATE:  1 << 5,  // 32
});

// ─── MCPGateway ───────────────────────────────────────────────────────────────

/**
 * @class MCPGateway
 * @extends EventEmitter
 *
 * Events emitted:
 *   'request'      – { requestId, tool, user, transport }
 *   'route'        – { requestId, tool, namespace, method }
 *   'dedup'        – { requestId, cachedId, similarity }
 *   'rateLimit'    – { requestId, layer, retryAfterMs }
 *   'poolEvent'    – { type, connectionId, poolSize }
 *   'heartbeat'    – { connectionId, ts }
 *   'aggregated'   – { namespace, toolCount }
 *   'securityDeny' – { requestId, reason }
 */
class MCPGateway extends EventEmitter {
  /**
   * @param {object} [opts]
   * @param {number} [opts.poolMin=2]    minimum pool connections
   * @param {number} [opts.poolMax=13]   maximum pool connections
   */
  constructor(opts = {}) {
    super();
    this._poolMin  = opts.poolMin  ?? POOL_MIN;
    this._poolMax  = opts.poolMax  ?? POOL_MAX;

    // Connection pool: Map<connId, { transport, healthy, lastPing, reconnectAttempt }>
    this._pool           = new Map();
    this._reconnectTimers = new Map();

    // Tool registry: Map<namespacedTool, { server, schema, capabilities }>
    this._toolRegistry   = new Map();

    // Schema cache: Map<server, { schema, expiresAt }>
    this._schemaCache    = new Map();

    // Dedup cache: Map<requestHash, { result, vector, ts }>
    this._dedupCache     = new Map();

    // Stats
    this._stats = {
      totalRequests:    0,
      dedupHits:        0,
      routedRequests:   0,
      rateLimited:      0,
      securityDenials:  0,
    };

    this._heartbeatInterval = null;
    this._initPool();
    this._startHeartbeat();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Handle an inbound MCP request (full pipeline).
   * @param {object} req
   * @param {string} req.tool         namespaced tool name (e.g. "search::web_search")
   * @param {object} req.args         tool arguments
   * @param {string} req.user         user identifier
   * @param {string} req.session      session identifier
   * @param {string} req.transport    one of TRANSPORT values
   * @param {number} [req.capMask]    required capability bitmask
   * @param {string} [req.jwt]        JWT for authentication
   * @param {number[]} [req.vector]   request embedding vector (for dedup)
   * @returns {Promise<object>} tool result
   */
  async handleRequest(req) {
    this._stats.totalRequests++;
    const requestId = crypto.randomBytes(fib(4)).toString('hex');
    this.emit('request', { requestId, tool: req.tool, user: req.user, transport: req.transport });

    // 1. Zero-trust validation
    const denied = this._zeroTrustCheck(req, requestId);
    if (denied) {
      this._stats.securityDenials++;
      this.emit('securityDeny', { requestId, reason: denied });
      const err = new Error(`Security denial: ${denied}`);
      err.code = 'SECURITY_DENY';
      throw err;
    }

    // 2. Semantic dedup
    if (req.vector) {
      const cached = this._findDedupMatch(req.vector, req.tool);
      if (cached) {
        this._stats.dedupHits++;
        this.emit('dedup', { requestId, cachedId: cached.id, similarity: cached.similarity });
        return cached.result;
      }
    }

    // 3. Route + execute
    const result = await this.route({ requestId, ...req });

    // 4. Cache result for dedup
    if (req.vector) {
      this._cacheDedup(requestId, req.vector, req.tool, result);
    }

    return result;
  }

  /**
   * Route a tool call to the correct MCP server.
   * Priority: 1. namespace prefix match, 2. cosine fallback.
   * @param {object} toolCall
   * @returns {Promise<object>} execution result
   */
  async route(toolCall) {
    this._stats.routedRequests++;
    const { tool, args } = toolCall;

    // 1. Namespace prefix match (e.g. "search::web_search" → namespace "search")
    let registration = this._toolRegistry.get(tool);

    if (!registration && toolCall.vector) {
      // 2. Cosine fallback: find tool with highest similarity
      registration = this._cosineFallback(toolCall.vector, tool);
    }

    if (!registration) {
      throw new Error(`Tool not found: ${tool}`);
    }

    this.emit('route', {
      requestId: toolCall.requestId,
      tool,
      namespace: registration.namespace,
      method:    registration.method,
    });

    return this.executeZeroTrust(registration, args, toolCall);
  }

  /**
   * Execute a tool call with zero-trust enforcement.
   * @param {object} tool         tool registration record
   * @param {object} args         tool arguments
   * @param {object} [context]    request context for scanning
   * @returns {Promise<object>}
   */
  async executeZeroTrust(tool, args, context = {}) {
    // Input validation: check argument schema
    this._validateInput(tool, args);

    // Capability check
    if (tool.capabilities && context.capMask !== undefined) {
      if ((tool.capabilities & context.capMask) !== context.capMask) {
        throw new Error(`Capability denied: required ${context.capMask}, granted ${tool.capabilities}`);
      }
    }

    let result;
    try {
      result = tool.handler ? await tool.handler(args) : { ok: true, echo: args };
    } catch (err) {
      throw new Error(`Tool execution error (${tool.name}): ${err.message}`);
    }

    // Output scanning (redact sensitive fields)
    result = this._scanOutput(result);
    return result;
  }

  /**
   * Aggregate tools from multiple MCP servers with namespace prefixing.
   * @param {Array<{ namespace: string, url: string, tools: Array<object> }>} servers
   */
  async aggregate(servers) {
    for (const server of servers) {
      const { namespace, url, tools } = server;
      let schema = this._schemaCache.get(url);

      if (!schema || Date.now() > schema.expiresAt) {
        schema = { tools, expiresAt: Date.now() + SCHEMA_CACHE_TTL };
        this._schemaCache.set(url, schema);
      }

      for (const tool of schema.tools) {
        const namespacedName = `${namespace}::${tool.name}`;
        this._toolRegistry.set(namespacedName, {
          ...tool,
          name:      namespacedName,
          namespace,
          server:    url,
          method:    tool.name,
        });
      }

      this.emit('aggregated', { namespace, toolCount: schema.tools.length });
    }
  }

  /** @returns {object} gateway statistics */
  getStats() {
    return {
      ...this._stats,
      poolSize:       this._pool.size,
      registeredTools: this._toolRegistry.size,
      dedupCacheSize: this._dedupCache.size,
      schemaCacheSize: this._schemaCache.size,
    };
  }

  // ─── Internal: Zero-Trust ────────────────────────────────────────────────────

  /**
   * Perform zero-trust security checks.
   * @param {object} req
   * @param {string} requestId
   * @returns {string|null} denial reason, or null if allowed
   */
  _zeroTrustCheck(req, requestId) {
    // JWT presence check
    if (!req.jwt && req.transport !== TRANSPORT.STDIO) {
      return 'Missing JWT';
    }

    // Input validation: tool name must be a non-empty string
    if (!req.tool || typeof req.tool !== 'string') {
      return 'Invalid tool identifier';
    }

    // Sanitize: reject tool names with path traversal attempts
    if (req.tool.includes('..') || req.tool.includes('/')) {
      return 'Malformed tool name';
    }

    return null;
  }

  /**
   * Validate tool input arguments against registered schema.
   * @param {object} tool
   * @param {object} args
   */
  _validateInput(tool, args) {
    if (!tool.schema) return; // no schema = pass
    const required = tool.schema.required || [];
    for (const field of required) {
      if (!(field in args)) {
        throw new Error(`Missing required argument: ${field}`);
      }
    }
  }

  /**
   * Scan output for sensitive patterns and redact.
   * @param {object} output
   * @returns {object} scanned output
   */
  _scanOutput(output) {
    if (!output || typeof output !== 'object') return output;
    const SENSITIVE = /\b(password|secret|token|apikey|api_key|private_key)\b/i;
    const redact = obj => {
      if (typeof obj !== 'object' || obj === null) return obj;
      const copy = Array.isArray(obj) ? [] : {};
      for (const [k, v] of Object.entries(obj)) {
        copy[k] = SENSITIVE.test(k) ? '[REDACTED]' : redact(v);
      }
      return copy;
    };
    return redact(output);
  }

  // ─── Internal: Dedup ─────────────────────────────────────────────────────────

  /**
   * Find a semantically duplicate cached result.
   * @param {number[]} vector
   * @param {string} tool
   * @returns {{ id: string, result: object, similarity: number }|null}
   */
  _findDedupMatch(vector, tool) {
    for (const [id, entry] of this._dedupCache) {
      if (entry.tool !== tool) continue;
      const sim = cosineSimilarity(vector, entry.vector);
      if (sim >= DEDUP_THRESHOLD) {
        return { id, result: entry.result, similarity: sim };
      }
    }
    return null;
  }

  _cacheDedup(id, vector, tool, result) {
    this._dedupCache.set(id, { vector, tool, result, ts: Date.now() });
    // Evict oldest entries beyond fib(11)=89 cached items
    if (this._dedupCache.size > fib(11)) {
      const oldest = this._dedupCache.keys().next().value;
      this._dedupCache.delete(oldest);
    }
  }

  // ─── Internal: Cosine Fallback ───────────────────────────────────────────────

  /**
   * Find the best-matching registered tool using cosine similarity.
   * Requires tool to have an embedded vector in its registration.
   * @param {number[]} vector
   * @param {string} toolName  original tool name for reference
   * @returns {object|null} best matching tool registration
   */
  _cosineFallback(vector, toolName) {
    let best = null, bestScore = CSL_THRESHOLDS.MEDIUM;
    for (const [name, reg] of this._toolRegistry) {
      if (!reg.vector) continue;
      const sim = cosineSimilarity(vector, reg.vector);
      if (sim > bestScore) { bestScore = sim; best = reg; }
    }
    return best;
  }

  // ─── Internal: Connection Pool ───────────────────────────────────────────────

  _initPool() {
    for (let i = 0; i < this._poolMin; i++) {
      this._addConnection();
    }
  }

  _addConnection() {
    if (this._pool.size >= this._poolMax) return null;
    const id = crypto.randomBytes(fib(3)).toString('hex');
    this._pool.set(id, {
      id,
      transport:         TRANSPORT.STREAMABLE_HTTP,
      healthy:           true,
      lastPing:          Date.now(),
      reconnectAttempt:  0,
    });
    this.emit('poolEvent', { type: 'add', connectionId: id, poolSize: this._pool.size });
    return id;
  }

  _startHeartbeat() {
    const interval = phiAdaptiveInterval
      ? phiAdaptiveInterval(HEARTBEAT_BASE_MS, 0)
      : HEARTBEAT_BASE_MS;

    this._heartbeatInterval = setInterval(() => {
      for (const [id, conn] of this._pool) {
        conn.lastPing = Date.now();
        this.emit('heartbeat', { connectionId: id, ts: conn.lastPing });
        if (!conn.healthy) {
          this._scheduleReconnect(id);
        }
      }
    }, interval);
    if (this._heartbeatInterval.unref) this._heartbeatInterval.unref();
  }

  _scheduleReconnect(connId) {
    if (this._reconnectTimers.has(connId)) return;
    const conn  = this._pool.get(connId);
    if (!conn) return;
    const delay = phiBackoff(conn.reconnectAttempt++, fib(8) * 100, fib(11) * 1000);
    const handle = setTimeout(() => {
      this._reconnectTimers.delete(connId);
      conn.healthy = true;
      conn.reconnectAttempt = 0;
      this.emit('poolEvent', { type: 'reconnect', connectionId: connId, poolSize: this._pool.size });
    }, delay);
    this._reconnectTimers.set(connId, handle);
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports = {
  MCPGateway,
  TRANSPORT,
  CAPABILITY,
  POOL_MIN,
  POOL_MAX,
  SCHEMA_CACHE_TTL,
};
