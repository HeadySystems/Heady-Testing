'use strict';

/**
 * @module mcp/audit-logger
 * @description SOC 2 Type II–compliant cryptographic audit logger.
 *   Maintains a tamper-evident hash chain (SHA-256), JSONL rotation at
 *   fib(13)×1MiB = 233 MiB, 89-day retention (fib(11)), and multi-format
 *   export (NDJSON, JSON, CEF, syslog).
 */

const crypto = require('crypto');
const {
  fib,
  PHI,
} = require('../shared/phi-math');

// ─── Rotation / Retention Constants ──────────────────────────────────────────

/** Log rotation threshold in bytes: fib(13) × 1 MiB = 233 × 1 048 576 */
const ROTATION_BYTES = fib(13) * 1048576; // 233 MiB

/** Retention period in days: fib(11) = 89 */
const RETENTION_DAYS = fib(11); // 89

/** Retention period in ms */
const RETENTION_MS = RETENTION_DAYS * fib(8) * 3600000 / fib(6);
// fib(8)=21, fib(6)=8 → 21/8 × 3600000 ≈ 9 450 000ms per day
// Use exact: RETENTION_DAYS * 24 * 3600000
const RETENTION_EXACT_MS = RETENTION_DAYS * 24 * 3600000;

/** Max chain entries before rotation: fib(16) = 987 per segment */
const MAX_CHAIN_LENGTH = fib(16); // 987

// ─── Export Format Types ──────────────────────────────────────────────────────

/** @enum {string} Export format identifiers */
const EXPORT_FORMAT = Object.freeze({
  NDJSON: 'NDJSON',
  JSON:   'JSON',
  CEF:    'CEF',
  SYSLOG: 'syslog',
});

// ─── AuditLogger ─────────────────────────────────────────────────────────────

/**
 * @class AuditLogger
 * @description Append-only cryptographic audit log with chain verification.
 *
 * Record schema (SOC 2 Type II required fields):
 *   - timestamp   (ISO 8601)
 *   - tool        (string)
 *   - user        (string)
 *   - input_hash  (SHA-256 hex of serialized inputs)
 *   - output_hash (SHA-256 hex of serialized outputs)
 *   - duration_ms (number)
 *   + chain_hash  (SHA-256(prevHash + recordHash))
 *   + record_hash (SHA-256 of core record fields)
 *   + seq         (sequence number)
 */
class AuditLogger {
  /**
   * @param {object} [opts]
   * @param {number} [opts.rotationBytes]   byte threshold for rotation
   * @param {number} [opts.retentionMs]     retention window in ms
   * @param {number} [opts.maxChainLength]  records per chain segment
   */
  constructor(opts = {}) {
    this._rotationBytes  = opts.rotationBytes  ?? ROTATION_BYTES;
    this._retentionMs    = opts.retentionMs    ?? RETENTION_EXACT_MS;
    this._maxChainLength = opts.maxChainLength ?? MAX_CHAIN_LENGTH;

    /** @type {Array<object>} in-memory log records */
    this._chain          = [];

    /** @type {Array<Array<object>>} rotated archive segments */
    this._archive        = [];

    /** SHA-256 hex of the previous record's chain_hash */
    this._prevHash       = '0'.repeat(64); // genesis hash

    /** Approximate byte size of current segment */
    this._segmentBytes   = 0;

    /** Monotonic sequence counter */
    this._seq            = 0;

    /** Stats */
    this._stats = {
      totalRecords: 0,
      rotations:    0,
      verifyPasses: 0,
      verifyFails:  0,
    };
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Append an audit record to the chain.
   * Automatically rotates if size threshold exceeded.
   *
   * @param {object} record
   * @param {string} record.tool         MCP tool name
   * @param {string} record.user         authenticated user identifier
   * @param {*}      record.input        raw input (will be hashed)
   * @param {*}      record.output       raw output (will be hashed)
   * @param {number} record.duration_ms  execution duration
   * @param {object} [record.meta]       optional extra fields
   * @returns {object} finalized audit record with chain_hash
   */
  log(record) {
    this._validateRecord(record);

    const timestamp   = new Date().toISOString();
    const input_hash  = this._sha256(record.input);
    const output_hash = this._sha256(record.output);

    const core = {
      seq:          ++this._seq,
      timestamp,
      tool:         record.tool,
      user:         record.user,
      input_hash,
      output_hash,
      duration_ms:  record.duration_ms,
      ...(record.meta ? { meta: record.meta } : {}),
    };

    const record_hash = this._sha256(core);
    const chain_hash  = this._sha256(this._prevHash + record_hash);

    const entry = { ...core, record_hash, chain_hash };

    this._chain.push(entry);
    this._prevHash     = chain_hash;
    this._segmentBytes += this._estimateBytes(entry);
    this._stats.totalRecords++;

    // Auto-rotate if threshold exceeded
    if (this._segmentBytes >= this._rotationBytes || this._chain.length >= this._maxChainLength) {
      this.rotate();
    }

    return entry;
  }

  /**
   * Verify the cryptographic integrity of the entire chain (all segments).
   * @returns {{ valid: boolean, checkedRecords: number, firstFailSeq: number|null }}
   */
  verifyChain() {
    let prevHash = '0'.repeat(64);
    let checked  = 0;

    // Verify archive segments + current segment in order
    const allSegments = [...this._archive, this._chain];

    for (const segment of allSegments) {
      for (const entry of segment) {
        const { record_hash, chain_hash, ...core } = entry;

        // Re-derive record_hash from core fields
        const expectedRecordHash = this._sha256(core);
        if (expectedRecordHash !== record_hash) {
          this._stats.verifyFails++;
          return { valid: false, checkedRecords: checked, firstFailSeq: entry.seq };
        }

        // Re-derive chain_hash from prevHash + record_hash
        const expectedChainHash = this._sha256(prevHash + record_hash);
        if (expectedChainHash !== chain_hash) {
          this._stats.verifyFails++;
          return { valid: false, checkedRecords: checked, firstFailSeq: entry.seq };
        }

        prevHash = chain_hash;
        checked++;
      }
    }

    this._stats.verifyPasses++;
    return { valid: true, checkedRecords: checked, firstFailSeq: null };
  }

  /**
   * Rotate the current chain segment into the archive.
   * In production: flush to disk / object storage.
   * @returns {{ segmentIndex: number, recordCount: number, bytes: number }}
   */
  rotate() {
    if (this._chain.length === 0) return { segmentIndex: -1, recordCount: 0, bytes: 0 };

    const segmentIndex = this._archive.length;
    const recordCount  = this._chain.length;
    const bytes        = this._segmentBytes;

    this._archive.push([...this._chain]);
    this._chain        = [];
    this._segmentBytes = 0;
    this._stats.rotations++;

    // Evict records beyond retention window
    this._evictExpired();

    return { segmentIndex, recordCount, bytes };
  }

  /**
   * Export log records in the specified format.
   * @param {string} [format='NDJSON']  one of EXPORT_FORMAT values
   * @param {object} [opts]
   * @param {number} [opts.since]  Unix timestamp ms lower bound
   * @param {number} [opts.limit]  max records to export
   * @returns {string} formatted export string
   */
  export(format = EXPORT_FORMAT.NDJSON, opts = {}) {
    let records = this._allRecords();

    if (opts.since) {
      records = records.filter(r => new Date(r.timestamp).getTime() >= opts.since);
    }
    if (opts.limit) {
      records = records.slice(-opts.limit);
    }

    switch (format) {
      case EXPORT_FORMAT.NDJSON:
        return records.map(r => JSON.stringify(r)).join('\n');

      case EXPORT_FORMAT.JSON:
        return JSON.stringify({ records, exportedAt: new Date().toISOString() }, null, fib(3));

      case EXPORT_FORMAT.CEF: {
        // ArcSight Common Event Format: CEF:Version|DeviceVendor|DeviceProduct|DeviceVersion|SignatureID|Name|Severity|Extension
        const version = fib(3) - 1; // 1
        return records.map(r => {
          const ext = `ts=${r.timestamp} user=${r.user} tool=${r.tool} dur=${r.duration_ms}ms ih=${r.input_hash.slice(0, 16)} oh=${r.output_hash.slice(0, 16)} seq=${r.seq}`;
          return `CEF:${version}|MCP|AuditLogger|1.0|${r.seq}|${r.tool}|${fib(4)}|${ext}`;
        }).join('\n');
      }

      case EXPORT_FORMAT.SYSLOG: {
        // RFC 5424 syslog format
        const PRI   = fib(6) + fib(4); // 8+3=11 → facility 1 (user), severity 3 (error)
        const APP   = 'mcp-audit';
        const MSGID = 'AUDIT';
        return records.map(r => {
          const sd = `[audit seq="${r.seq}" user="${r.user}" tool="${r.tool}" dur="${r.duration_ms}"]`;
          return `<${PRI}>1 ${r.timestamp} - ${APP} - ${MSGID} ${sd} chain=${r.chain_hash.slice(0, 16)}`;
        }).join('\n');
      }

      default:
        throw new Error(`Unknown export format: ${format}`);
    }
  }

  /**
   * @returns {{
   *   totalRecords: number,
   *   currentSegmentRecords: number,
   *   archivedSegments: number,
   *   rotations: number,
   *   verifyPasses: number,
   *   verifyFails: number,
   *   segmentBytes: number,
   *   rotationThresholdBytes: number,
   *   retentionDays: number,
   *   headHash: string
   * }}
   */
  getStats() {
    return {
      totalRecords:          this._stats.totalRecords,
      currentSegmentRecords: this._chain.length,
      archivedSegments:      this._archive.length,
      rotations:             this._stats.rotations,
      verifyPasses:          this._stats.verifyPasses,
      verifyFails:           this._stats.verifyFails,
      segmentBytes:          this._segmentBytes,
      rotationThresholdBytes: this._rotationBytes,
      retentionDays:         RETENTION_DAYS,
      headHash:              this._prevHash,
    };
  }

  // ─── Internal Helpers ────────────────────────────────────────────────────────

  /**
   * Validate required SOC 2 fields.
   * @param {object} record
   */
  _validateRecord(record) {
    const required = ['tool', 'user', 'input', 'output', 'duration_ms'];
    for (const field of required) {
      if (record[field] === undefined || record[field] === null) {
        throw new Error(`AuditLogger: missing required field "${field}"`);
      }
    }
    if (typeof record.duration_ms !== 'number' || record.duration_ms < 0) {
      throw new Error('AuditLogger: duration_ms must be a non-negative number');
    }
  }

  /**
   * Compute SHA-256 hash of any value (serialized to JSON if object).
   * @param {*} value
   * @returns {string} hex digest
   */
  _sha256(value) {
    const data = typeof value === 'string' ? value : JSON.stringify(value);
    return crypto.createHash('sha256').update(data).digest('hex');
  }

  /**
   * Estimate serialized byte size of a record.
   * @param {object} entry
   * @returns {number} approximate bytes
   */
  _estimateBytes(entry) {
    return Buffer.byteLength(JSON.stringify(entry), 'utf8');
  }

  /**
   * Get all records across archive and current segment.
   * @returns {Array<object>}
   */
  _allRecords() {
    return [...this._archive.flat(), ...this._chain];
  }

  /**
   * Evict archive segments older than the retention window.
   */
  _evictExpired() {
    const cutoff = Date.now() - this._retentionMs;
    this._archive = this._archive.filter(segment => {
      if (segment.length === 0) return false;
      const firstTs = new Date(segment[0].timestamp).getTime();
      return firstTs >= cutoff;
    });
  }
}

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports = {
  AuditLogger,
  EXPORT_FORMAT,
  ROTATION_BYTES,
  RETENTION_DAYS,
  MAX_CHAIN_LENGTH,
};
