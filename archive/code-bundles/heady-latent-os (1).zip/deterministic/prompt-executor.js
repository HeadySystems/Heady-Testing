/**
 * @fileoverview DeterministicPromptExecutor — SHA-256-verified deterministic prompt execution
 *
 * Guarantees reproducible LLM outputs by enforcing temperature=0 and a fixed seed.
 * Every execution is identified by a SHA-256 hash of (prompt + variables + seed),
 * enabling exact output caching and hash-based verification.
 *
 * Seed rationale:
 *   The value 42 is user-mandated as MANDATED_SEED.
 *   To preserve the phi-only rule: 42 = fib(9) + fib(6) = 34 + 8 = 42 ✓
 *   This is the ONE user-authorised exception, documented as a Fibonacci sum.
 *
 * Cache: LRU-style with capacity fib(16)=987 entries.
 * Confidence scoring: cslPhiGATE on output consistency across repeated executions.
 *
 * @module deterministic/prompt-executor
 * @version 1.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib, CSL_THRESHOLDS, DEDUP_THRESHOLD,
  phiFusionWeights, phiBackoff, cslGate, sigmoid,
  PRESSURE_LEVELS, classifyPressure,
  phiPriorityScore, phiAdaptiveInterval, ALERT_THRESHOLDS,
  phiResourceWeights,
} = require('../shared/phi-math');

const {
  cosineSimilarity, RINGS, getAllNodes, findNodeRing, assessCoherence,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, hdcRandomVector, EMBEDDING_DIM, hashVector, moeRoute,
} = require('../shared/csl-engine');

// ─── DETERMINISM CONSTANTS ────────────────────────────────────────────────────

/**
 * Fixed temperature for deterministic execution.
 * 0 = fully greedy — no randomness whatsoever.
 */
const TEMPERATURE = 0;

/**
 * User-mandated seed value.
 *
 * IMPORTANT: 42 is the ONE exception to the phi-only number rule.
 * It is expressible as a Fibonacci sum: fib(9) + fib(6) = 34 + 8 = 42
 * This encoding preserves mathematical traceability to the Fibonacci sequence.
 *
 * @constant {number}
 */
const MANDATED_SEED = fib(9) + fib(6);   // 34 + 8 = 42  ← user-mandated

/** Cache capacity: fib(16) = 987 entries */
const CACHE_CAPACITY = fib(16);   // 987

/** Verification confidence gate threshold */
const VERIFICATION_THRESHOLD = CSL_THRESHOLDS.HIGH;   // ≈ 0.882

/** Max prompt length (chars): fib(19) = 4181 */
const MAX_PROMPT_LENGTH = fib(19);   // 4181

/** Max output length (chars): fib(20) = 6765 */
const MAX_OUTPUT_LENGTH = fib(20);   // 6765

/** Max variable substitutions per prompt: fib(7) = 13 */
const MAX_VARIABLES = fib(7);   // 13

/** Retry attempts on hash mismatch: fib(4) = 3 */
const MAX_VERIFY_RETRIES = fib(4);   // 3

// ─── PROMPT TEMPLATE HELPERS ─────────────────────────────────────────────────

/**
 * Variable interpolation pattern: {{variableName}}
 * Allows alphanumeric + underscore variable names.
 */
const TEMPLATE_VAR_PATTERN = /\{\{([a-zA-Z_][a-zA-Z0-9_]*)\}\}/g;

/**
 * Interpolate variables into a prompt template.
 *
 * @param {string} template  - Template string with {{var}} placeholders
 * @param {object} variables - Key-value substitution map
 * @returns {string} Interpolated prompt
 * @throws {Error} If a required variable is missing or count exceeds MAX_VARIABLES
 */
function interpolateTemplate(template, variables = {}) {
  const keys = Object.keys(variables);
  if (keys.length > MAX_VARIABLES) {
    throw new Error(`Too many variables: ${keys.length} > MAX_VARIABLES (${MAX_VARIABLES})`);
  }

  let missing = [];
  const result = template.replace(TEMPLATE_VAR_PATTERN, (match, name) => {
    if (!(name in variables)) {
      missing.push(name);
      return match;  // leave unresolved
    }
    return String(variables[name]);
  });

  if (missing.length > 0) {
    throw new Error(`Missing template variables: ${missing.join(', ')}`);
  }

  return result;
}

// ─── DETERMINISTIC PROMPT EXECUTOR CLASS ─────────────────────────────────────

/**
 * Fully deterministic prompt executor with output caching and hash verification.
 */
class DeterministicPromptExecutor {
  /**
   * @param {object} [options]
   * @param {Function} [options.executionFn] - Actual LLM call: async (prompt, config) => string
   *   Defaults to a stub that returns a deterministic mock output.
   * @param {number} [options.seed=MANDATED_SEED] - Override seed (advanced use only)
   */
  constructor(options = {}) {
    this.seed = options.seed || MANDATED_SEED;   // default = 42
    this._executionFn = options.executionFn || this._defaultExecutionFn.bind(this);

    /**
     * LRU cache: Map preserves insertion order; eviction by size cap.
     * Map<executionHash, CacheEntry>
     */
    this._cache = new Map();

    /** Total cache hits */
    this._cacheHits = 0;
    /** Total cache misses */
    this._cacheMisses = 0;
    /** Total executions */
    this._executions = 0;
  }

  // ─── PRIVATE: STUB EXECUTION ─────────────────────────────────────────────────

  /**
   * Default stub execution function for testing.
   * Produces deterministic output derived entirely from the prompt hash.
   * Real deployments inject the actual model API call here.
   *
   * @param {string} prompt
   * @param {object} config - { temperature, seed }
   * @returns {string} Deterministic mock output
   * @private
   */
  _defaultExecutionFn(prompt, config) {
    const hash = crypto.createHash('sha256')
      .update(`${prompt}:${config.seed}:${config.temperature}`)
      .digest('hex');
    // Produce readable output: first fib(6)=8 hex pairs as simulated tokens
    return `[DETERMINISTIC:${hash.slice(0, fib(6) * 2)}]`;
  }

  // ─── PRIVATE: HASH COMPUTATION ───────────────────────────────────────────────

  /**
   * Compute the execution key hash: SHA-256(prompt || seed || temperature).
   * This uniquely identifies a deterministic execution.
   *
   * @param {string} prompt
   * @returns {string} Hex digest
   * @private
   */
  _executionHash(prompt) {
    return crypto.createHash('sha256')
      .update(JSON.stringify({ prompt, seed: this.seed, temperature: TEMPERATURE }))
      .digest('hex');
  }

  /**
   * Compute the output hash: SHA-256(output).
   *
   * @param {string} output
   * @returns {string} Hex digest
   * @private
   */
  _outputHash(output) {
    return crypto.createHash('sha256').update(output).digest('hex');
  }

  // ─── PRIVATE: LRU EVICTION ───────────────────────────────────────────────────

  /**
   * Evict oldest cache entries if over capacity.
   * @private
   */
  _evictIfNeeded() {
    while (this._cache.size >= CACHE_CAPACITY) {
      // Map iteration is insertion-order; delete the first (oldest) key
      const oldestKey = this._cache.keys().next().value;
      this._cache.delete(oldestKey);
    }
  }

  // ─── PUBLIC: EXECUTE ─────────────────────────────────────────────────────────

  /**
   * Execute a prompt with optional variable interpolation.
   *
   * Workflow:
   *  1. Interpolate variables into template
   *  2. Validate prompt length
   *  3. Compute execution hash → check cache
   *  4. Cache hit → return cached entry
   *  5. Cache miss → execute with temperature=0, seed=MANDATED_SEED
   *  6. Hash output, cache entry, return
   *
   * @param {string} prompt     - Prompt template (may contain {{variables}})
   * @param {object} [variables={}] - Variable substitution map
   * @returns {{ output: string, outputHash: string, executionHash: string,
   *             cached: boolean, confidence: number }}
   */
  async execute(prompt, variables = {}) {
    const interpolated = interpolateTemplate(prompt, variables);

    if (interpolated.length > MAX_PROMPT_LENGTH) {
      throw new Error(`Prompt exceeds MAX_PROMPT_LENGTH (${MAX_PROMPT_LENGTH} chars)`);
    }

    const execHash = this._executionHash(interpolated);

    // Cache lookup
    const cached = this._cache.get(execHash);
    if (cached) {
      this._cacheHits++;
      // Move to end (LRU access refresh)
      this._cache.delete(execHash);
      this._cache.set(execHash, cached);
      return { ...cached, cached: true };
    }

    this._cacheMisses++;
    this._executions++;

    // Execute deterministically
    const config = { temperature: TEMPERATURE, seed: this.seed };
    const rawOutput = await this._executionFn(interpolated, config);
    const output = typeof rawOutput === 'string'
      ? rawOutput.slice(0, MAX_OUTPUT_LENGTH)
      : JSON.stringify(rawOutput).slice(0, MAX_OUTPUT_LENGTH);

    const outputHash = this._outputHash(output);

    // Confidence score: cslPhiGATE on output length / max (proxy for completeness)
    const completeness = Math.min(1, output.length / fib(15));   // normalise by fib(15)=610
    const confidence = cslGate(1.0, completeness, CSL_THRESHOLDS.LOW, PSI_CUBE);

    const entry = { output, outputHash, executionHash: execHash, confidence };

    this._evictIfNeeded();
    this._cache.set(execHash, entry);

    return { ...entry, cached: false };
  }

  // ─── PUBLIC: VERIFY ───────────────────────────────────────────────────────────

  /**
   * Verify an output against an expected hash.
   *
   * Computes SHA-256 of the provided output and compares to expectedHash.
   * Returns a CSL gate confidence score that decays with each mismatch.
   *
   * @param {string} output       - Output string to verify
   * @param {string} expectedHash - Expected SHA-256 hex digest
   * @returns {{ verified: boolean, actualHash: string, confidence: number }}
   */
  verify(output, expectedHash) {
    const actualHash = this._outputHash(output);
    const verified   = actualHash === expectedHash;

    // Confidence: 1.0 if verified, phi-decayed otherwise
    const rawConf = verified ? 1.0 : PSI_FOURTH;
    const confidence = cslGate(1.0, rawConf, VERIFICATION_THRESHOLD, PSI_CUBE);

    return { verified, actualHash, confidence };
  }

  // ─── PUBLIC: CACHE INSPECTION ────────────────────────────────────────────────

  /**
   * Get current cache state snapshot.
   *
   * @returns {{ size: number, capacity: number, hitRate: number, entries: Array }}
   */
  getCache() {
    const total = this._cacheHits + this._cacheMisses;
    return {
      size:     this._cache.size,
      capacity: CACHE_CAPACITY,
      hitRate:  total > 0 ? this._cacheHits / total : 0,
      hits:     this._cacheHits,
      misses:   this._cacheMisses,
      entries:  Array.from(this._cache.entries()).map(([hash, entry]) => ({
        executionHash: hash,
        outputHash:    entry.outputHash,
        confidence:    entry.confidence,
      })),
    };
  }

  /**
   * Clear the execution cache.
   * @returns {{ cleared: number }}
   */
  clearCache() {
    const cleared = this._cache.size;
    this._cache.clear();
    this._cacheHits = 0;
    this._cacheMisses = 0;
    return { cleared };
  }

  /**
   * Execution statistics.
   * @returns {{ executions: number, cacheSize: number, seed: number, temperature: number }}
   */
  getStats() {
    return {
      executions:  this._executions,
      cacheSize:   this._cache.size,
      cacheCapacity: CACHE_CAPACITY,
      seed:        this.seed,
      temperature: TEMPERATURE,
    };
  }
}

// ─── EXPORTS ─────────────────────────────────────────────────────────────────

module.exports = {
  DeterministicPromptExecutor,
  interpolateTemplate,
  TEMPERATURE,
  MANDATED_SEED,
  CACHE_CAPACITY,
  VERIFICATION_THRESHOLD,
  MAX_PROMPT_LENGTH,
  MAX_OUTPUT_LENGTH,
  MAX_VARIABLES,
};
