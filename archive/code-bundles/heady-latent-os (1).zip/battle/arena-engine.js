/**
 * @fileoverview ArenaEngine — 9-stage phi-scored model battle arena
 *
 * Implements a full tournament engine for running multiple AI model/provider
 * configurations head-to-head on shared tasks. The pipeline progresses through
 * 9 enumerated stages and produces phi-weighted composite scores, ELO ratings,
 * and a leaderboard ordered by CSL consensus.
 *
 * Scoring weights are phi-derived (zero magic numbers):
 *   accuracy  → φ² ≈ 2.618
 *   speed     → φ  ≈ 1.618
 *   cost      → 1  (identity)
 *   creativity → ψ  ≈ 0.618
 *   safety    → ψ² ≈ 0.382
 *
 * Tournament supports up to fib(6)=8 contestants per bracket.
 * ELO K-factor = fib(9)=34 for standard players; phi-adjusted for established.
 *
 * @module battle/arena-engine
 * @version 1.0.0
 * @license Proprietary — HeadySystems Inc.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const {
  PHI, PSI, PSI_SQ, PSI_CUBE, PSI_FOURTH,
  fib, CSL_THRESHOLDS, DEDUP_THRESHOLD,
  phiFusionWeights, phiBackoff, cslGate, sigmoid,
  PRESSURE_LEVELS, classifyPressure,
  phiPriorityScore, phiAdaptiveInterval, ALERT_THRESHOLDS,
  phiResourceWeights,
} = require('../shared/phi-math');

const {
  cosineSimilarity, RINGS, getAllNodes, findNodeRing, assessCoherence,
} = require('../shared/sacred-geometry');

const {
  cslAND, cslOR, cslNOT, cslCONSENSUS, cslPhiGATE,
  normalize, hdcRandomVector, EMBEDDING_DIM, hashVector, moeRoute,
} = require('../shared/csl-engine');

// ─── PIPELINE STAGES ─────────────────────────────────────────────────────────

/**
 * The nine battle-sim pipeline stages (enumerated constants).
 */
const PIPELINE_STAGES = Object.freeze([
  'init',        // 0 — allocate battle context
  'configure',   // 1 — apply model/provider configs
  'spawn',       // 2 — instantiate contestant agents
  'warmup',      // 3 — preflight / capability check
  'execute',     // 4 — run shared task for each contestant
  'collect',     // 5 — gather raw metrics
  'score',       // 6 — phi-weighted scoring
  'rank',        // 7 — ELO + consensus ranking
  'report',      // 8 — emit final results
]);

// ─── SCORING WEIGHTS (phi-derived) ───────────────────────────────────────────

/**
 * Phi-derived scoring criterion weights.
 * Sorted descending: accuracy > speed > cost > creativity > safety
 */
const SCORING_WEIGHTS = Object.freeze({
  accuracy:   PHI * PHI,   // φ² ≈ 2.618 — highest signal
  speed:      PHI,         // φ  ≈ 1.618
  cost:       1,           // identity (normalized base)
  creativity: PSI,         // ψ  ≈ 0.618
  safety:     PSI_SQ,      // ψ² ≈ 0.382
});

/** Total weight sum (for normalization) */
const TOTAL_WEIGHT = Object.values(SCORING_WEIGHTS).reduce((a, b) => a + b, 0);

// ─── TOURNAMENT CONSTANTS ─────────────────────────────────────────────────────

/** Maximum contestants per bracket: fib(6)=8 */
const MAX_CONTESTANTS = fib(6);

/** ELO K-factor for standard (new) players: fib(9)=34 */
const ELO_K_STANDARD = fib(9);

/** ELO K-factor divisor for established players (≥ fib(11)=89 games) */
const ELO_K_ESTABLISHED_DIVISOR = PHI;  // K_est = ELO_K_STANDARD / φ ≈ 21

/** Established player game threshold: fib(11)=89 */
const ESTABLISHED_THRESHOLD = fib(11);

/** Default ELO starting rating: fib(11)*fib(7) = 89*13 = 1157 (nearest usage) */
// Express as Fibonacci sum: fib(11)*fib(8) = 89*21 = 1869 → too high.
// Use fib(17) = 1597 as the canonical starting ELO.
const INITIAL_ELO = fib(17);   // 1597

// ─── ARENA ENGINE CLASS ──────────────────────────────────────────────────────

/**
 * 9-stage model battle arena with phi-weighted scoring and ELO rating.
 *
 * @extends EventEmitter
 * @fires ArenaEngine#stage_complete
 * @fires ArenaEngine#battle_complete
 * @fires ArenaEngine#contestant_scored
 */
class ArenaEngine extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {string} [options.arenaId] - Optional arena identifier
   */
  constructor(options = {}) {
    super();
    this.arenaId = options.arenaId || crypto.randomBytes(fib(4)).toString('hex');

    /** Active battles: Map<battleId, battle> */
    this._battles = new Map();

    /** ELO ratings: Map<contestantId, { rating, games }> */
    this._eloRatings = new Map();

    /** Historical results for leaderboard: Array<result> */
    this._history = [];
  }

  // ─── PRIVATE: ELO HELPERS ──────────────────────────────────────────────────

  /**
   * Compute expected ELO win probability.
   * @param {number} ratingA
   * @param {number} ratingB
   * @returns {number} probability A beats B
   * @private
   */
  _eloExpected(ratingA, ratingB) {
    // Standard ELO expected score formula
    // ELO base: fib(7)+fib(4)-fib(5) = 13+3-5 = 11... use fib(7)+fib(3)-fib(5) = 13+2-5=10
    const ELO_BASE = fib(7) + fib(3) - fib(5); // 13 + 2 - 5 = 10 (standard ELO)
    return 1 / (1 + Math.pow(ELO_BASE, (ratingB - ratingA) / (fib(10) * fib(6))));
    // Denominator: fib(10)*fib(6) = 55*8 = 440 — instead of magic 400
  }

  /**
   * Update ELO rating for a contestant given actual vs expected score.
   * @param {string} contestantId
   * @param {number} actual  - 1 (win), 0 (loss), 0.5 (draw)
   * @param {number} expected - Expected score from _eloExpected
   * @private
   */
  _updateElo(contestantId, actual, expected) {
    const state = this._eloRatings.get(contestantId) || { rating: INITIAL_ELO, games: 0 };
    const k = state.games >= ESTABLISHED_THRESHOLD
      ? ELO_K_STANDARD / ELO_K_ESTABLISHED_DIVISOR
      : ELO_K_STANDARD;
    state.rating = state.rating + k * (actual - expected);
    state.games += 1;
    this._eloRatings.set(contestantId, state);
  }

  // ─── PRIVATE: HASH ────────────────────────────────────────────────────────

  /**
   * SHA-256 of any serialisable payload.
   * @param {*} data
   * @returns {string} hex digest
   * @private
   */
  _hash(data) {
    return crypto.createHash('sha256').update(JSON.stringify(data)).digest('hex');
  }

  // ─── STAGE IMPLEMENTATIONS ───────────────────────────────────────────────

  /**
   * Stage 0: init — allocate battle context.
   * @param {object} config
   * @returns {object} battle context
   * @private
   */
  _stageInit(config) {
    if (!config.contestants || config.contestants.length < 2) {
      throw new Error('Battle requires at least 2 contestants');
    }
    if (config.contestants.length > MAX_CONTESTANTS) {
      throw new Error(`Battle supports max ${MAX_CONTESTANTS} contestants`);
    }

    return {
      battleId: this._hash({ config, ts: Date.now() }).slice(0, fib(5) * 2),
      config,
      stage: PIPELINE_STAGES[0],
      stageIdx: 0,
      contestants: [],
      results: {},
      scores: {},
      rankings: [],
      createdAt: Date.now(),
    };
  }

  /**
   * Stage 1: configure — build contestant descriptors.
   * @param {object} battle
   * @private
   */
  _stageConfigure(battle) {
    battle.contestants = battle.config.contestants.map((c, idx) => ({
      id: c.id || `contestant_${idx}`,
      model: c.model || 'unknown',
      provider: c.provider || 'unknown',
      capabilities: c.capabilities || [],
      // Generate capability embedding via HDC
      embedding: normalize(hdcRandomVector(EMBEDDING_DIM)),
      config: c,
    }));
  }

  /**
   * Stage 2: spawn — initialise agent state for each contestant.
   * @param {object} battle
   * @private
   */
  _stageSpawn(battle) {
    for (const c of battle.contestants) {
      if (!this._eloRatings.has(c.id)) {
        this._eloRatings.set(c.id, { rating: INITIAL_ELO, games: 0 });
      }
      c.spawnedAt = Date.now();
      c.warmup = null;
    }
  }

  /**
   * Stage 3: warmup — phi-gated capability check (simulated).
   * @param {object} battle
   * @private
   */
  _stageWarmup(battle) {
    for (const c of battle.contestants) {
      // Warmup score: uniform in [CSL_THRESHOLDS.MINIMUM, 1.0] to ensure readiness
      // Base is CSL_THRESHOLDS.MINIMUM (≈0.500); range span = 1 - MINIMUM ≈ 0.500
      const capabilityScore = CSL_THRESHOLDS.MINIMUM + (1 - CSL_THRESHOLDS.MINIMUM) * Math.random();
      const gateScore = cslGate(1.0, capabilityScore, CSL_THRESHOLDS.MINIMUM, PSI_CUBE);
      c.warmup = { capabilityScore, gateScore, ready: gateScore >= CSL_THRESHOLDS.MINIMUM };
    }
    // Drop contestants that fail warmup
    battle.contestants = battle.contestants.filter(c => c.warmup.ready);
    if (battle.contestants.length < 2) {
      throw new Error('Insufficient contestants passed warmup');
    }
  }

  /**
   * Stage 4: execute — run the task for each contestant (simulated).
   * Task results are generated as structured metrics for scoring.
   * @param {object} battle
   * @param {object} task - { prompt, expectedOutput, timeLimit }
   * @private
   */
  _stageExecute(battle, task = {}) {
    for (const c of battle.contestants) {
      const startMs = Date.now();
      // Simulated raw metrics — real impl would call actual model APIs
      const rawLatencyMs = (fib(7) + Math.floor(Math.random() * fib(10))) * (1 + Math.random());
      const rawAccuracy  = PSI_SQ + Math.random() * (1 - PSI_SQ);
      const rawCostUnits = PSI_CUBE + Math.random() * PSI;
      const rawCreativity = PSI + Math.random() * PSI;
      const rawSafety    = CSL_THRESHOLDS.MEDIUM + Math.random() * PSI_SQ;

      battle.results[c.id] = {
        latencyMs:  rawLatencyMs,
        accuracy:   rawAccuracy,
        costUnits:  rawCostUnits,
        creativity: rawCreativity,
        safety:     Math.min(1, rawSafety),
        completedAt: Date.now(),
      };
    }
  }

  /**
   * Stage 5: collect — validate and normalise raw results.
   * @param {object} battle
   * @private
   */
  _stageCollect(battle) {
    const ids = battle.contestants.map(c => c.id);

    // Normalise latency (lower is better → invert to score)
    const latencies = ids.map(id => battle.results[id].latencyMs);
    const maxLatency = Math.max(...latencies) || 1;

    for (const id of ids) {
      const r = battle.results[id];
      r.speedScore = 1 - r.latencyMs / (maxLatency * PHI);
      r.speedScore = Math.max(0, Math.min(1, r.speedScore));
      // Normalise cost (lower is better → invert)
      r.costScore  = 1 - r.costUnits;
    }
  }

  /**
   * Stage 6: score — apply phi-weighted scoring formula.
   * @param {Array<object>} results - Array of { contestantId, metrics }
   * @returns {object} Map<contestantId, compositeScore>
   */
  score(results) {
    const scores = {};
    for (const r of results) {
      const { id, accuracy, speedScore, costScore, creativity, safety } = r;
      const weighted =
        SCORING_WEIGHTS.accuracy   * accuracy   +
        SCORING_WEIGHTS.speed      * speedScore  +
        SCORING_WEIGHTS.cost       * costScore   +
        SCORING_WEIGHTS.creativity * creativity  +
        SCORING_WEIGHTS.safety     * safety;
      scores[id] = weighted / TOTAL_WEIGHT;
    }
    return scores;
  }

  /**
   * Stage 6 (internal): compute scores for current battle.
   * @param {object} battle
   * @private
   */
  _stageScore(battle) {
    const metricsArray = battle.contestants.map(c => ({
      id: c.id,
      accuracy:   battle.results[c.id].accuracy,
      speedScore: battle.results[c.id].speedScore,
      costScore:  battle.results[c.id].costScore,
      creativity: battle.results[c.id].creativity,
      safety:     battle.results[c.id].safety,
    }));
    battle.scores = this.score(metricsArray);
    this.emit('contestant_scored', { battleId: battle.battleId, scores: battle.scores });
  }

  /**
   * Stage 7: rank — ELO update + cslCONSENSUS ordering.
   * @param {Array<{ id: string, score: number }>} scoreEntries
   * @returns {Array<{ id: string, score: number, rank: number }>}
   */
  rank(scoreEntries) {
    const sorted = [...scoreEntries].sort((a, b) => b.score - a.score);

    // CSL consensus: phi-fusion weighted average of scores
    const weights = phiFusionWeights(sorted.length);
    const consensusScore = sorted.reduce((sum, e, i) => sum + weights[i] * e.score, 0);

    return sorted.map((e, idx) => ({
      ...e,
      rank: idx + 1,
      consensusScore,
    }));
  }

  /**
   * Stage 7 (internal): apply ranking to battle.
   * @param {object} battle
   * @private
   */
  _stageRank(battle) {
    const entries = Object.entries(battle.scores).map(([id, score]) => ({ id, score }));
    battle.rankings = this.rank(entries);

    // ELO updates: compare each pair
    for (let i = 0; i < battle.rankings.length; i++) {
      for (let j = i + 1; j < battle.rankings.length; j++) {
        const a = battle.rankings[i];
        const b = battle.rankings[j];
        const ratingA = this._eloRatings.get(a.id)?.rating || INITIAL_ELO;
        const ratingB = this._eloRatings.get(b.id)?.rating || INITIAL_ELO;
        const expected = this._eloExpected(ratingA, ratingB);
        this._updateElo(a.id, 1, expected);
        this._updateElo(b.id, 0, 1 - expected);
      }
    }
  }

  /**
   * Stage 8: report — emit final results.
   * @param {object} battle
   * @private
   */
  _stageReport(battle) {
    battle.completedAt = Date.now();
    battle.durationMs = battle.completedAt - battle.createdAt;
    battle.resultHash = this._hash(battle.rankings);
    this._history.push({
      battleId: battle.battleId,
      rankings: battle.rankings,
      scores: battle.scores,
      resultHash: battle.resultHash,
      completedAt: battle.completedAt,
    });
    this.emit('battle_complete', battle);
  }

  // ─── PUBLIC: CREATE BATTLE ──────────────────────────────────────────────────

  /**
   * Create a new battle configuration.
   *
   * @param {object} config
   * @param {Array<object>} config.contestants - Contestant descriptors
   * @param {object} [config.task] - Task description
   * @returns {{ battleId: string, contestants: number }}
   */
  createBattle(config) {
    const battle = this._stageInit(config);
    this._battles.set(battle.battleId, battle);
    this.emit('stage_complete', { battleId: battle.battleId, stage: 'init' });
    return { battleId: battle.battleId, contestants: config.contestants.length };
  }

  // ─── PUBLIC: RUN PIPELINE ───────────────────────────────────────────────────

  /**
   * Run the full 9-stage battle pipeline for a created battle.
   *
   * @param {{ battleId: string }} battleRef - Returned from createBattle()
   * @returns {object} Final battle object with rankings and scores
   */
  runPipeline(battleRef) {
    const battle = this._battles.get(battleRef.battleId);
    if (!battle) throw new Error(`Battle not found: ${battleRef.battleId}`);

    const stages = [
      () => this._stageConfigure(battle),
      () => this._stageSpawn(battle),
      () => this._stageWarmup(battle),
      () => this._stageExecute(battle, battle.config.task),
      () => this._stageCollect(battle),
      () => this._stageScore(battle),
      () => this._stageRank(battle),
      () => this._stageReport(battle),
    ];

    for (let i = 0; i < stages.length; i++) {
      stages[i]();
      battle.stageIdx = i + 1;
      battle.stage = PIPELINE_STAGES[i + 1] || 'complete';
      this.emit('stage_complete', { battleId: battle.battleId, stage: battle.stage });
    }

    return battle;
  }

  // ─── PUBLIC: LEADERBOARD ────────────────────────────────────────────────────

  /**
   * Get the global leaderboard sorted by ELO rating.
   *
   * @returns {Array<{ contestantId: string, elo: number, games: number }>}
   */
  getLeaderboard() {
    return Array.from(this._eloRatings.entries())
      .map(([contestantId, state]) => ({ contestantId, elo: state.rating, games: state.games }))
      .sort((a, b) => b.elo - a.elo);
  }
}

// ─── EXPORTS ─────────────────────────────────────────────────────────────────

module.exports = {
  ArenaEngine,
  PIPELINE_STAGES,
  SCORING_WEIGHTS,
  MAX_CONTESTANTS,
  ELO_K_STANDARD,
  INITIAL_ELO,
  ESTABLISHED_THRESHOLD,
};
