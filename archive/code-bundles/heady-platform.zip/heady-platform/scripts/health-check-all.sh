#!/usr/bin/env bash
set -euo pipefail

# Heady™ Health Check — All Services
# © 2026 HeadySystems Inc. — Eric Haywood, Founder

echo "Heady™ Service Health Check"
echo "═══════════════════════════"

SERVICES=(
  "auth-session-server:3397:security"
  "notification-service:3398:monitoring"
  "analytics-service:3399:monitoring"
  "billing-service:3400:specialized"
  "search-service:3401:data"
  "scheduler-service:3402:orchestration"
  "migration-service:3403:data"
  "asset-pipeline:3404:data"
)

HEALTHY=0
DEGRADED=0
UNHEALTHY=0

for entry in "${SERVICES[@]}"; do
  IFS=: read -r name port domain <<< "$entry"
  RESPONSE=$(curl -s --max-time 5 "http://localhost:${port}/health" 2>/dev/null || echo '{"status":"unreachable"}')
  STATUS=$(echo "$RESPONSE" | grep -oP '"status"\s*:\s*"\K[^"]+' 2>/dev/null || echo "unreachable")
  
  case "$STATUS" in
    healthy)
      echo "  ✓ ${name} (${domain}) — healthy"
      HEALTHY=$((HEALTHY + 1))
      ;;
    degraded)
      echo "  ⚠ ${name} (${domain}) — degraded"
      DEGRADED=$((DEGRADED + 1))
      ;;
    *)
      echo "  ✗ ${name} (${domain}) — ${STATUS}"
      UNHEALTHY=$((UNHEALTHY + 1))
      ;;
  esac
done

echo ""
echo "Summary: ${HEALTHY} healthy, ${DEGRADED} degraded, ${UNHEALTHY} unhealthy"
echo "Total: $((HEALTHY + DEGRADED + UNHEALTHY)) services checked"

if [ "$UNHEALTHY" -gt 0 ]; then
  exit 1
fi
