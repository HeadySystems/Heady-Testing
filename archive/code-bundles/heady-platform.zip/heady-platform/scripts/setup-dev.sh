#!/usr/bin/env bash
set -euo pipefail

# Heady™ Developer Setup Script
# Zero to running system in < 5 minutes
# © 2026 HeadySystems Inc. — Eric Haywood, Founder

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log() { echo -e "${GREEN}[HEADY]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
fail() { echo -e "${RED}[FAIL]${NC} $1"; exit 1; }

echo -e "${CYAN}"
echo "  ╦ ╦╔═╗╔═╗╔╦╗╦ ╦™"
echo "  ╠═╣║╣ ╠═╣ ║║╚╦╝"
echo "  ╩ ╩╚═╝╩ ╩═╩╝ ╩"
echo "  Developer Environment Setup"
echo -e "${NC}"

# Check Node.js
log "Checking Node.js..."
if ! command -v node &> /dev/null; then
  fail "Node.js not found. Install Node.js 20+ from https://nodejs.org"
fi
NODE_VERSION=$(node -v | sed 's/v//' | cut -d. -f1)
if [ "$NODE_VERSION" -lt 20 ]; then
  fail "Node.js 20+ required. Current: $(node -v)"
fi
log "Node.js $(node -v) ✓"

# Check Docker
log "Checking Docker..."
if ! command -v docker &> /dev/null; then
  fail "Docker not found. Install Docker Desktop from https://docker.com"
fi
if ! docker info &> /dev/null; then
  fail "Docker daemon not running. Start Docker Desktop."
fi
log "Docker $(docker --version | grep -oP '\d+\.\d+\.\d+') ✓"

# Check Docker Compose
log "Checking Docker Compose..."
if ! docker compose version &> /dev/null; then
  fail "Docker Compose v2 not found."
fi
log "Docker Compose $(docker compose version --short) ✓"

# Check gcloud (optional)
if command -v gcloud &> /dev/null; then
  log "gcloud CLI $(gcloud --version 2>/dev/null | head -1 | grep -oP '\d+\.\d+\.\d+') ✓"
else
  warn "gcloud CLI not found. Not required for local development."
fi

# Check .env file
log "Checking environment configuration..."
if [ ! -f ".env" ]; then
  warn ".env file not found. Creating from template..."
  cat > .env << 'ENVFILE'
NODE_ENV=development
FIREBASE_PROJECT_ID=gen-lang-client-0920560496
PGVECTOR_HOST=localhost
PGVECTOR_PORT=5432
PGVECTOR_DB=heady
STRIPE_SECRET_KEY=
STRIPE_WEBHOOK_SECRET=
GRAFANA_PASSWORD=heady-admin
ENVFILE
  log ".env created. Edit with your credentials as needed."
else
  log ".env exists ✓"
fi

# Install dependencies
log "Installing dependencies for all services..."
SERVICES_DIR="./services"
if [ -d "$SERVICES_DIR" ]; then
  for svc in "$SERVICES_DIR"/*/; do
    if [ -f "$svc/package.json" ]; then
      svc_name=$(basename "$svc")
      log "  Installing: $svc_name"
      (cd "$svc" && npm ci --silent 2>/dev/null || npm install --silent)
    fi
  done
fi
log "Dependencies installed ✓"

# Pull Docker images
log "Pulling required Docker images..."
docker pull node:20-alpine --quiet 2>/dev/null || true
docker pull bitnami/pgbouncer:latest --quiet 2>/dev/null || true
docker pull nats:2-alpine --quiet 2>/dev/null || true
docker pull prom/prometheus:latest --quiet 2>/dev/null || true
docker pull grafana/grafana:latest --quiet 2>/dev/null || true
docker pull grafana/loki:latest --quiet 2>/dev/null || true
log "Docker images pulled ✓"

# Boot services
log "Starting services with Docker Compose..."
if [ -f "infrastructure/docker/docker-compose.new-services.yml" ]; then
  docker compose -f infrastructure/docker/docker-compose.new-services.yml up -d --build
fi
log "Services starting... Waiting 21 seconds for health checks..."
sleep 21  # Fibonacci

# Health check
log "Running health checks..."
HEALTHY=0
TOTAL=0
for port in 3397 3398 3399 3400 3401 3402 3403 3404; do
  TOTAL=$((TOTAL + 1))
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:${port}/health" 2>/dev/null || echo "000")
  if [ "$STATUS" == "200" ]; then
    HEALTHY=$((HEALTHY + 1))
    log "  Port ${port}: ${GREEN}healthy${NC}"
  else
    warn "  Port ${port}: not responding (HTTP ${STATUS})"
  fi
done

echo ""
echo -e "${CYAN}═══════════════════════════════════════${NC}"
log "Setup complete! ${HEALTHY}/${TOTAL} services healthy"
echo -e "${CYAN}═══════════════════════════════════════${NC}"
echo ""
log "Services:"
echo "  Auth:          http://localhost:3397/health"
echo "  Notifications: http://localhost:3398/health"
echo "  Analytics:     http://localhost:3399/health"
echo "  Billing:       http://localhost:3400/health"
echo "  Search:        http://localhost:3401/health"
echo "  Scheduler:     http://localhost:3402/health"
echo "  Migrations:    http://localhost:3403/health"
echo "  Assets:        http://localhost:3404/health"
echo ""
echo "  Grafana:       http://localhost:3000 (admin / heady-admin)"
echo "  Prometheus:    http://localhost:9090"
echo "  NATS Monitor:  http://localhost:8222"
echo ""
log "Happy building! — Eric Haywood, Founder"
