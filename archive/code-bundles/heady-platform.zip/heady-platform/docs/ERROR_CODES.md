# ERROR_CODES.md — Heady™ Error Code Catalog

Every error response across all services uses a unique code, HTTP status, description, and suggested fix.

## Format: `HEADY-{SERVICE}-{NUMBER}`

---

## Auth Session Server (HEADY-AUTH-*)

| Code | HTTP | Description | Fix |
|------|------|-------------|-----|
| HEADY-AUTH-001 | 429 | Rate limit exceeded | Wait for Retry-After header duration, then retry |
| HEADY-AUTH-002 | 400 | Missing idToken in request body | Include `{ "idToken": "..." }` in POST body |
| HEADY-AUTH-003 | 401 | Firebase token verification failed | Re-authenticate with Firebase, get fresh ID token |
| HEADY-AUTH-004 | 401 | No session cookie present | Sign in first via POST /api/session/create |
| HEADY-AUTH-005 | 401 | Session not found or expired | Re-authenticate; session may have been cleaned up |
| HEADY-AUTH-006 | 401 | Session expired | Re-authenticate; session TTL is Fibonacci-derived |
| HEADY-AUTH-007 | 401 | Client fingerprint mismatch | Possible session replay. Re-authenticate from current client |

## Notification Service (HEADY-NOTIF-*)

| Code | HTTP | Description | Fix |
|------|------|-------------|-----|
| HEADY-NOTIF-001 | 400 | Missing required fields: userId, title, body | Include all required fields in request body |
| HEADY-NOTIF-002 | 404 | Notification not found | Verify notification ID and userId |

## Analytics Service (HEADY-ANALYTICS-*)

| Code | HTTP | Description | Fix |
|------|------|-------------|-----|
| HEADY-ANALYTICS-001 | 400 | Missing required field: eventType | Include `eventType` in event payload |
| HEADY-ANALYTICS-002 | 400 | Missing or empty events array | Send `{ "events": [...] }` for batch endpoint |
| HEADY-ANALYTICS-003 | 400 | Batch size exceeds maximum | Split batch into chunks of 34 events (Fibonacci) |
| HEADY-ANALYTICS-004 | 400 | Funnel requires name and 2+ steps | Define funnel with `{ "name": "...", "steps": [...] }` |
| HEADY-ANALYTICS-005 | 404 | Funnel not found | Check funnel name spelling |

## Billing Service (HEADY-BILLING-*)

| Code | HTTP | Description | Fix |
|------|------|-------------|-----|
| HEADY-BILLING-001 | 400 | Missing userId or invalid plan | Include userId and valid plan (free/pro/enterprise) |
| HEADY-BILLING-002 | 400 | Paid plans require stripePaymentMethodId | Include Stripe payment method for pro/enterprise |
| HEADY-BILLING-003 | 404 | No active subscription found | User needs to subscribe first |
| HEADY-BILLING-004 | 404 | Subscription not found | Verify subscription ID |

## Search Service (HEADY-SEARCH-*)

| Code | HTTP | Description | Fix |
|------|------|-------------|-----|
| HEADY-SEARCH-001 | 400 | Missing required fields: id, title | Include id and title when indexing documents |
| HEADY-SEARCH-002 | 400 | Missing query parameter 'q' | Include `{ "q": "search terms" }` in request |

## Scheduler Service (HEADY-SCHED-*)

| Code | HTTP | Description | Fix |
|------|------|-------------|-----|
| HEADY-SCHED-001 | 400 | Missing required fields: name, handler | Include job name and handler URL |
| HEADY-SCHED-002 | 400 | Must provide cron or phiInterval | Include either cron expression or phiInterval in ms |
| HEADY-SCHED-003 | 404 | Job not found | Verify job ID |

## Migration Service (HEADY-MIGRATE-*)

| Code | HTTP | Description | Fix |
|------|------|-------------|-----|
| HEADY-MIGRATE-001 | 404 | Target version not found or already applied | Check available migrations via GET /api/migrations |
| HEADY-MIGRATE-002 | 400 | No migrations to roll back | All migrations already rolled back |
| HEADY-MIGRATE-003 | 400 | Missing migration fields | Include version, name, sql, rollbackSql |
| HEADY-MIGRATE-004 | 409 | Version already exists | Use a unique version number |

## Asset Pipeline (HEADY-ASSET-*)

| Code | HTTP | Description | Fix |
|------|------|-------------|-----|
| HEADY-ASSET-001 | 400 | Missing inputUrl or operations | Include inputUrl and operations array |
| HEADY-ASSET-002 | 400 | Invalid operation type | Use: resize, optimize, format, or responsive |
| HEADY-ASSET-003 | 400 | Missing inputUrl | Include the source image URL |
| HEADY-ASSET-004 | 404 | Job not found | Verify job ID |

## Rate Limiting (HEADY-*-RATELIMIT)

| Code | HTTP | Description | Fix |
|------|------|-------------|-----|
| HEADY-{SERVICE}-RATELIMIT | 429 | Rate limit exceeded | Check Retry-After header; use φ-exponential backoff |

---

*Error codes are generated from this catalog. Each service imports its error constants at startup.*
