# Heady™ Incident Runbooks

## Runbook: auth-session-server returns 503

**Symptoms:** Users cannot sign in across any of the 9 domains. Auth relay iframe returns errors.

**Diagnosis:**
1. Check service health: `curl https://auth.headysystems.com/health`
2. Check Cloud Run logs: `gcloud logging read "resource.labels.service_name=heady-auth-session-server" --limit 50`
3. Check if Firebase is responding: `curl https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=YOUR_API_KEY`
4. Check memory usage in health response — if heap exceeds 233MB (Fibonacci), service is OOM

**Remediation:**
1. If single instance: Scale to min-instances=2: `gcloud run services update heady-auth-session-server --min-instances 2`
2. If memory: Restart service: `gcloud run services update heady-auth-session-server --no-traffic && gcloud run services update heady-auth-session-server --traffic latest=100`
3. If Firebase down: Sessions already created continue working (cookie-based). New sign-ins fail until Firebase recovers. No action needed from our side.

**Post-incident:** Check session store size in metrics. If growing unbounded, investigate cleanup interval (should be every 34 seconds).

---

## Runbook: heady-brain returns 503

**Symptoms:** AI inference requests fail. Users see "AI temporarily unavailable."

**Diagnosis:**
1. Check pgvector connection: `SELECT 1 FROM heady_embeddings LIMIT 1;`
2. Check NATS JetStream: `curl http://nats:8222/jsz`
3. Check PgBouncer pool exhaustion: `SHOW POOLS;` in PgBouncer admin
4. Check if vector index is corrupted: `REINDEX INDEX idx_embeddings_hnsw;`

**Remediation:**
1. If pgvector down: Check PgBouncer → check database connection → restart database
2. If NATS down: Restart NATS container, check JetStream store directory
3. If pool exhaustion: Increase PgBouncer default_pool_size from 34 to 55 (next Fibonacci)

---

## Runbook: Search returns empty results

**Symptoms:** All search queries return 0 results despite indexed content.

**Diagnosis:**
1. Check search index size: `curl http://search-service:3401/api/search/stats`
2. If index is empty: VectorIndexer webhook may have stopped firing
3. Check Drupal webhook config: verify URL and auth token
4. Check if query cache is stale: restart service to clear in-memory cache

**Remediation:**
1. If webhook broken: Reindex manually via migration-service
2. If cache stale: POST to `/api/search/index` with known content to verify indexing works
3. If search logic broken: Check BM25 parameters (k1=φ, b=ψ) in search-service source

---

## Runbook: Billing webhook failures

**Symptoms:** Stripe payments succeed but subscription status not updated. Users stuck on wrong plan.

**Diagnosis:**
1. Check Stripe webhook dashboard for delivery failures
2. Check billing-service logs for webhook signature verification errors
3. Verify STRIPE_WEBHOOK_SECRET environment variable matches Stripe dashboard

**Remediation:**
1. If signature mismatch: Rotate webhook secret in both Stripe and Google Secret Manager
2. If service was down: Stripe retries webhooks for 72 hours — check for pending retries
3. Manual fix: Query Stripe API for subscription status, update local store

---

## Runbook: Rate limiter too aggressive

**Symptoms:** Legitimate users receiving 429 errors during normal usage.

**Diagnosis:**
1. Check rate limit headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`
2. Check if user is hitting anonymous limits (34/min) when they should be authenticated (89/min)
3. Check if API key header `x-api-key` is being sent correctly

**Remediation:**
1. If auth not propagating: Check auth-session-server relay iframe
2. If limits too low: Adjust to next Fibonacci value in shared/constants/phi.js
3. Emergency: Temporarily disable rate limiter via feature flag

---

## Post-Incident Review Template

```
## Incident: [Title]
**Date:** YYYY-MM-DD
**Duration:** X minutes
**Severity:** P1/P2/P3
**Services affected:** [list]

### Timeline
- HH:MM — First alert
- HH:MM — Investigation started
- HH:MM — Root cause identified
- HH:MM — Fix deployed
- HH:MM — Confirmed resolved

### Root Cause
[Description]

### Impact
[User impact, data impact]

### Action Items
- [ ] [Preventive action]
- [ ] [Detection improvement]
- [ ] [Documentation update]
```
