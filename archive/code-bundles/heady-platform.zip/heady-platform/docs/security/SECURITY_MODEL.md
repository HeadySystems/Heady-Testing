# Heady™ Security Model

© 2026 HeadySystems Inc. — Eric Haywood, Founder

## Authentication Flow

1. User authenticates via Firebase (Google OAuth, Email/Password, or Anonymous)
2. Client receives Firebase ID token
3. Client POSTs ID token to `auth.headysystems.com/api/session/create`
4. Auth session server verifies token with Firebase Admin SDK
5. Server generates session ID, binds to client fingerprint (IP + User-Agent hash)
6. Server sets `__Host-__heady_session` httpOnly secure cookie on `.headysystems.com`
7. Cross-domain propagation via relay iframe + postMessage to all 9 domains

## Session Security

- **Cookie attributes:** httpOnly, Secure, SameSite=None, `__Host-` prefix
- **No localStorage token storage — EVER**
- **Client fingerprinting:** Session bound to SHA-256(IP + User-Agent)
- **Fingerprint mismatch:** Session destroyed, re-authentication required
- **Session TTL:** Fibonacci-derived (377 minutes)
- **Automatic cleanup:** Expired sessions purged every 34 seconds (Fibonacci)

## Inter-Service Security (Zero Trust)

- **Envoy sidecars** on every service provide mTLS
- **Certificate rotation:** Every 89 days (Fibonacci) via Google Secret Manager
- **API key rotation:** Every 21 days (Fibonacci)
- **Request signing:** HMAC-SHA256 for inter-service calls
- **Timeout enforcement:** φ-scaled (1.618s connect, 4.236s request)

## Rate Limiting

- **Anonymous:** 34 requests/minute (Fibonacci)
- **Authenticated:** 89 requests/minute (Fibonacci)
- **Enterprise:** 233 requests/minute (Fibonacci)
- **Sliding window counter** with φ-weighted interpolation between windows
- **Per-IP anomaly detection** for anonymous signup bursts

## Content Security Policy

Applied to all 9 websites:
```
default-src 'self';
script-src 'self';
style-src 'self' 'unsafe-inline';
img-src 'self' data: https:;
connect-src 'self' https://identitytoolkit.googleapis.com https://securetoken.googleapis.com;
frame-ancestors <allowed-origins>;
object-src 'none';
base-uri 'self';
```

No `unsafe-eval`. No `unsafe-inline` for scripts. SRI for all external scripts.

## WebSocket Security

- Token validation on upgrade request
- Re-validation on every frame (configurable interval: 34 seconds)
- Connection termination on expired/invalid tokens
- Heartbeat pings for connection liveness

## Container Security

- Multi-stage Docker builds with distroless base images (<100MB)
- SBOM generation for every image
- Signed container images with binary attestation
- Dependency scanning (Snyk/Dependabot) before every build
- Non-root container execution (`USER nonroot`)

## Secrets Management

- All secrets in Google Secret Manager (not environment variables in production)
- RBAC for secret access with audit trail
- φ-scaled rotation intervals:
  - API keys: 21 days (Fibonacci)
  - Certificates: 89 days (Fibonacci)
  - Session keys: 13 days (Fibonacci)

## OWASP Top 10 for AI

1. **Prompt injection defense:** Parameterized prompt templates, no string concatenation
2. **LLM output validation:** JSON schema validation before downstream API calls
3. **HTML output sanitization:** DOMPurify on all LLM-generated HTML
4. **Input validation:** Schema validation on all API endpoints
5. **SQL injection prevention:** Parameterized queries only
6. **XSS prevention:** CSP headers, output encoding
7. **CSRF prevention:** SameSite cookies, origin verification
8. **Broken auth prevention:** Session fingerprinting, httpOnly cookies
9. **Sensitive data exposure:** No PII in logs, hashed user IDs in analytics
10. **Insufficient logging:** Structured JSON logging with trace correlation

## Autonomy Guardrails

Operations whitelist for autonomous agents:

**ALLOWED:** deploy, update dependencies, generate observability configs, run tests, create backups, scale services

**FORBIDDEN:** delete data, rotate production secrets, modify auth rules, change billing, access PII, modify security policies

All production changes require Git-versioned approval trail.
