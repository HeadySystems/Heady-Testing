# ADR-002: pgvector over Pinecone for Vector Memory

**Status:** Accepted
**Date:** 2026-01-20
**Author:** Eric Haywood

## Context

Heady™'s φ-scaled vector memory architecture requires high-performance similarity search across 384-dimensional embeddings. Options evaluated: Pinecone (managed), Weaviate (self-hosted), Milvus (self-hosted), and pgvector (PostgreSQL extension).

## Decision

Use pgvector with HNSW indexing as the vector store, deployed on Cloud SQL or self-managed PostgreSQL.

## Rationale

1. **Sovereignty:** Pinecone is a managed service — data leaves our infrastructure. Heady™ is a *sovereign* AI platform; vector memory must remain within our GCP project boundary.
2. **Unified data layer:** pgvector runs inside PostgreSQL, meaning relational data (sessions, subscriptions, analytics) and vector data (embeddings, projections) share a single transactional database. No ETL between systems.
3. **Cost:** Pinecone pricing scales with vector count. pgvector has zero per-vector cost — only compute.
4. **HNSW performance:** pgvector's HNSW index with ef_construction=200, m=32 achieves >0.95 recall at <50ms for 384-dim vectors. Sufficient for production workloads.
5. **φ-math integration:** Custom SQL functions can implement CSL-gated similarity thresholds directly in queries.

## Consequences

**Positive:** Full data sovereignty, lower cost, unified queries, no vendor lock-in.
**Negative:** Must manage HNSW index tuning ourselves, no managed scaling, must implement connection pooling (PgBouncer).
