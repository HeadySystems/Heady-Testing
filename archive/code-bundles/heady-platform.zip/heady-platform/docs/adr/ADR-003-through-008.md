# ADR-003: Firebase Authentication

**Status:** Accepted | **Date:** 2026-01-22 | **Author:** Eric Haywood

## Decision
Use Firebase Authentication for identity (Google OAuth, email/password, anonymous) with a custom session server (auth-session-server) that converts Firebase ID tokens into httpOnly session cookies.

## Rationale
Firebase handles identity provider complexity (Google, Apple, etc.) while our session server maintains sovereignty over session management. No localStorage token storage — httpOnly cookies only. Cross-domain relay via iframe + postMessage propagates auth across all 9 domains.

## Consequences
Depends on Firebase for identity verification but not session management. Session replay protection via client fingerprinting (IP + User-Agent hash).

---

# ADR-004: Sacred Geometry Constants (φ-Math)

**Status:** Accepted | **Date:** 2026-02-01 | **Author:** Eric Haywood

## Decision
All system constants derive from φ (Golden Ratio), ψ (its inverse), and the Fibonacci sequence. No magic numbers.

## Rationale
Sacred Geometry provides a mathematically coherent framework for all numeric decisions: timeouts (1.618s), circuit breaker thresholds (89/55/144), cache sizes (21/55/144), rate limits (34/89/233), retry backoff (φ-exponential), feature flag rollout stages (6.18%/38.2%/61.8%/100%), and connection pool sizes (34/233). This ensures consistency, eliminates arbitrary decisions, and embeds the platform's philosophical foundation into its engineering.

## Consequences
All new constants must justify their derivation from φ/ψ/Fibonacci. Documented in shared/constants/phi.js.

---

# ADR-005: CSL (Confidence-Scored Logic) over Boolean

**Status:** Accepted | **Date:** 2026-02-05 | **Author:** Eric Haywood

## Decision
Replace boolean true/false gates with CSL confidence-weighted decisions using three thresholds: include (0.382), boost (0.618), inject (0.718).

## Rationale
Binary decisions lose information. CSL preserves decision uncertainty and enables gradient responses: low-confidence results are included but not promoted, medium-confidence results are boosted, high-confidence results are injected into primary flows.

## Consequences
Every decision point in the platform must use CSL gates. Service health, search relevance, feature flags, and agent routing all use confidence scoring rather than boolean logic.

---

# ADR-006: Concurrent-Equals Architecture

**Status:** Accepted | **Date:** 2026-02-10 | **Author:** Eric Haywood

## Decision
No priority/ranking language in the codebase. All services, agents, and processes execute as concurrent equals. No service is "primary" or "secondary."

## Rationale
Priority-based architectures create single points of failure and implicit hierarchies. Concurrent-equals ensures every service is independently valuable and no service depends on being "first." This mirrors the platform's philosophical commitment to non-hierarchical AI.

## Consequences
Load balancing is round-robin (not weighted). Service health is reported independently (not relative to others). Documentation uses "concurrent" not "primary/secondary."

---

# ADR-007: Drupal CMS for Content Management

**Status:** Accepted | **Date:** 2026-02-15 | **Author:** Eric Haywood

## Decision
Use Drupal as the CMS for all 13 content types (articles, documentation, case studies, patents, events, etc.) with a VectorIndexer webhook that fires on create/update/delete to maintain search index currency.

## Rationale
Drupal provides enterprise-grade content modeling (13 custom content types), editorial workflows, access control, and a mature REST API. The VectorIndexer webhook bridges CMS content into the vector memory layer, ensuring all content is searchable via both full-text and semantic similarity.

## Consequences
Drupal deployment adds PHP infrastructure alongside Node.js services. Content editors use Drupal's admin UI. Vector embeddings are generated asynchronously on content change.

---

# ADR-008: NATS JetStream as Event Bus

**Status:** Accepted | **Date:** 2026-03-01 | **Author:** Eric Haywood

## Decision
Deploy NATS JetStream as the central async message broker for service-to-service communication that doesn't require synchronous response.

## Rationale
NATS JetStream provides durable message delivery, dead letter queues, and subject-based routing. Subjects are organized by domain: heady.memory.*, heady.inference.*, heady.agents.*. This decouples services temporally — a service can be down and catch up on events when it recovers.

## Consequences
All async inter-service communication goes through NATS. Each consumer has a DLQ policy (φ³ retries = 4 attempts before dead letter). DLQ size is monitored as a health metric.
