# Heady™ Developer Onboarding Guide

Welcome to HeadySystems. This guide gets you from zero to a running system in under 5 minutes.

## Prerequisites

- Node.js 20+ (`node --version`)
- Docker Desktop with Docker Compose v2+ (`docker compose version`)
- gcloud CLI (`gcloud --version`) — only needed for deployment
- Git

## Quick Start

```bash
# 1. Clone the repository
git clone https://github.com/HeadyMe/heady-platform.git
cd heady-platform

# 2. Run the setup script (validates prerequisites, installs deps, boots services)
./scripts/setup-dev.sh

# 3. Verify all services are healthy
./scripts/health-check-all.sh
```

That's it. All services should be running on ports 3310–3404.

## Architecture Overview

Heady™ is a sovereign AI operating system with 50+ microservices organized into 10 domains. Read the full architecture in `docs/adr/ADR-001-microservice-architecture.md`.

**Key domains:**
- **Inference** (ports 3310-3314): heady-brain, heady-brains, heady-infer, ai-router, model-gateway
- **Memory** (ports 3315-3318): heady-embed, heady-memory, heady-vector, heady-projection
- **Security** (port 3397): auth-session-server (central auth)
- **Data** (ports 3401-3404): search-service, scheduler-service, migration-service, asset-pipeline

## The 8 Unbreakable Laws

Before writing any code, understand these:

1. **Thoroughness over speed** — Correctness first
2. **Complete implementation only** — No stubs, no TODOs, no placeholders
3. **φ-scaled everything** — Golden ratio derives all constants (see `shared/constants/phi.js`)
4. **CSL gates replace boolean** — Confidence-weighted decisions (0.382/0.618/0.718)
5. **HeadyAutoContext mandatory** — Context middleware on every service, page, endpoint
6. **Zero-trust security** — mTLS between services, httpOnly cookies, no localStorage
7. **Concurrent-equals** — No priorities, no rankings
8. **Sacred Geometry** — φ, Fibonacci, golden spiral inform all design

## Development Workflow

```bash
# Start a specific service in dev mode (with hot-reload)
cd services/auth-session-server
npm run dev

# Run tests for a service
npm test

# Check health
npm run health

# Run all tests across all services
npm test --workspaces
```

## Commit Conventions

We use conventional commits:
- `feat:` New feature
- `fix:` Bug fix
- `chore:` Maintenance
- `docs:` Documentation
- `perf:` Performance improvement
- `security:` Security fix

## Key Files to Know

- `shared/constants/phi.js` — All φ/Fibonacci constants (import this, never hardcode numbers)
- `shared/types/index.d.ts` — TypeScript types for all inter-service contracts
- `shared/schemas/` — JSON Schema for API contract validation
- `docs/ERROR_CODES.md` — Every error code across all services
- `docs/security/SECURITY_MODEL.md` — Auth flow, mTLS, secrets management
- `docs/adr/` — Architecture Decision Records explaining every major choice

## Troubleshooting

- **Service won't start:** Check port conflicts (`lsof -i :PORT`), check Docker is running
- **Auth not propagating:** Verify relay iframe URL, check CORS allowlist in auth-session-server
- **Health check failing:** Each service has a `DEBUG.md` with common failure modes
- **Tests failing:** Run `npm ci` to ensure clean dependencies

## Questions?

- Architecture questions: Read the ADRs in `docs/adr/`
- Service-specific issues: Read the `DEBUG.md` in each service directory
- Error codes: Check `docs/ERROR_CODES.md`
- Security questions: Read `docs/security/SECURITY_MODEL.md`

© 2026 HeadySystems Inc. — Eric Haywood, Founder
