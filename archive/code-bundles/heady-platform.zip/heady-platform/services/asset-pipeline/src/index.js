"use strict";

/**
 * Heady™ Asset Pipeline Service
 * Image optimization, CDN upload, responsive image generation
 * Port: 3404
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const express = require("express");
const crypto = require("crypto");
const { PHI, PSI, FIB, CACHE_SIZES, phiBackoff } = require("../../shared/constants/phi");

const app = express();
const PORT = 3404;

const jobQueue = [];
const completedJobs = new Map();
const processingJobs = new Map();
const FIB_BREAKPOINTS = [FIB[8] * 10, FIB[9] * 10, FIB[10] * 10, FIB[11] * 10, FIB[12] * 10];

app.use(express.json({ limit: "50mb" }));
app.use((req, res, next) => {
  req.heady = {
    requestId: crypto.randomUUID(),
    traceId: req.headers["x-trace-id"] || crypto.randomBytes(16).toString("hex"),
    spanId: crypto.randomBytes(8).toString("hex"),
    domain: "data",
    timestamp: Date.now(),
    cslConfidence: PSI,
    phiVersion: "4.0.0",
  };
  res.setHeader("x-request-id", req.heady.requestId);
  res.setHeader("x-trace-id", req.heady.traceId);
  next();
});

app.post("/api/assets/process", (req, res) => {
  const { inputUrl, operations } = req.body;
  if (!inputUrl || !Array.isArray(operations) || operations.length === 0) {
    return res.status(400).json({
      code: "HEADY-ASSET-001",
      httpStatus: 400,
      message: "Missing inputUrl or operations array",
      service: "asset-pipeline",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  for (const op of operations) {
    const valid = ["resize", "optimize", "format", "responsive"];
    if (!valid.includes(op.type)) {
      return res.status(400).json({
        code: "HEADY-ASSET-002",
        httpStatus: 400,
        message: `Invalid operation type: ${op.type}. Allowed: ${valid.join(", ")}`,
        service: "asset-pipeline",
        traceId: req.heady.traceId,
        timestamp: Date.now(),
      });
    }
  }

  const job = {
    jobId: crypto.randomUUID(),
    inputUrl,
    operations,
    outputUrl: null,
    outputs: [],
    status: "queued",
    createdAt: Date.now(),
    completedAt: null,
    progress: 0,
  };

  jobQueue.push(job);
  return res.status(202).json({ jobId: job.jobId, status: "queued", position: jobQueue.length });
});

app.post("/api/assets/responsive", (req, res) => {
  const { inputUrl, breakpoints, format } = req.body;
  if (!inputUrl) {
    return res.status(400).json({
      code: "HEADY-ASSET-003",
      message: "Missing inputUrl",
      service: "asset-pipeline",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  const bp = breakpoints || FIB_BREAKPOINTS;
  const targetFormat = format || "webp";

  const outputs = bp.map((width) => ({
    width,
    url: `${inputUrl.replace(/\.[^.]+$/, "")}-${width}w.${targetFormat}`,
    srcset: `${inputUrl.replace(/\.[^.]+$/, "")}-${width}w.${targetFormat} ${width}w`,
  }));

  const srcset = outputs.map((o) => o.srcset).join(", ");
  const sizes = bp.map((w, i) => {
    if (i === bp.length - 1) return `${w}px`;
    return `(max-width: ${w}px) ${w}px`;
  }).join(", ");

  return res.status(200).json({
    original: inputUrl,
    format: targetFormat,
    outputs,
    html: {
      srcset,
      sizes,
      picture: `<picture>
  ${outputs.map((o) => `<source srcset="${o.url}" media="(max-width: ${o.width}px)" type="image/${targetFormat}" />`).join("\n  ")}
  <img src="${outputs[outputs.length - 1].url}" alt="" loading="lazy" />
</picture>`,
    },
  });
});

app.get("/api/assets/job/:jobId", (req, res) => {
  const job = completedJobs.get(req.params.jobId)
    || processingJobs.get(req.params.jobId)
    || jobQueue.find((j) => j.jobId === req.params.jobId);

  if (!job) {
    return res.status(404).json({
      code: "HEADY-ASSET-004",
      message: "Job not found",
      service: "asset-pipeline",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }
  return res.status(200).json(job);
});

app.get("/api/assets/breakpoints", (req, res) => {
  return res.status(200).json({
    fibonacci: FIB_BREAKPOINTS,
    description: "Fibonacci-derived responsive breakpoints (px)",
  });
});

function processQueue() {
  if (jobQueue.length === 0) return;
  const job = jobQueue.shift();
  processingJobs.set(job.jobId, job);
  job.status = "processing";

  setTimeout(() => {
    job.status = "completed";
    job.completedAt = Date.now();
    job.progress = 100;
    job.outputUrl = job.inputUrl.replace(/\.[^.]+$/, "-optimized.webp");
    job.outputs = job.operations.map((op) => ({
      operation: op.type,
      outputUrl: job.inputUrl.replace(/\.[^.]+$/, `-${op.type}.webp`),
    }));
    processingJobs.delete(job.jobId);
    completedJobs.set(job.jobId, job);
    if (completedJobs.size > CACHE_SIZES.medium) {
      const oldest = [...completedJobs.entries()].sort((a, b) => a[1].completedAt - b[1].completedAt);
      for (let i = 0; i < oldest.length - CACHE_SIZES.small; i++) {
        completedJobs.delete(oldest[i][0]);
      }
    }
  }, FIB[4] * 100);
}

setInterval(processQueue, FIB[4] * 1000);

app.get("/health", (req, res) => {
  return res.status(200).json({
    service: "asset-pipeline",
    status: "healthy",
    uptime: process.uptime(),
    version: "1.0.0",
    checks: [
      { name: "job-queue", status: jobQueue.length < FIB[8] ? "pass" : "warn", duration: 0, message: `${jobQueue.length} queued, ${processingJobs.size} processing` },
      { name: "completed-jobs", status: "pass", duration: 0, message: `${completedJobs.size} completed` },
    ],
    cslConfidence: PSI,
    lastChecked: Date.now(),
  });
});

app.listen(PORT, () => {
  process.stdout.write(JSON.stringify({
    level: "info",
    service: "asset-pipeline",
    message: `Asset pipeline running on port ${PORT}`,
    timestamp: new Date().toISOString(),
  }) + "\n");
});

module.exports = app;
