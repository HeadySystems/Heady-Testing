"use strict";

/**
 * Heady™ Notification Service
 * Real-time notifications via WebSocket, SSE, and push
 * Port: 3398
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const http = require("http");
const express = require("express");
const crypto = require("crypto");
const { PHI, PSI, PSI2, FIB, RATE_LIMITS, phiBackoff, cslGate } = require("../../shared/constants/phi");

const app = express();
const server = http.createServer(app);
const PORT = 3398;

const wsConnections = new Map();
const sseConnections = new Map();
const notificationStore = new Map();
const WS_REVALIDATE_INTERVAL = FIB[8] * 1000;

app.use(express.json({ limit: "256kb" }));
app.use(headyAutoContext);
app.use(structuredLogger);

function headyAutoContext(req, res, next) {
  req.heady = {
    requestId: crypto.randomUUID(),
    traceId: req.headers["x-trace-id"] || crypto.randomBytes(16).toString("hex"),
    spanId: crypto.randomBytes(8).toString("hex"),
    userId: req.headers["x-user-id"] || null,
    sessionId: req.headers["x-session-id"] || null,
    domain: "monitoring",
    timestamp: Date.now(),
    cslConfidence: PSI,
    phiVersion: "4.0.0",
  };
  res.setHeader("x-request-id", req.heady.requestId);
  res.setHeader("x-trace-id", req.heady.traceId);
  next();
}

function structuredLogger(req, res, next) {
  const start = Date.now();
  res.on("finish", () => {
    process.stdout.write(JSON.stringify({
      level: res.statusCode >= 500 ? "error" : "info",
      service: "notification-service",
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      durationMs: Date.now() - start,
      requestId: req.heady.requestId,
      traceId: req.heady.traceId,
      timestamp: new Date().toISOString(),
    }) + "\n");
  });
  next();
}

function getUserNotifications(userId) {
  if (!notificationStore.has(userId)) {
    notificationStore.set(userId, []);
  }
  return notificationStore.get(userId);
}

app.post("/api/notifications/send", (req, res) => {
  const { userId, type, channel, title, body, metadata } = req.body;

  if (!userId || !title || !body) {
    return res.status(400).json({
      code: "HEADY-NOTIF-001",
      httpStatus: 400,
      message: "Missing required fields: userId, title, body",
      service: "notification-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  const notification = {
    id: crypto.randomUUID(),
    userId,
    type: type || "info",
    channel: channel || "websocket",
    title,
    body,
    metadata: metadata || {},
    read: false,
    createdAt: Date.now(),
  };

  const store = getUserNotifications(userId);
  store.push(notification);
  if (store.length > FIB[12]) {
    store.splice(0, store.length - FIB[11]);
  }

  deliverRealtime(userId, notification);

  return res.status(201).json(notification);
});

app.get("/api/notifications/:userId", (req, res) => {
  const notifications = getUserNotifications(req.params.userId);
  const unreadOnly = req.query.unread === "true";
  const limit = Math.min(parseInt(req.query.limit) || FIB[8], FIB[11]);

  let result = unreadOnly ? notifications.filter((n) => !n.read) : notifications;
  result = result.slice(-limit).reverse();

  return res.status(200).json({ notifications: result, total: result.length });
});

app.patch("/api/notifications/:userId/:notificationId/read", (req, res) => {
  const store = getUserNotifications(req.params.userId);
  const notif = store.find((n) => n.id === req.params.notificationId);
  if (!notif) {
    return res.status(404).json({
      code: "HEADY-NOTIF-002",
      httpStatus: 404,
      message: "Notification not found",
      service: "notification-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }
  notif.read = true;
  return res.status(200).json(notif);
});

app.get("/api/notifications/:userId/stream", (req, res) => {
  const userId = req.params.userId;

  res.writeHead(200, {
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache",
    Connection: "keep-alive",
    "X-Accel-Buffering": "no",
  });

  res.write(`data: ${JSON.stringify({ type: "connected", userId })}\n\n`);

  if (!sseConnections.has(userId)) {
    sseConnections.set(userId, new Set());
  }
  sseConnections.get(userId).add(res);

  const heartbeat = setInterval(() => {
    res.write(`: heartbeat ${Date.now()}\n\n`);
  }, FIB[8] * 1000);

  req.on("close", () => {
    clearInterval(heartbeat);
    const conns = sseConnections.get(userId);
    if (conns) {
      conns.delete(res);
      if (conns.size === 0) sseConnections.delete(userId);
    }
  });
});

function deliverRealtime(userId, notification) {
  const sseConns = sseConnections.get(userId);
  if (sseConns) {
    const data = `data: ${JSON.stringify(notification)}\n\n`;
    for (const conn of sseConns) {
      try {
        conn.write(data);
      } catch (err) {
        sseConns.delete(conn);
      }
    }
  }

  const wsConns = wsConnections.get(userId);
  if (wsConns) {
    const frame = JSON.stringify({ type: "notification", payload: notification });
    for (const ws of wsConns) {
      try {
        sendWsFrame(ws, frame);
      } catch (err) {
        wsConns.delete(ws);
      }
    }
  }
}

server.on("upgrade", (req, socket, head) => {
  if (req.url.startsWith("/ws/notifications/")) {
    const userId = req.url.split("/ws/notifications/")[1]?.split("?")[0];
    if (!userId) {
      socket.destroy();
      return;
    }
    handleWebSocketUpgrade(req, socket, head, userId);
  } else {
    socket.destroy();
  }
});

function handleWebSocketUpgrade(req, socket, head, userId) {
  const key = req.headers["sec-websocket-key"];
  if (!key) {
    socket.destroy();
    return;
  }

  const accept = crypto
    .createHash("sha1")
    .update(key + "258EAFA5-E914-47DA-95CA-5AB5DC85B7E8")
    .digest("base64");

  socket.write([
    "HTTP/1.1 101 Switching Protocols",
    "Upgrade: websocket",
    "Connection: Upgrade",
    `Sec-WebSocket-Accept: ${accept}`,
    "",
    "",
  ].join("\r\n"));

  if (!wsConnections.has(userId)) {
    wsConnections.set(userId, new Set());
  }
  wsConnections.get(userId).add(socket);

  sendWsFrame(socket, JSON.stringify({ type: "connected", userId }));

  const revalidateTimer = setInterval(() => {
    sendWsFrame(socket, JSON.stringify({ type: "ping", timestamp: Date.now() }));
  }, WS_REVALIDATE_INTERVAL);

  socket.on("data", (buf) => {
    try {
      const message = decodeWsFrame(buf);
      if (message) {
        const parsed = JSON.parse(message);
        if (parsed.type === "pong") return;
        if (parsed.type === "mark_read" && parsed.notificationId) {
          const store = getUserNotifications(userId);
          const notif = store.find((n) => n.id === parsed.notificationId);
          if (notif) notif.read = true;
        }
      }
    } catch (e) {
      /* ignore malformed frames */
    }
  });

  socket.on("close", () => {
    clearInterval(revalidateTimer);
    const conns = wsConnections.get(userId);
    if (conns) {
      conns.delete(socket);
      if (conns.size === 0) wsConnections.delete(userId);
    }
  });

  socket.on("error", () => {
    clearInterval(revalidateTimer);
    const conns = wsConnections.get(userId);
    if (conns) conns.delete(socket);
  });
}

function sendWsFrame(socket, data) {
  const payload = Buffer.from(data);
  let frame;
  if (payload.length < 126) {
    frame = Buffer.alloc(2 + payload.length);
    frame[0] = 0x81;
    frame[1] = payload.length;
    payload.copy(frame, 2);
  } else if (payload.length < 65536) {
    frame = Buffer.alloc(4 + payload.length);
    frame[0] = 0x81;
    frame[1] = 126;
    frame.writeUInt16BE(payload.length, 2);
    payload.copy(frame, 4);
  } else {
    frame = Buffer.alloc(10 + payload.length);
    frame[0] = 0x81;
    frame[1] = 127;
    frame.writeBigUInt64BE(BigInt(payload.length), 2);
    payload.copy(frame, 10);
  }
  socket.write(frame);
}

function decodeWsFrame(buf) {
  if (buf.length < 2) return null;
  const masked = (buf[1] & 0x80) !== 0;
  let payloadLen = buf[1] & 0x7f;
  let offset = 2;
  if (payloadLen === 126) {
    payloadLen = buf.readUInt16BE(2);
    offset = 4;
  } else if (payloadLen === 127) {
    payloadLen = Number(buf.readBigUInt64BE(2));
    offset = 10;
  }
  let mask = null;
  if (masked) {
    mask = buf.slice(offset, offset + 4);
    offset += 4;
  }
  const data = buf.slice(offset, offset + payloadLen);
  if (mask) {
    for (let i = 0; i < data.length; i++) {
      data[i] ^= mask[i % 4];
    }
  }
  return data.toString("utf8");
}

app.get("/health", (req, res) => {
  let totalWs = 0;
  for (const conns of wsConnections.values()) totalWs += conns.size;
  let totalSse = 0;
  for (const conns of sseConnections.values()) totalSse += conns.size;

  return res.status(200).json({
    service: "notification-service",
    status: "healthy",
    uptime: process.uptime(),
    version: "1.0.0",
    checks: [
      { name: "websocket-connections", status: "pass", duration: 0, message: `${totalWs} active WS connections` },
      { name: "sse-connections", status: "pass", duration: 0, message: `${totalSse} active SSE connections` },
      { name: "notification-store", status: "pass", duration: 0, message: `${notificationStore.size} users with notifications` },
    ],
    cslConfidence: PSI,
    lastChecked: Date.now(),
  });
});

server.listen(PORT, () => {
  process.stdout.write(JSON.stringify({
    level: "info",
    service: "notification-service",
    message: `Notification service running on port ${PORT}`,
    timestamp: new Date().toISOString(),
  }) + "\n");
});

module.exports = { app, server };
