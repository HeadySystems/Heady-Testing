"use strict";

/**
 * Heady™ Migration Service
 * Database migration runner with rollback support for pgvector
 * Port: 3403
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const express = require("express");
const crypto = require("crypto");
const { PHI, PSI, FIB } = require("../../shared/constants/phi");

const app = express();
const PORT = 3403;

const migrations = new Map();
const migrationHistory = [];

const SEED_MIGRATIONS = [
  {
    version: "001",
    name: "create-extensions",
    sql: `CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";`,
    rollbackSql: `-- Extensions should not be dropped in rollback`,
  },
  {
    version: "002",
    name: "create-embeddings-table",
    sql: `CREATE TABLE IF NOT EXISTS heady_embeddings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  content_hash VARCHAR(64) NOT NULL UNIQUE,
  embedding vector(384) NOT NULL,
  content_type VARCHAR(64) NOT NULL,
  source_id VARCHAR(255),
  source_domain VARCHAR(64),
  metadata JSONB DEFAULT '{}',
  csl_confidence FLOAT DEFAULT 0.618,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_embeddings_hnsw
  ON heady_embeddings USING hnsw (embedding vector_cosine_ops)
  WITH (m = 32, ef_construction = 200);

CREATE INDEX IF NOT EXISTS idx_embeddings_content_type ON heady_embeddings(content_type);
CREATE INDEX IF NOT EXISTS idx_embeddings_source_domain ON heady_embeddings(source_domain);
CREATE INDEX IF NOT EXISTS idx_embeddings_created_at ON heady_embeddings(created_at);`,
    rollbackSql: `DROP TABLE IF EXISTS heady_embeddings CASCADE;`,
  },
  {
    version: "003",
    name: "create-sessions-table",
    sql: `CREATE TABLE IF NOT EXISTS heady_sessions (
  session_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id VARCHAR(255) NOT NULL,
  firebase_uid VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  display_name VARCHAR(255),
  auth_provider VARCHAR(32) NOT NULL,
  client_fingerprint VARCHAR(64) NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON heady_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON heady_sessions(expires_at);`,
    rollbackSql: `DROP TABLE IF EXISTS heady_sessions CASCADE;`,
  },
  {
    version: "004",
    name: "create-analytics-events-table",
    sql: `CREATE TABLE IF NOT EXISTS heady_analytics_events (
  event_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  hashed_user_id VARCHAR(64),
  session_id VARCHAR(255),
  event_type VARCHAR(128) NOT NULL,
  properties JSONB DEFAULT '{}',
  domain VARCHAR(128),
  path VARCHAR(512),
  referrer VARCHAR(512),
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_analytics_event_type ON heady_analytics_events(event_type);
CREATE INDEX IF NOT EXISTS idx_analytics_domain ON heady_analytics_events(domain);
CREATE INDEX IF NOT EXISTS idx_analytics_created_at ON heady_analytics_events(created_at);`,
    rollbackSql: `DROP TABLE IF EXISTS heady_analytics_events CASCADE;`,
  },
  {
    version: "005",
    name: "create-notifications-table",
    sql: `CREATE TABLE IF NOT EXISTS heady_notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id VARCHAR(255) NOT NULL,
  type VARCHAR(32) DEFAULT 'info',
  channel VARCHAR(32) DEFAULT 'websocket',
  title VARCHAR(512) NOT NULL,
  body TEXT NOT NULL,
  metadata JSONB DEFAULT '{}',
  read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON heady_notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON heady_notifications(user_id, read);`,
    rollbackSql: `DROP TABLE IF EXISTS heady_notifications CASCADE;`,
  },
  {
    version: "006",
    name: "create-subscriptions-table",
    sql: `CREATE TABLE IF NOT EXISTS heady_subscriptions (
  subscription_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id VARCHAR(255) NOT NULL,
  plan VARCHAR(32) NOT NULL DEFAULT 'free',
  stripe_customer_id VARCHAR(255),
  stripe_subscription_id VARCHAR(255),
  status VARCHAR(32) NOT NULL DEFAULT 'active',
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  canceled_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id ON heady_subscriptions(user_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status ON heady_subscriptions(status);`,
    rollbackSql: `DROP TABLE IF EXISTS heady_subscriptions CASCADE;`,
  },
  {
    version: "007",
    name: "create-scheduled-jobs-table",
    sql: `CREATE TABLE IF NOT EXISTS heady_scheduled_jobs (
  job_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  cron VARCHAR(64),
  phi_interval_ms BIGINT,
  handler VARCHAR(512) NOT NULL,
  payload JSONB DEFAULT '{}',
  status VARCHAR(32) DEFAULT 'active',
  last_run TIMESTAMPTZ,
  next_run TIMESTAMPTZ NOT NULL,
  retry_count INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_jobs_status ON heady_scheduled_jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_next_run ON heady_scheduled_jobs(next_run);`,
    rollbackSql: `DROP TABLE IF EXISTS heady_scheduled_jobs CASCADE;`,
  },
  {
    version: "008",
    name: "create-migration-tracking-table",
    sql: `CREATE TABLE IF NOT EXISTS heady_migrations (
  id SERIAL PRIMARY KEY,
  version VARCHAR(16) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  checksum VARCHAR(64) NOT NULL,
  applied_at TIMESTAMPTZ DEFAULT NOW()
);`,
    rollbackSql: `DROP TABLE IF EXISTS heady_migrations CASCADE;`,
  },
];

for (const m of SEED_MIGRATIONS) {
  const checksum = crypto.createHash("sha256").update(m.sql).digest("hex").substring(0, 16);
  migrations.set(m.version, { ...m, id: crypto.randomUUID(), checksum, appliedAt: null });
}

app.use(express.json({ limit: "1mb" }));
app.use((req, res, next) => {
  req.heady = {
    requestId: crypto.randomUUID(),
    traceId: req.headers["x-trace-id"] || crypto.randomBytes(16).toString("hex"),
    spanId: crypto.randomBytes(8).toString("hex"),
    domain: "data",
    timestamp: Date.now(),
    cslConfidence: PSI,
    phiVersion: "4.0.0",
  };
  res.setHeader("x-request-id", req.heady.requestId);
  res.setHeader("x-trace-id", req.heady.traceId);
  next();
});

app.get("/api/migrations", (req, res) => {
  const all = [...migrations.values()].sort((a, b) => a.version.localeCompare(b.version));
  return res.status(200).json({ migrations: all, total: all.length });
});

app.get("/api/migrations/pending", (req, res) => {
  const pending = [...migrations.values()]
    .filter((m) => !m.appliedAt)
    .sort((a, b) => a.version.localeCompare(b.version));
  return res.status(200).json({ pending, total: pending.length });
});

app.post("/api/migrations/run", (req, res) => {
  const { target } = req.body;
  const pending = [...migrations.values()]
    .filter((m) => !m.appliedAt)
    .sort((a, b) => a.version.localeCompare(b.version));

  if (target) {
    const idx = pending.findIndex((m) => m.version === target);
    if (idx === -1) return res.status(404).json({ code: "HEADY-MIGRATE-001", message: "Target version not found or already applied" });
    pending.splice(idx + 1);
  }

  const applied = [];
  for (const m of pending) {
    /**
     * Production: Execute SQL against pgvector database
     * await pool.query(m.sql);
     * await pool.query('INSERT INTO heady_migrations (version, name, checksum) VALUES ($1, $2, $3)', [m.version, m.name, m.checksum]);
     */
    m.appliedAt = Date.now();
    applied.push({ version: m.version, name: m.name });
    migrationHistory.push({ action: "apply", version: m.version, timestamp: Date.now() });
  }

  return res.status(200).json({ applied, total: applied.length });
});

app.post("/api/migrations/rollback", (req, res) => {
  const { target } = req.body;
  const applied = [...migrations.values()]
    .filter((m) => m.appliedAt)
    .sort((a, b) => b.version.localeCompare(a.version));

  if (applied.length === 0) {
    return res.status(400).json({ code: "HEADY-MIGRATE-002", message: "No migrations to roll back" });
  }

  const toRollback = target
    ? applied.filter((m) => m.version >= target)
    : [applied[0]];

  const rolledBack = [];
  for (const m of toRollback) {
    m.appliedAt = null;
    rolledBack.push({ version: m.version, name: m.name });
    migrationHistory.push({ action: "rollback", version: m.version, timestamp: Date.now() });
  }

  return res.status(200).json({ rolledBack, total: rolledBack.length });
});

app.post("/api/migrations/add", (req, res) => {
  const { version, name, sql, rollbackSql } = req.body;
  if (!version || !name || !sql || !rollbackSql) {
    return res.status(400).json({ code: "HEADY-MIGRATE-003", message: "Missing fields: version, name, sql, rollbackSql" });
  }
  if (migrations.has(version)) {
    return res.status(409).json({ code: "HEADY-MIGRATE-004", message: "Version already exists" });
  }

  const checksum = crypto.createHash("sha256").update(sql).digest("hex").substring(0, 16);
  migrations.set(version, { id: crypto.randomUUID(), version, name, sql, rollbackSql, checksum, appliedAt: null });
  return res.status(201).json({ version, name, checksum });
});

app.get("/api/migrations/history", (req, res) => {
  return res.status(200).json({ history: migrationHistory.slice(-FIB[8]) });
});

app.get("/health", (req, res) => {
  const applied = [...migrations.values()].filter((m) => m.appliedAt).length;
  return res.status(200).json({
    service: "migration-service",
    status: "healthy",
    uptime: process.uptime(),
    version: "1.0.0",
    checks: [
      { name: "migration-store", status: "pass", duration: 0, message: `${migrations.size} migrations, ${applied} applied` },
    ],
    cslConfidence: PSI,
    lastChecked: Date.now(),
  });
});

app.listen(PORT, () => {
  process.stdout.write(JSON.stringify({
    level: "info",
    service: "migration-service",
    message: `Migration service running on port ${PORT}`,
    timestamp: new Date().toISOString(),
  }) + "\n");
});

module.exports = app;
