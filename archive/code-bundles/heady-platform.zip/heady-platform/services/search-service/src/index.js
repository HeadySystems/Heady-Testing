"use strict";

/**
 * Heady™ Search Service
 * Full-text + vector hybrid search across all content
 * Port: 3401
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const express = require("express");
const crypto = require("crypto");
const { PHI, PSI, PSI2, FIB, HNSW, CACHE_SIZES, phiBackoff, cslGate } = require("../../shared/constants/phi");

const app = express();
const PORT = 3401;

const searchIndex = new Map();
const queryCache = new Map();
const CACHE_TTL = FIB[8] * 1000;

app.use(express.json({ limit: "1mb" }));
app.use(headyAutoContext);

function headyAutoContext(req, res, next) {
  req.heady = {
    requestId: crypto.randomUUID(),
    traceId: req.headers["x-trace-id"] || crypto.randomBytes(16).toString("hex"),
    spanId: crypto.randomBytes(8).toString("hex"),
    domain: "data",
    timestamp: Date.now(),
    cslConfidence: PSI,
    phiVersion: "4.0.0",
  };
  res.setHeader("x-request-id", req.heady.requestId);
  res.setHeader("x-trace-id", req.heady.traceId);
  next();
}

function tokenize(text) {
  return text
    .toLowerCase()
    .replace(/[^\w\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 1);
}

function cosineSimilarity(a, b) {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  const denom = Math.sqrt(magA) * Math.sqrt(magB);
  return denom === 0 ? 0 : dot / denom;
}

function bm25Score(query, docTokens, avgDocLen) {
  const k1 = PHI;
  const b = PSI;
  const queryTokens = tokenize(query);
  let score = 0;

  for (const qt of queryTokens) {
    const tf = docTokens.filter((t) => t === qt).length;
    if (tf === 0) continue;
    const idf = Math.log(1 + (searchIndex.size - docTokens.length + 0.5) / (docTokens.length + 0.5));
    const tfNorm = (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * (docTokens.length / avgDocLen)));
    score += idf * tfNorm;
  }

  return score;
}

app.post("/api/search/index", (req, res) => {
  const { id, contentType, title, body, url, metadata, vector } = req.body;
  if (!id || !title) {
    return res.status(400).json({
      code: "HEADY-SEARCH-001",
      httpStatus: 400,
      message: "Missing required fields: id, title",
      service: "search-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  const tokens = tokenize(`${title} ${body || ""}`);
  searchIndex.set(id, {
    id,
    contentType: contentType || "unknown",
    title,
    body: body || "",
    url: url || "",
    metadata: metadata || {},
    tokens,
    vector: vector || null,
    indexedAt: Date.now(),
  });

  queryCache.clear();

  return res.status(201).json({ id, indexed: true, tokenCount: tokens.length });
});

app.post("/api/search/query", (req, res) => {
  const { q, mode, limit, contentType, minScore } = req.body;
  if (!q) {
    return res.status(400).json({
      code: "HEADY-SEARCH-002",
      httpStatus: 400,
      message: "Missing query parameter 'q'",
      service: "search-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  const cacheKey = JSON.stringify({ q, mode, limit, contentType, minScore });
  const cached = queryCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return res.status(200).json({ results: cached.results, cached: true });
  }

  const searchMode = mode || "hybrid";
  const maxResults = Math.min(limit || FIB[5], FIB[8]);
  const threshold = minScore || PSI2 * 0.1;
  const queryVector = req.body.queryVector || null;

  let results = [];
  const docs = [...searchIndex.values()];
  const avgDocLen = docs.reduce((sum, d) => sum + d.tokens.length, 0) / (docs.length || 1);

  for (const doc of docs) {
    if (contentType && doc.contentType !== contentType) continue;

    let score = 0;

    if (searchMode === "fulltext" || searchMode === "hybrid") {
      score += bm25Score(q, doc.tokens, avgDocLen);
    }

    if ((searchMode === "vector" || searchMode === "hybrid") && queryVector && doc.vector) {
      const vecScore = cosineSimilarity(queryVector, doc.vector);
      score += vecScore * PHI;
    }

    if (score > threshold) {
      results.push({
        id: doc.id,
        score: Math.round(score * 10000) / 10000,
        source: searchMode,
        contentType: doc.contentType,
        title: doc.title,
        snippet: doc.body.substring(0, FIB[12]),
        url: doc.url,
        metadata: doc.metadata,
      });
    }
  }

  results.sort((a, b) => b.score - a.score);
  results = results.slice(0, maxResults);

  queryCache.set(cacheKey, { results, timestamp: Date.now() });
  if (queryCache.size > CACHE_SIZES.medium) {
    const oldest = [...queryCache.entries()].sort((a, b) => a[1].timestamp - b[1].timestamp);
    for (let i = 0; i < oldest.length - CACHE_SIZES.small; i++) {
      queryCache.delete(oldest[i][0]);
    }
  }

  return res.status(200).json({
    results,
    total: results.length,
    query: q,
    mode: searchMode,
    cached: false,
  });
});

app.delete("/api/search/index/:id", (req, res) => {
  const deleted = searchIndex.delete(req.params.id);
  queryCache.clear();
  return res.status(200).json({ id: req.params.id, deleted });
});

app.get("/api/search/stats", (req, res) => {
  const contentTypes = {};
  for (const doc of searchIndex.values()) {
    contentTypes[doc.contentType] = (contentTypes[doc.contentType] || 0) + 1;
  }
  return res.status(200).json({
    totalDocuments: searchIndex.size,
    contentTypes,
    cacheSize: queryCache.size,
    cacheSizeLimit: CACHE_SIZES.medium,
  });
});

app.get("/health", (req, res) => {
  return res.status(200).json({
    service: "search-service",
    status: "healthy",
    uptime: process.uptime(),
    version: "1.0.0",
    checks: [
      { name: "search-index", status: "pass", duration: 0, message: `${searchIndex.size} documents indexed` },
      { name: "query-cache", status: "pass", duration: 0, message: `${queryCache.size} cached queries` },
    ],
    cslConfidence: PSI,
    lastChecked: Date.now(),
  });
});

app.listen(PORT, () => {
  process.stdout.write(JSON.stringify({
    level: "info",
    service: "search-service",
    message: `Search service running on port ${PORT}`,
    timestamp: new Date().toISOString(),
  }) + "\n");
});

module.exports = app;
