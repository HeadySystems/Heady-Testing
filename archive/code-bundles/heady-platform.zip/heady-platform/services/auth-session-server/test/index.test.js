const { describe, it, before, after } = require("node:test");
const assert = require("node:assert");
const http = require("node:http");
const crypto = require("node:crypto");

const BASE_URL = "http://localhost:3397";

function makeRequest(method, path, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const url = new URL(path, BASE_URL);
    const opts = {
      method,
      hostname: url.hostname,
      port: url.port,
      path: url.pathname + url.search,
      headers: { "Content-Type": "application/json", ...headers },
    };
    const req = http.request(opts, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        resolve({
          status: res.statusCode,
          headers: res.headers,
          body: data ? JSON.parse(data) : null,
        });
      });
    });
    req.on("error", reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

function createMockJwt(payload = {}) {
  const header = Buffer.from(JSON.stringify({ alg: "RS256", typ: "JWT" })).toString("base64url");
  const body = Buffer.from(JSON.stringify({
    sub: payload.uid || "test-uid-" + crypto.randomUUID(),
    email: payload.email || "test@headysystems.com",
    name: payload.name || "Test User",
    iss: "https://securetoken.google.com/gen-lang-client-0920560496",
    exp: Math.floor(Date.now() / 1000) + 3600,
    firebase: { sign_in_provider: payload.provider || "google.com" },
  })).toString("base64url");
  const sig = Buffer.from("mock-signature").toString("base64url");
  return `${header}.${body}.${sig}`;
}

describe("Auth Session Server", () => {
  describe("POST /api/session/create", () => {
    it("returns 400 when idToken is missing", async () => {
      const res = await makeRequest("POST", "/api/session/create", {});
      assert.strictEqual(res.status, 400);
      assert.strictEqual(res.body.code, "HEADY-AUTH-002");
    });

    it("creates a session with valid token", async () => {
      const token = createMockJwt({ email: "eric@headysystems.com", name: "Eric Haywood" });
      const res = await makeRequest("POST", "/api/session/create", { idToken: token });
      assert.strictEqual(res.status, 201);
      assert.ok(res.body.sessionId);
      assert.ok(res.body.userId);
      assert.strictEqual(res.body.email, "eric@headysystems.com");
      assert.ok(res.headers["set-cookie"]);
    });

    it("rejects expired tokens", async () => {
      const header = Buffer.from(JSON.stringify({ alg: "RS256" })).toString("base64url");
      const body = Buffer.from(JSON.stringify({
        sub: "test",
        iss: "test",
        exp: Math.floor(Date.now() / 1000) - 3600,
      })).toString("base64url");
      const sig = Buffer.from("sig").toString("base64url");
      const token = `${header}.${body}.${sig}`;
      const res = await makeRequest("POST", "/api/session/create", { idToken: token });
      assert.strictEqual(res.status, 401);
      assert.strictEqual(res.body.code, "HEADY-AUTH-003");
    });
  });

  describe("GET /api/session/verify", () => {
    it("returns 401 when no cookie present", async () => {
      const res = await makeRequest("GET", "/api/session/verify");
      assert.strictEqual(res.status, 401);
      assert.strictEqual(res.body.code, "HEADY-AUTH-004");
    });
  });

  describe("GET /health", () => {
    it("returns healthy status", async () => {
      const res = await makeRequest("GET", "/health");
      assert.strictEqual(res.status, 200);
      assert.strictEqual(res.body.service, "auth-session-server");
      assert.strictEqual(res.body.status, "healthy");
      assert.ok(res.body.checks.length > 0);
      assert.ok(res.body.cslConfidence > 0);
    });
  });

  describe("Headers", () => {
    it("includes security headers", async () => {
      const res = await makeRequest("GET", "/health");
      assert.ok(res.headers["content-security-policy"]);
      assert.ok(res.headers["x-content-type-options"]);
      assert.ok(res.headers["strict-transport-security"]);
      assert.ok(res.headers["x-request-id"]);
      assert.ok(res.headers["x-trace-id"]);
    });
  });
});
