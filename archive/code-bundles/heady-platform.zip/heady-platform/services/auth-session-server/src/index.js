"use strict";

/**
 * Heady™ Auth Session Server
 * Central authentication at auth.headysystems.com
 * Firebase ID token validation → httpOnly session cookies
 * Cross-domain relay via postMessage + iframe
 *
 * Port: 3397
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const express = require("express");
const cookieParser = require("cookie-parser");
const crypto = require("crypto");
const { PHI, PSI, PSI2, FIB, TIMEOUTS, phiBackoff, cslGate } = require("../../shared/constants/phi");

const app = express();
const PORT = 3397;
const SESSION_COOKIE = "__heady_session";
const SESSION_EXPIRY_MS = FIB[13] * 60 * 1000;
const ALLOWED_ORIGINS = [
  "https://headyme.com",
  "https://headysystems.com",
  "https://heady-ai.com",
  "https://headyos.com",
  "https://headyconnection.org",
  "https://headyconnection.com",
  "https://headyex.com",
  "https://headyfinance.com",
  "https://admin.headysystems.com",
];

const sessions = new Map();
const rateLimitMap = new Map();

app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use(headyAutoContext);
app.use(corsMiddleware);
app.use(cspHeaders);
app.use(rateLimiter);
app.use(structuredLogger);

function headyAutoContext(req, res, next) {
  req.heady = {
    requestId: crypto.randomUUID(),
    traceId: req.headers["x-trace-id"] || crypto.randomBytes(16).toString("hex"),
    spanId: crypto.randomBytes(8).toString("hex"),
    userId: null,
    sessionId: null,
    domain: "security",
    timestamp: Date.now(),
    cslConfidence: PSI,
    phiVersion: "4.0.0",
  };
  res.setHeader("x-request-id", req.heady.requestId);
  res.setHeader("x-trace-id", req.heady.traceId);
  next();
}

function corsMiddleware(req, res, next) {
  const origin = req.headers.origin;
  if (ALLOWED_ORIGINS.includes(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Access-Control-Allow-Credentials", "true");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, x-trace-id");
    res.setHeader("Access-Control-Max-Age", String(FIB[10]));
  }
  if (req.method === "OPTIONS") return res.sendStatus(204);
  next();
}

function cspHeaders(req, res, next) {
  res.setHeader("Content-Security-Policy", [
    "default-src 'self'",
    `frame-ancestors ${ALLOWED_ORIGINS.join(" ")}`,
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: https:",
    "connect-src 'self' https://identitytoolkit.googleapis.com https://securetoken.googleapis.com",
    "object-src 'none'",
    "base-uri 'self'",
  ].join("; "));
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "SAMEORIGIN");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Strict-Transport-Security", "max-age=63072000; includeSubDomains; preload");
  next();
}

function rateLimiter(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const window = FIB[9] * 1000;
  const limit = req.heady.userId ? FIB[10] : FIB[8];

  if (!rateLimitMap.has(ip)) {
    rateLimitMap.set(ip, { count: 0, windowStart: now });
  }
  const entry = rateLimitMap.get(ip);
  if (now - entry.windowStart > window) {
    entry.count = 0;
    entry.windowStart = now;
  }
  entry.count++;
  res.setHeader("X-RateLimit-Limit", String(limit));
  res.setHeader("X-RateLimit-Remaining", String(Math.max(0, limit - entry.count)));

  if (entry.count > limit) {
    return res.status(429).json({
      code: "HEADY-AUTH-001",
      httpStatus: 429,
      message: "Rate limit exceeded. Retry after backoff.",
      service: "auth-session-server",
      traceId: req.heady.traceId,
      timestamp: now,
      retryAfterMs: phiBackoff(entry.count - limit),
    });
  }
  next();
}

function structuredLogger(req, res, next) {
  const start = Date.now();
  res.on("finish", () => {
    const log = {
      level: res.statusCode >= 500 ? "error" : res.statusCode >= 400 ? "warn" : "info",
      service: "auth-session-server",
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      durationMs: Date.now() - start,
      requestId: req.heady.requestId,
      traceId: req.heady.traceId,
      userId: req.heady.userId,
      ip: req.ip,
      timestamp: new Date().toISOString(),
    };
    process.stdout.write(JSON.stringify(log) + "\n");
  });
  next();
}

function generateFingerprint(req) {
  const raw = [req.ip, req.headers["user-agent"] || "unknown"].join("|");
  return crypto.createHash("sha256").update(raw).digest("hex").substring(0, 16);
}

async function verifyFirebaseToken(idToken) {
  /**
   * Production: Use firebase-admin SDK to verify the token.
   * const admin = require("firebase-admin");
   * return admin.auth().verifyIdToken(idToken);
   *
   * For now, decode JWT payload for structure validation.
   * Replace with real Firebase Admin verification before production deploy.
   */
  if (!idToken || typeof idToken !== "string") {
    throw new Error("Invalid token format");
  }
  const parts = idToken.split(".");
  if (parts.length !== 3) {
    throw new Error("Malformed JWT");
  }
  const payload = JSON.parse(Buffer.from(parts[1], "base64url").toString());
  if (!payload.sub || !payload.iss) {
    throw new Error("Missing required JWT claims");
  }
  if (payload.exp && payload.exp * 1000 < Date.now()) {
    throw new Error("Token expired");
  }
  return {
    uid: payload.sub,
    email: payload.email || null,
    name: payload.name || null,
    provider: payload.firebase?.sign_in_provider || "unknown",
  };
}

app.post("/api/session/create", async (req, res) => {
  const { idToken } = req.body;
  if (!idToken) {
    return res.status(400).json({
      code: "HEADY-AUTH-002",
      httpStatus: 400,
      message: "Missing idToken in request body",
      service: "auth-session-server",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  try {
    const decoded = await verifyFirebaseToken(idToken);
    const sessionId = crypto.randomUUID();
    const fingerprint = generateFingerprint(req);

    const session = {
      sessionId,
      userId: decoded.uid,
      firebaseUid: decoded.uid,
      email: decoded.email,
      displayName: decoded.name,
      authProvider: decoded.provider,
      createdAt: Date.now(),
      expiresAt: Date.now() + SESSION_EXPIRY_MS,
      clientFingerprint: fingerprint,
      domains: ALLOWED_ORIGINS,
    };

    sessions.set(sessionId, session);
    req.heady.userId = decoded.uid;
    req.heady.sessionId = sessionId;

    res.cookie(SESSION_COOKIE, sessionId, {
      httpOnly: true,
      secure: true,
      sameSite: "none",
      domain: ".headysystems.com",
      path: "/",
      maxAge: SESSION_EXPIRY_MS,
      prefix: "__Host-",
    });

    return res.status(201).json({
      sessionId,
      userId: decoded.uid,
      email: decoded.email,
      displayName: decoded.name,
      expiresAt: session.expiresAt,
    });
  } catch (err) {
    return res.status(401).json({
      code: "HEADY-AUTH-003",
      httpStatus: 401,
      message: `Token verification failed: ${err.message}`,
      service: "auth-session-server",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }
});

app.get("/api/session/verify", (req, res) => {
  const sessionId = req.cookies[SESSION_COOKIE];
  if (!sessionId) {
    return res.status(401).json({
      code: "HEADY-AUTH-004",
      httpStatus: 401,
      message: "No session cookie present",
      service: "auth-session-server",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  const session = sessions.get(sessionId);
  if (!session) {
    return res.status(401).json({
      code: "HEADY-AUTH-005",
      httpStatus: 401,
      message: "Session not found or expired",
      service: "auth-session-server",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  if (Date.now() > session.expiresAt) {
    sessions.delete(sessionId);
    res.clearCookie(SESSION_COOKIE);
    return res.status(401).json({
      code: "HEADY-AUTH-006",
      httpStatus: 401,
      message: "Session expired",
      service: "auth-session-server",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  const fingerprint = generateFingerprint(req);
  if (fingerprint !== session.clientFingerprint) {
    sessions.delete(sessionId);
    res.clearCookie(SESSION_COOKIE);
    return res.status(401).json({
      code: "HEADY-AUTH-007",
      httpStatus: 401,
      message: "Client fingerprint mismatch — possible session replay attack",
      service: "auth-session-server",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  req.heady.userId = session.userId;
  req.heady.sessionId = sessionId;

  return res.status(200).json({
    userId: session.userId,
    email: session.email,
    displayName: session.displayName,
    authProvider: session.authProvider,
    expiresAt: session.expiresAt,
  });
});

app.delete("/api/session/destroy", (req, res) => {
  const sessionId = req.cookies[SESSION_COOKIE];
  if (sessionId) {
    sessions.delete(sessionId);
  }
  res.clearCookie(SESSION_COOKIE, {
    httpOnly: true,
    secure: true,
    sameSite: "none",
    domain: ".headysystems.com",
    path: "/",
  });
  return res.status(200).json({ message: "Session destroyed" });
});

app.get("/api/relay/iframe", (req, res) => {
  const origin = req.query.origin;
  if (!ALLOWED_ORIGINS.includes(origin)) {
    return res.status(403).send("Origin not allowed");
  }

  const html = `<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><title>Heady Auth Relay</title></head>
<body>
<script>
(function() {
  "use strict";
  var ALLOWED = ${JSON.stringify(ALLOWED_ORIGINS)};
  window.addEventListener("message", function(event) {
    if (ALLOWED.indexOf(event.origin) === -1) return;
    if (!event.data || event.data.type !== "HEADY_AUTH_REQUEST") return;
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "/api/session/verify", true);
    xhr.withCredentials = true;
    xhr.setRequestHeader("x-trace-id", event.data.traceId || "");
    xhr.onload = function() {
      var response = { type: "HEADY_AUTH_RESPONSE", status: xhr.status };
      try { response.data = JSON.parse(xhr.responseText); } catch(e) { response.data = null; }
      event.source.postMessage(response, event.origin);
    };
    xhr.onerror = function() {
      event.source.postMessage({ type: "HEADY_AUTH_RESPONSE", status: 0, data: null }, event.origin);
    };
    xhr.send();
  });
})();
</script>
</body>
</html>`;
  res.setHeader("Content-Type", "text/html");
  return res.send(html);
});

app.get("/health", (req, res) => {
  const health = {
    service: "auth-session-server",
    status: "healthy",
    uptime: process.uptime(),
    version: "1.0.0",
    checks: [
      {
        name: "session-store",
        status: "pass",
        duration: 0,
        message: `${sessions.size} active sessions`,
      },
      {
        name: "memory",
        status: process.memoryUsage().heapUsed < FIB[12] * 1024 * 1024 ? "pass" : "warn",
        duration: 0,
        message: `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB heap`,
      },
    ],
    cslConfidence: PSI,
    lastChecked: Date.now(),
  };
  return res.status(200).json(health);
});

setInterval(() => {
  const now = Date.now();
  for (const [id, session] of sessions) {
    if (now > session.expiresAt) sessions.delete(id);
  }
  for (const [ip, entry] of rateLimitMap) {
    if (now - entry.windowStart > FIB[9] * 1000 * 2) rateLimitMap.delete(ip);
  }
}, FIB[8] * 1000);

app.listen(PORT, () => {
  process.stdout.write(JSON.stringify({
    level: "info",
    service: "auth-session-server",
    message: `Auth session server running on port ${PORT}`,
    timestamp: new Date().toISOString(),
  }) + "\n");
});

module.exports = app;
