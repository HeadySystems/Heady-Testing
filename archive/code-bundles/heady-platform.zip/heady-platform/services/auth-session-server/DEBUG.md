# DEBUG.md — auth-session-server

## Common Failure Modes

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| 401 on all requests | Session store cleared (restart) | Check uptime; sessions are in-memory |
| 429 rate limit | Burst from single IP | Check `X-RateLimit-Remaining` header |
| CORS errors in browser | Origin not in allowlist | Add origin to `ALLOWED_ORIGINS` |
| Fingerprint mismatch (AUTH-007) | User changed network/VPN | Normal — user re-authenticates |
| Relay iframe blank | CSP blocking | Check `frame-ancestors` directive |

## Log Locations

All logs go to stdout as structured JSON. In production:
- Cloud Run: `gcloud logging read "resource.type=cloud_run_revision AND resource.labels.service_name=auth-session-server"`
- Local: `docker logs heady-auth-session-server 2>&1 | jq .`

## Attach Debugger

```bash
node --inspect=0.0.0.0:9229 src/index.js
# Then in Chrome: chrome://inspect
```

## Local Test

```bash
npm test
curl http://localhost:3397/health | jq .
```

## Health Check URL

- `GET /health` — returns service health with session count and memory usage

## Known Issues

1. Sessions are in-memory only; a restart clears all sessions. Production should use Redis or Firestore.
2. Firebase token verification is mocked — must integrate `firebase-admin` SDK before production.
3. `__Host-` cookie prefix requires exact domain match; test with real HTTPS domains.
