"use strict";

/**
 * Heady™ Scheduler Service
 * Cron-equivalent with φ-scaled intervals for batch jobs
 * Port: 3402
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const express = require("express");
const crypto = require("crypto");
const { PHI, PSI, FIB, RETRY, phiBackoff } = require("../../shared/constants/phi");

const app = express();
const PORT = 3402;

const jobs = new Map();
const jobHistory = new Map();
const TICK_INTERVAL = FIB[5] * 1000;

app.use(express.json({ limit: "256kb" }));
app.use(headyAutoContext);

function headyAutoContext(req, res, next) {
  req.heady = {
    requestId: crypto.randomUUID(),
    traceId: req.headers["x-trace-id"] || crypto.randomBytes(16).toString("hex"),
    spanId: crypto.randomBytes(8).toString("hex"),
    domain: "orchestration",
    timestamp: Date.now(),
    cslConfidence: PSI,
    phiVersion: "4.0.0",
  };
  res.setHeader("x-request-id", req.heady.requestId);
  res.setHeader("x-trace-id", req.heady.traceId);
  next();
}

function parseCron(cron) {
  const parts = cron.split(/\s+/);
  if (parts.length !== 5) return null;
  return { minute: parts[0], hour: parts[1], dayOfMonth: parts[2], month: parts[3], dayOfWeek: parts[4] };
}

function cronMatches(cron, date) {
  const parsed = parseCron(cron);
  if (!parsed) return false;
  const checks = [
    [parsed.minute, date.getUTCMinutes()],
    [parsed.hour, date.getUTCHours()],
    [parsed.dayOfMonth, date.getUTCDate()],
    [parsed.month, date.getUTCMonth() + 1],
    [parsed.dayOfWeek, date.getUTCDay()],
  ];
  return checks.every(([pattern, value]) => {
    if (pattern === "*") return true;
    if (pattern.includes("/")) {
      const step = parseInt(pattern.split("/")[1]);
      return value % step === 0;
    }
    if (pattern.includes(",")) {
      return pattern.split(",").map(Number).includes(value);
    }
    if (pattern.includes("-")) {
      const [min, max] = pattern.split("-").map(Number);
      return value >= min && value <= max;
    }
    return parseInt(pattern) === value;
  });
}

function phiIntervalMs(baseMs) {
  return Math.round(baseMs * PHI);
}

app.post("/api/scheduler/jobs", (req, res) => {
  const { name, cron, phiInterval, handler, payload } = req.body;
  if (!name || !handler) {
    return res.status(400).json({
      code: "HEADY-SCHED-001",
      httpStatus: 400,
      message: "Missing required fields: name, handler",
      service: "scheduler-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }
  if (!cron && !phiInterval) {
    return res.status(400).json({
      code: "HEADY-SCHED-002",
      httpStatus: 400,
      message: "Must provide either cron expression or phiInterval (ms)",
      service: "scheduler-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  const now = Date.now();
  const job = {
    jobId: crypto.randomUUID(),
    name,
    cron: cron || null,
    phiInterval: phiInterval || null,
    handler,
    payload: payload || {},
    status: "active",
    lastRun: null,
    nextRun: phiInterval ? now + phiInterval : now + 60000,
    retryCount: 0,
    createdAt: now,
  };

  jobs.set(job.jobId, job);
  return res.status(201).json(job);
});

app.get("/api/scheduler/jobs", (req, res) => {
  const status = req.query.status;
  let result = [...jobs.values()];
  if (status) result = result.filter((j) => j.status === status);
  return res.status(200).json({ jobs: result, total: result.length });
});

app.get("/api/scheduler/jobs/:jobId", (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) {
    return res.status(404).json({
      code: "HEADY-SCHED-003",
      httpStatus: 404,
      message: "Job not found",
      service: "scheduler-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }
  const history = jobHistory.get(req.params.jobId) || [];
  return res.status(200).json({ ...job, history: history.slice(-FIB[5]) });
});

app.patch("/api/scheduler/jobs/:jobId/pause", (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ code: "HEADY-SCHED-003", message: "Not found" });
  job.status = "paused";
  return res.status(200).json(job);
});

app.patch("/api/scheduler/jobs/:jobId/resume", (req, res) => {
  const job = jobs.get(req.params.jobId);
  if (!job) return res.status(404).json({ code: "HEADY-SCHED-003", message: "Not found" });
  job.status = "active";
  job.nextRun = Date.now() + (job.phiInterval || 60000);
  return res.status(200).json(job);
});

app.delete("/api/scheduler/jobs/:jobId", (req, res) => {
  const deleted = jobs.delete(req.params.jobId);
  jobHistory.delete(req.params.jobId);
  return res.status(200).json({ jobId: req.params.jobId, deleted });
});

function executeJob(job) {
  const now = Date.now();
  const execution = {
    executionId: crypto.randomUUID(),
    jobId: job.jobId,
    startedAt: now,
    completedAt: null,
    status: "running",
    result: null,
  };

  /**
   * Production: Call the handler URL via HTTP POST with the job payload.
   * const response = await fetch(job.handler, { method: 'POST', body: JSON.stringify(job.payload) });
   */

  execution.completedAt = Date.now();
  execution.status = "completed";
  execution.durationMs = execution.completedAt - execution.startedAt;

  job.lastRun = now;
  job.retryCount = 0;

  if (job.phiInterval) {
    job.nextRun = now + job.phiInterval;
  } else if (job.cron) {
    job.nextRun = now + 60000;
  }

  if (!jobHistory.has(job.jobId)) jobHistory.set(job.jobId, []);
  const hist = jobHistory.get(job.jobId);
  hist.push(execution);
  if (hist.length > FIB[8]) hist.splice(0, hist.length - FIB[7]);

  process.stdout.write(JSON.stringify({
    level: "info",
    service: "scheduler-service",
    message: `Executed job: ${job.name}`,
    jobId: job.jobId,
    durationMs: execution.durationMs,
    timestamp: new Date().toISOString(),
  }) + "\n");
}

const schedulerLoop = setInterval(() => {
  const now = Date.now();
  const currentDate = new Date(now);

  for (const job of jobs.values()) {
    if (job.status !== "active") continue;

    let shouldRun = false;

    if (job.phiInterval && now >= job.nextRun) {
      shouldRun = true;
    } else if (job.cron && cronMatches(job.cron, currentDate)) {
      if (!job.lastRun || now - job.lastRun > 55000) {
        shouldRun = true;
      }
    }

    if (shouldRun) {
      try {
        executeJob(job);
      } catch (err) {
        job.retryCount++;
        if (job.retryCount >= RETRY.maxAttempts) {
          job.status = "failed";
        } else {
          job.nextRun = now + phiBackoff(job.retryCount);
        }
        process.stdout.write(JSON.stringify({
          level: "error",
          service: "scheduler-service",
          message: `Job failed: ${job.name}`,
          jobId: job.jobId,
          retryCount: job.retryCount,
          error: err.message,
          timestamp: new Date().toISOString(),
        }) + "\n");
      }
    }
  }
}, TICK_INTERVAL);

app.get("/health", (req, res) => {
  const active = [...jobs.values()].filter((j) => j.status === "active").length;
  return res.status(200).json({
    service: "scheduler-service",
    status: "healthy",
    uptime: process.uptime(),
    version: "1.0.0",
    checks: [
      { name: "job-store", status: "pass", duration: 0, message: `${jobs.size} total jobs, ${active} active` },
      { name: "scheduler-loop", status: "pass", duration: 0, message: `Tick interval: ${TICK_INTERVAL}ms` },
    ],
    cslConfidence: PSI,
    lastChecked: Date.now(),
  });
});

app.listen(PORT, () => {
  process.stdout.write(JSON.stringify({
    level: "info",
    service: "scheduler-service",
    message: `Scheduler service running on port ${PORT}`,
    timestamp: new Date().toISOString(),
  }) + "\n");
});

module.exports = app;
