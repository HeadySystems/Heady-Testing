"use strict";

/**
 * Heady™ Analytics Service
 * Self-hosted, privacy-first usage analytics
 * Funnel tracking, conversion metrics, session replay metadata
 * Port: 3399
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const express = require("express");
const crypto = require("crypto");
const { PHI, PSI, PSI2, FIB, CACHE_SIZES, phiBackoff } = require("../../shared/constants/phi");

const app = express();
const PORT = 3399;

const eventBuffer = [];
const funnelStore = new Map();
const sessionStore = new Map();
const metricsAgg = {
  totalEvents: 0,
  eventsByType: {},
  eventsByDomain: {},
  hourlyBuckets: new Map(),
  conversionFunnels: new Map(),
};

const BUFFER_FLUSH_SIZE = FIB[9];
const BUFFER_FLUSH_INTERVAL = FIB[8] * 1000;
const MAX_BATCH_SIZE = FIB[8];

app.use(express.json({ limit: "1mb" }));
app.use(headyAutoContext);
app.use(structuredLogger);

function headyAutoContext(req, res, next) {
  req.heady = {
    requestId: crypto.randomUUID(),
    traceId: req.headers["x-trace-id"] || crypto.randomBytes(16).toString("hex"),
    spanId: crypto.randomBytes(8).toString("hex"),
    userId: req.headers["x-user-id"] || null,
    sessionId: req.headers["x-session-id"] || null,
    domain: "monitoring",
    timestamp: Date.now(),
    cslConfidence: PSI,
    phiVersion: "4.0.0",
  };
  res.setHeader("x-request-id", req.heady.requestId);
  res.setHeader("x-trace-id", req.heady.traceId);
  next();
}

function structuredLogger(req, res, next) {
  const start = Date.now();
  res.on("finish", () => {
    if (req.path === "/health") return;
    process.stdout.write(JSON.stringify({
      level: "info",
      service: "analytics-service",
      method: req.method,
      path: req.path,
      statusCode: res.statusCode,
      durationMs: Date.now() - start,
      requestId: req.heady.requestId,
      traceId: req.heady.traceId,
      timestamp: new Date().toISOString(),
    }) + "\n");
  });
  next();
}

function hashUserId(userId, ip) {
  if (userId) return crypto.createHash("sha256").update(userId).digest("hex").substring(0, 16);
  return crypto.createHash("sha256").update(ip || "unknown").digest("hex").substring(0, 16);
}

function getHourBucket(ts) {
  const d = new Date(ts);
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}T${String(d.getUTCHours()).padStart(2, "0")}`;
}

function ingestEvent(event) {
  metricsAgg.totalEvents++;
  metricsAgg.eventsByType[event.eventType] = (metricsAgg.eventsByType[event.eventType] || 0) + 1;
  metricsAgg.eventsByDomain[event.domain] = (metricsAgg.eventsByDomain[event.domain] || 0) + 1;

  const bucket = getHourBucket(event.timestamp);
  if (!metricsAgg.hourlyBuckets.has(bucket)) {
    metricsAgg.hourlyBuckets.set(bucket, { events: 0, uniqueUsers: new Set() });
  }
  const hourData = metricsAgg.hourlyBuckets.get(bucket);
  hourData.events++;
  if (event.hashedUserId) hourData.uniqueUsers.add(event.hashedUserId);

  if (metricsAgg.hourlyBuckets.size > FIB[11]) {
    const keys = [...metricsAgg.hourlyBuckets.keys()].sort();
    for (let i = 0; i < keys.length - FIB[10]; i++) {
      metricsAgg.hourlyBuckets.delete(keys[i]);
    }
  }
}

app.post("/api/analytics/event", (req, res) => {
  const { eventType, properties, domain, path, referrer } = req.body;

  if (!eventType) {
    return res.status(400).json({
      code: "HEADY-ANALYTICS-001",
      httpStatus: 400,
      message: "Missing required field: eventType",
      service: "analytics-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  const event = {
    eventId: crypto.randomUUID(),
    hashedUserId: hashUserId(req.heady.userId, req.ip),
    sessionId: req.heady.sessionId || crypto.randomUUID(),
    eventType,
    properties: properties || {},
    domain: domain || "unknown",
    path: path || "/",
    referrer: referrer || null,
    userAgent: req.headers["user-agent"] || "unknown",
    timestamp: Date.now(),
  };

  eventBuffer.push(event);
  ingestEvent(event);

  if (eventBuffer.length >= BUFFER_FLUSH_SIZE) {
    flushBuffer();
  }

  return res.status(202).json({ eventId: event.eventId, accepted: true });
});

app.post("/api/analytics/batch", (req, res) => {
  const { events } = req.body;

  if (!Array.isArray(events) || events.length === 0) {
    return res.status(400).json({
      code: "HEADY-ANALYTICS-002",
      httpStatus: 400,
      message: "Missing or empty events array",
      service: "analytics-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  if (events.length > MAX_BATCH_SIZE) {
    return res.status(400).json({
      code: "HEADY-ANALYTICS-003",
      httpStatus: 400,
      message: `Batch size ${events.length} exceeds maximum ${MAX_BATCH_SIZE}`,
      service: "analytics-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  const accepted = [];
  for (const e of events) {
    if (!e.eventType) continue;
    const event = {
      eventId: crypto.randomUUID(),
      hashedUserId: hashUserId(req.heady.userId, req.ip),
      sessionId: req.heady.sessionId || crypto.randomUUID(),
      eventType: e.eventType,
      properties: e.properties || {},
      domain: e.domain || "unknown",
      path: e.path || "/",
      referrer: e.referrer || null,
      userAgent: req.headers["user-agent"] || "unknown",
      timestamp: e.timestamp || Date.now(),
    };
    eventBuffer.push(event);
    ingestEvent(event);
    accepted.push(event.eventId);
  }

  return res.status(202).json({ accepted: accepted.length, eventIds: accepted });
});

app.post("/api/analytics/funnel/define", (req, res) => {
  const { name, steps } = req.body;
  if (!name || !Array.isArray(steps) || steps.length < 2) {
    return res.status(400).json({
      code: "HEADY-ANALYTICS-004",
      httpStatus: 400,
      message: "Funnel requires a name and at least 2 steps",
      service: "analytics-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }

  funnelStore.set(name, {
    name,
    steps,
    createdAt: Date.now(),
    conversions: steps.map(() => 0),
  });

  return res.status(201).json({ funnel: name, steps: steps.length });
});

app.get("/api/analytics/funnel/:name", (req, res) => {
  const funnel = funnelStore.get(req.params.name);
  if (!funnel) {
    return res.status(404).json({
      code: "HEADY-ANALYTICS-005",
      httpStatus: 404,
      message: "Funnel not found",
      service: "analytics-service",
      traceId: req.heady.traceId,
      timestamp: Date.now(),
    });
  }
  return res.status(200).json(funnel);
});

app.get("/api/analytics/metrics", (req, res) => {
  const now = Date.now();
  const windowHours = parseInt(req.query.hours) || FIB[7];

  const recentBuckets = [];
  for (const [bucket, data] of metricsAgg.hourlyBuckets) {
    const bucketTime = new Date(bucket + ":00:00Z").getTime();
    if (now - bucketTime < windowHours * 3600000) {
      recentBuckets.push({
        hour: bucket,
        events: data.events,
        uniqueUsers: data.uniqueUsers.size,
      });
    }
  }

  return res.status(200).json({
    totalEvents: metricsAgg.totalEvents,
    eventsByType: metricsAgg.eventsByType,
    eventsByDomain: metricsAgg.eventsByDomain,
    hourly: recentBuckets.sort((a, b) => a.hour.localeCompare(b.hour)),
    windowHours,
    bufferSize: eventBuffer.length,
  });
});

app.get("/api/analytics/realtime", (req, res) => {
  const windowMs = FIB[5] * 60 * 1000;
  const cutoff = Date.now() - windowMs;
  const recent = eventBuffer.filter((e) => e.timestamp > cutoff);

  const uniqueUsers = new Set(recent.map((e) => e.hashedUserId));
  const topPaths = {};
  for (const e of recent) {
    topPaths[e.path] = (topPaths[e.path] || 0) + 1;
  }

  return res.status(200).json({
    activeUsers: uniqueUsers.size,
    eventsInWindow: recent.length,
    windowMinutes: FIB[5],
    topPaths: Object.entries(topPaths)
      .sort((a, b) => b[1] - a[1])
      .slice(0, FIB[5])
      .map(([path, count]) => ({ path, count })),
  });
});

function flushBuffer() {
  if (eventBuffer.length === 0) return;
  /**
   * Production: Write batch to BigQuery, PostgreSQL, or ClickHouse.
   * const batch = eventBuffer.splice(0, BUFFER_FLUSH_SIZE);
   * await bigquery.dataset('analytics').table('events').insert(batch);
   */
  const flushed = eventBuffer.splice(0, BUFFER_FLUSH_SIZE);
  process.stdout.write(JSON.stringify({
    level: "info",
    service: "analytics-service",
    message: `Flushed ${flushed.length} events from buffer`,
    timestamp: new Date().toISOString(),
  }) + "\n");
}

setInterval(flushBuffer, BUFFER_FLUSH_INTERVAL);

app.get("/health", (req, res) => {
  return res.status(200).json({
    service: "analytics-service",
    status: "healthy",
    uptime: process.uptime(),
    version: "1.0.0",
    checks: [
      { name: "event-buffer", status: eventBuffer.length < BUFFER_FLUSH_SIZE * 3 ? "pass" : "warn", duration: 0, message: `${eventBuffer.length} events buffered` },
      { name: "metrics-aggregator", status: "pass", duration: 0, message: `${metricsAgg.totalEvents} total events processed` },
      { name: "funnel-definitions", status: "pass", duration: 0, message: `${funnelStore.size} funnels defined` },
    ],
    cslConfidence: PSI,
    lastChecked: Date.now(),
  });
});

app.listen(PORT, () => {
  process.stdout.write(JSON.stringify({
    level: "info",
    service: "analytics-service",
    message: `Analytics service running on port ${PORT}`,
    timestamp: new Date().toISOString(),
  }) + "\n");
});

module.exports = app;
