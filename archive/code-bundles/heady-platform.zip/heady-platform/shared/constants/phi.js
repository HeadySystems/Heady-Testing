"use strict";

/**
 * Heady™ Sacred Geometry Constants
 * All system constants derived from φ (Golden Ratio), ψ (its inverse),
 * and the Fibonacci sequence. No magic numbers permitted.
 *
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const PHI = 1.618033988749895;
const PSI = 1 / PHI;
const PSI2 = PSI * PSI;
const PHI_SQUARED = PHI * PHI;
const PHI_CUBED = PHI * PHI * PHI;

const FIB = Object.freeze([
  1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584,
]);

const CSL_GATES = Object.freeze({
  include: PSI2,
  boost: PSI,
  inject: PSI + 0.1,
});

const TIMEOUTS = Object.freeze({
  connectMs: Math.round(PHI * 1000),
  requestMs: Math.round(PHI_SQUARED * 1000 + PHI * 1000),
  idleMs: Math.round(PHI_CUBED * 1000),
});

const CIRCUIT_BREAKER = Object.freeze({
  failureThreshold: FIB[10],
  successThreshold: FIB[9],
  timeout: FIB[11],
});

const BULKHEAD = Object.freeze({
  maxConcurrent: FIB[8],
  maxQueued: FIB[9],
});

const RATE_LIMITS = Object.freeze({
  anonymous: FIB[8],
  authenticated: FIB[10],
  enterprise: FIB[12],
});

const CACHE_SIZES = Object.freeze({
  small: FIB[7],
  medium: FIB[9],
  large: FIB[11],
  xlarge: FIB[13],
});

const RETRY = Object.freeze({
  maxAttempts: Math.round(PHI_CUBED),
  baseDelayMs: Math.round(PSI * 1000),
  maxDelayMs: FIB[9] * 1000,
  backoffMultiplier: PHI,
});

const ROLLOUT_STAGES = Object.freeze([
  PSI2 * 0.1618,
  PSI2,
  PSI,
  1.0,
]);

const SECRET_ROTATION = Object.freeze({
  apiKeyDays: FIB[7],
  certificateDays: FIB[10],
  sessionKeyDays: FIB[6],
});

const PGBOUNCER = Object.freeze({
  defaultPoolSize: FIB[8],
  maxClientConn: FIB[12],
  reservePoolSize: FIB[5],
});

const HNSW = Object.freeze({
  efConstruction: 200,
  m: 32,
  dimensions: FIB[8] * FIB[4] + FIB[8] * FIB[3],
});

function phiBackoff(attempt) {
  const delay = RETRY.baseDelayMs * Math.pow(PHI, attempt);
  const jitter = delay * PSI2 * Math.random();
  return Math.min(delay + jitter, RETRY.maxDelayMs);
}

function fibNearest(n) {
  for (let i = 0; i < FIB.length; i++) {
    if (FIB[i] >= n) return FIB[i];
  }
  return FIB[FIB.length - 1];
}

function cslGate(confidence, gate) {
  const threshold = CSL_GATES[gate];
  if (threshold === undefined) {
    throw new Error(`Unknown CSL gate: ${gate}. Use: include, boost, inject`);
  }
  return confidence >= threshold;
}

module.exports = {
  PHI,
  PSI,
  PSI2,
  PHI_SQUARED,
  PHI_CUBED,
  FIB,
  CSL_GATES,
  TIMEOUTS,
  CIRCUIT_BREAKER,
  BULKHEAD,
  RATE_LIMITS,
  CACHE_SIZES,
  RETRY,
  ROLLOUT_STAGES,
  SECRET_ROTATION,
  PGBOUNCER,
  HNSW,
  phiBackoff,
  fibNearest,
  cslGate,
};
