/**
 * Heady™ Shared Type Definitions
 * Inter-service API contracts for all 50+ services.
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

export interface HeadyAutoContext {
  requestId: string;
  traceId: string;
  spanId: string;
  userId: string | null;
  sessionId: string | null;
  domain: HeadyDomain;
  timestamp: number;
  cslConfidence: number;
  phiVersion: string;
}

export type HeadyDomain =
  | "inference"
  | "memory"
  | "agents"
  | "orchestration"
  | "security"
  | "monitoring"
  | "web"
  | "data"
  | "integration"
  | "specialized";

export interface CSLDecision {
  confidence: number;
  gate: "include" | "boost" | "inject";
  passed: boolean;
  reasoning: string;
  timestamp: number;
}

export interface VectorEmbedding {
  id: string;
  vector: number[];
  dimensions: number;
  metadata: Record<string, unknown>;
  contentHash: string;
  createdAt: number;
  updatedAt: number;
}

export interface ServiceHealth {
  service: string;
  status: "healthy" | "degraded" | "unhealthy";
  uptime: number;
  version: string;
  checks: HealthCheck[];
  cslConfidence: number;
  lastChecked: number;
}

export interface HealthCheck {
  name: string;
  status: "pass" | "fail" | "warn";
  duration: number;
  message: string;
}

export interface AuthSession {
  sessionId: string;
  userId: string;
  firebaseUid: string;
  email: string | null;
  displayName: string | null;
  authProvider: "google" | "email" | "anonymous";
  createdAt: number;
  expiresAt: number;
  clientFingerprint: string;
  domains: string[];
}

export interface Notification {
  id: string;
  userId: string;
  type: "info" | "warning" | "error" | "success" | "system";
  channel: "websocket" | "sse" | "push" | "email";
  title: string;
  body: string;
  metadata: Record<string, unknown>;
  read: boolean;
  createdAt: number;
}

export interface AnalyticsEvent {
  eventId: string;
  userId: string | null;
  sessionId: string;
  eventType: string;
  properties: Record<string, unknown>;
  domain: string;
  path: string;
  referrer: string | null;
  userAgent: string;
  timestamp: number;
}

export interface BillingSubscription {
  subscriptionId: string;
  userId: string;
  plan: "free" | "pro" | "enterprise";
  stripeCustomerId: string;
  stripeSubscriptionId: string;
  status: "active" | "past_due" | "canceled" | "trialing";
  currentPeriodStart: number;
  currentPeriodEnd: number;
}

export interface SearchResult {
  id: string;
  score: number;
  source: "fulltext" | "vector" | "hybrid";
  contentType: string;
  title: string;
  snippet: string;
  url: string;
  metadata: Record<string, unknown>;
}

export interface ScheduledJob {
  jobId: string;
  name: string;
  cron: string | null;
  phiInterval: number | null;
  handler: string;
  payload: Record<string, unknown>;
  status: "active" | "paused" | "completed" | "failed";
  lastRun: number | null;
  nextRun: number;
  retryCount: number;
}

export interface Migration {
  id: string;
  version: string;
  name: string;
  sql: string;
  rollbackSql: string;
  appliedAt: number | null;
  checksum: string;
}

export interface AssetPipelineJob {
  jobId: string;
  inputUrl: string;
  operations: AssetOperation[];
  outputUrl: string | null;
  status: "queued" | "processing" | "completed" | "failed";
  createdAt: number;
  completedAt: number | null;
}

export type AssetOperation =
  | { type: "resize"; width: number; height: number }
  | { type: "optimize"; quality: number }
  | { type: "format"; target: "webp" | "avif" | "png" | "jpg" }
  | { type: "responsive"; breakpoints: number[] };

export interface ServiceError {
  code: string;
  httpStatus: number;
  message: string;
  service: string;
  traceId: string;
  timestamp: number;
  details?: Record<string, unknown>;
}

export interface FeatureFlag {
  name: string;
  enabled: boolean;
  rolloutPercentage: number;
  cslConfidenceGate: number;
  killSwitch: boolean;
  metadata: Record<string, unknown>;
}

export interface SagaStep {
  stepId: string;
  sagaId: string;
  service: string;
  action: string;
  compensationAction: string;
  status: "pending" | "completed" | "compensating" | "compensated" | "failed";
  payload: Record<string, unknown>;
  result: Record<string, unknown> | null;
  executedAt: number | null;
}

export interface DrupalContent {
  nid: number;
  uuid: string;
  type: DrupalContentType;
  title: string;
  body: string;
  status: boolean;
  created: number;
  changed: number;
  uid: number;
  fields: Record<string, unknown>;
}

export type DrupalContentType =
  | "article"
  | "documentation"
  | "case_study"
  | "patent"
  | "event"
  | "grant_program"
  | "agent_listing"
  | "investor_update"
  | "testimonial"
  | "faq"
  | "product_catalog"
  | "news_release"
  | "media_asset";
