"use strict";

/**
 * Heady™ Rate Limiting Middleware
 * Per-user, per-IP, per-API-key with φ-scaled sliding windows
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

const { PHI, PSI, PSI2, FIB, RATE_LIMITS, phiBackoff } = require("../../shared/constants/phi");

class SlidingWindowCounter {
  constructor(windowMs, maxRequests) {
    this.windowMs = windowMs;
    this.maxRequests = maxRequests;
    this.windows = new Map();
  }

  isAllowed(key) {
    const now = Date.now();
    const currentWindow = Math.floor(now / this.windowMs);
    const previousWindow = currentWindow - 1;
    const windowProgress = (now % this.windowMs) / this.windowMs;

    const current = this.windows.get(`${key}:${currentWindow}`) || 0;
    const previous = this.windows.get(`${key}:${previousWindow}`) || 0;

    const estimatedCount = previous * (1 - windowProgress) + current;

    if (estimatedCount >= this.maxRequests) {
      return {
        allowed: false,
        remaining: 0,
        retryAfterMs: Math.round(this.windowMs * (1 - windowProgress)),
        limit: this.maxRequests,
      };
    }

    this.windows.set(`${key}:${currentWindow}`, current + 1);

    this._cleanup(currentWindow);

    return {
      allowed: true,
      remaining: Math.max(0, Math.floor(this.maxRequests - estimatedCount - 1)),
      retryAfterMs: 0,
      limit: this.maxRequests,
    };
  }

  _cleanup(currentWindow) {
    if (this.windows.size > FIB[10]) {
      for (const [key] of this.windows) {
        const windowNum = parseInt(key.split(":").pop());
        if (windowNum < currentWindow - 2) {
          this.windows.delete(key);
        }
      }
    }
  }
}

const windowMs = FIB[9] * 1000;
const anonymousLimiter = new SlidingWindowCounter(windowMs, RATE_LIMITS.anonymous);
const authenticatedLimiter = new SlidingWindowCounter(windowMs, RATE_LIMITS.authenticated);
const enterpriseLimiter = new SlidingWindowCounter(windowMs, RATE_LIMITS.enterprise);

function rateLimitMiddleware(serviceName) {
  return function rateLimit(req, res, next) {
    const apiKey = req.headers["x-api-key"];
    const userId = req.headers["x-user-id"] || req.heady?.userId;
    const ip = req.ip || req.connection.remoteAddress;

    let limiter;
    let key;

    if (apiKey && apiKey.startsWith("heady_ent_")) {
      limiter = enterpriseLimiter;
      key = `apikey:${apiKey}`;
    } else if (userId) {
      limiter = authenticatedLimiter;
      key = `user:${userId}`;
    } else {
      limiter = anonymousLimiter;
      key = `ip:${ip}`;
    }

    const result = limiter.isAllowed(key);

    res.setHeader("X-RateLimit-Limit", String(result.limit));
    res.setHeader("X-RateLimit-Remaining", String(result.remaining));
    res.setHeader("X-RateLimit-Reset", String(Math.ceil(Date.now() / 1000) + Math.ceil(windowMs / 1000)));

    if (!result.allowed) {
      res.setHeader("Retry-After", String(Math.ceil(result.retryAfterMs / 1000)));
      return res.status(429).json({
        code: `HEADY-${serviceName.toUpperCase()}-RATELIMIT`,
        httpStatus: 429,
        message: "Rate limit exceeded",
        service: serviceName,
        traceId: req.heady?.traceId || "unknown",
        timestamp: Date.now(),
        retryAfterMs: result.retryAfterMs,
      });
    }

    next();
  };
}

module.exports = {
  rateLimitMiddleware,
  SlidingWindowCounter,
};
