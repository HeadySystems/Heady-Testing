#!/usr/bin/env bash
set -euo pipefail

# Heady™ pgvector Backup Script
# Automated backups with point-in-time recovery support
# Fibonacci-derived retention: 8 daily, 5 weekly, 3 monthly
# © 2026 HeadySystems Inc. — Eric Haywood, Founder

PGVECTOR_HOST="${PGVECTOR_HOST:-localhost}"
PGVECTOR_PORT="${PGVECTOR_PORT:-5432}"
PGVECTOR_DB="${PGVECTOR_DB:-heady}"
PGVECTOR_USER="${PGVECTOR_USER:-heady}"
BACKUP_DIR="${BACKUP_DIR:-/backups/pgvector}"
GCS_BUCKET="${GCS_BUCKET:-heady-backups}"
RETENTION_DAILY=8    # Fibonacci
RETENTION_WEEKLY=5   # Fibonacci
RETENTION_MONTHLY=3  # Fibonacci

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
DAY_OF_WEEK=$(date +%u)
DAY_OF_MONTH=$(date +%d)
BACKUP_TYPE="daily"

if [ "$DAY_OF_MONTH" == "01" ]; then
  BACKUP_TYPE="monthly"
elif [ "$DAY_OF_WEEK" == "7" ]; then
  BACKUP_TYPE="weekly"
fi

BACKUP_FILE="${BACKUP_DIR}/${BACKUP_TYPE}/heady_${TIMESTAMP}.sql.gz"
mkdir -p "${BACKUP_DIR}/${BACKUP_TYPE}"

log() {
  echo "{\"level\":\"info\",\"service\":\"backup-pgvector\",\"message\":\"$1\",\"timestamp\":\"$(date -Iseconds)\"}"
}

log "Starting ${BACKUP_TYPE} backup of ${PGVECTOR_DB}"

pg_dump \
  -h "${PGVECTOR_HOST}" \
  -p "${PGVECTOR_PORT}" \
  -U "${PGVECTOR_USER}" \
  -d "${PGVECTOR_DB}" \
  --format=custom \
  --compress=8 \
  --verbose \
  --no-owner \
  --no-privileges \
  2>/dev/null | gzip > "${BACKUP_FILE}"

BACKUP_SIZE=$(stat -f%z "${BACKUP_FILE}" 2>/dev/null || stat -c%s "${BACKUP_FILE}")
log "Backup completed: ${BACKUP_FILE} (${BACKUP_SIZE} bytes)"

CHECKSUM=$(sha256sum "${BACKUP_FILE}" | cut -d' ' -f1)
echo "${CHECKSUM}  ${BACKUP_FILE}" > "${BACKUP_FILE}.sha256"
log "Checksum: ${CHECKSUM}"

if command -v gsutil &> /dev/null; then
  gsutil cp "${BACKUP_FILE}" "gs://${GCS_BUCKET}/${BACKUP_TYPE}/"
  gsutil cp "${BACKUP_FILE}.sha256" "gs://${GCS_BUCKET}/${BACKUP_TYPE}/"
  log "Uploaded to GCS: gs://${GCS_BUCKET}/${BACKUP_TYPE}/"
fi

cleanup_old_backups() {
  local dir=$1
  local keep=$2
  local count=$(ls -1 "${dir}"/heady_*.sql.gz 2>/dev/null | wc -l)
  if [ "${count}" -gt "${keep}" ]; then
    local to_remove=$((count - keep))
    ls -1t "${dir}"/heady_*.sql.gz | tail -n "${to_remove}" | while read -r f; do
      rm -f "${f}" "${f}.sha256"
      log "Removed old backup: ${f}"
    done
  fi
}

cleanup_old_backups "${BACKUP_DIR}/daily" "${RETENTION_DAILY}"
cleanup_old_backups "${BACKUP_DIR}/weekly" "${RETENTION_WEEKLY}"
cleanup_old_backups "${BACKUP_DIR}/monthly" "${RETENTION_MONTHLY}"

log "Backup process complete. Type: ${BACKUP_TYPE}, File: ${BACKUP_FILE}"
