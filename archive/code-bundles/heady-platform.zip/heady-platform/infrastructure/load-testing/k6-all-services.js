/**
 * Heady™ Load Testing — k6 Script
 * Tests all new service endpoints under load
 * Fibonacci-derived VU counts and durations
 * © 2026 HeadySystems Inc. — Eric Haywood, Founder
 */

import http from "k6/http";
import { check, sleep, group } from "k6";
import { Rate, Counter, Trend } from "k6/metrics";

const errorRate = new Rate("errors");
const requestCount = new Counter("requests");
const latency = new Trend("request_latency");

const BASE = __ENV.BASE_URL || "http://localhost";

export const options = {
  stages: [
    { duration: "21s", target: 8 },    // Fibonacci ramp
    { duration: "34s", target: 21 },   // Fibonacci sustained
    { duration: "55s", target: 55 },   // Fibonacci peak
    { duration: "34s", target: 21 },   // Fibonacci cool
    { duration: "13s", target: 0 },    // Fibonacci drain
  ],
  thresholds: {
    http_req_duration: ["p(95)<1618", "p(99)<2618"],  // φ-derived ms
    errors: ["rate<0.0618"],                            // PSI² * 0.1618
    http_req_failed: ["rate<0.05"],
  },
};

export default function () {
  group("Auth Session Server", () => {
    const health = http.get(`${BASE}:3397/health`);
    check(health, { "auth health 200": (r) => r.status === 200 });
    requestCount.add(1);
    latency.add(health.timings.duration);
    errorRate.add(health.status !== 200);

    const createRes = http.post(
      `${BASE}:3397/api/session/create`,
      JSON.stringify({ idToken: "test-token" }),
      { headers: { "Content-Type": "application/json" } }
    );
    check(createRes, { "session create responds": (r) => r.status === 401 || r.status === 201 });
    requestCount.add(1);
  });

  group("Notification Service", () => {
    const health = http.get(`${BASE}:3398/health`);
    check(health, { "notif health 200": (r) => r.status === 200 });

    const send = http.post(
      `${BASE}:3398/api/notifications/send`,
      JSON.stringify({
        userId: `load-test-${__VU}`,
        title: "Load Test Notification",
        body: "This is a load test notification",
        type: "info",
      }),
      { headers: { "Content-Type": "application/json" } }
    );
    check(send, { "notification created": (r) => r.status === 201 });
    requestCount.add(2);
  });

  group("Analytics Service", () => {
    const event = http.post(
      `${BASE}:3399/api/analytics/event`,
      JSON.stringify({
        eventType: "page_view",
        domain: "headyme.com",
        path: "/dashboard",
        properties: { source: "k6-load-test" },
      }),
      { headers: { "Content-Type": "application/json" } }
    );
    check(event, { "event accepted": (r) => r.status === 202 });

    const metrics = http.get(`${BASE}:3399/api/analytics/metrics`);
    check(metrics, { "metrics 200": (r) => r.status === 200 });
    requestCount.add(2);
  });

  group("Search Service", () => {
    http.post(
      `${BASE}:3401/api/search/index`,
      JSON.stringify({
        id: `doc-${__VU}-${__ITER}`,
        contentType: "article",
        title: "Load Test Document",
        body: "This is a load test document for the Heady search service",
        url: "/test",
      }),
      { headers: { "Content-Type": "application/json" } }
    );

    const search = http.post(
      `${BASE}:3401/api/search/query`,
      JSON.stringify({ q: "load test document", mode: "fulltext", limit: 5 }),
      { headers: { "Content-Type": "application/json" } }
    );
    check(search, { "search returns results": (r) => r.status === 200 });
    requestCount.add(2);
  });

  group("Billing Service", () => {
    const plans = http.get(`${BASE}:3400/api/billing/plans`);
    check(plans, { "plans 200": (r) => r.status === 200 });
    requestCount.add(1);
  });

  group("Scheduler Service", () => {
    const health = http.get(`${BASE}:3402/health`);
    check(health, { "scheduler health 200": (r) => r.status === 200 });
    requestCount.add(1);
  });

  group("Migration Service", () => {
    const pending = http.get(`${BASE}:3403/api/migrations/pending`);
    check(pending, { "migrations pending 200": (r) => r.status === 200 });
    requestCount.add(1);
  });

  group("Asset Pipeline", () => {
    const health = http.get(`${BASE}:3404/health`);
    check(health, { "asset health 200": (r) => r.status === 200 });
    requestCount.add(1);
  });

  sleep(0.618);  // PSI seconds between iterations
}

export function handleSummary(data) {
  return {
    stdout: JSON.stringify(
      {
        timestamp: new Date().toISOString(),
        service: "heady-load-test",
        totalRequests: data.metrics.requests?.values?.count || 0,
        errorRate: data.metrics.errors?.values?.rate || 0,
        p95Latency: data.metrics.http_req_duration?.values?.["p(95)"] || 0,
        p99Latency: data.metrics.http_req_duration?.values?.["p(99)"] || 0,
        medianLatency: data.metrics.http_req_duration?.values?.med || 0,
      },
      null,
      2
    ),
  };
}
