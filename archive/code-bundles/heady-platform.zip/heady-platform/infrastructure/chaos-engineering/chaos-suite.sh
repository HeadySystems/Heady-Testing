#!/usr/bin/env bash
set -euo pipefail

# Heady™ Chaos Engineering Suite
# Failure injection scripts to validate circuit breakers and bulkheads
# © 2026 HeadySystems Inc. — Eric Haywood, Founder

SERVICES=(
  "auth-session-server:3397"
  "notification-service:3398"
  "analytics-service:3399"
  "billing-service:3400"
  "search-service:3401"
  "scheduler-service:3402"
  "migration-service:3403"
  "asset-pipeline:3404"
)

log() {
  echo "{\"level\":\"info\",\"service\":\"chaos-engineering\",\"test\":\"$1\",\"message\":\"$2\",\"timestamp\":\"$(date -Iseconds)\"}"
}

# Test 1: Kill a service, verify others remain healthy
test_service_kill() {
  local target=$1
  local svc_name=$(echo "$target" | cut -d: -f1)
  log "service-kill" "Stopping $svc_name"
  
  docker stop "heady-${svc_name}" 2>/dev/null || true
  sleep 5

  local failures=0
  for svc in "${SERVICES[@]}"; do
    local name=$(echo "$svc" | cut -d: -f1)
    local port=$(echo "$svc" | cut -d: -f2)
    if [ "$name" == "$svc_name" ]; then continue; fi
    
    local status=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:${port}/health" 2>/dev/null || echo "000")
    if [ "$status" != "200" ]; then
      log "service-kill" "CASCADING FAILURE: ${name} returned ${status} after ${svc_name} was killed"
      failures=$((failures + 1))
    fi
  done

  docker start "heady-${svc_name}" 2>/dev/null || true
  sleep 8  # Fibonacci wait for recovery

  if [ "$failures" -eq 0 ]; then
    log "service-kill" "PASS: No cascading failures when ${svc_name} was killed"
  else
    log "service-kill" "FAIL: ${failures} services affected by ${svc_name} failure"
  fi
}

# Test 2: Network partition — block traffic between services
test_network_partition() {
  local target=$1
  local svc_name=$(echo "$target" | cut -d: -f1)
  log "network-partition" "Partitioning $svc_name from mesh"
  
  docker network disconnect heady-mesh "heady-${svc_name}" 2>/dev/null || true
  sleep 8

  local health=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:3397/health" 2>/dev/null || echo "000")
  log "network-partition" "Auth health after partition: ${health}"

  docker network connect heady-mesh "heady-${svc_name}" 2>/dev/null || true
  sleep 5
  log "network-partition" "Reconnected ${svc_name} to mesh"
}

# Test 3: Resource exhaustion — fill memory
test_memory_pressure() {
  local target=$1
  local svc_name=$(echo "$target" | cut -d: -f1)
  log "memory-pressure" "Applying memory pressure to ${svc_name}"
  
  # Send many large requests to exhaust memory
  for i in $(seq 1 89); do  # Fibonacci: 89
    curl -s -X POST "http://localhost:$(echo "$target" | cut -d: -f2)/health" \
      -H "Content-Type: application/json" \
      -d '{"data":"'"$(head -c 10000 /dev/urandom | base64)"'"}' \
      -o /dev/null &
  done
  wait
  
  sleep 5
  local health=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:$(echo "$target" | cut -d: -f2)/health" 2>/dev/null || echo "000")
  log "memory-pressure" "Health after pressure: ${health}"
}

# Test 4: Rate limit validation
test_rate_limits() {
  local target=$1
  local port=$(echo "$target" | cut -d: -f2)
  log "rate-limit" "Sending burst to port ${port}"
  
  local limited=0
  for i in $(seq 1 55); do  # Fibonacci: 55
    local status=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:${port}/health")
    if [ "$status" == "429" ]; then
      limited=$((limited + 1))
    fi
  done

  if [ "$limited" -gt 0 ]; then
    log "rate-limit" "PASS: Rate limiter triggered after burst (${limited}/55 requests limited)"
  else
    log "rate-limit" "INFO: Rate limiter not triggered — may need higher burst volume"
  fi
}

# Main execution
case "${1:-all}" in
  kill)
    for svc in "${SERVICES[@]}"; do
      test_service_kill "$svc"
    done
    ;;
  partition)
    for svc in "${SERVICES[@]}"; do
      test_network_partition "$svc"
    done
    ;;
  memory)
    for svc in "${SERVICES[@]}"; do
      test_memory_pressure "$svc"
    done
    ;;
  ratelimit)
    for svc in "${SERVICES[@]}"; do
      test_rate_limits "$svc"
    done
    ;;
  all)
    log "suite" "Running full chaos engineering suite"
    for svc in "${SERVICES[@]}"; do
      test_service_kill "$svc"
      test_rate_limits "$svc"
    done
    log "suite" "Chaos suite complete"
    ;;
  *)
    echo "Usage: $0 {kill|partition|memory|ratelimit|all}"
    exit 1
    ;;
esac
