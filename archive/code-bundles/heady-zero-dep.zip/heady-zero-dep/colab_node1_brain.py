"""
colab_node1_brain.py
====================
HEADY BRAIN NODE — Colab Pro+ Notebook #1

Run this script cell-by-cell inside a Google Colab Pro+ notebook that has
GPU runtime enabled.  Each section is delimited by a  # --- CELL N ---
comment so you can paste each block into its own notebook cell.

Services started on this node
──────────────────────────────
  • Embedding Server  →  0.0.0.0:8001  (GPU-accelerated sentence-transformers)
  • LLM Gateway       →  0.0.0.0:8002  (multi-provider, zero-SDK)
  • Monte Carlo API   →  0.0.0.0:8004  (simulation endpoint)
  • Public tunnel     →  ngrok or cloudflared (auto-detected)

After startup this node registers itself with the Conductor on Node 3 and
runs a φ^4 ≈ 6.85 s health-check loop until the Colab session ends.
On disconnect, all vector / checkpoint state is persisted to Google Drive.

Dependencies (pip-installed in Cell 2):
  torch  sentence-transformers
"""

# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 1: Banner & imports ---
# ═══════════════════════════════════════════════════════════════════════════════

from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Dict, Optional

# φ constant (all timing derived from this)
PHI: float = 1.6180339887498948482
PHI4: float = PHI ** 4   # ≈ 6.854 s  — health-check tick
PHI6: float = PHI ** 6   # ≈ 17.94 s  — persist tick

NODE_ID: str   = f"brain-{uuid.uuid4().hex[:8]}"
NODE_ROLE: str = "brain"
NODE_NAME: str = "HEADY BRAIN NODE — Colab Pro+ #1"

_BANNER = r"""
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║      ██╗  ██╗███████╗ █████╗ ██████╗ ██╗   ██╗                 ║
║      ██║  ██║██╔════╝██╔══██╗██╔══██╗╚██╗ ██╔╝                 ║
║      ███████║█████╗  ███████║██║  ██║ ╚████╔╝                  ║
║      ██╔══██║██╔══╝  ██╔══██║██║  ██║  ╚██╔╝                   ║
║      ██║  ██║███████╗██║  ██║██████╔╝   ██║                     ║
║      ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝    ╚═╝                    ║
║                                                                  ║
║         BRAIN NODE  ·  Colab Pro+  #1  ·  GPU                   ║
║         Embedding Server  ·  LLM Gateway  ·  Monte Carlo        ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
"""

print(_BANNER)
print(f"  Node ID   : {NODE_ID}")
print(f"  φ^4 tick  : {PHI4:.3f}s\n")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("brain_node")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 2: Install dependencies ---
# ═══════════════════════════════════════════════════════════════════════════════

def install_deps() -> None:
    """Install torch and sentence-transformers (the only pip deps)."""
    print("📦  Installing dependencies …")
    pkgs = ["torch", "sentence-transformers"]
    for pkg in pkgs:
        print(f"    pip install {pkg} …")
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", pkg, "--quiet", "--upgrade"],
            capture_output=True, text=True,
        )
        if r.returncode == 0:
            print(f"    ✓  {pkg}")
        else:
            print(f"    ⚠  {pkg} — {r.stderr.strip()[:120]}")
    print()


install_deps()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 3: Mount Google Drive & sync code ---
# ═══════════════════════════════════════════════════════════════════════════════

GDRIVE_MOUNT     = "/content/drive"
GDRIVE_HEADY_DIR = "/content/drive/MyDrive/heady-zero-dep"
LOCAL_HEADY_DIR  = "/content/heady-zero-dep"


def mount_drive() -> bool:
    """Mount Google Drive and return True on success."""
    try:
        from google.colab import drive  # type: ignore
        drive.mount(GDRIVE_MOUNT, force_remount=False)
        print(f"✓  Google Drive mounted at {GDRIVE_MOUNT}")
        return True
    except ImportError:
        print("⚠  google.colab not available — skipping Drive mount (local mode)")
        return False
    except Exception as e:
        print(f"⚠  Drive mount failed: {e}")
        return False


def sync_code_from_drive() -> None:
    """
    Copy the heady-zero-dep code from Drive to /content so Python can import it.
    Falls back to assuming code is already at LOCAL_HEADY_DIR.
    """
    drive_src = Path(GDRIVE_HEADY_DIR)
    local_dst = Path(LOCAL_HEADY_DIR)

    if drive_src.exists():
        import shutil
        if local_dst.exists():
            shutil.rmtree(str(local_dst))
        shutil.copytree(str(drive_src), str(local_dst))
        print(f"✓  Code synced from Drive → {local_dst}")
    elif local_dst.exists():
        print(f"✓  Code found at {local_dst} (no Drive sync needed)")
    else:
        # Check if we're running from the repo directly
        script_dir = Path(__file__).parent
        if (script_dir / "ai").exists():
            local_dst = script_dir
            print(f"✓  Using script directory as code root: {local_dst}")
        else:
            print(f"⚠  heady-zero-dep not found at {local_dst} or {drive_src}")
            print("   Continuing — ensure the heady-zero-dep directory is accessible")
            return

    # Add to Python path
    code_root = str(local_dst)
    if code_root not in sys.path:
        sys.path.insert(0, code_root)
    print(f"✓  {code_root} added to sys.path\n")


_drive_mounted = mount_drive()
sync_code_from_drive()

# Also add the script's own directory
_script_root = str(Path(__file__).parent)
if _script_root not in sys.path:
    sys.path.insert(0, _script_root)


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 4: Load configuration ---
# ═══════════════════════════════════════════════════════════════════════════════

# Load .env from Drive or local dir
_env_paths = [
    Path(GDRIVE_HEADY_DIR) / ".env",
    Path(LOCAL_HEADY_DIR)  / ".env",
    Path(__file__).parent  / ".env",
]
for _ep in _env_paths:
    if _ep.exists():
        try:
            from core.env_loader import load_env
            load_env(str(_ep))
            print(f"✓  Loaded .env from {_ep}")
            break
        except Exception:
            pass

# Override node identity
os.environ["HEADY_NODE_ID"]   = NODE_ID
os.environ["HEADY_NODE_ROLE"] = NODE_ROLE
os.environ["HEADY_ENV"]       = "colab"

try:
    from config import (
        PORT_EMBED, PORT_LLM, PORT_MC,
        NGROK_TOKEN, CLOUDFLARE_TOKEN, TUNNEL_PROVIDER,
        NODE3_URL, PHI4 as _PHI4, PHI6 as _PHI6,
        HEALTH_CHECK_INTERVAL, PERSIST_INTERVAL, GDRIVE_HEADY_DIR as _GDRIVE,
    )
    PHI4 = _PHI4
    PHI6 = _PHI6
    print("✓  Config loaded from config.py")
except ImportError:
    print("⚠  config.py not found — using built-in defaults")
    PORT_EMBED = int(os.getenv("PORT_EMBED", "8001"))
    PORT_LLM   = int(os.getenv("PORT_LLM",   "8002"))
    PORT_MC    = int(os.getenv("PORT_MC",    "8004"))
    NODE3_URL  = os.getenv("HEADY_NODE3_URL", "http://localhost:8000")
    NGROK_TOKEN      = os.getenv("NGROK_TOKEN", "")
    CLOUDFLARE_TOKEN = os.getenv("CLOUDFLARE_TOKEN", "")
    TUNNEL_PROVIDER  = os.getenv("TUNNEL_PROVIDER", "auto")
    HEALTH_CHECK_INTERVAL = PHI4
    PERSIST_INTERVAL      = PHI6
    _GDRIVE = GDRIVE_HEADY_DIR

print(f"  PORT_EMBED : {PORT_EMBED}")
print(f"  PORT_LLM   : {PORT_LLM}")
print(f"  PORT_MC    : {PORT_MC}")
print(f"  Node3 URL  : {NODE3_URL}\n")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 5: Tunnel setup (ngrok / cloudflared) ---
# ═══════════════════════════════════════════════════════════════════════════════

_tunnel_urls: Dict[str, str] = {}   # port → public URL


def _start_ngrok_tunnel(port: int, token: str) -> Optional[str]:
    """Start an ngrok tunnel on *port*. Returns public URL or None."""
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "pyngrok", "--quiet"],
            capture_output=True,
        )
        from pyngrok import ngrok, conf  # type: ignore
        conf.get_default().auth_token = token
        tunnel = ngrok.connect(port, "http")
        url = tunnel.public_url
        if url.startswith("http://"):
            url = url.replace("http://", "https://", 1)
        return url
    except Exception as e:
        log.warning("ngrok tunnel failed on port %d: %s", port, e)
        return None


def _start_cloudflared_tunnel(port: int) -> Optional[str]:
    """Start a cloudflared quick-tunnel. Returns public URL or None."""
    try:
        # Install cloudflared if missing
        cf_bin = "/usr/local/bin/cloudflared"
        if not Path(cf_bin).exists():
            subprocess.run([
                "wget", "-q",
                "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
                "-O", cf_bin,
            ], check=True)
            os.chmod(cf_bin, 0o755)

        proc = subprocess.Popen(
            [cf_bin, "tunnel", "--url", f"http://localhost:{port}"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, bufsize=1,
        )
        # Read output until we see the URL
        deadline = time.time() + 30
        while time.time() < deadline:
            line = proc.stdout.readline()
            if "trycloudflare.com" in line:
                # Extract URL from log line
                for part in line.split():
                    if "trycloudflare.com" in part:
                        url = part.strip()
                        if not url.startswith("http"):
                            url = "https://" + url
                        return url
        return None
    except Exception as e:
        log.warning("cloudflared tunnel failed on port %d: %s", port, e)
        return None


def establish_tunnels() -> Dict[str, str]:
    """
    Establish public tunnels for the embed and llm ports.
    Returns mapping {port_str: public_url}.
    """
    urls: Dict[str, str] = {}
    provider = TUNNEL_PROVIDER

    # Auto-detect: prefer ngrok if token exists, else cloudflared
    if provider == "auto":
        provider = "ngrok" if NGROK_TOKEN else ("cloudflared" if True else "none")

    print(f"🌐  Establishing tunnels via {provider} …")

    ports_to_tunnel = [
        (PORT_EMBED, "embed"),
        (PORT_LLM,   "llm"),
        (PORT_MC,    "monte_carlo"),
    ]

    for port, name in ports_to_tunnel:
        url: Optional[str] = None
        if provider == "ngrok" and NGROK_TOKEN:
            url = _start_ngrok_tunnel(port, NGROK_TOKEN)
        elif provider == "cloudflared":
            url = _start_cloudflared_tunnel(port)

        if url:
            urls[str(port)] = url
            urls[name]      = url
            print(f"  ✓  {name} ({port}) → {url}")
        else:
            local_url = f"http://localhost:{port}"
            urls[str(port)] = local_url
            urls[name]      = local_url
            print(f"  ⚠  {name} ({port}) — no tunnel, local only: {local_url}")

    return urls


_tunnel_urls = establish_tunnels()

# Export as env vars so other processes can read them
os.environ["HEADY_NODE1_URL"]    = _tunnel_urls.get("embed", f"http://localhost:{PORT_EMBED}")
os.environ["HEADY_NODE1_TUNNEL"] = _tunnel_urls.get("embed", "")
print()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 6: Start Embedding Server (GPU-accelerated) ---
# ═══════════════════════════════════════════════════════════════════════════════

_embed_server_thread: Optional[threading.Thread] = None
_embed_server_ready  = threading.Event()


def _run_embedding_server() -> None:
    """Run the EmbeddingServer in a daemon thread."""
    try:
        from ai.embedding_server import EmbeddingServer  # type: ignore
        server = EmbeddingServer(host="0.0.0.0", port=PORT_EMBED, preload_model=True)
        _embed_server_ready.set()
        server.run()
    except Exception as e:
        log.error("EmbeddingServer crashed: %s", e, exc_info=True)
        _embed_server_ready.set()   # unblock waiters even on crash


print(f"🧠  Starting Embedding Server on port {PORT_EMBED} (GPU) …")
_embed_server_thread = threading.Thread(
    target=_run_embedding_server, daemon=True, name="embed-server"
)
_embed_server_thread.start()

# Wait up to 90 s for model to load (large download on first run)
if _embed_server_ready.wait(timeout=90):
    time.sleep(1)   # let asyncio event loop bind the port
    print(f"✓  Embedding Server ready on port {PORT_EMBED}")
else:
    print(f"⚠  Embedding Server did not signal ready within 90 s — continuing anyway")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 7: Start LLM Gateway ---
# ═══════════════════════════════════════════════════════════════════════════════

_llm_thread: Optional[threading.Thread] = None


def _run_llm_gateway_server() -> None:
    """
    Wrap the LLMGateway in a small HTTP server and run it.
    Exposes POST /api/llm/complete and GET /api/llm/health.
    """
    try:
        from core.http_server import HTTPServer, JSONResponse, Request  # type: ignore
        from ai.llm_gateway import LLMGateway  # type: ignore

        gw = LLMGateway()
        server = HTTPServer(host="0.0.0.0", port=PORT_LLM, cors=True)

        @server.route("/api/llm/complete", methods=["POST"])
        async def llm_complete(req: Request) -> JSONResponse:
            body = req.json or {}
            messages   = body.get("messages", [])
            model_name = body.get("model",    os.getenv("DEFAULT_LLM_MODEL", "gpt-4o-mini"))
            provider   = body.get("provider", os.getenv("DEFAULT_LLM_PROVIDER", "openai"))
            max_tokens = int(body.get("max_tokens", 2048))
            temperature = float(body.get("temperature", 0.7))

            if not messages:
                return JSONResponse({"ok": False, "error": "messages required"}, status=400)
            try:
                loop = asyncio.get_event_loop()
                text = await loop.run_in_executor(
                    None,
                    lambda: gw.complete(
                        messages=messages,
                        model=model_name,
                        provider=provider,
                        max_tokens=max_tokens,
                        temperature=temperature,
                    )
                )
                return JSONResponse({"ok": True, "text": text, "model": model_name})
            except Exception as e:
                return JSONResponse({"ok": False, "error": str(e)}, status=500)

        @server.route("/api/llm/health", methods=["GET"])
        async def llm_health(req: Request) -> JSONResponse:
            return JSONResponse({
                "ok": True,
                "service": "heady-llm-gateway",
                "providers": list(gw._providers.keys()) if hasattr(gw, "_providers") else [],
                "timestamp": time.time(),
            })

        log.info("LLM Gateway server starting on port %d", PORT_LLM)
        server.run()
    except Exception as e:
        log.error("LLM Gateway server crashed: %s", e, exc_info=True)


print(f"🤖  Starting LLM Gateway on port {PORT_LLM} …")
_llm_thread = threading.Thread(
    target=_run_llm_gateway_server, daemon=True, name="llm-gateway"
)
_llm_thread.start()
time.sleep(2)
print(f"✓  LLM Gateway started on port {PORT_LLM}")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 8: Start Monte Carlo Engine ---
# ═══════════════════════════════════════════════════════════════════════════════

_mc_thread: Optional[threading.Thread] = None


def _run_monte_carlo_server() -> None:
    """
    Expose Monte Carlo simulation via HTTP on PORT_MC.
    POST /api/mc/simulate  — run a simulation
    GET  /api/mc/health    — liveness
    """
    try:
        from core.http_server import HTTPServer, JSONResponse, Request  # type: ignore
        from ai.monte_carlo import MonteCarloSimulator, Task  # type: ignore

        default_runs = int(PHI ** 8)  # ≈ 46
        server = HTTPServer(host="0.0.0.0", port=PORT_MC, cors=True)

        @server.route("/api/mc/simulate", methods=["POST"])
        async def mc_simulate(req: Request) -> JSONResponse:
            body = req.json or {}
            task_name   = body.get("name",       "unnamed")
            complexity  = float(body.get("complexity",  1.0))
            uncertainty = float(body.get("uncertainty", 0.2))
            runs        = int(body.get("runs", default_runs))

            task = Task(
                name=task_name,
                complexity=complexity,
                uncertainty=uncertainty,
            )
            try:
                # Create simulator with the requested run count
                sim = MonteCarloSimulator(n_runs=runs, n_workers=4)
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    lambda: sim.run(task)
                )
                return JSONResponse({
                    "ok":         True,
                    "task":       task_name,
                    "mean_time":  round(result.mean_time, 4),
                    "std_dev":    round(result.std_time, 4),
                    "p50":        round(result.percentile("time", 50), 4),
                    "p95":        round(result.percentile("time", 95), 4),
                    "confidence": round(result.confidence_score, 4),
                    "runs":       runs,
                })
            except Exception as e:
                return JSONResponse({"ok": False, "error": str(e)}, status=500)

        @server.route("/api/mc/health", methods=["GET"])
        async def mc_health(req: Request) -> JSONResponse:
            return JSONResponse({
                "ok": True,
                "service": "heady-monte-carlo",
                "phi4": round(PHI4, 4),
                "timestamp": time.time(),
            })

        log.info("Monte Carlo server starting on port %d", PORT_MC)
        server.run()
    except Exception as e:
        log.error("Monte Carlo server crashed: %s", e, exc_info=True)


print(f"🎲  Starting Monte Carlo Engine on port {PORT_MC} …")
_mc_thread = threading.Thread(
    target=_run_monte_carlo_server, daemon=True, name="monte-carlo"
)
_mc_thread.start()
time.sleep(1)
print(f"✓  Monte Carlo Engine started on port {PORT_MC}")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 9: Register with Conductor (Node 3) ---
# ═══════════════════════════════════════════════════════════════════════════════

def register_with_conductor(conductor_url: str, retries: int = 5) -> bool:
    """POST our node info to the conductor's /api/conductor/register endpoint."""
    payload = json.dumps({
        "node_id":    NODE_ID,
        "node_name":  NODE_NAME,
        "role":       NODE_ROLE,
        "url":        _tunnel_urls.get("embed", f"http://localhost:{PORT_EMBED}"),
        "tunnel_url": _tunnel_urls.get("embed", ""),
        "ports": {
            "embed": PORT_EMBED,
            "llm":   PORT_LLM,
            "mc":    PORT_MC,
        },
        "capabilities": ["embed", "llm", "monte_carlo"],
        "timestamp": time.time(),
    }).encode("utf-8")

    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(
                f"{conductor_url.rstrip('/')}/api/conductor/register",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
                if data.get("ok"):
                    print(f"✓  Registered with Conductor at {conductor_url}")
                    return True
                else:
                    log.warning("Conductor registration rejected: %s", data)
        except urllib.error.URLError as e:
            log.info("Conductor not reachable (attempt %d/%d): %s", attempt, retries, e)
            if attempt < retries:
                time.sleep(PHI4 * attempt)
    print(f"⚠  Could not register with Conductor at {conductor_url} (will retry in health loop)")
    return False


_conductor_url = NODE3_URL
register_with_conductor(_conductor_url)


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 10: Print endpoint summary ---
# ═══════════════════════════════════════════════════════════════════════════════

def print_endpoints() -> None:
    embed_public = _tunnel_urls.get("embed", f"http://localhost:{PORT_EMBED}")
    llm_public   = _tunnel_urls.get("llm",   f"http://localhost:{PORT_LLM}")
    mc_public    = _tunnel_urls.get("monte_carlo", f"http://localhost:{PORT_MC}")

    print("\n" + "═" * 65)
    print("  BRAIN NODE — ENDPOINTS READY")
    print("═" * 65)
    print(f"  Embedding Server  : {embed_public}")
    print(f"    POST  /embed            — embed texts (GPU)")
    print(f"    POST  /embed/batch      — batch embed")
    print(f"    GET   /health           — model info")
    print()
    print(f"  LLM Gateway       : {llm_public}")
    print(f"    POST  /api/llm/complete — LLM completion")
    print(f"    GET   /api/llm/health   — provider status")
    print()
    print(f"  Monte Carlo       : {mc_public}")
    print(f"    POST  /api/mc/simulate  — run simulation")
    print(f"    GET   /api/mc/health    — engine status")
    print()
    print(f"  Node ID           : {NODE_ID}")
    print(f"  Health tick       : every φ^4 = {PHI4:.2f}s")
    print("═" * 65 + "\n")


print_endpoints()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 11: Health check loop + state persistence ---
# ═══════════════════════════════════════════════════════════════════════════════

_shutdown_flag = threading.Event()
_last_persist  = time.time()


def _probe_local_port(port: int, path: str = "/health") -> bool:
    """Return True if the local service on *port* responds OK."""
    try:
        with urllib.request.urlopen(
            f"http://localhost:{port}{path}", timeout=3
        ) as resp:
            data = json.loads(resp.read())
            return data.get("ok", data.get("status") == "ok")
    except Exception:
        return False


def _persist_state_to_drive() -> None:
    """Write a checkpoint JSON to Google Drive (best-effort)."""
    try:
        checkpoint = {
            "node_id":    NODE_ID,
            "role":       NODE_ROLE,
            "timestamp":  time.time(),
            "tunnel_urls": _tunnel_urls,
            "ports": {"embed": PORT_EMBED, "llm": PORT_LLM, "mc": PORT_MC},
        }
        save_dir = Path(_GDRIVE) / "checkpoints"
        save_dir.mkdir(parents=True, exist_ok=True)
        ckpt_path = save_dir / f"node1_{NODE_ID}.json"
        ckpt_path.write_text(json.dumps(checkpoint, indent=2))
        log.debug("State persisted to %s", ckpt_path)
    except Exception as e:
        log.debug("State persist skipped: %s", e)


def _health_check_loop() -> None:
    """
    Run every φ^4 seconds:
     1. Probe all local services
     2. Re-register with Conductor if needed
     3. Persist state to Drive every φ^6 seconds
    """
    global _last_persist
    _registered = False
    log.info("Health-check loop started (interval=%.2fs)", PHI4)

    while not _shutdown_flag.is_set():
        try:
            embed_ok = _probe_local_port(PORT_EMBED, "/health")
            llm_ok   = _probe_local_port(PORT_LLM,   "/api/llm/health")
            mc_ok    = _probe_local_port(PORT_MC,     "/api/mc/health")

            status_line = (
                f"[BRAIN] embed={'✓' if embed_ok else '✗'}"
                f"  llm={'✓' if llm_ok else '✗'}"
                f"  mc={'✓' if mc_ok else '✗'}"
                f"  t={time.strftime('%H:%M:%S')}"
            )
            print(status_line, flush=True)

            # Re-register if conductor didn't ack last time
            if not _registered:
                _registered = register_with_conductor(_conductor_url, retries=1)

            # Persist to Drive on interval
            now = time.time()
            if now - _last_persist >= PERSIST_INTERVAL:
                _persist_state_to_drive()
                _last_persist = now

        except Exception as e:
            log.warning("Health-check iteration error: %s", e)

        _shutdown_flag.wait(timeout=PHI4)

    log.info("Health-check loop exited")


def _graceful_shutdown(*_args: Any) -> None:
    """Signal handler — persist state then set shutdown flag."""
    print("\n⚠  Shutdown signal received — persisting state to Drive …")
    _persist_state_to_drive()
    _shutdown_flag.set()
    print("✓  State saved.  Goodbye.")


# Register signal handlers for Colab disconnect / SIGTERM / SIGINT
for _sig in (signal.SIGTERM, signal.SIGINT):
    try:
        signal.signal(_sig, _graceful_shutdown)
    except (OSError, ValueError):
        pass  # Not in main thread — handled via atexit

import atexit
atexit.register(_persist_state_to_drive)


print("🔄  Starting health-check loop (Ctrl-C or Colab disconnect will save state) …\n")
_health_loop_thread = threading.Thread(
    target=_health_check_loop, daemon=False, name="health-loop"
)
_health_loop_thread.start()

# Block this script until shutdown (non-daemon thread keeps process alive)
try:
    _health_loop_thread.join()
except KeyboardInterrupt:
    _graceful_shutdown()
