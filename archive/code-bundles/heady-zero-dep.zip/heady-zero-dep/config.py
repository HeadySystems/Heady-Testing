"""
config.py
=========
Master configuration for the Heady Zero-Dep system.

All constants are φ-derived where applicable (φ = 1.6180339887...).

Environment variables override every default.  Import this module early
in each node script — it will call load_env() automatically so that a
.env file in the working directory is respected.

Usage::

    from config import cfg

    print(cfg.NODE1_URL)           # "http://localhost:8001"
    print(cfg.PHI4)                # ≈ 6.854
    print(cfg.ENVIRONMENT)         # "colab" | "local" | "cloud"

All values on ``cfg`` are also available as module-level names for
quick ``from config import X`` imports.
"""

from __future__ import annotations

import math
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Dict, Optional

# ---------------------------------------------------------------------------
# Load .env early (before any value reads)
# ---------------------------------------------------------------------------

def _safe_load_env() -> None:
    """Load .env if core.env_loader is available; fall back to os.environ."""
    try:
        from core.env_loader import load_env
        load_env()
    except Exception:
        pass  # env already in os.environ, or running without core module


_safe_load_env()

# ---------------------------------------------------------------------------
# φ-derived constants
# ---------------------------------------------------------------------------

PHI: float = 1.6180339887498948482   # golden ratio (exact to 19 digits)
PHI_INV: float = 1.0 / PHI           # ≈ 0.6180339887  (= φ − 1)
PHI2: float = PHI ** 2               # ≈ 2.618
PHI3: float = PHI ** 3               # ≈ 4.236
PHI4: float = PHI ** 4               # ≈ 6.854   ← health-check interval (s)
PHI5: float = PHI ** 5               # ≈ 11.090
PHI6: float = PHI ** 6               # ≈ 17.944
PHI7: float = PHI ** 7               # ≈ 29.034
PHI8: float = PHI ** 8               # ≈ 46.979
PHI9: float = PHI ** 9               # ≈ 76.013
PHI10: float = PHI ** 10             # ≈ 122.992
PHI12: float = PHI ** 12             # ≈ 321.997

# Priority pool quotas (φ-derived fractions, sum to 1.0)
POOL_HOT: float      = round(PHI / (PHI + 1 + PHI_INV + PHI_INV ** 2 + PHI_INV ** 3), 3)  # ≈ 0.340
POOL_WARM: float     = round(1.0   / (PHI + 1 + PHI_INV + PHI_INV ** 2 + PHI_INV ** 3), 3)  # ≈ 0.210
POOL_COLD: float     = round(PHI_INV / (PHI + 1 + PHI_INV + PHI_INV ** 2 + PHI_INV ** 3), 3)  # ≈ 0.130
POOL_RESERVE: float  = round((PHI_INV ** 2) / (PHI + 1 + PHI_INV + PHI_INV ** 2 + PHI_INV ** 3), 3)  # ≈ 0.080
POOL_GOVERNANCE: float = round((PHI_INV ** 3) / (PHI + 1 + PHI_INV + PHI_INV ** 2 + PHI_INV ** 3), 3)  # ≈ 0.050

# Fibonacci shard count (5 shards, matching vector_memory.py)
FIBONACCI_SHARDS: int = 5

# Monte Carlo default run count (φ^8 ≈ 47)
MC_DEFAULT_RUNS: int = int(PHI8)      # 46

# ---------------------------------------------------------------------------
# Environment detection
# ---------------------------------------------------------------------------

def _detect_environment() -> str:
    """Return 'colab', 'local', or 'cloud'."""
    # Google Colab sets a specific env var
    if os.path.exists("/content") and os.path.exists("/usr/local/lib/python3/dist-packages"):
        return "colab"
    try:
        import google.colab  # type: ignore  # noqa: F401
        return "colab"
    except ImportError:
        pass
    # Detect GCE / Cloud Run / Lambda / etc.
    cloud_hints = [
        "GCP_PROJECT", "GOOGLE_CLOUD_PROJECT", "AWS_EXECUTION_ENV",
        "LAMBDA_TASK_ROOT", "K_SERVICE", "CLOUD_RUN_JOB",
    ]
    if any(os.getenv(k) for k in cloud_hints):
        return "cloud"
    return "local"


ENVIRONMENT: str = os.getenv("HEADY_ENV", _detect_environment())
IS_COLAB: bool   = ENVIRONMENT == "colab"
IS_LOCAL: bool   = ENVIRONMENT == "local"
IS_CLOUD: bool   = ENVIRONMENT == "cloud"

# ---------------------------------------------------------------------------
# Node identity
# ---------------------------------------------------------------------------

NODE_ID: str    = os.getenv("HEADY_NODE_ID", "unknown")   # overridden per node script
NODE_NAME: str  = os.getenv("HEADY_NODE_NAME", "heady")

# ---------------------------------------------------------------------------
# Port assignments
# ---------------------------------------------------------------------------

PORT_CONDUCTOR: int     = int(os.getenv("PORT_CONDUCTOR",     "8000"))  # Node 3 — API Gateway
PORT_EMBED: int         = int(os.getenv("PORT_EMBED",         "8001"))  # Node 1 — Embedding Server
PORT_LLM: int           = int(os.getenv("PORT_LLM",           "8002"))  # Node 1 — LLM Gateway
PORT_MEMORY: int        = int(os.getenv("PORT_MEMORY",        "8003"))  # Node 2 — Vector Memory
PORT_MC: int            = int(os.getenv("PORT_MC",            "8004"))  # Node 1 — Monte Carlo (internal)
PORT_METRICS: int       = int(os.getenv("PORT_METRICS",       "9090"))  # Prometheus-style metrics (optional)

# ---------------------------------------------------------------------------
# Node URLs (configurable via env — set after tunnel is established)
# ---------------------------------------------------------------------------

NODE1_HOST: str  = os.getenv("HEADY_NODE1_HOST", "localhost")
NODE2_HOST: str  = os.getenv("HEADY_NODE2_HOST", "localhost")
NODE3_HOST: str  = os.getenv("HEADY_NODE3_HOST", "localhost")

NODE1_URL: str   = os.getenv("HEADY_NODE1_URL",  f"http://{NODE1_HOST}:{PORT_EMBED}")
NODE2_URL: str   = os.getenv("HEADY_NODE2_URL",  f"http://{NODE2_HOST}:{PORT_MEMORY}")
NODE3_URL: str   = os.getenv("HEADY_NODE3_URL",  f"http://{NODE3_HOST}:{PORT_CONDUCTOR}")

# Public tunnel URLs (filled in at runtime by each node)
NODE1_TUNNEL_URL: str  = os.getenv("HEADY_NODE1_TUNNEL", "")
NODE2_TUNNEL_URL: str  = os.getenv("HEADY_NODE2_TUNNEL", "")
NODE3_TUNNEL_URL: str  = os.getenv("HEADY_NODE3_TUNNEL", "")

# ---------------------------------------------------------------------------
# Timeouts (seconds, φ-derived tiers)
# ---------------------------------------------------------------------------

TIMEOUT_FAST: float     = PHI2          # ≈ 2.6s  — health checks, cache hits
TIMEOUT_NORMAL: float   = PHI4          # ≈ 6.9s  — normal API calls
TIMEOUT_LONG: float     = PHI6          # ≈ 17.9s — LLM generation
TIMEOUT_EXTENDED: float = PHI8          # ≈ 47.0s — large batch operations
TIMEOUT_MAX: float      = PHI10         # ≈ 123s  — pipeline completion

# Circuit breaker settings
CB_FAILURE_THRESHOLD: int     = 3
CB_COOLDOWN_BASE: float        = PHI4       # ≈ 6.85s
CB_COOLDOWN_MAX: float         = PHI10      # ≈ 123s
CB_HALF_OPEN_PROBE_INTERVAL: float = PHI6   # ≈ 17.9s

# ---------------------------------------------------------------------------
# Connection pools
# ---------------------------------------------------------------------------

DB_POOL_SIZE: int       = int(PHI3)     # 4 connections
HTTP_POOL_SIZE: int     = int(PHI5)     # 11 connections
EMBED_BATCH_MAX: int    = 512
LLM_MAX_TOKENS: int     = int(os.getenv("LLM_MAX_TOKENS", "4096"))
LLM_TEMPERATURE: float  = float(os.getenv("LLM_TEMPERATURE", "0.7"))

# ---------------------------------------------------------------------------
# Memory / Storage
# ---------------------------------------------------------------------------

DATA_DIR: str            = os.getenv("HEADY_DATA_DIR",     "data")
DB_PATH: str             = os.getenv("HEADY_DB_PATH",      f"{DATA_DIR}/heady.db")
VECTOR_STORE_DIR: str    = os.getenv("HEADY_VECTOR_DIR",   f"{DATA_DIR}/vectors")
CACHE_DIR: str           = os.getenv("HEADY_CACHE_DIR",    f"{DATA_DIR}/cache")
LOG_DIR: str             = os.getenv("HEADY_LOG_DIR",      f"{DATA_DIR}/logs")

# Google Drive mount point (Colab)
GDRIVE_MOUNT: str        = os.getenv("GDRIVE_MOUNT",       "/content/drive")
GDRIVE_HEADY_DIR: str    = os.getenv("GDRIVE_HEADY_DIR",   f"{GDRIVE_MOUNT}/MyDrive/heady-zero-dep")

# Persistence interval (seconds) — φ^6 ≈ 17.9s
PERSIST_INTERVAL: float  = float(os.getenv("PERSIST_INTERVAL", str(PHI6)))

# Maintenance loop interval (seconds) — φ^7 ≈ 29.0s
MAINTENANCE_INTERVAL: float = float(os.getenv("MAINTENANCE_INTERVAL", str(PHI7)))

# Health check interval — φ^4 ≈ 6.85s
HEALTH_CHECK_INTERVAL: float = float(os.getenv("HEALTH_CHECK_INTERVAL", str(PHI4)))

# ---------------------------------------------------------------------------
# Vector Memory tuning
# ---------------------------------------------------------------------------

VECTOR_DIM: int              = 384
STM_CAPACITY: int            = int(PHI7)   # ≈ 29 entries in short-term memory
LTM_CONSOLIDATION_THRESHOLD: float = 0.5  # importance score to promote to LTM
DENSITY_GATE_THRESHOLD: float = 0.97       # reject memories more similar than this
DRIFT_WINDOW: int            = int(PHI6)   # ≈ 18 samples for drift calculation
ZONE_COHERENCE_THRESHOLD: float = 0.40    # alert if zone coherence drops below

# Memory importance weights (α·Freq + β·e^(-γ·Δt) + δ·Surp)
MEM_ALPHA: float = 0.3
MEM_BETA: float  = 0.4
MEM_GAMMA: float = 1e-5
MEM_DELTA: float = 0.3

# ---------------------------------------------------------------------------
# Tunnel configuration
# ---------------------------------------------------------------------------

NGROK_TOKEN: str       = os.getenv("NGROK_TOKEN",      "")
CLOUDFLARE_TOKEN: str  = os.getenv("CLOUDFLARE_TOKEN", "")
TUNNEL_PROVIDER: str   = os.getenv("TUNNEL_PROVIDER",  "auto")  # auto | ngrok | cloudflared | none

# ---------------------------------------------------------------------------
# LLM providers
# ---------------------------------------------------------------------------

OPENAI_API_KEY: str         = os.getenv("OPENAI_API_KEY",    "")
ANTHROPIC_API_KEY: str      = os.getenv("ANTHROPIC_API_KEY", "")
GEMINI_API_KEY: str         = os.getenv("GEMINI_API_KEY",    "")
GROQ_API_KEY: str           = os.getenv("GROQ_API_KEY",      "")
PERPLEXITY_API_KEY: str     = os.getenv("PERPLEXITY_API_KEY","")
OLLAMA_BASE_URL: str        = os.getenv("OLLAMA_BASE_URL",   "http://localhost:11434")

DEFAULT_LLM_PROVIDER: str   = os.getenv("DEFAULT_LLM_PROVIDER", "openai")
DEFAULT_LLM_MODEL: str      = os.getenv("DEFAULT_LLM_MODEL",    "gpt-4o-mini")

# ---------------------------------------------------------------------------
# GitHub / external integrations
# ---------------------------------------------------------------------------

GITHUB_TOKEN: str           = os.getenv("GITHUB_TOKEN",      "")
GITHUB_REPO: str            = os.getenv("GITHUB_REPO",       "")

# ---------------------------------------------------------------------------
# Feature flags
# ---------------------------------------------------------------------------

FEATURE_GRAPH_RAG: bool      = os.getenv("FEATURE_GRAPH_RAG",      "true").lower()  == "true"
FEATURE_MONTE_CARLO: bool    = os.getenv("FEATURE_MONTE_CARLO",    "true").lower()  == "true"
FEATURE_3D_MAP: bool         = os.getenv("FEATURE_3D_MAP",         "true").lower()  == "true"
FEATURE_DRIFT_DETECT: bool   = os.getenv("FEATURE_DRIFT_DETECT",   "true").lower()  == "true"
FEATURE_AUTO_MAINTAIN: bool  = os.getenv("FEATURE_AUTO_MAINTAIN",  "true").lower()  == "true"
FEATURE_BEE_FACTORY: bool    = os.getenv("FEATURE_BEE_FACTORY",    "true").lower()  == "true"
FEATURE_SWARM: bool          = os.getenv("FEATURE_SWARM",          "true").lower()  == "true"
FEATURE_MCP: bool            = os.getenv("FEATURE_MCP",            "true").lower()  == "true"
FEATURE_TELEMETRY: bool      = os.getenv("FEATURE_TELEMETRY",      "true").lower()  == "true"
FEATURE_CIRCUIT_BREAKER: bool = os.getenv("FEATURE_CIRCUIT_BREAKER","true").lower() == "true"

# Debug / verbose logging
DEBUG: bool = os.getenv("HEADY_DEBUG", "false").lower() == "true"
LOG_LEVEL: str = os.getenv("HEADY_LOG_LEVEL", "DEBUG" if DEBUG else "INFO")

# ---------------------------------------------------------------------------
# Conductor / Pipeline settings
# ---------------------------------------------------------------------------

CONDUCTOR_MAX_RETRIES: int     = 3
CONDUCTOR_ARENA_MODE: bool     = os.getenv("CONDUCTOR_ARENA_MODE", "false").lower() == "true"
PIPELINE_TIMEOUT: float        = TIMEOUT_MAX
PIPELINE_STAGE_TIMEOUT: float  = TIMEOUT_LONG

# Bee Factory
BEE_MAX_WORKERS: int           = int(os.getenv("BEE_MAX_WORKERS", "8"))
BEE_IDLE_TIMEOUT: float        = PHI8    # ≈ 47s before idle bee is reaped

# Swarm
SWARM_MAX_MEMBERS: int         = int(os.getenv("SWARM_MAX_MEMBERS", "16"))
SWARM_CONSENSUS: str           = os.getenv("SWARM_CONSENSUS", "majority")

# MCP Protocol
MCP_SSE_KEEPALIVE: float       = PHI5    # ≈ 11s
MCP_MAX_TOOLS: int             = 128

# ---------------------------------------------------------------------------
# Node registration / discovery
# ---------------------------------------------------------------------------

REGISTRATION_TIMEOUT: float    = TIMEOUT_EXTENDED
NODE_DISCOVERY_INTERVAL: float = PHI5    # ≈ 11s — how often conductor polls for new nodes
NODE_HEARTBEAT_INTERVAL: float = PHI4    # ≈ 6.85s

# ---------------------------------------------------------------------------
# Config dataclass — single importable object
# ---------------------------------------------------------------------------

@dataclass
class HeadyConfig:
    """
    Convenience dataclass that mirrors all module-level constants.

    Instantiated once as ``cfg`` at the bottom of this file.
    Values are read at instantiation time from os.environ (already loaded).
    """

    # φ constants
    phi: float = PHI
    phi4: float = PHI4
    phi6: float = PHI6
    phi8: float = PHI8

    # Environment
    environment: str = ENVIRONMENT
    is_colab: bool = IS_COLAB
    is_local: bool = IS_LOCAL
    is_cloud: bool = IS_CLOUD

    # Node identity
    node_id: str = NODE_ID
    node_name: str = NODE_NAME

    # Ports
    port_conductor: int = PORT_CONDUCTOR
    port_embed: int     = PORT_EMBED
    port_llm: int       = PORT_LLM
    port_memory: int    = PORT_MEMORY

    # URLs
    node1_url: str = NODE1_URL
    node2_url: str = NODE2_URL
    node3_url: str = NODE3_URL

    # Timeouts
    timeout_fast: float     = TIMEOUT_FAST
    timeout_normal: float   = TIMEOUT_NORMAL
    timeout_long: float     = TIMEOUT_LONG
    timeout_extended: float = TIMEOUT_EXTENDED

    # Paths
    data_dir: str          = DATA_DIR
    db_path: str           = DB_PATH
    vector_store_dir: str  = VECTOR_STORE_DIR
    gdrive_heady_dir: str  = GDRIVE_HEADY_DIR

    # Intervals
    health_check_interval: float   = HEALTH_CHECK_INTERVAL
    persist_interval: float        = PERSIST_INTERVAL
    maintenance_interval: float    = MAINTENANCE_INTERVAL

    # Feature flags
    feature_graph_rag: bool     = FEATURE_GRAPH_RAG
    feature_monte_carlo: bool   = FEATURE_MONTE_CARLO
    feature_3d_map: bool        = FEATURE_3D_MAP
    feature_auto_maintain: bool = FEATURE_AUTO_MAINTAIN
    feature_bee_factory: bool   = FEATURE_BEE_FACTORY
    feature_swarm: bool         = FEATURE_SWARM
    feature_mcp: bool           = FEATURE_MCP

    # Misc
    debug: bool      = DEBUG
    log_level: str   = LOG_LEVEL

    # Tunnel
    ngrok_token: str       = NGROK_TOKEN
    cloudflare_token: str  = CLOUDFLARE_TOKEN
    tunnel_provider: str   = TUNNEL_PROVIDER

    # LLM keys (never log these)
    openai_api_key: str     = OPENAI_API_KEY
    anthropic_api_key: str  = ANTHROPIC_API_KEY
    gemini_api_key: str     = GEMINI_API_KEY
    groq_api_key: str       = GROQ_API_KEY

    def has_llm(self) -> bool:
        """Return True if at least one LLM provider key is configured."""
        return bool(
            self.openai_api_key or self.anthropic_api_key
            or self.gemini_api_key or self.groq_api_key
        )

    def has_tunnel(self) -> bool:
        """Return True if a tunnel token is available."""
        return bool(self.ngrok_token or self.cloudflare_token)

    def node_urls(self) -> Dict[str, str]:
        return {"node1": self.node1_url, "node2": self.node2_url, "node3": self.node3_url}

    def summary(self) -> str:
        lines = [
            "╔═══════════════════ Heady Config ═══════════════════╗",
            f"  Environment  : {self.environment}",
            f"  Node1 URL    : {self.node1_url}",
            f"  Node2 URL    : {self.node2_url}",
            f"  Node3 URL    : {self.node3_url}",
            f"  φ^4 (tick)   : {self.phi4:.3f}s",
            f"  Debug        : {self.debug}",
            f"  LLM ready    : {self.has_llm()}",
            f"  Tunnel ready : {self.has_tunnel()}",
            f"  Graph RAG    : {self.feature_graph_rag}",
            f"  Monte Carlo  : {self.feature_monte_carlo}",
            f"  Bee Factory  : {self.feature_bee_factory}",
            "╚════════════════════════════════════════════════════╝",
        ]
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Global singleton
# ---------------------------------------------------------------------------

cfg = HeadyConfig()

# ---------------------------------------------------------------------------
# Convenience re-exports (so ``from config import PORT_EMBED`` still works)
# ---------------------------------------------------------------------------
# All module-level names defined above are already importable directly.
# The ``cfg`` object is the recommended way for new code.
