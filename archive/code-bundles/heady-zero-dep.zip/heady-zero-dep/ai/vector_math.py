"""
vector_math.py
==============
Pure-Python vector math library — zero external dependencies.
Replaces numpy for 384-dimensional embedding operations used throughout Heady.

All functions operate on Python lists/tuples. The golden ratio φ = 1.6180339887
is used as a scaling constant in several projection utilities.

Thread-safety: all functions are stateless and purely functional.
"""

import math
from typing import List, Tuple, Union, Sequence

# ─── Constants ────────────────────────────────────────────────────────────────

PHI: float = 1.6180339887          # golden ratio
PHI_INV: float = 1.0 / PHI         # 1/φ ≈ 0.618
EMBEDDING_DIM: int = 384            # default sentence-transformer output dim

Vector = List[float]
Matrix = List[List[float]]


# ─── Basic Operations ─────────────────────────────────────────────────────────

def dot_product(a: Sequence[float], b: Sequence[float]) -> float:
    """
    Compute the dot product of two equal-length vectors.

    Args:
        a: First vector (list or tuple of floats).
        b: Second vector (list or tuple of floats).

    Returns:
        Scalar dot product Σ(aᵢ · bᵢ).

    Raises:
        ValueError: If vectors differ in length.
    """
    if len(a) != len(b):
        raise ValueError(f"Vector length mismatch: {len(a)} vs {len(b)}")
    return sum(x * y for x, y in zip(a, b))


def magnitude(vec: Sequence[float]) -> float:
    """
    Compute the L2 (Euclidean) magnitude (norm) of a vector.

    Args:
        vec: Input vector.

    Returns:
        Non-negative scalar magnitude ‖vec‖₂.
    """
    return math.sqrt(sum(x * x for x in vec))


def normalize(vec: Sequence[float]) -> Vector:
    """
    Return the unit vector (L2-normalized) in the direction of *vec*.

    If the vector is the zero vector, return a zero vector of the same
    length (to avoid division-by-zero errors).

    Args:
        vec: Input vector.

    Returns:
        Unit vector with ‖result‖₂ ≈ 1.0, or zero vector if ‖vec‖₂ == 0.
    """
    mag = magnitude(vec)
    if mag == 0.0:
        return [0.0] * len(vec)
    inv = 1.0 / mag
    return [x * inv for x in vec]


def cosine_similarity(a: Sequence[float], b: Sequence[float]) -> float:
    """
    Compute cosine similarity between two vectors.

    cosine_similarity(a, b) = (a · b) / (‖a‖ · ‖b‖)

    Returns a value in [-1, 1].  Returns 0.0 if either vector is zero.

    Args:
        a: First vector.
        b: Second vector.

    Returns:
        Cosine similarity in [-1.0, 1.0].
    """
    if len(a) != len(b):
        raise ValueError(f"Vector length mismatch: {len(a)} vs {len(b)}")
    mag_a = magnitude(a)
    mag_b = magnitude(b)
    if mag_a == 0.0 or mag_b == 0.0:
        return 0.0
    return dot_product(a, b) / (mag_a * mag_b)


def euclidean_distance(a: Sequence[float], b: Sequence[float]) -> float:
    """
    Compute the Euclidean (L2) distance between two vectors.

    Args:
        a: First vector.
        b: Second vector.

    Returns:
        Non-negative scalar distance.
    """
    if len(a) != len(b):
        raise ValueError(f"Vector length mismatch: {len(a)} vs {len(b)}")
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def vector_add(a: Sequence[float], b: Sequence[float]) -> Vector:
    """
    Element-wise vector addition: a + b.

    Args:
        a: First vector.
        b: Second vector.

    Returns:
        New vector where result[i] = a[i] + b[i].
    """
    if len(a) != len(b):
        raise ValueError(f"Vector length mismatch: {len(a)} vs {len(b)}")
    return [x + y for x, y in zip(a, b)]


def vector_subtract(a: Sequence[float], b: Sequence[float]) -> Vector:
    """
    Element-wise vector subtraction: a - b.

    Args:
        a: First vector.
        b: Second vector.

    Returns:
        New vector where result[i] = a[i] - b[i].
    """
    if len(a) != len(b):
        raise ValueError(f"Vector length mismatch: {len(a)} vs {len(b)}")
    return [x - y for x, y in zip(a, b)]


def vector_scale(vec: Sequence[float], scalar: float) -> Vector:
    """
    Multiply every element of *vec* by *scalar*.

    Args:
        vec: Input vector.
        scalar: Scaling factor.

    Returns:
        New scaled vector.
    """
    return [x * scalar for x in vec]


# ─── Matrix Operations ────────────────────────────────────────────────────────

def matrix_multiply(A: Matrix, B: Matrix) -> Matrix:
    """
    Basic matrix multiplication: C = A × B.

    Supports arbitrary shapes (m×k) @ (k×n) → (m×n).
    Pure Python — efficient enough for small projection matrices.

    Args:
        A: Matrix of shape (m, k) — list of rows.
        B: Matrix of shape (k, n) — list of rows.

    Returns:
        Result matrix of shape (m, n).

    Raises:
        ValueError: If inner dimensions don't match.
    """
    rows_A = len(A)
    cols_A = len(A[0]) if rows_A else 0
    rows_B = len(B)
    cols_B = len(B[0]) if rows_B else 0

    if cols_A != rows_B:
        raise ValueError(
            f"Shape mismatch: ({rows_A}×{cols_A}) @ ({rows_B}×{cols_B})"
        )

    result: Matrix = [[0.0] * cols_B for _ in range(rows_A)]
    for i in range(rows_A):
        for k in range(cols_A):
            if A[i][k] == 0.0:
                continue
            a_ik = A[i][k]
            for j in range(cols_B):
                result[i][j] += a_ik * B[k][j]
    return result


def matrix_vector_multiply(M: Matrix, v: Sequence[float]) -> Vector:
    """
    Multiply matrix M (m×n) by column vector v (n,) → result (m,).

    Args:
        M: Matrix of shape (m, n).
        v: Vector of length n.

    Returns:
        Vector of length m.
    """
    return [sum(M[i][j] * v[j] for j in range(len(v))) for i in range(len(M))]


def transpose(M: Matrix) -> Matrix:
    """
    Transpose a matrix (rows ↔ cols).

    Args:
        M: Matrix of shape (m, n).

    Returns:
        Transposed matrix of shape (n, m).
    """
    if not M:
        return []
    rows, cols = len(M), len(M[0])
    return [[M[r][c] for r in range(rows)] for c in range(cols)]


# ─── Statistical / Aggregate Operations ──────────────────────────────────────

def centroid(vectors: List[Sequence[float]]) -> Vector:
    """
    Compute the arithmetic mean (centroid) of a list of vectors.

    Args:
        vectors: Non-empty list of equal-length vectors.

    Returns:
        Centroid vector of the same dimension.

    Raises:
        ValueError: If *vectors* is empty.
    """
    if not vectors:
        raise ValueError("Cannot compute centroid of empty list")
    dim = len(vectors[0])
    n = len(vectors)
    result = [0.0] * dim
    for vec in vectors:
        for i, x in enumerate(vec):
            result[i] += x
    inv_n = 1.0 / n
    return [x * inv_n for x in result]


def weighted_centroid(
    vectors: List[Sequence[float]], weights: List[float]
) -> Vector:
    """
    Compute a weight-averaged centroid.

    Args:
        vectors: List of equal-length vectors.
        weights: Non-negative scalar weight for each vector.

    Returns:
        Weighted centroid vector.

    Raises:
        ValueError: If lengths differ or total weight is zero.
    """
    if len(vectors) != len(weights):
        raise ValueError("vectors and weights must have equal length")
    total = sum(weights)
    if total == 0.0:
        raise ValueError("Sum of weights must be non-zero")
    dim = len(vectors[0])
    result = [0.0] * dim
    for vec, w in zip(vectors, weights):
        for i, x in enumerate(vec):
            result[i] += x * w
    inv_total = 1.0 / total
    return [x * inv_total for x in result]


# ─── Dimensionality Reduction ─────────────────────────────────────────────────

def pca_lite_3d(embedding: Sequence[float]) -> Tuple[float, float, float]:
    """
    Project a 384-dimensional embedding to 3D via group-averaging (PCA-lite).

    The 384 dimensions are split into three contiguous groups of 128:
        x = mean(dims 0–127)
        y = mean(dims 128–255)
        z = mean(dims 256–383)

    This approximates a PCA projection while remaining O(n) and dependency-free.
    The result is NOT guaranteed to be unit-magnitude; normalize with
    ``to_spherical`` or ``normalize`` if needed.

    Args:
        embedding: 384-dim float vector (sentence-transformer output).

    Returns:
        (x, y, z) tuple of floats in the range of the embedding values.

    Raises:
        ValueError: If embedding length is not 384.
    """
    if len(embedding) != EMBEDDING_DIM:
        raise ValueError(
            f"Expected {EMBEDDING_DIM}-dim embedding, got {len(embedding)}"
        )
    group = EMBEDDING_DIM // 3  # 128
    x = sum(embedding[0:group]) / group
    y = sum(embedding[group:2 * group]) / group
    z = sum(embedding[2 * group:]) / group
    return (x, y, z)


def pca_lite_nd(embedding: Sequence[float], n_components: int = 3) -> Vector:
    """
    Generalised PCA-lite: project embedding to *n_components* dimensions
    by splitting into equal groups and averaging each.

    Args:
        embedding: Input vector (any length divisible by n_components).
        n_components: Target dimensionality.

    Returns:
        List of *n_components* floats.
    """
    dim = len(embedding)
    if dim % n_components != 0:
        # pad with zeros to make divisible
        pad = n_components - (dim % n_components)
        embedding = list(embedding) + [0.0] * pad
        dim = len(embedding)
    group = dim // n_components
    return [
        sum(embedding[i * group:(i + 1) * group]) / group
        for i in range(n_components)
    ]


# ─── Coordinate Conversions ───────────────────────────────────────────────────

def to_spherical(
    x: float, y: float, z: float
) -> Tuple[float, float, float]:
    """
    Convert Cartesian (x, y, z) to spherical coordinates (r, θ, φ).

    Returns:
        (r, theta, phi) where:
            r     = radial distance (‖vector‖)
            theta = polar angle from +z axis, in [0, π]  (radians)
            phi   = azimuthal angle in x-y plane from +x, in [0, 2π) (radians)
    """
    r = math.sqrt(x * x + y * y + z * z)
    if r == 0.0:
        return (0.0, 0.0, 0.0)
    theta = math.acos(max(-1.0, min(1.0, z / r)))  # clamp for float safety
    phi = math.atan2(y, x) % (2 * math.pi)
    return (r, theta, phi)


def from_spherical(r: float, theta: float, phi: float) -> Tuple[float, float, float]:
    """
    Convert spherical (r, θ, φ) back to Cartesian (x, y, z).

    Args:
        r:     Radial distance.
        theta: Polar angle in radians.
        phi:   Azimuthal angle in radians.

    Returns:
        (x, y, z) Cartesian coordinates.
    """
    sin_t = math.sin(theta)
    return (
        r * sin_t * math.cos(phi),
        r * sin_t * math.sin(phi),
        r * math.cos(theta),
    )


def to_isometric(
    x: float, y: float, z: float
) -> Tuple[float, float]:
    """
    Project 3D Cartesian coordinates to 2D isometric screen coordinates.

    Uses the standard dimetric isometric projection:
        screen_x =  (x - z) * cos(30°)
        screen_y = -y + (x + z) * sin(30°)

    Useful for rendering the 3D memory space in the Heady UI.

    Args:
        x, y, z: 3D Cartesian coordinates.

    Returns:
        (screen_x, screen_y) 2D projection.
    """
    cos30 = math.cos(math.radians(30))   # ≈ 0.8660
    sin30 = 0.5
    screen_x = (x - z) * cos30
    screen_y = -y + (x + z) * sin30
    return (screen_x, screen_y)


# ─── Octant / Zone Utilities ──────────────────────────────────────────────────

def octant_id(x: float, y: float, z: float) -> int:
    """
    Return the octant index (0–7) for the given 3D coordinates.

    Octant encoding:
        bit 2 = sign(x) > 0  (1 = positive x)
        bit 1 = sign(y) > 0  (1 = positive y)
        bit 0 = sign(z) > 0  (1 = positive z)

    Args:
        x, y, z: 3D coordinates.

    Returns:
        Integer in [0, 7].
    """
    return (
        (4 if x >= 0 else 0) |
        (2 if y >= 0 else 0) |
        (1 if z >= 0 else 0)
    )


def adjacent_octants(octant: int) -> List[int]:
    """
    Return the list of octant IDs that share a face/edge with *octant*.

    Each octant has 7 neighbours (all others), but we return only the
    3 face-adjacent ones first (differ by exactly 1 bit), then the
    3 edge-adjacent (differ by 2 bits), then the 1 vertex-opposite.

    Args:
        octant: Source octant (0–7).

    Returns:
        List of 7 neighbour octant IDs ordered by proximity.
    """
    by_hamming: List[Tuple[int, int]] = []
    for other in range(8):
        if other == octant:
            continue
        diff = bin(octant ^ other).count("1")
        by_hamming.append((diff, other))
    by_hamming.sort()
    return [o for _, o in by_hamming]


# ─── Fibonacci Shard Utilities ────────────────────────────────────────────────

_FIB5 = [1, 1, 2, 3, 5]  # first 5 Fibonacci numbers for consistent mapping

def fibonacci_shard(vec_id: str, n_shards: int = 5) -> int:
    """
    Map a vector ID to one of *n_shards* shards using a Fibonacci-modulo hash.

    This distributes keys across shards with a low collision rate while being
    entirely deterministic and dependency-free.

    Args:
        vec_id:   String identifier of the vector/memory.
        n_shards: Number of parallel shards (default 5).

    Returns:
        Shard index in [0, n_shards).
    """
    h = 0
    fib = _FIB5[: min(n_shards, len(_FIB5))]
    for i, ch in enumerate(vec_id):
        h = (h * fib[i % len(fib)] + ord(ch)) % (2 ** 32)
    return h % n_shards


# ─── Similarity / Distance Batch Utilities ────────────────────────────────────

def top_k_similar(
    query: Sequence[float],
    candidates: List[Tuple[str, Sequence[float]]],
    k: int = 10,
) -> List[Tuple[str, float]]:
    """
    Return the top-k most similar vectors to *query* by cosine similarity.

    Args:
        query:      Query embedding vector.
        candidates: List of (id, vector) pairs to compare against.
        k:          Maximum number of results to return.

    Returns:
        List of (id, similarity) pairs sorted descending by similarity.
    """
    scored = [
        (vid, cosine_similarity(query, vec))
        for vid, vec in candidates
    ]
    scored.sort(key=lambda t: t[1], reverse=True)
    return scored[:k]


def pairwise_distance_matrix(
    vectors: List[Sequence[float]],
) -> Matrix:
    """
    Compute the full pairwise Euclidean distance matrix (n×n).

    Args:
        vectors: List of n equal-length vectors.

    Returns:
        Symmetric matrix D where D[i][j] = euclidean_distance(vectors[i], vectors[j]).
    """
    n = len(vectors)
    D: Matrix = [[0.0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            d = euclidean_distance(vectors[i], vectors[j])
            D[i][j] = d
            D[j][i] = d
    return D
