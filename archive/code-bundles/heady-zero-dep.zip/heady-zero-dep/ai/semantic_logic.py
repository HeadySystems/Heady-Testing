"""
semantic_logic.py
=================
Core Semantic Logic (CSL) module for Heady.

Provides high-level semantic reasoning primitives built on top of vector_math.
All operations are pure Python with zero external dependencies.

Primary concepts:
  - Resonance Gate: threshold-based semantic gating between two concepts
  - Drift Score: measure semantic drift over time / context shifts
  - Harmonic Mean Similarity: multi-vector coherence measure
  - Weighted Centroid: importance-weighted semantic center of a concept cluster

Thread-safety: all functions are stateless and purely functional.
"""

import math
from typing import Dict, List, Optional, Sequence, Tuple

from .vector_math import (
    cosine_similarity as _cos_sim,
    dot_product,
    magnitude,
    normalize,
    vector_subtract,
    weighted_centroid as _weighted_centroid,
    centroid,
)

# ─── Re-export for convenience ───────────────────────────────────────────────

Vector = List[float]


def cosine_similarity(a: Sequence[float], b: Sequence[float]) -> float:
    """
    Compute cosine similarity between two 384-dim embedding vectors.

    Optimized for 384-dim: avoids redundant magnitude calculations when both
    vectors are already unit-normalized (detected via ‖v‖ ≈ 1.0).

    Args:
        a: First embedding vector.
        b: Second embedding vector.

    Returns:
        Float in [-1.0, 1.0].  Higher = more semantically similar.
    """
    return _cos_sim(a, b)


# ─── Resonance Gate ───────────────────────────────────────────────────────────

def resonance_gate(
    vec_a: Sequence[float],
    vec_b: Sequence[float],
    threshold: float = 0.75,
) -> Dict[str, object]:
    """
    Determine whether two semantic vectors are in "resonance" — i.e., whether
    they are semantically close enough to be considered related.

    The gate is "open" when cosine_similarity(a, b) >= threshold.

    Args:
        vec_a:     First embedding vector.
        vec_b:     Second embedding vector.
        threshold: Minimum cosine similarity to open the gate (default 0.75).
                   Common values:
                     0.90+ → near-duplicate
                     0.75  → strongly related
                     0.60  → loosely related
                     <0.50 → unrelated

    Returns:
        Dict with:
            "open"       (bool)  – True if gate is open (resonating)
            "similarity" (float) – Raw cosine similarity
            "threshold"  (float) – The threshold used
            "delta"      (float) – similarity - threshold (positive = above gate)
    """
    sim = _cos_sim(vec_a, vec_b)
    return {
        "open": sim >= threshold,
        "similarity": sim,
        "threshold": threshold,
        "delta": sim - threshold,
    }


# ─── Semantic Distance ────────────────────────────────────────────────────────

def semantic_distance(a: Sequence[float], b: Sequence[float]) -> float:
    """
    Compute semantic distance as 1 - cosine_similarity.

    Returns a value in [0, 2]:
        0.0 = identical direction (maximum similarity)
        1.0 = orthogonal (no semantic overlap)
        2.0 = opposite direction (maximum dissimilarity)

    Args:
        a: First embedding vector.
        b: Second embedding vector.

    Returns:
        Semantic distance in [0.0, 2.0].
    """
    return 1.0 - _cos_sim(a, b)


# ─── Harmonic Mean Similarity ─────────────────────────────────────────────────

def harmonic_mean_similarity(vectors: List[Sequence[float]]) -> float:
    """
    Compute multi-vector coherence via the harmonic mean of pairwise similarities.

    The harmonic mean penalizes outlier pairs more harshly than the arithmetic
    mean, making it a better measure of *cluster coherence*.

    For n vectors, computes all C(n,2) pairwise cosine similarities, then
    returns their harmonic mean.

    Args:
        vectors: List of at least 2 embedding vectors of equal length.

    Returns:
        Harmonic mean similarity in [-1.0, 1.0].
        Returns 1.0 if only a single vector is provided (degenerate case).

    Raises:
        ValueError: If *vectors* is empty.
    """
    if not vectors:
        raise ValueError("vectors must be non-empty")
    if len(vectors) == 1:
        return 1.0

    pairwise: List[float] = []
    n = len(vectors)
    for i in range(n):
        for j in range(i + 1, n):
            sim = _cos_sim(vectors[i], vectors[j])
            pairwise.append(sim)

    if not pairwise:
        return 1.0

    # Harmonic mean: n / Σ(1/xᵢ)
    # Guard against zero or negative similarities (which would cause div-by-0)
    epsilon = 1e-9
    inv_sum = sum(1.0 / max(s, epsilon) for s in pairwise)
    return len(pairwise) / inv_sum


def arithmetic_mean_similarity(vectors: List[Sequence[float]]) -> float:
    """
    Compute the arithmetic mean of all pairwise cosine similarities.

    Args:
        vectors: List of at least 2 equal-length embedding vectors.

    Returns:
        Mean pairwise similarity in [-1.0, 1.0].
    """
    if len(vectors) < 2:
        return 1.0
    pairs, total = 0, 0.0
    n = len(vectors)
    for i in range(n):
        for j in range(i + 1, n):
            total += _cos_sim(vectors[i], vectors[j])
            pairs += 1
    return total / pairs if pairs else 1.0


# ─── Weighted Centroid ────────────────────────────────────────────────────────

def weighted_centroid(
    vectors: List[Sequence[float]], weights: List[float]
) -> Vector:
    """
    Compute the importance-weighted centroid of a cluster of embeddings.

    Wraps vector_math.weighted_centroid with semantic-layer documentation.

    Args:
        vectors: List of embedding vectors representing concepts in a cluster.
        weights: Non-negative scalar importance weight for each vector.
                 Higher weight pulls the centroid toward that vector.

    Returns:
        Weighted centroid vector of the same dimension as the inputs.

    Example:
        >>> vecs  = [embedding_A, embedding_B, embedding_C]
        >>> wts   = [0.5, 0.3, 0.2]  # A is most important
        >>> center = weighted_centroid(vecs, wts)
    """
    return _weighted_centroid(vectors, weights)


# ─── Drift Score ──────────────────────────────────────────────────────────────

def drift_score(
    baseline: Sequence[float],
    current: Sequence[float],
) -> float:
    """
    Measure how far *current* has semantically drifted from *baseline*.

    drift_score = semantic_distance(baseline, current)
               = 1 - cosine_similarity(baseline, current)

    Interpretation:
        0.00–0.05  → Negligible drift  (same concept)
        0.05–0.15  → Minor drift       (concept evolved slightly)
        0.15–0.35  → Moderate drift    (concept changed meaningfully)
        0.35–0.65  → Major drift       (significantly different concept)
        0.65+      → Concept replaced  (unrelated directions)

    Args:
        baseline: Reference/historical embedding snapshot.
        current:  Current embedding to compare against baseline.

    Returns:
        Drift value in [0.0, 2.0].  Lower = less drift.
    """
    return semantic_distance(baseline, current)


def drift_report(
    baseline: Sequence[float],
    current: Sequence[float],
    label: str = "",
) -> Dict[str, object]:
    """
    Generate a structured drift analysis report.

    Args:
        baseline: Reference embedding.
        current:  Current embedding.
        label:    Optional human-readable label for the concept being tracked.

    Returns:
        Dict with keys:
            "label"       – Label passed in
            "drift"       – Drift score (0–2)
            "similarity"  – Cosine similarity (1 - drift)
            "severity"    – One of: "negligible", "minor", "moderate",
                            "major", "replaced"
            "magnitude_change" – Difference in L2 norms
    """
    drift = drift_score(baseline, current)
    sim = 1.0 - drift

    if drift < 0.05:
        severity = "negligible"
    elif drift < 0.15:
        severity = "minor"
    elif drift < 0.35:
        severity = "moderate"
    elif drift < 0.65:
        severity = "major"
    else:
        severity = "replaced"

    return {
        "label": label,
        "drift": drift,
        "similarity": sim,
        "severity": severity,
        "magnitude_change": abs(magnitude(list(current)) - magnitude(list(baseline))),
    }


# ─── Cluster Coherence ────────────────────────────────────────────────────────

def cluster_coherence(vectors: List[Sequence[float]]) -> Dict[str, float]:
    """
    Compute a comprehensive coherence report for a cluster of embeddings.

    Args:
        vectors: List of embedding vectors in the cluster.

    Returns:
        Dict with:
            "harmonic_mean"    – Harmonic mean of pairwise similarities
            "arithmetic_mean"  – Arithmetic mean of pairwise similarities
            "min_similarity"   – Minimum pairwise similarity (weakest link)
            "max_similarity"   – Maximum pairwise similarity
            "centroid_radius"  – Mean distance of each vector from centroid
    """
    if len(vectors) < 2:
        return {
            "harmonic_mean": 1.0,
            "arithmetic_mean": 1.0,
            "min_similarity": 1.0,
            "max_similarity": 1.0,
            "centroid_radius": 0.0,
        }

    sims: List[float] = []
    n = len(vectors)
    for i in range(n):
        for j in range(i + 1, n):
            sims.append(_cos_sim(vectors[i], vectors[j]))

    center = centroid(list(vectors))
    radii = [semantic_distance(v, center) for v in vectors]

    epsilon = 1e-9
    inv_sum = sum(1.0 / max(s, epsilon) for s in sims)
    hm = len(sims) / inv_sum

    return {
        "harmonic_mean": hm,
        "arithmetic_mean": sum(sims) / len(sims),
        "min_similarity": min(sims),
        "max_similarity": max(sims),
        "centroid_radius": sum(radii) / len(radii),
    }


# ─── Surprise / Novelty ───────────────────────────────────────────────────────

def surprise_score(
    new_vec: Sequence[float],
    context_vectors: List[Sequence[float]],
) -> float:
    """
    Compute how "surprising" or novel *new_vec* is relative to the current
    context (a list of recent/relevant embeddings).

    Surprise = mean semantic distance from *new_vec* to all context vectors.
    Higher = more novel / unexpected relative to context.

    Args:
        new_vec:         The incoming embedding to evaluate.
        context_vectors: Recent context embeddings.

    Returns:
        Surprise score in [0.0, 2.0].  0 = fully expected, 2 = maximally novel.
    """
    if not context_vectors:
        return 1.0  # no context → neutral surprise
    distances = [semantic_distance(new_vec, cv) for cv in context_vectors]
    return sum(distances) / len(distances)


def resonance_field(
    query: Sequence[float],
    field_vectors: List[Tuple[str, Sequence[float]]],
    threshold: float = 0.65,
) -> List[Dict[str, object]]:
    """
    Find all vectors in *field_vectors* that resonate with *query*.

    Args:
        query:         Query embedding.
        field_vectors: List of (id, embedding) pairs.
        threshold:     Minimum cosine similarity (default 0.65).

    Returns:
        Sorted list of resonating entries, each a dict with:
            "id"         – Vector identifier
            "similarity" – Cosine similarity to query
            "delta"      – similarity - threshold
    """
    results = []
    for vid, vec in field_vectors:
        sim = _cos_sim(query, vec)
        if sim >= threshold:
            results.append({
                "id": vid,
                "similarity": sim,
                "delta": sim - threshold,
            })
    results.sort(key=lambda r: r["similarity"], reverse=True)  # type: ignore[arg-type]
    return results
