"""
monte_carlo.py
==============
Monte Carlo simulation engine for Heady task analysis.

Used to model uncertainty in task decomposition, estimate completion times,
and run multi-strategy "Battle Arena" evaluations.

Key features:
  - Task decomposition simulation with fractal recursion
  - Parallel simulation runs via ThreadPoolExecutor
  - Statistical analysis (mean, std, percentiles, confidence intervals)
  - φ-derived iteration timing (golden ratio pacing)
  - Battle Arena: run same task through N strategies, rank by outcome
  - Integration with VectorMemory to record simulation outcomes
  - Confidence scoring via bootstrap sampling

All simulation computations are pure Python (random, math, statistics).

Thread-safety: Simulator instances are thread-safe via internal Lock.
"""

import math
import random
import statistics
import threading
import time
import uuid
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, List, Optional, Tuple, Union

# ─── Constants ────────────────────────────────────────────────────────────────

PHI: float = 1.6180339887
PHI_INV: float = 1.0 / PHI
PHI2: float = PHI ** 2
PHI3: float = PHI ** 3

DEFAULT_RUNS: int = int(PHI ** 8)        # ≈ 46 runs
DEFAULT_MAX_DEPTH: int = int(PHI ** 4)   # ≈ 6 fractal levels
DEFAULT_WORKERS: int = 4
CONFIDENCE_ALPHA: float = 0.05           # 95% CI


# ─── Task Model ───────────────────────────────────────────────────────────────

class Task:
    """
    A task node in the fractal decomposition tree.

    Attributes:
        id:           Unique task identifier.
        name:         Human-readable label.
        complexity:   Estimated base complexity (arbitrary units).
        uncertainty:  Uncertainty factor in [0, 1].  0 = deterministic.
        subtasks:     Child tasks (populated by fractal decomposition).
        depth:        Depth in the decomposition tree (root = 0).
    """

    def __init__(
        self,
        name: str,
        complexity: float = 1.0,
        uncertainty: float = 0.3,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.id: str = str(uuid.uuid4())[:8]
        self.name: str = name
        self.complexity: float = max(0.01, complexity)
        self.uncertainty: float = max(0.0, min(1.0, uncertainty))
        self.subtasks: List["Task"] = []
        self.depth: int = 0
        self.metadata: Dict[str, Any] = metadata or {}

    def add_subtask(self, task: "Task") -> None:
        task.depth = self.depth + 1
        self.subtasks.append(task)

    def is_leaf(self) -> bool:
        return len(self.subtasks) == 0

    def total_complexity(self) -> float:
        """Recursively sum complexity across the whole tree."""
        if self.is_leaf():
            return self.complexity
        return self.complexity + sum(t.total_complexity() for t in self.subtasks)

    def __repr__(self) -> str:
        return f"Task(name={self.name!r}, complexity={self.complexity:.2f}, depth={self.depth})"


# ─── Fractal Decomposer ───────────────────────────────────────────────────────

class FractalDecomposer:
    """
    Recursively decomposes a task into subtasks using a fractal branching model.

    Each task spawns k sub-tasks where:
        k ~ Fibonacci(depth) mapped to [min_branch, max_branch]
        sub_complexity ≈ parent_complexity / (k * φ^depth)
        sub_uncertainty ≈ parent_uncertainty * φ^(depth * 0.2)

    The recursion terminates when:
        - Max depth is reached
        - Sub-task complexity falls below min_complexity
        - A random dice roll says this leaf doesn't split further
    """

    def __init__(
        self,
        max_depth: int = DEFAULT_MAX_DEPTH,
        min_complexity: float = 0.05,
        min_branch: int = 2,
        max_branch: int = 5,
        seed: Optional[int] = None,
    ) -> None:
        self.max_depth = max_depth
        self.min_complexity = min_complexity
        self.min_branch = min_branch
        self.max_branch = max_branch
        self._rng = random.Random(seed)

    def decompose(self, task: Task) -> Task:
        """
        Mutate *task* in-place by filling its subtask tree.

        Args:
            task: Root task to decompose.

        Returns:
            The same task with subtasks populated.
        """
        self._decompose_recursive(task)
        return task

    def _decompose_recursive(self, task: Task) -> None:
        if task.depth >= self.max_depth:
            return
        if task.complexity < self.min_complexity:
            return

        # Probability of splitting decreases with depth using φ
        split_prob = PHI_INV ** task.depth
        if self._rng.random() > split_prob:
            return  # leaf node

        # Number of branches: biased toward lower values at higher depth
        k_max = max(self.min_branch, self.max_branch - task.depth)
        k = self._rng.randint(self.min_branch, k_max)

        for i in range(k):
            # Each child gets 1/(k * φ^depth) of parent complexity + jitter
            base = task.complexity / (k * (PHI ** max(task.depth, 1)))
            jitter = self._rng.gauss(0, base * task.uncertainty * 0.2)
            child_complexity = max(self.min_complexity, base + jitter)

            # Uncertainty grows slightly with depth
            child_uncertainty = min(1.0, task.uncertainty * (1.0 + task.depth * 0.1))

            child = Task(
                name=f"{task.name}[{task.depth+1}.{i+1}]",
                complexity=child_complexity,
                uncertainty=child_uncertainty,
            )
            task.add_subtask(child)
            self._decompose_recursive(child)


# ─── Simulation Run ────────────────────────────────────────────────────────────

class SimulationOutcome:
    """Result of a single Monte Carlo run."""

    def __init__(
        self,
        run_id: int,
        total_time: float,
        total_cost: float,
        success: bool,
        node_count: int,
        max_depth_reached: int,
        bottleneck: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.run_id = run_id
        self.total_time = total_time
        self.total_cost = total_cost
        self.success = success
        self.node_count = node_count
        self.max_depth_reached = max_depth_reached
        self.bottleneck = bottleneck
        self.metadata = metadata or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "total_time": self.total_time,
            "total_cost": self.total_cost,
            "success": self.success,
            "node_count": self.node_count,
            "max_depth_reached": self.max_depth_reached,
            "bottleneck": self.bottleneck,
            **self.metadata,
        }


def _simulate_task(
    task: Task,
    rng: random.Random,
    time_per_unit: float = 1.0,
    cost_per_unit: float = 0.01,
    failure_rate: float = 0.05,
) -> Tuple[float, float, bool, int, int, Optional[str]]:
    """
    Simulate execution of a task tree.

    Returns:
        (total_time, total_cost, success, node_count, max_depth, bottleneck_name)
    """
    total_time = 0.0
    total_cost = 0.0
    node_count = 0
    max_depth = 0
    bottleneck: Optional[str] = None
    worst_time = 0.0

    stack = [task]
    while stack:
        t = stack.pop()
        node_count += 1
        max_depth = max(max_depth, t.depth)

        # Sample actual execution time with uncertainty
        sigma = t.complexity * t.uncertainty
        actual_time = max(0.0, rng.gauss(t.complexity, sigma)) * time_per_unit
        actual_cost = actual_time * cost_per_unit

        total_time += actual_time
        total_cost += actual_cost

        if actual_time > worst_time:
            worst_time = actual_time
            bottleneck = t.name

        stack.extend(t.subtasks)

    # Aggregate failure probability across nodes
    agg_failure = 1.0 - (1.0 - failure_rate) ** node_count
    success = rng.random() > agg_failure

    return total_time, total_cost, success, node_count, max_depth, bottleneck


# ─── Statistical Analysis ─────────────────────────────────────────────────────

class SimulationStats:
    """Aggregate statistics from a set of simulation outcomes."""

    def __init__(self, outcomes: List[SimulationOutcome]) -> None:
        self.outcomes = outcomes
        self.n = len(outcomes)
        self._times = [o.total_time for o in outcomes]
        self._costs = [o.total_cost for o in outcomes]
        self._successes = [o.success for o in outcomes]

    @property
    def success_rate(self) -> float:
        return sum(self._successes) / self.n if self.n else 0.0

    @property
    def mean_time(self) -> float:
        return statistics.mean(self._times) if self._times else 0.0

    @property
    def median_time(self) -> float:
        return statistics.median(self._times) if self._times else 0.0

    @property
    def std_time(self) -> float:
        return statistics.stdev(self._times) if len(self._times) > 1 else 0.0

    @property
    def mean_cost(self) -> float:
        return statistics.mean(self._costs) if self._costs else 0.0

    def percentile(self, field: str, p: float) -> float:
        """
        Return the p-th percentile (0–100) for 'time' or 'cost'.
        Uses linear interpolation.
        """
        data = sorted(self._times if field == "time" else self._costs)
        if not data:
            return 0.0
        idx = (p / 100.0) * (len(data) - 1)
        lo = int(idx)
        hi = min(lo + 1, len(data) - 1)
        frac = idx - lo
        return data[lo] * (1 - frac) + data[hi] * frac

    def confidence_interval(
        self, field: str = "time", alpha: float = CONFIDENCE_ALPHA
    ) -> Tuple[float, float]:
        """
        Compute a bootstrap 95% confidence interval for mean time or cost.

        Uses the percentile bootstrap method with 1000 resamples.

        Args:
            field: "time" or "cost"
            alpha: Significance level (default 0.05 → 95% CI)

        Returns:
            (lower_bound, upper_bound)
        """
        data = self._times if field == "time" else self._costs
        if len(data) < 2:
            m = data[0] if data else 0.0
            return (m, m)

        n_boot = 1000
        boot_means: List[float] = []
        rng = random.Random(42)
        for _ in range(n_boot):
            sample = [rng.choice(data) for _ in range(len(data))]
            boot_means.append(sum(sample) / len(sample))
        boot_means.sort()
        lo = boot_means[int(alpha / 2 * n_boot)]
        hi = boot_means[int((1 - alpha / 2) * n_boot)]
        return (lo, hi)

    @property
    def confidence_score(self) -> float:
        """
        Scalar confidence score in [0, 1] based on coefficient of variation
        and success rate.

        Higher = more predictable and reliable.
        """
        if self.mean_time == 0:
            return 0.0
        cv = self.std_time / self.mean_time  # coefficient of variation
        # Scale: CV of 0 → confidence 1.0; CV of 2 → confidence ~0.2
        cv_score = math.exp(-cv * PHI_INV)
        return cv_score * self.success_rate

    def to_dict(self) -> Dict[str, Any]:
        ci_time = self.confidence_interval("time")
        ci_cost = self.confidence_interval("cost")
        return {
            "n": self.n,
            "success_rate": round(self.success_rate, 4),
            "mean_time": round(self.mean_time, 4),
            "median_time": round(self.median_time, 4),
            "std_time": round(self.std_time, 4),
            "p10_time": round(self.percentile("time", 10), 4),
            "p50_time": round(self.percentile("time", 50), 4),
            "p90_time": round(self.percentile("time", 90), 4),
            "ci_time_lo": round(ci_time[0], 4),
            "ci_time_hi": round(ci_time[1], 4),
            "mean_cost": round(self.mean_cost, 6),
            "ci_cost_lo": round(ci_cost[0], 6),
            "ci_cost_hi": round(ci_cost[1], 6),
            "confidence_score": round(self.confidence_score, 4),
        }


# ─── Monte Carlo Simulator ────────────────────────────────────────────────────

class MonteCarloSimulator:
    """
    Run Monte Carlo simulations over a task tree.

    Usage:
        sim = MonteCarloSimulator(n_runs=200, n_workers=8)
        root = Task("Deploy new feature", complexity=10, uncertainty=0.4)
        stats = sim.run(root)
        print(stats.to_dict())
    """

    def __init__(
        self,
        n_runs: int = DEFAULT_RUNS,
        n_workers: int = DEFAULT_WORKERS,
        seed: Optional[int] = None,
        memory=None,   # Optional VectorMemory instance for recording outcomes
    ) -> None:
        """
        Args:
            n_runs:    Number of simulation runs.
            n_workers: Thread pool size for parallel runs.
            seed:      Master RNG seed (reproducible results).
            memory:    Optional VectorMemory to persist simulation records.
        """
        self.n_runs = n_runs
        self.n_workers = n_workers
        self._master_seed = seed or int(time.time() * PHI) % (2 ** 31)
        self._memory = memory
        self._lock = threading.Lock()

    def run(
        self,
        task: Task,
        time_per_unit: float = 1.0,
        cost_per_unit: float = 0.01,
        failure_rate: float = 0.05,
    ) -> SimulationStats:
        """
        Run *n_runs* Monte Carlo simulations of *task* in parallel.

        Uses FractalDecomposer to generate one decomposition tree per run,
        then simulates execution with sampled uncertainties.

        Args:
            task:           Root task to simulate.
            time_per_unit:  Time multiplier per complexity unit.
            cost_per_unit:  Cost multiplier per time unit.
            failure_rate:   Per-node failure probability.

        Returns:
            SimulationStats aggregating all outcomes.
        """
        outcomes: List[SimulationOutcome] = [None] * self.n_runs  # type: ignore

        def _run_one(run_id: int) -> SimulationOutcome:
            # Each run gets its own RNG seeded deterministically
            seed = (self._master_seed + run_id * int(PHI3)) % (2 ** 31)
            rng = random.Random(seed)

            # Fresh decomposition for this run
            import copy
            task_copy = copy.deepcopy(task)
            decomp = FractalDecomposer(seed=seed)
            decomp.decompose(task_copy)

            total_time, total_cost, success, nodes, depth, bottleneck = _simulate_task(
                task_copy, rng, time_per_unit, cost_per_unit, failure_rate
            )
            return SimulationOutcome(
                run_id=run_id,
                total_time=total_time,
                total_cost=total_cost,
                success=success,
                node_count=nodes,
                max_depth_reached=depth,
                bottleneck=bottleneck,
            )

        # φ-based timing: stagger thread starts by φ^(-k) seconds
        with ThreadPoolExecutor(max_workers=self.n_workers) as pool:
            futures = {pool.submit(_run_one, i): i for i in range(self.n_runs)}
            for i, fut in enumerate(as_completed(futures)):
                outcomes[futures[fut]] = fut.result()

        stats = SimulationStats(outcomes)

        # Persist to vector memory if available
        if self._memory is not None:
            self._record_to_memory(task, stats)

        return stats

    def _record_to_memory(self, task: Task, stats: SimulationStats) -> None:
        """Store simulation summary in vector memory for future reference."""
        try:
            summary = f"MC simulation: {task.name} | {stats.to_dict()}"
            # Use a deterministic pseudo-embedding for the summary
            # (real systems would use the embedding server)
            from .vector_math import EMBEDDING_DIM
            seed_val = hash(summary) % (2 ** 31)
            rng = random.Random(seed_val)
            fake_emb = [rng.gauss(0, 0.1) for _ in range(EMBEDDING_DIM)]
            self._memory.insert(
                text=summary,
                embedding=fake_emb,
                metadata={"type": "mc_simulation", "task": task.name, **stats.to_dict()},
                tags=["monte_carlo", "simulation"],
            )
        except Exception:
            pass  # Never let memory errors break simulation


# ─── Battle Arena ─────────────────────────────────────────────────────────────

class Strategy:
    """
    A named strategy for task execution.

    A strategy is defined by a combination of simulation parameters that
    affect how tasks are decomposed and executed.
    """

    def __init__(
        self,
        name: str,
        time_per_unit: float = 1.0,
        cost_per_unit: float = 0.01,
        failure_rate: float = 0.05,
        decompose_max_depth: int = DEFAULT_MAX_DEPTH,
        decompose_uncertainty_bias: float = 0.0,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Args:
            name:                      Strategy label.
            time_per_unit:             Execution time per complexity unit.
            cost_per_unit:             Cost per time unit.
            failure_rate:              Per-node failure probability.
            decompose_max_depth:       Max fractal decomposition depth.
            decompose_uncertainty_bias: Additive offset to node uncertainty.
            metadata:                  Extra descriptive data.
        """
        self.name = name
        self.time_per_unit = time_per_unit
        self.cost_per_unit = cost_per_unit
        self.failure_rate = failure_rate
        self.decompose_max_depth = decompose_max_depth
        self.decompose_uncertainty_bias = decompose_uncertainty_bias
        self.metadata = metadata or {}


class BattleArenaResult:
    """Results from a multi-strategy Battle Arena run."""

    def __init__(
        self,
        task_name: str,
        strategy_stats: Dict[str, SimulationStats],
        rankings: List[Tuple[str, float]],
    ) -> None:
        self.task_name = task_name
        self.strategy_stats = strategy_stats
        self.rankings = rankings  # [(strategy_name, score), ...] desc

    def winner(self) -> Tuple[str, float]:
        """Return the top-ranked strategy and its score."""
        return self.rankings[0]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task": self.task_name,
            "winner": self.rankings[0][0] if self.rankings else None,
            "rankings": [{"strategy": n, "score": round(s, 4)} for n, s in self.rankings],
            "stats": {
                name: stats.to_dict()
                for name, stats in self.strategy_stats.items()
            },
        }


class BattleArena:
    """
    Run the same task through multiple strategies and rank results.

    Scoring formula (all values normalized to [0, 1]):
        score = w_sr  * success_rate
              + w_spd * (1 - normalized_time)
              + w_cst * (1 - normalized_cost)
              + w_con * confidence_score

    Default weights: success 40%, speed 25%, cost 15%, confidence 20%.

    Usage:
        arena = BattleArena(n_runs=100)
        task = Task("Optimize DB query", complexity=8, uncertainty=0.35)

        strategies = [
            Strategy("aggressive",    time_per_unit=0.8,  failure_rate=0.10),
            Strategy("conservative",  time_per_unit=1.2,  failure_rate=0.02),
            Strategy("balanced",      time_per_unit=1.0,  failure_rate=0.05),
        ]

        result = arena.fight(task, strategies)
        print(result.winner())
    """

    def __init__(
        self,
        n_runs: int = DEFAULT_RUNS,
        n_workers: int = DEFAULT_WORKERS,
        seed: Optional[int] = None,
        memory=None,
        weights: Optional[Dict[str, float]] = None,
    ) -> None:
        self.n_runs = n_runs
        self.n_workers = n_workers
        self.seed = seed
        self.memory = memory
        self.weights = weights or {
            "success": 0.40,
            "speed": 0.25,
            "cost": 0.15,
            "confidence": 0.20,
        }

    def fight(
        self, task: Task, strategies: List[Strategy]
    ) -> BattleArenaResult:
        """
        Pit each strategy against the task and return ranked results.

        Args:
            task:       The task to simulate under each strategy.
            strategies: List of Strategy objects to evaluate.

        Returns:
            BattleArenaResult with rankings sorted by composite score.
        """
        all_stats: Dict[str, SimulationStats] = {}

        def _run_strategy(s: Strategy) -> Tuple[str, SimulationStats]:
            sim = MonteCarloSimulator(
                n_runs=self.n_runs,
                n_workers=self.n_workers,
                seed=self.seed,
                memory=self.memory,
            )
            import copy
            task_copy = copy.deepcopy(task)
            # Apply uncertainty bias from strategy
            if s.decompose_uncertainty_bias != 0.0:
                task_copy.uncertainty = max(
                    0.0,
                    min(1.0, task_copy.uncertainty + s.decompose_uncertainty_bias),
                )
            stats = sim.run(
                task_copy,
                time_per_unit=s.time_per_unit,
                cost_per_unit=s.cost_per_unit,
                failure_rate=s.failure_rate,
            )
            return s.name, stats

        with ThreadPoolExecutor(max_workers=min(len(strategies), 8)) as pool:
            futures = [pool.submit(_run_strategy, s) for s in strategies]
            for fut in as_completed(futures):
                name, stats = fut.result()
                all_stats[name] = stats

        # Normalise and score
        times = [s.mean_time for s in all_stats.values()]
        costs = [s.mean_cost for s in all_stats.values()]
        max_time = max(times) or 1.0
        max_cost = max(costs) or 1.0

        w = self.weights
        scored: List[Tuple[str, float]] = []
        for name, s in all_stats.items():
            score = (
                w["success"] * s.success_rate
                + w["speed"] * (1.0 - s.mean_time / max_time)
                + w["cost"] * (1.0 - s.mean_cost / max_cost)
                + w["confidence"] * s.confidence_score
            )
            scored.append((name, score))

        scored.sort(key=lambda t: t[1], reverse=True)
        return BattleArenaResult(task.name, all_stats, scored)


# ─── Convenience Functions ────────────────────────────────────────────────────

def quick_simulate(
    task_name: str,
    complexity: float = 5.0,
    uncertainty: float = 0.3,
    n_runs: int = DEFAULT_RUNS,
) -> Dict[str, Any]:
    """
    One-line convenience for a quick Monte Carlo simulation.

    Args:
        task_name:   Name of the task.
        complexity:  Base complexity (arbitrary units).
        uncertainty: Uncertainty factor [0, 1].
        n_runs:      Number of simulation runs.

    Returns:
        Stats dict from SimulationStats.to_dict().
    """
    task = Task(task_name, complexity, uncertainty)
    sim = MonteCarloSimulator(n_runs=n_runs)
    stats = sim.run(task)
    return {"task": task_name, **stats.to_dict()}
