"""
ai/__init__.py
==============
Heady AI/ML subsystem — zero external dependency (stdlib + torch + sentence-transformers).

Exports
-------
vector_math
    Pure-Python vector operations for 384-dim embeddings.

semantic_logic
    Core Semantic Logic (CSL): resonance gating, drift detection, coherence.

vector_memory
    3D Spatial Vector Memory: sharded storage, graph RAG, agent lifecycle,
    STM→LTM consolidation, autonomous maintenance.

embedding_server
    Local GPU/CPU embedding server (sentence-transformers/all-MiniLM-L6-v2).
    Exposes HTTP API; use embed_via_server() to call it remotely.

llm_gateway
    Multi-provider LLM gateway with circuit breaking, liquid routing,
    cost tracking, caching, and streaming.

monte_carlo
    Monte Carlo simulation engine: task decomposition, fractal modelling,
    parallel runs, Battle Arena multi-strategy ranking.

Quick-start
-----------
    from ai.vector_memory import VectorMemory
    from ai.llm_gateway import LLMGateway, LLMMessage, build_gateway, RoutingStrategy
    from ai.monte_carlo import Task, MonteCarloSimulator, BattleArena, Strategy
    from ai.semantic_logic import resonance_gate, drift_score
    from ai.vector_math import cosine_similarity, pca_lite_3d
"""

# ── Module-level lazy imports ─────────────────────────────────────────────────
# Modules are imported lazily (on first use via __getattr__) to avoid loading
# torch / sentence-transformers at import time on environments without GPUs.

from . import vector_math
from . import semantic_logic
from . import vector_memory
from . import llm_gateway
from . import monte_carlo
# embedding_server is imported lazily because it triggers a torch import
# on CPU-only machines this is fine, but we keep it explicit:
from . import embedding_server

# ── Convenience re-exports ────────────────────────────────────────────────────

from .vector_memory import VectorMemory, Memory, GraphEdge, AgentHandle

from .semantic_logic import (
    cosine_similarity,
    resonance_gate,
    semantic_distance,
    harmonic_mean_similarity,
    weighted_centroid,
    drift_score,
    drift_report,
    cluster_coherence,
    surprise_score,
    resonance_field,
)

from .vector_math import (
    dot_product,
    magnitude,
    normalize,
    euclidean_distance,
    vector_add,
    vector_subtract,
    vector_scale,
    matrix_multiply,
    pca_lite_3d,
    to_spherical,
    to_isometric,
    centroid,
    octant_id,
    fibonacci_shard,
    top_k_similar,
    PHI,
)

from .llm_gateway import (
    LLMGateway,
    LLMMessage,
    LLMResponse,
    RoutingStrategy,
    CircuitBreaker,
    OpenAIProvider,
    AnthropicProvider,
    GoogleProvider,
    GroqProvider,
    PerplexityProvider,
    OllamaProvider,
    ProviderError,
    BudgetExceededError,
    AllProvidersFailedError,
    build_gateway,
    count_tokens_approx,
)

from .monte_carlo import (
    Task,
    MonteCarloSimulator,
    SimulationStats,
    SimulationOutcome,
    FractalDecomposer,
    BattleArena,
    BattleArenaResult,
    Strategy,
    quick_simulate,
)

from .embedding_server import (
    EmbeddingServer,
    embed_via_server,
    MODEL_NAME as EMBEDDING_MODEL_NAME,
    EMBEDDING_DIM,
)

__all__ = [
    # Modules
    "vector_math",
    "semantic_logic",
    "vector_memory",
    "llm_gateway",
    "monte_carlo",
    "embedding_server",
    # VectorMemory
    "VectorMemory",
    "Memory",
    "GraphEdge",
    "AgentHandle",
    # Semantic Logic
    "cosine_similarity",
    "resonance_gate",
    "semantic_distance",
    "harmonic_mean_similarity",
    "weighted_centroid",
    "drift_score",
    "drift_report",
    "cluster_coherence",
    "surprise_score",
    "resonance_field",
    # Vector Math
    "dot_product",
    "magnitude",
    "normalize",
    "euclidean_distance",
    "vector_add",
    "vector_subtract",
    "vector_scale",
    "matrix_multiply",
    "pca_lite_3d",
    "to_spherical",
    "to_isometric",
    "centroid",
    "octant_id",
    "fibonacci_shard",
    "top_k_similar",
    "PHI",
    # LLM Gateway
    "LLMGateway",
    "LLMMessage",
    "LLMResponse",
    "RoutingStrategy",
    "CircuitBreaker",
    "OpenAIProvider",
    "AnthropicProvider",
    "GoogleProvider",
    "GroqProvider",
    "PerplexityProvider",
    "OllamaProvider",
    "ProviderError",
    "BudgetExceededError",
    "AllProvidersFailedError",
    "build_gateway",
    "count_tokens_approx",
    # Monte Carlo
    "Task",
    "MonteCarloSimulator",
    "SimulationStats",
    "SimulationOutcome",
    "FractalDecomposer",
    "BattleArena",
    "BattleArenaResult",
    "Strategy",
    "quick_simulate",
    # Embedding Server
    "EmbeddingServer",
    "embed_via_server",
    "EMBEDDING_MODEL_NAME",
    "EMBEDDING_DIM",
]
