"""
embedding_server.py
===================
Local GPU-accelerated embedding server for Heady.

Wraps sentence-transformers/all-MiniLM-L6-v2 (384-dim) in a lightweight
HTTP server using the core HTTPServer abstraction.  Designed to run on a
Colab Pro+ GPU instance and serve other Heady services on the local network.

Endpoints:
  POST /embed   – Embed one or many texts
  GET  /health  – Liveness check + model info

Request format (POST /embed):
  {"texts": "single string"}
  {"texts": ["string1", "string2", ...]}

Response format:
  {"ok": true, "embeddings": [[...], ...], "count": N, "dim": 384}

Error response:
  {"ok": false, "error": "message"}

Model is loaded once and cached in GPU memory for the server lifetime.
Falls back to CPU automatically if torch.cuda is unavailable.

Dependencies:
  - sentence-transformers  (pip pre-installed on Colab Pro+)
  - torch                  (pip pre-installed on Colab Pro+)
  - core.http_server       (Heady stdlib)

Usage:
    python -m ai.embedding_server             # default port 8765
    python -m ai.embedding_server --port 9000

    Or programmatically:
        from ai.embedding_server import EmbeddingServer
        server = EmbeddingServer(port=8765)
        server.run()
"""

import argparse
import json
import logging
import sys
import time
from typing import List, Optional, Union

# ─── Logging ─────────────────────────────────────────────────────────────────

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] embedding_server: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("embedding_server")

# ─── Model Constants ──────────────────────────────────────────────────────────

MODEL_NAME: str = "sentence-transformers/all-MiniLM-L6-v2"
EMBEDDING_DIM: int = 384
MAX_BATCH_SIZE: int = 512
MAX_SEQ_LENGTH: int = 256  # truncate inputs beyond this token count

# ─── Lazy Imports (only loaded when server starts) ───────────────────────────
# We import these lazily to keep module-level import clean when embedding_server
# is imported but not actually started (e.g., during unit tests).

_model = None       # sentence_transformers.SentenceTransformer instance
_device: str = "cpu"


def _load_model() -> None:
    """
    Load the sentence-transformer model into GPU or CPU memory.

    Called once at server startup. Subsequent calls are no-ops.
    """
    global _model, _device

    if _model is not None:
        return  # already loaded

    try:
        import torch  # type: ignore
        _device = "cuda" if torch.cuda.is_available() else "cpu"
        if _device == "cuda":
            gpu_name = torch.cuda.get_device_name(0)
            log.info("GPU detected: %s — loading model on CUDA", gpu_name)
        else:
            log.warning("No GPU detected — running on CPU (slower)")
    except ImportError:
        log.warning("torch not installed — running on CPU")
        _device = "cpu"

    try:
        from sentence_transformers import SentenceTransformer  # type: ignore
        log.info("Loading %s ...", MODEL_NAME)
        t0 = time.time()
        _model = SentenceTransformer(MODEL_NAME, device=_device)
        _model.max_seq_length = MAX_SEQ_LENGTH
        dt = time.time() - t0
        log.info("Model loaded in %.2fs on %s", dt, _device)
    except ImportError as exc:
        log.error("sentence-transformers not installed: %s", exc)
        raise


def _embed_texts(texts: List[str]) -> List[List[float]]:
    """
    Encode a list of strings into 384-dim embeddings.

    Args:
        texts: List of input strings (max MAX_BATCH_SIZE per call).

    Returns:
        List of embedding vectors (each a list of 384 floats).
    """
    global _model

    if _model is None:
        _load_model()

    # Batch in chunks to avoid OOM on very large inputs
    results: List[List[float]] = []
    for i in range(0, len(texts), MAX_BATCH_SIZE):
        batch = texts[i : i + MAX_BATCH_SIZE]
        embeddings = _model.encode(
            batch,
            convert_to_tensor=False,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        results.extend(e.tolist() for e in embeddings)
    return results


# ─── HTTP Route Handlers ──────────────────────────────────────────────────────

async def handle_embed(request) -> object:
    """
    POST /embed handler.

    Accepts:
        {"texts": "string"}
        {"texts": ["string", ...]}

    Returns:
        {"ok": true, "embeddings": [[...]], "count": N, "dim": 384}
    """
    from ..core.http_server import JSONResponse  # type: ignore

    body = request.json or {}

    raw = body.get("texts")
    if raw is None:
        return JSONResponse({"ok": False, "error": "Missing 'texts' field"}, status=400)

    if isinstance(raw, str):
        texts = [raw]
    elif isinstance(raw, list):
        if not all(isinstance(t, str) for t in raw):
            return JSONResponse(
                {"ok": False, "error": "'texts' list must contain only strings"},
                status=400,
            )
        texts = raw
    else:
        return JSONResponse(
            {"ok": False, "error": "'texts' must be a string or list of strings"},
            status=400,
        )

    if not texts:
        return JSONResponse({"ok": True, "embeddings": [], "count": 0, "dim": EMBEDDING_DIM})

    if len(texts) > MAX_BATCH_SIZE:
        return JSONResponse(
            {
                "ok": False,
                "error": f"Batch too large: {len(texts)} > {MAX_BATCH_SIZE}",
            },
            status=413,
        )

    try:
        t0 = time.time()
        embeddings = _embed_texts(texts)
        dt = time.time() - t0
        log.info("Embedded %d text(s) in %.3fs on %s", len(texts), dt, _device)
        return JSONResponse({
            "ok": True,
            "embeddings": embeddings,
            "count": len(embeddings),
            "dim": EMBEDDING_DIM,
            "latency_ms": round(dt * 1000, 2),
            "device": _device,
        })
    except Exception as exc:
        log.exception("Embedding failed")
        return JSONResponse({"ok": False, "error": str(exc)}, status=500)


async def handle_health(request) -> object:
    """GET /health — liveness + model info."""
    from ..core.http_server import JSONResponse  # type: ignore

    model_loaded = _model is not None
    return JSONResponse({
        "ok": True,
        "service": "heady-embedding-server",
        "model": MODEL_NAME,
        "dim": EMBEDDING_DIM,
        "device": _device,
        "model_loaded": model_loaded,
        "max_batch": MAX_BATCH_SIZE,
        "timestamp": time.time(),
    })


async def handle_batch_embed(request) -> object:
    """
    POST /embed/batch — explicit batched endpoint.

    Accepts a JSON array of text arrays for multi-batch processing:
        [["text1", "text2"], ["text3", "text4"]]

    Returns:
        {"ok": true, "results": [{"embeddings": [[...]], "count": N}, ...]}
    """
    from ..core.http_server import JSONResponse  # type: ignore

    body = request.json
    if not isinstance(body, list):
        return JSONResponse({"ok": False, "error": "Body must be a JSON array"}, status=400)

    results = []
    for batch in body:
        if not isinstance(batch, list):
            batch = [str(batch)]
        embeddings = _embed_texts(batch)
        results.append({"embeddings": embeddings, "count": len(embeddings)})

    return JSONResponse({"ok": True, "results": results})


# ─── Server Bootstrap ─────────────────────────────────────────────────────────

class EmbeddingServer:
    """
    Wraps the embedding HTTP service with lifecycle management.

    Usage:
        server = EmbeddingServer(host="0.0.0.0", port=8765)
        server.run()  # blocks until SIGINT/SIGTERM
    """

    def __init__(
        self,
        host: str = "0.0.0.0",
        port: int = 8765,
        preload_model: bool = True,
    ) -> None:
        """
        Args:
            host:          Bind address.
            port:          Listen port.
            preload_model: Load the model immediately (True) or on first request.
        """
        self.host = host
        self.port = port

        if preload_model:
            _load_model()

    def run(self) -> None:
        """Start the HTTP server and block until shutdown."""
        from ..core.http_server import HTTPServer  # type: ignore

        server = HTTPServer(host=self.host, port=self.port)

        server.route("/embed", methods=["POST"])(handle_embed)
        server.route("/embed/batch", methods=["POST"])(handle_batch_embed)
        server.route("/health", methods=["GET"])(handle_health)

        log.info(
            "Embedding server starting on http://%s:%d  (model=%s, device=%s)",
            self.host, self.port, MODEL_NAME, _device,
        )
        server.run()


# ─── Standalone Client Helper ─────────────────────────────────────────────────

def embed_via_server(
    texts: Union[str, List[str]],
    server_url: str = "http://localhost:8765",
    timeout: int = 30,
) -> List[List[float]]:
    """
    Helper to embed texts by calling a running EmbeddingServer over HTTP.
    Intended for use from other Heady modules that don't have direct model access.

    Args:
        texts:       Single text or list of texts to embed.
        server_url:  Base URL of the embedding server.
        timeout:     Request timeout in seconds.

    Returns:
        List of 384-dim embedding vectors.

    Raises:
        ConnectionError:   If the server is not reachable.
        RuntimeError:      If the server returns an error response.
    """
    import urllib.request
    import urllib.error

    if isinstance(texts, str):
        texts = [texts]

    payload = json.dumps({"texts": texts}).encode("utf-8")
    req = urllib.request.Request(
        f"{server_url}/embed",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        raise ConnectionError(f"Cannot reach embedding server at {server_url}: {e}") from e

    if not data.get("ok"):
        raise RuntimeError(f"Embedding server error: {data.get('error')}")

    return data["embeddings"]


# ─── CLI Entry Point ──────────────────────────────────────────────────────────

def _cli() -> None:
    parser = argparse.ArgumentParser(description="Heady Local Embedding Server")
    parser.add_argument("--host", default="0.0.0.0", help="Bind address")
    parser.add_argument("--port", type=int, default=8765, help="Listen port")
    parser.add_argument(
        "--no-preload",
        action="store_true",
        help="Don't load model at startup (load on first request)",
    )
    args = parser.parse_args()

    server = EmbeddingServer(
        host=args.host,
        port=args.port,
        preload_model=not args.no_preload,
    )
    server.run()


if __name__ == "__main__":
    _cli()
