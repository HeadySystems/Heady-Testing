"""
llm_gateway.py
==============
Multi-provider LLM gateway for Heady — zero external SDK dependencies.

All provider calls go through core/http_client.py (raw HTTP).
No openai, anthropic, google-generativeai, or groq packages required.

Providers supported:
  - OpenAI         (gpt-4o, gpt-4o-mini, o1, o3, etc.)
  - Anthropic      (claude-3-5-sonnet, claude-3-haiku, etc.)
  - Google Gemini  (gemini-1.5-pro, gemini-1.5-flash, etc.)
  - Groq           (llama-3.1, mixtral, gemma, etc.)
  - Perplexity     (sonar-pro, sonar, etc.)
  - Ollama         (local: llama3, mistral, etc.)

Routing strategies:
  - SINGLE:   Use specified provider only
  - RACE:     Fire all providers in parallel, use first success
  - FAILOVER: Try providers in order until one succeeds
  - CHEAPEST: Select lowest cost-per-token provider with healthy circuit

Circuit breaker per provider:
  - CLOSED:   Normal operation
  - OPEN:     Provider failed recently, skip until cooldown expires
  - HALF_OPEN: Probe one request to test recovery

Caching:
  - Uses core/cache.py (in-memory + optional disk persistence)
  - Cache key = hash(provider, model, messages, params)
  - TTL configurable per call

SSE Streaming:
  - Returns a generator that yields text deltas
  - Parsed from standard SSE data: {...} lines

Thread-safety: circuit breakers and cost tracker use threading.Lock.
"""

import hashlib
import json
import logging
import math
import threading
import time
from enum import Enum
from typing import Any, Dict, Generator, Iterator, List, Optional, Tuple, Union

log = logging.getLogger("llm_gateway")

# ─── Constants ────────────────────────────────────────────────────────────────

PHI: float = 1.6180339887
CB_FAILURE_THRESHOLD: int = 3           # failures before OPEN
CB_COOLDOWN_BASE: float = PHI ** 4      # ≈ 6.85s initial cooldown
CB_COOLDOWN_MAX: float = PHI ** 10      # ≈ 122.99s max cooldown
DEFAULT_TIMEOUT: int = 60               # seconds
DEFAULT_MAX_TOKENS: int = 2048

# Cost per 1K tokens (input, output) in USD — approximate as of 2025
PROVIDER_COSTS: Dict[str, Tuple[float, float]] = {
    "openai/gpt-4o":           (0.0025, 0.010),
    "openai/gpt-4o-mini":      (0.00015, 0.0006),
    "openai/o1":               (0.015, 0.060),
    "openai/o3-mini":          (0.0011, 0.0044),
    "anthropic/claude-3-5-sonnet-20241022": (0.003, 0.015),
    "anthropic/claude-3-haiku-20240307":    (0.00025, 0.00125),
    "google/gemini-1.5-pro":   (0.00125, 0.005),
    "google/gemini-1.5-flash": (0.000075, 0.0003),
    "google/gemini-2.0-flash-exp": (0.0, 0.0),
    "groq/llama-3.1-70b-versatile": (0.00059, 0.00079),
    "groq/mixtral-8x7b-32768":     (0.00024, 0.00024),
    "perplexity/sonar-pro":    (0.003, 0.015),
    "perplexity/sonar":        (0.001, 0.001),
    "ollama/llama3":           (0.0, 0.0),
    "ollama/mistral":          (0.0, 0.0),
}


# ─── Enums ────────────────────────────────────────────────────────────────────

class RoutingStrategy(Enum):
    SINGLE = "single"
    RACE = "race"
    FAILOVER = "failover"
    CHEAPEST = "cheapest"


class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


# ─── Data Models ─────────────────────────────────────────────────────────────

class LLMMessage:
    """A single message in a conversation."""

    def __init__(self, role: str, content: str) -> None:
        if role not in ("system", "user", "assistant"):
            raise ValueError(f"Invalid role: {role}")
        self.role = role
        self.content = content

    def to_dict(self) -> Dict[str, str]:
        return {"role": self.role, "content": self.content}

    @classmethod
    def system(cls, content: str) -> "LLMMessage":
        return cls("system", content)

    @classmethod
    def user(cls, content: str) -> "LLMMessage":
        return cls("user", content)

    @classmethod
    def assistant(cls, content: str) -> "LLMMessage":
        return cls("assistant", content)


class LLMResponse:
    """Normalized response from any LLM provider."""

    def __init__(
        self,
        text: str,
        provider: str,
        model: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cost_usd: float = 0.0,
        latency_ms: float = 0.0,
        raw: Optional[Dict] = None,
    ) -> None:
        self.text = text
        self.provider = provider
        self.model = model
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.cost_usd = cost_usd
        self.latency_ms = latency_ms
        self.raw = raw or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.text,
            "provider": self.provider,
            "model": self.model,
            "input_tokens": self.input_tokens,
            "output_tokens": self.output_tokens,
            "cost_usd": self.cost_usd,
            "latency_ms": self.latency_ms,
        }


# ─── Circuit Breaker ──────────────────────────────────────────────────────────

class CircuitBreaker:
    """
    Per-provider circuit breaker.

    States:
      CLOSED    → normal, requests pass through
      OPEN      → failing, requests rejected immediately
      HALF_OPEN → cooldown elapsed, allow one probe request
    """

    def __init__(
        self,
        name: str,
        failure_threshold: int = CB_FAILURE_THRESHOLD,
        cooldown_base: float = CB_COOLDOWN_BASE,
        cooldown_max: float = CB_COOLDOWN_MAX,
    ) -> None:
        self.name = name
        self.failure_threshold = failure_threshold
        self.cooldown_base = cooldown_base
        self.cooldown_max = cooldown_max

        self._state = CircuitState.CLOSED
        self._failures = 0
        self._opened_at: float = 0.0
        self._cooldown: float = cooldown_base
        self._lock = threading.Lock()

    @property
    def state(self) -> CircuitState:
        with self._lock:
            return self._get_state()

    def _get_state(self) -> CircuitState:
        if self._state == CircuitState.OPEN:
            elapsed = time.time() - self._opened_at
            if elapsed >= self._cooldown:
                self._state = CircuitState.HALF_OPEN
        return self._state

    def is_available(self) -> bool:
        """Return True if the circuit allows a request."""
        with self._lock:
            state = self._get_state()
            return state != CircuitState.OPEN

    def record_success(self) -> None:
        """Reset failure count on a successful call."""
        with self._lock:
            self._failures = 0
            self._cooldown = self.cooldown_base
            self._state = CircuitState.CLOSED

    def record_failure(self) -> None:
        """Increment failure count; open circuit if threshold exceeded."""
        with self._lock:
            self._failures += 1
            if self._failures >= self.failure_threshold:
                self._state = CircuitState.OPEN
                self._opened_at = time.time()
                # Exponential backoff with φ-based multiplier, capped
                self._cooldown = min(
                    self._cooldown * PHI,
                    self.cooldown_max,
                )
                log.warning(
                    "Circuit OPEN for %s (cooldown %.1fs)", self.name, self._cooldown
                )


# ─── Token Counter (approximate) ─────────────────────────────────────────────

def count_tokens_approx(text: str) -> int:
    """
    Approximate token count for a string (≈ words × 1.3).

    Not model-specific — use only for cost estimation and budget checks.

    Args:
        text: Any string.

    Returns:
        Approximate token count.
    """
    words = len(text.split())
    return max(1, int(words * 1.3))


def count_messages_tokens(messages: List[LLMMessage]) -> int:
    """Approximate total token count for a list of messages."""
    total = 0
    for msg in messages:
        total += count_tokens_approx(msg.content) + 4  # role + formatting overhead
    return total


# ─── Provider Adapters ────────────────────────────────────────────────────────

class BaseProvider:
    """Abstract base class for LLM provider adapters."""

    name: str = "base"
    base_url: str = ""
    default_model: str = ""

    def __init__(self, api_key: str = "", budget_usd: float = 10.0) -> None:
        self.api_key = api_key
        self.budget_usd = budget_usd
        self.spent_usd: float = 0.0
        self.circuit = CircuitBreaker(self.name)

    def _budget_remaining(self) -> float:
        return self.budget_usd - self.spent_usd

    def _check_budget(self, estimated_cost: float) -> None:
        if self.spent_usd + estimated_cost > self.budget_usd:
            raise BudgetExceededError(
                f"{self.name}: budget ${self.budget_usd:.4f} exceeded "
                f"(spent ${self.spent_usd:.4f})"
            )

    def _cost(self, model: str, in_toks: int, out_toks: int) -> float:
        key = f"{self.name}/{model}"
        in_rate, out_rate = PROVIDER_COSTS.get(key, (0.002, 0.008))
        return (in_toks * in_rate + out_toks * out_rate) / 1000.0

    def complete(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = 0.7,
        json_mode: bool = False,
        stream: bool = False,
    ) -> Union["LLMResponse", Iterator[str]]:
        raise NotImplementedError

    def _post(
        self,
        url: str,
        payload: Dict[str, Any],
        headers: Optional[Dict[str, str]] = None,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> Dict[str, Any]:
        """Perform a synchronous POST via stdlib urllib."""
        import urllib.request
        import urllib.error

        hdrs = {"Content-Type": "application/json"}
        if self.api_key:
            hdrs["Authorization"] = f"Bearer {self.api_key}"
        if headers:
            hdrs.update(headers)

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=hdrs, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            raise ProviderError(f"{self.name} HTTP {e.code}: {body}") from e
        except urllib.error.URLError as e:
            raise ProviderError(f"{self.name} connection error: {e}") from e

    def _stream_post(
        self,
        url: str,
        payload: Dict[str, Any],
        headers: Optional[Dict[str, str]] = None,
        timeout: int = DEFAULT_TIMEOUT,
    ) -> Iterator[str]:
        """Stream an SSE response, yielding text delta chunks."""
        import urllib.request
        import urllib.error

        hdrs = {"Content-Type": "application/json", "Accept": "text/event-stream"}
        if self.api_key:
            hdrs["Authorization"] = f"Bearer {self.api_key}"
        if headers:
            hdrs.update(headers)

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=hdrs, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                for raw_line in resp:
                    line = raw_line.decode("utf-8").rstrip("\n\r")
                    if not line.startswith("data:"):
                        continue
                    chunk = line[5:].strip()
                    if chunk == "[DONE]":
                        return
                    try:
                        obj = json.loads(chunk)
                        delta = self._extract_stream_delta(obj)
                        if delta:
                            yield delta
                    except json.JSONDecodeError:
                        continue
        except urllib.error.URLError as e:
            raise ProviderError(f"{self.name} stream error: {e}") from e

    def _extract_stream_delta(self, obj: Dict) -> str:
        """Override per provider to extract text delta from SSE payload."""
        return ""


class OpenAIProvider(BaseProvider):
    """OpenAI-compatible provider (works for OpenAI + any OpenAI-API endpoint)."""

    name = "openai"
    base_url = "https://api.openai.com/v1"
    default_model = "gpt-4o-mini"

    def complete(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = 0.7,
        json_mode: bool = False,
        stream: bool = False,
    ) -> Union[LLMResponse, Iterator[str]]:
        mdl = model or self.default_model
        payload: Dict[str, Any] = {
            "model": mdl,
            "messages": [m.to_dict() for m in messages],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }
        if json_mode:
            payload["response_format"] = {"type": "json_object"}
        if stream:
            payload["stream"] = True
            return self._stream_post(f"{self.base_url}/chat/completions", payload)

        t0 = time.time()
        resp = self._post(f"{self.base_url}/chat/completions", payload)
        latency_ms = (time.time() - t0) * 1000

        text = resp["choices"][0]["message"]["content"]
        usage = resp.get("usage", {})
        in_toks = usage.get("prompt_tokens", 0)
        out_toks = usage.get("completion_tokens", 0)
        cost = self._cost(mdl, in_toks, out_toks)
        self.spent_usd += cost
        return LLMResponse(text, self.name, mdl, in_toks, out_toks, cost, latency_ms, resp)

    def _extract_stream_delta(self, obj: Dict) -> str:
        try:
            return obj["choices"][0]["delta"].get("content", "") or ""
        except (KeyError, IndexError):
            return ""


class AnthropicProvider(BaseProvider):
    """Anthropic Claude provider."""

    name = "anthropic"
    base_url = "https://api.anthropic.com/v1"
    default_model = "claude-3-haiku-20240307"
    ANTHROPIC_VERSION = "2023-06-01"

    def _post(self, url, payload, headers=None, timeout=DEFAULT_TIMEOUT):
        extra = {
            "x-api-key": self.api_key,
            "anthropic-version": self.ANTHROPIC_VERSION,
        }
        if headers:
            extra.update(headers)
        # Override auth header behaviour (Anthropic uses x-api-key, not Bearer)
        import urllib.request, urllib.error
        hdrs = {"Content-Type": "application/json", **extra}
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=hdrs, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            raise ProviderError(f"anthropic HTTP {e.code}: {body}") from e
        except urllib.error.URLError as e:
            raise ProviderError(f"anthropic connection error: {e}") from e

    def complete(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = 0.7,
        json_mode: bool = False,
        stream: bool = False,
    ) -> Union[LLMResponse, Iterator[str]]:
        mdl = model or self.default_model

        # Anthropic separates system messages
        system = ""
        user_msgs = []
        for m in messages:
            if m.role == "system":
                system = m.content
            else:
                user_msgs.append(m.to_dict())

        payload: Dict[str, Any] = {
            "model": mdl,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": user_msgs,
        }
        if system:
            payload["system"] = system

        t0 = time.time()
        resp = self._post(f"{self.base_url}/messages", payload)
        latency_ms = (time.time() - t0) * 1000

        text = resp["content"][0]["text"]
        usage = resp.get("usage", {})
        in_toks = usage.get("input_tokens", 0)
        out_toks = usage.get("output_tokens", 0)
        cost = self._cost(mdl, in_toks, out_toks)
        self.spent_usd += cost
        return LLMResponse(text, self.name, mdl, in_toks, out_toks, cost, latency_ms, resp)


class GoogleProvider(BaseProvider):
    """Google Gemini provider via REST API."""

    name = "google"
    base_url = "https://generativelanguage.googleapis.com/v1beta"
    default_model = "gemini-1.5-flash"

    def complete(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = 0.7,
        json_mode: bool = False,
        stream: bool = False,
    ) -> Union[LLMResponse, Iterator[str]]:
        import urllib.request, urllib.error

        mdl = model or self.default_model
        url = (
            f"{self.base_url}/models/{mdl}:generateContent"
            f"?key={self.api_key}"
        )

        # Convert messages to Gemini format
        contents = []
        system_parts = []
        for m in messages:
            if m.role == "system":
                system_parts.append({"text": m.content})
            else:
                role = "user" if m.role == "user" else "model"
                contents.append({"role": role, "parts": [{"text": m.content}]})

        payload: Dict[str, Any] = {
            "contents": contents,
            "generationConfig": {
                "maxOutputTokens": max_tokens,
                "temperature": temperature,
            },
        }
        if system_parts:
            payload["systemInstruction"] = {"parts": system_parts}
        if json_mode:
            payload["generationConfig"]["responseMimeType"] = "application/json"

        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        t0 = time.time()
        try:
            with urllib.request.urlopen(req, timeout=DEFAULT_TIMEOUT) as resp:
                raw = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")
            raise ProviderError(f"google HTTP {e.code}: {body}") from e

        latency_ms = (time.time() - t0) * 1000
        text = raw["candidates"][0]["content"]["parts"][0]["text"]
        usage = raw.get("usageMetadata", {})
        in_toks = usage.get("promptTokenCount", 0)
        out_toks = usage.get("candidatesTokenCount", 0)
        cost = self._cost(mdl, in_toks, out_toks)
        self.spent_usd += cost
        return LLMResponse(text, self.name, mdl, in_toks, out_toks, cost, latency_ms, raw)


class GroqProvider(OpenAIProvider):
    """Groq is OpenAI-API-compatible — just a different base URL."""

    name = "groq"
    base_url = "https://api.groq.com/openai/v1"
    default_model = "llama-3.1-70b-versatile"


class PerplexityProvider(OpenAIProvider):
    """Perplexity Sonar is OpenAI-API-compatible."""

    name = "perplexity"
    base_url = "https://api.perplexity.ai"
    default_model = "sonar"


class OllamaProvider(BaseProvider):
    """Ollama local provider — no API key required."""

    name = "ollama"
    base_url = "http://localhost:11434"
    default_model = "llama3"

    def complete(
        self,
        messages: List[LLMMessage],
        model: Optional[str] = None,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = 0.7,
        json_mode: bool = False,
        stream: bool = False,
    ) -> Union[LLMResponse, Iterator[str]]:
        mdl = model or self.default_model
        payload: Dict[str, Any] = {
            "model": mdl,
            "messages": [m.to_dict() for m in messages],
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        if json_mode:
            payload["format"] = "json"

        t0 = time.time()
        resp = self._post(f"{self.base_url}/api/chat", payload)
        latency_ms = (time.time() - t0) * 1000
        text = resp["message"]["content"]
        return LLMResponse(text, self.name, mdl, 0, 0, 0.0, latency_ms, resp)


# ─── Exceptions ───────────────────────────────────────────────────────────────

class ProviderError(Exception):
    """Raised when a provider call fails."""


class BudgetExceededError(Exception):
    """Raised when a provider's spend cap is hit."""


class AllProvidersFailedError(Exception):
    """Raised when all providers in FAILOVER/RACE strategy fail."""


# ─── Cache Key ────────────────────────────────────────────────────────────────

def _cache_key(provider: str, model: str, messages: List[LLMMessage], **kw) -> str:
    raw = json.dumps({
        "provider": provider, "model": model,
        "messages": [m.to_dict() for m in messages],
        **kw,
    }, sort_keys=True)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


# ─── LLM Gateway ──────────────────────────────────────────────────────────────

class LLMGateway:
    """
    Multi-provider LLM gateway with routing, circuit breaking, caching,
    cost tracking, and streaming support.

    Usage:
        gw = LLMGateway()
        gw.register("openai", OpenAIProvider(api_key="sk-..."))
        gw.register("groq",   GroqProvider(api_key="gsk_..."))

        response = gw.complete(
            messages=[LLMMessage.user("Hello!")],
            strategy=RoutingStrategy.RACE,
        )
        print(response.text)
    """

    def __init__(self, cache=None) -> None:
        """
        Args:
            cache: Optional core.cache.Cache instance for response caching.
        """
        self._providers: Dict[str, BaseProvider] = {}
        self._lock = threading.Lock()
        self._cache = cache

        # Aggregate cost tracker
        self._total_cost_usd: float = 0.0
        self._call_count: int = 0

    def register(
        self,
        name: str,
        provider: BaseProvider,
        api_key: Optional[str] = None,
    ) -> None:
        """
        Register a provider under the given name.

        Args:
            name:     Identifier (e.g. "openai", "groq").
            provider: Configured BaseProvider instance.
            api_key:  Override the provider's API key.
        """
        if api_key:
            provider.api_key = api_key
        with self._lock:
            self._providers[name] = provider
        log.info("Registered provider: %s (%s)", name, type(provider).__name__)

    def complete(
        self,
        messages: List[LLMMessage],
        provider: Optional[str] = None,
        model: Optional[str] = None,
        strategy: RoutingStrategy = RoutingStrategy.FAILOVER,
        max_tokens: int = DEFAULT_MAX_TOKENS,
        temperature: float = 0.7,
        json_mode: bool = False,
        stream: bool = False,
        cache_ttl: Optional[int] = None,
    ) -> Union[LLMResponse, Iterator[str]]:
        """
        Send a completion request using the specified routing strategy.

        Args:
            messages:    Conversation history (list of LLMMessage).
            provider:    Specific provider name (required for SINGLE strategy).
            model:       Model override (uses provider default if None).
            strategy:    Routing strategy (SINGLE, RACE, FAILOVER, CHEAPEST).
            max_tokens:  Maximum tokens in the response.
            temperature: Sampling temperature [0, 2].
            json_mode:   Request structured JSON output.
            stream:      Return a streaming iterator instead of full response.
            cache_ttl:   Cache TTL in seconds (None = don't cache).

        Returns:
            LLMResponse (or Iterator[str] if stream=True).
        """
        self._call_count += 1

        # Cache lookup (skip for streaming)
        if cache_ttl and self._cache and not stream:
            key = _cache_key(provider or strategy.value, model or "", messages,
                             max_tokens=max_tokens, temperature=temperature,
                             json_mode=json_mode)
            cached = self._cache.get(key)
            if cached:
                log.debug("Cache hit for key %s", key[:8])
                return LLMResponse(**json.loads(cached))

        if strategy == RoutingStrategy.SINGLE:
            if not provider:
                raise ValueError("SINGLE strategy requires a provider name")
            result = self._call_single(
                provider, messages, model, max_tokens, temperature, json_mode, stream
            )
        elif strategy == RoutingStrategy.RACE:
            result = self._call_race(
                messages, model, max_tokens, temperature, json_mode
            )
        elif strategy == RoutingStrategy.FAILOVER:
            result = self._call_failover(
                messages, model, max_tokens, temperature, json_mode,
                preferred=provider,
            )
        elif strategy == RoutingStrategy.CHEAPEST:
            result = self._call_cheapest(
                messages, model, max_tokens, temperature, json_mode
            )
        else:
            raise ValueError(f"Unknown strategy: {strategy}")

        # Cache result
        if cache_ttl and self._cache and isinstance(result, LLMResponse):
            key = _cache_key(provider or strategy.value, model or "", messages,
                             max_tokens=max_tokens, temperature=temperature,
                             json_mode=json_mode)
            self._cache.set(key, json.dumps(result.to_dict()), ttl=cache_ttl)

        if isinstance(result, LLMResponse):
            self._total_cost_usd += result.cost_usd

        return result

    def _call_single(
        self, name: str, messages, model, max_tokens, temperature, json_mode, stream
    ) -> Union[LLMResponse, Iterator[str]]:
        p = self._providers.get(name)
        if p is None:
            raise ValueError(f"Provider '{name}' not registered")
        if not p.circuit.is_available():
            raise ProviderError(f"Circuit OPEN for {name}")
        try:
            result = p.complete(messages, model, max_tokens, temperature, json_mode, stream)
            p.circuit.record_success()
            return result
        except Exception as e:
            p.circuit.record_failure()
            raise ProviderError(f"{name} failed: {e}") from e

    def _call_failover(
        self, messages, model, max_tokens, temperature, json_mode,
        preferred: Optional[str] = None,
    ) -> LLMResponse:
        names = list(self._providers.keys())
        if preferred and preferred in names:
            names.remove(preferred)
            names.insert(0, preferred)

        errors = []
        for name in names:
            p = self._providers[name]
            if not p.circuit.is_available():
                continue
            try:
                result = p.complete(messages, model, max_tokens, temperature, json_mode)
                p.circuit.record_success()
                return result  # type: ignore[return-value]
            except Exception as e:
                p.circuit.record_failure()
                errors.append(f"{name}: {e}")
                log.warning("Provider %s failed, trying next: %s", name, e)

        raise AllProvidersFailedError(f"All providers failed: {'; '.join(errors)}")

    def _call_race(
        self, messages, model, max_tokens, temperature, json_mode
    ) -> LLMResponse:
        """Fire all available providers concurrently; return first success."""
        import concurrent.futures

        available = {
            name: p
            for name, p in self._providers.items()
            if p.circuit.is_available()
        }
        if not available:
            raise AllProvidersFailedError("No available providers for RACE")

        result_holder: List[Optional[LLMResponse]] = [None]
        first_event = threading.Event()

        def _call(name: str, p: BaseProvider) -> Optional[LLMResponse]:
            try:
                r = p.complete(messages, model, max_tokens, temperature, json_mode)
                p.circuit.record_success()
                return r  # type: ignore[return-value]
            except Exception as e:
                p.circuit.record_failure()
                log.debug("Race: %s failed: %s", name, e)
                return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=len(available)) as pool:
            futures = {pool.submit(_call, n, p): n for n, p in available.items()}
            for fut in concurrent.futures.as_completed(futures):
                res = fut.result()
                if res is not None and result_holder[0] is None:
                    result_holder[0] = res
                    # Cancel remaining (best effort)
                    for f in futures:
                        f.cancel()
                    break

        if result_holder[0] is None:
            raise AllProvidersFailedError("RACE: all providers failed")
        return result_holder[0]

    def _call_cheapest(
        self, messages, model, max_tokens, temperature, json_mode
    ) -> LLMResponse:
        """Select the cheapest healthy provider and call it."""
        in_toks = count_messages_tokens(messages)
        out_toks = max_tokens // 2  # rough estimate

        best_name: Optional[str] = None
        best_cost = float("inf")

        for name, p in self._providers.items():
            if not p.circuit.is_available():
                continue
            mdl = model or p.default_model
            key = f"{name}/{mdl}"
            in_rate, out_rate = PROVIDER_COSTS.get(key, (0.002, 0.008))
            est = (in_toks * in_rate + out_toks * out_rate) / 1000.0
            if est < best_cost:
                best_cost = est
                best_name = name

        if best_name is None:
            raise AllProvidersFailedError("CHEAPEST: no available providers")

        return self._call_single(
            best_name, messages, model, max_tokens, temperature, json_mode, False
        )  # type: ignore[return-value]

    # ── Structured Output ──────────────────────────────────────────────────

    def complete_json(
        self,
        messages: List[LLMMessage],
        schema_hint: Optional[str] = None,
        **kwargs,
    ) -> Any:
        """
        Request a JSON-structured response and parse it.

        Args:
            messages:    Conversation messages.
            schema_hint: Optional instruction appended to prompt describing
                         the expected JSON structure.
            **kwargs:    Forwarded to complete().

        Returns:
            Parsed Python dict/list from the LLM response.

        Raises:
            json.JSONDecodeError: If the model returns invalid JSON.
        """
        if schema_hint:
            messages = list(messages) + [
                LLMMessage.user(
                    f"Respond ONLY with valid JSON. Schema hint: {schema_hint}"
                )
            ]
        kwargs["json_mode"] = True
        resp = self.complete(messages, **kwargs)
        assert isinstance(resp, LLMResponse)
        return json.loads(resp.text)

    # ── Status / Cost Reporting ────────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        """Return gateway health and cost summary."""
        with self._lock:
            return {
                "providers": {
                    name: {
                        "circuit": p.circuit.state.value,
                        "spent_usd": round(p.spent_usd, 6),
                        "budget_usd": p.budget_usd,
                    }
                    for name, p in self._providers.items()
                },
                "total_cost_usd": round(self._total_cost_usd, 6),
                "call_count": self._call_count,
            }

    def reset_circuit(self, provider_name: str) -> bool:
        """Manually reset the circuit breaker for a provider."""
        with self._lock:
            p = self._providers.get(provider_name)
            if p:
                p.circuit.record_success()
                return True
            return False


# ─── Factory ─────────────────────────────────────────────────────────────────

def build_gateway(
    env: Optional[Dict[str, str]] = None,
    cache=None,
) -> LLMGateway:
    """
    Build a pre-configured LLMGateway from environment variables or a dict.

    Reads these keys from ``env`` (or os.environ if None):
        OPENAI_API_KEY, ANTHROPIC_API_KEY, GOOGLE_API_KEY,
        GROQ_API_KEY, PERPLEXITY_API_KEY, OLLAMA_HOST

    Only registers providers for which an API key is present.

    Args:
        env:   Dict of key→value pairs (defaults to os.environ).
        cache: Optional core.cache.Cache for response caching.

    Returns:
        Configured LLMGateway instance.
    """
    import os
    env = env or dict(os.environ)
    gw = LLMGateway(cache=cache)

    if env.get("OPENAI_API_KEY"):
        gw.register("openai", OpenAIProvider(env["OPENAI_API_KEY"]))
    if env.get("ANTHROPIC_API_KEY"):
        gw.register("anthropic", AnthropicProvider(env["ANTHROPIC_API_KEY"]))
    if env.get("GOOGLE_API_KEY"):
        gw.register("google", GoogleProvider(env["GOOGLE_API_KEY"]))
    if env.get("GROQ_API_KEY"):
        gw.register("groq", GroqProvider(env["GROQ_API_KEY"]))
    if env.get("PERPLEXITY_API_KEY"):
        gw.register("perplexity", PerplexityProvider(env["PERPLEXITY_API_KEY"]))

    ollama_host = env.get("OLLAMA_HOST", "")
    if ollama_host:
        p = OllamaProvider()
        p.base_url = ollama_host.rstrip("/")
        gw.register("ollama", p)
    elif _ollama_reachable():
        gw.register("ollama", OllamaProvider())

    return gw


def _ollama_reachable(timeout: int = 2) -> bool:
    """Check if a local Ollama instance is running."""
    import urllib.request, urllib.error
    try:
        urllib.request.urlopen("http://localhost:11434/api/tags", timeout=timeout)
        return True
    except Exception:
        return False
