"""
vector_memory.py
================
3D Spatial Vector Memory System for Heady.

Port of the JavaScript VectorMemory into production-quality Python.
This is the core persistence + retrieval layer for all AI agent memory.

Architecture:
  ┌──────────────────────────────────────────────────────┐
  │  384-dim embedding space                              │
  │       │                                               │
  │  PCA-lite → (x, y, z) 3D coords                     │
  │       │                                               │
  │  Octant zone index (8 zones)                         │
  │       │                                               │
  │  5 Fibonacci shards (parallel storage)               │
  │       │                                               │
  │  Graph RAG layer (entity edges + multi-hop)          │
  └──────────────────────────────────────────────────────┘

Key subsystems:
  - STM (short-term memory)  → fast in-RAM ring buffer
  - LTM (long-term memory)   → sharded JSON persistence
  - Consolidation engine     → STM→LTM promotion logic
  - Density gate             → reject near-duplicate memories
  - Drift detector           → track semantic drift over time
  - Zone coherence alerting  → warn when a zone becomes incoherent
  - Agent lifecycle manager  → spawn / observe / terminate agents in 3D space
  - Autonomous maintenance   → background timer for decay + consolidation

Memory importance formula:
    I(m) = α·Freq(m) + β·e^(-γ·Δt) + δ·Surp(m)

    where:
        Freq(m) = access frequency (normalized)
        Δt      = seconds since last access
        Surp(m) = surprise / novelty score at insertion time
        α, β, γ, δ = tunable weights (defaults: 0.3, 0.4, 1e-5, 0.3)

All timing constants derived from φ (golden ratio = 1.6180339887).

Thread-safety: all mutating operations are wrapped in threading.Lock.
Persistence: JSON files, one per shard + one for the graph.

Dependencies: Python stdlib only (no numpy, no external packages).
"""

import json
import math
import os
import threading
import time
import uuid
from collections import defaultdict, deque
from typing import Any, Dict, Generator, Iterator, List, Optional, Set, Tuple

from .vector_math import (
    PHI,
    cosine_similarity,
    euclidean_distance,
    fibonacci_shard,
    normalize,
    octant_id,
    adjacent_octants,
    pca_lite_3d,
    centroid,
    top_k_similar,
)
from .semantic_logic import (
    drift_score,
    surprise_score,
    cluster_coherence,
    resonance_gate,
)

# ─── Constants ────────────────────────────────────────────────────────────────

PHI_INV: float = 1.0 / PHI                   # ≈ 0.618
PHI2: float = PHI ** 2                        # ≈ 2.618

N_SHARDS: int = 5
N_ZONES: int = 8                              # 8 octants
STM_CAPACITY: int = int(PHI ** 7)            # ≈ 29 items in STM ring buffer
CONSOLIDATION_INTERVAL: float = PHI ** 5     # ≈ 11.09 seconds
DECAY_HALF_LIFE: float = PHI ** 10           # ≈ 122.99 seconds
DENSITY_THRESHOLD: float = 0.92             # reject if sim > this vs nearest
DRIFT_ALERT_THRESHOLD: float = 0.35
ZONE_COHERENCE_THRESHOLD: float = 0.55
MAX_HOPS: int = 3                            # max graph traversal depth


# ─── Data Structures ─────────────────────────────────────────────────────────

class Memory:
    """
    A single memory unit stored in the vector memory system.
    """

    __slots__ = (
        "id", "text", "embedding", "x", "y", "z", "zone",
        "shard", "importance", "frequency", "created_at",
        "last_accessed", "surprise", "metadata", "tags",
    )

    def __init__(
        self,
        text: str,
        embedding: List[float],
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
    ) -> None:
        self.id: str = str(uuid.uuid4())
        self.text: str = text
        self.embedding: List[float] = embedding
        x, y, z = pca_lite_3d(embedding)
        self.x: float = x
        self.y: float = y
        self.z: float = z
        self.zone: int = octant_id(x, y, z)
        self.shard: int = fibonacci_shard(self.id, N_SHARDS)
        self.importance: float = 0.5
        self.frequency: int = 0
        self.created_at: float = time.time()
        self.last_accessed: float = self.created_at
        self.surprise: float = 0.5
        self.metadata: Dict[str, Any] = metadata or {}
        self.tags: List[str] = tags or []

    def touch(self) -> None:
        """Update last_accessed and increment frequency on each retrieval."""
        self.last_accessed = time.time()
        self.frequency += 1

    def recalculate_importance(
        self,
        alpha: float = 0.3,
        beta: float = 0.4,
        gamma: float = 1e-5,
        delta: float = 0.3,
        max_freq: int = 100,
    ) -> float:
        """
        Recompute importance score:
            I(m) = α·Freq(m) + β·e^(-γ·Δt) + δ·Surp(m)

        Args:
            alpha:    Frequency weight.
            beta:     Recency weight.
            gamma:    Decay rate (per second).
            delta:    Surprise weight.
            max_freq: Normalization cap for frequency.

        Returns:
            Updated importance score, clamped to [0, 1].
        """
        dt = time.time() - self.last_accessed
        freq_norm = min(self.frequency, max_freq) / max_freq
        recency = math.exp(-gamma * dt)
        self.importance = (
            alpha * freq_norm
            + beta * recency
            + delta * self.surprise
        )
        return self.importance

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "text": self.text,
            "embedding": self.embedding,
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "zone": self.zone,
            "shard": self.shard,
            "importance": self.importance,
            "frequency": self.frequency,
            "created_at": self.created_at,
            "last_accessed": self.last_accessed,
            "surprise": self.surprise,
            "metadata": self.metadata,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Memory":
        m = cls.__new__(cls)
        for key in cls.__slots__:
            setattr(m, key, d[key])
        return m


class GraphEdge:
    """Directed weighted edge in the Graph RAG layer."""

    __slots__ = ("source_id", "target_id", "relation", "weight", "created_at")

    def __init__(
        self,
        source_id: str,
        target_id: str,
        relation: str = "related",
        weight: float = 1.0,
    ) -> None:
        self.source_id = source_id
        self.target_id = target_id
        self.relation = relation
        self.weight = weight
        self.created_at = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "relation": self.relation,
            "weight": self.weight,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GraphEdge":
        e = cls.__new__(cls)
        for key in cls.__slots__:
            setattr(e, key, d[key])
        return e


class AgentHandle:
    """Represents a live agent occupying a position in 3D memory space."""

    __slots__ = ("id", "name", "x", "y", "z", "zone", "status",
                 "spawned_at", "last_heartbeat", "metadata")

    def __init__(
        self,
        name: str,
        embedding: List[float],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.id: str = str(uuid.uuid4())
        self.name: str = name
        x, y, z = pca_lite_3d(embedding)
        self.x, self.y, self.z = x, y, z
        self.zone: int = octant_id(x, y, z)
        self.status: str = "active"
        self.spawned_at: float = time.time()
        self.last_heartbeat: float = self.spawned_at
        self.metadata: Dict[str, Any] = metadata or {}

    def heartbeat(self) -> None:
        self.last_heartbeat = time.time()

    def to_dict(self) -> Dict[str, Any]:
        return {k: getattr(self, k) for k in self.__slots__}


# ─── Core VectorMemory Class ──────────────────────────────────────────────────

class VectorMemory:
    """
    3D Spatial Vector Memory — primary storage and retrieval engine.

    Usage:
        vm = VectorMemory(persist_dir="/tmp/heady_memory")
        vm.insert(text="The sky is blue", embedding=embed("The sky is blue"))
        results = vm.query(embedding=embed("sky color"), k=5)
    """

    def __init__(
        self,
        persist_dir: str = "./memory_store",
        auto_persist: bool = True,
        auto_maintenance: bool = True,
    ) -> None:
        """
        Args:
            persist_dir:        Directory for JSON shard files.
            auto_persist:       Automatically save on insert/delete.
            auto_maintenance:   Start background maintenance thread.
        """
        self.persist_dir = persist_dir
        self.auto_persist = auto_persist
        self._lock = threading.RLock()

        # Shards: 5 parallel dicts {memory_id → Memory}
        self._shards: List[Dict[str, Memory]] = [{} for _ in range(N_SHARDS)]

        # Zone index: zone_id → set of memory_ids
        self._zone_index: Dict[int, Set[str]] = defaultdict(set)

        # STM ring buffer (fast recent-memory cache)
        self._stm: deque = deque(maxlen=STM_CAPACITY)
        self._stm_set: Set[str] = set()  # fast membership test

        # Graph RAG layer: adjacency list {node_id → [GraphEdge]}
        self._graph: Dict[str, List[GraphEdge]] = defaultdict(list)

        # Drift detection: baseline snapshots {tag → embedding}
        self._drift_baselines: Dict[str, List[float]] = {}

        # Zone coherence snapshots: {zone_id → last_coherence}
        self._zone_coherence_cache: Dict[int, float] = {}

        # Agent lifecycle manager
        self._agents: Dict[str, AgentHandle] = {}

        # Maintenance timer handle
        self._maintenance_thread: Optional[threading.Thread] = None
        self._stop_maintenance = threading.Event()

        # Stats
        self._stats: Dict[str, int] = {
            "inserts": 0, "queries": 0, "deletes": 0,
            "stm_hits": 0, "ltm_hits": 0, "graph_traversals": 0,
            "consolidations": 0, "density_rejections": 0,
        }

        os.makedirs(persist_dir, exist_ok=True)
        self._load_from_disk()

        if auto_maintenance:
            self._start_maintenance()

    # ── Insertion ──────────────────────────────────────────────────────────

    def insert(
        self,
        text: str,
        embedding: List[float],
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        force: bool = False,
    ) -> Optional[str]:
        """
        Insert a new memory into the system.

        Performs density gating — rejects the insertion if an existing memory
        is too similar (cosine > DENSITY_THRESHOLD) unless *force=True*.

        Args:
            text:      Human-readable content string.
            embedding: 384-dim embedding vector.
            metadata:  Optional extra key-value data.
            tags:      Optional string tags for filtering.
            force:     Bypass density gating.

        Returns:
            Memory ID (str) if inserted, None if rejected by density gate.
        """
        with self._lock:
            # Density gate check
            if not force:
                nearest = self._nearest_in_zone(embedding, k=1)
                if nearest and nearest[0][1] >= DENSITY_THRESHOLD:
                    self._stats["density_rejections"] += 1
                    return None

            mem = Memory(text, embedding, metadata, tags)

            # Compute surprise against STM context
            context_embeddings = [
                self._shards[m.shard][m.id].embedding
                for m in list(self._stm)[-10:]
                if m.shard < N_SHARDS and m.id in self._shards[m.shard]
            ]
            mem.surprise = surprise_score(embedding, context_embeddings)
            mem.recalculate_importance()

            # Store in appropriate shard
            self._shards[mem.shard][mem.id] = mem

            # Update zone index
            self._zone_index[mem.zone].add(mem.id)

            # Add to STM
            self._stm.append(mem)
            self._stm_set.add(mem.id)

            # Auto-graph: link to nearest k memories by cosine similarity
            self._auto_link(mem, k=3)

            self._stats["inserts"] += 1

            if self.auto_persist:
                self._save_shard(mem.shard)

            return mem.id

    def _auto_link(self, mem: Memory, k: int = 3) -> None:
        """Automatically create graph edges to the k nearest memories."""
        nearest = self._nearest_in_zone(mem.embedding, k=k + 1)
        for mid, sim in nearest:
            if mid == mem.id:
                continue
            if sim > 0.5:
                edge = GraphEdge(mem.id, mid, "semantic", sim)
                self._graph[mem.id].append(edge)

    # ── Retrieval ──────────────────────────────────────────────────────────

    def query(
        self,
        embedding: List[float],
        k: int = 10,
        tags: Optional[List[str]] = None,
        min_importance: float = 0.0,
    ) -> List[Dict[str, Any]]:
        """
        Query the memory store for the k most similar embeddings.

        Search order: zone-first → adjacent zones → all zones.
        STM is checked first (O(1) set lookup), then LTM shards.

        Args:
            embedding:       Query vector (384-dim).
            k:               Maximum results to return.
            tags:            Optional tag filter (any tag must match).
            min_importance:  Minimum importance threshold.

        Returns:
            List of dicts with keys: id, text, similarity, importance, x, y, z,
            zone, metadata, tags.
        """
        with self._lock:
            self._stats["queries"] += 1

            query_zone = octant_id(*pca_lite_3d(embedding))

            # Build search order: same zone → adjacent → rest
            search_zones = [query_zone] + adjacent_octants(query_zone)

            candidates: List[Tuple[str, List[float]]] = []
            seen: Set[str] = set()

            for zone in search_zones:
                for mid in self._zone_index.get(zone, set()):
                    if mid in seen:
                        continue
                    seen.add(mid)
                    mem = self._get_by_id(mid)
                    if mem is None:
                        continue
                    if min_importance > 0 and mem.importance < min_importance:
                        continue
                    if tags and not any(t in mem.tags for t in tags):
                        continue
                    candidates.append((mid, mem.embedding))

                # If we already have enough candidates, stop expanding
                if len(candidates) >= k * 5:
                    break

            # Score all candidates
            scored = top_k_similar(embedding, candidates, k=k)

            results = []
            for mid, sim in scored:
                mem = self._get_by_id(mid)
                if mem is None:
                    continue
                mem.touch()
                if mid in self._stm_set:
                    self._stats["stm_hits"] += 1
                else:
                    self._stats["ltm_hits"] += 1
                results.append({
                    "id": mid,
                    "text": mem.text,
                    "similarity": sim,
                    "importance": mem.importance,
                    "x": mem.x,
                    "y": mem.y,
                    "z": mem.z,
                    "zone": mem.zone,
                    "metadata": mem.metadata,
                    "tags": mem.tags,
                })

            return results

    def get(self, memory_id: str) -> Optional[Memory]:
        """Retrieve a single memory by ID."""
        with self._lock:
            return self._get_by_id(memory_id)

    def _get_by_id(self, memory_id: str) -> Optional[Memory]:
        """Internal: look up a memory across all shards."""
        shard_idx = fibonacci_shard(memory_id, N_SHARDS)
        return self._shards[shard_idx].get(memory_id)

    def _nearest_in_zone(
        self,
        embedding: List[float],
        k: int = 5,
        zone: Optional[int] = None,
    ) -> List[Tuple[str, float]]:
        """Return (id, similarity) pairs of nearest memories in a zone."""
        if zone is None:
            x, y, z = pca_lite_3d(embedding)
            zone = octant_id(x, y, z)
        candidates = []
        for mid in self._zone_index.get(zone, set()):
            mem = self._get_by_id(mid)
            if mem:
                candidates.append((mid, mem.embedding))
        return top_k_similar(embedding, candidates, k=k)

    # ── Deletion ───────────────────────────────────────────────────────────

    def delete(self, memory_id: str) -> bool:
        """
        Remove a memory from all shards, zones, STM, and graph.

        Args:
            memory_id: ID of the memory to remove.

        Returns:
            True if found and removed, False if not found.
        """
        with self._lock:
            mem = self._get_by_id(memory_id)
            if mem is None:
                return False

            del self._shards[mem.shard][memory_id]
            self._zone_index[mem.zone].discard(memory_id)
            self._stm_set.discard(memory_id)

            # Remove from STM deque
            self._stm = deque(
                (m for m in self._stm if m.id != memory_id),
                maxlen=STM_CAPACITY,
            )

            # Remove graph edges
            self._graph.pop(memory_id, None)
            for edges in self._graph.values():
                edges[:] = [e for e in edges if e.target_id != memory_id]

            self._stats["deletes"] += 1

            if self.auto_persist:
                self._save_shard(mem.shard)

            return True

    # ── Graph RAG Layer ────────────────────────────────────────────────────

    def add_edge(
        self,
        source_id: str,
        target_id: str,
        relation: str = "related",
        weight: float = 1.0,
    ) -> None:
        """
        Add a directed relationship edge between two memories.

        Args:
            source_id: ID of the source memory.
            target_id: ID of the target memory.
            relation:  Relationship type label (e.g. "causes", "supports").
            weight:    Edge weight in (0, 1].
        """
        with self._lock:
            edge = GraphEdge(source_id, target_id, relation, weight)
            self._graph[source_id].append(edge)

    def traverse(
        self,
        start_id: str,
        max_hops: int = MAX_HOPS,
        relation_filter: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Multi-hop BFS traversal from *start_id* in the graph RAG layer.

        Args:
            start_id:        Starting memory ID.
            max_hops:        Maximum traversal depth.
            relation_filter: Only follow edges of this relation type.

        Returns:
            List of dicts: {id, text, depth, relation, weight}.
        """
        with self._lock:
            self._stats["graph_traversals"] += 1
            visited: Set[str] = {start_id}
            queue: deque = deque([(start_id, 0, "", 1.0)])
            results: List[Dict[str, Any]] = []

            while queue:
                node_id, depth, rel, weight = queue.popleft()
                if depth > 0:
                    mem = self._get_by_id(node_id)
                    results.append({
                        "id": node_id,
                        "text": mem.text if mem else "[missing]",
                        "depth": depth,
                        "relation": rel,
                        "weight": weight,
                    })
                if depth >= max_hops:
                    continue
                for edge in self._graph.get(node_id, []):
                    if relation_filter and edge.relation != relation_filter:
                        continue
                    if edge.target_id not in visited:
                        visited.add(edge.target_id)
                        queue.append((
                            edge.target_id,
                            depth + 1,
                            edge.relation,
                            edge.weight,
                        ))

            return results

    # ── STM → LTM Consolidation ────────────────────────────────────────────

    def consolidate(self) -> int:
        """
        Promote important STM memories to LTM and decay old ones.

        Memories are consolidated based on their importance score.
        Low-importance LTM memories are decayed (importance reduced).

        Returns:
            Number of memories consolidated in this pass.
        """
        with self._lock:
            consolidated = 0

            # Recalculate importance for all LTM memories
            for shard in self._shards:
                for mem in shard.values():
                    mem.recalculate_importance()

            # Decay: remove very low-importance memories from LTM
            # that haven't been accessed in a long time
            cutoff_time = time.time() - DECAY_HALF_LIFE * PHI
            to_delete: List[str] = []
            for shard in self._shards:
                for mid, mem in shard.items():
                    if (
                        mem.last_accessed < cutoff_time
                        and mem.importance < 0.1
                        and mid not in self._stm_set
                    ):
                        to_delete.append(mid)

            for mid in to_delete:
                self.delete(mid)

            # Promote high-importance STM items (recalculate after decay)
            for mem in list(self._stm):
                mem.recalculate_importance()
                if mem.importance > 0.6:
                    consolidated += 1  # already in LTM shards

            self._stats["consolidations"] += 1
            return consolidated

    # ── Drift Detection ────────────────────────────────────────────────────

    def set_drift_baseline(self, tag: str, embedding: List[float]) -> None:
        """
        Store a baseline embedding snapshot for drift tracking.

        Args:
            tag:       Human-readable label for the concept.
            embedding: Current embedding to use as baseline.
        """
        with self._lock:
            self._drift_baselines[tag] = list(embedding)

    def check_drift(self, tag: str, current: List[float]) -> Optional[Dict[str, Any]]:
        """
        Compare *current* embedding to stored baseline for *tag*.

        Returns:
            Drift report dict, or None if no baseline exists for *tag*.
        """
        with self._lock:
            baseline = self._drift_baselines.get(tag)
            if baseline is None:
                return None
            score = drift_score(baseline, current)
            severity = (
                "negligible" if score < 0.05 else
                "minor" if score < 0.15 else
                "moderate" if score < 0.35 else
                "major" if score < 0.65 else
                "replaced"
            )
            alert = score > DRIFT_ALERT_THRESHOLD
            return {
                "tag": tag,
                "drift": score,
                "severity": severity,
                "alert": alert,
            }

    # ── Zone Coherence ─────────────────────────────────────────────────────

    def zone_coherence(self, zone: int) -> Dict[str, Any]:
        """
        Compute coherence of a memory zone (octant).

        A zone is "incoherent" if its memories span very different semantic
        directions — which may indicate misclustered or corrupted data.

        Args:
            zone: Octant ID (0–7).

        Returns:
            Dict with: zone, coherence (float), alert (bool), member_count.
        """
        with self._lock:
            mids = list(self._zone_index.get(zone, set()))
            if len(mids) < 2:
                return {
                    "zone": zone,
                    "coherence": 1.0,
                    "alert": False,
                    "member_count": len(mids),
                }
            vecs = []
            for mid in mids[:50]:  # cap at 50 for performance
                mem = self._get_by_id(mid)
                if mem:
                    vecs.append(mem.embedding)

            if len(vecs) < 2:
                return {"zone": zone, "coherence": 1.0, "alert": False, "member_count": 0}

            report = cluster_coherence(vecs)
            coh = report["harmonic_mean"]
            self._zone_coherence_cache[zone] = coh
            return {
                "zone": zone,
                "coherence": coh,
                "alert": coh < ZONE_COHERENCE_THRESHOLD,
                "member_count": len(mids),
            }

    def all_zone_coherence(self) -> List[Dict[str, Any]]:
        """Return coherence report for all 8 zones."""
        return [self.zone_coherence(z) for z in range(N_ZONES)]

    # ── Agent Lifecycle Manager ────────────────────────────────────────────

    def spawn_agent(
        self,
        name: str,
        embedding: List[float],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Spawn an agent at the 3D position derived from *embedding*.

        Args:
            name:      Human-readable agent name.
            embedding: 384-dim embedding defining agent's semantic position.
            metadata:  Optional extra data (capabilities, config, etc.).

        Returns:
            Agent ID string.
        """
        with self._lock:
            agent = AgentHandle(name, embedding, metadata)
            self._agents[agent.id] = agent
            return agent.id

    def agent_heartbeat(self, agent_id: str) -> bool:
        """
        Record a heartbeat for agent *agent_id*.

        Returns:
            True if agent was found and updated, False if not found.
        """
        with self._lock:
            agent = self._agents.get(agent_id)
            if agent is None:
                return False
            agent.heartbeat()
            return True

    def terminate_agent(self, agent_id: str) -> bool:
        """
        Terminate and remove an agent.

        Returns:
            True if removed, False if not found.
        """
        with self._lock:
            if agent_id in self._agents:
                self._agents[agent_id].status = "terminated"
                del self._agents[agent_id]
                return True
            return False

    def get_agents_in_zone(self, zone: int) -> List[Dict[str, Any]]:
        """Return all active agents in the given octant zone."""
        with self._lock:
            return [
                a.to_dict()
                for a in self._agents.values()
                if a.zone == zone and a.status == "active"
            ]

    def observe_agents(self) -> List[Dict[str, Any]]:
        """Return a snapshot of all live agents."""
        with self._lock:
            return [a.to_dict() for a in self._agents.values()]

    # ── Statistics ─────────────────────────────────────────────────────────

    def stats(self) -> Dict[str, Any]:
        """Return system statistics."""
        with self._lock:
            total = sum(len(s) for s in self._shards)
            return {
                **self._stats,
                "total_memories": total,
                "stm_size": len(self._stm),
                "agent_count": len(self._agents),
                "graph_nodes": len(self._graph),
                "graph_edges": sum(len(e) for e in self._graph.values()),
                "zone_sizes": {
                    z: len(self._zone_index.get(z, set())) for z in range(N_ZONES)
                },
                "shard_sizes": [len(s) for s in self._shards],
            }

    # ── Persistence ────────────────────────────────────────────────────────

    def save(self) -> None:
        """Persist all shards and graph to disk."""
        with self._lock:
            for i in range(N_SHARDS):
                self._save_shard(i)
            self._save_graph()
            self._save_agents()

    def _save_shard(self, shard_idx: int) -> None:
        path = os.path.join(self.persist_dir, f"shard_{shard_idx}.json")
        data = {mid: mem.to_dict() for mid, mem in self._shards[shard_idx].items()}
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, separators=(",", ":"))
        os.replace(tmp, path)

    def _save_graph(self) -> None:
        path = os.path.join(self.persist_dir, "graph.json")
        data = {
            node: [e.to_dict() for e in edges]
            for node, edges in self._graph.items()
        }
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, separators=(",", ":"))
        os.replace(tmp, path)

    def _save_agents(self) -> None:
        path = os.path.join(self.persist_dir, "agents.json")
        data = {aid: a.to_dict() for aid, a in self._agents.items()}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, separators=(",", ":"))

    def _load_from_disk(self) -> None:
        """Load persisted data from disk on startup."""
        for i in range(N_SHARDS):
            path = os.path.join(self.persist_dir, f"shard_{i}.json")
            if not os.path.exists(path):
                continue
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for mid, mdict in data.items():
                    mem = Memory.from_dict(mdict)
                    self._shards[i][mid] = mem
                    self._zone_index[mem.zone].add(mid)
            except (json.JSONDecodeError, KeyError):
                pass  # corrupt shard — skip, don't crash

        graph_path = os.path.join(self.persist_dir, "graph.json")
        if os.path.exists(graph_path):
            try:
                with open(graph_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                for node, edges in data.items():
                    self._graph[node] = [GraphEdge.from_dict(e) for e in edges]
            except (json.JSONDecodeError, KeyError):
                pass

    # ── Autonomous Maintenance ─────────────────────────────────────────────

    def _start_maintenance(self) -> None:
        """Start the background maintenance thread."""
        self._stop_maintenance.clear()
        t = threading.Thread(target=self._maintenance_loop, daemon=True)
        t.start()
        self._maintenance_thread = t

    def _maintenance_loop(self) -> None:
        """Periodically consolidate memory and decay old entries."""
        interval = CONSOLIDATION_INTERVAL
        while not self._stop_maintenance.wait(timeout=interval):
            try:
                self.consolidate()
                # Slowly expand interval toward φ² to reduce CPU load
                interval = min(interval * PHI_INV + CONSOLIDATION_INTERVAL, PHI2 * 60)
            except Exception:
                pass  # never crash the maintenance thread

    def stop_maintenance(self) -> None:
        """Stop the background maintenance thread cleanly."""
        self._stop_maintenance.set()
        if self._maintenance_thread:
            self._maintenance_thread.join(timeout=5)

    def __len__(self) -> int:
        return sum(len(s) for s in self._shards)

    def __repr__(self) -> str:
        return (
            f"VectorMemory(memories={len(self)}, "
            f"agents={len(self._agents)}, "
            f"persist_dir={self.persist_dir!r})"
        )
