"""
conductor.py
============
HeadyConductor — central routing and orchestration hub for the Heady system.

Architecture:
  ┌─────────────────────────────────────────────────────────────┐
  │  HeadyConductor                                             │
  │                                                             │
  │  ┌──────────┐   ┌──────────────┐   ┌─────────────────┐    │
  │  │ Classify │ → │ Node Select  │ → │ HCFullPipeline  │    │
  │  └──────────┘   └──────────────┘   └─────────────────┘    │
  │        │               │                     │              │
  │  Domain+Priority    Hot/Warm/Cold          8 stages         │
  │                                                             │
  │  ┌─────────────────────────────────────────────────────┐   │
  │  │  Arena Mode: multi-node competition → winner pick   │   │
  │  └─────────────────────────────────────────────────────┘   │
  └─────────────────────────────────────────────────────────────┘

Priority Pools:
  Hot       34% — latency-sensitive, user-facing
  Warm      21% — standard background tasks
  Cold      13% — batch / deferred work
  Reserve    8% — emergency / overflow capacity
  Governance 5% — policy, audit, compliance

Pipeline Stages (HCFullPipeline sequence):
  1. Context Assembly      — gather all relevant context
  2. Intent Classification — determine task type + urgency
  3. Node Selection        — skill-based routing
  4. Execution             — parallel or sequential node activation
  5. Quality Gate          — validate output
  6. Assurance Gate        — certify for deployment
  7. Pattern Capture       — log workflow for learning
  8. Story Update          — record narrative

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Coroutine, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ─── Golden ratio for priority math ──────────────────────────────────────────
PHI: float = 1.6180339887

# ─── Enumerations ─────────────────────────────────────────────────────────────


class TaskDomain(str, Enum):
    """Semantic domain classification for tasks."""
    CODE         = "code"
    SECURITY     = "security"
    RESEARCH     = "research"
    DOCS         = "docs"
    CREATIVE     = "creative"
    MONITORING   = "monitoring"
    ANALYTICS    = "analytics"
    MAINTENANCE  = "maintenance"
    UNKNOWN      = "unknown"


class PriorityPool(str, Enum):
    """Conductor priority pools with capacity quotas."""
    HOT        = "hot"        # 34 %
    WARM       = "warm"       # 21 %
    COLD       = "cold"       # 13 %
    RESERVE    = "reserve"    #  8 %
    GOVERNANCE = "governance" #  5 %


# Pool capacity fractions
POOL_CAPACITY: Dict[PriorityPool, float] = {
    PriorityPool.HOT:        0.34,
    PriorityPool.WARM:       0.21,
    PriorityPool.COLD:       0.13,
    PriorityPool.RESERVE:    0.08,
    PriorityPool.GOVERNANCE: 0.05,
}

# Pool urgency multipliers (used in scoring)
POOL_URGENCY: Dict[PriorityPool, float] = {
    PriorityPool.HOT:        PHI ** 3,
    PriorityPool.WARM:       PHI ** 2,
    PriorityPool.COLD:       PHI,
    PriorityPool.RESERVE:    1.0,
    PriorityPool.GOVERNANCE: PHI ** 4,  # Governance overrides everything
}


# ─── Data classes ─────────────────────────────────────────────────────────────


@dataclass
class ConductorTask:
    """A unit of work submitted to the conductor."""
    id:        str              = field(default_factory=lambda: str(uuid.uuid4()))
    payload:   Dict[str, Any]  = field(default_factory=dict)
    domain:    TaskDomain      = TaskDomain.UNKNOWN
    pool:      PriorityPool    = PriorityPool.WARM
    metadata:  Dict[str, Any]  = field(default_factory=dict)
    created_at: float          = field(default_factory=time.monotonic)
    deadline:  Optional[float] = None  # monotonic deadline
    tags:      List[str]       = field(default_factory=list)


@dataclass
class NodeProfile:
    """Description of an available execution node / agent."""
    node_id:       str
    skills:        List[str]       = field(default_factory=list)
    domains:       List[TaskDomain] = field(default_factory=list)
    pools:         List[PriorityPool] = field(default_factory=list)
    capacity:      int             = 8       # max concurrent tasks
    current_load:  int             = 0
    health_score:  float           = 1.0     # 0.0 – 1.0
    latency_ms:    float           = 0.0     # rolling average latency
    metadata:      Dict[str, Any]  = field(default_factory=dict)


@dataclass
class RoutingEntry:
    """A single entry in the hot-swappable routing table."""
    route_id:  str
    domain:    TaskDomain
    pool:      PriorityPool
    node_ids:  List[str]    = field(default_factory=list)
    weight:    float        = 1.0
    enabled:   bool         = True
    created_at: float       = field(default_factory=time.time)


@dataclass
class StageOutcome:
    """Result of one pipeline stage inside the conductor."""
    stage:    str
    success:  bool
    data:     Dict[str, Any] = field(default_factory=dict)
    duration: float          = 0.0
    error:    Optional[str]  = None


@dataclass
class ConductorResult:
    """Full result returned after conductor processing."""
    task_id:     str
    success:     bool
    domain:      TaskDomain
    pool:        PriorityPool
    stages:      List[StageOutcome]    = field(default_factory=list)
    selected_node: Optional[str]       = None
    arena_winner:  Optional[str]       = None
    output:      Dict[str, Any]        = field(default_factory=dict)
    metrics:     Dict[str, float]      = field(default_factory=dict)
    total_duration: float              = 0.0
    error:       Optional[str]         = None


@dataclass
class ArenaRun:
    """One competitor in an Arena evaluation."""
    run_id:    str
    node_id:   str
    config:    Dict[str, Any]     = field(default_factory=dict)
    output:    Dict[str, Any]     = field(default_factory=dict)
    score:     float              = 0.0
    duration:  float              = 0.0
    success:   bool               = False
    error:     Optional[str]      = None


@dataclass
class ConductorMetrics:
    """Aggregated metrics emitted by the conductor."""
    tasks_routed:     int   = 0
    tasks_succeeded:  int   = 0
    tasks_failed:     int   = 0
    arena_runs:       int   = 0
    avg_latency_ms:   float = 0.0
    pool_utilization: Dict[str, float] = field(default_factory=dict)
    domain_counts:    Dict[str, int]   = field(default_factory=dict)
    node_loads:       Dict[str, int]   = field(default_factory=dict)


# ─── Domain keyword hints for classification ──────────────────────────────────

_DOMAIN_KEYWORDS: Dict[TaskDomain, List[str]] = {
    TaskDomain.CODE:        ["code", "function", "class", "bug", "test", "implement",
                              "refactor", "compile", "lint", "build", "deploy", "ci", "cd"],
    TaskDomain.SECURITY:    ["security", "vuln", "cve", "auth", "token", "secret",
                              "encrypt", "hash", "password", "audit", "pentest"],
    TaskDomain.RESEARCH:    ["research", "paper", "study", "analyze", "survey",
                              "literature", "compare", "investigate", "explore"],
    TaskDomain.DOCS:        ["doc", "document", "readme", "spec", "api", "guide",
                              "tutorial", "changelog", "wiki", "markdown"],
    TaskDomain.CREATIVE:    ["creative", "design", "story", "write", "generate",
                              "compose", "brainstorm", "ideate", "narrative"],
    TaskDomain.MONITORING:  ["monitor", "alert", "metric", "log", "trace", "health",
                              "uptime", "incident", "pager", "observe"],
    TaskDomain.ANALYTICS:   ["analytic", "report", "dashboard", "kpi", "stat",
                              "chart", "aggregate", "insight", "trend", "forecast"],
    TaskDomain.MAINTENANCE: ["maintenance", "cleanup", "prune", "archive", "rotate",
                              "gc", "vacuum", "migrate", "upgrade", "patch"],
}

_URGENCY_KEYWORDS: Dict[PriorityPool, List[str]] = {
    PriorityPool.HOT:        ["urgent", "critical", "immediate", "now", "asap",
                               "live", "prod", "outage", "down"],
    PriorityPool.GOVERNANCE: ["compliance", "audit", "policy", "regulation",
                               "governance", "legal", "gdpr"],
    PriorityPool.WARM:       ["soon", "today", "priority"],
    PriorityPool.COLD:       ["batch", "deferred", "background", "low-priority", "later"],
    PriorityPool.RESERVE:    ["reserve", "overflow"],
}


# ─── HeadyConductor ───────────────────────────────────────────────────────────


class HeadyConductor:
    """
    Central routing and orchestration hub for the Heady system.

    Responsibilities:
      - Classify tasks into domains and priority pools
      - Select optimal execution nodes via routing table
      - Sequence tasks through the 8-stage HCFullPipeline
      - Run Arena Mode for competitive node evaluation
      - Emit metrics for observability
      - Expose hooks for vector memory and pattern engine integration
    """

    def __init__(
        self,
        node_capacity: int = 100,
        arena_enabled: bool = True,
        arena_min_nodes: int = 2,
        metrics_window: int = 1000,
    ) -> None:
        self._nodes:       Dict[str, NodeProfile]  = {}
        self._routes:      Dict[str, RoutingEntry] = {}
        self._metrics:     ConductorMetrics        = ConductorMetrics()
        self._task_queue:  Dict[PriorityPool, deque] = {
            p: deque() for p in PriorityPool
        }
        self._latency_window: deque = deque(maxlen=metrics_window)
        self._arena_enabled   = arena_enabled
        self._arena_min_nodes = arena_min_nodes

        # Integration hooks (callable, set externally)
        self._memory_hook:  Optional[Callable[[str, Dict], None]] = None
        self._pattern_hook: Optional[Callable[[str, Dict], None]] = None
        self._event_hooks:  Dict[str, List[Callable]] = defaultdict(list)

        self._lock = asyncio.Lock()
        logger.info("HeadyConductor initialised (arena=%s)", arena_enabled)

    # ── Node registry ────────────────────────────────────────────────────────

    def register_node(self, profile: NodeProfile) -> None:
        """Register an execution node into the conductor pool."""
        self._nodes[profile.node_id] = profile
        self._metrics.node_loads[profile.node_id] = 0
        logger.debug("Node registered: %s (skills=%s)", profile.node_id, profile.skills)

    def deregister_node(self, node_id: str) -> None:
        """Remove a node from the pool."""
        self._nodes.pop(node_id, None)
        self._metrics.node_loads.pop(node_id, None)
        logger.info("Node deregistered: %s", node_id)

    def update_node_health(self, node_id: str, health: float, latency_ms: float) -> None:
        """Update real-time health and latency for a node."""
        if node_id in self._nodes:
            self._nodes[node_id].health_score = max(0.0, min(1.0, health))
            self._nodes[node_id].latency_ms   = max(0.0, latency_ms)

    # ── Routing table ────────────────────────────────────────────────────────

    def add_route(self, entry: RoutingEntry) -> None:
        """Add or replace a routing table entry (hot-swappable)."""
        self._routes[entry.route_id] = entry
        logger.debug("Route added: %s → nodes=%s", entry.route_id, entry.node_ids)

    def remove_route(self, route_id: str) -> None:
        """Remove a routing entry by ID."""
        self._routes.pop(route_id, None)

    def toggle_route(self, route_id: str, enabled: bool) -> None:
        """Enable or disable a route without removing it."""
        if route_id in self._routes:
            self._routes[route_id].enabled = enabled

    def get_routing_table(self) -> List[RoutingEntry]:
        """Return a snapshot of the current routing table."""
        return list(self._routes.values())

    # ── Integration hooks ────────────────────────────────────────────────────

    def set_memory_hook(self, hook: Callable[[str, Dict], None]) -> None:
        """Register a vector-memory integration hook (called after Pattern Capture)."""
        self._memory_hook = hook

    def set_pattern_hook(self, hook: Callable[[str, Dict], None]) -> None:
        """Register a pattern-engine hook (called after Story Update)."""
        self._pattern_hook = hook

    def on(self, event: str, handler: Callable) -> None:
        """Register an event handler for a named conductor event."""
        self._event_hooks[event].append(handler)

    async def _emit(self, event: str, data: Dict[str, Any]) -> None:
        for handler in self._event_hooks.get(event, []):
            try:
                result = handler(event, data)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as exc:
                logger.warning("Event hook error (%s): %s", event, exc)

    # ── Classification ───────────────────────────────────────────────────────

    def classify_domain(self, text: str) -> TaskDomain:
        """
        Classify task text into a TaskDomain using keyword scoring.

        Scores each domain by counting keyword hits in the lowercase text.
        Returns the highest-scoring domain, defaulting to UNKNOWN.
        """
        lower = text.lower()
        scores: Dict[TaskDomain, int] = {}
        for domain, keywords in _DOMAIN_KEYWORDS.items():
            scores[domain] = sum(1 for kw in keywords if kw in lower)
        best = max(scores, key=lambda d: scores[d])
        return best if scores[best] > 0 else TaskDomain.UNKNOWN

    def classify_priority(self, text: str) -> PriorityPool:
        """
        Classify task text into a PriorityPool using urgency keyword scoring.

        Falls back to WARM if no urgency signals found.
        """
        lower = text.lower()
        for pool in (PriorityPool.GOVERNANCE, PriorityPool.HOT,
                     PriorityPool.COLD, PriorityPool.RESERVE, PriorityPool.WARM):
            keywords = _URGENCY_KEYWORDS.get(pool, [])
            if any(kw in lower for kw in keywords):
                return pool
        return PriorityPool.WARM

    def classify_task(self, task: ConductorTask) -> ConductorTask:
        """
        Auto-classify a task's domain and pool if not already set.

        Uses the task payload 'text' or 'description' field for classification.
        """
        text = (
            task.payload.get("text", "")
            or task.payload.get("description", "")
            or " ".join(str(v) for v in task.payload.values())
        )
        if task.domain == TaskDomain.UNKNOWN:
            task.domain = self.classify_domain(text)
        if task.pool == PriorityPool.WARM and "urgency" not in task.metadata:
            task.pool = self.classify_priority(text)
        return task

    # ── Node selection ───────────────────────────────────────────────────────

    def select_node(
        self,
        task: ConductorTask,
        exclude: Optional[List[str]] = None,
    ) -> Optional[str]:
        """
        Select the best execution node for a task.

        Scoring formula per node:
            score = health_score
                  × (1 - current_load / capacity)
                  × pool_match_bonus
                  × domain_match_bonus
                  × (1 / (1 + latency_norm))

        Returns the node_id with the highest score, or None if no nodes available.
        """
        exclude = set(exclude or [])
        candidates = [
            n for nid, n in self._nodes.items()
            if nid not in exclude and n.current_load < n.capacity and n.health_score > 0.1
        ]
        if not candidates:
            return None

        def _score(node: NodeProfile) -> float:
            load_ratio     = 1.0 - node.current_load / max(1, node.capacity)
            pool_bonus     = 1.5 if task.pool in node.pools else 1.0
            domain_bonus   = 1.5 if task.domain in node.domains else 1.0
            latency_norm   = node.latency_ms / 1000.0
            return (
                node.health_score
                * load_ratio
                * pool_bonus
                * domain_bonus
                * (1.0 / (1.0 + latency_norm))
            )

        best = max(candidates, key=_score)
        return best.node_id

    def _mark_node_busy(self, node_id: str) -> None:
        if node_id in self._nodes:
            self._nodes[node_id].current_load += 1
            self._metrics.node_loads[node_id] = self._nodes[node_id].current_load

    def _mark_node_free(self, node_id: str) -> None:
        if node_id in self._nodes:
            self._nodes[node_id].current_load = max(
                0, self._nodes[node_id].current_load - 1
            )
            self._metrics.node_loads[node_id] = self._nodes[node_id].current_load

    # ── 8-Stage HCFullPipeline sequence ──────────────────────────────────────

    async def run_pipeline(
        self,
        task: ConductorTask,
        executor: Optional[Callable[[ConductorTask, str], Coroutine]] = None,
    ) -> ConductorResult:
        """
        Execute a task through the 8-stage HCFullPipeline sequence.

        Stages:
          1. Context Assembly      — build context dict
          2. Intent Classification — domain + priority
          3. Node Selection        — pick optimal node
          4. Execution             — call executor (or stub)
          5. Quality Gate          — validate output structure
          6. Assurance Gate        — certify readiness
          7. Pattern Capture       — record workflow
          8. Story Update          — narrative log

        Args:
            task:     The ConductorTask to process.
            executor: Optional async callable(task, node_id) → dict output.

        Returns:
            ConductorResult with all stage outcomes and final output.
        """
        start   = time.monotonic()
        stages: List[StageOutcome] = []
        result  = ConductorResult(
            task_id=task.id,
            success=False,
            domain=task.domain,
            pool=task.pool,
        )

        async def _stage(name: str, coro) -> Optional[Dict[str, Any]]:
            t0 = time.monotonic()
            try:
                data = await coro
                elapsed = time.monotonic() - t0
                stages.append(StageOutcome(stage=name, success=True,
                                           data=data or {}, duration=elapsed))
                await self._emit(f"stage.{name.lower().replace(' ', '_')}.complete",
                                 {"task_id": task.id, "data": data})
                return data
            except Exception as exc:
                elapsed = time.monotonic() - t0
                stages.append(StageOutcome(stage=name, success=False,
                                           error=str(exc), duration=elapsed))
                logger.error("Stage '%s' failed for task %s: %s", name, task.id, exc)
                return None

        # Stage 1: Context Assembly
        context = await _stage("Context Assembly", self._stage_context_assembly(task))
        if context is None:
            result.error = "Context Assembly failed"
            result.stages = stages
            return result

        # Stage 2: Intent Classification
        cls_data = await _stage("Intent Classification", self._stage_intent_classification(task))
        if cls_data:
            task.domain = TaskDomain(cls_data.get("domain", task.domain.value))
            task.pool   = PriorityPool(cls_data.get("pool", task.pool.value))
            result.domain = task.domain
            result.pool   = task.pool

        # Stage 3: Node Selection
        sel_data = await _stage("Node Selection", self._stage_node_selection(task))
        node_id  = sel_data.get("node_id") if sel_data else None
        result.selected_node = node_id

        # Stage 4: Execution
        if node_id:
            self._mark_node_busy(node_id)
        try:
            exec_data = await _stage("Execution", self._stage_execution(task, node_id, executor))
        finally:
            if node_id:
                self._mark_node_free(node_id)
        if exec_data is None:
            result.error = "Execution failed"
            result.stages = stages
            return result

        output = exec_data.get("output", {})

        # Stage 5: Quality Gate
        qg_data = await _stage("Quality Gate", self._stage_quality_gate(task, output))
        if qg_data and not qg_data.get("passed", True):
            result.error = f"Quality Gate failed: {qg_data.get('reason')}"
            result.stages = stages
            return result

        # Stage 6: Assurance Gate
        ag_data = await _stage("Assurance Gate", self._stage_assurance_gate(task, output))
        if ag_data and not ag_data.get("certified", True):
            result.error = f"Assurance Gate failed: {ag_data.get('reason')}"
            result.stages = stages
            return result

        # Stage 7: Pattern Capture
        await _stage("Pattern Capture", self._stage_pattern_capture(task, stages, output))

        # Stage 8: Story Update
        await _stage("Story Update", self._stage_story_update(task, stages, output))

        elapsed = time.monotonic() - start
        result.success        = True
        result.stages         = stages
        result.output         = output
        result.total_duration = elapsed
        result.metrics        = self._compute_run_metrics(stages)

        self._record_metrics(task, elapsed, success=True)
        return result

    # ── Stage implementations ─────────────────────────────────────────────────

    async def _stage_context_assembly(self, task: ConductorTask) -> Dict[str, Any]:
        """Stage 1: Gather all relevant context for the task."""
        await asyncio.sleep(0)  # yield to event loop
        return {
            "task_id":   task.id,
            "domain":    task.domain.value,
            "pool":      task.pool.value,
            "payload":   task.payload,
            "tags":      task.tags,
            "metadata":  task.metadata,
            "timestamp": time.time(),
            "nodes_available": len([n for n in self._nodes.values()
                                    if n.current_load < n.capacity]),
        }

    async def _stage_intent_classification(self, task: ConductorTask) -> Dict[str, Any]:
        """Stage 2: Determine task type and urgency."""
        await asyncio.sleep(0)
        self.classify_task(task)
        return {
            "domain": task.domain.value,
            "pool":   task.pool.value,
            "confidence": 0.85,   # stub — real impl uses vector similarity
        }

    async def _stage_node_selection(self, task: ConductorTask) -> Dict[str, Any]:
        """Stage 3: Skill-based routing picks optimal node."""
        await asyncio.sleep(0)
        node_id = self.select_node(task)
        if node_id is None:
            raise RuntimeError("No available nodes for task routing")
        return {"node_id": node_id, "strategy": "skill_weighted"}

    async def _stage_execution(
        self,
        task: ConductorTask,
        node_id: Optional[str],
        executor: Optional[Callable],
    ) -> Dict[str, Any]:
        """Stage 4: Invoke the executor (parallel or sequential)."""
        await asyncio.sleep(0)
        if executor and node_id:
            output = await executor(task, node_id)
        else:
            # Stub output when no real executor is provided
            output = {"result": "stub_output", "task_id": task.id, "node": node_id}
        return {"output": output, "node_id": node_id}

    async def _stage_quality_gate(
        self, task: ConductorTask, output: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Stage 5: Validate output structure and basic quality."""
        await asyncio.sleep(0)
        passed = isinstance(output, dict) and len(output) > 0
        return {"passed": passed, "reason": None if passed else "Empty or invalid output"}

    async def _stage_assurance_gate(
        self, task: ConductorTask, output: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Stage 6: Certify output for deployment / use."""
        await asyncio.sleep(0)
        # Real impl: call security scanner, schema validator, etc.
        return {"certified": True, "certifier": "conductor_v1", "timestamp": time.time()}

    async def _stage_pattern_capture(
        self,
        task: ConductorTask,
        stages: List[StageOutcome],
        output: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Stage 7: Log workflow for learning / pattern engine."""
        await asyncio.sleep(0)
        record = {
            "task_id":  task.id,
            "domain":   task.domain.value,
            "pool":     task.pool.value,
            "stages":   [{"name": s.stage, "ok": s.success, "ms": round(s.duration * 1000, 2)}
                         for s in stages],
            "output_keys": list(output.keys()),
            "timestamp": time.time(),
        }
        if self._memory_hook:
            try:
                self._memory_hook("pattern", record)
            except Exception as exc:
                logger.warning("Memory hook error: %s", exc)
        return record

    async def _stage_story_update(
        self,
        task: ConductorTask,
        stages: List[StageOutcome],
        output: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Stage 8: Record narrative for the task story."""
        await asyncio.sleep(0)
        story = {
            "task_id":    task.id,
            "narrative":  (
                f"Task [{task.domain.value}/{task.pool.value}] processed "
                f"through {len(stages)} stages; output has {len(output)} keys."
            ),
            "timestamp":  time.time(),
        }
        if self._pattern_hook:
            try:
                self._pattern_hook("story", story)
            except Exception as exc:
                logger.warning("Pattern hook error: %s", exc)
        return story

    # ── Arena Mode ───────────────────────────────────────────────────────────

    async def run_arena(
        self,
        task: ConductorTask,
        node_ids: Optional[List[str]] = None,
        executor: Optional[Callable[[ConductorTask, str], Coroutine]] = None,
        scorer:   Optional[Callable[[ArenaRun], float]] = None,
        timeout:  float = 30.0,
    ) -> Tuple[Optional[ArenaRun], List[ArenaRun]]:
        """
        Arena Mode: run the same task through multiple node configurations
        concurrently, score each run, and return the winner.

        Args:
            task:     Task to run in the arena.
            node_ids: Nodes to compete (defaults to all available nodes).
            executor: Async callable(task, node_id) → dict.
            scorer:   Optional callable to score an ArenaRun (default: latency × success).
            timeout:  Per-run wall-clock timeout in seconds.

        Returns:
            Tuple of (winner ArenaRun or None, all ArenaRun results).
        """
        if not self._arena_enabled:
            raise RuntimeError("Arena mode is disabled on this conductor")

        candidates = node_ids or [
            nid for nid, n in self._nodes.items()
            if n.current_load < n.capacity and n.health_score > 0.1
        ]
        if len(candidates) < self._arena_min_nodes:
            logger.warning(
                "Arena needs ≥%d nodes, only %d available",
                self._arena_min_nodes, len(candidates),
            )
            if not candidates:
                return None, []

        def _default_scorer(run: ArenaRun) -> float:
            if not run.success:
                return -1.0
            # Higher is better: reward speed, penalise failure
            return 1.0 / (1.0 + run.duration) * 100.0

        score_fn = scorer or _default_scorer

        async def _run_one(node_id: str) -> ArenaRun:
            run = ArenaRun(run_id=str(uuid.uuid4()), node_id=node_id)
            t0  = time.monotonic()
            try:
                if executor:
                    run.output = await asyncio.wait_for(executor(task, node_id), timeout=timeout)
                else:
                    await asyncio.sleep(0)
                    run.output = {"stub": True, "node": node_id}
                run.success  = True
            except asyncio.TimeoutError:
                run.error   = "timeout"
            except Exception as exc:
                run.error   = str(exc)
            run.duration = time.monotonic() - t0
            run.score    = score_fn(run)
            return run

        runs = await asyncio.gather(*[_run_one(nid) for nid in candidates])
        runs = list(runs)
        runs.sort(key=lambda r: r.score, reverse=True)
        winner = runs[0] if runs and runs[0].success else None

        self._metrics.arena_runs += len(runs)
        await self._emit("arena.complete", {
            "task_id": task.id,
            "winner":  winner.node_id if winner else None,
            "runs":    len(runs),
        })
        logger.info(
            "Arena completed: %d runs, winner=%s (score=%.2f)",
            len(runs), winner.node_id if winner else "none",
            winner.score if winner else 0.0,
        )
        return winner, runs

    # ── Main dispatch entry point ────────────────────────────────────────────

    async def dispatch(
        self,
        payload:  Dict[str, Any],
        domain:   Optional[TaskDomain]   = None,
        pool:     Optional[PriorityPool] = None,
        tags:     Optional[List[str]]    = None,
        metadata: Optional[Dict]         = None,
        executor: Optional[Callable]     = None,
        arena:    bool                   = False,
    ) -> ConductorResult:
        """
        High-level entry point: create a task and run it through the conductor.

        If ``arena=True`` the task runs in Arena Mode; otherwise it goes
        through the 8-stage HCFullPipeline.
        """
        task = ConductorTask(
            payload  = payload,
            domain   = domain or TaskDomain.UNKNOWN,
            pool     = pool   or PriorityPool.WARM,
            tags     = tags   or [],
            metadata = metadata or {},
        )
        self.classify_task(task)

        self._metrics.tasks_routed += 1
        self._metrics.domain_counts[task.domain.value] = (
            self._metrics.domain_counts.get(task.domain.value, 0) + 1
        )

        await self._emit("task.dispatched", {"task_id": task.id, "domain": task.domain.value})

        if arena and self._arena_enabled:
            winner, runs = await self.run_arena(task, executor=executor)
            node_id = winner.node_id if winner else None
            output  = winner.output  if winner else {}
            return ConductorResult(
                task_id      = task.id,
                success      = winner is not None,
                domain       = task.domain,
                pool         = task.pool,
                selected_node = node_id,
                arena_winner  = node_id,
                output        = output,
                metrics       = {
                    "arena_runs":      len(runs),
                    "winner_score":    winner.score if winner else 0.0,
                    "winner_duration": winner.duration if winner else 0.0,
                },
            )

        return await self.run_pipeline(task, executor=executor)

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _compute_run_metrics(self, stages: List[StageOutcome]) -> Dict[str, float]:
        total = sum(s.duration for s in stages)
        return {
            "total_ms":   round(total * 1000, 2),
            "stages":     len(stages),
            "failed_stages": sum(1 for s in stages if not s.success),
            **{f"stage_{s.stage.lower().replace(' ', '_')}_ms":
               round(s.duration * 1000, 2) for s in stages},
        }

    def _record_metrics(self, task: ConductorTask, elapsed: float, success: bool) -> None:
        self._latency_window.append(elapsed * 1000)
        if success:
            self._metrics.tasks_succeeded += 1
        else:
            self._metrics.tasks_failed += 1
        # Rolling average
        self._metrics.avg_latency_ms = (
            sum(self._latency_window) / len(self._latency_window)
        )

    def get_metrics(self) -> ConductorMetrics:
        """Return a copy of the current aggregated metrics."""
        import copy
        return copy.deepcopy(self._metrics)

    def get_node_profiles(self) -> List[NodeProfile]:
        """Return all registered node profiles."""
        return list(self._nodes.values())

    def __repr__(self) -> str:
        return (
            f"HeadyConductor(nodes={len(self._nodes)}, "
            f"routes={len(self._routes)}, arena={self._arena_enabled})"
        )
