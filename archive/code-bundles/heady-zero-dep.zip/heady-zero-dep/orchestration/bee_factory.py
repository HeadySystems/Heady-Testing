"""
bee_factory.py
==============
Agent Worker Factory (Bee system) for the Heady orchestration layer.

Architecture:
  ┌────────────────────────────────────────────────────────────┐
  │  BeeFactory                                                │
  │                                                            │
  │  ┌──────────────┐  ┌──────────────────┐  ┌────────────┐  │
  │  │  Bee Registry │  │  Health Monitor  │  │  Swarm Mgr │  │
  │  └──────────────┘  └──────────────────┘  └────────────┘  │
  │                                                            │
  │  ┌────────────────────────────────────────────────────┐   │
  │  │  Bee Instances (up to 24 domain types)             │   │
  │  │  code • security • research • docs • creative      │   │
  │  │  monitoring • analytics • maintenance • testing    │   │
  │  │  devops • data • ml • infra • finance • legal      │   │
  │  │  marketing • support • onboarding • qa • review    │   │
  │  │  planning • reporting • integration • custom       │   │
  │  └────────────────────────────────────────────────────┘   │
  └────────────────────────────────────────────────────────────┘

Bee lifecycle:
  SPAWNING → ACTIVE → IDLE → TERMINATING → TERMINATED

Communication:
  BeeMessage objects passed through asyncio.Queue channels.
  Each Bee has an inbox queue and an optional outbox queue.

Swarm mode:
  Multiple Bees coordinated on a single task via BeeSwarm.
  SwarmConfig controls strategy: parallel, sequential, vote, pipeline.

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Coroutine, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

# ─── Bee domain types ────────────────────────────────────────────────────────


class BeeDomain(str, Enum):
    """24 specialised agent worker domains."""
    CODE        = "code"
    SECURITY    = "security"
    RESEARCH    = "research"
    DOCS        = "docs"
    CREATIVE    = "creative"
    MONITORING  = "monitoring"
    ANALYTICS   = "analytics"
    MAINTENANCE = "maintenance"
    TESTING     = "testing"
    DEVOPS      = "devops"
    DATA        = "data"
    ML          = "ml"
    INFRA       = "infra"
    FINANCE     = "finance"
    LEGAL       = "legal"
    MARKETING   = "marketing"
    SUPPORT     = "support"
    ONBOARDING  = "onboarding"
    QA          = "qa"
    REVIEW      = "review"
    PLANNING    = "planning"
    REPORTING   = "reporting"
    INTEGRATION = "integration"
    CUSTOM      = "custom"


class BeeStatus(str, Enum):
    """Bee lifecycle states."""
    SPAWNING    = "spawning"
    ACTIVE      = "active"
    IDLE        = "idle"
    TERMINATING = "terminating"
    TERMINATED  = "terminated"
    ERROR       = "error"


# ─── Bee message ─────────────────────────────────────────────────────────────


@dataclass
class BeeMessage:
    """Message passed between Bees or from factory to Bee."""
    msg_id:     str             = field(default_factory=lambda: str(uuid.uuid4()))
    sender_id:  str             = "factory"
    recipient:  str             = "*"       # bee_id or "*" for broadcast
    topic:      str             = "task"
    payload:    Dict[str, Any]  = field(default_factory=dict)
    created_at: float           = field(default_factory=time.time)
    reply_to:   Optional[str]   = None     # msg_id to reply to
    ttl:        float           = 60.0     # seconds until expiry


@dataclass
class BeeHealth:
    """Health snapshot of a single Bee."""
    bee_id:       str
    status:       BeeStatus
    tasks_done:   int   = 0
    tasks_failed: int   = 0
    uptime:       float = 0.0
    last_task_at: float = 0.0
    cpu_tokens:   int   = 0     # conceptual resource tokens consumed
    error_rate:   float = 0.0


@dataclass
class BeeConfig:
    """Configuration for a Bee instance."""
    domain:        BeeDomain           = BeeDomain.CUSTOM
    max_tasks:     int                 = 10      # max concurrent tasks
    idle_timeout:  float               = 300.0   # seconds before auto-terminate
    task_timeout:  float               = 60.0    # per-task timeout
    resource_limit: int                = 1000    # conceptual CPU tokens
    metadata:      Dict[str, Any]      = field(default_factory=dict)
    skills:        List[str]           = field(default_factory=list)
    tags:          List[str]           = field(default_factory=list)


@dataclass
class BeeSwarmConfig:
    """Configuration for a Bee swarm on a single task."""
    strategy:        str            = "parallel"   # parallel | sequential | vote | pipeline
    min_bees:        int            = 2
    max_bees:        int            = 8
    consensus_threshold: float     = 0.6           # for 'vote' strategy
    aggregation:     str            = "merge"       # merge | pick_best | synthesize
    timeout:         float          = 120.0


# ─── Bee ─────────────────────────────────────────────────────────────────────


class Bee:
    """
    A single agent worker instance.

    Each Bee has:
      - An asyncio inbox queue for receiving BeeMessages
      - A handler registry keyed by message topic
      - Lifecycle management (spawn → active → idle → terminate)
      - Health tracking (task counts, error rates, uptime)

    Usage::

        bee = Bee(BeeConfig(domain=BeeDomain.CODE))
        bee.register_handler("task", my_code_handler)
        await bee.spawn()
        await bee.send(BeeMessage(topic="task", payload={"code": "..."}))
        result = await bee.receive()
        await bee.terminate()
    """

    def __init__(
        self,
        config:   BeeConfig,
        bee_id:   Optional[str] = None,
        factory:  Optional["BeeFactory"] = None,
    ) -> None:
        self.bee_id   = bee_id or str(uuid.uuid4())
        self.config   = config
        self.domain   = config.domain
        self._factory = factory
        self._status  = BeeStatus.SPAWNING

        self._inbox:   asyncio.Queue = asyncio.Queue(maxsize=100)
        self._outbox:  asyncio.Queue = asyncio.Queue(maxsize=100)
        self._handlers: Dict[str, Callable] = {}

        self._spawned_at:  float = 0.0
        self._last_task:   float = 0.0
        self._tasks_done:  int   = 0
        self._tasks_failed: int  = 0
        self._cpu_tokens:  int   = 0
        self._active_tasks: int  = 0

        self._run_task:    Optional[asyncio.Task] = None
        self._idle_timer:  Optional[asyncio.Task] = None
        self._shutdown_ev: asyncio.Event          = asyncio.Event()

    # ── Lifecycle ────────────────────────────────────────────────────────────

    async def spawn(self) -> "Bee":
        """Transition to ACTIVE and start the inbox processing loop."""
        self._spawned_at = time.monotonic()
        self._status     = BeeStatus.ACTIVE
        self._run_task   = asyncio.create_task(self._run_loop(), name=f"bee-{self.bee_id[:8]}")
        self._reset_idle_timer()
        logger.debug("Bee %s spawned (domain=%s)", self.bee_id[:8], self.domain.value)
        return self

    async def terminate(self, reason: str = "requested") -> None:
        """Gracefully shut down the Bee."""
        if self._status in (BeeStatus.TERMINATED, BeeStatus.TERMINATING):
            return
        self._status = BeeStatus.TERMINATING
        self._shutdown_ev.set()
        if self._idle_timer and not self._idle_timer.done():
            self._idle_timer.cancel()
        if self._run_task and not self._run_task.done():
            self._run_task.cancel()
            try:
                await asyncio.wait_for(self._run_task, timeout=5.0)
            except (asyncio.CancelledError, asyncio.TimeoutError):
                pass
        self._status = BeeStatus.TERMINATED
        logger.debug("Bee %s terminated (%s)", self.bee_id[:8], reason)

    # ── Handlers ─────────────────────────────────────────────────────────────

    def register_handler(self, topic: str, handler: Callable) -> None:
        """Register an async or sync handler for a message topic."""
        self._handlers[topic] = handler

    def on(self, topic: str) -> Callable:
        """Decorator to register a topic handler."""
        def _dec(fn: Callable) -> Callable:
            self.register_handler(topic, fn)
            return fn
        return _dec

    # ── Messaging ────────────────────────────────────────────────────────────

    async def send(self, message: BeeMessage) -> None:
        """Put a message into this Bee's inbox."""
        await self._inbox.put(message)
        self._status = BeeStatus.ACTIVE

    async def receive(self, timeout: float = 5.0) -> Optional[BeeMessage]:
        """Get a response from this Bee's outbox (blocking with timeout)."""
        try:
            return await asyncio.wait_for(self._outbox.get(), timeout=timeout)
        except asyncio.TimeoutError:
            return None

    async def ask(
        self, topic: str, payload: Dict[str, Any], timeout: float = 30.0
    ) -> Optional[Dict[str, Any]]:
        """
        Send a message and wait for a reply.

        Returns the response payload dict, or None on timeout.
        """
        msg_id  = str(uuid.uuid4())
        message = BeeMessage(
            msg_id  = msg_id,
            topic   = topic,
            payload = payload,
        )
        await self.send(message)
        try:
            reply = await asyncio.wait_for(self._outbox.get(), timeout=timeout)
            return reply.payload if reply else None
        except asyncio.TimeoutError:
            return None

    # ── Main loop ────────────────────────────────────────────────────────────

    async def _run_loop(self) -> None:
        """Process inbox messages until shutdown."""
        while not self._shutdown_ev.is_set():
            try:
                msg = await asyncio.wait_for(self._inbox.get(), timeout=1.0)
                await self._process_message(msg)
            except asyncio.TimeoutError:
                # Check idle timeout
                if (self._active_tasks == 0
                        and self._last_task > 0
                        and time.monotonic() - self._last_task > self.config.idle_timeout):
                    self._status = BeeStatus.IDLE
                continue
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("Bee %s loop error: %s", self.bee_id[:8], exc)

    async def _process_message(self, msg: BeeMessage) -> None:
        """Dispatch a message to the appropriate handler."""
        if self._active_tasks >= self.config.max_tasks:
            logger.warning("Bee %s at capacity, queuing message", self.bee_id[:8])

        self._active_tasks += 1
        self._last_task     = time.monotonic()
        self._status        = BeeStatus.ACTIVE
        self._reset_idle_timer()

        try:
            handler = self._handlers.get(msg.topic) or self._handlers.get("*")
            if handler is None:
                result = await self._default_handler(msg)
            elif asyncio.iscoroutinefunction(handler):
                result = await asyncio.wait_for(
                    handler(msg),
                    timeout=self.config.task_timeout,
                )
            else:
                loop   = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, handler, msg)

            self._tasks_done += 1
            self._cpu_tokens += 1
            response = BeeMessage(
                sender_id = self.bee_id,
                recipient = msg.sender_id,
                topic     = f"{msg.topic}.reply",
                payload   = result if isinstance(result, dict) else {"result": result},
                reply_to  = msg.msg_id,
            )
            await self._outbox.put(response)

        except asyncio.TimeoutError:
            self._tasks_failed += 1
            self._status = BeeStatus.ERROR
            logger.warning("Bee %s task timeout (topic=%s)", self.bee_id[:8], msg.topic)
        except Exception as exc:
            self._tasks_failed += 1
            logger.error("Bee %s handler error: %s", self.bee_id[:8], exc)
        finally:
            self._active_tasks = max(0, self._active_tasks - 1)

    async def _default_handler(self, msg: BeeMessage) -> Dict[str, Any]:
        """Default stub handler when no topic handler is registered."""
        await asyncio.sleep(0)
        return {
            "bee_id":  self.bee_id,
            "domain":  self.domain.value,
            "topic":   msg.topic,
            "payload": msg.payload,
            "note":    "No handler registered for this topic",
        }

    def _reset_idle_timer(self) -> None:
        if self._idle_timer and not self._idle_timer.done():
            self._idle_timer.cancel()
        self._idle_timer = asyncio.create_task(self._idle_countdown())

    async def _idle_countdown(self) -> None:
        await asyncio.sleep(self.config.idle_timeout)
        if self._active_tasks == 0:
            self._status = BeeStatus.IDLE

    # ── Health ────────────────────────────────────────────────────────────────

    def health(self) -> BeeHealth:
        """Return a health snapshot."""
        done   = self._tasks_done
        failed = self._tasks_failed
        total  = done + failed
        return BeeHealth(
            bee_id       = self.bee_id,
            status       = self._status,
            tasks_done   = done,
            tasks_failed = failed,
            uptime       = time.monotonic() - self._spawned_at if self._spawned_at else 0.0,
            last_task_at = self._last_task,
            cpu_tokens   = self._cpu_tokens,
            error_rate   = failed / total if total > 0 else 0.0,
        )

    @property
    def status(self) -> BeeStatus:
        return self._status

    @property
    def is_alive(self) -> bool:
        return self._status in (BeeStatus.ACTIVE, BeeStatus.IDLE, BeeStatus.SPAWNING)

    def __repr__(self) -> str:
        return f"Bee(id={self.bee_id[:8]}, domain={self.domain.value}, status={self._status.value})"


# ─── BeeSwarm ────────────────────────────────────────────────────────────────


class BeeSwarm:
    """
    A coordinated group of Bees working on a single task.

    Strategies:
      parallel    — all Bees run concurrently, results merged
      sequential  — Bees run in sequence, each feeding the next
      vote        — all Bees run, majority result selected
      pipeline    — output of each Bee becomes input of the next
    """

    def __init__(self, bees: List[Bee], config: BeeSwarmConfig) -> None:
        self.swarm_id = str(uuid.uuid4())
        self.bees     = bees
        self.config   = config

    async def run(
        self, topic: str, payload: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Dispatch the task to all Bees according to the configured strategy.

        Returns aggregated results.
        """
        if self.config.strategy == "parallel":
            return await self._run_parallel(topic, payload)
        elif self.config.strategy == "sequential":
            return await self._run_sequential(topic, payload)
        elif self.config.strategy == "vote":
            return await self._run_vote(topic, payload)
        elif self.config.strategy == "pipeline":
            return await self._run_pipeline(topic, payload)
        else:
            raise ValueError(f"Unknown swarm strategy: {self.config.strategy!r}")

    async def _run_parallel(self, topic: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """All Bees run the same task concurrently."""
        async def _ask_one(bee: Bee) -> Optional[Dict]:
            return await bee.ask(topic, payload, timeout=self.config.timeout)

        results = await asyncio.gather(*[_ask_one(b) for b in self.bees])
        valid   = [r for r in results if r is not None]
        return self._aggregate(valid)

    async def _run_sequential(self, topic: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Bees run one after another; each receives the accumulated output."""
        accumulated = dict(payload)
        for bee in self.bees:
            result = await bee.ask(topic, accumulated, timeout=self.config.timeout)
            if result:
                accumulated.update(result)
        return accumulated

    async def _run_vote(self, topic: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """All Bees run; majority result (by 'answer' key) wins."""
        results = await self._run_parallel(topic, payload)
        # Count 'answer' votes
        votes: Dict[str, int] = defaultdict(int)
        raw_results = results.get("_all", [])
        for r in raw_results:
            answer = str(r.get("answer", r.get("result", "")))
            votes[answer] += 1
        if votes:
            winner = max(votes, key=lambda k: votes[k])
            if votes[winner] / len(self.bees) >= self.config.consensus_threshold:
                return {"answer": winner, "votes": dict(votes), "consensus": True}
        return {**results, "consensus": False, "votes": dict(votes)}

    async def _run_pipeline(self, topic: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Output of each Bee becomes the input of the next."""
        return await self._run_sequential(topic, payload)

    def _aggregate(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not results:
            return {}
        if self.config.aggregation == "merge":
            merged = {}
            for r in results:
                merged.update(r)
            merged["_all"] = results
            return merged
        elif self.config.aggregation == "pick_best":
            # Pick result with most keys (most detailed)
            best = max(results, key=lambda r: len(r))
            best["_all"] = results
            return best
        elif self.config.aggregation == "synthesize":
            merged = {"_all": results, "_count": len(results)}
            # Collect all unique keys
            for r in results:
                for k, v in r.items():
                    if k not in merged:
                        merged[k] = v
            return merged
        return results[0]

    def health(self) -> Dict[str, Any]:
        healths = [b.health() for b in self.bees]
        total_done   = sum(h.tasks_done for h in healths)
        total_failed = sum(h.tasks_failed for h in healths)
        total        = total_done + total_failed
        return {
            "swarm_id":    self.swarm_id,
            "bee_count":   len(self.bees),
            "active_bees": sum(1 for h in healths if h.status == BeeStatus.ACTIVE),
            "tasks_done":  total_done,
            "tasks_failed": total_failed,
            "error_rate":  total_failed / total if total > 0 else 0.0,
        }

    def __repr__(self) -> str:
        return f"BeeSwarm(id={self.swarm_id[:8]}, bees={len(self.bees)}, strategy={self.config.strategy})"


# ─── BeeFactory ──────────────────────────────────────────────────────────────


class BeeFactory:
    """
    Factory for creating and managing specialised agent worker Bees.

    Provides:
      - createBee(domain, config) → persistent Bee instance
      - spawnBee(domain, config)  → ephemeral one-shot Bee
      - Registry for discovery and health monitoring
      - Resource limit enforcement per Bee
      - Swarm creation and coordination
      - Broadcast messaging to all active Bees

    Usage::

        factory = BeeFactory()
        bee = await factory.create_bee(BeeDomain.CODE)

        @bee.on("task")
        async def handle_task(msg):
            return {"result": f"processed: {msg.payload}"}

        result = await bee.ask("task", {"code": "print('hello')"})
        print(result)
    """

    def __init__(self, max_bees: int = 200) -> None:
        self._registry:   Dict[str, Bee]                    = {}
        self._by_domain:  Dict[BeeDomain, List[str]]        = defaultdict(list)
        self._swarms:     Dict[str, BeeSwarm]               = {}
        self._max_bees    = max_bees
        self._total_created = 0

    # ── Factory methods ──────────────────────────────────────────────────────

    async def create_bee(
        self,
        domain:    BeeDomain    = BeeDomain.CUSTOM,
        config:    Optional[BeeConfig] = None,
        bee_id:    Optional[str] = None,
        handlers:  Optional[Dict[str, Callable]] = None,
    ) -> Bee:
        """
        Create a persistent Bee and add it to the registry.

        The Bee is automatically spawned (active) after creation.
        """
        if len(self._registry) >= self._max_bees:
            raise RuntimeError(f"BeeFactory at capacity ({self._max_bees} bees)")

        cfg     = config or BeeConfig(domain=domain)
        cfg.domain = domain
        bee_id  = bee_id or str(uuid.uuid4())
        bee     = Bee(config=cfg, bee_id=bee_id, factory=self)

        if handlers:
            for topic, handler in handlers.items():
                bee.register_handler(topic, handler)

        self._registry[bee_id] = bee
        self._by_domain[domain].append(bee_id)
        self._total_created += 1

        await bee.spawn()
        logger.info("Bee created: %s (domain=%s)", bee_id[:8], domain.value)
        return bee

    async def spawn_bee(
        self,
        domain:   BeeDomain   = BeeDomain.CUSTOM,
        task:     Optional[Dict[str, Any]] = None,
        handler:  Optional[Callable]       = None,
        config:   Optional[BeeConfig]      = None,
        timeout:  float                    = 30.0,
    ) -> Optional[Dict[str, Any]]:
        """
        Create an ephemeral Bee, run it on a single task, then terminate it.

        Returns the task result, or None on timeout/failure.
        """
        cfg          = config or BeeConfig(domain=domain)
        cfg.domain   = domain
        ephemeral_id = str(uuid.uuid4())
        bee          = Bee(config=cfg, bee_id=ephemeral_id, factory=self)

        if handler:
            bee.register_handler("task", handler)

        try:
            await bee.spawn()
            if task:
                result = await bee.ask("task", task, timeout=timeout)
            else:
                result = None
            return result
        finally:
            await bee.terminate("ephemeral-done")

    # ── Registry ──────────────────────────────────────────────────────────────

    def get_bee(self, bee_id: str) -> Optional[Bee]:
        """Look up a Bee by ID."""
        return self._registry.get(bee_id)

    def get_bees_by_domain(
        self, domain: BeeDomain, alive_only: bool = True
    ) -> List[Bee]:
        """Return all registered Bees for a given domain."""
        ids  = self._by_domain.get(domain, [])
        bees = [self._registry[bid] for bid in ids if bid in self._registry]
        if alive_only:
            bees = [b for b in bees if b.is_alive]
        return bees

    def list_bees(self, domain: Optional[BeeDomain] = None) -> List[Bee]:
        """List all registered Bees, optionally filtered by domain."""
        if domain:
            return self.get_bees_by_domain(domain)
        return list(self._registry.values())

    async def terminate_bee(self, bee_id: str, reason: str = "factory_terminate") -> bool:
        """Terminate a specific Bee and remove it from the registry."""
        bee = self._registry.pop(bee_id, None)
        if bee is None:
            return False
        self._by_domain[bee.domain] = [
            bid for bid in self._by_domain[bee.domain] if bid != bee_id
        ]
        await bee.terminate(reason)
        return True

    async def terminate_all(self) -> int:
        """Terminate all registered Bees. Returns count terminated."""
        ids = list(self._registry.keys())
        for bee_id in ids:
            await self.terminate_bee(bee_id, "factory_shutdown")
        return len(ids)

    # ── Swarm management ─────────────────────────────────────────────────────

    async def create_swarm(
        self,
        domain:    BeeDomain,
        size:      int          = 3,
        config:    Optional[BeeSwarmConfig] = None,
        handlers:  Optional[Dict[str, Callable]] = None,
    ) -> BeeSwarm:
        """
        Create a BeeSwarm of ``size`` Bees for the given domain.

        All Bees in the swarm are spawned and registered in the factory.
        """
        swarm_config = config or BeeSwarmConfig()
        bees: List[Bee] = []
        for _ in range(size):
            bee = await self.create_bee(domain=domain, handlers=handlers)
            bees.append(bee)
        swarm = BeeSwarm(bees=bees, config=swarm_config)
        self._swarms[swarm.swarm_id] = swarm
        logger.info("Swarm created: %s (%d bees, domain=%s)", swarm.swarm_id[:8], size, domain.value)
        return swarm

    def get_swarm(self, swarm_id: str) -> Optional[BeeSwarm]:
        return self._swarms.get(swarm_id)

    async def dissolve_swarm(self, swarm_id: str) -> bool:
        """Terminate all Bees in a swarm and remove it from the registry."""
        swarm = self._swarms.pop(swarm_id, None)
        if not swarm:
            return False
        for bee in swarm.bees:
            await self.terminate_bee(bee.bee_id, "swarm_dissolved")
        return True

    # ── Broadcast messaging ───────────────────────────────────────────────────

    async def broadcast(
        self,
        topic:   str,
        payload: Dict[str, Any],
        domain:  Optional[BeeDomain] = None,
    ) -> int:
        """
        Send a message to all active Bees (optionally filtered by domain).

        Returns count of Bees reached.
        """
        targets = self.list_bees(domain=domain)
        targets = [b for b in targets if b.is_alive]
        for bee in targets:
            await bee.send(BeeMessage(topic=topic, payload=payload, recipient="*"))
        logger.debug("Broadcast '%s' to %d bees", topic, len(targets))
        return len(targets)

    # ── Health monitoring ─────────────────────────────────────────────────────

    def health_report(self) -> Dict[str, Any]:
        """Aggregate health across all registered Bees."""
        healths = [b.health() for b in self._registry.values()]
        total_done   = sum(h.tasks_done for h in healths)
        total_failed = sum(h.tasks_failed for h in healths)
        total        = total_done + total_failed

        by_status: Dict[str, int] = defaultdict(int)
        for h in healths:
            by_status[h.status.value] += 1

        by_domain: Dict[str, int] = defaultdict(int)
        for bee in self._registry.values():
            by_domain[bee.domain.value] += 1

        return {
            "total_bees":    len(healths),
            "total_created": self._total_created,
            "by_status":     dict(by_status),
            "by_domain":     dict(by_domain),
            "tasks_done":    total_done,
            "tasks_failed":  total_failed,
            "error_rate":    total_failed / total if total > 0 else 0.0,
            "swarms":        len(self._swarms),
        }

    async def prune_dead_bees(self) -> int:
        """Remove terminated/errored Bees from the registry. Returns count removed."""
        dead = [
            bid for bid, b in self._registry.items()
            if b.status in (BeeStatus.TERMINATED, BeeStatus.ERROR)
        ]
        for bid in dead:
            self._registry.pop(bid)
            for domain_ids in self._by_domain.values():
                if bid in domain_ids:
                    domain_ids.remove(bid)
        if dead:
            logger.info("Pruned %d dead bees", len(dead))
        return len(dead)

    # ── Auto-scale ────────────────────────────────────────────────────────────

    async def autoscale(
        self,
        domain:    BeeDomain,
        target:    int,
        handlers:  Optional[Dict[str, Callable]] = None,
    ) -> Dict[str, int]:
        """
        Scale the number of live Bees for a domain to ``target``.

        Adds or terminates Bees as needed.
        Returns {"added": N, "terminated": N, "current": N}.
        """
        current_bees = self.get_bees_by_domain(domain, alive_only=True)
        current      = len(current_bees)
        added        = 0
        terminated   = 0

        if current < target:
            for _ in range(target - current):
                await self.create_bee(domain=domain, handlers=handlers)
                added += 1
        elif current > target:
            to_remove = current_bees[target:]
            for bee in to_remove:
                await self.terminate_bee(bee.bee_id, "autoscale_down")
                terminated += 1

        return {
            "added":      added,
            "terminated": terminated,
            "current":    len(self.get_bees_by_domain(domain, alive_only=True)),
        }

    def __repr__(self) -> str:
        return (
            f"BeeFactory(bees={len(self._registry)}/{self._max_bees}, "
            f"swarms={len(self._swarms)})"
        )
