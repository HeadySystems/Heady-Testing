"""
mcp_protocol.py
===============
Model Context Protocol (MCP) handler — replaces @modelcontextprotocol/sdk.

Implements the MCP specification on top of JSON-RPC 2.0, with both SSE
and stdio transports and an optional HTTP transport via core/http_server.py.

Architecture:
  ┌────────────────────────────────────────────────────────┐
  │  MCPServer                                             │
  │                                                        │
  │  ┌─────────────┐  ┌──────────────┐  ┌─────────────┐  │
  │  │  Tool Reg.  │  │  Resource    │  │  Prompt     │  │
  │  │  & Executor │  │  Listing     │  │  Templates  │  │
  │  └─────────────┘  └──────────────┘  └─────────────┘  │
  │                                                        │
  │  ┌─────────────────────────────────────────────────┐  │
  │  │           JSON-RPC 2.0 Dispatcher               │  │
  │  └─────────────────────────────────────────────────┘  │
  │                                                        │
  │  ┌──────────────┐  ┌──────────────┐                   │
  │  │  SSE Transport│  │ stdio Transport│                  │
  │  └──────────────┘  └──────────────┘                   │
  └────────────────────────────────────────────────────────┘

MCP Methods supported:
  initialize              — capability negotiation + session start
  notifications/initialized — client ready signal
  tools/list              — list registered tools
  tools/call              — execute a tool
  resources/list          — list available resources
  resources/read          — read resource content
  prompts/list            — list prompt templates
  prompts/get             — render a prompt template
  ping                    — liveness check

Error codes (per MCP spec, which extends JSON-RPC):
  -32700  Parse error
  -32600  Invalid Request
  -32601  Method not found
  -32602  Invalid params
  -32603  Internal error
  -32001  Tool not found
  -32002  Resource not found
  -32003  Prompt not found
  -32004  Tool execution error
  -32005  Unauthorized
  -32006  Rate limited

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import sys
import time
import uuid
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, AsyncIterator, Callable, Dict, List, Optional, Union

logger = logging.getLogger(__name__)

# ─── JSON-RPC / MCP Error Codes ───────────────────────────────────────────────


class MCPErrorCode(IntEnum):
    PARSE_ERROR         = -32700
    INVALID_REQUEST     = -32600
    METHOD_NOT_FOUND    = -32601
    INVALID_PARAMS      = -32602
    INTERNAL_ERROR      = -32603
    TOOL_NOT_FOUND      = -32001
    RESOURCE_NOT_FOUND  = -32002
    PROMPT_NOT_FOUND    = -32003
    TOOL_EXEC_ERROR     = -32004
    UNAUTHORIZED        = -32005
    RATE_LIMITED        = -32006


# ─── JSON-RPC 2.0 primitives ─────────────────────────────────────────────────


@dataclass
class JSONRPCRequest:
    """A JSON-RPC 2.0 request object."""
    method:  str
    params:  Optional[Union[Dict, List]] = None
    id:      Optional[Union[str, int]]   = None
    jsonrpc: str                         = "2.0"

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"jsonrpc": self.jsonrpc, "method": self.method}
        if self.params is not None:
            d["params"] = self.params
        if self.id is not None:
            d["id"] = self.id
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "JSONRPCRequest":
        return cls(
            method  = data["method"],
            params  = data.get("params"),
            id      = data.get("id"),
            jsonrpc = data.get("jsonrpc", "2.0"),
        )


@dataclass
class JSONRPCResponse:
    """A JSON-RPC 2.0 response object (result or error)."""
    id:      Optional[Union[str, int]] = None
    result:  Optional[Any]            = None
    error:   Optional[Dict[str, Any]] = None
    jsonrpc: str                      = "2.0"

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"jsonrpc": self.jsonrpc, "id": self.id}
        if self.error is not None:
            d["error"] = self.error
        else:
            d["result"] = self.result
        return d

    @classmethod
    def ok(cls, request_id: Any, result: Any) -> "JSONRPCResponse":
        return cls(id=request_id, result=result)

    @classmethod
    def err(
        cls,
        request_id: Any,
        code: MCPErrorCode,
        message: str,
        data: Any = None,
    ) -> "JSONRPCResponse":
        error: Dict[str, Any] = {"code": int(code), "message": message}
        if data is not None:
            error["data"] = data
        return cls(id=request_id, error=error)


class MCPError(Exception):
    """Raised by MCP handlers to produce a structured error response."""
    def __init__(self, code: MCPErrorCode, message: str, data: Any = None) -> None:
        super().__init__(message)
        self.code    = code
        self.message = message
        self.data    = data


# ─── MCP Schema types ─────────────────────────────────────────────────────────


@dataclass
class MCPToolParameter:
    """JSON Schema-compatible parameter descriptor for an MCP tool."""
    name:        str
    type:        str           = "string"    # string | number | boolean | object | array
    description: str           = ""
    required:    bool          = False
    enum:        List[Any]     = field(default_factory=list)
    default:     Optional[Any] = None

    def to_json_schema(self) -> Dict[str, Any]:
        schema: Dict[str, Any] = {"type": self.type}
        if self.description:
            schema["description"] = self.description
        if self.enum:
            schema["enum"] = self.enum
        if self.default is not None:
            schema["default"] = self.default
        return schema


@dataclass
class MCPTool:
    """An MCP tool definition — callable unit of functionality."""
    name:        str
    description: str                      = ""
    parameters:  List[MCPToolParameter]   = field(default_factory=list)
    handler:     Optional[Callable]       = None
    metadata:    Dict[str, Any]           = field(default_factory=dict)

    def input_schema(self) -> Dict[str, Any]:
        """Return the JSON Schema for the tool's input parameters."""
        props = {p.name: p.to_json_schema() for p in self.parameters}
        required = [p.name for p in self.parameters if p.required]
        schema: Dict[str, Any] = {"type": "object", "properties": props}
        if required:
            schema["required"] = required
        return schema

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name":        self.name,
            "description": self.description,
            "inputSchema": self.input_schema(),
        }

    def validate_args(self, args: Dict[str, Any]) -> List[str]:
        """Return a list of validation error messages (empty = valid)."""
        errors = []
        for p in self.parameters:
            if p.required and p.name not in args:
                errors.append(f"Missing required parameter: {p.name}")
        return errors


@dataclass
class MCPResource:
    """An MCP resource — a readable data source."""
    uri:         str
    name:        str
    description: str               = ""
    mime_type:   str               = "text/plain"
    reader:      Optional[Callable] = None   # async callable() → str | bytes
    metadata:    Dict[str, Any]    = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "uri":         self.uri,
            "name":        self.name,
            "description": self.description,
            "mimeType":    self.mime_type,
        }


@dataclass
class MCPPromptArgument:
    """A template argument for an MCP prompt."""
    name:        str
    description: str  = ""
    required:    bool = False


@dataclass
class MCPPrompt:
    """An MCP prompt template."""
    name:        str
    description: str                    = ""
    arguments:   List[MCPPromptArgument] = field(default_factory=list)
    template:    str                    = ""   # may contain {arg_name} placeholders
    metadata:    Dict[str, Any]         = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name":        self.name,
            "description": self.description,
            "arguments":   [
                {"name": a.name, "description": a.description, "required": a.required}
                for a in self.arguments
            ],
        }

    def render(self, arguments: Dict[str, str]) -> str:
        """Render the prompt template by substituting arguments."""
        text = self.template
        for key, value in arguments.items():
            text = text.replace(f"{{{key}}}", str(value))
        return text


# ─── Session ─────────────────────────────────────────────────────────────────


@dataclass
class MCPSession:
    """An active MCP client session."""
    session_id:   str                = field(default_factory=lambda: str(uuid.uuid4()))
    client_info:  Dict[str, Any]     = field(default_factory=dict)
    capabilities: Dict[str, Any]     = field(default_factory=dict)
    initialized:  bool               = False
    created_at:   float              = field(default_factory=time.time)
    last_seen:    float              = field(default_factory=time.time)
    metadata:     Dict[str, Any]     = field(default_factory=dict)


# ─── MCPServer ────────────────────────────────────────────────────────────────


class MCPServer:
    """
    Model Context Protocol server.

    Handles JSON-RPC 2.0 dispatch, tool/resource/prompt registration,
    SSE transport, and stdio transport.

    Usage::

        server = MCPServer(name="heady-mcp", version="1.0.0")

        @server.tool("echo", description="Echo back the input")
        async def echo(args):
            return {"content": [{"type": "text", "text": args["message"]}]}

        # SSE mode (long-running HTTP stream)
        async for sse_line in server.handle_sse_stream(request_body):
            send_to_client(sse_line)

        # stdio mode
        await server.run_stdio()
    """

    SERVER_CAPABILITIES: Dict[str, Any] = {
        "tools":     {"listChanged": True},
        "resources": {"subscribe": False, "listChanged": False},
        "prompts":   {"listChanged": False},
        "logging":   {},
    }

    def __init__(
        self,
        name:    str = "heady-mcp-server",
        version: str = "1.0.0",
    ) -> None:
        self._name    = name
        self._version = version
        self._tools:     Dict[str, MCPTool]     = {}
        self._resources: Dict[str, MCPResource] = {}
        self._prompts:   Dict[str, MCPPrompt]   = {}
        self._sessions:  Dict[str, MCPSession]  = {}
        self._dispatch:  Dict[str, Callable]    = self._build_dispatch_table()

    # ── Registration ─────────────────────────────────────────────────────────

    def tool(
        self,
        name:        str,
        description: str = "",
        parameters:  Optional[List[MCPToolParameter]] = None,
        handler:     Optional[Callable] = None,
    ) -> Callable:
        """
        Register a tool. Can be used as a decorator::

            @server.tool("my_tool", description="Does something")
            async def my_tool(args): ...
        """
        def _decorator(fn: Callable) -> Callable:
            t = MCPTool(
                name        = name,
                description = description,
                parameters  = parameters or [],
                handler     = fn,
            )
            self._tools[name] = t
            logger.debug("Tool registered: %s", name)
            return fn

        if handler is not None:
            return _decorator(handler)
        return _decorator

    def register_tool(self, tool: MCPTool) -> None:
        """Register a pre-built MCPTool instance."""
        self._tools[tool.name] = tool
        logger.debug("Tool registered: %s", tool.name)

    def register_resource(self, resource: MCPResource) -> None:
        """Register an MCP resource."""
        self._resources[resource.uri] = resource
        logger.debug("Resource registered: %s", resource.uri)

    def register_prompt(self, prompt: MCPPrompt) -> None:
        """Register an MCP prompt template."""
        self._prompts[prompt.name] = prompt
        logger.debug("Prompt registered: %s", prompt.name)

    # ── Core dispatch ────────────────────────────────────────────────────────

    def _build_dispatch_table(self) -> Dict[str, Callable]:
        return {
            "initialize":                  self._handle_initialize,
            "notifications/initialized":   self._handle_initialized,
            "tools/list":                  self._handle_tools_list,
            "tools/call":                  self._handle_tools_call,
            "resources/list":              self._handle_resources_list,
            "resources/read":              self._handle_resources_read,
            "prompts/list":                self._handle_prompts_list,
            "prompts/get":                 self._handle_prompts_get,
            "ping":                        self._handle_ping,
        }

    async def handle_message(
        self,
        raw: Union[str, bytes, Dict],
        session_id: Optional[str] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Parse and dispatch a raw JSON-RPC message.

        Returns the JSON-serialisable response dict, or None for notifications.
        """
        # Parse
        try:
            if isinstance(raw, (str, bytes)):
                data = json.loads(raw)
            else:
                data = raw
            req = JSONRPCRequest.from_dict(data)
        except (json.JSONDecodeError, KeyError) as exc:
            resp = JSONRPCResponse.err(
                None, MCPErrorCode.PARSE_ERROR, f"Parse error: {exc}"
            )
            return resp.to_dict()

        # Lookup session
        session = self._sessions.get(session_id or "")

        # Dispatch
        handler = self._dispatch.get(req.method)
        if handler is None:
            if req.id is None:
                return None  # notification → no response
            resp = JSONRPCResponse.err(
                req.id, MCPErrorCode.METHOD_NOT_FOUND,
                f"Method not found: {req.method}"
            )
            return resp.to_dict()

        try:
            result = await handler(req, session)
            if req.id is None:
                return None  # notification
            return JSONRPCResponse.ok(req.id, result).to_dict()
        except MCPError as exc:
            return JSONRPCResponse.err(req.id, exc.code, exc.message, exc.data).to_dict()
        except Exception as exc:
            logger.exception("Internal error in %s: %s", req.method, exc)
            return JSONRPCResponse.err(
                req.id, MCPErrorCode.INTERNAL_ERROR, str(exc)
            ).to_dict()

    # ── Method handlers ───────────────────────────────────────────────────────

    async def _handle_initialize(
        self, req: JSONRPCRequest, session: Optional[MCPSession]
    ) -> Dict[str, Any]:
        params       = req.params or {}
        new_session  = MCPSession(
            client_info  = params.get("clientInfo", {}),
            capabilities = params.get("capabilities", {}),
        )
        self._sessions[new_session.session_id] = new_session
        return {
            "protocolVersion": "2024-11-05",
            "capabilities":    self.SERVER_CAPABILITIES,
            "serverInfo": {
                "name":      self._name,
                "version":   self._version,
            },
            "_sessionId": new_session.session_id,  # non-standard, for client bookkeeping
        }

    async def _handle_initialized(
        self, req: JSONRPCRequest, session: Optional[MCPSession]
    ) -> None:
        if session:
            session.initialized = True
            session.last_seen   = time.time()
        return None

    async def _handle_tools_list(
        self, req: JSONRPCRequest, session: Optional[MCPSession]
    ) -> Dict[str, Any]:
        return {"tools": [t.to_dict() for t in self._tools.values()]}

    async def _handle_tools_call(
        self, req: JSONRPCRequest, session: Optional[MCPSession]
    ) -> Dict[str, Any]:
        params    = req.params or {}
        tool_name = params.get("name")
        args      = params.get("arguments") or {}

        if not tool_name or tool_name not in self._tools:
            raise MCPError(MCPErrorCode.TOOL_NOT_FOUND, f"Tool not found: {tool_name}")

        tool = self._tools[tool_name]

        # Validate arguments
        errors = tool.validate_args(args)
        if errors:
            raise MCPError(
                MCPErrorCode.INVALID_PARAMS,
                "Invalid tool arguments",
                data=errors,
            )

        if tool.handler is None:
            raise MCPError(MCPErrorCode.TOOL_EXEC_ERROR, f"Tool '{tool_name}' has no handler")

        try:
            if asyncio.iscoroutinefunction(tool.handler):
                result = await tool.handler(args)
            else:
                loop   = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, tool.handler, args)
        except MCPError:
            raise
        except Exception as exc:
            raise MCPError(
                MCPErrorCode.TOOL_EXEC_ERROR,
                f"Tool execution error: {exc}",
            ) from exc

        # Normalise result to MCP content format
        if isinstance(result, dict) and "content" in result:
            return result
        return {
            "content": [{"type": "text", "text": json.dumps(result)}],
            "isError": False,
        }

    async def _handle_resources_list(
        self, req: JSONRPCRequest, session: Optional[MCPSession]
    ) -> Dict[str, Any]:
        return {"resources": [r.to_dict() for r in self._resources.values()]}

    async def _handle_resources_read(
        self, req: JSONRPCRequest, session: Optional[MCPSession]
    ) -> Dict[str, Any]:
        params = req.params or {}
        uri    = params.get("uri")

        if not uri or uri not in self._resources:
            raise MCPError(MCPErrorCode.RESOURCE_NOT_FOUND, f"Resource not found: {uri}")

        resource = self._resources[uri]
        if resource.reader is None:
            raise MCPError(MCPErrorCode.RESOURCE_NOT_FOUND, f"Resource '{uri}' has no reader")

        try:
            if asyncio.iscoroutinefunction(resource.reader):
                content = await resource.reader()
            else:
                loop    = asyncio.get_event_loop()
                content = await loop.run_in_executor(None, resource.reader)
        except Exception as exc:
            raise MCPError(MCPErrorCode.INTERNAL_ERROR, f"Resource read error: {exc}") from exc

        if isinstance(content, bytes):
            encoded = base64.b64encode(content).decode()
            return {
                "contents": [{
                    "uri":      uri,
                    "mimeType": resource.mime_type,
                    "blob":     encoded,
                }]
            }
        return {
            "contents": [{
                "uri":      uri,
                "mimeType": resource.mime_type,
                "text":     str(content),
            }]
        }

    async def _handle_prompts_list(
        self, req: JSONRPCRequest, session: Optional[MCPSession]
    ) -> Dict[str, Any]:
        return {"prompts": [p.to_dict() for p in self._prompts.values()]}

    async def _handle_prompts_get(
        self, req: JSONRPCRequest, session: Optional[MCPSession]
    ) -> Dict[str, Any]:
        params    = req.params or {}
        name      = params.get("name")
        arguments = params.get("arguments") or {}

        if not name or name not in self._prompts:
            raise MCPError(MCPErrorCode.PROMPT_NOT_FOUND, f"Prompt not found: {name}")

        prompt = self._prompts[name]
        # Validate required arguments
        for arg in prompt.arguments:
            if arg.required and arg.name not in arguments:
                raise MCPError(
                    MCPErrorCode.INVALID_PARAMS,
                    f"Missing required prompt argument: {arg.name}",
                )

        text = prompt.render(arguments)
        return {
            "description": prompt.description,
            "messages": [{"role": "user", "content": {"type": "text", "text": text}}],
        }

    async def _handle_ping(
        self, req: JSONRPCRequest, session: Optional[MCPSession]
    ) -> Dict[str, Any]:
        return {}  # MCP ping returns empty result

    # ── SSE Transport ────────────────────────────────────────────────────────

    async def handle_sse_stream(
        self,
        body:       Optional[str]  = None,
        session_id: Optional[str]  = None,
        keep_alive_interval: float = 15.0,
    ) -> AsyncIterator[str]:
        """
        Async generator that yields SSE-formatted lines.

        Clients connect once; the generator yields:
          - An initial ``endpoint`` event with the POST URL for JSON-RPC requests.
          - Periodic keep-alive comments (``:``) to prevent proxy timeouts.

        Typical usage with an HTTP server::

            async for line in server.handle_sse_stream():
                await response.write(line.encode())
        """
        sid = session_id or str(uuid.uuid4())
        # Send endpoint event
        yield f"event: endpoint\ndata: /mcp/message?sessionId={sid}\n\n"

        last_ka = time.monotonic()
        while True:
            now = time.monotonic()
            if now - last_ka >= keep_alive_interval:
                yield ": keep-alive\n\n"
                last_ka = now
            await asyncio.sleep(1.0)

    async def send_sse_message(
        self, event: str, data: Any
    ) -> str:
        """Format a message as an SSE event string."""
        payload = json.dumps(data) if not isinstance(data, str) else data
        return f"event: {event}\ndata: {payload}\n\n"

    # ── stdio Transport ──────────────────────────────────────────────────────

    async def run_stdio(self) -> None:
        """
        Run the MCP server in stdio mode (for local tool integration).

        Reads newline-delimited JSON-RPC requests from stdin,
        writes JSON-RPC responses to stdout.
        """
        loop   = asyncio.get_event_loop()
        reader = asyncio.StreamReader()
        proto  = asyncio.StreamReaderProtocol(reader)
        await loop.connect_read_pipe(lambda: proto, sys.stdin)

        logger.info("MCP server running in stdio mode")
        while True:
            try:
                line = await reader.readline()
                if not line:
                    break
                line_str = line.decode().strip()
                if not line_str:
                    continue

                response = await self.handle_message(line_str)
                if response is not None:
                    out = json.dumps(response) + "\n"
                    sys.stdout.write(out)
                    sys.stdout.flush()
            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.error("stdio transport error: %s", exc)

    # ── HTTP integration helper ───────────────────────────────────────────────

    def attach_to_http_server(self, server: Any) -> None:
        """
        Attach MCP routes to a core.http_server.HTTPServer instance.

        Registers:
          GET  /mcp/sse      — SSE stream endpoint
          POST /mcp/message  — JSON-RPC message endpoint
        """
        async def sse_handler(request: Any) -> Any:
            from core.http_server import Response
            session_id = (request.query_params or {}).get("sessionId")

            async def stream_body():
                async for chunk in self.handle_sse_stream(session_id=session_id):
                    yield chunk.encode()

            return Response(
                status=200,
                headers={
                    "Content-Type":  "text/event-stream",
                    "Cache-Control": "no-cache",
                    "Connection":    "keep-alive",
                },
                body_stream=stream_body(),
            )

        async def message_handler(request: Any) -> Any:
            from core.http_server import JSONResponse
            session_id = (request.query_params or {}).get("sessionId")
            body       = request.body or b""
            response   = await self.handle_message(body.decode(), session_id=session_id)
            return JSONResponse(response or {})

        server.route("/mcp/sse",     methods=["GET"])(sse_handler)
        server.route("/mcp/message", methods=["POST"])(message_handler)
        logger.info("MCP routes attached: GET /mcp/sse, POST /mcp/message")

    def __repr__(self) -> str:
        return (
            f"MCPServer(name={self._name!r}, tools={len(self._tools)}, "
            f"resources={len(self._resources)}, prompts={len(self._prompts)})"
        )


# ─── MCPClient ────────────────────────────────────────────────────────────────


class MCPClient:
    """
    Lightweight MCP client for making JSON-RPC 2.0 requests to an MCPServer.

    Can be used in-process (direct server reference) or over HTTP
    via core/http_client.py.

    In-process usage::

        client = MCPClient(server=my_server)
        result = await client.call_tool("echo", {"message": "hello"})

    HTTP usage::

        client = MCPClient(base_url="http://localhost:8080")
        await client.initialize()
        result = await client.call_tool("echo", {"message": "hello"})
    """

    def __init__(
        self,
        server:   Optional[MCPServer] = None,
        base_url: Optional[str]       = None,
    ) -> None:
        self._server   = server
        self._base_url = base_url
        self._session_id: Optional[str] = None
        self._req_id_counter = 0

    def _next_id(self) -> int:
        self._req_id_counter += 1
        return self._req_id_counter

    async def _send(self, req: JSONRPCRequest) -> Dict[str, Any]:
        """Send a request and return the result."""
        if self._server:
            raw = await self._server.handle_message(req.to_dict(), self._session_id)
            if raw is None:
                return {}
            if "error" in raw:
                err = raw["error"]
                raise MCPError(
                    MCPErrorCode(err.get("code", -32603)),
                    err.get("message", "Unknown error"),
                    err.get("data"),
                )
            return raw.get("result", {})

        if self._base_url:
            from core.http_client import AsyncHTTPClient
            url = f"{self._base_url.rstrip('/')}/mcp/message"
            if self._session_id:
                url += f"?sessionId={self._session_id}"
            async with AsyncHTTPClient() as http:
                resp = await http.post(url, json=req.to_dict())
                data = resp.json()
                if "error" in data:
                    err = data["error"]
                    raise MCPError(
                        MCPErrorCode(err.get("code", -32603)),
                        err.get("message", "Unknown error"),
                        err.get("data"),
                    )
                return data.get("result", {})

        raise RuntimeError("MCPClient requires either server= or base_url=")

    async def initialize(self, client_info: Optional[Dict] = None) -> Dict[str, Any]:
        """Perform MCP capability negotiation."""
        req = JSONRPCRequest(
            method = "initialize",
            params = {
                "protocolVersion": "2024-11-05",
                "capabilities":    {},
                "clientInfo":      client_info or {"name": "heady-client", "version": "1.0.0"},
            },
            id = self._next_id(),
        )
        result = await self._send(req)
        self._session_id = result.get("_sessionId")
        # Send initialized notification
        notif = JSONRPCRequest(method="notifications/initialized", params={})
        await self._send(notif)
        return result

    async def list_tools(self) -> List[Dict[str, Any]]:
        req = JSONRPCRequest(method="tools/list", params={}, id=self._next_id())
        result = await self._send(req)
        return result.get("tools", [])

    async def call_tool(self, name: str, arguments: Dict[str, Any]) -> Any:
        req = JSONRPCRequest(
            method = "tools/call",
            params = {"name": name, "arguments": arguments},
            id     = self._next_id(),
        )
        return await self._send(req)

    async def list_resources(self) -> List[Dict[str, Any]]:
        req = JSONRPCRequest(method="resources/list", params={}, id=self._next_id())
        result = await self._send(req)
        return result.get("resources", [])

    async def read_resource(self, uri: str) -> Dict[str, Any]:
        req = JSONRPCRequest(
            method = "resources/read",
            params = {"uri": uri},
            id     = self._next_id(),
        )
        return await self._send(req)

    async def list_prompts(self) -> List[Dict[str, Any]]:
        req = JSONRPCRequest(method="prompts/list", params={}, id=self._next_id())
        result = await self._send(req)
        return result.get("prompts", [])

    async def get_prompt(self, name: str, arguments: Dict[str, str]) -> Dict[str, Any]:
        req = JSONRPCRequest(
            method = "prompts/get",
            params = {"name": name, "arguments": arguments},
            id     = self._next_id(),
        )
        return await self._send(req)

    async def ping(self) -> bool:
        try:
            req = JSONRPCRequest(method="ping", params={}, id=self._next_id())
            await self._send(req)
            return True
        except Exception:
            return False

    def __repr__(self) -> str:
        target = f"server={self._server!r}" if self._server else f"url={self._base_url!r}"
        return f"MCPClient({target}, session={self._session_id!r})"
