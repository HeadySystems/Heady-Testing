"""
github_client.py
================
GitHub REST API client — replaces @octokit/rest and @octokit/auth-app.

Features:
  - Authentication: PAT, GitHub App (JWT + Installation tokens), OAuth
  - Repository operations: list, create, get, contents
  - Issue operations: list, create, update, comment
  - Pull Request operations: list, create, update, merge
  - Branch operations: list, create, delete, protect
  - File operations: get, create, update, delete (via Contents API)
  - Commit operations: list, get
  - Organization operations: list repos, list members
  - Rate limit tracking (X-RateLimit-* headers)
  - Automatic pagination (Link header / page parameter)
  - All HTTP via core/http_client.py (urllib only)

Authentication:
  GitHubClient(auth_type=GitHubAuthType.PAT, token="ghp_...")
  GitHubClient(auth_type=GitHubAuthType.APP, app_id=123, private_key_pem="...")
  GitHubClient(auth_type=GitHubAuthType.INSTALLATION, token="ghs_...")

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import math
import time
import urllib.parse
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, AsyncIterator, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

GITHUB_API_BASE = "https://api.github.com"
GITHUB_API_ACCEPT = "application/vnd.github+json"
GITHUB_API_VERSION = "2022-11-28"


# ─── Auth types ───────────────────────────────────────────────────────────────


class GitHubAuthType(str, Enum):
    PAT          = "pat"          # Personal Access Token
    APP          = "app"          # GitHub App (JWT)
    INSTALLATION = "installation" # Installation token (ghs_...)
    NONE         = "none"         # Unauthenticated (public API, low rate limit)


# ─── Data classes ─────────────────────────────────────────────────────────────


@dataclass
class GitHubRepo:
    id:          int
    name:        str
    full_name:   str
    private:     bool      = False
    description: str       = ""
    html_url:    str       = ""
    clone_url:   str       = ""
    default_branch: str    = "main"
    language:    str       = ""
    stars:       int       = 0
    forks:       int       = 0
    open_issues: int       = 0
    created_at:  str       = ""
    updated_at:  str       = ""
    raw:         Dict      = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GitHubRepo":
        return cls(
            id           = d.get("id", 0),
            name         = d.get("name", ""),
            full_name    = d.get("full_name", ""),
            private      = d.get("private", False),
            description  = d.get("description", "") or "",
            html_url     = d.get("html_url", ""),
            clone_url    = d.get("clone_url", ""),
            default_branch = d.get("default_branch", "main"),
            language     = d.get("language", "") or "",
            stars        = d.get("stargazers_count", 0),
            forks        = d.get("forks_count", 0),
            open_issues  = d.get("open_issues_count", 0),
            created_at   = d.get("created_at", ""),
            updated_at   = d.get("updated_at", ""),
            raw          = d,
        )


@dataclass
class GitHubIssue:
    id:        int
    number:    int
    title:     str
    state:     str       = "open"
    body:      str       = ""
    html_url:  str       = ""
    user:      str       = ""
    labels:    List[str] = field(default_factory=list)
    assignees: List[str] = field(default_factory=list)
    created_at: str      = ""
    updated_at: str      = ""
    raw:       Dict      = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GitHubIssue":
        return cls(
            id         = d.get("id", 0),
            number     = d.get("number", 0),
            title      = d.get("title", ""),
            state      = d.get("state", "open"),
            body       = d.get("body", "") or "",
            html_url   = d.get("html_url", ""),
            user       = (d.get("user") or {}).get("login", ""),
            labels     = [l["name"] for l in d.get("labels", []) if isinstance(l, dict)],
            assignees  = [(a.get("login", "")) for a in d.get("assignees", [])],
            created_at = d.get("created_at", ""),
            updated_at = d.get("updated_at", ""),
            raw        = d,
        )


@dataclass
class GitHubPR:
    id:          int
    number:      int
    title:       str
    state:       str    = "open"
    body:        str    = ""
    html_url:    str    = ""
    head:        str    = ""   # branch name
    base:        str    = ""   # branch name
    user:        str    = ""
    mergeable:   Optional[bool] = None
    merged:      bool   = False
    created_at:  str    = ""
    updated_at:  str    = ""
    raw:         Dict   = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GitHubPR":
        return cls(
            id         = d.get("id", 0),
            number     = d.get("number", 0),
            title      = d.get("title", ""),
            state      = d.get("state", "open"),
            body       = d.get("body", "") or "",
            html_url   = d.get("html_url", ""),
            head       = (d.get("head") or {}).get("ref", ""),
            base       = (d.get("base") or {}).get("ref", ""),
            user       = (d.get("user") or {}).get("login", ""),
            mergeable  = d.get("mergeable"),
            merged     = d.get("merged", False),
            created_at = d.get("created_at", ""),
            updated_at = d.get("updated_at", ""),
            raw        = d,
        )


@dataclass
class GitHubBranch:
    name:       str
    sha:        str        = ""
    protected:  bool       = False
    raw:        Dict       = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GitHubBranch":
        return cls(
            name      = d.get("name", ""),
            sha       = (d.get("commit") or {}).get("sha", ""),
            protected = d.get("protected", False),
            raw       = d,
        )


@dataclass
class GitHubFile:
    name:         str
    path:         str
    sha:          str        = ""
    size:         int        = 0
    type:         str        = "file"  # file | dir | symlink | submodule
    content:      str        = ""      # base64 when returned by API, decoded here
    encoding:     str        = "base64"
    html_url:     str        = ""
    download_url: str        = ""
    raw:          Dict       = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GitHubFile":
        raw_content = d.get("content", "")
        # Decode base64 content if present
        decoded = ""
        if raw_content and d.get("encoding") == "base64":
            try:
                decoded = base64.b64decode(raw_content.replace("\n", "")).decode("utf-8")
            except Exception:
                decoded = raw_content  # return raw if decode fails
        return cls(
            name         = d.get("name", ""),
            path         = d.get("path", ""),
            sha          = d.get("sha", ""),
            size         = d.get("size", 0),
            type         = d.get("type", "file"),
            content      = decoded,
            encoding     = d.get("encoding", ""),
            html_url     = d.get("html_url", ""),
            download_url = d.get("download_url", "") or "",
            raw          = d,
        )


@dataclass
class GitHubCommit:
    sha:       str
    message:   str    = ""
    author:    str    = ""
    timestamp: str    = ""
    url:       str    = ""
    raw:       Dict   = field(default_factory=dict)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "GitHubCommit":
        commit = d.get("commit", {})
        author = (commit.get("author") or {})
        return cls(
            sha       = d.get("sha", ""),
            message   = commit.get("message", ""),
            author    = author.get("name", ""),
            timestamp = author.get("date", ""),
            url       = d.get("html_url", ""),
            raw       = d,
        )


@dataclass
class RateLimitInfo:
    limit:     int   = 5000
    remaining: int   = 5000
    reset:     int   = 0   # Unix timestamp
    used:      int   = 0

    @property
    def reset_in(self) -> float:
        return max(0.0, self.reset - time.time())

    @property
    def exhausted(self) -> bool:
        return self.remaining <= 0


# ─── JWT builder (for GitHub App auth, stdlib only) ──────────────────────────


def _build_jwt(app_id: int, private_key_pem: str, expiry_seconds: int = 540) -> str:
    """
    Build a GitHub App JWT using RS256 (via subprocess openssl or fallback).

    stdlib does not include RSA signing, so we use the ``ssl`` module's
    underlying OpenSSL via a subprocess call to ``openssl dgst``.
    Falls back to a warning if openssl is not available.
    """
    import subprocess
    import tempfile
    import os

    now = int(time.time())
    header  = {"alg": "RS256", "typ": "JWT"}
    payload = {"iat": now - 60, "exp": now + expiry_seconds, "iss": str(app_id)}

    def _b64url(data: Union[str, bytes]) -> str:
        if isinstance(data, str):
            data = data.encode()
        return base64.urlsafe_b64encode(data).rstrip(b"=").decode()

    h_enc = _b64url(json.dumps(header, separators=(",", ":")))
    p_enc = _b64url(json.dumps(payload, separators=(",", ":")))
    signing_input = f"{h_enc}.{p_enc}"

    # Write private key to temp file and sign via openssl
    with tempfile.NamedTemporaryFile(mode="w", suffix=".pem", delete=False) as kf:
        kf.write(private_key_pem)
        key_path = kf.name

    try:
        result = subprocess.run(
            ["openssl", "dgst", "-sha256", "-sign", key_path],
            input=signing_input.encode(),
            capture_output=True,
            timeout=10,
        )
        if result.returncode != 0:
            raise RuntimeError(f"openssl failed: {result.stderr.decode()}")
        sig_b64 = _b64url(result.stdout)
    finally:
        os.unlink(key_path)

    return f"{signing_input}.{sig_b64}"


# ─── GitHubClient ─────────────────────────────────────────────────────────────


class GitHubClient:
    """
    GitHub REST API client built on core/http_client.py (urllib only).

    Supports PAT, GitHub App JWT, and Installation token authentication.
    Automatically handles rate-limit headers and pagination via Link headers.

    Example::

        client = GitHubClient(auth_type=GitHubAuthType.PAT, token="ghp_...")
        repos = await client.list_repos("my-org")
        issue = await client.create_issue("owner/repo", "Bug title", "Body text")
    """

    def __init__(
        self,
        auth_type:       GitHubAuthType = GitHubAuthType.NONE,
        token:           Optional[str]  = None,   # PAT or Installation token
        app_id:          Optional[int]  = None,
        private_key_pem: Optional[str]  = None,
        base_url:        str            = GITHUB_API_BASE,
    ) -> None:
        self._auth_type       = auth_type
        self._token           = token
        self._app_id          = app_id
        self._private_key_pem = private_key_pem
        self._base_url        = base_url.rstrip("/")
        self._rate_limit      = RateLimitInfo()
        self._jwt_cache: Optional[Tuple[str, float]] = None  # (jwt, expiry)

    # ── Auth helpers ──────────────────────────────────────────────────────────

    def _get_jwt(self) -> str:
        """Return a cached or freshly-minted GitHub App JWT."""
        now = time.time()
        if self._jwt_cache and self._jwt_cache[1] > now + 30:
            return self._jwt_cache[0]
        if not self._app_id or not self._private_key_pem:
            raise RuntimeError("GitHubAuthType.APP requires app_id and private_key_pem")
        jwt = _build_jwt(self._app_id, self._private_key_pem)
        self._jwt_cache = (jwt, now + 540)
        return jwt

    def _auth_header(self) -> str:
        """Return the Authorization header value for the configured auth type."""
        if self._auth_type in (GitHubAuthType.PAT, GitHubAuthType.INSTALLATION):
            if not self._token:
                raise RuntimeError(f"Token required for {self._auth_type}")
            return f"Bearer {self._token}"
        elif self._auth_type == GitHubAuthType.APP:
            return f"Bearer {self._get_jwt()}"
        return ""  # unauthenticated

    def _headers(self, extra: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        h = {
            "Accept":               GITHUB_API_ACCEPT,
            "X-GitHub-Api-Version": GITHUB_API_VERSION,
            "User-Agent":           "heady-zero-dep/1.0",
        }
        auth = self._auth_header()
        if auth:
            h["Authorization"] = auth
        if extra:
            h.update(extra)
        return h

    # ── Core HTTP ─────────────────────────────────────────────────────────────

    async def _request(
        self,
        method:  str,
        path:    str,
        params:  Optional[Dict]  = None,
        body:    Optional[Dict]  = None,
        headers: Optional[Dict]  = None,
    ) -> Tuple[int, Dict[str, Any], Dict[str, str]]:
        """
        Make a GitHub API request.

        Returns (status_code, json_body, response_headers).
        Raises RuntimeError on non-2xx responses.
        """
        from core.http_client import AsyncHTTPClient

        url = f"{self._base_url}{path}"
        if params:
            url += "?" + urllib.parse.urlencode(params)

        merged_headers = self._headers(headers)

        async with AsyncHTTPClient() as http:
            resp = await http.request(
                method  = method.upper(),
                url     = url,
                json    = body,
                headers = merged_headers,
            )

        # Track rate limits
        rh = {k.lower(): v for k, v in (resp.headers or {}).items()}
        if "x-ratelimit-limit" in rh:
            self._rate_limit.limit     = int(rh.get("x-ratelimit-limit", 5000))
            self._rate_limit.remaining = int(rh.get("x-ratelimit-remaining", 5000))
            self._rate_limit.reset     = int(rh.get("x-ratelimit-reset", 0))
            self._rate_limit.used      = int(rh.get("x-ratelimit-used", 0))
            if self._rate_limit.remaining < 10:
                logger.warning(
                    "GitHub rate limit low: %d/%d (resets in %.0fs)",
                    self._rate_limit.remaining, self._rate_limit.limit,
                    self._rate_limit.reset_in,
                )

        if resp.status >= 400:
            try:
                err_body = resp.json() if resp.body else {}
            except Exception:
                err_body = {}
            raise RuntimeError(
                f"GitHub API {method} {path} → {resp.status}: "
                f"{err_body.get('message', resp.body)}"
            )

        body_parsed: Dict[str, Any] = {}
        if resp.body:
            try:
                body_parsed = resp.json()
            except Exception:
                body_parsed = {"_raw": resp.body.decode(errors="replace")}

        return resp.status, body_parsed, dict(rh)

    # ── Pagination ─────────────────────────────────────────────────────────────

    async def _paginate(
        self,
        path:         str,
        params:       Optional[Dict] = None,
        per_page:     int            = 100,
        max_pages:    int            = 100,
    ) -> List[Dict[str, Any]]:
        """
        Collect all pages of a paginated GitHub API endpoint.

        Uses the ``Link`` header to follow next-page URLs.
        """
        all_items: List[Dict[str, Any]] = []
        merged = dict(params or {})
        merged.setdefault("per_page", per_page)
        merged.setdefault("page", 1)

        for _ in range(max_pages):
            status, body, resp_headers = await self._request("GET", path, params=merged)
            if isinstance(body, list):
                all_items.extend(body)
            elif isinstance(body, dict) and "items" in body:
                all_items.extend(body["items"])

            # Follow Link: <url>; rel="next"
            link_header = resp_headers.get("link", "")
            next_url    = _parse_next_link(link_header)
            if not next_url:
                break
            # Extract page number from URL
            parsed = urllib.parse.urlparse(next_url)
            qs     = urllib.parse.parse_qs(parsed.query)
            page   = int(qs.get("page", [merged["page"] + 1])[0])
            merged["page"] = page

        return all_items

    # ── Repository operations ─────────────────────────────────────────────────

    async def get_repo(self, owner: str, repo: str) -> GitHubRepo:
        """Get a repository by owner and name."""
        _, body, _ = await self._request("GET", f"/repos/{owner}/{repo}")
        return GitHubRepo.from_dict(body)

    async def list_repos(
        self,
        org:        Optional[str] = None,
        user:       Optional[str] = None,
        type:       str           = "all",
        sort:       str           = "updated",
        per_page:   int           = 100,
    ) -> List[GitHubRepo]:
        """List repositories for an org or user."""
        if org:
            path = f"/orgs/{org}/repos"
        elif user:
            path = f"/users/{user}/repos"
        else:
            path = "/user/repos"  # authenticated user
        items = await self._paginate(path, params={"type": type, "sort": sort},
                                     per_page=per_page)
        return [GitHubRepo.from_dict(r) for r in items]

    async def create_repo(
        self,
        name:        str,
        description: str  = "",
        private:     bool = True,
        org:         Optional[str] = None,
        auto_init:   bool = True,
    ) -> GitHubRepo:
        """Create a new repository."""
        path = f"/orgs/{org}/repos" if org else "/user/repos"
        _, body, _ = await self._request("POST", path, body={
            "name":        name,
            "description": description,
            "private":     private,
            "auto_init":   auto_init,
        })
        return GitHubRepo.from_dict(body)

    async def get_contents(
        self,
        owner: str,
        repo:  str,
        path:  str,
        ref:   Optional[str] = None,
    ) -> Union[GitHubFile, List[GitHubFile]]:
        """
        Get file or directory contents.

        Returns a GitHubFile for files, or a list of GitHubFiles for dirs.
        """
        params: Dict[str, Any] = {}
        if ref:
            params["ref"] = ref
        _, body, _ = await self._request(
            "GET", f"/repos/{owner}/{repo}/contents/{path.lstrip('/')}",
            params=params or None,
        )
        if isinstance(body, list):
            return [GitHubFile.from_dict(f) for f in body]
        return GitHubFile.from_dict(body)

    # ── Issue operations ──────────────────────────────────────────────────────

    async def list_issues(
        self,
        owner:    str,
        repo:     str,
        state:    str          = "open",
        labels:   Optional[List[str]] = None,
        per_page: int          = 100,
    ) -> List[GitHubIssue]:
        params: Dict[str, Any] = {"state": state}
        if labels:
            params["labels"] = ",".join(labels)
        items = await self._paginate(
            f"/repos/{owner}/{repo}/issues", params=params, per_page=per_page
        )
        return [GitHubIssue.from_dict(i) for i in items if "pull_request" not in i]

    async def get_issue(self, owner: str, repo: str, number: int) -> GitHubIssue:
        _, body, _ = await self._request("GET", f"/repos/{owner}/{repo}/issues/{number}")
        return GitHubIssue.from_dict(body)

    async def create_issue(
        self,
        owner:     str,
        repo:      str,
        title:     str,
        body:      str           = "",
        labels:    Optional[List[str]] = None,
        assignees: Optional[List[str]] = None,
    ) -> GitHubIssue:
        _, resp, _ = await self._request(
            "POST", f"/repos/{owner}/{repo}/issues",
            body={
                "title":     title,
                "body":      body,
                "labels":    labels or [],
                "assignees": assignees or [],
            },
        )
        return GitHubIssue.from_dict(resp)

    async def update_issue(
        self,
        owner:  str,
        repo:   str,
        number: int,
        **kwargs: Any,
    ) -> GitHubIssue:
        _, body, _ = await self._request(
            "PATCH", f"/repos/{owner}/{repo}/issues/{number}", body=kwargs
        )
        return GitHubIssue.from_dict(body)

    async def create_issue_comment(
        self, owner: str, repo: str, number: int, body: str
    ) -> Dict[str, Any]:
        _, resp, _ = await self._request(
            "POST", f"/repos/{owner}/{repo}/issues/{number}/comments",
            body={"body": body},
        )
        return resp

    # ── Pull Request operations ───────────────────────────────────────────────

    async def list_prs(
        self,
        owner:    str,
        repo:     str,
        state:    str = "open",
        per_page: int = 100,
    ) -> List[GitHubPR]:
        items = await self._paginate(
            f"/repos/{owner}/{repo}/pulls",
            params={"state": state},
            per_page=per_page,
        )
        return [GitHubPR.from_dict(p) for p in items]

    async def create_pr(
        self,
        owner:  str,
        repo:   str,
        title:  str,
        head:   str,
        base:   str,
        body:   str  = "",
        draft:  bool = False,
    ) -> GitHubPR:
        _, resp, _ = await self._request(
            "POST", f"/repos/{owner}/{repo}/pulls",
            body={"title": title, "head": head, "base": base,
                  "body": body, "draft": draft},
        )
        return GitHubPR.from_dict(resp)

    async def merge_pr(
        self,
        owner:         str,
        repo:          str,
        number:        int,
        commit_title:  str  = "",
        merge_method:  str  = "merge",  # merge | squash | rebase
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"merge_method": merge_method}
        if commit_title:
            body["commit_title"] = commit_title
        _, resp, _ = await self._request(
            "PUT", f"/repos/{owner}/{repo}/pulls/{number}/merge", body=body
        )
        return resp

    async def update_pr(
        self, owner: str, repo: str, number: int, **kwargs: Any
    ) -> GitHubPR:
        _, body, _ = await self._request(
            "PATCH", f"/repos/{owner}/{repo}/pulls/{number}", body=kwargs
        )
        return GitHubPR.from_dict(body)

    # ── Branch operations ─────────────────────────────────────────────────────

    async def list_branches(self, owner: str, repo: str, per_page: int = 100) -> List[GitHubBranch]:
        items = await self._paginate(f"/repos/{owner}/{repo}/branches", per_page=per_page)
        return [GitHubBranch.from_dict(b) for b in items]

    async def get_branch(self, owner: str, repo: str, branch: str) -> GitHubBranch:
        _, body, _ = await self._request("GET", f"/repos/{owner}/{repo}/branches/{branch}")
        return GitHubBranch.from_dict(body)

    async def create_branch(
        self, owner: str, repo: str, branch: str, from_sha: str
    ) -> GitHubBranch:
        _, body, _ = await self._request(
            "POST", f"/repos/{owner}/{repo}/git/refs",
            body={"ref": f"refs/heads/{branch}", "sha": from_sha},
        )
        # The response is a ref object, not a branch object
        return GitHubBranch(name=branch, sha=from_sha)

    async def delete_branch(self, owner: str, repo: str, branch: str) -> bool:
        status, _, _ = await self._request(
            "DELETE", f"/repos/{owner}/{repo}/git/refs/heads/{branch}"
        )
        return status == 204

    # ── File operations ───────────────────────────────────────────────────────

    async def get_file(
        self, owner: str, repo: str, path: str, ref: Optional[str] = None
    ) -> GitHubFile:
        result = await self.get_contents(owner, repo, path, ref=ref)
        if isinstance(result, list):
            raise ValueError(f"Path '{path}' is a directory, not a file")
        return result

    async def create_file(
        self,
        owner:   str,
        repo:    str,
        path:    str,
        content: str,
        message: str,
        branch:  Optional[str] = None,
        encoding: str          = "utf-8",
    ) -> Dict[str, Any]:
        """Create a new file in the repository."""
        encoded = base64.b64encode(content.encode(encoding)).decode()
        body: Dict[str, Any] = {"message": message, "content": encoded}
        if branch:
            body["branch"] = branch
        _, resp, _ = await self._request(
            "PUT", f"/repos/{owner}/{repo}/contents/{path.lstrip('/')}", body=body
        )
        return resp

    async def update_file(
        self,
        owner:   str,
        repo:    str,
        path:    str,
        content: str,
        message: str,
        sha:     str,
        branch:  Optional[str] = None,
        encoding: str          = "utf-8",
    ) -> Dict[str, Any]:
        """Update an existing file (requires the blob SHA)."""
        encoded = base64.b64encode(content.encode(encoding)).decode()
        body: Dict[str, Any] = {"message": message, "content": encoded, "sha": sha}
        if branch:
            body["branch"] = branch
        _, resp, _ = await self._request(
            "PUT", f"/repos/{owner}/{repo}/contents/{path.lstrip('/')}", body=body
        )
        return resp

    async def delete_file(
        self,
        owner:   str,
        repo:    str,
        path:    str,
        message: str,
        sha:     str,
        branch:  Optional[str] = None,
    ) -> Dict[str, Any]:
        """Delete a file from the repository."""
        body: Dict[str, Any] = {"message": message, "sha": sha}
        if branch:
            body["branch"] = branch
        _, resp, _ = await self._request(
            "DELETE", f"/repos/{owner}/{repo}/contents/{path.lstrip('/')}", body=body
        )
        return resp

    # ── Commit operations ─────────────────────────────────────────────────────

    async def list_commits(
        self,
        owner:    str,
        repo:     str,
        branch:   Optional[str] = None,
        path:     Optional[str] = None,
        per_page: int           = 50,
    ) -> List[GitHubCommit]:
        params: Dict[str, Any] = {}
        if branch:
            params["sha"] = branch
        if path:
            params["path"] = path
        items = await self._paginate(
            f"/repos/{owner}/{repo}/commits", params=params, per_page=per_page
        )
        return [GitHubCommit.from_dict(c) for c in items]

    async def get_commit(self, owner: str, repo: str, sha: str) -> GitHubCommit:
        _, body, _ = await self._request("GET", f"/repos/{owner}/{repo}/commits/{sha}")
        return GitHubCommit.from_dict(body)

    # ── Organization operations ───────────────────────────────────────────────

    async def list_org_repos(
        self, org: str, type: str = "all", per_page: int = 100
    ) -> List[GitHubRepo]:
        return await self.list_repos(org=org, type=type, per_page=per_page)

    async def list_org_members(self, org: str, per_page: int = 100) -> List[Dict[str, Any]]:
        return await self._paginate(f"/orgs/{org}/members", per_page=per_page)

    # ── GitHub App: Installation tokens ──────────────────────────────────────

    async def get_installation_token(self, installation_id: int) -> str:
        """Exchange a GitHub App JWT for an installation access token."""
        _, body, _ = await self._request(
            "POST",
            f"/app/installations/{installation_id}/access_tokens",
        )
        return body.get("token", "")

    async def list_installations(self) -> List[Dict[str, Any]]:
        """List all installations for the GitHub App (requires APP auth)."""
        return await self._paginate("/app/installations")

    # ── Rate limit ────────────────────────────────────────────────────────────

    async def get_rate_limit(self) -> RateLimitInfo:
        """Fetch current rate limit status from the API."""
        _, body, _ = await self._request("GET", "/rate_limit")
        core = (body.get("resources") or {}).get("core") or body.get("rate") or {}
        self._rate_limit = RateLimitInfo(
            limit     = core.get("limit", 5000),
            remaining = core.get("remaining", 5000),
            reset     = core.get("reset", 0),
            used      = core.get("used", 0),
        )
        return self._rate_limit

    @property
    def rate_limit(self) -> RateLimitInfo:
        """Last observed rate limit info (updated on every API call)."""
        return self._rate_limit

    def __repr__(self) -> str:
        return (
            f"GitHubClient(auth={self._auth_type.value}, "
            f"rate={self._rate_limit.remaining}/{self._rate_limit.limit})"
        )


# ─── Helpers ──────────────────────────────────────────────────────────────────


def _parse_next_link(link_header: str) -> Optional[str]:
    """Parse the 'next' URL from a GitHub Link header."""
    for part in link_header.split(","):
        parts = [p.strip() for p in part.split(";")]
        if len(parts) == 2 and parts[1] == 'rel="next"':
            url = parts[0]
            if url.startswith("<") and url.endswith(">"):
                return url[1:-1]
    return None
