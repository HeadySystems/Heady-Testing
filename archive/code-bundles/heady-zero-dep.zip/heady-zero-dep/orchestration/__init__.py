"""
orchestration/__init__.py
=========================
Heady Orchestration & Pipeline Layer — zero external dependencies.

This package provides the full orchestration stack for the Heady system:

    conductor      — HeadyConductor: central routing, arena mode, HCFullPipeline sequencing
    pipeline       — HCFullPipeline: 12-stage async pipeline state machine
    mcp_protocol   — Model Context Protocol (JSON-RPC 2.0) handler
    github_client  — GitHub REST API client (urllib only)
    bee_factory    — Agent Worker Factory (Bee system, 24 domain types)
    resilience     — Circuit breaker, phi-backoff, bulkhead, rate limiter, self-healing
    swarm          — Swarm consensus, task distribution, result aggregation

All modules use only Python standard library.
"""

from __future__ import annotations

from orchestration.conductor import (
    HeadyConductor,
    TaskDomain,
    PriorityPool,
    RoutingEntry,
    ConductorMetrics,
)
from orchestration.pipeline import (
    HCFullPipeline,
    PipelineStage,
    PipelineState,
    StageResult,
    PipelineTemplate,
)
from orchestration.mcp_protocol import (
    MCPServer,
    MCPClient,
    MCPTool,
    MCPResource,
    MCPPrompt,
    JSONRPCRequest,
    JSONRPCResponse,
    MCPError,
)
from orchestration.github_client import (
    GitHubClient,
    GitHubAuthType,
    GitHubRepo,
    GitHubIssue,
    GitHubPR,
    GitHubBranch,
    GitHubFile,
    GitHubCommit,
)
from orchestration.bee_factory import (
    BeeFactory,
    Bee,
    BeeDomain,
    BeeStatus,
    BeeMessage,
    BeeSwarmConfig,
)
from orchestration.resilience import (
    CircuitBreaker,
    CircuitState,
    PhiBackoff,
    RetryPolicy,
    BulkheadIsolation,
    RateLimiter,
    HealthProbe,
    GracefulShutdown,
    SelfHealingComponent,
    HealthState,
)
from orchestration.swarm import (
    SwarmCoordinator,
    ConsensusProtocol,
    TaskDistributionStrategy,
    AggregationStrategy,
    SwarmMember,
    SwarmTask,
    SwarmResult,
)

__all__ = [
    # conductor
    "HeadyConductor",
    "TaskDomain",
    "PriorityPool",
    "RoutingEntry",
    "ConductorMetrics",
    # pipeline
    "HCFullPipeline",
    "PipelineStage",
    "PipelineState",
    "StageResult",
    "PipelineTemplate",
    # mcp_protocol
    "MCPServer",
    "MCPClient",
    "MCPTool",
    "MCPResource",
    "MCPPrompt",
    "JSONRPCRequest",
    "JSONRPCResponse",
    "MCPError",
    # github_client
    "GitHubClient",
    "GitHubAuthType",
    "GitHubRepo",
    "GitHubIssue",
    "GitHubPR",
    "GitHubBranch",
    "GitHubFile",
    "GitHubCommit",
    # bee_factory
    "BeeFactory",
    "Bee",
    "BeeDomain",
    "BeeStatus",
    "BeeMessage",
    "BeeSwarmConfig",
    # resilience
    "CircuitBreaker",
    "CircuitState",
    "PhiBackoff",
    "RetryPolicy",
    "BulkheadIsolation",
    "RateLimiter",
    "HealthProbe",
    "GracefulShutdown",
    "SelfHealingComponent",
    "HealthState",
    # swarm
    "SwarmCoordinator",
    "ConsensusProtocol",
    "TaskDistributionStrategy",
    "AggregationStrategy",
    "SwarmMember",
    "SwarmTask",
    "SwarmResult",
]

__version__ = "1.0.0"
