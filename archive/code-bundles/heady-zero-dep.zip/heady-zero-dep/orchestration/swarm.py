"""
swarm.py
========
Swarm consensus and intelligence for the Heady orchestration layer.

Architecture:
  ┌───────────────────────────────────────────────────────────────┐
  │  SwarmCoordinator                                             │
  │                                                               │
  │  ┌──────────────────┐  ┌──────────────────┐                  │
  │  │  Member Registry  │  │  Task Distributor│                  │
  │  └──────────────────┘  └──────────────────┘                  │
  │                                                               │
  │  ┌──────────────────┐  ┌──────────────────┐                  │
  │  │  Consensus Engine │  │  Result Aggregator│                 │
  │  └──────────────────┘  └──────────────────┘                  │
  │                                                               │
  │  ┌──────────────────────────────────────────────────────┐    │
  │  │  Communication Bus (pub/sub between swarm members)   │    │
  │  └──────────────────────────────────────────────────────┘    │
  └───────────────────────────────────────────────────────────────┘

Consensus protocols:
  MAJORITY    — more than 50% of members agree
  WEIGHTED    — votes weighted by member confidence/score
  UNANIMOUS   — all members must agree
  QUORUM      — configurable minimum fraction agree
  FIRST_PAST  — first response accepted

Task distribution strategies:
  ROUND_ROBIN    — sequential cycling through members
  LOAD_BALANCED  — assign to least-loaded member
  SKILL_MATCHED  — assign based on member skill tags
  RANDOM         — random member selection
  BROADCAST      — all members receive the task

Result aggregation strategies:
  MERGE          — combine all results into one dict
  PICK_BEST      — select result with highest score
  SYNTHESIZE     — merge with deduplication
  VOTE           — count votes per answer field

Dynamic scaling:
  add_member / remove_member adjust the pool at runtime.
  Autoscale targets a utilization band.

Conflict resolution:
  When agents disagree, the coordinator uses configurable strategies
  to resolve conflicts: tiebreak by score, abstain, or escalate.

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import asyncio
import logging
import random
import time
import uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Coroutine, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ─── Enums ────────────────────────────────────────────────────────────────────


class ConsensusProtocol(str, Enum):
    """Consensus voting protocols."""
    MAJORITY    = "majority"     # > 50% agree
    WEIGHTED    = "weighted"     # sum of weights > threshold
    UNANIMOUS   = "unanimous"   # all must agree
    QUORUM      = "quorum"       # >= quorum_fraction agree
    FIRST_PAST  = "first_past"   # first result wins


class TaskDistributionStrategy(str, Enum):
    """How tasks are distributed among swarm members."""
    ROUND_ROBIN   = "round_robin"
    LOAD_BALANCED = "load_balanced"
    SKILL_MATCHED = "skill_matched"
    RANDOM        = "random"
    BROADCAST     = "broadcast"


class AggregationStrategy(str, Enum):
    """How individual results are combined into a final answer."""
    MERGE      = "merge"
    PICK_BEST  = "pick_best"
    SYNTHESIZE = "synthesize"
    VOTE       = "vote"


class SwarmMemberStatus(str, Enum):
    ACTIVE   = "active"
    IDLE     = "idle"
    OVERLOAD = "overload"
    OFFLINE  = "offline"


class ConflictResolution(str, Enum):
    TIEBREAK_BY_SCORE = "tiebreak_by_score"
    ABSTAIN           = "abstain"
    ESCALATE          = "escalate"
    RANDOM_PICK       = "random_pick"


# ─── Data classes ─────────────────────────────────────────────────────────────


@dataclass
class SwarmMember:
    """
    A registered participant in a swarm.

    Each member has:
      - An async handler callable for processing tasks
      - Skills / tags for skill-based routing
      - A confidence weight for weighted voting
      - Load tracking for load-balanced routing
    """
    member_id:  str                = field(default_factory=lambda: str(uuid.uuid4()))
    name:       str                = ""
    skills:     List[str]          = field(default_factory=list)
    weight:     float              = 1.0      # voting weight
    capacity:   int                = 10       # max concurrent tasks
    current_load: int              = 0
    status:     SwarmMemberStatus  = SwarmMemberStatus.ACTIVE
    metadata:   Dict[str, Any]     = field(default_factory=dict)
    handler:    Optional[Callable] = None     # async callable(task) → result

    # Health tracking
    tasks_done:   int   = 0
    tasks_failed: int   = 0
    avg_latency:  float = 0.0     # rolling average latency in ms
    last_seen:    float = field(default_factory=time.monotonic)

    @property
    def is_available(self) -> bool:
        return (self.status == SwarmMemberStatus.ACTIVE
                and self.current_load < self.capacity)

    @property
    def utilization(self) -> float:
        return self.current_load / max(1, self.capacity)

    @property
    def error_rate(self) -> float:
        total = self.tasks_done + self.tasks_failed
        return self.tasks_failed / total if total > 0 else 0.0


@dataclass
class SwarmTask:
    """A unit of work submitted to the swarm."""
    task_id:    str                = field(default_factory=lambda: str(uuid.uuid4()))
    payload:    Dict[str, Any]     = field(default_factory=dict)
    required_skills: List[str]     = field(default_factory=list)
    priority:   int                = 5        # 1 (highest) – 10 (lowest)
    timeout:    float              = 30.0
    metadata:   Dict[str, Any]     = field(default_factory=dict)
    created_at: float              = field(default_factory=time.monotonic)


@dataclass
class MemberResult:
    """Result from a single swarm member."""
    member_id:  str
    task_id:    str
    data:       Dict[str, Any]   = field(default_factory=dict)
    score:      float            = 1.0
    latency_ms: float            = 0.0
    success:    bool             = True
    error:      Optional[str]    = None


@dataclass
class SwarmResult:
    """Aggregated result from a swarm execution."""
    task_id:     str
    consensus:   bool
    protocol:    ConsensusProtocol
    aggregation: AggregationStrategy
    final:       Dict[str, Any]       = field(default_factory=dict)
    member_results: List[MemberResult] = field(default_factory=list)
    participating: int                 = 0
    agreeing:      int                 = 0
    confidence:    float               = 0.0
    conflict:      bool                = False
    total_latency: float               = 0.0
    metadata:      Dict[str, Any]      = field(default_factory=dict)


# ─── Communication bus ────────────────────────────────────────────────────────


class SwarmBus:
    """
    Pub/sub communication bus for swarm members.

    Members subscribe to topics and receive BusMessage objects.
    Messages are delivered asynchronously via asyncio queues.

    Usage::

        bus = SwarmBus()
        sub = bus.subscribe("alerts")
        await bus.publish("alerts", {"text": "node down"})
        msg = await sub.get()
    """

    def __init__(self) -> None:
        self._subscribers: Dict[str, List[asyncio.Queue]] = defaultdict(list)

    def subscribe(self, topic: str, maxsize: int = 100) -> asyncio.Queue:
        """Subscribe to a topic and return a Queue that receives messages."""
        q: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._subscribers[topic].append(q)
        return q

    def unsubscribe(self, topic: str, queue: asyncio.Queue) -> None:
        """Unsubscribe a queue from a topic."""
        if queue in self._subscribers[topic]:
            self._subscribers[topic].remove(queue)

    async def publish(self, topic: str, data: Any) -> int:
        """Publish a message to all subscribers of a topic. Returns delivery count."""
        delivered = 0
        message   = {"topic": topic, "data": data, "ts": time.time()}
        for q in list(self._subscribers.get(topic, [])):
            try:
                q.put_nowait(message)
                delivered += 1
            except asyncio.QueueFull:
                logger.debug("Bus queue full for topic '%s'", topic)
        return delivered

    def subscriber_count(self, topic: str) -> int:
        return len(self._subscribers.get(topic, []))


# ─── Consensus Engine ────────────────────────────────────────────────────────


class ConsensusEngine:
    """
    Evaluate consensus among member results.

    Each protocol has a different rule for what constitutes agreement.
    """

    def __init__(
        self,
        protocol:          ConsensusProtocol = ConsensusProtocol.MAJORITY,
        quorum_fraction:   float             = 0.6,
        conflict_resolution: ConflictResolution = ConflictResolution.TIEBREAK_BY_SCORE,
    ) -> None:
        self._protocol           = protocol
        self._quorum_fraction    = quorum_fraction
        self._conflict_resolution = conflict_resolution

    def evaluate(
        self,
        results: List[MemberResult],
        members: Dict[str, SwarmMember],
    ) -> Tuple[bool, Optional[MemberResult], float]:
        """
        Evaluate consensus over a list of member results.

        Returns (consensus_reached, winning_result_or_None, confidence_score).
        """
        valid = [r for r in results if r.success]
        if not valid:
            return False, None, 0.0

        if self._protocol == ConsensusProtocol.FIRST_PAST:
            return True, valid[0], 1.0

        if self._protocol == ConsensusProtocol.UNANIMOUS:
            return self._unanimous(valid, members)

        if self._protocol == ConsensusProtocol.MAJORITY:
            return self._majority(valid, members)

        if self._protocol == ConsensusProtocol.WEIGHTED:
            return self._weighted(valid, members)

        if self._protocol == ConsensusProtocol.QUORUM:
            return self._quorum(valid, results, members)

        return False, None, 0.0

    def _canonical_answer(self, r: MemberResult) -> str:
        """Extract a canonical string representation of an answer for comparison."""
        data = r.data
        for key in ("answer", "result", "output", "value"):
            if key in data:
                return str(data[key])
        # Hash the sorted keys for structural equality
        return str(sorted(data.items()))

    def _majority(
        self, valid: List[MemberResult], members: Dict[str, SwarmMember]
    ) -> Tuple[bool, Optional[MemberResult], float]:
        counts: Dict[str, List[MemberResult]] = defaultdict(list)
        for r in valid:
            counts[self._canonical_answer(r)].append(r)
        winner_answer = max(counts, key=lambda k: len(counts[k]))
        winner_group  = counts[winner_answer]
        fraction      = len(winner_group) / len(valid)
        if fraction > 0.5:
            best = max(winner_group, key=lambda r: r.score)
            return True, best, fraction
        return self._resolve_conflict(valid, members)

    def _weighted(
        self, valid: List[MemberResult], members: Dict[str, SwarmMember]
    ) -> Tuple[bool, Optional[MemberResult], float]:
        weights: Dict[str, float]           = defaultdict(float)
        best_per: Dict[str, MemberResult]   = {}
        total_weight = sum(members[r.member_id].weight
                           for r in valid if r.member_id in members)
        for r in valid:
            key    = self._canonical_answer(r)
            weight = members.get(r.member_id, SwarmMember()).weight
            weights[key] += weight
            if key not in best_per or r.score > best_per[key].score:
                best_per[key] = r
        winner_key = max(weights, key=lambda k: weights[k])
        confidence = weights[winner_key] / total_weight if total_weight > 0 else 0.0
        if confidence > 0.5:
            return True, best_per[winner_key], confidence
        return self._resolve_conflict(valid, members)

    def _unanimous(
        self, valid: List[MemberResult], members: Dict[str, SwarmMember]
    ) -> Tuple[bool, Optional[MemberResult], float]:
        answers = {self._canonical_answer(r) for r in valid}
        if len(answers) == 1:
            best = max(valid, key=lambda r: r.score)
            return True, best, 1.0
        return self._resolve_conflict(valid, members)

    def _quorum(
        self,
        valid:   List[MemberResult],
        all_r:   List[MemberResult],
        members: Dict[str, SwarmMember],
    ) -> Tuple[bool, Optional[MemberResult], float]:
        counts: Dict[str, List[MemberResult]] = defaultdict(list)
        for r in valid:
            counts[self._canonical_answer(r)].append(r)
        winner_answer = max(counts, key=lambda k: len(counts[k]))
        winner_group  = counts[winner_answer]
        # Quorum is measured against total members (including failures)
        fraction = len(winner_group) / max(1, len(all_r))
        if fraction >= self._quorum_fraction:
            best = max(winner_group, key=lambda r: r.score)
            return True, best, fraction
        return self._resolve_conflict(valid, members)

    def _resolve_conflict(
        self, valid: List[MemberResult], members: Dict[str, SwarmMember]
    ) -> Tuple[bool, Optional[MemberResult], float]:
        """Handle the no-consensus case per conflict_resolution strategy."""
        if not valid:
            return False, None, 0.0

        if self._conflict_resolution == ConflictResolution.TIEBREAK_BY_SCORE:
            best = max(valid, key=lambda r: r.score)
            return False, best, best.score

        elif self._conflict_resolution == ConflictResolution.RANDOM_PICK:
            picked = random.choice(valid)
            return False, picked, picked.score

        elif self._conflict_resolution == ConflictResolution.ABSTAIN:
            return False, None, 0.0

        elif self._conflict_resolution == ConflictResolution.ESCALATE:
            # Return all results for external resolution; mark as conflict
            return False, valid[0], 0.0

        return False, None, 0.0


# ─── Result Aggregator ────────────────────────────────────────────────────────


class ResultAggregator:
    """Combine multiple MemberResult objects into a single SwarmResult."""

    def aggregate(
        self,
        task:           SwarmTask,
        results:        List[MemberResult],
        winning:        Optional[MemberResult],
        consensus:      bool,
        confidence:     float,
        protocol:       ConsensusProtocol,
        strategy:       AggregationStrategy,
    ) -> SwarmResult:
        valid = [r for r in results if r.success]
        total_latency = sum(r.latency_ms for r in results) / max(1, len(results))

        if strategy == AggregationStrategy.PICK_BEST:
            final = winning.data if winning else {}
        elif strategy == AggregationStrategy.MERGE:
            final = self._merge(valid)
        elif strategy == AggregationStrategy.SYNTHESIZE:
            final = self._synthesize(valid)
        elif strategy == AggregationStrategy.VOTE:
            final = self._vote(valid)
        else:
            final = winning.data if winning else {}

        return SwarmResult(
            task_id         = task.task_id,
            consensus       = consensus,
            protocol        = protocol,
            aggregation     = strategy,
            final           = final,
            member_results  = results,
            participating   = len(results),
            agreeing        = sum(1 for r in valid if winning and
                                  self._same_answer(r, winning)),
            confidence      = confidence,
            conflict        = not consensus,
            total_latency   = total_latency,
        )

    def _same_answer(self, a: MemberResult, b: MemberResult) -> bool:
        for key in ("answer", "result", "output", "value"):
            if key in a.data and key in b.data:
                return a.data[key] == b.data[key]
        return a.data == b.data

    def _merge(self, results: List[MemberResult]) -> Dict[str, Any]:
        merged: Dict[str, Any] = {}
        for r in results:
            merged.update(r.data)
        merged["_member_results"] = [
            {"member_id": r.member_id, "score": r.score} for r in results
        ]
        return merged

    def _synthesize(self, results: List[MemberResult]) -> Dict[str, Any]:
        """Merge without clobbering — keeps first-seen value per key."""
        merged: Dict[str, Any] = {}
        for r in results:
            for k, v in r.data.items():
                if k not in merged:
                    merged[k] = v
        merged["_count"]    = len(results)
        merged["_avg_score"] = sum(r.score for r in results) / max(1, len(results))
        return merged

    def _vote(self, results: List[MemberResult]) -> Dict[str, Any]:
        votes: Dict[str, int] = defaultdict(int)
        for r in results:
            for key in ("answer", "result", "output"):
                if key in r.data:
                    votes[str(r.data[key])] += 1
                    break
        if votes:
            winner = max(votes, key=lambda k: votes[k])
            return {
                "answer":      winner,
                "votes":       dict(votes),
                "vote_leader": max(votes.values()),
                "total_votes": len(results),
            }
        return {}


# ─── SwarmCoordinator ────────────────────────────────────────────────────────


class SwarmCoordinator:
    """
    Manage groups of agents (SwarmMembers) working on tasks.

    Responsibilities:
      - Member registration and health monitoring
      - Task distribution via configurable strategy
      - Consensus evaluation
      - Result aggregation
      - Dynamic scaling (add/remove members on load)
      - Conflict resolution
      - Pub/sub communication bus

    Usage::

        coordinator = SwarmCoordinator(
            consensus=ConsensusProtocol.MAJORITY,
            distribution=TaskDistributionStrategy.LOAD_BALANCED,
            aggregation=AggregationStrategy.MERGE,
        )

        async def my_agent(task: dict) -> dict:
            return {"answer": "42"}

        coordinator.add_member(SwarmMember(name="agent-1", handler=my_agent))
        coordinator.add_member(SwarmMember(name="agent-2", handler=my_agent))

        task   = SwarmTask(payload={"question": "life"})
        result = await coordinator.execute(task)
        print(result.final, result.consensus)
    """

    def __init__(
        self,
        name:            str                      = "heady-swarm",
        consensus:       ConsensusProtocol        = ConsensusProtocol.MAJORITY,
        distribution:    TaskDistributionStrategy = TaskDistributionStrategy.LOAD_BALANCED,
        aggregation:     AggregationStrategy      = AggregationStrategy.MERGE,
        conflict_resolution: ConflictResolution   = ConflictResolution.TIEBREAK_BY_SCORE,
        quorum_fraction: float                    = 0.6,
        min_members:     int                      = 1,
        max_members:     int                      = 50,
        task_timeout:    float                    = 60.0,
    ) -> None:
        self.name            = name
        self._members:       Dict[str, SwarmMember]    = {}
        self._round_robin_idx: int                     = 0
        self._bus            = SwarmBus()
        self._task_history:  deque                     = deque(maxlen=1000)
        self._consensus_engine = ConsensusEngine(
            protocol=consensus,
            quorum_fraction=quorum_fraction,
            conflict_resolution=conflict_resolution,
        )
        self._aggregator     = ResultAggregator()

        self._consensus_protocol = consensus
        self._distribution       = distribution
        self._aggregation        = aggregation
        self._min_members        = min_members
        self._max_members        = max_members
        self._task_timeout       = task_timeout

        # Metrics
        self._tasks_processed: int   = 0
        self._consensus_rate:  float = 0.0
        self._last_consensus_window: deque = deque(maxlen=100)

    # ── Member management ─────────────────────────────────────────────────────

    def add_member(self, member: SwarmMember) -> None:
        """Register a new swarm member."""
        if len(self._members) >= self._max_members:
            raise RuntimeError(f"Swarm '{self.name}' at max capacity ({self._max_members})")
        self._members[member.member_id] = member
        logger.info("Swarm '%s': added member %s (%s)", self.name, member.name, member.member_id[:8])

    def remove_member(self, member_id: str) -> bool:
        """Remove a member from the swarm."""
        if member_id not in self._members:
            return False
        if len(self._members) <= self._min_members:
            logger.warning(
                "Swarm '%s': cannot remove member (at min_members=%d)",
                self.name, self._min_members,
            )
            return False
        del self._members[member_id]
        logger.info("Swarm '%s': removed member %s", self.name, member_id[:8])
        return True

    def get_member(self, member_id: str) -> Optional[SwarmMember]:
        return self._members.get(member_id)

    def list_members(self, available_only: bool = False) -> List[SwarmMember]:
        members = list(self._members.values())
        if available_only:
            members = [m for m in members if m.is_available]
        return members

    # ── Task distribution ─────────────────────────────────────────────────────

    def _select_members(self, task: SwarmTask) -> List[SwarmMember]:
        """Select which members should handle this task based on the distribution strategy."""
        available = [m for m in self._members.values()
                     if m.status != SwarmMemberStatus.OFFLINE]
        if not available:
            return []

        if self._distribution == TaskDistributionStrategy.BROADCAST:
            return available

        if self._distribution == TaskDistributionStrategy.ROUND_ROBIN:
            if not available:
                return []
            idx    = self._round_robin_idx % len(available)
            picked = available[idx]
            self._round_robin_idx = (self._round_robin_idx + 1) % len(available)
            return [picked]

        if self._distribution == TaskDistributionStrategy.LOAD_BALANCED:
            avail = [m for m in available if m.is_available]
            if not avail:
                avail = available  # fall back to any
            return [min(avail, key=lambda m: m.utilization)]

        if self._distribution == TaskDistributionStrategy.SKILL_MATCHED:
            if task.required_skills:
                scored = sorted(
                    available,
                    key=lambda m: sum(1 for s in task.required_skills if s in m.skills),
                    reverse=True,
                )
                return [scored[0]] if scored else available[:1]
            return available[:1]

        if self._distribution == TaskDistributionStrategy.RANDOM:
            return [random.choice(available)]

        return available[:1]

    # ── Task execution ────────────────────────────────────────────────────────

    async def _execute_member(
        self, member: SwarmMember, task: SwarmTask
    ) -> MemberResult:
        """Run a task on a single member and return its result."""
        member.current_load += 1
        member.last_seen     = time.monotonic()
        t0 = time.monotonic()

        try:
            if member.handler is None:
                result_data = {"stub": True, "member": member.name, "task_id": task.task_id}
            elif asyncio.iscoroutinefunction(member.handler):
                result_data = await asyncio.wait_for(
                    member.handler(task.payload), timeout=task.timeout
                )
            else:
                loop        = asyncio.get_event_loop()
                result_data = await asyncio.wait_for(
                    loop.run_in_executor(None, member.handler, task.payload),
                    timeout=task.timeout,
                )

            if not isinstance(result_data, dict):
                result_data = {"result": result_data}

            latency = (time.monotonic() - t0) * 1000
            member.tasks_done  += 1
            # Update rolling average latency
            member.avg_latency = (
                (member.avg_latency * (member.tasks_done - 1) + latency)
                / member.tasks_done
            )
            return MemberResult(
                member_id  = member.member_id,
                task_id    = task.task_id,
                data       = result_data,
                score      = member.weight * (1.0 / (1.0 + latency / 1000.0)),
                latency_ms = latency,
                success    = True,
            )

        except asyncio.TimeoutError:
            member.tasks_failed += 1
            return MemberResult(
                member_id  = member.member_id,
                task_id    = task.task_id,
                success    = False,
                error      = "timeout",
                latency_ms = (time.monotonic() - t0) * 1000,
            )
        except Exception as exc:
            member.tasks_failed += 1
            logger.warning("Member %s failed task %s: %s", member.name, task.task_id[:8], exc)
            return MemberResult(
                member_id  = member.member_id,
                task_id    = task.task_id,
                success    = False,
                error      = str(exc),
                latency_ms = (time.monotonic() - t0) * 1000,
            )
        finally:
            member.current_load = max(0, member.current_load - 1)

    async def execute(
        self,
        task:        SwarmTask,
        member_ids:  Optional[List[str]] = None,
    ) -> SwarmResult:
        """
        Distribute and execute a task across the swarm.

        Args:
            task:       The SwarmTask to execute.
            member_ids: Optionally pin execution to specific member IDs.

        Returns:
            A SwarmResult with consensus, aggregated output, and per-member results.
        """
        if member_ids:
            targets = [self._members[mid] for mid in member_ids if mid in self._members]
        else:
            targets = self._select_members(task)

        if not targets:
            return SwarmResult(
                task_id    = task.task_id,
                consensus  = False,
                protocol   = self._consensus_protocol,
                aggregation = self._aggregation,
                conflict   = True,
                metadata   = {"error": "No members available"},
            )

        # Execute on all targets concurrently
        member_results: List[MemberResult] = await asyncio.gather(
            *[self._execute_member(m, task) for m in targets]
        )
        member_results = list(member_results)

        # Evaluate consensus
        consensus_reached, winner, confidence = self._consensus_engine.evaluate(
            member_results, self._members
        )

        # Aggregate results
        swarm_result = self._aggregator.aggregate(
            task         = task,
            results      = member_results,
            winning      = winner,
            consensus    = consensus_reached,
            confidence   = confidence,
            protocol     = self._consensus_protocol,
            strategy     = self._aggregation,
        )

        # Record metrics
        self._tasks_processed += 1
        self._last_consensus_window.append(consensus_reached)
        self._consensus_rate = (
            sum(self._last_consensus_window) / len(self._last_consensus_window)
        )
        self._task_history.append({
            "task_id":   task.task_id,
            "consensus": consensus_reached,
            "confidence": confidence,
            "members":   len(targets),
            "ts":        time.time(),
        })

        await self._bus.publish("task.completed", {
            "task_id":   task.task_id,
            "consensus": consensus_reached,
            "confidence": confidence,
        })

        logger.debug(
            "Swarm '%s' task %s: consensus=%s confidence=%.2f members=%d",
            self.name, task.task_id[:8], consensus_reached, confidence, len(targets),
        )
        return swarm_result

    # ── Batch execution ───────────────────────────────────────────────────────

    async def execute_batch(
        self,
        tasks:       List[SwarmTask],
        concurrency: int = 10,
    ) -> List[SwarmResult]:
        """
        Execute multiple tasks in parallel with a concurrency cap.

        Returns results in the same order as input tasks.
        """
        semaphore = asyncio.Semaphore(concurrency)

        async def _guarded(task: SwarmTask) -> SwarmResult:
            async with semaphore:
                return await self.execute(task)

        return list(await asyncio.gather(*[_guarded(t) for t in tasks]))

    # ── Dynamic scaling ──────────────────────────────────────────────────────

    def autoscale(
        self,
        target_utilization: float = 0.7,
        scale_up_fn: Optional[Callable[[], SwarmMember]] = None,
    ) -> Dict[str, Any]:
        """
        Evaluate current utilization and suggest scaling actions.

        If scale_up_fn is provided and current utilization exceeds target,
        automatically add a new member.

        Returns a scaling recommendation dict.
        """
        members = self.list_members()
        if not members:
            return {"action": "scale_up", "reason": "no_members", "count": 0}

        avg_util = sum(m.utilization for m in members) / len(members)
        max_util = max(m.utilization for m in members)

        if avg_util >= target_utilization and scale_up_fn:
            new_member = scale_up_fn()
            try:
                self.add_member(new_member)
                return {
                    "action": "scaled_up",
                    "new_member": new_member.member_id,
                    "avg_utilization": round(avg_util, 3),
                }
            except RuntimeError as exc:
                return {"action": "scale_blocked", "reason": str(exc)}

        if avg_util < target_utilization * 0.3 and len(members) > self._min_members:
            # Suggest scale-down: find the least-loaded member
            candidate = min(members, key=lambda m: m.utilization)
            return {
                "action": "suggest_scale_down",
                "candidate": candidate.member_id,
                "avg_utilization": round(avg_util, 3),
            }

        return {
            "action": "none",
            "avg_utilization": round(avg_util, 3),
            "max_utilization": round(max_util, 3),
        }

    # ── Health ────────────────────────────────────────────────────────────────

    def swarm_health(self) -> Dict[str, Any]:
        """Aggregate individual member health into an overall swarm health score."""
        members  = list(self._members.values())
        if not members:
            return {"healthy": False, "members": 0, "score": 0.0}

        available = [m for m in members if m.is_available]
        total_tasks_done   = sum(m.tasks_done for m in members)
        total_tasks_failed = sum(m.tasks_failed for m in members)
        total_tasks        = total_tasks_done + total_tasks_failed

        availability = len(available) / len(members)
        error_rate   = total_tasks_failed / total_tasks if total_tasks > 0 else 0.0
        # Health score: availability × (1 - error_rate)
        score        = availability * (1.0 - error_rate)

        return {
            "healthy":         score >= 0.5,
            "score":           round(score, 3),
            "availability":    round(availability, 3),
            "error_rate":      round(error_rate, 4),
            "members":         len(members),
            "available":       len(available),
            "tasks_processed": self._tasks_processed,
            "consensus_rate":  round(self._consensus_rate, 3),
        }

    def member_health(self) -> List[Dict[str, Any]]:
        """Return per-member health snapshots."""
        return [
            {
                "member_id":   m.member_id,
                "name":        m.name,
                "status":      m.status.value,
                "utilization": round(m.utilization, 3),
                "tasks_done":  m.tasks_done,
                "error_rate":  round(m.error_rate, 4),
                "avg_latency": round(m.avg_latency, 1),
                "skills":      m.skills,
            }
            for m in self._members.values()
        ]

    # ── Communication ────────────────────────────────────────────────────────

    @property
    def bus(self) -> SwarmBus:
        """Access the swarm's communication bus."""
        return self._bus

    async def broadcast(self, topic: str, data: Any) -> int:
        """Publish a message to all bus subscribers on a topic."""
        return await self._bus.publish(topic, data)

    # ── Metrics ──────────────────────────────────────────────────────────────

    def metrics(self) -> Dict[str, Any]:
        return {
            "swarm":           self.name,
            "tasks_processed": self._tasks_processed,
            "consensus_rate":  round(self._consensus_rate, 3),
            "protocol":        self._consensus_protocol.value,
            "distribution":    self._distribution.value,
            "aggregation":     self._aggregation.value,
            **self.swarm_health(),
        }

    def __repr__(self) -> str:
        return (
            f"SwarmCoordinator(name={self.name!r}, "
            f"members={len(self._members)}, "
            f"protocol={self._consensus_protocol.value})"
        )
