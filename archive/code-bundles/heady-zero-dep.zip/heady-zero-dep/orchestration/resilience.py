"""
resilience.py
=============
Resilience patterns for the Heady orchestration layer.

Patterns provided:
  CircuitBreaker      — CLOSED → OPEN → HALF_OPEN state machine
  PhiBackoff          — exponential backoff using golden ratio (1.618^n)
  RetryPolicy         — configurable retry with jitter
  BulkheadIsolation   — semaphore-based concurrency limiter per service
  RateLimiter         — token bucket algorithm
  HealthProbe         — liveness + readiness checks with history
  GracefulShutdown    — LIFO cleanup with configurable timeout
  SelfHealingComponent — healthy → suspect → quarantined → recovering → restored

All patterns are composable: wrap any async callable.

Usage::

    # Circuit breaker
    cb = CircuitBreaker("my-service", failure_threshold=5)

    @cb.guard
    async def call_service():
        return await do_something()

    # Retry with phi-backoff
    policy = RetryPolicy(max_attempts=5, backoff=PhiBackoff(base_ms=100))
    result = await policy.execute(call_service)

    # Bulkhead
    bulkhead = BulkheadIsolation("payments", max_concurrent=10)
    async with bulkhead:
        await process_payment()

    # Rate limiter
    limiter = RateLimiter(capacity=100, refill_rate=10)  # 10 req/s
    allowed = limiter.acquire()

    # Graceful shutdown
    shutdown = GracefulShutdown(timeout=30.0)
    shutdown.register(cleanup_fn)
    await shutdown.execute()

Zero external dependencies — stdlib only.
"""

from __future__ import annotations

import asyncio
import logging
import math
import random
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Coroutine, Dict, List, Optional, Tuple, Union

logger = logging.getLogger(__name__)

PHI: float = 1.6180339887  # Golden ratio


# ─── Circuit Breaker ──────────────────────────────────────────────────────────


class CircuitState(str, Enum):
    """Circuit breaker states."""
    CLOSED    = "closed"     # Normal operation — calls pass through
    OPEN      = "open"       # Circuit tripped — calls rejected immediately
    HALF_OPEN = "half_open"  # Trial calls allowed to test recovery


class CircuitOpenError(Exception):
    """Raised when a call is rejected because the circuit is OPEN."""
    def __init__(self, service: str, reset_in: float) -> None:
        self.service  = service
        self.reset_in = reset_in
        super().__init__(f"Circuit OPEN for '{service}' (resets in {reset_in:.1f}s)")


@dataclass
class CircuitBreakerStats:
    total_calls:   int = 0
    failures:      int = 0
    successes:     int = 0
    rejections:    int = 0
    trips:         int = 0
    last_trip_at:  float = 0.0
    last_reset_at: float = 0.0


class CircuitBreaker:
    """
    Circuit breaker implementation following the standard state machine:

      CLOSED → (failure_threshold exceeded) → OPEN
      OPEN   → (reset_timeout elapsed)       → HALF_OPEN
      HALF_OPEN → (success)                  → CLOSED
      HALF_OPEN → (failure)                  → OPEN

    Args:
        service:           Name of the protected service (for logging).
        failure_threshold: Consecutive failures to trip the breaker.
        reset_timeout:     Seconds to wait before moving OPEN → HALF_OPEN.
        half_open_max:     Max calls allowed in HALF_OPEN state.
        success_threshold: Successes in HALF_OPEN to close the circuit.
        window_size:       Rolling window for failure rate counting.
    """

    def __init__(
        self,
        service:           str,
        failure_threshold: int   = 5,
        reset_timeout:     float = 30.0,
        half_open_max:     int   = 3,
        success_threshold: int   = 2,
        window_size:       int   = 20,
    ) -> None:
        self._service           = service
        self._failure_threshold = failure_threshold
        self._reset_timeout     = reset_timeout
        self._half_open_max     = half_open_max
        self._success_threshold = success_threshold
        self._window:  deque    = deque(maxlen=window_size)

        self._state            = CircuitState.CLOSED
        self._failure_count    = 0
        self._success_count    = 0
        self._half_open_count  = 0
        self._last_failure_at  = 0.0
        self._stats            = CircuitBreakerStats()

    @property
    def state(self) -> CircuitState:
        self._maybe_transition()
        return self._state

    def _maybe_transition(self) -> None:
        """Check if OPEN → HALF_OPEN transition is due."""
        if (self._state == CircuitState.OPEN
                and time.monotonic() - self._last_failure_at >= self._reset_timeout):
            self._state           = CircuitState.HALF_OPEN
            self._half_open_count = 0
            self._success_count   = 0
            logger.info("Circuit '%s' OPEN → HALF_OPEN", self._service)

    def _on_success(self) -> None:
        self._stats.successes += 1
        self._window.append(True)
        if self._state == CircuitState.HALF_OPEN:
            self._success_count += 1
            if self._success_count >= self._success_threshold:
                self._state         = CircuitState.CLOSED
                self._failure_count = 0
                self._stats.last_reset_at = time.monotonic()
                logger.info("Circuit '%s' HALF_OPEN → CLOSED", self._service)
        else:
            self._failure_count = max(0, self._failure_count - 1)

    def _on_failure(self) -> None:
        self._stats.failures += 1
        self._window.append(False)
        self._failure_count  += 1
        self._last_failure_at = time.monotonic()

        if self._state == CircuitState.HALF_OPEN:
            self._state = CircuitState.OPEN
            self._stats.trips += 1
            logger.warning("Circuit '%s' HALF_OPEN → OPEN (failure in probe)", self._service)
        elif self._failure_count >= self._failure_threshold:
            self._state = CircuitState.OPEN
            self._stats.trips += 1
            logger.warning(
                "Circuit '%s' CLOSED → OPEN (%d consecutive failures)",
                self._service, self._failure_count,
            )

    def _check_state(self) -> None:
        """Raise if the circuit is OPEN or HALF_OPEN and at capacity."""
        self._maybe_transition()
        if self._state == CircuitState.OPEN:
            reset_in = max(0.0, self._reset_timeout - (time.monotonic() - self._last_failure_at))
            self._stats.rejections += 1
            raise CircuitOpenError(self._service, reset_in)
        if self._state == CircuitState.HALF_OPEN:
            if self._half_open_count >= self._half_open_max:
                self._stats.rejections += 1
                raise CircuitOpenError(self._service, 0.0)
            self._half_open_count += 1

    async def call(self, fn: Callable[..., Coroutine], *args: Any, **kwargs: Any) -> Any:
        """Execute ``fn`` under circuit-breaker protection."""
        self._check_state()
        self._stats.total_calls += 1
        try:
            result = await fn(*args, **kwargs)
            self._on_success()
            return result
        except CircuitOpenError:
            raise
        except Exception as exc:
            self._on_failure()
            raise

    def guard(self, fn: Callable) -> Callable:
        """Decorator that wraps an async function with this circuit breaker."""
        async def _wrapper(*args: Any, **kwargs: Any) -> Any:
            return await self.call(fn, *args, **kwargs)
        _wrapper.__name__ = fn.__name__
        return _wrapper

    def reset(self) -> None:
        """Manually reset the circuit to CLOSED state."""
        self._state         = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        logger.info("Circuit '%s' manually reset to CLOSED", self._service)

    @property
    def stats(self) -> CircuitBreakerStats:
        return self._stats

    def __repr__(self) -> str:
        return f"CircuitBreaker(service={self._service!r}, state={self.state.value})"


# ─── Phi Backoff ─────────────────────────────────────────────────────────────


class PhiBackoff:
    """
    Exponential backoff using the golden ratio (φ = 1.618).

    Delay formula:
        delay(n) = base_ms × φ^n + jitter(cap_ms)

    Delays grow as: base, base×φ, base×φ², base×φ³ ...
    Capped at max_ms.

    Args:
        base_ms:  Initial delay in milliseconds.
        max_ms:   Maximum delay cap in milliseconds.
        jitter:   Fraction of delay to add as random jitter (0.0 – 1.0).
    """

    def __init__(
        self,
        base_ms: float = 100.0,
        max_ms:  float = 30_000.0,
        jitter:  float = 0.2,
    ) -> None:
        self.base_ms = base_ms
        self.max_ms  = max_ms
        self.jitter  = jitter
        self._attempt = 0

    def reset(self) -> None:
        """Reset attempt counter to 0."""
        self._attempt = 0

    def next_delay(self) -> float:
        """
        Return the next back-off delay in seconds and advance the counter.
        """
        delay = min(self.base_ms * (PHI ** self._attempt), self.max_ms)
        if self.jitter > 0:
            delay += random.uniform(0, delay * self.jitter)
        self._attempt += 1
        return delay / 1000.0  # convert to seconds

    async def wait(self) -> float:
        """Wait the next back-off delay and return it."""
        delay = self.next_delay()
        await asyncio.sleep(delay)
        return delay

    def peek(self, attempt: int) -> float:
        """Peek at the delay for a given attempt without advancing the counter (in ms)."""
        delay = min(self.base_ms * (PHI ** attempt), self.max_ms)
        return delay

    def __repr__(self) -> str:
        return (
            f"PhiBackoff(base={self.base_ms}ms, max={self.max_ms}ms, "
            f"attempt={self._attempt})"
        )


# ─── RetryPolicy ─────────────────────────────────────────────────────────────


@dataclass
class RetryResult:
    """Outcome of a RetryPolicy execution."""
    success:   bool
    attempts:  int
    result:    Any          = None
    last_error: Optional[Exception] = None
    total_delay: float      = 0.0


class RetryPolicy:
    """
    Configurable retry policy with exponential phi-backoff and jitter.

    Args:
        max_attempts:      Total attempts before giving up (including first).
        backoff:           PhiBackoff instance (default: base=100ms, max=30s).
        retryable_errors:  Tuple of exception types to retry (None = retry all).
        timeout_per_call:  Per-attempt asyncio timeout in seconds.
        on_retry:          Optional async callback(attempt, exc) called before retry.
    """

    def __init__(
        self,
        max_attempts:     int                       = 3,
        backoff:          Optional[PhiBackoff]      = None,
        retryable_errors: Optional[Tuple]           = None,
        timeout_per_call: Optional[float]           = None,
        on_retry:         Optional[Callable]        = None,
    ) -> None:
        self.max_attempts     = max_attempts
        self.backoff          = backoff or PhiBackoff()
        self.retryable_errors = retryable_errors
        self.timeout_per_call = timeout_per_call
        self.on_retry         = on_retry

    async def execute(
        self,
        fn:    Callable[..., Coroutine],
        *args: Any,
        **kwargs: Any,
    ) -> RetryResult:
        """
        Execute ``fn`` with retry logic.

        Returns a RetryResult with the outcome, attempt count, and timing.
        """
        self.backoff.reset()
        last_exc:    Optional[Exception] = None
        total_delay: float               = 0.0

        for attempt in range(1, self.max_attempts + 1):
            try:
                if self.timeout_per_call:
                    result = await asyncio.wait_for(
                        fn(*args, **kwargs), timeout=self.timeout_per_call
                    )
                else:
                    result = await fn(*args, **kwargs)
                return RetryResult(
                    success    = True,
                    attempts   = attempt,
                    result     = result,
                    total_delay = total_delay,
                )
            except Exception as exc:
                last_exc = exc
                # Check if this exception is retryable
                if self.retryable_errors and not isinstance(exc, self.retryable_errors):
                    break

                if attempt < self.max_attempts:
                    delay = self.backoff.next_delay()
                    total_delay += delay
                    logger.debug(
                        "Retry %d/%d after %.2fs: %s",
                        attempt, self.max_attempts, delay, exc,
                    )
                    if self.on_retry:
                        try:
                            cb_result = self.on_retry(attempt, exc)
                            if asyncio.iscoroutine(cb_result):
                                await cb_result
                        except Exception:
                            pass
                    await asyncio.sleep(delay)

        return RetryResult(
            success     = False,
            attempts    = self.max_attempts,
            last_error  = last_exc,
            total_delay = total_delay,
        )

    def wrap(self, fn: Callable) -> Callable:
        """Decorator that applies this retry policy to an async function."""
        async def _wrapper(*args: Any, **kwargs: Any) -> Any:
            result = await self.execute(fn, *args, **kwargs)
            if not result.success:
                raise result.last_error or RuntimeError("RetryPolicy exhausted")
            return result.result
        _wrapper.__name__ = fn.__name__
        return _wrapper

    def __repr__(self) -> str:
        return f"RetryPolicy(max={self.max_attempts}, backoff={self.backoff!r})"


# ─── BulkheadIsolation ────────────────────────────────────────────────────────


class BulkheadFullError(Exception):
    """Raised when a bulkhead is at capacity and no waiting is requested."""
    def __init__(self, service: str) -> None:
        super().__init__(f"Bulkhead full for service '{service}'")


class BulkheadIsolation:
    """
    Bulkhead pattern: limit concurrent calls to a service.

    Prevents one slow/failing service from consuming all resources.

    Usage::

        bulkhead = BulkheadIsolation("payments", max_concurrent=10)
        async with bulkhead:
            await process_payment()

        # Or with a timeout
        acquired = await bulkhead.acquire(timeout=5.0)
        if acquired:
            try:
                await process_payment()
            finally:
                bulkhead.release()
    """

    def __init__(
        self,
        service:        str,
        max_concurrent: int   = 10,
        max_waiting:    int   = 20,
        acquire_timeout: float = 10.0,
    ) -> None:
        self._service         = service
        self._max_concurrent  = max_concurrent
        self._semaphore       = asyncio.Semaphore(max_concurrent)
        self._max_waiting     = max_waiting
        self._acquire_timeout = acquire_timeout
        self._waiting:    int = 0
        self._total_calls: int = 0
        self._rejected:    int = 0
        self._current:     int = 0

    async def acquire(self, timeout: Optional[float] = None) -> bool:
        """Acquire a slot. Returns True if acquired, False on timeout."""
        if self._waiting >= self._max_waiting:
            self._rejected += 1
            raise BulkheadFullError(self._service)
        self._waiting += 1
        try:
            await asyncio.wait_for(
                self._semaphore.acquire(),
                timeout=timeout or self._acquire_timeout,
            )
            self._current += 1
            self._total_calls += 1
            return True
        except asyncio.TimeoutError:
            self._rejected += 1
            return False
        finally:
            self._waiting = max(0, self._waiting - 1)

    def release(self) -> None:
        """Release an acquired slot."""
        self._current = max(0, self._current - 1)
        self._semaphore.release()

    async def __aenter__(self) -> "BulkheadIsolation":
        acquired = await self.acquire()
        if not acquired:
            raise BulkheadFullError(self._service)
        return self

    async def __aexit__(self, *_: Any) -> None:
        self.release()

    def wrap(self, fn: Callable) -> Callable:
        """Decorator applying bulkhead to an async function."""
        async def _wrapper(*args: Any, **kwargs: Any) -> Any:
            async with self:
                return await fn(*args, **kwargs)
        return _wrapper

    @property
    def utilization(self) -> float:
        return self._current / self._max_concurrent

    def stats(self) -> Dict[str, Any]:
        return {
            "service":       self._service,
            "max_concurrent": self._max_concurrent,
            "current":       self._current,
            "waiting":       self._waiting,
            "total_calls":   self._total_calls,
            "rejected":      self._rejected,
            "utilization":   round(self.utilization, 3),
        }

    def __repr__(self) -> str:
        return (
            f"BulkheadIsolation(service={self._service!r}, "
            f"{self._current}/{self._max_concurrent})"
        )


# ─── RateLimiter ─────────────────────────────────────────────────────────────


class RateLimiter:
    """
    Token bucket rate limiter.

    Tokens refill at ``refill_rate`` tokens per second up to ``capacity``.
    Calls that exceed the rate will either block (wait=True) or
    raise RateLimitExceeded.

    Args:
        capacity:     Maximum tokens in the bucket.
        refill_rate:  Tokens added per second.
        name:         Optional name for logging.
    """

    class RateLimitExceeded(Exception):
        def __init__(self, name: str, wait_time: float) -> None:
            super().__init__(f"Rate limit exceeded for '{name}' (wait {wait_time:.2f}s)")
            self.wait_time = wait_time

    def __init__(
        self,
        capacity:    float = 100.0,
        refill_rate: float = 10.0,
        name:        str   = "default",
    ) -> None:
        self._capacity    = capacity
        self._refill_rate = refill_rate
        self._name        = name
        self._tokens:     float = capacity
        self._last_refill: float = time.monotonic()
        self._lock        = asyncio.Lock()
        self._total_acquired: int = 0
        self._total_rejected: int = 0

    def _refill(self) -> None:
        now    = time.monotonic()
        delta  = now - self._last_refill
        gained = delta * self._refill_rate
        self._tokens      = min(self._capacity, self._tokens + gained)
        self._last_refill = now

    def acquire(self, tokens: float = 1.0) -> bool:
        """Non-blocking acquire. Returns True if tokens available, False otherwise."""
        self._refill()
        if self._tokens >= tokens:
            self._tokens -= tokens
            self._total_acquired += 1
            return True
        self._total_rejected += 1
        return False

    async def acquire_wait(self, tokens: float = 1.0, timeout: float = 60.0) -> bool:
        """
        Blocking acquire — waits until tokens are available or timeout expires.

        Returns True on success, False on timeout.
        """
        deadline = time.monotonic() + timeout
        async with self._lock:
            while True:
                self._refill()
                if self._tokens >= tokens:
                    self._tokens -= tokens
                    self._total_acquired += 1
                    return True
                wait_time = (tokens - self._tokens) / self._refill_rate
                if time.monotonic() + wait_time > deadline:
                    self._total_rejected += 1
                    return False
                await asyncio.sleep(min(wait_time, 0.05))

    def wait_time(self, tokens: float = 1.0) -> float:
        """Estimate seconds until ``tokens`` are available."""
        self._refill()
        deficit = max(0.0, tokens - self._tokens)
        return deficit / self._refill_rate

    def stats(self) -> Dict[str, Any]:
        self._refill()
        return {
            "name":            self._name,
            "capacity":        self._capacity,
            "tokens":          round(self._tokens, 2),
            "refill_rate":     self._refill_rate,
            "total_acquired":  self._total_acquired,
            "total_rejected":  self._total_rejected,
        }

    def __repr__(self) -> str:
        return (
            f"RateLimiter(name={self._name!r}, "
            f"tokens={self._tokens:.1f}/{self._capacity}, rate={self._refill_rate}/s)"
        )


# ─── HealthProbe ─────────────────────────────────────────────────────────────


@dataclass
class ProbeResult:
    name:       str
    healthy:    bool
    message:    str      = ""
    checked_at: float    = field(default_factory=time.time)
    duration:   float    = 0.0


class HealthProbe:
    """
    Liveness and readiness health probe system.

    Register named checks; run them individually or all at once.
    Maintains a rolling history of results.

    Usage::

        probe = HealthProbe()
        probe.register("db", lambda: db.ping())
        probe.register("cache", lambda: cache.ping())

        status = await probe.check_all()
        print(status["healthy"], status["checks"])
    """

    def __init__(self, history_size: int = 100) -> None:
        self._liveness_checks:  Dict[str, Callable] = {}
        self._readiness_checks: Dict[str, Callable] = {}
        self._history: deque = deque(maxlen=history_size)

    def register(
        self, name: str, check: Callable, kind: str = "liveness"
    ) -> None:
        """Register a health check function (sync or async)."""
        if kind == "readiness":
            self._readiness_checks[name] = check
        else:
            self._liveness_checks[name] = check

    def liveness(self, name: str) -> Callable:
        """Decorator to register a liveness check."""
        def _dec(fn): self.register(name, fn, kind="liveness"); return fn
        return _dec

    def readiness(self, name: str) -> Callable:
        """Decorator to register a readiness check."""
        def _dec(fn): self.register(name, fn, kind="readiness"); return fn
        return _dec

    async def _run_check(self, name: str, check: Callable) -> ProbeResult:
        t0 = time.monotonic()
        try:
            if asyncio.iscoroutinefunction(check):
                result = await asyncio.wait_for(check(), timeout=5.0)
            else:
                loop   = asyncio.get_event_loop()
                result = await loop.run_in_executor(None, check)
            healthy = bool(result) if result is not None else True
            return ProbeResult(
                name=name, healthy=healthy,
                message="ok" if healthy else "check returned falsy",
                checked_at=time.time(), duration=time.monotonic() - t0,
            )
        except asyncio.TimeoutError:
            return ProbeResult(
                name=name, healthy=False, message="timeout",
                checked_at=time.time(), duration=time.monotonic() - t0,
            )
        except Exception as exc:
            return ProbeResult(
                name=name, healthy=False, message=str(exc),
                checked_at=time.time(), duration=time.monotonic() - t0,
            )

    async def check_liveness(self) -> Dict[str, Any]:
        """Run all liveness checks."""
        results = await asyncio.gather(
            *[self._run_check(n, c) for n, c in self._liveness_checks.items()]
        )
        return self._summarise("liveness", list(results))

    async def check_readiness(self) -> Dict[str, Any]:
        """Run all readiness checks."""
        results = await asyncio.gather(
            *[self._run_check(n, c) for n, c in self._readiness_checks.items()]
        )
        return self._summarise("readiness", list(results))

    async def check_all(self) -> Dict[str, Any]:
        """Run all registered health checks."""
        all_checks = {**self._liveness_checks, **self._readiness_checks}
        results = await asyncio.gather(
            *[self._run_check(n, c) for n, c in all_checks.items()]
        )
        summary = self._summarise("all", list(results))
        self._history.append(summary)
        return summary

    def _summarise(self, kind: str, results: List[ProbeResult]) -> Dict[str, Any]:
        healthy = all(r.healthy for r in results)
        return {
            "healthy":   healthy,
            "kind":      kind,
            "timestamp": time.time(),
            "checks":    {
                r.name: {
                    "healthy":  r.healthy,
                    "message":  r.message,
                    "duration": round(r.duration * 1000, 2),
                }
                for r in results
            },
        }

    def last_result(self) -> Optional[Dict[str, Any]]:
        """Return the most recent check_all result."""
        return self._history[-1] if self._history else None


# ─── GracefulShutdown ─────────────────────────────────────────────────────────


class GracefulShutdown:
    """
    LIFO cleanup registry for graceful application shutdown.

    Register cleanup callbacks; execute them in reverse registration order
    with a global timeout.

    Usage::

        shutdown = GracefulShutdown(timeout=30.0)
        shutdown.register(db.close)
        shutdown.register(cache.flush)
        shutdown.register(server.stop)

        # On SIGTERM / app exit:
        await shutdown.execute()
    """

    def __init__(self, timeout: float = 30.0) -> None:
        self._timeout   = timeout
        self._cleanups: List[Tuple[str, Callable, float]] = []  # (name, fn, per_fn_timeout)
        self._executed  = False

    def register(
        self,
        cleanup:  Callable,
        name:     Optional[str] = None,
        timeout:  Optional[float] = None,
    ) -> None:
        """Register a cleanup function (sync or async)."""
        label = name or getattr(cleanup, "__name__", str(cleanup))
        self._cleanups.append((label, cleanup, timeout or self._timeout))

    async def execute(self) -> Dict[str, Any]:
        """
        Execute all registered cleanups in LIFO order.

        Returns a summary of results.
        """
        if self._executed:
            logger.warning("GracefulShutdown already executed")
            return {"already_executed": True}

        self._executed = True
        results: Dict[str, Any] = {}
        start = time.monotonic()

        for name, fn, fn_timeout in reversed(self._cleanups):
            t0 = time.monotonic()
            try:
                if asyncio.iscoroutinefunction(fn):
                    await asyncio.wait_for(fn(), timeout=fn_timeout)
                else:
                    loop = asyncio.get_event_loop()
                    await asyncio.wait_for(
                        loop.run_in_executor(None, fn), timeout=fn_timeout
                    )
                results[name] = {"ok": True, "duration": round(time.monotonic() - t0, 3)}
                logger.debug("Shutdown cleanup '%s' completed in %.3fs",
                             name, time.monotonic() - t0)
            except asyncio.TimeoutError:
                results[name] = {"ok": False, "error": "timeout"}
                logger.error("Shutdown cleanup '%s' timed out", name)
            except Exception as exc:
                results[name] = {"ok": False, "error": str(exc)}
                logger.error("Shutdown cleanup '%s' failed: %s", name, exc)

        total_duration = time.monotonic() - start
        return {
            "cleanups":      len(self._cleanups),
            "results":       results,
            "total_duration": round(total_duration, 3),
            "all_ok":        all(v.get("ok") for v in results.values()),
        }

    def __repr__(self) -> str:
        return f"GracefulShutdown(cleanups={len(self._cleanups)}, timeout={self._timeout}s)"


# ─── SelfHealingComponent ────────────────────────────────────────────────────


class HealthState(str, Enum):
    """Self-healing lifecycle states."""
    HEALTHY      = "healthy"
    SUSPECT      = "suspect"
    QUARANTINED  = "quarantined"
    RECOVERING   = "recovering"
    RESTORED     = "restored"
    DEAD         = "dead"


class SelfHealingComponent:
    """
    Self-healing lifecycle manager.

    Tracks error rates and transitions a component through:
      HEALTHY → SUSPECT → QUARANTINED → RECOVERING → RESTORED

    Each transition triggers registered callbacks (async or sync).
    Automatic recovery attempts are scheduled after quarantine timeout.

    Usage::

        healer = SelfHealingComponent("payment-gateway")

        @healer.on_state_change(HealthState.QUARANTINED)
        async def on_quarantine(component, old_state, new_state):
            await alert_ops(f"{component} is quarantined!")

        healer.record_failure()  # call when errors occur
        healer.record_success()  # call when healthy requests complete
    """

    def __init__(
        self,
        name:               str,
        suspect_threshold:  float = 0.3,   # error rate to enter SUSPECT
        quarantine_threshold: float = 0.6,  # error rate to QUARANTINE
        recovery_timeout:   float = 60.0,  # seconds before recovery attempt
        window_size:        int   = 20,    # rolling window for error rate
        recovery_fn:        Optional[Callable] = None,
    ) -> None:
        self._name                 = name
        self._suspect_threshold    = suspect_threshold
        self._quarantine_threshold = quarantine_threshold
        self._recovery_timeout     = recovery_timeout
        self._window:    deque     = deque(maxlen=window_size)
        self._recovery_fn          = recovery_fn
        self._state                = HealthState.HEALTHY
        self._quarantined_at       = 0.0
        self._state_hooks:  Dict[HealthState, List[Callable]] = {}
        self._recovery_task: Optional[asyncio.Task] = None

        self._total_ok:     int = 0
        self._total_fail:   int = 0
        self._transitions:  int = 0

    def on_state_change(
        self, state: HealthState, handler: Optional[Callable] = None
    ) -> Callable:
        """Register a callback for a specific state transition."""
        def _dec(fn: Callable) -> Callable:
            self._state_hooks.setdefault(state, []).append(fn)
            return fn
        if handler is not None:
            return _dec(handler)
        return _dec

    def record_success(self) -> None:
        """Record a successful operation."""
        self._window.append(True)
        self._total_ok += 1
        self._evaluate()

    def record_failure(self) -> None:
        """Record a failed operation."""
        self._window.append(False)
        self._total_fail += 1
        self._evaluate()

    @property
    def error_rate(self) -> float:
        if not self._window:
            return 0.0
        return sum(1 for v in self._window if not v) / len(self._window)

    def _evaluate(self) -> None:
        """Evaluate the current error rate and transition state if needed."""
        rate = self.error_rate
        old  = self._state

        if self._state in (HealthState.HEALTHY, HealthState.RESTORED, HealthState.SUSPECT):
            if rate >= self._quarantine_threshold:
                self._transition(HealthState.QUARANTINED)
            elif rate >= self._suspect_threshold:
                self._transition(HealthState.SUSPECT)
            elif rate < self._suspect_threshold / 2:
                if self._state not in (HealthState.HEALTHY,):
                    self._transition(HealthState.HEALTHY)

    def _transition(self, new_state: HealthState) -> None:
        if new_state == self._state:
            return
        old_state      = self._state
        self._state    = new_state
        self._transitions += 1
        logger.info(
            "Component '%s': %s → %s (error_rate=%.2f%%)",
            self._name, old_state.value, new_state.value, self.error_rate * 100,
        )
        # Fire hooks
        for hook in self._state_hooks.get(new_state, []):
            try:
                result = hook(self, old_state, new_state)
                if asyncio.iscoroutine(result):
                    asyncio.create_task(result)
            except Exception as exc:
                logger.warning("State hook error: %s", exc)

        # Schedule recovery attempt after quarantine
        if new_state == HealthState.QUARANTINED:
            self._quarantined_at = time.monotonic()
            self._recovery_task  = asyncio.create_task(self._recovery_loop())

    async def _recovery_loop(self) -> None:
        """Periodically attempt to recover from quarantine."""
        while self._state == HealthState.QUARANTINED:
            await asyncio.sleep(self._recovery_timeout)
            await self._attempt_recovery()

    async def _attempt_recovery(self) -> None:
        """Run the recovery function and transition based on result."""
        self._transition(HealthState.RECOVERING)
        logger.info("Component '%s' attempting recovery...", self._name)
        try:
            if self._recovery_fn:
                if asyncio.iscoroutinefunction(self._recovery_fn):
                    await self._recovery_fn()
                else:
                    loop = asyncio.get_event_loop()
                    await loop.run_in_executor(None, self._recovery_fn)
            # Clear the error window to reset error rate
            self._window.clear()
            self._transition(HealthState.RESTORED)
            logger.info("Component '%s' recovered successfully", self._name)
        except Exception as exc:
            logger.error("Component '%s' recovery failed: %s", self._name, exc)
            self._transition(HealthState.QUARANTINED)

    def force_state(self, state: HealthState) -> None:
        """Manually force a specific state (for testing or administrative override)."""
        self._transition(state)

    @property
    def state(self) -> HealthState:
        return self._state

    @property
    def is_available(self) -> bool:
        """True if the component can accept requests."""
        return self._state in (
            HealthState.HEALTHY, HealthState.SUSPECT, HealthState.RESTORED
        )

    def stats(self) -> Dict[str, Any]:
        return {
            "name":         self._name,
            "state":        self._state.value,
            "error_rate":   round(self.error_rate, 4),
            "total_ok":     self._total_ok,
            "total_fail":   self._total_fail,
            "transitions":  self._transitions,
            "is_available": self.is_available,
        }

    def __repr__(self) -> str:
        return (
            f"SelfHealingComponent(name={self._name!r}, "
            f"state={self._state.value}, error_rate={self.error_rate:.1%})"
        )
