"""
pipeline.py
===========
HCFullPipeline — 12-stage async pipeline orchestration for the Heady system.

Stages (in order):
  INTAKE       → receive and validate raw input
  TRIAGE       → classify priority and urgency
  DECOMPOSE    → break into sub-tasks (if complex)
  MONTE_CARLO  → run uncertainty simulation
  ARENA        → competitive node evaluation
  JUDGE        → select best arena result
  APPROVE      → human/policy approval gate
  EXECUTE      → run actual work
  VERIFY       → validate output
  RECEIPT      → acknowledge completion
  ARCHIVE      → persist to long-term storage
  LEARN        → extract patterns for future use

State machine transitions:
  IDLE → RUNNING → (PAUSED | FAILED | COMPLETED)
  Any stage can transition to FAILED or ROLLBACK.
  Stages can be skipped via skip-list in PipelineConfig.

Features:
  - Async execution with asyncio (concurrent stages where dependencies allow)
  - Per-stage timeout (configurable)
  - Stage rollback support (LIFO order)
  - Event hooks at every stage transition
  - Comprehensive state and timing tracking
  - Pipeline templates for common workflows
  - Zero external dependencies

Usage::

    from orchestration.pipeline import HCFullPipeline, PipelineConfig, PipelineTemplate

    pipeline = HCFullPipeline(config=PipelineConfig(timeout_per_stage=10.0))

    @pipeline.on_stage(PipelineStage.EXECUTE)
    async def my_executor(ctx):
        ctx["output"] = await do_work(ctx["payload"])

    result = await pipeline.run({"payload": "hello world"})
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Coroutine, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)

# ─── Stage enumeration ────────────────────────────────────────────────────────


class PipelineStage(str, Enum):
    """The 12 canonical pipeline stages in execution order."""
    INTAKE      = "INTAKE"
    TRIAGE      = "TRIAGE"
    DECOMPOSE   = "DECOMPOSE"
    MONTE_CARLO = "MONTE_CARLO"
    ARENA       = "ARENA"
    JUDGE       = "JUDGE"
    APPROVE     = "APPROVE"
    EXECUTE     = "EXECUTE"
    VERIFY      = "VERIFY"
    RECEIPT     = "RECEIPT"
    ARCHIVE     = "ARCHIVE"
    LEARN       = "LEARN"


STAGE_ORDER: List[PipelineStage] = list(PipelineStage)

# Stages that may be skipped for lightweight pipelines
OPTIONAL_STAGES: Set[PipelineStage] = {
    PipelineStage.DECOMPOSE,
    PipelineStage.MONTE_CARLO,
    PipelineStage.ARENA,
    PipelineStage.JUDGE,
    PipelineStage.APPROVE,
    PipelineStage.ARCHIVE,
    PipelineStage.LEARN,
}


# ─── Pipeline state machine ──────────────────────────────────────────────────


class PipelineState(str, Enum):
    """Overall pipeline lifecycle state."""
    IDLE       = "IDLE"
    RUNNING    = "RUNNING"
    PAUSED     = "PAUSED"
    COMPLETED  = "COMPLETED"
    FAILED     = "FAILED"
    ROLLING_BACK = "ROLLING_BACK"
    ROLLED_BACK  = "ROLLED_BACK"


# ─── Data classes ─────────────────────────────────────────────────────────────


@dataclass
class StageResult:
    """Outcome of a single pipeline stage execution."""
    stage:      PipelineStage
    state:      str           = "pending"   # pending | running | success | failed | skipped
    started_at: Optional[float] = None
    ended_at:   Optional[float] = None
    data:       Dict[str, Any]  = field(default_factory=dict)
    error:      Optional[str]   = None

    @property
    def duration(self) -> float:
        if self.started_at and self.ended_at:
            return self.ended_at - self.started_at
        return 0.0

    @property
    def succeeded(self) -> bool:
        return self.state == "success"

    @property
    def skipped(self) -> bool:
        return self.state == "skipped"


@dataclass
class PipelineConfig:
    """Configuration for an HCFullPipeline instance."""
    timeout_per_stage: float           = 30.0      # seconds
    skip_stages:       Set[PipelineStage] = field(default_factory=set)
    parallel_groups:   List[List[PipelineStage]] = field(default_factory=list)
    max_retries_per_stage: int         = 1
    rollback_on_failure:   bool        = True
    pause_on_approve:      bool        = False     # wait for external approval signal
    emit_events:           bool        = True
    metadata:              Dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineRun:
    """A single execution run of the pipeline."""
    run_id:      str                         = field(default_factory=lambda: str(uuid.uuid4()))
    state:       PipelineState               = PipelineState.IDLE
    context:     Dict[str, Any]              = field(default_factory=dict)
    stage_results: Dict[PipelineStage, StageResult] = field(default_factory=dict)
    started_at:  Optional[float]             = None
    ended_at:    Optional[float]             = None
    error:       Optional[str]               = None
    rollback_log: List[str]                  = field(default_factory=list)

    @property
    def duration(self) -> float:
        if self.started_at and self.ended_at:
            return self.ended_at - self.started_at
        return 0.0

    @property
    def succeeded(self) -> bool:
        return self.state == PipelineState.COMPLETED

    def to_summary(self) -> Dict[str, Any]:
        return {
            "run_id":   self.run_id,
            "state":    self.state.value,
            "duration": round(self.duration, 4),
            "stages":   {
                s.value: {
                    "state":    r.state,
                    "duration": round(r.duration, 4),
                    "error":    r.error,
                }
                for s, r in self.stage_results.items()
            },
            "error": self.error,
        }


# ─── Pipeline Templates ───────────────────────────────────────────────────────


class PipelineTemplate(str, Enum):
    """Pre-built pipeline configurations for common workflows."""
    FULL         = "FULL"         # All 12 stages
    FAST         = "FAST"         # Skip simulation + arena
    CODE_REVIEW  = "CODE_REVIEW"  # Focus on verify + approve
    RESEARCH     = "RESEARCH"     # Skip arena, heavy decompose
    MAINTENANCE  = "MAINTENANCE"  # Skip arena + judge
    MINIMAL      = "MINIMAL"      # Intake → Execute → Verify only


_TEMPLATE_CONFIGS: Dict[PipelineTemplate, Dict[str, Any]] = {
    PipelineTemplate.FULL: {
        "skip_stages": set(),
    },
    PipelineTemplate.FAST: {
        "skip_stages": {PipelineStage.DECOMPOSE, PipelineStage.MONTE_CARLO,
                        PipelineStage.ARENA, PipelineStage.JUDGE},
    },
    PipelineTemplate.CODE_REVIEW: {
        "skip_stages": {PipelineStage.DECOMPOSE, PipelineStage.MONTE_CARLO,
                        PipelineStage.ARENA, PipelineStage.JUDGE},
        "pause_on_approve": True,
    },
    PipelineTemplate.RESEARCH: {
        "skip_stages": {PipelineStage.ARENA, PipelineStage.JUDGE},
    },
    PipelineTemplate.MAINTENANCE: {
        "skip_stages": {PipelineStage.MONTE_CARLO, PipelineStage.ARENA,
                        PipelineStage.JUDGE, PipelineStage.APPROVE},
    },
    PipelineTemplate.MINIMAL: {
        "skip_stages": {
            PipelineStage.DECOMPOSE, PipelineStage.MONTE_CARLO, PipelineStage.ARENA,
            PipelineStage.JUDGE, PipelineStage.APPROVE, PipelineStage.RECEIPT,
            PipelineStage.ARCHIVE, PipelineStage.LEARN,
        },
    },
}


def config_from_template(
    template: PipelineTemplate,
    overrides: Optional[Dict[str, Any]] = None,
) -> PipelineConfig:
    """Build a PipelineConfig from a named template with optional overrides."""
    base = dict(_TEMPLATE_CONFIGS[template])
    if overrides:
        base.update(overrides)
    return PipelineConfig(**{k: v for k, v in base.items()
                              if k in PipelineConfig.__dataclass_fields__})


# ─── HCFullPipeline ───────────────────────────────────────────────────────────


class HCFullPipeline:
    """
    12-Stage async pipeline orchestration engine for the Heady system.

    Each stage follows the pattern:
      enter_hook → validate → process → exit_hook

    Supports:
      - Per-stage custom handlers registered with ``on_stage()``
      - Event hooks at every transition via ``on_event()``
      - Rollback handlers registered with ``on_rollback()``
      - Stage skipping, timeouts, and retries
      - Parallel execution of independent stage groups
      - Template-based configuration
    """

    def __init__(self, config: Optional[PipelineConfig] = None) -> None:
        self._config    = config or PipelineConfig()
        self._handlers: Dict[PipelineStage, List[Callable]] = defaultdict(list)
        self._rollbacks: Dict[PipelineStage, List[Callable]] = defaultdict(list)
        self._event_hooks: Dict[str, List[Callable]] = defaultdict(list)
        self._approve_event: asyncio.Event = asyncio.Event()
        self._approve_event.set()  # default: auto-approve

    # ── Handler registration ─────────────────────────────────────────────────

    def on_stage(
        self,
        stage: PipelineStage,
        handler: Optional[Callable] = None,
    ) -> Callable:
        """
        Register an async handler for a pipeline stage.

        Can be used as a decorator or called directly::

            @pipeline.on_stage(PipelineStage.EXECUTE)
            async def run(ctx): ...

            pipeline.on_stage(PipelineStage.EXECUTE, run)
        """
        def _decorator(fn: Callable) -> Callable:
            self._handlers[stage].append(fn)
            return fn
        if handler is not None:
            return _decorator(handler)
        return _decorator

    def on_rollback(self, stage: PipelineStage, handler: Optional[Callable] = None) -> Callable:
        """Register a rollback handler for a pipeline stage (LIFO on failure)."""
        def _decorator(fn: Callable) -> Callable:
            self._rollbacks[stage].append(fn)
            return fn
        if handler is not None:
            return _decorator(handler)
        return _decorator

    def on_event(self, event: str, handler: Optional[Callable] = None) -> Callable:
        """Register a handler for pipeline lifecycle events."""
        def _decorator(fn: Callable) -> Callable:
            self._event_hooks[event].append(fn)
            return fn
        if handler is not None:
            return _decorator(handler)
        return _decorator

    def set_approval_event(self, event: asyncio.Event) -> None:
        """
        Inject an external asyncio.Event for the APPROVE stage gate.

        The pipeline will wait for this event before proceeding past APPROVE.
        """
        self._approve_event = event

    # ── Core run ─────────────────────────────────────────────────────────────

    async def run(
        self,
        input_data: Dict[str, Any],
        run_id: Optional[str] = None,
        extra_skips: Optional[Set[PipelineStage]] = None,
    ) -> PipelineRun:
        """
        Execute the full pipeline for the given input.

        Args:
            input_data:   Initial context data passed through all stages.
            run_id:       Optional explicit run ID (auto-generated if not provided).
            extra_skips:  Additional stages to skip for this specific run.

        Returns:
            A completed PipelineRun with full stage results and final context.
        """
        run = PipelineRun(
            run_id  = run_id or str(uuid.uuid4()),
            state   = PipelineState.RUNNING,
            context = dict(input_data),
        )
        run.started_at = time.monotonic()

        skip = set(self._config.skip_stages)
        if extra_skips:
            skip |= extra_skips

        await self._emit_event("pipeline.started", run)
        logger.info("Pipeline run %s started (%d stages, %d skipped)",
                    run.run_id, len(STAGE_ORDER), len(skip))

        completed_stages: List[PipelineStage] = []

        for stage in STAGE_ORDER:
            if stage in skip:
                sr = StageResult(stage=stage, state="skipped")
                run.stage_results[stage] = sr
                await self._emit_event("stage.skipped", run, stage=stage)
                continue

            sr = await self._run_stage(stage, run)
            run.stage_results[stage] = sr

            if sr.state == "failed":
                run.state = PipelineState.FAILED
                run.error = sr.error
                await self._emit_event("pipeline.failed", run, stage=stage)
                if self._config.rollback_on_failure:
                    await self._rollback(run, completed_stages)
                run.ended_at = time.monotonic()
                return run

            if sr.succeeded:
                completed_stages.append(stage)

        run.state    = PipelineState.COMPLETED
        run.ended_at = time.monotonic()
        await self._emit_event("pipeline.completed", run)
        logger.info("Pipeline run %s completed in %.3fs", run.run_id, run.duration)
        return run

    # ── Stage execution ──────────────────────────────────────────────────────

    async def _run_stage(self, stage: PipelineStage, run: PipelineRun) -> StageResult:
        """Execute a single stage with enter/validate/process/exit pattern."""
        sr = StageResult(stage=stage, state="running", started_at=time.monotonic())
        await self._emit_event("stage.enter", run, stage=stage)

        attempts = 0
        max_attempts = max(1, self._config.max_retries_per_stage)

        while attempts < max_attempts:
            attempts += 1
            try:
                # --- validate ---
                await self._validate_stage(stage, run)

                # --- special handling: APPROVE pause gate ---
                if stage == PipelineStage.APPROVE and self._config.pause_on_approve:
                    run.state = PipelineState.PAUSED
                    await self._emit_event("stage.pause", run, stage=stage)
                    try:
                        await asyncio.wait_for(
                            self._approve_event.wait(),
                            timeout=self._config.timeout_per_stage,
                        )
                    except asyncio.TimeoutError:
                        raise TimeoutError("APPROVE gate timed out waiting for approval")
                    run.state = PipelineState.RUNNING
                    self._approve_event.clear()
                    self._approve_event.set()  # reset for next run

                # --- process (call registered handlers) ---
                stage_data: Dict[str, Any] = {}
                handlers = self._handlers.get(stage, [])
                if handlers:
                    for handler in handlers:
                        try:
                            result = await asyncio.wait_for(
                                self._call_handler(handler, run.context),
                                timeout=self._config.timeout_per_stage,
                            )
                            if isinstance(result, dict):
                                stage_data.update(result)
                                run.context.update(result)
                        except asyncio.TimeoutError:
                            raise TimeoutError(
                                f"Stage {stage.value} handler timed out "
                                f"after {self._config.timeout_per_stage}s"
                            )
                else:
                    # Default stub processing
                    stage_data = await self._default_stage_handler(stage, run)
                    run.context.update(stage_data)

                sr.data     = stage_data
                sr.state    = "success"
                sr.ended_at = time.monotonic()
                await self._emit_event("stage.exit", run, stage=stage)
                logger.debug("Stage %s completed in %.3fs", stage.value, sr.duration)
                return sr

            except Exception as exc:
                logger.warning(
                    "Stage %s attempt %d/%d failed: %s",
                    stage.value, attempts, max_attempts, exc,
                )
                if attempts >= max_attempts:
                    sr.state    = "failed"
                    sr.error    = str(exc)
                    sr.ended_at = time.monotonic()
                    await self._emit_event("stage.failed", run, stage=stage, error=str(exc))
                    return sr
                await asyncio.sleep(0.05 * attempts)  # brief back-off between retries

        sr.state    = "failed"
        sr.error    = "Max retries exceeded"
        sr.ended_at = time.monotonic()
        return sr

    async def _call_handler(
        self, handler: Callable, ctx: Dict[str, Any]
    ) -> Any:
        """Call a handler, whether it's a coroutine function or a sync function."""
        if asyncio.iscoroutinefunction(handler):
            return await handler(ctx)
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, handler, ctx)

    async def _validate_stage(self, stage: PipelineStage, run: PipelineRun) -> None:
        """
        Per-stage validation gate called before processing.

        Override individual stage validations by subclassing.
        """
        ctx = run.context
        if stage == PipelineStage.INTAKE:
            if not ctx:
                raise ValueError("INTAKE: empty input context")
        elif stage == PipelineStage.EXECUTE:
            if "triage_done" not in ctx and "skipped_triage" not in ctx:
                # soft check — warn only
                logger.debug("EXECUTE: TRIAGE context key missing (may be skipped)")

    # ── Default stage handlers ────────────────────────────────────────────────

    async def _default_stage_handler(
        self, stage: PipelineStage, run: PipelineRun
    ) -> Dict[str, Any]:
        """
        Built-in logic for each stage when no custom handler is registered.

        These provide sensible defaults so the pipeline is immediately runnable.
        """
        ctx = run.context
        await asyncio.sleep(0)  # yield

        if stage == PipelineStage.INTAKE:
            return {
                "intake_id":      run.run_id,
                "raw_payload":    ctx.get("payload"),
                "received_at":    time.time(),
                "schema_valid":   True,
            }

        elif stage == PipelineStage.TRIAGE:
            text  = str(ctx.get("payload", ""))
            urgent = any(w in text.lower() for w in ("urgent", "critical", "asap"))
            return {
                "triage_done":  True,
                "priority":     "hot" if urgent else "warm",
                "domain":       ctx.get("domain", "unknown"),
                "complexity":   "simple" if len(text) < 200 else "complex",
            }

        elif stage == PipelineStage.DECOMPOSE:
            payload = ctx.get("payload", "")
            words   = str(payload).split()
            sub_tasks = [{"id": i, "chunk": " ".join(words[i:i+50])}
                         for i in range(0, min(len(words), 200), 50)]
            return {
                "sub_tasks":   sub_tasks,
                "task_count":  len(sub_tasks),
                "decomposed":  True,
            }

        elif stage == PipelineStage.MONTE_CARLO:
            import random
            import math
            PHI = 1.6180339887
            runs_count = int(PHI ** 5)  # ≈ 11 quick sim runs
            durations  = [random.gauss(1.0, 0.3) for _ in range(runs_count)]
            durations  = [max(0.1, d) for d in durations]
            mean_d     = sum(durations) / len(durations)
            variance   = sum((d - mean_d) ** 2 for d in durations) / len(durations)
            return {
                "mc_runs":           runs_count,
                "estimated_duration": round(mean_d, 4),
                "std_dev":           round(math.sqrt(variance), 4),
                "p95":               round(sorted(durations)[int(0.95 * len(durations))], 4),
                "confidence":        0.85,
            }

        elif stage == PipelineStage.ARENA:
            return {
                "arena_enabled":  False,
                "candidates":     0,
                "note": "Arena requires conductor integration",
            }

        elif stage == PipelineStage.JUDGE:
            return {
                "selected_strategy": ctx.get("arena_winner", "default"),
                "judge_reason":      "highest_score",
            }

        elif stage == PipelineStage.APPROVE:
            return {
                "approved":    True,
                "approver":    "auto",
                "approved_at": time.time(),
            }

        elif stage == PipelineStage.EXECUTE:
            return {
                "executed":   True,
                "output":     ctx.get("payload"),
                "executed_at": time.time(),
            }

        elif stage == PipelineStage.VERIFY:
            output  = ctx.get("output")
            passed  = output is not None
            return {
                "verified": passed,
                "checks":   ["output_present", "schema_valid"],
                "passed":   passed,
            }

        elif stage == PipelineStage.RECEIPT:
            return {
                "receipt_id": str(uuid.uuid4()),
                "run_id":     run.run_id,
                "issued_at":  time.time(),
                "status":     "completed",
            }

        elif stage == PipelineStage.ARCHIVE:
            return {
                "archived":     True,
                "archive_key":  f"run:{run.run_id}",
                "archived_at":  time.time(),
            }

        elif stage == PipelineStage.LEARN:
            stage_timings = {
                s.value: round(r.duration * 1000, 2)
                for s, r in run.stage_results.items()
                if r.state == "success"
            }
            return {
                "patterns_extracted": 1,
                "stage_timings":      stage_timings,
                "learned_at":         time.time(),
            }

        return {}

    # ── Rollback ─────────────────────────────────────────────────────────────

    async def _rollback(
        self, run: PipelineRun, completed_stages: List[PipelineStage]
    ) -> None:
        """Execute rollback handlers in LIFO order for all completed stages."""
        run.state = PipelineState.ROLLING_BACK
        await self._emit_event("pipeline.rollback_start", run)
        logger.info("Rolling back pipeline %s (%d stages)", run.run_id, len(completed_stages))

        for stage in reversed(completed_stages):
            handlers = self._rollbacks.get(stage, [])
            for handler in handlers:
                try:
                    await asyncio.wait_for(
                        self._call_handler(handler, run.context),
                        timeout=self._config.timeout_per_stage,
                    )
                    run.rollback_log.append(f"Rolled back {stage.value}")
                    logger.debug("Rolled back stage %s", stage.value)
                except Exception as exc:
                    run.rollback_log.append(f"Rollback failed for {stage.value}: {exc}")
                    logger.error("Rollback error at %s: %s", stage.value, exc)

        run.state = PipelineState.ROLLED_BACK
        await self._emit_event("pipeline.rolled_back", run)

    # ── Event emission ────────────────────────────────────────────────────────

    async def _emit_event(
        self,
        event: str,
        run: PipelineRun,
        stage: Optional[PipelineStage] = None,
        **kwargs: Any,
    ) -> None:
        if not self._config.emit_events:
            return
        data = {
            "run_id":  run.run_id,
            "state":   run.state.value,
            "stage":   stage.value if stage else None,
            **kwargs,
        }
        for handler in self._event_hooks.get(event, []):
            try:
                result = handler(event, data)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as exc:
                logger.warning("Event hook error (%s): %s", event, exc)

    # ── Parallel group execution ──────────────────────────────────────────────

    async def run_parallel_group(
        self,
        stages: List[PipelineStage],
        run: PipelineRun,
    ) -> Dict[PipelineStage, StageResult]:
        """
        Execute a group of stages concurrently.

        All stages in the group are independent — they share the context
        from before the group starts, and their outputs are merged into
        the context after all complete.

        Returns a mapping of stage → StageResult.
        """
        tasks = {stage: asyncio.create_task(self._run_stage(stage, run))
                 for stage in stages}
        results: Dict[PipelineStage, StageResult] = {}
        for stage, task in tasks.items():
            try:
                results[stage] = await task
            except Exception as exc:
                results[stage] = StageResult(
                    stage=stage, state="failed",
                    error=str(exc), ended_at=time.monotonic()
                )
        # Merge successful stage outputs into context
        for stage, sr in results.items():
            if sr.succeeded:
                run.context.update(sr.data)
        return results

    # ── Factory / template helpers ────────────────────────────────────────────

    @classmethod
    def from_template(
        cls,
        template: PipelineTemplate,
        overrides: Optional[Dict[str, Any]] = None,
    ) -> "HCFullPipeline":
        """Create an HCFullPipeline pre-configured from a template."""
        config = config_from_template(template, overrides)
        return cls(config=config)

    # ── Introspection ────────────────────────────────────────────────────────

    def describe(self) -> Dict[str, Any]:
        """Return a human-readable description of this pipeline configuration."""
        return {
            "stages": [s.value for s in STAGE_ORDER],
            "skipped": [s.value for s in self._config.skip_stages],
            "optional": [s.value for s in OPTIONAL_STAGES],
            "timeout_per_stage": self._config.timeout_per_stage,
            "rollback_on_failure": self._config.rollback_on_failure,
            "pause_on_approve": self._config.pause_on_approve,
            "handlers_registered": {
                s.value: len(h) for s, h in self._handlers.items()
            },
        }

    def __repr__(self) -> str:
        skip = len(self._config.skip_stages)
        return f"HCFullPipeline(stages=12, skipped={skip}, timeout={self._config.timeout_per_stage}s)"
