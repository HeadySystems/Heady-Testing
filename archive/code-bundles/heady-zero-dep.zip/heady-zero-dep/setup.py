"""
setup.py
========
Heady Zero-Dep Bootstrap Script

Validates the runtime environment, creates required directories, initialises
the SQLite database, generates a default .env if one is absent, runs a
self-test sweep across every module, and prints a system-readiness report.

Usage::

    python setup.py              # full bootstrap (interactive)
    python setup.py --check      # check only, no writes
    python setup.py --quiet      # minimal output
    python setup.py --force      # overwrite existing .env

Exit codes:
    0  — all checks passed
    1  — warnings only (system usable but degraded)
    2  — critical failure (system not usable)
"""

from __future__ import annotations

import argparse
import importlib
import json
import os
import platform
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from typing import List, Optional, Tuple


# ─── Colour helpers ───────────────────────────────────────────────────────────

_USE_COLOUR = sys.stdout.isatty() or os.getenv("FORCE_COLOR") == "1"

def _c(code: str, text: str) -> str:
    if not _USE_COLOUR:
        return text
    return f"\033[{code}m{text}\033[0m"

OK    = _c("32", "✓")
WARN  = _c("33", "⚠")
FAIL  = _c("31", "✗")
INFO  = _c("36", "·")

PHI: float = 1.6180339887498948482


# ─── Report accumulator ──────────────────────────────────────────────────────

_results: List[Tuple[str, str, str]] = []  # (status, category, message)
_warnings = 0
_failures = 0

def _record(status: str, category: str, message: str, quiet: bool = False) -> None:
    global _warnings, _failures
    _results.append((status, category, message))
    if status == "FAIL":
        _failures += 1
    elif status == "WARN":
        _warnings += 1
    if not quiet:
        icon = {"OK": OK, "WARN": WARN, "FAIL": FAIL, "INFO": INFO}.get(status, status)
        print(f"  {icon}  [{category}] {message}")


# ─── 1. Python version ────────────────────────────────────────────────────────

def check_python_version(quiet: bool = False) -> None:
    v = sys.version_info
    msg = f"Python {v.major}.{v.minor}.{v.micro}"
    if v < (3, 10):
        _record("FAIL", "Python", f"{msg} — requires ≥3.10", quiet)
    elif v >= (3, 13):
        _record("WARN", "Python", f"{msg} — 3.13+ is untested with sentence-transformers", quiet)
    else:
        _record("OK", "Python", msg, quiet)


# ─── 2. Required stdlib modules ──────────────────────────────────────────────

_REQUIRED_STDLIB = [
    "asyncio", "sqlite3", "json", "threading", "pathlib",
    "hashlib", "uuid", "math", "statistics", "logging",
    "urllib.request", "http.server", "signal", "subprocess",
]

def check_stdlib(quiet: bool = False) -> None:
    for mod in _REQUIRED_STDLIB:
        try:
            importlib.import_module(mod)
            _record("OK", "stdlib", mod, quiet)
        except ImportError as e:
            _record("FAIL", "stdlib", f"{mod} — {e}", quiet)


# ─── 3. Third-party dependencies ─────────────────────────────────────────────

def check_torch(quiet: bool = False) -> None:
    try:
        import torch  # type: ignore
        cuda = torch.cuda.is_available()
        device = torch.cuda.get_device_name(0) if cuda else "CPU"
        _record("OK", "torch", f"{torch.__version__}  device={device}", quiet)
    except ImportError:
        _record("WARN", "torch", "not installed — run: pip install torch", quiet)

def check_sentence_transformers(quiet: bool = False) -> None:
    try:
        import sentence_transformers  # type: ignore
        _record("OK", "sentence-transformers", sentence_transformers.__version__, quiet)
    except ImportError:
        _record("WARN", "sentence-transformers",
                "not installed — run: pip install sentence-transformers", quiet)


# ─── 4. Heady module imports ─────────────────────────────────────────────────

_HEADY_MODULES = {
    "core.http_server":       "HTTPServer",
    "core.http_client":       "HTTPClient",
    "core.cache":             "Cache",
    "core.database":          "Database",
    "core.telemetry":         "Telemetry",
    "core.env_loader":        "load_env",
    "core.process_manager":   "ProcessManager",
    "ai.vector_math":         "cosine_similarity",
    "ai.vector_memory":       "VectorMemory",
    "ai.embedding_server":    "EmbeddingServer",
    "ai.llm_gateway":         "LLMGateway",
    "ai.monte_carlo":         "MonteCarloSimulator",
    "ai.semantic_logic":      "cosine_similarity",
    "orchestration.conductor":    "HeadyConductor",
    "orchestration.pipeline":     "HCFullPipeline",
    "orchestration.mcp_protocol": "MCPServer",
    "orchestration.github_client":"GitHubClient",
    "orchestration.bee_factory":  "BeeFactory",
    "orchestration.resilience":   "CircuitBreaker",
    "orchestration.swarm":        "SwarmCoordinator",
}

def check_heady_modules(quiet: bool = False) -> None:
    # Ensure the workspace root is importable
    root = str(Path(__file__).parent)
    if root not in sys.path:
        sys.path.insert(0, root)

    for module_name, attr in _HEADY_MODULES.items():
        try:
            mod = importlib.import_module(module_name)
            if not hasattr(mod, attr):
                _record("WARN", "heady", f"{module_name}.{attr} — attribute missing", quiet)
            else:
                _record("OK", "heady", module_name, quiet)
        except ImportError as e:
            _record("FAIL", "heady", f"{module_name} — {e}", quiet)
        except Exception as e:
            _record("WARN", "heady", f"{module_name} — {e}", quiet)


# ─── 5. Directory structure ───────────────────────────────────────────────────

_REQUIRED_DIRS = [
    "data",
    "data/vectors",
    "data/cache",
    "data/logs",
    "data/backups",
    "data/checkpoints",
]

def ensure_directories(root: Path, dry_run: bool = False, quiet: bool = False) -> None:
    for rel in _REQUIRED_DIRS:
        d = root / rel
        if d.exists():
            _record("OK", "dirs", str(d.relative_to(root)), quiet)
        elif dry_run:
            _record("INFO", "dirs", f"would create: {rel}", quiet)
        else:
            try:
                d.mkdir(parents=True, exist_ok=True)
                _record("OK", "dirs", f"created {rel}", quiet)
            except OSError as e:
                _record("FAIL", "dirs", f"cannot create {rel}: {e}", quiet)

    # .gitkeep in each dir
    if not dry_run:
        for rel in _REQUIRED_DIRS:
            gk = root / rel / ".gitkeep"
            if not gk.exists():
                try:
                    gk.touch()
                except OSError:
                    pass


# ─── 6. SQLite database initialisation ───────────────────────────────────────

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS heady_migrations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    UNIQUE NOT NULL,
    applied_at  REAL    NOT NULL DEFAULT (unixepoch('now'))
);

CREATE TABLE IF NOT EXISTS heady_nodes (
    node_id      TEXT PRIMARY KEY,
    node_name    TEXT NOT NULL,
    url          TEXT NOT NULL,
    tunnel_url   TEXT,
    role         TEXT NOT NULL,
    status       TEXT NOT NULL DEFAULT 'registered',
    last_seen    REAL NOT NULL DEFAULT (unixepoch('now')),
    metadata     TEXT DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS heady_telemetry (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          REAL    NOT NULL DEFAULT (unixepoch('now')),
    node_id     TEXT    NOT NULL,
    event       TEXT    NOT NULL,
    payload     TEXT    DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS heady_memories_meta (
    memory_id   TEXT PRIMARY KEY,
    node        TEXT,
    zone        INTEGER,
    importance  REAL,
    created_at  REAL NOT NULL DEFAULT (unixepoch('now')),
    accessed_at REAL NOT NULL DEFAULT (unixepoch('now'))
);

CREATE INDEX IF NOT EXISTS idx_telemetry_ts   ON heady_telemetry(ts);
CREATE INDEX IF NOT EXISTS idx_telemetry_node ON heady_telemetry(node_id);
CREATE INDEX IF NOT EXISTS idx_memories_zone  ON heady_memories_meta(zone);
"""

def init_database(db_path: Path, dry_run: bool = False, quiet: bool = False) -> None:
    if dry_run:
        _record("INFO", "database", f"would init: {db_path}", quiet)
        return
    try:
        db_path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(str(db_path), timeout=10)
        conn.executescript(_SCHEMA_SQL)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.commit()
        conn.close()
        _record("OK", "database", f"SQLite ready at {db_path}", quiet)
    except Exception as e:
        _record("FAIL", "database", f"{db_path}: {e}", quiet)


# ─── 7. Generate default .env ─────────────────────────────────────────────────

_DEFAULT_ENV = """# Heady Zero-Dep Environment Configuration
# Generated by setup.py  —  edit to match your deployment

# ── Environment ────────────────────────────────────────────────────────────
HEADY_ENV=local          # auto | local | colab | cloud
HEADY_DEBUG=false
HEADY_LOG_LEVEL=INFO

# ── Node Identity ──────────────────────────────────────────────────────────
# HEADY_NODE_ID is set automatically by each node script

# ── Node URLs (update after tunnels are established) ───────────────────────
HEADY_NODE1_URL=http://localhost:8001
HEADY_NODE2_URL=http://localhost:8003
HEADY_NODE3_URL=http://localhost:8000

# ── Tunnel tokens (provide ONE) ────────────────────────────────────────────
NGROK_TOKEN=
CLOUDFLARE_TOKEN=
TUNNEL_PROVIDER=auto

# ── LLM Provider Keys (at least one recommended) ───────────────────────────
OPENAI_API_KEY=
ANTHROPIC_API_KEY=
GEMINI_API_KEY=
GROQ_API_KEY=
PERPLEXITY_API_KEY=

# Default provider + model
DEFAULT_LLM_PROVIDER=openai
DEFAULT_LLM_MODEL=gpt-4o-mini

# ── GitHub (optional) ──────────────────────────────────────────────────────
GITHUB_TOKEN=
GITHUB_REPO=

# ── Ports (defaults are fine for local dev) ────────────────────────────────
PORT_CONDUCTOR=8000
PORT_EMBED=8001
PORT_LLM=8002
PORT_MEMORY=8003

# ── Storage ────────────────────────────────────────────────────────────────
HEADY_DATA_DIR=data
HEADY_DB_PATH=data/heady.db

# ── Feature Flags ──────────────────────────────────────────────────────────
FEATURE_GRAPH_RAG=true
FEATURE_MONTE_CARLO=true
FEATURE_3D_MAP=true
FEATURE_DRIFT_DETECT=true
FEATURE_AUTO_MAINTAIN=true
FEATURE_BEE_FACTORY=true
FEATURE_SWARM=true
FEATURE_MCP=true
FEATURE_TELEMETRY=true
FEATURE_CIRCUIT_BREAKER=true
"""

def generate_dotenv(root: Path, force: bool = False, dry_run: bool = False, quiet: bool = False) -> None:
    env_path = root / ".env"
    if env_path.exists() and not force:
        _record("INFO", ".env", f"already exists at {env_path} (use --force to overwrite)", quiet)
        return
    if dry_run:
        _record("INFO", ".env", "would generate .env", quiet)
        return
    try:
        env_path.write_text(_DEFAULT_ENV, encoding="utf-8")
        _record("OK", ".env", f"generated at {env_path}", quiet)
    except OSError as e:
        _record("FAIL", ".env", f"cannot write .env: {e}", quiet)


# ─── 8. Self-test sweep ───────────────────────────────────────────────────────

def run_self_tests(quiet: bool = False) -> None:
    """Run lightweight in-process smoke tests on each Heady subsystem."""
    root = str(Path(__file__).parent)
    if root not in sys.path:
        sys.path.insert(0, root)

    # Test vector_math
    try:
        from ai.vector_math import cosine_similarity, normalize
        v1 = [1.0] + [0.0] * 383
        v2 = [0.0, 1.0] + [0.0] * 382
        sim = cosine_similarity(v1, v2)
        assert abs(sim) < 0.01, f"expected ~0, got {sim}"
        nv = normalize(v1)
        assert abs(sum(x * x for x in nv) ** 0.5 - 1.0) < 1e-6
        _record("OK", "self-test", "vector_math.cosine_similarity + normalize", quiet)
    except Exception as e:
        _record("WARN", "self-test", f"vector_math: {e}", quiet)

    # Test database
    try:
        import tempfile, os
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            tmp = f.name
        conn = sqlite3.connect(tmp)
        conn.execute("CREATE TABLE t (x INTEGER)")
        conn.execute("INSERT INTO t VALUES (42)")
        row = conn.execute("SELECT x FROM t").fetchone()
        assert row[0] == 42
        conn.close()
        os.unlink(tmp)
        _record("OK", "self-test", "SQLite read/write", quiet)
    except Exception as e:
        _record("FAIL", "self-test", f"SQLite: {e}", quiet)

    # Test PHI constant from config
    try:
        from config import PHI
        assert abs(PHI ** 2 - PHI - 1) < 1e-10, "φ² ≠ φ+1"
        _record("OK", "self-test", f"φ identity (φ²=φ+1): {PHI:.10f}", quiet)
    except Exception as e:
        _record("WARN", "self-test", f"config φ: {e}", quiet)

    # Test HTTP server instantiation
    try:
        from core.http_server import HTTPServer
        srv = HTTPServer(port=0)  # port 0 = don't bind yet
        assert hasattr(srv, "route")
        _record("OK", "self-test", "HTTPServer instantiation", quiet)
    except Exception as e:
        _record("WARN", "self-test", f"HTTPServer: {e}", quiet)

    # Test cache
    try:
        from core.cache import Cache
        c = Cache(max_size=16)
        c.set("hello", "world", ttl=60)
        assert c.get("hello") == "world"
        _record("OK", "self-test", "Cache set/get", quiet)
    except Exception as e:
        _record("WARN", "self-test", f"Cache: {e}", quiet)

    # Test conductor instantiation
    try:
        from orchestration.conductor import HeadyConductor
        cond = HeadyConductor()
        assert cond is not None
        _record("OK", "self-test", "HeadyConductor instantiation", quiet)
    except Exception as e:
        _record("WARN", "self-test", f"Conductor: {e}", quiet)

    # Test Monte Carlo
    try:
        from ai.monte_carlo import MonteCarloSimulator, Task
        sim = MonteCarloSimulator(n_runs=5, n_workers=1)
        task = Task(name="test", complexity=1.0, uncertainty=0.1)
        result = sim.run(task)
        assert result.mean_time > 0
        _record("OK", "self-test", f"MonteCarloSimulator (5 runs, mean={result.mean_time:.2f})", quiet)
    except Exception as e:
        _record("WARN", "self-test", f"MonteCarlo: {e}", quiet)


# ─── 9. Platform summary ─────────────────────────────────────────────────────

def print_platform_info() -> None:
    print(_c("36", f"\n  Platform    : {platform.system()} {platform.release()} {platform.machine()}"))
    print(_c("36", f"  Python      : {sys.version.split()[0]}"))
    print(_c("36", f"  CWD         : {Path.cwd()}"))
    print(_c("36", f"  Script dir  : {Path(__file__).parent}"))
    try:
        import torch  # type: ignore
        cuda = torch.cuda.is_available()
        print(_c("36", f"  PyTorch     : {torch.__version__}  CUDA={cuda}"))
        if cuda:
            print(_c("36", f"  GPU         : {torch.cuda.get_device_name(0)}"))
    except ImportError:
        print(_c("33", "  PyTorch     : not installed"))


# ─── 10. Readiness report ─────────────────────────────────────────────────────

def print_report() -> int:
    """Print final status and return exit code."""
    total = len(_results)
    ok    = sum(1 for s, _, _ in _results if s == "OK")
    warn  = sum(1 for s, _, _ in _results if s == "WARN")
    fail  = sum(1 for s, _, _ in _results if s == "FAIL")

    print("\n" + "─" * 55)
    if fail == 0 and warn == 0:
        print(_c("32", f"  ✓  System READY  —  {ok}/{total} checks passed"))
        code = 0
    elif fail == 0:
        print(_c("33", f"  ⚠  System DEGRADED  —  {ok} OK, {warn} warnings, {fail} failures"))
        code = 1
    else:
        print(_c("31", f"  ✗  System NOT READY  —  {ok} OK, {warn} warnings, {fail} failures"))
        code = 2

    print("─" * 55)

    if fail > 0:
        print(_c("31", "\n  Critical failures:"))
        for s, cat, msg in _results:
            if s == "FAIL":
                print(f"    {FAIL} [{cat}] {msg}")

    if warn > 0:
        print(_c("33", "\n  Warnings:"))
        for s, cat, msg in _results:
            if s == "WARN":
                print(f"    {WARN} [{cat}] {msg}")

    print()
    return code


# ─── CLI entry point ─────────────────────────────────────────────────────────

def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Heady Zero-Dep system bootstrap",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="Exit codes: 0=ready  1=degraded  2=not-ready",
    )
    parser.add_argument("--check",  action="store_true", help="Check only; do not create files")
    parser.add_argument("--quiet",  action="store_true", help="Suppress per-check output")
    parser.add_argument("--force",  action="store_true", help="Overwrite existing .env")
    parser.add_argument("--no-self-test", action="store_true", help="Skip self-test sweep")
    args = parser.parse_args(argv)

    dry_run = args.check
    quiet   = args.quiet

    print(_c("35", """
╔══════════════════════════════════════════════════════╗
║          HEADY ZERO-DEP BOOTSTRAP (setup.py)         ║
╚══════════════════════════════════════════════════════╝"""))

    print_platform_info()
    print("\n" + _c("35", "─── Runtime checks ──────────────────────────────────") + "\n")

    root = Path(__file__).parent

    check_python_version(quiet)
    check_stdlib(quiet)
    check_torch(quiet)
    check_sentence_transformers(quiet)
    check_heady_modules(quiet)

    print("\n" + _c("35", "─── File system ─────────────────────────────────────") + "\n")
    ensure_directories(root, dry_run=dry_run, quiet=quiet)

    print("\n" + _c("35", "─── Database ────────────────────────────────────────") + "\n")
    db_path = root / "data" / "heady.db"
    init_database(db_path, dry_run=dry_run, quiet=quiet)

    print("\n" + _c("35", "─── Environment ─────────────────────────────────────") + "\n")
    generate_dotenv(root, force=args.force, dry_run=dry_run, quiet=quiet)

    if not args.no_self_test:
        print("\n" + _c("35", "─── Self-tests ──────────────────────────────────────") + "\n")
        run_self_tests(quiet)

    return print_report()


if __name__ == "__main__":
    sys.exit(main())
