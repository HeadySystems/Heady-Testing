# Heady Zero-Dep

**A fully distributed AI orchestration system running on zero external dependencies — only Python stdlib + `torch` + `sentence-transformers`.**

---

## Architecture

```
                         ┌─────────────────────────────────┐
                         │  INTERNET / MCP CLIENT          │
                         └─────────────┬───────────────────┘
                                       │ HTTPS tunnel
                         ┌─────────────▼───────────────────┐
                         │  NODE 3 — CONDUCTOR             │
                         │  Colab Pro+  ·  port 8000        │
                         │                                  │
                         │  ┌──────────────┐               │
                         │  │  API Gateway │ proxy + CB     │
                         │  ├──────────────┤               │
                         │  │  Conductor   │ routing + arena│
                         │  ├──────────────┤               │
                         │  │  Pipeline    │ 12 stages      │
                         │  ├──────────────┤               │
                         │  │  MCP Server  │ JSON-RPC + SSE │
                         │  ├──────────────┤               │
                         │  │  Bee Factory │ 24 domains     │
                         │  ├──────────────┤               │
                         │  │  Swarm       │ consensus      │
                         │  └──────────────┘               │
                         └──────┬───────────────┬──────────┘
                                │               │
              ┌─────────────────▼──┐    ┌───────▼───────────────────┐
              │  NODE 1 — BRAIN    │    │  NODE 2 — MEMORY           │
              │  Colab Pro+  GPU   │    │  Colab Pro+  CPU/RAM       │
              │  ports 8001/8002   │    │  port 8003                 │
              │                    │    │                             │
              │ ┌────────────────┐ │    │ ┌───────────────────────┐  │
              │ │Embedding Server│ │    │ │  Vector Memory (3D)   │  │
              │ │sentence-transf.│ │    │ │  384-dim · 5 shards   │  │
              │ │GPU-accelerated │ │    │ │  STM + LTM · 8 zones  │  │
              │ ├────────────────┤ │    │ ├───────────────────────┤  │
              │ │  LLM Gateway   │ │    │ │  Graph RAG Layer      │  │
              │ │  OpenAI/Claude │ │    │ │  entity edges + hops  │  │
              │ │  Gemini/Groq   │ │    │ ├───────────────────────┤  │
              │ │  Perplexity    │ │    │ │  SQLite (WAL mode)    │  │
              │ │  Ollama (local)│ │    │ │  persisted to Drive   │  │
              │ ├────────────────┤ │    │ ├───────────────────────┤  │
              │ │  Monte Carlo   │ │    │ │  Cache System         │  │
              │ │  φ-paced sims  │ │    │ ├───────────────────────┤  │
              │ └────────────────┘ │    │ │  Agent Lifecycle Mgr  │  │
              └────────────────────┘    │ │  3D spatial agents    │  │
                                        │ ├───────────────────────┤  │
                                        │ │  Drift Detector       │  │
                                        │ │  Coherence Monitor    │  │
                                        │ │  Auto-Maintenance     │  │
                                        │ └───────────────────────┘  │
                                        └────────────────────────────┘

All timing constants derived from φ = 1.6180339887…
  φ^4 ≈  6.85s — health-check tick
  φ^6 ≈ 17.94s — persist interval
  φ^7 ≈ 29.03s — maintenance cycle
  φ^8 ≈ 47 MC runs per simulation
```

---

## Quick Start — 3 Colab Pro+ Tabs

### Prerequisites
1. Three Colab Pro+ notebooks open simultaneously  
2. A Google Drive account (for persistent storage)  
3. At least one of: `NGROK_TOKEN` or `CLOUDFLARE_TOKEN` (for public URLs)  
4. At least one LLM API key (optional but recommended)

### Step 1 — Start Node 3 (Conductor) first

In Colab Tab #3, run:
```python
# Colab cell — paste entire colab_node3_conductor.py content here
# Or upload to Drive and run:
exec(open('/content/drive/MyDrive/heady-zero-dep/colab_node3_conductor.py').read())
```

Wait for the output:
```
✓  API Gateway ready on port 8000
  conductor (8000) → https://xxxx.trycloudflare.com
```

**Copy the public tunnel URL** — this is your main entry point.

### Step 2 — Start Node 1 (Brain)

In Colab Tab #1, set environment variables, then run:
```python
import os
os.environ['HEADY_NODE3_URL'] = 'https://xxxx.trycloudflare.com'  # from Step 1
os.environ['NGROK_TOKEN']     = 'your_ngrok_token'                 # or CLOUDFLARE_TOKEN
os.environ['OPENAI_API_KEY']  = 'sk-...'                           # optional

exec(open('/content/drive/MyDrive/heady-zero-dep/colab_node1_brain.py').read())
```

### Step 3 — Start Node 2 (Memory)

In Colab Tab #2:
```python
import os
os.environ['HEADY_NODE3_URL'] = 'https://xxxx.trycloudflare.com'  # same as Step 1
os.environ['NGROK_TOKEN']     = 'your_ngrok_token'

exec(open('/content/drive/MyDrive/heady-zero-dep/colab_node2_memory.py').read())
```

### Step 4 — Verify cluster health

```bash
curl https://xxxx.trycloudflare.com/api/health
# → {"ok": true, "nodes": {"node1_brain": {...}, "node2_memory": {...}}}
```

Visit `https://xxxx.trycloudflare.com/` for the live dashboard.

---

## Local Development Setup (Ryzen 9 / 32 GB)

### One-command startup
```bash
cd heady-zero-dep
python setup.py                # bootstrap + validate
python local_runner.py         # start all 3 nodes
```

### Custom node selection
```bash
python local_runner.py --nodes 1,3      # brain + conductor (no memory)
python local_runner.py --dev            # verbose logging, no tunnels
python local_runner.py --health-only    # check running nodes
```

### Environment variables
Copy `.env.example` to `.env` and fill in your keys:
```bash
cp .env .env.local   # backup defaults
# Edit .env with your API keys
```

Key variables:
```env
NGROK_TOKEN=            # or CLOUDFLARE_TOKEN
OPENAI_API_KEY=         # at least one LLM key recommended
HEADY_NODE3_URL=        # auto-set by local_runner.py
```

---

## API Reference

All endpoints are available through the **Conductor** (Node 3) on port `8000`.
In local mode: `http://localhost:8000/`. In Colab mode: the tunnel URL.

### Embedding (→ Node 1, port 8001)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/embed` | Embed texts via GPU-accelerated sentence-transformers |
| `POST` | `/api/embed/batch` | Batch embedding (multiple text arrays) |
| `GET`  | `/embed/health` | Embedding server health + model info |

**POST `/api/embed`**
```json
{ "texts": "single string" }
// or
{ "texts": ["str1", "str2"] }
```
Response:
```json
{ "ok": true, "embeddings": [[...384 floats...]], "count": 2, "dim": 384, "device": "cuda" }
```

### LLM Gateway (→ Node 1, port 8002)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/llm/complete` | LLM completion (multi-provider) |
| `GET`  | `/api/llm/health`   | Provider circuit-breaker status |

**POST `/api/llm/complete`**
```json
{
  "messages":    [{"role": "user", "content": "Hello"}],
  "model":       "gpt-4o-mini",
  "provider":    "openai",
  "max_tokens":  2048,
  "temperature": 0.7
}
```

### Monte Carlo (→ Node 1, port 8004)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/mc/simulate` | Run Monte Carlo task simulation |
| `GET`  | `/api/mc/health`   | Engine status |

**POST `/api/mc/simulate`**
```json
{ "name": "deploy task", "complexity": 2.5, "uncertainty": 0.3, "runs": 46 }
```
Response:
```json
{ "ok": true, "mean_time": 4.23, "std_dev": 0.87, "p50": 4.1, "p95": 5.9, "confidence": 0.94 }
```

### Vector Memory (→ Node 2, port 8003)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/vector/store`           | Store a memory with embedding |
| `POST` | `/api/vector/query`           | Similarity search |
| `GET`  | `/api/vector/stats`           | Memory statistics |
| `GET`  | `/api/vector/3d/map`          | 3D spatial position of all memories |
| `GET`  | `/api/vector/3d/topology`     | Zone occupancy and topology |
| `POST` | `/api/vector/graph/query`     | Graph RAG multi-hop query |
| `POST` | `/api/vector/graph/edge`      | Add relationship edge |
| `GET`  | `/api/vector/drift/check`     | Semantic drift report |
| `POST` | `/api/vector/drift/snapshot`  | Force drift snapshot |
| `GET`  | `/api/vector/coherence/check` | Zone coherence report |
| `GET`  | `/api/vector/health`          | Memory node health |
| `POST` | `/api/vector/autonomy/run`    | Trigger maintenance cycle |

**POST `/api/vector/store`**
```json
{
  "content":    "The deployment succeeded",
  "embedding":  [/* optional: 384 floats */],
  "metadata":   {"source": "ci", "tag": "deploy"},
  "importance": 0.8
}
```

**POST `/api/vector/query`**
```json
{
  "embedding": [/* 384 floats */],
  "query":     "deployment status",
  "top_k":     10,
  "threshold": 0.5
}
```

### Agent Management (→ Node 2, port 8003)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/agents/spawn`   | Spawn an agent at a 3D position |
| `GET`  | `/api/agents/observe` | List all active agents |

**POST `/api/agents/spawn`**
```json
{
  "agent_id":  "agent-001",
  "type":      "research",
  "position":  [0.5, -0.3, 0.8],
  "metadata":  {"task": "summarize docs"}
}
```

### Conductor / Orchestration (local)

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/conductor/register` | Register a node (called by Node 1+2) |
| `GET`  | `/api/conductor/status`   | Conductor stats |
| `POST` | `/api/pipeline/run`       | Run the 12-stage pipeline |
| `GET`  | `/api/pipeline/status`    | Pipeline readiness |
| `POST` | `/api/mcp/rpc`            | MCP JSON-RPC call |
| `GET`  | `/api/mcp/tools`          | List registered MCP tools |
| `POST` | `/api/bees/spawn`         | Spawn a Bee worker |
| `GET`  | `/api/bees/list`          | List all Bees |
| `POST` | `/api/swarm/submit`       | Submit a task to the Swarm |
| `GET`  | `/api/swarm/status`       | Swarm consensus state |
| `GET`  | `/api/health`             | Aggregate health (all 3 nodes) |
| `GET`  | `/api/system/status`      | Full system status JSON |
| `GET`  | `/`                       | HTML dashboard (auto-refreshes every 10s) |

---

## Configuration Guide

All configuration is read from environment variables (or a `.env` file in the repo root).
The `config.py` module exports every constant as both a module-level name and on the `cfg` singleton.

### Essential variables

| Variable | Default | Description |
|----------|---------|-------------|
| `NGROK_TOKEN` | _(empty)_ | ngrok authentication token |
| `CLOUDFLARE_TOKEN` | _(empty)_ | cloudflared auth (usually not needed for quick-tunnels) |
| `TUNNEL_PROVIDER` | `auto` | `auto` \| `ngrok` \| `cloudflared` \| `none` |
| `OPENAI_API_KEY` | _(empty)_ | OpenAI key for LLM gateway |
| `ANTHROPIC_API_KEY` | _(empty)_ | Anthropic key |
| `GEMINI_API_KEY` | _(empty)_ | Google Gemini key |
| `GROQ_API_KEY` | _(empty)_ | Groq key |

### Port configuration

| Variable | Default | Service |
|----------|---------|---------|
| `PORT_CONDUCTOR` | `8000` | Node 3 — API Gateway |
| `PORT_EMBED`     | `8001` | Node 1 — Embedding Server |
| `PORT_LLM`       | `8002` | Node 1 — LLM Gateway |
| `PORT_MEMORY`    | `8003` | Node 2 — Vector Memory |
| `PORT_MC`        | `8004` | Node 1 — Monte Carlo |

### Node URL overrides (Colab multi-tab setup)

```env
HEADY_NODE1_URL=https://your-node1-tunnel.ngrok.io
HEADY_NODE2_URL=https://your-node2-tunnel.trycloudflare.com
HEADY_NODE3_URL=https://your-node3-tunnel.ngrok.io
```

### φ-derived timing constants

| Constant | Value (s) | Used for |
|----------|-----------|---------|
| `φ^4` | 6.854 | Health check interval |
| `φ^6` | 17.944 | Persist / save interval |
| `φ^7` | 29.034 | Maintenance cycle |
| `φ^8` | 46.979 | Monte Carlo default run count |
| `φ^10` | 122.992 | Circuit-breaker max cooldown |

### Feature flags

```env
FEATURE_GRAPH_RAG=true        # Graph RAG layer on Node 2
FEATURE_MONTE_CARLO=true      # Monte Carlo engine on Node 1
FEATURE_3D_MAP=true           # 3D spatial memory features
FEATURE_DRIFT_DETECT=true     # Semantic drift detection
FEATURE_AUTO_MAINTAIN=true    # Background maintenance loop
FEATURE_BEE_FACTORY=true      # Bee agent workers on Node 3
FEATURE_SWARM=true            # Swarm consensus on Node 3
FEATURE_MCP=true              # MCP protocol server on Node 3
FEATURE_TELEMETRY=true        # Internal telemetry
FEATURE_CIRCUIT_BREAKER=true  # Per-node circuit breakers
```

---

## Troubleshooting

### Node 1 fails to start — torch not found
```bash
pip install torch sentence-transformers
```
Node 1 automatically runs `pip install` on startup; if it fails, install manually.

### Tunnel URL not appearing
1. Check `NGROK_TOKEN` is set correctly in `.env`
2. Try `TUNNEL_PROVIDER=cloudflared` (no token needed for quick-tunnels)
3. In local mode, `TUNNEL_PROVIDER=none` and use `http://localhost:PORT`

### Conductor cannot reach Node 1 or Node 2
1. Run Node 1 and Node 2 first
2. After their tunnels appear, set `HEADY_NODE1_URL` and `HEADY_NODE2_URL` in Node 3's environment before starting it
3. Alternatively, Nodes 1 and 2 will self-register with Node 3 via `/api/conductor/register` when they start

### Health check shows `circuit=open`
The circuit breaker trips after 3 consecutive failures per node.  It resets automatically after `φ^4` seconds (exponential backoff up to `φ^10 ≈ 123s`).  Check the target node's logs.

### SQLite "database is locked"
Colab sessions share the same Drive file.  Run only one Memory node per Drive directory, or set different `HEADY_DATA_DIR` paths per node.

### Colab disconnects and loses state
State is automatically persisted to Drive every `φ^6 ≈ 18s` and on `SIGTERM`.  On reconnect, `VectorMemory` reloads from the persisted shard files in `HEADY_DATA_DIR/vectors/`.

### Running `setup.py` reports failures
```bash
python setup.py          # full report
python setup.py --check  # read-only check, no file writes
```
Critical failures (exit code 2) block the system.  Warnings (exit code 1) allow degraded operation.

---

## Zero-Dependency Philosophy

**Why no FastAPI, Redis, PostgreSQL, numpy, or aiohttp?**

Heady is designed to run anywhere Python 3.10+ exists — inside a Colab notebook, on a Raspberry Pi, in a minimal Docker container, or air-gapped.  Every "production" dependency adds:

- A separate installation step that can fail
- Version conflicts across Python environments
- Additional security surface area
- Friction for contributors

The two allowed third-party packages (`torch` and `sentence-transformers`) are unavoidable for GPU-accelerated embedding — they are already pre-installed in every Colab Pro+ runtime.  Everything else is reimplemented on top of the Python standard library:

| Replaced by | Built as |
|-------------|----------|
| FastAPI / Flask | `core/http_server.py` — async HTTP/1.1 + WebSocket |
| httpx / requests | `core/http_client.py` — raw urllib/asyncio |
| Redis | `core/cache.py` — TTL LRU in-memory + disk |
| PostgreSQL / Neon | `core/database.py` — SQLite with connection pool + migrations |
| python-dotenv | `core/env_loader.py` — full .env parser |
| pm2 / supervisor | `core/process_manager.py` — process lifecycle + file-watch |
| numpy | `ai/vector_math.py` — pure-Python 384-dim vector ops |
| Pinecone / Weaviate | `ai/vector_memory.py` — 3D sharded vector store |
| @modelcontextprotocol/sdk | `orchestration/mcp_protocol.py` — JSON-RPC 2.0 + SSE |

The result is a system whose entire dependency tree can be audited in a single `grep` and deployed with `git clone`.

---

## Module Reference

```
heady-zero-dep/
├── config.py              ← master configuration (all φ-derived constants)
├── setup.py               ← bootstrap + self-test runner
├── local_runner.py        ← single-machine 3-node launcher
├── colab_node1_brain.py   ← Node 1: Embedding + LLM + Monte Carlo
├── colab_node2_memory.py  ← Node 2: VectorMemory + GraphRAG + SQLite
├── colab_node3_conductor.py ← Node 3: API Gateway + Orchestration
│
├── core/
│   ├── http_server.py     ← async HTTP/1.1 + WebSocket (no deps)
│   ├── http_client.py     ← async HTTP client (no deps)
│   ├── cache.py           ← TTL LRU cache + disk persistence
│   ├── database.py        ← SQLite pool + migrations + query builder
│   ├── env_loader.py      ← .env parser (replaces python-dotenv)
│   ├── process_manager.py ← subprocess lifecycle + file watcher
│   └── telemetry.py       ← metrics + event tracing
│
├── ai/
│   ├── vector_math.py     ← pure-Python 384-dim vector ops (replaces numpy)
│   ├── vector_memory.py   ← 3D spatial memory: STM/LTM/shards/graph/drift
│   ├── embedding_server.py ← GPU embedding via sentence-transformers
│   ├── llm_gateway.py     ← multi-provider LLM (OpenAI/Anthropic/Gemini/Groq)
│   ├── monte_carlo.py     ← fractal task simulation + battle arena
│   └── semantic_logic.py  ← resonance gates + drift scores
│
└── orchestration/
    ├── conductor.py       ← HeadyConductor: routing + arena + priority pools
    ├── pipeline.py        ← HCFullPipeline: 12-stage async pipeline
    ├── mcp_protocol.py    ← MCP server: JSON-RPC 2.0 + SSE transport
    ├── github_client.py   ← GitHub API client (no SDK)
    ├── bee_factory.py     ← 24-domain agent worker factory
    ├── resilience.py      ← circuit breakers + retry policies
    └── swarm.py           ← SwarmCoordinator: consensus + task distribution
```

---

## License

MIT — see LICENSE file.  
Built for the Heady project. Zero external dependencies (except torch + sentence-transformers for GPU embedding).
