"""
local_runner.py
===============
Heady Single-Machine Runner (Ryzen 9  /  32 GB  /  Local Dev)

Spawns all three Heady nodes as separate OS processes on localhost,
wires them together via environment variables, aggregates their logs,
monitors their health, and provides a clean Ctrl-C shutdown.

Usage::

    python local_runner.py                 # full 3-node cluster
    python local_runner.py --nodes 1,3     # only Node 1 + Conductor
    python local_runner.py --no-tunnel     # disable tunnel setup
    python local_runner.py --dev           # verbose logging + no tunnel

The three nodes use these default ports:
    Node 1  BRAIN      — embed:8001  llm:8002  mc:8004
    Node 2  MEMORY     — memory:8003
    Node 3  CONDUCTOR  — gateway:8000

All inter-node URLs point to localhost so no tunnel is needed locally.
Logs from each node are tagged and printed to stdout in real time.

Requirements:
    Python 3.10+   (stdlib only, plus torch / sentence-transformers for Node 1)
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import deque
from pathlib import Path
from typing import Dict, List, Optional

PHI: float = 1.6180339887498948482
PHI4: float = PHI ** 4   # ≈ 6.85 s — health poll interval

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] runner: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("local_runner")

_ROOT = Path(__file__).parent

# ─── ANSI colour tags per node ───────────────────────────────────────────────

_COLOURS = {
    "brain":     "\033[33m",   # yellow
    "memory":    "\033[36m",   # cyan
    "conductor": "\033[35m",   # magenta
    "runner":    "\033[32m",   # green
    "reset":     "\033[0m",
}

_USE_COLOUR = sys.stdout.isatty() or os.getenv("FORCE_COLOR") == "1"


def _coloured(role: str, text: str) -> str:
    if not _USE_COLOUR:
        return f"[{role.upper():>10}] {text}"
    colour = _COLOURS.get(role, "")
    reset  = _COLOURS["reset"]
    return f"{colour}[{role.upper():>10}]{reset} {text}"


# ─── Node definitions ─────────────────────────────────────────────────────────

_NODE_DEFINITIONS = {
    "1": {
        "id":     "node1",
        "role":   "brain",
        "script": "colab_node1_brain.py",
        "ports":  {"embed": 8001, "llm": 8002, "mc": 8004},
        "health": "http://localhost:8001/health",
        "env": {
            "HEADY_NODE_ID":    "node1_brain",
            "HEADY_NODE_ROLE":  "brain",
            "HEADY_ENV":        "local",
            "PORT_EMBED":       "8001",
            "PORT_LLM":         "8002",
            "PORT_MC":          "8004",
            "HEADY_NODE1_URL":  "http://localhost:8001",
            "TUNNEL_PROVIDER":  "none",
        },
    },
    "2": {
        "id":     "node2",
        "role":   "memory",
        "script": "colab_node2_memory.py",
        "ports":  {"memory": 8003},
        "health": "http://localhost:8003/api/vector/health",
        "env": {
            "HEADY_NODE_ID":    "node2_memory",
            "HEADY_NODE_ROLE":  "memory",
            "HEADY_ENV":        "local",
            "PORT_MEMORY":      "8003",
            "HEADY_NODE2_URL":  "http://localhost:8003",
            "TUNNEL_PROVIDER":  "none",
        },
    },
    "3": {
        "id":     "node3",
        "role":   "conductor",
        "script": "colab_node3_conductor.py",
        "ports":  {"conductor": 8000},
        "health": "http://localhost:8000/api/health",
        "env": {
            "HEADY_NODE_ID":    "node3_conductor",
            "HEADY_NODE_ROLE":  "conductor",
            "HEADY_ENV":        "local",
            "PORT_CONDUCTOR":   "8000",
            "HEADY_NODE1_URL":  "http://localhost:8001",
            "HEADY_NODE2_URL":  "http://localhost:8003",
            "HEADY_NODE3_URL":  "http://localhost:8000",
            "TUNNEL_PROVIDER":  "none",
        },
    },
}


# ─── Managed process wrapper ──────────────────────────────────────────────────

class ManagedNode:
    """
    Wraps a single Heady node subprocess.

    Features:
    - Start / stop / restart
    - Stdout/stderr streaming to parent stdout with coloured prefix
    - Health probe via HTTP
    - Auto-restart on crash (with φ-based backoff, up to 5 attempts)
    """

    MAX_RESTARTS   = 5
    BACKOFF_BASE   = PHI4   # ≈ 6.85 s

    def __init__(self, node_key: str, node_def: dict, extra_env: Dict[str, str]) -> None:
        self.key      = node_key
        self.role     = node_def["role"]
        self.script   = _ROOT / node_def["script"]
        self.health   = node_def["health"]
        self.ports    = node_def["ports"]
        self.node_env = {**node_def["env"], **extra_env}

        self._process: Optional[subprocess.Popen] = None
        self._log_thread: Optional[threading.Thread] = None
        self._restarts   = 0
        self._started_at = 0.0
        self._healthy    = False
        self._lock       = threading.Lock()

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> None:
        env = {**os.environ, **self.node_env}
        cmd = [sys.executable, str(self.script)]

        self._process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
            text=True,
            bufsize=1,
            cwd=str(_ROOT),
        )
        self._started_at = time.time()
        self._log_thread = threading.Thread(
            target=self._stream_logs,
            daemon=True,
            name=f"log-{self.role}",
        )
        self._log_thread.start()
        log.info(_coloured(self.role, f"Started (PID {self._process.pid})"))

    def stop(self, timeout: float = 8.0) -> None:
        if self._process is None:
            return
        log.info(_coloured(self.role, "Sending SIGTERM …"))
        try:
            self._process.terminate()
            self._process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            log.warning(_coloured(self.role, "SIGTERM timeout — sending SIGKILL"))
            self._process.kill()
            self._process.wait(timeout=5)
        except Exception as e:
            log.warning(_coloured(self.role, f"Stop error: {e}"))
        finally:
            self._process = None
            self._healthy = False

    def is_alive(self) -> bool:
        if self._process is None:
            return False
        return self._process.poll() is None

    def wait(self) -> int:
        if self._process:
            return self._process.wait()
        return -1

    # ── log streaming ─────────────────────────────────────────────────────────

    def _stream_logs(self) -> None:
        if self._process is None or self._process.stdout is None:
            return
        try:
            for line in self._process.stdout:
                print(_coloured(self.role, line.rstrip()), flush=True)
        except Exception:
            pass

    # ── health probe ──────────────────────────────────────────────────────────

    def probe_health(self, timeout: float = 4.0) -> bool:
        try:
            with urllib.request.urlopen(self.health, timeout=timeout) as resp:
                data = json.loads(resp.read())
                self._healthy = data.get("ok", data.get("status") == "ok")
        except Exception:
            self._healthy = False
        return self._healthy

    @property
    def healthy(self) -> bool:
        return self._healthy

    # ── restart logic ─────────────────────────────────────────────────────────

    def maybe_restart(self) -> bool:
        """If the process is dead, restart with φ-backoff. Returns True if restarted."""
        if self.is_alive():
            return False
        if self._restarts >= self.MAX_RESTARTS:
            log.error(_coloured(self.role, f"Max restarts ({self.MAX_RESTARTS}) reached — giving up"))
            return False

        backoff = self.BACKOFF_BASE * (PHI ** self._restarts)
        log.warning(
            _coloured(self.role, f"Process died — restart #{self._restarts + 1} in {backoff:.1f}s")
        )
        time.sleep(backoff)
        self._restarts += 1
        self.start()
        return True


# ─── Runner ───────────────────────────────────────────────────────────────────

class LocalRunner:
    """
    Orchestrates all three Heady nodes on a single machine.
    """

    STARTUP_DELAY: Dict[str, float] = {
        "1": 0.0,    # Brain starts first (GPU model load takes longest)
        "2": 3.0,    # Memory starts 3s later
        "3": 8.0,    # Conductor starts after Brain+Memory are initialising
    }

    def __init__(
        self,
        nodes: List[str],
        extra_env: Dict[str, str],
        health_interval: float = PHI4,
    ) -> None:
        self.node_keys  = nodes
        self.extra_env  = extra_env
        self.interval   = health_interval
        self._managed: Dict[str, ManagedNode] = {}
        self._shutdown  = threading.Event()
        self._log_buf: deque = deque(maxlen=200)   # rolling log for status display

    # ── startup ───────────────────────────────────────────────────────────────

    def start(self) -> None:
        _print_runner_banner(self.node_keys)

        # Run setup bootstrap
        setup_script = _ROOT / "setup.py"
        if setup_script.exists():
            print(_coloured("runner", "Running setup.py …"))
            r = subprocess.run(
                [sys.executable, str(setup_script), "--quiet", "--no-self-test"],
                cwd=str(_ROOT),
            )
            if r.returncode == 2:
                print(_coloured("runner", "⚠  setup.py reported critical failures — check your env"))
        else:
            # Ensure data directories exist
            for d in ["data", "data/vectors", "data/cache", "data/logs"]:
                (_ROOT / d).mkdir(parents=True, exist_ok=True)

        # Build managed nodes in startup order
        for key in self.node_keys:
            node_def = _NODE_DEFINITIONS[key]
            self._managed[key] = ManagedNode(key, node_def, self.extra_env)

        # Staggered start
        start_time = time.time()
        for key, node in self._managed.items():
            delay = self.STARTUP_DELAY.get(key, 0.0)
            elapsed = time.time() - start_time
            if delay > elapsed:
                time.sleep(delay - elapsed)
            print(_coloured(node.role, f"Starting {node.script.name} …"))
            node.start()

    # ── main loop ─────────────────────────────────────────────────────────────

    def run(self) -> int:
        self.start()

        # Register signal handlers
        def _sig_handler(*_):
            print(_coloured("runner", "Shutdown signal received …"))
            self._shutdown.set()

        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                signal.signal(sig, _sig_handler)
            except (OSError, ValueError):
                pass

        # Wait for conductor to start, then print access info
        print(_coloured("runner", "Waiting for Conductor (Node 3) to bind …"))
        self._wait_for_node("3", timeout=120)

        self._print_access_info()

        # Health monitoring loop
        print(_coloured("runner", f"Monitoring all nodes (interval={self.interval:.1f}s)"))
        try:
            while not self._shutdown.is_set():
                self._health_tick()
                self._shutdown.wait(timeout=self.interval)
        except KeyboardInterrupt:
            pass

        return self.shutdown()

    def _health_tick(self) -> None:
        """Probe all nodes, restart dead ones, print status line."""
        statuses = []
        for key in self.node_keys:
            node = self._managed.get(key)
            if node is None:
                continue
            if not node.is_alive():
                node.maybe_restart()
            alive = node.is_alive()
            if alive:
                healthy = node.probe_health()
                symbol  = "✓" if healthy else "?"
            else:
                symbol  = "✗"
            statuses.append(f"{node.role}={symbol}")

        line = "  ".join(statuses) + f"  t={time.strftime('%H:%M:%S')}"
        print(_coloured("runner", line), flush=True)

    def _wait_for_node(self, key: str, timeout: float = 60.0) -> bool:
        node = self._managed.get(key)
        if node is None:
            return False
        deadline = time.time() + timeout
        while time.time() < deadline:
            if node.probe_health():
                return True
            time.sleep(2.0)
        return False

    def _print_access_info(self) -> None:
        port = int(_NODE_DEFINITIONS["3"]["env"].get("PORT_CONDUCTOR", "8000"))
        base = f"http://localhost:{port}"
        print("\n" + "═" * 60)
        print(_coloured("runner", "HEADY LOCAL CLUSTER READY"))
        print("═" * 60)
        print(f"  Dashboard        : {base}/")
        print(f"  Aggregate health : {base}/api/health")
        print(f"  System status    : {base}/api/system/status")
        print(f"  Embed            : POST {base}/api/embed")
        print(f"  LLM complete     : POST {base}/api/llm/complete")
        print(f"  Vector query     : POST {base}/api/vector/query")
        print(f"  Monte Carlo      : POST {base}/api/mc/simulate")
        print("═" * 60 + "\n")

    # ── shutdown ──────────────────────────────────────────────────────────────

    def shutdown(self) -> int:
        print(_coloured("runner", "Shutting down all nodes (LIFO order) …"))
        # Stop in reverse startup order (LIFO)
        for key in reversed(self.node_keys):
            node = self._managed.get(key)
            if node:
                node.stop()
                print(_coloured(node.role, "Stopped"))
        print(_coloured("runner", "All nodes stopped. Bye."))
        return 0


# ─── ASCII banner ─────────────────────────────────────────────────────────────

def _print_runner_banner(node_keys: List[str]) -> None:
    nodes_str = "  ".join(f"Node {k}" for k in node_keys)
    print("""
╔══════════════════════════════════════════════════════════════╗
║          HEADY LOCAL RUNNER  ·  Single-Machine Mode          ║
╚══════════════════════════════════════════════════════════════╝""")
    print(f"  Nodes    : {nodes_str}")
    print(f"  Python   : {sys.version.split()[0]}")
    print(f"  Root     : {_ROOT}")
    print(f"  φ^4 tick : {PHI4:.3f}s\n")


# ─── Environment helpers ──────────────────────────────────────────────────────

def _load_env_file(path: Path) -> Dict[str, str]:
    """Parse a .env file into a dict (no interpolation needed here)."""
    env: Dict[str, str] = {}
    if not path.exists():
        return env
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key = key.strip().lstrip("export").strip()
        val = val.strip().strip('"').strip("'")
        env[key] = val
    return env


# ─── CLI ──────────────────────────────────────────────────────────────────────

def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Heady local cluster runner (all 3 nodes on one machine)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python local_runner.py                 # start all 3 nodes
  python local_runner.py --nodes 1,3     # brain + conductor only
  python local_runner.py --dev           # verbose + no tunnel
  python local_runner.py --health-only   # health check without starting
""",
    )
    parser.add_argument(
        "--nodes",
        default="1,2,3",
        help="Comma-separated node numbers to start (default: 1,2,3)",
    )
    parser.add_argument(
        "--env-file",
        default=str(_ROOT / ".env"),
        help="Path to .env file (default: ./heady-zero-dep/.env)",
    )
    parser.add_argument(
        "--dev",
        action="store_true",
        help="Developer mode: verbose logging, no tunnels",
    )
    parser.add_argument(
        "--no-tunnel",
        action="store_true",
        help="Disable tunnel setup",
    )
    parser.add_argument(
        "--health-only",
        action="store_true",
        help="Print health status of running nodes and exit",
    )
    parser.add_argument(
        "--health-interval",
        type=float,
        default=PHI4,
        help=f"Health poll interval in seconds (default: φ^4 = {PHI4:.2f})",
    )
    args = parser.parse_args(argv)

    # Parse node list
    node_keys = [k.strip() for k in args.nodes.split(",") if k.strip() in ("1", "2", "3")]
    if not node_keys:
        print("Error: no valid node keys in --nodes (must be subset of 1,2,3)")
        return 2

    # Load .env
    extra_env: Dict[str, str] = _load_env_file(Path(args.env_file))
    if args.dev:
        extra_env["HEADY_DEBUG"]    = "true"
        extra_env["HEADY_LOG_LEVEL"] = "DEBUG"
    if args.no_tunnel or args.dev:
        extra_env["TUNNEL_PROVIDER"] = "none"

    # --health-only: probe running nodes and exit
    if args.health_only:
        print("Probing running nodes …")
        for k in node_keys:
            defn    = _NODE_DEFINITIONS[k]
            health  = defn["health"]
            role    = defn["role"]
            try:
                with urllib.request.urlopen(health, timeout=4) as resp:
                    data = json.loads(resp.read())
                    ok   = data.get("ok", False)
                    print(f"  {'✓' if ok else '✗'}  {role}  {health}")
            except Exception as e:
                print(f"  ✗  {role}  {health} — {e}")
        return 0

    # Full run
    runner = LocalRunner(
        nodes=node_keys,
        extra_env=extra_env,
        health_interval=args.health_interval,
    )
    return runner.run()


if __name__ == "__main__":
    sys.exit(main())
