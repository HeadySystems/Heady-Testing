"""
colab_node3_conductor.py
========================
HEADY CONDUCTOR NODE — Colab Pro+ Notebook #3

This is the primary entry point for the entire Heady cluster.
Run this notebook LAST (after Node 1 and Node 2 are tunnelled).

Services started on this node
──────────────────────────────
  • HeadyConductor        — task routing + arena mode
  • HCFullPipeline        — 12-stage async pipeline
  • MCP Protocol Server   — JSON-RPC 2.0 + SSE transport
  • Bee Factory           — 24-domain agent workers
  • Swarm Coordinator     — consensus + task distribution
  • API Gateway (port 8000) — routes all traffic to Nodes 1 & 2
  • Dashboard (GET /)     — HTML system status page
  • Public tunnel         — the main public entry point

API Gateway routing
──────────────────────────────────────────────────
  /api/vector/*     →  Node 2 (Memory, port 8003)
  /api/agents/*     →  Node 2 (Memory, port 8003)
  /api/embed/*      →  Node 1 (Brain,  port 8001)
  /api/llm/*        →  Node 1 (Brain,  port 8002)
  /api/mc/*         →  Node 1 (Brain,  port 8004)
  /api/conductor/*  →  local (this node)
  /api/pipeline/*   →  local
  /api/mcp/*        →  local
  /api/bees/*       →  local
  /api/swarm/*      →  local
  /api/health       →  aggregate from all 3 nodes
  /api/system/status → full system status JSON
  GET /             →  HTML dashboard

Circuit breakers, automatic retry, and failover are applied to all
proxied requests.  Node discovery polls /api/conductor/register.
"""

# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 1: Banner & imports ---
# ═══════════════════════════════════════════════════════════════════════════════

from __future__ import annotations

import asyncio
import html
import json
import logging
import math
import os
import signal
import subprocess
import sys
import threading
import time
import atexit
import urllib.error
import urllib.request
import uuid
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

PHI: float = 1.6180339887498948482
PHI4: float = PHI ** 4   # ≈ 6.854 s
PHI6: float = PHI ** 6   # ≈ 17.94 s

NODE_ID: str   = f"conductor-{uuid.uuid4().hex[:8]}"
NODE_ROLE: str = "conductor"
NODE_NAME: str = "HEADY CONDUCTOR NODE — Colab Pro+ #3"

_BANNER = r"""
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║      ██╗  ██╗███████╗ █████╗ ██████╗ ██╗   ██╗                 ║
║      ██║  ██║██╔════╝██╔══██╗██╔══██╗╚██╗ ██╔╝                 ║
║      ███████║█████╗  ███████║██║  ██║ ╚████╔╝                  ║
║      ██╔══██║██╔══╝  ██╔══██║██║  ██║  ╚██╔╝                   ║
║      ██║  ██║███████╗██║  ██║██████╔╝   ██║                     ║
║      ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝    ╚═╝                    ║
║                                                                  ║
║         CONDUCTOR NODE  ·  Colab Pro+  #3  ·  ORCHESTRATION     ║
║         API Gateway  ·  MCP  ·  Bees  ·  Swarm  ·  Pipeline     ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
"""

print(_BANNER)
print(f"  Node ID   : {NODE_ID}")
print(f"  φ^4 tick  : {PHI4:.3f}s\n")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("conductor_node")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 2: Install dependencies ---
# ═══════════════════════════════════════════════════════════════════════════════

def install_deps() -> None:
    print("📦  Installing dependencies …")
    for pkg in ["torch", "sentence-transformers"]:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", pkg, "--quiet"],
            capture_output=True, text=True,
        )
        print(f"    {'✓' if r.returncode == 0 else '⚠'}  {pkg}")
    print()


install_deps()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 3: Mount Google Drive & sync code ---
# ═══════════════════════════════════════════════════════════════════════════════

GDRIVE_MOUNT     = "/content/drive"
GDRIVE_HEADY_DIR = "/content/drive/MyDrive/heady-zero-dep"
LOCAL_HEADY_DIR  = "/content/heady-zero-dep"


def mount_drive() -> bool:
    try:
        from google.colab import drive  # type: ignore
        drive.mount(GDRIVE_MOUNT, force_remount=False)
        print(f"✓  Google Drive mounted at {GDRIVE_MOUNT}")
        return True
    except ImportError:
        print("⚠  google.colab not available — local mode")
        return False
    except Exception as e:
        print(f"⚠  Drive mount: {e}")
        return False


def sync_code_from_drive() -> None:
    drive_src = Path(GDRIVE_HEADY_DIR)
    local_dst = Path(LOCAL_HEADY_DIR)

    if drive_src.exists():
        import shutil
        if local_dst.exists():
            shutil.rmtree(str(local_dst))
        shutil.copytree(str(drive_src), str(local_dst))
        print(f"✓  Code synced from Drive → {local_dst}")
    elif local_dst.exists():
        print(f"✓  Code found at {local_dst}")
    else:
        script_dir = Path(__file__).parent
        if (script_dir / "ai").exists():
            local_dst = script_dir
            print(f"✓  Using script directory: {local_dst}")
        else:
            print("⚠  Code not found — check Drive setup")
            return

    code_root = str(local_dst)
    if code_root not in sys.path:
        sys.path.insert(0, code_root)
    print(f"✓  {code_root} added to sys.path\n")


_drive_mounted = mount_drive()
sync_code_from_drive()

_script_root = str(Path(__file__).parent)
if _script_root not in sys.path:
    sys.path.insert(0, _script_root)


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 4: Load configuration ---
# ═══════════════════════════════════════════════════════════════════════════════

for _ep in [Path(GDRIVE_HEADY_DIR) / ".env", Path(LOCAL_HEADY_DIR) / ".env",
            Path(__file__).parent / ".env"]:
    if _ep.exists():
        try:
            from core.env_loader import load_env
            load_env(str(_ep))
            print(f"✓  Loaded .env from {_ep}")
            break
        except Exception:
            pass

os.environ["HEADY_NODE_ID"]   = NODE_ID
os.environ["HEADY_NODE_ROLE"] = NODE_ROLE
os.environ["HEADY_ENV"]       = "colab"

try:
    from config import (
        PORT_CONDUCTOR, PORT_EMBED, PORT_LLM, PORT_MEMORY, PORT_MC,
        NODE1_URL, NODE2_URL,
        NGROK_TOKEN, CLOUDFLARE_TOKEN, TUNNEL_PROVIDER,
        PHI4 as _PHI4, PHI6 as _PHI6,
        HEALTH_CHECK_INTERVAL, PERSIST_INTERVAL,
        GDRIVE_HEADY_DIR as _GDRIVE,
        FEATURE_GRAPH_RAG, FEATURE_MONTE_CARLO,
        FEATURE_BEE_FACTORY, FEATURE_SWARM, FEATURE_MCP,
    )
    PHI4 = _PHI4
    PHI6 = _PHI6
    print("✓  Config loaded from config.py")
except ImportError:
    print("⚠  config.py not found — using defaults")
    PORT_CONDUCTOR   = int(os.getenv("PORT_CONDUCTOR", "8000"))
    PORT_EMBED       = int(os.getenv("PORT_EMBED",     "8001"))
    PORT_LLM         = int(os.getenv("PORT_LLM",       "8002"))
    PORT_MEMORY      = int(os.getenv("PORT_MEMORY",    "8003"))
    PORT_MC          = int(os.getenv("PORT_MC",        "8004"))
    NODE1_URL        = os.getenv("HEADY_NODE1_URL", f"http://localhost:{PORT_EMBED}")
    NODE2_URL        = os.getenv("HEADY_NODE2_URL", f"http://localhost:{PORT_MEMORY}")
    NGROK_TOKEN      = os.getenv("NGROK_TOKEN", "")
    CLOUDFLARE_TOKEN = os.getenv("CLOUDFLARE_TOKEN", "")
    TUNNEL_PROVIDER  = os.getenv("TUNNEL_PROVIDER", "auto")
    HEALTH_CHECK_INTERVAL = PHI4
    PERSIST_INTERVAL      = PHI6
    _GDRIVE = GDRIVE_HEADY_DIR
    FEATURE_GRAPH_RAG = True
    FEATURE_MONTE_CARLO = True
    FEATURE_BEE_FACTORY = True
    FEATURE_SWARM = True
    FEATURE_MCP = True

print(f"  PORT_CONDUCTOR : {PORT_CONDUCTOR}")
print(f"  NODE1_URL      : {NODE1_URL}")
print(f"  NODE2_URL      : {NODE2_URL}\n")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 5: Node registry + circuit breakers ---
# ═══════════════════════════════════════════════════════════════════════════════

class CircuitState:
    CLOSED    = "closed"
    OPEN      = "open"
    HALF_OPEN = "half_open"


class NodeCircuitBreaker:
    """
    Per-node circuit breaker.
    States: CLOSED → OPEN (after threshold failures) → HALF_OPEN → CLOSED
    """

    def __init__(
        self,
        node_id: str,
        failure_threshold: int = 3,
        cooldown: float = PHI4,
        cooldown_max: float = PHI ** 10,
    ) -> None:
        self.node_id    = node_id
        self.threshold  = failure_threshold
        self.cooldown   = cooldown
        self.cooldown_max = cooldown_max
        self.state      = CircuitState.CLOSED
        self.failures   = 0
        self.opened_at: Optional[float] = None
        self._lock      = threading.Lock()

    def record_success(self) -> None:
        with self._lock:
            self.failures  = 0
            self.state     = CircuitState.CLOSED
            self.opened_at = None

    def record_failure(self) -> None:
        with self._lock:
            self.failures += 1
            if self.failures >= self.threshold:
                self.state     = CircuitState.OPEN
                self.opened_at = time.time()
                log.warning("Circuit OPEN for node %s (failures=%d)", self.node_id, self.failures)

    def is_available(self) -> bool:
        with self._lock:
            if self.state == CircuitState.CLOSED:
                return True
            if self.state == CircuitState.OPEN:
                elapsed = time.time() - (self.opened_at or 0)
                # Exponential backoff with φ, capped at cooldown_max
                required = min(self.cooldown * (PHI ** max(self.failures - self.threshold, 0)),
                               self.cooldown_max)
                if elapsed >= required:
                    self.state = CircuitState.HALF_OPEN
                    return True
                return False
            # HALF_OPEN — allow one probe
            return True


# Node registry — populated by /api/conductor/register POSTs and .env pre-config
_node_registry: Dict[str, Dict[str, Any]] = {
    "node1_brain": {
        "node_id": "node1_brain",
        "role":    "brain",
        "url":     NODE1_URL,
        "status":  "pending",
        "last_seen": 0.0,
        "capabilities": ["embed", "llm", "monte_carlo"],
    },
    "node2_memory": {
        "node_id": "node2_memory",
        "role":    "memory",
        "url":     NODE2_URL,
        "status":  "pending",
        "last_seen": 0.0,
        "capabilities": ["vector_memory", "graph_rag", "sqlite", "cache", "agents"],
    },
}

_circuit_breakers: Dict[str, NodeCircuitBreaker] = {
    "node1_brain":  NodeCircuitBreaker("node1_brain"),
    "node2_memory": NodeCircuitBreaker("node2_memory"),
}

_registry_lock = threading.Lock()

# Derived URL lookups (updated when nodes register their tunnel URLs)
_node1_embed_url:  str = NODE1_URL
_node1_llm_url:    str = NODE1_URL.replace(str(PORT_EMBED), str(PORT_LLM))
_node1_mc_url:     str = NODE1_URL.replace(str(PORT_EMBED), str(PORT_MC))
_node2_memory_url: str = NODE2_URL

_tunnel_urls: Dict[str, str] = {}


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 6: Initialise orchestration subsystems ---
# ═══════════════════════════════════════════════════════════════════════════════

_conductor   = None
_pipeline    = None
_bee_factory = None
_swarm       = None
_mcp_server  = None


def init_orchestration() -> None:
    global _conductor, _pipeline, _bee_factory, _swarm, _mcp_server

    print("⚙️   Initialising orchestration subsystems …")

    # HeadyConductor
    try:
        from orchestration.conductor import HeadyConductor  # type: ignore
        _conductor = HeadyConductor()
        print("  ✓  HeadyConductor")
    except Exception as e:
        log.error("HeadyConductor init: %s", e)
        print(f"  ⚠  HeadyConductor: {e}")

    # HCFullPipeline
    try:
        from orchestration.pipeline import HCFullPipeline  # type: ignore
        _pipeline = HCFullPipeline()
        print("  ✓  HCFullPipeline")
    except Exception as e:
        log.error("HCFullPipeline init: %s", e)
        print(f"  ⚠  HCFullPipeline: {e}")

    # BeeFactory
    if FEATURE_BEE_FACTORY:
        try:
            from orchestration.bee_factory import BeeFactory  # type: ignore
            _bee_factory = BeeFactory()
            print("  ✓  BeeFactory")
        except Exception as e:
            log.error("BeeFactory init: %s", e)
            print(f"  ⚠  BeeFactory: {e}")

    # SwarmCoordinator
    if FEATURE_SWARM:
        try:
            from orchestration.swarm import SwarmCoordinator  # type: ignore
            _swarm = SwarmCoordinator()
            print("  ✓  SwarmCoordinator")
        except Exception as e:
            log.error("SwarmCoordinator init: %s", e)
            print(f"  ⚠  SwarmCoordinator: {e}")

    # MCPServer (initialised without binding; routes added in API server)
    if FEATURE_MCP:
        try:
            from orchestration.mcp_protocol import MCPServer  # type: ignore
            _mcp_server = MCPServer(name="heady-mcp", version="1.0.0")
            print("  ✓  MCPServer")
        except Exception as e:
            log.error("MCPServer init: %s", e)
            print(f"  ⚠  MCPServer: {e}")

    print()


init_orchestration()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 7: Tunnel setup ---
# ═══════════════════════════════════════════════════════════════════════════════

def _start_ngrok_tunnel(port: int, token: str) -> Optional[str]:
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "pyngrok", "--quiet"],
            capture_output=True,
        )
        from pyngrok import ngrok, conf  # type: ignore
        conf.get_default().auth_token = token
        tunnel = ngrok.connect(port, "http")
        url = tunnel.public_url
        return url.replace("http://", "https://", 1) if url.startswith("http://") else url
    except Exception as e:
        log.warning("ngrok failed on port %d: %s", port, e)
        return None


def _start_cloudflared_tunnel(port: int) -> Optional[str]:
    try:
        cf_bin = "/usr/local/bin/cloudflared"
        if not Path(cf_bin).exists():
            subprocess.run([
                "wget", "-q",
                "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
                "-O", cf_bin,
            ], check=True)
            os.chmod(cf_bin, 0o755)
        proc = subprocess.Popen(
            [cf_bin, "tunnel", "--url", f"http://localhost:{port}"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
        )
        deadline = time.time() + 30
        while time.time() < deadline:
            line = proc.stdout.readline()
            if "trycloudflare.com" in line:
                for part in line.split():
                    if "trycloudflare.com" in part:
                        url = part.strip()
                        return url if url.startswith("http") else "https://" + url
        return None
    except Exception as e:
        log.warning("cloudflared failed on port %d: %s", port, e)
        return None


def establish_tunnels() -> Dict[str, str]:
    urls: Dict[str, str] = {}
    provider = TUNNEL_PROVIDER
    if provider == "auto":
        provider = "ngrok" if NGROK_TOKEN else "cloudflared"

    print(f"🌐  Establishing tunnel via {provider} on port {PORT_CONDUCTOR} …")
    url: Optional[str] = None
    if provider == "ngrok" and NGROK_TOKEN:
        url = _start_ngrok_tunnel(PORT_CONDUCTOR, NGROK_TOKEN)
    elif provider == "cloudflared":
        url = _start_cloudflared_tunnel(PORT_CONDUCTOR)

    if url:
        urls["conductor"] = url
        urls[str(PORT_CONDUCTOR)] = url
        print(f"  ✓  conductor ({PORT_CONDUCTOR}) → {url}")
    else:
        local_url = f"http://localhost:{PORT_CONDUCTOR}"
        urls["conductor"] = local_url
        urls[str(PORT_CONDUCTOR)] = local_url
        print(f"  ⚠  conductor — local only: {local_url}")

    return urls


_tunnel_urls = establish_tunnels()
os.environ["HEADY_NODE3_URL"]    = _tunnel_urls.get("conductor", f"http://localhost:{PORT_CONDUCTOR}")
os.environ["HEADY_NODE3_TUNNEL"] = _tunnel_urls.get("conductor", "")
print()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 8: Proxy helper ---
# ═══════════════════════════════════════════════════════════════════════════════

def _proxy_request(
    target_url: str,
    method: str,
    path: str,
    body: bytes,
    headers: Dict[str, str],
    timeout: float = 30.0,
    cb: Optional[NodeCircuitBreaker] = None,
) -> Tuple[int, bytes, Dict[str, str]]:
    """
    Forward an HTTP request to *target_url + path* and return
    (status_code, response_body, response_headers).
    Applies circuit-breaker logic if *cb* is provided.
    """
    if cb is not None and not cb.is_available():
        err = json.dumps({"ok": False, "error": f"Circuit open for {cb.node_id}"}).encode()
        return 503, err, {"Content-Type": "application/json"}

    full_url = target_url.rstrip("/") + "/" + path.lstrip("/")
    req = urllib.request.Request(
        full_url,
        data=body if body else None,
        headers=headers,
        method=method,
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp_body    = resp.read()
            resp_headers = dict(resp.headers)
            status       = resp.status
            if cb:
                cb.record_success()
            return status, resp_body, resp_headers
    except urllib.error.HTTPError as e:
        if cb:
            cb.record_failure()
        return e.code, e.read(), {}
    except Exception as e:
        if cb:
            cb.record_failure()
        err = json.dumps({"ok": False, "error": str(e), "target": full_url}).encode()
        return 502, err, {"Content-Type": "application/json"}


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 9: Dashboard HTML template ---
# ═══════════════════════════════════════════════════════════════════════════════

def _build_dashboard_html(nodes: Dict[str, Dict], system_ok: bool) -> str:
    """Generate a minimal but informative system dashboard page."""
    status_color = "#22c55e" if system_ok else "#ef4444"
    status_text  = "OPERATIONAL" if system_ok else "DEGRADED"

    node_rows = ""
    for nid, info in nodes.items():
        ok     = info.get("status") == "healthy"
        color  = "#22c55e" if ok else "#f59e0b"
        caps   = ", ".join(info.get("capabilities", []))
        seen   = info.get("last_seen", 0)
        ago    = f"{int(time.time() - seen)}s ago" if seen else "never"
        node_rows += f"""
        <tr>
          <td>{html.escape(nid)}</td>
          <td style="color:{color}">{'●' if ok else '○'} {info.get('status','unknown')}</td>
          <td>{html.escape(info.get('url',''))}</td>
          <td>{html.escape(caps)}</td>
          <td>{ago}</td>
        </tr>"""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="refresh" content="10">
<title>Heady System Dashboard</title>
<style>
  body{{font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;margin:0;padding:24px}}
  h1{{color:#818cf8;font-size:1.6rem;margin-bottom:4px}}
  .badge{{display:inline-block;padding:4px 12px;border-radius:9999px;font-weight:600;
         color:#fff;background:{status_color};font-size:.85rem}}
  table{{width:100%;border-collapse:collapse;margin-top:16px}}
  th{{text-align:left;padding:8px 12px;background:#1e293b;color:#94a3b8;font-size:.8rem;
      text-transform:uppercase;letter-spacing:.05em}}
  td{{padding:8px 12px;border-top:1px solid #1e293b;font-size:.9rem}}
  .meta{{color:#64748b;font-size:.8rem;margin-top:8px}}
  a{{color:#818cf8;text-decoration:none}}
  a:hover{{text-decoration:underline}}
  .endpoints{{background:#1e293b;border-radius:8px;padding:16px;margin-top:16px;font-size:.82rem}}
  .endpoints code{{color:#34d399}}
</style>
</head>
<body>
<h1>⬡  Heady System Dashboard</h1>
<span class="badge">{status_text}</span>
<p class="meta">Node: {html.escape(NODE_ID)}  ·  Updated: {time.strftime('%H:%M:%S')}  ·
  Auto-refreshes every 10s</p>

<table>
<thead><tr>
  <th>Node</th><th>Status</th><th>URL</th><th>Capabilities</th><th>Last seen</th>
</tr></thead>
<tbody>{node_rows}</tbody>
</table>

<div class="endpoints">
<strong>API Endpoints</strong><br><br>
<code>POST /api/vector/query</code>  — vector similarity search (→ Node 2)<br>
<code>POST /api/vector/store</code>  — store memory (→ Node 2)<br>
<code>POST /api/llm/complete</code>  — LLM completion (→ Node 1)<br>
<code>POST /api/embed</code>         — embed texts (→ Node 1)<br>
<code>POST /api/mc/simulate</code>   — Monte Carlo (→ Node 1)<br>
<code>GET  /api/conductor/status</code> — conductor info<br>
<code>GET  /api/health</code>        — aggregate health<br>
<code>GET  /api/system/status</code> — full system status JSON<br>
</div>
</body>
</html>"""


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 10: Build and start the API Gateway server ---
# ═══════════════════════════════════════════════════════════════════════════════

_api_ready = threading.Event()
_api_thread: Optional[threading.Thread] = None


def _build_gateway_server():  # noqa: C901 — intentionally long
    from core.http_server import HTTPServer, JSONResponse, Response, Request  # type: ignore

    server = HTTPServer(host="0.0.0.0", port=PORT_CONDUCTOR, cors=True)
    cb1 = _circuit_breakers["node1_brain"]
    cb2 = _circuit_breakers["node2_memory"]

    # ── Dashboard ────────────────────────────────────────────────────────────
    @server.route("/", methods=["GET"])
    async def dashboard(req: Request) -> Response:
        system_ok = all(
            n.get("status") == "healthy"
            for n in _node_registry.values()
        )
        html_body = _build_dashboard_html(_node_registry, system_ok)
        return Response(
            body=html_body.encode("utf-8"),
            status=200,
            headers={"Content-Type": "text/html; charset=utf-8"},
        )

    # ── Aggregate health ─────────────────────────────────────────────────────
    @server.route("/api/health", methods=["GET"])
    async def aggregate_health(req: Request) -> JSONResponse:
        results: Dict[str, Any] = {"conductor": {"ok": True}}
        loop = asyncio.get_event_loop()

        async def _probe(name: str, url: str, path: str, cb: NodeCircuitBreaker) -> None:
            status_code, body, _ = await loop.run_in_executor(
                None,
                lambda: _proxy_request(url, "GET", path, b"", {}, timeout=5.0, cb=cb)
            )
            try:
                data = json.loads(body)
            except Exception:
                data = {"ok": False}
            data["http_status"] = status_code
            data["circuit"] = cb.state
            results[name] = data

        await asyncio.gather(
            _probe("node1_brain",   _node1_embed_url,  "/health",           cb1),
            _probe("node1_llm",     _node1_llm_url,    "/api/llm/health",   cb1),
            _probe("node1_mc",      _node1_mc_url,     "/api/mc/health",    cb1),
            _probe("node2_memory",  _node2_memory_url, "/api/vector/health",cb2),
        )

        all_ok = all(v.get("ok") for v in results.values())
        return JSONResponse({
            "ok":        all_ok,
            "nodes":     results,
            "node_id":   NODE_ID,
            "timestamp": time.time(),
        }, status=200 if all_ok else 207)

    # ── Full system status ───────────────────────────────────────────────────
    @server.route("/api/system/status", methods=["GET"])
    async def system_status(req: Request) -> JSONResponse:
        return JSONResponse({
            "ok":           True,
            "node_id":      NODE_ID,
            "node_name":    NODE_NAME,
            "role":         NODE_ROLE,
            "tunnel_url":   _tunnel_urls.get("conductor", ""),
            "registry":     _node_registry,
            "circuits":     {k: v.state for k, v in _circuit_breakers.items()},
            "conductor_ok": _conductor is not None,
            "pipeline_ok":  _pipeline  is not None,
            "bee_ok":       _bee_factory is not None,
            "swarm_ok":     _swarm is not None,
            "mcp_ok":       _mcp_server is not None,
            "phi4":         round(PHI4, 4),
            "timestamp":    time.time(),
        })

    # ── Conductor registration endpoint ─────────────────────────────────────
    @server.route("/api/conductor/register", methods=["POST"])
    async def conductor_register(req: Request) -> JSONResponse:
        body = req.json or {}
        node_id     = body.get("node_id",   "")
        role        = body.get("role",       "unknown")
        url         = body.get("url",        "")
        tunnel_url  = body.get("tunnel_url", "")
        caps        = body.get("capabilities", [])
        ports       = body.get("ports", {})

        if not node_id or not url:
            return JSONResponse({"ok": False, "error": "node_id and url required"}, status=400)

        global _node1_embed_url, _node1_llm_url, _node1_mc_url, _node2_memory_url

        with _registry_lock:
            _node_registry[node_id] = {
                "node_id":      node_id,
                "node_name":    body.get("node_name", node_id),
                "role":         role,
                "url":          tunnel_url or url,
                "status":       "healthy",
                "last_seen":    time.time(),
                "capabilities": caps,
                "ports":        ports,
            }

            # Update routing URLs when brain or memory registers
            if role == "brain":
                base = (tunnel_url or url).rstrip("/")
                _node1_embed_url = f"{base}"
                embed_port = ports.get("embed", PORT_EMBED)
                llm_port   = ports.get("llm",   PORT_LLM)
                mc_port    = ports.get("mc",     PORT_MC)
                # If tunnel (single URL), use path routing; otherwise port-based
                _node1_llm_url = base if "/" in base[8:] else base.replace(
                    f":{embed_port}", f":{llm_port}")
                _node1_mc_url  = base if "/" in base[8:] else base.replace(
                    f":{embed_port}", f":{mc_port}")
            elif role == "memory":
                _node2_memory_url = (tunnel_url or url).rstrip("/")

        log.info("Node registered: %s role=%s url=%s", node_id, role, url)
        return JSONResponse({
            "ok":          True,
            "acknowledged": node_id,
            "conductor_id": NODE_ID,
            "timestamp":   time.time(),
        })

    # ── Conductor status ─────────────────────────────────────────────────────
    @server.route("/api/conductor/status", methods=["GET"])
    async def conductor_status(req: Request) -> JSONResponse:
        info: Dict[str, Any] = {
            "node_id": NODE_ID,
            "conductor_ok": _conductor is not None,
        }
        if _conductor is not None:
            try:
                info["stats"] = _conductor.stats() if hasattr(_conductor, "stats") else {}
            except Exception:
                pass
        return JSONResponse({"ok": True, **info, "timestamp": time.time()})

    # ── Pipeline endpoints ───────────────────────────────────────────────────
    @server.route("/api/pipeline/run", methods=["POST"])
    async def pipeline_run(req: Request) -> JSONResponse:
        if _pipeline is None:
            return JSONResponse({"ok": False, "error": "Pipeline not initialised"}, status=503)
        body = req.json or {}
        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None, lambda: asyncio.run(_pipeline.run(body))
            )
            return JSONResponse({"ok": True, "result": result})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    @server.route("/api/pipeline/status", methods=["GET"])
    async def pipeline_status(req: Request) -> JSONResponse:
        return JSONResponse({
            "ok":     _pipeline is not None,
            "ready":  _pipeline is not None,
            "timestamp": time.time(),
        })

    # ── MCP endpoints (SSE + JSON-RPC) ───────────────────────────────────────
    @server.route("/api/mcp/rpc", methods=["POST"])
    async def mcp_rpc(req: Request) -> JSONResponse:
        if _mcp_server is None:
            return JSONResponse({"ok": False, "error": "MCP not initialised"}, status=503)
        body = req.json or {}
        try:
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None, lambda: _mcp_server.handle_rpc(body)
            )
            return JSONResponse(response)
        except Exception as e:
            return JSONResponse({"jsonrpc": "2.0", "error": {"code": -32603, "message": str(e)}},
                                status=500)

    @server.route("/api/mcp/tools", methods=["GET"])
    async def mcp_tools(req: Request) -> JSONResponse:
        if _mcp_server is None:
            return JSONResponse({"ok": False, "error": "MCP not initialised"}, status=503)
        try:
            tools = _mcp_server.list_tools() if hasattr(_mcp_server, "list_tools") else []
            return JSONResponse({"ok": True, "tools": tools})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── Bee Factory endpoints ────────────────────────────────────────────────
    @server.route("/api/bees/spawn", methods=["POST"])
    async def bees_spawn(req: Request) -> JSONResponse:
        if _bee_factory is None:
            return JSONResponse({"ok": False, "error": "BeeFactory not initialised"}, status=503)
        body = req.json or {}
        domain   = body.get("domain", "code")
        task     = body.get("task",   {})
        bee_id   = body.get("bee_id", str(uuid.uuid4()))
        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None, lambda: _bee_factory.spawn(domain=domain, task=task, bee_id=bee_id)
            )
            return JSONResponse({"ok": True, "bee_id": bee_id, "result": result})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    @server.route("/api/bees/status", methods=["GET"])
    async def bees_status(req: Request) -> JSONResponse:
        if _bee_factory is None:
            return JSONResponse({"ok": False, "error": "BeeFactory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            status = await loop.run_in_executor(None, _bee_factory.get_status)
            return JSONResponse({"ok": True, "status": status})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    @server.route("/api/bees/list", methods=["GET"])
    async def bees_list(req: Request) -> JSONResponse:
        if _bee_factory is None:
            return JSONResponse({"ok": False, "error": "BeeFactory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            bees = await loop.run_in_executor(None, _bee_factory.list_bees)
            return JSONResponse({"ok": True, "bees": bees, "count": len(bees)})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── Swarm endpoints ──────────────────────────────────────────────────────
    @server.route("/api/swarm/submit", methods=["POST"])
    async def swarm_submit(req: Request) -> JSONResponse:
        if _swarm is None:
            return JSONResponse({"ok": False, "error": "Swarm not initialised"}, status=503)
        body = req.json or {}
        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None, lambda: _swarm.submit_task(body)
            )
            return JSONResponse({"ok": True, "result": result})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    @server.route("/api/swarm/status", methods=["GET"])
    async def swarm_status(req: Request) -> JSONResponse:
        if _swarm is None:
            return JSONResponse({"ok": False, "error": "Swarm not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            status = await loop.run_in_executor(None, _swarm.get_status)
            return JSONResponse({"ok": True, "status": status})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ─────────────────────────────────────────────────────────────────────────
    # Proxy factory — create route handlers that forward to Node 1 or Node 2
    # ─────────────────────────────────────────────────────────────────────────
    def _make_proxy_handler(get_target_url, cb: NodeCircuitBreaker, strip_prefix: str = ""):
        async def _proxy(req: Request) -> Response:
            target_url = get_target_url()
            path       = req.path
            if strip_prefix and path.startswith(strip_prefix):
                path = path[len(strip_prefix):]
            if req.query_string:
                path += "?" + req.query_string
            status_code, body, resp_headers = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: _proxy_request(
                    target_url, req.method, path, req.body,
                    {k: v for k, v in req.headers.items()
                     if k.lower() not in ("host", "connection")},
                    timeout=30.0, cb=cb,
                )
            )
            content_type = resp_headers.get("Content-Type",
                           resp_headers.get("content-type", "application/json"))
            return Response(
                body=body, status=status_code,
                headers={"Content-Type": content_type},
            )
        return _proxy

    # Route: /api/embed/* → Node 1 embed (port 8001)
    embed_handler = _make_proxy_handler(lambda: _node1_embed_url, cb1)
    server.route("/embed",             methods=["GET", "POST", "PUT", "DELETE", "PATCH"])(embed_handler)
    server.route("/embed/batch",       methods=["GET", "POST", "PUT", "DELETE", "PATCH"])(embed_handler)
    server.route("/api/embed",         methods=["GET", "POST", "PUT", "DELETE", "PATCH"])(embed_handler)
    server.route("/api/embed/batch",   methods=["GET", "POST", "PUT", "DELETE", "PATCH"])(embed_handler)

    # Route: /api/llm/* → Node 1 LLM gateway (port 8002)
    llm_handler = _make_proxy_handler(lambda: _node1_llm_url, cb1)
    server.route("/api/llm/complete",  methods=["GET", "POST"])(llm_handler)
    server.route("/api/llm/health",    methods=["GET"])(llm_handler)

    # Route: /api/mc/* → Node 1 Monte Carlo (port 8004)
    mc_handler = _make_proxy_handler(lambda: _node1_mc_url, cb1)
    server.route("/api/mc/simulate",   methods=["GET", "POST"])(mc_handler)
    server.route("/api/mc/health",     methods=["GET"])(mc_handler)

    # Route: /api/vector/* → Node 2
    vec_handler = _make_proxy_handler(lambda: _node2_memory_url, cb2)
    for _vpath in [
        "/api/vector/query", "/api/vector/store", "/api/vector/stats",
        "/api/vector/3d/map", "/api/vector/3d/topology",
        "/api/vector/graph/query", "/api/vector/graph/edge",
        "/api/vector/drift/check", "/api/vector/drift/snapshot",
        "/api/vector/coherence/check", "/api/vector/health",
        "/api/vector/autonomy/run",
    ]:
        server.route(_vpath, methods=["GET", "POST"])(vec_handler)

    # Route: /api/agents/* → Node 2
    agents_handler = _make_proxy_handler(lambda: _node2_memory_url, cb2)
    server.route("/api/agents/spawn",   methods=["POST"])(agents_handler)
    server.route("/api/agents/observe", methods=["GET"])(agents_handler)

    return server


def _run_gateway_server() -> None:
    try:
        server = _build_gateway_server()
        _api_ready.set()
        log.info("API Gateway starting on port %d", PORT_CONDUCTOR)
        server.run()
    except Exception as e:
        log.error("API Gateway crashed: %s", e, exc_info=True)
        _api_ready.set()


print(f"🚀  Starting API Gateway on port {PORT_CONDUCTOR} …")
_api_thread = threading.Thread(
    target=_run_gateway_server, daemon=True, name="api-gateway"
)
_api_thread.start()

if _api_ready.wait(timeout=20):
    time.sleep(1)
    print(f"✓  API Gateway ready on port {PORT_CONDUCTOR}")
else:
    print("⚠  API Gateway did not signal ready — continuing anyway")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 11: Print endpoint summary ---
# ═══════════════════════════════════════════════════════════════════════════════

def print_endpoints() -> None:
    base = _tunnel_urls.get("conductor", f"http://localhost:{PORT_CONDUCTOR}")
    print("\n" + "═" * 70)
    print("  CONDUCTOR NODE — ENDPOINTS READY")
    print("═" * 70)
    print(f"  Public URL     : {base}")
    print(f"  Dashboard      : {base}/")
    print()
    print("  ── Proxied to Node 1 (Brain) ──")
    print(f"    POST {base}/api/embed")
    print(f"    POST {base}/api/llm/complete")
    print(f"    POST {base}/api/mc/simulate")
    print()
    print("  ── Proxied to Node 2 (Memory) ──")
    print(f"    POST {base}/api/vector/query")
    print(f"    POST {base}/api/vector/store")
    print(f"    GET  {base}/api/vector/stats")
    print(f"    GET  {base}/api/vector/3d/map")
    print(f"    POST {base}/api/agents/spawn")
    print(f"    GET  {base}/api/agents/observe")
    print()
    print("  ── Local (Conductor) ──")
    print(f"    GET  {base}/api/health")
    print(f"    GET  {base}/api/system/status")
    print(f"    POST {base}/api/conductor/register")
    print(f"    GET  {base}/api/conductor/status")
    print(f"    POST {base}/api/pipeline/run")
    print(f"    POST {base}/api/mcp/rpc")
    print(f"    POST {base}/api/bees/spawn")
    print(f"    POST {base}/api/swarm/submit")
    print()
    print(f"  Node ID        : {NODE_ID}")
    print(f"  Health tick    : every φ^4 = {PHI4:.2f}s")
    print("═" * 70 + "\n")


print_endpoints()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 12: Node discovery + health monitoring loop ---
# ═══════════════════════════════════════════════════════════════════════════════

_shutdown_flag = threading.Event()
_last_persist  = time.time()


def _update_node_health() -> None:
    """Probe each registered node and update its status in the registry."""
    probes = [
        ("node1_brain",  _node1_embed_url,  "/health",           cb1),
        ("node2_memory", _node2_memory_url, "/api/vector/health", cb2),
    ]
    for nid, url, path, cb in probes:
        full = url.rstrip("/") + path
        try:
            with urllib.request.urlopen(full, timeout=4) as resp:
                data = json.loads(resp.read())
                ok = data.get("ok", data.get("status") == "ok")
                with _registry_lock:
                    _node_registry[nid]["status"]    = "healthy" if ok else "degraded"
                    _node_registry[nid]["last_seen"] = time.time()
                if ok:
                    cb.record_success()
                else:
                    cb.record_failure()
        except Exception:
            with _registry_lock:
                _node_registry[nid]["status"] = "unreachable"
            cb.record_failure()


def _persist_state() -> None:
    try:
        save_dir = Path(_GDRIVE) / "checkpoints"
        save_dir.mkdir(parents=True, exist_ok=True)
        checkpoint = {
            "node_id":    NODE_ID,
            "role":       NODE_ROLE,
            "tunnel_url": _tunnel_urls.get("conductor", ""),
            "registry":   _node_registry,
            "timestamp":  time.time(),
        }
        (save_dir / f"node3_{NODE_ID}.json").write_text(json.dumps(checkpoint, indent=2))
        log.debug("State persisted")
    except Exception as e:
        log.debug("Persist skipped: %s", e)


def _health_and_discovery_loop() -> None:
    global _last_persist
    log.info("Health & discovery loop started (interval=%.2fs)", PHI4)

    while not _shutdown_flag.is_set():
        try:
            _update_node_health()

            n1_status = _node_registry.get("node1_brain",  {}).get("status", "?")
            n2_status = _node_registry.get("node2_memory", {}).get("status", "?")
            cb1_state = _circuit_breakers["node1_brain"].state
            cb2_state = _circuit_breakers["node2_memory"].state

            print(
                f"[CONDUCTOR] n1={n1_status}(cb:{cb1_state})  "
                f"n2={n2_status}(cb:{cb2_state})  "
                f"t={time.strftime('%H:%M:%S')}",
                flush=True,
            )

            now = time.time()
            if now - _last_persist >= PERSIST_INTERVAL:
                _persist_state()
                _last_persist = now

        except Exception as e:
            log.warning("Health loop error: %s", e)

        _shutdown_flag.wait(timeout=PHI4)

    log.info("Health & discovery loop exited")


def _graceful_shutdown(*_args: Any) -> None:
    print("\n⚠  Shutdown — persisting state to Drive …")
    _persist_state()
    _shutdown_flag.set()
    print("✓  State saved. Goodbye.")


for _sig in (signal.SIGTERM, signal.SIGINT):
    try:
        signal.signal(_sig, _graceful_shutdown)
    except (OSError, ValueError):
        pass

atexit.register(_persist_state)

print("🔄  Starting health & discovery loop (this node is the main entry point) …\n")

_health_thread = threading.Thread(
    target=_health_and_discovery_loop, daemon=False, name="health-loop"
)
_health_thread.start()

try:
    _health_thread.join()
except KeyboardInterrupt:
    _graceful_shutdown()
