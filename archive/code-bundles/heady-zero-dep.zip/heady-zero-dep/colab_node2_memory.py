"""
colab_node2_memory.py
=====================
HEADY MEMORY NODE — Colab Pro+ Notebook #2

Run this script cell-by-cell inside a Google Colab Pro+ notebook.
CPU runtime is fine; GPU not required.

Services started on this node
──────────────────────────────
  • Vector Memory System   — 3D spatial memory with all features
  • Graph RAG layer        — entity graph + multi-hop traversal
  • SQLite database        — WAL mode, persisted on Google Drive
  • Cache system           — in-memory + disk persistence
  • HTTP API Server        — port 8003 with all vector endpoints
  • Autonomous maintenance — background consolidation + drift detection
  • Public tunnel          — ngrok or cloudflared

All data is persisted to Google Drive at φ^6 ≈ 17.9s intervals and
on Colab disconnect.

Endpoints exposed (all under port 8003)
──────────────────────────────────────────────────────────────────
  POST /api/vector/query            — similarity search
  POST /api/vector/store            — store a new memory
  GET  /api/vector/stats            — memory statistics
  GET  /api/vector/3d/map           — 3D position map of all memories
  GET  /api/vector/3d/topology      — zone topology summary
  POST /api/vector/graph/query      — graph RAG query
  POST /api/vector/graph/edge       — add a graph edge
  GET  /api/vector/drift/check      — semantic drift report
  POST /api/vector/drift/snapshot   — force drift snapshot
  GET  /api/vector/coherence/check  — zone coherence report
  POST /api/agents/spawn            — spawn an agent in 3D space
  GET  /api/agents/observe          — observe all agents
  GET  /api/vector/health           — liveness check
  POST /api/vector/autonomy/run     — trigger maintenance cycle
"""

# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 1: Banner & imports ---
# ═══════════════════════════════════════════════════════════════════════════════

from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import signal
import subprocess
import sys
import threading
import time
import atexit
import urllib.error
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional

PHI: float = 1.6180339887498948482
PHI4: float = PHI ** 4   # ≈ 6.854 s
PHI6: float = PHI ** 6   # ≈ 17.94 s

NODE_ID: str   = f"memory-{uuid.uuid4().hex[:8]}"
NODE_ROLE: str = "memory"
NODE_NAME: str = "HEADY MEMORY NODE — Colab Pro+ #2"

_BANNER = r"""
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║      ██╗  ██╗███████╗ █████╗ ██████╗ ██╗   ██╗                 ║
║      ██║  ██║██╔════╝██╔══██╗██╔══██╗╚██╗ ██╔╝                 ║
║      ███████║█████╗  ███████║██║  ██║ ╚████╔╝                  ║
║      ██╔══██║██╔══╝  ██╔══██║██║  ██║  ╚██╔╝                   ║
║      ██║  ██║███████╗██║  ██║██████╔╝   ██║                     ║
║      ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝    ╚═╝                    ║
║                                                                  ║
║         MEMORY NODE  ·  Colab Pro+  #2                          ║
║         Vector Memory  ·  Graph RAG  ·  SQLite  ·  Cache        ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
"""

print(_BANNER)
print(f"  Node ID   : {NODE_ID}")
print(f"  φ^4 tick  : {PHI4:.3f}s\n")

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("memory_node")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 2: Install dependencies ---
# ═══════════════════════════════════════════════════════════════════════════════

def install_deps() -> None:
    """sentence-transformers pulls torch as a dependency; install both explicitly."""
    print("📦  Installing dependencies …")
    pkgs = ["torch", "sentence-transformers"]
    for pkg in pkgs:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", pkg, "--quiet"],
            capture_output=True, text=True,
        )
        status = "✓" if r.returncode == 0 else "⚠"
        print(f"    {status}  {pkg}")
    print()


install_deps()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 3: Mount Google Drive & sync code ---
# ═══════════════════════════════════════════════════════════════════════════════

GDRIVE_MOUNT     = "/content/drive"
GDRIVE_HEADY_DIR = "/content/drive/MyDrive/heady-zero-dep"
LOCAL_HEADY_DIR  = "/content/heady-zero-dep"


def mount_drive() -> bool:
    try:
        from google.colab import drive  # type: ignore
        drive.mount(GDRIVE_MOUNT, force_remount=False)
        print(f"✓  Google Drive mounted at {GDRIVE_MOUNT}")
        return True
    except ImportError:
        print("⚠  google.colab not available — local mode")
        return False
    except Exception as e:
        print(f"⚠  Drive mount failed: {e}")
        return False


def sync_code_from_drive() -> None:
    drive_src = Path(GDRIVE_HEADY_DIR)
    local_dst = Path(LOCAL_HEADY_DIR)

    if drive_src.exists():
        import shutil
        if local_dst.exists():
            shutil.rmtree(str(local_dst))
        shutil.copytree(str(drive_src), str(local_dst))
        print(f"✓  Code synced from Drive → {local_dst}")
    elif local_dst.exists():
        print(f"✓  Code found at {local_dst}")
    else:
        script_dir = Path(__file__).parent
        if (script_dir / "ai").exists():
            local_dst = script_dir
            print(f"✓  Using script directory: {local_dst}")
        else:
            print(f"⚠  heady-zero-dep not found — check your Drive setup")
            return

    code_root = str(local_dst)
    if code_root not in sys.path:
        sys.path.insert(0, code_root)
    print(f"✓  {code_root} added to sys.path\n")


_drive_mounted = mount_drive()
sync_code_from_drive()

_script_root = str(Path(__file__).parent)
if _script_root not in sys.path:
    sys.path.insert(0, _script_root)


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 4: Load configuration ---
# ═══════════════════════════════════════════════════════════════════════════════

for _ep in [Path(GDRIVE_HEADY_DIR) / ".env", Path(LOCAL_HEADY_DIR) / ".env",
            Path(__file__).parent / ".env"]:
    if _ep.exists():
        try:
            from core.env_loader import load_env
            load_env(str(_ep))
            print(f"✓  Loaded .env from {_ep}")
            break
        except Exception:
            pass

os.environ["HEADY_NODE_ID"]   = NODE_ID
os.environ["HEADY_NODE_ROLE"] = NODE_ROLE
os.environ["HEADY_ENV"]       = "colab"

try:
    from config import (
        PORT_MEMORY,
        NGROK_TOKEN, CLOUDFLARE_TOKEN, TUNNEL_PROVIDER,
        NODE3_URL,
        PHI4 as _PHI4, PHI6 as _PHI6,
        HEALTH_CHECK_INTERVAL, PERSIST_INTERVAL,
        DATA_DIR, DB_PATH, VECTOR_STORE_DIR, CACHE_DIR,
        GDRIVE_HEADY_DIR as _GDRIVE,
    )
    PHI4 = _PHI4
    PHI6 = _PHI6
    print("✓  Config loaded from config.py")
except ImportError:
    print("⚠  config.py not found — using built-in defaults")
    PORT_MEMORY      = int(os.getenv("PORT_MEMORY", "8003"))
    NODE3_URL        = os.getenv("HEADY_NODE3_URL", "http://localhost:8000")
    NGROK_TOKEN      = os.getenv("NGROK_TOKEN", "")
    CLOUDFLARE_TOKEN = os.getenv("CLOUDFLARE_TOKEN", "")
    TUNNEL_PROVIDER  = os.getenv("TUNNEL_PROVIDER", "auto")
    DATA_DIR         = os.getenv("HEADY_DATA_DIR",    "data")
    DB_PATH          = os.getenv("HEADY_DB_PATH",     "data/heady.db")
    VECTOR_STORE_DIR = os.getenv("HEADY_VECTOR_DIR",  "data/vectors")
    CACHE_DIR        = os.getenv("HEADY_CACHE_DIR",   "data/cache")
    HEALTH_CHECK_INTERVAL = PHI4
    PERSIST_INTERVAL      = PHI6
    _GDRIVE = GDRIVE_HEADY_DIR

print(f"  PORT_MEMORY : {PORT_MEMORY}")
print(f"  DATA_DIR    : {DATA_DIR}")
print(f"  Node3 URL   : {NODE3_URL}\n")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 5: Initialise storage directories ---
# ═══════════════════════════════════════════════════════════════════════════════

def init_storage() -> None:
    """Create data directories, preferring Google Drive if mounted."""
    global DATA_DIR, DB_PATH, VECTOR_STORE_DIR, CACHE_DIR

    # If Drive is mounted, store data there for persistence
    if _drive_mounted and Path(_GDRIVE).exists():
        drive_data = Path(_GDRIVE) / "data"
        DATA_DIR        = str(drive_data)
        DB_PATH         = str(drive_data / "heady.db")
        VECTOR_STORE_DIR = str(drive_data / "vectors")
        CACHE_DIR       = str(drive_data / "cache")
        print(f"✓  Using Google Drive for persistent storage: {drive_data}")

    # Create directories
    for d in [DATA_DIR, VECTOR_STORE_DIR, CACHE_DIR,
              str(Path(DATA_DIR) / "logs"),
              str(Path(DATA_DIR) / "checkpoints"),
              str(Path(DATA_DIR) / "backups")]:
        Path(d).mkdir(parents=True, exist_ok=True)

    # Init SQLite
    try:
        from core.database import Database  # type: ignore
        db = Database(DB_PATH)
        print(f"✓  SQLite database: {DB_PATH}")
    except Exception as e:
        log.warning("Database init error (will use sqlite3 directly): %s", e)
        import sqlite3
        Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.commit()
        conn.close()
        print(f"✓  SQLite (raw): {DB_PATH}")


init_storage()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 6: Initialise Vector Memory & Cache ---
# ═══════════════════════════════════════════════════════════════════════════════

_vector_memory = None
_cache         = None

def init_vector_memory():
    global _vector_memory
    try:
        from ai.vector_memory import VectorMemory  # type: ignore
        _vector_memory = VectorMemory(
            persist_dir=VECTOR_STORE_DIR,
            db_path=DB_PATH,
        )
        print(f"✓  VectorMemory initialised  (store={VECTOR_STORE_DIR})")
        return _vector_memory
    except Exception as e:
        log.error("VectorMemory init failed: %s", e, exc_info=True)
        print(f"⚠  VectorMemory unavailable: {e}")
        return None


def init_cache():
    global _cache
    try:
        from core.cache import Cache  # type: ignore
        _cache = Cache(
            max_size=int(PHI ** 10),   # ≈ 123 entries
            persist_path=str(Path(CACHE_DIR) / "heady_cache.json"),
        )
        print(f"✓  Cache initialised  (dir={CACHE_DIR})")
        return _cache
    except Exception as e:
        log.warning("Cache init failed: %s", e)
        return None


_vector_memory = init_vector_memory()
_cache         = init_cache()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 7: Tunnel setup ---
# ═══════════════════════════════════════════════════════════════════════════════

_tunnel_urls: Dict[str, str] = {}


def _start_ngrok_tunnel(port: int, token: str) -> Optional[str]:
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "pyngrok", "--quiet"],
            capture_output=True,
        )
        from pyngrok import ngrok, conf  # type: ignore
        conf.get_default().auth_token = token
        tunnel = ngrok.connect(port, "http")
        url = tunnel.public_url
        return url.replace("http://", "https://", 1) if url.startswith("http://") else url
    except Exception as e:
        log.warning("ngrok failed on port %d: %s", port, e)
        return None


def _start_cloudflared_tunnel(port: int) -> Optional[str]:
    try:
        cf_bin = "/usr/local/bin/cloudflared"
        if not Path(cf_bin).exists():
            subprocess.run([
                "wget", "-q",
                "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64",
                "-O", cf_bin,
            ], check=True)
            os.chmod(cf_bin, 0o755)
        proc = subprocess.Popen(
            [cf_bin, "tunnel", "--url", f"http://localhost:{port}"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
        )
        deadline = time.time() + 30
        while time.time() < deadline:
            line = proc.stdout.readline()
            if "trycloudflare.com" in line:
                for part in line.split():
                    if "trycloudflare.com" in part:
                        url = part.strip()
                        return url if url.startswith("http") else "https://" + url
        return None
    except Exception as e:
        log.warning("cloudflared failed on port %d: %s", port, e)
        return None


def establish_tunnels() -> Dict[str, str]:
    urls: Dict[str, str] = {}
    provider = TUNNEL_PROVIDER
    if provider == "auto":
        provider = "ngrok" if NGROK_TOKEN else "cloudflared"

    print(f"🌐  Establishing tunnel via {provider} …")

    url: Optional[str] = None
    if provider == "ngrok" and NGROK_TOKEN:
        url = _start_ngrok_tunnel(PORT_MEMORY, NGROK_TOKEN)
    elif provider == "cloudflared":
        url = _start_cloudflared_tunnel(PORT_MEMORY)

    if url:
        urls["memory"] = url
        urls[str(PORT_MEMORY)] = url
        print(f"  ✓  memory ({PORT_MEMORY}) → {url}")
    else:
        local_url = f"http://localhost:{PORT_MEMORY}"
        urls["memory"] = local_url
        urls[str(PORT_MEMORY)] = local_url
        print(f"  ⚠  memory ({PORT_MEMORY}) — local only: {local_url}")

    return urls


_tunnel_urls = establish_tunnels()
os.environ["HEADY_NODE2_URL"]    = _tunnel_urls.get("memory", f"http://localhost:{PORT_MEMORY}")
os.environ["HEADY_NODE2_TUNNEL"] = _tunnel_urls.get("memory", "")
print()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 8: Build and start API server ---
# ═══════════════════════════════════════════════════════════════════════════════

_api_thread: Optional[threading.Thread] = None
_api_ready   = threading.Event()


def _build_api_server():
    """
    Build the HTTP server with all 14 vector/agent endpoints.
    Returns the HTTPServer instance (not yet running).
    """
    from core.http_server import HTTPServer, JSONResponse, Request  # type: ignore

    server = HTTPServer(host="0.0.0.0", port=PORT_MEMORY, cors=True)
    vm     = _vector_memory
    cache  = _cache

    # ── POST /api/vector/store ───────────────────────────────────────────────
    @server.route("/api/vector/store", methods=["POST"])
    async def vector_store(req: Request) -> JSONResponse:
        body = req.json or {}
        content    = body.get("content", "")
        embedding  = body.get("embedding")
        metadata   = body.get("metadata", {})
        importance = float(body.get("importance", 0.5))

        if not content and not embedding:
            return JSONResponse({"ok": False, "error": "content or embedding required"}, status=400)

        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)

        try:
            loop = asyncio.get_event_loop()
            memory_id = await loop.run_in_executor(
                None,
                lambda: vm.store(
                    content=content,
                    embedding=embedding,
                    metadata=metadata,
                    importance=importance,
                )
            )
            return JSONResponse({"ok": True, "memory_id": memory_id})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── POST /api/vector/query ───────────────────────────────────────────────
    @server.route("/api/vector/query", methods=["POST"])
    async def vector_query(req: Request) -> JSONResponse:
        body = req.json or {}
        query_embedding = body.get("embedding")
        query_text      = body.get("query", "")
        top_k           = int(body.get("top_k", 10))
        threshold       = float(body.get("threshold", 0.5))
        zone_filter     = body.get("zone")

        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        if not query_embedding and not query_text:
            return JSONResponse({"ok": False, "error": "embedding or query required"}, status=400)

        try:
            loop = asyncio.get_event_loop()
            results = await loop.run_in_executor(
                None,
                lambda: vm.query(
                    embedding=query_embedding,
                    query_text=query_text,
                    top_k=top_k,
                    threshold=threshold,
                    zone=zone_filter,
                )
            )
            return JSONResponse({"ok": True, "results": results, "count": len(results)})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── GET /api/vector/stats ────────────────────────────────────────────────
    @server.route("/api/vector/stats", methods=["GET"])
    async def vector_stats(req: Request) -> JSONResponse:
        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            stats = await loop.run_in_executor(None, vm.get_stats)
            return JSONResponse({"ok": True, "stats": stats})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── GET /api/vector/3d/map ───────────────────────────────────────────────
    @server.route("/api/vector/3d/map", methods=["GET"])
    async def vector_3d_map(req: Request) -> JSONResponse:
        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            positions = await loop.run_in_executor(None, vm.get_3d_map)
            return JSONResponse({"ok": True, "positions": positions, "count": len(positions)})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── GET /api/vector/3d/topology ──────────────────────────────────────────
    @server.route("/api/vector/3d/topology", methods=["GET"])
    async def vector_3d_topology(req: Request) -> JSONResponse:
        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            topo = await loop.run_in_executor(None, vm.get_zone_topology)
            return JSONResponse({"ok": True, "topology": topo})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── POST /api/vector/graph/query ─────────────────────────────────────────
    @server.route("/api/vector/graph/query", methods=["POST"])
    async def graph_query(req: Request) -> JSONResponse:
        body = req.json or {}
        node_id = body.get("node_id", "")
        query   = body.get("query",   "")
        depth   = int(body.get("depth", 2))
        top_k   = int(body.get("top_k", 10))

        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            results = await loop.run_in_executor(
                None,
                lambda: vm.graph_query(node_id=node_id, query=query, depth=depth, top_k=top_k)
            )
            return JSONResponse({"ok": True, "results": results, "count": len(results)})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── POST /api/vector/graph/edge ──────────────────────────────────────────
    @server.route("/api/vector/graph/edge", methods=["POST"])
    async def graph_add_edge(req: Request) -> JSONResponse:
        body = req.json or {}
        src      = body.get("source", "")
        dst      = body.get("target", "")
        rel_type = body.get("relationship", "related")
        weight   = float(body.get("weight", 1.0))

        if not src or not dst:
            return JSONResponse({"ok": False, "error": "source and target required"}, status=400)
        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None,
                lambda: vm.add_graph_edge(src, dst, rel_type, weight)
            )
            return JSONResponse({"ok": True, "edge": {"source": src, "target": dst, "rel": rel_type}})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── GET /api/vector/drift/check ──────────────────────────────────────────
    @server.route("/api/vector/drift/check", methods=["GET"])
    async def drift_check(req: Request) -> JSONResponse:
        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            drift = await loop.run_in_executor(None, vm.check_drift)
            return JSONResponse({"ok": True, "drift": drift})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── POST /api/vector/drift/snapshot ──────────────────────────────────────
    @server.route("/api/vector/drift/snapshot", methods=["POST"])
    async def drift_snapshot(req: Request) -> JSONResponse:
        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            snap = await loop.run_in_executor(None, vm.take_drift_snapshot)
            return JSONResponse({"ok": True, "snapshot": snap, "timestamp": time.time()})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── GET /api/vector/coherence/check ─────────────────────────────────────
    @server.route("/api/vector/coherence/check", methods=["GET"])
    async def coherence_check(req: Request) -> JSONResponse:
        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            coherence = await loop.run_in_executor(None, vm.check_zone_coherence)
            return JSONResponse({"ok": True, "coherence": coherence})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── POST /api/agents/spawn ───────────────────────────────────────────────
    @server.route("/api/agents/spawn", methods=["POST"])
    async def agents_spawn(req: Request) -> JSONResponse:
        body       = req.json or {}
        agent_id   = body.get("agent_id",   str(uuid.uuid4()))
        agent_type = body.get("type",        "generic")
        position   = body.get("position",    None)   # [x, y, z] optional
        metadata   = body.get("metadata",    {})

        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                lambda: vm.spawn_agent(agent_id=agent_id, agent_type=agent_type,
                                       position=position, metadata=metadata)
            )
            return JSONResponse({"ok": True, "agent_id": agent_id, "result": result})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── GET /api/agents/observe ──────────────────────────────────────────────
    @server.route("/api/agents/observe", methods=["GET"])
    async def agents_observe(req: Request) -> JSONResponse:
        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            agents = await loop.run_in_executor(None, vm.list_agents)
            return JSONResponse({"ok": True, "agents": agents, "count": len(agents)})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    # ── GET /api/vector/health ───────────────────────────────────────────────
    @server.route("/api/vector/health", methods=["GET"])
    async def vector_health(req: Request) -> JSONResponse:
        vm_ok    = vm is not None
        cache_ok = cache is not None
        stats: Dict[str, Any] = {}
        if vm_ok:
            try:
                loop = asyncio.get_event_loop()
                stats = await loop.run_in_executor(None, vm.get_stats)
            except Exception:
                pass
        return JSONResponse({
            "ok": vm_ok,
            "service":   "heady-memory-node",
            "node_id":   NODE_ID,
            "vm_ready":  vm_ok,
            "cache_ready": cache_ok,
            "db_path":   DB_PATH,
            "stats":     stats,
            "timestamp": time.time(),
        })

    # ── POST /api/vector/autonomy/run ────────────────────────────────────────
    @server.route("/api/vector/autonomy/run", methods=["POST"])
    async def autonomy_run(req: Request) -> JSONResponse:
        if vm is None:
            return JSONResponse({"ok": False, "error": "VectorMemory not initialised"}, status=503)
        try:
            loop = asyncio.get_event_loop()
            report = await loop.run_in_executor(None, vm.run_maintenance)
            return JSONResponse({"ok": True, "report": report, "timestamp": time.time()})
        except Exception as e:
            return JSONResponse({"ok": False, "error": str(e)}, status=500)

    return server


def _run_api_server() -> None:
    try:
        server = _build_api_server()
        _api_ready.set()
        log.info("Memory API server starting on port %d", PORT_MEMORY)
        server.run()
    except Exception as e:
        log.error("Memory API server crashed: %s", e, exc_info=True)
        _api_ready.set()


print(f"🧩  Starting Memory API on port {PORT_MEMORY} …")
_api_thread = threading.Thread(
    target=_run_api_server, daemon=True, name="memory-api"
)
_api_thread.start()

if _api_ready.wait(timeout=20):
    time.sleep(1)
    print(f"✓  Memory API ready on port {PORT_MEMORY}")
else:
    print("⚠  Memory API did not signal ready in 20s — continuing anyway")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 9: Start autonomous maintenance loop ---
# ═══════════════════════════════════════════════════════════════════════════════

_maintenance_thread: Optional[threading.Thread] = None


def _run_maintenance_loop() -> None:
    """
    Background loop that:
    - Consolidates STM → LTM every φ^7 ≈ 29s
    - Checks zone coherence and alerts on degradation
    - Saves a persist checkpoint every φ^6 ≈ 18s
    """
    from ai.vector_math import PHI as _phi  # type: ignore
    interval = _phi ** 7   # ≈ 29.0s

    log.info("Autonomous maintenance loop started (interval=%.1fs)", interval)
    while not _shutdown_flag.is_set():
        _shutdown_flag.wait(timeout=interval)
        if _shutdown_flag.is_set():
            break
        if _vector_memory is None:
            continue
        try:
            _vector_memory.run_maintenance()
            log.debug("Maintenance cycle complete")
        except Exception as e:
            log.warning("Maintenance error: %s", e)


_maintenance_thread = threading.Thread(
    target=_run_maintenance_loop, daemon=True, name="maintenance"
)
_maintenance_thread.start()
print("✓  Autonomous maintenance loop started")


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 10: Register with Conductor (Node 3) ---
# ═══════════════════════════════════════════════════════════════════════════════

def register_with_conductor(conductor_url: str, retries: int = 5) -> bool:
    payload = json.dumps({
        "node_id":    NODE_ID,
        "node_name":  NODE_NAME,
        "role":       NODE_ROLE,
        "url":        _tunnel_urls.get("memory", f"http://localhost:{PORT_MEMORY}"),
        "tunnel_url": _tunnel_urls.get("memory", ""),
        "ports":      {"memory": PORT_MEMORY},
        "capabilities": ["vector_memory", "graph_rag", "sqlite", "cache", "agents"],
        "timestamp":  time.time(),
    }).encode("utf-8")

    for attempt in range(1, retries + 1):
        try:
            req = urllib.request.Request(
                f"{conductor_url.rstrip('/')}/api/conductor/register",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())
                if data.get("ok"):
                    print(f"✓  Registered with Conductor at {conductor_url}")
                    return True
        except Exception as e:
            log.info("Conductor not reachable (attempt %d/%d): %s", attempt, retries, e)
            if attempt < retries:
                time.sleep(PHI4 * attempt)
    print(f"⚠  Could not register with Conductor — will retry in health loop")
    return False


register_with_conductor(NODE3_URL)


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 11: Print endpoint summary ---
# ═══════════════════════════════════════════════════════════════════════════════

def print_endpoints() -> None:
    base = _tunnel_urls.get("memory", f"http://localhost:{PORT_MEMORY}")
    endpoints = [
        ("POST", "/api/vector/query",          "similarity search"),
        ("POST", "/api/vector/store",          "store memory"),
        ("GET",  "/api/vector/stats",          "statistics"),
        ("GET",  "/api/vector/3d/map",         "3D position map"),
        ("GET",  "/api/vector/3d/topology",    "zone topology"),
        ("POST", "/api/vector/graph/query",    "graph RAG query"),
        ("POST", "/api/vector/graph/edge",     "add graph edge"),
        ("GET",  "/api/vector/drift/check",    "drift report"),
        ("POST", "/api/vector/drift/snapshot", "force snapshot"),
        ("GET",  "/api/vector/coherence/check","coherence report"),
        ("POST", "/api/agents/spawn",          "spawn agent"),
        ("GET",  "/api/agents/observe",        "list agents"),
        ("GET",  "/api/vector/health",         "health check"),
        ("POST", "/api/vector/autonomy/run",   "run maintenance"),
    ]
    print("\n" + "═" * 65)
    print("  MEMORY NODE — ENDPOINTS READY")
    print("═" * 65)
    print(f"  Base URL: {base}\n")
    for method, path, desc in endpoints:
        print(f"  {method:4s} {path:<38} — {desc}")
    print()
    print(f"  Node ID       : {NODE_ID}")
    print(f"  DB path       : {DB_PATH}")
    print(f"  Vector store  : {VECTOR_STORE_DIR}")
    print(f"  Health tick   : every φ^4 = {PHI4:.2f}s")
    print("═" * 65 + "\n")


print_endpoints()


# ═══════════════════════════════════════════════════════════════════════════════
# --- CELL 12: Health check loop + state persistence ---
# ═══════════════════════════════════════════════════════════════════════════════

_shutdown_flag = threading.Event()
_last_persist  = time.time()
_conductor_url = NODE3_URL


def _probe_local(port: int, path: str = "/health") -> bool:
    try:
        with urllib.request.urlopen(f"http://localhost:{port}{path}", timeout=3) as resp:
            data = json.loads(resp.read())
            return data.get("ok", data.get("status") == "ok")
    except Exception:
        return False


def _persist_state() -> None:
    """Persist memory + checkpoint to Drive (best-effort)."""
    try:
        # Checkpoint JSON
        checkpoint = {
            "node_id":    NODE_ID,
            "role":       NODE_ROLE,
            "timestamp":  time.time(),
            "db_path":    DB_PATH,
            "vector_dir": VECTOR_STORE_DIR,
            "tunnel_url": _tunnel_urls.get("memory", ""),
        }
        save_dir = Path(_GDRIVE) / "checkpoints"
        save_dir.mkdir(parents=True, exist_ok=True)
        (save_dir / f"node2_{NODE_ID}.json").write_text(json.dumps(checkpoint, indent=2))

        # Persist vector memory
        if _vector_memory is not None:
            try:
                _vector_memory.persist()
            except Exception as e:
                log.debug("vm.persist() error: %s", e)
        log.debug("State persisted")
    except Exception as e:
        log.debug("Persist skipped: %s", e)


def _health_loop() -> None:
    global _last_persist
    _registered = False
    log.info("Health-check loop started (interval=%.2fs)", PHI4)

    while not _shutdown_flag.is_set():
        try:
            api_ok = _probe_local(PORT_MEMORY, "/api/vector/health")
            print(
                f"[MEMORY] api={'✓' if api_ok else '✗'}  "
                f"vm={'✓' if _vector_memory else '✗'}  "
                f"t={time.strftime('%H:%M:%S')}",
                flush=True,
            )
            if not _registered:
                _registered = register_with_conductor(_conductor_url, retries=1)

            now = time.time()
            if now - _last_persist >= PERSIST_INTERVAL:
                _persist_state()
                _last_persist = now

        except Exception as e:
            log.warning("Health loop error: %s", e)

        _shutdown_flag.wait(timeout=PHI4)

    log.info("Health loop exited")


def _graceful_shutdown(*_args: Any) -> None:
    print("\n⚠  Shutdown — persisting state to Drive …")
    _persist_state()
    _shutdown_flag.set()
    print("✓  State saved. Goodbye.")


for _sig in (signal.SIGTERM, signal.SIGINT):
    try:
        signal.signal(_sig, _graceful_shutdown)
    except (OSError, ValueError):
        pass

atexit.register(_persist_state)

print("🔄  Starting health-check loop …\n")
_health_thread = threading.Thread(
    target=_health_loop, daemon=False, name="health-loop"
)
_health_thread.start()

try:
    _health_thread.join()
except KeyboardInterrupt:
    _graceful_shutdown()
