"""
Heady Zero-Dependency Core
==========================
A complete replacement for all external dependencies using only Python stdlib.

Modules:
    env_loader      - Replaces python-dotenv
    http_server     - Replaces FastAPI/Flask (async, zero-dep)
    http_client     - Replaces requests/httpx (async, retry, SSE)
    cache           - Replaces Redis/Upstash (in-memory, TTL, pub/sub)
    database        - Replaces PostgreSQL/Neon (SQLite-backed, WAL, migrations)
    telemetry       - Replaces Sentry (structured logging, metrics, tracing)
    process_manager - Replaces concurrently/nodemon (child proc management)
"""

from .env_loader import (
    load_env,
    load_env_file,
    get_env,
    require_env,
    EnvLoader,
)

from .http_server import (
    HTTPServer,
    Request,
    Response,
    Router,
    route,
    middleware,
    JSONResponse,
    TextResponse,
    StreamingResponse,
)

from .http_client import (
    HTTPClient,
    AsyncHTTPClient,
    get,
    post,
    put,
    delete,
    patch,
    HttpError,
)

from .cache import (
    Cache,
    CacheNamespace,
    cache_key,
    get_default_cache,
)

from .database import (
    Database,
    QueryBuilder,
    Migration,
    get_default_db,
    transaction,
)

from .telemetry import (
    Telemetry,
    Logger,
    Metrics,
    EventBus,
    timer,
    capture_exception,
    get_telemetry,
)

from .process_manager import (
    ProcessManager,
    ManagedProcess,
    FileWatcher,
    get_process_manager,
)

__all__ = [
    # env_loader
    "load_env",
    "load_env_file",
    "get_env",
    "require_env",
    "EnvLoader",
    # http_server
    "HTTPServer",
    "Request",
    "Response",
    "Router",
    "route",
    "middleware",
    "JSONResponse",
    "TextResponse",
    "StreamingResponse",
    # http_client
    "HTTPClient",
    "AsyncHTTPClient",
    "get",
    "post",
    "put",
    "delete",
    "patch",
    "HttpError",
    # cache
    "Cache",
    "CacheNamespace",
    "cache_key",
    "get_default_cache",
    # database
    "Database",
    "QueryBuilder",
    "Migration",
    "get_default_db",
    "transaction",
    # telemetry
    "Telemetry",
    "Logger",
    "Metrics",
    "EventBus",
    "timer",
    "capture_exception",
    "get_telemetry",
    # process_manager
    "ProcessManager",
    "ManagedProcess",
    "FileWatcher",
    "get_process_manager",
]

__version__ = "1.0.0"
__author__ = "Heady Zero-Dep"
