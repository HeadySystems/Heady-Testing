/**
 * @file mcp-protocol.js
 * @description Full MCP (Model Context Protocol) implementation - JSON-RPC 2.0
 *
 * Implements the Model Context Protocol spec over stdio and SSE transports.
 * Handles tool registration, tool calling, resource listing, and session
 * management with capability negotiation.
 *
 * Sacred Geometry: PHI-scaled timeouts, Fibonacci retry sequences.
 * Zero external dependencies - pure Node.js (http, crypto, stream, events).
 *
 * @module HeadyCore/MCPProtocol
 */

import { EventEmitter } from 'events';
import { createHash, randomUUID } from 'crypto';
import http from 'http';
import https from 'https';
import { Readable, Writable, Transform } from 'stream';
import readline from 'readline';

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI = 1.6180339887498948482;
const FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610];

/**
 * Get PHI-scaled timeout for retry attempt n
 * @param {number} n - retry index (0-based)
 * @param {number} [base=200] - base delay in ms
 * @returns {number} delay in ms
 */
function phiBackoff(n, base = 200) {
  return Math.floor(base * Math.pow(PHI, Math.min(n, 14)));
}

// ─── JSON-RPC 2.0 Message Types ───────────────────────────────────────────────

/** @enum {string} */
export const MsgType = Object.freeze({
  REQUEST: 'request',
  RESPONSE: 'response',
  NOTIFICATION: 'notification',
  ERROR: 'error',
});

/** @enum {number} JSON-RPC 2.0 error codes */
export const JsonRpcError = Object.freeze({
  PARSE_ERROR: -32700,
  INVALID_REQUEST: -32600,
  METHOD_NOT_FOUND: -32601,
  INVALID_PARAMS: -32602,
  INTERNAL_ERROR: -32603,
  // MCP-specific
  SESSION_NOT_FOUND: -32001,
  CAPABILITY_NOT_SUPPORTED: -32002,
  TOOL_NOT_FOUND: -32003,
  RESOURCE_NOT_FOUND: -32004,
  UNAUTHORIZED: -32005,
});

/**
 * Build a JSON-RPC 2.0 request message
 * @param {string} method
 * @param {*} [params]
 * @param {string|number} [id]
 * @returns {object}
 */
export function buildRequest(method, params, id) {
  return {
    jsonrpc: '2.0',
    method,
    ...(params !== undefined ? { params } : {}),
    id: id ?? randomUUID(),
  };
}

/**
 * Build a JSON-RPC 2.0 response message
 * @param {string|number} id
 * @param {*} result
 * @returns {object}
 */
export function buildResponse(id, result) {
  return { jsonrpc: '2.0', id, result };
}

/**
 * Build a JSON-RPC 2.0 error response
 * @param {string|number|null} id
 * @param {number} code
 * @param {string} message
 * @param {*} [data]
 * @returns {object}
 */
export function buildError(id, code, message, data) {
  return {
    jsonrpc: '2.0',
    id: id ?? null,
    error: { code, message, ...(data !== undefined ? { data } : {}) },
  };
}

/**
 * Build a JSON-RPC 2.0 notification (no id)
 * @param {string} method
 * @param {*} [params]
 * @returns {object}
 */
export function buildNotification(method, params) {
  return {
    jsonrpc: '2.0',
    method,
    ...(params !== undefined ? { params } : {}),
  };
}

/**
 * Validate a JSON-RPC 2.0 message
 * @param {*} msg
 * @returns {{ valid: boolean, type: string, error?: string }}
 */
export function validateMessage(msg) {
  if (!msg || typeof msg !== 'object') {
    return { valid: false, error: 'Message must be an object' };
  }
  if (msg.jsonrpc !== '2.0') {
    return { valid: false, error: 'jsonrpc must be "2.0"' };
  }
  if ('method' in msg) {
    if (typeof msg.method !== 'string') {
      return { valid: false, error: 'method must be a string' };
    }
    const type = 'id' in msg ? MsgType.REQUEST : MsgType.NOTIFICATION;
    return { valid: true, type };
  }
  if ('result' in msg || 'error' in msg) {
    return { valid: true, type: 'id' in msg ? MsgType.RESPONSE : MsgType.ERROR };
  }
  return { valid: false, error: 'Invalid message structure' };
}

// ─── MCP Session ──────────────────────────────────────────────────────────────

/**
 * @typedef {object} MCPCapabilities
 * @property {boolean} [tools] - supports tools/list and tools/call
 * @property {boolean} [resources] - supports resources/list and resources/read
 * @property {boolean} [prompts] - supports prompts/list and prompts/get
 * @property {boolean} [logging] - supports logging/setLevel
 * @property {boolean} [sampling] - supports sampling/createMessage
 */

/**
 * @typedef {object} MCPTool
 * @property {string} name
 * @property {string} description
 * @property {object} inputSchema - JSON Schema object
 * @property {Function} handler - async (params) => result
 */

/**
 * @typedef {object} MCPResource
 * @property {string} uri
 * @property {string} name
 * @property {string} [mimeType]
 * @property {string} [description]
 * @property {Function} reader - async (uri, params) => { contents }
 */

/**
 * Represents a single MCP session (connection lifecycle)
 */
export class MCPSession extends EventEmitter {
  /**
   * @param {string} sessionId
   * @param {object} [options]
   * @param {MCPCapabilities} [options.serverCapabilities]
   */
  constructor(sessionId, options = {}) {
    super();
    /** @type {string} */
    this.id = sessionId;
    /** @type {'initializing'|'active'|'closing'|'closed'} */
    this.state = 'initializing';
    /** @type {MCPCapabilities} */
    this.clientCapabilities = {};
    /** @type {MCPCapabilities} */
    this.serverCapabilities = options.serverCapabilities ?? {
      tools: true,
      resources: true,
      prompts: true,
      logging: true,
    };
    /** @type {Map<string|number, { resolve: Function, reject: Function, timer: any }>} */
    this._pending = new Map();
    /** @type {number} */
    this.createdAt = Date.now();
    /** @type {number} */
    this.lastActivity = Date.now();
    /** @type {object|null} */
    this.clientInfo = null;
    /** @type {string|null} */
    this.protocolVersion = null;
  }

  /** Touch last activity timestamp */
  touch() {
    this.lastActivity = Date.now();
  }

  /** @returns {number} session age in ms */
  get age() {
    return Date.now() - this.createdAt;
  }

  /** @returns {number} idle time in ms */
  get idle() {
    return Date.now() - this.lastActivity;
  }

  /**
   * Register a pending outbound request
   * @param {string|number} id
   * @param {Function} resolve
   * @param {Function} reject
   * @param {number} [timeoutMs=30000]
   */
  registerPending(id, resolve, reject, timeoutMs = 30000) {
    const timer = setTimeout(() => {
      this._pending.delete(id);
      reject(new Error(`Request ${id} timed out after ${timeoutMs}ms`));
    }, timeoutMs);
    this._pending.set(id, { resolve, reject, timer });
  }

  /**
   * Resolve or reject a pending request by id
   * @param {string|number} id
   * @param {*} resultOrError
   * @param {boolean} [isError=false]
   */
  settlePending(id, resultOrError, isError = false) {
    const pending = this._pending.get(id);
    if (!pending) return;
    clearTimeout(pending.timer);
    this._pending.delete(id);
    if (isError) {
      pending.reject(resultOrError);
    } else {
      pending.resolve(resultOrError);
    }
  }

  /** Clean up all pending requests */
  clearPending(reason = 'Session closed') {
    for (const [id, { reject, timer }] of this._pending) {
      clearTimeout(timer);
      reject(new Error(reason));
      this._pending.delete(id);
    }
  }
}

// ─── Stdio Transport ──────────────────────────────────────────────────────────

/**
 * Stdio transport for MCP - reads newline-delimited JSON from stdin,
 * writes to stdout. Used for local tool integrations.
 */
export class StdioTransport extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {NodeJS.ReadableStream} [options.input=process.stdin]
   * @param {NodeJS.WritableStream} [options.output=process.stdout]
   */
  constructor(options = {}) {
    super();
    this._input = options.input ?? process.stdin;
    this._output = options.output ?? process.stdout;
    this._rl = null;
    this._started = false;
  }

  /** Start reading from input */
  start() {
    if (this._started) return;
    this._started = true;

    this._rl = readline.createInterface({
      input: this._input,
      terminal: false,
      crlfDelay: Infinity,
    });

    this._rl.on('line', (line) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      try {
        const msg = JSON.parse(trimmed);
        this.emit('message', msg);
      } catch (e) {
        this.emit('error', new SyntaxError(`Failed to parse JSON: ${e.message}`));
      }
    });

    this._rl.on('close', () => {
      this.emit('close');
    });

    this._rl.on('error', (err) => {
      this.emit('error', err);
    });
  }

  /**
   * Send a message over stdout
   * @param {object} msg
   */
  send(msg) {
    const line = JSON.stringify(msg) + '\n';
    this._output.write(line);
  }

  /** Close the transport */
  close() {
    if (this._rl) {
      this._rl.close();
      this._rl = null;
    }
    this._started = false;
  }
}

// ─── SSE Transport ────────────────────────────────────────────────────────────

/**
 * SSE (Server-Sent Events) transport for MCP.
 * Manages the SSE channel for server→client streaming and
 * accepts POST requests for client→server messages.
 */
export class SSETransport extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.keepAliveInterval=PHI*10000] - SSE keepalive ping ms
   */
  constructor(options = {}) {
    super();
    /** @type {Map<string, { res: object, sessionId: string }>} */
    this._clients = new Map();
    this._keepAliveInterval = options.keepAliveInterval ?? Math.floor(PHI * 10000);
    this._keepAliveTimer = null;
  }

  /**
   * Register an SSE response stream for a session
   * @param {string} sessionId
   * @param {object} res - Node http.ServerResponse
   */
  registerClient(sessionId, res) {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
      'Access-Control-Allow-Origin': '*',
    });

    // Send endpoint event so client knows where to POST messages
    res.write(`event: endpoint\ndata: /mcp/message?session=${sessionId}\n\n`);

    this._clients.set(sessionId, { res, sessionId });

    res.on('close', () => {
      this._clients.delete(sessionId);
      this.emit('clientDisconnected', sessionId);
    });

    if (!this._keepAliveTimer) {
      this._startKeepAlive();
    }
  }

  /**
   * Handle an incoming POST message for a session
   * @param {string} sessionId
   * @param {object} msg - parsed JSON-RPC message
   */
  receiveMessage(sessionId, msg) {
    this.emit('message', msg, sessionId);
  }

  /**
   * Send a message to a specific session via SSE
   * @param {string} sessionId
   * @param {object} msg
   */
  send(msg, sessionId) {
    const client = this._clients.get(sessionId);
    if (!client) {
      this.emit('error', new Error(`SSE client ${sessionId} not found`));
      return;
    }
    const data = JSON.stringify(msg);
    client.res.write(`data: ${data}\n\n`);
  }

  /**
   * Broadcast to all connected SSE clients
   * @param {object} msg
   */
  broadcast(msg) {
    const data = JSON.stringify(msg);
    for (const { res } of this._clients.values()) {
      res.write(`data: ${data}\n\n`);
    }
  }

  /** @private */
  _startKeepAlive() {
    this._keepAliveTimer = setInterval(() => {
      for (const { res } of this._clients.values()) {
        res.write(': ping\n\n');
      }
    }, this._keepAliveInterval);

    if (this._keepAliveTimer.unref) {
      this._keepAliveTimer.unref();
    }
  }

  /** Close all client connections */
  close() {
    if (this._keepAliveTimer) {
      clearInterval(this._keepAliveTimer);
      this._keepAliveTimer = null;
    }
    for (const { res } of this._clients.values()) {
      try { res.end(); } catch (_) {}
    }
    this._clients.clear();
  }

  /** @returns {number} number of connected clients */
  get clientCount() {
    return this._clients.size;
  }
}

// ─── MCP Server ───────────────────────────────────────────────────────────────

/**
 * Full MCP server implementation.
 * Supports stdio and SSE transports, tool registration, resource management,
 * session lifecycle, and capability negotiation.
 *
 * @example
 * const server = new MCPServer({ name: 'heady', version: '1.0.0' });
 * server.registerTool({ name: 'echo', description: '...', inputSchema: {...}, handler: async (p) => p });
 * server.start(); // stdio mode
 */
export class MCPServer extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {string} [options.name='heady-mcp']
   * @param {string} [options.version='1.0.0']
   * @param {MCPCapabilities} [options.capabilities]
   * @param {number} [options.sessionTimeout=PHI^8 * 1000] - session idle timeout ms
   */
  constructor(options = {}) {
    super();
    this._name = options.name ?? 'heady-mcp';
    this._version = options.version ?? '1.0.0';
    this._capabilities = options.capabilities ?? {
      tools: true,
      resources: true,
      prompts: true,
      logging: true,
    };

    /** @type {Map<string, MCPTool>} */
    this._tools = new Map();
    /** @type {Map<string, MCPResource>} */
    this._resources = new Map();
    /** @type {Map<string, { list: Function, get: Function }>} */
    this._prompts = new Map();
    /** @type {Map<string, MCPSession>} */
    this._sessions = new Map();

    // Session idle timeout: PHI^8 * 1000ms ≈ 46.98 seconds
    this._sessionTimeout = options.sessionTimeout ?? Math.floor(Math.pow(PHI, 8) * 1000);
    this._sessionCleanupTimer = null;

    /** @type {StdioTransport|null} */
    this._stdioTransport = null;
    /** @type {SSETransport|null} */
    this._sseTransport = null;

    this._logLevel = 'info';
  }

  // ── Tool Registration ──────────────────────────────────────────────────────

  /**
   * Register a tool handler
   * @param {MCPTool} tool
   */
  registerTool(tool) {
    if (!tool.name || typeof tool.handler !== 'function') {
      throw new TypeError('Tool requires name and handler');
    }
    this._tools.set(tool.name, {
      name: tool.name,
      description: tool.description ?? '',
      inputSchema: tool.inputSchema ?? { type: 'object', properties: {} },
      handler: tool.handler,
    });
    this.emit('toolRegistered', tool.name);
    return this;
  }

  /**
   * Unregister a tool
   * @param {string} name
   */
  unregisterTool(name) {
    const removed = this._tools.delete(name);
    if (removed) this.emit('toolUnregistered', name);
    return removed;
  }

  // ── Resource Registration ──────────────────────────────────────────────────

  /**
   * Register a resource
   * @param {MCPResource} resource
   */
  registerResource(resource) {
    if (!resource.uri || typeof resource.reader !== 'function') {
      throw new TypeError('Resource requires uri and reader');
    }
    this._resources.set(resource.uri, resource);
    this.emit('resourceRegistered', resource.uri);
    return this;
  }

  // ── Prompt Registration ────────────────────────────────────────────────────

  /**
   * Register a prompt
   * @param {string} name
   * @param {Function} listFn - () => [{ name, description, arguments }]
   * @param {Function} getFn - (name, args) => { messages }
   */
  registerPrompt(name, listFn, getFn) {
    this._prompts.set(name, { list: listFn, get: getFn });
    return this;
  }

  // ── Transport Management ───────────────────────────────────────────────────

  /**
   * Start the server in stdio mode
   * @param {object} [options] - passed to StdioTransport
   */
  startStdio(options = {}) {
    this._stdioTransport = new StdioTransport(options);
    const sessionId = randomUUID();
    const session = new MCPSession(sessionId, {
      serverCapabilities: this._capabilities,
    });
    this._sessions.set(sessionId, session);

    this._stdioTransport.on('message', (msg) => {
      this._handleMessage(msg, session, (response) => {
        this._stdioTransport.send(response);
      }).catch((err) => this.emit('error', err));
    });

    this._stdioTransport.on('close', () => {
      this._closeSession(sessionId);
      this.emit('close');
    });

    this._stdioTransport.on('error', (err) => this.emit('error', err));
    this._stdioTransport.start();
    this._startSessionCleanup();
    this.emit('started', { transport: 'stdio', sessionId });
    return this;
  }

  /**
   * Attach SSE transport (call after setting up HTTP routes)
   * @param {SSETransport} sseTransport
   */
  attachSSE(sseTransport) {
    this._sseTransport = sseTransport;

    sseTransport.on('message', (msg, sessionId) => {
      let session = this._sessions.get(sessionId);
      if (!session) {
        session = new MCPSession(sessionId, { serverCapabilities: this._capabilities });
        this._sessions.set(sessionId, session);
      }
      this._handleMessage(msg, session, (response) => {
        sseTransport.send(response, sessionId);
      }).catch((err) => this.emit('error', err));
    });

    sseTransport.on('clientDisconnected', (sessionId) => {
      this._closeSession(sessionId);
    });

    this._startSessionCleanup();
    return this;
  }

  // ── Message Handling ───────────────────────────────────────────────────────

  /**
   * Handle an incoming JSON-RPC message
   * @private
   * @param {*} rawMsg
   * @param {MCPSession} session
   * @param {Function} reply - (msg) => void
   */
  async _handleMessage(rawMsg, session, reply) {
    session.touch();

    // Validate
    const validation = validateMessage(rawMsg);
    if (!validation.valid) {
      reply(buildError(rawMsg?.id ?? null, JsonRpcError.INVALID_REQUEST, validation.error));
      return;
    }

    // Handle batch requests
    if (Array.isArray(rawMsg)) {
      const responses = await Promise.all(
        rawMsg.map((m) => this._processSingleMessage(m, session))
      );
      const filtered = responses.filter(Boolean);
      if (filtered.length > 0) reply(filtered);
      return;
    }

    const response = await this._processSingleMessage(rawMsg, session);
    if (response !== null) reply(response);
  }

  /**
   * Process a single JSON-RPC message
   * @private
   * @param {object} msg
   * @param {MCPSession} session
   * @returns {object|null} response (null for notifications)
   */
  async _processSingleMessage(msg, session) {
    const isRequest = 'id' in msg && 'method' in msg;
    const isNotification = !('id' in msg) && 'method' in msg;
    const isResponse = 'id' in msg && ('result' in msg || 'error' in msg);

    if (isResponse) {
      // Handle response to an outbound request we made
      if ('error' in msg) {
        const err = new Error(msg.error.message);
        err.code = msg.error.code;
        err.data = msg.error.data;
        session.settlePending(msg.id, err, true);
      } else {
        session.settlePending(msg.id, msg.result, false);
      }
      return null;
    }

    if (isNotification) {
      await this._handleNotification(msg, session);
      return null;
    }

    if (isRequest) {
      return await this._handleRequest(msg, session);
    }

    return buildError(msg.id ?? null, JsonRpcError.INVALID_REQUEST, 'Unrecognized message');
  }

  /**
   * @private
   * @param {object} msg
   * @param {MCPSession} session
   * @returns {object} JSON-RPC response
   */
  async _handleRequest(msg, session) {
    const { id, method, params } = msg;

    try {
      let result;
      switch (method) {
        case 'initialize':
          result = await this._handleInitialize(params, session);
          break;
        case 'ping':
          result = {};
          break;
        case 'tools/list':
          result = this._handleToolsList(params);
          break;
        case 'tools/call':
          result = await this._handleToolsCall(params, session);
          break;
        case 'resources/list':
          result = this._handleResourcesList(params);
          break;
        case 'resources/read':
          result = await this._handleResourcesRead(params);
          break;
        case 'resources/subscribe':
          result = await this._handleResourcesSubscribe(params, session);
          break;
        case 'prompts/list':
          result = this._handlePromptsList(params);
          break;
        case 'prompts/get':
          result = await this._handlePromptsGet(params);
          break;
        case 'logging/setLevel':
          result = this._handleLoggingSetLevel(params);
          break;
        case 'completion/complete':
          result = await this._handleCompletionComplete(params, session);
          break;
        default:
          return buildError(id, JsonRpcError.METHOD_NOT_FOUND, `Method not found: ${method}`);
      }
      return buildResponse(id, result);
    } catch (err) {
      const code = err.code ?? JsonRpcError.INTERNAL_ERROR;
      return buildError(id, code, err.message, err.data);
    }
  }

  /**
   * @private
   */
  async _handleNotification(msg, session) {
    const { method, params } = msg;
    switch (method) {
      case 'notifications/initialized':
        session.state = 'active';
        this.emit('sessionActive', session.id);
        break;
      case 'notifications/cancelled':
        // Client cancelled a request - log but don't act
        this.emit('requestCancelled', params?.requestId, session.id);
        break;
      case 'notifications/roots/list_changed':
        this.emit('rootsChanged', session.id);
        break;
      default:
        this.emit('notification', method, params, session.id);
    }
  }

  // ── MCP Method Handlers ────────────────────────────────────────────────────

  /** @private */
  async _handleInitialize(params, session) {
    session.protocolVersion = params?.protocolVersion ?? '2024-11-05';
    session.clientCapabilities = params?.capabilities ?? {};
    session.clientInfo = params?.clientInfo ?? null;
    session.state = 'active';

    this.emit('sessionInitialized', session.id, session.clientInfo);

    return {
      protocolVersion: '2024-11-05',
      capabilities: this._buildCapabilitiesResponse(),
      serverInfo: {
        name: this._name,
        version: this._version,
      },
      instructions: `HeadyCore MCP Server v${this._version} - Zero-dependency implementation. Sacred Geometry principles apply.`,
    };
  }

  /** @private */
  _buildCapabilitiesResponse() {
    const caps = {};
    if (this._capabilities.tools && this._tools.size > 0) {
      caps.tools = { listChanged: true };
    }
    if (this._capabilities.resources && this._resources.size > 0) {
      caps.resources = { subscribe: true, listChanged: true };
    }
    if (this._capabilities.prompts && this._prompts.size > 0) {
      caps.prompts = { listChanged: true };
    }
    if (this._capabilities.logging) {
      caps.logging = {};
    }
    return caps;
  }

  /** @private */
  _handleToolsList(params) {
    const cursor = params?.cursor;
    const tools = [...this._tools.values()].map(({ name, description, inputSchema }) => ({
      name,
      description,
      inputSchema,
    }));

    // PHI-paginated: page size = Fibonacci[8] = 21
    const pageSize = FIBONACCI[8]; // 21
    const startIdx = cursor ? parseInt(cursor, 10) : 0;
    const page = tools.slice(startIdx, startIdx + pageSize);
    const nextCursor = startIdx + pageSize < tools.length
      ? String(startIdx + pageSize)
      : undefined;

    return {
      tools: page,
      ...(nextCursor ? { nextCursor } : {}),
    };
  }

  /** @private */
  async _handleToolsCall(params, session) {
    const { name, arguments: args } = params ?? {};
    const tool = this._tools.get(name);
    if (!tool) {
      const err = new Error(`Tool not found: ${name}`);
      err.code = JsonRpcError.TOOL_NOT_FOUND;
      throw err;
    }

    this.emit('toolCall', name, args, session.id);

    try {
      const result = await tool.handler(args ?? {});

      // Normalize result to MCP content format
      const content = this._normalizeToolResult(result);
      return { content, isError: false };
    } catch (err) {
      this.emit('toolError', name, err, session.id);
      return {
        content: [{ type: 'text', text: `Tool error: ${err.message}` }],
        isError: true,
      };
    }
  }

  /** @private */
  _normalizeToolResult(result) {
    if (Array.isArray(result)) {
      // Already content array
      if (result[0]?.type) return result;
      return [{ type: 'text', text: JSON.stringify(result) }];
    }
    if (typeof result === 'string') {
      return [{ type: 'text', text: result }];
    }
    if (result?.type && result?.text) {
      return [result];
    }
    return [{ type: 'text', text: JSON.stringify(result) }];
  }

  /** @private */
  _handleResourcesList(params) {
    const resources = [...this._resources.values()].map(
      ({ uri, name, mimeType, description }) => ({
        uri,
        name,
        ...(mimeType ? { mimeType } : {}),
        ...(description ? { description } : {}),
      })
    );

    const pageSize = FIBONACCI[8]; // 21
    const cursor = params?.cursor;
    const startIdx = cursor ? parseInt(cursor, 10) : 0;
    const page = resources.slice(startIdx, startIdx + pageSize);
    const nextCursor = startIdx + pageSize < resources.length
      ? String(startIdx + pageSize)
      : undefined;

    return {
      resources: page,
      ...(nextCursor ? { nextCursor } : {}),
    };
  }

  /** @private */
  async _handleResourcesRead(params) {
    const { uri } = params ?? {};
    const resource = this._resources.get(uri);
    if (!resource) {
      const err = new Error(`Resource not found: ${uri}`);
      err.code = JsonRpcError.RESOURCE_NOT_FOUND;
      throw err;
    }
    const contents = await resource.reader(uri, params);
    return { contents: Array.isArray(contents) ? contents : [contents] };
  }

  /** @private */
  async _handleResourcesSubscribe(params, session) {
    const { uri } = params ?? {};
    if (!this._resources.has(uri)) {
      const err = new Error(`Resource not found: ${uri}`);
      err.code = JsonRpcError.RESOURCE_NOT_FOUND;
      throw err;
    }
    this.emit('resourceSubscribed', uri, session.id);
    return {};
  }

  /** @private */
  _handlePromptsList() {
    const prompts = [];
    for (const [name, { list }] of this._prompts) {
      prompts.push(...list());
    }
    return { prompts };
  }

  /** @private */
  async _handlePromptsGet(params) {
    const { name, arguments: args } = params ?? {};
    const prompt = this._prompts.get(name);
    if (!prompt) {
      const err = new Error(`Prompt not found: ${name}`);
      err.code = JsonRpcError.METHOD_NOT_FOUND;
      throw err;
    }
    return await prompt.get(name, args);
  }

  /** @private */
  _handleLoggingSetLevel(params) {
    const { level } = params ?? {};
    const valid = ['debug', 'info', 'notice', 'warning', 'error', 'critical', 'alert', 'emergency'];
    if (!valid.includes(level)) {
      throw Object.assign(new Error(`Invalid log level: ${level}`), { code: JsonRpcError.INVALID_PARAMS });
    }
    this._logLevel = level;
    this.emit('logLevelChanged', level);
    return {};
  }

  /** @private */
  async _handleCompletionComplete(params, session) {
    // Basic completion - emit for external handler
    return new Promise((resolve, reject) => {
      this.emit('completionRequest', params, session.id, resolve, reject);
      // Default: empty completion
      setTimeout(() => resolve({ completion: { values: [], total: 0, hasMore: false } }), 0);
    });
  }

  // ── Notification Sending ───────────────────────────────────────────────────

  /**
   * Send a notification to a session or broadcast
   * @param {string} method
   * @param {*} [params]
   * @param {string} [sessionId] - if omitted, broadcast to all SSE clients
   */
  notify(method, params, sessionId) {
    const msg = buildNotification(method, params);
    if (sessionId) {
      if (this._sseTransport) {
        this._sseTransport.send(msg, sessionId);
      } else if (this._stdioTransport) {
        this._stdioTransport.send(msg);
      }
    } else {
      if (this._sseTransport) {
        this._sseTransport.broadcast(msg);
      } else if (this._stdioTransport) {
        this._stdioTransport.send(msg);
      }
    }
  }

  /**
   * Send a log message notification
   * @param {'debug'|'info'|'warning'|'error'} level
   * @param {string} message
   * @param {*} [data]
   * @param {string} [sessionId]
   */
  log(level, message, data, sessionId) {
    this.notify('notifications/message', { level, logger: this._name, data: { message, ...data } }, sessionId);
  }

  // ── Session Management ─────────────────────────────────────────────────────

  /**
   * @private
   */
  _closeSession(sessionId) {
    const session = this._sessions.get(sessionId);
    if (!session) return;
    session.state = 'closed';
    session.clearPending();
    this._sessions.delete(sessionId);
    this.emit('sessionClosed', sessionId);
  }

  /**
   * Get an active session by ID
   * @param {string} sessionId
   * @returns {MCPSession|undefined}
   */
  getSession(sessionId) {
    return this._sessions.get(sessionId);
  }

  /** @returns {number} number of active sessions */
  get sessionCount() {
    return this._sessions.size;
  }

  /** @private */
  _startSessionCleanup() {
    if (this._sessionCleanupTimer) return;
    // Run cleanup every Fibonacci[7]=13 seconds
    const interval = FIBONACCI[7] * 1000;
    this._sessionCleanupTimer = setInterval(() => {
      const now = Date.now();
      for (const [id, session] of this._sessions) {
        if (session.idle > this._sessionTimeout) {
          this._closeSession(id);
        }
      }
    }, interval);
    if (this._sessionCleanupTimer.unref) {
      this._sessionCleanupTimer.unref();
    }
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  /** Shut down the server gracefully */
  async shutdown() {
    if (this._sessionCleanupTimer) {
      clearInterval(this._sessionCleanupTimer);
      this._sessionCleanupTimer = null;
    }
    // Close all sessions (LIFO order)
    const sessionIds = [...this._sessions.keys()].reverse();
    for (const id of sessionIds) {
      this._closeSession(id);
    }
    if (this._stdioTransport) {
      this._stdioTransport.close();
    }
    if (this._sseTransport) {
      this._sseTransport.close();
    }
    this.emit('shutdown');
  }
}

// ─── MCP Client ───────────────────────────────────────────────────────────────

/**
 * MCP client implementation for connecting to MCP servers.
 * Supports stdio transport with PHI-scaled reconnection.
 */
export class MCPClient extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {string} [options.name='heady-client']
   * @param {string} [options.version='1.0.0']
   * @param {number} [options.requestTimeout=30000]
   */
  constructor(options = {}) {
    super();
    this._name = options.name ?? 'heady-client';
    this._version = options.version ?? '1.0.0';
    this._requestTimeout = options.requestTimeout ?? 30000;
    /** @type {MCPSession|null} */
    this._session = null;
    /** @type {StdioTransport|SSETransport|null} */
    this._transport = null;
    this._reconnectAttempts = 0;
    this._serverCapabilities = null;
    this._serverInfo = null;
  }

  /**
   * Connect using a stdio transport
   * @param {StdioTransport} transport
   */
  async connectStdio(transport) {
    this._transport = transport;
    this._session = new MCPSession(randomUUID());

    transport.on('message', (msg) => {
      this._handleIncoming(msg);
    });

    transport.on('close', () => {
      this.emit('disconnected');
    });

    transport.on('error', (err) => this.emit('error', err));
    transport.start();

    return await this._initialize();
  }

  /** @private */
  async _initialize() {
    const result = await this._request('initialize', {
      protocolVersion: '2024-11-05',
      capabilities: { tools: {}, resources: {}, prompts: {} },
      clientInfo: { name: this._name, version: this._version },
    });

    this._serverCapabilities = result.capabilities;
    this._serverInfo = result.serverInfo;
    this._session.state = 'active';

    this._send(buildNotification('notifications/initialized'));
    this.emit('connected', result.serverInfo);
    return result;
  }

  /** @private */
  _handleIncoming(msg) {
    if (!this._session) return;
    if ('id' in msg && ('result' in msg || 'error' in msg)) {
      if ('error' in msg) {
        const err = new Error(msg.error.message);
        err.code = msg.error.code;
        this._session.settlePending(msg.id, err, true);
      } else {
        this._session.settlePending(msg.id, msg.result, false);
      }
    } else if ('method' in msg) {
      this.emit('notification', msg.method, msg.params);
    }
  }

  /** @private */
  _send(msg) {
    if (!this._transport) throw new Error('Not connected');
    this._transport.send(msg);
  }

  /**
   * Send a request and await response
   * @param {string} method
   * @param {*} [params]
   * @returns {Promise<*>}
   */
  _request(method, params) {
    return new Promise((resolve, reject) => {
      if (!this._session) {
        reject(new Error('Not connected'));
        return;
      }
      const msg = buildRequest(method, params);
      this._session.registerPending(msg.id, resolve, reject, this._requestTimeout);
      this._send(msg);
    });
  }

  /** List available tools */
  async listTools(cursor) {
    return this._request('tools/list', cursor ? { cursor } : undefined);
  }

  /**
   * Call a tool
   * @param {string} name
   * @param {object} [args]
   */
  async callTool(name, args) {
    return this._request('tools/call', { name, arguments: args });
  }

  /** List resources */
  async listResources(cursor) {
    return this._request('resources/list', cursor ? { cursor } : undefined);
  }

  /**
   * Read a resource
   * @param {string} uri
   */
  async readResource(uri) {
    return this._request('resources/read', { uri });
  }

  /** List prompts */
  async listPrompts() {
    return this._request('prompts/list');
  }

  /**
   * Get a prompt
   * @param {string} name
   * @param {object} [args]
   */
  async getPrompt(name, args) {
    return this._request('prompts/get', { name, arguments: args });
  }

  /** Disconnect */
  async disconnect() {
    if (this._session) {
      this._session.clearPending('Client disconnected');
      this._session.state = 'closed';
    }
    if (this._transport) {
      this._transport.close();
    }
    this.emit('disconnected');
  }
}

// ─── Message Codec ────────────────────────────────────────────────────────────

/**
 * Streaming message codec for length-prefixed JSON-RPC
 * (alternative to newline-delimited for binary channels)
 */
export class MessageCodec extends Transform {
  constructor() {
    super({ readableObjectMode: true });
    this._buf = Buffer.alloc(0);
  }

  _transform(chunk, _enc, cb) {
    this._buf = Buffer.concat([this._buf, chunk]);
    this._drain();
    cb();
  }

  _drain() {
    while (this._buf.length >= 4) {
      const len = this._buf.readUInt32BE(0);
      if (this._buf.length < 4 + len) break;
      const json = this._buf.subarray(4, 4 + len).toString('utf8');
      this._buf = this._buf.subarray(4 + len);
      try {
        this.push(JSON.parse(json));
      } catch (_) {}
    }
  }

  /**
   * Encode a message to length-prefixed buffer
   * @param {object} msg
   * @returns {Buffer}
   */
  static encode(msg) {
    const json = Buffer.from(JSON.stringify(msg), 'utf8');
    const len = Buffer.allocUnsafe(4);
    len.writeUInt32BE(json.length, 0);
    return Buffer.concat([len, json]);
  }
}

// ─── Standalone PHI / helpers (already const-exported above, repeat for clarity) ─
export { PHI, FIBONACCI, phiBackoff };

// ─── Default Export ───────────────────────────────────────────────────────────

export default {
  MCPServer,
  MCPClient,
  MCPSession,
  StdioTransport,
  SSETransport,
  MessageCodec,
  buildRequest,
  buildResponse,
  buildError,
  buildNotification,
  validateMessage,
  JsonRpcError,
  MsgType,
  PHI,
  FIBONACCI,
  phiBackoff,
};
