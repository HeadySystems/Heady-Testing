/**
 * @file process-manager.js
 * @description Process lifecycle management for HeadyCore.
 *
 * Replaces PM2 / Docker process management for the 3-Colab cluster.
 * Features:
 * - Spawn and manage child processes with stdio/IPC
 * - Graceful shutdown with LIFO (last-in, first-out) cleanup order
 * - Health monitoring with PHI-scaled heartbeat intervals
 * - Auto-restart with circuit breaker pattern
 * - Resource tracking (CPU, memory) via /proc or Node process APIs
 * - Worker thread pool support
 *
 * Sacred Geometry: PHI-based intervals, Fibonacci retry sequences.
 * Zero external dependencies (child_process, os, fs, events, worker_threads).
 *
 * @module HeadyCore/ProcessManager
 */

import { spawn, fork, execFile } from 'child_process';
import { EventEmitter } from 'events';
import { Worker } from 'worker_threads';
import os from 'os';
import fs from 'fs';
import path from 'path';
import { randomBytes } from 'crypto';

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI = 1.6180339887498948482;
const FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610];

/**
 * PHI^n * base delay for backoff
 * @param {number} n - attempt index
 * @param {number} [base=1000]
 * @returns {number} ms
 */
function phiBackoff(n, base = 1000) {
  return Math.floor(base * Math.pow(PHI, Math.min(n, 12)));
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ─── Circuit Breaker ──────────────────────────────────────────────────────────

/**
 * Circuit breaker states
 * @enum {string}
 */
export const CircuitState = Object.freeze({
  CLOSED: 'closed',     // Normal operation
  OPEN: 'open',         // Failing - reject all requests
  HALF_OPEN: 'half_open', // Testing - allow limited requests
});

/**
 * Circuit breaker for process restart management.
 * Prevents restart loops by opening the circuit after too many failures.
 */
export class CircuitBreaker extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.threshold=FIBONACCI[4]=5] - failures before opening
   * @param {number} [options.resetTimeout] - ms before trying half-open; PHI^6*1000
   * @param {number} [options.successThreshold=FIBONACCI[2]=2] - successes in half-open to close
   */
  constructor(options = {}) {
    super();
    this._threshold = options.threshold ?? FIBONACCI[4]; // 5
    this._resetTimeout = options.resetTimeout ?? Math.floor(Math.pow(PHI, 6) * 1000); // ~17.9s
    this._successThreshold = options.successThreshold ?? FIBONACCI[2]; // 2

    this._state = CircuitState.CLOSED;
    this._failures = 0;
    this._successes = 0;
    this._nextAttempt = 0;
    this._openedAt = 0;
  }

  /** @returns {string} current state */
  get state() { return this._state; }

  /** @returns {boolean} */
  get isOpen() { return this._state === CircuitState.OPEN; }

  /** @returns {boolean} whether a request should be allowed through */
  get canAttempt() {
    if (this._state === CircuitState.CLOSED) return true;
    if (this._state === CircuitState.OPEN) {
      if (Date.now() >= this._nextAttempt) {
        this._state = CircuitState.HALF_OPEN;
        this._successes = 0;
        this.emit('halfOpen');
        return true;
      }
      return false;
    }
    // HALF_OPEN: allow one at a time
    return true;
  }

  /**
   * Record a successful operation
   */
  success() {
    this._failures = 0;
    if (this._state === CircuitState.HALF_OPEN) {
      this._successes++;
      if (this._successes >= this._successThreshold) {
        this._state = CircuitState.CLOSED;
        this._successes = 0;
        this.emit('closed');
      }
    }
  }

  /**
   * Record a failed operation
   */
  failure() {
    this._failures++;
    if (this._state === CircuitState.HALF_OPEN || this._failures >= this._threshold) {
      this._state = CircuitState.OPEN;
      this._openedAt = Date.now();
      // PHI-scaled reset timeout grows with each opening
      this._nextAttempt = Date.now() + this._resetTimeout;
      this.emit('open', { failures: this._failures });
    }
  }

  /** Force-reset the circuit breaker */
  reset() {
    this._state = CircuitState.CLOSED;
    this._failures = 0;
    this._successes = 0;
    this._nextAttempt = 0;
    this.emit('reset');
  }

  /** @returns {object} circuit breaker status */
  get status() {
    return {
      state: this._state,
      failures: this._failures,
      successes: this._successes,
      openedAt: this._openedAt,
      nextAttempt: this._nextAttempt,
      msUntilRetry: Math.max(0, this._nextAttempt - Date.now()),
    };
  }
}

// ─── Resource Monitor ─────────────────────────────────────────────────────────

/**
 * Reads CPU and memory stats for a process from /proc (Linux) or via Node APIs.
 */
export class ResourceMonitor {
  /**
   * @param {number} pid
   */
  constructor(pid) {
    this.pid = pid;
    this._lastCpuStats = null;
    this._lastCpuTime = null;
  }

  /**
   * Read process stats from /proc/[pid]/stat (Linux)
   * @returns {Promise<{ cpu: number, memory: number }|null>}
   */
  async sample() {
    // On Linux: /proc/[pid]/statm for memory, /proc/[pid]/stat for CPU
    if (process.platform === 'linux') {
      try {
        const statm = await fs.promises.readFile(`/proc/${this.pid}/statm`, 'utf8');
        const [pages] = statm.trim().split(' ');
        const pageSize = 4096; // typical Linux page size
        const memory = parseInt(pages, 10) * pageSize;

        const stat = await fs.promises.readFile(`/proc/${this.pid}/stat`, 'utf8');
        const fields = stat.trim().split(' ');
        const utime = parseInt(fields[13], 10);
        const stime = parseInt(fields[14], 10);
        const totalTicks = utime + stime;
        const now = Date.now();

        let cpuPercent = 0;
        if (this._lastCpuStats !== null && this._lastCpuTime !== null) {
          const tickDiff = totalTicks - this._lastCpuStats;
          const timeDiff = (now - this._lastCpuTime) / 1000; // seconds
          const ticksPerSec = os.cpus().length * 100; // HZ=100 typical
          cpuPercent = timeDiff > 0 ? (tickDiff / (ticksPerSec * timeDiff)) * 100 : 0;
        }

        this._lastCpuStats = totalTicks;
        this._lastCpuTime = now;

        return { cpu: cpuPercent, memory };
      } catch (_) {
        return null;
      }
    }
    // Fallback: process-level stats (only works for current process)
    if (this.pid === process.pid) {
      const mem = process.memoryUsage();
      return { cpu: 0, memory: mem.rss };
    }
    return null;
  }
}

// ─── Managed Process ──────────────────────────────────────────────────────────

/**
 * @typedef {object} ProcessSpec
 * @property {string} name - unique identifier
 * @property {string} command - executable
 * @property {string[]} [args=[]]
 * @property {object} [env] - additional env vars
 * @property {string} [cwd] - working directory
 * @property {number} [maxRestarts=FIBONACCI[4]=5]
 * @property {boolean} [autoRestart=true]
 * @property {number} [restartDelay] - base ms; PHI-scaled per attempt
 * @property {number} [healthCheckInterval] - ms; default PHI^5*1000
 * @property {number} [killTimeout=5000] - ms before SIGKILL after SIGTERM
 * @property {boolean} [ipc=false] - use fork() with IPC channel
 * @property {string} [script] - Node.js script path (use fork instead of spawn)
 */

/**
 * @typedef {'starting'|'running'|'stopping'|'stopped'|'failed'|'crashed'} ProcessState
 */

/**
 * A single managed child process with health monitoring and auto-restart.
 */
export class ManagedProcess extends EventEmitter {
  /**
   * @param {ProcessSpec} spec
   */
  constructor(spec) {
    super();
    this.spec = spec;
    this.name = spec.name;
    this.id = randomBytes(4).toString('hex');

    /** @type {ProcessState} */
    this._state = 'stopped';
    /** @type {import('child_process').ChildProcess|null} */
    this._process = null;
    this._restartCount = 0;
    this._startTime = null;
    this._stopTime = null;
    this._circuit = new CircuitBreaker({
      threshold: spec.maxRestarts ?? FIBONACCI[4],
    });

    this._healthInterval = null;
    this._resourceMonitor = null;
    this._stdout = [];
    this._stderr = [];
    this._logMaxLines = FIBONACCI[9]; // 34 lines in-memory log

    const healthCheckMs = spec.healthCheckInterval ?? Math.floor(Math.pow(PHI, 5) * 1000);
    this._healthCheckInterval = healthCheckMs;
  }

  /** @returns {ProcessState} */
  get state() { return this._state; }

  /** @returns {number|null} */
  get pid() { return this._process?.pid ?? null; }

  /** @returns {number} seconds since start */
  get uptime() {
    return this._startTime ? (Date.now() - this._startTime) / 1000 : 0;
  }

  /** @returns {string[]} last N stdout lines */
  get stdout() { return [...this._stdout]; }

  /** @returns {string[]} last N stderr lines */
  get stderr() { return [...this._stderr]; }

  /**
   * Start the process
   * @returns {Promise<void>}
   */
  async start() {
    if (this._state === 'running' || this._state === 'starting') return;

    if (this._circuit.isOpen && !this._circuit.canAttempt) {
      const err = new Error(`Circuit breaker open for ${this.name}: too many failures`);
      err.circuit = this._circuit.status;
      throw err;
    }

    this._state = 'starting';
    this.emit('starting', { name: this.name });

    try {
      await this._spawn();
      this._state = 'running';
      this._startTime = Date.now();
      this._circuit.success();
      this._startHealthCheck();
      this.emit('started', { name: this.name, pid: this.pid });
    } catch (err) {
      this._state = 'failed';
      this._circuit.failure();
      this.emit('error', err);
      throw err;
    }
  }

  /**
   * Stop the process gracefully
   * @param {number} [timeoutMs] - default from spec.killTimeout
   * @returns {Promise<void>}
   */
  async stop(timeoutMs) {
    if (this._state === 'stopped' || this._state === 'stopping') return;

    this._state = 'stopping';
    this._stopHealthCheck();
    this.emit('stopping', { name: this.name });

    if (!this._process) {
      this._state = 'stopped';
      return;
    }

    const killTimeout = timeoutMs ?? this.spec.killTimeout ?? 5000;

    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        if (this._process) {
          this._process.kill('SIGKILL');
        }
        resolve();
      }, killTimeout);

      this._process.once('exit', () => {
        clearTimeout(timer);
        this._state = 'stopped';
        this._stopTime = Date.now();
        this._process = null;
        this.emit('stopped', { name: this.name });
        resolve();
      });

      try {
        this._process.kill('SIGTERM');
      } catch (_) {
        clearTimeout(timer);
        this._state = 'stopped';
        this._process = null;
        resolve();
      }
    });
  }

  /**
   * Restart the process
   * @returns {Promise<void>}
   */
  async restart() {
    await this.stop();
    await sleep(this.spec.restartDelay ?? 500);
    await this.start();
  }

  /**
   * Send a signal to the process
   * @param {string} signal
   */
  kill(signal = 'SIGTERM') {
    if (this._process) {
      this._process.kill(signal);
    }
  }

  /**
   * Send a message via IPC (requires ipc:true or fork mode)
   * @param {*} message
   */
  send(message) {
    if (this._process && this._process.send) {
      this._process.send(message);
    } else {
      throw new Error(`Process ${this.name} does not have an IPC channel`);
    }
  }

  /**
   * Get resource usage
   * @returns {Promise<{ cpu: number, memory: number }|null>}
   */
  async getResources() {
    if (!this._resourceMonitor) return null;
    return this._resourceMonitor.sample();
  }

  // ── Private ────────────────────────────────────────────────────────────────

  /** @private */
  async _spawn() {
    const { command, args = [], env = {}, cwd, ipc, script } = this.spec;

    const childEnv = { ...process.env, ...env };
    const options = {
      env: childEnv,
      cwd: cwd ?? process.cwd(),
      stdio: ipc ? ['pipe', 'pipe', 'pipe', 'ipc'] : ['pipe', 'pipe', 'pipe'],
    };

    const child = script
      ? fork(script, args, { ...options, execArgv: process.execArgv })
      : spawn(command, args, options);

    // Wire up stdout/stderr
    child.stdout?.on('data', (chunk) => {
      const line = chunk.toString().trim();
      this._stdout.push(line);
      if (this._stdout.length > this._logMaxLines) this._stdout.shift();
      this.emit('stdout', line);
    });

    child.stderr?.on('data', (chunk) => {
      const line = chunk.toString().trim();
      this._stderr.push(line);
      if (this._stderr.length > this._logMaxLines) this._stderr.shift();
      this.emit('stderr', line);
    });

    child.on('message', (msg) => {
      this.emit('message', msg);
    });

    child.on('error', (err) => {
      this.emit('error', err);
    });

    // Handle unexpected exit
    child.once('exit', (code, signal) => {
      if (this._state === 'stopping' || this._state === 'stopped') return;
      this._state = 'crashed';
      this._stopHealthCheck();
      this.emit('crash', { name: this.name, code, signal, restarts: this._restartCount });
      this._handleCrash();
    });

    // Wait for spawn to succeed
    await new Promise((resolve, reject) => {
      child.once('spawn', resolve);
      child.once('error', reject);
      // Fallback timeout: PHI^2*100ms
      setTimeout(resolve, Math.floor(Math.pow(PHI, 2) * 100));
    });

    this._process = child;
    this._resourceMonitor = new ResourceMonitor(child.pid);
  }

  /** @private */
  async _handleCrash() {
    this._restartCount++;
    this._circuit.failure();

    if (!this.spec.autoRestart) return;
    if (!this._circuit.canAttempt) {
      this._state = 'failed';
      this.emit('failed', { name: this.name, restarts: this._restartCount });
      return;
    }

    // PHI-scaled backoff between restarts
    const delay = phiBackoff(this._restartCount - 1, this.spec.restartDelay ?? 1000);
    this.emit('restarting', { name: this.name, attempt: this._restartCount, delay });
    await sleep(delay);

    try {
      await this.start();
    } catch (err) {
      this.emit('error', err);
    }
  }

  /** @private */
  _startHealthCheck() {
    if (this._healthInterval) return;
    this._healthInterval = setInterval(async () => {
      if (!this._process || this._state !== 'running') {
        this._stopHealthCheck();
        return;
      }

      // Check process is still alive
      try {
        process.kill(this._process.pid, 0); // Signal 0 = existence check
      } catch (_) {
        // Process no longer exists
        if (this._state === 'running') {
          this._state = 'crashed';
          this.emit('crash', { name: this.name, code: null, signal: null });
          this._handleCrash();
        }
        return;
      }

      // Sample resources
      const resources = await this.getResources();
      if (resources) {
        this.emit('heartbeat', { name: this.name, pid: this.pid, uptime: this.uptime, ...resources });
      } else {
        this.emit('heartbeat', { name: this.name, pid: this.pid, uptime: this.uptime });
      }
    }, this._healthCheckInterval);

    if (this._healthInterval.unref) this._healthInterval.unref();
  }

  /** @private */
  _stopHealthCheck() {
    if (this._healthInterval) {
      clearInterval(this._healthInterval);
      this._healthInterval = null;
    }
  }

  /** @returns {object} process status snapshot */
  get status() {
    return {
      name: this.name,
      id: this.id,
      state: this._state,
      pid: this.pid,
      restarts: this._restartCount,
      uptime: this.uptime,
      startTime: this._startTime,
      stopTime: this._stopTime,
      circuit: this._circuit.status,
      spec: {
        command: this.spec.command,
        args: this.spec.args,
        cwd: this.spec.cwd,
      },
    };
  }
}

// ─── Worker Thread Pool ───────────────────────────────────────────────────────

/**
 * @typedef {object} WorkerTask
 * @property {string} id
 * @property {*} data
 * @property {Function} resolve
 * @property {Function} reject
 * @property {number} timeout
 * @property {any} timer
 */

/**
 * Pool of Node.js Worker threads for CPU-bound tasks.
 * Uses Fibonacci-sized pool (default: FIBONACCI[5]=8 workers).
 */
export class WorkerPool extends EventEmitter {
  /**
   * @param {string} workerScript - path to worker_threads script
   * @param {object} [options]
   * @param {number} [options.size=FIBONACCI[5]] - pool size (default 8)
   * @param {number} [options.taskTimeout=30000]
   * @param {object} [options.workerData] - static data passed to workers
   */
  constructor(workerScript, options = {}) {
    super();
    this._script = workerScript;
    this._size = options.size ?? FIBONACCI[5]; // 8
    this._taskTimeout = options.taskTimeout ?? 30000;
    this._workerData = options.workerData ?? {};

    /** @type {Worker[]} */
    this._workers = [];
    /** @type {Map<Worker, WorkerTask|null>} */
    this._workerTasks = new Map();
    /** @type {WorkerTask[]} */
    this._queue = [];
    this._started = false;
  }

  /**
   * Initialize all workers in the pool
   * @returns {Promise<void>}
   */
  async start() {
    if (this._started) return;
    const promises = [];
    for (let i = 0; i < this._size; i++) {
      promises.push(this._createWorker());
    }
    await Promise.all(promises);
    this._started = true;
    this.emit('started', { size: this._size });
  }

  /**
   * Execute a task on an available worker
   * @param {*} data - task data passed to worker
   * @param {number} [timeoutMs]
   * @returns {Promise<*>}
   */
  run(data, timeoutMs) {
    return new Promise((resolve, reject) => {
      const task = {
        id: randomBytes(4).toString('hex'),
        data,
        resolve,
        reject,
        timeout: timeoutMs ?? this._taskTimeout,
        timer: null,
      };

      const idle = this._findIdleWorker();
      if (idle) {
        this._dispatch(idle, task);
      } else {
        this._queue.push(task);
      }
    });
  }

  /**
   * Terminate all workers
   * @returns {Promise<void>}
   */
  async stop() {
    // Drain queue with rejection
    for (const task of this._queue) {
      if (task.timer) clearTimeout(task.timer);
      task.reject(new Error('Worker pool stopped'));
    }
    this._queue = [];

    await Promise.all(this._workers.map((w) => w.terminate()));
    this._workers = [];
    this._workerTasks.clear();
    this._started = false;
  }

  /** @private */
  _createWorker() {
    return new Promise((resolve, reject) => {
      const worker = new Worker(this._script, {
        workerData: this._workerData,
      });

      worker.once('online', () => {
        this._workers.push(worker);
        this._workerTasks.set(worker, null);
        this._setupWorkerHandlers(worker);
        resolve(worker);
      });

      worker.once('error', reject);
    });
  }

  /** @private */
  _setupWorkerHandlers(worker) {
    worker.on('message', (result) => {
      const task = this._workerTasks.get(worker);
      if (!task) return;

      if (task.timer) clearTimeout(task.timer);
      this._workerTasks.set(worker, null);

      if (result?.error) {
        task.reject(new Error(result.error));
      } else {
        task.resolve(result?.data ?? result);
      }

      this._drainQueue(worker);
    });

    worker.on('error', (err) => {
      const task = this._workerTasks.get(worker);
      if (task) {
        if (task.timer) clearTimeout(task.timer);
        task.reject(err);
        this._workerTasks.set(worker, null);
      }
      // Replace failed worker
      this._workers = this._workers.filter((w) => w !== worker);
      this._workerTasks.delete(worker);
      this._createWorker().then((newWorker) => {
        this._drainQueue(newWorker);
      }).catch((e) => this.emit('error', e));
    });

    worker.on('exit', (code) => {
      if (code !== 0) {
        this.emit('workerExit', { code });
      }
    });
  }

  /** @private */
  _findIdleWorker() {
    for (const [worker, task] of this._workerTasks) {
      if (task === null) return worker;
    }
    return null;
  }

  /** @private */
  _dispatch(worker, task) {
    this._workerTasks.set(worker, task);
    task.timer = setTimeout(() => {
      this._workerTasks.set(worker, null);
      task.reject(new Error(`Worker task timed out after ${task.timeout}ms`));
    }, task.timeout);
    worker.postMessage(task.data);
  }

  /** @private */
  _drainQueue(worker) {
    if (this._queue.length > 0) {
      const next = this._queue.shift();
      this._dispatch(worker, next);
    }
  }

  /** @returns {number} number of queued tasks */
  get queueSize() { return this._queue.length; }

  /** @returns {number} idle worker count */
  get idleCount() {
    let count = 0;
    for (const task of this._workerTasks.values()) {
      if (task === null) count++;
    }
    return count;
  }
}

// ─── Process Manager ──────────────────────────────────────────────────────────

/**
 * Central process lifecycle manager for the HeadyCore cluster.
 * Manages a registry of named child processes with LIFO shutdown.
 *
 * @example
 * const pm = new ProcessManager();
 * pm.register({ name: 'brain', command: 'node', args: ['brain.js'], autoRestart: true });
 * await pm.startAll();
 * // on shutdown:
 * await pm.shutdown();
 */
export class ProcessManager extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.shutdownTimeout=10000]
   */
  constructor(options = {}) {
    super();
    /** @type {Map<string, ManagedProcess>} */
    this._processes = new Map();
    /** @type {string[]} startup order (for LIFO shutdown) */
    this._startOrder = [];
    this._shutdownTimeout = options.shutdownTimeout ?? 10000;
    this._shuttingDown = false;

    // Bind signal handlers
    this._onSIGTERM = () => this.shutdown().then(() => process.exit(0));
    this._onSIGINT = () => this.shutdown().then(() => process.exit(0));
  }

  /**
   * Register a process spec (does not start it yet)
   * @param {ProcessSpec} spec
   * @returns {ManagedProcess}
   */
  register(spec) {
    if (this._processes.has(spec.name)) {
      throw new Error(`Process ${spec.name} already registered`);
    }
    const managed = new ManagedProcess(spec);

    // Forward events
    managed.on('started', (e) => this.emit('processStarted', e));
    managed.on('stopped', (e) => this.emit('processStopped', e));
    managed.on('crash', (e) => this.emit('processCrash', e));
    managed.on('failed', (e) => this.emit('processFailed', e));
    managed.on('heartbeat', (e) => this.emit('heartbeat', e));
    managed.on('restarting', (e) => this.emit('processRestarting', e));
    managed.on('stdout', (line) => this.emit('stdout', { name: spec.name, line }));
    managed.on('stderr', (line) => this.emit('stderr', { name: spec.name, line }));

    this._processes.set(spec.name, managed);
    return managed;
  }

  /**
   * Unregister a process (stops it first if running)
   * @param {string} name
   */
  async unregister(name) {
    const proc = this._processes.get(name);
    if (!proc) return;
    if (proc.state === 'running') await proc.stop();
    this._processes.delete(name);
    this._startOrder = this._startOrder.filter((n) => n !== name);
  }

  /**
   * Start a specific process by name
   * @param {string} name
   * @returns {Promise<void>}
   */
  async start(name) {
    const proc = this._get(name);
    await proc.start();
    if (!this._startOrder.includes(name)) {
      this._startOrder.push(name);
    }
  }

  /**
   * Start all registered processes (in registration order)
   * @param {number} [delayBetween=0] - ms between starts
   * @returns {Promise<void>}
   */
  async startAll(delayBetween = 0) {
    for (const [name] of this._processes) {
      await this.start(name);
      if (delayBetween > 0) await sleep(delayBetween);
    }
  }

  /**
   * Stop a process by name
   * @param {string} name
   * @param {number} [timeoutMs]
   */
  async stop(name, timeoutMs) {
    const proc = this._get(name);
    await proc.stop(timeoutMs);
  }

  /**
   * Restart a process
   * @param {string} name
   */
  async restart(name) {
    const proc = this._get(name);
    await proc.restart();
  }

  /**
   * Graceful shutdown of all processes in LIFO order
   * @returns {Promise<void>}
   */
  async shutdown() {
    if (this._shuttingDown) return;
    this._shuttingDown = true;
    this.emit('shutdown:start');

    // LIFO: reverse startup order
    const order = [...this._startOrder].reverse();

    for (const name of order) {
      const proc = this._processes.get(name);
      if (!proc) continue;
      this.emit('shutdown:stopping', { name });
      try {
        await proc.stop(this._shutdownTimeout);
      } catch (err) {
        this.emit('error', err);
      }
    }

    this.emit('shutdown:complete');
  }

  /**
   * Register OS signal handlers for graceful shutdown
   * @returns {this}
   */
  handleSignals() {
    process.on('SIGTERM', this._onSIGTERM);
    process.on('SIGINT', this._onSIGINT);
    return this;
  }

  /**
   * Remove OS signal handlers
   * @returns {this}
   */
  removeSignalHandlers() {
    process.off('SIGTERM', this._onSIGTERM);
    process.off('SIGINT', this._onSIGINT);
    return this;
  }

  /**
   * Get a registered process
   * @param {string} name
   * @returns {ManagedProcess}
   */
  get(name) { return this._get(name); }

  /** @private */
  _get(name) {
    const proc = this._processes.get(name);
    if (!proc) throw new Error(`Process not found: ${name}`);
    return proc;
  }

  /**
   * Get status of all processes
   * @returns {object[]}
   */
  status() {
    return [...this._processes.values()].map((p) => p.status);
  }

  /**
   * Get system-level resource info
   * @returns {object}
   */
  systemInfo() {
    const mem = process.memoryUsage();
    return {
      platform: process.platform,
      arch: process.arch,
      nodeVersion: process.version,
      pid: process.pid,
      uptime: process.uptime(),
      cpuCount: os.cpus().length,
      totalMemory: os.totalmem(),
      freeMemory: os.freemem(),
      loadAvg: os.loadavg(),
      processMemory: mem,
      // PHI health: freeMemory / totalMemory ratio
      phiMemoryRatio: os.freemem() / os.totalmem(),
    };
  }

  /** @returns {number} number of registered processes */
  get size() { return this._processes.size; }

  /** @returns {number} number of running processes */
  get runningCount() {
    let count = 0;
    for (const p of this._processes.values()) {
      if (p.state === 'running') count++;
    }
    return count;
  }
}

// Named exports for direct destructuring
export { PHI, FIBONACCI, phiBackoff };

// ─── Default Export ───────────────────────────────────────────────────────────

export default {
  ProcessManager,
  ManagedProcess,
  WorkerPool,
  CircuitBreaker,
  ResourceMonitor,
  CircuitState,
  phiBackoff,
  PHI,
  FIBONACCI,
};
