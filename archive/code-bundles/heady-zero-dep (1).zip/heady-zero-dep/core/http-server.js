/**
 * @file http-server.js
 * @description Pure Node.js HTTP/WebSocket server for HeadyCore.
 *
 * Features:
 * - Route registration with layered middleware chain
 * - WebSocket upgrade handling per RFC 6455
 * - SSE streaming support
 * - CORS, gzip compression, JSON body parsing
 * - Health endpoints: /health, /ready, /pulse
 * - Zero external dependencies (http, https, zlib, crypto, stream, url, os)
 *
 * Sacred Geometry: PHI-based keep-alive timing, Fibonacci buffer sizes.
 *
 * @module HeadyCore/HTTPServer
 */

import http from 'http';
import https from 'https';
import { createHash, randomBytes } from 'crypto';
import { createGzip, createDeflate, createBrotliCompress } from 'zlib';
import { EventEmitter } from 'events';
import { Readable, pipeline } from 'stream';
import { promisify } from 'util';
import os from 'os';
import { URL } from 'url';

const pipelineAsync = promisify(pipeline);

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI = 1.6180339887498948482;
const FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610];

/** Server start time for uptime calculations */
const SERVER_BIRTH = Date.now();

// ─── Utility Helpers ──────────────────────────────────────────────────────────

/**
 * Parse query string from a URL path
 * @param {string} rawUrl
 * @returns {{ pathname: string, query: object }}
 */
function parseUrl(rawUrl) {
  try {
    const base = 'http://localhost';
    const u = new URL(rawUrl, base);
    const query = Object.fromEntries(u.searchParams.entries());
    return { pathname: u.pathname, query };
  } catch (_) {
    return { pathname: rawUrl, query: {} };
  }
}

/**
 * Match a route pattern (with :param support) against a pathname
 * @param {string} pattern - e.g. '/api/repos/:owner/:repo'
 * @param {string} pathname
 * @returns {{ matched: boolean, params: object }}
 */
function matchRoute(pattern, pathname) {
  const patternParts = pattern.split('/').filter(Boolean);
  const pathParts = pathname.split('/').filter(Boolean);

  if (patternParts.length !== pathParts.length) {
    // Check for wildcard suffix
    const wildcardIdx = patternParts.findIndex((p) => p === '*');
    if (wildcardIdx === -1) return { matched: false, params: {} };
    if (pathParts.length < wildcardIdx) return { matched: false, params: {} };
    // Match up to wildcard
    const params = {};
    for (let i = 0; i < wildcardIdx; i++) {
      if (patternParts[i].startsWith(':')) {
        params[patternParts[i].slice(1)] = decodeURIComponent(pathParts[i]);
      } else if (patternParts[i] !== pathParts[i]) {
        return { matched: false, params: {} };
      }
    }
    params['*'] = pathParts.slice(wildcardIdx).join('/');
    return { matched: true, params };
  }

  const params = {};
  for (let i = 0; i < patternParts.length; i++) {
    if (patternParts[i].startsWith(':')) {
      params[patternParts[i].slice(1)] = decodeURIComponent(pathParts[i]);
    } else if (patternParts[i] !== pathParts[i]) {
      return { matched: false, params: {} };
    }
  }
  return { matched: true, params };
}

// ─── Request / Response Augmentation ─────────────────────────────────────────

/**
 * Augment a Node IncomingMessage with parsed data
 * @param {http.IncomingMessage} req
 * @param {object} params - route params
 * @param {object} query - query params
 */
function augmentRequest(req, params, query) {
  req.params = params;
  req.query = query;
  req.body = null;
  req.id = randomBytes(8).toString('hex');
  req.startTime = Date.now();
}

/**
 * Augment ServerResponse with helper methods
 * @param {http.ServerResponse} res
 */
function augmentResponse(res) {
  /**
   * Send JSON response
   * @param {*} data
   * @param {number} [status=200]
   */
  res.json = function (data, status = 200) {
    if (res.headersSent) return;
    const body = JSON.stringify(data);
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': Buffer.byteLength(body),
    });
    res.end(body);
  };

  /**
   * Send text response
   * @param {string} text
   * @param {number} [status=200]
   */
  res.text = function (text, status = 200) {
    if (res.headersSent) return;
    const body = String(text);
    res.writeHead(status, {
      'Content-Type': 'text/plain; charset=utf-8',
      'Content-Length': Buffer.byteLength(body),
    });
    res.end(body);
  };

  /**
   * Send a redirect
   * @param {string} location
   * @param {number} [status=302]
   */
  res.redirect = function (location, status = 302) {
    if (res.headersSent) return;
    res.writeHead(status, { Location: location });
    res.end();
  };

  /**
   * Send an error response
   * @param {number} status
   * @param {string} message
   * @param {*} [details]
   */
  res.error = function (status, message, details) {
    res.json({ error: message, ...(details ? { details } : {}) }, status);
  };
}

// ─── Body Parser ──────────────────────────────────────────────────────────────

/**
 * Parse the request body as JSON or raw Buffer
 * @param {http.IncomingMessage} req
 * @param {number} [maxBytes=FIBONACCI[10]*1024] ~89KB
 * @returns {Promise<*>}
 */
async function parseBody(req, maxBytes = FIBONACCI[10] * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;

    req.on('data', (chunk) => {
      total += chunk.length;
      if (total > maxBytes) {
        req.destroy(new Error(`Request body exceeds limit: ${maxBytes} bytes`));
        reject(new Error('Request body too large'));
        return;
      }
      chunks.push(chunk);
    });

    req.on('end', () => {
      const buf = Buffer.concat(chunks);
      const contentType = req.headers['content-type'] ?? '';

      if (contentType.includes('application/json')) {
        try {
          resolve(JSON.parse(buf.toString('utf8')));
        } catch (e) {
          reject(new SyntaxError(`Invalid JSON body: ${e.message}`));
        }
      } else if (contentType.includes('application/x-www-form-urlencoded')) {
        const params = new URLSearchParams(buf.toString('utf8'));
        resolve(Object.fromEntries(params.entries()));
      } else {
        resolve(buf);
      }
    });

    req.on('error', reject);
  });
}

// ─── Middleware ────────────────────────────────────────────────────────────────

/**
 * CORS middleware
 * @param {object} [options]
 * @param {string|string[]} [options.origin='*']
 * @param {string} [options.methods='GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS']
 * @param {string} [options.headers='Content-Type,Authorization,X-Requested-With']
 * @param {number} [options.maxAge=86400]
 * @returns {Function} middleware
 */
export function cors(options = {}) {
  const {
    origin = '*',
    methods = 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    headers = 'Content-Type,Authorization,X-Requested-With,X-Session-ID',
    maxAge = 86400,
    credentials = false,
  } = options;

  return function corsMiddleware(req, res, next) {
    const originHeader = Array.isArray(origin) ? origin.join(',') : origin;
    res.setHeader('Access-Control-Allow-Origin', originHeader);
    res.setHeader('Access-Control-Allow-Methods', methods);
    res.setHeader('Access-Control-Allow-Headers', headers);
    res.setHeader('Access-Control-Max-Age', String(maxAge));
    if (credentials) res.setHeader('Access-Control-Allow-Credentials', 'true');

    if (req.method === 'OPTIONS') {
      res.writeHead(204);
      res.end();
      return;
    }
    next();
  };
}

/**
 * JSON body parser middleware
 * @param {object} [options]
 * @param {number} [options.limit] - max body bytes
 * @returns {Function}
 */
export function bodyParser(options = {}) {
  return async function bodyParserMiddleware(req, res, next) {
    const method = req.method?.toUpperCase();
    if (method === 'GET' || method === 'HEAD' || method === 'DELETE') {
      return next();
    }
    const contentType = req.headers['content-type'] ?? '';
    if (!contentType) return next();
    try {
      req.body = await parseBody(req, options.limit);
      next();
    } catch (err) {
      res.error(400, err.message);
    }
  };
}

/**
 * Request logger middleware
 * @param {object} [options]
 * @param {Function} [options.logger=console.log]
 * @returns {Function}
 */
export function requestLogger(options = {}) {
  const log = options.logger ?? console.log;
  return function loggerMiddleware(req, res, next) {
    const start = Date.now();
    res.on('finish', () => {
      const ms = Date.now() - start;
      log(`[HTTP] ${req.method} ${req.url} ${res.statusCode} ${ms}ms`);
    });
    next();
  };
}

/**
 * Compression middleware (gzip / deflate / br)
 * @returns {Function}
 */
export function compression() {
  return function compressionMiddleware(req, res, next) {
    const acceptEncoding = req.headers['accept-encoding'] ?? '';
    const originalWrite = res.write.bind(res);
    const originalEnd = res.end.bind(res);

    let encoder = null;
    let encoding = null;

    if (acceptEncoding.includes('br')) {
      encoder = createBrotliCompress();
      encoding = 'br';
    } else if (acceptEncoding.includes('gzip')) {
      encoder = createGzip();
      encoding = 'gzip';
    } else if (acceptEncoding.includes('deflate')) {
      encoder = createDeflate();
      encoding = 'deflate';
    }

    if (!encoder) return next();

    res.setHeader('Content-Encoding', encoding);
    res.removeHeader('Content-Length');

    // Buffer compressed chunks
    const compressed = [];
    encoder.on('data', (chunk) => compressed.push(chunk));

    res.write = function (chunk, enc, cb) {
      encoder.write(chunk, enc);
      if (typeof enc === 'function') enc();
      if (typeof cb === 'function') cb();
      return true;
    };

    res.end = function (chunk, enc, cb) {
      if (chunk) encoder.write(chunk, enc);
      encoder.end();
      encoder.on('end', () => {
        const buf = Buffer.concat(compressed);
        res.write = originalWrite;
        res.end = originalEnd;
        originalEnd(buf, cb);
      });
    };

    next();
  };
}

// ─── WebSocket ────────────────────────────────────────────────────────────────

/** RFC 6455 WebSocket magic GUID */
const WS_MAGIC = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

/**
 * Compute the WebSocket handshake accept key
 * @param {string} clientKey
 * @returns {string} base64 SHA-1
 */
function wsAcceptKey(clientKey) {
  return createHash('sha1').update(clientKey + WS_MAGIC).digest('base64');
}

/**
 * WebSocket frame opcodes
 * @enum {number}
 */
const WS_OPCODE = Object.freeze({
  CONTINUATION: 0x0,
  TEXT: 0x1,
  BINARY: 0x2,
  CLOSE: 0x8,
  PING: 0x9,
  PONG: 0xA,
});

/**
 * Build a WebSocket frame
 * @param {number} opcode
 * @param {Buffer|string} data
 * @param {boolean} [fin=true]
 * @returns {Buffer}
 */
function buildWSFrame(opcode, data, fin = true) {
  const payload = typeof data === 'string' ? Buffer.from(data, 'utf8') : data;
  const len = payload.length;

  let headerLen = 2;
  if (len > 125 && len <= 65535) headerLen += 2;
  else if (len > 65535) headerLen += 8;

  const header = Buffer.allocUnsafe(headerLen);
  header[0] = (fin ? 0x80 : 0x00) | (opcode & 0x0f);

  if (len <= 125) {
    header[1] = len;
  } else if (len <= 65535) {
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }

  return Buffer.concat([header, payload]);
}

/**
 * WebSocket connection wrapper
 */
export class WebSocket extends EventEmitter {
  /**
   * @param {import('net').Socket} socket
   * @param {http.IncomingMessage} req
   */
  constructor(socket, req) {
    super();
    this.socket = socket;
    this.req = req;
    this.id = randomBytes(8).toString('hex');
    this._readyState = 1; // OPEN
    this._buf = Buffer.alloc(0);
    this._pingTimer = null;
    this._pongTimeout = null;

    socket.on('data', (chunk) => this._onData(chunk));
    socket.on('close', () => this._onSocketClose());
    socket.on('error', (err) => this.emit('error', err));

    // PHI-scaled ping interval: PHI^5 * 1000ms ≈ 11.09s
    const pingInterval = Math.floor(Math.pow(PHI, 5) * 1000);
    this._startPing(pingInterval);
  }

  /** @returns {'CONNECTING'|'OPEN'|'CLOSING'|'CLOSED'} */
  get readyState() {
    const states = ['CONNECTING', 'OPEN', 'CLOSING', 'CLOSED'];
    return states[this._readyState] ?? 'CLOSED';
  }

  /**
   * Send data to the client
   * @param {string|Buffer} data
   * @param {boolean} [binary=false]
   */
  send(data, binary = false) {
    if (this._readyState !== 1) return;
    const opcode = binary ? WS_OPCODE.BINARY : WS_OPCODE.TEXT;
    const frame = buildWSFrame(opcode, data);
    this.socket.write(frame);
  }

  /**
   * Send a JSON-serialized message
   * @param {*} obj
   */
  sendJSON(obj) {
    this.send(JSON.stringify(obj));
  }

  /**
   * Close the connection
   * @param {number} [code=1000]
   * @param {string} [reason='']
   */
  close(code = 1000, reason = '') {
    if (this._readyState >= 2) return;
    this._readyState = 2; // CLOSING
    const codeBuffer = Buffer.allocUnsafe(2);
    codeBuffer.writeUInt16BE(code, 0);
    const payload = reason
      ? Buffer.concat([codeBuffer, Buffer.from(reason, 'utf8')])
      : codeBuffer;
    this.socket.write(buildWSFrame(WS_OPCODE.CLOSE, payload));
    this.socket.end();
  }

  /** @private */
  _onData(chunk) {
    this._buf = Buffer.concat([this._buf, chunk]);
    this._parseFrames();
  }

  /** @private */
  _parseFrames() {
    while (this._buf.length >= 2) {
      const fin = (this._buf[0] & 0x80) !== 0;
      const opcode = this._buf[0] & 0x0f;
      const masked = (this._buf[1] & 0x80) !== 0;
      let payloadLen = this._buf[1] & 0x7f;
      let offset = 2;

      if (payloadLen === 126) {
        if (this._buf.length < 4) break;
        payloadLen = this._buf.readUInt16BE(2);
        offset = 4;
      } else if (payloadLen === 127) {
        if (this._buf.length < 10) break;
        payloadLen = Number(this._buf.readBigUInt64BE(2));
        offset = 10;
      }

      const maskLen = masked ? 4 : 0;
      if (this._buf.length < offset + maskLen + payloadLen) break;

      let payload = this._buf.subarray(offset + maskLen, offset + maskLen + payloadLen);

      if (masked) {
        const mask = this._buf.subarray(offset, offset + 4);
        const unmasked = Buffer.allocUnsafe(payloadLen);
        for (let i = 0; i < payloadLen; i++) {
          unmasked[i] = payload[i] ^ mask[i % 4];
        }
        payload = unmasked;
      }

      this._buf = this._buf.subarray(offset + maskLen + payloadLen);
      this._handleFrame(opcode, payload, fin);
    }
  }

  /** @private */
  _handleFrame(opcode, payload, fin) {
    switch (opcode) {
      case WS_OPCODE.TEXT:
        const text = payload.toString('utf8');
        this.emit('message', text, false);
        try {
          const obj = JSON.parse(text);
          this.emit('json', obj);
        } catch (_) {}
        break;
      case WS_OPCODE.BINARY:
        this.emit('message', payload, true);
        break;
      case WS_OPCODE.PING:
        // Auto-pong
        this.socket.write(buildWSFrame(WS_OPCODE.PONG, payload));
        this.emit('ping', payload);
        break;
      case WS_OPCODE.PONG:
        if (this._pongTimeout) {
          clearTimeout(this._pongTimeout);
          this._pongTimeout = null;
        }
        this.emit('pong', payload);
        break;
      case WS_OPCODE.CLOSE:
        const code = payload.length >= 2 ? payload.readUInt16BE(0) : 1000;
        const reason = payload.length > 2 ? payload.subarray(2).toString('utf8') : '';
        this.emit('close', code, reason);
        this._readyState = 3; // CLOSED
        this.socket.end();
        break;
    }
  }

  /** @private */
  _startPing(interval) {
    this._pingTimer = setInterval(() => {
      if (this._readyState !== 1) {
        clearInterval(this._pingTimer);
        return;
      }
      const pingData = Buffer.from(Date.now().toString());
      this.socket.write(buildWSFrame(WS_OPCODE.PING, pingData));

      // Pong timeout: PHI^3 * 1000ms ≈ 4.24s
      this._pongTimeout = setTimeout(() => {
        this.close(1001, 'Pong timeout');
      }, Math.floor(Math.pow(PHI, 3) * 1000));
    }, interval);

    if (this._pingTimer.unref) this._pingTimer.unref();
  }

  /** @private */
  _onSocketClose() {
    if (this._pingTimer) clearInterval(this._pingTimer);
    if (this._pongTimeout) clearTimeout(this._pongTimeout);
    this._readyState = 3;
    this.emit('close', 1006, 'Socket closed');
  }
}

// ─── SSE Response ─────────────────────────────────────────────────────────────

/**
 * Server-Sent Events stream helper
 */
export class SSEStream extends EventEmitter {
  /**
   * @param {http.ServerResponse} res
   * @param {object} [options]
   * @param {number} [options.keepAliveMs] - ping interval ms, default PHI^4*1000
   */
  constructor(res, options = {}) {
    super();
    this.res = res;
    this.id = 0;
    this._closed = false;
    const keepAliveMs = options.keepAliveMs ?? Math.floor(Math.pow(PHI, 4) * 1000);

    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    });

    // Keep-alive ping
    this._timer = setInterval(() => {
      if (!this._closed) res.write(': ping\n\n');
    }, keepAliveMs);
    if (this._timer.unref) this._timer.unref();

    res.on('close', () => this._cleanup());
  }

  /**
   * Send an event
   * @param {string} event - event type
   * @param {*} data - will be JSON.stringified if not a string
   * @param {number|string} [id] - event id
   * @param {number} [retry] - reconnect delay ms
   */
  send(event, data, id, retry) {
    if (this._closed) return;
    const dataStr = typeof data === 'string' ? data : JSON.stringify(data);
    const eventId = id ?? ++this.id;
    let msg = '';
    if (retry !== undefined) msg += `retry: ${retry}\n`;
    msg += `id: ${eventId}\n`;
    msg += `event: ${event}\n`;
    // Multi-line data support
    for (const line of dataStr.split('\n')) {
      msg += `data: ${line}\n`;
    }
    msg += '\n';
    this.res.write(msg);
  }

  /**
   * Send a data-only event (no event name)
   * @param {*} data
   */
  emit_data(data) {
    if (this._closed) return;
    const dataStr = typeof data === 'string' ? data : JSON.stringify(data);
    this.res.write(`data: ${dataStr}\n\n`);
  }

  /** Close the SSE stream */
  close() {
    this._cleanup();
    this.res.end();
  }

  /** @private */
  _cleanup() {
    if (this._closed) return;
    this._closed = true;
    clearInterval(this._timer);
    this.emit('close');
  }

  /** @returns {boolean} */
  get closed() { return this._closed; }
}

// ─── Router ────────────────────────────────────────────────────────────────────

/**
 * @typedef {Function} MiddlewareFn
 * @param {http.IncomingMessage} req
 * @param {http.ServerResponse} res
 * @param {Function} next
 */

/**
 * @typedef {object} Route
 * @property {string} method - HTTP method or '*'
 * @property {string} pattern - URL pattern
 * @property {MiddlewareFn[]} handlers
 */

/**
 * Lightweight Express-style router
 */
export class Router {
  constructor() {
    /** @type {Route[]} */
    this._routes = [];
    /** @type {MiddlewareFn[]} */
    this._globalMiddleware = [];
  }

  /**
   * Register global middleware
   * @param {...MiddlewareFn} fns
   */
  use(...fns) {
    this._globalMiddleware.push(...fns);
    return this;
  }

  /**
   * Register a GET route
   * @param {string} pattern
   * @param {...MiddlewareFn} handlers
   */
  get(pattern, ...handlers) { return this._register('GET', pattern, handlers); }

  /**
   * Register a POST route
   * @param {string} pattern
   * @param {...MiddlewareFn} handlers
   */
  post(pattern, ...handlers) { return this._register('POST', pattern, handlers); }

  /**
   * Register a PUT route
   * @param {string} pattern
   * @param {...MiddlewareFn} handlers
   */
  put(pattern, ...handlers) { return this._register('PUT', pattern, handlers); }

  /**
   * Register a PATCH route
   * @param {string} pattern
   * @param {...MiddlewareFn} handlers
   */
  patch(pattern, ...handlers) { return this._register('PATCH', pattern, handlers); }

  /**
   * Register a DELETE route
   * @param {string} pattern
   * @param {...MiddlewareFn} handlers
   */
  delete(pattern, ...handlers) { return this._register('DELETE', pattern, handlers); }

  /**
   * Register a route for any method
   * @param {string} pattern
   * @param {...MiddlewareFn} handlers
   */
  all(pattern, ...handlers) { return this._register('*', pattern, handlers); }

  /** @private */
  _register(method, pattern, handlers) {
    this._routes.push({ method, pattern, handlers });
    return this;
  }

  /**
   * Handle an HTTP request
   * @param {http.IncomingMessage} req
   * @param {http.ServerResponse} res
   */
  async handle(req, res) {
    const { pathname, query } = parseUrl(req.url ?? '/');
    const method = req.method?.toUpperCase() ?? 'GET';

    augmentResponse(res);

    // Find matching route
    let routeHandlers = null;
    let routeParams = {};

    for (const route of this._routes) {
      if (route.method !== '*' && route.method !== method) continue;
      const { matched, params } = matchRoute(route.pattern, pathname);
      if (matched) {
        routeParams = params;
        routeHandlers = route.handlers;
        break;
      }
    }

    augmentRequest(req, routeParams, query);

    // Build full middleware chain: global + route handlers (or 404)
    const chain = [
      ...this._globalMiddleware,
      ...(routeHandlers ?? [
        (req, res) => res.error(404, `Not found: ${pathname}`),
      ]),
    ];

    // Execute chain
    let idx = 0;
    const next = async (err) => {
      if (err) {
        if (typeof err === 'object' && err.message) {
          res.error(500, err.message);
        } else {
          res.error(500, 'Internal server error');
        }
        return;
      }
      if (idx >= chain.length) return;
      const fn = chain[idx++];
      try {
        await fn(req, res, next);
      } catch (e) {
        next(e);
      }
    };

    await next();
  }
}

// ─── HTTP Server ──────────────────────────────────────────────────────────────

/**
 * Full-featured Node.js HTTP server with WebSocket support.
 *
 * @example
 * const server = new HeadyHTTPServer({ port: 3000 });
 * server.get('/api/hello', (req, res) => res.json({ hello: 'world' }));
 * server.ws('/ws', (socket) => { socket.send('connected'); });
 * await server.listen();
 */
export class HeadyHTTPServer extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {number} [options.port=3000]
   * @param {string} [options.host='0.0.0.0']
   * @param {boolean} [options.cors=true]
   * @param {boolean} [options.compression=false]
   * @param {boolean} [options.bodyParser=true]
   * @param {number} [options.maxBodySize] - max request body bytes
   * @param {boolean} [options.requestLog=false]
   * @param {object} [options.tls] - tls options for https.createServer
   */
  constructor(options = {}) {
    super();
    this._port = options.port ?? 3000;
    this._host = options.host ?? '0.0.0.0';
    this._router = new Router();
    this._wsHandlers = new Map(); // pattern -> handler fn
    this._wsConnections = new Set();
    this._server = null;
    this._started = false;

    // Built-in health routes
    this._registerHealthRoutes();

    // Built-in middleware
    if (options.cors !== false) {
      this._router.use(cors(typeof options.cors === 'object' ? options.cors : {}));
    }
    if (options.compression) {
      this._router.use(compression());
    }
    if (options.bodyParser !== false) {
      this._router.use(bodyParser({ limit: options.maxBodySize }));
    }
    if (options.requestLog) {
      this._router.use(requestLogger());
    }
  }

  /** @private */
  _registerHealthRoutes() {
    const startTime = SERVER_BIRTH;

    this._router.get('/health', (req, res) => {
      res.json({
        status: 'healthy',
        uptime: Date.now() - startTime,
        timestamp: new Date().toISOString(),
        phi: PHI,
      });
    });

    this._router.get('/ready', (req, res) => {
      res.json({
        ready: true,
        timestamp: new Date().toISOString(),
      });
    });

    this._router.get('/pulse', (req, res) => {
      const mem = process.memoryUsage();
      res.json({
        ts: Date.now(),
        uptime: process.uptime(),
        memory: {
          heapUsed: mem.heapUsed,
          heapTotal: mem.heapTotal,
          rss: mem.rss,
          external: mem.external,
        },
        cpu: process.cpuUsage(),
        // PHI ratio: heapUsed/heapTotal as sacred health indicator
        phi_health: mem.heapUsed / mem.heapTotal,
        load: os.loadavg(),
        platform: process.platform,
        nodeVersion: process.version,
      });
    });
  }

  // ── Route Registration (proxied to router) ─────────────────────────────────

  /** Use global middleware */
  use(...fns) { this._router.use(...fns); return this; }

  /** GET route */
  get(pattern, ...handlers) { this._router.get(pattern, ...handlers); return this; }

  /** POST route */
  post(pattern, ...handlers) { this._router.post(pattern, ...handlers); return this; }

  /** PUT route */
  put(pattern, ...handlers) { this._router.put(pattern, ...handlers); return this; }

  /** PATCH route */
  patch(pattern, ...handlers) { this._router.patch(pattern, ...handlers); return this; }

  /** DELETE route */
  delete(pattern, ...handlers) { this._router.delete(pattern, ...handlers); return this; }

  /** Route for any method */
  all(pattern, ...handlers) { this._router.all(pattern, ...handlers); return this; }

  /**
   * Register a WebSocket handler for a path pattern
   * @param {string} pattern - URL path pattern
   * @param {Function} handler - (ws: WebSocket, req: IncomingMessage) => void
   */
  ws(pattern, handler) {
    this._wsHandlers.set(pattern, handler);
    return this;
  }

  /**
   * Register an SSE endpoint
   * @param {string} pattern
   * @param {Function} handler - (sse: SSEStream, req: IncomingMessage) => void
   */
  sse(pattern, handler) {
    this._router.get(pattern, (req, res) => {
      const stream = new SSEStream(res);
      handler(stream, req);
    });
    return this;
  }

  // ── Server Lifecycle ───────────────────────────────────────────────────────

  /**
   * Start listening
   * @returns {Promise<{ port: number, host: string }>}
   */
  listen() {
    return new Promise((resolve, reject) => {
      if (this._started) {
        resolve({ port: this._port, host: this._host });
        return;
      }

      this._server = http.createServer((req, res) => {
        this._router.handle(req, res).catch((err) => {
          this.emit('error', err);
          if (!res.headersSent) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Internal server error' }));
          }
        });
      });

      // WebSocket upgrade handler
      this._server.on('upgrade', (req, socket, head) => {
        this._handleUpgrade(req, socket, head);
      });

      this._server.on('error', (err) => {
        this.emit('error', err);
        reject(err);
      });

      this._server.listen(this._port, this._host, () => {
        this._started = true;
        const addr = this._server.address();
        const port = addr.port;
        this._port = port;
        this.emit('listening', { port, host: this._host });
        resolve({ port, host: this._host });
      });
    });
  }

  /**
   * Handle WebSocket upgrade
   * @private
   */
  _handleUpgrade(req, socket, head) {
    const { pathname } = parseUrl(req.url ?? '/');

    // Find matching WS handler
    let handler = null;
    for (const [pattern, fn] of this._wsHandlers) {
      const { matched } = matchRoute(pattern, pathname);
      if (matched) { handler = fn; break; }
    }

    if (!handler) {
      socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
      socket.destroy();
      return;
    }

    // Validate upgrade request
    const key = req.headers['sec-websocket-key'];
    if (!key) {
      socket.write('HTTP/1.1 400 Bad Request\r\n\r\n');
      socket.destroy();
      return;
    }

    const acceptKey = wsAcceptKey(key);
    const subprotocol = req.headers['sec-websocket-protocol'];

    const responseHeaders = [
      'HTTP/1.1 101 Switching Protocols',
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Accept: ${acceptKey}`,
      ...(subprotocol ? [`Sec-WebSocket-Protocol: ${subprotocol.split(',')[0].trim()}`] : []),
      '\r\n',
    ].join('\r\n');

    socket.write(responseHeaders);

    const ws = new WebSocket(socket, req);
    this._wsConnections.add(ws);
    ws.on('close', () => this._wsConnections.delete(ws));

    this.emit('connection', ws, req);
    handler(ws, req);
  }

  /**
   * Broadcast a message to all connected WebSocket clients
   * @param {string|Buffer} data
   */
  broadcast(data) {
    for (const ws of this._wsConnections) {
      if (ws._readyState === 1) ws.send(data);
    }
  }

  /**
   * Gracefully shut down the server
   * @param {number} [timeoutMs=5000]
   * @returns {Promise<void>}
   */
  shutdown(timeoutMs = 5000) {
    return new Promise((resolve) => {
      if (!this._server || !this._started) { resolve(); return; }

      // Close all WebSocket connections
      for (const ws of this._wsConnections) {
        ws.close(1001, 'Server shutting down');
      }
      this._wsConnections.clear();

      const timer = setTimeout(() => {
        this._server.closeAllConnections?.();
        resolve();
      }, timeoutMs);

      this._server.close(() => {
        clearTimeout(timer);
        this._started = false;
        this.emit('shutdown');
        resolve();
      });
    });
  }

  /** @returns {number} current WebSocket connection count */
  get wsConnectionCount() {
    return this._wsConnections.size;
  }

  /** @returns {number} port the server is listening on */
  get port() { return this._port; }

  /** @returns {boolean} */
  get listening() { return this._started; }

  /** @returns {http.Server} underlying Node HTTP server */
  get httpServer() { return this._server; }
}

// ─── Default Export ───────────────────────────────────────────────────────────

// Named exports for direct destructuring
export { PHI, FIBONACCI, parseUrl, matchRoute, parseBody };

export default {
  HeadyHTTPServer,
  Router,
  WebSocket,
  SSEStream,
  cors,
  bodyParser,
  compression,
  requestLogger,
  parseUrl,
  matchRoute,
  parseBody,
  PHI,
  FIBONACCI,
};
