/**
 * @file event-bus.js
 * @description Internal event system for HeadyCore.
 *
 * Features:
 * - Pub/sub with topic-based routing (dot-notation + wildcard support)
 * - Priority queues (Fibonacci-weighted priority levels)
 * - Event replay / persistence (in-memory ring buffer + WAL file)
 * - Cross-process event bridge (WebSocket/IPC mesh for Colab cluster)
 * - Backpressure handling with PHI-scaled overflow protection
 *
 * Sacred Geometry: PHI buffer sizes, Fibonacci priority levels.
 * Zero external dependencies (events, net, fs, crypto, worker_threads).
 *
 * @module HeadyCore/EventBus
 */

import { EventEmitter } from 'events';
import net from 'net';
import fs from 'fs';
import path from 'path';
import { createHash, randomBytes, randomUUID } from 'crypto';
import { Worker, isMainThread, parentPort, workerData } from 'worker_threads';

// ─── Sacred Geometry ──────────────────────────────────────────────────────────
const PHI = 1.6180339887498948482;
const FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610];

/**
 * Fibonacci-indexed priority levels
 * @enum {number}
 */
export const Priority = Object.freeze({
  CRITICAL: 5,   // FIBONACCI[4] = 5
  HIGH: 3,       // FIBONACCI[3] = 3
  NORMAL: 2,     // FIBONACCI[2] = 2
  LOW: 1,        // FIBONACCI[1] = 1
  BACKGROUND: 0, // Processed when idle
});

// ─── Topic Matching ───────────────────────────────────────────────────────────

/**
 * Match a topic pattern against an actual topic.
 * Supports:
 * - Exact match: "brain.vector.query"
 * - Single segment wildcard: "brain.*.query"
 * - Multi-segment wildcard: "brain.#" matches "brain.any.depth.here"
 *
 * @param {string} pattern
 * @param {string} topic
 * @returns {boolean}
 */
export function topicMatch(pattern, topic) {
  if (pattern === topic) return true;
  if (pattern === '#') return true;

  const pParts = pattern.split('.');
  const tParts = topic.split('.');

  for (let i = 0; i < pParts.length; i++) {
    const p = pParts[i];
    if (p === '#') return true; // matches rest
    if (i >= tParts.length) return false;
    if (p !== '*' && p !== tParts[i]) return false;
  }

  return pParts.length === tParts.length;
}

// ─── Event Object ─────────────────────────────────────────────────────────────

/**
 * @typedef {object} HeadyEvent
 * @property {string} id - unique event ID
 * @property {string} topic - dot-notation topic
 * @property {*} data - event payload
 * @property {number} priority - Priority enum value
 * @property {number} ts - timestamp (unix ms)
 * @property {string} [source] - originating node/process
 * @property {string} [correlationId] - for request/reply patterns
 * @property {number} [ttl] - time-to-live ms (0 = no expiry)
 * @property {boolean} [persistent] - persist to WAL
 */

/**
 * Create a HeadyEvent
 * @param {string} topic
 * @param {*} data
 * @param {object} [options]
 * @returns {HeadyEvent}
 */
export function createEvent(topic, data, options = {}) {
  return {
    id: options.id ?? randomUUID(),
    topic,
    data,
    priority: options.priority ?? Priority.NORMAL,
    ts: Date.now(),
    source: options.source ?? null,
    correlationId: options.correlationId ?? null,
    ttl: options.ttl ?? 0,
    persistent: options.persistent ?? false,
  };
}

// ─── Priority Queue ───────────────────────────────────────────────────────────

/**
 * Min-heap priority queue for events.
 * Higher priority = earlier dequeue.
 * Ties broken by timestamp (FIFO within same priority).
 */
export class PriorityQueue {
  constructor() {
    /** @type {HeadyEvent[]} */
    this._heap = [];
  }

  /**
   * Enqueue an event
   * @param {HeadyEvent} event
   */
  enqueue(event) {
    this._heap.push(event);
    this._bubbleUp(this._heap.length - 1);
  }

  /**
   * Dequeue the highest-priority event
   * @returns {HeadyEvent|undefined}
   */
  dequeue() {
    if (this._heap.length === 0) return undefined;
    if (this._heap.length === 1) return this._heap.pop();

    const top = this._heap[0];
    this._heap[0] = this._heap.pop();
    this._siftDown(0);
    return top;
  }

  /** @returns {HeadyEvent|undefined} peek without dequeuing */
  peek() { return this._heap[0]; }

  /** @returns {number} */
  get size() { return this._heap.length; }

  /** @returns {boolean} */
  get empty() { return this._heap.length === 0; }

  /** @private */
  _compare(a, b) {
    // Higher priority first (max-heap on priority)
    if (b.priority !== a.priority) return b.priority - a.priority;
    // Then FIFO by timestamp
    return a.ts - b.ts;
  }

  /** @private */
  _bubbleUp(i) {
    while (i > 0) {
      const parent = Math.floor((i - 1) / 2);
      if (this._compare(this._heap[i], this._heap[parent]) < 0) {
        [this._heap[i], this._heap[parent]] = [this._heap[parent], this._heap[i]];
        i = parent;
      } else break;
    }
  }

  /** @private */
  _siftDown(i) {
    const n = this._heap.length;
    while (true) {
      let smallest = i;
      const left = 2 * i + 1;
      const right = 2 * i + 2;
      if (left < n && this._compare(this._heap[left], this._heap[smallest]) < 0) smallest = left;
      if (right < n && this._compare(this._heap[right], this._heap[smallest]) < 0) smallest = right;
      if (smallest === i) break;
      [this._heap[i], this._heap[smallest]] = [this._heap[smallest], this._heap[i]];
      i = smallest;
    }
  }

  /**
   * Remove expired events (TTL check)
   * @returns {number} number of evicted events
   */
  evictExpired() {
    const now = Date.now();
    const before = this._heap.length;
    this._heap = this._heap.filter((e) => !e.ttl || (now - e.ts) < e.ttl);
    // Rebuild heap after filter
    this._heap = this._heap.slice();
    for (let i = Math.floor(this._heap.length / 2) - 1; i >= 0; i--) {
      this._siftDown(i);
    }
    return before - this._heap.length;
  }

  /** Clear the queue */
  clear() { this._heap = []; }
}

// ─── Event Ring Buffer (Replay) ───────────────────────────────────────────────

/**
 * Fixed-size ring buffer for event replay.
 * Capacity: PHI^8 * 1 ≈ 46 events (rounded to FIBONACCI[9]=34 by default)
 */
export class EventRingBuffer {
  /**
   * @param {number} [capacity=FIBONACCI[9]] default 34
   */
  constructor(capacity = FIBONACCI[9]) {
    this._capacity = capacity;
    /** @type {HeadyEvent[]} */
    this._buf = new Array(capacity);
    this._head = 0;
    this._count = 0;
  }

  /**
   * Write an event to the ring buffer
   * @param {HeadyEvent} event
   */
  write(event) {
    this._buf[this._head] = event;
    this._head = (this._head + 1) % this._capacity;
    if (this._count < this._capacity) this._count++;
  }

  /**
   * Get all stored events in order (oldest first)
   * @param {string} [topicFilter] - optional topic pattern to filter
   * @param {number} [since=0] - only events after this timestamp
   * @returns {HeadyEvent[]}
   */
  replay(topicFilter, since = 0) {
    const events = [];
    const start = this._count < this._capacity ? 0 : this._head;
    for (let i = 0; i < this._count; i++) {
      const idx = (start + i) % this._capacity;
      const ev = this._buf[idx];
      if (!ev) continue;
      if (ev.ts < since) continue;
      if (topicFilter && !topicMatch(topicFilter, ev.topic)) continue;
      events.push(ev);
    }
    return events;
  }

  /** @returns {number} number of stored events */
  get size() { return this._count; }

  /** Clear the buffer */
  clear() {
    this._buf = new Array(this._capacity);
    this._head = 0;
    this._count = 0;
  }
}

// ─── WAL (Write-Ahead Log) ────────────────────────────────────────────────────

/**
 * Append-only Write-Ahead Log for persistent events.
 * Each line is a JSON-encoded HeadyEvent.
 */
export class EventWAL {
  /**
   * @param {string} walPath - file path for WAL
   * @param {object} [options]
   * @param {number} [options.maxSizeBytes=FIBONACCI[12]*1024] ~233KB
   * @param {boolean} [options.autoRotate=true]
   */
  constructor(walPath, options = {}) {
    this._path = walPath;
    this._maxSizeBytes = options.maxSizeBytes ?? FIBONACCI[12] * 1024; // 233KB
    this._autoRotate = options.autoRotate !== false;
    this._stream = null;
    this._bytesWritten = 0;
    this._initialized = false;
  }

  /**
   * Open the WAL for writing
   * @returns {Promise<void>}
   */
  async open() {
    if (this._initialized) return;
    try {
      const stat = await fs.promises.stat(this._path).catch(() => null);
      this._bytesWritten = stat?.size ?? 0;
    } catch (_) {}

    this._stream = fs.createWriteStream(this._path, { flags: 'a', encoding: 'utf8' });
    this._initialized = true;
    return new Promise((resolve, reject) => {
      this._stream.once('open', resolve);
      this._stream.once('error', reject);
    });
  }

  /**
   * Append an event to the WAL
   * @param {HeadyEvent} event
   * @returns {Promise<void>}
   */
  async append(event) {
    if (!this._initialized) await this.open();

    if (this._autoRotate && this._bytesWritten >= this._maxSizeBytes) {
      await this.rotate();
    }

    return new Promise((resolve, reject) => {
      const line = JSON.stringify(event) + '\n';
      this._bytesWritten += Buffer.byteLength(line);
      this._stream.write(line, 'utf8', (err) => {
        if (err) reject(err);
        else resolve();
      });
    });
  }

  /**
   * Read and replay all events from the WAL file
   * @param {string} [topicFilter]
   * @param {number} [since=0]
   * @returns {Promise<HeadyEvent[]>}
   */
  async readAll(topicFilter, since = 0) {
    try {
      const content = await fs.promises.readFile(this._path, 'utf8');
      const events = [];
      for (const line of content.split('\n')) {
        if (!line.trim()) continue;
        try {
          const ev = JSON.parse(line);
          if (ev.ts < since) continue;
          if (topicFilter && !topicMatch(topicFilter, ev.topic)) continue;
          events.push(ev);
        } catch (_) {}
      }
      return events;
    } catch (err) {
      if (err.code === 'ENOENT') return [];
      throw err;
    }
  }

  /**
   * Rotate the WAL (archive current, start fresh)
   * @returns {Promise<void>}
   */
  async rotate() {
    if (this._stream) {
      await new Promise((resolve) => this._stream.end(resolve));
    }
    const archivePath = `${this._path}.${Date.now()}.bak`;
    try {
      await fs.promises.rename(this._path, archivePath);
    } catch (_) {}
    this._bytesWritten = 0;
    this._stream = fs.createWriteStream(this._path, { flags: 'a', encoding: 'utf8' });
  }

  /**
   * Close the WAL
   * @returns {Promise<void>}
   */
  close() {
    return new Promise((resolve) => {
      if (!this._stream) { resolve(); return; }
      this._stream.end(resolve);
      this._stream = null;
      this._initialized = false;
    });
  }
}

// ─── Subscription ─────────────────────────────────────────────────────────────

/**
 * @typedef {object} Subscription
 * @property {string} id
 * @property {string} pattern
 * @property {Function} handler
 * @property {Priority} minPriority
 * @property {boolean} once
 */

// ─── Event Bus ────────────────────────────────────────────────────────────────

/**
 * The main HeadyCore event bus.
 * Provides pub/sub, priority queuing, replay, persistence, and cross-node bridging.
 *
 * @example
 * const bus = new EventBus({ persist: '/tmp/heady-events.wal' });
 * bus.subscribe('brain.#', (event) => console.log(event));
 * await bus.publish('brain.vector.query', { query: 'test' }, { priority: Priority.HIGH });
 */
export class EventBus extends EventEmitter {
  /**
   * @param {object} [options]
   * @param {string} [options.nodeId] - identifier for this bus instance
   * @param {boolean} [options.replay=true] - enable in-memory replay buffer
   * @param {number} [options.replayCapacity] - ring buffer size
   * @param {string} [options.persist] - file path for WAL persistence
   * @param {number} [options.maxQueueSize] - max events in priority queue (default PHI^8 ≈ 47)
   * @param {boolean} [options.processAsync=true] - process queue asynchronously
   * @param {number} [options.processBatchSize] - events per processing tick (default FIBONACCI[4]=5)
   */
  constructor(options = {}) {
    super();
    this._nodeId = options.nodeId ?? randomBytes(4).toString('hex');
    this._replayEnabled = options.replay !== false;
    this._ringBuffer = new EventRingBuffer(options.replayCapacity ?? FIBONACCI[9]);
    this._wal = options.persist ? new EventWAL(options.persist) : null;
    this._maxQueueSize = options.maxQueueSize ?? Math.floor(Math.pow(PHI, 8)); // ~46
    this._processAsync = options.processAsync !== false;
    this._batchSize = options.processBatchSize ?? FIBONACCI[4]; // 5

    /** @type {Map<string, Subscription>} */
    this._subscriptions = new Map();
    /** @type {PriorityQueue} */
    this._queue = new PriorityQueue();

    this._processing = false;
    this._drainTimer = null;
    this._evictionTimer = null;

    // Bridges to other nodes
    /** @type {Map<string, EventBridgeConnection>} */
    this._bridges = new Map();

    // Evict expired events every FIBONACCI[6]=13 seconds
    this._evictionTimer = setInterval(() => {
      const evicted = this._queue.evictExpired();
      if (evicted > 0) this.emit('evicted', { count: evicted });
    }, FIBONACCI[6] * 1000);
    if (this._evictionTimer.unref) this._evictionTimer.unref();
  }

  // ── Publishing ─────────────────────────────────────────────────────────────

  /**
   * Publish an event to the bus
   * @param {string} topic
   * @param {*} data
   * @param {object} [options]
   * @param {number} [options.priority=Priority.NORMAL]
   * @param {string} [options.correlationId]
   * @param {number} [options.ttl] - TTL in ms
   * @param {boolean} [options.persistent] - persist to WAL
   * @param {boolean} [options.local=false] - skip bridge forwarding
   * @returns {Promise<HeadyEvent>}
   */
  async publish(topic, data, options = {}) {
    const event = createEvent(topic, data, {
      ...options,
      source: options.source ?? this._nodeId,
    });

    return this._enqueue(event, options.local ?? false);
  }

  /**
   * Publish synchronously (fire-and-forget)
   * @param {string} topic
   * @param {*} data
   * @param {object} [options]
   */
  emit_event(topic, data, options = {}) {
    const event = createEvent(topic, data, {
      ...options,
      source: options.source ?? this._nodeId,
    });
    this._enqueue(event, options.local ?? false).catch((err) => this.emit('error', err));
    return event;
  }

  /**
   * @private
   * @param {HeadyEvent} event
   * @param {boolean} local
   * @returns {Promise<HeadyEvent>}
   */
  async _enqueue(event, local = false) {
    // Backpressure: if queue is full, drop BACKGROUND events or reject
    if (this._queue.size >= this._maxQueueSize) {
      if (event.priority === Priority.BACKGROUND) {
        this.emit('dropped', { event, reason: 'backpressure' });
        return event;
      }
      // For higher priority: evict lowest priority item to make room
      const evicted = this._queue.dequeue(); // This gets the lowest (after sorting)
      if (evicted) this.emit('dropped', { event: evicted, reason: 'overflow' });
    }

    this._queue.enqueue(event);

    // Persist if requested
    if (event.persistent && this._wal) {
      await this._wal.append(event).catch((err) => this.emit('error', err));
    }

    // Record in replay buffer
    if (this._replayEnabled) {
      this._ringBuffer.write(event);
    }

    // Forward to bridges (other cluster nodes)
    if (!local && this._bridges.size > 0) {
      this._forwardToBridges(event);
    }

    // Schedule processing
    if (this._processAsync) {
      this._scheduleDrain();
    } else {
      await this._drain();
    }

    return event;
  }

  /** @private */
  _scheduleDrain() {
    if (this._drainTimer) return;
    this._drainTimer = setImmediate(() => {
      this._drainTimer = null;
      this._drain().catch((err) => this.emit('error', err));
    });
  }

  /**
   * Process queued events in priority order
   * @private
   * @returns {Promise<void>}
   */
  async _drain() {
    if (this._processing) return;
    this._processing = true;

    try {
      let processed = 0;
      while (!this._queue.empty && processed < this._batchSize) {
        const event = this._queue.dequeue();
        if (!event) break;

        // TTL check
        if (event.ttl && (Date.now() - event.ts) >= event.ttl) {
          this.emit('evicted', { event, reason: 'ttl' });
          continue;
        }

        await this._dispatch(event);
        processed++;
      }

      // If still items, schedule next drain
      if (!this._queue.empty) {
        this._scheduleDrain();
      }
    } finally {
      this._processing = false;
    }
  }

  /**
   * Dispatch an event to all matching subscribers
   * @private
   * @param {HeadyEvent} event
   */
  async _dispatch(event) {
    const promises = [];
    const toRemove = [];

    for (const [id, sub] of this._subscriptions) {
      if (!topicMatch(sub.pattern, event.topic)) continue;
      if (event.priority < sub.minPriority) continue;

      if (sub.once) toRemove.push(id);

      try {
        const result = sub.handler(event);
        if (result instanceof Promise) promises.push(result);
      } catch (err) {
        this.emit('handlerError', { error: err, event, subscription: sub });
      }
    }

    // Remove one-shot subscriptions
    for (const id of toRemove) this._subscriptions.delete(id);

    // Await async handlers (catch individually to not block others)
    if (promises.length > 0) {
      await Promise.allSettled(promises);
    }

    this.emit('dispatched', event);
  }

  // ── Subscribing ────────────────────────────────────────────────────────────

  /**
   * Subscribe to events matching a topic pattern
   * @param {string} pattern - dot-notation topic pattern (* = single, # = multi)
   * @param {Function} handler - (event: HeadyEvent) => void|Promise
   * @param {object} [options]
   * @param {number} [options.minPriority=Priority.BACKGROUND]
   * @param {boolean} [options.once=false]
   * @param {boolean} [options.replay=false] - replay buffered events on subscribe
   * @param {number} [options.replaySince=0] - replay events since this timestamp
   * @returns {string} subscription ID
   */
  subscribe(pattern, handler, options = {}) {
    const id = randomUUID();
    const sub = {
      id,
      pattern,
      handler,
      minPriority: options.minPriority ?? Priority.BACKGROUND,
      once: options.once ?? false,
    };
    this._subscriptions.set(id, sub);

    // Replay buffered events if requested
    if (options.replay && this._replayEnabled) {
      const events = this._ringBuffer.replay(pattern, options.replaySince ?? 0);
      setImmediate(() => {
        for (const ev of events) {
          try { handler(ev); } catch (_) {}
        }
      });
    }

    this.emit('subscribed', { id, pattern });
    return id;
  }

  /**
   * Subscribe to one event only
   * @param {string} pattern
   * @param {Function} handler
   * @param {object} [options]
   * @returns {string} subscription ID
   */
  subscribeOnce(pattern, handler, options = {}) {
    return this.subscribe(pattern, handler, { ...options, once: true });
  }

  /**
   * Wait for the next event matching a topic pattern
   * @param {string} pattern
   * @param {number} [timeoutMs=30000]
   * @returns {Promise<HeadyEvent>}
   */
  waitFor(pattern, timeoutMs = 30000) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this._subscriptions.delete(id);
        reject(new Error(`Timeout waiting for topic: ${pattern}`));
      }, timeoutMs);

      const id = this.subscribeOnce(pattern, (event) => {
        clearTimeout(timer);
        resolve(event);
      });
    });
  }

  /**
   * Unsubscribe by subscription ID
   * @param {string} id
   * @returns {boolean}
   */
  unsubscribe(id) {
    const removed = this._subscriptions.delete(id);
    if (removed) this.emit('unsubscribed', { id });
    return removed;
  }

  /**
   * Remove all subscriptions matching a pattern
   * @param {string} pattern
   * @returns {number} count removed
   */
  unsubscribeAll(pattern) {
    let count = 0;
    for (const [id, sub] of this._subscriptions) {
      if (sub.pattern === pattern) {
        this._subscriptions.delete(id);
        count++;
      }
    }
    return count;
  }

  // ── Request / Reply ────────────────────────────────────────────────────────

  /**
   * Publish a request event and wait for a reply
   * @param {string} topic
   * @param {*} data
   * @param {object} [options]
   * @param {number} [options.timeout=10000]
   * @returns {Promise<HeadyEvent>}
   */
  async request(topic, data, options = {}) {
    const correlationId = randomUUID();
    const replyTopic = `_reply.${correlationId}`;
    const timeout = options.timeout ?? 10000;

    const replyPromise = this.waitFor(replyTopic, timeout);
    await this.publish(topic, data, { ...options, correlationId });
    return replyPromise;
  }

  /**
   * Reply to a request event
   * @param {HeadyEvent} requestEvent
   * @param {*} replyData
   */
  async reply(requestEvent, replyData) {
    if (!requestEvent.correlationId) {
      throw new Error('Cannot reply to event without correlationId');
    }
    return this.publish(`_reply.${requestEvent.correlationId}`, replyData, {
      correlationId: requestEvent.correlationId,
      priority: requestEvent.priority,
    });
  }

  // ── Replay ─────────────────────────────────────────────────────────────────

  /**
   * Replay buffered events to a handler
   * @param {string} [topicFilter]
   * @param {number} [since=0]
   * @returns {HeadyEvent[]}
   */
  getBuffer(topicFilter, since = 0) {
    return this._ringBuffer.replay(topicFilter, since);
  }

  /**
   * Replay persisted WAL events
   * @param {string} [topicFilter]
   * @param {number} [since=0]
   * @returns {Promise<HeadyEvent[]>}
   */
  async getPersistedEvents(topicFilter, since = 0) {
    if (!this._wal) return [];
    return this._wal.readAll(topicFilter, since);
  }

  // ── Bridges (Cross-Node) ───────────────────────────────────────────────────

  /**
   * Add a bridge connection to another node
   * @param {string} nodeId
   * @param {EventBridgeConnection} bridge
   */
  addBridge(nodeId, bridge) {
    this._bridges.set(nodeId, bridge);

    // Receive events from remote node
    bridge.on('event', (event) => {
      // Mark as remote and enqueue locally (don't re-forward to bridges)
      const remoteEvent = { ...event, _remote: true, _fromNode: nodeId };
      this._enqueue(remoteEvent, true).catch((err) => this.emit('error', err));
    });

    bridge.on('close', () => {
      this._bridges.delete(nodeId);
      this.emit('bridgeDisconnected', { nodeId });
    });

    this.emit('bridgeConnected', { nodeId });
  }

  /**
   * Remove a bridge
   * @param {string} nodeId
   */
  removeBridge(nodeId) {
    const bridge = this._bridges.get(nodeId);
    if (bridge) {
      bridge.close();
      this._bridges.delete(nodeId);
    }
  }

  /** @private */
  _forwardToBridges(event) {
    for (const [nodeId, bridge] of this._bridges) {
      try {
        bridge.forward(event);
      } catch (err) {
        this.emit('bridgeError', { nodeId, error: err });
      }
    }
  }

  // ── Status ─────────────────────────────────────────────────────────────────

  /** @returns {object} bus status snapshot */
  get status() {
    return {
      nodeId: this._nodeId,
      queueSize: this._queue.size,
      subscriptions: this._subscriptions.size,
      bufferSize: this._ringBuffer.size,
      bridges: this._bridges.size,
      // PHI health ratio: queue fill
      phiLoad: this._queue.size / this._maxQueueSize,
    };
  }

  // ── Lifecycle ──────────────────────────────────────────────────────────────

  /**
   * Drain remaining queued events and shut down
   * @returns {Promise<void>}
   */
  async shutdown() {
    if (this._evictionTimer) {
      clearInterval(this._evictionTimer);
      this._evictionTimer = null;
    }
    if (this._drainTimer) {
      clearImmediate(this._drainTimer);
      this._drainTimer = null;
    }

    // Final drain (synchronous)
    while (!this._queue.empty) {
      const event = this._queue.dequeue();
      if (event) await this._dispatch(event).catch(() => {});
    }

    // Close bridges
    for (const [_, bridge] of this._bridges) {
      try { bridge.close(); } catch (_) {}
    }
    this._bridges.clear();

    // Close WAL
    if (this._wal) {
      await this._wal.close().catch(() => {});
    }

    this.emit('shutdown');
  }
}

// ─── Event Bridge ─────────────────────────────────────────────────────────────

/**
 * TCP-based event bridge for inter-node (cross-Colab) communication.
 * JSON newline-delimited framing over a net.Socket.
 */
export class EventBridgeConnection extends EventEmitter {
  /**
   * @param {net.Socket} socket
   * @param {object} [options]
   * @param {string[]} [options.topicFilters] - only forward matching topics
   */
  constructor(socket, options = {}) {
    super();
    this._socket = socket;
    this._topicFilters = options.topicFilters ?? ['#']; // default: all
    this._buf = '';
    this._closed = false;

    socket.setEncoding('utf8');
    socket.on('data', (chunk) => this._onData(chunk));
    socket.on('close', () => {
      this._closed = true;
      this.emit('close');
    });
    socket.on('error', (err) => this.emit('error', err));
  }

  /** @private */
  _onData(chunk) {
    this._buf += chunk;
    const lines = this._buf.split('\n');
    this._buf = lines.pop() ?? '';
    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const event = JSON.parse(line);
        this.emit('event', event);
      } catch (_) {}
    }
  }

  /**
   * Forward an event to the remote node
   * @param {HeadyEvent} event
   */
  forward(event) {
    if (this._closed) return;
    // Filter check
    const shouldForward = this._topicFilters.some((f) => topicMatch(f, event.topic));
    if (!shouldForward) return;
    this._socket.write(JSON.stringify(event) + '\n');
  }

  /** Close the bridge connection */
  close() {
    if (!this._closed) {
      this._closed = true;
      this._socket.end();
    }
  }

  /** @returns {boolean} */
  get connected() { return !this._closed; }
}

// ─── Event Bridge Server ──────────────────────────────────────────────────────

/**
 * TCP server that accepts bridge connections from other EventBus nodes.
 */
export class EventBridgeServer extends EventEmitter {
  /**
   * @param {EventBus} bus - local bus instance
   * @param {object} [options]
   * @param {number} [options.port=9100]
   * @param {string} [options.host='0.0.0.0']
   */
  constructor(bus, options = {}) {
    super();
    this._bus = bus;
    this._port = options.port ?? 9100;
    this._host = options.host ?? '0.0.0.0';
    this._server = null;
    /** @type {Set<EventBridgeConnection>} */
    this._connections = new Set();
  }

  /**
   * Start listening for bridge connections
   * @returns {Promise<{ port: number, host: string }>}
   */
  listen() {
    return new Promise((resolve, reject) => {
      this._server = net.createServer((socket) => {
        const bridge = new EventBridgeConnection(socket);
        this._connections.add(bridge);
        bridge.on('close', () => this._connections.delete(bridge));

        const nodeId = randomBytes(4).toString('hex');
        this._bus.addBridge(nodeId, bridge);
        this.emit('connection', { nodeId, remoteAddress: socket.remoteAddress });
      });

      this._server.once('error', reject);
      this._server.listen(this._port, this._host, () => {
        this.emit('listening', { port: this._port, host: this._host });
        resolve({ port: this._port, host: this._host });
      });
    });
  }

  /**
   * Connect to a remote EventBridgeServer and add to the local bus
   * @param {string} remoteHost
   * @param {number} remotePort
   * @param {string} [nodeId]
   * @returns {Promise<EventBridgeConnection>}
   */
  async connect(remoteHost, remotePort, nodeId) {
    return new Promise((resolve, reject) => {
      const socket = net.createConnection({ host: remoteHost, port: remotePort }, () => {
        const bridge = new EventBridgeConnection(socket);
        const id = nodeId ?? `${remoteHost}:${remotePort}`;
        this._bus.addBridge(id, bridge);
        this._connections.add(bridge);
        bridge.on('close', () => this._connections.delete(bridge));
        resolve(bridge);
      });
      socket.once('error', reject);
    });
  }

  /**
   * Close the bridge server
   * @returns {Promise<void>}
   */
  shutdown() {
    return new Promise((resolve) => {
      for (const conn of this._connections) {
        conn.close();
      }
      this._connections.clear();
      if (this._server) {
        this._server.close(resolve);
      } else {
        resolve();
      }
    });
  }

  /** @returns {number} */
  get connectionCount() { return this._connections.size; }
}

// ─── Global Bus Singleton ─────────────────────────────────────────────────────

/** @type {EventBus|null} */
let _globalBus = null;

/**
 * Get (or create) the global EventBus singleton
 * @param {object} [options] - only used on first call
 * @returns {EventBus}
 */
export function getGlobalBus(options = {}) {
  if (!_globalBus) {
    _globalBus = new EventBus({ nodeId: 'global', ...options });
  }
  return _globalBus;
}

/**
 * Replace the global bus (useful for testing)
 * @param {EventBus} bus
 */
export function setGlobalBus(bus) {
  _globalBus = bus;
}

// Named exports for direct destructuring
export { PHI, FIBONACCI };

// ─── Default Export ───────────────────────────────────────────────────────────

export default {
  EventBus,
  EventBridgeConnection,
  EventBridgeServer,
  EventRingBuffer,
  PriorityQueue,
  EventWAL,
  Priority,
  createEvent,
  topicMatch,
  getGlobalBus,
  setGlobalBus,
  PHI,
  FIBONACCI,
};
