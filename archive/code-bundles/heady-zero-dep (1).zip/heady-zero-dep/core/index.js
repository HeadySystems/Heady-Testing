/**
 * @file index.js
 * @description HeadyCore Runtime - Main Export
 *
 * Zero-dependency runtime for the Heady project.
 * Combines all core modules into a unified, production-ready runtime:
 *
 * - MCPProtocol: Full MCP/JSON-RPC 2.0 over stdio and SSE
 * - GitHubClient: REST API with App auth, JWT, PHI-scaled backoff
 * - HTTPServer: Pure Node.js HTTP/WebSocket/SSE server
 * - ProcessManager: Process lifecycle with circuit breaker and LIFO shutdown
 * - EventBus: Pub/sub with priority queues, replay, and cross-node bridging
 *
 * Sacred Geometry principles:
 * - PHI (φ=1.618) scales all timing and backoff
 * - Fibonacci sequences govern buffer sizes, retries, and pool sizing
 * - 3-node cluster maps to BRAIN / CONDUCTOR / SENTINEL sacred geometry roles
 *
 * @module HeadyCore
 * @example
 * import HeadyCore, { Runtime, EventBus, MCPServer } from './core/index.js';
 *
 * const runtime = new Runtime({ port: 3000, nodeRole: 'brain' });
 * await runtime.start();
 */

// ─── Re-export all named exports from each module ─────────────────────────────

export {
  // MCP Protocol
  MCPServer,
  MCPClient,
  MCPSession,
  StdioTransport,
  SSETransport,
  MessageCodec,
  buildRequest,
  buildResponse,
  buildError,
  buildNotification,
  validateMessage,
  JsonRpcError,
  MsgType,
  phiBackoff as mcpPhiBackoff,
} from './mcp-protocol.js';

export {
  // GitHub Client
  GitHubClient,
  generateAppJWT,
  createTokenClient,
  createAppClient,
} from './github-client.js';

export {
  // HTTP Server
  HeadyHTTPServer,
  Router,
  WebSocket,
  SSEStream,
  cors,
  bodyParser,
  compression,
  requestLogger,
  parseUrl,
  matchRoute,
  parseBody,
} from './http-server.js';

export {
  // Process Manager
  ProcessManager,
  ManagedProcess,
  WorkerPool,
  CircuitBreaker,
  ResourceMonitor,
  CircuitState,
  phiBackoff,
  FIBONACCI as PROCESS_FIBONACCI,
} from './process-manager.js';

export {
  // Event Bus
  EventBus,
  EventBridgeConnection,
  EventBridgeServer,
  EventRingBuffer,
  PriorityQueue,
  EventWAL,
  Priority,
  createEvent,
  topicMatch,
  getGlobalBus,
  setGlobalBus,
} from './event-bus.js';

// ─── Direct imports for use in this module ────────────────────────────────────

import { MCPServer, MCPClient, SSETransport } from './mcp-protocol.js';
import { GitHubClient, createTokenClient, createAppClient } from './github-client.js';
import { HeadyHTTPServer } from './http-server.js';
import { ProcessManager } from './process-manager.js';
import { EventBus, EventBridgeServer, getGlobalBus, Priority } from './event-bus.js';
import { randomUUID } from 'crypto';

// ─── Sacred Geometry Constants ────────────────────────────────────────────────

/** Golden ratio φ = (1 + √5) / 2 */
export const PHI = 1.6180339887498948482;

/** First 15 Fibonacci numbers for use throughout the system */
export const FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610];

/**
 * PHI-scaled exponential backoff
 * @param {number} n - attempt index (0-based)
 * @param {number} [base=1000] - base delay ms
 * @returns {number} delay ms
 */
// phiBackoff is already exported from process-manager.js above

/**
 * Fibonacci value at index
 * @param {number} index - 0-14
 * @returns {number}
 */
export function fib(index) {
  return FIBONACCI[Math.min(Math.abs(index), FIBONACCI.length - 1)];
}

// ─── Runtime Orchestrator ─────────────────────────────────────────────────────

/**
 * @typedef {object} RuntimeOptions
 * @property {number} [port=3000] - HTTP server port
 * @property {string} [host='0.0.0.0']
 * @property {string} [nodeId] - identifier for this cluster node
 * @property {string} [nodeRole='standalone'] - 'brain'|'conductor'|'sentinel'|'standalone'
 * @property {boolean} [cors=true]
 * @property {boolean} [requestLog=false]
 * @property {string} [walPath] - event WAL file path
 * @property {number} [bridgePort=9100] - EventBridge server port
 * @property {boolean} [startBridge=false]
 * @property {object} [mcpOptions] - extra options for MCPServer
 * @property {object} [processOptions] - extra options for ProcessManager
 */

/**
 * HeadyCore Runtime: orchestrates all core services.
 *
 * Maps to the 3-Colab cluster architecture:
 * - BRAIN: VectorDB + LLM routing - central hub (sacred origin point)
 * - CONDUCTOR: Pipeline + Bee factory - inner ring (processing core)
 * - SENTINEL: Security + Telemetry - governance shell
 *
 * @example
 * const runtime = new Runtime({ port: 3000, nodeRole: 'brain', startBridge: true });
 * await runtime.start();
 *
 * // Register a tool
 * runtime.mcp.registerTool({
 *   name: 'echo',
 *   description: 'Echo input',
 *   inputSchema: { type: 'object', properties: { text: { type: 'string' } } },
 *   handler: async ({ text }) => text,
 * });
 *
 * // Publish an event
 * await runtime.bus.publish('brain.query', { text: 'hello' });
 *
 * // Spawn a child process
 * runtime.pm.register({ name: 'worker', command: 'node', args: ['worker.js'], autoRestart: true });
 * await runtime.pm.start('worker');
 */
export class Runtime {
  /**
   * @param {RuntimeOptions} [options={}]
   */
  constructor(options = {}) {
    this._options = options;
    this._nodeId = options.nodeId ?? `heady-${options.nodeRole ?? 'standalone'}-${process.pid}`;
    this._nodeRole = options.nodeRole ?? 'standalone';
    this._started = false;
    this._pulseTimer = null;

    // ── Core Services ──────────────────────────────────────────────────────

    /**
     * Event bus for inter-component communication
     * @type {EventBus}
     */
    this.bus = new EventBus({
      nodeId: this._nodeId,
      persist: options.walPath,
    });

    /**
     * HTTP/WebSocket server
     * @type {HeadyHTTPServer}
     */
    this.http = new HeadyHTTPServer({
      port: options.port ?? 3000,
      host: options.host ?? '0.0.0.0',
      cors: options.cors !== false,
      requestLog: options.requestLog ?? false,
    });

    /**
     * MCP protocol server (tools, resources, prompts)
     * @type {MCPServer}
     */
    this.mcp = new MCPServer({
      name: `heady-${this._nodeRole}`,
      version: VERSION,
      ...(options.mcpOptions ?? {}),
    });

    /**
     * Process lifecycle manager
     * @type {ProcessManager}
     */
    this.pm = new ProcessManager({
      shutdownTimeout: options.processOptions?.shutdownTimeout ?? 10000,
    });

    /**
     * Cross-node event bridge (null if startBridge=false)
     * @type {EventBridgeServer|null}
     */
    this.bridge = options.startBridge
      ? new EventBridgeServer(this.bus, { port: options.bridgePort ?? 9100 })
      : null;

    /** @type {boolean} */
    this.healthy = false;
  }

  /**
   * Start all runtime services
   * @returns {Promise<{ port: number, nodeId: string, role: string, started: boolean }>}
   */
  async start() {
    if (this._started) return this._makeInfo();

    // 1. Start HTTP server
    const { port } = await this.http.listen();

    // 2. Attach SSE transport for MCP
    const sseTransport = new SSETransport();
    this.mcp.attachSSE(sseTransport);
    this._registerMCPRoutes(sseTransport);

    // 3. Start bridge server if enabled
    if (this.bridge) {
      await this.bridge.listen();
    }

    // 4. Register OS signal handlers for graceful shutdown
    this.pm.handleSignals();

    // 5. Emit startup event on the bus
    await this.bus.publish('runtime.started', {
      nodeId: this._nodeId,
      role: this._nodeRole,
      port,
      ts: Date.now(),
      phi: PHI,
    });

    // 6. Start PHI-scaled health pulse
    this._startPulse();

    this._started = true;
    this.healthy = true;

    return this._makeInfo(port);
  }

  /**
   * Register MCP HTTP/SSE routes on the HTTP server
   * @private
   * @param {SSETransport} sseTransport
   */
  _registerMCPRoutes(sseTransport) {
    // SSE stream endpoint: GET /mcp → opens SSE channel
    this.http.get('/mcp', (req, res) => {
      const sessionId = randomUUID();
      sseTransport.registerClient(sessionId, res);
    });

    // Message endpoint: POST /mcp/message?session=<id>
    this.http.post('/mcp/message', async (req, res) => {
      const sessionId = req.query?.session;
      if (!sessionId) {
        res.error(400, 'Missing session parameter');
        return;
      }
      if (!req.body) {
        res.error(400, 'Empty message body');
        return;
      }
      sseTransport.receiveMessage(sessionId, req.body);
      res.json({ ok: true });
    });

    // MCP introspection endpoint
    this.http.get('/mcp/info', (req, res) => {
      res.json({
        name: `heady-${this._nodeRole}`,
        version: VERSION,
        protocolVersion: '2024-11-05',
        sessions: this.mcp.sessionCount,
        tools: [...this.mcp._tools.keys()],
        resources: [...this.mcp._resources.keys()],
        nodeId: this._nodeId,
        role: this._nodeRole,
        phi: PHI,
      });
    });
  }

  /**
   * Start the PHI-scaled pulse loop.
   * Emits 'runtime.pulse' events every ~11 seconds (PHI^5 * 1000ms).
   * @private
   */
  _startPulse() {
    // PHI^5 * 1000ms ≈ 11,090ms
    const interval = Math.floor(Math.pow(PHI, 5) * 1000);
    this._pulseTimer = setInterval(async () => {
      if (!this._started) return;
      const mem = process.memoryUsage();
      await this.bus.publish('runtime.pulse', {
        nodeId: this._nodeId,
        role: this._nodeRole,
        ts: Date.now(),
        uptime: process.uptime(),
        memory: mem.heapUsed,
        phi_health: mem.heapUsed / mem.heapTotal,
        bus: this.bus.status,
        processes: this.pm.runningCount,
        wsConnections: this.http.wsConnectionCount,
      }, { priority: Priority.BACKGROUND }).catch(() => {});
    }, interval);

    if (this._pulseTimer.unref) this._pulseTimer.unref();
  }

  /**
   * Gracefully shut down all services in LIFO order.
   * Order: bridge → processes → bus → http → mcp
   * @returns {Promise<void>}
   */
  async shutdown() {
    if (!this._started) return;
    this._started = false;
    this.healthy = false;

    if (this._pulseTimer) {
      clearInterval(this._pulseTimer);
      this._pulseTimer = null;
    }

    try {
      await this.bus.publish('runtime.stopping', { nodeId: this._nodeId, ts: Date.now() });
    } catch (_) {}

    // LIFO order from start()
    if (this.bridge) await this.bridge.shutdown().catch(() => {});
    await this.pm.shutdown().catch(() => {});
    await this.bus.shutdown().catch(() => {});
    await this.http.shutdown().catch(() => {});
    await this.mcp.shutdown().catch(() => {});

    this.pm.removeSignalHandlers();
  }

  /** @private */
  _makeInfo(port) {
    return {
      nodeId: this._nodeId,
      role: this._nodeRole,
      port: port ?? this.http.port,
      started: this._started,
    };
  }

  /** @returns {boolean} */
  get started() { return this._started; }

  /** @returns {string} */
  get nodeId() { return this._nodeId; }

  /** @returns {string} */
  get nodeRole() { return this._nodeRole; }

  /** Get current system and runtime status */
  get status() {
    return {
      nodeId: this._nodeId,
      role: this._nodeRole,
      started: this._started,
      healthy: this.healthy,
      http: { port: this.http.port, listening: this.http.listening },
      bus: this.bus.status,
      processes: this.pm.status(),
      phi: PHI,
    };
  }
}

// ─── Cluster Node Factory ─────────────────────────────────────────────────────

/**
 * Create a Runtime pre-configured for a specific Heady cluster role.
 *
 * Sacred geometry resource ratios from ARCHITECTURE.md:
 * - BRAIN:      34% hot pool  → Fibonacci[8]=34  → central hub / origin
 * - CONDUCTOR:  21%+13% pool  → Fibonacci[7]+[6] → inner ring / processing
 * - SENTINEL:   8%+5% pool    → Fibonacci[5]+[3] → governance shell
 *
 * @param {'brain'|'conductor'|'sentinel'} role
 * @param {RuntimeOptions} [options]
 * @returns {Runtime}
 */
export function createClusterNode(role, options = {}) {
  const defaults = {
    brain:     { port: 3001, bridgePort: 9101 },
    conductor: { port: 3002, bridgePort: 9102 },
    sentinel:  { port: 3003, bridgePort: 9103 },
  };

  const roleDefaults = defaults[role] ?? { port: 3000, bridgePort: 9100 };

  return new Runtime({
    nodeRole: role,
    port: options.port ?? roleDefaults.port,
    bridgePort: options.bridgePort ?? roleDefaults.bridgePort,
    startBridge: options.startBridge ?? true,
    ...options,
  });
}

/**
 * Create a full 3-node local cluster (for single-machine development/testing)
 * @param {object} [options]
 * @param {RuntimeOptions} [options.brain]
 * @param {RuntimeOptions} [options.conductor]
 * @param {RuntimeOptions} [options.sentinel]
 * @returns {{ brain: Runtime, conductor: Runtime, sentinel: Runtime }}
 */
export function createLocalCluster(options = {}) {
  return {
    brain:     createClusterNode('brain',     options.brain     ?? {}),
    conductor: createClusterNode('conductor', options.conductor ?? {}),
    sentinel:  createClusterNode('sentinel',  options.sentinel  ?? {}),
  };
}

/**
 * Start a full local cluster and wire bridge connections
 * @param {object} [options]
 * @returns {Promise<{ brain: Runtime, conductor: Runtime, sentinel: Runtime }>}
 */
export async function startLocalCluster(options = {}) {
  const cluster = createLocalCluster(options);
  await cluster.brain.start();
  await cluster.conductor.start();
  await cluster.sentinel.start();

  // Connect bridges: brain ↔ conductor ↔ sentinel ↔ brain
  if (cluster.brain.bridge && cluster.conductor.bridge) {
    await cluster.brain.bridge.connect('127.0.0.1', 9102, 'conductor').catch(() => {});
    await cluster.conductor.bridge.connect('127.0.0.1', 9101, 'brain').catch(() => {});
    await cluster.sentinel.bridge.connect('127.0.0.1', 9101, 'brain').catch(() => {});
  }

  return cluster;
}

// ─── Version & Build Info ─────────────────────────────────────────────────────

/** @type {string} */
export const VERSION = '1.0.0';

/**
 * HeadyCore build metadata
 */
export const BUILD_INFO = Object.freeze({
  version: VERSION,
  nodeRequirement: '>=22.0.0',
  dependencies: 'zero',
  builtAt: new Date().toISOString(),
  modules: {
    'mcp-protocol':   'JSON-RPC 2.0, stdio+SSE, tools, resources, sessions',
    'github-client':  'REST API, App JWT, PHI backoff, pagination, all CRUD ops',
    'http-server':    'HTTP, WebSocket RFC-6455, SSE, CORS, compression, routing',
    'process-manager':'Spawn, LIFO shutdown, circuit breaker, health monitoring',
    'event-bus':      'Pub/sub, priority queue, WAL persistence, cross-node bridge',
  },
  sacredGeometry: {
    phi: PHI,
    phiSquared: PHI * PHI,
    phiCubed: PHI * PHI * PHI,
    goldenAngle: 2 * Math.PI * (2 - PHI), // ≈137.508° (sunflower spiral)
    fibonacci15: FIBONACCI,
    clusterRoles: {
      brain:     { resource: '34%', fibIndex: 8,  fib: FIBONACCI[8],  role: 'Central Hub' },
      conductor: { resource: '34%', fibIndex: '7+6', fib: FIBONACCI[7]+FIBONACCI[6], role: 'Inner Ring' },
      sentinel:  { resource: '13%', fibIndex: '5+3', fib: FIBONACCI[5]+FIBONACCI[3], role: 'Governance Shell' },
    },
  },
});

// ─── Default Export ───────────────────────────────────────────────────────────

export default {
  // ── Runtime ────────────────────────────────────────────────────
  Runtime,
  createClusterNode,
  createLocalCluster,
  startLocalCluster,

  // ── Core Modules ───────────────────────────────────────────────
  MCPServer,
  MCPClient,
  GitHubClient,
  HeadyHTTPServer,
  ProcessManager,
  EventBus,
  EventBridgeServer,

  // ── Auth factories ─────────────────────────────────────────────
  createTokenClient,
  createAppClient,
  getGlobalBus,

  // ── Sacred Geometry ────────────────────────────────────────────
  PHI,
  FIBONACCI,
  fib,

  // ── Metadata ───────────────────────────────────────────────────
  VERSION,
  BUILD_INFO,
};
