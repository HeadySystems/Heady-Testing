/**
 * @file github-client.js
 * @description Zero-dependency GitHub REST API client.
 *
 * Replaces @octokit/rest and @octokit/auth-app.
 * Uses native fetch() (Node 22+) and native crypto for JWT.
 * Implements PHI-scaled rate limit backoff and full pagination support.
 *
 * Sacred Geometry: PHI (φ=1.618) for exponential backoff timing.
 * Zero external dependencies - pure Node.js (crypto, https, url).
 *
 * @module HeadyCore/GitHubClient
 */

import { createSign, createHash, randomUUID } from 'crypto';
import { EventEmitter } from 'events';

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI = 1.6180339887498948482;
const FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610];

/**
 * PHI-scaled backoff delay
 * @param {number} attempt - 0-based attempt index
 * @param {number} [base=1000] - base delay ms
 * @returns {number} delay ms
 */
function phiBackoff(attempt, base = 1000) {
  return Math.floor(base * Math.pow(PHI, Math.min(attempt, 12)));
}

/**
 * Sleep for n ms
 * @param {number} ms
 * @returns {Promise<void>}
 */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ─── Base64url Encoding ───────────────────────────────────────────────────────

/**
 * Base64url encode a buffer or string (no padding)
 * @param {Buffer|string} data
 * @returns {string}
 */
function base64url(data) {
  const buf = typeof data === 'string' ? Buffer.from(data, 'utf8') : data;
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

// ─── JWT Generation ───────────────────────────────────────────────────────────

/**
 * Generate a GitHub App JWT using RS256 and native crypto.
 * @param {object} params
 * @param {string|number} params.appId - GitHub App ID
 * @param {string} params.privateKey - PEM-encoded RSA private key
 * @param {number} [params.expiresIn=600] - seconds (max 600 per GitHub)
 * @returns {string} signed JWT
 */
export function generateAppJWT({ appId, privateKey, expiresIn = 600 }) {
  const now = Math.floor(Date.now() / 1000);
  const header = base64url(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const payload = base64url(JSON.stringify({
    iat: now - 60, // 60s clock skew tolerance
    exp: now + Math.min(expiresIn, 600),
    iss: String(appId),
  }));

  const signingInput = `${header}.${payload}`;
  const signer = createSign('RSA-SHA256');
  signer.update(signingInput);
  const signature = base64url(signer.sign(privateKey));

  return `${signingInput}.${signature}`;
}

// ─── Token Cache ──────────────────────────────────────────────────────────────

/**
 * Simple in-memory token cache with TTL
 * @private
 */
class TokenCache {
  constructor() {
    /** @type {Map<string, { token: string, expiresAt: number }>} */
    this._cache = new Map();
  }

  /**
   * Get a cached token if still valid
   * @param {string} key
   * @param {number} [bufferMs=60000] - expire this many ms early
   * @returns {string|null}
   */
  get(key, bufferMs = 60000) {
    const entry = this._cache.get(key);
    if (!entry) return null;
    if (Date.now() + bufferMs >= entry.expiresAt) {
      this._cache.delete(key);
      return null;
    }
    return entry.token;
  }

  /**
   * Store a token with expiry
   * @param {string} key
   * @param {string} token
   * @param {number} expiresAt - unix ms
   */
  set(key, token, expiresAt) {
    this._cache.set(key, { token, expiresAt });
  }

  /** Purge all expired tokens */
  purge() {
    const now = Date.now();
    for (const [key, entry] of this._cache) {
      if (now >= entry.expiresAt) this._cache.delete(key);
    }
  }
}

// ─── Rate Limit Tracker ───────────────────────────────────────────────────────

/**
 * Tracks GitHub API rate limit headers
 */
class RateLimitTracker {
  constructor() {
    this.remaining = 5000;
    this.limit = 5000;
    this.reset = 0;
    this.used = 0;
    this.resource = 'core';
  }

  /**
   * Update from response headers
   * @param {Headers} headers
   */
  update(headers) {
    const remaining = headers.get('x-ratelimit-remaining');
    const limit = headers.get('x-ratelimit-limit');
    const reset = headers.get('x-ratelimit-reset');
    const used = headers.get('x-ratelimit-used');
    const resource = headers.get('x-ratelimit-resource');

    if (remaining !== null) this.remaining = parseInt(remaining, 10);
    if (limit !== null) this.limit = parseInt(limit, 10);
    if (reset !== null) this.reset = parseInt(reset, 10) * 1000; // to ms
    if (used !== null) this.used = parseInt(used, 10);
    if (resource !== null) this.resource = resource;
  }

  /** @returns {boolean} true if we should wait before next request */
  get shouldWait() {
    return this.remaining < 5 && this.reset > Date.now();
  }

  /** @returns {number} ms until rate limit resets */
  get msUntilReset() {
    return Math.max(0, this.reset - Date.now());
  }

  /** @returns {number} current usage ratio (0-1) */
  get usageRatio() {
    return this.limit > 0 ? this.used / this.limit : 0;
  }
}

// ─── GitHub Client ────────────────────────────────────────────────────────────

/**
 * Full GitHub REST API client - zero dependencies.
 *
 * Supports:
 * - Token authentication (PAT)
 * - GitHub App authentication (JWT + installation tokens)
 * - All core repo operations: CRUD, commits, branches, PRs, issues
 * - PHI-scaled rate limit backoff
 * - Automatic pagination
 *
 * @example
 * const gh = new GitHubClient({ token: process.env.GITHUB_TOKEN });
 * const repo = await gh.getRepo('owner', 'repo');
 *
 * @example App auth:
 * const gh = new GitHubClient({ appId: '123', privateKey: '...', installationId: 456 });
 * await gh.createFile('owner', 'repo', 'path/to/file.js', content, 'commit message');
 */
export class GitHubClient extends EventEmitter {
  /**
   * @param {object} options
   * @param {string} [options.token] - Personal Access Token or OAuth token
   * @param {string|number} [options.appId] - GitHub App ID
   * @param {string} [options.privateKey] - GitHub App private key (PEM)
   * @param {number|string} [options.installationId] - GitHub App installation ID
   * @param {string} [options.baseUrl='https://api.github.com']
   * @param {number} [options.maxRetries=5]
   * @param {string} [options.userAgent='HeadyCore/1.0.0']
   * @param {number} [options.timeout=30000] - request timeout ms
   */
  constructor(options = {}) {
    super();
    this._token = options.token ?? null;
    this._appId = options.appId ?? null;
    this._privateKey = options.privateKey ?? null;
    this._installationId = options.installationId ?? null;
    this._baseUrl = (options.baseUrl ?? 'https://api.github.com').replace(/\/$/, '');
    this._maxRetries = options.maxRetries ?? 5;
    this._userAgent = options.userAgent ?? 'HeadyCore/1.0.0 (github-client.js)';
    this._timeout = options.timeout ?? 30000;

    this._tokenCache = new TokenCache();
    this._rateLimits = {
      core: new RateLimitTracker(),
      search: new RateLimitTracker(),
      graphql: new RateLimitTracker(),
    };
  }

  // ── Authentication ─────────────────────────────────────────────────────────

  /**
   * Get current authentication token (PAT or installation token)
   * @returns {Promise<string>}
   * @private
   */
  async _getToken() {
    if (this._token) return this._token;

    if (this._appId && this._privateKey && this._installationId) {
      return await this._getInstallationToken();
    }

    throw new Error('GitHubClient: No authentication configured. Provide token or appId+privateKey+installationId.');
  }

  /**
   * Get (or refresh) a GitHub App installation access token
   * @returns {Promise<string>}
   * @private
   */
  async _getInstallationToken() {
    const cacheKey = `installation:${this._installationId}`;
    const cached = this._tokenCache.get(cacheKey);
    if (cached) return cached;

    const jwt = generateAppJWT({ appId: this._appId, privateKey: this._privateKey });

    const response = await this._rawRequest(
      'POST',
      `/app/installations/${this._installationId}/access_tokens`,
      null,
      { Authorization: `Bearer ${jwt}` }
    );

    const expiresAt = new Date(response.expires_at).getTime();
    this._tokenCache.set(cacheKey, response.token, expiresAt);
    this.emit('tokenRefreshed', { installationId: this._installationId });
    return response.token;
  }

  // ── Core HTTP ──────────────────────────────────────────────────────────────

  /**
   * Make a raw authenticated request (no retry)
   * @param {string} method
   * @param {string} path - relative to baseUrl, or absolute URL
   * @param {object|null} body
   * @param {object} [extraHeaders]
   * @returns {Promise<*>} parsed JSON or null for 204/304
   * @private
   */
  async _rawRequest(method, path, body = null, extraHeaders = {}) {
    const url = path.startsWith('http') ? path : `${this._baseUrl}${path}`;

    const headers = {
      'Accept': 'application/vnd.github+json',
      'User-Agent': this._userAgent,
      'X-GitHub-Api-Version': '2022-11-28',
      'Content-Type': 'application/json',
      ...extraHeaders,
    };

    if (!extraHeaders.Authorization) {
      const token = await this._getToken();
      headers['Authorization'] = `Bearer ${token}`;
    }

    const init = {
      method,
      headers,
      signal: AbortSignal.timeout(this._timeout),
    };

    if (body !== null && method !== 'GET' && method !== 'DELETE') {
      init.body = JSON.stringify(body);
    }

    const response = await fetch(url, init);

    // Update rate limit tracker
    const trackerKey = response.headers.get('x-ratelimit-resource') ?? 'core';
    if (this._rateLimits[trackerKey]) {
      this._rateLimits[trackerKey].update(response.headers);
    } else {
      this._rateLimits.core.update(response.headers);
    }

    this.emit('request', { method, url, status: response.status });

    if (response.status === 204 || response.status === 304) {
      return null;
    }

    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (_) {
      data = text;
    }

    if (!response.ok) {
      const err = new Error(data?.message ?? `GitHub API error: ${response.status}`);
      err.status = response.status;
      err.response = data;
      err.headers = Object.fromEntries(response.headers.entries());
      throw err;
    }

    // Attach pagination link header
    if (typeof data === 'object' && data !== null) {
      data._links = this._parseLinkHeader(response.headers.get('link'));
    }

    return data;
  }

  /**
   * Parse GitHub Link header into { next, prev, first, last } URLs
   * @param {string|null} header
   * @returns {object}
   * @private
   */
  _parseLinkHeader(header) {
    const links = {};
    if (!header) return links;
    for (const part of header.split(',')) {
      const match = part.trim().match(/<([^>]+)>;\s*rel="([^"]+)"/);
      if (match) links[match[2]] = match[1];
    }
    return links;
  }

  /**
   * Make an authenticated request with PHI-scaled retry and rate limit handling
   * @param {string} method
   * @param {string} path
   * @param {object|null} [body]
   * @param {object} [extraHeaders]
   * @returns {Promise<*>}
   */
  async request(method, path, body = null, extraHeaders = {}) {
    let attempt = 0;

    while (attempt <= this._maxRetries) {
      // Rate limit pre-check
      if (this._rateLimits.core.shouldWait) {
        const waitMs = this._rateLimits.core.msUntilReset + FIBONACCI[attempt % 15] * 100;
        this.emit('rateLimitWait', { waitMs, attempt });
        await sleep(waitMs);
      }

      try {
        return await this._rawRequest(method, path, body, extraHeaders);
      } catch (err) {
        const status = err.status;

        // 401: token expired for app auth - clear cache and retry once
        if (status === 401 && this._appId && attempt === 0) {
          const cacheKey = `installation:${this._installationId}`;
          // Remove cached token to force refresh
          this._tokenCache._cache.delete(cacheKey);
          attempt++;
          continue;
        }

        // 403 rate limit or 429 too many requests: wait and retry
        if (status === 403 || status === 429) {
          const retryAfter = err.headers?.['retry-after'];
          const waitMs = retryAfter
            ? parseInt(retryAfter, 10) * 1000
            : phiBackoff(attempt);
          this.emit('retrying', { attempt, status, waitMs });
          await sleep(waitMs);
          attempt++;
          continue;
        }

        // 5xx server errors: PHI backoff retry
        if (status >= 500 && attempt < this._maxRetries) {
          const waitMs = phiBackoff(attempt);
          this.emit('retrying', { attempt, status, waitMs });
          await sleep(waitMs);
          attempt++;
          continue;
        }

        throw err;
      }
    }

    throw new Error(`GitHub request failed after ${this._maxRetries} retries: ${method} ${path}`);
  }

  // ── Pagination ─────────────────────────────────────────────────────────────

  /**
   * Fetch all pages of a paginated endpoint
   * @param {string} path - initial path with optional ?per_page param
   * @param {object} [params] - query params
   * @param {number} [maxPages=Infinity] - limit pages to fetch
   * @returns {Promise<Array>} all items concatenated
   */
  async paginate(path, params = {}, maxPages = Infinity) {
    const items = [];
    let url = this._buildUrl(path, { per_page: 100, ...params });
    let page = 0;

    while (url && page < maxPages) {
      const data = await this.request('GET', url);
      if (!data) break;

      if (Array.isArray(data)) {
        items.push(...data);
      } else if (data.items) {
        items.push(...data.items);
      }

      url = data._links?.next ?? null;
      page++;
    }

    return items;
  }

  /**
   * Build URL with query params
   * @private
   */
  _buildUrl(path, params = {}) {
    const entries = Object.entries(params).filter(([_, v]) => v !== undefined && v !== null);
    if (entries.length === 0) return path;
    const qs = new URLSearchParams(entries.map(([k, v]) => [k, String(v)])).toString();
    const sep = path.includes('?') ? '&' : '?';
    return `${path}${sep}${qs}`;
  }

  // ── Repository Operations ──────────────────────────────────────────────────

  /**
   * Get repository info
   * @param {string} owner
   * @param {string} repo
   * @returns {Promise<object>}
   */
  async getRepo(owner, repo) {
    return this.request('GET', `/repos/${owner}/${repo}`);
  }

  /**
   * Create a new repository
   * @param {object} params
   * @param {string} params.name
   * @param {string} [params.description]
   * @param {boolean} [params.private=false]
   * @param {boolean} [params.auto_init=true]
   * @param {string} [params.gitignore_template]
   * @param {string} [params.license_template]
   * @param {string} [params.org] - org name; if omitted creates under authenticated user
   * @returns {Promise<object>}
   */
  async createRepo({ org, name, description, private: isPrivate = false, auto_init = true, ...rest }) {
    const path = org ? `/orgs/${org}/repos` : '/user/repos';
    return this.request('POST', path, {
      name,
      description,
      private: isPrivate,
      auto_init,
      ...rest,
    });
  }

  /**
   * Delete a repository
   * @param {string} owner
   * @param {string} repo
   */
  async deleteRepo(owner, repo) {
    return this.request('DELETE', `/repos/${owner}/${repo}`);
  }

  /**
   * Fork a repository
   * @param {string} owner
   * @param {string} repo
   * @param {object} [params]
   * @param {string} [params.organization]
   * @param {string} [params.name]
   */
  async forkRepo(owner, repo, params = {}) {
    return this.request('POST', `/repos/${owner}/${repo}/forks`, params);
  }

  /**
   * Update repository settings
   * @param {string} owner
   * @param {string} repo
   * @param {object} updates
   */
  async updateRepo(owner, repo, updates) {
    return this.request('PATCH', `/repos/${owner}/${repo}`, updates);
  }

  /**
   * List repositories for a user or org
   * @param {string} [ownerOrOrg] - if omitted, lists authenticated user repos
   * @param {object} [params]
   */
  async listRepos(ownerOrOrg, params = {}) {
    const path = ownerOrOrg ? `/users/${ownerOrOrg}/repos` : '/user/repos';
    return this.paginate(path, params);
  }

  // ── Branch Operations ──────────────────────────────────────────────────────

  /**
   * List branches
   * @param {string} owner
   * @param {string} repo
   */
  async listBranches(owner, repo) {
    return this.paginate(`/repos/${owner}/${repo}/branches`);
  }

  /**
   * Get a branch
   * @param {string} owner
   * @param {string} repo
   * @param {string} branch
   */
  async getBranch(owner, repo, branch) {
    return this.request('GET', `/repos/${owner}/${repo}/branches/${encodeURIComponent(branch)}`);
  }

  /**
   * Create a branch from a source ref
   * @param {string} owner
   * @param {string} repo
   * @param {string} branchName - new branch name
   * @param {string} [fromRef] - SHA or ref; defaults to default branch HEAD
   */
  async createBranch(owner, repo, branchName, fromRef) {
    let sha = fromRef;
    if (!sha) {
      const repoData = await this.getRepo(owner, repo);
      const defaultBranch = await this.getBranch(owner, repo, repoData.default_branch);
      sha = defaultBranch.commit.sha;
    } else if (!sha.match(/^[0-9a-f]{40}$/)) {
      // It's a ref name, resolve it
      const refData = await this.request('GET', `/repos/${owner}/${repo}/git/ref/heads/${encodeURIComponent(sha)}`);
      sha = refData.object.sha;
    }

    return this.request('POST', `/repos/${owner}/${repo}/git/refs`, {
      ref: `refs/heads/${branchName}`,
      sha,
    });
  }

  /**
   * Delete a branch
   * @param {string} owner
   * @param {string} repo
   * @param {string} branch
   */
  async deleteBranch(owner, repo, branch) {
    return this.request('DELETE', `/repos/${owner}/${repo}/git/refs/heads/${encodeURIComponent(branch)}`);
  }

  /**
   * Merge a branch
   * @param {string} owner
   * @param {string} repo
   * @param {string} base - branch to merge into
   * @param {string} head - branch or SHA to merge
   * @param {string} [commitMessage]
   */
  async mergeBranch(owner, repo, base, head, commitMessage) {
    return this.request('POST', `/repos/${owner}/${repo}/merges`, {
      base,
      head,
      ...(commitMessage ? { commit_message: commitMessage } : {}),
    });
  }

  // ── File / Content Operations ──────────────────────────────────────────────

  /**
   * Get file contents
   * @param {string} owner
   * @param {string} repo
   * @param {string} filePath
   * @param {string} [ref] - branch/tag/SHA
   * @returns {Promise<{ content: string, sha: string, encoding: string, ...}>}
   */
  async getFile(owner, repo, filePath, ref) {
    const path = this._buildUrl(
      `/repos/${owner}/${repo}/contents/${filePath}`,
      ref ? { ref } : {}
    );
    return this.request('GET', path);
  }

  /**
   * Get decoded file content as string
   * @param {string} owner
   * @param {string} repo
   * @param {string} filePath
   * @param {string} [ref]
   * @returns {Promise<string>}
   */
  async getFileContent(owner, repo, filePath, ref) {
    const file = await this.getFile(owner, repo, filePath, ref);
    if (file.encoding === 'base64') {
      return Buffer.from(file.content.replace(/\n/g, ''), 'base64').toString('utf8');
    }
    return file.content;
  }

  /**
   * Create a file
   * @param {string} owner
   * @param {string} repo
   * @param {string} filePath
   * @param {string|Buffer} content
   * @param {string} message - commit message
   * @param {string} [branch]
   * @param {string} [committerName]
   * @param {string} [committerEmail]
   */
  async createFile(owner, repo, filePath, content, message, branch, committerName, committerEmail) {
    const encoded = Buffer.isBuffer(content)
      ? content.toString('base64')
      : Buffer.from(content, 'utf8').toString('base64');

    const body = {
      message,
      content: encoded,
      ...(branch ? { branch } : {}),
      ...(committerName ? { committer: { name: committerName, email: committerEmail ?? '' } } : {}),
    };

    return this.request('PUT', `/repos/${owner}/${repo}/contents/${filePath}`, body);
  }

  /**
   * Update an existing file
   * @param {string} owner
   * @param {string} repo
   * @param {string} filePath
   * @param {string|Buffer} content
   * @param {string} message - commit message
   * @param {string} sha - current file SHA (from getFile)
   * @param {string} [branch]
   */
  async updateFile(owner, repo, filePath, content, message, sha, branch) {
    const encoded = Buffer.isBuffer(content)
      ? content.toString('base64')
      : Buffer.from(content, 'utf8').toString('base64');

    return this.request('PUT', `/repos/${owner}/${repo}/contents/${filePath}`, {
      message,
      content: encoded,
      sha,
      ...(branch ? { branch } : {}),
    });
  }

  /**
   * Delete a file
   * @param {string} owner
   * @param {string} repo
   * @param {string} filePath
   * @param {string} message
   * @param {string} sha
   * @param {string} [branch]
   */
  async deleteFile(owner, repo, filePath, message, sha, branch) {
    return this.request('DELETE', `/repos/${owner}/${repo}/contents/${filePath}`, {
      message,
      sha,
      ...(branch ? { branch } : {}),
    });
  }

  /**
   * Upsert a file (create or update automatically)
   * @param {string} owner
   * @param {string} repo
   * @param {string} filePath
   * @param {string|Buffer} content
   * @param {string} message
   * @param {string} [branch]
   */
  async upsertFile(owner, repo, filePath, content, message, branch) {
    try {
      const existing = await this.getFile(owner, repo, filePath, branch);
      return await this.updateFile(owner, repo, filePath, content, message, existing.sha, branch);
    } catch (err) {
      if (err.status === 404) {
        return await this.createFile(owner, repo, filePath, content, message, branch);
      }
      throw err;
    }
  }

  /**
   * List directory contents
   * @param {string} owner
   * @param {string} repo
   * @param {string} [dirPath='']
   * @param {string} [ref]
   */
  async listDirectory(owner, repo, dirPath = '', ref) {
    const path = this._buildUrl(
      `/repos/${owner}/${repo}/contents/${dirPath}`,
      ref ? { ref } : {}
    );
    return this.request('GET', path);
  }

  // ── Commit Operations ──────────────────────────────────────────────────────

  /**
   * Get a single commit
   * @param {string} owner
   * @param {string} repo
   * @param {string} ref - SHA, branch, or tag
   */
  async getCommit(owner, repo, ref) {
    return this.request('GET', `/repos/${owner}/${repo}/commits/${ref}`);
  }

  /**
   * List commits
   * @param {string} owner
   * @param {string} repo
   * @param {object} [params] - { sha, path, since, until, per_page }
   */
  async listCommits(owner, repo, params = {}) {
    return this.paginate(`/repos/${owner}/${repo}/commits`, params);
  }

  /**
   * Create a commit using the Git Data API (for multi-file commits)
   * @param {string} owner
   * @param {string} repo
   * @param {object} params
   * @param {string} params.message
   * @param {string} params.treeSha
   * @param {string[]} params.parents - parent commit SHAs
   * @param {object} [params.author] - { name, email, date }
   */
  async createCommit(owner, repo, { message, treeSha, parents, author }) {
    return this.request('POST', `/repos/${owner}/${repo}/git/commits`, {
      message,
      tree: treeSha,
      parents,
      ...(author ? { author } : {}),
    });
  }

  /**
   * Push multiple files in a single commit using Git Data API
   * @param {string} owner
   * @param {string} repo
   * @param {string} branch
   * @param {string} message - commit message
   * @param {Array<{ path: string, content: string|Buffer, mode?: string }>} files
   * @returns {Promise<object>} new commit object
   */
  async pushFiles(owner, repo, branch, message, files) {
    // Get current branch HEAD
    const refData = await this.request('GET', `/repos/${owner}/${repo}/git/ref/heads/${encodeURIComponent(branch)}`);
    const headSha = refData.object.sha;

    // Get base tree
    const headCommit = await this.request('GET', `/repos/${owner}/${repo}/git/commits/${headSha}`);
    const baseTreeSha = headCommit.tree.sha;

    // Create blob for each file
    const treeItems = await Promise.all(
      files.map(async (f) => {
        const content = Buffer.isBuffer(f.content) ? f.content.toString('utf8') : f.content;
        const blob = await this.request('POST', `/repos/${owner}/${repo}/git/blobs`, {
          content: Buffer.from(content).toString('base64'),
          encoding: 'base64',
        });
        return {
          path: f.path,
          mode: f.mode ?? '100644',
          type: 'blob',
          sha: blob.sha,
        };
      })
    );

    // Create new tree
    const newTree = await this.request('POST', `/repos/${owner}/${repo}/git/trees`, {
      base_tree: baseTreeSha,
      tree: treeItems,
    });

    // Create commit
    const newCommit = await this.createCommit(owner, repo, {
      message,
      treeSha: newTree.sha,
      parents: [headSha],
    });

    // Update branch ref
    await this.request('PATCH', `/repos/${owner}/${repo}/git/refs/heads/${encodeURIComponent(branch)}`, {
      sha: newCommit.sha,
      force: false,
    });

    return newCommit;
  }

  /**
   * Compare two commits/branches/tags
   * @param {string} owner
   * @param {string} repo
   * @param {string} base
   * @param {string} head
   */
  async compareCommits(owner, repo, base, head) {
    return this.request('GET', `/repos/${owner}/${repo}/compare/${base}...${head}`);
  }

  // ── Pull Request Operations ────────────────────────────────────────────────

  /**
   * List pull requests
   * @param {string} owner
   * @param {string} repo
   * @param {object} [params] - { state, head, base, sort, direction }
   */
  async listPRs(owner, repo, params = {}) {
    return this.paginate(`/repos/${owner}/${repo}/pulls`, { state: 'open', ...params });
  }

  /**
   * Get a pull request
   * @param {string} owner
   * @param {string} repo
   * @param {number} prNumber
   */
  async getPR(owner, repo, prNumber) {
    return this.request('GET', `/repos/${owner}/${repo}/pulls/${prNumber}`);
  }

  /**
   * Create a pull request
   * @param {string} owner
   * @param {string} repo
   * @param {object} params
   * @param {string} params.title
   * @param {string} params.head - branch name
   * @param {string} params.base - target branch
   * @param {string} [params.body]
   * @param {boolean} [params.draft=false]
   */
  async createPR(owner, repo, { title, head, base, body = '', draft = false, ...rest }) {
    return this.request('POST', `/repos/${owner}/${repo}/pulls`, {
      title,
      head,
      base,
      body,
      draft,
      ...rest,
    });
  }

  /**
   * Update a pull request
   * @param {string} owner
   * @param {string} repo
   * @param {number} prNumber
   * @param {object} updates
   */
  async updatePR(owner, repo, prNumber, updates) {
    return this.request('PATCH', `/repos/${owner}/${repo}/pulls/${prNumber}`, updates);
  }

  /**
   * Merge a pull request
   * @param {string} owner
   * @param {string} repo
   * @param {number} prNumber
   * @param {object} [params] - { merge_method, commit_title, commit_message }
   */
  async mergePR(owner, repo, prNumber, params = {}) {
    return this.request('PUT', `/repos/${owner}/${repo}/pulls/${prNumber}/merge`, {
      merge_method: 'merge',
      ...params,
    });
  }

  /**
   * List PR reviews
   * @param {string} owner
   * @param {string} repo
   * @param {number} prNumber
   */
  async listPRReviews(owner, repo, prNumber) {
    return this.paginate(`/repos/${owner}/${repo}/pulls/${prNumber}/reviews`);
  }

  /**
   * Request PR reviewers
   * @param {string} owner
   * @param {string} repo
   * @param {number} prNumber
   * @param {string[]} reviewers
   * @param {string[]} [teamReviewers]
   */
  async requestReviewers(owner, repo, prNumber, reviewers, teamReviewers = []) {
    return this.request('POST', `/repos/${owner}/${repo}/pulls/${prNumber}/requested_reviewers`, {
      reviewers,
      team_reviewers: teamReviewers,
    });
  }

  // ── Issues ─────────────────────────────────────────────────────────────────

  /**
   * List issues
   * @param {string} owner
   * @param {string} repo
   * @param {object} [params]
   */
  async listIssues(owner, repo, params = {}) {
    return this.paginate(`/repos/${owner}/${repo}/issues`, { state: 'open', ...params });
  }

  /**
   * Create an issue
   * @param {string} owner
   * @param {string} repo
   * @param {object} params - { title, body, labels, assignees, milestone }
   */
  async createIssue(owner, repo, params) {
    return this.request('POST', `/repos/${owner}/${repo}/issues`, params);
  }

  /**
   * Update an issue
   * @param {string} owner
   * @param {string} repo
   * @param {number} issueNumber
   * @param {object} updates
   */
  async updateIssue(owner, repo, issueNumber, updates) {
    return this.request('PATCH', `/repos/${owner}/${repo}/issues/${issueNumber}`, updates);
  }

  /**
   * Add a comment to an issue or PR
   * @param {string} owner
   * @param {string} repo
   * @param {number} issueNumber
   * @param {string} body
   */
  async addComment(owner, repo, issueNumber, body) {
    return this.request('POST', `/repos/${owner}/${repo}/issues/${issueNumber}/comments`, { body });
  }

  // ── Labels / Milestones ────────────────────────────────────────────────────

  /**
   * List labels
   * @param {string} owner
   * @param {string} repo
   */
  async listLabels(owner, repo) {
    return this.paginate(`/repos/${owner}/${repo}/labels`);
  }

  /**
   * Create a label
   * @param {string} owner
   * @param {string} repo
   * @param {object} params - { name, color, description }
   */
  async createLabel(owner, repo, params) {
    return this.request('POST', `/repos/${owner}/${repo}/labels`, params);
  }

  // ── Actions / Workflows ────────────────────────────────────────────────────

  /**
   * List workflow runs
   * @param {string} owner
   * @param {string} repo
   * @param {object} [params]
   */
  async listWorkflowRuns(owner, repo, params = {}) {
    return this.request('GET', this._buildUrl(`/repos/${owner}/${repo}/actions/runs`, params));
  }

  /**
   * Trigger a workflow dispatch event
   * @param {string} owner
   * @param {string} repo
   * @param {string} workflowId - workflow file name or ID
   * @param {string} ref - branch/tag
   * @param {object} [inputs]
   */
  async triggerWorkflow(owner, repo, workflowId, ref, inputs = {}) {
    return this.request('POST', `/repos/${owner}/${repo}/actions/workflows/${workflowId}/dispatches`, {
      ref,
      inputs,
    });
  }

  // ── Tags / Releases ────────────────────────────────────────────────────────

  /**
   * List releases
   * @param {string} owner
   * @param {string} repo
   */
  async listReleases(owner, repo) {
    return this.paginate(`/repos/${owner}/${repo}/releases`);
  }

  /**
   * Create a release
   * @param {string} owner
   * @param {string} repo
   * @param {object} params - { tag_name, name, body, draft, prerelease, target_commitish }
   */
  async createRelease(owner, repo, params) {
    return this.request('POST', `/repos/${owner}/${repo}/releases`, params);
  }

  /**
   * Create or update a tag ref
   * @param {string} owner
   * @param {string} repo
   * @param {string} tag
   * @param {string} sha
   */
  async createTag(owner, repo, tag, sha) {
    return this.request('POST', `/repos/${owner}/${repo}/git/refs`, {
      ref: `refs/tags/${tag}`,
      sha,
    });
  }

  // ── Users / Orgs ───────────────────────────────────────────────────────────

  /**
   * Get the authenticated user
   */
  async getAuthenticatedUser() {
    return this.request('GET', '/user');
  }

  /**
   * Get a user by login
   * @param {string} login
   */
  async getUser(login) {
    return this.request('GET', `/users/${login}`);
  }

  /**
   * Get an organization
   * @param {string} org
   */
  async getOrg(org) {
    return this.request('GET', `/orgs/${org}`);
  }

  // ── GitHub App ─────────────────────────────────────────────────────────────

  /**
   * List app installations
   * Requires JWT authentication
   */
  async listInstallations() {
    if (!this._appId || !this._privateKey) {
      throw new Error('App credentials required');
    }
    const jwt = generateAppJWT({ appId: this._appId, privateKey: this._privateKey });
    return this.paginate('/app/installations', {}, 10);
  }

  /**
   * Get installation info
   * @param {string|number} installationId
   */
  async getInstallation(installationId) {
    if (!this._appId || !this._privateKey) {
      throw new Error('App credentials required');
    }
    const jwt = generateAppJWT({ appId: this._appId, privateKey: this._privateKey });
    return this._rawRequest('GET', `/app/installations/${installationId}`, null, {
      Authorization: `Bearer ${jwt}`,
    });
  }

  // ── Search ─────────────────────────────────────────────────────────────────

  /**
   * Search code
   * @param {string} query
   * @param {object} [params]
   */
  async searchCode(query, params = {}) {
    return this.request('GET', this._buildUrl('/search/code', { q: query, ...params }));
  }

  /**
   * Search repositories
   * @param {string} query
   * @param {object} [params]
   */
  async searchRepos(query, params = {}) {
    return this.request('GET', this._buildUrl('/search/repositories', { q: query, ...params }));
  }

  /**
   * Search issues and PRs
   * @param {string} query
   * @param {object} [params]
   */
  async searchIssues(query, params = {}) {
    return this.request('GET', this._buildUrl('/search/issues', { q: query, ...params }));
  }

  // ── Rate Limit Info ────────────────────────────────────────────────────────

  /**
   * Get current rate limit info
   * @returns {Promise<object>}
   */
  async getRateLimit() {
    return this.request('GET', '/rate_limit');
  }

  /** @returns {object} cached rate limit state */
  get rateLimit() {
    return {
      core: {
        remaining: this._rateLimits.core.remaining,
        limit: this._rateLimits.core.limit,
        reset: this._rateLimits.core.reset,
        usageRatio: this._rateLimits.core.usageRatio,
      },
      search: {
        remaining: this._rateLimits.search.remaining,
        limit: this._rateLimits.search.limit,
      },
    };
  }
}

// ─── Factory ──────────────────────────────────────────────────────────────────

/**
 * Create a GitHubClient with token auth
 * @param {string} token
 * @param {object} [options]
 * @returns {GitHubClient}
 */
export function createTokenClient(token, options = {}) {
  return new GitHubClient({ token, ...options });
}

/**
 * Create a GitHubClient with GitHub App auth
 * @param {object} params
 * @param {string|number} params.appId
 * @param {string} params.privateKey
 * @param {number|string} params.installationId
 * @param {object} [options]
 * @returns {GitHubClient}
 */
export function createAppClient({ appId, privateKey, installationId }, options = {}) {
  return new GitHubClient({ appId, privateKey, installationId, ...options });
}

// Named exports for direct destructuring
export { PHI, FIBONACCI, phiBackoff };

// ─── Default Export ───────────────────────────────────────────────────────────

export default {
  GitHubClient,
  generateAppJWT,
  createTokenClient,
  createAppClient,
  phiBackoff,
  PHI,
  FIBONACCI,
};
