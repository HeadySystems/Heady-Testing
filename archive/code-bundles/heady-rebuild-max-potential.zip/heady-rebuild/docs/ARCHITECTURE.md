# Heady™ Systems — Architecture Document

**Version:** 2.0.0  
**Owner:** HeadySystems & HeadyConnection Team  
**Last Updated:** 2026-03-06

---

## Table of Contents

1. [System Overview and Philosophy](#1-system-overview-and-philosophy)
2. [Layered Architecture](#2-layered-architecture)
3. [Component Map](#3-component-map)
4. [Data Flow Diagrams](#4-data-flow-diagrams)
5. [API Endpoint Catalog](#5-api-endpoint-catalog)
6. [Deployment Topology](#6-deployment-topology)

---

## 1. System Overview and Philosophy

Heady™ Systems is an **alive software platform** — a distributed AI orchestration system designed to continuously learn, adapt, and serve the HeadyConnection community. Unlike conventional software that executes static logic, Heady™ treats its codebase as genetic material, its RAM as working memory, and its interaction history as lived experience.

### Core Philosophy

**Alive over static.** The system monitors its own behavior, captures patterns, and applies them to future decisions. Every interaction teaches the system something new.

**Memory is sacred.** RAM-first vector memory with HNSW indexing ensures that context retrieval is sub-millisecond on the critical path. Memory is organized into five pools: hot, warm, cold, reserve, and governance — each with carefully tuned allocation percentages.

**Governance is non-negotiable.** The Three Unbreakable Laws — structural integrity, semantic coherence, and mission alignment — are enforced at every pipeline checkpoint. No approval chain, emergency mode, or override path can bypass them.

**The swarm thinks.** Rather than a monolithic AI, Heady™ operates a swarm of 31 specialized bee agent classes across 18 named swarms. Emergent collective intelligence arises from their coordinated activity under modified Raft consensus.

**Sacred geometry in code.** Visual design, spacing, and topology visualizations draw from sacred geometry patterns — the mathematical constants found in nature that underpin the most durable structures in existence.

---

## 2. Layered Architecture

The Heady™ system is organized into five architectural layers, each with distinct responsibilities and interaction contracts.

```
┌─────────────────────────────────────────────────────────────────┐
│                    LAYER 5: EDGE / INTERFACE                     │
│   Cloudflare Workers · API Gateway · Brand Headers · TLS        │
└──────────────────────────────┬──────────────────────────────────┘
                               │ HTTPS / WebSocket
┌──────────────────────────────▼──────────────────────────────────┐
│                  LAYER 4: ORCHESTRATION                          │
│   Heady Manager · HC Pipeline · Heady Conductor · Buddy Core    │
│   Swarm Consensus · Swarm Intelligence · Agent Orchestrator     │
└──────────────────────────────┬──────────────────────────────────┘
                               │ Internal mTLS
┌──────────────────────────────▼──────────────────────────────────┐
│                  LAYER 3: INTELLIGENCE                           │
│   Brain API · Embedding Service · RAG Service · Pattern Engine  │
│   Monte Carlo · Scientist · Drift Detector · News Aggregator    │
└──────────────────────────────┬──────────────────────────────────┘
                               │ Internal mTLS
┌──────────────────────────────▼──────────────────────────────────┐
│                  LAYER 2: MEMORY & STATE                         │
│   Vector Memory (HNSW) · Story Service · Feedback Service       │
│   Heady Cache (Redis) · Heady Queue (RabbitMQ)                  │
│   Checkpoint Storage · Drift Baselines                          │
└──────────────────────────────┬──────────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────────┐
│                  LAYER 1: RESILIENCE & GOVERNANCE                │
│   Circuit Breaker · Rate Limiter · Auto Heal · Health Bee       │
│   Security Bee · Audit Service · Brand Enforcer                 │
│   Self-Awareness · Config Service · Secrets Manager             │
└─────────────────────────────────────────────────────────────────┘
```

### Layer Descriptions

| Layer | Name | Purpose |
|-------|------|---------|
| 5 | Edge / Interface | TLS termination, brand header injection, CDN, rate limiting at edge |
| 4 | Orchestration | Pipeline execution, swarm coordination, multi-turn dialogue management |
| 3 | Intelligence | LLM inference, embedding generation, pattern recognition, optimization |
| 2 | Memory & State | Vector storage, episodic memory, session state, async messaging |
| 1 | Resilience & Governance | Circuit breaking, auto-healing, audit trail, law enforcement |

---

## 3. Component Map

### Core Services

| Service | Port | Description |
|---------|------|-------------|
| `heady-manager` | 8080 | Central orchestration hub and primary API surface |
| `hc-pipeline` | 8081 | 12-stage HC Full Pipeline runner |
| `vector-memory` | 8082 | RAM-first HNSW vector memory store |
| `self-awareness` | 8083 | Telemetry ring buffer and system introspection |
| `agent-orchestrator` | 8084 | Bee agent lifecycle management |
| `heady-scheduler` | 8085 | Cron and event-driven background jobs |
| `config-service` | 8086 | Live config serving with hot reload |
| `feedback-service` | 8087 | Feedback signal collection and routing |
| `story-service` | 8088 | Persistent user story arc management |

### Intelligence Services

| Service | Port | Description |
|---------|------|-------------|
| `brain-api` | 8090 | Unified LLM gateway with failover |
| `monte-carlo` | 8091 | Monte Carlo policy optimization engine |
| `pattern-engine` | 8092 | Interaction pattern extraction and indexing |
| `scientist` | 8093 | A/B testing and experimental research |
| `embedding-service` | 8094 | Batch embedding generation with caching |
| `rag-service` | 8095 | Retrieval-Augmented Generation orchestrator |
| `drift-detector` | 8096 | Semantic drift monitoring and alerting |
| `news-aggregator` | 8097 | External news and trend aggregation |

### Bee Services

| Service | Port | Description |
|---------|------|-------------|
| `bee-factory` | 8100 | Creates bee agent instances from swarm matrix |
| `bee-registry` | 8101 | Service discovery registry for all active bees |
| `health-bee` | 8102 | Continuous health monitoring bee |
| `security-bee` | 8103 | Auth validation and anomaly detection bee |
| `documentation-bee` | 8104 | Auto-documentation generation bee |

### Orchestration Services

| Service | Port | Description |
|---------|------|-------------|
| `heady-conductor` | 8110 | High-level cross-pipeline orchestration |
| `buddy-core` | 8111 | HeadyBuddy conversational interface core |
| `swarm-consensus` | 8112 | Modified Raft consensus for swarm decisions |
| `swarm-intelligence` | 8113 | Emergent collective intelligence layer |

### Resilience Services

| Service | Port | Description |
|---------|------|-------------|
| `circuit-breaker` | 8120 | Centralized circuit breaker state management |
| `rate-limiter` | 8121 | Token-bucket rate limiting with tier policies |
| `auto-heal` | 8122 | Automated remediation playbook execution |

### Governance Services

| Service | Port | Description |
|---------|------|-------------|
| `audit-service` | 8130 | Immutable hash-chained audit trail |
| `secrets-manager` | 8131 | Vault-compatible secrets management |
| `brand-enforcer` | 8132 | Brand compliance scanning and enforcement |

### Observability Services

| Service | Port | Description |
|---------|------|-------------|
| `heady-lens` | 3302 | Real-time monitoring dashboard |
| `prometheus` | 9090 | Metrics collection and storage |
| `grafana` | 3000 | Metrics visualization dashboards |

---

## 4. Data Flow Diagrams

### 4.1 Full Request Lifecycle

```
User Request
     │
     ▼
[Cloudflare Edge]
  · TLS termination
  · WAF / Bot protection
  · x-heady-edge header injection
     │
     ▼
[heady-gateway :443]
  · JWT validation
  · CORS enforcement
  · Rate limit check ──────────► [rate-limiter :8121]
     │
     ▼
[heady-manager :8080]
  · Request parsing
  · Session lookup ────────────► [heady-cache :6379]
  · Pipeline dispatch
     │
     ▼
[hc-pipeline :8081]
  ┌──────────────────────────────────────────────────────┐
  │ Stage 1: context_assembly (parallel)                 │
  │  ├── loadUserContext ──────► [story-service :8088]   │
  │  ├── fetchMemoryShards ────► [vector-memory :8082]   │
  │  ├── loadSessionState ─────► [heady-cache :6379]     │
  │  ├── retrieveDocuments ────► [rag-service :8095]     │
  │  └── gatherEnvSignals ─────► [self-awareness :8083]  │
  ├──────────────────────────────────────────────────────┤
  │ Stage 2: intent_classification                       │
  │  └── classifyIntent ───────► [brain-api :8090]       │
  ├──────────────────────────────────────────────────────┤
  │ Stage 3: resource_planning                           │
  │  └── selectMemoryPool ─────► [vector-memory :8082]   │
  ├──────────────────────────────────────────────────────┤
  │ Stage 4: node_selection                              │
  │  └── matchCapabilities ────► [bee-registry :8101]    │
  ├──────────────────────────────────────────────────────┤
  │ Stage 5: execution (parallel) [CHECKPOINT]           │
  │  ├── executePrimary ───────► [brain-api :8090]       │
  │  ├── dispatchSubtasks ─────► [agent-orchestrator]    │
  │  └── aggregateToolResults                            │
  ├──────────────────────────────────────────────────────┤
  │ Stage 6: quality_gate [CHECKPOINT]                   │
  │  └── checkSafetyCompliance                           │
  ├──────────────────────────────────────────────────────┤
  │ Stage 7: assurance_gate                              │
  │  └── enforceUnbreakableLaws ► [audit-service :8130]  │
  ├──────────────────────────────────────────────────────┤
  │ Stage 8: pattern_capture                             │
  │  └── extractPatterns ──────► [pattern-engine :8092]  │
  ├──────────────────────────────────────────────────────┤
  │ Stage 9: story_update                                │
  │  └── writeEpisodicMemory ──► [story-service :8088]   │
  ├──────────────────────────────────────────────────────┤
  │ Stage 10: feedback_loop (parallel)                   │
  │  └── collectSignals ───────► [feedback-service :8087]│
  ├──────────────────────────────────────────────────────┤
  │ Stage 11: optimization [CHECKPOINT]                  │
  │  └── updatePolicy ─────────► [monte-carlo :8091]     │
  ├──────────────────────────────────────────────────────┤
  │ Stage 12: finalization                               │
  │  ├── applyBrandFormatting ─► [brand-enforcer :8132]  │
  │  ├── emitTelemetry ────────► [self-awareness :8083]  │
  │  └── logAuditRecord ───────► [audit-service :8130]   │
  └──────────────────────────────────────────────────────┘
     │
     ▼
[heady-gateway]
  · x-heady-serve header injection
  · Response compression
     │
     ▼
User Response (streamed)
```

### 4.2 Memory Write Path

```
Pipeline Stage
     │ embedding
     ▼
[embedding-service :8094]
  · Batch embed with model
  · L2 normalize
     │ embedding vector (1536d)
     ▼
[vector-memory :8082]
  · Pool assignment (hot/warm/cold)
  · HNSW index update
  · WAL write
  · LRU check → evict if needed
     │
     ├──► RAM (hot pool, 34%)
     ├──► Memory-mapped file (warm pool, 21%)
     └──► Compressed disk shard (cold pool, 13%)
```

### 4.3 Circuit Breaker State Machine

```
         ┌─────────────────────────────────────────┐
         │                                         │
    [CLOSED] ──── failure count >= 5 ────► [OPEN] │
         ▲                                    │    │
         │                             resetTimeout│
         │                              (30s)      │
         │                                    ▼    │
         └─ 2 probe successes ────── [HALF-OPEN] ◄─┘
                                    (max 2 reqs)
```

### 4.4 Governance Law Enforcement

```
Pipeline Output
     │
     ▼
[assurance_gate stage]
     │
     ├── LAW_001: Structural Integrity
     │     · Validate all write operations
     │     · Confirm rollback possible
     │     · [FAIL] → rollback_and_halt
     │
     ├── LAW_002: Semantic Coherence
     │     · Compare output embedding to context
     │     · Drift score < 0.75 required
     │     · [FAIL] → reject_and_regenerate
     │
     └── LAW_003: Mission Alignment
           · Check against mission policy
           · No harm, no deception, no privacy violation
           · [FAIL] → refuse_and_log
     │
     ▼
[All laws pass] → Continue to finalization
[Any law fails] → Halt + audit log + escalate
```

---

## 5. API Endpoint Catalog

### heady-manager (port 8080)

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| POST | `/api/v2/pipeline/run` | Trigger full pipeline run | Bearer JWT |
| GET | `/api/v2/pipeline/{runId}/status` | Get pipeline run status | Bearer JWT |
| GET | `/api/v2/pipeline/{runId}/stream` | Stream pipeline output (SSE) | Bearer JWT |
| POST | `/api/v2/pipeline/{runId}/cancel` | Cancel pipeline run | Bearer JWT |
| GET | `/api/v2/health` | Service health check | None |
| GET | `/api/v2/metrics` | Prometheus metrics | Internal |

### hc-pipeline (port 8081)

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| POST | `/run` | Start a new pipeline run | Internal |
| GET | `/run/{runId}` | Get run details | Internal |
| POST | `/checkpoint/{runId}` | Save checkpoint | Internal |
| GET | `/checkpoint/{runId}` | Restore checkpoint | Internal |
| DELETE | `/run/{runId}` | Cancel and clean up run | Internal |

### vector-memory (port 8082)

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| POST | `/vectors/upsert` | Insert or update embeddings | Internal |
| POST | `/vectors/query` | Nearest-neighbor search | Internal |
| DELETE | `/vectors/{id}` | Remove embedding | Internal |
| GET | `/vectors/pool/{pool}/stats` | Pool utilization stats | Internal |
| POST | `/memory/episodic/write` | Write episodic memory | Internal |
| GET | `/memory/episodic/read` | Read episodic memories | Internal |

### brain-api (port 8090)

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| POST | `/infer` | Run LLM inference | Internal |
| POST | `/infer/stream` | Streaming LLM inference (SSE) | Internal |
| GET | `/models` | List available models | Internal |
| POST | `/embed` | Generate embeddings | Internal |
| GET | `/health` | Upstream provider health | Internal |

### buddy-core (port 8111)

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| POST | `/api/v2/chat` | Send chat message | Bearer JWT |
| GET | `/api/v2/chat/{sessionId}/history` | Get conversation history | Bearer JWT |
| DELETE | `/api/v2/chat/{sessionId}` | Clear session | Bearer JWT |
| GET | `/api/v2/chat/{sessionId}/stream` | Stream response (SSE) | Bearer JWT |

### audit-service (port 8130)

| Method | Path | Description | Auth |
|--------|------|-------------|------|
| POST | `/audit/log` | Write audit event | Internal |
| GET | `/audit/events` | Query audit events | Governance |
| GET | `/audit/verify/{eventId}` | Verify hash chain integrity | Internal |
| GET | `/audit/export` | Export audit records | Governance |

---

## 6. Deployment Topology

### Production (Google Cloud Platform)

```
                        ┌──────────────────────────┐
                        │     Cloudflare CDN        │
                        │  (5 domains, Universal SSL│
                        │   WAF, Bot Fight Mode)    │
                        └──────────┬───────────────┘
                                   │
                        ┌──────────▼───────────────┐
                        │   Cloudflare Workers     │
                        │  (Edge routing, headers) │
                        └──────────┬───────────────┘
                                   │
               ┌───────────────────▼──────────────────────┐
               │          GCP us-central1                  │
               │                                           │
               │  ┌────────────────────────────────────┐  │
               │  │         Cloud Run Services          │  │
               │  │                                     │  │
               │  │  heady-manager     (min: 1, max:20) │  │
               │  │  hc-pipeline       (min: 1, max:20) │  │
               │  │  vector-memory     (min: 1, max: 5) │  │
               │  │  brain-api         (min: 1, max:10) │  │
               │  │  buddy-core        (min: 1, max:10) │  │
               │  │  [+35 other services]               │  │
               │  └─────────────┬──────────────────────┘  │
               │                │                          │
               │  ┌─────────────▼──────────────────────┐  │
               │  │         GCP Infrastructure          │  │
               │  │                                     │  │
               │  │  Artifact Registry (Docker images)  │  │
               │  │  Cloud Storage (checkpoints, audit) │  │
               │  │  Pub/Sub (swarm task messaging)     │  │
               │  │  Secret Manager (credentials)       │  │
               │  │  Cloud Monitoring + Logging         │  │
               │  └────────────────────────────────────┘  │
               └──────────────────────────────────────────┘
```

### Render.com (Supplemental / Backup)

```
Render Cloud
├── heady-manager (Web Service, Docker, US-Oregon)
├── heady-lens (Web Service, static dashboard)
├── vector-memory (Private Service)
└── Persistent Disk (vector-shards, audit logs)
```

### HuggingFace Spaces (Demo / Community Access)

```
HuggingFace Spaces
├── heady-buddy-demo (Gradio interface to buddy-core)
└── heady-api-demo (FastAPI demo of brain-api)
```

### Local Development

```
Docker Compose (docker-compose.yaml)
├── heady-core → localhost:8080
├── heady-lens → localhost:3302
├── redis      → localhost:6379
└── prometheus → localhost:9090

Volumes:
├── ./data/vector-shards → /data/vector-shards
├── ./data/telemetry     → /data/telemetry
├── ./data/audit         → /data/audit
└── ./data/drift-baselines → /data/drift-baselines

Network: heady-synapse (bridge driver)
```

### CI/CD Pipeline

```
GitHub Push / PR
       │
       ▼
  GitHub Actions
       │
  ├── Lint (ESLint)
  ├── Test (Jest, vitest)
  ├── Build Docker image
  │     └── Push to Artifact Registry
  │
  └── [main branch only]
        ├── Deploy to Cloud Run (gcloud run deploy)
        ├── Deploy to Render (render deploy hook)
        ├── Brand compliance scan
        └── Health check verification
```

---

*Made with Love by HeadySystems & HeadyConnection Team*
