# Heady™ Systems — Rebuild Instructions

**Version:** 2.0.0  
**Last Updated:** 2026-03-06

This guide walks you through a complete rebuild of the Heady™ Systems platform from scratch — from prerequisites through production deployment on all supported targets.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Clone and Setup](#2-clone-and-setup)
3. [Environment Variables](#3-environment-variables)
4. [Local Development](#4-local-development)
5. [Docker Build](#5-docker-build)
6. [Cloud Run Deployment](#6-cloud-run-deployment)
7. [Render Deployment](#7-render-deployment)
8. [Cloudflare Workers Setup](#8-cloudflare-workers-setup)
9. [Health Verification](#9-health-verification)
10. [Troubleshooting](#10-troubleshooting)

---

## 1. Prerequisites

### Required Tools

| Tool | Minimum Version | Install |
|------|----------------|---------|
| Node.js | 20.x LTS | https://nodejs.org or `nvm install 20` |
| npm | 10.x | Bundled with Node 20 |
| Docker | 24.x | https://docs.docker.com/get-docker/ |
| Docker Compose | 2.x (plugin) | Bundled with Docker Desktop |
| Git | 2.40+ | https://git-scm.com |
| Google Cloud CLI | 450.0.0+ | https://cloud.google.com/sdk/docs/install |
| Terraform | 1.7+ | https://developer.hashicorp.com/terraform/install |
| Wrangler (Cloudflare) | 3.x | `npm install -g wrangler` |

### Required Accounts

- **Google Cloud Platform** — Project with billing enabled
- **Cloudflare** — Account with zones for all 5 production domains
- **GitHub** — Repository access for CI/CD
- **Docker Hub / Artifact Registry** — Container registry access

### System Resources (Development)

- RAM: 8 GB minimum, 16 GB recommended
- Disk: 20 GB free
- CPU: 4 cores minimum

### Verify Prerequisites

```bash
node --version        # v20.x.x
npm --version         # 10.x.x
docker --version      # Docker version 24.x.x
docker compose version # Docker Compose version v2.x.x
git --version         # git version 2.40+
gcloud --version      # Google Cloud SDK 450.0.0+
terraform --version   # Terraform v1.7.x
wrangler --version    # 3.x.x
```

---

## 2. Clone and Setup

### 2.1 Clone the Repository

```bash
git clone https://github.com/headysystems/heady-rebuild.git
cd heady-rebuild
```

### 2.2 Install Dependencies

```bash
npm ci
```

> **Important:** Always use `npm ci` (not `npm install`) for reproducible installs. `npm ci` installs exactly what is specified in `package-lock.json`.

### 2.3 Copy Environment Template

```bash
cp .env.example .env
```

Then edit `.env` with your actual credentials. See [Section 3](#3-environment-variables) for full reference.

### 2.4 Validate Configuration Files

```bash
# Validate YAML configs
node scripts/validate-configs.js

# Check for forbidden strings in configs
node scripts/brand-check.js --configs-only
```

Both commands should exit with code 0.

---

## 3. Environment Variables

Copy `.env.example` to `.env` and populate each variable. Required variables will cause startup failure if missing. Optional variables activate enhanced features.

### Core Variables (Required)

```dotenv
# Server
PORT=8080
NODE_ENV=production

# LLM Provider
LLM_PROVIDER=openai
LLM_API_KEY=sk-...
LLM_MODEL_DEFAULT=gpt-4o

# Embedding Service  
EMBEDDING_MODEL=text-embedding-3-small
EMBEDDING_API_KEY=sk-...

# Vector Memory
VECTOR_DIM=1536
SHARD_COUNT=16
DATA_DIR=/data

# Pipeline
PIPELINE_CONFIG_PATH=configs/pipeline/hcfullpipeline.yaml
CHECKPOINT_STORAGE=local

# Observability
OTEL_EXPORTER_ENDPOINT=http://heady-lens:4318/v1/traces
RING_BUFFER_SIZE=500
TELEMETRY_FLUSH_INTERVAL_MS=5000

# Governance
AUDIT_STORAGE=local
ESCALATION_WEBHOOK_URL=https://hooks.slack.com/...
```

### Cloud Variables (Required for Cloud Deployments)

```dotenv
# Google Cloud
GOOGLE_CLOUD_PROJECT=your-project-id
GOOGLE_CLOUD_REGION=us-central1
GCS_BUCKET=your-heady-checkpoints-bucket
ARTIFACT_REGISTRY_HOST=us-central1-docker.pkg.dev
ARTIFACT_REGISTRY_REPO=heady-images

# Cloud Run URLs (set after first deploy)
CLOUD_RUN_URL_HEADYSYSTEMS=https://heady-manager-xxxx-uc.a.run.app
CLOUD_RUN_URL_HEADYCONNECTION=https://heady-manager-conn-xxxx-uc.a.run.app
CLOUD_RUN_URL_HEADYMCP=https://heady-mcp-xxxx-uc.a.run.app
CLOUD_RUN_URL_HEADYIO=https://heady-io-xxxx-uc.a.run.app
CLOUD_RUN_URL_HEADYBUDDY=https://heady-buddy-xxxx-uc.a.run.app
```

### Cloudflare Variables (Required for Cloudflare Workers)

```dotenv
CLOUDFLARE_ACCOUNT_ID=your-account-id
CLOUDFLARE_API_TOKEN=your-api-token
CLOUDFLARE_ZONE_ID_HEADYSYSTEMS=zone-id-for-headysystems.com
CLOUDFLARE_ZONE_ID_HEADYCONNECTION=zone-id-for-headyconnection.org
```

### Optional Variables

```dotenv
# LLM Fallback
LLM_FALLBACK_PROVIDER=anthropic
LLM_FALLBACK_MODEL=claude-3-5-sonnet-20241022
LLM_FALLBACK_API_KEY=sk-ant-...

# External APIs
NEWS_API_URL=https://newsapi.org/v2
NEWS_API_KEY=your-news-api-key

# Render.com
RENDER_DEPLOY_HOOK=https://api.render.com/deploy/srv-...

# HuggingFace
HUGGINGFACE_TOKEN=hf_...
HUGGINGFACE_SPACE=headysystems/heady-buddy-demo

# Performance tuning
MAX_CONCURRENT_STAGES=8
DEFAULT_TIMEOUT_MS=30000
MAX_PIPELINE_CONCURRENCY=5
MAX_AGENTS_PER_SWARM=20

# Logging
LOG_LEVEL=info
TELEMETRY_STDOUT_ENABLED=false
```

---

## 4. Local Development

### 4.1 Start with Docker Compose (Recommended)

```bash
# Start all services
docker compose up

# Start in background
docker compose up -d

# Watch logs
docker compose logs -f heady-core

# Stop
docker compose down

# Stop and remove volumes (clean slate)
docker compose down -v
```

Services will be available at:
- Heady Core API: http://localhost:8080
- Heady Lens (monitoring): http://localhost:3302
- Prometheus: http://localhost:9090

### 4.2 Start Without Docker

```bash
# Install dependencies
npm ci

# Start in development mode (hot reload)
npm run dev

# In a separate terminal, start the lens dashboard
npm run lens:dev
```

### 4.3 Run Tests

```bash
# All tests
npm test

# Watch mode
npm run test:watch

# With coverage
npm run test:coverage

# Specific test file
npm test -- tests/hc-full-pipeline.test.js
```

### 4.4 Initialize Vector Memory (First Run)

```bash
# Initialize shards and baselines
node scripts/heady-swarm-ignition.sh

# Or using npm
npm run init:memory
```

### 4.5 Development Utilities

```bash
# Validate all YAML configs
npm run validate:configs

# Run brand compliance check
npm run check:brand

# Check for forbidden strings
npm run check:forbidden

# Generate API documentation
npm run docs:generate

# View current system health
curl http://localhost:8080/api/v2/health | jq
```

---

## 5. Docker Build

### 5.1 Build the Production Image

```bash
# Build with default tag
docker build -t heady-manager:latest .

# Build with version tag
docker build -t heady-manager:2.0.0 .

# Build with both
docker build \
  -t heady-manager:latest \
  -t heady-manager:2.0.0 \
  --build-arg NODE_ENV=production \
  .
```

### 5.2 Test the Image Locally

```bash
# Run the container
docker run --rm \
  -p 8080:8080 \
  --env-file .env \
  -v $(pwd)/data:/data \
  heady-manager:latest

# Verify health
curl http://localhost:8080/health
```

### 5.3 Inspect the Image

```bash
# View layers and size
docker image inspect heady-manager:latest

# Check for non-root user
docker run --rm heady-manager:latest whoami
# Expected output: heady

# View data directory structure
docker run --rm heady-manager:latest ls -la /data
```

### 5.4 Push to Artifact Registry

```bash
# Authenticate
gcloud auth configure-docker us-central1-docker.pkg.dev

# Tag for registry
docker tag heady-manager:latest \
  us-central1-docker.pkg.dev/${GOOGLE_CLOUD_PROJECT}/heady-images/heady-manager:latest

# Push
docker push \
  us-central1-docker.pkg.dev/${GOOGLE_CLOUD_PROJECT}/heady-images/heady-manager:latest
```

---

## 6. Cloud Run Deployment

### 6.1 Initialize GCP (First Time)

```bash
# Set project
gcloud config set project YOUR_PROJECT_ID

# Enable required APIs
gcloud services enable \
  run.googleapis.com \
  artifactregistry.googleapis.com \
  pubsub.googleapis.com \
  secretmanager.googleapis.com \
  cloudbuild.googleapis.com

# Create Artifact Registry repo
gcloud artifacts repositories create heady-images \
  --repository-format=docker \
  --location=us-central1 \
  --description="Heady Systems Docker images"
```

### 6.2 Apply Terraform Infrastructure

```bash
cd infra

# Initialize Terraform
terraform init

# Review plan
terraform plan -var="project_id=${GOOGLE_CLOUD_PROJECT}"

# Apply
terraform apply -var="project_id=${GOOGLE_CLOUD_PROJECT}"

cd ..
```

### 6.3 Deploy with Script

```bash
# Full deploy (build + push + deploy to Cloud Run)
node scripts/deploy.js --target cloud-run

# Deploy only (image already in registry)
node scripts/deploy.js --target cloud-run --skip-build

# Deploy and run health check
node scripts/deploy.js --target cloud-run --health-check
```

### 6.4 Manual Deploy

```bash
# Build and push image
docker build -t heady-manager:latest .
docker tag heady-manager:latest \
  us-central1-docker.pkg.dev/${GOOGLE_CLOUD_PROJECT}/heady-images/heady-manager:latest
docker push \
  us-central1-docker.pkg.dev/${GOOGLE_CLOUD_PROJECT}/heady-images/heady-manager:latest

# Deploy to Cloud Run
gcloud run deploy heady-manager \
  --image us-central1-docker.pkg.dev/${GOOGLE_CLOUD_PROJECT}/heady-images/heady-manager:latest \
  --platform managed \
  --region us-central1 \
  --port 8080 \
  --min-instances 1 \
  --max-instances 20 \
  --memory 2Gi \
  --cpu 2 \
  --set-env-vars "NODE_ENV=production" \
  --set-secrets "LLM_API_KEY=heady-llm-api-key:latest" \
  --allow-unauthenticated

# Get the service URL
gcloud run services describe heady-manager \
  --region us-central1 \
  --format 'value(status.url)'
```

### 6.5 Set Up Cloud Run Domain Mapping

```bash
# Map custom domain
gcloud run domain-mappings create \
  --service heady-manager \
  --domain api.headysystems.com \
  --region us-central1

# Verify DNS records
gcloud run domain-mappings describe \
  --domain api.headysystems.com \
  --region us-central1
```

---

## 7. Render Deployment

### 7.1 Initial Setup

1. Log in to [render.com](https://render.com)
2. Create a new **Web Service**
3. Connect your GitHub repository
4. Configure:
   - **Environment:** Docker
   - **Region:** Oregon (US West)
   - **Instance Type:** Standard (2 GB RAM)
   - **Port:** 8080

### 7.2 Environment Variables

In the Render dashboard, add all variables from your `.env` file under **Environment → Environment Variables**.

For secrets, use Render's **Secret Files** or **Secret Environment Variables** feature.

### 7.3 Deploy via Hook

```bash
# Trigger deploy via webhook (set RENDER_DEPLOY_HOOK in .env)
node scripts/deploy.js --target render

# Or directly
curl -X POST "${RENDER_DEPLOY_HOOK}"
```

### 7.4 Persistent Disk

In the Render dashboard:
1. Go to your service → **Disks**
2. Add a disk:
   - **Mount path:** `/data`
   - **Size:** 10 GB minimum

---

## 8. Cloudflare Workers Setup

### 8.1 Authenticate Wrangler

```bash
wrangler login
```

### 8.2 Deploy Edge Workers

```bash
# Deploy the edge routing worker
cd workers/heady-edge
wrangler deploy

# Deploy the brand enforcement worker
cd workers/heady-brand
wrangler deploy

cd ../..
```

### 8.3 Configure Domain Routes

```bash
# Add route for headysystems.com
wrangler routes add "headysystems.com/*" heady-edge-worker

# Add route for headyconnection.org
wrangler routes add "headyconnection.org/*" heady-edge-worker
```

### 8.4 Set Worker Secrets

```bash
wrangler secret put HEADY_BACKEND_URL
# Enter: https://heady-manager-xxxx-uc.a.run.app

wrangler secret put HEADY_INTERNAL_TOKEN
# Enter: your-internal-token
```

### 8.5 Verify Workers

```bash
# Test edge worker
curl -I https://headysystems.com/health

# Verify brand headers
curl -I https://headysystems.com | grep -E "x-heady-(edge|serve)"
```

---

## 9. Health Verification

### 9.1 Service Health Checks

```bash
# Local
curl http://localhost:8080/health
curl http://localhost:8080/api/v2/health | jq

# Cloud Run
CLOUD_RUN_URL=$(gcloud run services describe heady-manager \
  --region us-central1 --format 'value(status.url)')
curl "${CLOUD_RUN_URL}/health"
```

Expected healthy response:
```json
{
  "status": "healthy",
  "version": "2.0.0",
  "timestamp": "2026-03-06T21:47:00Z",
  "checks": {
    "pipeline": "ok",
    "vectorMemory": "ok",
    "brainApi": "ok",
    "circuitBreaker": "closed",
    "laws": "compliant"
  },
  "healthScore": 95
}
```

### 9.2 Pipeline Smoke Test

```bash
# Run a test pipeline
curl -X POST http://localhost:8080/api/v2/pipeline/run \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer ${TEST_JWT}" \
  -d '{
    "input": "Hello Heady, are you alive?",
    "options": { "smoke_test": true }
  }' | jq
```

### 9.3 Brand Compliance Check

```bash
# Check all production domains
node scripts/deploy.js --health-check --brand-check

# Check specific domain
curl -s -I https://headysystems.com | grep -E "x-heady-"
```

### 9.4 Governance Law Verification

```bash
curl http://localhost:8080/api/v2/governance/laws/status | jq
```

Expected:
```json
{
  "laws": {
    "LAW_001_structural_integrity": "enforced",
    "LAW_002_semantic_coherence": "enforced",
    "LAW_003_mission_alignment": "enforced"
  },
  "lastViolation": null,
  "auditTrailIntact": true
}
```

---

## 10. Troubleshooting

### Container won't start

```bash
# Check logs
docker compose logs heady-core

# Common cause: missing required env var
# Solution: verify .env has all required variables from .env.example

# Check if port is in use
lsof -i :8080
```

### Health check fails with 503

```bash
# Check circuit breaker state
curl http://localhost:8080/api/v2/circuit-breaker/status | jq

# If LLM provider circuit is open, check API key
echo $LLM_API_KEY | head -c 10

# Reset circuit breaker (development only)
curl -X POST http://localhost:8080/internal/circuit-breaker/reset \
  -H "X-Internal-Token: ${INTERNAL_TOKEN}"
```

### Vector memory out of space

```bash
# Check memory pool utilization
curl http://localhost:8082/vectors/pool/hot/stats | jq
curl http://localhost:8082/vectors/pool/cold/stats | jq

# Trigger manual GC
curl -X POST http://localhost:8082/internal/gc \
  -H "X-Internal-Token: ${INTERNAL_TOKEN}"

# Check disk space
df -h /data/vector-shards
```

### Cloud Run deploy fails

```bash
# Check service account permissions
gcloud projects get-iam-policy ${GOOGLE_CLOUD_PROJECT} \
  --flatten="bindings[].members" \
  --filter="bindings.members:serviceAccount:heady-manager@"

# Verify image exists in registry
gcloud artifacts docker images list \
  us-central1-docker.pkg.dev/${GOOGLE_CLOUD_PROJECT}/heady-images

# Check Cloud Build logs
gcloud builds list --limit 5
gcloud builds log BUILD_ID
```

### Brand headers missing in production

```bash
# Check Cloudflare Worker is active
wrangler deployments list

# Check worker routes
wrangler routes list

# Test worker directly
curl -H "X-Heady-Test: true" https://headysystems.com/health \
  | grep x-heady
```

### Governance law violations in logs

```bash
# Check audit log for recent violations
curl http://localhost:8130/audit/events?type=law_violation&limit=10 \
  -H "X-Governance-Token: ${GOVERNANCE_TOKEN}" | jq

# Verify semantic coherence threshold
grep "driftThreshold" configs/pipeline/governance-policies.yaml
```

### Tests failing

```bash
# Run with verbose output
npm test -- --verbose

# Run single test file
npm test -- tests/circuit-breaker.test.js --verbose

# Clear test cache
npm test -- --clearCache

# Check Node version
node --version  # Must be 20.x
```

### Terraform errors

```bash
# Re-initialize if providers changed
terraform init -upgrade

# Import existing GCP resource (if already exists)
terraform import google_cloud_run_service.heady_manager \
  "locations/us-central1/namespaces/${GOOGLE_CLOUD_PROJECT}/services/heady-manager"

# Check Terraform state
terraform show
terraform state list
```

---

*Made with Love by HeadySystems & HeadyConnection Team*  
*For support: eric@headyconnection.org*
