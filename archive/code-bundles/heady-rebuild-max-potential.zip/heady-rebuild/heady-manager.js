/**
 * @fileoverview Heady™ Systems — Root Orchestrator (heady-manager.js)
 * 10-phase bootstrap sequence for the Autonomous Multi-Agent AI OS.
 *
 * Sacred Geometry Architecture:
 *   Each phase feeds its exports into subsequent phases via the opts cascade.
 *   PHI (1.6180339887) governs timing, thresholds, and capacity throughout.
 *
 * Bootstrap Phases:
 *   Phase 1:  config-globals    — Express app, logger, eventBus, remoteConfig, secrets, CF
 *   Phase 2:  middleware-stack  — CORS, helmet, rate limiter, JSON, compression, site renderer
 *   Phase 3:  auth-engine       — JWT, API keys, CF Access, secrets route
 *   Phase 4:  vector-stack      — 384-dim memory, buddy, HCFullPipeline, self-awareness, watchdog
 *   Phase 5:  engine-wiring     — Monte Carlo, pattern, auto-success, scientist QA, self-critique
 *   Phase 6:  pipeline-wiring   — Self-healing wire, PHI-backoff retry
 *   Phase 7:  service-registry  — 40+ services via try/require
 *   Phase 8:  inline-routes     — health, pulse, layer, CSL gate, edge, telemetry, principles
 *   Phase 9:  voice-relay       — WebSocket voice relay, session management
 *   Phase 10: server-boot       — HTTP server, WS upgrade, listen, graceful shutdown
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module heady-manager
 * @version 3.1.0
 */

'use strict';

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI = 1.6180339887;

// ─── Phase Runner ─────────────────────────────────────────────────────────────

/**
 * Execute a named bootstrap phase with error isolation.
 * Phase failures log an error but do not halt subsequent phases.
 *
 * @param {string}   name    - Phase label (e.g. 'Phase 1: config-globals')
 * @param {Function} fn      - Phase factory (may be async)
 * @param {object}   opts    - Accumulated options from prior phases
 * @returns {Promise<object>} Phase result (merged into opts for next phase)
 */
async function runPhase(name, fn, opts = {}) {
  const start = Date.now();
  try {
    const result = await fn(opts) || {};
    const ms     = Date.now() - start;
    const logger = opts.logger || console;
    const logFn  = logger.logSystem || logger.info || console.log;
    logFn.call(logger, `✓ ${name}`, { ms, phi_ratio: (ms / (PHI * 1000)).toFixed(4) });
    return { ...opts, ...result };
  } catch (err) {
    const ms = Date.now() - start;
    // Use whatever logger we have — may not exist yet on Phase 1 failure
    (opts.logger?.error || console.error)(`✗ ${name} FAILED: ${err.message}`, { ms, stack: err.stack });
    // Return opts unchanged so later phases can attempt recovery
    return opts;
  }
}

// ─── Bootstrap Sequence ───────────────────────────────────────────────────────

/**
 * Run all 10 bootstrap phases in sequence and start the server.
 * @returns {Promise<void>}
 */
async function bootstrap() {
  console.log(`\n⬡ Heady™ Systems v3.1.0 — bootstrap initiated  φ=${PHI}\n`);
  const t0 = Date.now();

  // Accumulated opts cascade — each phase receives all prior exports
  let opts = {};

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 1: Config & Globals
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 1: config-globals', async () => {
    const globals = require('./src/bootstrap/config-globals');
    // Attach module-level logger for all subsequent runPhase calls
    return {
      app:           globals.app,
      logger:        globals.logger,
      eventBus:      globals.eventBus,
      remoteConfig:  globals.remoteConfig,
      secretsManager: globals.secretsManager,
      cfManager:     globals.cfManager,
    };
  }, opts);

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 2: Middleware Stack
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 2: middleware-stack', async (o) => {
    const applyMiddleware = require('./src/bootstrap/middleware-stack');
    applyMiddleware(o.app, {
      rateLimitWindowMs: o.remoteConfig?.rateLimitRpm ? 15 * 60 * 1000 : undefined,
      rateLimitMax:      o.remoteConfig?.rateLimitRpm || 100,
    });
    return {}; // Middleware applies in-place; no new exports
  }, opts);

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 3: Auth Engine
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 3: auth-engine', async (o) => {
    const wireAuth = require('./src/bootstrap/auth-engine');
    return wireAuth(o.app, {
      secretsManager: o.secretsManager,
      cfManager:      o.cfManager,
      eventBus:       o.eventBus,
    });
  }, opts);

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 4: Vector Stack
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 4: vector-stack', async (o) => {
    const wireVectors = require('./src/bootstrap/vector-stack');
    return wireVectors(o.app, {
      eventBus: o.eventBus,
    });
  }, opts);

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 5: Engine Wiring
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 5: engine-wiring', async (o) => {
    const { wireEngines } = require('./src/bootstrap/engine-wiring');
    return wireEngines({
      pipeline: o.pipeline,
      eventBus: o.eventBus,
    });
  }, opts);

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 6: Pipeline Wiring
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 6: pipeline-wiring', async (o) => {
    const wirePipeline = require('./src/bootstrap/pipeline-wiring');
    return wirePipeline(o.app, {
      pipeline:      o.pipeline,
      mcScheduler:   o.mcScheduler,
      patternEngine: o.patternEngine,
      eventBus:      o.eventBus,
    });
  }, opts);

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 7: Service Registry
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 7: service-registry', async (o) => {
    const mountRegistry = require('./src/bootstrap/service-registry');
    const registryStats = mountRegistry(o.app, {
      stubMissing:    true,
      authEngine:     o.authEngine,
      vectorMemory:   o.vectorMemory,
      pipeline:       o.pipeline,
      eventBus:       o.eventBus,
    });
    return { registryStats };
  }, opts);

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 8: Inline Routes
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 8: inline-routes', async (o) => {
    const mountInlineRoutes = require('./src/bootstrap/inline-routes');
    mountInlineRoutes(o.app, {
      selfAwareness: o.selfAwareness,
      vectorMemory:  o.vectorMemory,
      pipeline:      o.pipeline,
      selfHeal:      o.selfHeal,
      mcScheduler:   o.mcScheduler,
    });
    return {};
  }, opts);

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 9: Voice Relay
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 9: voice-relay', async (o) => {
    const wireVoiceRelay = require('./src/bootstrap/voice-relay');
    const { voiceSessions, attach } = wireVoiceRelay(o.app, {
      eventBus:   o.eventBus,
      authEngine: o.authEngine,
    });
    return { voiceSessions, voiceRelayAttach: attach };
  }, opts);

  // ──────────────────────────────────────────────────────────────────────────
  // PHASE 10: Server Boot
  // ──────────────────────────────────────────────────────────────────────────
  opts = await runPhase('Phase 10: server-boot', async (o) => {
    const bootServer = require('./src/bootstrap/server-boot');
    const { server, port } = await bootServer(o.app, {
      eventBus:          o.eventBus,
      selfAwareness:     o.selfAwareness,
      voiceRelayAttach:  o.voiceRelayAttach,
      remoteConfig:      o.remoteConfig,
    });
    return { server, port };
  }, opts);

  // ─── Bootstrap Complete ─────────────────────────────────────────────────────
  const totalMs  = Date.now() - t0;
  const phi_boot = (totalMs / (PHI * 1000)).toFixed(4);

  (opts.logger || console).logSystem?.('Bootstrap complete', {
    phases:    10,
    totalMs,
    phi_boot,
    port:      opts.port,
    services:  opts.registryStats,
    phi:       PHI,
  }) || console.log(`⬡ Bootstrap complete in ${totalMs}ms  φ_boot=${phi_boot}`);

  if (opts.eventBus) {
    opts.eventBus.emit('system:ready', {
      totalMs,
      phi_boot,
      port: opts.port,
      phi:  PHI,
    });
  }
}

// ─── Entry Point ──────────────────────────────────────────────────────────────

// Run bootstrap when executed directly
if (require.main === module) {
  bootstrap().catch((err) => {
    console.error('Fatal bootstrap error:', err);
    process.exit(1);
  });
}

module.exports = bootstrap;
module.exports.runPhase = runPhase;
