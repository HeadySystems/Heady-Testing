/**
 * Heady™ Systems — HC Full Pipeline Tests
 * Tests the 12-stage pipeline orchestration, stage ordering,
 * checkpoint protocol, stop rule evaluation, and law enforcement.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

// ---------------------------------------------------------------------------
// Test doubles / mocks
// ---------------------------------------------------------------------------

/** Minimal pipeline runner mock */
function createMockPipelineRunner(overrides = {}) {
  return {
    stages: [],
    checkpoints: [],
    telemetryEvents: [],
    aborted: false,

    async run(input, options = {}) {
      if (this.aborted) throw new Error('Pipeline aborted');
      return { runId: `run_test_${Date.now()}`, status: 'complete', output: input, ...overrides.runResult };
    },

    async saveCheckpoint(stageId, state) {
      this.checkpoints.push({ stageId, state, timestamp: Date.now() });
    },

    async restoreCheckpoint(runId) {
      return this.checkpoints[this.checkpoints.length - 1] || null;
    },

    emitTelemetry(event) {
      this.telemetryEvents.push(event);
    },

    abort(reason) {
      this.aborted = true;
      this.telemetryEvents.push({ type: 'pipeline_halt', reason });
    },

    ...overrides,
  };
}

/** Minimal stage mock factory */
function createMockStage(id, options = {}) {
  return {
    id,
    name: options.name || `Stage ${id}`,
    parallel: options.parallel || false,
    dependsOn: options.dependsOn || [],
    checkpoint: options.checkpoint || false,
    executed: false,
    executionOrder: null,

    async execute(context) {
      this.executed = true;
      this.executionOrder = Date.now();
      if (options.shouldFail) throw new Error(options.failMessage || `Stage ${id} failed`);
      return { stageId: id, output: options.output || {}, ...context };
    },
  };
}

// ---------------------------------------------------------------------------
// Stage ordering tests
// ---------------------------------------------------------------------------

describe('HC Full Pipeline — Stage Ordering', () => {
  const STAGE_ORDER = [
    'context_assembly',
    'intent_classification',
    'resource_planning',
    'node_selection',
    'execution',
    'quality_gate',
    'assurance_gate',
    'pattern_capture',
    'story_update',
    'feedback_loop',
    'optimization',
    'finalization',
  ];

  it('defines exactly 12 pipeline stages', () => {
    expect(STAGE_ORDER).toHaveLength(12);
  });

  it('has correct stage order by index', () => {
    expect(STAGE_ORDER[0]).toBe('context_assembly');
    expect(STAGE_ORDER[1]).toBe('intent_classification');
    expect(STAGE_ORDER[4]).toBe('execution');
    expect(STAGE_ORDER[5]).toBe('quality_gate');
    expect(STAGE_ORDER[6]).toBe('assurance_gate');
    expect(STAGE_ORDER[11]).toBe('finalization');
  });

  it('execution comes after node_selection', () => {
    const executionIdx = STAGE_ORDER.indexOf('execution');
    const nodeSelectionIdx = STAGE_ORDER.indexOf('node_selection');
    expect(executionIdx).toBeGreaterThan(nodeSelectionIdx);
  });

  it('quality_gate comes immediately after execution', () => {
    const executionIdx = STAGE_ORDER.indexOf('execution');
    const qualityIdx = STAGE_ORDER.indexOf('quality_gate');
    expect(qualityIdx).toBe(executionIdx + 1);
  });

  it('assurance_gate comes immediately after quality_gate', () => {
    const qualityIdx = STAGE_ORDER.indexOf('quality_gate');
    const assuranceIdx = STAGE_ORDER.indexOf('assurance_gate');
    expect(assuranceIdx).toBe(qualityIdx + 1);
  });

  it('finalization is the last stage', () => {
    expect(STAGE_ORDER[STAGE_ORDER.length - 1]).toBe('finalization');
  });

  it('pattern_capture comes after assurance_gate', () => {
    const assuranceIdx = STAGE_ORDER.indexOf('assurance_gate');
    const patternIdx = STAGE_ORDER.indexOf('pattern_capture');
    expect(patternIdx).toBeGreaterThan(assuranceIdx);
  });

  it('optimization comes after feedback_loop', () => {
    const feedbackIdx = STAGE_ORDER.indexOf('feedback_loop');
    const optimizationIdx = STAGE_ORDER.indexOf('optimization');
    expect(optimizationIdx).toBeGreaterThan(feedbackIdx);
  });
});

// ---------------------------------------------------------------------------
// Parallel stage tests
// ---------------------------------------------------------------------------

describe('HC Full Pipeline — Parallel Stages', () => {
  const PARALLEL_STAGES = new Set(['context_assembly', 'execution', 'feedback_loop']);

  it('context_assembly is parallel', () => {
    expect(PARALLEL_STAGES.has('context_assembly')).toBe(true);
  });

  it('execution is parallel', () => {
    expect(PARALLEL_STAGES.has('execution')).toBe(true);
  });

  it('feedback_loop is parallel', () => {
    expect(PARALLEL_STAGES.has('feedback_loop')).toBe(true);
  });

  it('quality_gate is NOT parallel (sequential)', () => {
    expect(PARALLEL_STAGES.has('quality_gate')).toBe(false);
  });

  it('assurance_gate is NOT parallel (sequential)', () => {
    expect(PARALLEL_STAGES.has('assurance_gate')).toBe(false);
  });

  it('exactly 3 stages are parallel', () => {
    expect(PARALLEL_STAGES.size).toBe(3);
  });
});

// ---------------------------------------------------------------------------
// Checkpoint protocol tests
// ---------------------------------------------------------------------------

describe('HC Full Pipeline — Checkpoint Protocol', () => {
  const CHECKPOINT_STAGES = new Set(['execution', 'quality_gate', 'optimization']);

  let runner;

  beforeEach(() => {
    runner = createMockPipelineRunner();
  });

  it('execution stage requires checkpoint', () => {
    expect(CHECKPOINT_STAGES.has('execution')).toBe(true);
  });

  it('quality_gate stage requires checkpoint', () => {
    expect(CHECKPOINT_STAGES.has('quality_gate')).toBe(true);
  });

  it('optimization stage requires checkpoint', () => {
    expect(CHECKPOINT_STAGES.has('optimization')).toBe(true);
  });

  it('exactly 3 stages have checkpoints', () => {
    expect(CHECKPOINT_STAGES.size).toBe(3);
  });

  it('saves checkpoint with stageId and state', async () => {
    const stageId = 'execution';
    const state = { runId: 'run_abc', tasks: ['task1', 'task2'] };
    
    await runner.saveCheckpoint(stageId, state);

    expect(runner.checkpoints).toHaveLength(1);
    expect(runner.checkpoints[0].stageId).toBe(stageId);
    expect(runner.checkpoints[0].state).toEqual(state);
  });

  it('restores most recent checkpoint', async () => {
    await runner.saveCheckpoint('execution', { iteration: 1 });
    await runner.saveCheckpoint('quality_gate', { iteration: 2 });

    const restored = await runner.restoreCheckpoint('run_abc');
    expect(restored.state.iteration).toBe(2);
    expect(restored.stageId).toBe('quality_gate');
  });

  it('returns null when no checkpoints exist', async () => {
    const restored = await runner.restoreCheckpoint('run_abc');
    expect(restored).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// Stop rule tests
// ---------------------------------------------------------------------------

describe('HC Full Pipeline — Stop Rule', () => {
  const STOP_RULE = {
    conditions: [
      { metric: 'error_rate', threshold: 0.3, operator: 'gte' },
      { metric: 'readiness_score', threshold: 40, operator: 'lte' },
    ],
    action: 'halt_immediately',
  };

  function evaluateStopRule(metrics) {
    for (const condition of STOP_RULE.conditions) {
      const value = metrics[condition.metric];
      if (condition.operator === 'gte' && value >= condition.threshold) return true;
      if (condition.operator === 'lte' && value <= condition.threshold) return true;
    }
    return false;
  }

  it('does not halt when error_rate is below threshold', () => {
    expect(evaluateStopRule({ error_rate: 0.1, readiness_score: 80 })).toBe(false);
  });

  it('halts when error_rate reaches 0.3', () => {
    expect(evaluateStopRule({ error_rate: 0.3, readiness_score: 80 })).toBe(true);
  });

  it('halts when error_rate exceeds 0.3', () => {
    expect(evaluateStopRule({ error_rate: 0.5, readiness_score: 80 })).toBe(true);
  });

  it('halts when readiness_score is exactly 40', () => {
    expect(evaluateStopRule({ error_rate: 0.1, readiness_score: 40 })).toBe(true);
  });

  it('halts when readiness_score drops below 40', () => {
    expect(evaluateStopRule({ error_rate: 0.1, readiness_score: 30 })).toBe(true);
  });

  it('halts when both conditions are violated', () => {
    expect(evaluateStopRule({ error_rate: 0.5, readiness_score: 20 })).toBe(true);
  });

  it('does not halt at readiness_score of 41', () => {
    expect(evaluateStopRule({ error_rate: 0.1, readiness_score: 41 })).toBe(false);
  });

  it('abort sets aborted flag on runner', () => {
    const runner = createMockPipelineRunner();
    runner.abort('stop_rule_triggered');
    expect(runner.aborted).toBe(true);
  });

  it('aborted runner rejects new runs', async () => {
    const runner = createMockPipelineRunner();
    runner.abort('stop_rule_triggered');
    await expect(runner.run('test input')).rejects.toThrow('Pipeline aborted');
  });

  it('stop rule action is halt_immediately', () => {
    expect(STOP_RULE.action).toBe('halt_immediately');
  });
});

// ---------------------------------------------------------------------------
// Global config tests
// ---------------------------------------------------------------------------

describe('HC Full Pipeline — Global Config', () => {
  const GLOBAL_CONFIG = {
    maxConcurrentTasks: 8,
    defaultTimeoutMs: 30000,
  };

  it('maxConcurrentTasks is 8', () => {
    expect(GLOBAL_CONFIG.maxConcurrentTasks).toBe(8);
  });

  it('defaultTimeoutMs is 30000 (30s)', () => {
    expect(GLOBAL_CONFIG.defaultTimeoutMs).toBe(30000);
  });
});

// ---------------------------------------------------------------------------
// Dependency graph tests
// ---------------------------------------------------------------------------

describe('HC Full Pipeline — Dependency Graph', () => {
  const DEPENDENCIES = {
    context_assembly: [],
    intent_classification: ['context_assembly'],
    resource_planning: ['intent_classification'],
    node_selection: ['resource_planning'],
    execution: ['node_selection'],
    quality_gate: ['execution'],
    assurance_gate: ['quality_gate'],
    pattern_capture: ['assurance_gate'],
    story_update: ['pattern_capture'],
    feedback_loop: ['story_update'],
    optimization: ['feedback_loop'],
    finalization: ['optimization'],
  };

  it('context_assembly has no dependencies', () => {
    expect(DEPENDENCIES.context_assembly).toHaveLength(0);
  });

  it('each non-root stage has at least one dependency', () => {
    const stages = Object.keys(DEPENDENCIES);
    stages.filter((s) => s !== 'context_assembly').forEach((stage) => {
      expect(DEPENDENCIES[stage].length).toBeGreaterThan(0);
    });
  });

  it('execution depends on node_selection', () => {
    expect(DEPENDENCIES.execution).toContain('node_selection');
  });

  it('quality_gate depends on execution', () => {
    expect(DEPENDENCIES.quality_gate).toContain('execution');
  });

  it('assurance_gate depends on quality_gate', () => {
    expect(DEPENDENCIES.assurance_gate).toContain('quality_gate');
  });

  it('there are no circular dependencies', () => {
    // Simple cycle detection: DFS with visited tracking
    function hasCycle(graph) {
      const visited = new Set();
      const recursionStack = new Set();

      function dfs(node) {
        visited.add(node);
        recursionStack.add(node);
        for (const dep of (graph[node] || [])) {
          if (!visited.has(dep)) {
            if (dfs(dep)) return true;
          } else if (recursionStack.has(dep)) {
            return true;
          }
        }
        recursionStack.delete(node);
        return false;
      }

      for (const node of Object.keys(graph)) {
        if (!visited.has(node) && dfs(node)) return true;
      }
      return false;
    }

    expect(hasCycle(DEPENDENCIES)).toBe(false);
  });
});
