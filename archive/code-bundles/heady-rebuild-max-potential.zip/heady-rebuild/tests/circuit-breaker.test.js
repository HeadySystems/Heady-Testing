/**
 * Heady™ Systems — Circuit Breaker Tests
 * Tests open/half-open/closed state transitions, failure threshold,
 * reset timeout, half-open probe logic, and fallback execution.
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';

// ---------------------------------------------------------------------------
// Circuit Breaker Implementation (test-local)
// ---------------------------------------------------------------------------

const CB_STATES = Object.freeze({
  CLOSED: 'closed',
  OPEN: 'open',
  HALF_OPEN: 'half_open',
});

class CircuitBreaker {
  constructor(options = {}) {
    this.failureThreshold = options.failureThreshold ?? 5;
    this.resetTimeoutMs = options.resetTimeoutMs ?? 30000;
    this.halfOpenMaxRequests = options.halfOpenMaxRequests ?? 2;
    this.successThresholdToClose = options.successThresholdToClose ?? 2;

    this.state = CB_STATES.CLOSED;
    this.failureCount = 0;
    this.successCount = 0;
    this.halfOpenRequestCount = 0;
    this.lastFailureTime = null;
    this.openedAt = null;

    this.onStateChange = options.onStateChange || null;
    this._calls = { total: 0, succeeded: 0, failed: 0, rejected: 0 };
  }

  get isOpen() { return this.state === CB_STATES.OPEN; }
  get isClosed() { return this.state === CB_STATES.CLOSED; }
  get isHalfOpen() { return this.state === CB_STATES.HALF_OPEN; }

  async execute(fn, fallback = null) {
    this._checkResetTimeout();

    this._calls.total++;

    if (this.state === CB_STATES.OPEN) {
      this._calls.rejected++;
      if (fallback) return fallback();
      throw new Error('Circuit breaker is OPEN — request rejected');
    }

    if (this.state === CB_STATES.HALF_OPEN) {
      if (this.halfOpenRequestCount >= this.halfOpenMaxRequests) {
        this._calls.rejected++;
        if (fallback) return fallback();
        throw new Error('Circuit breaker HALF_OPEN — max probe requests reached');
      }
      this.halfOpenRequestCount++;
    }

    try {
      const result = await fn();
      this._onSuccess();
      return result;
    } catch (err) {
      this._onFailure();
      throw err;
    }
  }

  _onSuccess() {
    this._calls.succeeded++;
    if (this.state === CB_STATES.HALF_OPEN) {
      this.successCount++;
      if (this.successCount >= this.successThresholdToClose) {
        this._transition(CB_STATES.CLOSED);
      }
    } else {
      // Reset failure count on success in closed state
      this.failureCount = 0;
    }
  }

  _onFailure() {
    this._calls.failed++;
    this.failureCount++;
    this.lastFailureTime = Date.now();

    if (this.state === CB_STATES.HALF_OPEN) {
      // Any failure in half-open sends us back to open
      this._transition(CB_STATES.OPEN);
      return;
    }

    if (this.failureCount >= this.failureThreshold) {
      this._transition(CB_STATES.OPEN);
    }
  }

  _checkResetTimeout() {
    if (this.state === CB_STATES.OPEN && this.openedAt !== null) {
      const elapsed = Date.now() - this.openedAt;
      if (elapsed >= this.resetTimeoutMs) {
        this._transition(CB_STATES.HALF_OPEN);
      }
    }
  }

  _transition(newState) {
    const prevState = this.state;
    this.state = newState;

    if (newState === CB_STATES.OPEN) {
      this.openedAt = Date.now();
      this.halfOpenRequestCount = 0;
      this.successCount = 0;
    } else if (newState === CB_STATES.HALF_OPEN) {
      this.halfOpenRequestCount = 0;
      this.successCount = 0;
    } else if (newState === CB_STATES.CLOSED) {
      this.failureCount = 0;
      this.successCount = 0;
      this.halfOpenRequestCount = 0;
      this.openedAt = null;
    }

    if (this.onStateChange) {
      this.onStateChange({ from: prevState, to: newState, timestamp: Date.now() });
    }
  }

  forceOpen() { this._transition(CB_STATES.OPEN); }
  forceHalfOpen() { this._transition(CB_STATES.HALF_OPEN); }
  forceClosed() { this._transition(CB_STATES.CLOSED); }
  reset() { this._transition(CB_STATES.CLOSED); this.failureCount = 0; }
  getStats() { return { ...this._calls, state: this.state }; }
}

// Test helpers
const success = () => Promise.resolve('ok');
const fail = () => Promise.reject(new Error('upstream error'));
const fallback = () => 'fallback_response';

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('Circuit Breaker — Initial State', () => {
  let cb;

  beforeEach(() => {
    cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMaxRequests: 2 });
  });

  it('initializes in CLOSED state', () => {
    expect(cb.state).toBe(CB_STATES.CLOSED);
    expect(cb.isClosed).toBe(true);
  });

  it('starts with 0 failure count', () => {
    expect(cb.failureCount).toBe(0);
  });

  it('has correct configuration', () => {
    expect(cb.failureThreshold).toBe(5);
    expect(cb.resetTimeoutMs).toBe(30000);
    expect(cb.halfOpenMaxRequests).toBe(2);
  });
});

describe('Circuit Breaker — Closed → Open Transition', () => {
  let cb;

  beforeEach(() => {
    cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 30000 });
  });

  it('executes successfully in closed state', async () => {
    const result = await cb.execute(success);
    expect(result).toBe('ok');
    expect(cb.isClosed).toBe(true);
  });

  it('increments failure count on error', async () => {
    await cb.execute(fail).catch(() => {});
    expect(cb.failureCount).toBe(1);
    expect(cb.isClosed).toBe(true);
  });

  it('opens after exactly 5 failures', async () => {
    for (let i = 0; i < 5; i++) {
      await cb.execute(fail).catch(() => {});
    }
    expect(cb.isOpen).toBe(true);
    expect(cb.failureCount).toBe(5);
  });

  it('remains closed after 4 failures', async () => {
    for (let i = 0; i < 4; i++) {
      await cb.execute(fail).catch(() => {});
    }
    expect(cb.isClosed).toBe(true);
  });

  it('resets failure count on success', async () => {
    await cb.execute(fail).catch(() => {});
    await cb.execute(fail).catch(() => {});
    await cb.execute(success);
    expect(cb.failureCount).toBe(0);
    expect(cb.isClosed).toBe(true);
  });

  it('fires onStateChange when opening', async () => {
    const listener = vi.fn();
    cb.onStateChange = listener;

    for (let i = 0; i < 5; i++) {
      await cb.execute(fail).catch(() => {});
    }

    expect(listener).toHaveBeenCalledWith(expect.objectContaining({
      from: CB_STATES.CLOSED,
      to: CB_STATES.OPEN,
    }));
  });
});

describe('Circuit Breaker — Open State', () => {
  let cb;

  beforeEach(async () => {
    cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 30000, halfOpenMaxRequests: 2 });
    cb.forceOpen();
  });

  it('rejects requests when open', async () => {
    await expect(cb.execute(success)).rejects.toThrow('OPEN');
  });

  it('executes fallback when open and fallback provided', async () => {
    const result = await cb.execute(success, fallback);
    expect(result).toBe('fallback_response');
  });

  it('does not execute the primary function when open', async () => {
    const fn = vi.fn().mockResolvedValue('primary');
    await cb.execute(fn, fallback).catch(() => {});
    expect(fn).not.toHaveBeenCalled();
  });

  it('increments rejected count for open-state requests', async () => {
    await cb.execute(success).catch(() => {});
    await cb.execute(success).catch(() => {});
    expect(cb.getStats().rejected).toBe(2);
  });
});

describe('Circuit Breaker — Reset Timeout (Open → Half-Open)', () => {
  it('transitions to HALF_OPEN after resetTimeout', async () => {
    const cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 50 });
    cb.forceOpen();
    
    // Wait for reset timeout
    await new Promise((r) => setTimeout(r, 60));
    
    // Execute something to trigger state check
    await cb.execute(success).catch(() => {});
    
    // Should have transitioned to HALF_OPEN and then CLOSED (after 1 success, but
    // successThresholdToClose=2 by default, so HALF_OPEN after success)
    expect([CB_STATES.HALF_OPEN, CB_STATES.CLOSED]).toContain(cb.state);
  });

  it('remains OPEN before resetTimeout', async () => {
    const cb = new CircuitBreaker({ failureThreshold: 5, resetTimeoutMs: 60000 });
    cb.forceOpen();
    
    // Check immediately — should still be open
    cb._checkResetTimeout();
    expect(cb.isOpen).toBe(true);
  });
});

describe('Circuit Breaker — Half-Open State', () => {
  let cb;

  beforeEach(() => {
    cb = new CircuitBreaker({
      failureThreshold: 5,
      resetTimeoutMs: 30000,
      halfOpenMaxRequests: 2,
      successThresholdToClose: 2,
    });
    cb.forceHalfOpen();
  });

  it('allows up to halfOpenMaxRequests probe requests', async () => {
    await cb.execute(success); // probe 1
    expect(cb.isHalfOpen).toBe(true);

    await cb.execute(success); // probe 2 → closes (2 successes)
    expect(cb.isClosed).toBe(true);
  });

  it('rejects when halfOpenMaxRequests exceeded without close', async () => {
    cb.successThresholdToClose = 99; // Prevent close
    await cb.execute(success); // probe 1
    await cb.execute(success); // probe 2 (max)

    await expect(cb.execute(success)).rejects.toThrow('max probe requests');
  });

  it('returns to OPEN on failure in half-open state', async () => {
    await cb.execute(fail).catch(() => {});
    expect(cb.isOpen).toBe(true);
  });

  it('closes after successThresholdToClose consecutive successes', async () => {
    const listener = vi.fn();
    cb.onStateChange = listener;

    await cb.execute(success);
    await cb.execute(success); // 2nd success → close

    expect(cb.isClosed).toBe(true);
    expect(listener).toHaveBeenCalledWith(expect.objectContaining({
      from: CB_STATES.HALF_OPEN,
      to: CB_STATES.CLOSED,
    }));
  });
});

describe('Circuit Breaker — Configuration', () => {
  it('uses failureThreshold of 5', () => {
    const cb = new CircuitBreaker({ failureThreshold: 5 });
    expect(cb.failureThreshold).toBe(5);
  });

  it('uses resetTimeoutMs of 30000', () => {
    const cb = new CircuitBreaker({ resetTimeoutMs: 30000 });
    expect(cb.resetTimeoutMs).toBe(30000);
  });

  it('uses halfOpenMaxRequests of 2', () => {
    const cb = new CircuitBreaker({ halfOpenMaxRequests: 2 });
    expect(cb.halfOpenMaxRequests).toBe(2);
  });
});

describe('Circuit Breaker — Stats', () => {
  let cb;

  beforeEach(() => {
    cb = new CircuitBreaker({ failureThreshold: 5 });
  });

  it('tracks total call count', async () => {
    await cb.execute(success);
    await cb.execute(success);
    expect(cb.getStats().total).toBe(2);
  });

  it('tracks succeeded call count', async () => {
    await cb.execute(success);
    await cb.execute(fail).catch(() => {});
    expect(cb.getStats().succeeded).toBe(1);
  });

  it('tracks failed call count', async () => {
    await cb.execute(fail).catch(() => {});
    await cb.execute(fail).catch(() => {});
    expect(cb.getStats().failed).toBe(2);
  });

  it('includes current state in stats', () => {
    expect(cb.getStats().state).toBe(CB_STATES.CLOSED);
    cb.forceOpen();
    expect(cb.getStats().state).toBe(CB_STATES.OPEN);
  });

  it('reset restores closed state and clears failure count', () => {
    cb.forceOpen();
    cb.reset();
    expect(cb.isClosed).toBe(true);
    expect(cb.failureCount).toBe(0);
  });
});

describe('Circuit Breaker — Monitored Endpoints', () => {
  const MONITORED = ['llm-provider', 'external-news-api', 'embedding-service', 'cloud-deploy'];

  it('has exactly 4 monitored endpoints', () => {
    expect(MONITORED).toHaveLength(4);
  });

  it('llm-provider is monitored', () => {
    expect(MONITORED).toContain('llm-provider');
  });

  it('embedding-service is monitored', () => {
    expect(MONITORED).toContain('embedding-service');
  });

  it('cloud-deploy is monitored', () => {
    expect(MONITORED).toContain('cloud-deploy');
  });

  it('each endpoint can have its own circuit breaker', () => {
    const breakers = {};
    for (const endpoint of MONITORED) {
      breakers[endpoint] = new CircuitBreaker({ failureThreshold: 5 });
    }
    expect(Object.keys(breakers)).toHaveLength(4);
    expect(breakers['llm-provider'].isClosed).toBe(true);
  });
});
