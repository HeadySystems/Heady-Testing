/**
 * Heady™ Systems — Vector Memory Tests
 * Tests HNSW indexing, pool management, similarity search,
 * drift detection, and episodic memory operations.
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

// ---------------------------------------------------------------------------
// Test utilities
// ---------------------------------------------------------------------------

/** Generate a random unit vector of given dimension */
function randomUnitVector(dim) {
  const v = Array.from({ length: dim }, () => Math.random() * 2 - 1);
  const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
  return v.map((x) => x / norm);
}

/** Cosine similarity between two vectors */
function cosineSimilarity(a, b) {
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

/** In-memory vector store (mock HNSW for tests) */
function createMockVectorStore(dim = 1536) {
  const store = new Map();
  let idCounter = 0;

  return {
    dimension: dim,
    size: () => store.size,

    upsert(id, vector, metadata = {}) {
      if (vector.length !== dim) throw new Error(`Vector must have ${dim} dimensions, got ${vector.length}`);
      const recordId = id ?? `vec_${++idCounter}`;
      store.set(recordId, { id: recordId, vector, metadata, timestamp: Date.now() });
      return recordId;
    },

    query(queryVector, topK = 10) {
      if (queryVector.length !== dim) throw new Error(`Query vector must have ${dim} dimensions`);
      const results = [];
      for (const [id, record] of store) {
        const similarity = cosineSimilarity(queryVector, record.vector);
        results.push({ id, similarity, metadata: record.metadata });
      }
      return results
        .sort((a, b) => b.similarity - a.similarity)
        .slice(0, topK);
    },

    delete(id) {
      return store.delete(id);
    },

    get(id) {
      return store.get(id) || null;
    },

    clear() {
      store.clear();
      idCounter = 0;
    },
  };
}

/** Memory pool manager mock */
function createMockPoolManager() {
  const POOLS = {
    hot:        { allocationPercent: 34, items: new Map() },
    warm:       { allocationPercent: 21, items: new Map() },
    cold:       { allocationPercent: 13, items: new Map() },
    reserve:    { allocationPercent:  8, items: new Map() },
    governance: { allocationPercent:  5, items: new Map() },
  };

  return {
    pools: POOLS,

    assign(id, pool, data) {
      if (!POOLS[pool]) throw new Error(`Unknown pool: ${pool}`);
      POOLS[pool].items.set(id, { id, data, assignedAt: Date.now() });
    },

    get(id, pool) {
      if (!POOLS[pool]) return null;
      return POOLS[pool].items.get(id) || null;
    },

    getUtilization(pool) {
      if (!POOLS[pool]) throw new Error(`Unknown pool: ${pool}`);
      return {
        pool,
        itemCount: POOLS[pool].items.size,
        allocationPercent: POOLS[pool].allocationPercent,
      };
    },

    totalAllocationPercent() {
      return Object.values(POOLS).reduce((sum, p) => sum + p.allocationPercent, 0);
    },

    evictLRU(pool, count = 1) {
      const items = Array.from(POOLS[pool].items.values())
        .sort((a, b) => a.assignedAt - b.assignedAt)
        .slice(0, count);
      for (const item of items) POOLS[pool].items.delete(item.id);
      return items.length;
    },
  };
}

// ---------------------------------------------------------------------------
// Vector store tests
// ---------------------------------------------------------------------------

describe('Vector Memory — Vector Store', () => {
  let store;

  beforeEach(() => {
    store = createMockVectorStore(16); // Use 16d for speed in tests
  });

  it('initializes with dimension 16', () => {
    expect(store.dimension).toBe(16);
    expect(store.size()).toBe(0);
  });

  it('upserts a vector and returns an id', () => {
    const v = randomUnitVector(16);
    const id = store.upsert(null, v);
    expect(id).toBeTruthy();
    expect(store.size()).toBe(1);
  });

  it('upserts with explicit id', () => {
    const v = randomUnitVector(16);
    const id = store.upsert('my-vec-001', v);
    expect(id).toBe('my-vec-001');
    expect(store.get('my-vec-001')).toBeTruthy();
  });

  it('throws when vector dimension is wrong', () => {
    expect(() => store.upsert(null, randomUnitVector(8))).toThrow('16 dimensions');
  });

  it('queries return topK results sorted by similarity descending', () => {
    const query = randomUnitVector(16);
    for (let i = 0; i < 20; i++) {
      store.upsert(null, randomUnitVector(16));
    }
    
    const results = store.query(query, 5);
    expect(results).toHaveLength(5);
    
    // Verify descending similarity order
    for (let i = 1; i < results.length; i++) {
      expect(results[i].similarity).toBeLessThanOrEqual(results[i - 1].similarity);
    }
  });

  it('returns fewer results than topK when store has fewer items', () => {
    store.upsert(null, randomUnitVector(16));
    store.upsert(null, randomUnitVector(16));
    
    const results = store.query(randomUnitVector(16), 10);
    expect(results).toHaveLength(2);
  });

  it('returns self as most similar on exact match', () => {
    const v = randomUnitVector(16);
    const id = store.upsert('self-test', v);
    
    const results = store.query(v, 5);
    expect(results[0].id).toBe(id);
    expect(results[0].similarity).toBeCloseTo(1.0, 5);
  });

  it('deletes a vector by id', () => {
    const id = store.upsert(null, randomUnitVector(16));
    expect(store.size()).toBe(1);
    
    store.delete(id);
    expect(store.size()).toBe(0);
    expect(store.get(id)).toBeNull();
  });

  it('stores and retrieves metadata', () => {
    const meta = { userId: 'user_abc', sessionId: 'sess_xyz', pool: 'hot' };
    const id = store.upsert('meta-test', randomUnitVector(16), meta);
    
    const record = store.get(id);
    expect(record.metadata).toEqual(meta);
  });
});

// ---------------------------------------------------------------------------
// Pool management tests
// ---------------------------------------------------------------------------

describe('Vector Memory — Pool Management', () => {
  let poolManager;

  beforeEach(() => {
    poolManager = createMockPoolManager();
  });

  it('defines 5 memory pools', () => {
    expect(Object.keys(poolManager.pools)).toHaveLength(5);
  });

  it('pool allocation percentages sum to correct total', () => {
    // hot(34) + warm(21) + cold(13) + reserve(8) + governance(5) = 81%
    // (remaining 19% is OS/overhead)
    expect(poolManager.totalAllocationPercent()).toBe(81);
  });

  it('hot pool has 34% allocation', () => {
    expect(poolManager.pools.hot.allocationPercent).toBe(34);
  });

  it('warm pool has 21% allocation', () => {
    expect(poolManager.pools.warm.allocationPercent).toBe(21);
  });

  it('cold pool has 13% allocation', () => {
    expect(poolManager.pools.cold.allocationPercent).toBe(13);
  });

  it('reserve pool has 8% allocation', () => {
    expect(poolManager.pools.reserve.allocationPercent).toBe(8);
  });

  it('governance pool has 5% allocation', () => {
    expect(poolManager.pools.governance.allocationPercent).toBe(5);
  });

  it('assigns item to hot pool', () => {
    poolManager.assign('item-1', 'hot', { embedding: [0.1, 0.2] });
    expect(poolManager.get('item-1', 'hot')).toBeTruthy();
  });

  it('throws on unknown pool assignment', () => {
    expect(() => poolManager.assign('x', 'nonexistent', {})).toThrow('Unknown pool');
  });

  it('returns null for item in wrong pool', () => {
    poolManager.assign('item-1', 'hot', {});
    expect(poolManager.get('item-1', 'warm')).toBeNull();
  });

  it('reports pool utilization', () => {
    poolManager.assign('a', 'hot', {});
    poolManager.assign('b', 'hot', {});
    const util = poolManager.getUtilization('hot');
    expect(util.itemCount).toBe(2);
    expect(util.allocationPercent).toBe(34);
  });

  it('LRU eviction removes oldest items', async () => {
    poolManager.assign('old', 'cold', {});
    await new Promise((r) => setTimeout(r, 10));
    poolManager.assign('new', 'cold', {});

    const evicted = poolManager.evictLRU('cold', 1);
    expect(evicted).toBe(1);
    expect(poolManager.get('old', 'cold')).toBeNull();
    expect(poolManager.get('new', 'cold')).toBeTruthy();
  });
});

// ---------------------------------------------------------------------------
// Cosine similarity tests
// ---------------------------------------------------------------------------

describe('Vector Memory — Cosine Similarity', () => {
  it('identical vectors have similarity 1.0', () => {
    const v = randomUnitVector(16);
    expect(cosineSimilarity(v, v)).toBeCloseTo(1.0, 5);
  });

  it('opposite vectors have similarity close to -1.0', () => {
    const v = randomUnitVector(16);
    const neg = v.map((x) => -x);
    expect(cosineSimilarity(v, neg)).toBeCloseTo(-1.0, 5);
  });

  it('orthogonal vectors have similarity close to 0', () => {
    // Construct two orthogonal vectors
    const v1 = new Array(16).fill(0);
    v1[0] = 1;
    const v2 = new Array(16).fill(0);
    v2[1] = 1;
    expect(cosineSimilarity(v1, v2)).toBeCloseTo(0, 5);
  });

  it('similarity is between -1 and 1', () => {
    for (let i = 0; i < 20; i++) {
      const sim = cosineSimilarity(randomUnitVector(16), randomUnitVector(16));
      expect(sim).toBeGreaterThanOrEqual(-1.0 - 1e-10);
      expect(sim).toBeLessThanOrEqual(1.0 + 1e-10);
    }
  });
});

// ---------------------------------------------------------------------------
// Drift detection tests
// ---------------------------------------------------------------------------

describe('Vector Memory — Drift Detection', () => {
  const DRIFT_THRESHOLD = 0.75;

  function computeDriftScore(currentVectors, baselineVectors) {
    // Compute average centroid of each set
    const dim = currentVectors[0].length;

    const centroid = (vectors) => {
      const c = new Array(dim).fill(0);
      for (const v of vectors) for (let i = 0; i < dim; i++) c[i] += v[i];
      return c.map((x) => x / vectors.length);
    };

    const currentCentroid = centroid(currentVectors);
    const baselineCentroid = centroid(baselineVectors);
    
    const similarity = cosineSimilarity(currentCentroid, baselineCentroid);
    return 1 - similarity; // drift = distance from baseline
  }

  it('drift score is near 0 for identical distributions', () => {
    const vectors = Array.from({ length: 10 }, () => randomUnitVector(16));
    const drift = computeDriftScore(vectors, vectors);
    expect(drift).toBeCloseTo(0, 3);
  });

  it('drift score is positive for divergent distributions', () => {
    const baseline = Array.from({ length: 10 }, () => randomUnitVector(16));
    // Create a clearly different distribution by negating all vectors
    const current = baseline.map((v) => v.map((x) => -x));
    const drift = computeDriftScore(current, baseline);
    expect(drift).toBeGreaterThan(0.5);
  });

  it('alert triggers when drift exceeds threshold 0.75', () => {
    const alertFired = vi.fn();
    const drift = 0.80;
    if (drift >= DRIFT_THRESHOLD) alertFired('DRIFT_ALERT');
    expect(alertFired).toHaveBeenCalledWith('DRIFT_ALERT');
  });

  it('no alert when drift is below threshold', () => {
    const alertFired = vi.fn();
    const drift = 0.60;
    if (drift >= DRIFT_THRESHOLD) alertFired('DRIFT_ALERT');
    expect(alertFired).not.toHaveBeenCalled();
  });

  it('drift threshold is 0.75', () => {
    expect(DRIFT_THRESHOLD).toBe(0.75);
  });
});

// ---------------------------------------------------------------------------
// Episodic memory tests
// ---------------------------------------------------------------------------

describe('Vector Memory — Episodic Memory', () => {
  it('stores and retrieves episodic memory record', () => {
    const episodicStore = [];

    function writeEpisode(episode) {
      episodicStore.push({ ...episode, id: `ep_${Date.now()}`, storedAt: Date.now() });
    }

    function readEpisodes(userId, limit = 10) {
      return episodicStore
        .filter((e) => e.userId === userId)
        .slice(-limit);
    }

    writeEpisode({ userId: 'user_abc', sessionId: 'sess_1', summary: 'Discussed RAG patterns', embedding: randomUnitVector(16) });
    writeEpisode({ userId: 'user_abc', sessionId: 'sess_2', summary: 'Explored swarm consensus', embedding: randomUnitVector(16) });
    writeEpisode({ userId: 'user_xyz', sessionId: 'sess_3', summary: 'Another user', embedding: randomUnitVector(16) });

    const episodes = readEpisodes('user_abc');
    expect(episodes).toHaveLength(2);
    expect(episodes.every((e) => e.userId === 'user_abc')).toBe(true);
  });

  it('respects limit parameter', () => {
    const episodicStore = [];
    for (let i = 0; i < 20; i++) {
      episodicStore.push({ userId: 'user_abc', sessionId: `sess_${i}`, storedAt: i });
    }
    const limited = episodicStore.filter((e) => e.userId === 'user_abc').slice(-5);
    expect(limited).toHaveLength(5);
  });
});
