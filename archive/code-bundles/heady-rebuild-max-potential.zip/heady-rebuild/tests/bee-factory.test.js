/**
 * Heady™ Systems — Bee Factory Tests
 * Tests bee agent spawning, capability validation, pool assignment,
 * swarm registration, and lifecycle management.
 */

import { describe, it, expect, beforeEach, vi } from 'vitest';

// ---------------------------------------------------------------------------
// Bee Factory Implementation (test-local)
// ---------------------------------------------------------------------------

const BEE_STATES = Object.freeze({
  SPAWNING: 'spawning',
  ACTIVE: 'active',
  IDLE: 'idle',
  DRAINING: 'draining',
  TERMINATED: 'terminated',
});

const VALID_POOLS = new Set(['hot', 'warm', 'cold', 'reserve', 'governance']);
const VALID_CAPABILITIES = new Set([
  'embed', 'index', 'retrieve', 'compress', 'dedup',
  'llm_inference', 'prompt_engineer', 'stream_output',
  'auth_validate', 'rbac_check', 'anomaly_detect',
  'route_request', 'load_balance', 'service_discover',
  'pattern_extract', 'pattern_match', 'cluster',
  'simulate', 'policy_update', 'risk_estimate',
  'audit_write', 'hash_chain', 'audit_verify',
  'stage_execute', 'checkpoint_write', 'rollback',
  'story_read', 'story_write', 'arc_update',
  'feedback_collect', 'signal_encode', 'sentiment_analyze',
  'generate_docs', 'update_runbook', 'api_doc_publish',
]);

class BeeFactory {
  constructor(registry) {
    this.registry = registry;
    this._spawned = 0;
  }

  validateTemplate(template) {
    const errors = [];
    if (!template.classId) errors.push('classId is required');
    if (!template.name) errors.push('name is required');
    if (!template.swarm) errors.push('swarm is required');
    if (!template.poolAssignment) errors.push('poolAssignment is required');
    if (!VALID_POOLS.has(template.poolAssignment)) {
      errors.push(`Invalid poolAssignment: ${template.poolAssignment}. Must be one of: ${[...VALID_POOLS].join(', ')}`);
    }
    if (!Array.isArray(template.capabilities) || template.capabilities.length === 0) {
      errors.push('capabilities must be a non-empty array');
    }
    return errors;
  }

  spawn(template, count = 1) {
    const errors = this.validateTemplate(template);
    if (errors.length > 0) {
      throw new Error(`Invalid bee template: ${errors.join('; ')}`);
    }

    const bees = [];
    for (let i = 0; i < count; i++) {
      const bee = {
        id: `bee_${template.classId}_${++this._spawned}_${Date.now()}`,
        classId: template.classId,
        name: template.name,
        swarm: template.swarm,
        capabilities: [...template.capabilities],
        poolAssignment: template.poolAssignment,
        maxInstances: template.maxInstances || 10,
        resourceProfile: template.resourceProfile || { memoryMb: 256, cpuWeight: 1 },
        state: BEE_STATES.SPAWNING,
        spawnedAt: Date.now(),
        lastHeartbeat: null,
      };

      // Transition to active
      bee.state = BEE_STATES.ACTIVE;
      bee.lastHeartbeat = Date.now();

      // Register with registry
      this.registry.register(bee);
      bees.push(bee);
    }

    return count === 1 ? bees[0] : bees;
  }

  terminate(beeId, registry) {
    const bee = registry.get(beeId);
    if (!bee) throw new Error(`Bee not found: ${beeId}`);
    bee.state = BEE_STATES.TERMINATED;
    registry.deregister(beeId);
    return bee;
  }
}

class BeeRegistry {
  constructor() {
    this._bees = new Map();
  }

  register(bee) {
    this._bees.set(bee.id, bee);
  }

  deregister(id) {
    return this._bees.delete(id);
  }

  get(id) {
    return this._bees.get(id) || null;
  }

  list(filters = {}) {
    let bees = Array.from(this._bees.values());
    if (filters.swarm) bees = bees.filter((b) => b.swarm === filters.swarm);
    if (filters.pool) bees = bees.filter((b) => b.poolAssignment === filters.pool);
    if (filters.capability) bees = bees.filter((b) => b.capabilities.includes(filters.capability));
    if (filters.state) bees = bees.filter((b) => b.state === filters.state);
    return bees;
  }

  count(filters = {}) {
    return this.list(filters).length;
  }

  clear() {
    this._bees.clear();
  }
}

// Test templates
const TEMPLATES = {
  vectorWeaver: {
    classId: 'VectorWeaverBee',
    name: 'Vector Weaver Bee',
    swarm: 'SWARM_THE_WEAVER',
    capabilities: ['embed', 'index', 'retrieve', 'compress', 'dedup'],
    poolAssignment: 'hot',
    maxInstances: 8,
    resourceProfile: { memoryMb: 512, cpuWeight: 2 },
  },
  latticeCrypto: {
    classId: 'LatticeCryptographyBee',
    name: 'Lattice Cryptography Bee',
    swarm: 'SWARM_THE_SENTINEL',
    capabilities: ['auth_validate', 'rbac_check', 'anomaly_detect'],
    poolAssignment: 'hot',
    maxInstances: 3,
    resourceProfile: { memoryMb: 256, cpuWeight: 3 },
  },
  auditLogger: {
    classId: 'AuditLoggerBee',
    name: 'Audit Logger Bee',
    swarm: 'SWARM_THE_CHRONICLER',
    capabilities: ['audit_write', 'hash_chain', 'audit_verify'],
    poolAssignment: 'governance',
    maxInstances: 3,
    resourceProfile: { memoryMb: 128, cpuWeight: 1 },
  },
  coldPatternBee: {
    classId: 'PatternRecognitionBee',
    name: 'Pattern Recognition Bee',
    swarm: 'SWARM_THE_ARCHITECT',
    capabilities: ['pattern_extract', 'pattern_match', 'cluster'],
    poolAssignment: 'cold',
    maxInstances: 6,
    resourceProfile: { memoryMb: 384, cpuWeight: 2 },
  },
};

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

describe('Bee Factory — Template Validation', () => {
  let factory, registry;

  beforeEach(() => {
    registry = new BeeRegistry();
    factory = new BeeFactory(registry);
  });

  it('validates a correct template with no errors', () => {
    const errors = factory.validateTemplate(TEMPLATES.vectorWeaver);
    expect(errors).toHaveLength(0);
  });

  it('rejects template missing classId', () => {
    const errors = factory.validateTemplate({ ...TEMPLATES.vectorWeaver, classId: undefined });
    expect(errors).toContain('classId is required');
  });

  it('rejects template missing name', () => {
    const errors = factory.validateTemplate({ ...TEMPLATES.vectorWeaver, name: undefined });
    expect(errors).toContain('name is required');
  });

  it('rejects template missing swarm', () => {
    const errors = factory.validateTemplate({ ...TEMPLATES.vectorWeaver, swarm: undefined });
    expect(errors).toContain('swarm is required');
  });

  it('rejects template with invalid poolAssignment', () => {
    const errors = factory.validateTemplate({ ...TEMPLATES.vectorWeaver, poolAssignment: 'superfast' });
    expect(errors.some((e) => e.includes('Invalid poolAssignment'))).toBe(true);
  });

  it('accepts all valid pool assignments', () => {
    for (const pool of VALID_POOLS) {
      const errors = factory.validateTemplate({ ...TEMPLATES.vectorWeaver, poolAssignment: pool });
      expect(errors.filter((e) => e.includes('poolAssignment'))).toHaveLength(0);
    }
  });

  it('rejects template with empty capabilities array', () => {
    const errors = factory.validateTemplate({ ...TEMPLATES.vectorWeaver, capabilities: [] });
    expect(errors.some((e) => e.includes('capabilities'))).toBe(true);
  });

  it('rejects template with non-array capabilities', () => {
    const errors = factory.validateTemplate({ ...TEMPLATES.vectorWeaver, capabilities: 'embed' });
    expect(errors.some((e) => e.includes('capabilities'))).toBe(true);
  });
});

describe('Bee Factory — Spawn', () => {
  let factory, registry;

  beforeEach(() => {
    registry = new BeeRegistry();
    factory = new BeeFactory(registry);
  });

  afterEach(() => {
    registry.clear();
  });

  it('spawns a single bee from template', () => {
    const bee = factory.spawn(TEMPLATES.vectorWeaver);
    expect(bee).toBeTruthy();
    expect(bee.classId).toBe('VectorWeaverBee');
  });

  it('spawned bee has ACTIVE state', () => {
    const bee = factory.spawn(TEMPLATES.vectorWeaver);
    expect(bee.state).toBe(BEE_STATES.ACTIVE);
  });

  it('spawned bee has unique id', () => {
    const bee1 = factory.spawn(TEMPLATES.vectorWeaver);
    const bee2 = factory.spawn(TEMPLATES.vectorWeaver);
    expect(bee1.id).not.toBe(bee2.id);
  });

  it('spawned bee is registered in registry', () => {
    const bee = factory.spawn(TEMPLATES.vectorWeaver);
    expect(registry.get(bee.id)).toBeTruthy();
  });

  it('spawned bee copies capabilities from template', () => {
    const bee = factory.spawn(TEMPLATES.vectorWeaver);
    expect(bee.capabilities).toEqual(TEMPLATES.vectorWeaver.capabilities);
  });

  it('spawned bee has correct pool assignment', () => {
    const bee = factory.spawn(TEMPLATES.auditLogger);
    expect(bee.poolAssignment).toBe('governance');
  });

  it('spawns multiple bees with count parameter', () => {
    const bees = factory.spawn(TEMPLATES.vectorWeaver, 3);
    expect(bees).toHaveLength(3);
    expect(registry.count()).toBe(3);
  });

  it('throws on invalid template', () => {
    expect(() => factory.spawn({ ...TEMPLATES.vectorWeaver, classId: undefined })).toThrow('Invalid bee template');
  });

  it('spawned bee has spawnedAt timestamp', () => {
    const before = Date.now();
    const bee = factory.spawn(TEMPLATES.vectorWeaver);
    const after = Date.now();
    expect(bee.spawnedAt).toBeGreaterThanOrEqual(before);
    expect(bee.spawnedAt).toBeLessThanOrEqual(after);
  });
});

describe('Bee Factory — Pool Assignment', () => {
  let factory, registry;

  beforeEach(() => {
    registry = new BeeRegistry();
    factory = new BeeFactory(registry);
  });

  afterEach(() => {
    registry.clear();
  });

  it('VectorWeaverBee spawns in hot pool', () => {
    const bee = factory.spawn(TEMPLATES.vectorWeaver);
    expect(bee.poolAssignment).toBe('hot');
  });

  it('LatticeCryptographyBee spawns in hot pool', () => {
    const bee = factory.spawn(TEMPLATES.latticeCrypto);
    expect(bee.poolAssignment).toBe('hot');
  });

  it('AuditLoggerBee spawns in governance pool', () => {
    const bee = factory.spawn(TEMPLATES.auditLogger);
    expect(bee.poolAssignment).toBe('governance');
  });

  it('PatternRecognitionBee spawns in cold pool', () => {
    const bee = factory.spawn(TEMPLATES.coldPatternBee);
    expect(bee.poolAssignment).toBe('cold');
  });

  it('can filter registry by pool', () => {
    factory.spawn(TEMPLATES.vectorWeaver);
    factory.spawn(TEMPLATES.vectorWeaver);
    factory.spawn(TEMPLATES.auditLogger);
    factory.spawn(TEMPLATES.coldPatternBee);

    expect(registry.count({ pool: 'hot' })).toBe(2);
    expect(registry.count({ pool: 'governance' })).toBe(1);
    expect(registry.count({ pool: 'cold' })).toBe(1);
  });
});

describe('Bee Registry — Querying', () => {
  let factory, registry;

  beforeEach(() => {
    registry = new BeeRegistry();
    factory = new BeeFactory(registry);
    
    factory.spawn(TEMPLATES.vectorWeaver);
    factory.spawn(TEMPLATES.vectorWeaver);
    factory.spawn(TEMPLATES.latticeCrypto);
    factory.spawn(TEMPLATES.auditLogger);
    factory.spawn(TEMPLATES.coldPatternBee);
  });

  afterEach(() => {
    registry.clear();
  });

  it('lists all bees', () => {
    expect(registry.list()).toHaveLength(5);
  });

  it('filters bees by swarm', () => {
    const weavers = registry.list({ swarm: 'SWARM_THE_WEAVER' });
    expect(weavers).toHaveLength(2);
    expect(weavers.every((b) => b.swarm === 'SWARM_THE_WEAVER')).toBe(true);
  });

  it('filters bees by capability', () => {
    const embedders = registry.list({ capability: 'embed' });
    expect(embedders).toHaveLength(2);
    expect(embedders.every((b) => b.capabilities.includes('embed'))).toBe(true);
  });

  it('filters bees by state', () => {
    const activeBees = registry.list({ state: BEE_STATES.ACTIVE });
    expect(activeBees).toHaveLength(5);
  });

  it('returns empty array for unmatched filter', () => {
    expect(registry.list({ swarm: 'NONEXISTENT_SWARM' })).toHaveLength(0);
  });

  it('returns null for unknown bee id', () => {
    expect(registry.get('bee_unknown_999')).toBeNull();
  });
});

describe('Bee Factory — Swarm Matrix Integrity', () => {
  const SWARM_IDS = [
    'SWARM_CORE_OS', 'SWARM_THE_FORGE', 'SWARM_THE_SENTINEL', 'SWARM_THE_ORACLE',
    'SWARM_THE_WEAVER', 'SWARM_THE_HEALER', 'SWARM_THE_CHRONICLER', 'SWARM_THE_NAVIGATOR',
    'SWARM_THE_ARTISAN', 'SWARM_THE_MATHEMATICIAN', 'SWARM_THE_EMPATH', 'SWARM_THE_ALCHEMIST',
    'SWARM_THE_OBSERVER', 'SWARM_THE_DIPLOMAT', 'SWARM_THE_ARCHITECT', 'SWARM_THE_SAGE',
    'SWARM_THE_CONDUCTOR', 'SWARM_THE_PIONEER',
  ];

  const AGENT_CLASS_IDS = [
    'VectorWeaverBee', 'LatticeCryptographyBee', 'PatternRecognitionBee', 'BrainBee',
    'EmbeddingBee', 'SecurityBee', 'AutoHealBee', 'DocumentationBee', 'AuditLoggerBee',
    'MonteCarloSimulatorBee', 'KnowledgeGraphBee', 'DriftSentinelBee', 'ContentCraftBee',
    'BrandGuardianBee', 'RAGOrchestratorBee', 'TelemetryCollectorBee', 'PipelineExecutorBee',
    'UserStoryBee', 'FeedbackProcessorBee', 'SwarmCoordinatorBee', 'ConsensusEnforcerBee',
    'ScientistBee', 'BuildEngineerBee', 'SystemCoordinatorBee', 'RoutingBee',
    'APIBridgeBee', 'DiagnosticBee', 'StatisticalAnalyzerBee', 'MemoryConsolidatorBee',
    'ReasoningBee', 'ExperimentRunnerBee',
  ];

  it('has exactly 18 swarms', () => {
    expect(SWARM_IDS).toHaveLength(18);
  });

  it('has exactly 31 agent classes', () => {
    expect(AGENT_CLASS_IDS).toHaveLength(31);
  });

  it('all swarm IDs are unique', () => {
    expect(new Set(SWARM_IDS).size).toBe(SWARM_IDS.length);
  });

  it('all agent class IDs are unique', () => {
    expect(new Set(AGENT_CLASS_IDS).size).toBe(AGENT_CLASS_IDS.length);
  });

  it('VectorWeaverBee is in the agent class list', () => {
    expect(AGENT_CLASS_IDS).toContain('VectorWeaverBee');
  });

  it('LatticeCryptographyBee is in the agent class list', () => {
    expect(AGENT_CLASS_IDS).toContain('LatticeCryptographyBee');
  });

  it('PatternRecognitionBee is in the agent class list', () => {
    expect(AGENT_CLASS_IDS).toContain('PatternRecognitionBee');
  });

  it('SWARM_THE_ORACLE is a swarm', () => {
    expect(SWARM_IDS).toContain('SWARM_THE_ORACLE');
  });

  it('SWARM_THE_SENTINEL is a swarm', () => {
    expect(SWARM_IDS).toContain('SWARM_THE_SENTINEL');
  });

  it('SWARM_THE_WEAVER is a swarm', () => {
    expect(SWARM_IDS).toContain('SWARM_THE_WEAVER');
  });
});
