/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║  Metacognitive Telemetry Loop — Self-Awareness Engine                      ║
 * ║  Heady™ Systems · Sacred Geometry Architecture                             ║
 * ║  © 2026 HeadySystems Inc. All rights reserved.                             ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  The system watches itself. Branding integrity, telemetry ring buffers,    ║
 * ║  rolling error rates, confidence assessment, and LLM-injectable context.   ║
 * ║  PHI governs scan cadence. The organism knows its own health.              ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * @module self-awareness
 * @version 4.0.0
 * @author HeadySystems Engineering
 */

'use strict';

const os = require('os');
const https = require('https');
const EventEmitter = require('events');

// ─── Sacred Constants ──────────────────────────────────────────────────────────

/** @constant {number} PHI - The golden ratio */
const PHI = 1.6180339887;

/** @constant {number} RING_BUFFER_SIZE - Telemetry ring buffer capacity */
const RING_BUFFER_SIZE = 500;

/** @constant {number} ONE_MINUTE_MS */
const ONE_MINUTE_MS = 60000;

/** @constant {number} FIVE_MINUTES_MS */
const FIVE_MINUTES_MS = 300000;

/** @constant {number} BASE_SCAN_INTERVAL - Base branding scan interval (PHI-scaled 60s) */
const BASE_SCAN_INTERVAL = Math.round(ONE_MINUTE_MS * PHI);

// ─── Brand Domains ─────────────────────────────────────────────────────────────

/** @constant {Array<string>} BRAND_DOMAINS - Domains to monitor for branding compliance */
const BRAND_DOMAINS = [
  'headysystems.com',
  'headyme.com',
  'headyconnection.org',
  'headyio.com',
  'headymcp.com',
  'headybuddy.org',
];

// ─── Branding Rules ────────────────────────────────────────────────────────────

/**
 * Required meta tags that must be present in all Heady™ domain pages.
 * @constant {Array<Object>}
 */
const REQUIRED_META = [
  { name: 'author', contains: 'HeadySystems' },
  { name: 'generator', contains: 'Heady' },
];

/**
 * Required HTTP response headers.
 * @constant {Array<Object>}
 */
const REQUIRED_HEADERS = [
  { header: 'x-powered-by', contains: 'Heady' },
];

/**
 * Strings that must NOT appear in any Heady™ page content.
 * No localhost references allowed.
 * @constant {Array<string>}
 */
const FORBIDDEN_STRINGS = [
  'localhost',
  '127.0.0.1',
  '0.0.0.0',
  'localhost:',
  'http://localhost',
  'https://localhost',
];

/**
 * Required branding elements in page content.
 * @constant {Array<string>}
 */
const REQUIRED_BRANDING = [
  'Heady',
  '©',
  'HeadySystems',
];

// ─── Telemetry Ring Buffer ─────────────────────────────────────────────────────

/**
 * Fixed-size ring buffer for telemetry events with aggregate stats.
 *
 * @class TelemetryRingBuffer
 */
class TelemetryRingBuffer {
  /**
   * @param {number} [capacity=500] - Buffer capacity.
   */
  constructor(capacity = RING_BUFFER_SIZE) {
    this.capacity = capacity;
    this._buffer = new Array(capacity);
    this._head = 0;
    this._count = 0;
    this._stats = {
      totalEvents: 0,
      byType: {},
      byLevel: { info: 0, warn: 0, error: 0, critical: 0 },
      firstEvent: null,
      lastEvent: null,
    };
  }

  /**
   * Push a telemetry event into the ring buffer.
   * @param {Object} event - Telemetry event.
   * @param {string} event.type - Event type.
   * @param {string} [event.level='info'] - Severity level.
   * @param {*} event.data - Event payload.
   * @returns {Object} The stored event with timestamp.
   */
  push(event) {
    const enriched = {
      ...event,
      ts: Date.now(),
      seq: this._stats.totalEvents,
      level: event.level || 'info',
    };

    this._buffer[this._head] = enriched;
    this._head = (this._head + 1) % this.capacity;
    if (this._count < this.capacity) this._count++;

    // Update stats
    this._stats.totalEvents++;
    this._stats.byType[event.type] = (this._stats.byType[event.type] || 0) + 1;
    this._stats.byLevel[enriched.level] = (this._stats.byLevel[enriched.level] || 0) + 1;
    if (!this._stats.firstEvent) this._stats.firstEvent = enriched.ts;
    this._stats.lastEvent = enriched.ts;

    return enriched;
  }

  /**
   * Get the last N events from the buffer.
   * @param {number} [n=50] - Number of events.
   * @returns {Array<Object>}
   */
  recent(n = 50) {
    const count = Math.min(n, this._count);
    const result = [];
    for (let i = 0; i < count; i++) {
      const idx = (this._head - 1 - i + this.capacity) % this.capacity;
      if (this._buffer[idx]) result.push(this._buffer[idx]);
    }
    return result;
  }

  /**
   * Get events within a time window.
   * @param {number} windowMs - Time window in ms.
   * @returns {Array<Object>}
   */
  window(windowMs) {
    const cutoff = Date.now() - windowMs;
    const result = [];
    for (let i = 0; i < this._count; i++) {
      const idx = (this._head - 1 - i + this.capacity) % this.capacity;
      const event = this._buffer[idx];
      if (event && event.ts >= cutoff) result.push(event);
      else if (event && event.ts < cutoff) break; // Events are ordered by time
    }
    return result;
  }

  /**
   * Get aggregate stats.
   * @returns {Object}
   */
  getStats() {
    return {
      ...this._stats,
      bufferSize: this._count,
      bufferCapacity: this.capacity,
      bufferUtilization: this._count / this.capacity,
    };
  }

  /**
   * Count events of a specific type within a time window.
   * @param {string} type - Event type to count.
   * @param {number} windowMs - Time window in ms.
   * @returns {number}
   */
  countByType(type, windowMs) {
    const events = this.window(windowMs);
    return events.filter(e => e.type === type).length;
  }

  /**
   * Count error-level events within a time window.
   * @param {number} windowMs
   * @returns {number}
   */
  countErrors(windowMs) {
    const events = this.window(windowMs);
    return events.filter(e => e.level === 'error' || e.level === 'critical').length;
  }
}

// ─── Rolling Error Rate Calculator ─────────────────────────────────────────────

/**
 * Track rolling error rates over configurable time windows.
 *
 * @class RollingErrorRate
 */
class RollingErrorRate {
  /**
   * @param {TelemetryRingBuffer} ringBuffer - Source telemetry buffer.
   */
  constructor(ringBuffer) {
    this._ring = ringBuffer;
  }

  /**
   * Get the error rate for a given time window.
   * @param {number} windowMs - Time window in ms.
   * @returns {{ rate: number, errors: number, total: number }}
   */
  getRate(windowMs) {
    const events = this._ring.window(windowMs);
    const total = events.length;
    const errors = events.filter(e => e.level === 'error' || e.level === 'critical').length;
    return {
      rate: total > 0 ? errors / total : 0,
      errors,
      total,
    };
  }

  /**
   * Get 1-minute error rate.
   * @returns {{ rate: number, errors: number, total: number }}
   */
  get oneMinute() {
    return this.getRate(ONE_MINUTE_MS);
  }

  /**
   * Get 5-minute error rate.
   * @returns {{ rate: number, errors: number, total: number }}
   */
  get fiveMinute() {
    return this.getRate(FIVE_MINUTES_MS);
  }

  /**
   * Get a summary of all tracked windows.
   * @returns {Object}
   */
  summary() {
    return {
      '1min': this.oneMinute,
      '5min': this.fiveMinute,
    };
  }
}

// ─── Branding Monitor ──────────────────────────────────────────────────────────

/**
 * Monitor Heady™ brand domains for compliance with branding rules.
 * Checks meta tags, headers, forbidden strings, and required branding.
 *
 * @class BrandingMonitor
 */
class BrandingMonitor {
  constructor() {
    this._results = new Map();
    this._lastScan = null;
    this._scanCount = 0;
  }

  /**
   * Scan all brand domains for compliance.
   * @returns {Promise<Object>} Scan results.
   */
  async scanAll() {
    const results = {};
    const startTime = Date.now();

    for (const domain of BRAND_DOMAINS) {
      try {
        results[domain] = await this._scanDomain(domain);
      } catch (err) {
        results[domain] = {
          domain,
          reachable: false,
          error: err.message,
          violations: [],
          ts: Date.now(),
        };
      }
    }

    this._lastScan = Date.now();
    this._scanCount++;

    const allViolations = Object.values(results)
      .flatMap(r => r.violations || []);

    const report = {
      ts: Date.now(),
      duration: Date.now() - startTime,
      domains: results,
      totalViolations: allViolations.length,
      compliant: allViolations.length === 0,
      scanNumber: this._scanCount,
    };

    this._results.set(this._lastScan, report);
    // Keep last 50 scan results
    if (this._results.size > 50) {
      const oldest = this._results.keys().next().value;
      this._results.delete(oldest);
    }

    return report;
  }

  /**
   * Scan a single domain.
   * @private
   * @param {string} domain
   * @returns {Promise<Object>}
   */
  _scanDomain(domain) {
    return new Promise((resolve, reject) => {
      const violations = [];
      const url = `https://${domain}`;

      const req = https.get(url, { timeout: 10000 }, (res) => {
        // Check required headers
        for (const rule of REQUIRED_HEADERS) {
          const headerVal = res.headers[rule.header] || '';
          if (!headerVal.toLowerCase().includes(rule.contains.toLowerCase())) {
            violations.push({
              type: 'missing_header',
              rule: rule.header,
              expected: rule.contains,
              actual: headerVal || '(not set)',
            });
          }
        }

        let body = '';
        res.on('data', chunk => { body += chunk; });
        res.on('end', () => {
          // Check forbidden strings
          for (const forbidden of FORBIDDEN_STRINGS) {
            if (body.toLowerCase().includes(forbidden.toLowerCase())) {
              violations.push({
                type: 'forbidden_string',
                value: forbidden,
                message: `Forbidden string "${forbidden}" found in page content`,
              });
            }
          }

          // Check required meta tags
          for (const meta of REQUIRED_META) {
            const regex = new RegExp(`<meta[^>]*name=["']${meta.name}["'][^>]*content=["']([^"']*)["']`, 'i');
            const match = body.match(regex);
            if (!match || !match[1].includes(meta.contains)) {
              violations.push({
                type: 'missing_meta',
                name: meta.name,
                expected: meta.contains,
                actual: match ? match[1] : '(not found)',
              });
            }
          }

          // Check required branding
          for (const brand of REQUIRED_BRANDING) {
            if (!body.includes(brand)) {
              violations.push({
                type: 'missing_branding',
                expected: brand,
                message: `Required branding "${brand}" not found in page`,
              });
            }
          }

          resolve({
            domain,
            reachable: true,
            statusCode: res.statusCode,
            violations,
            compliant: violations.length === 0,
            ts: Date.now(),
          });
        });
      });

      req.on('error', (err) => {
        resolve({
          domain,
          reachable: false,
          error: err.message,
          violations: [{
            type: 'unreachable',
            message: `Domain unreachable: ${err.message}`,
          }],
          compliant: false,
          ts: Date.now(),
        });
      });

      req.on('timeout', () => {
        req.destroy();
        resolve({
          domain,
          reachable: false,
          error: 'Timeout',
          violations: [{
            type: 'timeout',
            message: 'Domain scan timed out',
          }],
          compliant: false,
          ts: Date.now(),
        });
      });
    });
  }

  /**
   * Get last scan results.
   * @returns {Object|null}
   */
  getLastScan() {
    if (this._results.size === 0) return null;
    const lastKey = [...this._results.keys()].pop();
    return this._results.get(lastKey);
  }

  /**
   * Get scan history.
   * @param {number} [limit=10]
   * @returns {Array<Object>}
   */
  getHistory(limit = 10) {
    const entries = [...this._results.values()];
    return entries.slice(-limit);
  }
}

// ─── System State Assessment ───────────────────────────────────────────────────

/**
 * Assess overall system state and compute confidence score.
 *
 * @param {Object} params
 * @param {RollingErrorRate} params.errorRates - Rolling error rate tracker.
 * @param {Object} [params.vectorMemory] - Vector memory instance (for depth).
 * @param {Object} [params.circuitBreakers] - Circuit breaker snapshots.
 * @returns {Object} System state assessment.
 */
function assessSystemState({ errorRates, vectorMemory, circuitBreakers }) {
  const memUsage = process.memoryUsage();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const memPressure = 1 - (freeMem / totalMem);

  const oneMin = errorRates.oneMinute;
  const fiveMin = errorRates.fiveMinute;

  // Vector memory depth
  let vmDepth = 0;
  if (vectorMemory && typeof vectorMemory.depth !== 'undefined') {
    vmDepth = vectorMemory.depth;
  }

  // Circuit breaker health
  let openBreakers = 0;
  let totalBreakers = 0;
  if (circuitBreakers) {
    for (const [, snap] of Object.entries(circuitBreakers)) {
      totalBreakers++;
      if (snap.state === 'OPEN') openBreakers++;
    }
  }

  // Confidence calculation:
  // Start at 1.0, deduct for error rate, memory pressure, open breakers
  let confidence = 1.0;

  // Error rate impact (heaviest penalty)
  confidence -= oneMin.rate * 0.4;
  confidence -= fiveMin.rate * 0.2;

  // Memory pressure impact
  if (memPressure > 0.9) confidence -= 0.2;
  else if (memPressure > 0.75) confidence -= 0.1;
  else if (memPressure > 0.5) confidence -= 0.05;

  // Vector memory depth bonus (more memories = more context = higher confidence)
  const depthBonus = Math.min(vmDepth / 10000, 0.1);
  confidence += depthBonus;

  // Circuit breaker penalty
  if (totalBreakers > 0) {
    confidence -= (openBreakers / totalBreakers) * 0.15;
  }

  confidence = Math.max(0, Math.min(1, confidence));

  // Determine health status
  let health;
  if (confidence >= 0.8) health = 'healthy';
  else if (confidence >= 0.6) health = 'degraded';
  else if (confidence >= 0.3) health = 'impaired';
  else health = 'critical';

  return {
    confidence: Math.round(confidence * 10000) / 10000,
    health,
    errorRates: {
      '1min': oneMin,
      '5min': fiveMin,
    },
    memoryPressure: Math.round(memPressure * 10000) / 10000,
    heapUsedMB: Math.round(memUsage.heapUsed / 1048576),
    rssMB: Math.round(memUsage.rss / 1048576),
    vectorMemoryDepth: vmDepth,
    circuitBreakers: {
      total: totalBreakers,
      open: openBreakers,
    },
    ts: Date.now(),
  };
}

// ─── LLM Context Synthesis ─────────────────────────────────────────────────────

/**
 * Synthesize an LLM-injectable context string from system state.
 * This string can be prepended to LLM prompts for system-aware responses.
 *
 * @param {Object} systemState - Output of assessSystemState().
 * @param {Object} [extras] - Additional context fields.
 * @returns {string} Context string for LLM injection.
 */
function synthesizeLLMContext(systemState, extras = {}) {
  const parts = [
    `[HEADY-SYSTEM-STATE]`,
    `Health: ${systemState.health} (confidence: ${(systemState.confidence * 100).toFixed(1)}%)`,
    `Error rates: 1min=${(systemState.errorRates['1min'].rate * 100).toFixed(1)}%, 5min=${(systemState.errorRates['5min'].rate * 100).toFixed(1)}%`,
    `Memory: ${systemState.heapUsedMB}MB heap, ${(systemState.memoryPressure * 100).toFixed(0)}% pressure`,
    `Vector memory depth: ${systemState.vectorMemoryDepth} entries`,
    `Circuit breakers: ${systemState.circuitBreakers.open}/${systemState.circuitBreakers.total} open`,
  ];

  if (extras.recentErrors && extras.recentErrors.length > 0) {
    parts.push(`Recent errors: ${extras.recentErrors.slice(0, 3).map(e => e.type || e.message || 'unknown').join(', ')}`);
  }

  if (extras.brandingStatus) {
    parts.push(`Branding compliance: ${extras.brandingStatus.compliant ? 'OK' : `${extras.brandingStatus.totalViolations} violations`}`);
  }

  if (extras.agentCount !== undefined) {
    parts.push(`Active agents: ${extras.agentCount}`);
  }

  parts.push(`[/HEADY-SYSTEM-STATE]`);
  return parts.join('\n');
}

// ─── SelfAwareness Engine ──────────────────────────────────────────────────────

/**
 * Metacognitive Telemetry Loop — the system's self-awareness engine.
 * Combines branding monitoring, telemetry, error rates, system assessment,
 * and LLM context synthesis into a unified introspection system.
 *
 * @class SelfAwareness
 * @extends EventEmitter
 */
class SelfAwareness extends EventEmitter {
  /**
   * @param {Object} [opts]
   * @param {Object} [opts.vectorMemory] - Vector memory instance.
   * @param {Object} [opts.pipeline] - Pipeline instance (for circuit breakers).
   * @param {boolean} [opts.autoScan=false] - Enable automatic branding scans.
   */
  constructor(opts = {}) {
    super();
    this.setMaxListeners(30);

    // Core subsystems
    this.telemetry = new TelemetryRingBuffer(RING_BUFFER_SIZE);
    this.errorRates = new RollingErrorRate(this.telemetry);
    this.branding = new BrandingMonitor();

    // Bound systems
    this._vectorMemory = opts.vectorMemory || null;
    this._pipeline = opts.pipeline || null;

    // Branding scan timer
    this._scanTimer = null;
    this._autoScan = opts.autoScan || false;
    this._scanInterval = BASE_SCAN_INTERVAL;

    if (this._autoScan) {
      this._startBrandingScan();
    }
  }

  /**
   * Bind external systems for richer introspection.
   * @param {Object} systems - { vectorMemory, pipeline }
   */
  bind(systems) {
    if (systems.vectorMemory) this._vectorMemory = systems.vectorMemory;
    if (systems.pipeline) this._pipeline = systems.pipeline;
  }

  // ── Telemetry ──

  /**
   * Record a telemetry event.
   * @param {string} type - Event type.
   * @param {*} data - Event data.
   * @param {string} [level='info'] - Severity level.
   */
  recordEvent(type, data, level = 'info') {
    const event = this.telemetry.push({ type, data, level });
    this.emit('event', event);
    return event;
  }

  /**
   * Process an external event (e.g., circuit breaker state change).
   * Hooks into pipeline/system events.
   * @param {Object} event - External event.
   */
  processEvent(event) {
    const level = this._classifyEventLevel(event);
    this.telemetry.push({
      type: event.type || 'external',
      data: event,
      level,
    });

    // Special handling for circuit breaker events
    if (event.type === 'circuit_breaker') {
      if (event.state === 'OPEN') {
        this.emit('alert', {
          severity: 'warn',
          message: `Circuit breaker "${event.name}" opened`,
          event,
        });
      }
      if (event.state === 'CLOSED' && event.oldState === 'OPEN') {
        this.emit('recovery', {
          message: `Circuit breaker "${event.name}" recovered`,
          event,
        });
      }
    }
  }

  /**
   * Classify an event's severity level.
   * @private
   * @param {Object} event
   * @returns {string}
   */
  _classifyEventLevel(event) {
    if (event.type === 'circuit_breaker' && event.state === 'OPEN') return 'error';
    if (event.type === 'circuit_breaker' && event.state === 'HALF_OPEN') return 'warn';
    if (event.type === 'error' || event.severity === 'critical') return 'critical';
    if (event.type === 'warning' || event.severity === 'high') return 'warn';
    return 'info';
  }

  // ── Assessment ──

  /**
   * Assess current system state with confidence scoring.
   * @returns {Object} System state assessment.
   */
  assessSystemState() {
    const circuitBreakers = this._pipeline
      ? (typeof this._pipeline.getCircuitBreakers === 'function'
        ? this._pipeline.getCircuitBreakers()
        : {})
      : {};

    return assessSystemState({
      errorRates: this.errorRates,
      vectorMemory: this._vectorMemory,
      circuitBreakers,
    });
  }

  /**
   * Get LLM-injectable context string.
   * @returns {string}
   */
  getLLMContext() {
    const state = this.assessSystemState();
    const recentErrors = this.telemetry.recent(20)
      .filter(e => e.level === 'error' || e.level === 'critical');

    const agentCount = this._vectorMemory && this._vectorMemory.agentManager
      ? this._vectorMemory.agentManager.getActiveAgents().length
      : 0;

    return synthesizeLLMContext(state, {
      recentErrors,
      brandingStatus: this.branding.getLastScan(),
      agentCount,
    });
  }

  // ── Full Introspection ──

  /**
   * Perform full system introspection combining all telemetry streams.
   * @returns {Object} Complete introspection report.
   */
  introspect() {
    const state = this.assessSystemState();
    const telemetryStats = this.telemetry.getStats();
    const errorSummary = this.errorRates.summary();
    const lastBrandScan = this.branding.getLastScan();

    const pipelineState = this._pipeline
      ? (typeof this._pipeline.getState === 'function' ? this._pipeline.getState() : null)
      : null;

    const memoryStats = this._vectorMemory
      ? (typeof this._vectorMemory.stats === 'function' ? this._vectorMemory.stats() : null)
      : null;

    return {
      system: state,
      telemetry: telemetryStats,
      errorRates: errorSummary,
      branding: lastBrandScan,
      pipeline: pipelineState,
      memory: memoryStats,
      llmContext: this.getLLMContext(),
      uptime: process.uptime(),
      ts: Date.now(),
    };
  }

  // ── Branding Scan ──

  /**
   * Trigger a branding compliance scan.
   * @returns {Promise<Object>}
   */
  async scanBranding() {
    const result = await this.branding.scanAll();

    if (!result.compliant) {
      this.recordEvent('branding_violation', result, 'warn');
      this.emit('branding_violation', result);
    } else {
      this.recordEvent('branding_scan', result, 'info');
    }

    return result;
  }

  /**
   * Start automatic branding scan with dynamic PHI-scaled intervals.
   * Interval adjusts based on memory pressure:
   *   - High pressure → scan less frequently (conserve resources)
   *   - Low pressure → scan more frequently
   * @private
   */
  _startBrandingScan() {
    const tick = async () => {
      try {
        await this.scanBranding();
      } catch (err) {
        this.recordEvent('branding_scan_error', { error: err.message }, 'error');
      }

      // Recompute interval based on current memory pressure
      this._scanInterval = this._computeScanInterval();
      this._scanTimer = setTimeout(tick, this._scanInterval);
      if (this._scanTimer.unref) this._scanTimer.unref();
    };

    this._scanTimer = setTimeout(tick, this._scanInterval);
    if (this._scanTimer.unref) this._scanTimer.unref();
  }

  /**
   * Compute scan interval dynamically based on memory pressure and PHI.
   * @private
   * @returns {number} Interval in ms.
   */
  _computeScanInterval() {
    const freeMem = os.freemem();
    const totalMem = os.totalmem();
    const pressure = 1 - (freeMem / totalMem);

    // Under high pressure, scale up the interval by PHI^2
    // Under low pressure, use base interval
    if (pressure > 0.85) {
      return Math.round(BASE_SCAN_INTERVAL * PHI * PHI);
    }
    if (pressure > 0.65) {
      return Math.round(BASE_SCAN_INTERVAL * PHI);
    }
    return BASE_SCAN_INTERVAL;
  }

  // ── Lifecycle ──

  /**
   * Stop all timers and release resources.
   */
  destroy() {
    if (this._scanTimer) {
      clearTimeout(this._scanTimer);
      this._scanTimer = null;
    }
    this.removeAllListeners();
  }
}

// ─── Singleton Instance ────────────────────────────────────────────────────────

/** @type {SelfAwareness} Default self-awareness instance */
const selfAwareness = new SelfAwareness();

// ─── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  // Primary export
  selfAwareness,

  // Classes
  SelfAwareness,
  TelemetryRingBuffer,
  RollingErrorRate,
  BrandingMonitor,

  // Functions
  assessSystemState,
  synthesizeLLMContext,

  // Constants
  PHI,
  RING_BUFFER_SIZE,
  BRAND_DOMAINS,
  REQUIRED_META,
  REQUIRED_HEADERS,
  FORBIDDEN_STRINGS,
  REQUIRED_BRANDING,
  BASE_SCAN_INTERVAL,
};
