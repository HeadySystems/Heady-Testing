/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 8: Inline Routes
 * Core system routes mounted directly — no external router file required.
 * These routes are always available regardless of service registry state.
 *
 * Routes:
 *   GET  /health           — Kubernetes/Cloud Run liveness probe
 *   GET  /api/pulse        — Deep system pulse with subsystem status
 *   GET  /api/layer        — Architecture layer map
 *   GET  /api/csl/gate     — Continuous Semantic Logic gate evaluation
 *   GET  /api/edge/status  — Edge deployment status
 *   GET  /api/telemetry/stats — Aggregate telemetry statistics
 *   GET  /api/principles   — Heady Sacred Geometry operating principles
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/inline-routes
 * @version 3.1.0
 */

'use strict';

const logger = require('../utils/logger');
const { cosine_similarity, coherence_score, PHI_GATE } = require('../core/semantic-logic');

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI   = 1.6180339887;
const PHI_I = 1 / PHI;

// ─── System Start Time ────────────────────────────────────────────────────────
const BOOT_TIME = Date.now();

/**
 * Calculate uptime in seconds with PHI ratio.
 * @returns {{ seconds: number, phi_ratio: number }}
 */
function uptime() {
  const seconds   = (Date.now() - BOOT_TIME) / 1000;
  const phi_ratio = seconds / (PHI * 1000);
  return { seconds: parseFloat(seconds.toFixed(3)), phi_ratio: parseFloat(phi_ratio.toFixed(6)) };
}

// ─── Architecture Layers ──────────────────────────────────────────────────────

/** Complete Heady architecture layer map */
const LAYER_MAP = {
  version: '3.1.0',
  architecture: 'Sacred Geometry Multi-Agent OS',
  phi: PHI,
  layers: [
    {
      id:       'L0',
      name:     'Sacred Foundation',
      desc:     'PHI constants, CSL math, YAML parser',
      modules:  ['src/core/semantic-logic', 'src/core/heady-yaml', 'src/utils/logger'],
      phi_level: 0,
    },
    {
      id:       'L1',
      name:     'Config & Globals',
      desc:     'Express app, event bus, remote config, secrets, Cloudflare manager',
      modules:  ['src/bootstrap/config-globals'],
      phi_level: 1,
    },
    {
      id:       'L2',
      name:     'Security & Middleware',
      desc:     'Helmet, CORS, rate limiter, compression, site renderer',
      modules:  ['src/bootstrap/middleware-stack'],
      phi_level: PHI_I,
    },
    {
      id:       'L3',
      name:     'Auth Engine',
      desc:     'JWT, API keys, Cloudflare Access, RBAC',
      modules:  ['src/bootstrap/auth-engine'],
      phi_level: PHI,
    },
    {
      id:       'L4',
      name:     'Vector Stack',
      desc:     '384-dim memory, buddy interface, HCFullPipeline, self-awareness, watchdog',
      modules:  ['src/bootstrap/vector-stack'],
      phi_level: PHI * PHI,
    },
    {
      id:       'L5',
      name:     'Engine Wiring',
      desc:     'Monte Carlo, pattern engine, auto-success, scientist QA, self-critique',
      modules:  ['src/bootstrap/engine-wiring'],
      phi_level: PHI * PHI * PHI,
    },
    {
      id:       'L6',
      name:     'Pipeline Wiring',
      desc:     'Self-healing wire, PHI-backoff retry, timing analysis',
      modules:  ['src/bootstrap/pipeline-wiring'],
      phi_level: PHI * PHI * PHI * PHI,
    },
    {
      id:       'L7',
      name:     'Service Registry',
      desc:     '40+ service endpoints via try/require pattern',
      modules:  ['src/bootstrap/service-registry'],
      phi_level: PHI * 5,
    },
    {
      id:       'L8',
      name:     'Inline Routes',
      desc:     'Health, pulse, layer, CSL gate, edge, telemetry, principles',
      modules:  ['src/bootstrap/inline-routes'],
      phi_level: PHI * 6,
    },
    {
      id:       'L9',
      name:     'Voice Relay',
      desc:     'WebSocket voice sessions, audio chunking, real-time transcription relay',
      modules:  ['src/bootstrap/voice-relay'],
      phi_level: PHI * 7,
    },
    {
      id:       'L10',
      name:     'Server Boot',
      desc:     'HTTP/HTTPS + WebSocket listener, graceful shutdown, sacred banner',
      modules:  ['src/bootstrap/server-boot'],
      phi_level: PHI * 8,
    },
  ],
};

// ─── Heady Principles ─────────────────────────────────────────────────────────

const HEADY_PRINCIPLES = [
  {
    id: 'P1',
    name: 'PHI Coherence',
    desc: 'All timing, thresholds, and capacity limits are derived from the golden ratio (1.6180339887). This creates natural harmonic resonance throughout the system.',
    phi_value: PHI,
  },
  {
    id: 'P2',
    name: 'Sacred Geometry Architecture',
    desc: 'System components follow Fibonacci spiral organization. Each layer emerges from the previous, creating self-similar patterns at every scale.',
    phi_value: PHI * PHI,
  },
  {
    id: 'P3',
    name: 'Liquid Orchestration',
    desc: 'Agents flow dynamically between tasks. No rigid pipelines — only adaptive, PHI-weighted orchestration that self-heals and re-plans.',
    phi_value: PHI * PHI * PHI,
  },
  {
    id: 'P4',
    name: 'Self-Awareness Loop',
    desc: 'The system continuously monitors itself via the SelfAwareness telemetry loop, maintaining consciousness of its own state at 2618ms intervals.',
    phi_value: PHI ** 4,
  },
  {
    id: 'P5',
    name: 'Resonance Gate (CSL)',
    desc: 'Semantic operations pass through a PHI-derived resonance gate. Only vectors with cosine similarity ≥ 0.618 (1/PHI) are considered semantically aligned.',
    phi_value: PHI_I,
  },
  {
    id: 'P6',
    name: 'Monte Carlo Truth',
    desc: 'Planning uses Monte Carlo simulation with 688 samples to find optimal execution paths. Uncertainty is embraced, not avoided.',
    phi_value: PHI ** 6,
  },
  {
    id: 'P7',
    name: 'No Localhost',
    desc: 'All services reference branded domains. Heady runs cloud-native from day one — containerized, 12-factor, and globally distributed.',
    phi_value: PHI ** 7,
  },
  {
    id: 'P8',
    name: 'Graceful Degradation',
    desc: 'Every service is optional. Missing modules degrade gracefully to 501 stubs. The system never fully fails — it reduces capabilities progressively.',
    phi_value: PHI ** 8,
  },
];

// ─── Main Export ──────────────────────────────────────────────────────────────

/**
 * Mount all inline core routes on the Express app.
 *
 * @param {import('express').Application} app
 * @param {object} [opts={}]
 * @param {object} [opts.selfAwareness]  - SelfAwareness instance
 * @param {object} [opts.vectorMemory]   - VectorMemory instance
 * @param {object} [opts.pipeline]       - HCFullPipeline instance
 * @param {object} [opts.selfHeal]       - SelfHealingWire instance
 * @param {object} [opts.mcScheduler]    - MonteCarloScheduler instance
 * @returns {void}
 */
function mountInlineRoutes(app, opts = {}) {
  const log = logger.child('inlineRoutes');

  // ── GET /health ─────────────────────────────────────────────────────────────
  /**
   * @route GET /health
   * @desc  Kubernetes liveness probe. Returns 200 OK while process is alive.
   */
  app.get('/health', (_req, res) => {
    res.status(200).json({
      status:  'ok',
      ts:      new Date().toISOString(),
      uptime:  uptime(),
      version: '3.1.0',
      phi:     PHI,
    });
  });

  // ── GET /api/pulse ──────────────────────────────────────────────────────────
  /**
   * @route GET /api/pulse
   * @desc  Deep system pulse — subsystem status, memory stats, pipeline activity.
   */
  app.get('/api/pulse', (req, res) => {
    const awareness = opts.selfAwareness?.health || {};
    const memStats  = opts.vectorMemory?.stats()  || {};
    const pipeline  = opts.pipeline;

    res.json({
      status:   'operational',
      ts:       new Date().toISOString(),
      uptime:   uptime(),
      version:  '3.1.0',
      phi:      PHI,
      subsystems: {
        vectorMemory: {
          status:   memStats.size !== undefined ? 'online' : 'unavailable',
          size:     memStats.size  || 0,
          dim:      memStats.dim   || 384,
          inserts:  memStats.inserts || 0,
        },
        pipeline: {
          status:      pipeline ? 'online' : 'unavailable',
          activeTasks: pipeline?.active?.size || 0,
        },
        selfAwareness: {
          status: awareness.status || 'unknown',
          tick:   awareness.tick   || 0,
        },
        selfHeal: {
          status: opts.selfHeal ? 'online' : 'unavailable',
          stats:  opts.selfHeal?.stats() || {},
        },
      },
      process: {
        pid:      process.pid,
        uptime:   process.uptime(),
        heapMb:   parseFloat((process.memoryUsage().heapUsed / 1_048_576).toFixed(2)),
        rssMb:    parseFloat((process.memoryUsage().rss       / 1_048_576).toFixed(2)),
      },
    });
  });

  // ── GET /api/layer ──────────────────────────────────────────────────────────
  /**
   * @route GET /api/layer
   * @desc  Architecture layer map with PHI level values.
   */
  app.get('/api/layer', (_req, res) => {
    res.json({
      ...LAYER_MAP,
      ts:     new Date().toISOString(),
      uptime: uptime(),
    });
  });

  // ── GET /api/csl/gate ───────────────────────────────────────────────────────
  /**
   * @route GET /api/csl/gate
   * @desc  Test the CSL resonance gate with query-string vectors a and b.
   *        Vectors are JSON-encoded arrays: ?a=[0.1,0.2]&b=[0.1,0.2]
   */
  app.get('/api/csl/gate', (req, res) => {
    try {
      const rawA = req.query.a;
      const rawB = req.query.b;
      const threshold = parseFloat(req.query.threshold) || PHI_GATE;

      if (!rawA || !rawB) {
        return res.json({
          desc:      'Continuous Semantic Logic (CSL) Resonance Gate',
          threshold: PHI_GATE,
          phi:       PHI,
          phi_i:     PHI_I,
          usage:     'GET /api/csl/gate?a=[v1,v2]&b=[v1,v2]&threshold=0.618',
          example:   { a: [1, 0, 0], b: [0.9, 0.1, 0], expected_sim: '~0.994' },
        });
      }

      const a = JSON.parse(rawA);
      const b = JSON.parse(rawB);
      const sim  = cosine_similarity(a, b);
      const open = sim >= threshold;

      res.json({
        open,
        similarity: parseFloat(sim.toFixed(6)),
        threshold,
        phi_ratio:  parseFloat((sim / PHI_I).toFixed(4)),
        a_dim:      a.length,
        b_dim:      b.length,
        phi:        PHI,
      });
    } catch (err) {
      res.status(400).json({ error: 'csl_gate_error', message: err.message });
    }
  });

  // ── GET /api/edge/status ────────────────────────────────────────────────────
  /**
   * @route GET /api/edge/status
   * @desc  Cloudflare edge deployment status.
   */
  app.get('/api/edge/status', (req, res) => {
    const cfRay    = req.headers['cf-ray']           || null;
    const cfPop    = req.headers['cf-ipcountry']     || null;
    const cfIp     = req.headers['cf-connecting-ip'] || req.ip;
    const edgeTls  = req.headers['cf-visitor'] ? JSON.parse(req.headers['cf-visitor'] || '{}').scheme : null;

    res.json({
      edge: {
        provider:    cfRay ? 'cloudflare' : 'direct',
        ray:         cfRay,
        pop:         cfPop,
        clientIp:    cfIp,
        tls:         edgeTls || (req.secure ? 'https' : 'http'),
        cached:      req.headers['cf-cache-status'] || null,
      },
      origin: {
        region:      process.env.CLOUD_REGION    || 'us-central1',
        projectId:   process.env.GCP_PROJECT_ID  || 'heady-prod',
        serviceUrl:  process.env.SERVICE_URL      || `https://api.headysystems.com`,
        version:     '3.1.0',
        instance:    process.env.K_REVISION       || process.env.HOSTNAME || 'local',
      },
      phi: PHI,
      ts:  new Date().toISOString(),
    });
  });

  // ── GET /api/telemetry/stats ────────────────────────────────────────────────
  /**
   * @route GET /api/telemetry/stats
   * @desc  Aggregate telemetry statistics from all subsystems.
   */
  app.get('/api/telemetry/stats', (req, res) => {
    const memStats    = opts.vectorMemory?.stats()        || {};
    const healStats   = opts.selfHeal?.stats()            || {};
    const mcScheduler = opts.mcScheduler;
    const up          = uptime();

    res.json({
      ts:      new Date().toISOString(),
      uptime:  up,
      phi:     PHI,
      memory: {
        vectors:    memStats.size      || 0,
        inserts:    memStats.inserts   || 0,
        queries:    memStats.queries   || 0,
        evictions:  memStats.evictions || 0,
        dim:        memStats.dim       || 384,
        namespaces: memStats.namespaces || {},
      },
      selfHeal: {
        activeHeals:  Object.keys(healStats.healAttempts || {}).length,
        timingLogSize: healStats.timingLogSize || 0,
      },
      process: {
        pid:        process.pid,
        uptime:     process.uptime(),
        heapMb:     parseFloat((process.memoryUsage().heapUsed / 1_048_576).toFixed(2)),
        rssMb:      parseFloat((process.memoryUsage().rss       / 1_048_576).toFixed(2)),
        cpuUser:    process.cpuUsage().user,
        cpuSystem:  process.cpuUsage().system,
      },
      phi_coherence: {
        uptime_phi_ratio: up.phi_ratio,
        description: 'Ratio of system uptime to PHI×1000 seconds',
      },
    });
  });

  // ── GET /api/principles ─────────────────────────────────────────────────────
  /**
   * @route GET /api/principles
   * @desc  Heady Sacred Geometry operating principles.
   */
  app.get('/api/principles', (_req, res) => {
    res.json({
      system:     'Heady™ Systems',
      version:    '3.1.0',
      phi:        PHI,
      principles: HEADY_PRINCIPLES,
      ts:         new Date().toISOString(),
    });
  });

  log.logSystem('Inline routes mounted', {
    routes: ['/health', '/api/pulse', '/api/layer', '/api/csl/gate',
             '/api/edge/status', '/api/telemetry/stats', '/api/principles'],
    phi: PHI,
  });
}

module.exports = mountInlineRoutes;
module.exports.LAYER_MAP         = LAYER_MAP;
module.exports.HEADY_PRINCIPLES  = HEADY_PRINCIPLES;
module.exports.uptime            = uptime;
