/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 7: Service Registry
 * Mounts 40+ service endpoints via try/require pattern.
 * Each service is optional — missing modules degrade gracefully.
 *
 * Services are grouped into domains:
 *   - Core Infrastructure (MCP, brain, memory)
 *   - Creative (generation, art, music, story)
 *   - Governance (policies, roles, audit)
 *   - Deployment (CI/CD, cloud run, rollback)
 *   - Intelligence (trading, research, analysis)
 *   - Health & Monitoring (metrics, alerts, telemetry)
 *   - Agent Factory (bees, liquid, spatial)
 *   - Communication (voice, email, webhooks)
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/service-registry
 * @version 3.1.0
 */

'use strict';

const express = require('express');
const logger  = require('../utils/logger');

// ─── Sacred Geometry ──────────────────────────────────────────────────────────
const PHI = 1.6180339887;

// ─── Service Registry Entry ───────────────────────────────────────────────────

/**
 * @typedef {object} ServiceEntry
 * @property {string}   path    - Express mount path
 * @property {string}   module  - Require path (relative to src/)
 * @property {string}   domain  - Service domain group
 * @property {string}   [desc]  - Human-readable description
 */

/** @type {ServiceEntry[]} */
const SERVICE_CATALOG = [
  // ── Core Infrastructure ────────────────────────────────────────────────────
  { path: '/mcp',                   module: '../services/mcp-server',          domain: 'core',        desc: 'Model Context Protocol server' },
  { path: '/api/brain',             module: '../services/brain-api',           domain: 'core',        desc: 'Central cognitive API' },
  { path: '/api/memory',            module: '../services/memory-api',          domain: 'core',        desc: 'Vector memory CRUD' },
  { path: '/api/pipeline',          module: '../services/pipeline-api',        domain: 'core',        desc: 'HCFullPipeline HTTP interface' },
  { path: '/api/agents',            module: '../services/agents-api',          domain: 'core',        desc: 'Agent management' },
  { path: '/api/sessions',          module: '../services/sessions-api',        domain: 'core',        desc: 'Session state management' },
  { path: '/api/config',            module: '../services/config-api',          domain: 'core',        desc: 'Runtime config hot-reload' },

  // ── Heady Bees Agent Factory ───────────────────────────────────────────────
  { path: '/api/bees',              module: '../services/bees-api',            domain: 'factory',     desc: 'HeadyBees agent factory' },
  { path: '/api/bees/swarm',        module: '../services/bees-swarm',          domain: 'factory',     desc: 'Multi-bee swarm coordination' },
  { path: '/api/liquid',            module: '../services/liquid-api',          domain: 'factory',     desc: 'Liquid dynamic orchestration' },
  { path: '/api/spatial',           module: '../services/spatial-api',         domain: 'factory',     desc: '3D spatial agent positioning' },
  { path: '/api/federation',        module: '../services/federation-api',      domain: 'factory',     desc: 'Multi-cluster agent federation' },

  // ── Creative Services ──────────────────────────────────────────────────────
  { path: '/api/creative',          module: '../services/creative-api',        domain: 'creative',    desc: 'Creative generation hub' },
  { path: '/api/creative/art',      module: '../services/creative-art',        domain: 'creative',    desc: 'Visual art generation' },
  { path: '/api/creative/music',    module: '../services/creative-music',      domain: 'creative',    desc: 'Music composition' },
  { path: '/api/creative/story',    module: '../services/creative-story',      domain: 'creative',    desc: 'Narrative generation' },
  { path: '/api/creative/code',     module: '../services/creative-code',       domain: 'creative',    desc: 'Code generation' },

  // ── Intelligence & Analysis ────────────────────────────────────────────────
  { path: '/api/trading',           module: '../services/trading-api',         domain: 'intelligence', desc: 'Trading analysis engine' },
  { path: '/api/trading/mc',        module: '../services/trading-mc',          domain: 'intelligence', desc: 'Monte Carlo trading simulation' },
  { path: '/api/research',          module: '../services/research-api',        domain: 'intelligence', desc: 'Deep research orchestration' },
  { path: '/api/analysis',          module: '../services/analysis-api',        domain: 'intelligence', desc: 'Data analysis pipeline' },
  { path: '/api/forecast',          module: '../services/forecast-api',        domain: 'intelligence', desc: 'Predictive forecasting' },

  // ── Governance ────────────────────────────────────────────────────────────
  { path: '/api/governance',        module: '../services/governance-api',      domain: 'governance',  desc: 'Policy & compliance engine' },
  { path: '/api/governance/roles',  module: '../services/governance-roles',    domain: 'governance',  desc: 'Role-based access control' },
  { path: '/api/governance/audit',  module: '../services/governance-audit',    domain: 'governance',  desc: 'Immutable audit trail' },
  { path: '/api/governance/ethics', module: '../services/governance-ethics',   domain: 'governance',  desc: 'AI ethics guardrails' },

  // ── Deployment & DevOps ───────────────────────────────────────────────────
  { path: '/api/deploy',            module: '../services/deploy-api',          domain: 'deployment',  desc: 'Deployment orchestration' },
  { path: '/api/deploy/rollback',   module: '../services/deploy-rollback',     domain: 'deployment',  desc: 'Rollback management' },
  { path: '/api/deploy/cloudrun',   module: '../services/deploy-cloudrun',     domain: 'deployment',  desc: 'Cloud Run integration' },
  { path: '/api/deploy/sync',       module: '../services/deploy-sync',         domain: 'deployment',  desc: 'Config sync' },

  // ── Health & Monitoring ───────────────────────────────────────────────────
  { path: '/api/health/deep',       module: '../services/health-deep',         domain: 'monitoring',  desc: 'Deep health diagnostics' },
  { path: '/api/metrics',           module: '../services/metrics-api',         domain: 'monitoring',  desc: 'Prometheus-compatible metrics' },
  { path: '/api/alerts',            module: '../services/alerts-api',          domain: 'monitoring',  desc: 'Alert management' },
  { path: '/api/logs',              module: '../services/logs-api',            domain: 'monitoring',  desc: 'Log streaming API' },
  { path: '/api/traces',            module: '../services/traces-api',          domain: 'monitoring',  desc: 'Distributed tracing' },

  // ── Communication ─────────────────────────────────────────────────────────
  { path: '/api/webhooks',          module: '../services/webhooks-api',        domain: 'comms',       desc: 'Inbound webhook handler' },
  { path: '/api/email',             module: '../services/email-api',           domain: 'comms',       desc: 'Transactional email' },
  { path: '/api/notifications',     module: '../services/notifications-api',   domain: 'comms',       desc: 'Push notification hub' },

  // ── Sacred Geometry & Identity ────────────────────────────────────────────
  { path: '/api/geometry',          module: '../services/geometry-api',        domain: 'identity',    desc: 'Sacred geometry computations' },
  { path: '/api/identity',          module: '../services/identity-api',        domain: 'identity',    desc: 'Agent identity & DID' },
  { path: '/api/manifest',          module: '../services/manifest-api',        domain: 'identity',    desc: 'System manifest & capabilities' },
];

// ─── Fallback Stub Router ─────────────────────────────────────────────────────

/**
 * Create a stub router for services that haven't been implemented yet.
 * Returns a 501 Not Implemented with service metadata.
 *
 * @param {ServiceEntry} entry
 * @returns {import('express').Router}
 */
function stubRouter(entry) {
  const router = express.Router();
  router.all('*', (_req, res) => {
    res.status(501).json({
      error:   'service_not_implemented',
      service: entry.path,
      domain:  entry.domain,
      desc:    entry.desc,
      message: `Service '${entry.path}' (${entry.desc}) is registered but not yet implemented.`,
      phi:     PHI,
    });
  });
  return router;
}

// ─── Main Export ──────────────────────────────────────────────────────────────

/**
 * Mount all registered services onto the Express app.
 * Uses try/require — missing modules are replaced with stub routers.
 *
 * @param {import('express').Application} app
 * @param {object} [opts={}]
 * @param {boolean} [opts.stubMissing=true]  - Mount stub for missing services
 * @param {string[]} [opts.skip=[]]          - Service paths to skip entirely
 * @returns {{ mounted: string[], stubbed: string[], skipped: string[] }}
 */
function mountServiceRegistry(app, opts = {}) {
  const log        = logger.child('serviceRegistry');
  const skipSet    = new Set(opts.skip || []);
  const stubMissing = opts.stubMissing !== false;

  const mounted = [];
  const stubbed = [];
  const skipped = [];

  for (const entry of SERVICE_CATALOG) {
    if (skipSet.has(entry.path)) {
      skipped.push(entry.path);
      continue;
    }

    try {
      // eslint-disable-next-line import/no-dynamic-require
      const serviceModule = require(entry.module);
      const router = typeof serviceModule === 'function'
        ? serviceModule(opts)
        : serviceModule;

      if (router && typeof router === 'function') {
        app.use(entry.path, router);
        mounted.push(entry.path);
        log.debug(`Mounted: ${entry.domain}/${entry.path}`, { desc: entry.desc });
      } else {
        throw new Error('module did not export a router or factory function');
      }
    } catch (err) {
      if (stubMissing) {
        app.use(entry.path, stubRouter(entry));
        stubbed.push(entry.path);
        log.debug(`Stubbed (not found): ${entry.path}`, { reason: err.message });
      } else {
        skipped.push(entry.path);
        log.debug(`Skipped (not found): ${entry.path}`);
      }
    }
  }

  // Registry introspection endpoint
  app.get('/api/registry', (_req, res) => {
    res.json({
      total:    SERVICE_CATALOG.length,
      mounted:  mounted.length,
      stubbed:  stubbed.length,
      skipped:  skipped.length,
      services: SERVICE_CATALOG.map(e => ({
        path:   e.path,
        domain: e.domain,
        desc:   e.desc,
        status: mounted.includes(e.path) ? 'mounted'
               : stubbed.includes(e.path) ? 'stub'
               : 'skipped',
      })),
      phi: PHI,
    });
  });

  log.logSystem('Service registry mounted', {
    total:   SERVICE_CATALOG.length,
    mounted: mounted.length,
    stubbed: stubbed.length,
    skipped: skipped.length,
    phi:     PHI,
  });

  return { mounted, stubbed, skipped };
}

module.exports = mountServiceRegistry;
module.exports.SERVICE_CATALOG = SERVICE_CATALOG;
module.exports.stubRouter       = stubRouter;
