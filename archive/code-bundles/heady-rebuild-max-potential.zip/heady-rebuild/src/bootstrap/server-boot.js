/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 10: Server Boot
 * Creates the HTTP server, handles WebSocket upgrades, listens on the
 * Cloud Run PORT, and implements graceful shutdown with LIFO cleanup stack.
 *
 * Sacred Geometry boot banner displayed on startup.
 * PHI-derived timing for shutdown grace period.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/server-boot
 * @version 3.1.0
 */

'use strict';

const http   = require('http');
const logger = require('../utils/logger');

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI              = 1.6180339887;
const SHUTDOWN_GRACE   = Math.round(PHI * PHI * PHI * 1000); // ≈ 4236ms
const HEALTH_CHECK_MS  = Math.round(PHI * 1000);              // ≈ 1618ms
const DEFAULT_PORT     = 8080;                                 // Cloud Run default

// ─── Sacred Geometry Boot Banner ─────────────────────────────────────────────

/**
 * Print the Heady Sacred Geometry ASCII boot banner to stdout.
 * @param {number} port
 * @param {string} env
 */
function printBanner(port, env) {
  const C = {
    gold:    '\x1b[38;5;220m',
    cyan:    '\x1b[38;5;51m',
    magenta: '\x1b[38;5;171m',
    dim:     '\x1b[2m',
    bold:    '\x1b[1m',
    reset:   '\x1b[0m',
  };

  const G = C.gold + C.bold;
  const D = C.dim;
  const R = C.reset;
  const M = C.magenta;
  const CY = C.cyan;

  const banner = `
${G}╔═══════════════════════════════════════════════════════════════╗${R}
${G}║${R}  ${M}${C.bold}⬡  H E A D Y ™  S Y S T E M S${R}  ${G}║${R}
${G}║${R}  ${D}Autonomous Multi-Agent AI Operating System${R}              ${G}║${R}
${G}║${R}  ${D}Sacred Geometry Architecture v3.1.0${R}                     ${G}║${R}
${G}╠═══════════════════════════════════════════════════════════════╣${R}
${G}║${R}  ${CY}φ PHI${R}   = ${G}1.6180339887${R}  ${D}(Golden Ratio)${R}                ${G}║${R}
${G}║${R}  ${CY}⬡ PORT${R}  = ${G}${String(port).padEnd(5)}${R}              ${D}(Cloud Run)${R}                  ${G}║${R}
${G}║${R}  ${CY}⬡ ENV${R}   = ${G}${env.padEnd(11)}${R}         ${D}(Runtime)${R}                    ${G}║${R}
${G}║${R}  ${CY}⬡ PID${R}   = ${G}${String(process.pid).padEnd(6)}${R}             ${D}(Process ID)${R}                 ${G}║${R}
${G}╠═══════════════════════════════════════════════════════════════╣${R}
${G}║${R}  ${D}Bootstrap phases: 10/10  ✓  All systems nominal${R}           ${G}║${R}
${G}║${R}  ${D}Vector Dim: 384   MC Samples: ~688   Self-Awareness: ON${R}   ${G}║${R}
${G}╠═══════════════════════════════════════════════════════════════╣${R}
${G}║${R}  ${D}Domains:${R}                                                   ${G}║${R}
${G}║${R}    ${CY}api.headysystems.com${R}   ${D}· Primary API${R}                   ${G}║${R}
${G}║${R}    ${CY}mcp.headysystems.com${R}   ${D}· MCP Server${R}                    ${G}║${R}
${G}║${R}    ${CY}voice.headysystems.com${R} ${D}· Voice Relay${R}                   ${G}║${R}
${G}║${R}    ${CY}heady.headyconnection.org${R} ${D}· Connection Hub${R}               ${G}║${R}
${G}╚═══════════════════════════════════════════════════════════════╝${R}
`;
  process.stdout.write(banner + '\n');
}

// ─── LIFO Cleanup Stack ───────────────────────────────────────────────────────

/**
 * @class CleanupStack
 * @description Last-In-First-Out shutdown task registry.
 * Modules register cleanup functions; on SIGTERM/SIGINT they run in reverse order.
 */
class CleanupStack {
  constructor() {
    this._stack = [];
    this._log   = logger.child('cleanup');
  }

  /**
   * Register a cleanup function.
   * @param {string}   name  - Human-readable label
   * @param {Function} fn    - Sync or async cleanup function
   */
  push(name, fn) {
    this._stack.push({ name, fn });
    this._log.debug(`Cleanup registered: ${name}`, { depth: this._stack.length });
  }

  /**
   * Execute all cleanup functions in LIFO order.
   * @param {string} [signal='unknown']
   * @returns {Promise<void>}
   */
  async run(signal = 'unknown') {
    this._log.logSystem(`Shutdown sequence initiated (${signal})`, {
      depth: this._stack.length,
      gracePeriodMs: SHUTDOWN_GRACE,
    });

    const tasks = [...this._stack].reverse();
    for (const { name, fn } of tasks) {
      try {
        this._log.info(`Cleanup: ${name}`);
        await Promise.race([
          Promise.resolve(fn()),
          new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), SHUTDOWN_GRACE)),
        ]);
        this._log.info(`Cleanup OK: ${name}`);
      } catch (err) {
        this._log.error(`Cleanup error: ${name}`, err);
      }
    }

    this._log.logSystem('Shutdown complete', { phi: PHI });
  }
}

/** @type {CleanupStack} */
const cleanupStack = new CleanupStack();

// ─── Signal Handlers ──────────────────────────────────────────────────────────

let _shuttingDown = false;

/**
 * Register SIGTERM/SIGINT handlers for graceful shutdown.
 * @param {import('http').Server} server
 */
function registerSignalHandlers(server) {
  const log = logger.child('signals');

  async function shutdown(signal) {
    if (_shuttingDown) {
      log.warn('Duplicate shutdown signal — force exiting');
      process.exit(1);
    }
    _shuttingDown = true;
    log.logSystem(`Received ${signal} — starting graceful shutdown`, { gracePeriodMs: SHUTDOWN_GRACE });

    // Close HTTP server (stop accepting new connections)
    server.close(async () => {
      log.info('HTTP server closed');
      await cleanupStack.run(signal);
      log.logSystem('Process exiting cleanly');
      process.exit(0);
    });

    // Force exit after PHI^4 seconds (≈ 6854ms) — Cloud Run gives 10s
    setTimeout(() => {
      log.warn('Graceful shutdown timed out — force exiting', { phi4: Math.round(PHI ** 4 * 1000) });
      process.exit(1);
    }, Math.round(PHI ** 4 * 1000)).unref();
  }

  process.once('SIGTERM', () => shutdown('SIGTERM'));
  process.once('SIGINT',  () => shutdown('SIGINT'));

  // Catch uncaught exceptions — log but don't exit (let Cloud Run handle restarts)
  process.on('uncaughtException', (err) => {
    log.fatal('Uncaught exception', err);
    // Don't exit here — allow graceful degradation
  });

  process.on('unhandledRejection', (reason) => {
    log.error('Unhandled promise rejection', { reason: String(reason) });
  });

  log.info('Signal handlers registered (SIGTERM, SIGINT)');
}

// ─── Main Export ──────────────────────────────────────────────────────────────

/**
 * Create HTTP server, bind WebSocket voice relay, listen on PORT, and
 * register graceful shutdown handlers.
 *
 * @param {import('express').Application} app
 * @param {object} opts
 * @param {object} [opts.eventBus]
 * @param {object} [opts.selfAwareness]
 * @param {object} [opts.voiceRelayAttach]  - The attach() function from voice-relay
 * @param {object} [opts.remoteConfig]
 * @returns {Promise<{ server: import('http').Server, port: number }>}
 */
async function bootServer(app, opts = {}) {
  const log = logger.child('serverBoot');

  // Cloud Run sets PORT env; default to 8080
  const port = parseInt(process.env.PORT || String(DEFAULT_PORT), 10);
  const env  = process.env.NODE_ENV || 'development';

  // Create HTTP server
  const server = http.createServer(app);

  // Increase connection headroom using PHI
  server.maxConnections = Math.round(PHI * 1000); // ≈ 1618

  // Set keep-alive using PHI-derived timeout
  server.keepAliveTimeout  = Math.round(PHI ** 4 * 1000); // ≈ 6854ms
  server.headersTimeout    = Math.round(PHI ** 4 * 1000 + PHI * 1000); // +1618ms margin

  // ── Attach WebSocket voice relay
  if (opts.voiceRelayAttach) {
    try {
      opts.voiceRelayAttach(server);
      log.info('Voice relay WebSocket attached to HTTP server');
    } catch (err) {
      log.error('Voice relay attach failed', err);
    }
  }

  // ── Register cleanup tasks (LIFO)
  cleanupStack.push('selfAwareness:stop', () => opts.selfAwareness?.stop?.());
  cleanupStack.push('http:drain', () => new Promise(r => server.close(r)));
  cleanupStack.push('eventBus:flush', () => opts.eventBus?.emit('system:shutdown'));

  // ── Register signal handlers
  registerSignalHandlers(server);

  // ── Listen
  await new Promise((resolve, reject) => {
    server.listen(port, '0.0.0.0', (err) => {
      if (err) return reject(err);
      resolve();
    });

    server.once('error', reject);
  });

  // Print boot banner
  printBanner(port, env);

  log.logSystem('Server listening', {
    port,
    env,
    phi:       PHI,
    pid:       process.pid,
    nodeVer:   process.version,
    serviceUrl: process.env.SERVICE_URL || `https://api.headysystems.com`,
  });

  // Emit boot complete event
  if (opts.eventBus) {
    opts.eventBus.emit('system:boot_complete', {
      port, env, phi: PHI, ts: new Date().toISOString(),
    });
  }

  // Health probe loop — log PHI-tick heartbeats
  const healthTimer = setInterval(() => {
    if (process.env.LOG_HEARTBEAT === 'true') {
      log.debug('Heartbeat ♡', { uptime: process.uptime(), phi: PHI });
    }
  }, HEALTH_CHECK_MS);
  if (healthTimer.unref) healthTimer.unref();

  cleanupStack.push('healthTimer:clear', () => clearInterval(healthTimer));

  return { server, port };
}

module.exports = bootServer;
module.exports.cleanupStack  = cleanupStack;
module.exports.printBanner   = printBanner;
module.exports.CleanupStack  = CleanupStack;
