/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 2: Middleware Stack
 * Applies security headers, CORS, rate limiting, JSON parsing, compression,
 * and the Heady branded domain site renderer.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/middleware-stack
 * @version 3.1.0
 */

'use strict';

const helmet      = require('helmet');
const cors        = require('cors');
const compression = require('compression');
const { v4: uuidv4 } = require('uuid');
const logger      = require('../utils/logger');

// ─── Sacred Geometry ──────────────────────────────────────────────────────────
const PHI          = 1.6180339887;
const RATE_WINDOW  = 15 * 60 * 1000;            // 15-minute window
const RATE_MAX     = 100;                        // requests per window per IP
const RATE_CLEANUP = Math.round(PHI * 60_000);  // cleanup interval ≈ 97 seconds

// ─── Allowed Origins ──────────────────────────────────────────────────────────
const HEADY_ORIGINS = [
  /^https:\/\/(.+\.)?headysystems\.com$/,
  /^https:\/\/(.+\.)?headyconnection\.org$/,
  /^https:\/\/(.+\.)?heady\.ai$/,
  /^https:\/\/(.+\.)?heady\.cloud$/,
];

/**
 * Determine whether an origin is allowed to make cross-origin requests.
 * @param {string|undefined} origin
 * @returns {boolean}
 */
function isAllowedOrigin(origin) {
  if (!origin) return true; // Same-origin or server-to-server
  return HEADY_ORIGINS.some(pattern => pattern.test(origin));
}

// ─── In-Memory Rate Limiter ───────────────────────────────────────────────────

/**
 * Simple in-memory rate limiter (token bucket per IP).
 * For production, replace with Redis-backed counter.
 *
 * @param {object} [opts]
 * @param {number} [opts.windowMs]  - Window duration in ms
 * @param {number} [opts.max]       - Max requests per window
 * @returns {import('express').RequestHandler}
 */
function createRateLimiter(opts = {}) {
  const windowMs = opts.windowMs || RATE_WINDOW;
  const max      = opts.max      || RATE_MAX;

  /** @type {Map<string, { count: number, resetAt: number }>} */
  const store = new Map();
  const log   = logger.child('rateLimiter');

  // Periodic cleanup of expired entries
  const cleanupTimer = setInterval(() => {
    const now = Date.now();
    for (const [ip, entry] of store.entries()) {
      if (now > entry.resetAt) store.delete(ip);
    }
  }, RATE_CLEANUP);
  if (cleanupTimer.unref) cleanupTimer.unref();

  return function rateLimiter(req, res, next) {
    // Respect CF-Connecting-IP header (Cloudflare proxied requests)
    const ip      = req.headers['cf-connecting-ip']
                 || req.headers['x-forwarded-for']?.split(',')[0]?.trim()
                 || req.ip
                 || 'unknown';
    const now     = Date.now();
    const entry   = store.get(ip) || { count: 0, resetAt: now + windowMs };

    if (now > entry.resetAt) {
      entry.count   = 0;
      entry.resetAt = now + windowMs;
    }

    entry.count++;
    store.set(ip, entry);

    res.setHeader('X-RateLimit-Limit',     max);
    res.setHeader('X-RateLimit-Remaining', Math.max(0, max - entry.count));
    res.setHeader('X-RateLimit-Reset',     Math.ceil(entry.resetAt / 1000));

    if (entry.count > max) {
      log.warn('Rate limit exceeded', { ip, count: entry.count, max });
      return res.status(429).json({
        error:   'rate_limit_exceeded',
        message: 'Too many requests. Please slow down.',
        retryAfter: Math.ceil((entry.resetAt - now) / 1000),
      });
    }

    next();
  };
}

// ─── Request Correlation IDs ──────────────────────────────────────────────────

/**
 * Middleware to attach a unique request ID to every inbound request.
 * Uses Cloudflare's cf-ray header when available.
 * @type {import('express').RequestHandler}
 */
function requestId(req, res, next) {
  const id = req.headers['cf-ray'] || req.headers['x-request-id'] || uuidv4();
  req.id = id;
  res.setHeader('X-Request-Id', id);
  next();
}

// ─── Site Renderer (Branded Domain Handler) ───────────────────────────────────

/**
 * Custom site renderer for Heady branded domains.
 * Inspects the Host header and injects domain-specific context into req.heady.
 * @type {import('express').RequestHandler}
 */
function siteRenderer(req, res, next) {
  const host = (req.headers.host || '').toLowerCase().split(':')[0];

  /** @type {object} */
  req.heady = {
    host,
    requestId: req.id,
    phi:       PHI,
    site:      'default',
    timestamp: new Date().toISOString(),
  };

  if (host.includes('mcp.headysystems')) {
    req.heady.site = 'mcp';
  } else if (host.includes('voice.headysystems')) {
    req.heady.site = 'voice';
  } else if (host.includes('admin.headysystems')) {
    req.heady.site = 'admin';
  } else if (host.includes('headyconnection')) {
    req.heady.site = 'connection';
  } else if (host.includes('headysystems') || host.includes('heady.ai')) {
    req.heady.site = 'api';
  }

  // Heady branded response headers
  res.setHeader('X-Powered-By',    'Heady™ Systems 3.1');
  res.setHeader('X-Heady-Site',    req.heady.site);
  res.setHeader('X-Heady-Version', '3.1.0');
  res.setHeader('X-Heady-Phi',     String(PHI));

  next();
}

// ─── Request Logger ───────────────────────────────────────────────────────────

/**
 * Minimal access logger. Logs method, path, status, and response time.
 * @type {import('express').RequestHandler}
 */
function accessLogger(req, res, next) {
  const start = Date.now();
  const log   = logger.child('access');

  res.on('finish', () => {
    const ms = Date.now() - start;
    log.info(`${req.method} ${req.path}`, {
      method:    req.method,
      path:      req.path,
      status:    res.statusCode,
      ms,
      phi_ratio: (ms / Math.round(PHI * 1000)).toFixed(4),
      requestId: req.id,
      site:      req.heady?.site || 'unknown',
      ip:        req.headers['cf-connecting-ip'] || req.ip,
    });
  });

  next();
}

// ─── Main Export ──────────────────────────────────────────────────────────────

/**
 * Apply the full Heady middleware stack to an Express app.
 *
 * @param {import('express').Application} app
 * @param {object} [opts]
 * @param {number} [opts.rateLimitWindowMs]
 * @param {number} [opts.rateLimitMax]
 * @param {boolean} [opts.trustProxy=true]
 * @returns {void}
 */
function applyMiddlewareStack(app, opts = {}) {
  const log = logger.child('middlewareStack');

  // Trust Cloudflare/GCP load-balancer proxy headers
  if (opts.trustProxy !== false) {
    app.set('trust proxy', true);
  }

  // 1. Request correlation IDs (must be first)
  app.use(requestId);

  // 2. Security headers (Helmet)
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc:  ["'self'"],
        scriptSrc:   ["'self'", 'https://headysystems.com'],
        styleSrc:    ["'self'", "'unsafe-inline'"],
        imgSrc:      ["'self'", 'data:', 'https:'],
        connectSrc:  ["'self'", 'https://*.headysystems.com', 'wss://*.headysystems.com'],
        fontSrc:     ["'self'", 'https:'],
        objectSrc:   ["'none'"],
        upgradeInsecureRequests: [],
      },
    },
    crossOriginEmbedderPolicy: false, // Required for WebAssembly in agents
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  }));

  // 3. CORS
  app.use(cors({
    origin: (origin, cb) => {
      if (isAllowedOrigin(origin)) return cb(null, true);
      log.warn('CORS rejected', { origin });
      cb(new Error(`CORS: origin '${origin}' not allowed`));
    },
    credentials:     true,
    allowedHeaders:  ['Content-Type', 'Authorization', 'X-API-Key', 'X-Request-Id',
                      'CF-Access-Jwt-Assertion'],
    exposedHeaders:  ['X-Request-Id', 'X-RateLimit-Limit', 'X-RateLimit-Remaining',
                      'X-Heady-Version'],
    methods:         ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    maxAge:          Math.round(PHI * 600),  // ≈ 970s preflight cache
  }));

  // 4. Body parsing
  app.use(express.json({ limit: '10mb' }));
  app.use(express.urlencoded({ extended: true, limit: '10mb' }));

  // 5. Compression (Brotli preferred, gzip fallback)
  app.use(compression({
    level:     6,
    threshold: Math.round(PHI * 1000), // ≈ 1618 bytes — PHI-threshold
    filter:    (req, res) => {
      if (req.headers['x-no-compression']) return false;
      return compression.filter(req, res);
    },
  }));

  // 6. Rate limiter
  app.use(createRateLimiter({
    windowMs: opts.rateLimitWindowMs || RATE_WINDOW,
    max:      opts.rateLimitMax      || RATE_MAX,
  }));

  // 7. Site renderer (domain-based context injection)
  app.use(siteRenderer);

  // 8. Access logger
  app.use(accessLogger);

  log.logSystem('Middleware stack initialized', {
    cors:        true,
    helmet:      true,
    rateLimit:   true,
    compression: true,
    siteRenderer: true,
  });
}

// Lazy-require express to avoid circular dep during test
let express;
try { express = require('express'); } catch (_) {}

module.exports = applyMiddlewareStack;
module.exports.createRateLimiter = createRateLimiter;
module.exports.siteRenderer      = siteRenderer;
module.exports.requestId         = requestId;
