/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 6: Pipeline Wiring
 * Self-healing pipeline event wiring. Connects stage failures to Monte Carlo
 * re-planning, feeds timing data to the pattern engine, and implements
 * exponential-backoff retry with PHI-derived intervals.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/pipeline-wiring
 * @version 3.1.0
 */

'use strict';

const logger = require('../utils/logger');

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI             = 1.6180339887;
const PHI_I           = 1 / PHI;
const MAX_RETRIES     = Math.round(PHI * PHI * PHI);   // ≈ 4 retries
const RETRY_BASE_MS   = Math.round(PHI * 1000);        // ≈ 1618ms base backoff
const HEAL_TIMEOUT_MS = Math.round(PHI * PHI * PHI * PHI * 1000); // ≈ 6854ms

// ─── Retry with PHI Backoff ───────────────────────────────────────────────────

/**
 * Execute an async function with PHI-based exponential backoff retry.
 * Interval_n = base × PHI^n
 *
 * @param {Function} fn         - Async function to retry
 * @param {object}   [opts={}]
 * @param {number}   [opts.maxRetries=MAX_RETRIES]
 * @param {number}   [opts.baseMs=RETRY_BASE_MS]
 * @param {string}   [opts.label='operation']
 * @returns {Promise<*>}
 */
async function retryWithPhiBackoff(fn, opts = {}) {
  const maxRetries = opts.maxRetries !== undefined ? opts.maxRetries : MAX_RETRIES;
  const baseMs     = opts.baseMs    || RETRY_BASE_MS;
  const label      = opts.label     || 'operation';
  const log        = logger.child(`retry:${label}`);

  let lastErr;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const result = await fn(attempt);
      if (attempt > 0) {
        log.info(`Recovered after ${attempt} retry(s)`, { attempt, label });
      }
      return result;
    } catch (err) {
      lastErr = err;
      if (attempt === maxRetries) break;

      // PHI-exponential backoff: 1618ms, 2618ms, 4236ms, 6854ms
      const delayMs = Math.round(baseMs * Math.pow(PHI, attempt));
      log.warn(`Attempt ${attempt + 1} failed — retrying in ${delayMs}ms`, {
        label, attempt: attempt + 1, maxRetries, delayMs, err: err.message,
      });
      await new Promise(r => setTimeout(r, delayMs));
    }
  }

  throw new Error(`${label} failed after ${maxRetries + 1} attempts: ${lastErr?.message}`);
}

// ─── Self-Healing Wire ────────────────────────────────────────────────────────

/**
 * @class SelfHealingWire
 * @description Monitors pipeline events and automatically initiates
 * recovery sequences on stage failures. Integrates with MC scheduler
 * for intelligent re-planning.
 */
class SelfHealingWire {
  /**
   * @param {object} opts
   * @param {object} opts.pipeline     - HCFullPipeline instance
   * @param {object} opts.mcScheduler  - MonteCarloScheduler instance
   * @param {object} opts.patternEngine - PatternEngine instance
   * @param {object} opts.eventBus     - HeadyEventBus instance
   */
  constructor(opts = {}) {
    this._pipeline      = opts.pipeline;
    this._mc            = opts.mcScheduler;
    this._pattern       = opts.patternEngine;
    this._bus           = opts.eventBus;
    this._log           = logger.child('selfHeal');
    this._healAttempts  = new Map(); // taskId → attempt count
    this._timingLog     = [];        // Recent { stage, ms, ts } entries
    this._maxTimingLog  = Math.round(PHI * 100); // ≈ 162 entries
  }

  /**
   * Bind self-healing listeners to the pipeline.
   */
  wire() {
    const pipe = this._pipeline;
    const log  = this._log;
    if (!pipe) {
      log.warn('No pipeline provided — self-healing inactive');
      return;
    }

    // ── Stage complete: feed timing to pattern engine
    pipe.on('stage:complete', ({ id, stage, ms }) => {
      this._recordTiming(stage, ms);
      if (this._pattern) {
        const { patterns, phi_deviation } = this._pattern.ingest(stage, ms);
        if (patterns.length > 0) {
          log.debug(`Pattern detected in stage '${stage}'`, { patterns, phi_deviation });
        }
      }
    });

    // ── Stage error: trigger self-heal
    pipe.on('stage:error', async ({ id, stage, err }) => {
      log.warn(`Stage error: ${stage} on task ${id}`, { err: err?.message });
      await this._initiateHeal(id, stage, err);
    });

    // ── Pipeline complete: reset heal counter on success
    pipe.on('pipeline:complete', ({ id, ok }) => {
      if (ok) {
        this._healAttempts.delete(id);
        log.debug(`Heal counter cleared for task ${id}`);
      }
    });

    // ── Watchdog alert: escalate heal
    if (this._bus) {
      this._bus.on('watchdog:alert', (alerts) => {
        log.warn('Watchdog alert received — checking pipeline health', { alerts });
        this._checkSystemHealth();
      });
    }

    log.logSystem('Self-healing wire connected', {
      maxRetries:    MAX_RETRIES,
      retryBaseMs:   RETRY_BASE_MS,
      healTimeoutMs: HEAL_TIMEOUT_MS,
      phi:           PHI,
    });
  }

  /**
   * Initiate self-healing for a failed task stage.
   * Escalation path: retry → MC replan → circuit-break
   *
   * @param {string} taskId
   * @param {string} stage
   * @param {Error}  [err]
   */
  async _initiateHeal(taskId, stage, err) {
    const attempts = (this._healAttempts.get(taskId) || 0) + 1;
    this._healAttempts.set(taskId, attempts);
    const log = this._log;

    log.info(`Heal attempt ${attempts}/${MAX_RETRIES} for task ${taskId}, stage ${stage}`);

    if (this._bus) {
      this._bus.emit('selfHeal:start', { taskId, stage, attempt: attempts });
    }

    if (attempts <= MAX_RETRIES) {
      // Phase 1: PHI-backoff retry
      const delayMs = Math.round(RETRY_BASE_MS * Math.pow(PHI, attempts - 1));
      log.info(`Scheduling retry in ${delayMs}ms`, { taskId, stage, delayMs });

      await new Promise(r => setTimeout(r, delayMs));

      if (this._bus) this._bus.emit('selfHeal:retry', { taskId, stage, attempt: attempts, delayMs });
    } else {
      // Phase 2: MC re-plan
      log.warn(`Max retries exceeded for ${taskId} — escalating to MC re-plan`);
      await this._mcReplan(taskId, stage);
    }
  }

  /**
   * Trigger Monte Carlo re-planning for a failed task.
   * @param {string} taskId
   * @param {string} stage
   */
  async _mcReplan(taskId, stage) {
    const log = this._log;
    if (!this._mc) {
      log.warn('No MC scheduler — circuit breaking', { taskId, stage });
      if (this._bus) this._bus.emit('selfHeal:circuit_break', { taskId, stage });
      return;
    }

    try {
      const healTasks = [
        { id: `${stage}:retry`,    weight: PHI,   deps: [] },
        { id: `${stage}:fallback`, weight: 1,     deps: [] },
        { id: `${stage}:skip`,     weight: PHI_I, deps: [] },
      ];

      const replan = await this._mc.simulate(healTasks, { errorStage: stage, taskId });
      log.info('MC re-plan generated', { taskId, stage, score: replan.score });

      if (this._bus) this._bus.emit('selfHeal:replanned', { taskId, stage, replan });
    } catch (mcErr) {
      log.error('MC re-plan failed — circuit breaking', mcErr);
      if (this._bus) this._bus.emit('selfHeal:circuit_break', { taskId, stage, reason: mcErr.message });
    }
  }

  /**
   * Record a timing data point for trend analysis.
   * @param {string} stage
   * @param {number} ms
   */
  _recordTiming(stage, ms) {
    this._timingLog.push({ stage, ms, ts: Date.now() });
    if (this._timingLog.length > this._maxTimingLog) {
      this._timingLog.shift();
    }
  }

  /**
   * System-level health check triggered by watchdog alerts.
   */
  _checkSystemHealth() {
    const recent = this._timingLog.slice(-Math.round(PHI * 10));
    if (recent.length < 2) return;

    const avgMs = recent.reduce((s, e) => s + e.ms, 0) / recent.length;
    const phi_ratio = avgMs / (PHI * 1000);

    this._log.info('System health check', {
      recentStages: recent.length,
      avgMs: avgMs.toFixed(2),
      phi_ratio: phi_ratio.toFixed(4),
      trend: phi_ratio > PHI ? 'degraded' : phi_ratio < PHI_I ? 'fast' : 'optimal',
    });

    if (phi_ratio > PHI * PHI) {
      this._log.warn('Performance degradation detected — PHI² threshold exceeded', { phi_ratio });
      if (this._bus) this._bus.emit('selfHeal:degradation_alert', { phi_ratio, avgMs });
    }
  }

  /**
   * Return heal attempt counts.
   * @returns {object}
   */
  stats() {
    return {
      healAttempts: Object.fromEntries(this._healAttempts),
      timingLogSize: this._timingLog.length,
      phi: PHI,
    };
  }
}

// ─── Main Export ──────────────────────────────────────────────────────────────

/**
 * Wire pipeline self-healing to the Express app and engine stack.
 *
 * @param {import('express').Application} app
 * @param {object} opts
 * @param {object} opts.pipeline
 * @param {object} opts.mcScheduler
 * @param {object} opts.patternEngine
 * @param {object} opts.eventBus
 * @returns {{ selfHeal: SelfHealingWire }}
 */
function wirePipeline(app, opts = {}) {
  const log      = logger.child('pipelineWiring:boot');
  const selfHeal = new SelfHealingWire(opts);
  selfHeal.wire();

  // Expose on app.locals
  app.locals.selfHeal = selfHeal;

  log.logSystem('Pipeline wiring complete', {
    phi:     PHI,
    retryMs: RETRY_BASE_MS,
    maxRetry: MAX_RETRIES,
  });

  return { selfHeal };
}

module.exports = wirePipeline;
module.exports.SelfHealingWire    = SelfHealingWire;
module.exports.retryWithPhiBackoff = retryWithPhiBackoff;
