/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 1: Config & Globals
 * Initializes Express application, logger, event bus, remote config,
 * secrets manager, and Cloudflare manager stubs.
 *
 * This module runs first — it must not import any Heady modules to avoid
 * circular dependency issues. All downstream phases receive exported references.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/config-globals
 * @version 3.1.0
 */

'use strict';

require('dotenv').config();

const express      = require('express');
const { EventEmitter } = require('events');
const logger       = require('../utils/logger');

// ─── Sacred Geometry ──────────────────────────────────────────────────────────
const PHI = 1.6180339887;

// ─── Express Application ──────────────────────────────────────────────────────

/** @type {import('express').Application} */
const app = express();

// Increase EventEmitter listener ceiling for high-concurrency agent events
app.setMaxListeners(Math.round(PHI * 64)); // ≈ 103 listeners

// ─── Event Bus ────────────────────────────────────────────────────────────────

/**
 * @class HeadyEventBus
 * @description Global in-process pub/sub bus for cross-module events.
 * Wraps Node EventEmitter with structured logging on every emission.
 */
class HeadyEventBus extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(256);
    this._log = logger.child('eventBus');
  }

  /**
   * Emit an event and log it for observability.
   * @param {string} event
   * @param {...*}   args
   * @returns {boolean}
   */
  emit(event, ...args) {
    this._log.debug(`→ ${event}`, { event });
    return super.emit(event, ...args);
  }
}

/** @type {HeadyEventBus} */
const eventBus = new HeadyEventBus();

// ─── Remote Config ────────────────────────────────────────────────────────────

/**
 * Remote configuration snapshot loaded from environment.
 * In production this is hydrated from Cloudflare KV / GCP Secret Manager.
 * The object is intentionally mutable so hot-reload can patch it.
 *
 * @type {object}
 */
const remoteConfig = {
  // Core identifiers
  appName:       process.env.APP_NAME           || 'heady-systems',
  version:       process.env.APP_VERSION        || '3.1.0',
  environment:   process.env.NODE_ENV           || 'development',
  region:        process.env.CLOUD_REGION       || 'us-central1',
  projectId:     process.env.GCP_PROJECT_ID     || 'heady-prod',

  // Domains (no localhost references)
  primaryDomain:    process.env.PRIMARY_DOMAIN    || 'api.headysystems.com',
  mcpDomain:        process.env.MCP_DOMAIN        || 'mcp.headysystems.com',
  voiceDomain:      process.env.VOICE_DOMAIN      || 'voice.headysystems.com',
  adminDomain:      process.env.ADMIN_DOMAIN      || 'admin.headysystems.com',
  connectionDomain: process.env.CONNECTION_DOMAIN || 'heady.headyconnection.org',

  // Feature flags
  featureVectorMemory:  process.env.FEATURE_VECTOR_MEMORY  !== 'false',
  featureMonteCarlo:    process.env.FEATURE_MONTE_CARLO    !== 'false',
  featureVoiceRelay:    process.env.FEATURE_VOICE_RELAY    !== 'false',
  featureSelfAwareness: process.env.FEATURE_SELF_AWARENESS !== 'false',
  featureBeesFactory:   process.env.FEATURE_BEES_FACTORY   !== 'false',

  // Capacity & limits
  maxAgents:      parseInt(process.env.MAX_AGENTS      || '64',  10),
  maxVectors:     parseInt(process.env.MAX_VECTORS     || '100000', 10),
  vectorDim:      parseInt(process.env.VECTOR_DIM      || '384',  10),
  rateLimitRpm:   parseInt(process.env.RATE_LIMIT_RPM  || '100',  10),

  // Sacred geometry timing
  phi:            PHI,
  phiTickMs:      Math.round(PHI * 1000),        // 1618ms
  phiRetryMs:     Math.round(PHI * PHI * 1000),  // 2618ms

  // Hot-reload metadata
  _loadedAt: new Date().toISOString(),
  _hotReload: false,
};

/**
 * Patch remote config at runtime (e.g. from a webhook or KV watch).
 * @param {object} patch - Key/value overrides
 */
remoteConfig.patch = function patch(obj) {
  Object.assign(remoteConfig, obj, { _hotReload: true, _patchedAt: new Date().toISOString() });
  eventBus.emit('config:patched', obj);
  logger.info('RemoteConfig patched', { keys: Object.keys(obj) });
};

// ─── Secrets Manager Stub ─────────────────────────────────────────────────────

/**
 * @class SecretsManager
 * @description Thin abstraction over GCP Secret Manager / env vars.
 * In production, calls are made to the GCP SM REST API via service account.
 * In development, secrets fall back to process.env.
 */
class SecretsManager {
  constructor() {
    this._cache  = new Map();
    this._log    = logger.child('secretsMgr');
    this._prefix = process.env.SECRET_PREFIX || 'heady';
  }

  /**
   * Retrieve a secret by name, with in-process caching.
   * @param {string}  name
   * @param {*}       [fallback=null]
   * @returns {Promise<string|null>}
   */
  async get(name, fallback = null) {
    if (this._cache.has(name)) return this._cache.get(name);

    // Env fallback: HEADY_<NAME> or <NAME>
    const envKey = `${this._prefix.toUpperCase()}_${name.toUpperCase().replace(/-/g, '_')}`;
    const value  = process.env[envKey] || process.env[name] || fallback;

    if (value !== null && value !== undefined) {
      this._cache.set(name, value);
    } else {
      this._log.warn(`Secret not found: ${name}`, { name, envKey });
    }
    return value;
  }

  /**
   * Evict a secret from the in-process cache (forces re-fetch on next get()).
   * @param {string} name
   */
  invalidate(name) {
    this._cache.delete(name);
    this._log.debug(`Cache invalidated: ${name}`);
  }

  /** Clear entire secret cache. */
  flushCache() {
    this._cache.clear();
    this._log.info('Secret cache flushed');
  }
}

/** @type {SecretsManager} */
const secretsManager = new SecretsManager();

// ─── Cloudflare Manager Stub ──────────────────────────────────────────────────

/**
 * @class CloudflareManager
 * @description Stub for Cloudflare Access JWT validation and KV operations.
 * Production implementation calls the CF Access certs endpoint and CF KV API.
 */
class CloudflareManager {
  constructor() {
    this._log     = logger.child('cfManager');
    this._teamDomain = process.env.CF_TEAM_DOMAIN  || 'headysystems.cloudflareaccess.com';
    this._audience   = process.env.CF_AUDIENCE_TAG || '';
    this._kvBinding  = process.env.CF_KV_BINDING   || 'HEADY_KV';
  }

  /**
   * Validate a Cloudflare Access JWT from the Cf-Access-Jwt-Assertion header.
   * @param {string} token - Raw JWT string
   * @returns {Promise<{ valid: boolean, payload: object|null }>}
   */
  async validateAccessToken(token) {
    if (!token) return { valid: false, payload: null };
    try {
      // In production: fetch public key from https://<teamDomain>/cdn-cgi/access/certs
      // and verify RS256 signature. Stub returns valid=false until wired.
      this._log.debug('CF Access token validation (stub)', { tokenLen: token.length });
      return { valid: false, payload: null, stub: true };
    } catch (err) {
      this._log.error('CF Access validation error', err);
      return { valid: false, payload: null };
    }
  }

  /**
   * Read a value from Cloudflare KV (stub).
   * @param {string} key
   * @returns {Promise<string|null>}
   */
  async kvGet(key) {
    this._log.debug(`KV GET ${key} (stub)`);
    return null;
  }

  /**
   * Write a value to Cloudflare KV (stub).
   * @param {string} key
   * @param {string} value
   * @param {object} [opts]
   * @returns {Promise<void>}
   */
  async kvPut(key, value, opts = {}) {
    this._log.debug(`KV PUT ${key} (stub)`, { len: String(value).length, ...opts });
  }

  /** Return team domain. @returns {string} */
  get teamDomain() { return this._teamDomain; }
}

/** @type {CloudflareManager} */
const cfManager = new CloudflareManager();

// ─── Process-level Metadata ───────────────────────────────────────────────────

// Expose version + env on app.locals for downstream middleware
app.locals.heady = {
  version:     remoteConfig.version,
  environment: remoteConfig.environment,
  phi:         PHI,
  startedAt:   new Date().toISOString(),
};

// ─── Module Exports ───────────────────────────────────────────────────────────

module.exports = {
  app,
  logger,
  eventBus,
  remoteConfig,
  secretsManager,
  cfManager,
  PHI,
};
