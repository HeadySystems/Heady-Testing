/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 3: Auth Engine
 * JWT validation, API key fallback, Cloudflare Access integration,
 * secrets route, and role-based access control.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/auth-engine
 * @version 3.1.0
 */

'use strict';

const crypto = require('crypto');
const logger = require('../utils/logger');

// ─── Sacred Geometry ──────────────────────────────────────────────────────────
const PHI           = 1.6180339887;
const TOKEN_TTL_MS  = Math.round(PHI * PHI * PHI * 3_600_000); // ≈ 4.236 hours
const LOCK_WINDOW   = Math.round(PHI * 60_000);                // ≈ 97s lockout window
const MAX_ATTEMPTS  = Math.round(PHI * PHI * 2);               // ≈ 5 attempts

// ─── JWT Utilities (no external library) ─────────────────────────────────────

/**
 * Base64URL encode a Buffer or string.
 * @param {Buffer|string} data
 * @returns {string}
 */
function b64url(data) {
  return Buffer.from(data)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=/g, '');
}

/**
 * Base64URL decode to a string.
 * @param {string} str
 * @returns {string}
 */
function b64urlDecode(str) {
  const padded = str.replace(/-/g, '+').replace(/_/g, '/');
  return Buffer.from(padded, 'base64').toString('utf8');
}

/**
 * Sign a JWT payload using HMAC-SHA256.
 * @param {object} payload   - Claims object
 * @param {string} secret    - HMAC secret
 * @param {object} [header]  - Optional header overrides
 * @returns {string} Signed JWT
 */
function signJWT(payload, secret, header = {}) {
  const h = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT', ...header }));
  const p = b64url(JSON.stringify({
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor((Date.now() + TOKEN_TTL_MS) / 1000),
    iss: 'heady-systems',
    ...payload,
  }));
  const sig = b64url(
    crypto.createHmac('sha256', secret).update(`${h}.${p}`).digest()
  );
  return `${h}.${p}.${sig}`;
}

/**
 * Verify and decode a JWT. Returns null if invalid or expired.
 * @param {string} token
 * @param {string} secret
 * @returns {{ header: object, payload: object }|null}
 */
function verifyJWT(token, secret) {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) return null;

    const [h, p, sig] = parts;
    const expected = b64url(
      crypto.createHmac('sha256', secret).update(`${h}.${p}`).digest()
    );

    // Constant-time comparison
    if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) {
      return null;
    }

    const payload = JSON.parse(b64urlDecode(p));
    const now     = Math.floor(Date.now() / 1000);
    if (payload.exp && payload.exp < now) return null;

    return { header: JSON.parse(b64urlDecode(h)), payload };
  } catch (_) {
    return null;
  }
}

// ─── Brute-Force Protection ───────────────────────────────────────────────────

/** @type {Map<string, { attempts: number, lockedUntil: number }>} */
const loginAttempts = new Map();

/**
 * Check and update the brute-force counter for an identifier (IP or key).
 * @param {string} id
 * @returns {{ blocked: boolean, remaining: number }}
 */
function checkBruteForce(id) {
  const now   = Date.now();
  const entry = loginAttempts.get(id) || { attempts: 0, lockedUntil: 0 };

  if (now < entry.lockedUntil) {
    return { blocked: true, remaining: Math.ceil((entry.lockedUntil - now) / 1000) };
  }

  // Reset if lock window expired
  if (entry.lockedUntil && now >= entry.lockedUntil) {
    entry.attempts   = 0;
    entry.lockedUntil = 0;
  }

  entry.attempts++;
  if (entry.attempts >= MAX_ATTEMPTS) {
    entry.lockedUntil = now + LOCK_WINDOW;
  }

  loginAttempts.set(id, entry);
  return { blocked: false, remaining: MAX_ATTEMPTS - entry.attempts };
}

/**
 * Clear brute-force tracking for an identifier after successful auth.
 * @param {string} id
 */
function clearBruteForce(id) {
  loginAttempts.delete(id);
}

// ─── HeadyAuth Class ──────────────────────────────────────────────────────────

/**
 * @class HeadyAuth
 * @description Multi-strategy authentication engine.
 * Supports: JWT Bearer tokens, API keys (X-API-Key header), Cloudflare Access JWTs.
 */
class HeadyAuth {
  /**
   * @param {object} opts
   * @param {object} opts.secretsManager - SecretsManager instance
   * @param {object} opts.cfManager      - CloudflareManager instance
   * @param {object} opts.eventBus       - HeadyEventBus instance
   */
  constructor(opts = {}) {
    this._secrets = opts.secretsManager;
    this._cf      = opts.cfManager;
    this._bus     = opts.eventBus;
    this._log     = logger.child('authEngine');
    this._jwtSecret = null;  // Lazy-loaded from secretsManager
  }

  /**
   * Get (or lazily load) the JWT signing secret.
   * @returns {Promise<string>}
   */
  async _getJwtSecret() {
    if (this._jwtSecret) return this._jwtSecret;
    this._jwtSecret = await this._secrets?.get('JWT_SECRET')
      || process.env.JWT_SECRET
      || 'heady-dev-secret-change-in-production';
    return this._jwtSecret;
  }

  /**
   * Extract a bearer token from the Authorization header.
   * @param {import('express').Request} req
   * @returns {string|null}
   */
  extractBearer(req) {
    const auth = req.headers.authorization || '';
    if (auth.toLowerCase().startsWith('bearer ')) {
      return auth.slice(7).trim();
    }
    return null;
  }

  /**
   * Extract an API key from the X-API-Key header or query param.
   * @param {import('express').Request} req
   * @returns {string|null}
   */
  extractApiKey(req) {
    return req.headers['x-api-key']
      || req.headers['x-heady-key']
      || req.query.api_key
      || null;
  }

  /**
   * Validate an API key against stored keys.
   * @param {string} key
   * @returns {Promise<{ valid: boolean, role: string, keyId: string }|null>}
   */
  async validateApiKey(key) {
    if (!key || key.length < 16) return null;

    // Hash-compare to avoid storing plaintext keys in memory
    const hash  = crypto.createHash('sha256').update(key).digest('hex');
    const stored = await this._secrets?.get('API_KEYS_JSON');

    if (stored) {
      try {
        const keys = JSON.parse(stored);
        const entry = keys.find(k => k.hash === hash || k.key === key);
        if (entry) {
          return { valid: true, role: entry.role || 'agent', keyId: entry.id || hash.slice(0, 8) };
        }
      } catch (_) {}
    }

    // Env fallback: single master API key
    const masterKey = process.env.HEADY_API_KEY || process.env.API_KEY;
    if (masterKey && crypto.timingSafeEqual(Buffer.from(key), Buffer.from(masterKey))) {
      return { valid: true, role: 'admin', keyId: 'master' };
    }

    return null;
  }

  /**
   * Express middleware: authenticate and populate req.user.
   * Tries JWT → API Key → CF Access → anonymous (if public route).
   *
   * @param {object} [opts]
   * @param {boolean} [opts.required=true] - Reject unauthenticated requests
   * @returns {import('express').RequestHandler}
   */
  middleware(opts = { required: true }) {
    return async (req, res, next) => {
      const ip  = req.headers['cf-connecting-ip'] || req.ip;
      const log = this._log;

      // 1. Try JWT Bearer token
      const token = this.extractBearer(req);
      if (token) {
        const secret  = await this._getJwtSecret();
        const decoded = verifyJWT(token, secret);
        if (decoded) {
          req.user = { ...decoded.payload, authMethod: 'jwt' };
          clearBruteForce(ip);
          return next();
        }
        log.warn('Invalid JWT presented', { ip, tokenLen: token.length });
      }

      // 2. Try API Key
      const apiKey = this.extractApiKey(req);
      if (apiKey) {
        const { blocked } = checkBruteForce(ip);
        if (blocked) {
          return res.status(429).json({ error: 'too_many_attempts', message: 'Account temporarily locked' });
        }
        const keyInfo = await this.validateApiKey(apiKey);
        if (keyInfo?.valid) {
          req.user = { role: keyInfo.role, keyId: keyInfo.keyId, authMethod: 'apiKey' };
          clearBruteForce(ip);
          return next();
        }
        log.warn('Invalid API key', { ip, keyLen: apiKey.length });
      }

      // 3. Try Cloudflare Access JWT
      const cfToken = req.headers['cf-access-jwt-assertion'];
      if (cfToken) {
        const result = await this._cf?.validateAccessToken(cfToken);
        if (result?.valid) {
          req.user = { ...result.payload, authMethod: 'cfAccess' };
          return next();
        }
      }

      // 4. Unauthenticated
      if (opts.required !== false) {
        log.warn('Unauthenticated request rejected', { ip, path: req.path });
        return res.status(401).json({ error: 'unauthorized', message: 'Authentication required' });
      }

      req.user = { role: 'anonymous', authMethod: 'none' };
      next();
    };
  }

  /**
   * Issue a new JWT for a given principal.
   * @param {object} claims - e.g. { sub: 'agent-007', role: 'agent' }
   * @returns {Promise<string>}
   */
  async issueToken(claims) {
    const secret = await this._getJwtSecret();
    const token  = signJWT(claims, secret);
    this._log.info('Token issued', { sub: claims.sub, role: claims.role });
    if (this._bus) this._bus.emit('auth:token_issued', { sub: claims.sub, role: claims.role });
    return token;
  }
}

// ─── Main Export ──────────────────────────────────────────────────────────────

/**
 * Wire auth engine into an Express app.
 *
 * @param {import('express').Application} app
 * @param {object} opts
 * @param {object} opts.secretsManager
 * @param {object} opts.cfManager
 * @param {object} opts.eventBus
 * @returns {{ authEngine: HeadyAuth }}
 */
function wireAuthEngine(app, opts = {}) {
  const log        = logger.child('authEngine:boot');
  const authEngine = new HeadyAuth(opts);

  // ── /api/secrets — protected secrets relay route
  app.get('/api/secrets/:name', authEngine.middleware({ required: true }), async (req, res) => {
    const { role } = req.user || {};
    if (role !== 'admin') {
      return res.status(403).json({ error: 'forbidden', message: 'Admin role required' });
    }
    const value = await opts.secretsManager?.get(req.params.name);
    if (value === null || value === undefined) {
      return res.status(404).json({ error: 'not_found', message: `Secret '${req.params.name}' not found` });
    }
    res.json({ name: req.params.name, value });
  });

  // ── /api/auth/token — issue a token (fallback login)
  app.post('/api/auth/token', async (req, res) => {
    const { apiKey, secret } = req.body || {};
    const ip = req.headers['cf-connecting-ip'] || req.ip;

    const { blocked, remaining } = checkBruteForce(ip);
    if (blocked) {
      return res.status(429).json({ error: 'too_many_attempts', message: 'Temporarily locked' });
    }

    // Validate master key or secret
    const masterKey = process.env.HEADY_API_KEY || process.env.API_KEY;
    const masterSec = process.env.HEADY_SECRET   || process.env.ADMIN_SECRET;

    const valid = (masterKey && apiKey === masterKey)
               || (masterSec && secret === masterSec);

    if (!valid) {
      log.warn('Failed login attempt', { ip, remaining });
      return res.status(401).json({ error: 'invalid_credentials', message: 'Invalid credentials' });
    }

    clearBruteForce(ip);
    const token = await authEngine.issueToken({ sub: 'admin', role: 'admin' });
    res.json({ token, ttl_ms: TOKEN_TTL_MS, phi: PHI });
  });

  // ── /api/auth/verify — inspect a token
  app.get('/api/auth/verify', authEngine.middleware({ required: true }), (req, res) => {
    res.json({ valid: true, user: req.user, phi: PHI });
  });

  log.logSystem('Auth engine wired', { routes: ['/api/secrets', '/api/auth/token', '/api/auth/verify'] });
  return { authEngine };
}

module.exports = wireAuthEngine;
module.exports.HeadyAuth  = HeadyAuth;
module.exports.signJWT    = signJWT;
module.exports.verifyJWT  = verifyJWT;
