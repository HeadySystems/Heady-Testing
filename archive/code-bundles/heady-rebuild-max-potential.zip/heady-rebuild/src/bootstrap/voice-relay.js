/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 9: Voice Relay
 * WebSocket-based real-time voice relay with session management,
 * audio chunking, and transcription relay.
 *
 * Protocol:
 *   Client → Server: { type: 'init', sessionId?, lang?, sampleRate? }
 *   Client → Server: Binary audio chunk (PCM/Opus/WebM)
 *   Client → Server: { type: 'end' }
 *
 *   Server → Client: { type: 'session', sessionId, phi }
 *   Server → Client: { type: 'transcript', text, final, confidence, phi_confidence }
 *   Server → Client: { type: 'error', code, message }
 *   Server → Client: { type: 'closed', sessionId, durationMs }
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/voice-relay
 * @version 3.1.0
 */

'use strict';

const { WebSocketServer } = require('ws');
const { v4: uuidv4 }     = require('uuid');
const logger             = require('../utils/logger');

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI              = 1.6180339887;
const PHI_I            = 1 / PHI;
const PING_INTERVAL_MS = Math.round(PHI * PHI * PHI * 1000); // ≈ 4236ms
const SESSION_TTL_MS   = Math.round(PHI ** 8 * 1000);        // ≈ 46.9s max idle
const CHUNK_BUFFER_MAX = Math.round(PHI * 100);               // ≈ 162 chunks max

// ─── Voice Message Helpers ────────────────────────────────────────────────────

/**
 * Serialize a voice protocol message to JSON string.
 * @param {object} msg
 * @returns {string}
 */
function encode(msg) {
  return JSON.stringify({ ...msg, phi: PHI, ts: new Date().toISOString() });
}

/**
 * Parse an inbound WebSocket message (text or binary).
 * @param {Buffer|string} data
 * @returns {{ type: string, binary?: Buffer, payload?: object }}
 */
function decode(data) {
  if (Buffer.isBuffer(data) || data instanceof ArrayBuffer) {
    return { type: 'audio_chunk', binary: Buffer.from(data) };
  }
  try {
    const payload = JSON.parse(String(data));
    return { type: payload.type || 'unknown', payload };
  } catch (_) {
    return { type: 'raw_text', payload: { text: String(data) } };
  }
}

// ─── Voice Session ────────────────────────────────────────────────────────────

/**
 * @class VoiceSession
 * @description Represents a single voice relay session.
 * Manages audio buffering, heartbeat, and session lifecycle.
 */
class VoiceSession {
  /**
   * @param {string}     sessionId
   * @param {WebSocket}  ws         - Client WebSocket connection
   * @param {object}     [opts={}]
   * @param {string}     [opts.lang='en-US']
   * @param {number}     [opts.sampleRate=16000]
   * @param {object}     [opts.eventBus]
   */
  constructor(sessionId, ws, opts = {}) {
    this.id          = sessionId;
    this._ws         = ws;
    this._lang       = opts.lang       || 'en-US';
    this._sampleRate = opts.sampleRate || 16000;
    this._bus        = opts.eventBus;
    this._log        = logger.child(`voice:${sessionId.slice(0, 8)}`);

    this._chunks     = [];        // Buffered audio chunks
    this._startTs    = Date.now();
    this._lastPing   = Date.now();
    this._active     = true;
    this._transcript = '';        // Accumulated transcript
    this._confidence = 0;

    // Start heartbeat
    this._pingTimer = setInterval(() => this._ping(), PING_INTERVAL_MS);
  }

  /**
   * Send a structured message to the client.
   * @param {object} msg
   */
  send(msg) {
    if (this._ws.readyState === 1 /* OPEN */) {
      try {
        this._ws.send(encode(msg));
      } catch (err) {
        this._log.error('Send failed', err);
      }
    }
  }

  /**
   * Process an inbound audio chunk.
   * @param {Buffer} chunk
   */
  processAudioChunk(chunk) {
    if (!this._active) return;

    this._chunks.push({ data: chunk, ts: Date.now() });
    if (this._chunks.length > CHUNK_BUFFER_MAX) {
      this._chunks.shift(); // Drop oldest chunk on overflow
      this._log.warn('Chunk buffer overflow — dropping oldest', { sessionId: this.id });
    }

    // Relay acknowledgment
    this.send({
      type:       'chunk_ack',
      chunkIndex: this._chunks.length,
      bytes:      chunk.length,
      phi_ratio:  (chunk.length / (PHI * 1000)).toFixed(4),
    });

    // Emit audio chunk event for downstream transcription relay
    if (this._bus) {
      this._bus.emit('voice:audio_chunk', {
        sessionId: this.id,
        chunk:     chunk.toString('base64'),
        chunkIdx:  this._chunks.length,
        bytes:     chunk.length,
        lang:      this._lang,
        sampleRate: this._sampleRate,
      });
    }
  }

  /**
   * Relay a transcript result back to the client.
   * Called by downstream transcription services via event bus.
   *
   * @param {string}  text
   * @param {boolean} final
   * @param {number}  [confidence=0.85]
   */
  relayTranscript(text, final = false, confidence = 0.85) {
    if (!this._active) return;

    if (final) this._transcript += (this._transcript ? ' ' : '') + text;
    this._confidence = confidence;

    this.send({
      type:           'transcript',
      text,
      final,
      confidence,
      phi_confidence: parseFloat((confidence * PHI_I).toFixed(4)),
      accumulated:    final ? this._transcript : undefined,
    });

    this._log.debug('Transcript relayed', { final, confidence, textLen: text.length });
  }

  /**
   * Gracefully close the session.
   * @param {string} [reason='normal']
   */
  close(reason = 'normal') {
    if (!this._active) return;
    this._active = false;
    clearInterval(this._pingTimer);

    const durationMs = Date.now() - this._startTs;
    this.send({
      type:        'closed',
      sessionId:   this.id,
      reason,
      durationMs,
      chunks:      this._chunks.length,
      transcript:  this._transcript,
      phi_duration: parseFloat((durationMs / (PHI * 1000)).toFixed(4)),
    });

    this._log.info('Session closed', { reason, durationMs, chunks: this._chunks.length });

    if (this._bus) {
      this._bus.emit('voice:session_closed', {
        sessionId:   this.id,
        reason,
        durationMs,
        transcript:  this._transcript,
        confidence:  this._confidence,
      });
    }
  }

  /** Send WebSocket ping to detect stale connections. */
  _ping() {
    if (!this._active) return;
    const idleMs = Date.now() - this._lastPing;
    if (idleMs > SESSION_TTL_MS) {
      this._log.warn('Session TTL exceeded — closing', { idleMs });
      this.close('timeout');
      return;
    }
    try {
      this._ws.ping();
      this._lastPing = Date.now();
    } catch (_) {}
  }

  /** Record pong receipt to reset idle timer. */
  pong() {
    this._lastPing = Date.now();
  }

  /** @returns {boolean} */
  get active() { return this._active; }

  /** Session metadata snapshot. @returns {object} */
  snapshot() {
    return {
      id:          this.id,
      lang:        this._lang,
      sampleRate:  this._sampleRate,
      startTs:     this._startTs,
      durationMs:  Date.now() - this._startTs,
      chunks:      this._chunks.length,
      active:      this._active,
      transcript:  this._transcript.slice(0, 200),
      confidence:  this._confidence,
    };
  }
}

// ─── Main Export ──────────────────────────────────────────────────────────────

/**
 * Attach WebSocket voice relay to the HTTP server.
 * Called in Phase 9 — after all HTTP routes but before server.listen().
 *
 * @param {import('express').Application} app     - Express app (used for event bus access)
 * @param {object}                         opts
 * @param {import('http').Server}          opts.server   - HTTP server instance
 * @param {object}                         opts.eventBus - HeadyEventBus instance
 * @param {object}                         opts.authEngine - HeadyAuth instance (optional)
 * @returns {{ voiceSessions: Map<string, VoiceSession>, wss: WebSocketServer }}
 */
function wireVoiceRelay(app, opts = {}) {
  const log          = logger.child('voiceRelay');
  const bus          = opts.eventBus;

  /** @type {Map<string, VoiceSession>} */
  const voiceSessions = new Map();

  // Defer WSS creation until server is available
  let wss = null;

  /**
   * Attach WSS to the HTTP server.
   * Called from server-boot after server.listen().
   * @param {import('http').Server} server
   */
  function attach(server) {
    wss = new WebSocketServer({
      server,
      path:               '/voice',
      maxPayload:         Math.round(PHI * 1_000_000), // ≈ 1.618 MB per message
      perMessageDeflate:  false,  // Disable for real-time audio (latency sensitive)
    });

    wss.on('connection', async (ws, req) => {
      const sessionId = req.headers['x-session-id'] || uuidv4();
      const ip        = req.headers['cf-connecting-ip']
                     || req.headers['x-forwarded-for']?.split(',')[0]?.trim()
                     || req.socket?.remoteAddress
                     || 'unknown';

      log.info('Voice connection established', { sessionId: sessionId.slice(0, 8), ip });

      // Create session
      const session = new VoiceSession(sessionId, ws, {
        lang:       req.headers['x-lang']        || 'en-US',
        sampleRate: parseInt(req.headers['x-sample-rate'] || '16000', 10),
        eventBus:   bus,
      });
      voiceSessions.set(sessionId, session);

      // Send session init confirmation
      session.send({ type: 'session', sessionId, phi: PHI });

      if (bus) bus.emit('voice:session_opened', { sessionId, ip });

      // ── Message handler
      ws.on('message', (data) => {
        const msg = decode(data);
        session._lastPing = Date.now();

        switch (msg.type) {
          case 'audio_chunk':
            session.processAudioChunk(msg.binary);
            break;

          case 'init':
            // Re-initialize session parameters
            if (msg.payload?.lang)       session._lang       = msg.payload.lang;
            if (msg.payload?.sampleRate) session._sampleRate = msg.payload.sampleRate;
            session.send({ type: 'initialized', sessionId, lang: session._lang, sampleRate: session._sampleRate });
            break;

          case 'transcript_relay':
            // Downstream service relaying a transcript back through the session
            session.relayTranscript(
              msg.payload?.text        || '',
              msg.payload?.final       !== false,
              msg.payload?.confidence  || 0.85,
            );
            break;

          case 'end':
            session.close('client_ended');
            break;

          case 'ping':
            session.send({ type: 'pong' });
            break;

          default:
            log.debug('Unknown voice message type', { type: msg.type, sessionId: sessionId.slice(0, 8) });
        }
      });

      // ── Pong handler
      ws.on('pong', () => session.pong());

      // ── Close handler
      ws.on('close', (code, reason) => {
        log.info('Voice WS closed', { sessionId: sessionId.slice(0, 8), code, reason: String(reason) });
        if (session.active) session.close(`ws_close:${code}`);
        voiceSessions.delete(sessionId);
      });

      // ── Error handler
      ws.on('error', (err) => {
        log.error('Voice WS error', err);
        if (session.active) session.close('ws_error');
        voiceSessions.delete(sessionId);
      });
    });

    wss.on('error', (err) => {
      log.error('Voice WSS error', err);
    });

    log.logSystem('Voice WebSocket relay attached', {
      path:    '/voice',
      phi:     PHI,
      pingMs:  PING_INTERVAL_MS,
      ttlMs:   SESSION_TTL_MS,
    });
  }

  // Expose attach function and session map
  app.locals.voiceRelay = { voiceSessions, attach };

  // Register event bus listener for transcript injection from transcription services
  if (bus) {
    bus.on('voice:transcript', ({ sessionId, text, final, confidence }) => {
      const session = voiceSessions.get(sessionId);
      if (session?.active) {
        session.relayTranscript(text, final, confidence);
      }
    });
  }

  // Admin route: list active voice sessions
  app.get('/api/voice/sessions', (req, res) => {
    const sessions = [];
    for (const session of voiceSessions.values()) {
      sessions.push(session.snapshot());
    }
    res.json({
      active:   voiceSessions.size,
      phi:      PHI,
      sessions,
    });
  });

  return { voiceSessions, attach };
}

module.exports = wireVoiceRelay;
module.exports.VoiceSession = VoiceSession;
