/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 4: Vector Stack
 * Initializes 3D Vector Memory (384-dim), buddy interface, HCFullPipeline,
 * self-awareness telemetry loop, and system watchdog.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/vector-stack
 * @version 3.1.0
 */

'use strict';

const { EventEmitter } = require('events');
const { v4: uuidv4 }  = require('uuid');
const logger           = require('../utils/logger');
const { cosine_similarity, coherence_score, PHI_I } = require('../core/semantic-logic');

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI             = 1.6180339887;
const VECTOR_DIM      = parseInt(process.env.VECTOR_DIM || '384', 10);
const AWARENESS_TICK  = Math.round(PHI * PHI * 1000); // ≈ 2618ms — Fibonacci-adjacent
const WATCHDOG_TICK   = Math.round(PHI * PHI * PHI * 1000); // ≈ 4236ms
const MAX_VECTORS     = parseInt(process.env.MAX_VECTORS || '100000', 10);

// ─── 3D Vector Memory ─────────────────────────────────────────────────────────

/**
 * @class VectorMemory
 * @description In-process 384-dimensional vector store with cosine-based recall.
 * Supports namespaced partitions, temporal decay, and PHI-gated retrieval.
 */
class VectorMemory extends EventEmitter {
  constructor() {
    super();
    /** @type {Map<string, { id: string, vector: number[], meta: object, ts: number, namespace: string }>} */
    this._store     = new Map();
    this._log       = logger.child('vectorMemory');
    this._stats     = { inserts: 0, queries: 0, evictions: 0 };
    this.dim        = VECTOR_DIM;
    this.maxVectors = MAX_VECTORS;
  }

  /**
   * Insert a vector into memory.
   * @param {number[]} vector    - Must be VECTOR_DIM dimensions
   * @param {object}   [meta={}] - Arbitrary metadata
   * @param {string}   [namespace='default']
   * @returns {string} Assigned vector ID
   */
  insert(vector, meta = {}, namespace = 'default') {
    if (vector.length !== this.dim) {
      throw new RangeError(`VectorMemory: expected dim=${this.dim}, got ${vector.length}`);
    }

    // Evict oldest entry if at capacity
    if (this._store.size >= this.maxVectors) {
      this._evictOldest();
    }

    const id  = uuidv4();
    const rec = { id, vector, meta, ts: Date.now(), namespace };
    this._store.set(id, rec);
    this._stats.inserts++;
    this.emit('insert', { id, namespace, meta });
    return id;
  }

  /**
   * Top-K cosine similarity search.
   * @param {number[]} queryVector
   * @param {object}   [opts]
   * @param {number}   [opts.k=10]              - Number of results
   * @param {number}   [opts.threshold=PHI_I]   - Minimum similarity
   * @param {string}   [opts.namespace]         - Restrict to namespace
   * @returns {Array<{ id: string, similarity: number, meta: object, ts: number }>}
   */
  query(queryVector, opts = {}) {
    const k         = opts.k         || 10;
    const threshold = opts.threshold !== undefined ? opts.threshold : PHI_I;
    const ns        = opts.namespace;
    this._stats.queries++;

    /** @type {Array<{ id: string, similarity: number, meta: object, ts: number }>} */
    const results = [];

    for (const rec of this._store.values()) {
      if (ns && rec.namespace !== ns) continue;
      try {
        const sim = cosine_similarity(queryVector, rec.vector);
        if (sim >= threshold) {
          results.push({ id: rec.id, similarity: sim, meta: rec.meta, ts: rec.ts });
        }
      } catch (_) {}
    }

    results.sort((a, b) => b.similarity - a.similarity);
    return results.slice(0, k);
  }

  /**
   * Delete a vector by ID.
   * @param {string} id
   * @returns {boolean}
   */
  delete(id) {
    const deleted = this._store.delete(id);
    if (deleted) this.emit('delete', { id });
    return deleted;
  }

  /**
   * Return aggregate statistics.
   * @returns {object}
   */
  stats() {
    const ns = {};
    for (const rec of this._store.values()) {
      ns[rec.namespace] = (ns[rec.namespace] || 0) + 1;
    }
    return {
      ...this._stats,
      size:       this._store.size,
      maxVectors: this.maxVectors,
      dim:        this.dim,
      namespaces: ns,
      phi:        PHI,
    };
  }

  /** Evict oldest (lowest ts) entry. */
  _evictOldest() {
    let oldest = null;
    let oldestTs = Infinity;
    for (const [id, rec] of this._store.entries()) {
      if (rec.ts < oldestTs) { oldestTs = rec.ts; oldest = id; }
    }
    if (oldest) {
      this._store.delete(oldest);
      this._stats.evictions++;
      this.emit('evict', { id: oldest });
    }
  }
}

// ─── Buddy Interface ──────────────────────────────────────────────────────────

/**
 * @class BuddyInterface
 * @description High-level semantic search interface over VectorMemory.
 * Named "Buddy" — the agent's memory companion.
 */
class BuddyInterface {
  /**
   * @param {VectorMemory} memory
   */
  constructor(memory) {
    this._mem = memory;
    this._log = logger.child('buddy');
  }

  /**
   * Store a memory with text + embedding.
   * @param {string}   text
   * @param {number[]} embedding
   * @param {object}   [tags={}]
   * @returns {string} Memory ID
   */
  remember(text, embedding, tags = {}) {
    return this._mem.insert(embedding, { text, tags, source: 'buddy' }, 'buddy');
  }

  /**
   * Recall the most semantically relevant memories.
   * @param {number[]} queryEmbedding
   * @param {number}   [k=5]
   * @returns {Array}
   */
  recall(queryEmbedding, k = 5) {
    return this._mem.query(queryEmbedding, { k, namespace: 'buddy' });
  }

  /**
   * Forget a memory by ID.
   * @param {string} id
   */
  forget(id) {
    this._mem.delete(id);
    this._log.debug('Memory forgotten', { id });
  }

  /**
   * Coherence score for the buddy memory namespace.
   * @returns {object}
   */
  coherence() {
    const vecs = [];
    for (const rec of this._mem._store.values()) {
      if (rec.namespace === 'buddy') vecs.push(rec.vector);
    }
    return coherence_score(vecs.slice(0, 50)); // Sample for performance
  }
}

// ─── HCFullPipeline Stub ──────────────────────────────────────────────────────

/**
 * @class HCFullPipeline
 * @description Multi-stage task execution pipeline.
 * Stages: parse → plan → expand → execute → validate → consolidate
 * Real implementation loaded from src/core/hc-full-pipeline.js if present.
 */
class HCFullPipeline extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._opts   = opts;
    this._log    = logger.child('pipeline');
    this._active = new Map(); // taskId → stage
    this._stages = ['parse', 'plan', 'expand', 'execute', 'validate', 'consolidate'];
  }

  /**
   * Run a task through the full pipeline.
   * @param {object} task
   * @param {string} task.id
   * @param {string} task.type
   * @param {*}      task.payload
   * @returns {Promise<object>} Result object
   */
  async run(task) {
    const startTs = Date.now();
    const id      = task.id || uuidv4();
    this._log.info(`Pipeline start: ${task.type}`, { id, type: task.type });
    this._active.set(id, 'parse');
    this.emit('pipeline:start', { id, type: task.type });

    const result = { id, type: task.type, stages: {}, ok: false };

    for (const stage of this._stages) {
      this._active.set(id, stage);
      this.emit('stage:start', { id, stage });
      const stageStart = Date.now();

      try {
        // Real implementations replace this stub
        result.stages[stage] = {
          ok: true,
          ms: Date.now() - stageStart,
          phi_ratio: ((Date.now() - stageStart) / Math.round(PHI * 1000)).toFixed(4),
        };
        this.emit('stage:complete', { id, stage, ms: Date.now() - stageStart });
      } catch (err) {
        result.stages[stage] = { ok: false, error: err.message, ms: Date.now() - stageStart };
        this.emit('stage:error', { id, stage, err });
        this._log.error(`Stage error: ${stage}`, err);
        break;
      }
    }

    this._active.delete(id);
    result.ok    = Object.values(result.stages).every(s => s.ok);
    result.ms    = Date.now() - startTs;
    result.phi   = PHI;
    this.emit('pipeline:complete', result);
    this._log.info(`Pipeline ${result.ok ? 'OK' : 'FAIL'}: ${task.type}`, { id, ms: result.ms });
    return result;
  }

  /** @returns {Map} Active pipeline tasks */
  get active() { return this._active; }
}

// ─── Self-Awareness Telemetry Loop ────────────────────────────────────────────

/**
 * @class SelfAwareness
 * @description Periodic introspection loop that reports system health,
 * vector memory stats, and pipeline activity to the event bus.
 */
class SelfAwareness extends EventEmitter {
  /**
   * @param {object} opts
   * @param {VectorMemory}  opts.memory
   * @param {HCFullPipeline} opts.pipeline
   * @param {object}         opts.eventBus
   */
  constructor(opts = {}) {
    super();
    this._mem      = opts.memory;
    this._pipeline = opts.pipeline;
    this._bus      = opts.eventBus;
    this._log      = logger.child('selfAwareness');
    this._timer    = null;
    this._ticks    = 0;
    this._health   = { status: 'initializing', phi: PHI };
  }

  /** Start the awareness loop. */
  start() {
    if (this._timer) return;
    this._timer = setInterval(() => this._tick(), AWARENESS_TICK);
    if (this._timer.unref) this._timer.unref();
    this._log.logSystem('Self-awareness loop started', { tickMs: AWARENESS_TICK, phi: PHI });
    this._tick(); // Immediate first tick
  }

  /** Stop the awareness loop. */
  stop() {
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
      this._log.logSystem('Self-awareness loop stopped');
    }
  }

  /** Single telemetry tick. */
  async _tick() {
    this._ticks++;
    const memStats = this._mem?.stats() || {};
    const active   = this._pipeline?.active?.size || 0;

    this._health = {
      status:    'operational',
      ts:        new Date().toISOString(),
      tick:      this._ticks,
      phi:       PHI,
      phiTick:   this._ticks % Math.round(PHI * 10) === 0 ? 'resonant' : 'normal',
      memory:    memStats,
      pipeline:  { activeTasks: active },
      process:   {
        uptime:   process.uptime(),
        heapUsed: process.memoryUsage().heapUsed,
        rss:      process.memoryUsage().rss,
        pid:      process.pid,
      },
    };

    if (this._bus) this._bus.emit('telemetry:pulse', this._health);
    this.emit('pulse', this._health);
  }

  /** Return last health snapshot. @returns {object} */
  get health() { return this._health; }
}

// ─── Watchdog ─────────────────────────────────────────────────────────────────

/**
 * @class Watchdog
 * @description Monitors pipeline and memory health. Triggers self-heal events.
 */
class Watchdog {
  /**
   * @param {object} opts
   * @param {SelfAwareness}  opts.awareness
   * @param {object}         opts.eventBus
   */
  constructor(opts = {}) {
    this._awareness = opts.awareness;
    this._bus       = opts.eventBus;
    this._log       = logger.child('watchdog');
    this._timer     = null;
  }

  /** Start the watchdog timer. */
  start() {
    if (this._timer) return;
    this._timer = setInterval(() => this._check(), WATCHDOG_TICK);
    if (this._timer.unref) this._timer.unref();
    this._log.logSystem('Watchdog started', { tickMs: WATCHDOG_TICK });
  }

  /** Stop the watchdog. */
  stop() {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
  }

  /** Health check. Emits watchdog:alert if anomalies detected. */
  _check() {
    const h = this._awareness?.health || {};
    const heapMb = (h.process?.heapUsed || 0) / 1_048_576;

    const alerts = [];
    if (heapMb > 512)               alerts.push({ type: 'high_heap', heapMb });
    if (h.pipeline?.activeTasks > 50) alerts.push({ type: 'pipeline_overload', active: h.pipeline.activeTasks });

    if (alerts.length > 0) {
      this._log.warn('Watchdog alerts', { alerts });
      if (this._bus) this._bus.emit('watchdog:alert', { alerts, ts: new Date().toISOString() });
    }
  }
}

// ─── Main Export ──────────────────────────────────────────────────────────────

/**
 * Initialize and wire the full vector stack.
 *
 * @param {import('express').Application} app
 * @param {object} opts
 * @param {object} opts.eventBus
 * @returns {{ vectorMemory: VectorMemory, buddy: BuddyInterface, pipeline: HCFullPipeline, selfAwareness: SelfAwareness, watchdog: Watchdog }}
 */
function wireVectorStack(app, opts = {}) {
  const log = logger.child('vectorStack:boot');

  // 1. Vector Memory
  const vectorMemory = new VectorMemory();

  // 2. Buddy Interface
  const buddy = new BuddyInterface(vectorMemory);

  // 3. HCFullPipeline — try to load real implementation
  let pipeline;
  try {
    const HCReal = require('../core/hc-full-pipeline');
    pipeline = new HCReal({ vectorMemory, buddy, eventBus: opts.eventBus });
    log.info('Loaded HCFullPipeline (real)');
  } catch (_) {
    pipeline = new HCFullPipeline({ vectorMemory, buddy, eventBus: opts.eventBus });
    log.info('Loaded HCFullPipeline (stub)');
  }

  // 4. Self-Awareness
  const selfAwareness = new SelfAwareness({
    memory:   vectorMemory,
    pipeline,
    eventBus: opts.eventBus,
  });

  // 5. Watchdog
  const watchdog = new Watchdog({
    awareness: selfAwareness,
    eventBus:  opts.eventBus,
  });

  // Start background loops (unref'd so they don't hold process open)
  selfAwareness.start();
  watchdog.start();

  // Expose stack on app.locals for downstream modules
  app.locals.vectorStack = { vectorMemory, buddy, pipeline, selfAwareness, watchdog };

  log.logSystem('Vector stack initialized', {
    dim:        VECTOR_DIM,
    maxVectors: MAX_VECTORS,
    phi:        PHI,
  });

  return { vectorMemory, buddy, pipeline, selfAwareness, watchdog };
}

module.exports = wireVectorStack;
module.exports.VectorMemory   = VectorMemory;
module.exports.BuddyInterface = BuddyInterface;
module.exports.HCFullPipeline = HCFullPipeline;
module.exports.SelfAwareness  = SelfAwareness;
module.exports.Watchdog       = Watchdog;
