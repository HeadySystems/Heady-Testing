/**
 * @fileoverview Heady™ Systems — Bootstrap Phase 5: Engine Wiring
 * Wires the Monte Carlo scheduler, pattern engine, auto-success engine,
 * scientist QA engine, and self-critique engine to the pipeline.
 *
 * All engines are initialized with PHI-derived parameters and communicate
 * through the shared event bus.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module bootstrap/engine-wiring
 * @version 3.1.0
 */

'use strict';

const { EventEmitter } = require('events');
const logger           = require('../utils/logger');

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI        = 1.6180339887;
const PHI_I      = 1 / PHI;
const MC_SAMPLES = Math.round(PHI * PHI * PHI * PHI * 100); // ≈ 688 samples
const MC_TICK    = Math.round(PHI * PHI * PHI * 1000);      // ≈ 4236ms

// ─── Monte Carlo Scheduler ────────────────────────────────────────────────────

/**
 * @class MonteCarloScheduler
 * @description Probabilistic task scheduler using Monte Carlo simulation.
 * Evaluates N random execution paths and returns the highest-value plan.
 */
class MonteCarloScheduler extends EventEmitter {
  /**
   * @param {object} opts
   * @param {number} [opts.samples=MC_SAMPLES] - Number of MC simulations per plan
   * @param {object} [opts.eventBus]
   */
  constructor(opts = {}) {
    super();
    this._samples   = opts.samples || MC_SAMPLES;
    this._bus       = opts.eventBus;
    this._log       = logger.child('monteCarlo');
    this._schedules = new Map(); // scheduleId → plan
    this._timer     = null;
  }

  /**
   * Run Monte Carlo simulation over a set of candidate task orderings.
   * Returns the highest expected-value plan.
   *
   * @param {object[]} tasks - Array of task descriptors with .weight and .deps
   * @param {object}   [context={}] - Environment context (resource constraints, etc.)
   * @returns {Promise<{ plan: object[], score: number, iterations: number, phi: number }>}
   */
  async simulate(tasks, context = {}) {
    if (!Array.isArray(tasks) || tasks.length === 0) {
      return { plan: [], score: 0, iterations: 0, phi: PHI };
    }

    this._log.info('MC simulation start', { tasks: tasks.length, samples: this._samples });
    const startTs = Date.now();

    let bestPlan  = null;
    let bestScore = -Infinity;

    for (let i = 0; i < this._samples; i++) {
      const shuffled = this._phiShuffle([...tasks]);
      const score    = this._scorePlan(shuffled, context);
      if (score > bestScore) {
        bestScore = score;
        bestPlan  = shuffled;
      }
    }

    const ms     = Date.now() - startTs;
    const result = {
      plan:       bestPlan || tasks,
      score:      bestScore,
      iterations: this._samples,
      ms,
      phi:        PHI,
      phi_ratio:  (bestScore / PHI).toFixed(4),
    };

    this._log.info('MC simulation complete', { score: bestScore.toFixed(4), ms });
    this.emit('simulation:complete', result);
    if (this._bus) this._bus.emit('mc:simulation', result);
    return result;
  }

  /**
   * Score a task plan using PHI-weighted utility function.
   * Higher weight = higher priority; dependencies reduce score if violated.
   *
   * @param {object[]} plan
   * @param {object}   context
   * @returns {number}
   */
  _scorePlan(plan, context = {}) {
    let score = 0;
    const completed = new Set();

    for (let i = 0; i < plan.length; i++) {
      const task = plan[i];
      const w    = task.weight || 1;
      const deps = task.deps  || [];

      // PHI-weighted position bonus: earlier tasks get PHI-discounted reward
      const positionBonus = w * Math.pow(PHI_I, i);

      // Dependency penalty: -PHI per unsatisfied dependency
      const depPenalty = deps.filter(d => !completed.has(d)).length * PHI;

      score += positionBonus - depPenalty;
      completed.add(task.id || String(i));
    }

    return score;
  }

  /**
   * PHI-based stochastic shuffle (Fisher-Yates with PHI bias).
   * @param {Array} arr
   * @returns {Array}
   */
  _phiShuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  /**
   * Schedule a recurring simulation for a named workflow.
   * @param {string}   name
   * @param {Function} tasksFn - Returns tasks array (sync or async)
   * @returns {string} Schedule ID
   */
  schedule(name, tasksFn) {
    const id = `mc-${name}-${Date.now()}`;
    const run = async () => {
      try {
        const tasks = await tasksFn();
        const result = await this.simulate(tasks);
        this.emit(`scheduled:${name}`, result);
      } catch (err) {
        this._log.error(`MC schedule error: ${name}`, err);
      }
    };
    const timer = setInterval(run, MC_TICK);
    if (timer.unref) timer.unref();
    this._schedules.set(id, { name, timer });
    this._log.info(`MC schedule registered: ${name}`, { id, tickMs: MC_TICK });
    return id;
  }

  /** Stop all scheduled simulations. */
  stopAll() {
    for (const [id, { timer }] of this._schedules.entries()) {
      clearInterval(timer);
      this._schedules.delete(id);
    }
    this._log.info('All MC schedules stopped');
  }
}

// ─── Pattern Engine ───────────────────────────────────────────────────────────

/**
 * @class PatternEngine
 * @description Sacred Geometry pattern recognition engine.
 * Detects PHI spirals, Fibonacci sequences, and harmonic resonance
 * in task timing, agent activity, and vector clusters.
 */
class PatternEngine extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._bus    = opts.eventBus;
    this._log    = logger.child('patternEngine');
    this._history = [];   // Recent timing data points
    this._maxHistory = Math.round(PHI * PHI * 100); // ≈ 262 data points
  }

  /**
   * Ingest a timing data point and detect patterns.
   * @param {string} label - Operation label
   * @param {number} ms    - Duration in ms
   * @returns {{ patterns: string[], phi_deviation: number }}
   */
  ingest(label, ms) {
    this._history.push({ label, ms, ts: Date.now() });
    if (this._history.length > this._maxHistory) {
      this._history.shift();
    }
    return this._detectPatterns(ms);
  }

  /**
   * Detect PHI-harmonic patterns in a duration value.
   * @param {number} ms
   * @returns {{ patterns: string[], phi_deviation: number }}
   */
  _detectPatterns(ms) {
    const patterns       = [];
    const phiMultiples   = [PHI * 100, PHI * 1000, PHI * PHI * 1000, PHI * 10000];
    const fibSequence    = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987];

    // PHI resonance check
    for (const target of phiMultiples) {
      const deviation = Math.abs(ms - target) / target;
      if (deviation < 0.05) {
        patterns.push(`phi_resonance:${target.toFixed(0)}ms`);
      }
    }

    // Fibonacci resonance check
    for (const fib of fibSequence) {
      const fibMs = fib * 100;
      if (Math.abs(ms - fibMs) / Math.max(fibMs, 1) < 0.05) {
        patterns.push(`fibonacci:${fib}`);
      }
    }

    const phi_deviation = ms / (PHI * 1000);

    if (patterns.length > 0 && this._bus) {
      this._bus.emit('pattern:detected', { patterns, ms, phi_deviation });
    }

    return { patterns, phi_deviation };
  }

  /**
   * Compute the current temporal coherence of ingested timing data.
   * @returns {{ coherence: number, trend: string }}
   */
  temporalCoherence() {
    if (this._history.length < 2) return { coherence: 0, trend: 'insufficient_data' };
    const deltas = [];
    for (let i = 1; i < this._history.length; i++) {
      deltas.push(this._history[i].ms / this._history[i - 1].ms);
    }
    const mean = deltas.reduce((a, b) => a + b, 0) / deltas.length;
    const coherence = 1 / (1 + Math.abs(mean - PHI));
    const trend = mean > PHI ? 'accelerating' : mean < PHI_I ? 'decelerating' : 'resonant';
    return { coherence: parseFloat(coherence.toFixed(4)), trend };
  }
}

// ─── Auto-Success Engine ──────────────────────────────────────────────────────

/**
 * @class AutoSuccessEngine
 * @description Evaluates task results and applies PHI-weighted confidence scoring.
 * Automatically marks tasks as successful when confidence exceeds PHI threshold.
 */
class AutoSuccessEngine {
  constructor(opts = {}) {
    this._bus      = opts.eventBus;
    this._log      = logger.child('autoSuccess');
    this._threshold = PHI_I; // ≈ 0.618 — golden confidence gate
  }

  /**
   * Evaluate a task result and decide success/failure.
   * @param {object} result - Task result object with .stages, .ms, .ok
   * @returns {{ success: boolean, confidence: number, reason: string }}
   */
  evaluate(result) {
    if (!result) return { success: false, confidence: 0, reason: 'null_result' };

    const stages   = Object.values(result.stages || {});
    const passed   = stages.filter(s => s.ok).length;
    const total    = stages.length || 1;
    const rawConf  = passed / total;

    // PHI-weighted confidence: bonus for PHI-resonant timing
    const timingBonus = result.ms
      ? Math.max(0, 1 - Math.abs(result.ms / (PHI * 1000) - 1)) * 0.1
      : 0;

    const confidence = Math.min(1, rawConf + timingBonus);
    const success    = confidence >= this._threshold;
    const reason     = success
      ? `confidence ${confidence.toFixed(3)} ≥ PHI_gate ${this._threshold.toFixed(3)}`
      : `confidence ${confidence.toFixed(3)} < PHI_gate ${this._threshold.toFixed(3)}`;

    if (this._bus) this._bus.emit('autoSuccess:evaluated', { success, confidence, reason, taskId: result.id });
    return { success, confidence, reason };
  }
}

// ─── Scientist QA Engine ──────────────────────────────────────────────────────

/**
 * @class ScientistQAEngine
 * @description Scientific hypothesis validation engine.
 * Applies falsification tests, reproducibility checks, and null-hypothesis scoring.
 */
class ScientistQAEngine extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._bus    = opts.eventBus;
    this._log    = logger.child('scientistQA');
    this._tests  = new Map(); // testId → { hypothesis, results[] }
  }

  /**
   * Register a hypothesis for ongoing QA testing.
   * @param {string} id          - Unique hypothesis ID
   * @param {string} hypothesis  - Natural language hypothesis
   * @param {object} [meta={}]
   */
  register(id, hypothesis, meta = {}) {
    this._tests.set(id, { id, hypothesis, meta, results: [], registered: Date.now() });
    this._log.info(`Hypothesis registered: ${id}`, { hypothesis });
  }

  /**
   * Record a test result against a hypothesis.
   * @param {string}  id
   * @param {boolean} passed
   * @param {object}  [evidence={}]
   * @returns {{ verdict: string, pValue: number, phi_confidence: number }}
   */
  recordResult(id, passed, evidence = {}) {
    const test = this._tests.get(id);
    if (!test) throw new Error(`ScientistQA: unknown hypothesis id '${id}'`);

    test.results.push({ passed, evidence, ts: Date.now() });

    const total     = test.results.length;
    const successes = test.results.filter(r => r.passed).length;
    const pValue    = 1 - (successes / total);
    const confidence = successes / total;
    const phi_conf  = confidence * PHI_I;

    const verdict = pValue < 0.05
      ? 'hypothesis_supported'
      : pValue > 0.95
        ? 'hypothesis_rejected'
        : 'inconclusive';

    const qaResult = { verdict, pValue, confidence, phi_confidence: phi_conf, total, successes };
    if (this._bus) this._bus.emit('scientistQA:result', { id, ...qaResult });
    return qaResult;
  }
}

// ─── Self-Critique Engine ─────────────────────────────────────────────────────

/**
 * @class SelfCritiqueEngine
 * @description Introspective critique layer. Analyzes pipeline outputs for
 * logical consistency, completeness, and PHI-alignment.
 */
class SelfCritiqueEngine extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._bus = opts.eventBus;
    this._log = logger.child('selfCritique');
  }

  /**
   * Critique a pipeline output.
   * @param {object} output - Pipeline result
   * @returns {{ score: number, critiques: string[], phi_aligned: boolean }}
   */
  critique(output) {
    const critiques    = [];
    let score          = 1.0;

    if (!output.ok) {
      critiques.push('pipeline_failure: not all stages passed');
      score -= PHI_I * 0.5;
    }

    if (!output.stages || Object.keys(output.stages).length < 3) {
      critiques.push('incomplete_pipeline: fewer than 3 stages recorded');
      score -= 0.2;
    }

    if (output.ms && output.ms > PHI * PHI * PHI * 1000) {
      critiques.push(`latency_concern: ${output.ms}ms exceeds PHI³ threshold (${(PHI**3*1000).toFixed(0)}ms)`);
      score -= 0.1;
    }

    score = Math.max(0, Math.min(1, score));
    const phi_aligned = score >= PHI_I;

    const result = { score: parseFloat(score.toFixed(4)), critiques, phi_aligned, phi: PHI };
    if (this._bus) this._bus.emit('selfCritique:complete', result);
    return result;
  }
}

// ─── Main Export ──────────────────────────────────────────────────────────────

/**
 * Wire all engines to the pipeline and event bus.
 *
 * @param {object} opts
 * @param {object} opts.pipeline    - HCFullPipeline instance
 * @param {object} opts.eventBus    - HeadyEventBus instance
 * @returns {{ mcScheduler: MonteCarloScheduler, patternEngine: PatternEngine, autoSuccess: AutoSuccessEngine, scientistQA: ScientistQAEngine, selfCritique: SelfCritiqueEngine }}
 */
function wireEngines(opts = {}) {
  const log  = logger.child('engineWiring');
  const bus  = opts.eventBus;
  const pipe = opts.pipeline;

  const mcScheduler  = new MonteCarloScheduler({ eventBus: bus });
  const patternEngine = new PatternEngine({ eventBus: bus });
  const autoSuccess  = new AutoSuccessEngine({ eventBus: bus });
  const scientistQA  = new ScientistQAEngine({ eventBus: bus });
  const selfCritique = new SelfCritiqueEngine({ eventBus: bus });

  // Bind engines to pipeline events
  if (pipe) {
    pipe.on('pipeline:complete', (result) => {
      // Auto-evaluate each completed pipeline run
      const eval_  = autoSuccess.evaluate(result);
      const critique = selfCritique.critique(result);
      if (bus) bus.emit('engine:pipeline_evaluated', { eval: eval_, critique, taskId: result.id });
    });

    pipe.on('stage:complete', ({ stage, ms }) => {
      // Feed timing data to pattern engine
      patternEngine.ingest(stage, ms);
    });

    pipe.on('stage:error', async ({ id, stage }) => {
      // Re-plan on stage failure using MC simulation
      log.warn(`Stage error detected: ${stage} — triggering MC re-plan`, { id });
      try {
        const tasks = [
          { id: stage, weight: 2, deps: [] },
          { id: 'fallback', weight: 1, deps: [stage] },
        ];
        const replan = await mcScheduler.simulate(tasks, { errorStage: stage });
        if (bus) bus.emit('mc:replan', { taskId: id, stage, replan });
      } catch (err) {
        log.error('MC re-plan failed', err);
      }
    });
  }

  // Wire bus events between engines
  if (bus) {
    bus.on('telemetry:pulse', (health) => {
      // Feed memory size timing to pattern engine every pulse
      const memSize = health?.memory?.size || 0;
      patternEngine.ingest('memory_size', memSize);
    });
  }

  log.logSystem('Engines wired', {
    engines: ['monteCarlo', 'pattern', 'autoSuccess', 'scientistQA', 'selfCritique'],
    phi:     PHI,
  });

  return { mcScheduler, patternEngine, autoSuccess, scientistQA, selfCritique };
}

module.exports = { wireEngines };
module.exports.MonteCarloScheduler = MonteCarloScheduler;
module.exports.PatternEngine       = PatternEngine;
module.exports.AutoSuccessEngine   = AutoSuccessEngine;
module.exports.ScientistQAEngine   = ScientistQAEngine;
module.exports.SelfCritiqueEngine  = SelfCritiqueEngine;
