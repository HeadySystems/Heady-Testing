/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║  3D Spatial Vector Memory — Heady™ Systems                                 ║
 * ║  Sacred Geometry Architecture · Fibonacci-Sharded Octant Memory            ║
 * ║  © 2026 HeadySystems Inc. All rights reserved.                             ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  Memory is not flat. It lives in 3D space, organized by meaning.           ║
 * ║  8 octants × 5 Fibonacci shards. Zone-first retrieval.                     ║
 * ║  Graph RAG for entity traversal. STM→LTM consolidation.                   ║
 * ║  PHI governs all maintenance rhythms.                                      ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * @module vector-memory
 * @version 4.0.0
 * @author HeadySystems Engineering
 */

'use strict';

const crypto = require('crypto');
const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const os = require('os');

// ─── Sacred Constants ──────────────────────────────────────────────────────────

/** @constant {number} PHI - The golden ratio */
const PHI = 1.6180339887;

/** @constant {number} EMBEDDING_DIM - Full embedding dimensionality */
const EMBEDDING_DIM = 384;

/** @constant {number} PCA_DIM - Projected dimensionality for spatial indexing */
const PCA_DIM = 3;

/** @constant {number} NUM_OCTANTS - 2^3 octant zones based on sign of (x,y,z) */
const NUM_OCTANTS = 8;

/** @constant {number} NUM_SHARDS - Fibonacci shard count for parallel scan */
const NUM_SHARDS = 5;

/** @constant {number} DEDUP_THRESHOLD - Cosine similarity threshold for semantic dedup */
const DEDUP_THRESHOLD = 0.92;

/** @constant {number} RING_MAX - Default max entries per shard */
const RING_MAX = 10000;

/** @constant {number} STM_TTL - Short-term memory TTL in ms (PHI-derived: ~5min) */
const STM_TTL = Math.round(300000 * PHI);

/** @constant {number} MAINTENANCE_BASE_INTERVAL - Base maintenance interval in ms */
const MAINTENANCE_BASE_INTERVAL = Math.round(60000 * PHI);

/** @constant {number} DRIFT_CHECK_INTERVAL - Semantic drift check interval in ms */
const DRIFT_CHECK_INTERVAL = Math.round(MAINTENANCE_BASE_INTERVAL * PHI * PHI);

// ─── Importance Scoring Weights ────────────────────────────────────────────────

/** @constant {number} ALPHA_FREQ - Frequency weight */
const ALPHA_FREQ = 0.25;

/** @constant {number} BETA_RECENCY - Recency weight */
const BETA_RECENCY = 0.35;

/** @constant {number} GAMMA_DECAY - Temporal decay rate */
const GAMMA_DECAY = 0.001;

/** @constant {number} DELTA_SURPRISE - Surprise weight */
const DELTA_SURPRISE = 0.40;

// ─── PCA-lite Projection Matrix ────────────────────────────────────────────────

/**
 * Generate a deterministic pseudo-random projection matrix (384→3).
 * Uses seeded PRNG for reproducibility.
 *
 * @returns {Array<Float64Array>} 3 × 384 projection matrix.
 */
function generateProjectionMatrix() {
  const matrix = [];
  // Deterministic seed for reproducibility
  let seed = 0x48454144; // "HEAD" in hex

  function mulberry32() {
    seed |= 0;
    seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  for (let i = 0; i < PCA_DIM; i++) {
    const row = new Float64Array(EMBEDDING_DIM);
    for (let j = 0; j < EMBEDDING_DIM; j++) {
      // Gaussian-ish via Box-Muller
      const u1 = mulberry32() || 0.0001;
      const u2 = mulberry32();
      row[j] = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    }
    // Normalize the row
    const norm = Math.sqrt(row.reduce((s, v) => s + v * v, 0));
    for (let j = 0; j < EMBEDDING_DIM; j++) {
      row[j] /= norm || 1;
    }
    matrix.push(row);
  }
  return matrix;
}

/** @type {Array<Float64Array>} Cached projection matrix */
const PROJECTION_MATRIX = generateProjectionMatrix();

/**
 * Project a 384-dim vector to 3D using PCA-lite.
 *
 * @param {Float64Array|Array<number>} vec - 384-dimensional embedding.
 * @returns {{ x: number, y: number, z: number }} 3D coordinates.
 */
function projectTo3D(vec) {
  const coords = [0, 0, 0];
  for (let i = 0; i < PCA_DIM; i++) {
    let dot = 0;
    for (let j = 0; j < EMBEDDING_DIM; j++) {
      dot += (PROJECTION_MATRIX[i][j] || 0) * (vec[j] || 0);
    }
    coords[i] = dot;
  }
  return { x: coords[0], y: coords[1], z: coords[2] };
}

// ─── Octant Classification ─────────────────────────────────────────────────────

/**
 * Determine the octant zone (0-7) based on the sign of (x, y, z).
 * Octant = 4*(z>=0) + 2*(y>=0) + 1*(x>=0)
 *
 * @param {{ x: number, y: number, z: number }} pos - 3D position.
 * @returns {number} Octant index 0-7.
 */
function getOctant(pos) {
  return (
    ((pos.z >= 0 ? 1 : 0) << 2) |
    ((pos.y >= 0 ? 1 : 0) << 1) |
    ((pos.x >= 0 ? 1 : 0))
  );
}

/**
 * Get adjacent octant indices (differ by exactly one sign bit).
 *
 * @param {number} octant - Source octant (0-7).
 * @returns {Array<number>} Adjacent octant indices.
 */
function getAdjacentOctants(octant) {
  return [
    octant ^ 1, // flip x sign
    octant ^ 2, // flip y sign
    octant ^ 4, // flip z sign
  ];
}

// ─── Cosine Similarity (CSL Resonance Layer) ──────────────────────────────────

/**
 * Compute cosine similarity between two vectors.
 * Implements the CSL (Cosine Similarity Layer) resonance computation.
 *
 * @param {Float64Array|Array<number>} a - First vector.
 * @param {Float64Array|Array<number>} b - Second vector.
 * @returns {number} Cosine similarity in [-1, 1].
 */
function cosineSimilarity(a, b) {
  const len = Math.min(a.length, b.length);
  let dot = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < len; i++) {
    const va = a[i] || 0;
    const vb = b[i] || 0;
    dot += va * vb;
    normA += va * va;
    normB += vb * vb;
  }

  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom > 0 ? dot / denom : 0;
}

/**
 * Batch cosine similarity: compute similarity between a query and multiple targets.
 *
 * @param {Float64Array|Array<number>} query - Query vector.
 * @param {Array<Float64Array|Array<number>>} targets - Array of target vectors.
 * @returns {Array<number>} Similarities.
 */
function batchCosineSimilarity(query, targets) {
  return targets.map(t => cosineSimilarity(query, t));
}

// ─── Local Hash Embedding Fallback ─────────────────────────────────────────────

/**
 * Generate a deterministic 384-dim pseudo-embedding from text via hashing.
 * Used as final fallback when no embedding service is available.
 *
 * @param {string} text - Input text.
 * @returns {Float64Array} 384-dimensional pseudo-embedding.
 */
function hashEmbedding(text) {
  const embedding = new Float64Array(EMBEDDING_DIM);
  // Generate multiple hash digests to fill 384 dimensions
  const numHashes = Math.ceil(EMBEDDING_DIM / 16); // SHA256 gives 32 bytes = 16 float pairs

  for (let h = 0; h < numHashes; h++) {
    const digest = crypto.createHash('sha256')
      .update(`${text}::shard::${h}`)
      .digest();

    for (let i = 0; i < 16 && (h * 16 + i) < EMBEDDING_DIM; i++) {
      const idx = h * 16 + i;
      // Convert two bytes to a float in [-1, 1]
      const byte1 = digest[i * 2] || 0;
      const byte2 = digest[i * 2 + 1] || 0;
      embedding[idx] = ((byte1 * 256 + byte2) / 65535) * 2 - 1;
    }
  }

  // Normalize to unit sphere
  let norm = 0;
  for (let i = 0; i < EMBEDDING_DIM; i++) norm += embedding[i] * embedding[i];
  norm = Math.sqrt(norm);
  if (norm > 0) {
    for (let i = 0; i < EMBEDDING_DIM; i++) embedding[i] /= norm;
  }

  return embedding;
}

// ─── Embedding Strategy Chain ──────────────────────────────────────────────────

/**
 * Embedding strategy: tries GPU server → HuggingFace API → Ollama → local hash fallback.
 *
 * @class EmbeddingProvider
 */
class EmbeddingProvider {
  constructor() {
    this._strategy = 'auto';
    this._gpuEndpoint = process.env.HC_GPU_EMBED_URL || null;
    this._hfToken = process.env.HF_API_TOKEN || null;
    this._hfModel = process.env.HF_EMBED_MODEL || 'sentence-transformers/all-MiniLM-L6-v2';
    this._ollamaEndpoint = process.env.OLLAMA_URL || null;
    this._ollamaModel = process.env.OLLAMA_EMBED_MODEL || 'nomic-embed-text';
    this._cache = new Map();
    this._stats = { gpu: 0, hf: 0, ollama: 0, hash: 0, cacheHit: 0 };
  }

  /**
   * Generate an embedding for text, trying strategies in order.
   *
   * @param {string} text - Input text.
   * @returns {Promise<Float64Array>} 384-dim embedding vector.
   */
  async embed(text) {
    const cacheKey = crypto.createHash('md5').update(text).digest('hex');
    if (this._cache.has(cacheKey)) {
      this._stats.cacheHit++;
      return this._cache.get(cacheKey);
    }

    let embedding = null;

    // Strategy 1: GPU server
    if (this._gpuEndpoint) {
      try {
        embedding = await this._gpuEmbed(text);
        this._stats.gpu++;
      } catch (_) { /* fallthrough */ }
    }

    // Strategy 2: HuggingFace Inference API
    if (!embedding && this._hfToken) {
      try {
        embedding = await this._hfEmbed(text);
        this._stats.hf++;
      } catch (_) { /* fallthrough */ }
    }

    // Strategy 3: Ollama local
    if (!embedding && this._ollamaEndpoint) {
      try {
        embedding = await this._ollamaEmbed(text);
        this._stats.ollama++;
      } catch (_) { /* fallthrough */ }
    }

    // Strategy 4: Local hash fallback (always available)
    if (!embedding) {
      embedding = hashEmbedding(text);
      this._stats.hash++;
    }

    // Ensure correct dimensionality
    if (embedding.length !== EMBEDDING_DIM) {
      const padded = new Float64Array(EMBEDDING_DIM);
      for (let i = 0; i < Math.min(embedding.length, EMBEDDING_DIM); i++) {
        padded[i] = embedding[i];
      }
      embedding = padded;
    }

    this._cache.set(cacheKey, embedding);
    // Limit cache size
    if (this._cache.size > 5000) {
      const firstKey = this._cache.keys().next().value;
      this._cache.delete(firstKey);
    }

    return embedding;
  }

  /**
   * @private
   * @param {string} text
   * @returns {Promise<Float64Array>}
   */
  async _gpuEmbed(text) {
    const http = require('http');
    const url = new URL(this._gpuEndpoint);
    const payload = JSON.stringify({ text, model: 'all-MiniLM-L6-v2' });

    return new Promise((resolve, reject) => {
      const req = http.request({
        hostname: url.hostname,
        port: url.port,
        path: url.pathname,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
        timeout: 5000,
      }, (res) => {
        let body = '';
        res.on('data', chunk => { body += chunk; });
        res.on('end', () => {
          try {
            const data = JSON.parse(body);
            const vec = new Float64Array(data.embedding || data.data?.[0]?.embedding || []);
            if (vec.length > 0) resolve(vec);
            else reject(new Error('Empty GPU embedding response'));
          } catch (e) { reject(e); }
        });
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('GPU embed timeout')); });
      req.write(payload);
      req.end();
    });
  }

  /**
   * @private
   * @param {string} text
   * @returns {Promise<Float64Array>}
   */
  async _hfEmbed(text) {
    const https = require('https');
    const payload = JSON.stringify({ inputs: text });

    return new Promise((resolve, reject) => {
      const req = https.request({
        hostname: 'api-inference.huggingface.co',
        path: `/pipeline/feature-extraction/${this._hfModel}`,
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this._hfToken}`,
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(payload),
        },
        timeout: 10000,
      }, (res) => {
        let body = '';
        res.on('data', chunk => { body += chunk; });
        res.on('end', () => {
          try {
            const data = JSON.parse(body);
            const flat = Array.isArray(data[0]) ? data[0] : data;
            resolve(new Float64Array(flat));
          } catch (e) { reject(e); }
        });
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('HF embed timeout')); });
      req.write(payload);
      req.end();
    });
  }

  /**
   * @private
   * @param {string} text
   * @returns {Promise<Float64Array>}
   */
  async _ollamaEmbed(text) {
    const http = require('http');
    const url = new URL(this._ollamaEndpoint);
    const payload = JSON.stringify({ model: this._ollamaModel, prompt: text });

    return new Promise((resolve, reject) => {
      const req = http.request({
        hostname: url.hostname,
        port: url.port,
        path: '/api/embeddings',
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
        timeout: 8000,
      }, (res) => {
        let body = '';
        res.on('data', chunk => { body += chunk; });
        res.on('end', () => {
          try {
            const data = JSON.parse(body);
            resolve(new Float64Array(data.embedding || []));
          } catch (e) { reject(e); }
        });
      });
      req.on('error', reject);
      req.on('timeout', () => { req.destroy(); reject(new Error('Ollama embed timeout')); });
      req.write(payload);
      req.end();
    });
  }

  /**
   * Get embedding provider statistics.
   * @returns {Object}
   */
  getStats() {
    return { ...this._stats, cacheSize: this._cache.size };
  }

  /**
   * Set strategy explicitly.
   * @param {'auto'|'gpu'|'hf'|'ollama'|'hash'} strategy
   */
  setStrategy(strategy) {
    this._strategy = strategy;
  }
}

// ─── Fibonacci Shard ───────────────────────────────────────────────────────────

/**
 * A single Fibonacci shard within an octant zone.
 * Stores memory entries with embeddings, metadata, and importance scores.
 *
 * @class FibonacciShard
 */
class FibonacciShard {
  /**
   * @param {number} shardId - Shard index (0-4).
   * @param {number} octant - Parent octant (0-7).
   * @param {number} [maxEntries=10000] - Maximum entries.
   */
  constructor(shardId, octant, maxEntries = RING_MAX) {
    this.shardId = shardId;
    this.octant = octant;
    this.maxEntries = maxEntries;
    this.entries = [];
    this._idIndex = new Map();
  }

  /**
   * Insert a memory entry.
   * @param {Object} entry - Memory entry with id, embedding, text, metadata.
   * @returns {boolean} True if inserted, false if rejected by density gate.
   */
  insert(entry) {
    // Density gating: check for near-duplicates
    for (const existing of this.entries) {
      const sim = cosineSimilarity(entry.embedding, existing.embedding);
      if (sim >= DEDUP_THRESHOLD) {
        // Merge: update existing entry's frequency and timestamp
        existing.accessCount = (existing.accessCount || 0) + 1;
        existing.lastAccess = Date.now();
        existing.metadata = { ...existing.metadata, ...entry.metadata };
        return false; // Deduplicated
      }
    }

    const memEntry = {
      id: entry.id || crypto.randomUUID(),
      embedding: entry.embedding,
      position: entry.position || projectTo3D(entry.embedding),
      text: entry.text,
      metadata: entry.metadata || {},
      createdAt: Date.now(),
      lastAccess: Date.now(),
      accessCount: 1,
      importance: 0,
      surprise: entry.surprise || 0,
      source: entry.source || 'unknown',
      tier: 'stm', // starts in short-term memory
    };

    this.entries.push(memEntry);
    this._idIndex.set(memEntry.id, this.entries.length - 1);

    // Evict if over capacity (remove lowest importance)
    if (this.entries.length > this.maxEntries) {
      this._evictLowest();
    }

    return true;
  }

  /**
   * Search entries by cosine similarity.
   * @param {Float64Array|Array<number>} queryVec - Query embedding.
   * @param {number} [topK=10] - Number of results.
   * @param {number} [minSim=0.0] - Minimum similarity threshold.
   * @returns {Array<Object>} Scored results.
   */
  search(queryVec, topK = 10, minSim = 0.0) {
    const results = [];
    for (const entry of this.entries) {
      const sim = cosineSimilarity(queryVec, entry.embedding);
      if (sim >= minSim) {
        results.push({ ...entry, similarity: sim });
      }
    }
    results.sort((a, b) => b.similarity - a.similarity);
    return results.slice(0, topK);
  }

  /**
   * Get entry by ID.
   * @param {string} id
   * @returns {Object|null}
   */
  getById(id) {
    const idx = this._idIndex.get(id);
    if (idx !== undefined && idx < this.entries.length) {
      const entry = this.entries[idx];
      if (entry && entry.id === id) {
        entry.lastAccess = Date.now();
        entry.accessCount++;
        return entry;
      }
    }
    // Linear fallback if index is stale
    for (const entry of this.entries) {
      if (entry.id === id) {
        entry.lastAccess = Date.now();
        entry.accessCount++;
        return entry;
      }
    }
    return null;
  }

  /**
   * Remove an entry by ID.
   * @param {string} id
   * @returns {boolean}
   */
  remove(id) {
    const idx = this.entries.findIndex(e => e.id === id);
    if (idx >= 0) {
      this.entries.splice(idx, 1);
      this._rebuildIndex();
      return true;
    }
    return false;
  }

  /**
   * Compute importance scores for all entries.
   * I(m) = αFreq + βe^(-γΔt) + δSurprise
   */
  recomputeImportance() {
    const now = Date.now();
    let maxFreq = 1;
    for (const e of this.entries) {
      if (e.accessCount > maxFreq) maxFreq = e.accessCount;
    }

    for (const entry of this.entries) {
      const normFreq = entry.accessCount / maxFreq;
      const deltaT = (now - entry.lastAccess) / 1000; // seconds
      const recency = Math.exp(-GAMMA_DECAY * deltaT);
      const surprise = Math.min(entry.surprise || 0, 1);
      entry.importance = ALPHA_FREQ * normFreq + BETA_RECENCY * recency + DELTA_SURPRISE * surprise;
    }
  }

  /**
   * Consolidate: promote STM entries to LTM based on importance threshold.
   * @param {number} [threshold=0.4] - Minimum importance for LTM promotion.
   * @returns {number} Number of promotions.
   */
  consolidateSTMtoLTM(threshold = 0.4) {
    let promoted = 0;
    const now = Date.now();

    for (const entry of this.entries) {
      if (entry.tier === 'stm' && now - entry.createdAt > STM_TTL) {
        if (entry.importance >= threshold) {
          entry.tier = 'ltm';
          promoted++;
        }
      }
    }

    // Expire low-importance STM entries
    const before = this.entries.length;
    this.entries = this.entries.filter(e => {
      if (e.tier === 'stm' && now - e.createdAt > STM_TTL && e.importance < threshold * 0.5) {
        return false;
      }
      return true;
    });

    if (this.entries.length !== before) this._rebuildIndex();
    return promoted;
  }

  /**
   * Get shard statistics.
   * @returns {Object}
   */
  stats() {
    const stm = this.entries.filter(e => e.tier === 'stm').length;
    const ltm = this.entries.filter(e => e.tier === 'ltm').length;
    return {
      shardId: this.shardId,
      octant: this.octant,
      total: this.entries.length,
      stm,
      ltm,
      maxEntries: this.maxEntries,
      utilization: this.entries.length / this.maxEntries,
    };
  }

  /**
   * Compute centroid of all entries.
   * @returns {Float64Array|null}
   */
  centroid() {
    if (this.entries.length === 0) return null;
    const c = new Float64Array(EMBEDDING_DIM);
    for (const entry of this.entries) {
      for (let i = 0; i < EMBEDDING_DIM; i++) {
        c[i] += (entry.embedding[i] || 0);
      }
    }
    for (let i = 0; i < EMBEDDING_DIM; i++) {
      c[i] /= this.entries.length;
    }
    return c;
  }

  /**
   * @private
   */
  _evictLowest() {
    this.recomputeImportance();
    this.entries.sort((a, b) => b.importance - a.importance);
    this.entries = this.entries.slice(0, this.maxEntries);
    this._rebuildIndex();
  }

  /**
   * @private
   */
  _rebuildIndex() {
    this._idIndex.clear();
    for (let i = 0; i < this.entries.length; i++) {
      this._idIndex.set(this.entries[i].id, i);
    }
  }
}

// ─── Octant Zone ───────────────────────────────────────────────────────────────

/**
 * An octant zone containing 5 Fibonacci shards.
 *
 * @class OctantZone
 */
class OctantZone {
  /**
   * @param {number} octantId - Octant index (0-7).
   * @param {number} [shardsPerOctant=5] - Number of Fibonacci shards.
   */
  constructor(octantId, shardsPerOctant = NUM_SHARDS) {
    this.octantId = octantId;
    this.shards = [];
    this._ingestCounter = 0;

    for (let i = 0; i < shardsPerOctant; i++) {
      this.shards.push(new FibonacciShard(i, octantId));
    }
  }

  /**
   * Ingest a memory entry using round-robin shard assignment.
   * @param {Object} entry - Memory entry.
   * @returns {Object} { inserted: boolean, shardId: number, entryId: string }
   */
  ingest(entry) {
    const shardIdx = this._ingestCounter % this.shards.length;
    this._ingestCounter++;

    const entryId = entry.id || crypto.randomUUID();
    entry.id = entryId;

    const inserted = this.shards[shardIdx].insert(entry);
    return { inserted, shardId: shardIdx, entryId };
  }

  /**
   * Search across all shards in parallel (conceptual; sequential in single-thread JS).
   * @param {Float64Array|Array<number>} queryVec - Query embedding.
   * @param {number} [topK=10]
   * @param {number} [minSim=0.0]
   * @returns {Array<Object>} Merged results.
   */
  search(queryVec, topK = 10, minSim = 0.0) {
    const allResults = [];
    for (const shard of this.shards) {
      const shardResults = shard.search(queryVec, topK, minSim);
      allResults.push(...shardResults);
    }
    allResults.sort((a, b) => b.similarity - a.similarity);
    return allResults.slice(0, topK);
  }

  /**
   * Get an entry by ID across shards.
   * @param {string} id
   * @returns {Object|null}
   */
  getById(id) {
    for (const shard of this.shards) {
      const entry = shard.getById(id);
      if (entry) return entry;
    }
    return null;
  }

  /**
   * Remove an entry by ID across shards.
   * @param {string} id
   * @returns {boolean}
   */
  remove(id) {
    for (const shard of this.shards) {
      if (shard.remove(id)) return true;
    }
    return false;
  }

  /**
   * Recompute importance scores across all shards.
   */
  recomputeImportance() {
    for (const shard of this.shards) {
      shard.recomputeImportance();
    }
  }

  /**
   * Consolidate STM→LTM across all shards.
   * @returns {number} Total promotions.
   */
  consolidate() {
    let total = 0;
    for (const shard of this.shards) {
      total += shard.consolidateSTMtoLTM();
    }
    return total;
  }

  /**
   * Get zone-level centroid.
   * @returns {Float64Array|null}
   */
  centroid() {
    const centroids = this.shards.map(s => s.centroid()).filter(Boolean);
    if (centroids.length === 0) return null;

    const merged = new Float64Array(EMBEDDING_DIM);
    for (const c of centroids) {
      for (let i = 0; i < EMBEDDING_DIM; i++) merged[i] += c[i];
    }
    for (let i = 0; i < EMBEDDING_DIM; i++) merged[i] /= centroids.length;
    return merged;
  }

  /**
   * Get aggregate stats.
   * @returns {Object}
   */
  stats() {
    const shardStats = this.shards.map(s => s.stats());
    const totalEntries = shardStats.reduce((s, st) => s + st.total, 0);
    return {
      octantId: this.octantId,
      totalEntries,
      shards: shardStats,
    };
  }

  /**
   * Total entry count.
   * @returns {number}
   */
  get size() {
    return this.shards.reduce((s, sh) => s + sh.entries.length, 0);
  }
}

// ─── Graph RAG Layer ───────────────────────────────────────────────────────────

/**
 * Graph RAG layer for entity-relationship edges and multi-hop traversal.
 * Supports hybrid queries combining vector similarity with graph structure.
 *
 * @class GraphRAGLayer
 */
class GraphRAGLayer {
  constructor() {
    /** @type {Map<string, Object>} Entity nodes: id → { id, type, label, memoryIds, metadata } */
    this._nodes = new Map();
    /** @type {Map<string, Object>} Edges: edgeId → { source, target, relation, weight, metadata } */
    this._edges = new Map();
    /** @type {Map<string, Set<string>>} Adjacency list: nodeId → Set<edgeId> */
    this._adjacency = new Map();
  }

  /**
   * Add or update an entity node.
   * @param {string} id - Entity ID.
   * @param {Object} data - Node data { type, label, memoryIds, metadata }.
   */
  addNode(id, data = {}) {
    const existing = this._nodes.get(id);
    if (existing) {
      Object.assign(existing, data);
      if (data.memoryIds) {
        existing.memoryIds = [...new Set([...(existing.memoryIds || []), ...data.memoryIds])];
      }
    } else {
      this._nodes.set(id, {
        id,
        type: data.type || 'entity',
        label: data.label || id,
        memoryIds: data.memoryIds || [],
        metadata: data.metadata || {},
        createdAt: Date.now(),
      });
      this._adjacency.set(id, new Set());
    }
  }

  /**
   * Add a directed edge between entities.
   * @param {string} source - Source entity ID.
   * @param {string} target - Target entity ID.
   * @param {string} relation - Relationship type.
   * @param {Object} [metadata] - Edge metadata.
   * @returns {string} Edge ID.
   */
  addEdge(source, target, relation, metadata = {}) {
    // Auto-create nodes if missing
    if (!this._nodes.has(source)) this.addNode(source);
    if (!this._nodes.has(target)) this.addNode(target);

    const edgeId = `${source}--${relation}-->${target}`;
    this._edges.set(edgeId, {
      id: edgeId,
      source,
      target,
      relation,
      weight: metadata.weight || 1.0,
      metadata,
      createdAt: Date.now(),
    });

    this._adjacency.get(source).add(edgeId);
    this._adjacency.get(target).add(edgeId);

    return edgeId;
  }

  /**
   * Remove an edge.
   * @param {string} edgeId
   * @returns {boolean}
   */
  removeEdge(edgeId) {
    const edge = this._edges.get(edgeId);
    if (!edge) return false;

    this._edges.delete(edgeId);
    const srcAdj = this._adjacency.get(edge.source);
    if (srcAdj) srcAdj.delete(edgeId);
    const tgtAdj = this._adjacency.get(edge.target);
    if (tgtAdj) tgtAdj.delete(edgeId);
    return true;
  }

  /**
   * Get all edges for a node.
   * @param {string} nodeId
   * @returns {Array<Object>}
   */
  getEdges(nodeId) {
    const adj = this._adjacency.get(nodeId);
    if (!adj) return [];
    return [...adj].map(eid => this._edges.get(eid)).filter(Boolean);
  }

  /**
   * Get neighbors of a node.
   * @param {string} nodeId
   * @param {string} [relation] - Optional filter by relation type.
   * @returns {Array<Object>} Neighbor nodes.
   */
  getNeighbors(nodeId, relation = null) {
    const edges = this.getEdges(nodeId);
    const neighborIds = new Set();

    for (const edge of edges) {
      if (relation && edge.relation !== relation) continue;
      if (edge.source === nodeId) neighborIds.add(edge.target);
      if (edge.target === nodeId) neighborIds.add(edge.source);
    }

    return [...neighborIds].map(id => this._nodes.get(id)).filter(Boolean);
  }

  /**
   * Multi-hop traversal from a start node.
   * @param {string} startId - Starting entity ID.
   * @param {number} [maxHops=3] - Maximum traversal depth.
   * @param {Object} [opts] - Traversal options.
   * @param {string} [opts.relation] - Filter by relation type.
   * @param {number} [opts.maxNodes=100] - Maximum nodes to visit.
   * @returns {Object} { nodes: Array, edges: Array, paths: Array }
   */
  traverse(startId, maxHops = 3, opts = {}) {
    const visited = new Set();
    const resultNodes = [];
    const resultEdges = [];
    const paths = [];
    const maxNodes = opts.maxNodes || 100;

    const queue = [{ nodeId: startId, depth: 0, path: [startId] }];
    visited.add(startId);

    while (queue.length > 0 && resultNodes.length < maxNodes) {
      const { nodeId, depth, path: currentPath } = queue.shift();

      const node = this._nodes.get(nodeId);
      if (node) {
        resultNodes.push({ ...node, depth });
      }

      if (depth >= maxHops) {
        paths.push(currentPath);
        continue;
      }

      const edges = this.getEdges(nodeId);
      for (const edge of edges) {
        if (opts.relation && edge.relation !== opts.relation) continue;

        const nextId = edge.source === nodeId ? edge.target : edge.source;
        if (!visited.has(nextId)) {
          visited.add(nextId);
          resultEdges.push(edge);
          queue.push({
            nodeId: nextId,
            depth: depth + 1,
            path: [...currentPath, nextId],
          });
        }
      }

      if (edges.length === 0 || depth === maxHops - 1) {
        paths.push(currentPath);
      }
    }

    return { nodes: resultNodes, edges: resultEdges, paths };
  }

  /**
   * Hybrid query: combine vector similarity results with graph structure.
   * @param {Array<Object>} vectorResults - Results from vector search with similarity scores.
   * @param {Object} [opts]
   * @param {number} [opts.graphWeight=0.3] - Weight for graph connectivity.
   * @param {number} [opts.maxHops=2] - Hops from vector results.
   * @returns {Array<Object>} Re-ranked results.
   */
  hybridQuery(vectorResults, opts = {}) {
    const graphWeight = opts.graphWeight || 0.3;
    const vectorWeight = 1.0 - graphWeight;
    const maxHops = opts.maxHops || 2;

    const scores = new Map();

    // Base scores from vector results
    for (const vr of vectorResults) {
      scores.set(vr.id, {
        vectorScore: vr.similarity || 0,
        graphScore: 0,
        entry: vr,
      });
    }

    // Boost scores based on graph connectivity
    for (const vr of vectorResults) {
      // Find the memory's associated entity nodes
      for (const [nodeId, node] of this._nodes) {
        if (node.memoryIds && node.memoryIds.includes(vr.id)) {
          // Traverse from this entity node
          const traversal = this.traverse(nodeId, maxHops, { maxNodes: 20 });
          for (const tNode of traversal.nodes) {
            for (const memId of (tNode.memoryIds || [])) {
              if (scores.has(memId)) {
                const depthDecay = 1 / (1 + tNode.depth);
                scores.get(memId).graphScore += depthDecay;
              }
            }
          }
        }
      }
    }

    // Combine scores
    const combined = [];
    for (const [id, scoreData] of scores) {
      const finalScore = vectorWeight * scoreData.vectorScore + graphWeight * scoreData.graphScore;
      combined.push({ ...scoreData.entry, finalScore, graphScore: scoreData.graphScore });
    }

    combined.sort((a, b) => b.finalScore - a.finalScore);
    return combined;
  }

  /**
   * Get graph statistics.
   * @returns {Object}
   */
  stats() {
    const relationCounts = {};
    for (const edge of this._edges.values()) {
      relationCounts[edge.relation] = (relationCounts[edge.relation] || 0) + 1;
    }
    return {
      nodes: this._nodes.size,
      edges: this._edges.size,
      relations: relationCounts,
    };
  }

  /**
   * Export the graph as a serializable object.
   * @returns {Object}
   */
  export() {
    return {
      nodes: [...this._nodes.values()],
      edges: [...this._edges.values()],
    };
  }

  /**
   * Import a graph from a serialized object.
   * @param {Object} data - { nodes, edges }
   */
  import(data) {
    if (data.nodes) {
      for (const node of data.nodes) {
        this.addNode(node.id, node);
      }
    }
    if (data.edges) {
      for (const edge of data.edges) {
        this.addEdge(edge.source, edge.target, edge.relation, edge.metadata);
      }
    }
  }
}

// ─── Semantic Drift Detector ───────────────────────────────────────────────────

/**
 * Detect semantic drift by comparing zone centroids against baseline snapshots.
 *
 * @class SemanticDriftDetector
 */
class SemanticDriftDetector {
  constructor() {
    this._baselines = new Map(); // octantId → centroid
    this._history = [];
    this._alertThreshold = 0.15; // cosine distance threshold
  }

  /**
   * Capture baseline centroids from all octant zones.
   * @param {Array<OctantZone>} zones
   */
  captureBaseline(zones) {
    this._baselines.clear();
    for (const zone of zones) {
      const centroid = zone.centroid();
      if (centroid) {
        this._baselines.set(zone.octantId, centroid);
      }
    }
  }

  /**
   * Check for drift against baseline.
   * @param {Array<OctantZone>} zones
   * @returns {Object} Drift report.
   */
  checkDrift(zones) {
    if (this._baselines.size === 0) return { drifted: false, zones: [] };

    const driftedZones = [];
    for (const zone of zones) {
      const baseline = this._baselines.get(zone.octantId);
      if (!baseline) continue;

      const current = zone.centroid();
      if (!current) continue;

      const sim = cosineSimilarity(baseline, current);
      const distance = 1 - sim;

      if (distance > this._alertThreshold) {
        driftedZones.push({
          octant: zone.octantId,
          distance: Math.round(distance * 10000) / 10000,
          similarity: Math.round(sim * 10000) / 10000,
          severity: distance > this._alertThreshold * 2 ? 'high' : 'medium',
        });
      }
    }

    const report = {
      ts: Date.now(),
      drifted: driftedZones.length > 0,
      zones: driftedZones,
      totalZonesChecked: zones.length,
    };

    this._history.push(report);
    if (this._history.length > 100) this._history = this._history.slice(-100);

    return report;
  }

  /**
   * Get drift history.
   * @returns {Array<Object>}
   */
  getHistory() {
    return [...this._history];
  }

  /**
   * Set drift alert threshold.
   * @param {number} threshold
   */
  setThreshold(threshold) {
    this._alertThreshold = threshold;
  }
}

// ─── Zone Coherence Alerting ───────────────────────────────────────────────────

/**
 * Monitor pairwise centroid similarity between octant zones.
 * Alert when zones that should be distinct become too similar (convergence)
 * or when adjacent zones diverge unexpectedly.
 *
 * @class ZoneCoherenceMonitor
 */
class ZoneCoherenceMonitor {
  /**
   * @param {Object} opts
   * @param {number} [opts.convergenceThreshold=0.85] - Alert if non-adjacent zones are this similar.
   * @param {number} [opts.divergenceThreshold=0.3] - Alert if adjacent zones drop below this similarity.
   */
  constructor(opts = {}) {
    this.convergenceThreshold = opts.convergenceThreshold || 0.85;
    this.divergenceThreshold = opts.divergenceThreshold || 0.3;
    this._alerts = [];
  }

  /**
   * Analyze zone coherence.
   * @param {Array<OctantZone>} zones
   * @returns {Object} Coherence report with alerts.
   */
  analyze(zones) {
    const centroids = new Map();
    for (const zone of zones) {
      const c = zone.centroid();
      if (c) centroids.set(zone.octantId, c);
    }

    const alerts = [];
    const pairwise = [];
    const octants = [...centroids.keys()];

    for (let i = 0; i < octants.length; i++) {
      for (let j = i + 1; j < octants.length; j++) {
        const oA = octants[i];
        const oB = octants[j];
        const sim = cosineSimilarity(centroids.get(oA), centroids.get(oB));
        const isAdjacent = getAdjacentOctants(oA).includes(oB);

        pairwise.push({ octantA: oA, octantB: oB, similarity: sim, adjacent: isAdjacent });

        if (!isAdjacent && sim > this.convergenceThreshold) {
          alerts.push({
            type: 'convergence',
            octantA: oA,
            octantB: oB,
            similarity: Math.round(sim * 10000) / 10000,
            message: `Non-adjacent zones ${oA} and ${oB} are converging (sim=${sim.toFixed(4)})`,
          });
        }

        if (isAdjacent && sim < this.divergenceThreshold) {
          alerts.push({
            type: 'divergence',
            octantA: oA,
            octantB: oB,
            similarity: Math.round(sim * 10000) / 10000,
            message: `Adjacent zones ${oA} and ${oB} are diverging (sim=${sim.toFixed(4)})`,
          });
        }
      }
    }

    this._alerts.push(...alerts);
    if (this._alerts.length > 500) this._alerts = this._alerts.slice(-500);

    return {
      ts: Date.now(),
      alerts,
      pairwise,
      coherenceScore: pairwise.length > 0
        ? pairwise.reduce((s, p) => s + p.similarity, 0) / pairwise.length
        : 1.0,
    };
  }

  /**
   * Get alert history.
   * @returns {Array<Object>}
   */
  getAlerts() {
    return [...this._alerts];
  }
}

// ─── Agent Lifecycle Manager ───────────────────────────────────────────────────

/**
 * Manage agent lifecycles within the 3D memory space.
 * Track agent positions, spawn, observe, update, and terminate.
 *
 * @class AgentLifecycleManager
 */
class AgentLifecycleManager {
  constructor() {
    /** @type {Map<string, Object>} Active agents */
    this._agents = new Map();
    this._history = [];
  }

  /**
   * Spawn a new agent in the memory space.
   * @param {Object} opts
   * @param {string} opts.id - Agent ID.
   * @param {string} opts.type - Agent type (reasoning, embedding, search, etc.).
   * @param {{ x: number, y: number, z: number }} [opts.position] - 3D position.
   * @param {Object} [opts.metadata] - Additional metadata.
   * @returns {Object} Agent record.
   */
  spawn(opts) {
    const agent = {
      id: opts.id || crypto.randomUUID(),
      type: opts.type || 'generic',
      position: opts.position || { x: 0, y: 0, z: 0 },
      octant: getOctant(opts.position || { x: 0, y: 0, z: 0 }),
      status: 'active',
      spawnedAt: Date.now(),
      lastUpdate: Date.now(),
      observations: [],
      metadata: opts.metadata || {},
      taskCount: 0,
      errorCount: 0,
    };

    this._agents.set(agent.id, agent);
    this._recordEvent('spawn', agent.id, { type: agent.type, position: agent.position });
    return agent;
  }

  /**
   * Record an observation from an agent.
   * @param {string} agentId - Agent ID.
   * @param {Object} observation - Observation data.
   * @returns {boolean} Success.
   */
  observe(agentId, observation) {
    const agent = this._agents.get(agentId);
    if (!agent) return false;

    agent.observations.push({
      ...observation,
      ts: Date.now(),
    });

    // Keep last 100 observations per agent
    if (agent.observations.length > 100) {
      agent.observations = agent.observations.slice(-100);
    }

    agent.lastUpdate = Date.now();
    return true;
  }

  /**
   * Update an agent's position and metadata.
   * @param {string} agentId
   * @param {Object} updates - { position, metadata, status }
   * @returns {Object|null} Updated agent or null.
   */
  update(agentId, updates) {
    const agent = this._agents.get(agentId);
    if (!agent) return null;

    if (updates.position) {
      agent.position = updates.position;
      agent.octant = getOctant(updates.position);
    }
    if (updates.metadata) {
      agent.metadata = { ...agent.metadata, ...updates.metadata };
    }
    if (updates.status) {
      agent.status = updates.status;
    }
    if (updates.taskCount !== undefined) {
      agent.taskCount = updates.taskCount;
    }
    if (updates.errorCount !== undefined) {
      agent.errorCount = updates.errorCount;
    }

    agent.lastUpdate = Date.now();
    this._recordEvent('update', agentId, updates);
    return agent;
  }

  /**
   * Terminate an agent.
   * @param {string} agentId
   * @param {string} [reason='manual']
   * @returns {boolean}
   */
  terminate(agentId, reason = 'manual') {
    const agent = this._agents.get(agentId);
    if (!agent) return false;

    agent.status = 'terminated';
    agent.terminatedAt = Date.now();
    agent.terminationReason = reason;

    this._recordEvent('terminate', agentId, { reason });
    this._agents.delete(agentId);
    return true;
  }

  /**
   * Get all active agents.
   * @returns {Array<Object>}
   */
  getActiveAgents() {
    return [...this._agents.values()].filter(a => a.status === 'active');
  }

  /**
   * Get agent by ID.
   * @param {string} agentId
   * @returns {Object|null}
   */
  getAgent(agentId) {
    return this._agents.get(agentId) || null;
  }

  /**
   * Get all agents in a specific octant.
   * @param {number} octant
   * @returns {Array<Object>}
   */
  getAgentsInOctant(octant) {
    return [...this._agents.values()].filter(a => a.octant === octant);
  }

  /**
   * Get lifecycle event history.
   * @param {number} [limit=50]
   * @returns {Array<Object>}
   */
  getHistory(limit = 50) {
    return this._history.slice(-limit);
  }

  /**
   * Get agent statistics.
   * @returns {Object}
   */
  stats() {
    const byType = {};
    const byOctant = {};
    for (const agent of this._agents.values()) {
      byType[agent.type] = (byType[agent.type] || 0) + 1;
      byOctant[agent.octant] = (byOctant[agent.octant] || 0) + 1;
    }
    return {
      total: this._agents.size,
      active: this.getActiveAgents().length,
      byType,
      byOctant,
    };
  }

  /**
   * @private
   */
  _recordEvent(event, agentId, data) {
    this._history.push({ event, agentId, data, ts: Date.now() });
    if (this._history.length > 1000) this._history = this._history.slice(-1000);
  }
}

// ─── Outbound Representation Builder ───────────────────────────────────────────

/**
 * Build outbound representations of the memory space in various projections.
 *
 * @class RepresentationBuilder
 */
class RepresentationBuilder {
  /**
   * Cartesian projection (x, y, z) — raw 3D coordinates.
   * @param {Array<Object>} entries - Memory entries with position.
   * @returns {Array<Object>}
   */
  static cartesian(entries) {
    return entries.map(e => ({
      id: e.id,
      x: e.position.x,
      y: e.position.y,
      z: e.position.z,
      octant: getOctant(e.position),
      importance: e.importance || 0,
      tier: e.tier || 'stm',
      text: e.text ? e.text.slice(0, 100) : '',
    }));
  }

  /**
   * Spherical projection (r, θ, φ) from Cartesian coordinates.
   * @param {Array<Object>} entries - Memory entries with position.
   * @returns {Array<Object>}
   */
  static spherical(entries) {
    return entries.map(e => {
      const { x, y, z } = e.position;
      const r = Math.sqrt(x * x + y * y + z * z);
      const theta = r > 0 ? Math.acos(z / r) : 0; // polar angle
      const phi = Math.atan2(y, x); // azimuthal angle

      return {
        id: e.id,
        r: Math.round(r * 10000) / 10000,
        theta: Math.round(theta * 10000) / 10000,
        phi: Math.round(phi * 10000) / 10000,
        importance: e.importance || 0,
        tier: e.tier || 'stm',
      };
    });
  }

  /**
   * Isometric projection for 2D visualization.
   * @param {Array<Object>} entries - Memory entries with position.
   * @param {number} [angle=Math.PI/6] - Isometric angle.
   * @returns {Array<Object>}
   */
  static isometric(entries, angle = Math.PI / 6) {
    const cosA = Math.cos(angle);
    const sinA = Math.sin(angle);

    return entries.map(e => {
      const { x, y, z } = e.position;
      const isoX = (x - z) * cosA;
      const isoY = (x + z) * sinA - y;

      return {
        id: e.id,
        isoX: Math.round(isoX * 10000) / 10000,
        isoY: Math.round(isoY * 10000) / 10000,
        depth: Math.round((x + y + z) * 10000) / 10000,
        importance: e.importance || 0,
        tier: e.tier || 'stm',
      };
    });
  }
}

// ─── VectorMemory3D — Main Class ───────────────────────────────────────────────

/**
 * 3D Spatial Vector Memory — the core memory system for Heady™.
 *
 * Features:
 *   - 384-dim embeddings projected to 3D (x,y,z) via PCA-lite
 *   - 8 octant zones × 5 Fibonacci shards
 *   - Zone-first query strategy
 *   - Graph RAG with multi-hop traversal
 *   - STM→LTM consolidation
 *   - Density gating for semantic dedup
 *   - Autonomous PHI-timed maintenance
 *   - Semantic drift detection
 *   - Zone coherence alerting
 *   - Agent lifecycle management
 *
 * @class VectorMemory3D
 * @extends EventEmitter
 */
class VectorMemory3D extends EventEmitter {
  /**
   * @param {Object} [opts]
   * @param {string} [opts.persistDir] - Directory for persistence.
   * @param {boolean} [opts.autoMaintenance=true] - Enable autonomous maintenance.
   */
  constructor(opts = {}) {
    super();
    this.setMaxListeners(50);

    // Initialize octant zones
    this.zones = [];
    for (let i = 0; i < NUM_OCTANTS; i++) {
      this.zones.push(new OctantZone(i));
    }

    // Subsystems
    this.embeddingProvider = new EmbeddingProvider();
    this.graphRAG = new GraphRAGLayer();
    this.driftDetector = new SemanticDriftDetector();
    this.coherenceMonitor = new ZoneCoherenceMonitor();
    this.agentManager = new AgentLifecycleManager();

    // Persistence
    this._persistDir = opts.persistDir || path.join(os.tmpdir(), 'hc-vector-memory');
    try {
      if (!fs.existsSync(this._persistDir)) {
        fs.mkdirSync(this._persistDir, { recursive: true });
      }
    } catch (_) { /* best-effort */ }

    // Stats
    this._totalIngested = 0;
    this._totalQueries = 0;
    this._createdAt = Date.now();

    // Maintenance timers
    this._maintenanceTimer = null;
    this._driftTimer = null;
    this._autoMaintenance = opts.autoMaintenance !== false;

    if (this._autoMaintenance) {
      this._startMaintenance();
    }
  }

  // ── Ingest ──

  /**
   * Ingest a memory entry.
   * @param {Object} entry
   * @param {string} entry.text - Text content.
   * @param {string} [entry.id] - Optional ID.
   * @param {Object} [entry.metadata] - Metadata.
   * @param {Float64Array} [entry.embedding] - Pre-computed embedding.
   * @param {number} [entry.surprise] - Surprise score.
   * @param {string} [entry.source] - Source identifier.
   * @returns {Promise<Object>} Ingest result.
   */
  async ingest(entry) {
    // Generate embedding if not provided
    let embedding = entry.embedding;
    if (!embedding) {
      embedding = await this.embeddingProvider.embed(entry.text || '');
    }

    // Project to 3D
    const position = projectTo3D(embedding);
    const octant = getOctant(position);

    // Ingest into the appropriate zone (round-robin within zone's shards)
    const result = this.zones[octant].ingest({
      ...entry,
      embedding,
      position,
    });

    this._totalIngested++;
    this.emit('ingest', { octant, ...result, position });

    return {
      ...result,
      octant,
      position,
    };
  }

  /**
   * Batch ingest multiple entries.
   * @param {Array<Object>} entries
   * @returns {Promise<Array<Object>>}
   */
  async batchIngest(entries) {
    const results = [];
    for (const entry of entries) {
      try {
        const result = await this.ingest(entry);
        results.push(result);
      } catch (err) {
        results.push({ error: err.message, entry: entry.id || 'unknown' });
      }
    }
    return results;
  }

  // ── Query ──

  /**
   * Query the memory using zone-first strategy:
   * 1. Identify the query's octant
   * 2. Search same-zone first
   * 3. Expand to adjacent zones
   * 4. Full scan if needed
   *
   * @param {string|Float64Array} query - Text query or embedding vector.
   * @param {Object} [opts]
   * @param {number} [opts.topK=10]
   * @param {number} [opts.minSimilarity=0.0]
   * @param {boolean} [opts.graphEnhanced=false] - Use Graph RAG hybrid scoring.
   * @param {boolean} [opts.fullScan=false] - Force full scan across all zones.
   * @returns {Promise<Object>} Query result.
   */
  async query(query, opts = {}) {
    const topK = opts.topK || 10;
    const minSim = opts.minSimilarity || 0.0;
    const queryStart = Date.now();

    // Get query embedding
    let queryVec;
    if (typeof query === 'string') {
      queryVec = await this.embeddingProvider.embed(query);
    } else {
      queryVec = query;
    }

    const queryPos = projectTo3D(queryVec);
    const queryOctant = getOctant(queryPos);

    let results = [];
    let searchStrategy = 'zone-first';

    if (opts.fullScan) {
      // Full scan across all zones
      searchStrategy = 'full-scan';
      for (const zone of this.zones) {
        results.push(...zone.search(queryVec, topK, minSim));
      }
    } else {
      // Zone-first strategy
      // Phase 1: Same zone
      results = this.zones[queryOctant].search(queryVec, topK, minSim);

      if (results.length < topK) {
        // Phase 2: Adjacent zones
        const adjacent = getAdjacentOctants(queryOctant);
        for (const adjOctant of adjacent) {
          if (results.length >= topK) break;
          const adjResults = this.zones[adjOctant].search(queryVec, topK - results.length, minSim);
          results.push(...adjResults);
        }

        if (results.length < topK) {
          // Phase 3: Remaining zones
          searchStrategy = 'expanded';
          const searched = new Set([queryOctant, ...adjacent]);
          for (let z = 0; z < NUM_OCTANTS; z++) {
            if (searched.has(z)) continue;
            if (results.length >= topK) break;
            const zResults = this.zones[z].search(queryVec, topK - results.length, minSim);
            results.push(...zResults);
          }
        }
      }
    }

    // Deduplicate and sort
    const seen = new Set();
    results = results.filter(r => {
      if (seen.has(r.id)) return false;
      seen.add(r.id);
      return true;
    });
    results.sort((a, b) => b.similarity - a.similarity);
    results = results.slice(0, topK);

    // Graph RAG enhancement
    if (opts.graphEnhanced && this.graphRAG.stats().nodes > 0) {
      results = this.graphRAG.hybridQuery(results, {
        graphWeight: opts.graphWeight || 0.3,
        maxHops: opts.graphHops || 2,
      });
    }

    this._totalQueries++;
    const queryTime = Date.now() - queryStart;

    return {
      results,
      queryOctant,
      queryPosition: queryPos,
      searchStrategy,
      queryTimeMs: queryTime,
      totalResults: results.length,
    };
  }

  // ── Entity Management (Graph RAG) ──

  /**
   * Add an entity to the graph RAG layer.
   * @param {string} entityId
   * @param {Object} data
   */
  addEntity(entityId, data = {}) {
    this.graphRAG.addNode(entityId, data);
  }

  /**
   * Add a relationship between entities.
   * @param {string} source
   * @param {string} target
   * @param {string} relation
   * @param {Object} [metadata]
   * @returns {string} Edge ID.
   */
  addRelation(source, target, relation, metadata = {}) {
    return this.graphRAG.addEdge(source, target, relation, metadata);
  }

  /**
   * Traverse the entity graph from a starting point.
   * @param {string} startEntity
   * @param {number} [maxHops=3]
   * @param {Object} [opts]
   * @returns {Object}
   */
  traverseGraph(startEntity, maxHops = 3, opts = {}) {
    return this.graphRAG.traverse(startEntity, maxHops, opts);
  }

  // ── Retrieval ──

  /**
   * Get a memory entry by ID.
   * @param {string} id
   * @returns {Object|null}
   */
  getById(id) {
    for (const zone of this.zones) {
      const entry = zone.getById(id);
      if (entry) return entry;
    }
    return null;
  }

  /**
   * Remove a memory entry by ID.
   * @param {string} id
   * @returns {boolean}
   */
  remove(id) {
    for (const zone of this.zones) {
      if (zone.remove(id)) return true;
    }
    return false;
  }

  // ── Maintenance ──

  /**
   * Run maintenance cycle: consolidation, importance recompute, drift check.
   * @returns {Object} Maintenance report.
   */
  runMaintenance() {
    const start = Date.now();

    // Recompute importance scores
    for (const zone of this.zones) {
      zone.recomputeImportance();
    }

    // STM → LTM consolidation
    let totalPromoted = 0;
    for (const zone of this.zones) {
      totalPromoted += zone.consolidate();
    }

    // Zone coherence check
    const coherence = this.coherenceMonitor.analyze(this.zones);

    const report = {
      ts: Date.now(),
      duration: Date.now() - start,
      promoted: totalPromoted,
      coherence,
    };

    this.emit('maintenance', report);
    return report;
  }

  /**
   * Capture a drift baseline and check for drift.
   * @returns {Object}
   */
  checkDrift() {
    if (this.driftDetector._baselines.size === 0) {
      this.driftDetector.captureBaseline(this.zones);
      return { drifted: false, message: 'Baseline captured' };
    }
    return this.driftDetector.checkDrift(this.zones);
  }

  /**
   * Start autonomous maintenance with PHI-derived intervals.
   * @private
   */
  _startMaintenance() {
    // Main maintenance cycle
    this._maintenanceTimer = setInterval(() => {
      try {
        this.runMaintenance();
      } catch (err) {
        this.emit('error', { type: 'maintenance', error: err.message });
      }
    }, this._getMaintenanceInterval());

    if (this._maintenanceTimer.unref) this._maintenanceTimer.unref();

    // Drift detection cycle
    this._driftTimer = setInterval(() => {
      try {
        const drift = this.checkDrift();
        if (drift.drifted) {
          this.emit('drift', drift);
        }
      } catch (err) {
        this.emit('error', { type: 'drift', error: err.message });
      }
    }, DRIFT_CHECK_INTERVAL);

    if (this._driftTimer.unref) this._driftTimer.unref();
  }

  /**
   * Compute maintenance interval dynamically based on memory pressure and PHI.
   * @private
   * @returns {number} Interval in ms.
   */
  _getMaintenanceInterval() {
    const freeMem = os.freemem();
    const totalMem = os.totalmem();
    const memPressure = 1 - (freeMem / totalMem);

    // Higher pressure → more frequent maintenance
    const factor = memPressure > 0.8 ? 1 / PHI : memPressure > 0.5 ? 1 : PHI;
    return Math.round(MAINTENANCE_BASE_INTERVAL * factor);
  }

  // ── Statistics ──

  /**
   * Get comprehensive memory statistics.
   * @returns {Object}
   */
  stats() {
    const zoneStats = this.zones.map(z => z.stats());
    const totalEntries = zoneStats.reduce((s, z) => s + z.totalEntries, 0);

    return {
      totalEntries,
      totalIngested: this._totalIngested,
      totalQueries: this._totalQueries,
      uptime: Date.now() - this._createdAt,
      zones: zoneStats,
      graphRAG: this.graphRAG.stats(),
      embedding: this.embeddingProvider.getStats(),
      agents: this.agentManager.stats(),
      drift: this.driftDetector.getHistory().slice(-5),
    };
  }

  /**
   * Get the total depth (entry count) of the vector memory.
   * @returns {number}
   */
  get depth() {
    return this.zones.reduce((s, z) => s + z.size, 0);
  }

  // ── Representation ──

  /**
   * Get all entries in Cartesian representation.
   * @param {number} [limit=1000]
   * @returns {Array<Object>}
   */
  getCartesian(limit = 1000) {
    const allEntries = this._getAllEntries(limit);
    return RepresentationBuilder.cartesian(allEntries);
  }

  /**
   * Get all entries in spherical representation.
   * @param {number} [limit=1000]
   * @returns {Array<Object>}
   */
  getSpherical(limit = 1000) {
    const allEntries = this._getAllEntries(limit);
    return RepresentationBuilder.spherical(allEntries);
  }

  /**
   * Get all entries in isometric representation.
   * @param {number} [limit=1000]
   * @returns {Array<Object>}
   */
  getIsometric(limit = 1000) {
    const allEntries = this._getAllEntries(limit);
    return RepresentationBuilder.isometric(allEntries);
  }

  /**
   * Collect entries across all zones.
   * @private
   * @param {number} limit
   * @returns {Array<Object>}
   */
  _getAllEntries(limit = 1000) {
    const entries = [];
    for (const zone of this.zones) {
      for (const shard of zone.shards) {
        for (const entry of shard.entries) {
          entries.push(entry);
          if (entries.length >= limit) return entries;
        }
      }
    }
    return entries;
  }

  // ── Persistence ──

  /**
   * Persist the memory state to disk.
   * @returns {boolean}
   */
  persist() {
    try {
      const state = {
        version: '4.0.0',
        ts: Date.now(),
        zones: this.zones.map(z => ({
          octantId: z.octantId,
          shards: z.shards.map(s => ({
            shardId: s.shardId,
            entries: s.entries.map(e => ({
              id: e.id,
              embedding: Array.from(e.embedding),
              position: e.position,
              text: e.text,
              metadata: e.metadata,
              createdAt: e.createdAt,
              lastAccess: e.lastAccess,
              accessCount: e.accessCount,
              importance: e.importance,
              surprise: e.surprise,
              source: e.source,
              tier: e.tier,
            })),
          })),
        })),
        graphRAG: this.graphRAG.export(),
        stats: {
          totalIngested: this._totalIngested,
          totalQueries: this._totalQueries,
        },
      };

      const filePath = path.join(this._persistDir, 'vector-memory-snapshot.json');
      fs.writeFileSync(filePath, JSON.stringify(state), 'utf-8');
      this.emit('persisted', { path: filePath, size: state.zones.length });
      return true;
    } catch (err) {
      this.emit('error', { type: 'persist', error: err.message });
      return false;
    }
  }

  /**
   * Restore memory state from disk.
   * @returns {boolean}
   */
  restore() {
    try {
      const filePath = path.join(this._persistDir, 'vector-memory-snapshot.json');
      if (!fs.existsSync(filePath)) return false;

      const raw = fs.readFileSync(filePath, 'utf-8');
      const state = JSON.parse(raw);

      for (const zoneData of (state.zones || [])) {
        const zone = this.zones[zoneData.octantId];
        if (!zone) continue;

        for (const shardData of (zoneData.shards || [])) {
          const shard = zone.shards[shardData.shardId];
          if (!shard) continue;

          for (const entryData of (shardData.entries || [])) {
            shard.entries.push({
              ...entryData,
              embedding: new Float64Array(entryData.embedding),
            });
          }
          shard._rebuildIndex();
        }
      }

      if (state.graphRAG) {
        this.graphRAG.import(state.graphRAG);
      }
      if (state.stats) {
        this._totalIngested = state.stats.totalIngested || 0;
        this._totalQueries = state.stats.totalQueries || 0;
      }

      this.emit('restored', { ts: state.ts });
      return true;
    } catch (err) {
      this.emit('error', { type: 'restore', error: err.message });
      return false;
    }
  }

  // ── Cleanup ──

  /**
   * Stop maintenance timers and release resources.
   */
  destroy() {
    if (this._maintenanceTimer) {
      clearInterval(this._maintenanceTimer);
      this._maintenanceTimer = null;
    }
    if (this._driftTimer) {
      clearInterval(this._driftTimer);
      this._driftTimer = null;
    }
    this.removeAllListeners();
  }
}

// ─── Express Route Registration ────────────────────────────────────────────────

/**
 * Register all vector memory API routes on an Express app/router.
 *
 * @param {Object} app - Express app or Router.
 * @param {VectorMemory3D} memory - VectorMemory3D instance.
 * @param {string} [prefix='/api/memory'] - Route prefix.
 */
function registerRoutes(app, memory, prefix = '/api/memory') {

  /**
   * POST /api/memory/ingest
   * Ingest a single memory entry.
   * Body: { text, metadata?, id?, surprise?, source? }
   */
  app.post(`${prefix}/ingest`, async (req, res) => {
    try {
      const result = await memory.ingest(req.body);
      res.json({ ok: true, result });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /**
   * POST /api/memory/batch-ingest
   * Ingest multiple entries.
   * Body: { entries: Array }
   */
  app.post(`${prefix}/batch-ingest`, async (req, res) => {
    try {
      const results = await memory.batchIngest(req.body.entries || []);
      res.json({ ok: true, results });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /**
   * POST /api/memory/query
   * Query the memory.
   * Body: { query, topK?, minSimilarity?, graphEnhanced?, fullScan? }
   */
  app.post(`${prefix}/query`, async (req, res) => {
    try {
      const result = await memory.query(req.body.query, req.body);
      res.json({ ok: true, ...result });
    } catch (err) {
      res.status(500).json({ ok: false, error: err.message });
    }
  });

  /**
   * GET /api/memory/entry/:id
   * Get a memory entry by ID.
   */
  app.get(`${prefix}/entry/:id`, (req, res) => {
    const entry = memory.getById(req.params.id);
    if (!entry) return res.status(404).json({ ok: false, error: 'Not found' });
    res.json({ ok: true, entry });
  });

  /**
   * DELETE /api/memory/entry/:id
   * Remove a memory entry by ID.
   */
  app.delete(`${prefix}/entry/:id`, (req, res) => {
    const removed = memory.remove(req.params.id);
    res.json({ ok: true, removed });
  });

  /**
   * POST /api/memory/entity
   * Add an entity to the graph RAG layer.
   * Body: { id, type?, label?, memoryIds?, metadata? }
   */
  app.post(`${prefix}/entity`, (req, res) => {
    memory.addEntity(req.body.id, req.body);
    res.json({ ok: true });
  });

  /**
   * POST /api/memory/relation
   * Add a relationship between entities.
   * Body: { source, target, relation, metadata? }
   */
  app.post(`${prefix}/relation`, (req, res) => {
    const edgeId = memory.addRelation(
      req.body.source,
      req.body.target,
      req.body.relation,
      req.body.metadata
    );
    res.json({ ok: true, edgeId });
  });

  /**
   * POST /api/memory/traverse
   * Traverse the entity graph.
   * Body: { startEntity, maxHops?, relation?, maxNodes? }
   */
  app.post(`${prefix}/traverse`, (req, res) => {
    const result = memory.traverseGraph(
      req.body.startEntity,
      req.body.maxHops,
      req.body
    );
    res.json({ ok: true, ...result });
  });

  /**
   * GET /api/memory/stats
   * Get comprehensive memory statistics.
   */
  app.get(`${prefix}/stats`, (_req, res) => {
    res.json({ ok: true, ...memory.stats() });
  });

  /**
   * GET /api/memory/representation/:type
   * Get memory in specified projection (cartesian, spherical, isometric).
   */
  app.get(`${prefix}/representation/:type`, (req, res) => {
    const limit = parseInt(req.query.limit) || 1000;
    const type = req.params.type;

    let data;
    switch (type) {
      case 'cartesian':
        data = memory.getCartesian(limit);
        break;
      case 'spherical':
        data = memory.getSpherical(limit);
        break;
      case 'isometric':
        data = memory.getIsometric(limit);
        break;
      default:
        return res.status(400).json({ ok: false, error: `Unknown projection: ${type}` });
    }

    res.json({ ok: true, type, count: data.length, data });
  });

  /**
   * POST /api/memory/maintenance
   * Trigger a maintenance cycle.
   */
  app.post(`${prefix}/maintenance`, (_req, res) => {
    const report = memory.runMaintenance();
    res.json({ ok: true, ...report });
  });

  /**
   * GET /api/memory/drift
   * Check for semantic drift.
   */
  app.get(`${prefix}/drift`, (_req, res) => {
    const drift = memory.checkDrift();
    res.json({ ok: true, ...drift });
  });

  /**
   * GET /api/memory/coherence
   * Get zone coherence report.
   */
  app.get(`${prefix}/coherence`, (_req, res) => {
    const report = memory.coherenceMonitor.analyze(memory.zones);
    res.json({ ok: true, ...report });
  });

  /**
   * POST /api/memory/persist
   * Persist memory state to disk.
   */
  app.post(`${prefix}/persist`, (_req, res) => {
    const success = memory.persist();
    res.json({ ok: success });
  });

  /**
   * POST /api/memory/restore
   * Restore memory state from disk.
   */
  app.post(`${prefix}/restore`, (_req, res) => {
    const success = memory.restore();
    res.json({ ok: success });
  });

  // ── Agent Lifecycle Routes ──

  /**
   * POST /api/memory/agents/spawn
   * Spawn a new agent.
   * Body: { id?, type, position?, metadata? }
   */
  app.post(`${prefix}/agents/spawn`, (req, res) => {
    const agent = memory.agentManager.spawn(req.body);
    res.json({ ok: true, agent });
  });

  /**
   * POST /api/memory/agents/:id/observe
   * Record an observation from an agent.
   * Body: observation data
   */
  app.post(`${prefix}/agents/:id/observe`, (req, res) => {
    const success = memory.agentManager.observe(req.params.id, req.body);
    if (!success) return res.status(404).json({ ok: false, error: 'Agent not found' });
    res.json({ ok: true });
  });

  /**
   * PATCH /api/memory/agents/:id
   * Update an agent.
   * Body: { position?, metadata?, status? }
   */
  app.patch(`${prefix}/agents/:id`, (req, res) => {
    const agent = memory.agentManager.update(req.params.id, req.body);
    if (!agent) return res.status(404).json({ ok: false, error: 'Agent not found' });
    res.json({ ok: true, agent });
  });

  /**
   * DELETE /api/memory/agents/:id
   * Terminate an agent.
   */
  app.delete(`${prefix}/agents/:id`, (req, res) => {
    const success = memory.agentManager.terminate(req.params.id, req.query.reason || 'api');
    if (!success) return res.status(404).json({ ok: false, error: 'Agent not found' });
    res.json({ ok: true });
  });

  /**
   * GET /api/memory/agents
   * List all active agents.
   */
  app.get(`${prefix}/agents`, (_req, res) => {
    const agents = memory.agentManager.getActiveAgents();
    res.json({ ok: true, agents, stats: memory.agentManager.stats() });
  });

  /**
   * GET /api/memory/agents/:id
   * Get a specific agent.
   */
  app.get(`${prefix}/agents/:id`, (req, res) => {
    const agent = memory.agentManager.getAgent(req.params.id);
    if (!agent) return res.status(404).json({ ok: false, error: 'Agent not found' });
    res.json({ ok: true, agent });
  });

  /**
   * GET /api/memory/graph
   * Export the full graph.
   */
  app.get(`${prefix}/graph`, (_req, res) => {
    const graph = memory.graphRAG.export();
    res.json({ ok: true, ...graph, stats: memory.graphRAG.stats() });
  });
}

// ─── Singleton Instance ────────────────────────────────────────────────────────

/** @type {VectorMemory3D} Default memory instance */
const vectorMemory = new VectorMemory3D({ autoMaintenance: false });

// ─── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  // Primary export
  vectorMemory,

  // Classes
  VectorMemory3D,
  EmbeddingProvider,
  FibonacciShard,
  OctantZone,
  GraphRAGLayer,
  SemanticDriftDetector,
  ZoneCoherenceMonitor,
  AgentLifecycleManager,
  RepresentationBuilder,
  NodePoolManager: undefined, // Re-exported from pipeline

  // Functions
  registerRoutes,
  projectTo3D,
  getOctant,
  getAdjacentOctants,
  cosineSimilarity,
  batchCosineSimilarity,
  hashEmbedding,
  generateProjectionMatrix,

  // Constants
  PHI,
  EMBEDDING_DIM,
  PCA_DIM,
  NUM_OCTANTS,
  NUM_SHARDS,
  DEDUP_THRESHOLD,
  STM_TTL,
  MAINTENANCE_BASE_INTERVAL,
  ALPHA_FREQ,
  BETA_RECENCY,
  GAMMA_DECAY,
  DELTA_SURPRISE,
};
