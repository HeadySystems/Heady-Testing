/**
 * @file lifecycle-bee.js
 * @description Graceful shutdown bee — registers cleanup handlers in order,
 *              executes them in LIFO sequence on SIGTERM/SIGINT, enforces
 *              per-handler and global timeouts, and reports status throughout.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const { EventEmitter } = require('events');

const PHI = 1.6180339887;

/** Default global shutdown timeout: PHI^7 * 1000 ≈ 29 034 ms */
const DEFAULT_SHUTDOWN_TIMEOUT_MS = Math.round(Math.pow(PHI, 7) * 1000);

/** Default per-handler timeout: PHI^5 * 1000 ≈ 11 090 ms */
const DEFAULT_HANDLER_TIMEOUT_MS  = Math.round(Math.pow(PHI, 5) * 1000);

/**
 * @typedef {object} CleanupHandler
 * @property {string}   name       - Human-readable handler name
 * @property {Function} fn         - Async cleanup function () => void
 * @property {number}   [timeout]  - Per-handler timeout in ms
 * @property {number}   _index     - Registration order (set internally)
 */

/**
 * Wrap a promise with a timeout rejection.
 *
 * @param {Promise<*>}  promise
 * @param {number}      ms
 * @param {string}      name
 * @returns {Promise<*>}
 */
function withTimeout(promise, ms, name) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(
      () => reject(new Error(`Cleanup handler "${name}" timed out after ${ms} ms`)),
      ms,
    );
    promise.then(
      (v) => { clearTimeout(t); resolve(v); },
      (e) => { clearTimeout(t); reject(e); },
    );
  });
}

/**
 * @class LifecycleBee
 * @extends EventEmitter
 *
 * @example
 * const lifecycle = new LifecycleBee({ shutdownTimeoutMs: 15000 });
 *
 * lifecycle.register('close-db', async () => { await db.close(); });
 * lifecycle.register('flush-queue', async () => { await queue.flush(); });
 *
 * lifecycle.listen(); // Attach SIGTERM/SIGINT
 */
class LifecycleBee extends EventEmitter {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.shutdownTimeoutMs] - Global shutdown deadline (default PHI^7*1000)
   * @param {number}  [opts.handlerTimeoutMs]  - Per-handler timeout (default PHI^5*1000)
   * @param {boolean} [opts.exitAfterShutdown=true] - Call process.exit(0) after clean shutdown
   */
  constructor(opts = {}) {
    super();

    this.shutdownTimeoutMs  = opts.shutdownTimeoutMs  ?? DEFAULT_SHUTDOWN_TIMEOUT_MS;
    this.handlerTimeoutMs   = opts.handlerTimeoutMs   ?? DEFAULT_HANDLER_TIMEOUT_MS;
    this.exitAfterShutdown  = opts.exitAfterShutdown  ?? true;

    /** @type {CleanupHandler[]} Handlers in registration order (LIFO on shutdown) */
    this._handlers = [];

    /** @type {boolean} */
    this._shutting = false;

    /** @type {boolean} */
    this._listening = false;

    /** @type {Array<{ name: string, status: 'pending'|'running'|'done'|'failed'|'timeout', elapsed?: number }>} */
    this._statusLog = [];
  }

  // ─── Registration ────────────────────────────────────────────────────────────

  /**
   * Register a cleanup handler.
   * Handlers are executed in LIFO order (last registered runs first).
   *
   * @param {string}   name      - Descriptive name for this handler
   * @param {Function} fn        - Async cleanup function
   * @param {object}   [opts]
   * @param {number}   [opts.timeout] - Override per-handler timeout
   * @returns {number} Handler index
   */
  register(name, fn, opts = {}) {
    if (typeof fn !== 'function') {
      throw new TypeError(`LifecycleBee.register: fn must be a function (handler: "${name}")`);
    }

    const handler = {
      name,
      fn,
      timeout: opts.timeout ?? this.handlerTimeoutMs,
      _index:  this._handlers.length,
    };

    this._handlers.push(handler);
    this.emit('registered', { name, index: handler._index });
    return handler._index;
  }

  /**
   * Remove a handler by name.
   *
   * @param {string} name
   * @returns {boolean}
   */
  unregister(name) {
    const idx = this._handlers.findIndex((h) => h.name === name);
    if (idx === -1) return false;
    this._handlers.splice(idx, 1);
    return true;
  }

  // ─── Signal Handling ─────────────────────────────────────────────────────────

  /**
   * Attach SIGTERM and SIGINT listeners.
   * Safe to call multiple times — only attaches once.
   */
  listen() {
    if (this._listening) return;
    this._listening = true;

    const handler = (signal) => {
      this.emit('signal', { signal });
      this.shutdown(signal).catch((err) => {
        this.emit('error', err);
        if (this.exitAfterShutdown) process.exit(1);
      });
    };

    process.once('SIGTERM', () => handler('SIGTERM'));
    process.once('SIGINT',  () => handler('SIGINT'));
  }

  // ─── Shutdown ────────────────────────────────────────────────────────────────

  /**
   * Execute all registered cleanup handlers in LIFO order.
   *
   * @param {string} [reason='manual'] - Reason for shutdown (e.g. 'SIGTERM')
   * @returns {Promise<void>}
   */
  async shutdown(reason = 'manual') {
    if (this._shutting) return;
    this._shutting = true;

    this._statusLog = [];
    const start = Date.now();

    this.emit('shutdownStart', { reason, handlers: this._handlers.length, ts: start });

    // Global deadline timer
    const globalDeadline = new Promise((_, reject) =>
      setTimeout(
        () => reject(new Error(`Shutdown global timeout exceeded (${this.shutdownTimeoutMs} ms)`)),
        this.shutdownTimeoutMs,
      ).unref(),
    );

    // Run handlers LIFO
    const lifoHandlers = [...this._handlers].reverse();

    const runAll = async () => {
      for (const handler of lifoHandlers) {
        const entry = { name: handler.name, status: 'running', elapsed: 0 };
        this._statusLog.push(entry);
        this.emit('handlerStart', { name: handler.name, ts: Date.now() });

        const t0 = Date.now();
        try {
          await withTimeout(
            Promise.resolve().then(() => handler.fn()),
            handler.timeout,
            handler.name,
          );
          entry.status  = 'done';
          entry.elapsed = Date.now() - t0;
          this.emit('handlerDone', { name: handler.name, elapsed: entry.elapsed });
        } catch (err) {
          entry.status  = err.message.includes('timed out') ? 'timeout' : 'failed';
          entry.elapsed = Date.now() - t0;
          entry.error   = err.message;
          this.emit('handlerError', { name: handler.name, error: err.message, elapsed: entry.elapsed });
          // Continue with remaining handlers despite individual failures
        }
      }
    };

    try {
      await Promise.race([runAll(), globalDeadline]);
    } catch (err) {
      this.emit('shutdownTimeout', { error: err.message, elapsed: Date.now() - start });
    }

    const elapsed = Date.now() - start;
    this.emit('shutdownComplete', {
      reason,
      elapsed,
      handlers: this._statusLog.length,
      failed:   this._statusLog.filter((s) => s.status === 'failed' || s.status === 'timeout').length,
    });

    if (this.exitAfterShutdown) {
      process.exit(0);
    }
  }

  // ─── Status ──────────────────────────────────────────────────────────────────

  /**
   * Return the current shutdown status log.
   *
   * @returns {Array<{ name: string, status: string, elapsed: number }>}
   */
  getStatus() {
    return {
      shutting:    this._shutting,
      handlers:    this._handlers.map((h) => ({ name: h.name, index: h._index })),
      log:         [...this._statusLog],
    };
  }
}

module.exports = {
  LifecycleBee,
  DEFAULT_SHUTDOWN_TIMEOUT_MS,
  DEFAULT_HANDLER_TIMEOUT_MS,
  domain: 'lifecycle',
  tasks:  ['register', 'listen', 'shutdown', 'getStatus'],
};
