/**
 * @file mcp-bee.js
 * @description MCP (Model Context Protocol) integration bee — sets up an MCP server
 *              using @modelcontextprotocol/sdk, registers tools/resources/prompts,
 *              and handles SSE/JSON-RPC transport.
 *
 * The MCP bee exposes Heady capabilities as MCP tools consumable by any
 * MCP-compatible LLM client (Claude Desktop, Cursor, etc.).
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const { EventEmitter } = require('events');

const PHI = 1.6180339887;

/**
 * @typedef {object} McpTool
 * @property {string}   name        - Tool name (snake_case)
 * @property {string}   description - Human-readable description
 * @property {object}   inputSchema - JSON Schema for input parameters
 * @property {Function} handler     - Async (input) => { content: Array }
 */

/**
 * @typedef {object} McpResource
 * @property {string}   uri         - Resource URI (e.g. 'heady://config/main')
 * @property {string}   name        - Display name
 * @property {string}   [mimeType]  - MIME type of the resource
 * @property {Function} read        - Async () => string|Buffer
 */

/**
 * @typedef {object} McpPrompt
 * @property {string}   name        - Prompt name
 * @property {string}   [description]
 * @property {object[]} [arguments] - Array of { name, description, required }
 * @property {Function} render      - Async (args) => { messages: Array }
 */

/**
 * Build a standard MCP text content block.
 *
 * @param {string} text
 * @returns {{ type: 'text', text: string }}
 */
function textContent(text) {
  return { type: 'text', text: String(text) };
}

/**
 * Build a standard MCP error response.
 *
 * @param {string} message
 * @returns {{ isError: true, content: Array }}
 */
function errorResponse(message) {
  return { isError: true, content: [textContent(`Error: ${message}`)] };
}

/**
 * @class McpBee
 * @extends EventEmitter
 *
 * Wraps @modelcontextprotocol/sdk to provide a managed MCP server with
 * Heady's tool/resource/prompt registry.
 *
 * @example
 * const bee = new McpBee({ serverName: 'heady', serverVersion: '1.0.0' });
 *
 * bee.registerTool({
 *   name:        'get_system_health',
 *   description: 'Get the current health status of Heady services',
 *   inputSchema: { type: 'object', properties: {} },
 *   handler:     async () => ({ content: [textContent(JSON.stringify(await healthBee.health()))] }),
 * });
 *
 * // In an Express app:
 * app.get('/mcp/sse',  bee.sseHandler());
 * app.post('/mcp/rpc', bee.rpcHandler());
 */
class McpBee extends EventEmitter {
  /**
   * @param {object} [opts]
   * @param {string} [opts.serverName='heady-mcp']     - MCP server name
   * @param {string} [opts.serverVersion='1.0.0']      - MCP server version
   * @param {object} [opts.capabilities]               - Override MCP capabilities
   */
  constructor(opts = {}) {
    super();

    this.serverName    = opts.serverName    ?? 'heady-mcp';
    this.serverVersion = opts.serverVersion ?? '1.0.0';

    /** @type {Map<string, McpTool>} */
    this._tools     = new Map();

    /** @type {Map<string, McpResource>} */
    this._resources = new Map();

    /** @type {Map<string, McpPrompt>} */
    this._prompts   = new Map();

    /** @type {object|null} MCP Server instance (set when SDK is available) */
    this._server = null;

    this._tryInitSdk(opts.capabilities);
  }

  // ─── SDK Initialization ──────────────────────────────────────────────────────

  /**
   * @private Attempt to load the MCP SDK and create the server.
   * Falls back to a lightweight stub if the package is not installed.
   *
   * @param {object} [capabilities]
   */
  _tryInitSdk(capabilities) {
    try {
      const { Server }           = require('@modelcontextprotocol/sdk/server/index.js');
      const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
      const { CallToolRequestSchema, ListToolsRequestSchema,
              ListResourcesRequestSchema, ReadResourceRequestSchema,
              ListPromptsRequestSchema, GetPromptRequestSchema } =
        require('@modelcontextprotocol/sdk/types.js');

      const server = new Server(
        { name: this.serverName, version: this.serverVersion },
        { capabilities: capabilities ?? { tools: {}, resources: {}, prompts: {} } },
      );

      // ── Tools ──────────────────────────────────────────────────────────────
      server.setRequestHandler(ListToolsRequestSchema, async () => ({
        tools: Array.from(this._tools.values()).map((t) => ({
          name:        t.name,
          description: t.description,
          inputSchema: t.inputSchema,
        })),
      }));

      server.setRequestHandler(CallToolRequestSchema, async (req) => {
        const tool = this._tools.get(req.params.name);
        if (!tool) return errorResponse(`Unknown tool: ${req.params.name}`);
        try {
          const result = await tool.handler(req.params.arguments ?? {});
          this.emit('toolCall', { tool: req.params.name, ts: Date.now() });
          return result;
        } catch (err) {
          return errorResponse(err.message);
        }
      });

      // ── Resources ──────────────────────────────────────────────────────────
      server.setRequestHandler(ListResourcesRequestSchema, async () => ({
        resources: Array.from(this._resources.values()).map((r) => ({
          uri:      r.uri,
          name:     r.name,
          mimeType: r.mimeType ?? 'application/json',
        })),
      }));

      server.setRequestHandler(ReadResourceRequestSchema, async (req) => {
        const resource = this._resources.get(req.params.uri);
        if (!resource) return { contents: [] };
        try {
          const data = await resource.read();
          return {
            contents: [{
              uri:      req.params.uri,
              mimeType: resource.mimeType ?? 'application/json',
              text:     typeof data === 'string' ? data : JSON.stringify(data),
            }],
          };
        } catch (err) {
          return { contents: [], error: err.message };
        }
      });

      // ── Prompts ────────────────────────────────────────────────────────────
      server.setRequestHandler(ListPromptsRequestSchema, async () => ({
        prompts: Array.from(this._prompts.values()).map((p) => ({
          name:        p.name,
          description: p.description ?? '',
          arguments:   p.arguments   ?? [],
        })),
      }));

      server.setRequestHandler(GetPromptRequestSchema, async (req) => {
        const prompt = this._prompts.get(req.params.name);
        if (!prompt) return { messages: [] };
        try {
          return await prompt.render(req.params.arguments ?? {});
        } catch (err) {
          return { messages: [{ role: 'user', content: { type: 'text', text: `Error: ${err.message}` } }] };
        }
      });

      this._server = server;
      this._StdioServerTransport = StdioServerTransport;
      this.emit('sdkLoaded', { ts: Date.now() });
    } catch (_) {
      // SDK not installed — use stub server
      this._server = null;
      this.emit('sdkMissing', { ts: Date.now(), message: 'Install @modelcontextprotocol/sdk to enable MCP' });
    }
  }

  // ─── Tool/Resource/Prompt Registration ──────────────────────────────────────

  /**
   * Register an MCP tool.
   *
   * @param {McpTool} tool
   */
  registerTool(tool) {
    if (!tool.name || !tool.handler) {
      throw new TypeError('McpBee.registerTool: tool must have name and handler');
    }
    this._tools.set(tool.name, tool);
    this.emit('toolRegistered', { name: tool.name });
  }

  /**
   * Register an MCP resource.
   *
   * @param {McpResource} resource
   */
  registerResource(resource) {
    if (!resource.uri || !resource.read) {
      throw new TypeError('McpBee.registerResource: resource must have uri and read()');
    }
    this._resources.set(resource.uri, resource);
    this.emit('resourceRegistered', { uri: resource.uri });
  }

  /**
   * Register an MCP prompt template.
   *
   * @param {McpPrompt} prompt
   */
  registerPrompt(prompt) {
    if (!prompt.name || !prompt.render) {
      throw new TypeError('McpBee.registerPrompt: prompt must have name and render()');
    }
    this._prompts.set(prompt.name, prompt);
    this.emit('promptRegistered', { name: prompt.name });
  }

  // ─── Transport ───────────────────────────────────────────────────────────────

  /**
   * Connect the MCP server to a stdio transport (for CLI / subprocess use).
   *
   * @returns {Promise<void>}
   */
  async connectStdio() {
    if (!this._server || !this._StdioServerTransport) {
      throw new Error('MCP SDK not loaded — cannot connect stdio transport');
    }
    const transport = new this._StdioServerTransport();
    await this._server.connect(transport);
    this.emit('connected', { transport: 'stdio' });
  }

  /**
   * Create an Express SSE handler for MCP streaming.
   * Requires the SSE transport from @modelcontextprotocol/sdk.
   *
   * @returns {Function} Express (req, res) => void
   */
  sseHandler() {
    return async (req, res) => {
      if (!this._server) {
        return res.status(503).json({ error: 'MCP SDK not loaded' });
      }

      try {
        const { SSEServerTransport } = require('@modelcontextprotocol/sdk/server/sse.js');
        const transport = new SSEServerTransport('/mcp/rpc', res);
        await this._server.connect(transport);
        this.emit('connected', { transport: 'sse', ts: Date.now() });
      } catch (err) {
        if (!res.headersSent) {
          res.status(500).json({ error: err.message });
        }
      }
    };
  }

  /**
   * Create an Express JSON-RPC POST handler for MCP messages.
   *
   * @returns {Function} Express (req, res) => void
   */
  rpcHandler() {
    return async (req, res) => {
      if (!this._server) {
        return res.status(503).json({ error: 'MCP SDK not loaded' });
      }

      try {
        // Delegate to active SSE transport if available, otherwise return capability listing
        res.json({
          jsonrpc: '2.0',
          result: {
            serverInfo: { name: this.serverName, version: this.serverVersion },
            tools:      Array.from(this._tools.keys()),
            resources:  Array.from(this._resources.keys()),
            prompts:    Array.from(this._prompts.keys()),
          },
          id: req.body?.id ?? null,
        });
      } catch (err) {
        res.status(500).json({ jsonrpc: '2.0', error: { code: -32603, message: err.message } });
      }
    };
  }

  // ─── Introspection ───────────────────────────────────────────────────────────

  /**
   * Return registry summary.
   *
   * @returns {{ tools: string[], resources: string[], prompts: string[], sdkLoaded: boolean }}
   */
  getStatus() {
    return {
      serverName:    this.serverName,
      serverVersion: this.serverVersion,
      sdkLoaded:     this._server !== null,
      tools:         Array.from(this._tools.keys()),
      resources:     Array.from(this._resources.keys()),
      prompts:       Array.from(this._prompts.keys()),
    };
  }
}

module.exports = {
  McpBee,
  textContent,
  errorResponse,
  domain: 'mcp',
  tasks:  ['registerTool', 'registerResource', 'registerPrompt', 'connectStdio', 'sseHandler', 'rpcHandler'],
};
