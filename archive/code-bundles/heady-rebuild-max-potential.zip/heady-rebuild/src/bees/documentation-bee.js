/**
 * @file documentation-bee.js
 * @description Auto-documentation generator bee — scans source files for JSDoc
 *              comments, generates API documentation, and produces system topology
 *              Markdown output.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const fs   = require('fs');
const path = require('path');

const PHI = 1.6180339887;

// ─── JSDoc Parser ────────────────────────────────────────────────────────────

/**
 * Extract all JSDoc comment blocks from source text.
 *
 * @param {string} source
 * @returns {string[]} Array of raw JSDoc strings (/** ... *\/)
 */
function extractJsDocBlocks(source) {
  const blocks = [];
  const re     = /\/\*\*([\s\S]*?)\*\//g;
  let match;
  while ((match = re.exec(source)) !== null) {
    blocks.push(match[0]);
  }
  return blocks;
}

/**
 * Parse a JSDoc block into structured tags.
 *
 * @param {string} block
 * @returns {{ description: string, tags: Array<{ tag: string, value: string }> }}
 */
function parseJsDocBlock(block) {
  // Strip /** ... */ delimiters and leading * from each line
  const cleaned = block
    .replace(/^\/\*\*\s?/, '')
    .replace(/\s*\*\/$/, '')
    .replace(/^\s*\*\s?/gm, '')
    .trim();

  const lines       = cleaned.split('\n');
  const descLines   = [];
  const tags        = [];
  let inTag         = false;
  let currentTag    = null;

  for (const line of lines) {
    const tagMatch = line.match(/^@(\w+)\s*(.*)/);
    if (tagMatch) {
      if (currentTag) tags.push(currentTag);
      currentTag = { tag: tagMatch[1], value: tagMatch[2].trim() };
      inTag = true;
    } else if (inTag && currentTag) {
      currentTag.value += ' ' + line.trim();
    } else {
      descLines.push(line);
    }
  }

  if (currentTag) tags.push(currentTag);

  return { description: descLines.join('\n').trim(), tags };
}

// ─── File Scanner ────────────────────────────────────────────────────────────

/**
 * Scan a single .js file and extract its documentation items.
 *
 * @param {string} filePath
 * @returns {{ file: string, items: Array<{ description: string, tags: object[] }> }}
 */
function scanFile(filePath) {
  let source;
  try {
    source = fs.readFileSync(filePath, 'utf8');
  } catch (_) {
    return { file: filePath, items: [] };
  }

  const blocks = extractJsDocBlocks(source);
  const items  = blocks.map(parseJsDocBlock).filter((b) => b.description || b.tags.length);

  return { file: filePath, items };
}

/**
 * Recursively scan a directory for .js files (excluding node_modules).
 *
 * @param {string} dir
 * @param {string[]} [acc=[]]
 * @returns {string[]} Absolute file paths
 */
function collectJsFiles(dir, acc = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch (_) {
    return acc;
  }

  for (const entry of entries) {
    if (entry.name === 'node_modules' || entry.name.startsWith('.')) continue;
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      collectJsFiles(fullPath, acc);
    } else if (entry.isFile() && entry.name.endsWith('.js')) {
      acc.push(fullPath);
    }
  }

  return acc;
}

// ─── Markdown Renderers ──────────────────────────────────────────────────────

/**
 * Render an API documentation block as Markdown.
 *
 * @param {{ file: string, items: object[] }} scanResult
 * @param {string} [baseDir] - Strip from file path prefix
 * @returns {string}
 */
function renderApiMarkdown(scanResult, baseDir) {
  const relPath = baseDir
    ? path.relative(baseDir, scanResult.file)
    : scanResult.file;

  const lines = [`## \`${relPath}\`\n`];

  for (const item of scanResult.items) {
    if (item.description) {
      lines.push(item.description + '\n');
    }

    const params   = item.tags.filter((t) => t.tag === 'param');
    const returns  = item.tags.find((t)  => t.tag === 'returns' || t.tag === 'return');
    const examples = item.tags.filter((t) => t.tag === 'example');
    const throwsTags = item.tags.filter((t) => t.tag === 'throws');

    if (params.length) {
      lines.push('**Parameters:**\n');
      lines.push('| Name | Description |');
      lines.push('|------|-------------|');
      for (const p of params) {
        lines.push(`| \`${p.value.split(/\s+/)[0]}\` | ${p.value.split(/\s+/).slice(1).join(' ')} |`);
      }
      lines.push('');
    }

    if (returns) {
      lines.push(`**Returns:** ${returns.value}\n`);
    }

    if (throwsTags.length) {
      lines.push('**Throws:**\n');
      for (const t of throwsTags) {
        lines.push(`- ${t.value}`);
      }
      lines.push('');
    }

    if (examples.length) {
      lines.push('**Example:**\n');
      for (const e of examples) {
        lines.push('```js');
        lines.push(e.value);
        lines.push('```\n');
      }
    }

    lines.push('---\n');
  }

  return lines.join('\n');
}

/**
 * Render a system topology document as Markdown.
 *
 * @param {Array<{ file: string, items: object[] }>} scanResults
 * @param {object}  [opts]
 * @param {string}  [opts.title]
 * @param {string}  [opts.baseDir]
 * @returns {string}
 */
function renderTopologyMarkdown(scanResults, opts = {}) {
  const title   = opts.title   ?? 'System Topology';
  const baseDir = opts.baseDir ?? null;

  const lines = [
    `# ${title}`,
    '',
    `_Generated by DocumentationBee — ${new Date().toISOString()}_`,
    '',
    '## Module Overview',
    '',
    '| Module | Items Documented |',
    '|--------|-----------------|',
  ];

  for (const r of scanResults) {
    const rel = baseDir ? path.relative(baseDir, r.file) : r.file;
    lines.push(`| \`${rel}\` | ${r.items.length} |`);
  }

  lines.push('');
  lines.push('## Module Details');
  lines.push('');

  for (const r of scanResults) {
    if (r.items.length === 0) continue;
    lines.push(renderApiMarkdown(r, baseDir));
  }

  return lines.join('\n');
}

// ─── Documentation Bee ───────────────────────────────────────────────────────

/**
 * @class DocumentationBee
 *
 * @example
 * const bee = new DocumentationBee({ baseDir: './src' });
 * const md  = await bee.generateApiDocs('./src/resilience');
 * fs.writeFileSync('./docs/resilience.md', md);
 */
class DocumentationBee {
  /**
   * @param {object} [opts]
   * @param {string} [opts.baseDir]    - Root directory for relative paths in output
   * @param {string} [opts.outputDir]  - Directory to write generated docs (optional)
   */
  constructor(opts = {}) {
    this.baseDir   = opts.baseDir   ?? null;
    this.outputDir = opts.outputDir ?? null;
  }

  /**
   * Scan a directory and generate API documentation Markdown.
   *
   * @param {string} dir
   * @param {object} [opts]
   * @param {string} [opts.title]
   * @param {string} [opts.outputFile] - Filename (within outputDir) to write
   * @returns {Promise<string>} Markdown content
   */
  async generateApiDocs(dir, opts = {}) {
    const files   = collectJsFiles(dir);
    const results = files.map((f) => scanFile(f));
    const md      = renderTopologyMarkdown(results, {
      title:   opts.title   ?? `API Documentation — ${path.basename(dir)}`,
      baseDir: this.baseDir ?? dir,
    });

    if (this.outputDir && opts.outputFile) {
      try {
        fs.mkdirSync(this.outputDir, { recursive: true });
        fs.writeFileSync(path.join(this.outputDir, opts.outputFile), md, 'utf8');
      } catch (_) {}
    }

    return md;
  }

  /**
   * Generate a system topology document spanning multiple directories.
   *
   * @param {string[]} dirs
   * @param {object}   [opts]
   * @param {string}   [opts.title]
   * @param {string}   [opts.outputFile]
   * @returns {Promise<string>}
   */
  async generateTopology(dirs, opts = {}) {
    const allResults = [];
    for (const dir of dirs) {
      const files = collectJsFiles(dir);
      for (const f of files) {
        allResults.push(scanFile(f));
      }
    }

    const md = renderTopologyMarkdown(allResults, {
      title:   opts.title ?? 'System Topology',
      baseDir: this.baseDir,
    });

    if (this.outputDir && opts.outputFile) {
      try {
        fs.mkdirSync(this.outputDir, { recursive: true });
        fs.writeFileSync(path.join(this.outputDir, opts.outputFile), md, 'utf8');
      } catch (_) {}
    }

    return md;
  }

  /**
   * Scan and return structured documentation for a single file.
   *
   * @param {string} filePath
   * @returns {{ file: string, items: object[] }}
   */
  scanFile(filePath) {
    return scanFile(filePath);
  }
}

module.exports = {
  DocumentationBee,
  scanFile,
  collectJsFiles,
  extractJsDocBlocks,
  parseJsDocBlock,
  renderApiMarkdown,
  renderTopologyMarkdown,
  domain: 'documentation',
  tasks:  ['generateApiDocs', 'generateTopology', 'scanFile'],
};
