/**
 * @file bee-factory.js
 * @description BeeFactory — dynamically creates bee domain modules, spawns
 *              ephemeral single-purpose bees, and manages discovery of active bees.
 *
 * A "bee" is a focused, single-domain service object with a standardised shape:
 *   { id, domain, tasks, handlers, meta, createdAt }
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const crypto = require('crypto');
const fs     = require('fs');
const path   = require('path');

const PHI = 1.6180339887;

/**
 * Generate a unique bee ID.
 *
 * @param {string} domain
 * @returns {string} e.g. "bee_analytics_a3f9c2d1"
 */
function generateBeeId(domain) {
  const rand = crypto.randomBytes(4).toString('hex');
  return `bee_${domain.replace(/[^a-z0-9]/gi, '_').toLowerCase()}_${rand}`;
}

/**
 * Default bee config skeleton.
 *
 * @returns {object}
 */
function defaultMeta() {
  return {
    version:   '1.0.0',
    createdAt: Date.now(),
    phi:       PHI,
  };
}

/**
 * @class BeeFactory
 *
 * @example
 * const factory = new BeeFactory({ outputDir: './src/bees/generated' });
 *
 * // Create a full domain bee
 * const analyticsBee = factory.createBee('analytics', {
 *   tasks: ['trackEvent', 'summarizeSession'],
 *   handlers: {
 *     trackEvent: async (payload) => { ... },
 *     summarizeSession: async (id) => { ... },
 *   },
 * });
 *
 * // Ephemeral single-purpose bee
 * const emailBee = factory.spawnBee('sendWelcomeEmail', async (data) => {
 *   await mailer.send(data);
 * });
 */
class BeeFactory {
  /**
   * @param {object}  [opts]
   * @param {string}  [opts.outputDir]  - Directory to write persisted bee files
   * @param {boolean} [opts.persist]    - Write generated bees to outputDir by default
   */
  constructor(opts = {}) {
    this.outputDir     = opts.outputDir ?? null;
    this.persistDefault = opts.persist  ?? false;

    /** @type {Map<string, object>} Active bees keyed by bee.id */
    this._bees = new Map();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Create a full bee domain.
   *
   * @param {string}  domain                     - Bee domain name (e.g. 'analytics')
   * @param {object}  [config]                   - Bee configuration
   * @param {string[]}  [config.tasks=[]]        - Task names this bee handles
   * @param {object}    [config.handlers={}]     - { taskName: async fn } map
   * @param {object}    [config.meta={}]         - Additional metadata
   * @param {boolean}   [config.persist]         - Override factory-level persist setting
   * @returns {object} The constructed bee
   */
  createBee(domain, config = {}) {
    if (!domain || typeof domain !== 'string') {
      throw new TypeError('BeeFactory.createBee: domain must be a non-empty string');
    }

    const id = generateBeeId(domain);
    const bee = {
      id,
      domain,
      tasks:     config.tasks    ?? [],
      handlers:  config.handlers ?? {},
      meta:      { ...defaultMeta(), ...(config.meta ?? {}) },
      createdAt: Date.now(),

      /**
       * Execute a handler by task name.
       *
       * @param {string} task
       * @param {...*}   args
       * @returns {Promise<*>}
       */
      run: async (task, ...args) => {
        const handler = bee.handlers[task];
        if (typeof handler !== 'function') {
          throw new Error(`Bee "${domain}" has no handler for task "${task}"`);
        }
        return handler(...args);
      },
    };

    this._bees.set(id, bee);

    const shouldPersist = config.persist ?? this.persistDefault;
    if (shouldPersist && this.outputDir) {
      this._writeBeeFile(bee, config);
    }

    return bee;
  }

  /**
   * Spawn a single-purpose ephemeral bee for one task.
   *
   * @param {string}   taskName - The task this bee performs
   * @param {Function} fn       - Async handler function
   * @param {object}   [opts]
   * @param {boolean}  [opts.persist] - Write to disk
   * @returns {object} Ephemeral bee
   */
  spawnBee(taskName, fn, opts = {}) {
    if (typeof fn !== 'function') {
      throw new TypeError('BeeFactory.spawnBee: fn must be a function');
    }

    return this.createBee(`ephemeral_${taskName}`, {
      tasks:    [taskName],
      handlers: { [taskName]: fn },
      meta:     { ephemeral: true },
      persist:  opts.persist ?? false,
    });
  }

  /**
   * Retrieve a bee by ID or domain name.
   *
   * @param {string} idOrDomain
   * @returns {object|undefined}
   */
  getBee(idOrDomain) {
    // Try direct ID lookup first
    if (this._bees.has(idOrDomain)) return this._bees.get(idOrDomain);

    // Search by domain
    for (const bee of this._bees.values()) {
      if (bee.domain === idOrDomain) return bee;
    }

    return undefined;
  }

  /**
   * List all active bees.
   *
   * @returns {object[]}
   */
  listBees() {
    return Array.from(this._bees.values()).map((b) => ({
      id:        b.id,
      domain:    b.domain,
      tasks:     b.tasks,
      createdAt: b.createdAt,
      meta:      b.meta,
    }));
  }

  /**
   * Destroy (remove) a bee by ID.
   *
   * @param {string} id
   * @returns {boolean} true if removed
   */
  destroyBee(id) {
    return this._bees.delete(id);
  }

  // ─── Persistence ─────────────────────────────────────────────────────────────

  /**
   * Write a bee definition to disk as a .js module.
   *
   * @private
   * @param {object} bee
   * @param {object} config
   */
  _writeBeeFile(bee, config) {
    if (!this.outputDir) return;

    try {
      fs.mkdirSync(this.outputDir, { recursive: true });

      const fileName  = `${bee.domain.replace(/[^a-z0-9_\-]/gi, '_')}-bee.js`;
      const filePath  = path.join(this.outputDir, fileName);

      const taskList  = bee.tasks.map((t) => `'${t}'`).join(', ');
      const handlerEntries = Object.keys(config.handlers ?? {})
        .map((k) => `  ${k}: async (...args) => { /* TODO: implement ${k} */ },`)
        .join('\n');

      const content = [
        `/**`,
        ` * @file ${fileName}`,
        ` * @description Auto-generated bee for domain: ${bee.domain}`,
        ` * @beeId ${bee.id}`,
        ` *`,
        ` * © 2026 HeadySystems Inc. All rights reserved.`,
        ` */`,
        `'use strict';`,
        ``,
        `const PHI = ${PHI};`,
        ``,
        `module.exports = {`,
        `  id:     '${bee.id}',`,
        `  domain: '${bee.domain}',`,
        `  tasks:  [${taskList}],`,
        `  meta:   ${JSON.stringify(bee.meta, null, 2).replace(/\n/g, '\n  ')},`,
        `  handlers: {`,
        handlerEntries,
        `  },`,
        `};`,
      ].join('\n');

      fs.writeFileSync(filePath, content, 'utf8');
    } catch (_) {
      // Non-fatal: persist failure should not crash bee creation
    }
  }
}

module.exports = { BeeFactory, generateBeeId };
