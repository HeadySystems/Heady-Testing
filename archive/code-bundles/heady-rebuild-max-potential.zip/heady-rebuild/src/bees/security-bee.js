/**
 * @file security-bee.js
 * @description Security governance bee — input validation, rate-limit enforcement,
 *              token verification, audit trail logging, and injection detection.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const crypto = require('crypto');
const { EventEmitter } = require('events');

const PHI = 1.6180339887;

// ─── Injection Pattern Library ───────────────────────────────────────────────

const INJECTION_PATTERNS = {
  sqlInjection: [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION|CAST|CONVERT)\b)/i,
    /('|\"|;|--|\bOR\b\s+\d+=\d+|\bAND\b\s+\d+=\d+)/i,
    /\bWAITFOR\b|\bSLEEP\b|\bBENCHMARK\b/i,
  ],
  xss: [
    /<script[\s\S]*?>[\s\S]*?<\/script>/i,
    /javascript\s*:/i,
    /on\w+\s*=\s*["']?[^"'>]*/i,
    /<\s*iframe|<\s*object|<\s*embed/i,
  ],
  pathTraversal: [
    /\.\.[/\\]/,
    /%2e%2e[%2f%5c]/i,
    /\.\.%2f|\.\.%5c/i,
  ],
  commandInjection: [
    /[;&|`$(){}[\]]/,
    /\$\(|`[^`]*`/,
  ],
  ldapInjection: [
    /[*()\\|&]/,
  ],
};

/**
 * Scan a string for injection patterns.
 *
 * @param {string} value
 * @returns {{ detected: boolean, types: string[] }}
 */
function detectInjection(value) {
  const types = [];
  for (const [type, patterns] of Object.entries(INJECTION_PATTERNS)) {
    if (patterns.some((p) => p.test(value))) types.push(type);
  }
  return { detected: types.length > 0, types };
}

// ─── Input Validator ─────────────────────────────────────────────────────────

/**
 * Validate an object against a simple schema.
 *
 * Schema format: { fieldName: { type, required, maxLength, pattern } }
 *
 * @param {object} data
 * @param {object} schema
 * @returns {{ valid: boolean, errors: string[] }}
 */
function validateInput(data, schema) {
  const errors = [];

  for (const [field, rules] of Object.entries(schema)) {
    const value = data[field];

    if (rules.required && (value === undefined || value === null || value === '')) {
      errors.push(`${field} is required`);
      continue;
    }

    if (value === undefined || value === null) continue;

    if (rules.type && typeof value !== rules.type) {
      errors.push(`${field} must be of type ${rules.type}`);
    }

    if (rules.maxLength && typeof value === 'string' && value.length > rules.maxLength) {
      errors.push(`${field} exceeds maxLength of ${rules.maxLength}`);
    }

    if (rules.pattern && !rules.pattern.test(String(value))) {
      errors.push(`${field} does not match required pattern`);
    }

    // Injection check on string fields
    if (typeof value === 'string') {
      const { detected, types } = detectInjection(value);
      if (detected) {
        errors.push(`${field} contains potential injection (${types.join(', ')})`);
      }
    }
  }

  return { valid: errors.length === 0, errors };
}

// ─── Audit Logger ────────────────────────────────────────────────────────────

/**
 * @class AuditLog
 * Append-only in-memory audit trail with optional emit hook.
 */
class AuditLog {
  /**
   * @param {object}   [opts]
   * @param {number}   [opts.maxEntries=10000]
   * @param {Function} [opts.onEntry] - Called with each AuditEntry when appended
   */
  constructor(opts = {}) {
    this.maxEntries = opts.maxEntries ?? 10_000;
    this.onEntry    = opts.onEntry    ?? null;

    /** @type {Array<{ id: string, ts: number, event: string, actor: string, data: object, risk: string }>} */
    this._entries = [];
  }

  /**
   * Append an audit entry.
   *
   * @param {object} entry
   * @param {string} entry.event  - Event type (e.g. 'auth.login', 'security.injection_detected')
   * @param {string} [entry.actor] - Who performed the action
   * @param {object} [entry.data]  - Contextual data
   * @param {string} [entry.risk]  - 'low'|'medium'|'high'|'critical'
   */
  append(entry) {
    const record = {
      id:    crypto.randomBytes(8).toString('hex'),
      ts:    Date.now(),
      event: entry.event,
      actor: entry.actor ?? 'unknown',
      data:  entry.data  ?? {},
      risk:  entry.risk  ?? 'low',
    };

    this._entries.push(record);
    if (this._entries.length > this.maxEntries) this._entries.shift();
    if (typeof this.onEntry === 'function') this.onEntry(record);
    return record.id;
  }

  /**
   * Query audit entries.
   *
   * @param {object} [filter]
   * @param {string} [filter.event]
   * @param {string} [filter.actor]
   * @param {string} [filter.risk]
   * @param {number} [filter.since] - Unix ms timestamp
   * @param {number} [limit=100]
   * @returns {object[]}
   */
  query(filter = {}, limit = 100) {
    let entries = this._entries;
    if (filter.event) entries = entries.filter((e) => e.event === filter.event);
    if (filter.actor) entries = entries.filter((e) => e.actor === filter.actor);
    if (filter.risk)  entries = entries.filter((e) => e.risk  === filter.risk);
    if (filter.since) entries = entries.filter((e) => e.ts >= filter.since);
    return entries.slice(-limit);
  }

  /** @returns {number} */
  get size() { return this._entries.length; }
}

// ─── Security Bee ────────────────────────────────────────────────────────────

/**
 * @class SecurityBee
 * @extends EventEmitter
 *
 * @example
 * const bee = new SecurityBee();
 *
 * // Express middleware
 * app.use(bee.middleware());
 *
 * // Manual validation
 * const { valid, errors } = bee.validate(req.body, mySchema);
 */
class SecurityBee extends EventEmitter {
  /**
   * @param {object} [opts]
   * @param {number} [opts.maxAuditEntries=10000]
   * @param {Function} [opts.tokenVerifier] - Async (token) => payload | null
   */
  constructor(opts = {}) {
    super();

    this.tokenVerifier = opts.tokenVerifier ?? null;
    this.audit = new AuditLog({
      maxEntries: opts.maxAuditEntries ?? 10_000,
      onEntry: (e) => {
        if (e.risk === 'high' || e.risk === 'critical') {
          this.emit('threat', e);
        }
      },
    });
  }

  // ─── Input Validation ───────────────────────────────────────────────────────

  /**
   * Validate and scan input data.
   *
   * @param {object} data
   * @param {object} schema
   * @param {string} [actor]
   * @returns {{ valid: boolean, errors: string[] }}
   */
  validate(data, schema, actor) {
    const result = validateInput(data, schema);

    this.audit.append({
      event: result.valid ? 'validation.pass' : 'validation.fail',
      actor,
      data:  { errors: result.errors, fields: Object.keys(data) },
      risk:  result.valid ? 'low' : 'medium',
    });

    return result;
  }

  // ─── Token Verification ─────────────────────────────────────────────────────

  /**
   * Verify a bearer token using the configured tokenVerifier.
   *
   * @param {string} token
   * @param {string} [actor]
   * @returns {Promise<{ valid: boolean, payload: *|null }>}
   */
  async verifyToken(token, actor) {
    if (!this.tokenVerifier) {
      return { valid: true, payload: null }; // pass-through if no verifier configured
    }

    try {
      const payload = await this.tokenVerifier(token);
      const valid   = payload != null;

      this.audit.append({
        event: valid ? 'auth.token_valid' : 'auth.token_invalid',
        actor,
        data:  { tokenPrefix: token?.slice(0, 8) },
        risk:  valid ? 'low' : 'high',
      });

      return { valid, payload: valid ? payload : null };
    } catch (err) {
      this.audit.append({
        event: 'auth.token_error',
        actor,
        data:  { error: err.message },
        risk:  'high',
      });
      return { valid: false, payload: null };
    }
  }

  // ─── Injection Detection ────────────────────────────────────────────────────

  /**
   * Scan a value for injection patterns.
   *
   * @param {string} value
   * @param {string} [field]
   * @param {string} [actor]
   * @returns {{ detected: boolean, types: string[] }}
   */
  scanInjection(value, field, actor) {
    const result = detectInjection(String(value));

    if (result.detected) {
      this.audit.append({
        event: 'security.injection_detected',
        actor,
        data:  { field, types: result.types, snippet: String(value).slice(0, 100) },
        risk:  'critical',
      });
      this.emit('injectionDetected', { field, types: result.types, actor });
    }

    return result;
  }

  // ─── Express Middleware ─────────────────────────────────────────────────────

  /**
   * Create an Express middleware that:
   *  1. Scans query params and body for injection
   *  2. Optionally verifies bearer token
   *  3. Logs to audit trail
   *
   * @param {object}  [mwOpts]
   * @param {boolean} [mwOpts.requireAuth=false]  - Reject requests without valid token
   * @param {boolean} [mwOpts.scanBody=true]       - Scan req.body for injections
   * @param {boolean} [mwOpts.scanQuery=true]      - Scan req.query for injections
   * @returns {Function} Express middleware
   */
  middleware(mwOpts = {}) {
    const requireAuth = mwOpts.requireAuth ?? false;
    const scanBody    = mwOpts.scanBody    ?? true;
    const scanQuery   = mwOpts.scanQuery   ?? true;

    return async (req, res, next) => {
      const actor = req.user?.id ?? req.ip ?? 'unknown';

      // Injection scanning
      if (scanQuery && req.query) {
        for (const [k, v] of Object.entries(req.query)) {
          if (typeof v === 'string') this.scanInjection(v, `query.${k}`, actor);
        }
      }

      if (scanBody && req.body && typeof req.body === 'object') {
        for (const [k, v] of Object.entries(req.body)) {
          if (typeof v === 'string') this.scanInjection(v, `body.${k}`, actor);
        }
      }

      // Token verification
      if (requireAuth || this.tokenVerifier) {
        const authHeader = req.headers?.authorization ?? '';
        const token      = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;

        if (!token) {
          if (requireAuth) {
            return res.status(401).json({ error: 'Unauthorized: missing token' });
          }
        } else {
          const { valid } = await this.verifyToken(token, actor);
          if (requireAuth && !valid) {
            return res.status(401).json({ error: 'Unauthorized: invalid token' });
          }
        }
      }

      this.audit.append({ event: 'request.processed', actor, risk: 'low' });
      next();
    };
  }

  /**
   * Get audit log entries.
   *
   * @param {object} [filter]
   * @param {number} [limit]
   * @returns {object[]}
   */
  getAuditLog(filter, limit) {
    return this.audit.query(filter, limit);
  }
}

module.exports = {
  SecurityBee,
  AuditLog,
  validateInput,
  detectInjection,
  INJECTION_PATTERNS,
  domain: 'security',
  tasks:  ['validate', 'verifyToken', 'scanInjection', 'middleware', 'getAuditLog'],
};
