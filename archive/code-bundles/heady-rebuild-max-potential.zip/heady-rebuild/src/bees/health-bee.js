/**
 * @file health-bee.js
 * @description Health monitoring bee — provides Kubernetes-compatible health
 *              probes (/healthz, /readyz, /livez), startup dependency checks,
 *              component health aggregation, and degraded-state detection.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const { EventEmitter } = require('events');

const PHI = 1.6180339887;

/** Probe status codes */
const STATUS = Object.freeze({
  UP:       'UP',
  DOWN:     'DOWN',
  DEGRADED: 'DEGRADED',
  STARTING: 'STARTING',
});

/**
 * @typedef {object} ComponentCheck
 * @property {string}   name          - Component name
 * @property {Function} check         - Async () => boolean
 * @property {boolean}  [critical]    - If true, DOWN → overall DOWN (else DEGRADED)
 * @property {string}   [description]
 */

/**
 * @class HealthBee
 * @extends EventEmitter
 *
 * Express integration:
 * @example
 * const bee = new HealthBee();
 * bee.register({ name: 'postgres', check: () => db.ping() });
 * app.get('/healthz', bee.middleware('live'));
 * app.get('/readyz',  bee.middleware('ready'));
 */
class HealthBee extends EventEmitter {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.startupTimeoutMs] - ms before startup probes time out (default PHI^7*1000 ≈ 29 s)
   * @param {boolean} [opts.cacheResults]     - Cache probe results for one poll cycle (default true)
   * @param {number}  [opts.cacheTtlMs]       - Cache TTL ms (default PHI^3*1000 ≈ 4237 ms)
   */
  constructor(opts = {}) {
    super();

    this.startupTimeoutMs = opts.startupTimeoutMs ?? Math.round(Math.pow(PHI, 7) * 1000);
    this.cacheResults     = opts.cacheResults     ?? true;
    this.cacheTtlMs       = opts.cacheTtlMs       ?? Math.round(Math.pow(PHI, 3) * 1000);

    /** @type {Map<string, ComponentCheck>} */
    this._components = new Map();

    /** @type {{ result: object, ts: number }|null} */
    this._cache = null;

    /** @type {number} */
    this._startedAt = Date.now();

    /** @type {boolean} Becomes true after startup checks pass */
    this._ready = false;
  }

  // ─── Component Registration ──────────────────────────────────────────────────

  /**
   * Register a component for health monitoring.
   *
   * @param {ComponentCheck} component
   */
  register(component) {
    if (!component.name || typeof component.check !== 'function') {
      throw new TypeError('HealthBee.register: component must have name and check()');
    }
    this._components.set(component.name, component);
  }

  /**
   * Unregister a component.
   *
   * @param {string} name
   */
  unregister(name) {
    this._components.delete(name);
  }

  // ─── Probes ──────────────────────────────────────────────────────────────────

  /**
   * Liveness probe — is the process alive and not deadlocked?
   * Always returns UP unless a critical component is DOWN.
   *
   * @returns {Promise<{ status: string, ts: number }>}
   */
  async live() {
    const result = await this._aggregate();
    return {
      status: result.criticalDown ? STATUS.DOWN : STATUS.UP,
      ts:     Date.now(),
    };
  }

  /**
   * Readiness probe — is the service ready to receive traffic?
   * Returns UP only when all critical components are UP and startup has completed.
   *
   * @returns {Promise<{ status: string, components: object, ts: number }>}
   */
  async ready() {
    const result = await this._aggregate();
    const ready  = !result.criticalDown && this._ready;

    return {
      status:     ready ? STATUS.UP : STATUS.DOWN,
      components: result.components,
      ts:         Date.now(),
    };
  }

  /**
   * Health probe — full component breakdown for monitoring dashboards.
   *
   * @returns {Promise<{ status: string, components: object, summary: object, ts: number }>}
   */
  async health() {
    const result = await this._aggregate();

    let overall;
    if (result.criticalDown)  overall = STATUS.DOWN;
    else if (result.degraded) overall = STATUS.DEGRADED;
    else                      overall = STATUS.UP;

    this.emit('health', { status: overall, ts: Date.now() });

    return {
      status:     overall,
      components: result.components,
      summary: {
        total:    result.total,
        up:       result.up,
        down:     result.down,
        degraded: result.degraded ? 1 : 0,
      },
      ts: Date.now(),
    };
  }

  /**
   * Startup probe — runs once at process start to verify all dependencies.
   * Sets _ready = true on success.
   *
   * @returns {Promise<{ status: string, elapsed: number }>}
   */
  async startup() {
    const elapsed = Date.now() - this._startedAt;

    if (elapsed > this.startupTimeoutMs) {
      return { status: STATUS.DOWN, elapsed, reason: 'Startup timeout exceeded' };
    }

    const result = await this._aggregate();
    if (!result.criticalDown) {
      this._ready = true;
      this.emit('ready', { elapsed });
      return { status: STATUS.UP, elapsed };
    }

    return { status: STATUS.STARTING, elapsed, components: result.components };
  }

  // ─── Express Middleware ───────────────────────────────────────────────────────

  /**
   * Create an Express handler for a named probe.
   *
   * @param {'live'|'ready'|'health'|'startup'} probe
   * @returns {Function} (req, res) => void
   */
  middleware(probe = 'health') {
    const probeMap = {
      live:    () => this.live(),
      ready:   () => this.ready(),
      health:  () => this.health(),
      startup: () => this.startup(),
    };

    const fn = probeMap[probe];
    if (!fn) throw new TypeError(`HealthBee.middleware: unknown probe "${probe}"`);

    return async (req, res) => {
      try {
        const result = await fn();
        const code   = result.status === STATUS.UP ? 200
          : result.status === STATUS.DEGRADED       ? 207
          : 503;
        res.status(code).json(result);
      } catch (err) {
        res.status(500).json({ status: STATUS.DOWN, error: err.message });
      }
    };
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Run all component checks, optionally returning cached result.
   */
  async _aggregate() {
    if (this.cacheResults && this._cache) {
      if (Date.now() - this._cache.ts < this.cacheTtlMs) {
        return this._cache.result;
      }
    }

    const checks = Array.from(this._components.values()).map(async (c) => {
      let up = false;
      let error;
      try {
        up = !!(await c.check());
      } catch (err) {
        error = err.message;
      }
      return { name: c.name, up, critical: c.critical ?? true, error };
    });

    const results = await Promise.allSettled(checks);
    const components = {};
    let total       = 0;
    let up          = 0;
    let criticalDown = false;
    let degraded     = false;

    for (const r of results) {
      if (r.status !== 'fulfilled') continue;
      const c = r.value;
      total++;
      components[c.name] = { status: c.up ? STATUS.UP : STATUS.DOWN, error: c.error };
      if (c.up) {
        up++;
      } else {
        if (c.critical) criticalDown = true;
        else            degraded     = true;
      }
    }

    const result = { components, total, up, down: total - up, criticalDown, degraded };
    this._cache = { result, ts: Date.now() };
    return result;
  }
}

module.exports = {
  HealthBee,
  STATUS,
  domain:  'health',
  tasks:   ['live', 'ready', 'health', 'startup', 'register', 'middleware'],
};
