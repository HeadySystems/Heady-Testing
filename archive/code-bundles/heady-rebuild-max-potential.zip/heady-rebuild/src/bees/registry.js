/**
 * @file registry.js
 * @description BeeRegistry — auto-loads all *-bee.js files from a directory,
 *              provides register/find/list operations, and performs semantic
 *              task-to-bee matching using keyword overlap.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const fs   = require('fs');
const path = require('path');

const PHI = 1.6180339887;

/**
 * @typedef {object} BeeModule
 * @property {string}   id        - Unique bee ID
 * @property {string}   domain    - Domain name (e.g. 'health', 'security')
 * @property {string[]} tasks     - Task names this bee handles
 * @property {object}   [handlers]
 * @property {object}   [meta]
 */

/**
 * Tokenise a string for semantic matching — lowercase words, no punctuation.
 *
 * @param {string} text
 * @returns {string[]}
 */
function tokenise(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
}

/**
 * Compute keyword-overlap score between a query and a list of task strings.
 *
 * @param {string[]} queryTokens
 * @param {string[]} taskTokens
 * @returns {number} Score ≥ 0
 */
function overlapScore(queryTokens, taskTokens) {
  let score = 0;
  for (const qt of queryTokens) {
    for (const tt of taskTokens) {
      if (tt.includes(qt) || qt.includes(tt)) score++;
    }
  }
  return score;
}

/**
 * @class BeeRegistry
 *
 * @example
 * const registry = new BeeRegistry();
 * registry.autoLoad(path.join(__dirname, './'));
 *
 * const bee = registry.findBeeForTask('check service health');
 */
class BeeRegistry {
  constructor() {
    /** @type {Map<string, BeeModule>} keyed by domain */
    this._bees = new Map();
  }

  // ─── Registration ────────────────────────────────────────────────────────────

  /**
   * Register a single bee.
   *
   * @param {BeeModule} bee
   */
  register(bee) {
    if (!bee || !bee.domain) {
      throw new TypeError('BeeRegistry.register: bee must have a domain property');
    }
    this._bees.set(bee.domain, bee);
  }

  /**
   * Unregister a bee by domain.
   *
   * @param {string} domain
   * @returns {boolean}
   */
  unregister(domain) {
    return this._bees.delete(domain);
  }

  // ─── Auto-Load ───────────────────────────────────────────────────────────────

  /**
   * Scan a directory for *-bee.js files and register each one.
   *
   * @param {string} dir - Absolute path to scan
   * @returns {number} Number of bees loaded
   */
  autoLoad(dir) {
    let loaded = 0;

    let entries;
    try {
      entries = fs.readdirSync(dir);
    } catch (_) {
      return 0;
    }

    for (const entry of entries) {
      if (!entry.endsWith('-bee.js')) continue;

      const filePath = path.join(dir, entry);
      try {
        const bee = require(filePath);
        if (bee && bee.domain) {
          this.register(bee);
          loaded++;
        }
      } catch (_) {
        // Non-fatal: skip unloadable bee files
      }
    }

    return loaded;
  }

  // ─── Discovery ───────────────────────────────────────────────────────────────

  /**
   * Find the best-matching bee for a plain-language task description.
   * Uses keyword-overlap scoring across all registered bee task lists.
   *
   * @param {string} description - Natural-language task description
   * @returns {BeeModule|null} Best match, or null if no bees registered
   */
  findBeeForTask(description) {
    if (this._bees.size === 0) return null;

    const queryTokens = tokenise(description);

    let best       = null;
    let bestScore  = -1;

    for (const bee of this._bees.values()) {
      const allTasks   = [bee.domain, ...(bee.tasks ?? [])].join(' ');
      const taskTokens = tokenise(allTasks);
      const score      = overlapScore(queryTokens, taskTokens);

      // PHI-weighted: longer task lists get a small boost for breadth
      const phiBoost   = Math.log(1 + (bee.tasks?.length ?? 0)) * PHI * 0.1;
      const adjusted   = score + phiBoost;

      if (adjusted > bestScore) {
        bestScore = adjusted;
        best      = bee;
      }
    }

    return best;
  }

  /**
   * Get a bee by domain.
   *
   * @param {string} domain
   * @returns {BeeModule|undefined}
   */
  get(domain) {
    return this._bees.get(domain);
  }

  /**
   * Return all registered bees.
   *
   * @returns {BeeModule[]}
   */
  getAll() {
    return Array.from(this._bees.values());
  }

  /**
   * Return a summary catalog of registered bees.
   *
   * @returns {Array<{ domain: string, tasks: string[], id: string }>}
   */
  catalog() {
    return this.getAll().map((b) => ({
      id:     b.id     ?? b.domain,
      domain: b.domain,
      tasks:  b.tasks  ?? [],
    }));
  }

  /**
   * Number of registered bees.
   *
   * @returns {number}
   */
  get size() {
    return this._bees.size;
  }
}

module.exports = { BeeRegistry, tokenise, overlapScore };
