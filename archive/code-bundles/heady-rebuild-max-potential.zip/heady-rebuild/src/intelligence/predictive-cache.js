/**
 * @file predictive-cache.js
 * @description ML-informed predictive cache — tracks access patterns, predicts
 *              what will be needed next, and pre-warms the cache at PHI-derived
 *              intervals.
 *
 * Access pattern model:
 *  - Tracks sequential key co-occurrences (A → B)
 *  - Counts how often B is accessed after A
 *  - Prefetch candidates are the top-N successors of the most recently accessed key
 *
 * PHI-derived warming interval: PHI^4 * 1000 ≈ 6854 ms
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const PHI = 1.6180339887;

/** PHI^4 * 1000 ms — default prefetch interval */
const PREFETCH_INTERVAL_MS = Math.round(Math.pow(PHI, 4) * 1000);

/** PHI^9 * 1000 ms — default pattern TTL before decay */
const PATTERN_TTL_MS = Math.round(Math.pow(PHI, 9) * 1000);

/**
 * @class AccessPatternTracker
 * Tracks pairwise sequential key accesses to build a transition probability model.
 */
class AccessPatternTracker {
  /**
   * @param {object} [opts]
   * @param {number} [opts.maxPairs=5000] - Max co-occurrence pairs to track
   * @param {number} [opts.decayFactor]   - Multiplicative decay applied on each prune pass (default PHI^-1)
   */
  constructor(opts = {}) {
    this.maxPairs   = opts.maxPairs   ?? 5000;
    this.decayFactor = opts.decayFactor ?? (1 / PHI); // ~0.618

    /** @type {Map<string, Map<string, number>>} from-key → (to-key → count) */
    this._transitions = new Map();

    /** @type {string|null} Last accessed key */
    this._lastKey = null;
  }

  /**
   * Record a key access and update the transition model.
   *
   * @param {string} key
   */
  record(key) {
    if (this._lastKey && this._lastKey !== key) {
      this._increment(this._lastKey, key);
    }
    this._lastKey = key;
  }

  /**
   * Get predicted next keys for a given source key, sorted by probability.
   *
   * @param {string} key
   * @param {number} [topN=5]
   * @returns {Array<{ key: string, score: number }>}
   */
  predict(key, topN = 5) {
    const successors = this._transitions.get(key);
    if (!successors || successors.size === 0) return [];

    const total  = Array.from(successors.values()).reduce((s, v) => s + v, 0);
    const scored = Array.from(successors.entries())
      .map(([k, count]) => ({ key: k, score: count / total }))
      .sort((a, b) => b.score - a.score);

    return scored.slice(0, topN);
  }

  /**
   * Apply PHI-based decay to all counts, evicting low-count pairs.
   *
   * @param {number} [threshold=0.1] - Remove pairs with count below this after decay
   */
  decay(threshold = 0.1) {
    for (const [from, successors] of this._transitions) {
      for (const [to, count] of successors) {
        const decayed = count * this.decayFactor;
        if (decayed < threshold) {
          successors.delete(to);
        } else {
          successors.set(to, decayed);
        }
      }
      if (successors.size === 0) this._transitions.delete(from);
    }
  }

  /**
   * Total number of tracked transition pairs.
   *
   * @returns {number}
   */
  get size() {
    let n = 0;
    for (const s of this._transitions.values()) n += s.size;
    return n;
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private
   * @param {string} from
   * @param {string} to
   */
  _increment(from, to) {
    if (!this._transitions.has(from)) {
      this._transitions.set(from, new Map());
    }
    const m = this._transitions.get(from);
    m.set(to, (m.get(to) ?? 0) + 1);

    // Evict if over capacity
    if (this.size > this.maxPairs) this.decay();
  }
}

/**
 * @class PredictiveCache
 *
 * Wraps a backing cache (any object with get/set) and adds:
 *  - Access pattern tracking
 *  - Prefetch predictions
 *  - Periodic background warming
 *
 * @example
 * const cache = new PredictiveCache({
 *   backingCache:  myL1Cache,
 *   prefetchFn:    (key) => fetchFromSource(key),
 *   prefetchTopN:  3,
 * });
 *
 * cache.startWarming();
 * const value = await cache.get('user:42');
 */
class PredictiveCache {
  /**
   * @param {object}    opts
   * @param {object}    opts.backingCache           - Cache with get(key) / set(key, value)
   * @param {Function}  opts.prefetchFn             - Async (key) => value — fetches missing values
   * @param {number}    [opts.prefetchInterval]     - Warm interval in ms (default PHI^4*1000)
   * @param {number}    [opts.prefetchTopN=3]       - Predicted keys to prefetch per cycle
   * @param {number}    [opts.decayInterval]        - How often to decay patterns (default PHI^9*1000)
   */
  constructor(opts) {
    if (!opts.backingCache) throw new TypeError('PredictiveCache: opts.backingCache is required');
    if (typeof opts.prefetchFn !== 'function') throw new TypeError('PredictiveCache: opts.prefetchFn is required');

    this.backingCache      = opts.backingCache;
    this.prefetchFn        = opts.prefetchFn;
    this.prefetchInterval  = opts.prefetchInterval  ?? PREFETCH_INTERVAL_MS;
    this.prefetchTopN      = opts.prefetchTopN      ?? 3;
    this.decayInterval     = opts.decayInterval     ?? PATTERN_TTL_MS;

    this.tracker = new AccessPatternTracker();

    /** @type {{ prefetches: number, hits: number, misses: number }} */
    this._stats = { prefetches: 0, hits: 0, misses: 0 };

    /** @type {*|null} */
    this._warmTimer  = null;
    this._decayTimer = null;
  }

  // ─── Core ────────────────────────────────────────────────────────────────────

  /**
   * Get a value from the cache, record the access, and trigger predictions.
   *
   * @param {string} key
   * @returns {Promise<*>}
   */
  async get(key) {
    this.tracker.record(key);

    const cached = this.backingCache.get(key);
    if (cached !== undefined) {
      this._stats.hits++;
      this._schedulePrefetch(key);
      return cached;
    }

    this._stats.misses++;
    const value = await this.prefetchFn(key);
    if (value !== undefined) {
      this.backingCache.set(key, value);
    }
    return value;
  }

  /**
   * Explicitly set a value (pass-through to backing cache).
   *
   * @param {string} key
   * @param {*}      value
   * @param {*}      [...args] Additional args forwarded to backingCache.set
   */
  set(key, value, ...args) {
    this.backingCache.set(key, value, ...args);
  }

  // ─── Warming ─────────────────────────────────────────────────────────────────

  /**
   * Start periodic cache warming using predicted access patterns.
   */
  startWarming() {
    if (this._warmTimer) return;
    this._warmTimer = setInterval(() => this._warmCycle(), this.prefetchInterval);
    if (this._warmTimer.unref) this._warmTimer.unref();

    this._decayTimer = setInterval(() => this.tracker.decay(), this.decayInterval);
    if (this._decayTimer.unref) this._decayTimer.unref();
  }

  /** Stop background warming. */
  stopWarming() {
    if (this._warmTimer)  { clearInterval(this._warmTimer);  this._warmTimer  = null; }
    if (this._decayTimer) { clearInterval(this._decayTimer); this._decayTimer = null; }
  }

  /**
   * Get current stats.
   *
   * @returns {{ prefetches: number, hits: number, misses: number, patternPairs: number }}
   */
  stats() {
    return { ...this._stats, patternPairs: this.tracker.size };
  }

  /**
   * Return the top-N predictions for a given key without triggering a fetch.
   *
   * @param {string} key
   * @param {number} [topN]
   * @returns {Array<{ key: string, score: number }>}
   */
  predict(key, topN) {
    return this.tracker.predict(key, topN ?? this.prefetchTopN);
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Immediately prefetch predicted successors for a key.
   * @param {string} key
   */
  _schedulePrefetch(key) {
    const predictions = this.tracker.predict(key, this.prefetchTopN);
    for (const { key: pKey } of predictions) {
      if (this.backingCache.get(pKey) !== undefined) continue; // already cached
      this.prefetchFn(pKey)
        .then((value) => {
          if (value !== undefined) {
            this.backingCache.set(pKey, value);
            this._stats.prefetches++;
          }
        })
        .catch(() => {}); // non-fatal
    }
  }

  /**
   * @private Run a warming cycle — prefetch top predictions from recent accesses.
   */
  async _warmCycle() {
    const transitions = this.tracker._transitions;
    // Pick the top-3 most accessed source keys
    const topSources = Array.from(transitions.entries())
      .map(([k, m]) => ({ key: k, total: Array.from(m.values()).reduce((s, v) => s + v, 0) }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 3);

    for (const { key } of topSources) {
      this._schedulePrefetch(key);
    }
  }
}

module.exports = {
  PredictiveCache,
  AccessPatternTracker,
  PREFETCH_INTERVAL_MS,
  PATTERN_TTL_MS,
  PHI,
};
