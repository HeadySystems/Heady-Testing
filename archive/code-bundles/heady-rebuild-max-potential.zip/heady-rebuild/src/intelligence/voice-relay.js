/**
 * @file voice-relay.js
 * @description Voice I/O relay — manages WebSocket audio streams, chunks/buffers
 *              audio for transcription, relays transcription results back to clients,
 *              and handles multiple concurrent sessions.
 *
 * Architecture:
 *   Client WebSocket → VoiceRelay.handleConnection()
 *     → AudioBuffer (accumulates chunks)
 *     → TranscriptionRelay (sends to transcription backend)
 *     → Emits 'transcript' back to client
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const { EventEmitter } = require('events');
const crypto = require('crypto');

const PHI = 1.6180339887;

/** PHI^3 * 1000 ms — default chunk flush interval (~4237 ms) */
const DEFAULT_FLUSH_INTERVAL_MS = Math.round(Math.pow(PHI, 3) * 1000);

/** PHI^2 * 1000 bytes — default min chunk size before flush (~2618 bytes) */
const DEFAULT_MIN_CHUNK_BYTES = Math.round(Math.pow(PHI, 2) * 1000);

/** PHI^6 * 1000 ms — session idle timeout (~17944 ms) */
const DEFAULT_SESSION_TIMEOUT_MS = Math.round(Math.pow(PHI, 6) * 1000);

// ─── Audio Buffer ────────────────────────────────────────────────────────────

/**
 * @class AudioBuffer
 * Accumulates raw audio chunks (Buffer | Uint8Array) and flushes them
 * when the size threshold or time interval is reached.
 */
class AudioBuffer {
  /**
   * @param {object}   opts
   * @param {Function} opts.onFlush         - Async (chunk: Buffer) => void
   * @param {number}   [opts.minBytes]      - Minimum accumulated bytes before flush
   * @param {number}   [opts.flushInterval] - Max ms before forced flush
   */
  constructor(opts) {
    if (typeof opts.onFlush !== 'function') {
      throw new TypeError('AudioBuffer: opts.onFlush is required');
    }

    this.onFlush       = opts.onFlush;
    this.minBytes      = opts.minBytes      ?? DEFAULT_MIN_CHUNK_BYTES;
    this.flushInterval = opts.flushInterval ?? DEFAULT_FLUSH_INTERVAL_MS;

    /** @type {Buffer[]} */
    this._chunks = [];
    this._byteCount = 0;

    this._timer = setInterval(() => this._flush(), this.flushInterval);
    if (this._timer.unref) this._timer.unref();
  }

  /**
   * Append an audio chunk.
   *
   * @param {Buffer|Uint8Array|ArrayBuffer} data
   */
  push(data) {
    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data);
    this._chunks.push(buf);
    this._byteCount += buf.length;

    if (this._byteCount >= this.minBytes) {
      this._flush();
    }
  }

  /**
   * Flush immediately (e.g. on silence detection or end of utterance).
   */
  async forceFlush() {
    await this._flush();
  }

  /** Destroy the buffer and stop the flush timer. */
  destroy() {
    clearInterval(this._timer);
    this._chunks     = [];
    this._byteCount  = 0;
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /** @private */
  async _flush() {
    if (this._chunks.length === 0) return;

    const combined  = Buffer.concat(this._chunks);
    this._chunks    = [];
    this._byteCount = 0;

    try {
      await this.onFlush(combined);
    } catch (_) {
      // non-fatal: flush failure should not crash the session
    }
  }
}

// ─── Voice Session ───────────────────────────────────────────────────────────

/**
 * @class VoiceSession
 * Represents one active client voice connection.
 */
class VoiceSession {
  /**
   * @param {object}    opts
   * @param {string}    opts.id              - Session ID
   * @param {object}    opts.ws              - WebSocket instance
   * @param {Function}  opts.transcribeFn    - Async (audioChunk: Buffer) => string
   * @param {Function}  opts.onTranscript    - (sessionId, text) => void
   * @param {number}    [opts.idleTimeout]   - ms of silence before session considered idle
   */
  constructor(opts) {
    this.id            = opts.id;
    this.ws            = opts.ws;
    this.transcribeFn  = opts.transcribeFn;
    this.onTranscript  = opts.onTranscript;
    this.idleTimeout   = opts.idleTimeout ?? DEFAULT_SESSION_TIMEOUT_MS;

    this.createdAt = Date.now();
    this.lastActivity = Date.now();

    /** @type {number} Total bytes received */
    this.bytesReceived = 0;

    /** @type {number} Total transcription requests */
    this.transcriptions = 0;

    this._audioBuffer = new AudioBuffer({
      onFlush: (chunk) => this._transcribe(chunk),
    });

    this._idleTimer = setInterval(() => this._checkIdle(), this.idleTimeout);
    if (this._idleTimer.unref) this._idleTimer.unref();
  }

  /**
   * Process an incoming audio chunk.
   *
   * @param {Buffer|Uint8Array} data
   */
  receiveAudio(data) {
    this.lastActivity = Date.now();
    this.bytesReceived += data.length ?? 0;
    this._audioBuffer.push(data);
  }

  /**
   * Send a message to the WebSocket client.
   *
   * @param {object} payload
   */
  send(payload) {
    try {
      if (this.ws.readyState === 1 /* OPEN */) {
        this.ws.send(JSON.stringify(payload));
      }
    } catch (_) {}
  }

  /** Gracefully close the session. */
  close() {
    clearInterval(this._idleTimer);
    this._audioBuffer.destroy();
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /** @private Transcribe a flushed audio chunk. */
  async _transcribe(chunk) {
    if (chunk.length === 0) return;
    try {
      const text = await this.transcribeFn(chunk);
      if (text && text.trim()) {
        this.transcriptions++;
        this.send({ type: 'transcript', text, ts: Date.now() });
        this.onTranscript(this.id, text);
      }
    } catch (err) {
      this.send({ type: 'error', error: err.message });
    }
  }

  /** @private Close session if idle too long. */
  _checkIdle() {
    if (Date.now() - this.lastActivity > this.idleTimeout) {
      this.send({ type: 'idle_timeout' });
      this.close();
    }
  }
}

// ─── Voice Relay ─────────────────────────────────────────────────────────────

/**
 * @class VoiceRelay
 * @extends EventEmitter
 *
 * Manages multiple concurrent voice sessions over WebSocket.
 *
 * @example
 * const relay = new VoiceRelay({
 *   transcribeFn: async (audioChunk) => {
 *     const response = await fetch('https://api.transcription.example.com/v1/audio', {
 *       method: 'POST',
 *       body: audioChunk,
 *     });
 *     const data = await response.json();
 *     return data.text;
 *   },
 * });
 *
 * // With ws (WebSocket server):
 * wss.on('connection', (ws) => relay.handleConnection(ws));
 */
class VoiceRelay extends EventEmitter {
  /**
   * @param {object}    opts
   * @param {Function}  opts.transcribeFn          - Async (audioChunk: Buffer) => string
   * @param {number}    [opts.maxSessions=100]     - Max concurrent sessions
   * @param {number}    [opts.idleTimeout]         - Session idle timeout in ms
   */
  constructor(opts) {
    super();

    if (typeof opts.transcribeFn !== 'function') {
      throw new TypeError('VoiceRelay: opts.transcribeFn is required');
    }

    this.transcribeFn = opts.transcribeFn;
    this.maxSessions  = opts.maxSessions ?? 100;
    this.idleTimeout  = opts.idleTimeout ?? DEFAULT_SESSION_TIMEOUT_MS;

    /** @type {Map<string, VoiceSession>} */
    this._sessions = new Map();
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Handle an incoming WebSocket connection by creating a new VoiceSession.
   *
   * @param {object} ws          - WebSocket instance
   * @param {string} [sessionId] - Optional custom session ID
   * @returns {string} The session ID
   */
  handleConnection(ws, sessionId) {
    if (this._sessions.size >= this.maxSessions) {
      try { ws.close(1013, 'Maximum sessions reached'); } catch (_) {}
      this.emit('maxSessionsReached', { ts: Date.now() });
      return null;
    }

    const id = sessionId ?? crypto.randomBytes(8).toString('hex');

    const session = new VoiceSession({
      id,
      ws,
      transcribeFn: this.transcribeFn,
      idleTimeout:  this.idleTimeout,
      onTranscript: (sid, text) => {
        this.emit('transcript', { sessionId: sid, text, ts: Date.now() });
      },
    });

    this._sessions.set(id, session);
    this.emit('sessionOpen', { sessionId: id, ts: Date.now() });

    // Wire WebSocket events
    ws.on('message', (data) => {
      try {
        session.receiveAudio(data);
      } catch (_) {}
    });

    ws.on('close', () => {
      session.close();
      this._sessions.delete(id);
      this.emit('sessionClose', { sessionId: id, ts: Date.now() });
    });

    ws.on('error', (err) => {
      this.emit('sessionError', { sessionId: id, error: err.message });
    });

    // Send session-open confirmation
    session.send({ type: 'session_open', sessionId: id, ts: Date.now() });

    return id;
  }

  /**
   * Get a session by ID.
   *
   * @param {string} id
   * @returns {VoiceSession|undefined}
   */
  getSession(id) {
    return this._sessions.get(id);
  }

  /**
   * Close a session by ID.
   *
   * @param {string} id
   */
  closeSession(id) {
    const session = this._sessions.get(id);
    if (session) {
      session.close();
      this._sessions.delete(id);
    }
  }

  /**
   * Return stats for all active sessions.
   *
   * @returns {{ sessions: number, details: object[] }}
   */
  stats() {
    return {
      sessions: this._sessions.size,
      details:  Array.from(this._sessions.values()).map((s) => ({
        id:             s.id,
        createdAt:      s.createdAt,
        lastActivity:   s.lastActivity,
        bytesReceived:  s.bytesReceived,
        transcriptions: s.transcriptions,
      })),
    };
  }
}

module.exports = {
  VoiceRelay,
  VoiceSession,
  AudioBuffer,
  DEFAULT_FLUSH_INTERVAL_MS,
  DEFAULT_MIN_CHUNK_BYTES,
  DEFAULT_SESSION_TIMEOUT_MS,
  PHI,
};
