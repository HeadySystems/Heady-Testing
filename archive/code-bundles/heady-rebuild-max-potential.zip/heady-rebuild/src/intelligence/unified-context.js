/**
 * @file unified-context.js
 * @description UnifiedContext — layer-based context storage with timestamps,
 *              flattened retrieval, age-based pruning, and multi-source merging.
 *
 * Contexts are organised into named layers (e.g. 'system', 'user', 'session').
 * Each layer entry carries a timestamp, enabling time-based pruning and
 * recency-weighted retrieval.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const PHI = 1.6180339887;

/**
 * @typedef {object} ContextEntry
 * @property {string} key       - Entry key
 * @property {*}      value     - Stored value
 * @property {number} ts        - Unix timestamp (ms) when stored
 * @property {string} layer     - Layer name
 * @property {number} [ttl]     - Optional TTL in ms
 */

/**
 * @class UnifiedContext
 *
 * @example
 * const ctx = new UnifiedContext();
 * ctx.set('system', 'model', 'gpt-4');
 * ctx.set('user',   'name',  'Alice');
 * const flat = ctx.flatten(); // { model: 'gpt-4', name: 'Alice' }
 */
class UnifiedContext {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.maxAge]          - Default max age in ms for pruning (default: PHI^12 * 1000 ≈ 322 s)
   * @param {string[]}[opts.layerPriority]   - Layer order for conflict resolution during flatten (later = higher priority)
   */
  constructor(opts = {}) {
    this.maxAge        = opts.maxAge        ?? Math.round(Math.pow(PHI, 12) * 1000);
    this.layerPriority = opts.layerPriority ?? ['system', 'session', 'user', 'ephemeral'];

    /** @type {Map<string, Map<string, ContextEntry>>} layer → (key → entry) */
    this._layers = new Map();
  }

  // ─── Storage ─────────────────────────────────────────────────────────────────

  /**
   * Store a value in a layer.
   *
   * @param {string}  layer
   * @param {string}  key
   * @param {*}       value
   * @param {object}  [opts]
   * @param {number}  [opts.ttl]  - TTL in ms; entry auto-expires after this duration
   */
  set(layer, key, value, opts = {}) {
    if (!this._layers.has(layer)) {
      this._layers.set(layer, new Map());
    }

    this._layers.get(layer).set(key, {
      key,
      value,
      ts:    Date.now(),
      layer,
      ttl:   opts.ttl ?? null,
    });
  }

  /**
   * Retrieve a value from a specific layer.
   *
   * @param {string} layer
   * @param {string} key
   * @returns {*|undefined}
   */
  get(layer, key) {
    const entry = this._layers.get(layer)?.get(key);
    if (!entry) return undefined;
    if (entry.ttl && Date.now() - entry.ts > entry.ttl) {
      this._layers.get(layer).delete(key);
      return undefined;
    }
    return entry.value;
  }

  /**
   * Delete a key from a layer.
   *
   * @param {string} layer
   * @param {string} key
   * @returns {boolean}
   */
  delete(layer, key) {
    return this._layers.get(layer)?.delete(key) ?? false;
  }

  /**
   * Clear an entire layer.
   *
   * @param {string} layer
   */
  clearLayer(layer) {
    this._layers.delete(layer);
  }

  // ─── Retrieval ───────────────────────────────────────────────────────────────

  /**
   * Flatten all layers into a single object.
   * Layers later in layerPriority override earlier ones on key conflict.
   * Expired entries are excluded.
   *
   * @param {object}  [opts]
   * @param {string[]}[opts.layers]    - Restrict to these layer names
   * @param {boolean} [opts.withMeta]  - Include { value, ts, layer } instead of raw value
   * @returns {object}
   */
  flatten(opts = {}) {
    const now          = Date.now();
    const targetLayers = opts.layers ?? this._layerOrder();
    const withMeta     = opts.withMeta ?? false;
    const result       = {};

    for (const layerName of targetLayers) {
      const layer = this._layers.get(layerName);
      if (!layer) continue;

      for (const [key, entry] of layer) {
        if (entry.ttl && now - entry.ts > entry.ttl) continue;
        result[key] = withMeta
          ? { value: entry.value, ts: entry.ts, layer: entry.layer }
          : entry.value;
      }
    }

    return result;
  }

  /**
   * Get all entries from a layer as an array.
   *
   * @param {string} layer
   * @returns {ContextEntry[]}
   */
  getLayer(layer) {
    const map = this._layers.get(layer);
    if (!map) return [];
    const now = Date.now();
    return Array.from(map.values()).filter(
      (e) => !e.ttl || now - e.ts <= e.ttl,
    );
  }

  /**
   * Get all layer names currently in use.
   *
   * @returns {string[]}
   */
  getLayers() {
    return Array.from(this._layers.keys());
  }

  // ─── Pruning ─────────────────────────────────────────────────────────────────

  /**
   * Remove all entries older than maxAge (or a custom age).
   *
   * @param {number} [maxAge] - Max age in ms (defaults to this.maxAge)
   * @returns {number} Number of entries pruned
   */
  prune(maxAge) {
    const cutoff = Date.now() - (maxAge ?? this.maxAge);
    let pruned   = 0;

    for (const [, layer] of this._layers) {
      for (const [key, entry] of layer) {
        if (entry.ts < cutoff) {
          layer.delete(key);
          pruned++;
        }
      }
    }

    return pruned;
  }

  // ─── Merging ─────────────────────────────────────────────────────────────────

  /**
   * Merge context from multiple sources into a single layer.
   *
   * @param {string}   targetLayer - Layer to write merged results into
   * @param {object[]} sources     - Array of { data: object, weight?: number, ts?: number }
   * @param {object}   [opts]
   * @param {boolean}  [opts.preferNewest=true]  - On conflict, keep newest entry
   */
  merge(targetLayer, sources, opts = {}) {
    const preferNewest = opts.preferNewest ?? true;

    // Sort sources by timestamp if preferring newest
    const sorted = preferNewest
      ? [...sources].sort((a, b) => (a.ts ?? 0) - (b.ts ?? 0))
      : sources;

    for (const source of sorted) {
      const data = source.data ?? {};
      for (const [key, value] of Object.entries(data)) {
        this.set(targetLayer, key, value);
      }
    }
  }

  // ─── Statistics ──────────────────────────────────────────────────────────────

  /**
   * Return stats snapshot.
   *
   * @returns {{ layers: number, totalEntries: number, breakdown: object }}
   */
  stats() {
    const breakdown = {};
    let total = 0;

    for (const [name, layer] of this._layers) {
      breakdown[name] = layer.size;
      total += layer.size;
    }

    return { layers: this._layers.size, totalEntries: total, breakdown };
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Return layers in priority order, with unknown layers appended last.
   * @returns {string[]}
   */
  _layerOrder() {
    const known   = new Set(this.layerPriority);
    const unknown = Array.from(this._layers.keys()).filter((l) => !known.has(l));
    return [...this.layerPriority, ...unknown];
  }
}

module.exports = { UnifiedContext };
