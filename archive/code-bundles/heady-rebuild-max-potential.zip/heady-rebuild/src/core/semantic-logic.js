/**
 * @fileoverview Heady™ Systems — Continuous Semantic Logic (CSL)
 * Mathematical foundation layer for vector resonance and semantic coherence.
 * Sacred Geometry: all thresholds are PHI-derived where appropriate.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module core/semantic-logic
 * @version 3.1.0
 */

'use strict';

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
/** Golden ratio — permeates all resonance scoring */
const PHI   = 1.6180339887;
/** Inverse golden ratio */
const PHI_I = 1 / PHI; // ≈ 0.6180339887
/** PHI-derived default resonance threshold */
const PHI_GATE = PHI_I; // ≈ 0.618 — natural harmonic threshold

// ─── Type Definitions (JSDoc) ─────────────────────────────────────────────────
/**
 * @typedef {number[]} Vector - Dense float32-compatible numeric array
 */

// ─── Internal Helpers ─────────────────────────────────────────────────────────

/**
 * Compute the L2 norm (magnitude) of a vector.
 * @param {Vector} v
 * @returns {number}
 */
function l2norm(v) {
  let sum = 0;
  for (let i = 0; i < v.length; i++) sum += v[i] * v[i];
  return Math.sqrt(sum);
}

/**
 * Validate that a value is a non-empty numeric array.
 * @param {*}      v
 * @param {string} name - Parameter name for error message
 * @throws {TypeError}
 */
function assertVector(v, name) {
  if (!Array.isArray(v) || v.length === 0) {
    throw new TypeError(`CSL: '${name}' must be a non-empty numeric array`);
  }
}

/**
 * Validate that two vectors have equal dimensionality.
 * @param {Vector} a
 * @param {Vector} b
 * @throws {RangeError}
 */
function assertSameDim(a, b) {
  if (a.length !== b.length) {
    throw new RangeError(
      `CSL: dimension mismatch — a(${a.length}) ≠ b(${b.length})`
    );
  }
}

// ─── Core Functions ───────────────────────────────────────────────────────────

/**
 * Compute cosine similarity between two dense vectors.
 * Returns a value in [-1, 1]; 1 = identical direction, -1 = opposite.
 *
 * @param {Vector} a - First embedding vector
 * @param {Vector} b - Second embedding vector
 * @returns {number} Cosine similarity in [-1, 1]
 *
 * @example
 * const sim = cosine_similarity([1, 0, 0], [1, 0, 0]); // 1.0
 */
function cosine_similarity(a, b) {
  assertVector(a, 'a');
  assertVector(b, 'b');
  assertSameDim(a, b);

  let dot = 0;
  for (let i = 0; i < a.length; i++) dot += a[i] * b[i];

  const magA = l2norm(a);
  const magB = l2norm(b);

  if (magA === 0 || magB === 0) return 0;
  return dot / (magA * magB);
}

/**
 * Resonance gate — returns true only if cosine similarity meets the
 * PHI-derived harmonic threshold (default: 1/PHI ≈ 0.618).
 * Used as a semantic "open/close" valve throughout the pipeline.
 *
 * @param {Vector} a         - First embedding vector
 * @param {Vector} b         - Second embedding vector
 * @param {number} [threshold=PHI_GATE] - Minimum similarity to open gate
 * @returns {{ open: boolean, similarity: number, threshold: number, phi_ratio: number }}
 *
 * @example
 * const gate = resonance_gate(embedA, embedB);
 * if (gate.open) { // semantic resonance confirmed }
 */
function resonance_gate(a, b, threshold = PHI_GATE) {
  const similarity = cosine_similarity(a, b);
  const open       = similarity >= threshold;
  return {
    open,
    similarity,
    threshold,
    phi_ratio: similarity / PHI_GATE,
  };
}

/**
 * Semantic distance — angular distance in [0, 1] derived from cosine similarity.
 * 0 = identical, 1 = maximally distant (orthogonal or opposite).
 * Normalized so that PHI_GATE similarity maps to exactly 0.382 (1 - PHI_I²).
 *
 * @param {Vector} a
 * @param {Vector} b
 * @returns {number} Semantic distance in [0, 1]
 *
 * @example
 * const dist = semantic_distance(embedA, embedB); // 0.12 = very close
 */
function semantic_distance(a, b) {
  const sim = cosine_similarity(a, b);
  // Map cosine similarity [-1, 1] → distance [0, 1]
  // Uses arccos normalized by PI to preserve metric space properties
  return Math.acos(Math.min(1, Math.max(-1, sim))) / Math.PI;
}

/**
 * Coherence score for a set of vectors — measures how tightly a cluster
 * of embeddings aligns. Returns a PHI-weighted mean pairwise similarity.
 * Used by the Monte Carlo planner to assess agent agreement.
 *
 * @param {Vector[]} vectors - Array of embedding vectors (same dimensionality)
 * @returns {{ score: number, phi_harmonic: number, n: number, pairs: number }}
 *   - score: mean pairwise cosine similarity (0–1)
 *   - phi_harmonic: score weighted by 1/PHI for sacred geometry normalisation
 *   - n: number of vectors
 *   - pairs: number of pairs evaluated
 *
 * @example
 * const { score } = coherence_score([e1, e2, e3]);
 * // score > 0.8 → high semantic coherence (agents in agreement)
 */
function coherence_score(vectors) {
  if (!Array.isArray(vectors) || vectors.length < 2) {
    return { score: 0, phi_harmonic: 0, n: vectors?.length ?? 0, pairs: 0 };
  }

  let total = 0;
  let count = 0;

  for (let i = 0; i < vectors.length; i++) {
    for (let j = i + 1; j < vectors.length; j++) {
      try {
        total += cosine_similarity(vectors[i], vectors[j]);
        count++;
      } catch (_) {
        // Skip mismatched-dim pairs gracefully
      }
    }
  }

  const score        = count > 0 ? total / count : 0;
  const phi_harmonic = score * PHI_I;

  return {
    score:         parseFloat(score.toFixed(6)),
    phi_harmonic:  parseFloat(phi_harmonic.toFixed(6)),
    n:             vectors.length,
    pairs:         count,
  };
}

/**
 * Compute the centroid (mean vector) of an array of vectors.
 * Useful for summarizing an agent cluster into a single embedding.
 *
 * @param {Vector[]} vectors
 * @returns {Vector} Centroid vector
 */
function centroid(vectors) {
  if (!Array.isArray(vectors) || vectors.length === 0) return [];
  const dim  = vectors[0].length;
  const cent = new Array(dim).fill(0);
  for (const v of vectors) {
    for (let i = 0; i < dim; i++) cent[i] += v[i];
  }
  return cent.map(x => x / vectors.length);
}

/**
 * PHI-weighted blend of two vectors.
 * a′ = (a × PHI + b) / (PHI + 1)
 * Used in self-healing and memory consolidation.
 *
 * @param {Vector} a - Dominant vector (weighted by PHI)
 * @param {Vector} b - Subdominant vector
 * @returns {Vector}
 */
function phi_blend(a, b) {
  assertVector(a, 'a');
  assertVector(b, 'b');
  assertSameDim(a, b);
  const denom = PHI + 1;
  return a.map((ai, i) => (ai * PHI + b[i]) / denom);
}

// ─── Module Exports ───────────────────────────────────────────────────────────

module.exports = {
  cosine_similarity,
  resonance_gate,
  semantic_distance,
  coherence_score,
  centroid,
  phi_blend,
  // Constants
  PHI,
  PHI_I,
  PHI_GATE,
};
