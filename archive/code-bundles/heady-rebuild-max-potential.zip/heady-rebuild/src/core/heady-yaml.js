/**
 * @fileoverview Heady™ Systems — Lightweight YAML Loader/Dumper
 * Minimal dependency YAML parser for config files and agent manifests.
 * Handles the subset of YAML commonly used in Heady config files:
 *   - String, number, boolean, null scalars
 *   - Block mappings (key: value)
 *   - Block sequences (- item)
 *   - Inline arrays and objects
 *   - Quoted strings (single and double)
 *   - Multi-line folded (>) and literal (|) blocks
 *   - Comments (#)
 *   - Nested indentation
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module core/heady-yaml
 * @version 3.1.0
 */

'use strict';

const PHI = 1.6180339887;

// ─── Token Types ──────────────────────────────────────────────────────────────
const T = {
  MAP_KEY:   'MAP_KEY',
  MAP_VALUE: 'MAP_VALUE',
  SEQ_ITEM:  'SEQ_ITEM',
  SCALAR:    'SCALAR',
};

// ─── Scalar Coercion ──────────────────────────────────────────────────────────

/**
 * Coerce a raw YAML scalar string to its native JS type.
 * @param {string} raw
 * @returns {string|number|boolean|null}
 */
function coerceScalar(raw) {
  if (raw === null || raw === undefined) return null;
  const s = String(raw).trim();

  // Null
  if (s === '' || s === 'null' || s === '~') return null;

  // Boolean
  if (s === 'true'  || s === 'yes' || s === 'on')  return true;
  if (s === 'false' || s === 'no'  || s === 'off') return false;

  // Integer
  if (/^-?0x[0-9a-fA-F]+$/.test(s)) return parseInt(s, 16);
  if (/^-?0o[0-7]+$/.test(s))       return parseInt(s.replace('0o', ''), 8);
  if (/^-?[0-9]+$/.test(s))         return parseInt(s, 10);

  // Float
  if (/^-?[0-9]+\.[0-9]*([eE][+-]?[0-9]+)?$/.test(s)) return parseFloat(s);
  if (s === '.inf' || s === '+.inf') return Infinity;
  if (s === '-.inf')                 return -Infinity;
  if (s === '.nan')                  return NaN;

  return s;
}

/**
 * Strip surrounding quotes and unescape basic sequences.
 * @param {string} s
 * @returns {string}
 */
function unquote(s) {
  s = s.trim();
  if ((s.startsWith('"') && s.endsWith('"')) ||
      (s.startsWith("'") && s.endsWith("'"))) {
    const inner = s.slice(1, -1);
    return inner
      .replace(/\\n/g, '\n')
      .replace(/\\t/g, '\t')
      .replace(/\\r/g, '\r')
      .replace(/\\"/g, '"')
      .replace(/\\'/g, "'")
      .replace(/\\\\/g, '\\');
  }
  return s;
}

// ─── Inline Parser (arrays/objects on a single line) ─────────────────────────

/**
 * Parse an inline YAML flow sequence: [a, b, c]
 * @param {string} src
 * @returns {Array}
 */
function parseInlineArray(src) {
  const inner = src.slice(1, -1).trim();
  if (!inner) return [];
  return splitFlowItems(inner).map(item => parseInlineValue(item.trim()));
}

/**
 * Parse an inline YAML flow mapping: {a: 1, b: 2}
 * @param {string} src
 * @returns {object}
 */
function parseInlineObject(src) {
  const inner = src.slice(1, -1).trim();
  if (!inner) return {};
  const result = {};
  for (const item of splitFlowItems(inner)) {
    const colonIdx = item.indexOf(':');
    if (colonIdx === -1) continue;
    const key = unquote(item.slice(0, colonIdx).trim());
    const val = parseInlineValue(item.slice(colonIdx + 1).trim());
    result[key] = val;
  }
  return result;
}

/**
 * Split comma-separated flow items respecting nested brackets/braces/quotes.
 * @param {string} src
 * @returns {string[]}
 */
function splitFlowItems(src) {
  const items  = [];
  let depth    = 0;
  let inStr    = null;
  let start    = 0;

  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inStr) {
      if (ch === inStr && src[i - 1] !== '\\') inStr = null;
    } else if (ch === '"' || ch === "'") {
      inStr = ch;
    } else if (ch === '[' || ch === '{') {
      depth++;
    } else if (ch === ']' || ch === '}') {
      depth--;
    } else if (ch === ',' && depth === 0) {
      items.push(src.slice(start, i));
      start = i + 1;
    }
  }
  if (start < src.length) items.push(src.slice(start));
  return items;
}

/**
 * Parse a single inline value (scalar, array, or object).
 * @param {string} s
 * @returns {*}
 */
function parseInlineValue(s) {
  s = s.trim();
  if (s.startsWith('[')) return parseInlineArray(s);
  if (s.startsWith('{')) return parseInlineObject(s);
  if ((s.startsWith('"') && s.endsWith('"')) ||
      (s.startsWith("'") && s.endsWith("'"))) {
    return unquote(s);
  }
  return coerceScalar(s);
}

// ─── Block Parser ─────────────────────────────────────────────────────────────

/**
 * Count the leading spaces in a line (indentation level).
 * @param {string} line
 * @returns {number}
 */
function indent(line) {
  let i = 0;
  while (i < line.length && line[i] === ' ') i++;
  return i;
}

/**
 * Strip inline comment from a raw YAML value.
 * @param {string} s
 * @returns {string}
 */
function stripComment(s) {
  // Only strip # that are preceded by a space (not inside quotes)
  let inStr = null;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (inStr) {
      if (ch === inStr && s[i - 1] !== '\\') inStr = null;
    } else if (ch === '"' || ch === "'") {
      inStr = ch;
    } else if (ch === '#' && (i === 0 || s[i - 1] === ' ')) {
      return s.slice(0, i).trimEnd();
    }
  }
  return s;
}

/**
 * Parse YAML lines starting at index `start` with a minimum indentation of `minIndent`.
 * Returns [parsedValue, nextLineIndex].
 *
 * @param {string[]} lines
 * @param {number}   start
 * @param {number}   minIndent
 * @returns {[*, number]}
 */
function parseBlock(lines, start, minIndent) {
  // Skip blank/comment lines
  while (start < lines.length) {
    const trimmed = lines[start].trim();
    if (trimmed !== '' && !trimmed.startsWith('#')) break;
    start++;
  }
  if (start >= lines.length) return [null, start];

  const firstLine    = lines[start];
  const firstIndent  = indent(firstLine);
  const firstTrimmed = firstLine.trim();

  // Detect block type from first non-blank line at this level
  if (firstTrimmed.startsWith('- ') || firstTrimmed === '-') {
    // Sequence
    return parseSequence(lines, start, firstIndent);
  } else {
    // Try mapping
    return parseMapping(lines, start, firstIndent);
  }
}

/**
 * Parse a YAML block sequence.
 * @param {string[]} lines
 * @param {number}   start
 * @param {number}   seqIndent
 * @returns {[Array, number]}
 */
function parseSequence(lines, start, seqIndent) {
  const arr = [];
  let i = start;

  while (i < lines.length) {
    const line = lines[i];
    if (line.trim() === '' || line.trim().startsWith('#')) { i++; continue; }
    const lineIndent = indent(line);
    if (lineIndent < seqIndent) break;
    if (lineIndent > seqIndent) { i++; continue; }

    const trimmed = line.trimStart();
    if (!trimmed.startsWith('- ') && trimmed !== '-') break;

    const valueStr = trimmed.slice(2).trim();
    i++;

    if (!valueStr || valueStr.startsWith('#')) {
      // Value on next lines (nested block)
      const [val, nextI] = parseBlock(lines, i, lineIndent + 2);
      arr.push(val);
      i = nextI;
    } else if (valueStr.startsWith('[') || valueStr.startsWith('{')) {
      arr.push(parseInlineValue(stripComment(valueStr)));
    } else {
      // Check if next non-blank line is more indented (nested block under sequence item)
      let nextContent = i;
      while (nextContent < lines.length && lines[nextContent].trim() === '') nextContent++;
      if (nextContent < lines.length && indent(lines[nextContent]) > lineIndent + 1) {
        const [val, nextI] = parseBlock(lines, i, lineIndent + 2);
        arr.push(val);
        i = nextI;
      } else {
        arr.push(coerceScalar(unquote(stripComment(valueStr))));
      }
    }
  }
  return [arr, i];
}

/**
 * Parse a YAML block mapping.
 * @param {string[]} lines
 * @param {number}   start
 * @param {number}   mapIndent
 * @returns {[object, number]}
 */
function parseMapping(lines, start, mapIndent) {
  const obj = {};
  let i = start;

  while (i < lines.length) {
    const line = lines[i];
    if (line.trim() === '' || line.trim().startsWith('#')) { i++; continue; }
    const lineIndent = indent(line);
    if (lineIndent < mapIndent) break;
    if (lineIndent > mapIndent) { i++; continue; }

    const trimmed  = line.trimStart();
    const colonIdx = trimmed.indexOf(': ');
    const isEndKey = trimmed.endsWith(':') && !trimmed.includes(': ');

    if (colonIdx === -1 && !isEndKey) { i++; continue; }

    let key, rawVal;
    if (isEndKey) {
      key    = unquote(trimmed.slice(0, -1).trim());
      rawVal = '';
    } else {
      key    = unquote(trimmed.slice(0, colonIdx).trim());
      rawVal = stripComment(trimmed.slice(colonIdx + 2).trim());
    }
    i++;

    if (!rawVal) {
      // Value on subsequent lines
      while (i < lines.length && lines[i].trim() === '') i++;
      if (i < lines.length && indent(lines[i]) > lineIndent) {
        const [val, nextI] = parseBlock(lines, i, lineIndent + 1);
        obj[key] = val;
        i = nextI;
      } else {
        obj[key] = null;
      }
    } else if (rawVal.startsWith('|') || rawVal.startsWith('>')) {
      // Multi-line scalar
      const fold = rawVal[0] === '>';
      const blockLines = [];
      while (i < lines.length && indent(lines[i]) > lineIndent) {
        blockLines.push(lines[i].trimStart());
        i++;
      }
      obj[key] = fold
        ? blockLines.join(' ').trim()
        : blockLines.join('\n').trimEnd();
    } else if (rawVal.startsWith('[') || rawVal.startsWith('{')) {
      obj[key] = parseInlineValue(rawVal);
    } else {
      obj[key] = coerceScalar(unquote(rawVal));
    }
  }
  return [obj, i];
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Parse a YAML string into a JavaScript value.
 * Handles mappings, sequences, and scalars at the top level.
 *
 * @param {string} yamlStr - Raw YAML content
 * @returns {*} Parsed JavaScript value
 * @throws {Error} On parse failure
 *
 * @example
 * const cfg = load('port: 8080\nname: heady');
 * // → { port: 8080, name: 'heady' }
 */
function load(yamlStr) {
  if (typeof yamlStr !== 'string') {
    throw new TypeError('heady-yaml.load: input must be a string');
  }
  try {
    const lines = yamlStr.replace(/\r\n/g, '\n').split('\n');
    const [result] = parseBlock(lines, 0, 0);
    return result;
  } catch (err) {
    throw new Error(`heady-yaml parse error: ${err.message}`);
  }
}

/**
 * Serialize a JavaScript value to a YAML string.
 * Produces block-style YAML suitable for config files.
 *
 * @param {*}      value   - Value to serialize
 * @param {number} [level=0] - Current indentation level
 * @returns {string} YAML string
 *
 * @example
 * dump({ port: 8080, agents: ['bee-1', 'bee-2'] });
 */
function dump(value, level = 0) {
  const pad = '  '.repeat(level);

  if (value === null || value === undefined) return 'null';
  if (typeof value === 'boolean')            return value ? 'true' : 'false';
  if (typeof value === 'number')             return String(value);

  if (typeof value === 'string') {
    // Quote strings that could be misinterpreted
    if (/^[\s]|[\s]$|[:#\[\]{}|>&*!,'"?]/.test(value) || value === '') {
      return `"${value.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n')}"`;
    }
    if (/^(true|false|yes|no|on|off|null|~)$/i.test(value)) {
      return `"${value}"`;
    }
    if (/^-?[0-9]/.test(value)) return `"${value}"`;
    return value;
  }

  if (Array.isArray(value)) {
    if (value.length === 0) return '[]';
    return value
      .map(item => `${pad}- ${dump(item, level + 1).trimStart()}`)
      .join('\n');
  }

  if (typeof value === 'object') {
    const entries = Object.entries(value);
    if (entries.length === 0) return '{}';
    return entries
      .map(([k, v]) => {
        const keyStr = `${pad}${k}:`;
        if (v !== null && typeof v === 'object') {
          return `${keyStr}\n${dump(v, level + 1)}`;
        }
        return `${keyStr} ${dump(v, level)}`;
      })
      .join('\n');
  }

  return String(value);
}

module.exports = { load, dump, PHI };
