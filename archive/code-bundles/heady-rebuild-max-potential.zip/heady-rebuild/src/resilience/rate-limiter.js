/**
 * @file rate-limiter.js
 * @description Token bucket rate limiter — supports per-key and global limiting,
 *              burst capacity, and an Express middleware factory.
 *
 * Token bucket algorithm:
 *  - Bucket starts full at `burst` capacity
 *  - Tokens refill at `tokensPerInterval` / `interval` ms
 *  - Each request consumes `cost` tokens (default 1)
 *  - Requests that cannot acquire tokens are rejected with 429
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const PHI = 1.6180339887;

/**
 * @class TokenBucket
 * Internal per-key bucket state.
 */
class TokenBucket {
  /**
   * @param {number} capacity      - Maximum token capacity (burst)
   * @param {number} refillRate    - Tokens added per ms
   * @param {number} [initialFill] - Starting token count (default = capacity)
   */
  constructor(capacity, refillRate, initialFill) {
    this.capacity   = capacity;
    this.refillRate = refillRate;
    this.tokens     = initialFill ?? capacity;
    this.lastRefill = Date.now();
  }

  /**
   * Refill tokens based on elapsed time, then try to consume `cost` tokens.
   *
   * @param {number} [cost=1]
   * @returns {boolean} true if tokens were consumed, false if insufficient
   */
  consume(cost = 1) {
    const now     = Date.now();
    const elapsed = now - this.lastRefill;
    const added   = elapsed * this.refillRate;

    this.tokens     = Math.min(this.capacity, this.tokens + added);
    this.lastRefill = now;

    if (this.tokens >= cost) {
      this.tokens -= cost;
      return true;
    }
    return false;
  }

  /**
   * Seconds until `cost` tokens are available.
   *
   * @param {number} [cost=1]
   * @returns {number} seconds (0 if tokens available now)
   */
  retryAfter(cost = 1) {
    const deficit = cost - this.tokens;
    if (deficit <= 0) return 0;
    return deficit / (this.refillRate * 1000); // convert ms rate → seconds
  }
}

/**
 * @class RateLimiter
 *
 * @example
 * const limiter = new RateLimiter({ tokensPerInterval: 100, interval: 1000, burst: 200 });
 * if (!limiter.check('user-123')) throw new Error('rate limited');
 */
class RateLimiter {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.tokensPerInterval=100] - Tokens replenished per interval
   * @param {number}  [opts.interval=1000]         - Refill interval in ms
   * @param {number}  [opts.burst]                 - Max burst capacity (default = tokensPerInterval * PHI)
   * @param {number}  [opts.globalMax]             - Optional global request ceiling (tokens/interval across all keys)
   * @param {number}  [opts.keyTTL=300000]         - ms before an idle per-key bucket is evicted (5 min)
   */
  constructor(opts = {}) {
    this.tokensPerInterval = opts.tokensPerInterval ?? 100;
    this.interval          = opts.interval          ?? 1000;
    this.burst             = opts.burst             ?? Math.ceil(this.tokensPerInterval * PHI);
    this.keyTTL            = opts.keyTTL            ?? 300_000;

    /** tokens per ms — used as refill rate for TokenBucket */
    this._refillRate = this.tokensPerInterval / this.interval;

    /** @type {Map<string, TokenBucket>} */
    this._buckets = new Map();

    /** @type {Map<string, number>} Last-access timestamps per key */
    this._lastAccess = new Map();

    /** Global bucket (optional) */
    this._global = opts.globalMax
      ? new TokenBucket(
          Math.ceil(opts.globalMax * PHI),
          opts.globalMax / this.interval,
        )
      : null;

    // Periodic eviction of stale keys
    this._evictTimer = setInterval(() => this._evictStale(), this.keyTTL);
    if (this._evictTimer.unref) this._evictTimer.unref();
  }

  // ─── Core ────────────────────────────────────────────────────────────────────

  /**
   * Check and consume tokens for a given key.
   *
   * @param {string} [key='__global__']  - Per-key identifier (IP, user ID, etc.)
   * @param {number} [cost=1]            - Token cost for this request
   * @returns {{ allowed: boolean, retryAfter: number, remaining: number }}
   */
  check(key = '__global__', cost = 1) {
    // Global gate
    if (this._global && !this._global.consume(cost)) {
      return {
        allowed:    false,
        retryAfter: Math.ceil(this._global.retryAfter(cost)),
        remaining:  Math.floor(this._global.tokens),
      };
    }

    const bucket = this._getOrCreate(key);
    this._lastAccess.set(key, Date.now());

    const allowed = bucket.consume(cost);
    return {
      allowed,
      retryAfter: allowed ? 0 : Math.ceil(bucket.retryAfter(cost)),
      remaining:  Math.floor(bucket.tokens),
    };
  }

  /**
   * Reset a specific key's bucket.
   *
   * @param {string} key
   */
  reset(key) {
    this._buckets.delete(key);
    this._lastAccess.delete(key);
  }

  /**
   * Return stats for all tracked keys.
   *
   * @returns {{ keys: number, global: object|null }}
   */
  stats() {
    return {
      keys:   this._buckets.size,
      global: this._global
        ? { tokens: Math.floor(this._global.tokens), capacity: this._global.capacity }
        : null,
    };
  }

  // ─── Express Middleware Factory ──────────────────────────────────────────────

  /**
   * Create an Express middleware that rate-limits by `keyExtractor(req)`.
   *
   * @param {object}   [mwOpts]
   * @param {Function} [mwOpts.keyExtractor]  - (req) => string — default: req.ip
   * @param {number}   [mwOpts.cost=1]        - Token cost per request
   * @param {Function} [mwOpts.onLimited]     - Custom 429 handler: (req, res, info) => void
   * @returns {Function} Express (req, res, next) => void
   */
  middleware(mwOpts = {}) {
    const keyExtractor = mwOpts.keyExtractor ?? ((req) => req.ip ?? 'unknown');
    const cost         = mwOpts.cost         ?? 1;
    const onLimited    = mwOpts.onLimited    ?? null;

    return (req, res, next) => {
      const key    = keyExtractor(req);
      const result = this.check(key, cost);

      res.setHeader('X-RateLimit-Remaining', result.remaining);
      res.setHeader('X-RateLimit-Burst',     this.burst);

      if (!result.allowed) {
        res.setHeader('Retry-After', result.retryAfter);
        if (typeof onLimited === 'function') {
          return onLimited(req, res, result);
        }
        return res.status(429).json({
          error:      'Too Many Requests',
          retryAfter: result.retryAfter,
        });
      }

      next();
    };
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Get or create a per-key bucket.
   * @param {string} key
   * @returns {TokenBucket}
   */
  _getOrCreate(key) {
    if (!this._buckets.has(key)) {
      this._buckets.set(key, new TokenBucket(this.burst, this._refillRate));
    }
    return this._buckets.get(key);
  }

  /** @private Evict buckets that have been idle longer than keyTTL. */
  _evictStale() {
    const now     = Date.now();
    const cutoff  = now - this.keyTTL;
    for (const [key, ts] of this._lastAccess) {
      if (ts < cutoff) {
        this._buckets.delete(key);
        this._lastAccess.delete(key);
      }
    }
  }

  /** Tear down the eviction timer. */
  destroy() {
    clearInterval(this._evictTimer);
  }
}

module.exports = { RateLimiter, TokenBucket };
