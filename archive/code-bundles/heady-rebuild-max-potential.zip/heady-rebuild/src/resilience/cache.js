/**
 * @file cache.js
 * @description Multi-tier cache — L1 in-memory Map with TTL, L2 disk-based JSON persistence.
 *              Max entries scale dynamically with available heap memory.
 *              PHI-derived default TTLs.
 *
 * PHI TTL defaults:
 *   L1 TTL : PHI^10 * 1000 ≈ 122 s
 *   L2 TTL : PHI^13 * 1000 ≈ 521 s
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const fs   = require('fs');
const path = require('path');
const os   = require('os');

const PHI = 1.6180339887;

/** PHI^10 * 1000 ms — L1 default TTL */
const L1_TTL = Math.round(Math.pow(PHI, 10) * 1000);  // ~122 000 ms

/** PHI^13 * 1000 ms — L2 default TTL */
const L2_TTL = Math.round(Math.pow(PHI, 13) * 1000);  // ~521 000 ms

/**
 * Compute max in-memory entries from available heap.
 * Reserve 10% of freeMemory, assume ~1 KB per entry.
 *
 * @returns {number}
 */
function dynamicMaxEntries() {
  const freeMem  = os.freemem();          // bytes
  const reserved = freeMem * 0.10;        // 10% of free
  const bytes    = Math.floor(reserved);
  const entries  = Math.floor(bytes / 1024); // ~1 KB per entry
  return Math.max(100, Math.min(entries, 100_000)); // clamp [100, 100k]
}

// ─── L1 In-Memory Cache ──────────────────────────────────────────────────────

/**
 * @class L1Cache
 * In-memory Map with TTL expiry and LRU-like eviction when max entries is reached.
 */
class L1Cache {
  /**
   * @param {object} [opts]
   * @param {number} [opts.ttl]        - Default TTL in ms (default PHI^10 * 1000)
   * @param {number} [opts.maxEntries] - Max entries (default dynamic)
   */
  constructor(opts = {}) {
    this.defaultTTL = opts.ttl        ?? L1_TTL;
    this.maxEntries = opts.maxEntries ?? dynamicMaxEntries();

    /** @type {Map<string, { value: *, expiresAt: number, hits: number }>} */
    this._map = new Map();

    /** @type {{ hits: number, misses: number, evictions: number }} */
    this._stats = { hits: 0, misses: 0, evictions: 0 };
  }

  /**
   * Retrieve a value.  Returns undefined on miss or expiry.
   *
   * @param {string} key
   * @returns {*|undefined}
   */
  get(key) {
    const entry = this._map.get(key);
    if (!entry) {
      this._stats.misses++;
      return undefined;
    }
    if (Date.now() > entry.expiresAt) {
      this._map.delete(key);
      this._stats.misses++;
      return undefined;
    }
    entry.hits++;
    this._stats.hits++;
    // Refresh LRU order
    this._map.delete(key);
    this._map.set(key, entry);
    return entry.value;
  }

  /**
   * Store a value.
   *
   * @param {string} key
   * @param {*}      value
   * @param {number} [ttl] - TTL in ms (overrides default)
   */
  set(key, value, ttl) {
    const expiresAt = Date.now() + (ttl ?? this.defaultTTL);

    // Evict oldest entry if at capacity
    if (!this._map.has(key) && this._map.size >= this.maxEntries) {
      const oldest = this._map.keys().next().value;
      this._map.delete(oldest);
      this._stats.evictions++;
    }

    this._map.set(key, { value, expiresAt, hits: 0 });
  }

  /**
   * Delete a key.
   *
   * @param {string} key
   * @returns {boolean}
   */
  invalidate(key) {
    return this._map.delete(key);
  }

  /**
   * Remove all expired entries.
   *
   * @returns {number} Number of entries pruned
   */
  prune() {
    const now = Date.now();
    let pruned = 0;
    for (const [key, entry] of this._map) {
      if (now > entry.expiresAt) {
        this._map.delete(key);
        pruned++;
      }
    }
    return pruned;
  }

  /**
   * Return stats snapshot.
   *
   * @returns {{ size: number, maxEntries: number, hits: number, misses: number, evictions: number }}
   */
  stats() {
    return { size: this._map.size, maxEntries: this.maxEntries, ...this._stats };
  }

  /** Clear all entries. */
  clear() {
    this._map.clear();
  }
}

// ─── L2 Disk Cache ───────────────────────────────────────────────────────────

/**
 * @class L2Cache
 * JSON file-based persistence cache.  Each key maps to a single JSON file
 * under cacheDir.  Files contain { value, expiresAt }.
 */
class L2Cache {
  /**
   * @param {object} [opts]
   * @param {string} [opts.cacheDir] - Directory for cache files (default: os.tmpdir()/heady-cache)
   * @param {number} [opts.ttl]      - Default TTL in ms (default PHI^13 * 1000)
   */
  constructor(opts = {}) {
    this.cacheDir   = opts.cacheDir ?? path.join(os.tmpdir(), 'heady-cache');
    this.defaultTTL = opts.ttl      ?? L2_TTL;
    this._stats     = { hits: 0, misses: 0, writes: 0 };

    try {
      fs.mkdirSync(this.cacheDir, { recursive: true });
    } catch (_) {
      // ignore if already exists
    }
  }

  /**
   * @private Sanitize a cache key to a safe filename.
   * @param {string} key
   * @returns {string}
   */
  _filePath(key) {
    const safe = key.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 200);
    return path.join(this.cacheDir, `${safe}.json`);
  }

  /**
   * Retrieve a value.  Returns undefined on miss or expiry.
   *
   * @param {string} key
   * @returns {*|undefined}
   */
  get(key) {
    try {
      const raw     = fs.readFileSync(this._filePath(key), 'utf8');
      const entry   = JSON.parse(raw);
      if (Date.now() > entry.expiresAt) {
        this.invalidate(key);
        this._stats.misses++;
        return undefined;
      }
      this._stats.hits++;
      return entry.value;
    } catch (_) {
      this._stats.misses++;
      return undefined;
    }
  }

  /**
   * Store a value.
   *
   * @param {string} key
   * @param {*}      value
   * @param {number} [ttl]
   */
  set(key, value, ttl) {
    const entry = { value, expiresAt: Date.now() + (ttl ?? this.defaultTTL) };
    try {
      fs.writeFileSync(this._filePath(key), JSON.stringify(entry), 'utf8');
      this._stats.writes++;
    } catch (_) {
      // disk write failure is non-fatal
    }
  }

  /**
   * Delete a key's file.
   *
   * @param {string} key
   */
  invalidate(key) {
    try { fs.unlinkSync(this._filePath(key)); } catch (_) {}
  }

  /**
   * @returns {{ hits: number, misses: number, writes: number }}
   */
  stats() {
    return { ...this._stats };
  }
}

// ─── Multi-Tier Cache ────────────────────────────────────────────────────────

/**
 * @class MultiTierCache
 * Unified get/set/invalidate interface backed by L1 then L2.
 *
 * @example
 * const cache = new MultiTierCache();
 * cache.set('key', { data: 'value' });
 * const hit = cache.get('key'); // served from L1
 */
class MultiTierCache {
  /**
   * @param {object} [opts]
   * @param {object} [opts.l1] - L1Cache constructor options
   * @param {object} [opts.l2] - L2Cache constructor options
   */
  constructor(opts = {}) {
    this.l1 = new L1Cache(opts.l1 ?? {});
    this.l2 = new L2Cache(opts.l2 ?? {});
  }

  /**
   * Get a value — checks L1 first, then promotes from L2 on L1 miss.
   *
   * @param {string} key
   * @returns {*|undefined}
   */
  get(key) {
    const l1val = this.l1.get(key);
    if (l1val !== undefined) return l1val;

    const l2val = this.l2.get(key);
    if (l2val !== undefined) {
      // Promote to L1
      this.l1.set(key, l2val);
      return l2val;
    }

    return undefined;
  }

  /**
   * Set a value in both tiers.
   *
   * @param {string} key
   * @param {*}      value
   * @param {object} [ttlOpts]
   * @param {number} [ttlOpts.l1]  - L1 TTL in ms
   * @param {number} [ttlOpts.l2]  - L2 TTL in ms
   */
  set(key, value, ttlOpts = {}) {
    this.l1.set(key, value, ttlOpts.l1);
    this.l2.set(key, value, ttlOpts.l2);
  }

  /**
   * Invalidate a key from all tiers.
   *
   * @param {string} key
   */
  invalidate(key) {
    this.l1.invalidate(key);
    this.l2.invalidate(key);
  }

  /**
   * Combined stats from both tiers.
   *
   * @returns {{ l1: object, l2: object }}
   */
  stats() {
    return { l1: this.l1.stats(), l2: this.l2.stats() };
  }
}

module.exports = {
  MultiTierCache,
  L1Cache,
  L2Cache,
  L1_TTL,
  L2_TTL,
  dynamicMaxEntries,
  PHI,
};
