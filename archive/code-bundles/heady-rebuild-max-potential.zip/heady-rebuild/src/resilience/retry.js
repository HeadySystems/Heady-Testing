/**
 * @file retry.js
 * @description Smart retry with exponential backoff integration, circuit-breaker
 *              awareness, and error classification.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const PHI = 1.6180339887;

const { withBackoff }    = require('./exponential-backoff');
const { CircuitOpenError } = require('./circuit-breaker');

// ─── Error Classification ────────────────────────────────────────────────────

/**
 * Determine whether an error is retryable.
 *
 * Permanent (non-retryable) errors:
 *  - 4xx HTTP status codes (excluding 408 Request Timeout, 429 Too Many Requests)
 *  - CircuitOpenError — retrying into an open circuit is futile
 *  - SyntaxError / TypeError — indicative of programming errors, not transient
 *  - Custom `retryable: false` flag on error object
 *
 * @param {Error} err
 * @returns {boolean} true if the error is worth retrying
 */
function isRetryable(err) {
  // Explicit flag override
  if (err && typeof err.retryable === 'boolean') return err.retryable;

  // Circuit open — no point retrying
  if (err instanceof CircuitOpenError) return false;

  // Programming errors
  if (err instanceof TypeError || err instanceof SyntaxError) return false;

  // HTTP status codes
  const status = err.status ?? err.statusCode ?? err.response?.status;
  if (typeof status === 'number') {
    // 408 Timeout and 429 Too Many Requests are retryable
    if (status === 408 || status === 429) return true;
    // Other 4xx are client errors — not retryable
    if (status >= 400 && status < 500) return false;
    // 5xx are server errors — retryable
    if (status >= 500) return true;
  }

  // Network-level errors
  const retryableCodes = new Set([
    'ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND',
    'ENETUNREACH', 'EAI_AGAIN', 'EPIPE',
  ]);
  if (err.code && retryableCodes.has(err.code)) return true;

  // Default: retry unknown errors
  return true;
}

/**
 * Classify an error into a category string.
 *
 * @param {Error} err
 * @returns {'circuit_open'|'client_error'|'server_error'|'network'|'permanent'|'unknown'}
 */
function classifyError(err) {
  if (err instanceof CircuitOpenError) return 'circuit_open';

  const status = err.status ?? err.statusCode ?? err.response?.status;
  if (typeof status === 'number') {
    if (status >= 400 && status < 500) return 'client_error';
    if (status >= 500)                 return 'server_error';
  }

  const networkCodes = new Set([
    'ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'ENOTFOUND', 'ENETUNREACH', 'EAI_AGAIN',
  ]);
  if (err.code && networkCodes.has(err.code)) return 'network';

  if (err instanceof TypeError || err instanceof SyntaxError) return 'permanent';

  return 'unknown';
}

// ─── Smart Retry ─────────────────────────────────────────────────────────────

/**
 * Execute an async function with smart retry logic.
 *
 * Features:
 *  - PHI-scaled exponential backoff between attempts
 *  - Skips retry for non-retryable errors (4xx, CircuitOpenError, etc.)
 *  - Optional circuit breaker integration: wraps action inside breaker.fire()
 *  - Per-attempt and final-failure callbacks
 *
 * @param {Function}          fn           - Async function to execute; receives (attempt: number)
 * @param {object}            [opts]
 * @param {number}            [opts.retries=3]         - Max retry count (total attempts = retries + 1)
 * @param {number}            [opts.baseDelay=1000]    - Base delay in ms
 * @param {number}            [opts.maxDelay=30000]    - Max delay cap in ms
 * @param {boolean}           [opts.jitter=true]       - Apply full-jitter to delays
 * @param {object|null}       [opts.circuit]           - CircuitBreaker instance (optional)
 * @param {Function}          [opts.shouldRetry]       - (err) => boolean — override classification
 * @param {Function}          [opts.onRetry]           - (attempt, delay, err) => void — callback before retry
 * @param {Function}          [opts.onFailure]         - (err, attempts) => void — called on final failure
 * @returns {Promise<*>}
 *
 * @example
 * const result = await retry(
 *   () => fetch('https://api.example.com/data'),
 *   { retries: 4, circuit: myBreaker },
 * );
 */
async function retry(fn, opts = {}) {
  const retries     = opts.retries     ?? 3;
  const baseDelay   = opts.baseDelay   ?? 1000;
  const maxDelay    = opts.maxDelay    ?? 30_000;
  const jitter      = opts.jitter      ?? true;
  const circuit     = opts.circuit     ?? null;
  const shouldRetry = opts.shouldRetry ?? isRetryable;
  const onRetry     = opts.onRetry     ?? null;
  const onFailure   = opts.onFailure   ?? null;

  // Wrap fn in circuit breaker if provided
  const action = circuit
    ? (attempt) => circuit.fire(() => fn(attempt))
    : fn;

  let totalAttempts = 0;

  try {
    return await withBackoff(
      (attempt) => {
        totalAttempts++;
        return action(attempt);
      },
      {
        maxAttempts: retries + 1,
        baseDelay,
        maxDelay,
        jitter,
        shouldRetry,
        onRetry: (attempt, delay, err) => {
          if (typeof onRetry === 'function') onRetry(attempt, delay, err);
        },
      },
    );
  } catch (err) {
    if (typeof onFailure === 'function') onFailure(err, totalAttempts);
    throw err;
  }
}

// ─── Retry Decorator ──────────────────────────────────────────────────────────

/**
 * Wrap an async function so it automatically retries on failure.
 *
 * @param {Function} fn   - Async function to wrap
 * @param {object}   opts - Same as retry() options
 * @returns {Function} Wrapped async function
 *
 * @example
 * const robustFetch = withRetry(fetch, { retries: 3 });
 * const res = await robustFetch('https://api.example.com/data');
 */
function withRetry(fn, opts = {}) {
  return (...args) => retry(() => fn(...args), opts);
}

module.exports = { retry, withRetry, isRetryable, classifyError };
