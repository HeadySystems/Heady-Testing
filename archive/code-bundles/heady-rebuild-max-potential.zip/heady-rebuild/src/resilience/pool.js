/**
 * @file pool.js
 * @description ResourcePool — manages a fixed-size pool of reusable resources
 *              (DB connections, HTTP agents, workers, etc.) with a waiting queue
 *              and optional health-check eviction.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const PHI = 1.6180339887;

const { EventEmitter } = require('events');

/**
 * @class ResourcePool
 * @extends EventEmitter
 *
 * @example
 * const pool = new ResourcePool({
 *   factory:     () => createDbConnection(),
 *   destroy:     (conn) => conn.close(),
 *   healthCheck: (conn) => conn.ping(),
 *   size:        10,
 * });
 * const conn = await pool.acquire();
 * try { await conn.query('SELECT 1'); } finally { pool.release(conn); }
 */
class ResourcePool extends EventEmitter {
  /**
   * @param {object}    opts
   * @param {Function}  opts.factory               - Async factory: () => resource
   * @param {Function}  [opts.destroy]             - Async teardown: (resource) => void
   * @param {Function}  [opts.healthCheck]         - Async health probe: (resource) => boolean
   * @param {number}    [opts.size=10]             - Maximum pool size
   * @param {number}    [opts.acquireTimeout=5000] - ms to wait for a free resource
   * @param {number}    [opts.healthCheckInterval] - ms between background health sweeps (0 = off)
   * @param {string}    [opts.name='pool']         - Name for event payloads
   */
  constructor(opts = {}) {
    super();

    if (typeof opts.factory !== 'function') {
      throw new TypeError('ResourcePool: opts.factory must be a function');
    }

    this.name                = opts.name                ?? 'pool';
    this.factory             = opts.factory;
    this.destroy             = opts.destroy             ?? (() => Promise.resolve());
    this.healthCheck         = opts.healthCheck         ?? null;
    this.size                = opts.size                ?? 10;
    this.acquireTimeout      = opts.acquireTimeout      ?? 5_000;
    this.healthCheckInterval = opts.healthCheckInterval ?? 0;

    /** @type {Array<{resource: *, healthy: boolean, createdAt: number, lastUsed: number}>} */
    this._idle = [];

    /** @type {Set<*>} Resources currently in use */
    this._inUse = new Set();

    /** @type {Array<{resolve: Function, reject: Function, timer: *}>} Waiters queue */
    this._waiters = [];

    /** @type {number} Total resources ever created */
    this._created = 0;

    /** @type {number} Total resources ever destroyed */
    this._destroyed = 0;

    /** @type {*|null} Interval handle for health sweeps */
    this._healthTimer = null;

    if (this.healthCheckInterval > 0) {
      this._startHealthSweep();
    }
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Acquire a resource from the pool.  Waits up to acquireTimeout if none are available.
   *
   * @returns {Promise<*>} The acquired resource
   * @throws {PoolTimeoutError} If no resource becomes available within acquireTimeout
   */
  acquire() {
    return new Promise((resolve, reject) => {
      // Try to serve immediately from idle
      if (this._idle.length > 0) {
        const entry = this._idle.pop();
        this._inUse.add(entry.resource);
        entry.lastUsed = Date.now();
        this.emit('acquire', { pool: this.name, inUse: this._inUse.size });
        return resolve(entry.resource);
      }

      // Can we create a new resource?
      if (this._inUse.size + this._idle.length < this.size) {
        this._create()
          .then((resource) => {
            this._inUse.add(resource);
            this.emit('acquire', { pool: this.name, inUse: this._inUse.size });
            resolve(resource);
          })
          .catch(reject);
        return;
      }

      // Queue the waiter
      const timer = setTimeout(() => {
        const idx = this._waiters.findIndex((w) => w.reject === reject);
        if (idx !== -1) this._waiters.splice(idx, 1);
        reject(new PoolTimeoutError(
          `Pool "${this.name}" acquire timeout after ${this.acquireTimeout} ms`,
        ));
      }, this.acquireTimeout);

      if (timer.unref) timer.unref();
      this._waiters.push({ resolve, reject, timer });
    });
  }

  /**
   * Return a resource to the pool.  Notifies the next waiter if present.
   *
   * @param {*} resource - The resource to release
   */
  release(resource) {
    if (!this._inUse.has(resource)) {
      this.emit('error', new Error(`Pool "${this.name}": released resource not recognized`));
      return;
    }

    this._inUse.delete(resource);

    // Serve next waiter directly
    if (this._waiters.length > 0) {
      const waiter = this._waiters.shift();
      clearTimeout(waiter.timer);
      this._inUse.add(resource);
      this.emit('acquire', { pool: this.name, inUse: this._inUse.size });
      return waiter.resolve(resource);
    }

    this._idle.push({ resource, healthy: true, createdAt: 0, lastUsed: Date.now() });
    this.emit('release', { pool: this.name, idle: this._idle.length });
  }

  /**
   * Drain and destroy all idle resources.  Does not wait for in-use resources.
   *
   * @returns {Promise<void>}
   */
  async drain() {
    this._stopHealthSweep();
    const toDestroy = this._idle.splice(0);
    await Promise.allSettled(toDestroy.map((e) => this._destroyEntry(e)));
    this.emit('drain', { pool: this.name });
  }

  /**
   * Pool statistics snapshot.
   *
   * @returns {{ name: string, idle: number, inUse: number, waiting: number, created: number, destroyed: number }}
   */
  stats() {
    return {
      name:      this.name,
      idle:      this._idle.length,
      inUse:     this._inUse.size,
      waiting:   this._waiters.length,
      created:   this._created,
      destroyed: this._destroyed,
    };
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Create a new resource via factory.
   * @returns {Promise<*>}
   */
  async _create() {
    const resource = await this.factory();
    this._created++;
    this.emit('created', { pool: this.name, total: this._created });
    return resource;
  }

  /**
   * @private Destroy a pool entry.
   * @param {{ resource: * }} entry
   * @returns {Promise<void>}
   */
  async _destroyEntry(entry) {
    try {
      await this.destroy(entry.resource);
    } catch (_) {
      // swallow destroy errors
    }
    this._destroyed++;
    this.emit('destroyed', { pool: this.name, total: this._destroyed });
  }

  /**
   * @private Run a health sweep — evict unhealthy idle resources.
   */
  async _runHealthSweep() {
    if (!this.healthCheck) return;

    const checks = this._idle.map(async (entry, idx) => {
      try {
        const ok = await this.healthCheck(entry.resource);
        if (!ok) throw new Error('unhealthy');
      } catch (_) {
        this._idle.splice(idx, 1);
        await this._destroyEntry(entry);
        this.emit('evicted', { pool: this.name });
      }
    });

    await Promise.allSettled(checks);
  }

  /** @private Start background health sweep interval. */
  _startHealthSweep() {
    this._healthTimer = setInterval(
      () => this._runHealthSweep(),
      this.healthCheckInterval,
    );
    if (this._healthTimer.unref) this._healthTimer.unref();
  }

  /** @private Stop background health sweep. */
  _stopHealthSweep() {
    if (this._healthTimer) {
      clearInterval(this._healthTimer);
      this._healthTimer = null;
    }
  }
}

// ─── Error Types ─────────────────────────────────────────────────────────────

/**
 * @class PoolTimeoutError
 * @extends Error
 */
class PoolTimeoutError extends Error {
  /** @param {string} message */
  constructor(message) {
    super(message);
    this.name = 'PoolTimeoutError';
  }
}

module.exports = { ResourcePool, PoolTimeoutError };
