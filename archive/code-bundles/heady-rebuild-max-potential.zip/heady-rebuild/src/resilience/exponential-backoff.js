/**
 * @file exponential-backoff.js
 * @description PHI-scaled exponential backoff — delay grows by the golden ratio
 *              on each retry attempt, producing naturally spaced retry windows.
 *
 * Sequence (base 1000 ms):
 *   attempt 0 → 1000 ms
 *   attempt 1 → 1618 ms
 *   attempt 2 → 2618 ms
 *   attempt 3 → 4236 ms
 *   attempt 4 → 6854 ms
 *   ...
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

/** Golden ratio */
const PHI = 1.6180339887;

/**
 * Compute the raw PHI-scaled delay for a given attempt.
 *
 * @param {number} attempt   - Zero-based attempt index
 * @param {number} baseDelay - Base delay in ms (default 1000)
 * @returns {number} Raw delay in ms before jitter / cap
 */
function computeDelay(attempt, baseDelay = 1000) {
  return baseDelay * Math.pow(PHI, attempt);
}

/**
 * Apply optional jitter to a delay to prevent thundering-herd.
 * Uses full-jitter: random value in [0, delay].
 *
 * @param {number}  delay  - Base delay in ms
 * @param {boolean} jitter - Whether to apply jitter
 * @returns {number} Jittered delay in ms
 */
function applyJitter(delay, jitter) {
  return jitter ? Math.random() * delay : delay;
}

/**
 * Sleep for `ms` milliseconds.
 *
 * @param {number} ms
 * @returns {Promise<void>}
 */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Execute an async function with PHI-scaled exponential backoff on failure.
 *
 * @param {Function} fn                     - Async function to call on each attempt
 * @param {object}   [opts]                 - Options
 * @param {number}   [opts.maxAttempts=5]   - Maximum number of total attempts
 * @param {number}   [opts.baseDelay=1000]  - Base delay in ms
 * @param {number}   [opts.maxDelay=60000]  - Upper cap on delay in ms
 * @param {boolean}  [opts.jitter=true]     - Add full-jitter to each delay
 * @param {Function} [opts.onRetry]         - Called before each retry: (attempt, delay, err) => void
 * @param {Function} [opts.shouldRetry]     - (err) => boolean — override retryability
 * @returns {Promise<*>} Resolves with fn() result or rejects after exhausting attempts
 *
 * @example
 * const data = await withBackoff(() => fetch('https://api.example.com/data'), {
 *   maxAttempts: 6,
 *   baseDelay:   500,
 *   jitter:      true,
 * });
 */
async function withBackoff(fn, opts = {}) {
  const maxAttempts = opts.maxAttempts ?? 5;
  const baseDelay   = opts.baseDelay   ?? 1000;
  const maxDelay    = opts.maxDelay    ?? 60_000;
  const jitter      = opts.jitter      ?? true;
  const onRetry     = opts.onRetry     ?? null;
  const shouldRetry = opts.shouldRetry ?? (() => true);

  let lastErr;

  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    try {
      return await fn(attempt);
    } catch (err) {
      lastErr = err;

      const isLast = attempt === maxAttempts - 1;
      if (isLast || !shouldRetry(err)) {
        throw err;
      }

      const raw    = computeDelay(attempt, baseDelay);
      const capped = Math.min(raw, maxDelay);
      const delay  = Math.round(applyJitter(capped, jitter));

      if (typeof onRetry === 'function') {
        onRetry(attempt + 1, delay, err);
      }

      await sleep(delay);
    }
  }

  throw lastErr;
}

/**
 * Build a delay schedule array for inspection / testing.
 *
 * @param {object} [opts]
 * @param {number} [opts.maxAttempts=5]
 * @param {number} [opts.baseDelay=1000]
 * @param {number} [opts.maxDelay=60000]
 * @returns {number[]} Array of delays (ms) for attempts 0…maxAttempts-2
 */
function buildSchedule(opts = {}) {
  const maxAttempts = opts.maxAttempts ?? 5;
  const baseDelay   = opts.baseDelay   ?? 1000;
  const maxDelay    = opts.maxDelay    ?? 60_000;

  return Array.from({ length: maxAttempts - 1 }, (_, i) =>
    Math.round(Math.min(computeDelay(i, baseDelay), maxDelay)),
  );
}

module.exports = { withBackoff, computeDelay, applyJitter, sleep, buildSchedule, PHI };
