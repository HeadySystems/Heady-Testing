/**
 * @file circuit-breaker.js
 * @description CircuitBreaker — protects downstream services by opening on repeated failures
 *              and allowing recovery through a HALF_OPEN probe window.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 *
 * States:
 *  CLOSED    — normal operation; failures are counted
 *  OPEN      — circuit tripped; calls fail immediately
 *  HALF_OPEN — probe window; limited calls allowed to test recovery
 *
 * PHI-derived default reset timeout: PHI^6 * 1000 ≈ 17944 ms
 */

'use strict';

const { EventEmitter } = require('events');

/** Golden ratio. Used for PHI-derived timing defaults. */
const PHI = 1.6180339887;

/** PHI^6 * 1000 — default OPEN → HALF_OPEN reset timeout in ms */
const PHI6_MS = Math.round(Math.pow(PHI, 6) * 1000); // ~17944

/** Circuit states enum */
const STATES = Object.freeze({
  CLOSED:    'CLOSED',
  OPEN:      'OPEN',
  HALF_OPEN: 'HALF_OPEN',
});

/**
 * @class CircuitBreaker
 * @extends EventEmitter
 *
 * @example
 * const cb = new CircuitBreaker({ failureThreshold: 5 });
 * const result = await cb.fire(() => fetch('https://api.example.com/data'));
 */
class CircuitBreaker extends EventEmitter {
  /**
   * @param {object}  [opts]                       - Configuration options
   * @param {number}  [opts.failureThreshold=5]    - Consecutive failures before OPEN
   * @param {number}  [opts.resetTimeout=17944]    - ms before OPEN → HALF_OPEN (default PHI^6*1000)
   * @param {number}  [opts.halfOpenMaxRequests=1] - Max probe requests in HALF_OPEN
   * @param {string}  [opts.name='circuit']        - Circuit name for logging / events
   */
  constructor(opts = {}) {
    super();
    this.name               = opts.name               ?? 'circuit';
    this.failureThreshold   = opts.failureThreshold   ?? 5;
    this.resetTimeout       = opts.resetTimeout       ?? PHI6_MS;
    this.halfOpenMaxRequests = opts.halfOpenMaxRequests ?? 1;

    /** @type {string} */
    this._state = STATES.CLOSED;

    /** @type {number} Consecutive failure count */
    this._failures = 0;

    /** @type {number} Successes recorded in current HALF_OPEN window */
    this._halfOpenSuccesses = 0;

    /** @type {number} Requests in-flight during HALF_OPEN */
    this._halfOpenRequests = 0;

    /** @type {number|null} Timer handle for OPEN → HALF_OPEN transition */
    this._resetTimer = null;

    /** @type {number} Total lifetime calls */
    this._totalCalls = 0;

    /** @type {number} Total lifetime successes */
    this._totalSuccesses = 0;

    /** @type {number} Total lifetime failures */
    this._totalFailures = 0;

    /** @type {number} Calls rejected while OPEN */
    this._rejected = 0;
  }

  // ─── State Helpers ──────────────────────────────────────────────────────────

  /**
   * @returns {string} Current state (CLOSED | OPEN | HALF_OPEN)
   */
  get state() {
    return this._state;
  }

  /**
   * @private Transition to a new state and emit an event.
   * @param {string} newState
   */
  _transition(newState) {
    const prev = this._state;
    this._state = newState;
    this.emit('stateChange', { circuit: this.name, from: prev, to: newState, ts: Date.now() });
  }

  // ─── Core API ───────────────────────────────────────────────────────────────

  /**
   * Execute an async action through the circuit breaker.
   *
   * @param {Function} action - Async function to execute
   * @returns {Promise<*>} Resolves with action result or rejects with CircuitOpenError
   * @throws {CircuitOpenError} When circuit is OPEN
   */
  async fire(action) {
    if (this._state === STATES.OPEN) {
      this._rejected++;
      const err = new CircuitOpenError(
        `Circuit "${this.name}" is OPEN — call rejected`,
        { circuit: this.name, resetIn: this._resetTimer ? this.resetTimeout : null },
      );
      this.emit('rejected', { circuit: this.name, ts: Date.now() });
      throw err;
    }

    if (this._state === STATES.HALF_OPEN) {
      if (this._halfOpenRequests >= this.halfOpenMaxRequests) {
        this._rejected++;
        throw new CircuitOpenError(
          `Circuit "${this.name}" HALF_OPEN probe quota exceeded`,
          { circuit: this.name },
        );
      }
      this._halfOpenRequests++;
    }

    this._totalCalls++;
    try {
      const result = await action();
      this.success();
      return result;
    } catch (err) {
      this.fail(err);
      throw err;
    }
  }

  /**
   * Record a successful call.  Resets failure count; closes circuit from HALF_OPEN.
   */
  success() {
    this._totalSuccesses++;
    this._failures = 0;

    if (this._state === STATES.HALF_OPEN) {
      this._halfOpenSuccesses++;
      this._halfOpenRequests = Math.max(0, this._halfOpenRequests - 1);
      this._close();
    }
  }

  /**
   * Record a failed call.  Increments failure count; may trip to OPEN.
   *
   * @param {Error} [err] - The error that caused the failure
   */
  fail(err) {
    this._totalFailures++;
    this._failures++;

    if (this._state === STATES.HALF_OPEN) {
      // Probe failed — go back to OPEN
      this._open();
      return;
    }

    if (this._failures >= this.failureThreshold) {
      this._open();
    }
  }

  // ─── Monitoring ─────────────────────────────────────────────────────────────

  /**
   * Return a snapshot of circuit status for monitoring / health checks.
   *
   * @returns {{
   *   name: string,
   *   state: string,
   *   failures: number,
   *   totalCalls: number,
   *   totalSuccesses: number,
   *   totalFailures: number,
   *   rejected: number,
   *   failureThreshold: number,
   *   resetTimeout: number
   * }}
   */
  getStatus() {
    return {
      name:             this.name,
      state:            this._state,
      failures:         this._failures,
      totalCalls:       this._totalCalls,
      totalSuccesses:   this._totalSuccesses,
      totalFailures:    this._totalFailures,
      rejected:         this._rejected,
      failureThreshold: this.failureThreshold,
      resetTimeout:     this.resetTimeout,
    };
  }

  // ─── Internal State Machines ─────────────────────────────────────────────────

  /** @private Trip the circuit to OPEN state and schedule reset. */
  _open() {
    if (this._resetTimer) clearTimeout(this._resetTimer);
    this._transition(STATES.OPEN);
    this.emit('open', { circuit: this.name, failures: this._failures, ts: Date.now() });
    this._resetTimer = setTimeout(() => this._halfOpen(), this.resetTimeout);
    // Allow GC — don't prevent process exit
    if (this._resetTimer.unref) this._resetTimer.unref();
  }

  /** @private Move to HALF_OPEN probe window. */
  _halfOpen() {
    this._resetTimer = null;
    this._halfOpenRequests = 0;
    this._halfOpenSuccesses = 0;
    this._transition(STATES.HALF_OPEN);
    this.emit('halfOpen', { circuit: this.name, ts: Date.now() });
  }

  /** @private Close the circuit after successful probe or manual reset. */
  _close() {
    if (this._resetTimer) {
      clearTimeout(this._resetTimer);
      this._resetTimer = null;
    }
    this._failures = 0;
    this._halfOpenRequests = 0;
    this._transition(STATES.CLOSED);
    this.emit('close', { circuit: this.name, ts: Date.now() });
  }

  /**
   * Manually reset the circuit to CLOSED state (e.g. after manual incident resolution).
   */
  reset() {
    this._close();
  }
}

// ─── Error Types ──────────────────────────────────────────────────────────────

/**
 * @class CircuitOpenError
 * @extends Error
 * Thrown when a call is rejected because the circuit is OPEN.
 */
class CircuitOpenError extends Error {
  /**
   * @param {string} message
   * @param {object} [meta]
   */
  constructor(message, meta = {}) {
    super(message);
    this.name = 'CircuitOpenError';
    this.meta = meta;
  }
}

module.exports = { CircuitBreaker, CircuitOpenError, STATES, PHI6_MS };
