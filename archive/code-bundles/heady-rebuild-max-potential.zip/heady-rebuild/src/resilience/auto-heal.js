/**
 * @file auto-heal.js
 * @description Self-healing module — monitors registered services, detects failures
 *              via health checks, automatically restarts/recovers, quarantines
 *              persistently-failing services, and maintains an event log.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const { EventEmitter } = require('events');

const PHI = 1.6180339887;

/** PHI^8 * 1000 ms — default health check interval (~76 s) */
const DEFAULT_POLL_MS = Math.round(Math.pow(PHI, 8) * 1000);

/** PHI^6 * 1000 ms — default quarantine duration (~17 944 ms) */
const DEFAULT_QUARANTINE_MS = Math.round(Math.pow(PHI, 6) * 1000);

/**
 * @typedef {object} ServiceDescriptor
 * @property {string}   name               - Unique service name
 * @property {Function} healthCheck        - Async () => boolean
 * @property {Function} [restart]          - Async () => void — how to restart the service
 * @property {number}   [failureThreshold] - Consecutive failures before quarantine (default 3)
 * @property {number}   [quarantineMs]     - How long to quarantine before retrying (default PHI^6*1000)
 */

/**
 * @typedef {object} HealEvent
 * @property {string} type       - 'healthy'|'unhealthy'|'healing'|'healed'|'quarantined'|'respawned'
 * @property {string} service    - Service name
 * @property {number} ts         - Unix timestamp ms
 * @property {string} [message]
 */

/**
 * @class AutoHealer
 * @extends EventEmitter
 *
 * @example
 * const healer = new AutoHealer({ pollInterval: 30_000 });
 * healer.register({
 *   name:        'redis',
 *   healthCheck: () => redisClient.ping().then(() => true).catch(() => false),
 *   restart:     () => redisClient.connect(),
 * });
 * healer.start();
 */
class AutoHealer extends EventEmitter {
  /**
   * @param {object} [opts]
   * @param {number} [opts.pollInterval]    - ms between health sweep rounds (default PHI^8*1000)
   * @param {number} [opts.quarantineMs]    - Global quarantine duration override
   * @param {number} [opts.maxHealAttempts] - Max consecutive heal attempts before giving up (default 5)
   */
  constructor(opts = {}) {
    super();

    this.pollInterval    = opts.pollInterval    ?? DEFAULT_POLL_MS;
    this.quarantineMs    = opts.quarantineMs    ?? DEFAULT_QUARANTINE_MS;
    this.maxHealAttempts = opts.maxHealAttempts ?? 5;

    /** @type {Map<string, ServiceDescriptor & { failures: number, healAttempts: number, quarantinedUntil: number|null }>} */
    this._services = new Map();

    /** @type {HealEvent[]} */
    this._log = [];

    /** @type {*|null} Interval handle */
    this._timer = null;

    /** @type {boolean} */
    this._running = false;
  }

  // ─── Registration ────────────────────────────────────────────────────────────

  /**
   * Register a service for monitoring.
   *
   * @param {ServiceDescriptor} descriptor
   */
  register(descriptor) {
    if (!descriptor.name)        throw new TypeError('AutoHealer: service must have a name');
    if (typeof descriptor.healthCheck !== 'function') {
      throw new TypeError('AutoHealer: service must have a healthCheck function');
    }

    this._services.set(descriptor.name, {
      ...descriptor,
      failures:          0,
      healAttempts:      0,
      quarantinedUntil:  null,
    });

    this._addLog({ type: 'registered', service: descriptor.name, message: 'Service registered for monitoring' });
  }

  /**
   * Unregister a service.
   *
   * @param {string} name
   */
  unregister(name) {
    this._services.delete(name);
  }

  // ─── Lifecycle ───────────────────────────────────────────────────────────────

  /**
   * Start the periodic health sweep.
   */
  start() {
    if (this._running) return;
    this._running = true;
    this._timer = setInterval(() => this._sweep(), this.pollInterval);
    if (this._timer.unref) this._timer.unref();
    this.emit('started', { pollInterval: this.pollInterval });
  }

  /**
   * Stop the health sweep.
   */
  stop() {
    if (!this._running) return;
    this._running = false;
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
    this.emit('stopped', {});
  }

  /**
   * Manually trigger a single health sweep.
   *
   * @returns {Promise<void>}
   */
  async sweep() {
    return this._sweep();
  }

  // ─── Monitoring ─────────────────────────────────────────────────────────────

  /**
   * Return the current healing event log.
   *
   * @param {number} [limit] - Return only the last N events
   * @returns {HealEvent[]}
   */
  getLog(limit) {
    if (limit != null) return this._log.slice(-limit);
    return [...this._log];
  }

  /**
   * Return status snapshot for all registered services.
   *
   * @returns {Array<{ name: string, failures: number, quarantined: boolean, healAttempts: number }>}
   */
  getStatus() {
    const now = Date.now();
    return Array.from(this._services.values()).map((svc) => ({
      name:         svc.name,
      failures:     svc.failures,
      quarantined:  svc.quarantinedUntil != null && svc.quarantinedUntil > now,
      healAttempts: svc.healAttempts,
    }));
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Run a single health sweep across all services.
   */
  async _sweep() {
    const checks = Array.from(this._services.values()).map((svc) =>
      this._checkService(svc).catch((err) =>
        this._addLog({ type: 'error', service: svc.name, message: err.message }),
      ),
    );
    await Promise.allSettled(checks);
  }

  /**
   * @private Check and react to a single service's health.
   * @param {object} svc
   */
  async _checkService(svc) {
    const now = Date.now();

    // Skip quarantined services
    if (svc.quarantinedUntil != null && now < svc.quarantinedUntil) {
      return;
    }

    // Clear quarantine if window has passed
    if (svc.quarantinedUntil != null && now >= svc.quarantinedUntil) {
      svc.quarantinedUntil = null;
      svc.healAttempts     = 0;
      this._addLog({ type: 'respawned', service: svc.name, message: 'Quarantine lifted — monitoring resumed' });
      this.emit('respawned', { service: svc.name });
    }

    let healthy = false;
    try {
      healthy = await svc.healthCheck();
    } catch (_) {
      healthy = false;
    }

    if (healthy) {
      if (svc.failures > 0) {
        this._addLog({ type: 'healed', service: svc.name, message: `Recovered after ${svc.failures} failures` });
        this.emit('healed', { service: svc.name });
      }
      svc.failures     = 0;
      svc.healAttempts = 0;
      this.emit('healthy', { service: svc.name, ts: now });
      return;
    }

    // Unhealthy
    svc.failures++;
    this._addLog({ type: 'unhealthy', service: svc.name, message: `Failure #${svc.failures}` });
    this.emit('unhealthy', { service: svc.name, failures: svc.failures });

    const threshold = svc.failureThreshold ?? 3;

    if (svc.failures >= threshold) {
      if (svc.healAttempts >= this.maxHealAttempts) {
        // Quarantine
        const qtUntil = now + (svc.quarantineMs ?? this.quarantineMs);
        svc.quarantinedUntil = qtUntil;
        this._addLog({ type: 'quarantined', service: svc.name, message: `Quarantined until ${new Date(qtUntil).toISOString()}` });
        this.emit('quarantined', { service: svc.name, until: qtUntil });
        return;
      }

      // Attempt restart
      if (typeof svc.restart === 'function') {
        svc.healAttempts++;
        this._addLog({ type: 'healing', service: svc.name, message: `Restart attempt #${svc.healAttempts}` });
        this.emit('healing', { service: svc.name, attempt: svc.healAttempts });
        try {
          await svc.restart();
          svc.failures = 0;
          this._addLog({ type: 'healed', service: svc.name, message: 'Restart succeeded' });
          this.emit('healed', { service: svc.name });
        } catch (err) {
          this._addLog({ type: 'healFailed', service: svc.name, message: `Restart failed: ${err.message}` });
          this.emit('healFailed', { service: svc.name, error: err.message });
        }
      }
    }
  }

  /**
   * @private Append an event to the healing log.
   * @param {{ type: string, service: string, message?: string }} evt
   */
  _addLog(evt) {
    this._log.push({ ...evt, ts: Date.now() });
    // Cap log at 1000 entries
    if (this._log.length > 1000) this._log.shift();
  }
}

module.exports = { AutoHealer, DEFAULT_POLL_MS, DEFAULT_QUARANTINE_MS };
