/**
 * @file index.js
 * @description Resilience layer — central export for all resilience modules.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 *
 * @module resilience
 *
 * @example
 * const {
 *   CircuitBreaker,
 *   withBackoff,
 *   ResourcePool,
 *   RateLimiter,
 *   MultiTierCache,
 *   retry,
 *   AutoHealer,
 * } = require('./src/resilience');
 */

'use strict';

const circuitBreaker   = require('./circuit-breaker');
const exponentialBackoff = require('./exponential-backoff');
const pool             = require('./pool');
const rateLimiter      = require('./rate-limiter');
const cache            = require('./cache');
const retryModule      = require('./retry');
const autoHeal         = require('./auto-heal');

module.exports = {
  // ── Circuit Breaker ─────────────────────────────────────────────────────
  /** @see module:resilience/circuit-breaker */
  CircuitBreaker:   circuitBreaker.CircuitBreaker,
  CircuitOpenError: circuitBreaker.CircuitOpenError,
  CIRCUIT_STATES:   circuitBreaker.STATES,
  PHI6_MS:          circuitBreaker.PHI6_MS,

  // ── Exponential Backoff ─────────────────────────────────────────────────
  /** @see module:resilience/exponential-backoff */
  withBackoff:    exponentialBackoff.withBackoff,
  computeDelay:   exponentialBackoff.computeDelay,
  buildSchedule:  exponentialBackoff.buildSchedule,
  sleep:          exponentialBackoff.sleep,

  // ── Resource Pool ────────────────────────────────────────────────────────
  /** @see module:resilience/pool */
  ResourcePool:     pool.ResourcePool,
  PoolTimeoutError: pool.PoolTimeoutError,

  // ── Rate Limiter ─────────────────────────────────────────────────────────
  /** @see module:resilience/rate-limiter */
  RateLimiter:  rateLimiter.RateLimiter,
  TokenBucket:  rateLimiter.TokenBucket,

  // ── Cache ────────────────────────────────────────────────────────────────
  /** @see module:resilience/cache */
  MultiTierCache:    cache.MultiTierCache,
  L1Cache:           cache.L1Cache,
  L2Cache:           cache.L2Cache,
  L1_TTL:            cache.L1_TTL,
  L2_TTL:            cache.L2_TTL,
  dynamicMaxEntries: cache.dynamicMaxEntries,

  // ── Retry ────────────────────────────────────────────────────────────────
  /** @see module:resilience/retry */
  retry:         retryModule.retry,
  withRetry:     retryModule.withRetry,
  isRetryable:   retryModule.isRetryable,
  classifyError: retryModule.classifyError,

  // ── Auto Healer ──────────────────────────────────────────────────────────
  /** @see module:resilience/auto-heal */
  AutoHealer:            autoHeal.AutoHealer,
  DEFAULT_POLL_MS:       autoHeal.DEFAULT_POLL_MS,
  DEFAULT_QUARANTINE_MS: autoHeal.DEFAULT_QUARANTINE_MS,
};
