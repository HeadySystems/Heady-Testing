/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║  HCFullPipeline — Runtime Engine                                           ║
 * ║  Heady™ Systems · Sacred Geometry Architecture                             ║
 * ║  © 2026 HeadySystems Inc. All rights reserved.                             ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  The pipeline is the spine of the organism. Every stage flows through it.   ║
 * ║  PHI governs timing. Circuit breakers protect the edges.                   ║
 * ║  Fail-closed by default. Simulation mode for development.                  ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * @module hc_pipeline
 * @version 4.0.0
 * @author HeadySystems Engineering
 */

'use strict';

const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');

// ─── Sacred Constants ──────────────────────────────────────────────────────────

/** @constant {number} PHI - The golden ratio, governs all timing intervals */
const PHI = 1.6180339887;

/** @constant {number} DEFAULT_CACHE_TTL - Default task result cache TTL in ms (1 hour) */
const DEFAULT_CACHE_TTL = 3600000;

/** @constant {number} DEFAULT_CIRCUIT_FAILURE_THRESHOLD - Failures before circuit opens */
const DEFAULT_CIRCUIT_FAILURE_THRESHOLD = 5;

/** @constant {number} DEFAULT_CIRCUIT_RESET_TIMEOUT - Circuit breaker reset timeout in ms */
const DEFAULT_CIRCUIT_RESET_TIMEOUT = Math.round(30000 * PHI);

/** @constant {number} CHECKPOINT_DRIFT_WARN - Warning threshold for config drift (%) */
const CHECKPOINT_DRIFT_WARN = 10;

/** @constant {number} CHECKPOINT_DRIFT_ESCALATE - Escalation threshold for config drift (%) */
const CHECKPOINT_DRIFT_ESCALATE = 25;

// ─── RunStatus Enum ────────────────────────────────────────────────────────────

/**
 * Pipeline run status enumeration.
 * @readonly
 * @enum {string}
 */
const RunStatus = Object.freeze({
  IDLE:      'IDLE',
  RUNNING:   'RUNNING',
  PAUSED:    'PAUSED',
  RECOVERY:  'RECOVERY',
  HALTED:    'HALTED',
  COMPLETED: 'COMPLETED',
  FAILED:    'FAILED',
});

// ─── Config Loader ─────────────────────────────────────────────────────────────

/**
 * Search multiple config paths and load the first YAML/JSON config found.
 * Falls back to sensible defaults if no config file exists.
 *
 * @param {string} [filename='hc-pipeline.yaml'] - Config filename to search for.
 * @returns {Object} Parsed configuration object.
 */
function loadYaml(filename = 'hc-pipeline.yaml') {
  const searchPaths = [
    process.env.HC_CONFIG_PATH,
    path.join(process.cwd(), 'config'),
    path.join(process.cwd()),
    path.join(os.homedir(), '.heady'),
    '/etc/heady',
    path.resolve(__dirname, '..', 'config'),
    path.resolve(__dirname, 'config'),
  ].filter(Boolean);

  for (const dir of searchPaths) {
    const yamlPath = path.join(dir, filename);
    const jsonPath = path.join(dir, filename.replace(/\.ya?ml$/, '.json'));

    for (const candidate of [yamlPath, jsonPath]) {
      try {
        if (fs.existsSync(candidate)) {
          const raw = fs.readFileSync(candidate, 'utf-8');
          if (candidate.endsWith('.json')) {
            return JSON.parse(raw);
          }
          // Simple YAML parser for flat/nested configs
          return _parseSimpleYaml(raw);
        }
      } catch (err) {
        // Continue searching
      }
    }
  }

  // Return default configuration
  return _defaultConfig();
}

/**
 * Minimal YAML parser for structured config files.
 * Handles nested keys, arrays, and scalar values.
 *
 * @private
 * @param {string} raw - Raw YAML string.
 * @returns {Object} Parsed config object.
 */
function _parseSimpleYaml(raw) {
  const result = {};
  const lines = raw.split('\n');
  const stack = [{ obj: result, indent: -1 }];

  for (const line of lines) {
    const trimmed = line.replace(/#.*$/, '').trimEnd();
    if (!trimmed || trimmed.trim() === '') continue;

    const indent = line.search(/\S/);
    const match = trimmed.trim().match(/^([^:]+):\s*(.*)$/);
    if (!match) continue;

    const key = match[1].trim();
    const value = match[2].trim();

    // Pop stack to find parent
    while (stack.length > 1 && stack[stack.length - 1].indent >= indent) {
      stack.pop();
    }

    const parent = stack[stack.length - 1].obj;

    if (value === '' || value === '|' || value === '>') {
      // Nested object
      parent[key] = {};
      stack.push({ obj: parent[key], indent });
    } else if (value.startsWith('[') && value.endsWith(']')) {
      // Inline array
      parent[key] = value.slice(1, -1).split(',').map(s => _castYamlValue(s.trim()));
    } else {
      parent[key] = _castYamlValue(value);
    }
  }

  return result;
}

/**
 * Cast a YAML string value to the appropriate JS type.
 * @private
 * @param {string} val - Raw string value.
 * @returns {*} Typed value.
 */
function _castYamlValue(val) {
  if (val === 'true') return true;
  if (val === 'false') return false;
  if (val === 'null' || val === '~') return null;
  if (/^-?\d+$/.test(val)) return parseInt(val, 10);
  if (/^-?\d+\.\d+$/.test(val)) return parseFloat(val);
  if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
    return val.slice(1, -1);
  }
  return val;
}

/**
 * Return default pipeline configuration.
 * @private
 * @returns {Object} Default config.
 */
function _defaultConfig() {
  return {
    pipeline: {
      name: 'hc-default',
      version: '4.0.0',
      simulationMode: false,
      maxConcurrency: 8,
      cacheEnabled: true,
      cacheTtl: DEFAULT_CACHE_TTL,
      checkpointEnabled: true,
    },
    circuitBreaker: {
      failureThreshold: DEFAULT_CIRCUIT_FAILURE_THRESHOLD,
      resetTimeout: DEFAULT_CIRCUIT_RESET_TIMEOUT,
      halfOpenMax: 2,
    },
    stopRules: {
      maxErrorRate: 0.25,
      minReadinessScore: 0.5,
      criticalAlarmHalt: true,
      dataIntegrityHalt: true,
    },
    nodePools: {
      hot: { maxTasks: 50, priority: 1 },
      warm: { maxTasks: 200, priority: 2 },
      cold: { maxTasks: 1000, priority: 3 },
    },
    stages: [],
  };
}

// ─── CircuitBreaker ────────────────────────────────────────────────────────────

/**
 * Circuit breaker states.
 * @readonly
 * @enum {string}
 */
const CBState = Object.freeze({
  CLOSED:    'CLOSED',
  OPEN:      'OPEN',
  HALF_OPEN: 'HALF_OPEN',
});

/**
 * Circuit breaker implementation for endpoint/task protection.
 * Transitions: CLOSED → OPEN (on threshold) → HALF_OPEN (after timeout) → CLOSED (on success) or OPEN (on failure).
 *
 * @class CircuitBreaker
 */
class CircuitBreaker {
  /**
   * @param {Object} opts
   * @param {string} opts.name - Circuit breaker name/identifier.
   * @param {number} [opts.failureThreshold=5] - Consecutive failures before opening.
   * @param {number} [opts.resetTimeout=48541] - Time in ms before transitioning to half-open.
   * @param {number} [opts.halfOpenMax=2] - Max concurrent requests in half-open state.
   */
  constructor({ name, failureThreshold, resetTimeout, halfOpenMax } = {}) {
    this.name = name || 'unnamed';
    this.failureThreshold = failureThreshold || DEFAULT_CIRCUIT_FAILURE_THRESHOLD;
    this.resetTimeout = resetTimeout || DEFAULT_CIRCUIT_RESET_TIMEOUT;
    this.halfOpenMax = halfOpenMax || 2;

    this.state = CBState.CLOSED;
    this.failureCount = 0;
    this.successCount = 0;
    this.lastFailureTime = null;
    this.lastStateChange = Date.now();
    this.halfOpenAttempts = 0;
    this._resetTimer = null;
    this._listeners = [];
  }

  /**
   * Register a state-change listener.
   * @param {Function} fn - Callback receiving (newState, oldState, breakerName).
   */
  onStateChange(fn) {
    this._listeners.push(fn);
  }

  /**
   * Emit state change to all listeners.
   * @private
   * @param {string} newState
   * @param {string} oldState
   */
  _emitChange(newState, oldState) {
    for (const fn of this._listeners) {
      try { fn(newState, oldState, this.name); } catch (_) { /* swallow */ }
    }
  }

  /**
   * Check if the circuit allows a request through.
   * @returns {boolean} True if the request should proceed.
   */
  canPass() {
    if (this.state === CBState.CLOSED) return true;

    if (this.state === CBState.OPEN) {
      const elapsed = Date.now() - this.lastFailureTime;
      if (elapsed >= this.resetTimeout) {
        this._transitionTo(CBState.HALF_OPEN);
        this.halfOpenAttempts = 0;
        return true;
      }
      return false;
    }

    // HALF_OPEN: allow limited attempts
    if (this.halfOpenAttempts < this.halfOpenMax) {
      this.halfOpenAttempts++;
      return true;
    }
    return false;
  }

  /**
   * Record a successful request.
   */
  recordSuccess() {
    this.successCount++;
    if (this.state === CBState.HALF_OPEN) {
      this._transitionTo(CBState.CLOSED);
      this.failureCount = 0;
      this.halfOpenAttempts = 0;
    } else if (this.state === CBState.CLOSED) {
      this.failureCount = Math.max(0, this.failureCount - 1);
    }
  }

  /**
   * Record a failed request.
   */
  recordFailure() {
    this.failureCount++;
    this.lastFailureTime = Date.now();

    if (this.state === CBState.HALF_OPEN) {
      this._transitionTo(CBState.OPEN);
      this._scheduleReset();
    } else if (this.state === CBState.CLOSED && this.failureCount >= this.failureThreshold) {
      this._transitionTo(CBState.OPEN);
      this._scheduleReset();
    }
  }

  /**
   * Force-reset the circuit breaker to CLOSED state.
   */
  reset() {
    this.failureCount = 0;
    this.halfOpenAttempts = 0;
    if (this._resetTimer) {
      clearTimeout(this._resetTimer);
      this._resetTimer = null;
    }
    this._transitionTo(CBState.CLOSED);
  }

  /**
   * Get a snapshot of the breaker state.
   * @returns {Object} State snapshot.
   */
  snapshot() {
    return {
      name: this.name,
      state: this.state,
      failureCount: this.failureCount,
      successCount: this.successCount,
      lastFailureTime: this.lastFailureTime,
      lastStateChange: this.lastStateChange,
      halfOpenAttempts: this.halfOpenAttempts,
    };
  }

  /**
   * @private
   * @param {string} newState
   */
  _transitionTo(newState) {
    const old = this.state;
    if (old === newState) return;
    this.state = newState;
    this.lastStateChange = Date.now();
    this._emitChange(newState, old);
  }

  /**
   * @private
   */
  _scheduleReset() {
    if (this._resetTimer) clearTimeout(this._resetTimer);
    this._resetTimer = setTimeout(() => {
      if (this.state === CBState.OPEN) {
        this._transitionTo(CBState.HALF_OPEN);
        this.halfOpenAttempts = 0;
      }
    }, this.resetTimeout);
    if (this._resetTimer.unref) this._resetTimer.unref();
  }

  /**
   * Destroy the circuit breaker and clear timers.
   */
  destroy() {
    if (this._resetTimer) {
      clearTimeout(this._resetTimer);
      this._resetTimer = null;
    }
    this._listeners = [];
  }
}

// ─── WorkerPool (Semaphore-based Concurrency Limiter) ──────────────────────────

/**
 * Semaphore-based concurrency limiter for parallel task execution.
 * Manages a pool of concurrent "worker slots" with queuing.
 *
 * @class WorkerPool
 */
class WorkerPool {
  /**
   * @param {number} [maxConcurrency=8] - Maximum concurrent tasks.
   */
  constructor(maxConcurrency = 8) {
    this.maxConcurrency = maxConcurrency;
    this.active = 0;
    this._queue = [];
    this._activeSet = new Set();
  }

  /**
   * Acquire a worker slot. Resolves when a slot is available.
   * @param {string} [taskId='anonymous'] - Task identifier for tracking.
   * @returns {Promise<Function>} Release function to call when done.
   */
  acquire(taskId = 'anonymous') {
    return new Promise((resolve) => {
      const tryAcquire = () => {
        if (this.active < this.maxConcurrency) {
          this.active++;
          this._activeSet.add(taskId);
          const release = () => {
            this.active--;
            this._activeSet.delete(taskId);
            this._processQueue();
          };
          resolve(release);
        } else {
          this._queue.push({ taskId, tryAcquire });
        }
      };
      tryAcquire();
    });
  }

  /**
   * Process queued acquisition requests.
   * @private
   */
  _processQueue() {
    while (this._queue.length > 0 && this.active < this.maxConcurrency) {
      const next = this._queue.shift();
      next.tryAcquire();
    }
  }

  /**
   * Get current pool utilization.
   * @returns {Object} Pool stats.
   */
  stats() {
    return {
      active: this.active,
      queued: this._queue.length,
      maxConcurrency: this.maxConcurrency,
      utilization: this.active / this.maxConcurrency,
      activeTasks: Array.from(this._activeSet),
    };
  }

  /**
   * Dynamically update the concurrency limit.
   * @param {number} newMax - New maximum concurrency.
   */
  resize(newMax) {
    this.maxConcurrency = Math.max(1, newMax);
    this._processQueue();
  }

  /**
   * Drain the pool: reject all queued tasks and wait for active ones.
   * @returns {Promise<void>}
   */
  drain() {
    this._queue = [];
    return new Promise((resolve) => {
      const check = () => {
        if (this.active === 0) return resolve();
        setTimeout(check, 100);
      };
      check();
    });
  }
}

// ─── Task Result Cache ─────────────────────────────────────────────────────────

/**
 * Disk-persisted task result cache with TTL, code-version-aware keys,
 * and dynamic size limits based on available memory.
 *
 * @class TaskResultCache
 */
class TaskResultCache {
  /**
   * @param {Object} opts
   * @param {string} [opts.cacheDir] - Directory for disk persistence.
   * @param {number} [opts.ttl=3600000] - Cache TTL in ms.
   * @param {string} [opts.codeVersion='0.0.0'] - Code version for cache key generation.
   */
  constructor({ cacheDir, ttl, codeVersion } = {}) {
    this.ttl = ttl || DEFAULT_CACHE_TTL;
    this.codeVersion = codeVersion || process.env.HC_CODE_VERSION || '0.0.0';
    this.cacheDir = cacheDir || path.join(os.tmpdir(), 'hc-pipeline-cache');
    this._memory = new Map();
    this._maxEntries = this._computeMaxEntries();
    this._hits = 0;
    this._misses = 0;

    try {
      if (!fs.existsSync(this.cacheDir)) {
        fs.mkdirSync(this.cacheDir, { recursive: true });
      }
    } catch (_) { /* best-effort */ }
  }

  /**
   * Compute max cache entries based on available system memory.
   * Uses PHI ratio to scale.
   * @private
   * @returns {number}
   */
  _computeMaxEntries() {
    const freeMem = os.freemem();
    const totalMem = os.totalmem();
    const freeRatio = freeMem / totalMem;
    // Scale entries: base 500, up to 5000 on high-memory systems
    const base = 500;
    const scaled = Math.floor(base + (freeRatio * base * PHI * PHI));
    return Math.min(scaled, 5000);
  }

  /**
   * Generate a cache key incorporating task identity and code version.
   * @param {string} taskType - The task type/handler name.
   * @param {Object} input - Task input parameters.
   * @returns {string} Cache key hash.
   */
  key(taskType, input) {
    const payload = JSON.stringify({ taskType, input, v: this.codeVersion });
    return crypto.createHash('sha256').update(payload).digest('hex');
  }

  /**
   * Get a cached result.
   * @param {string} cacheKey - The cache key.
   * @returns {*|null} Cached value or null if miss/expired.
   */
  get(cacheKey) {
    // Try in-memory first
    if (this._memory.has(cacheKey)) {
      const entry = this._memory.get(cacheKey);
      if (Date.now() - entry.ts <= this.ttl) {
        this._hits++;
        return entry.value;
      }
      this._memory.delete(cacheKey);
    }

    // Try disk
    const diskPath = path.join(this.cacheDir, `${cacheKey}.json`);
    try {
      if (fs.existsSync(diskPath)) {
        const raw = fs.readFileSync(diskPath, 'utf-8');
        const entry = JSON.parse(raw);
        if (Date.now() - entry.ts <= this.ttl) {
          this._hits++;
          // Promote to memory
          this._memory.set(cacheKey, entry);
          this._evictIfNeeded();
          return entry.value;
        }
        // Expired on disk
        try { fs.unlinkSync(diskPath); } catch (_) { /* best-effort */ }
      }
    } catch (_) { /* disk read failure is a miss */ }

    this._misses++;
    return null;
  }

  /**
   * Store a result in cache (memory + disk).
   * @param {string} cacheKey - The cache key.
   * @param {*} value - The value to cache.
   */
  set(cacheKey, value) {
    const entry = { ts: Date.now(), value, v: this.codeVersion };

    this._memory.set(cacheKey, entry);
    this._evictIfNeeded();

    // Persist to disk asynchronously
    const diskPath = path.join(this.cacheDir, `${cacheKey}.json`);
    try {
      fs.writeFileSync(diskPath, JSON.stringify(entry), 'utf-8');
    } catch (_) { /* best-effort disk write */ }
  }

  /**
   * Invalidate a specific cache entry.
   * @param {string} cacheKey
   */
  invalidate(cacheKey) {
    this._memory.delete(cacheKey);
    const diskPath = path.join(this.cacheDir, `${cacheKey}.json`);
    try { fs.unlinkSync(diskPath); } catch (_) { /* best-effort */ }
  }

  /**
   * Clear the entire cache.
   */
  clear() {
    this._memory.clear();
    try {
      const files = fs.readdirSync(this.cacheDir);
      for (const f of files) {
        try { fs.unlinkSync(path.join(this.cacheDir, f)); } catch (_) { /* skip */ }
      }
    } catch (_) { /* best-effort */ }
  }

  /**
   * Evict oldest entries if memory cache exceeds max size.
   * @private
   */
  _evictIfNeeded() {
    if (this._memory.size <= this._maxEntries) return;
    // Evict oldest entries (FIFO via insertion order)
    const excess = this._memory.size - this._maxEntries;
    const keys = this._memory.keys();
    for (let i = 0; i < excess; i++) {
      const k = keys.next().value;
      this._memory.delete(k);
    }
  }

  /**
   * Get cache statistics.
   * @returns {Object}
   */
  stats() {
    return {
      memoryEntries: this._memory.size,
      maxEntries: this._maxEntries,
      hits: this._hits,
      misses: this._misses,
      hitRate: this._hits + this._misses > 0
        ? this._hits / (this._hits + this._misses)
        : 0,
      ttl: this.ttl,
      codeVersion: this.codeVersion,
    };
  }
}

// ─── Topological Sort for DAG Dependencies ─────────────────────────────────────

/**
 * Perform a topological sort on a directed acyclic graph of stages.
 * Used for dependency resolution in stage execution.
 *
 * @param {Array<Object>} stages - Array of stage objects with `name` and `dependsOn` array.
 * @returns {Array<Array<Object>>} Layers of stages that can execute in parallel.
 * @throws {Error} If a cycle is detected.
 */
function topologicalSort(stages) {
  const stageMap = new Map();
  const inDegree = new Map();
  const adjacency = new Map();

  for (const stage of stages) {
    stageMap.set(stage.name, stage);
    inDegree.set(stage.name, 0);
    adjacency.set(stage.name, []);
  }

  for (const stage of stages) {
    const deps = stage.dependsOn || [];
    for (const dep of deps) {
      if (!stageMap.has(dep)) {
        throw new Error(`Stage "${stage.name}" depends on unknown stage "${dep}"`);
      }
      adjacency.get(dep).push(stage.name);
      inDegree.set(stage.name, inDegree.get(stage.name) + 1);
    }
  }

  const layers = [];
  let remaining = new Set(stageMap.keys());

  while (remaining.size > 0) {
    const layer = [];
    for (const name of remaining) {
      if (inDegree.get(name) === 0) {
        layer.push(name);
      }
    }

    if (layer.length === 0) {
      throw new Error(`Cycle detected in stage dependencies. Remaining: ${[...remaining].join(', ')}`);
    }

    layers.push(layer.map(n => stageMap.get(n)));

    for (const name of layer) {
      remaining.delete(name);
      for (const dependent of adjacency.get(name)) {
        inDegree.set(dependent, inDegree.get(dependent) - 1);
      }
    }
  }

  return layers;
}

// ─── Node Pool Priority Manager ────────────────────────────────────────────────

/**
 * Node pool priority classification for tasks.
 * Hot = latency-sensitive, Warm = standard, Cold = batch/background.
 *
 * @class NodePoolManager
 */
class NodePoolManager {
  /**
   * @param {Object} config - Node pool configuration.
   */
  constructor(config = {}) {
    this.pools = {
      hot:  { maxTasks: (config.hot  || {}).maxTasks || 50,  priority: 1, active: 0, tasks: [] },
      warm: { maxTasks: (config.warm || {}).maxTasks || 200, priority: 2, active: 0, tasks: [] },
      cold: { maxTasks: (config.cold || {}).maxTasks || 1000, priority: 3, active: 0, tasks: [] },
    };
    this._classificationRules = new Map();
  }

  /**
   * Register a classification rule for a task type.
   * @param {string} taskType - Task type identifier.
   * @param {'hot'|'warm'|'cold'} pool - Target pool.
   */
  registerClassification(taskType, pool) {
    this._classificationRules.set(taskType, pool);
  }

  /**
   * Classify a task into a pool based on registered rules or heuristics.
   * @param {Object} task - Task object with type, priority, deadline fields.
   * @returns {'hot'|'warm'|'cold'} Pool classification.
   */
  classify(task) {
    // Explicit rule
    if (this._classificationRules.has(task.type)) {
      return this._classificationRules.get(task.type);
    }
    // Priority-based heuristic
    if (task.priority === 'critical' || task.priority === 'high' || task.deadline) {
      return 'hot';
    }
    if (task.priority === 'low' || task.batch === true) {
      return 'cold';
    }
    return 'warm';
  }

  /**
   * Sort tasks by pool priority (hot first, then warm, then cold).
   * @param {Array<Object>} tasks - Tasks to sort.
   * @returns {Array<Object>} Sorted tasks with pool annotations.
   */
  prioritySort(tasks) {
    return tasks
      .map(t => ({ ...t, _pool: this.classify(t) }))
      .sort((a, b) => {
        const pa = this.pools[a._pool].priority;
        const pb = this.pools[b._pool].priority;
        return pa - pb;
      });
  }

  /**
   * Get pool utilization stats.
   * @returns {Object}
   */
  stats() {
    const result = {};
    for (const [name, pool] of Object.entries(this.pools)) {
      result[name] = {
        active: pool.active,
        maxTasks: pool.maxTasks,
        utilization: pool.active / pool.maxTasks,
      };
    }
    return result;
  }
}

// ─── Stop Rule Evaluator ───────────────────────────────────────────────────────

/**
 * Evaluate stop conditions to determine if the pipeline should halt.
 *
 * @param {Object} metrics - Current pipeline metrics.
 * @param {number} metrics.errorRate - Current error rate (0-1).
 * @param {number} metrics.readinessScore - System readiness score (0-1).
 * @param {boolean} metrics.criticalAlarm - Whether a critical alarm is active.
 * @param {boolean} metrics.dataIntegrityFailure - Whether a data integrity failure occurred.
 * @param {Object} rules - Stop rules from config.
 * @returns {Object} Evaluation result { shouldStop, reason, severity }.
 */
function evaluateStopRules(metrics, rules) {
  const violations = [];

  if (metrics.errorRate > (rules.maxErrorRate || 0.25)) {
    violations.push({
      rule: 'error_rate',
      message: `Error rate ${(metrics.errorRate * 100).toFixed(1)}% exceeds threshold ${((rules.maxErrorRate || 0.25) * 100).toFixed(1)}%`,
      severity: 'high',
    });
  }

  if (metrics.readinessScore < (rules.minReadinessScore || 0.5)) {
    violations.push({
      rule: 'readiness_score',
      message: `Readiness ${(metrics.readinessScore * 100).toFixed(1)}% below minimum ${((rules.minReadinessScore || 0.5) * 100).toFixed(1)}%`,
      severity: 'medium',
    });
  }

  if (metrics.criticalAlarm && (rules.criticalAlarmHalt !== false)) {
    violations.push({
      rule: 'critical_alarm',
      message: 'Critical alarm active — immediate halt required',
      severity: 'critical',
    });
  }

  if (metrics.dataIntegrityFailure && (rules.dataIntegrityHalt !== false)) {
    violations.push({
      rule: 'data_integrity_failure',
      message: 'Data integrity failure detected — pipeline halted',
      severity: 'critical',
    });
  }

  const shouldStop = violations.length > 0;
  const severity = violations.reduce((max, v) => {
    const order = { critical: 4, high: 3, medium: 2, low: 1 };
    return (order[v.severity] || 0) > (order[max] || 0) ? v.severity : max;
  }, 'low');

  return {
    shouldStop,
    violations,
    severity: shouldStop ? severity : 'none',
    reason: shouldStop ? violations.map(v => v.message).join('; ') : null,
  };
}

// ─── Checkpoint Protocol ───────────────────────────────────────────────────────

/**
 * Checkpoint protocol: compare configuration hashes, detect drift, and escalate.
 *
 * @class CheckpointProtocol
 */
class CheckpointProtocol {
  constructor() {
    this._baselineHash = null;
    this._checkpoints = [];
    this._driftHistory = [];
  }

  /**
   * Capture a configuration baseline.
   * @param {Object} config - The current configuration.
   */
  setBaseline(config) {
    this._baselineHash = this._hash(config);
    this._checkpoints = [{
      ts: Date.now(),
      hash: this._baselineHash,
      drift: 0,
    }];
  }

  /**
   * Check for configuration drift against baseline.
   * @param {Object} currentConfig - Current configuration to check.
   * @returns {Object} Drift report { driftDetected, driftPercent, action }.
   */
  checkDrift(currentConfig) {
    if (!this._baselineHash) {
      return { driftDetected: false, driftPercent: 0, action: 'none' };
    }

    const currentHash = this._hash(currentConfig);
    const identical = currentHash === this._baselineHash;

    if (identical) {
      this._checkpoints.push({ ts: Date.now(), hash: currentHash, drift: 0 });
      return { driftDetected: false, driftPercent: 0, action: 'none' };
    }

    // Compute drift magnitude by comparing serialized keys
    const baseKeys = this._flatKeys(JSON.parse(this._lastBaselineJson || '{}'));
    const currKeys = this._flatKeys(currentConfig);
    const allKeys = new Set([...baseKeys, ...currKeys]);
    const changedKeys = [...allKeys].filter(k => !baseKeys.includes(k) || !currKeys.includes(k));
    const driftPercent = allKeys.size > 0 ? (changedKeys.length / allKeys.size) * 100 : 0;

    let action = 'log';
    if (driftPercent >= CHECKPOINT_DRIFT_ESCALATE) {
      action = 'escalate';
    } else if (driftPercent >= CHECKPOINT_DRIFT_WARN) {
      action = 'warn';
    }

    const report = {
      driftDetected: true,
      driftPercent: Math.round(driftPercent * 100) / 100,
      changedKeys: changedKeys.length,
      totalKeys: allKeys.size,
      action,
      ts: Date.now(),
    };

    this._driftHistory.push(report);
    this._checkpoints.push({ ts: Date.now(), hash: currentHash, drift: driftPercent });

    return report;
  }

  /**
   * Get drift history.
   * @returns {Array<Object>}
   */
  getDriftHistory() {
    return [...this._driftHistory];
  }

  /**
   * @private
   * @param {Object} obj
   * @returns {string}
   */
  _hash(obj) {
    const json = JSON.stringify(obj, Object.keys(obj).sort());
    this._lastBaselineJson = this._lastBaselineJson || json;
    return crypto.createHash('sha256').update(json).digest('hex');
  }

  /**
   * @private
   * @param {Object} obj
   * @param {string} prefix
   * @returns {Array<string>}
   */
  _flatKeys(obj, prefix = '') {
    const keys = [];
    for (const [k, v] of Object.entries(obj || {})) {
      const full = prefix ? `${prefix}.${k}` : k;
      if (v && typeof v === 'object' && !Array.isArray(v)) {
        keys.push(...this._flatKeys(v, full));
      } else {
        keys.push(full);
      }
    }
    return keys;
  }
}

// ─── Circuit Breaker Map ───────────────────────────────────────────────────────

/**
 * Task-to-endpoint circuit breaker routing registry.
 *
 * @class CircuitBreakerMap
 */
class CircuitBreakerMap {
  /**
   * @param {Object} defaultOpts - Default circuit breaker options.
   */
  constructor(defaultOpts = {}) {
    this._breakers = new Map();
    this._taskRoutes = new Map();
    this._defaultOpts = defaultOpts;
  }

  /**
   * Register a mapping from task type to a named circuit breaker.
   * @param {string} taskType - Task type identifier.
   * @param {string} endpoint - Endpoint/service name for the breaker.
   */
  registerRoute(taskType, endpoint) {
    this._taskRoutes.set(taskType, endpoint);
    if (!this._breakers.has(endpoint)) {
      this._breakers.set(endpoint, new CircuitBreaker({
        name: endpoint,
        ...this._defaultOpts,
      }));
    }
  }

  /**
   * Get the circuit breaker for a task type.
   * @param {string} taskType
   * @returns {CircuitBreaker|null}
   */
  getBreakerForTask(taskType) {
    const endpoint = this._taskRoutes.get(taskType);
    if (!endpoint) return null;
    return this._breakers.get(endpoint) || null;
  }

  /**
   * Get the circuit breaker for a named endpoint.
   * @param {string} endpoint
   * @returns {CircuitBreaker|null}
   */
  getBreaker(endpoint) {
    return this._breakers.get(endpoint) || null;
  }

  /**
   * Get all circuit breaker snapshots.
   * @returns {Object<string, Object>}
   */
  allSnapshots() {
    const result = {};
    for (const [name, breaker] of this._breakers) {
      result[name] = breaker.snapshot();
    }
    return result;
  }

  /**
   * Destroy all breakers.
   */
  destroyAll() {
    for (const breaker of this._breakers.values()) {
      breaker.destroy();
    }
    this._breakers.clear();
    this._taskRoutes.clear();
  }
}

// ─── Post-Run Feedback Loop ────────────────────────────────────────────────────

/**
 * Post-run feedback loop: feeds timing data to MC scheduler,
 * errors to pattern engine, and performs self-critique.
 *
 * @class FeedbackLoop
 */
class FeedbackLoop {
  constructor() {
    this._timingHistory = [];
    this._errorPatterns = [];
    this._selfCritiques = [];
  }

  /**
   * Record stage timing for the MC scheduler.
   * @param {string} stageName - Stage that completed.
   * @param {number} durationMs - Execution time in ms.
   * @param {boolean} success - Whether the stage succeeded.
   */
  recordTiming(stageName, durationMs, success) {
    this._timingHistory.push({
      stage: stageName,
      duration: durationMs,
      success,
      ts: Date.now(),
    });
    // Keep last 1000 entries
    if (this._timingHistory.length > 1000) {
      this._timingHistory = this._timingHistory.slice(-1000);
    }
  }

  /**
   * Feed error information to the pattern engine.
   * @param {string} taskType - Task that failed.
   * @param {Error|string} error - Error details.
   * @param {Object} context - Execution context.
   */
  recordError(taskType, error, context = {}) {
    this._errorPatterns.push({
      taskType,
      error: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : null,
      context,
      ts: Date.now(),
    });
    if (this._errorPatterns.length > 500) {
      this._errorPatterns = this._errorPatterns.slice(-500);
    }
  }

  /**
   * Perform self-critique after a pipeline run.
   * @param {Object} runResult - The run result summary.
   * @returns {Object} Critique report.
   */
  selfCritique(runResult) {
    const critique = {
      ts: Date.now(),
      runId: runResult.runId,
      observations: [],
      suggestions: [],
    };

    // Analyze timing variance
    if (this._timingHistory.length > 5) {
      const durations = this._timingHistory.slice(-20).map(t => t.duration);
      const avg = durations.reduce((a, b) => a + b, 0) / durations.length;
      const variance = durations.reduce((sum, d) => sum + Math.pow(d - avg, 2), 0) / durations.length;
      const stddev = Math.sqrt(variance);
      const cv = stddev / avg;

      if (cv > 0.5) {
        critique.observations.push(`High timing variance (CV=${cv.toFixed(2)}). Execution is unstable.`);
        critique.suggestions.push('Consider adding resource reservation or increasing worker pool capacity.');
      }
    }

    // Analyze error patterns
    const recentErrors = this._errorPatterns.filter(e => Date.now() - e.ts < 300000);
    if (recentErrors.length > 3) {
      const byType = {};
      for (const err of recentErrors) {
        byType[err.taskType] = (byType[err.taskType] || 0) + 1;
      }
      const hotspot = Object.entries(byType).sort((a, b) => b[1] - a[1])[0];
      if (hotspot) {
        critique.observations.push(`Error hotspot: "${hotspot[0]}" failed ${hotspot[1]} times in last 5min.`);
        critique.suggestions.push(`Investigate "${hotspot[0]}" handler or add circuit breaker routing.`);
      }
    }

    // Check overall success rate
    if (runResult.totalTasks > 0) {
      const successRate = runResult.successTasks / runResult.totalTasks;
      if (successRate < 0.8) {
        critique.observations.push(`Low success rate: ${(successRate * 100).toFixed(1)}%.`);
        critique.suggestions.push('Review task handler implementations and input validation.');
      }
    }

    this._selfCritiques.push(critique);
    return critique;
  }

  /**
   * Get timing data formatted for MC scheduler consumption.
   * @returns {Array<Object>}
   */
  getTimingForScheduler() {
    return this._timingHistory.map(t => ({
      stage: t.stage,
      avgDuration: t.duration,
      success: t.success,
    }));
  }

  /**
   * Get error patterns for the pattern engine.
   * @returns {Array<Object>}
   */
  getErrorPatterns() {
    return [...this._errorPatterns];
  }

  /**
   * Get all self-critiques.
   * @returns {Array<Object>}
   */
  getCritiques() {
    return [...this._selfCritiques];
  }
}

// ─── HCFullPipeline Class ──────────────────────────────────────────────────────

/**
 * HCFullPipeline — The central runtime engine for Heady™ Systems.
 * Orchestrates stages, manages circuit breakers, caches results,
 * and implements the checkpoint/feedback protocol.
 *
 * Extends EventEmitter with events:
 *   - 'status'      (RunStatus)
 *   - 'stage:start' ({ stage, layer })
 *   - 'stage:end'   ({ stage, layer, duration, success })
 *   - 'task:start'  ({ task })
 *   - 'task:end'    ({ task, result, cached })
 *   - 'task:error'  ({ task, error })
 *   - 'stop'        ({ reason, violations })
 *   - 'checkpoint'  ({ drift })
 *   - 'feedback'    ({ critique })
 *   - 'breaker'     ({ name, state, oldState })
 *
 * @class HCFullPipeline
 * @extends EventEmitter
 */
class HCFullPipeline extends EventEmitter {
  constructor() {
    super();
    this.setMaxListeners(50);

    this._config = null;
    this._status = RunStatus.IDLE;
    this._handlers = new Map();
    this._workerPool = null;
    this._cache = null;
    this._checkpoint = new CheckpointProtocol();
    this._cbMap = new CircuitBreakerMap();
    this._nodePool = null;
    this._feedback = new FeedbackLoop();
    this._history = [];
    this._boundSystems = {};
    this._runCounter = 0;
    this._currentRun = null;
    this._dagLayers = null;
    this._metrics = {
      totalTasks: 0,
      successTasks: 0,
      failedTasks: 0,
      errorRate: 0,
      readinessScore: 1.0,
      criticalAlarm: false,
      dataIntegrityFailure: false,
    };
  }

  // ── Config & Setup ──

  /**
   * Load pipeline configuration.
   * @param {Object|string} [configOrPath] - Config object or path to config file.
   * @returns {HCFullPipeline} this (for chaining).
   */
  load(configOrPath) {
    if (typeof configOrPath === 'string') {
      this._config = loadYaml(configOrPath);
    } else if (typeof configOrPath === 'object' && configOrPath !== null) {
      this._config = configOrPath;
    } else {
      this._config = loadYaml();
    }

    const pCfg = this._config.pipeline || this._config;
    const cbCfg = this._config.circuitBreaker || {};

    // Initialize subsystems
    this._workerPool = new WorkerPool(pCfg.maxConcurrency || 8);

    if (pCfg.cacheEnabled !== false) {
      this._cache = new TaskResultCache({
        ttl: pCfg.cacheTtl || DEFAULT_CACHE_TTL,
        codeVersion: pCfg.codeVersion,
        cacheDir: pCfg.cacheDir,
      });
    }

    this._cbMap = new CircuitBreakerMap({
      failureThreshold: cbCfg.failureThreshold || DEFAULT_CIRCUIT_FAILURE_THRESHOLD,
      resetTimeout: cbCfg.resetTimeout || DEFAULT_CIRCUIT_RESET_TIMEOUT,
      halfOpenMax: cbCfg.halfOpenMax || 2,
    });

    this._nodePool = new NodePoolManager(this._config.nodePools || {});

    // Build DAG from stages
    if (this._config.stages && this._config.stages.length > 0) {
      this._dagLayers = topologicalSort(this._config.stages);
    }

    // Set checkpoint baseline
    this._checkpoint.setBaseline(this._config);

    this._setStatus(RunStatus.IDLE);
    this.emit('loaded', { config: this.getConfigSummary() });

    return this;
  }

  /**
   * Register a task handler function.
   * @param {string} taskType - The task type identifier.
   * @param {Function} handler - Async function(task, context) => result.
   * @param {Object} [opts] - Handler options.
   * @param {'hot'|'warm'|'cold'} [opts.pool] - Node pool classification.
   * @param {string} [opts.endpoint] - Circuit breaker endpoint mapping.
   */
  registerTaskHandler(taskType, handler, opts = {}) {
    if (typeof handler !== 'function') {
      throw new TypeError(`Handler for "${taskType}" must be a function`);
    }
    this._handlers.set(taskType, { handler, opts });

    if (opts.pool && this._nodePool) {
      this._nodePool.registerClassification(taskType, opts.pool);
    }
    if (opts.endpoint) {
      this._cbMap.registerRoute(taskType, opts.endpoint);
    }
  }

  /**
   * Bind external systems for pipeline integration.
   * @param {Object} systems - Map of system name to system instance.
   * @returns {HCFullPipeline} this.
   */
  bind(systems) {
    this._boundSystems = { ...this._boundSystems, ...systems };

    // Wire circuit breaker events to process hooks
    if (systems.selfAwareness) {
      for (const [, breaker] of this._cbMap._breakers) {
        breaker.onStateChange((newState, oldState, name) => {
          this.emit('breaker', { name, state: newState, oldState });
          if (systems.selfAwareness.processEvent) {
            systems.selfAwareness.processEvent({
              type: 'circuit_breaker',
              name,
              state: newState,
              oldState,
              ts: Date.now(),
            });
          }
        });
      }
    }

    return this;
  }

  // ── Execution ──

  /**
   * Execute the full pipeline run.
   * @param {Object} [input] - Optional run input/context.
   * @returns {Promise<Object>} Run result.
   */
  async run(input = {}) {
    if (this._status === RunStatus.RUNNING) {
      throw new Error('Pipeline is already running');
    }

    if (!this._config) {
      this.load();
    }

    this._runCounter++;
    const runId = `run-${this._runCounter}-${Date.now()}`;
    const startTime = Date.now();

    this._currentRun = {
      runId,
      startTime,
      input,
      stageResults: [],
      taskResults: [],
      errors: [],
    };

    this._setStatus(RunStatus.RUNNING);

    try {
      // Checkpoint: check for config drift
      const drift = this._checkpoint.checkDrift(this._config);
      if (drift.driftDetected) {
        this.emit('checkpoint', { drift });
        if (drift.action === 'escalate') {
          this._setStatus(RunStatus.HALTED);
          const result = this._buildRunResult(runId, startTime, 'Config drift escalation');
          this._history.push(result);
          return result;
        }
      }

      // Execute stage DAG or flat task list
      if (this._dagLayers && this._dagLayers.length > 0) {
        await this._executeDAG(runId);
      } else if (input.tasks && input.tasks.length > 0) {
        await this._executeTasks(input.tasks, runId);
      }

      // Evaluate stop rules
      this._updateMetrics();
      const stopEval = evaluateStopRules(this._metrics, this._config.stopRules || {});
      if (stopEval.shouldStop) {
        this.emit('stop', { reason: stopEval.reason, violations: stopEval.violations });
        this._setStatus(stopEval.severity === 'critical' ? RunStatus.HALTED : RunStatus.FAILED);
      } else {
        this._setStatus(RunStatus.COMPLETED);
      }
    } catch (err) {
      this._currentRun.errors.push({ error: err.message, stack: err.stack, ts: Date.now() });
      this._setStatus(RunStatus.FAILED);
    }

    const result = this._buildRunResult(runId, startTime);
    this._history.push(result);

    // Post-run feedback
    const critique = this._feedback.selfCritique(result);
    this.emit('feedback', { critique });

    // Feed timing to MC scheduler (non-fatal)
    try {
      if (this._boundSystems.mcScheduler) {
        const timingData = this._feedback.getTimingForScheduler();
        this._boundSystems.mcScheduler.recordTimings(timingData);
      }
    } catch (_) { /* non-fatal MC scheduler feed */ }

    // Feed errors to pattern engine (non-fatal)
    try {
      if (this._boundSystems.patternEngine) {
        const errors = this._feedback.getErrorPatterns();
        this._boundSystems.patternEngine.ingestErrors(errors);
      }
    } catch (_) { /* non-fatal pattern engine feed */ }

    // Auto-commit engine integration (non-fatal)
    try {
      if (this._boundSystems.autoCommit) {
        await this._boundSystems.autoCommit.commit({
          runId,
          status: this._status,
          summary: result,
        });
      }
    } catch (_) { /* non-fatal auto-commit */ }

    this._currentRun = null;
    return result;
  }

  /**
   * Execute the stage DAG layer by layer.
   * @private
   * @param {string} runId
   */
  async _executeDAG(runId) {
    for (let layerIdx = 0; layerIdx < this._dagLayers.length; layerIdx++) {
      if (this._status === RunStatus.HALTED || this._status === RunStatus.PAUSED) break;

      const layer = this._dagLayers[layerIdx];

      // Execute all stages in this layer in parallel
      const stagePromises = layer.map(stage => this._executeStage(stage, layerIdx, runId));
      const stageResults = await Promise.allSettled(stagePromises);

      for (let i = 0; i < stageResults.length; i++) {
        const sr = stageResults[i];
        this._currentRun.stageResults.push({
          stage: layer[i].name,
          layer: layerIdx,
          status: sr.status,
          value: sr.status === 'fulfilled' ? sr.value : null,
          error: sr.status === 'rejected' ? sr.reason?.message : null,
        });
      }

      // Check stop rules after each layer
      this._updateMetrics();
      const stopEval = evaluateStopRules(this._metrics, this._config.stopRules || {});
      if (stopEval.shouldStop) {
        this.emit('stop', { reason: stopEval.reason, violations: stopEval.violations });
        break;
      }
    }
  }

  /**
   * Execute a single stage (which may contain parallel or sequential tasks).
   * @private
   * @param {Object} stage
   * @param {number} layerIdx
   * @param {string} runId
   */
  async _executeStage(stage, layerIdx, runId) {
    const stageStart = Date.now();
    this.emit('stage:start', { stage: stage.name, layer: layerIdx });

    let success = true;
    try {
      const tasks = stage.tasks || [];
      if (stage.parallel !== false && tasks.length > 1) {
        await this._executeTasks(tasks, runId);
      } else {
        for (const task of tasks) {
          if (this._status === RunStatus.HALTED) break;
          await this._executeTask(task, runId);
        }
      }
    } catch (err) {
      success = false;
      throw err;
    } finally {
      const duration = Date.now() - stageStart;
      this._feedback.recordTiming(stage.name, duration, success);
      this.emit('stage:end', { stage: stage.name, layer: layerIdx, duration, success });
    }
  }

  /**
   * Execute multiple tasks in parallel using the worker pool.
   * @private
   * @param {Array<Object>} tasks
   * @param {string} runId
   */
  async _executeTasks(tasks, runId) {
    // Priority sort via node pool
    const sorted = this._nodePool ? this._nodePool.prioritySort(tasks) : tasks;

    const promises = sorted.map(task => this._executeTask(task, runId));
    await Promise.allSettled(promises);
  }

  /**
   * Execute a single task with circuit breaker, caching, and worker pool.
   * @private
   * @param {Object} task
   * @param {string} runId
   */
  async _executeTask(task, runId) {
    const taskType = task.type || task.handler || 'unknown';
    const taskId = task.id || `${taskType}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

    this.emit('task:start', { task: { ...task, id: taskId } });

    // FAIL-CLOSED: reject unregistered tasks unless in simulation mode
    const registered = this._handlers.get(taskType);
    const isSimulation = (this._config.pipeline || this._config).simulationMode === true;

    if (!registered && !isSimulation) {
      const err = new Error(`FAIL-CLOSED: No handler registered for task type "${taskType}"`);
      this._metrics.failedTasks++;
      this._metrics.totalTasks++;
      this._feedback.recordError(taskType, err, { taskId, runId });
      this.emit('task:error', { task: { ...task, id: taskId }, error: err.message });
      this._currentRun.errors.push({ taskId, error: err.message, ts: Date.now() });
      throw err;
    }

    // Circuit breaker check
    const breaker = this._cbMap.getBreakerForTask(taskType);
    if (breaker && !breaker.canPass()) {
      const err = new Error(`Circuit breaker OPEN for "${taskType}" (endpoint: ${breaker.name})`);
      this._metrics.failedTasks++;
      this._metrics.totalTasks++;
      this.emit('task:error', { task: { ...task, id: taskId }, error: err.message });
      throw err;
    }

    // Cache check
    let cacheKey = null;
    if (this._cache) {
      cacheKey = this._cache.key(taskType, task.input || task);
      const cached = this._cache.get(cacheKey);
      if (cached !== null) {
        this._metrics.totalTasks++;
        this._metrics.successTasks++;
        this._currentRun.taskResults.push({ taskId, taskType, result: cached, cached: true });
        this.emit('task:end', { task: { ...task, id: taskId }, result: cached, cached: true });
        return cached;
      }
    }

    // Acquire worker slot
    const release = await this._workerPool.acquire(taskId);

    try {
      let result;
      if (registered) {
        const context = {
          runId,
          taskId,
          config: this._config,
          systems: this._boundSystems,
          metrics: { ...this._metrics },
        };
        result = await registered.handler(task, context);
      } else {
        // Simulation mode: return a mock result
        result = {
          simulated: true,
          taskType,
          taskId,
          ts: Date.now(),
          message: `[SIMULATION] Task "${taskType}" would execute here`,
        };
      }

      // Record success
      this._metrics.totalTasks++;
      this._metrics.successTasks++;
      if (breaker) breaker.recordSuccess();
      if (this._cache && cacheKey) this._cache.set(cacheKey, result);
      this._currentRun.taskResults.push({ taskId, taskType, result, cached: false });
      this.emit('task:end', { task: { ...task, id: taskId }, result, cached: false });
      return result;

    } catch (err) {
      this._metrics.totalTasks++;
      this._metrics.failedTasks++;
      if (breaker) breaker.recordFailure();
      this._feedback.recordError(taskType, err, { taskId, runId });
      this._currentRun.errors.push({ taskId, taskType, error: err.message, ts: Date.now() });
      this.emit('task:error', { task: { ...task, id: taskId }, error: err.message });
      throw err;

    } finally {
      release();
    }
  }

  // ── Metrics & State ──

  /**
   * Update internal metrics from current run data.
   * @private
   */
  _updateMetrics() {
    if (this._metrics.totalTasks > 0) {
      this._metrics.errorRate = this._metrics.failedTasks / this._metrics.totalTasks;
    }
    // Compute readiness from bound systems if available
    if (this._boundSystems.monteCarlo) {
      try {
        const mc = this._boundSystems.monteCarlo;
        if (typeof mc.quickReadiness === 'function') {
          const readiness = mc.quickReadiness();
          this._metrics.readinessScore = readiness.score || this._metrics.readinessScore;
        }
      } catch (_) { /* non-fatal */ }
    }
  }

  /**
   * @private
   * @param {RunStatus} newStatus
   */
  _setStatus(newStatus) {
    const old = this._status;
    this._status = newStatus;
    if (old !== newStatus) {
      this.emit('status', { status: newStatus, previous: old, ts: Date.now() });
    }
  }

  /**
   * Build a run result summary object.
   * @private
   * @param {string} runId
   * @param {number} startTime
   * @param {string} [haltReason]
   * @returns {Object}
   */
  _buildRunResult(runId, startTime, haltReason = null) {
    return {
      runId,
      status: this._status,
      startTime,
      endTime: Date.now(),
      duration: Date.now() - startTime,
      totalTasks: this._metrics.totalTasks,
      successTasks: this._metrics.successTasks,
      failedTasks: this._metrics.failedTasks,
      errorRate: this._metrics.errorRate,
      stageResults: this._currentRun ? this._currentRun.stageResults : [],
      errors: this._currentRun ? this._currentRun.errors : [],
      haltReason,
      cacheStats: this._cache ? this._cache.stats() : null,
      workerPoolStats: this._workerPool ? this._workerPool.stats() : null,
    };
  }

  // ── Public Accessors ──

  /**
   * Get current pipeline state.
   * @returns {Object} State snapshot.
   */
  getState() {
    return {
      status: this._status,
      metrics: { ...this._metrics },
      runCounter: this._runCounter,
      workerPool: this._workerPool ? this._workerPool.stats() : null,
      cache: this._cache ? this._cache.stats() : null,
      nodePool: this._nodePool ? this._nodePool.stats() : null,
      registeredHandlers: [...this._handlers.keys()],
      boundSystems: Object.keys(this._boundSystems),
    };
  }

  /**
   * Get run history.
   * @param {number} [limit=10] - Max number of history entries to return.
   * @returns {Array<Object>}
   */
  getHistory(limit = 10) {
    return this._history.slice(-limit);
  }

  /**
   * Get all circuit breaker snapshots.
   * @returns {Object}
   */
  getCircuitBreakers() {
    return this._cbMap.allSnapshots();
  }

  /**
   * Get the stage DAG as computed layers.
   * @returns {Array<Array<Object>>|null}
   */
  getStageDag() {
    if (!this._dagLayers) return null;
    return this._dagLayers.map((layer, idx) => ({
      layer: idx,
      stages: layer.map(s => ({
        name: s.name,
        dependsOn: s.dependsOn || [],
        tasks: (s.tasks || []).length,
        parallel: s.parallel !== false,
      })),
    }));
  }

  /**
   * Get a summary of the current configuration.
   * @returns {Object}
   */
  getConfigSummary() {
    if (!this._config) return { loaded: false };
    const p = this._config.pipeline || this._config;
    return {
      loaded: true,
      name: p.name || 'unnamed',
      version: p.version || '0.0.0',
      simulationMode: !!p.simulationMode,
      maxConcurrency: p.maxConcurrency || 8,
      cacheEnabled: p.cacheEnabled !== false,
      cacheTtl: p.cacheTtl || DEFAULT_CACHE_TTL,
      checkpointEnabled: p.checkpointEnabled !== false,
      stages: (this._config.stages || []).length,
      stopRules: this._config.stopRules || {},
      circuitBreaker: this._config.circuitBreaker || {},
    };
  }

  /**
   * Pause the pipeline (will stop after current stage layer completes).
   */
  pause() {
    if (this._status === RunStatus.RUNNING) {
      this._setStatus(RunStatus.PAUSED);
    }
  }

  /**
   * Resume a paused pipeline.
   */
  resume() {
    if (this._status === RunStatus.PAUSED) {
      this._setStatus(RunStatus.RUNNING);
    }
  }

  /**
   * Halt the pipeline immediately.
   * @param {string} [reason='Manual halt']
   */
  halt(reason = 'Manual halt') {
    this._setStatus(RunStatus.HALTED);
    this.emit('stop', { reason, violations: [{ rule: 'manual', message: reason, severity: 'critical' }] });
  }

  /**
   * Reset the pipeline to IDLE state with fresh metrics.
   */
  reset() {
    this._setStatus(RunStatus.IDLE);
    this._metrics = {
      totalTasks: 0,
      successTasks: 0,
      failedTasks: 0,
      errorRate: 0,
      readinessScore: 1.0,
      criticalAlarm: false,
      dataIntegrityFailure: false,
    };
    this._currentRun = null;
  }

  /**
   * Destroy the pipeline and release all resources.
   */
  destroy() {
    this._cbMap.destroyAll();
    if (this._workerPool) this._workerPool.drain().catch(() => {});
    this.removeAllListeners();
  }
}

// ─── Singleton Instance ────────────────────────────────────────────────────────

/** @type {HCFullPipeline} Singleton pipeline instance */
const pipeline = new HCFullPipeline();

// ─── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  // Primary export
  pipeline,

  // Classes
  HCFullPipeline,
  CircuitBreaker,
  WorkerPool,
  TaskResultCache,
  CheckpointProtocol,
  CircuitBreakerMap,
  NodePoolManager,
  FeedbackLoop,

  // Functions
  loadYaml,
  topologicalSort,
  evaluateStopRules,

  // Enums & Constants
  RunStatus,
  CBState,
  PHI,
  DEFAULT_CACHE_TTL,
  DEFAULT_CIRCUIT_FAILURE_THRESHOLD,
  DEFAULT_CIRCUIT_RESET_TIMEOUT,
};
