/**
 * @file buddy-core.js
 * @description HeadyBuddy companion core — manages conversations, assembles
 *              context from vector memory, routes responses through a conductor,
 *              and provides stats/recovery operations.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const { EventEmitter } = require('events');
const crypto = require('crypto');

const PHI = 1.6180339887;

/** PHI^5 * 1000 ms — default conversation idle timeout (~11 090 ms) */
const CONVERSATION_TIMEOUT_MS = Math.round(Math.pow(PHI, 5) * 1000);

/** PHI^12 * 1000 ms — max conversation history age before pruning (~322 s) */
const HISTORY_MAX_AGE_MS = Math.round(Math.pow(PHI, 12) * 1000);

/**
 * @typedef {object} Message
 * @property {string} id      - Unique message ID
 * @property {string} role    - 'user' | 'assistant' | 'system'
 * @property {string} content - Message text
 * @property {number} ts      - Unix timestamp ms
 */

/**
 * @typedef {object} ConversationSession
 * @property {string}    id        - Session ID
 * @property {Message[]} history   - Message history
 * @property {number}    createdAt
 * @property {number}    updatedAt
 * @property {object}    meta      - Arbitrary session metadata
 */

/**
 * @class BuddyCore
 * @extends EventEmitter
 *
 * @example
 * const buddy = new BuddyCore({
 *   conductorFn:   (messages, context) => llm.chat(messages, context),
 *   vectorMemory:  { search: (query, k) => vectorStore.search(query, k) },
 * });
 *
 * const reply = await buddy.chat('session-1', 'How do I configure the rate limiter?');
 */
class BuddyCore extends EventEmitter {
  /**
   * @param {object}    opts
   * @param {Function}  opts.conductorFn               - Async (messages, context) => string — LLM router
   * @param {object}    [opts.vectorMemory]             - { search: async (query, k) => ContextEntry[] }
   * @param {number}    [opts.vectorTopK=5]             - Top-K memory results to inject into context
   * @param {number}    [opts.maxHistoryMessages=20]    - Max messages kept per conversation
   * @param {number}    [opts.conversationTimeoutMs]    - Idle timeout before session expires
   * @param {string}    [opts.systemPrompt]             - Default system prompt prepended to every conversation
   */
  constructor(opts) {
    super();

    if (typeof opts.conductorFn !== 'function') {
      throw new TypeError('BuddyCore: opts.conductorFn is required');
    }

    this.conductorFn           = opts.conductorFn;
    this.vectorMemory          = opts.vectorMemory          ?? null;
    this.vectorTopK            = opts.vectorTopK            ?? 5;
    this.maxHistoryMessages    = opts.maxHistoryMessages    ?? 20;
    this.conversationTimeout   = opts.conversationTimeoutMs ?? CONVERSATION_TIMEOUT_MS;
    this.systemPrompt          = opts.systemPrompt          ?? null;

    /** @type {Map<string, ConversationSession>} */
    this._sessions = new Map();

    /** @type {{ totalMessages: number, totalSessions: number, errors: number }} */
    this._stats = { totalMessages: 0, totalSessions: 0, errors: 0 };

    // Periodic prune
    this._pruneTimer = setInterval(() => this._pruneExpired(), this.conversationTimeout);
    if (this._pruneTimer.unref) this._pruneTimer.unref();
  }

  // ─── Conversation API ────────────────────────────────────────────────────────

  /**
   * Send a message and get a response. Creates the session if it doesn't exist.
   *
   * @param {string}  sessionId
   * @param {string}  userMessage
   * @param {object}  [opts]
   * @param {object}  [opts.meta]          - Extra metadata stored on the session
   * @param {object}  [opts.contextHints]  - Additional context to pass to conductor
   * @returns {Promise<{ reply: string, sessionId: string, messageId: string }>}
   */
  async chat(sessionId, userMessage, opts = {}) {
    const session = this._getOrCreateSession(sessionId, opts.meta);

    const userMsg = this._makeMessage('user', userMessage);
    session.history.push(userMsg);
    session.updatedAt = Date.now();
    this._stats.totalMessages++;

    this.emit('message', { sessionId, message: userMsg });

    // Assemble context from vector memory
    let retrievedContext = [];
    if (this.vectorMemory) {
      try {
        retrievedContext = await this.vectorMemory.search(userMessage, this.vectorTopK);
      } catch (_) {
        // Non-fatal: proceed without memory context
      }
    }

    // Build messages array for conductor
    const messages = this._buildMessages(session, opts.contextHints, retrievedContext);

    let reply;
    try {
      reply = await this.conductorFn(messages, {
        sessionId,
        retrieved:    retrievedContext,
        contextHints: opts.contextHints ?? {},
      });
    } catch (err) {
      this._stats.errors++;
      this.emit('error', { sessionId, error: err.message });
      throw err;
    }

    const assistantMsg = this._makeMessage('assistant', reply);
    session.history.push(assistantMsg);
    session.updatedAt = Date.now();
    this._stats.totalMessages++;

    this.emit('reply', { sessionId, message: assistantMsg });

    // Trim history if over limit
    this._trimHistory(session);

    return { reply, sessionId, messageId: assistantMsg.id };
  }

  // ─── Session Management ──────────────────────────────────────────────────────

  /**
   * Get conversation history for a session.
   *
   * @param {string} sessionId
   * @returns {Message[]}
   */
  getHistory(sessionId) {
    return [...(this._sessions.get(sessionId)?.history ?? [])];
  }

  /**
   * Clear conversation history for a session without destroying the session.
   *
   * @param {string} sessionId
   */
  clearHistory(sessionId) {
    const s = this._sessions.get(sessionId);
    if (s) s.history = [];
  }

  /**
   * Destroy a session entirely.
   *
   * @param {string} sessionId
   */
  destroySession(sessionId) {
    this._sessions.delete(sessionId);
    this.emit('sessionDestroyed', { sessionId });
  }

  // ─── Stats & Recovery ────────────────────────────────────────────────────────

  /**
   * Return runtime statistics.
   *
   * @returns {{ sessions: number, totalMessages: number, totalSessions: number, errors: number }}
   */
  getStats() {
    return {
      sessions:       this._sessions.size,
      ...this._stats,
    };
  }

  /**
   * Attempt recovery from an error state.
   * Currently: prunes expired sessions and resets error counter.
   *
   * @returns {{ pruned: number, errorsReset: number }}
   */
  recover() {
    const pruned = this._pruneExpired();
    const errorsReset = this._stats.errors;
    this._stats.errors = 0;
    this.emit('recovered', { pruned, errorsReset });
    return { pruned, errorsReset };
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Get or create a session.
   * @param {string}  id
   * @param {object}  [meta]
   * @returns {ConversationSession}
   */
  _getOrCreateSession(id, meta) {
    if (!this._sessions.has(id)) {
      this._sessions.set(id, {
        id,
        history:   [],
        createdAt: Date.now(),
        updatedAt: Date.now(),
        meta:      meta ?? {},
      });
      this._stats.totalSessions++;
      this.emit('sessionCreated', { sessionId: id });
    }
    return this._sessions.get(id);
  }

  /**
   * @private Create a message object.
   * @param {'user'|'assistant'|'system'} role
   * @param {string} content
   * @returns {Message}
   */
  _makeMessage(role, content) {
    return {
      id:      crypto.randomBytes(6).toString('hex'),
      role,
      content,
      ts:      Date.now(),
    };
  }

  /**
   * @private Build the messages array for the conductor.
   * @param {ConversationSession} session
   * @param {object}              [contextHints]
   * @param {object[]}            [retrieved]
   * @returns {Message[]}
   */
  _buildMessages(session, contextHints, retrieved) {
    const messages = [];

    // System prompt
    if (this.systemPrompt) {
      messages.push({ role: 'system', content: this.systemPrompt });
    }

    // Inject retrieved memory as a system context block
    if (retrieved && retrieved.length > 0) {
      const memoryText = retrieved
        .map((item, i) => `[Memory ${i + 1}]: ${typeof item === 'string' ? item : JSON.stringify(item)}`)
        .join('\n');
      messages.push({ role: 'system', content: `Relevant context from memory:\n${memoryText}` });
    }

    // Context hints
    if (contextHints && Object.keys(contextHints).length > 0) {
      messages.push({ role: 'system', content: `Additional context: ${JSON.stringify(contextHints)}` });
    }

    // Conversation history
    for (const msg of session.history) {
      messages.push({ role: msg.role, content: msg.content });
    }

    return messages;
  }

  /**
   * @private Trim session history to maxHistoryMessages.
   * @param {ConversationSession} session
   */
  _trimHistory(session) {
    if (session.history.length > this.maxHistoryMessages) {
      session.history = session.history.slice(-this.maxHistoryMessages);
    }
  }

  /**
   * @private Remove sessions idle for longer than conversationTimeout.
   * @returns {number} Number of sessions pruned
   */
  _pruneExpired() {
    const cutoff = Date.now() - this.conversationTimeout;
    let pruned   = 0;
    for (const [id, session] of this._sessions) {
      if (session.updatedAt < cutoff) {
        this._sessions.delete(id);
        pruned++;
      }
    }
    return pruned;
  }
}

module.exports = {
  BuddyCore,
  CONVERSATION_TIMEOUT_MS,
  HISTORY_MAX_AGE_MS,
  PHI,
};
