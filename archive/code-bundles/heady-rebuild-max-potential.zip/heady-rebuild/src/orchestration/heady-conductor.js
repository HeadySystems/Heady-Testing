/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║  HeadyConductor — Central Dispatch & Routing Engine                        ║
 * ║  Heady™ Systems · Sacred Geometry Architecture                             ║
 * ║  © 2026 HeadySystems Inc. All rights reserved.                             ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  The Conductor is the nerve center. It classifies, routes, and assigns.    ║
 * ║  Domain classification → skill-based routing → pool assignment.            ║
 * ║  Hot/Warm/Cold pools. Optimal node selection. PHI-balanced.                ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * @module orchestration/heady-conductor
 * @version 4.0.0
 * @author HeadySystems Engineering
 */

'use strict';

// ─── Sacred Constants ──────────────────────────────────────────────────────────

/** @constant {number} PHI - The golden ratio */
const PHI = 1.6180339887;

// ─── Task Domains ──────────────────────────────────────────────────────────────

/**
 * Task domain classification definitions.
 * Each domain maps to keywords, default pool, and preferred service groups.
 *
 * @constant {Object<string, Object>}
 */
const TASK_DOMAINS = Object.freeze({
  code: {
    keywords: ['code', 'implement', 'refactor', 'debug', 'compile', 'lint', 'test', 'unit-test', 'integration', 'build', 'deploy-code', 'PR', 'pull-request', 'commit', 'branch', 'merge'],
    defaultPool: 'hot',
    preferredGroups: ['coding', 'heady-core'],
    priority: 1,
  },
  review: {
    keywords: ['review', 'code-review', 'pr-review', 'audit-code', 'quality', 'feedback', 'approve', 'reject', 'comment'],
    defaultPool: 'warm',
    preferredGroups: ['coding', 'governance'],
    priority: 2,
  },
  security: {
    keywords: ['security', 'vulnerability', 'CVE', 'scan', 'penetration', 'pentest', 'threat', 'exploit', 'patch', 'firewall', 'auth', 'encryption', 'certificate'],
    defaultPool: 'hot',
    preferredGroups: ['battle', 'governance', 'ops'],
    priority: 1,
  },
  architecture: {
    keywords: ['architecture', 'design', 'schema', 'database', 'migration', 'infrastructure', 'topology', 'microservice', 'API-design', 'system-design', 'scale'],
    defaultPool: 'warm',
    preferredGroups: ['reasoning', 'heady-core'],
    priority: 2,
  },
  research: {
    keywords: ['research', 'investigate', 'explore', 'analyze', 'study', 'benchmark', 'compare', 'evaluate', 'survey', 'discovery'],
    defaultPool: 'warm',
    preferredGroups: ['intelligence', 'search', 'reasoning'],
    priority: 3,
  },
  docs: {
    keywords: ['document', 'documentation', 'readme', 'wiki', 'guide', 'tutorial', 'specification', 'spec', 'API-docs', 'changelog', 'release-notes'],
    defaultPool: 'cold',
    preferredGroups: ['creative', 'coding'],
    priority: 3,
  },
  creative: {
    keywords: ['creative', 'design', 'image', 'video', 'audio', 'generate', 'illustration', 'brand', 'logo', 'UI', 'UX', 'mockup', 'prototype'],
    defaultPool: 'warm',
    preferredGroups: ['creative', 'vision'],
    priority: 2,
  },
  monitoring: {
    keywords: ['monitor', 'alert', 'health', 'status', 'uptime', 'metrics', 'dashboard', 'observability', 'trace', 'log', 'telemetry'],
    defaultPool: 'hot',
    preferredGroups: ['ops', 'heady-telemetry'],
    priority: 1,
  },
  cleanup: {
    keywords: ['cleanup', 'clean', 'garbage', 'prune', 'archive', 'delete', 'remove', 'expire', 'purge', 'vacuum', 'compact'],
    defaultPool: 'cold',
    preferredGroups: ['ops', 'heady-memory'],
    priority: 4,
  },
  analytics: {
    keywords: ['analytics', 'report', 'statistics', 'insight', 'trend', 'forecast', 'predict', 'ML', 'model', 'training', 'inference', 'data'],
    defaultPool: 'warm',
    preferredGroups: ['reasoning', 'intelligence', 'sims'],
    priority: 2,
  },
  maintenance: {
    keywords: ['maintenance', 'upgrade', 'update', 'patch', 'version', 'dependency', 'migrate', 'backup', 'restore', 'recovery'],
    defaultPool: 'cold',
    preferredGroups: ['ops', 'heady-pipeline'],
    priority: 3,
  },
});

// ─── Skill Registry ────────────────────────────────────────────────────────────

/**
 * Node skill profiles for routing. Maps service group to capabilities.
 *
 * @constant {Object<string, Object>}
 */
const SKILL_REGISTRY = Object.freeze({
  reasoning: {
    capabilities: ['analysis', 'logic', 'planning', 'decision-making', 'architecture'],
    throughput: 'medium',
    latency: 'medium',
  },
  embedding: {
    capabilities: ['embedding', 'vectorization', 'similarity', 'encoding'],
    throughput: 'high',
    latency: 'low',
  },
  search: {
    capabilities: ['search', 'retrieval', 'indexing', 'ranking', 'filtering'],
    throughput: 'high',
    latency: 'low',
  },
  creative: {
    capabilities: ['generation', 'design', 'writing', 'image', 'audio', 'video'],
    throughput: 'low',
    latency: 'high',
  },
  battle: {
    capabilities: ['testing', 'adversarial', 'fuzzing', 'security', 'penetration'],
    throughput: 'medium',
    latency: 'medium',
  },
  ops: {
    capabilities: ['deployment', 'monitoring', 'scaling', 'maintenance', 'cleanup'],
    throughput: 'high',
    latency: 'low',
  },
  coding: {
    capabilities: ['code-generation', 'review', 'debugging', 'testing', 'refactoring'],
    throughput: 'medium',
    latency: 'medium',
  },
  governance: {
    capabilities: ['compliance', 'approval', 'audit', 'policy', 'review'],
    throughput: 'low',
    latency: 'high',
  },
  vision: {
    capabilities: ['image-analysis', 'OCR', 'object-detection', 'classification'],
    throughput: 'medium',
    latency: 'medium',
  },
  sims: {
    capabilities: ['simulation', 'monte-carlo', 'modeling', 'forecasting'],
    throughput: 'low',
    latency: 'high',
  },
  swarm: {
    capabilities: ['coordination', 'distribution', 'consensus', 'aggregation'],
    throughput: 'high',
    latency: 'medium',
  },
  intelligence: {
    capabilities: ['research', 'discovery', 'trend-analysis', 'knowledge-graph'],
    throughput: 'medium',
    latency: 'medium',
  },
  'heady-core': {
    capabilities: ['orchestration', 'routing', 'pipeline', 'system'],
    throughput: 'high',
    latency: 'low',
  },
  'heady-memory': {
    capabilities: ['memory', 'storage', 'retrieval', 'consolidation', 'vector'],
    throughput: 'high',
    latency: 'low',
  },
  'heady-pipeline': {
    capabilities: ['pipeline', 'workflow', 'stage', 'task-execution'],
    throughput: 'medium',
    latency: 'medium',
  },
  'heady-telemetry': {
    capabilities: ['telemetry', 'monitoring', 'alerting', 'metrics'],
    throughput: 'high',
    latency: 'low',
  },
  'heady-conductor': {
    capabilities: ['routing', 'dispatch', 'classification', 'federation'],
    throughput: 'high',
    latency: 'low',
  },
});

// ─── Pool Configuration ────────────────────────────────────────────────────────

/**
 * Pool definitions for Hot/Warm/Cold task assignment.
 * @constant {Object}
 */
const POOL_CONFIG = Object.freeze({
  hot: {
    name: 'hot',
    description: 'Latency-sensitive, mission-critical tasks',
    maxLatencyMs: 1000,
    priority: 1,
    scaleUpThreshold: 0.6,
  },
  warm: {
    name: 'warm',
    description: 'Standard throughput tasks',
    maxLatencyMs: 5000,
    priority: 2,
    scaleUpThreshold: 0.7,
  },
  cold: {
    name: 'cold',
    description: 'Background, batch, non-urgent tasks',
    maxLatencyMs: 30000,
    priority: 3,
    scaleUpThreshold: 0.85,
  },
});

// ─── HeadyConductor Class ──────────────────────────────────────────────────────

/**
 * HeadyConductor — Central dispatch/routing engine.
 * Classifies tasks into domains, routes to optimal service groups,
 * and assigns Hot/Warm/Cold pools.
 *
 * @class HeadyConductor
 */
class HeadyConductor {
  constructor() {
    this._routingHistory = [];
    this._domainStats = {};
    this._customRules = [];

    // Initialize domain stats
    for (const domain of Object.keys(TASK_DOMAINS)) {
      this._domainStats[domain] = { routed: 0, avgLatency: 0, totalLatency: 0 };
    }
    this._domainStats['unknown'] = { routed: 0, avgLatency: 0, totalLatency: 0 };
  }

  /**
   * Classify a task into a domain based on its type, description, and metadata.
   *
   * @param {Object} task
   * @param {string} [task.type] - Task type identifier.
   * @param {string} [task.description] - Task description.
   * @param {string} [task.group] - Explicit service group.
   * @param {Object} [task.metadata] - Additional metadata.
   * @returns {Object} Classification result { domain, confidence, matchedKeywords }
   */
  classify(task) {
    const text = [
      task.type || '',
      task.description || '',
      task.group || '',
      JSON.stringify(task.metadata || {}),
    ].join(' ').toLowerCase();

    let bestDomain = 'unknown';
    let bestScore = 0;
    let matchedKeywords = [];

    for (const [domain, config] of Object.entries(TASK_DOMAINS)) {
      let score = 0;
      const matches = [];

      for (const keyword of config.keywords) {
        if (text.includes(keyword.toLowerCase())) {
          score++;
          matches.push(keyword);
        }
      }

      // Bonus for explicit group match
      if (task.group && config.preferredGroups.includes(task.group)) {
        score += 2;
      }

      if (score > bestScore) {
        bestScore = score;
        bestDomain = domain;
        matchedKeywords = matches;
      }
    }

    const maxPossible = bestDomain !== 'unknown'
      ? TASK_DOMAINS[bestDomain].keywords.length + 2
      : 1;

    return {
      domain: bestDomain,
      confidence: Math.min(bestScore / maxPossible, 1),
      matchedKeywords,
      score: bestScore,
    };
  }

  /**
   * Route a task to the optimal service group based on classification and skills.
   *
   * @param {Object} task - Task to route.
   * @returns {Object} Routing decision:
   *   { domain, pool, serviceGroup, backupGroups, confidence, reasoning }
   */
  routeSync(task) {
    const classification = this.classify(task);
    const domain = classification.domain;

    let pool, preferredGroups, priority;

    if (domain !== 'unknown' && TASK_DOMAINS[domain]) {
      const domainConfig = TASK_DOMAINS[domain];
      pool = domainConfig.defaultPool;
      preferredGroups = domainConfig.preferredGroups;
      priority = domainConfig.priority;
    } else {
      pool = 'warm'; // Default pool
      preferredGroups = ['reasoning', 'heady-core'];
      priority = 3;
    }

    // Override pool based on explicit task properties
    if (task.priority === 'critical' || task.deadline) {
      pool = 'hot';
      priority = 1;
    } else if (task.batch === true || task.priority === 'low') {
      pool = 'cold';
      priority = 4;
    }

    // Check custom routing rules
    for (const rule of this._customRules) {
      if (rule.match(task)) {
        if (rule.pool) pool = rule.pool;
        if (rule.group) preferredGroups = [rule.group, ...preferredGroups];
        break;
      }
    }

    // Select best service group from preferred list based on skill match
    const serviceGroup = this._selectBestGroup(task, preferredGroups);
    const backupGroups = preferredGroups.filter(g => g !== serviceGroup);

    const routing = {
      domain,
      pool,
      poolConfig: POOL_CONFIG[pool],
      serviceGroup,
      backupGroups,
      priority,
      confidence: classification.confidence,
      classification,
      reasoning: `Classified as "${domain}" (confidence: ${(classification.confidence * 100).toFixed(0)}%). ` +
                 `Routed to ${serviceGroup} in ${pool} pool.`,
      ts: Date.now(),
    };

    // Track stats
    this._domainStats[domain].routed++;
    this._routingHistory.push({
      taskType: task.type,
      domain,
      serviceGroup,
      pool,
      ts: Date.now(),
    });
    if (this._routingHistory.length > 1000) {
      this._routingHistory = this._routingHistory.slice(-1000);
    }

    return routing;
  }

  /**
   * Select the best service group from a list based on task skill requirements.
   * @private
   * @param {Object} task
   * @param {Array<string>} groups
   * @returns {string} Best service group.
   */
  _selectBestGroup(task, groups) {
    if (groups.length === 0) return 'heady-core';
    if (groups.length === 1) return groups[0];

    const taskText = [task.type || '', task.description || ''].join(' ').toLowerCase();
    let bestGroup = groups[0];
    let bestScore = 0;

    for (const group of groups) {
      const skills = SKILL_REGISTRY[group];
      if (!skills) continue;

      let score = 0;
      for (const cap of skills.capabilities) {
        if (taskText.includes(cap.toLowerCase())) {
          score += 2;
        }
      }

      // Latency bonus for hot pool tasks
      if (skills.latency === 'low') score += 1;
      if (skills.throughput === 'high') score += 0.5;

      if (score > bestScore) {
        bestScore = score;
        bestGroup = group;
      }
    }

    return bestGroup;
  }

  /**
   * Add a custom routing rule.
   * @param {Object} rule
   * @param {Function} rule.match - Function(task) => boolean.
   * @param {string} [rule.pool] - Pool override.
   * @param {string} [rule.group] - Service group override.
   * @param {string} [rule.name] - Rule name.
   */
  addRule(rule) {
    this._customRules.push(rule);
  }

  /**
   * Record latency feedback for a domain.
   * @param {string} domain
   * @param {number} latencyMs
   */
  recordLatency(domain, latencyMs) {
    const stats = this._domainStats[domain] || this._domainStats['unknown'];
    stats.totalLatency += latencyMs;
    stats.avgLatency = stats.routed > 0 ? stats.totalLatency / stats.routed : 0;
  }

  /**
   * Get routing statistics.
   * @returns {Object}
   */
  getStats() {
    return {
      domains: { ...this._domainStats },
      totalRouted: this._routingHistory.length,
      customRules: this._customRules.length,
      recentRoutes: this._routingHistory.slice(-10),
    };
  }

  /**
   * Get all domain definitions.
   * @returns {Object}
   */
  getDomains() {
    const result = {};
    for (const [name, config] of Object.entries(TASK_DOMAINS)) {
      result[name] = {
        ...config,
        stats: this._domainStats[name],
      };
    }
    return result;
  }

  /**
   * Get all pool configurations.
   * @returns {Object}
   */
  getPools() {
    return { ...POOL_CONFIG };
  }

  /**
   * Get the skill registry.
   * @returns {Object}
   */
  getSkills() {
    return { ...SKILL_REGISTRY };
  }
}

// ─── Singleton Factory ─────────────────────────────────────────────────────────

/** @type {HeadyConductor|null} Singleton instance */
let _conductorInstance = null;

/**
 * Get the singleton HeadyConductor instance.
 * @returns {HeadyConductor}
 */
function getConductor() {
  if (!_conductorInstance) {
    _conductorInstance = new HeadyConductor();
  }
  return _conductorInstance;
}

// ─── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  // Primary exports
  getConductor,
  HeadyConductor,

  // Constants
  PHI,
  TASK_DOMAINS,
  SKILL_REGISTRY,
  POOL_CONFIG,
};
