/**
 * @file buddy-watchdog.js
 * @description Watchdog monitor — periodically health-checks registered nodes
 *              at a PHI-derived interval, detects unhealthy nodes, and triggers
 *              automatic recovery.
 *
 * PHI-derived default check interval: PHI^7 * 1000 ≈ 29 034 ms
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const { EventEmitter } = require('events');

const PHI = 1.6180339887;

/** PHI^7 * 1000 ms — default watchdog check interval */
const DEFAULT_INTERVAL_MS = Math.round(Math.pow(PHI, 7) * 1000);

/** PHI^5 * 1000 ms — default recovery attempt timeout */
const DEFAULT_RECOVERY_TIMEOUT_MS = Math.round(Math.pow(PHI, 5) * 1000);

/**
 * @typedef {object} WatchdogNode
 * @property {string}   id               - Node identifier
 * @property {Function} healthCheck      - Async () => boolean
 * @property {Function} [recover]        - Async () => void — recovery action
 * @property {number}   [failThreshold]  - Consecutive failures before triggering recovery (default 2)
 */

/**
 * @class BuddyWatchdog
 * @extends EventEmitter
 *
 * @example
 * const watchdog = new BuddyWatchdog({ intervalMs: 15000 });
 *
 * watchdog.register({
 *   id:          'buddy-core',
 *   healthCheck: () => buddyCore.getStats().errors < 10,
 *   recover:     () => buddyCore.recover(),
 * });
 *
 * watchdog.start();
 */
class BuddyWatchdog extends EventEmitter {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.intervalMs]         - Check interval in ms (default PHI^7*1000)
   * @param {number}  [opts.recoveryTimeoutMs]  - Max ms allowed for a recovery attempt
   * @param {boolean} [opts.stopOnError=false]  - Stop watchdog if a check itself throws
   */
  constructor(opts = {}) {
    super();

    this.intervalMs          = opts.intervalMs          ?? DEFAULT_INTERVAL_MS;
    this.recoveryTimeoutMs   = opts.recoveryTimeoutMs   ?? DEFAULT_RECOVERY_TIMEOUT_MS;
    this.stopOnError         = opts.stopOnError         ?? false;

    /** @type {Map<string, WatchdogNode & { failures: number, lastCheck: number, status: string }>} */
    this._nodes = new Map();

    /** @type {*|null} */
    this._timer = null;

    /** @type {boolean} */
    this._running = false;

    /** @type {Array<{ id: string, event: string, ts: number, message?: string }>} */
    this._log = [];
  }

  // ─── Node Registration ───────────────────────────────────────────────────────

  /**
   * Register a node for watchdog monitoring.
   *
   * @param {WatchdogNode} node
   */
  register(node) {
    if (!node.id || typeof node.healthCheck !== 'function') {
      throw new TypeError('BuddyWatchdog.register: node must have id and healthCheck()');
    }

    this._nodes.set(node.id, {
      ...node,
      failures:  0,
      lastCheck: 0,
      status:    'unknown',
    });
  }

  /**
   * Unregister a node.
   *
   * @param {string} id
   */
  unregister(id) {
    this._nodes.delete(id);
  }

  // ─── Lifecycle ───────────────────────────────────────────────────────────────

  /**
   * Start the periodic watchdog checks.
   *
   * @param {number} [intervalMs] - Override the instance-level interval
   */
  start(intervalMs) {
    if (this._running) return;
    this._running  = true;
    const interval = intervalMs ?? this.intervalMs;

    this._timer = setInterval(() => this._runChecks(), interval);
    if (this._timer.unref) this._timer.unref();

    this.emit('started', { intervalMs: interval, nodes: this._nodes.size });
  }

  /**
   * Stop the watchdog.
   */
  stop() {
    if (!this._running) return;
    this._running = false;
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
    this.emit('stopped', {});
  }

  /**
   * Manually trigger a single check cycle.
   *
   * @returns {Promise<void>}
   */
  async check() {
    return this._runChecks();
  }

  // ─── Status ──────────────────────────────────────────────────────────────────

  /**
   * Return the current status of all monitored nodes.
   *
   * @returns {Array<{ id: string, status: string, failures: number, lastCheck: number }>}
   */
  getStatus() {
    return Array.from(this._nodes.values()).map((n) => ({
      id:        n.id,
      status:    n.status,
      failures:  n.failures,
      lastCheck: n.lastCheck,
    }));
  }

  /**
   * Return the recent watchdog event log.
   *
   * @param {number} [limit=50]
   * @returns {object[]}
   */
  getLog(limit = 50) {
    return this._log.slice(-limit);
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Run a health check cycle across all nodes.
   */
  async _runChecks() {
    const checks = Array.from(this._nodes.values()).map((node) =>
      this._checkNode(node).catch((err) => {
        this._addLog(node.id, 'checkError', err.message);
        if (this.stopOnError) this.stop();
      }),
    );

    await Promise.allSettled(checks);
  }

  /**
   * @private Check a single node and react to unhealthy state.
   * @param {object} node
   */
  async _checkNode(node) {
    let healthy = false;
    try {
      healthy = !!(await node.healthCheck());
    } catch (_) {
      healthy = false;
    }

    node.lastCheck = Date.now();

    if (healthy) {
      if (node.failures > 0) {
        this._addLog(node.id, 'recovered', `Recovered after ${node.failures} failures`);
        this.emit('recovered', { id: node.id });
      }
      node.failures = 0;
      node.status   = 'healthy';
      this.emit('healthy', { id: node.id, ts: node.lastCheck });
      return;
    }

    node.failures++;
    node.status = 'unhealthy';
    this._addLog(node.id, 'unhealthy', `Failure #${node.failures}`);
    this.emit('unhealthy', { id: node.id, failures: node.failures });

    const threshold = node.failThreshold ?? 2;
    if (node.failures >= threshold && typeof node.recover === 'function') {
      this._addLog(node.id, 'recovering', `Triggering recovery (failures: ${node.failures})`);
      this.emit('recovering', { id: node.id, failures: node.failures });

      try {
        await Promise.race([
          node.recover(),
          new Promise((_, reject) =>
            setTimeout(() => reject(new Error('Recovery timeout')), this.recoveryTimeoutMs).unref(),
          ),
        ]);

        node.failures = 0;
        node.status   = 'recovered';
        this._addLog(node.id, 'recoverySuccess', 'Recovery completed');
        this.emit('recoverySuccess', { id: node.id });
      } catch (err) {
        this._addLog(node.id, 'recoveryFailed', err.message);
        this.emit('recoveryFailed', { id: node.id, error: err.message });
      }
    }
  }

  /**
   * @private Append to internal event log.
   * @param {string} id
   * @param {string} event
   * @param {string} [message]
   */
  _addLog(id, event, message) {
    this._log.push({ id, event, ts: Date.now(), message });
    if (this._log.length > 500) this._log.shift();
  }
}

module.exports = {
  BuddyWatchdog,
  DEFAULT_INTERVAL_MS,
  DEFAULT_RECOVERY_TIMEOUT_MS,
  PHI,
};
