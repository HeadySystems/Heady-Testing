/**
 * @file swarm-consensus.js
 * @description Swarm consensus — multi-agent voting on decisions with weighted
 *              consensus based on agent expertise, confidence thresholds,
 *              and tie-breaking logic.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const { EventEmitter } = require('events');
const crypto = require('crypto');

const PHI = 1.6180339887;

/** Default confidence threshold for consensus action (PHI-derived: ~0.618) */
const DEFAULT_CONFIDENCE_THRESHOLD = 1 / PHI; // ~0.618

/**
 * @typedef {object} Agent
 * @property {string}  id          - Agent identifier
 * @property {string}  [domain]    - Domain of expertise
 * @property {number}  [expertise] - Expertise weight [0, 1] — default 1.0
 */

/**
 * @typedef {object} Vote
 * @property {string}  agentId    - Voting agent ID
 * @property {*}       choice     - The agent's chosen option
 * @property {number}  confidence - Agent's confidence in its choice [0, 1]
 * @property {string}  [reason]   - Optional reasoning
 */

/**
 * @typedef {object} ConsensusResult
 * @property {string}   roundId      - Round identifier
 * @property {*}        decision     - Winning choice (null if below threshold)
 * @property {boolean}  achieved     - Whether consensus threshold was met
 * @property {number}   confidence   - Weighted confidence of winning choice
 * @property {number}   threshold    - Required threshold
 * @property {object}   tally        - { choice: weightedScore }
 * @property {Vote[]}   votes        - All cast votes
 * @property {string}   [tieBreaker] - How tie was resolved if applicable
 */

/**
 * @class ConsensusRound
 * Represents one voting round for a specific decision.
 */
class ConsensusRound {
  /**
   * @param {object}  opts
   * @param {string}  opts.id          - Round ID
   * @param {string}  opts.question    - The decision question
   * @param {*[]}     opts.options     - Available choices
   * @param {number}  opts.threshold   - Required confidence to act
   * @param {number}  opts.quorum      - Minimum fraction of agents that must vote
   */
  constructor(opts) {
    this.id        = opts.id;
    this.question  = opts.question;
    this.options   = opts.options;
    this.threshold = opts.threshold;
    this.quorum    = opts.quorum ?? 0.5;
    this.createdAt = Date.now();

    /** @type {Vote[]} */
    this.votes = [];

    /** @type {boolean} */
    this.closed = false;
  }

  /**
   * Cast a vote.
   *
   * @param {Vote} vote
   */
  castVote(vote) {
    if (this.closed) throw new Error(`Round "${this.id}" is already closed`);
    // Prevent duplicate votes from same agent
    if (this.votes.some((v) => v.agentId === vote.agentId)) {
      throw new Error(`Agent "${vote.agentId}" has already voted in round "${this.id}"`);
    }
    this.votes.push(vote);
  }
}

/**
 * @class SwarmConsensus
 * @extends EventEmitter
 *
 * @example
 * const swarm = new SwarmConsensus({ confidenceThreshold: 0.7 });
 *
 * swarm.registerAgent({ id: 'agent-a', domain: 'security',  expertise: 0.9 });
 * swarm.registerAgent({ id: 'agent-b', domain: 'analytics', expertise: 0.7 });
 *
 * const round = swarm.openRound({
 *   question: 'Should we enable rate limiting for API endpoint /v1/chat?',
 *   options:  ['yes', 'no'],
 * });
 *
 * swarm.vote(round.id, { agentId: 'agent-a', choice: 'yes', confidence: 0.9 });
 * swarm.vote(round.id, { agentId: 'agent-b', choice: 'yes', confidence: 0.8 });
 *
 * const result = swarm.tally(round.id);
 */
class SwarmConsensus extends EventEmitter {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.confidenceThreshold] - Required weighted confidence to act (default 1/PHI ≈ 0.618)
   * @param {number}  [opts.quorum]              - Min fraction of agents that must vote (default 0.5)
   * @param {string}  [opts.tieBreakerStrategy]  - 'random' | 'oldest_agent' | 'abstain' (default 'random')
   */
  constructor(opts = {}) {
    super();

    this.confidenceThreshold = opts.confidenceThreshold ?? DEFAULT_CONFIDENCE_THRESHOLD;
    this.quorum              = opts.quorum              ?? 0.5;
    this.tieBreakerStrategy  = opts.tieBreakerStrategy  ?? 'random';

    /** @type {Map<string, Agent>} */
    this._agents = new Map();

    /** @type {Map<string, ConsensusRound>} */
    this._rounds = new Map();
  }

  // ─── Agent Management ────────────────────────────────────────────────────────

  /**
   * Register a voting agent.
   *
   * @param {Agent} agent
   */
  registerAgent(agent) {
    if (!agent.id) throw new TypeError('SwarmConsensus.registerAgent: agent.id is required');
    this._agents.set(agent.id, { expertise: 1.0, ...agent });
  }

  /**
   * Unregister an agent.
   *
   * @param {string} id
   */
  unregisterAgent(id) {
    this._agents.delete(id);
  }

  // ─── Voting ──────────────────────────────────────────────────────────────────

  /**
   * Open a new consensus round.
   *
   * @param {object}  opts
   * @param {string}  opts.question    - The decision question
   * @param {*[]}     opts.options     - Valid choices
   * @param {number}  [opts.threshold] - Override instance threshold
   * @param {number}  [opts.quorum]    - Override instance quorum
   * @returns {ConsensusRound}
   */
  openRound(opts) {
    const round = new ConsensusRound({
      id:        crypto.randomBytes(6).toString('hex'),
      question:  opts.question,
      options:   opts.options ?? [],
      threshold: opts.threshold ?? this.confidenceThreshold,
      quorum:    opts.quorum    ?? this.quorum,
    });

    this._rounds.set(round.id, round);
    this.emit('roundOpened', { roundId: round.id, question: round.question });
    return round;
  }

  /**
   * Cast a vote in a round.
   *
   * @param {string}  roundId
   * @param {Vote}    vote
   */
  vote(roundId, vote) {
    const round = this._rounds.get(roundId);
    if (!round) throw new Error(`No open round with id "${roundId}"`);

    const agent = this._agents.get(vote.agentId);
    if (!agent) throw new Error(`Unknown agent "${vote.agentId}"`);

    round.castVote(vote);
    this.emit('voteCast', { roundId, agentId: vote.agentId, choice: vote.choice });
  }

  /**
   * Tally votes for a round and compute consensus.
   *
   * @param {string}   roundId
   * @param {object}   [opts]
   * @param {boolean}  [opts.close=true] - Mark round as closed after tallying
   * @returns {ConsensusResult}
   */
  tally(roundId, opts = {}) {
    const round = this._rounds.get(roundId);
    if (!round) throw new Error(`No round with id "${roundId}"`);

    const close = opts.close ?? true;
    if (close) round.closed = true;

    const totalAgents = this._agents.size;
    const quorumMet   = totalAgents === 0 || (round.votes.length / totalAgents) >= round.quorum;

    if (!quorumMet) {
      const result = {
        roundId:    round.id,
        decision:   null,
        achieved:   false,
        confidence: 0,
        threshold:  round.threshold,
        tally:      {},
        votes:      round.votes,
        reason:     `Quorum not met: ${round.votes.length}/${totalAgents} agents voted (required ${round.quorum * 100}%)`,
      };
      this.emit('tallied', result);
      return result;
    }

    // Compute weighted tally: each vote contributes agent.expertise * vote.confidence
    const tally = {};
    for (const vote of round.votes) {
      const agent  = this._agents.get(vote.agentId) ?? { expertise: 1.0 };
      const weight = agent.expertise * vote.confidence;
      const key    = String(vote.choice);
      tally[key]   = (tally[key] ?? 0) + weight;
    }

    // Normalize scores
    const totalWeight = Object.values(tally).reduce((s, v) => s + v, 0);
    const normalized  = {};
    for (const [k, v] of Object.entries(tally)) {
      normalized[k] = totalWeight > 0 ? v / totalWeight : 0;
    }

    // Find winner(s)
    const sorted   = Object.entries(normalized).sort((a, b) => b[1] - a[1]);
    const topScore = sorted[0]?.[1] ?? 0;
    const winners  = sorted.filter(([, s]) => Math.abs(s - topScore) < 1e-9);

    let decision    = null;
    let tieBreaker  = null;

    if (winners.length > 1) {
      // Tie resolution
      tieBreaker = this.tieBreakerStrategy;
      if (this.tieBreakerStrategy === 'random') {
        decision = winners[Math.floor(Math.random() * winners.length)][0];
      } else if (this.tieBreakerStrategy === 'oldest_agent') {
        // Pick the choice voted by the earliest registered agent
        const agentOrder = Array.from(this._agents.keys());
        const winnerChoices = new Set(winners.map(([c]) => c));
        for (const agentId of agentOrder) {
          const vote = round.votes.find((v) => v.agentId === agentId && winnerChoices.has(String(v.choice)));
          if (vote) { decision = String(vote.choice); break; }
        }
      } else {
        // 'abstain'
        decision = null;
      }
    } else {
      decision = sorted[0]?.[0] ?? null;
    }

    const confidence = decision ? (normalized[decision] ?? 0) : 0;
    const achieved   = confidence >= round.threshold;

    const result = {
      roundId:    round.id,
      decision:   achieved ? decision : null,
      achieved,
      confidence,
      threshold:  round.threshold,
      tally:      normalized,
      votes:      round.votes,
      tieBreaker,
    };

    this.emit('tallied', result);
    if (achieved) this.emit('consensusReached', result);

    return result;
  }

  /**
   * List all open rounds.
   *
   * @returns {object[]}
   */
  listRounds() {
    return Array.from(this._rounds.values()).map((r) => ({
      id:        r.id,
      question:  r.question,
      votes:     r.votes.length,
      closed:    r.closed,
      createdAt: r.createdAt,
    }));
  }
}

module.exports = {
  SwarmConsensus,
  ConsensusRound,
  DEFAULT_CONFIDENCE_THRESHOLD,
  PHI,
};
