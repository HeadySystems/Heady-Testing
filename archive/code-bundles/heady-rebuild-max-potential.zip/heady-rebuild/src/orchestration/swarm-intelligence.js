/**
 * @file swarm-intelligence.js
 * @description Swarm intelligence — collective pattern recognition, stigmergic
 *              indirect coordination (pheromone-like signals), emergent behaviour
 *              from simple agent rules, and task allocation optimization.
 *
 * Inspired by ACO (Ant Colony Optimization) and stigmergy:
 *  - Agents deposit "pheromone" when completing tasks
 *  - Pheromone evaporates at PHI^-1 per cycle (~0.618 decay)
 *  - New agents follow high-pheromone paths (positive reinforcement)
 *  - Emergent routing arises without central coordination
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const { EventEmitter } = require('events');

const PHI = 1.6180339887;

/** Pheromone evaporation rate per cycle (PHI^-1 ≈ 0.618) */
const EVAPORATION_RATE = 1 / PHI; // ~0.618

/** PHI^4 * 1000 ms — default pheromone update interval */
const PHEROMONE_INTERVAL_MS = Math.round(Math.pow(PHI, 4) * 1000);

/** PHI^2 — initial pheromone deposit amount */
const INITIAL_PHEROMONE = Math.pow(PHI, 2); // ~2.618

// ─── Pheromone Map ────────────────────────────────────────────────────────────

/**
 * @class PheromoneMap
 * Stores pheromone concentration for task→agent paths.
 * Concentration decays each evaporation cycle.
 */
class PheromoneMap {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.evaporationRate] - Fraction remaining after each cycle (default 1/PHI)
   * @param {number}  [opts.minConcentration] - Floor below which entries are evicted
   */
  constructor(opts = {}) {
    this.evaporationRate   = opts.evaporationRate   ?? EVAPORATION_RATE;
    this.minConcentration  = opts.minConcentration  ?? 0.01;

    /** @type {Map<string, number>} path-key → concentration */
    this._map = new Map();
  }

  /**
   * Deposit pheromone on a path (taskId → agentId).
   *
   * @param {string} taskId
   * @param {string} agentId
   * @param {number} [amount] - Amount to add (default INITIAL_PHEROMONE)
   */
  deposit(taskId, agentId, amount = INITIAL_PHEROMONE) {
    const key = `${taskId}::${agentId}`;
    this._map.set(key, (this._map.get(key) ?? 0) + amount);
  }

  /**
   * Get pheromone concentration for a path.
   *
   * @param {string} taskId
   * @param {string} agentId
   * @returns {number}
   */
  get(taskId, agentId) {
    return this._map.get(`${taskId}::${agentId}`) ?? 0;
  }

  /**
   * Run one evaporation cycle — multiply all concentrations by evaporationRate,
   * evict entries below minConcentration.
   *
   * @returns {number} Entries evicted
   */
  evaporate() {
    let evicted = 0;
    for (const [key, conc] of this._map) {
      const updated = conc * this.evaporationRate;
      if (updated < this.minConcentration) {
        this._map.delete(key);
        evicted++;
      } else {
        this._map.set(key, updated);
      }
    }
    return evicted;
  }

  /**
   * Get all (agentId, concentration) pairs for a task, sorted by concentration descending.
   *
   * @param {string} taskId
   * @returns {Array<{ agentId: string, concentration: number }>}
   */
  getPathsForTask(taskId) {
    const prefix = `${taskId}::`;
    const results = [];
    for (const [key, conc] of this._map) {
      if (key.startsWith(prefix)) {
        results.push({ agentId: key.slice(prefix.length), concentration: conc });
      }
    }
    return results.sort((a, b) => b.concentration - a.concentration);
  }

  /** @returns {number} Total entries in pheromone map */
  get size() { return this._map.size; }
}

// ─── Swarm Agent ─────────────────────────────────────────────────────────────

/**
 * @typedef {object} SwarmAgentConfig
 * @property {string}   id           - Agent identifier
 * @property {string[]} capabilities - Task types this agent can handle
 * @property {number}   [capacity]   - Max concurrent tasks (default 1)
 * @property {Function} [execute]    - Async (task) => result — task handler
 */

/**
 * @class SwarmIntelligence
 * @extends EventEmitter
 *
 * @example
 * const swarm = new SwarmIntelligence();
 *
 * swarm.registerAgent({
 *   id:           'worker-1',
 *   capabilities: ['summarize', 'classify'],
 *   capacity:     3,
 *   execute:      async (task) => processTask(task),
 * });
 *
 * const result = await swarm.allocate({ type: 'summarize', payload: { text: '...' } });
 */
class SwarmIntelligence extends EventEmitter {
  /**
   * @param {object}  [opts]
   * @param {number}  [opts.pheromoneInterval] - Evaporation cycle interval in ms
   * @param {number}  [opts.explorationRate]   - Probability of random vs pheromone routing [0,1] (default 1/PHI^2 ≈ 0.382)
   */
  constructor(opts = {}) {
    super();

    this.pheromoneInterval = opts.pheromoneInterval ?? PHEROMONE_INTERVAL_MS;
    this.explorationRate   = opts.explorationRate   ?? (1 / Math.pow(PHI, 2)); // ~0.382

    this.pheromones = new PheromoneMap();

    /** @type {Map<string, SwarmAgentConfig & { load: number }>} */
    this._agents = new Map();

    /** @type {Array<{ taskId: string, type: string, ts: number, agentId: string, duration: number, success: boolean }>} */
    this._history = [];

    /** @type {*|null} */
    this._pheromoneTimer = null;
  }

  // ─── Agent Management ────────────────────────────────────────────────────────

  /**
   * Register an agent in the swarm.
   *
   * @param {SwarmAgentConfig} config
   */
  registerAgent(config) {
    if (!config.id) throw new TypeError('SwarmIntelligence.registerAgent: config.id is required');
    this._agents.set(config.id, { capacity: 1, ...config, load: 0 });
    this.emit('agentRegistered', { id: config.id, capabilities: config.capabilities ?? [] });
  }

  /**
   * Deregister an agent.
   *
   * @param {string} id
   */
  deregisterAgent(id) {
    this._agents.delete(id);
  }

  // ─── Task Allocation ─────────────────────────────────────────────────────────

  /**
   * Allocate a task to the best available agent using pheromone-guided selection.
   * Falls back to load-balancing when no pheromone trail exists.
   *
   * @param {object}   task
   * @param {string}   task.type      - Task type (must match agent capability)
   * @param {string}   [task.id]      - Optional task ID
   * @param {*}        [task.payload] - Task payload
   * @returns {Promise<{ agentId: string, result: *, taskId: string, duration: number }>}
   * @throws {Error} If no capable agent is available
   */
  async allocate(task) {
    const taskId = task.id ?? `task_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;

    const agent = this._selectAgent(task.type, taskId);
    if (!agent) {
      throw new Error(`No available agent for task type "${task.type}"`);
    }

    agent.load++;
    this.emit('taskAllocated', { taskId, agentId: agent.id, type: task.type });

    const t0 = Date.now();
    let result;
    let success = false;

    try {
      if (typeof agent.execute === 'function') {
        result = await agent.execute({ ...task, id: taskId });
      }
      success = true;

      // Deposit pheromone for successful execution
      this.pheromones.deposit(task.type, agent.id, INITIAL_PHEROMONE);
      this.emit('taskComplete', { taskId, agentId: agent.id, type: task.type });
    } catch (err) {
      // Deposit negative signal (small amount) — reduces future routing to this agent for this task
      this.pheromones.deposit(task.type, agent.id, INITIAL_PHEROMONE * 0.1);
      this.emit('taskFailed', { taskId, agentId: agent.id, type: task.type, error: err.message });
      throw err;
    } finally {
      agent.load = Math.max(0, agent.load - 1);
      const duration = Date.now() - t0;
      this._history.push({ taskId, type: task.type, ts: t0, agentId: agent.id, duration, success });
      if (this._history.length > 1000) this._history.shift();
    }

    return { agentId: agent.id, result, taskId, duration: Date.now() - t0 };
  }

  // ─── Pattern Recognition ─────────────────────────────────────────────────────

  /**
   * Analyse task history to identify collective patterns.
   *
   * @param {object}  [opts]
   * @param {number}  [opts.windowMs] - Time window for analysis (default PHI^9*1000 ≈ 76 s)
   * @returns {{
   *   taskTypeFrequency: object,
   *   agentLoadDistribution: object,
   *   successRates: object,
   *   avgDurationByType: object,
   * }}
   */
  recognizePatterns(opts = {}) {
    const window = opts.windowMs ?? Math.round(Math.pow(PHI, 9) * 1000);
    const since  = Date.now() - window;
    const recent = this._history.filter((e) => e.ts >= since);

    const typeFreq    = {};
    const agentLoad   = {};
    const typeSuccess = {};
    const typeDuration = {};

    for (const entry of recent) {
      // Type frequency
      typeFreq[entry.type] = (typeFreq[entry.type] ?? 0) + 1;

      // Agent load distribution
      agentLoad[entry.agentId] = (agentLoad[entry.agentId] ?? 0) + 1;

      // Success rates
      if (!typeSuccess[entry.type]) typeSuccess[entry.type] = { ok: 0, total: 0 };
      typeSuccess[entry.type].total++;
      if (entry.success) typeSuccess[entry.type].ok++;

      // Average duration
      if (!typeDuration[entry.type]) typeDuration[entry.type] = { sum: 0, count: 0 };
      typeDuration[entry.type].sum   += entry.duration;
      typeDuration[entry.type].count += 1;
    }

    const successRates = {};
    for (const [t, v] of Object.entries(typeSuccess)) {
      successRates[t] = v.total > 0 ? Math.round((v.ok / v.total) * 100) : 0;
    }

    const avgDuration = {};
    for (const [t, v] of Object.entries(typeDuration)) {
      avgDuration[t] = v.count > 0 ? Math.round(v.sum / v.count) : 0;
    }

    return {
      taskTypeFrequency:     typeFreq,
      agentLoadDistribution: agentLoad,
      successRates,
      avgDurationByType:     avgDuration,
    };
  }

  // ─── Pheromone Lifecycle ─────────────────────────────────────────────────────

  /**
   * Start periodic pheromone evaporation.
   */
  startEvaporation() {
    if (this._pheromoneTimer) return;
    this._pheromoneTimer = setInterval(() => {
      const evicted = this.pheromones.evaporate();
      this.emit('evaporation', { evicted, remaining: this.pheromones.size });
    }, this.pheromoneInterval);
    if (this._pheromoneTimer.unref) this._pheromoneTimer.unref();
  }

  /** Stop pheromone evaporation. */
  stopEvaporation() {
    if (this._pheromoneTimer) {
      clearInterval(this._pheromoneTimer);
      this._pheromoneTimer = null;
    }
  }

  // ─── Stats ────────────────────────────────────────────────────────────────────

  /**
   * Snapshot of swarm state.
   *
   * @returns {{ agents: number, pheromoneEntries: number, taskHistory: number }}
   */
  stats() {
    return {
      agents:           this._agents.size,
      pheromoneEntries: this.pheromones.size,
      taskHistory:      this._history.length,
      agentLoad:        Array.from(this._agents.values()).map((a) => ({ id: a.id, load: a.load, capacity: a.capacity })),
    };
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Select the best agent for a task type using pheromone + load balancing.
   * Uses epsilon-greedy exploration:
   *   - With probability explorationRate: random capable agent with available capacity
   *   - Otherwise: highest pheromone concentration + lowest load
   *
   * @param {string} type
   * @param {string} taskId
   * @returns {object|null}
   */
  _selectAgent(type, taskId) {
    const capable = Array.from(this._agents.values()).filter(
      (a) => (a.capabilities ?? []).includes(type) && a.load < a.capacity,
    );

    if (capable.length === 0) return null;

    // Explore: pick random
    if (Math.random() < this.explorationRate) {
      return capable[Math.floor(Math.random() * capable.length)];
    }

    // Exploit: use pheromone signals
    const paths = this.pheromones.getPathsForTask(type);
    if (paths.length > 0) {
      for (const { agentId } of paths) {
        const agent = this._agents.get(agentId);
        if (agent && agent.load < agent.capacity && (agent.capabilities ?? []).includes(type)) {
          return agent;
        }
      }
    }

    // Fallback: least loaded
    return capable.sort((a, b) => (a.load / a.capacity) - (b.load / b.capacity))[0];
  }
}

module.exports = {
  SwarmIntelligence,
  PheromoneMap,
  EVAPORATION_RATE,
  PHEROMONE_INTERVAL_MS,
  INITIAL_PHEROMONE,
  PHI,
};
