/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║  Liquid Dynamic Agent Orchestrator                                         ║
 * ║  Heady™ Systems · Sacred Geometry Architecture                             ║
 * ║  © 2026 HeadySystems Inc. All rights reserved.                             ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  Agents are fluid. They spawn, merge, scale, and dissolve.                 ║
 * ║  Golden-ratio-proportioned group limits. PHI-derived concurrency.          ║
 * ║  HeadyValidator guards every action. JSONL audit trail.                    ║
 * ║  No self-HTTP. Local dispatch only. The swarm is self-organizing.          ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * @module agent-orchestrator
 * @version 4.0.0
 * @author HeadySystems Engineering
 */

'use strict';

const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

// ─── Sacred Constants ──────────────────────────────────────────────────────────

/** @constant {number} PHI - The golden ratio */
const PHI = 1.6180339887;

/** @constant {number} MIN_CONCURRENCY - Absolute minimum concurrent agents (PHI-derived) */
const MIN_CONCURRENCY = Math.ceil(PHI * 2); // 4

/** @constant {number} MAX_CONCURRENCY - Absolute maximum concurrent agents (PHI-derived) */
const MAX_CONCURRENCY = Math.ceil(PHI * PHI * PHI * 10); // ~42

/** @constant {number} IDLE_RECLAIM_MS - Idle agent reclamation timeout */
const IDLE_RECLAIM_MS = Math.round(120000 * PHI); // ~194s

/** @constant {number} SCALE_CHECK_INTERVAL - Auto-scaling check interval */
const SCALE_CHECK_INTERVAL = Math.round(15000 * PHI); // ~24.3s

/** @constant {number} AUDIT_FLUSH_INTERVAL - JSONL audit flush interval */
const AUDIT_FLUSH_INTERVAL = Math.round(30000 * PHI); // ~48.5s

// ─── Service Groups ────────────────────────────────────────────────────────────

/**
 * Service group definitions with golden-ratio-proportioned concurrency limits.
 * Limits are scaled from a base of 2 by successive PHI multiplications.
 *
 * @constant {Object}
 */
const SERVICE_GROUPS = Object.freeze({
  reasoning:     { base: Math.ceil(2 * PHI * PHI),   desc: 'Reasoning and logic agents' },
  embedding:     { base: Math.ceil(2 * PHI),          desc: 'Embedding generation agents' },
  search:        { base: Math.ceil(2 * PHI),          desc: 'Search and retrieval agents' },
  creative:      { base: Math.ceil(2 * PHI),          desc: 'Creative content agents' },
  battle:        { base: 2,                            desc: 'Adversarial testing agents' },
  ops:           { base: Math.ceil(2 * PHI),          desc: 'Operations and infrastructure' },
  coding:        { base: Math.ceil(2 * PHI * PHI),   desc: 'Code generation and review' },
  governance:    { base: 2,                            desc: 'Governance and compliance' },
  vision:        { base: Math.ceil(2 * PHI),          desc: 'Vision and image analysis' },
  sims:          { base: 2,                            desc: 'Simulation runners' },
  swarm:         { base: Math.ceil(2 * PHI * PHI),   desc: 'Swarm coordination agents' },
  intelligence:  { base: Math.ceil(2 * PHI),          desc: 'Intelligence gathering' },
  // Heady-specific provider groups
  'heady-core':      { base: Math.ceil(2 * PHI * PHI * PHI), desc: 'Core Heady processing' },
  'heady-memory':    { base: Math.ceil(2 * PHI * PHI),       desc: 'Heady memory operations' },
  'heady-pipeline':  { base: Math.ceil(2 * PHI),             desc: 'Heady pipeline tasks' },
  'heady-telemetry': { base: 2,                               desc: 'Heady telemetry agents' },
  'heady-conductor': { base: Math.ceil(2 * PHI),             desc: 'Conductor federation' },
});

// ─── HeadySupervisor ───────────────────────────────────────────────────────────

/**
 * Per-agent statistics tracker and supervisor.
 * Monitors tasks, errors, latency, and uptime for each agent.
 *
 * @class HeadySupervisor
 */
class HeadySupervisor {
  constructor() {
    /** @type {Map<string, Object>} Agent stats: agentId → stats */
    this._agents = new Map();
  }

  /**
   * Register an agent for supervision.
   * @param {string} agentId
   * @param {string} group - Service group.
   * @param {Object} [metadata]
   */
  register(agentId, group, metadata = {}) {
    this._agents.set(agentId, {
      agentId,
      group,
      metadata,
      totalTasks: 0,
      successTasks: 0,
      errorCount: 0,
      latencySum: 0,
      latencyCount: 0,
      minLatency: Infinity,
      maxLatency: 0,
      registeredAt: Date.now(),
      lastActivity: Date.now(),
      status: 'idle',
    });
  }

  /**
   * Record a task completion for an agent.
   * @param {string} agentId
   * @param {number} latencyMs
   * @param {boolean} success
   */
  recordTask(agentId, latencyMs, success) {
    const stats = this._agents.get(agentId);
    if (!stats) return;

    stats.totalTasks++;
    if (success) stats.successTasks++;
    else stats.errorCount++;

    stats.latencySum += latencyMs;
    stats.latencyCount++;
    stats.minLatency = Math.min(stats.minLatency, latencyMs);
    stats.maxLatency = Math.max(stats.maxLatency, latencyMs);
    stats.lastActivity = Date.now();
  }

  /**
   * Set agent status.
   * @param {string} agentId
   * @param {string} status - 'idle', 'busy', 'error', 'terminated'.
   */
  setStatus(agentId, status) {
    const stats = this._agents.get(agentId);
    if (stats) {
      stats.status = status;
      stats.lastActivity = Date.now();
    }
  }

  /**
   * Unregister an agent.
   * @param {string} agentId
   */
  unregister(agentId) {
    this._agents.delete(agentId);
  }

  /**
   * Get stats for a specific agent.
   * @param {string} agentId
   * @returns {Object|null}
   */
  getStats(agentId) {
    const stats = this._agents.get(agentId);
    if (!stats) return null;

    return {
      ...stats,
      avgLatency: stats.latencyCount > 0 ? stats.latencySum / stats.latencyCount : 0,
      errorRate: stats.totalTasks > 0 ? stats.errorCount / stats.totalTasks : 0,
      uptime: Date.now() - stats.registeredAt,
    };
  }

  /**
   * Get stats for all agents in a group.
   * @param {string} group
   * @returns {Array<Object>}
   */
  getGroupStats(group) {
    const results = [];
    for (const stats of this._agents.values()) {
      if (stats.group === group) {
        results.push(this.getStats(stats.agentId));
      }
    }
    return results;
  }

  /**
   * Get global stats across all agents.
   * @returns {Object}
   */
  getGlobalStats() {
    let total = 0, busy = 0, idle = 0, errored = 0;
    const byGroup = {};

    for (const stats of this._agents.values()) {
      total++;
      if (stats.status === 'busy') busy++;
      else if (stats.status === 'idle') idle++;
      else if (stats.status === 'error') errored++;

      byGroup[stats.group] = (byGroup[stats.group] || 0) + 1;
    }

    return { total, busy, idle, errored, byGroup };
  }

  /**
   * Get idle agents that exceed the reclamation timeout.
   * @param {number} [timeoutMs=IDLE_RECLAIM_MS]
   * @returns {Array<string>} Agent IDs eligible for reclamation.
   */
  getIdleForReclamation(timeoutMs = IDLE_RECLAIM_MS) {
    const now = Date.now();
    const result = [];
    for (const stats of this._agents.values()) {
      if (stats.status === 'idle' && (now - stats.lastActivity) > timeoutMs) {
        result.push(stats.agentId);
      }
    }
    return result;
  }
}

// ─── HeadyValidator (Pre-Action Protocol) ──────────────────────────────────────

/**
 * HeadyValidator — pre-action validation protocol.
 * Every agent action must pass through validation before execution.
 *
 * Checks:
 *   1. Registry check (agent must be registered)
 *   2. Min-concurrent enforcement (group must have minimum agents)
 *   3. Memory scan with injection defense
 *   4. Pattern matching for known attack vectors
 *   5. Strict typed payload validation
 *   6. Static refusal for ill-typed payloads
 *
 * @class HeadyValidator
 */
class HeadyValidator {
  /**
   * @param {HeadySupervisor} supervisor
   * @param {Object} [opts]
   * @param {Object} [opts.vectorMemory] - Vector memory for memory-scan checks.
   */
  constructor(supervisor, opts = {}) {
    this._supervisor = supervisor;
    this._vectorMemory = opts.vectorMemory || null;
    this._rejections = [];

    // Known injection patterns
    this._injectionPatterns = [
      /\bignore\s+(previous|above|all)\s+instructions?\b/i,
      /\bsystem\s*:\s*you\s+are\b/i,
      /\bact\s+as\s+(if|a|an)\b.*\b(admin|root|god)\b/i,
      /\b(DROP|DELETE|TRUNCATE)\s+TABLE\b/i,
      /<script[\s>]/i,
      /\$\{.*\}/,
      /\{\{.*\}\}/,
      /__(proto|constructor)__/,
    ];
  }

  /**
   * Validate an agent action.
   * @param {Object} action
   * @param {string} action.agentId - Agent performing the action.
   * @param {string} action.group - Service group.
   * @param {string} action.type - Action type.
   * @param {Object} action.payload - Action payload.
   * @returns {Object} { valid: boolean, reason?: string, checks: Array }
   */
  async validate(action) {
    const checks = [];

    // 1. Registry check
    const registered = this._supervisor.getStats(action.agentId);
    checks.push({ name: 'registry', passed: !!registered });
    if (!registered) {
      return this._reject(action, 'Agent not registered', checks);
    }

    // 2. Min-concurrent enforcement
    const groupConfig = SERVICE_GROUPS[action.group];
    if (groupConfig) {
      const groupStats = this._supervisor.getGroupStats(action.group);
      const activeCount = groupStats.filter(s => s && s.status !== 'terminated').length;
      checks.push({ name: 'min_concurrent', passed: activeCount >= 1 });
      // Allow action even if below minimum (just flag it)
    } else {
      checks.push({ name: 'min_concurrent', passed: true, note: 'unknown group' });
    }

    // 3. Memory scan with injection defense
    const memoryScan = this._scanForInjection(action.payload);
    checks.push({ name: 'memory_scan', passed: !memoryScan.detected, details: memoryScan });
    if (memoryScan.detected) {
      return this._reject(action, `Injection attempt detected: ${memoryScan.pattern}`, checks);
    }

    // 4. Pattern matching
    const patternCheck = this._checkPatterns(action);
    checks.push({ name: 'pattern_match', passed: patternCheck.valid });
    if (!patternCheck.valid) {
      return this._reject(action, `Pattern violation: ${patternCheck.reason}`, checks);
    }

    // 5. Strict typed payload validation
    const typeCheck = this._validatePayloadTypes(action.type, action.payload);
    checks.push({ name: 'type_validation', passed: typeCheck.valid });
    if (!typeCheck.valid) {
      // 6. Static refusal for ill-typed payloads
      return this._reject(action, `Type validation failed: ${typeCheck.reason}`, checks);
    }

    return { valid: true, checks };
  }

  /**
   * Scan payload strings for injection attempts.
   * @private
   * @param {Object} payload
   * @returns {Object} { detected: boolean, pattern?: string }
   */
  _scanForInjection(payload) {
    const strings = this._extractStrings(payload);

    for (const str of strings) {
      for (const pattern of this._injectionPatterns) {
        if (pattern.test(str)) {
          return { detected: true, pattern: pattern.source, value: str.slice(0, 100) };
        }
      }
    }

    return { detected: false };
  }

  /**
   * Extract all string values from a nested object.
   * @private
   * @param {*} obj
   * @param {number} depth
   * @returns {Array<string>}
   */
  _extractStrings(obj, depth = 0) {
    if (depth > 10) return [];
    if (typeof obj === 'string') return [obj];
    if (Array.isArray(obj)) return obj.flatMap(item => this._extractStrings(item, depth + 1));
    if (obj && typeof obj === 'object') {
      return Object.values(obj).flatMap(v => this._extractStrings(v, depth + 1));
    }
    return [];
  }

  /**
   * Check action against known patterns.
   * @private
   * @param {Object} action
   * @returns {Object} { valid: boolean, reason?: string }
   */
  _checkPatterns(action) {
    // Reject actions targeting internal system paths
    if (action.payload && typeof action.payload.target === 'string') {
      if (action.payload.target.includes('__internal__') || action.payload.target.includes('..')) {
        return { valid: false, reason: 'Forbidden target path' };
      }
    }

    // Reject oversized payloads
    const payloadSize = JSON.stringify(action.payload || {}).length;
    if (payloadSize > 1048576) { // 1MB
      return { valid: false, reason: `Payload too large: ${payloadSize} bytes` };
    }

    return { valid: true };
  }

  /**
   * Validate payload types based on action type schema.
   * @private
   * @param {string} actionType
   * @param {Object} payload
   * @returns {Object} { valid: boolean, reason?: string }
   */
  _validatePayloadTypes(actionType, payload) {
    if (!payload || typeof payload !== 'object') {
      return { valid: false, reason: 'Payload must be a non-null object' };
    }

    // Generic schemas by action type prefix
    const schemas = {
      'task:execute': { required: ['taskType'], types: { taskType: 'string', input: 'object' } },
      'agent:spawn':  { required: ['type', 'group'], types: { type: 'string', group: 'string' } },
      'agent:terminate': { required: ['agentId'], types: { agentId: 'string' } },
      'memory:ingest': { required: ['text'], types: { text: 'string' } },
      'memory:query':  { required: ['query'], types: { query: 'string' } },
    };

    const schema = schemas[actionType];
    if (!schema) return { valid: true }; // No schema = allow (unknown types pass)

    // Check required fields
    for (const field of schema.required || []) {
      if (payload[field] === undefined || payload[field] === null) {
        return { valid: false, reason: `Missing required field: ${field}` };
      }
    }

    // Check types
    for (const [field, expectedType] of Object.entries(schema.types || {})) {
      if (payload[field] !== undefined && typeof payload[field] !== expectedType) {
        return { valid: false, reason: `Field "${field}" must be ${expectedType}, got ${typeof payload[field]}` };
      }
    }

    return { valid: true };
  }

  /**
   * Record a rejection.
   * @private
   * @param {Object} action
   * @param {string} reason
   * @param {Array} checks
   * @returns {Object}
   */
  _reject(action, reason, checks) {
    const rejection = {
      valid: false,
      reason,
      checks,
      agentId: action.agentId,
      actionType: action.type,
      ts: Date.now(),
    };

    this._rejections.push(rejection);
    if (this._rejections.length > 1000) {
      this._rejections = this._rejections.slice(-1000);
    }

    return rejection;
  }

  /**
   * Get rejection history.
   * @param {number} [limit=50]
   * @returns {Array<Object>}
   */
  getRejections(limit = 50) {
    return this._rejections.slice(-limit);
  }
}

// ─── JSONL Audit Trail ─────────────────────────────────────────────────────────

/**
 * Append-only JSONL audit trail for agent actions.
 *
 * @class AuditTrail
 */
class AuditTrail {
  /**
   * @param {string} [filePath] - Path to JSONL audit file.
   */
  constructor(filePath) {
    this._path = filePath || path.join(os.tmpdir(), 'heady-orchestrator-audit.jsonl');
    this._buffer = [];
    this._flushTimer = null;
    this._totalEntries = 0;

    this._startFlush();
  }

  /**
   * Log an audit event.
   * @param {Object} event
   */
  log(event) {
    const entry = {
      ...event,
      ts: Date.now(),
      seq: this._totalEntries++,
    };
    this._buffer.push(JSON.stringify(entry));
  }

  /**
   * Flush buffered entries to disk.
   */
  flush() {
    if (this._buffer.length === 0) return;

    const batch = this._buffer.splice(0);
    const data = batch.join('\n') + '\n';

    try {
      fs.appendFileSync(this._path, data, 'utf-8');
    } catch (_) { /* best-effort audit write */ }
  }

  /**
   * Start periodic flush.
   * @private
   */
  _startFlush() {
    this._flushTimer = setInterval(() => this.flush(), AUDIT_FLUSH_INTERVAL);
    if (this._flushTimer.unref) this._flushTimer.unref();
  }

  /**
   * Stop periodic flush and write remaining entries.
   */
  destroy() {
    if (this._flushTimer) {
      clearInterval(this._flushTimer);
      this._flushTimer = null;
    }
    this.flush();
  }

  /**
   * Get audit stats.
   * @returns {Object}
   */
  stats() {
    return {
      totalEntries: this._totalEntries,
      buffered: this._buffer.length,
      filePath: this._path,
    };
  }
}

// ─── Agent Orchestrator ────────────────────────────────────────────────────────

/**
 * Liquid Dynamic Agent Orchestrator — manages the agent swarm.
 *
 * @class AgentOrchestrator
 * @extends EventEmitter
 */
class AgentOrchestrator extends EventEmitter {
  /**
   * @param {Object} [opts]
   * @param {Object} [opts.vectorMemory] - Vector memory instance for prompt ingestion.
   * @param {Object} [opts.conductor] - HeadyConductor instance for federated routing.
   */
  constructor(opts = {}) {
    super();
    this.setMaxListeners(50);

    // Core subsystems
    this.supervisor = new HeadySupervisor();
    this.validator = new HeadyValidator(this.supervisor, { vectorMemory: opts.vectorMemory });
    this.audit = new AuditTrail();

    // Bound systems
    this._vectorMemory = opts.vectorMemory || null;
    this._conductor = opts.conductor || null;

    // Task handlers (local dispatch)
    this._handlers = new Map();

    // Task queue
    this._queue = [];
    this._processing = false;

    // Concurrency management
    this._currentConcurrency = MIN_CONCURRENCY;
    this._activeCount = 0;

    // Auto-scaling timer
    this._scaleTimer = null;
    this._autoScale = true;

    // Performance profiling
    this._profiling = {
      totalDispatched: 0,
      totalLatency: 0,
      peakConcurrency: 0,
    };

    this._startAutoScaling();
  }

  // ── Handler Registration (Local Dispatch) ──

  /**
   * Register a local handler function for an action type.
   * No self-HTTP: handlers execute in-process.
   *
   * @param {string} actionType - Action type identifier.
   * @param {Function} handler - Async handler function(payload, context) => result.
   */
  registerHandler(actionType, handler) {
    if (typeof handler !== 'function') {
      throw new TypeError(`Handler for "${actionType}" must be a function`);
    }
    this._handlers.set(actionType, handler);
  }

  // ── Agent Management ──

  /**
   * Spawn an agent.
   * @param {string} agentId
   * @param {string} group
   * @param {Object} [metadata]
   * @returns {Object} Agent record.
   */
  spawnAgent(agentId, group, metadata = {}) {
    this.supervisor.register(agentId, group, metadata);
    this.audit.log({ event: 'agent:spawn', agentId, group, metadata });
    this.emit('agent:spawn', { agentId, group });

    // Register in vector memory agent manager if available
    if (this._vectorMemory && this._vectorMemory.agentManager) {
      this._vectorMemory.agentManager.spawn({
        id: agentId,
        type: group,
        metadata,
      });
    }

    return { agentId, group, status: 'idle' };
  }

  /**
   * Terminate an agent.
   * @param {string} agentId
   * @param {string} [reason='manual']
   */
  terminateAgent(agentId, reason = 'manual') {
    this.supervisor.unregister(agentId);
    this.audit.log({ event: 'agent:terminate', agentId, reason });
    this.emit('agent:terminate', { agentId, reason });

    if (this._vectorMemory && this._vectorMemory.agentManager) {
      this._vectorMemory.agentManager.terminate(agentId, reason);
    }
  }

  // ── Task Dispatch ──

  /**
   * Dispatch an action through the orchestrator.
   * Validates → routes → executes locally → audits.
   *
   * @param {Object} action
   * @param {string} action.agentId - Agent performing the action.
   * @param {string} action.group - Service group.
   * @param {string} action.type - Action type.
   * @param {Object} action.payload - Action payload.
   * @param {boolean} [action.queue=false] - If true, queue instead of immediate dispatch.
   * @returns {Promise<Object>} Dispatch result.
   */
  async dispatch(action) {
    // Validate
    const validation = await this.validator.validate(action);
    if (!validation.valid) {
      this.audit.log({
        event: 'dispatch:rejected',
        agentId: action.agentId,
        type: action.type,
        reason: validation.reason,
      });
      this.emit('dispatch:rejected', { action, reason: validation.reason });
      return { success: false, error: validation.reason, validation };
    }

    // Queue if requested
    if (action.queue) {
      this._queue.push(action);
      this._processQueue();
      return { success: true, queued: true, queuePosition: this._queue.length };
    }

    return this._executeAction(action);
  }

  /**
   * Execute a validated action.
   * @private
   * @param {Object} action
   * @returns {Promise<Object>}
   */
  async _executeAction(action) {
    const startTime = Date.now();
    this._activeCount++;
    this._profiling.totalDispatched++;
    this._profiling.peakConcurrency = Math.max(this._profiling.peakConcurrency, this._activeCount);

    this.supervisor.setStatus(action.agentId, 'busy');

    try {
      let result;

      // Route through conductor if available
      if (this._conductor && typeof this._conductor.routeSync === 'function') {
        const routing = this._conductor.routeSync({
          type: action.type,
          group: action.group,
          payload: action.payload,
        });
        // Use routing recommendation but still dispatch locally
        action._routing = routing;
      }

      // Local dispatch: find registered handler
      const handler = this._handlers.get(action.type);
      if (handler) {
        const context = {
          agentId: action.agentId,
          group: action.group,
          routing: action._routing,
          ts: startTime,
        };
        result = await handler(action.payload, context);
      } else {
        result = {
          message: `No local handler for "${action.type}". Action accepted but not processed.`,
          unhandled: true,
        };
      }

      const latency = Date.now() - startTime;
      this._profiling.totalLatency += latency;

      this.supervisor.recordTask(action.agentId, latency, true);
      this.supervisor.setStatus(action.agentId, 'idle');

      this.audit.log({
        event: 'dispatch:success',
        agentId: action.agentId,
        type: action.type,
        latencyMs: latency,
      });

      this.emit('dispatch:success', { action, result, latencyMs: latency });
      return { success: true, result, latencyMs: latency };

    } catch (err) {
      const latency = Date.now() - startTime;
      this.supervisor.recordTask(action.agentId, latency, false);
      this.supervisor.setStatus(action.agentId, 'error');

      this.audit.log({
        event: 'dispatch:error',
        agentId: action.agentId,
        type: action.type,
        error: err.message,
        latencyMs: latency,
      });

      this.emit('dispatch:error', { action, error: err.message });
      return { success: false, error: err.message, latencyMs: latency };

    } finally {
      this._activeCount--;
    }
  }

  /**
   * Process queued actions.
   * @private
   */
  async _processQueue() {
    if (this._processing) return;
    this._processing = true;

    while (this._queue.length > 0 && this._activeCount < this._currentConcurrency) {
      const action = this._queue.shift();
      // Fire-and-forget dispatch (errors are handled internally)
      this._executeAction(action).catch(() => {});
    }

    this._processing = false;
  }

  // ── Atomic Prompt Ingestion Protocol ──

  /**
   * Ingest a prompt result atomically into vector memory with provenance.
   * @param {Object} opts
   * @param {string} opts.agentId - Agent that produced the result.
   * @param {string} opts.prompt - Original prompt.
   * @param {string} opts.result - Result text.
   * @param {Object} [opts.metadata] - Additional metadata.
   * @returns {Promise<Object>} Ingestion result.
   */
  async ingestPromptResult(opts) {
    if (!this._vectorMemory) {
      return { success: false, error: 'Vector memory not bound' };
    }

    try {
      const entry = {
        text: opts.result,
        source: `agent:${opts.agentId}`,
        metadata: {
          ...opts.metadata,
          agentId: opts.agentId,
          prompt: opts.prompt,
          ingestedAt: Date.now(),
          provenance: 'atomic-ingestion',
        },
      };

      const result = await this._vectorMemory.ingest(entry);

      this.audit.log({
        event: 'prompt:ingested',
        agentId: opts.agentId,
        memoryId: result.entryId,
        octant: result.octant,
      });

      return { success: true, ...result };
    } catch (err) {
      return { success: false, error: err.message };
    }
  }

  // ── Auto-Scaling ──

  /**
   * Start the auto-scaling check loop.
   * @private
   */
  _startAutoScaling() {
    this._scaleTimer = setInterval(() => {
      if (!this._autoScale) return;

      try {
        this._autoScaleCheck();
      } catch (_) { /* swallow scaling errors */ }
    }, SCALE_CHECK_INTERVAL);

    if (this._scaleTimer.unref) this._scaleTimer.unref();
  }

  /**
   * Perform an auto-scaling check.
   * Scale up under pressure, reclaim idle agents.
   * Never drop below MIN_CONCURRENCY.
   * @private
   */
  _autoScaleCheck() {
    const globalStats = this.supervisor.getGlobalStats();
    const utilization = globalStats.total > 0
      ? globalStats.busy / globalStats.total
      : 0;

    // Scale UP: if utilization exceeds PHI-inverse (~0.618), increase capacity
    if (utilization > (1 / PHI) && this._currentConcurrency < MAX_CONCURRENCY) {
      const newMax = Math.min(
        Math.ceil(this._currentConcurrency * PHI),
        MAX_CONCURRENCY
      );
      if (newMax !== this._currentConcurrency) {
        this._currentConcurrency = newMax;
        this.emit('scale:up', { newConcurrency: newMax, utilization });
        this.audit.log({ event: 'scale:up', newConcurrency: newMax, utilization });
      }
    }

    // Scale DOWN: reclaim idle agents (but never below minimum)
    const idle = this.supervisor.getIdleForReclamation();
    let reclaimed = 0;
    for (const agentId of idle) {
      if (globalStats.total - reclaimed <= MIN_CONCURRENCY) break;
      this.terminateAgent(agentId, 'idle_reclamation');
      reclaimed++;
    }

    if (reclaimed > 0) {
      this._currentConcurrency = Math.max(
        MIN_CONCURRENCY,
        this._currentConcurrency - reclaimed
      );
      this.emit('scale:down', { reclaimed, newConcurrency: this._currentConcurrency });
      this.audit.log({ event: 'scale:down', reclaimed, newConcurrency: this._currentConcurrency });
    }

    // Process queue if there's capacity
    if (this._queue.length > 0) {
      this._processQueue();
    }
  }

  // ── Performance Profiling ──

  /**
   * Get performance profiling data and feedback.
   * @returns {Object}
   */
  getProfilingReport() {
    const avg = this._profiling.totalDispatched > 0
      ? this._profiling.totalLatency / this._profiling.totalDispatched
      : 0;

    const globalStats = this.supervisor.getGlobalStats();

    return {
      totalDispatched: this._profiling.totalDispatched,
      avgLatencyMs: Math.round(avg * 100) / 100,
      peakConcurrency: this._profiling.peakConcurrency,
      currentConcurrency: this._currentConcurrency,
      queueLength: this._queue.length,
      activeCount: this._activeCount,
      globalAgentStats: globalStats,
      auditStats: this.audit.stats(),
      recommendations: this._generateRecommendations(avg, globalStats),
    };
  }

  /**
   * Generate performance recommendations.
   * @private
   * @param {number} avgLatency
   * @param {Object} globalStats
   * @returns {Array<string>}
   */
  _generateRecommendations(avgLatency, globalStats) {
    const recs = [];

    if (avgLatency > 5000) {
      recs.push('Average latency exceeds 5s. Consider increasing concurrency or optimizing handlers.');
    }
    if (this._queue.length > 50) {
      recs.push(`Queue depth is ${this._queue.length}. Consider scaling up agent pool.`);
    }
    if (globalStats.errored > globalStats.total * 0.2) {
      recs.push('Over 20% of agents in error state. Investigate common failure patterns.');
    }
    if (globalStats.idle > globalStats.total * 0.8 && globalStats.total > MIN_CONCURRENCY * 2) {
      recs.push('Over 80% of agents idle. Consider reducing pool size to save resources.');
    }

    return recs;
  }

  // ── Express Routes ──

  /**
   * Register Express routes for the orchestrator API.
   * @param {Object} app - Express app or Router.
   * @param {string} [prefix='/api/orchestrator']
   */
  registerRoutes(app, prefix = '/api/orchestrator') {

    /** POST /api/orchestrator/dispatch — Dispatch an action */
    app.post(`${prefix}/dispatch`, async (req, res) => {
      try {
        const result = await this.dispatch(req.body);
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/orchestrator/agents/spawn — Spawn an agent */
    app.post(`${prefix}/agents/spawn`, (req, res) => {
      const { agentId, group, metadata } = req.body;
      const id = agentId || crypto.randomUUID();
      const agent = this.spawnAgent(id, group || 'reasoning', metadata);
      res.json({ ok: true, agent });
    });

    /** DELETE /api/orchestrator/agents/:id — Terminate an agent */
    app.delete(`${prefix}/agents/:id`, (req, res) => {
      this.terminateAgent(req.params.id, req.query.reason || 'api');
      res.json({ ok: true });
    });

    /** GET /api/orchestrator/agents — List all agents */
    app.get(`${prefix}/agents`, (_req, res) => {
      res.json({ ok: true, stats: this.supervisor.getGlobalStats() });
    });

    /** GET /api/orchestrator/agents/:id — Get agent stats */
    app.get(`${prefix}/agents/:id`, (req, res) => {
      const stats = this.supervisor.getStats(req.params.id);
      if (!stats) return res.status(404).json({ ok: false, error: 'Agent not found' });
      res.json({ ok: true, stats });
    });

    /** POST /api/orchestrator/ingest — Atomic prompt ingestion */
    app.post(`${prefix}/ingest`, async (req, res) => {
      try {
        const result = await this.ingestPromptResult(req.body);
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/orchestrator/profiling — Performance profiling report */
    app.get(`${prefix}/profiling`, (_req, res) => {
      res.json({ ok: true, ...this.getProfilingReport() });
    });

    /** GET /api/orchestrator/groups — Service group configuration */
    app.get(`${prefix}/groups`, (_req, res) => {
      const groups = {};
      for (const [name, config] of Object.entries(SERVICE_GROUPS)) {
        const groupStats = this.supervisor.getGroupStats(name);
        groups[name] = {
          ...config,
          activeAgents: groupStats.length,
        };
      }
      res.json({ ok: true, groups });
    });

    /** GET /api/orchestrator/queue — Queue status */
    app.get(`${prefix}/queue`, (_req, res) => {
      res.json({
        ok: true,
        queueLength: this._queue.length,
        activeCount: this._activeCount,
        currentConcurrency: this._currentConcurrency,
      });
    });

    /** GET /api/orchestrator/validation/rejections — Validation rejections */
    app.get(`${prefix}/validation/rejections`, (req, res) => {
      const limit = parseInt(req.query.limit) || 50;
      res.json({ ok: true, rejections: this.validator.getRejections(limit) });
    });

    /** GET /api/orchestrator/audit — Audit trail stats */
    app.get(`${prefix}/audit`, (_req, res) => {
      res.json({ ok: true, ...this.audit.stats() });
    });
  }

  // ── Lifecycle ──

  /**
   * Bind external systems.
   * @param {Object} systems
   */
  bind(systems) {
    if (systems.vectorMemory) {
      this._vectorMemory = systems.vectorMemory;
      this.validator._vectorMemory = systems.vectorMemory;
    }
    if (systems.conductor) {
      this._conductor = systems.conductor;
    }
  }

  /**
   * Get orchestrator state.
   * @returns {Object}
   */
  getState() {
    return {
      currentConcurrency: this._currentConcurrency,
      activeCount: this._activeCount,
      queueLength: this._queue.length,
      agents: this.supervisor.getGlobalStats(),
      profiling: this.getProfilingReport(),
      audit: this.audit.stats(),
    };
  }

  /**
   * Destroy the orchestrator and release resources.
   */
  destroy() {
    if (this._scaleTimer) {
      clearInterval(this._scaleTimer);
      this._scaleTimer = null;
    }
    this.audit.destroy();
    this.removeAllListeners();
  }
}

// ─── Singleton Instance ────────────────────────────────────────────────────────

/** @type {AgentOrchestrator} Default orchestrator instance */
const orchestrator = new AgentOrchestrator();

// ─── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  // Primary export
  orchestrator,

  // Classes
  AgentOrchestrator,
  HeadySupervisor,
  HeadyValidator,
  AuditTrail,

  // Constants
  PHI,
  MIN_CONCURRENCY,
  MAX_CONCURRENCY,
  SERVICE_GROUPS,
  IDLE_RECLAIM_MS,
  SCALE_CHECK_INTERVAL,
};
