/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║  Monte Carlo Engine SPEC-1 — Probabilistic Decision Framework              ║
 * ║  Heady™ Systems · Sacred Geometry Architecture                             ║
 * ║  © 2026 HeadySystems Inc. All rights reserved.                             ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  Certainty is a lie. The Monte Carlo Engine quantifies uncertainty.         ║
 * ║  Seeded PRNG for reproducibility. Risk grading. Confidence bounds.         ║
 * ║  PHI governs scheduling. The organism predicts its own future.             ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * @module monte-carlo
 * @version 4.0.0
 * @author HeadySystems Engineering
 */

'use strict';

// ─── Sacred Constants ──────────────────────────────────────────────────────────

/** @constant {number} PHI - The golden ratio */
const PHI = 1.6180339887;

/** @constant {number} DEFAULT_ITERATIONS - Default simulation iteration count */
const DEFAULT_ITERATIONS = 10000;

/** @constant {number} MAX_HISTORY - Max simulation history entries */
const MAX_HISTORY = 100;

// ─── Risk Grades ───────────────────────────────────────────────────────────────

/**
 * Risk color grades.
 * @readonly
 * @enum {string}
 */
const RiskColor = Object.freeze({
  GREEN:  'GREEN',
  YELLOW: 'YELLOW',
  ORANGE: 'ORANGE',
  RED:    'RED',
});

/**
 * Risk severity levels.
 * @readonly
 * @enum {string}
 */
const RiskSeverity = Object.freeze({
  LOW:      'LOW',
  MEDIUM:   'MEDIUM',
  HIGH:     'HIGH',
  CRITICAL: 'CRITICAL',
});

// ─── Seeded PRNG (Mulberry32) ──────────────────────────────────────────────────

/**
 * Mulberry32 seeded pseudo-random number generator.
 * Provides reproducible random sequences for simulation determinism.
 *
 * @class Mulberry32
 */
class Mulberry32 {
  /**
   * @param {number} seed - Integer seed value.
   */
  constructor(seed) {
    this._seed = seed | 0;
    this._initial = this._seed;
    this._calls = 0;
  }

  /**
   * Generate the next random number in [0, 1).
   * @returns {number}
   */
  next() {
    this._seed |= 0;
    this._seed = (this._seed + 0x6D2B79F5) | 0;
    let t = Math.imul(this._seed ^ (this._seed >>> 15), 1 | this._seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    this._calls++;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }

  /**
   * Generate a random number in [min, max).
   * @param {number} min
   * @param {number} max
   * @returns {number}
   */
  range(min, max) {
    return min + this.next() * (max - min);
  }

  /**
   * Generate a random integer in [min, max].
   * @param {number} min
   * @param {number} max
   * @returns {number}
   */
  intRange(min, max) {
    return Math.floor(this.range(min, max + 1));
  }

  /**
   * Generate a normally distributed random number (Box-Muller).
   * @param {number} [mean=0]
   * @param {number} [stddev=1]
   * @returns {number}
   */
  gaussian(mean = 0, stddev = 1) {
    const u1 = this.next() || 0.0001;
    const u2 = this.next();
    const z = Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
    return mean + z * stddev;
  }

  /**
   * Simulate a Bernoulli trial.
   * @param {number} probability - Success probability in [0,1].
   * @returns {boolean}
   */
  bernoulli(probability) {
    return this.next() < probability;
  }

  /**
   * Reset the PRNG to its initial seed.
   */
  reset() {
    this._seed = this._initial;
    this._calls = 0;
  }

  /**
   * Get PRNG state.
   * @returns {Object}
   */
  state() {
    return { seed: this._initial, currentSeed: this._seed, calls: this._calls };
  }
}

// ─── Quick Readiness Check ─────────────────────────────────────────────────────

/**
 * Signal weights for quick readiness scoring.
 * @constant {Object}
 */
const READINESS_WEIGHTS = Object.freeze({
  errorRate:      -0.30,  // Higher error rate → lower readiness
  lastDeployAge:  -0.10,  // Older deploy → slightly lower readiness
  cpuPressure:    -0.15,  // Higher CPU → lower readiness
  memoryPressure: -0.15,  // Higher memory → lower readiness
  serviceHealth:   0.20,  // Higher health → higher readiness
  openIncidents:  -0.10,  // More incidents → lower readiness
});

/**
 * Perform a quick readiness check using weighted signal scoring.
 * No simulation needed — instant assessment.
 *
 * @param {Object} signals - Current system signals.
 * @param {number} signals.errorRate - Current error rate (0-1).
 * @param {number} [signals.lastDeployAge=0] - Hours since last deploy.
 * @param {number} [signals.cpuPressure=0] - CPU utilization (0-1).
 * @param {number} [signals.memoryPressure=0] - Memory utilization (0-1).
 * @param {number} [signals.serviceHealth=1] - Overall service health (0-1).
 * @param {number} [signals.openIncidents=0] - Number of open incidents.
 * @returns {Object} Readiness assessment { score, grade, color, signals }
 */
function quickReadiness(signals = {}) {
  const normalized = {
    errorRate:      Math.min(signals.errorRate || 0, 1),
    lastDeployAge:  Math.min((signals.lastDeployAge || 0) / 168, 1), // Normalize to weeks
    cpuPressure:    Math.min(signals.cpuPressure || 0, 1),
    memoryPressure: Math.min(signals.memoryPressure || 0, 1),
    serviceHealth:  Math.min(signals.serviceHealth !== undefined ? signals.serviceHealth : 1, 1),
    openIncidents:  Math.min((signals.openIncidents || 0) / 10, 1), // Normalize 0-10
  };

  // Compute weighted score (base = 1.0, deduct penalties)
  let score = 1.0;
  for (const [key, weight] of Object.entries(READINESS_WEIGHTS)) {
    score += weight * normalized[key];
  }
  score = Math.max(0, Math.min(1, score));

  // Determine grade and color
  let color, severity;
  if (score >= 0.8) {
    color = RiskColor.GREEN;
    severity = RiskSeverity.LOW;
  } else if (score >= 0.6) {
    color = RiskColor.YELLOW;
    severity = RiskSeverity.MEDIUM;
  } else if (score >= 0.35) {
    color = RiskColor.ORANGE;
    severity = RiskSeverity.HIGH;
  } else {
    color = RiskColor.RED;
    severity = RiskSeverity.CRITICAL;
  }

  return {
    score: Math.round(score * 10000) / 10000,
    color,
    severity,
    signals: normalized,
    weights: READINESS_WEIGHTS,
    ts: Date.now(),
  };
}

// ─── Full Monte Carlo Simulation ───────────────────────────────────────────────

/**
 * Run a full Monte Carlo simulation to estimate outcome probability distributions.
 *
 * @param {Object} opts
 * @param {number} [opts.iterations=10000] - Number of simulation iterations.
 * @param {number} [opts.seed] - PRNG seed (defaults to timestamp).
 * @param {number} [opts.baseSuccessRate=0.85] - Baseline success probability.
 * @param {Array<Object>} [opts.riskFactors=[]] - Risk factors:
 *   { name: string, probability: number (0-1), impact: number (0-1) }
 * @param {Array<Object>} [opts.mitigations=[]] - Mitigations:
 *   { name: string, boost: number (0-1), appliesTo?: string }
 * @returns {Object} Simulation results with confidence bounds and risk grading.
 */
function simulate(opts = {}) {
  const iterations = opts.iterations || DEFAULT_ITERATIONS;
  const seed = opts.seed || Date.now();
  const baseRate = opts.baseSuccessRate !== undefined ? opts.baseSuccessRate : 0.85;
  const riskFactors = opts.riskFactors || [];
  const mitigations = opts.mitigations || [];

  const rng = new Mulberry32(seed);
  const outcomes = new Float64Array(iterations);
  let successes = 0;
  let totalImpact = 0;

  // Pre-compute mitigation boosts per risk factor
  const mitigationMap = new Map();
  for (const mit of mitigations) {
    if (mit.appliesTo) {
      const existing = mitigationMap.get(mit.appliesTo) || 0;
      mitigationMap.set(mit.appliesTo, existing + (mit.boost || 0));
    }
  }
  // Global mitigation boost
  const globalBoost = mitigations
    .filter(m => !m.appliesTo)
    .reduce((sum, m) => sum + (m.boost || 0), 0);

  for (let i = 0; i < iterations; i++) {
    let iterSuccess = baseRate + globalBoost;

    // Apply each risk factor
    for (const risk of riskFactors) {
      const mitBoost = mitigationMap.get(risk.name) || 0;
      const effectiveProb = Math.max(0, (risk.probability || 0) - mitBoost);

      if (rng.bernoulli(effectiveProb)) {
        const impact = risk.impact || 0.1;
        iterSuccess -= impact;
        totalImpact += impact;
      }
    }

    iterSuccess = Math.max(0, Math.min(1, iterSuccess));
    outcomes[i] = iterSuccess;

    if (rng.bernoulli(iterSuccess)) {
      successes++;
    }
  }

  // Compute statistics
  const sorted = Array.from(outcomes).sort((a, b) => a - b);
  const mean = sorted.reduce((s, v) => s + v, 0) / iterations;
  const variance = sorted.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / iterations;
  const stddev = Math.sqrt(variance);

  const p5 = sorted[Math.floor(iterations * 0.05)];
  const p25 = sorted[Math.floor(iterations * 0.25)];
  const median = sorted[Math.floor(iterations * 0.5)];
  const p75 = sorted[Math.floor(iterations * 0.75)];
  const p95 = sorted[Math.floor(iterations * 0.95)];

  const successRate = successes / iterations;

  // Confidence bounds
  const confidenceBounds = {
    '90%': { lower: p5, upper: p95 },
    '50%': { lower: p25, upper: p75 },
  };

  // Risk grading
  let color, severity;
  if (successRate >= 0.85) {
    color = RiskColor.GREEN;
    severity = RiskSeverity.LOW;
  } else if (successRate >= 0.65) {
    color = RiskColor.YELLOW;
    severity = RiskSeverity.MEDIUM;
  } else if (successRate >= 0.40) {
    color = RiskColor.ORANGE;
    severity = RiskSeverity.HIGH;
  } else {
    color = RiskColor.RED;
    severity = RiskSeverity.CRITICAL;
  }

  return {
    iterations,
    seed,
    baseSuccessRate: baseRate,
    successRate: Math.round(successRate * 10000) / 10000,
    mean: Math.round(mean * 10000) / 10000,
    median: Math.round(median * 10000) / 10000,
    stddev: Math.round(stddev * 10000) / 10000,
    variance: Math.round(variance * 10000) / 10000,
    percentiles: {
      p5:  Math.round(p5 * 10000) / 10000,
      p25: Math.round(p25 * 10000) / 10000,
      p50: Math.round(median * 10000) / 10000,
      p75: Math.round(p75 * 10000) / 10000,
      p95: Math.round(p95 * 10000) / 10000,
    },
    confidenceBounds: {
      '90%': {
        lower: Math.round(p5 * 10000) / 10000,
        upper: Math.round(p95 * 10000) / 10000,
      },
      '50%': {
        lower: Math.round(p25 * 10000) / 10000,
        upper: Math.round(p75 * 10000) / 10000,
      },
    },
    riskGrade: { color, severity },
    riskFactors: riskFactors.map(r => ({
      name: r.name,
      probability: r.probability,
      impact: r.impact,
      mitigated: mitigationMap.has(r.name),
    })),
    mitigations: mitigations.map(m => ({
      name: m.name,
      boost: m.boost,
      appliesTo: m.appliesTo || 'global',
    })),
    totalImpactSum: Math.round(totalImpact * 10000) / 10000,
    ts: Date.now(),
  };
}

// ─── Simulation History Tracker ────────────────────────────────────────────────

/**
 * Track simulation results over time for trend analysis.
 *
 * @class SimulationHistory
 */
class SimulationHistory {
  /**
   * @param {number} [maxEntries=100]
   */
  constructor(maxEntries = MAX_HISTORY) {
    this._entries = [];
    this._maxEntries = maxEntries;
  }

  /**
   * Record a simulation result.
   * @param {Object} result - Simulation result from simulate().
   * @param {string} [label] - Optional label/context.
   */
  record(result, label = '') {
    this._entries.push({
      label,
      successRate: result.successRate,
      mean: result.mean,
      stddev: result.stddev,
      riskGrade: result.riskGrade,
      iterations: result.iterations,
      ts: result.ts || Date.now(),
    });

    if (this._entries.length > this._maxEntries) {
      this._entries = this._entries.slice(-this._maxEntries);
    }
  }

  /**
   * Get the trend: is risk increasing, decreasing, or stable?
   * @param {number} [window=10] - Number of recent entries to analyze.
   * @returns {Object} Trend analysis.
   */
  getTrend(window = 10) {
    const recent = this._entries.slice(-window);
    if (recent.length < 2) return { trend: 'insufficient_data', entries: recent.length };

    const rates = recent.map(e => e.successRate);
    const first = rates.slice(0, Math.floor(rates.length / 2));
    const second = rates.slice(Math.floor(rates.length / 2));

    const avgFirst = first.reduce((s, v) => s + v, 0) / first.length;
    const avgSecond = second.reduce((s, v) => s + v, 0) / second.length;
    const delta = avgSecond - avgFirst;

    let trend;
    if (delta > 0.05) trend = 'improving';
    else if (delta < -0.05) trend = 'degrading';
    else trend = 'stable';

    return {
      trend,
      delta: Math.round(delta * 10000) / 10000,
      avgEarly: Math.round(avgFirst * 10000) / 10000,
      avgRecent: Math.round(avgSecond * 10000) / 10000,
      entries: recent.length,
    };
  }

  /**
   * Get all history entries.
   * @param {number} [limit]
   * @returns {Array<Object>}
   */
  getAll(limit) {
    if (limit) return this._entries.slice(-limit);
    return [...this._entries];
  }

  /**
   * Clear history.
   */
  clear() {
    this._entries = [];
  }
}

// ─── MC Scheduler ──────────────────────────────────────────────────────────────

/**
 * Monte Carlo Scheduler — selects strategies and records results.
 * Uses PHI-derived intervals for scheduled simulation runs.
 *
 * @class MCScheduler
 */
class MCScheduler {
  constructor() {
    this._strategies = new Map();
    this._history = new SimulationHistory();
    this._timings = [];
    this._lastRun = null;
    this._interval = Math.round(60000 * PHI); // PHI-scaled minute
    this._timer = null;
  }

  /**
   * Register a simulation strategy.
   * @param {string} name - Strategy name.
   * @param {Object} config - Strategy configuration (riskFactors, mitigations, etc.).
   */
  registerStrategy(name, config) {
    this._strategies.set(name, {
      name,
      config,
      lastResult: null,
      runCount: 0,
    });
  }

  /**
   * Select the best strategy based on recent results.
   * Picks the strategy with the highest recent success rate.
   * @returns {string|null} Best strategy name or null if none registered.
   */
  selectBest() {
    let best = null;
    let bestRate = -1;

    for (const [name, strategy] of this._strategies) {
      if (strategy.lastResult && strategy.lastResult.successRate > bestRate) {
        bestRate = strategy.lastResult.successRate;
        best = name;
      }
    }

    // If no results yet, return the first strategy
    if (!best && this._strategies.size > 0) {
      best = this._strategies.keys().next().value;
    }

    return best;
  }

  /**
   * Run a simulation for a specific strategy.
   * @param {string} strategyName
   * @param {Object} [overrides] - Override simulation parameters.
   * @returns {Object} Simulation result.
   */
  runStrategy(strategyName, overrides = {}) {
    const strategy = this._strategies.get(strategyName);
    if (!strategy) {
      throw new Error(`Unknown strategy: "${strategyName}"`);
    }

    const result = simulate({
      ...strategy.config,
      ...overrides,
    });

    strategy.lastResult = result;
    strategy.runCount++;
    this._history.record(result, strategyName);
    this._lastRun = Date.now();

    return result;
  }

  /**
   * Run all registered strategies and return comparative results.
   * @param {Object} [overrides]
   * @returns {Object} Comparative analysis.
   */
  runAll(overrides = {}) {
    const results = {};
    for (const name of this._strategies.keys()) {
      results[name] = this.runStrategy(name, overrides);
    }

    const ranked = Object.entries(results)
      .sort(([, a], [, b]) => b.successRate - a.successRate)
      .map(([name, result], idx) => ({
        rank: idx + 1,
        strategy: name,
        successRate: result.successRate,
        riskGrade: result.riskGrade,
      }));

    return {
      results,
      ranked,
      recommended: ranked[0] ? ranked[0].strategy : null,
      ts: Date.now(),
    };
  }

  /**
   * Record external timing data (fed from pipeline feedback loop).
   * @param {Array<Object>} timings - Array of { stage, avgDuration, success }.
   */
  recordTimings(timings) {
    this._timings.push(...timings.map(t => ({ ...t, ts: Date.now() })));
    if (this._timings.length > 1000) {
      this._timings = this._timings.slice(-1000);
    }
  }

  /**
   * Record a result directly (for external integrations).
   * @param {Object} result
   * @param {string} [label]
   */
  recordResult(result, label) {
    this._history.record(result, label);
  }

  /**
   * Get simulation trend analysis.
   * @returns {Object}
   */
  getTrend() {
    return this._history.getTrend();
  }

  /**
   * Get scheduler state.
   * @returns {Object}
   */
  getState() {
    const strategies = {};
    for (const [name, s] of this._strategies) {
      strategies[name] = {
        runCount: s.runCount,
        lastSuccessRate: s.lastResult ? s.lastResult.successRate : null,
        lastRiskGrade: s.lastResult ? s.lastResult.riskGrade : null,
      };
    }

    return {
      strategies,
      historyCount: this._history.getAll().length,
      trend: this._history.getTrend(),
      lastRun: this._lastRun,
      timingsCount: this._timings.length,
    };
  }

  /**
   * Start scheduled simulation runs.
   * @param {string} strategyName - Strategy to run on schedule.
   * @param {number} [intervalMs] - Override interval (default PHI-scaled).
   */
  startSchedule(strategyName, intervalMs) {
    this.stopSchedule();
    const interval = intervalMs || this._interval;

    this._timer = setInterval(() => {
      try {
        this.runStrategy(strategyName);
      } catch (_) { /* swallow scheduler errors */ }
    }, interval);

    if (this._timer.unref) this._timer.unref();
  }

  /**
   * Stop scheduled runs.
   */
  stopSchedule() {
    if (this._timer) {
      clearInterval(this._timer);
      this._timer = null;
    }
  }

  /**
   * Destroy the scheduler.
   */
  destroy() {
    this.stopSchedule();
    this._strategies.clear();
    this._history.clear();
    this._timings = [];
  }
}

// ─── Singleton Instances ───────────────────────────────────────────────────────

/** @type {MCScheduler} Default MC scheduler instance */
const mcScheduler = new MCScheduler();

// ─── Exports ───────────────────────────────────────────────────────────────────

module.exports = {
  // Primary exports
  mcScheduler,
  simulate,
  quickReadiness,

  // Classes
  Mulberry32,
  MCScheduler,
  SimulationHistory,

  // Enums
  RiskColor,
  RiskSeverity,

  // Constants
  PHI,
  DEFAULT_ITERATIONS,
  READINESS_WEIGHTS,
};
