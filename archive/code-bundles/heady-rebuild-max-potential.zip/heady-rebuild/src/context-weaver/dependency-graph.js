/**
 * @file dependency-graph.js
 * @description Dependency graph — addDependency, topological sort with cycle
 *              detection, getDependencies, and visualization data export.
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const PHI = 1.6180339887;

/**
 * @class DependencyGraph
 *
 * @example
 * const graph = new DependencyGraph();
 * graph.addDependency('app', 'database');
 * graph.addDependency('app', 'cache');
 * graph.addDependency('cache', 'database');
 *
 * const order = graph.topologicalSort();
 * // → ['database', 'cache', 'app']
 */
class DependencyGraph {
  constructor() {
    /** @type {Map<string, Set<string>>} node → set of nodes it depends on */
    this._edges = new Map();

    /** @type {Set<string>} All node names */
    this._nodes = new Set();
  }

  // ─── Graph Construction ───────────────────────────────────────────────────────

  /**
   * Declare that `from` depends on `to`.
   * Both nodes are automatically registered.
   *
   * @param {string} from - Dependent node
   * @param {string} to   - Dependency node
   * @returns {this} Chainable
   */
  addDependency(from, to) {
    this._ensureNode(from);
    this._ensureNode(to);
    this._edges.get(from).add(to);
    return this;
  }

  /**
   * Add a node without any dependencies.
   *
   * @param {string} node
   * @returns {this}
   */
  addNode(node) {
    this._ensureNode(node);
    return this;
  }

  /**
   * Remove a dependency edge.
   *
   * @param {string} from
   * @param {string} to
   * @returns {boolean}
   */
  removeDependency(from, to) {
    return this._edges.get(from)?.delete(to) ?? false;
  }

  /**
   * Remove a node and all edges referencing it.
   *
   * @param {string} node
   */
  removeNode(node) {
    this._nodes.delete(node);
    this._edges.delete(node);
    for (const deps of this._edges.values()) {
      deps.delete(node);
    }
  }

  // ─── Queries ──────────────────────────────────────────────────────────────────

  /**
   * Get direct dependencies of a node.
   *
   * @param {string} node
   * @returns {string[]}
   */
  getDependencies(node) {
    return Array.from(this._edges.get(node) ?? []);
  }

  /**
   * Get all nodes that directly depend on `node` (reverse edges).
   *
   * @param {string} node
   * @returns {string[]}
   */
  getDependents(node) {
    const result = [];
    for (const [n, deps] of this._edges) {
      if (deps.has(node)) result.push(n);
    }
    return result;
  }

  /**
   * Get all transitive dependencies of a node (recursive).
   *
   * @param {string}  node
   * @param {Set<string>} [_visited] - Internal cycle guard
   * @returns {string[]}
   */
  getAllDependencies(node, _visited = new Set()) {
    if (_visited.has(node)) return [];
    _visited.add(node);

    const direct = this.getDependencies(node);
    const all    = [...direct];
    for (const dep of direct) {
      all.push(...this.getAllDependencies(dep, _visited));
    }
    return [...new Set(all)];
  }

  /**
   * Check whether a path from `from` to `to` exists.
   *
   * @param {string} from
   * @param {string} to
   * @returns {boolean}
   */
  hasPath(from, to) {
    const visited = new Set();
    const stack   = [from];
    while (stack.length) {
      const node = stack.pop();
      if (node === to) return true;
      if (visited.has(node)) continue;
      visited.add(node);
      for (const dep of this._edges.get(node) ?? []) {
        stack.push(dep);
      }
    }
    return false;
  }

  // ─── Topological Sort ────────────────────────────────────────────────────────

  /**
   * Return nodes in topological order (dependencies before dependents).
   * Throws CycleError if a cycle is detected.
   *
   * @returns {string[]}
   * @throws {CycleError}
   */
  topologicalSort() {
    const result   = [];
    const visited  = new Set();
    const visiting = new Set(); // cycle detection

    const visit = (node) => {
      if (visited.has(node))  return;
      if (visiting.has(node)) {
        throw new CycleError(
          `Cycle detected involving node "${node}"`,
          { node, path: Array.from(visiting) },
        );
      }

      visiting.add(node);
      for (const dep of this._edges.get(node) ?? []) {
        visit(dep);
      }
      visiting.delete(node);
      visited.add(node);
      result.push(node);
    };

    for (const node of this._nodes) {
      visit(node);
    }

    return result;
  }

  /**
   * Detect all cycles in the graph.
   *
   * @returns {string[][]} Array of cycle paths (empty if none)
   */
  detectCycles() {
    const cycles   = [];
    const visited  = new Set();
    const path     = [];
    const pathSet  = new Set();

    const dfs = (node) => {
      if (pathSet.has(node)) {
        const cycleStart = path.indexOf(node);
        cycles.push(path.slice(cycleStart).concat(node));
        return;
      }
      if (visited.has(node)) return;

      visited.add(node);
      path.push(node);
      pathSet.add(node);

      for (const dep of this._edges.get(node) ?? []) {
        dfs(dep);
      }

      path.pop();
      pathSet.delete(node);
    };

    for (const node of this._nodes) {
      dfs(node);
    }

    return cycles;
  }

  // ─── Visualization ───────────────────────────────────────────────────────────

  /**
   * Export the graph as a visualization-friendly data structure.
   * Compatible with D3.js force-directed graphs and similar libraries.
   *
   * @param {object} [opts]
   * @param {boolean} [opts.includeWeights=false] - Include edge weight (currently always 1)
   * @returns {{ nodes: Array<{ id: string, deps: number }>, edges: Array<{ source: string, target: string, weight: number }> }}
   */
  toVisualizationData(opts = {}) {
    const includeWeights = opts.includeWeights ?? false;

    const nodes = Array.from(this._nodes).map((id) => ({
      id,
      deps:       this.getDependencies(id).length,
      dependents: this.getDependents(id).length,
      // PHI-scaled node importance: more dependents = larger radius hint
      radius:     Math.round(10 + this.getDependents(id).length * PHI * 3),
    }));

    const edges = [];
    for (const [from, deps] of this._edges) {
      for (const to of deps) {
        const edge = { source: from, target: to };
        if (includeWeights) edge.weight = 1;
        edges.push(edge);
      }
    }

    return { nodes, edges };
  }

  /**
   * Export to DOT language for Graphviz rendering.
   *
   * @param {object}  [opts]
   * @param {string}  [opts.graphName='G']
   * @param {boolean} [opts.directed=true]
   * @returns {string}
   */
  toDot(opts = {}) {
    const name     = opts.graphName ?? 'G';
    const directed = opts.directed  ?? true;
    const type     = directed ? 'digraph' : 'graph';
    const arrow    = directed ? '->' : '--';

    const lines = [`${type} ${name} {`];
    lines.push('  rankdir=LR;');

    for (const node of this._nodes) {
      lines.push(`  "${node}";`);
    }

    for (const [from, deps] of this._edges) {
      for (const to of deps) {
        lines.push(`  "${from}" ${arrow} "${to}";`);
      }
    }

    lines.push('}');
    return lines.join('\n');
  }

  // ─── Stats ────────────────────────────────────────────────────────────────────

  /**
   * @returns {{ nodes: number, edges: number, hasCycles: boolean }}
   */
  stats() {
    let edgeCount = 0;
    for (const deps of this._edges.values()) edgeCount += deps.size;
    return {
      nodes:     this._nodes.size,
      edges:     edgeCount,
      hasCycles: this.detectCycles().length > 0,
    };
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private Ensure node exists in both _nodes and _edges.
   * @param {string} node
   */
  _ensureNode(node) {
    this._nodes.add(node);
    if (!this._edges.has(node)) this._edges.set(node, new Set());
  }
}

// ─── Error Types ─────────────────────────────────────────────────────────────

/**
 * @class CycleError
 * @extends Error
 */
class CycleError extends Error {
  /**
   * @param {string} message
   * @param {object} [meta]
   */
  constructor(message, meta = {}) {
    super(message);
    this.name = 'CycleError';
    this.meta = meta;
  }
}

module.exports = { DependencyGraph, CycleError };
