/**
 * @file token-budget-allocator.js
 * @description LLM token budget allocator — distributes a finite token budget
 *              across multiple context sources using priority-based allocation
 *              with dynamic adjustment.
 *
 * Allocation strategy:
 *  1. Each source declares a priority and an ideal token count
 *  2. High-priority sources are allocated first up to their ideal
 *  3. Remaining budget is distributed proportionally to lower-priority sources
 *  4. PHI-scaled minimum floor ensures every source gets some representation
 *
 * PHI floor: each source gets at least floor(budget / (sources * PHI)) tokens
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const PHI = 1.6180339887;

/**
 * @typedef {object} ContextSource
 * @property {string}  id           - Source identifier
 * @property {number}  priority     - Allocation priority (higher = more tokens first); default 1
 * @property {number}  ideal        - Ideal token count requested
 * @property {number}  [minTokens]  - Hard minimum (overrides PHI floor if larger)
 * @property {number}  [maxTokens]  - Hard cap on this source's allocation
 * @property {*}       [data]       - Optional opaque data for the caller
 */

/**
 * @typedef {object} Allocation
 * @property {string}  id           - Source ID
 * @property {number}  allocated    - Tokens allocated
 * @property {number}  ideal        - Original ideal request
 * @property {number}  priority     - Source priority
 * @property {boolean} truncated    - Whether ideal was reduced
 * @property {number}  utilizationPct - allocated / ideal * 100
 */

/**
 * @class TokenBudgetAllocator
 *
 * @example
 * const allocator = new TokenBudgetAllocator({ totalBudget: 4096 });
 *
 * allocator.addSource({ id: 'system_prompt', priority: 10, ideal: 500, minTokens: 200 });
 * allocator.addSource({ id: 'recent_history', priority: 8,  ideal: 2000 });
 * allocator.addSource({ id: 'retrieved_docs', priority: 5,  ideal: 1500 });
 * allocator.addSource({ id: 'user_query',     priority: 10, ideal: 100, minTokens: 50 });
 *
 * const plan = allocator.allocate();
 * // { totalBudget: 4096, used: 4096, allocations: [...] }
 */
class TokenBudgetAllocator {
  /**
   * @param {object}  opts
   * @param {number}  opts.totalBudget             - Total token budget to distribute
   * @param {number}  [opts.reserveTokens=0]       - Tokens reserved for output / safety margin
   * @param {boolean} [opts.usePhiFloor=true]      - Enforce PHI-derived minimum token floor
   * @param {boolean} [opts.allowOverflow=false]   - Allow exceeding totalBudget (useful for dry-run)
   */
  constructor(opts) {
    if (!opts || !opts.totalBudget) {
      throw new TypeError('TokenBudgetAllocator: opts.totalBudget is required');
    }

    this.totalBudget    = opts.totalBudget;
    this.reserveTokens  = opts.reserveTokens  ?? 0;
    this.usePhiFloor    = opts.usePhiFloor    ?? true;
    this.allowOverflow  = opts.allowOverflow  ?? false;

    /** @type {Map<string, ContextSource>} */
    this._sources = new Map();
  }

  // ─── Source Management ───────────────────────────────────────────────────────

  /**
   * Register a context source.
   *
   * @param {ContextSource} source
   * @returns {this}
   */
  addSource(source) {
    if (!source.id) throw new TypeError('TokenBudgetAllocator.addSource: source.id is required');
    this._sources.set(source.id, {
      priority:  1,
      minTokens: 0,
      maxTokens: Infinity,
      ...source,
    });
    return this;
  }

  /**
   * Update a source's configuration.
   *
   * @param {string}        id
   * @param {Partial<ContextSource>} update
   * @returns {boolean}
   */
  updateSource(id, update) {
    const s = this._sources.get(id);
    if (!s) return false;
    Object.assign(s, update);
    return true;
  }

  /**
   * Remove a source.
   *
   * @param {string} id
   * @returns {boolean}
   */
  removeSource(id) {
    return this._sources.delete(id);
  }

  // ─── Allocation ──────────────────────────────────────────────────────────────

  /**
   * Compute token allocations for all registered sources.
   *
   * @param {object}  [opts]
   * @param {number}  [opts.budgetOverride]  - Temporarily use a different total budget
   * @returns {{
   *   totalBudget: number,
   *   availableBudget: number,
   *   used: number,
   *   remaining: number,
   *   allocations: Allocation[],
   *   summary: object,
   * }}
   */
  allocate(opts = {}) {
    const budget    = (opts.budgetOverride ?? this.totalBudget) - this.reserveTokens;
    const sources   = Array.from(this._sources.values());

    if (sources.length === 0) {
      return { totalBudget: this.totalBudget, availableBudget: budget, used: 0, remaining: budget, allocations: [], summary: {} };
    }

    // PHI floor per source
    const phiFloor = this.usePhiFloor
      ? Math.max(1, Math.floor(budget / (sources.length * PHI)))
      : 0;

    // Sort by priority descending
    const sorted = [...sources].sort((a, b) => b.priority - a.priority);

    /** @type {Map<string, number>} id → allocated */
    const allocated = new Map();
    let remaining   = budget;

    // Phase 1: guarantee minimums
    for (const s of sorted) {
      const floor = Math.max(phiFloor, s.minTokens ?? 0);
      const give  = Math.min(floor, s.maxTokens, remaining);
      allocated.set(s.id, Math.max(0, give));
      remaining -= Math.max(0, give);
    }

    // Phase 2: fill ideal allocations in priority order
    for (const s of sorted) {
      const current = allocated.get(s.id);
      const gap     = s.ideal - current;
      if (gap <= 0) continue;

      const additional = Math.min(gap, s.maxTokens - current, remaining);
      if (additional <= 0) continue;

      allocated.set(s.id, current + additional);
      remaining -= additional;
    }

    // Phase 3: distribute leftover proportionally to under-served sources
    if (remaining > 0) {
      const underServed = sorted.filter((s) => (allocated.get(s.id) ?? 0) < s.ideal);
      const totalShortfall = underServed.reduce((sum, s) => sum + (s.ideal - (allocated.get(s.id) ?? 0)), 0);

      if (totalShortfall > 0) {
        for (const s of underServed) {
          const shortfall = s.ideal - (allocated.get(s.id) ?? 0);
          const share     = Math.floor((shortfall / totalShortfall) * remaining);
          const capped    = Math.min(share, s.maxTokens - (allocated.get(s.id) ?? 0));
          if (capped > 0) {
            allocated.set(s.id, (allocated.get(s.id) ?? 0) + capped);
          }
        }
      }
    }

    // Build result
    const allocations = sorted.map((s) => {
      const alloc = allocated.get(s.id) ?? 0;
      return {
        id:             s.id,
        priority:       s.priority,
        ideal:          s.ideal,
        allocated:      alloc,
        truncated:      alloc < s.ideal,
        utilizationPct: s.ideal > 0 ? Math.round((alloc / s.ideal) * 100) : 100,
        data:           s.data ?? null,
      };
    });

    const used = allocations.reduce((sum, a) => sum + a.allocated, 0);

    return {
      totalBudget:     this.totalBudget,
      availableBudget: budget,
      used,
      remaining:       budget - used,
      allocations,
      summary: {
        sources:   sources.length,
        truncated: allocations.filter((a) => a.truncated).length,
        phiFloor,
      },
    };
  }

  /**
   * Dynamically adjust the total budget and re-allocate.
   *
   * @param {number} newBudget
   * @returns {object} New allocation plan
   */
  resize(newBudget) {
    this.totalBudget = newBudget;
    return this.allocate();
  }

  /**
   * Return stats without mutating state.
   *
   * @returns {{ sources: number, totalIdeal: number, budget: number }}
   */
  stats() {
    const sources   = Array.from(this._sources.values());
    const totalIdeal = sources.reduce((s, src) => s + src.ideal, 0);
    return {
      sources:    sources.length,
      totalIdeal,
      budget:     this.totalBudget - this.reserveTokens,
      pressure:   totalIdeal > 0 ? Math.round((this.totalBudget / totalIdeal) * 100) : 100,
    };
  }
}

module.exports = { TokenBudgetAllocator, PHI };
