/**
 * @file relevance-scorer.js
 * @description Content relevance scoring — TF-IDF-like scoring with recency
 *              weighting and source authority weighting.
 *
 * Score formula:
 *   score = tf_idf(query, document) * recency_weight(age) * authority_weight(source)
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 */

'use strict';

const PHI = 1.6180339887;

/** PHI^10 * 1000 ms — recency half-life (~122 s) */
const RECENCY_HALF_LIFE_MS = Math.round(Math.pow(PHI, 10) * 1000);

// ─── Tokenisation ────────────────────────────────────────────────────────────

/**
 * Basic tokeniser — lowercase, remove punctuation, split on whitespace.
 *
 * @param {string} text
 * @returns {string[]}
 */
function tokenise(text) {
  return String(text)
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
}

/**
 * Compute term frequency for a token in a token array.
 * TF = (occurrences of term) / (total tokens)
 *
 * @param {string}   term
 * @param {string[]} tokens
 * @returns {number}
 */
function tf(term, tokens) {
  if (tokens.length === 0) return 0;
  const count = tokens.filter((t) => t === term).length;
  return count / tokens.length;
}

/**
 * Compute inverse document frequency for a term across a corpus.
 * IDF = log(1 + N / (1 + df(term)))  — smoothed variant
 *
 * @param {string}     term
 * @param {string[][]} corpus - Array of token arrays
 * @returns {number}
 */
function idf(term, corpus) {
  if (corpus.length === 0) return 0;
  const df = corpus.filter((doc) => doc.includes(term)).length;
  return Math.log(1 + corpus.length / (1 + df));
}

/**
 * Compute TF-IDF score for a query against a document.
 *
 * @param {string[]} queryTokens
 * @param {string[]} docTokens
 * @param {string[][]} corpus - Background corpus for IDF
 * @returns {number}
 */
function tfIdf(queryTokens, docTokens, corpus) {
  let score = 0;
  for (const term of queryTokens) {
    score += tf(term, docTokens) * idf(term, corpus);
  }
  return score;
}

// ─── Weighting Functions ─────────────────────────────────────────────────────

/**
 * Recency weight: exponential decay based on document age.
 * weight = e^(-age / halfLife)  — gives 1.0 for brand-new content,
 * 0.5 at halfLife, approaching 0 for old content.
 *
 * @param {number} ageMs      - Document age in ms
 * @param {number} [halfLife] - Half-life in ms (default PHI^10*1000)
 * @returns {number} Weight in [0, 1]
 */
function recencyWeight(ageMs, halfLife = RECENCY_HALF_LIFE_MS) {
  return Math.exp(-ageMs / halfLife);
}

/**
 * Authority weight: maps a source name to a configurable authority score.
 * Defaults to 1.0 (neutral) for unknown sources.
 *
 * @param {string}         source       - Source identifier
 * @param {Map<string, number>} registry - Authority registry
 * @returns {number}
 */
function authorityWeight(source, registry) {
  return registry?.get(source) ?? 1.0;
}

// ─── Relevance Scorer ────────────────────────────────────────────────────────

/**
 * @typedef {object} ScoredDocument
 * @property {string} id        - Document identifier
 * @property {string} text      - Document text content
 * @property {number} [ts]      - Timestamp (ms) when document was created/indexed
 * @property {string} [source]  - Source identifier for authority weighting
 */

/**
 * @class RelevanceScorer
 *
 * @example
 * const scorer = new RelevanceScorer();
 * scorer.setAuthority('official_docs', 2.0);
 * scorer.setAuthority('user_notes', 0.7);
 *
 * const ranked = scorer.rank('how to configure rate limiting', documents);
 * // Returns documents sorted by combined relevance score
 */
class RelevanceScorer {
  /**
   * @param {object} [opts]
   * @param {number} [opts.recencyHalfLifeMs] - Recency decay half-life in ms
   * @param {number} [opts.recencyWeight]     - Multiplier for recency component (0–1; default 0.3)
   * @param {number} [opts.tfIdfWeight]       - Multiplier for TF-IDF component (default 0.7)
   * @param {boolean}[opts.useIdf=true]       - Use IDF across corpus (false for single-doc queries)
   */
  constructor(opts = {}) {
    this.recencyHalfLifeMs = opts.recencyHalfLifeMs ?? RECENCY_HALF_LIFE_MS;
    this._recencyW         = opts.recencyWeight     ?? 0.3;
    this._tfIdfW           = opts.tfIdfWeight       ?? 0.7;
    this.useIdf            = opts.useIdf            ?? true;

    /** @type {Map<string, number>} source → authority weight */
    this._authorities = new Map();
  }

  // ─── Authority Registry ──────────────────────────────────────────────────────

  /**
   * Set authority weight for a source.
   * Values > 1 boost relevance; < 1 suppresses it.
   *
   * @param {string} source
   * @param {number} weight
   */
  setAuthority(source, weight) {
    this._authorities.set(source, weight);
  }

  /**
   * Get authority weight for a source.
   *
   * @param {string} source
   * @returns {number}
   */
  getAuthority(source) {
    return this._authorities.get(source) ?? 1.0;
  }

  // ─── Scoring ─────────────────────────────────────────────────────────────────

  /**
   * Score a single document against a query.
   *
   * @param {string}          query
   * @param {ScoredDocument}  doc
   * @param {ScoredDocument[]}[corpus=[]] - Background corpus for IDF (defaults to [doc])
   * @returns {number} Combined relevance score
   */
  score(query, doc, corpus = []) {
    const queryTokens = tokenise(query);
    const docTokens   = tokenise(doc.text ?? '');
    const corpusTokens = this.useIdf && corpus.length > 0
      ? corpus.map((d) => tokenise(d.text ?? ''))
      : [docTokens];

    // TF-IDF component
    const tfidfScore = tfIdf(queryTokens, docTokens, corpusTokens);

    // Recency component
    const ageMs = doc.ts ? Date.now() - doc.ts : 0;
    const recency = recencyWeight(ageMs, this.recencyHalfLifeMs);

    // Authority component
    const authority = authorityWeight(doc.source ?? '', this._authorities);

    return (this._tfIdfW * tfidfScore + this._recencyW * recency) * authority;
  }

  /**
   * Rank an array of documents by relevance to a query.
   *
   * @param {string}           query
   * @param {ScoredDocument[]} docs
   * @returns {Array<ScoredDocument & { _score: number }>} Sorted highest-first
   */
  rank(query, docs) {
    const corpus = docs;
    return docs
      .map((doc) => ({ ...doc, _score: this.score(query, doc, corpus) }))
      .sort((a, b) => b._score - a._score);
  }

  /**
   * Return only documents above a minimum score threshold.
   *
   * @param {string}           query
   * @param {ScoredDocument[]} docs
   * @param {number}           [threshold=0.01]
   * @returns {Array<ScoredDocument & { _score: number }>}
   */
  filter(query, docs, threshold = 0.01) {
    return this.rank(query, docs).filter((d) => d._score >= threshold);
  }
}

module.exports = {
  RelevanceScorer,
  tokenise,
  tf,
  idf,
  tfIdf,
  recencyWeight,
  authorityWeight,
  RECENCY_HALF_LIFE_MS,
  PHI,
};
