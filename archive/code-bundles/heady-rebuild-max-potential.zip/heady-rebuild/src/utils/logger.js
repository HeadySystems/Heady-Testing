/**
 * @fileoverview Heady™ Systems — Structured JSON Logger
 * Sacred Geometry Log Engine | PHI-aware rotation hinting
 *
 * © 2026 HeadySystems Inc. All rights reserved.
 * CONFIDENTIAL — Proprietary multi-agent AI infrastructure.
 *
 * @module utils/logger
 * @version 3.1.0
 */

'use strict';

// ─── Sacred Geometry Constants ────────────────────────────────────────────────
const PHI = 1.6180339887;
const PHI_MS = Math.round(PHI * 1000); // 1618ms — golden tick interval

// ─── ANSI Color Palette ───────────────────────────────────────────────────────
const C = {
  reset:   '\x1b[0m',
  bold:    '\x1b[1m',
  dim:     '\x1b[2m',
  // Heady brand palette
  gold:    '\x1b[38;5;220m',   // PHI gold
  cyan:    '\x1b[38;5;51m',    // info
  yellow:  '\x1b[38;5;226m',   // warn
  red:     '\x1b[38;5;196m',   // error
  magenta: '\x1b[38;5;171m',   // system
  green:   '\x1b[38;5;46m',    // success
  gray:    '\x1b[38;5;244m',   // dim meta
};

// ─── Level Definitions ────────────────────────────────────────────────────────
const LEVELS = {
  debug:  { rank: 10, label: 'DEBUG',  color: C.gray    },
  info:   { rank: 20, label: 'INFO',   color: C.cyan    },
  warn:   { rank: 30, label: 'WARN',   color: C.yellow  },
  error:  { rank: 40, label: 'ERROR',  color: C.red     },
  system: { rank: 50, label: 'SYSTEM', color: C.magenta },
  fatal:  { rank: 60, label: 'FATAL',  color: C.bold + C.red },
};

/**
 * Format a timestamp ISO string with millisecond precision.
 * @returns {string}
 */
function ts() {
  return new Date().toISOString();
}

/**
 * Serialize a value safely to JSON without throwing.
 * Circular references are replaced with '[Circular]'.
 * @param {*} value
 * @returns {string}
 */
function safeJson(value) {
  const seen = new WeakSet();
  return JSON.stringify(value, (_key, val) => {
    if (typeof val === 'object' && val !== null) {
      if (seen.has(val)) return '[Circular]';
      seen.add(val);
    }
    return val;
  });
}

/**
 * Emit a log record to stdout (JSON in production, colorized in dev).
 * @param {string}  level   - Log level key
 * @param {string}  message - Human-readable message
 * @param {object}  [meta]  - Structured metadata fields
 * @param {string}  [ns]    - Namespace/child logger prefix
 */
function emit(level, message, meta = {}, ns = 'heady') {
  const def    = LEVELS[level] || LEVELS.info;
  const record = {
    ts:      ts(),
    level:   def.label,
    ns,
    msg:     message,
    pid:     process.pid,
    phi:     PHI,
    ...meta,
  };

  if (process.env.NODE_ENV === 'production' || process.env.LOG_FORMAT === 'json') {
    // Structured JSON — consumed by Cloud Logging / Datadog
    process.stdout.write(safeJson(record) + '\n');
  } else {
    // Colorized dev output
    const lvlTag  = `${def.color}${C.bold}[${def.label.padEnd(6)}]${C.reset}`;
    const nsTag   = `${C.gold}${ns}${C.reset}`;
    const timeTag = `${C.gray}${record.ts}${C.reset}`;
    const msgStr  = message;
    const metaStr = Object.keys(meta).length
      ? `  ${C.dim}${safeJson(meta)}${C.reset}`
      : '';
    process.stdout.write(`${timeTag} ${lvlTag} ${nsTag} ${msgStr}${metaStr}\n`);
  }
}

// ─── Logger Factory ───────────────────────────────────────────────────────────

/**
 * @class HeadyLogger
 * @description Structured logger with child namespacing and PHI rotation hints.
 */
class HeadyLogger {
  /**
   * @param {string} namespace - Logger namespace (e.g. 'heady:auth')
   * @param {object} [defaults={}] - Default metadata bound to all records
   */
  constructor(namespace = 'heady', defaults = {}) {
    this.ns       = namespace;
    this.defaults = defaults;
    // PHI-based rotation hint: rotate logs every PHI * 1h = ~1.618 hours
    this.rotationHintMs = Math.round(PHI * 3_600_000);
  }

  /**
   * Create a child logger with an extended namespace.
   * @param {string} suffix  - Appended to current namespace
   * @param {object} [extra] - Additional bound metadata
   * @returns {HeadyLogger}
   */
  child(suffix, extra = {}) {
    return new HeadyLogger(`${this.ns}:${suffix}`, { ...this.defaults, ...extra });
  }

  /**
   * Log a debug message.
   * @param {string} message
   * @param {object} [meta]
   */
  debug(message, meta = {}) {
    emit('debug', message, { ...this.defaults, ...meta }, this.ns);
  }

  /**
   * Log an informational message.
   * @param {string} message
   * @param {object} [meta]
   */
  info(message, meta = {}) {
    emit('info', message, { ...this.defaults, ...meta }, this.ns);
  }

  /**
   * Log a warning.
   * @param {string} message
   * @param {object} [meta]
   */
  warn(message, meta = {}) {
    emit('warn', message, { ...this.defaults, ...meta }, this.ns);
  }

  /**
   * Log an error with optional Error object serialization.
   * @param {string}        message
   * @param {Error|object}  [errOrMeta]
   */
  error(message, errOrMeta = {}) {
    const meta = errOrMeta instanceof Error
      ? { err: { message: errOrMeta.message, stack: errOrMeta.stack, name: errOrMeta.name } }
      : errOrMeta;
    emit('error', message, { ...this.defaults, ...meta }, this.ns);
  }

  /**
   * Log a system-level lifecycle event (bootstrap, shutdown, phase transitions).
   * @param {string} message
   * @param {object} [meta]
   */
  logSystem(message, meta = {}) {
    emit('system', message, { ...this.defaults, ...meta }, this.ns);
  }

  /**
   * Alias for logSystem — surface-level compatibility.
   * @param {string} message
   * @param {object} [meta]
   */
  logError(message, meta = {}) {
    this.error(message, meta);
  }

  /**
   * Log a fatal error and hint at process termination.
   * @param {string}       message
   * @param {Error|object} [errOrMeta]
   */
  fatal(message, errOrMeta = {}) {
    const meta = errOrMeta instanceof Error
      ? { err: { message: errOrMeta.message, stack: errOrMeta.stack, name: errOrMeta.name } }
      : errOrMeta;
    emit('fatal', message, { ...this.defaults, ...meta, fatal: true }, this.ns);
  }

  /**
   * Return PHI-based log rotation recommendation in milliseconds.
   * @returns {number}
   */
  rotationHint() {
    return this.rotationHintMs;
  }

  /**
   * Emit a structured timing metric.
   * @param {string} operation - Name of the timed operation
   * @param {number} durationMs - Duration in milliseconds
   * @param {object} [meta]
   */
  timing(operation, durationMs, meta = {}) {
    this.info(`⧖ ${operation}`, {
      ...this.defaults,
      ...meta,
      timing_ms:   durationMs,
      phi_ratio:   (durationMs / PHI_MS).toFixed(4),
      operation,
    });
  }
}

// ─── Root Logger Singleton ────────────────────────────────────────────────────

/** @type {HeadyLogger} Root logger instance */
const logger = new HeadyLogger('heady');

module.exports = logger;
module.exports.HeadyLogger = HeadyLogger;
module.exports.PHI_MS = PHI_MS;
