# =============================================================================
# Heady™ Systems — Terraform Infrastructure (Google Cloud Platform)
# Version: 2.0.0
# Provider: google 5.x
# =============================================================================

terraform {
  required_version = ">= 1.7.0"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
    google-beta = {
      source  = "hashicorp/google-beta"
      version = "~> 5.0"
    }
  }

  # Uncomment to use GCS backend for team state management
  # backend "gcs" {
  #   bucket  = "heady-terraform-state"
  #   prefix  = "heady-rebuild/state"
  # }
}

# ─────────────────────────────────────────────────────────────────────────────
# Variables
# ─────────────────────────────────────────────────────────────────────────────
variable "project_id" {
  description = "Google Cloud Project ID"
  type        = string
}

variable "region" {
  description = "Primary GCP region"
  type        = string
  default     = "us-central1"
}

variable "image_tag" {
  description = "Docker image tag to deploy"
  type        = string
  default     = "latest"
}

variable "min_instances" {
  description = "Minimum Cloud Run instances (0 = scale to zero)"
  type        = number
  default     = 1
}

variable "max_instances" {
  description = "Maximum Cloud Run instances"
  type        = number
  default     = 20
}

variable "memory_limit" {
  description = "Cloud Run memory limit"
  type        = string
  default     = "2Gi"
}

variable "cpu_limit" {
  description = "Cloud Run CPU limit"
  type        = string
  default     = "2"
}

# ─────────────────────────────────────────────────────────────────────────────
# Provider Configuration
# ─────────────────────────────────────────────────────────────────────────────
provider "google" {
  project = var.project_id
  region  = var.region
}

provider "google-beta" {
  project = var.project_id
  region  = var.region
}

# ─────────────────────────────────────────────────────────────────────────────
# Local Values
# ─────────────────────────────────────────────────────────────────────────────
locals {
  image_name   = "${var.region}-docker.pkg.dev/${var.project_id}/heady-images/heady-manager"
  image_uri    = "${local.image_name}:${var.image_tag}"
  service_name = "heady-manager"

  common_labels = {
    app         = "heady-systems"
    managed-by  = "terraform"
    environment = "production"
    team        = "headysystems"
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# Artifact Registry Repository
# ─────────────────────────────────────────────────────────────────────────────
resource "google_artifact_registry_repository" "heady_images" {
  provider      = google
  location      = var.region
  repository_id = "heady-images"
  description   = "Heady™ Systems Docker container images"
  format        = "DOCKER"

  cleanup_policies {
    id     = "keep-minimum-versions"
    action = "KEEP"
    most_recent_versions {
      keep_count = 10
    }
  }

  cleanup_policies {
    id     = "delete-old-untagged"
    action = "DELETE"
    condition {
      tag_state     = "UNTAGGED"
      older_than    = "168h"  # 7 days
    }
  }

  labels = local.common_labels
}

# ─────────────────────────────────────────────────────────────────────────────
# Service Account — heady-manager (minimal permissions)
# ─────────────────────────────────────────────────────────────────────────────
resource "google_service_account" "heady_manager" {
  account_id   = "heady-manager"
  display_name = "Heady Manager Service Account"
  description  = "Service account for heady-manager Cloud Run service. Minimal permissions."
  project      = var.project_id
}

# Allow heady-manager SA to read secrets
resource "google_project_iam_member" "heady_manager_secret_accessor" {
  project = var.project_id
  role    = "roles/secretmanager.secretAccessor"
  member  = "serviceAccount:${google_service_account.heady_manager.email}"
}

# Allow heady-manager SA to write to Cloud Storage (checkpoints, audit)
resource "google_project_iam_member" "heady_manager_storage_writer" {
  project = var.project_id
  role    = "roles/storage.objectCreator"
  member  = "serviceAccount:${google_service_account.heady_manager.email}"
}

# Allow heady-manager SA to read from Cloud Storage
resource "google_project_iam_member" "heady_manager_storage_reader" {
  project = var.project_id
  role    = "roles/storage.objectViewer"
  member  = "serviceAccount:${google_service_account.heady_manager.email}"
}

# Allow heady-manager SA to publish to Pub/Sub
resource "google_project_iam_member" "heady_manager_pubsub_publisher" {
  project = var.project_id
  role    = "roles/pubsub.publisher"
  member  = "serviceAccount:${google_service_account.heady_manager.email}"
}

# Allow heady-manager SA to subscribe to Pub/Sub
resource "google_project_iam_member" "heady_manager_pubsub_subscriber" {
  project = var.project_id
  role    = "roles/pubsub.subscriber"
  member  = "serviceAccount:${google_service_account.heady_manager.email}"
}

# Allow heady-manager SA to write logs
resource "google_project_iam_member" "heady_manager_log_writer" {
  project = var.project_id
  role    = "roles/logging.logWriter"
  member  = "serviceAccount:${google_service_account.heady_manager.email}"
}

# Allow heady-manager SA to write metrics
resource "google_project_iam_member" "heady_manager_metric_writer" {
  project = var.project_id
  role    = "roles/monitoring.metricWriter"
  member  = "serviceAccount:${google_service_account.heady_manager.email}"
}

# ─────────────────────────────────────────────────────────────────────────────
# Cloud Storage Bucket — Checkpoints and Audit
# ─────────────────────────────────────────────────────────────────────────────
resource "google_storage_bucket" "heady_data" {
  name          = "${var.project_id}-heady-data"
  location      = var.region
  force_destroy = false

  uniform_bucket_level_access = true

  versioning {
    enabled = true
  }

  lifecycle_rule {
    condition {
      age = 365
      with_state = "ARCHIVED"
    }
    action {
      type          = "SetStorageClass"
      storage_class = "COLDLINE"
    }
  }

  lifecycle_rule {
    condition {
      age                   = 2555  # 7 years for governance records
      matches_prefix        = ["audit/"]
    }
    action {
      type = "Delete"
    }
  }

  labels = local.common_labels
}

# ─────────────────────────────────────────────────────────────────────────────
# Pub/Sub Topics — Swarm Task Messaging
# ─────────────────────────────────────────────────────────────────────────────
resource "google_pubsub_topic" "swarm_tasks" {
  name    = "heady-swarm-tasks"
  project = var.project_id

  message_retention_duration = "86400s"  # 24 hours

  labels = local.common_labels
}

resource "google_pubsub_subscription" "swarm_tasks_sub" {
  name    = "heady-swarm-tasks-sub"
  topic   = google_pubsub_topic.swarm_tasks.name
  project = var.project_id

  ack_deadline_seconds = 60
  
  retry_policy {
    minimum_backoff = "10s"
    maximum_backoff = "600s"
  }

  expiration_policy {
    ttl = "86400s"
  }

  labels = local.common_labels
}

resource "google_pubsub_topic" "pipeline_events" {
  name    = "heady-pipeline-events"
  project = var.project_id

  message_retention_duration = "86400s"

  labels = local.common_labels
}

resource "google_pubsub_subscription" "pipeline_events_sub" {
  name    = "heady-pipeline-events-sub"
  topic   = google_pubsub_topic.pipeline_events.name
  project = var.project_id

  ack_deadline_seconds = 30

  labels = local.common_labels
}

resource "google_pubsub_topic" "governance_events" {
  name    = "heady-governance-events"
  project = var.project_id

  message_retention_duration = "604800s"  # 7 days for governance

  labels = local.common_labels
}

# ─────────────────────────────────────────────────────────────────────────────
# Secret Manager Secrets (values managed externally)
# ─────────────────────────────────────────────────────────────────────────────
resource "google_secret_manager_secret" "llm_api_key" {
  secret_id = "heady-llm-api-key"
  project   = var.project_id

  replication {
    auto {}
  }

  labels = local.common_labels
}

resource "google_secret_manager_secret" "embedding_api_key" {
  secret_id = "heady-embedding-api-key"
  project   = var.project_id

  replication {
    auto {}
  }

  labels = local.common_labels
}

resource "google_secret_manager_secret" "internal_token" {
  secret_id = "heady-internal-token"
  project   = var.project_id

  replication {
    auto {}
  }

  labels = local.common_labels
}

# ─────────────────────────────────────────────────────────────────────────────
# Cloud Run Service — heady-manager
# ─────────────────────────────────────────────────────────────────────────────
resource "google_cloud_run_v2_service" "heady_manager" {
  provider = google-beta
  name     = local.service_name
  location = var.region
  project  = var.project_id

  deletion_protection = false

  ingress = "INGRESS_TRAFFIC_ALL"

  labels = local.common_labels

  template {
    service_account = google_service_account.heady_manager.email

    labels = local.common_labels

    annotations = {
      "autoscaling.knative.dev/minScale" = tostring(var.min_instances)
      "autoscaling.knative.dev/maxScale" = tostring(var.max_instances)
    }

    scaling {
      min_instance_count = var.min_instances
      max_instance_count = var.max_instances
    }

    containers {
      image = local.image_uri
      name  = "heady-manager"

      ports {
        container_port = 8080
        name           = "http1"
      }

      resources {
        limits = {
          memory = var.memory_limit
          cpu    = var.cpu_limit
        }
        cpu_idle          = false  # Keep CPU allocated between requests
        startup_cpu_boost = true   # Extra CPU on cold start
      }

      # Environment variables (non-secret)
      env {
        name  = "PORT"
        value = "8080"
      }
      env {
        name  = "NODE_ENV"
        value = "production"
      }
      env {
        name  = "DATA_DIR"
        value = "/data"
      }
      env {
        name  = "PIPELINE_CONFIG_PATH"
        value = "configs/pipeline/hcfullpipeline.yaml"
      }
      env {
        name  = "CHECKPOINT_STORAGE"
        value = "gcs"
      }
      env {
        name  = "GCS_BUCKET"
        value = google_storage_bucket.heady_data.name
      }
      env {
        name  = "GOOGLE_CLOUD_PROJECT"
        value = var.project_id
      }
      env {
        name  = "PUBSUB_SWARM_TASKS_TOPIC"
        value = google_pubsub_topic.swarm_tasks.id
      }
      env {
        name  = "PUBSUB_PIPELINE_EVENTS_TOPIC"
        value = google_pubsub_topic.pipeline_events.id
      }
      env {
        name  = "RING_BUFFER_SIZE"
        value = "500"
      }
      env {
        name  = "LOG_LEVEL"
        value = "info"
      }

      # Secret environment variables
      env {
        name = "LLM_API_KEY"
        value_source {
          secret_key_ref {
            secret  = google_secret_manager_secret.llm_api_key.secret_id
            version = "latest"
          }
        }
      }
      env {
        name = "EMBEDDING_API_KEY"
        value_source {
          secret_key_ref {
            secret  = google_secret_manager_secret.embedding_api_key.secret_id
            version = "latest"
          }
        }
      }
      env {
        name = "INTERNAL_TOKEN"
        value_source {
          secret_key_ref {
            secret  = google_secret_manager_secret.internal_token.secret_id
            version = "latest"
          }
        }
      }

      # Startup probe
      startup_probe {
        http_get {
          path = "/health"
          port = 8080
        }
        initial_delay_seconds = 10
        timeout_seconds       = 5
        period_seconds        = 10
        failure_threshold     = 6
      }

      # Liveness probe
      liveness_probe {
        http_get {
          path = "/health"
          port = 8080
        }
        initial_delay_seconds = 30
        timeout_seconds       = 5
        period_seconds        = 30
        failure_threshold     = 3
      }
    }
  }

  depends_on = [
    google_artifact_registry_repository.heady_images,
    google_project_iam_member.heady_manager_secret_accessor,
    google_project_iam_member.heady_manager_storage_writer,
    google_project_iam_member.heady_manager_log_writer,
  ]
}

# Allow unauthenticated invocations (public API)
resource "google_cloud_run_v2_service_iam_member" "heady_manager_public" {
  project  = var.project_id
  location = var.region
  name     = google_cloud_run_v2_service.heady_manager.name
  role     = "roles/run.invoker"
  member   = "allUsers"
}

# ─────────────────────────────────────────────────────────────────────────────
# Outputs
# ─────────────────────────────────────────────────────────────────────────────
output "heady_manager_url" {
  description = "Cloud Run service URL for heady-manager"
  value       = google_cloud_run_v2_service.heady_manager.uri
}

output "artifact_registry_url" {
  description = "Artifact Registry URL for Docker images"
  value       = "${var.region}-docker.pkg.dev/${var.project_id}/${google_artifact_registry_repository.heady_images.repository_id}"
}

output "heady_data_bucket" {
  description = "GCS bucket for checkpoints and audit data"
  value       = google_storage_bucket.heady_data.name
}

output "service_account_email" {
  description = "Service account email for heady-manager"
  value       = google_service_account.heady_manager.email
}

output "swarm_tasks_topic" {
  description = "Pub/Sub topic for swarm task dispatch"
  value       = google_pubsub_topic.swarm_tasks.id
}
