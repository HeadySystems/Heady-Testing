#!/usr/bin/env node
// =============================================================================
// Heady™ Systems — One-Command Zero-Friction Deploy Script
// Version: 2.0.0
// Usage: node scripts/deploy.js [options]
// =============================================================================

import { execSync, spawn } from 'child_process';
import { readFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

// ─────────────────────────────────────────────────────────────────────────────
// Color helpers
// ─────────────────────────────────────────────────────────────────────────────
const c = {
  reset:  '\x1b[0m',
  bold:   '\x1b[1m',
  dim:    '\x1b[2m',
  green:  '\x1b[32m',
  yellow: '\x1b[33m',
  red:    '\x1b[31m',
  blue:   '\x1b[34m',
  cyan:   '\x1b[36m',
  magenta:'\x1b[35m',
};

const log = {
  info:    (msg) => console.log(`${c.cyan}ℹ${c.reset}  ${msg}`),
  success: (msg) => console.log(`${c.green}✓${c.reset}  ${msg}`),
  warn:    (msg) => console.log(`${c.yellow}⚠${c.reset}  ${msg}`),
  error:   (msg) => console.error(`${c.red}✗${c.reset}  ${msg}`),
  step:    (msg) => console.log(`\n${c.bold}${c.blue}▶${c.reset}  ${c.bold}${msg}${c.reset}`),
  banner:  (msg) => console.log(`\n${c.magenta}${c.bold}${msg}${c.reset}\n`),
};

// ─────────────────────────────────────────────────────────────────────────────
// Parse CLI arguments
// ─────────────────────────────────────────────────────────────────────────────
function parseArgs() {
  const args = process.argv.slice(2);
  return {
    target: getArg(args, '--target') || 'cloud-run',
    // Options: cloud-run | render | cloudflare | huggingface | git | all
    skipBuild: args.includes('--skip-build'),
    skipTests: args.includes('--skip-tests'),
    healthCheck: args.includes('--health-check'),
    brandCheck: args.includes('--brand-check'),
    dryRun: args.includes('--dry-run'),
    tag: getArg(args, '--tag') || `${gitShortHash()}-${Date.now()}`,
    help: args.includes('--help') || args.includes('-h'),
  };
}

function getArg(args, flag) {
  const idx = args.indexOf(flag);
  return idx !== -1 && idx + 1 < args.length ? args[idx + 1] : null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Utilities
// ─────────────────────────────────────────────────────────────────────────────
function exec(cmd, options = {}) {
  const { silent = false, dryRun = false } = options;
  if (!silent) log.info(`$ ${c.dim}${cmd}${c.reset}`);
  if (dryRun) return '';
  return execSync(cmd, { cwd: ROOT, stdio: silent ? 'pipe' : 'inherit', encoding: 'utf8' });
}

function execAsync(cmd, args, options = {}) {
  return new Promise((resolve, reject) => {
    const proc = spawn(cmd, args, { cwd: ROOT, stdio: 'inherit', ...options });
    proc.on('exit', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`${cmd} exited with code ${code}`));
    });
  });
}

function gitShortHash() {
  try {
    return execSync('git rev-parse --short HEAD', { cwd: ROOT, encoding: 'utf8' }).trim();
  } catch {
    return 'unknown';
  }
}

function loadEnv() {
  const envPath = join(ROOT, '.env');
  if (!existsSync(envPath)) {
    log.warn('.env file not found — using process environment only');
    return;
  }
  const lines = readFileSync(envPath, 'utf8').split('\n');
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const [key, ...valParts] = trimmed.split('=');
    const val = valParts.join('=').trim().replace(/^["']|["']$/g, '');
    if (key && !process.env[key]) process.env[key] = val;
  }
}

function requireEnv(...vars) {
  const missing = vars.filter((v) => !process.env[v]);
  if (missing.length > 0) {
    log.error(`Missing required environment variables: ${missing.join(', ')}`);
    process.exit(1);
  }
}

async function healthCheck(url, maxRetries = 10, delayMs = 3000) {
  log.step(`Health Check: ${url}`);
  for (let i = 1; i <= maxRetries; i++) {
    try {
      const response = await fetch(`${url}/health`);
      if (response.ok) {
        const data = await response.json();
        log.success(`Health check passed (attempt ${i}/${maxRetries})`);
        log.info(`Status: ${data.status}, Health Score: ${data.healthScore}`);
        return true;
      }
      log.warn(`Health check returned ${response.status} (attempt ${i}/${maxRetries})`);
    } catch (e) {
      log.warn(`Health check failed: ${e.message} (attempt ${i}/${maxRetries})`);
    }
    if (i < maxRetries) await new Promise((r) => setTimeout(r, delayMs));
  }
  log.error(`Health check failed after ${maxRetries} attempts`);
  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// Deploy Targets
// ─────────────────────────────────────────────────────────────────────────────

async function deployGit(opts) {
  log.step('Git Deploy — Commit & Push to Trigger CI/CD');
  const { dryRun } = opts;

  exec('git add -A', { dryRun });
  
  const timestamp = new Date().toISOString();
  const commitMsg = `chore: deploy ${opts.tag} [${timestamp}]`;
  exec(`git commit -m "${commitMsg}" --allow-empty`, { dryRun });
  exec('git push origin HEAD', { dryRun });
  
  log.success('Pushed to GitHub — CI/CD pipeline triggered');
  log.info('Monitor CI: https://github.com/headysystems/heady-rebuild/actions');
}

async function deployCloudRun(opts) {
  log.step('Google Cloud Run Deploy');
  requireEnv('GOOGLE_CLOUD_PROJECT', 'GOOGLE_CLOUD_REGION', 'ARTIFACT_REGISTRY_HOST', 'ARTIFACT_REGISTRY_REPO');

  const { project, region, registry, repo, tag, dryRun, skipBuild } = {
    project:  process.env.GOOGLE_CLOUD_PROJECT,
    region:   process.env.GOOGLE_CLOUD_REGION || 'us-central1',
    registry: process.env.ARTIFACT_REGISTRY_HOST,
    repo:     process.env.ARTIFACT_REGISTRY_REPO || 'heady-images',
    tag:      opts.tag,
    dryRun:   opts.dryRun,
    skipBuild: opts.skipBuild,
  };

  const imageUri = `${registry}/${project}/${repo}/heady-manager:${tag}`;

  if (!skipBuild) {
    log.step('Building Docker Image');
    exec(`docker build -t ${imageUri} --build-arg NODE_ENV=production .`, { dryRun });

    log.step('Pushing to Artifact Registry');
    exec(`gcloud auth configure-docker ${registry} --quiet`, { dryRun });
    exec(`docker push ${imageUri}`, { dryRun });
  } else {
    log.warn('Skipping build — using existing image in registry');
  }

  log.step('Deploying to Cloud Run');
  exec([
    'gcloud run deploy heady-manager',
    `--image ${imageUri}`,
    `--platform managed`,
    `--region ${region}`,
    `--project ${project}`,
    '--port 8080',
    '--min-instances 1',
    '--max-instances 20',
    '--memory 2Gi',
    '--cpu 2',
    '--timeout 300',
    '--concurrency 1000',
    '--set-env-vars NODE_ENV=production',
    '--quiet',
  ].join(' '), { dryRun });

  // Get service URL
  const serviceUrl = exec(
    `gcloud run services describe heady-manager --region ${region} --project ${project} --format 'value(status.url)'`,
    { silent: true, dryRun }
  )?.trim();

  if (serviceUrl) {
    log.success(`Deployed to Cloud Run: ${serviceUrl}`);
    if (opts.healthCheck) await healthCheck(serviceUrl);
  }

  return serviceUrl;
}

async function deployRender(opts) {
  log.step('Render.com Deploy');
  requireEnv('RENDER_DEPLOY_HOOK');

  const hookUrl = process.env.RENDER_DEPLOY_HOOK;
  
  log.info(`Triggering Render deploy hook...`);
  if (!opts.dryRun) {
    const response = await fetch(hookUrl, { method: 'POST' });
    if (response.ok) {
      log.success('Render deploy triggered');
      log.info('Monitor: https://dashboard.render.com/');
    } else {
      throw new Error(`Render deploy hook returned ${response.status}`);
    }
  } else {
    log.info(`[DRY RUN] Would POST to: ${hookUrl}`);
  }
}

async function deployCloudflare(opts) {
  log.step('Cloudflare Workers Deploy');
  requireEnv('CLOUDFLARE_ACCOUNT_ID', 'CLOUDFLARE_API_TOKEN');

  const workers = [
    { name: 'heady-edge', dir: 'workers/heady-edge' },
    { name: 'heady-brand', dir: 'workers/heady-brand' },
  ];

  for (const worker of workers) {
    const workerDir = join(ROOT, worker.dir);
    if (!existsSync(workerDir)) {
      log.warn(`Worker directory not found: ${worker.dir} — skipping`);
      continue;
    }
    log.info(`Deploying worker: ${worker.name}`);
    exec(`wrangler deploy`, { dryRun: opts.dryRun });
  }
  
  log.success('Cloudflare Workers deployed');
}

async function deployHuggingFace(opts) {
  log.step('HuggingFace Spaces Deploy');
  requireEnv('HUGGINGFACE_TOKEN', 'HUGGINGFACE_SPACE');

  const space = process.env.HUGGINGFACE_SPACE;
  log.info(`Pushing to HuggingFace Space: ${space}`);

  if (!opts.dryRun) {
    // Push to HF Spaces git remote
    exec(`git remote get-url huggingface 2>/dev/null || git remote add huggingface https://huggingface.co/spaces/${space}`, {
      dryRun: false,
    });
    exec(`git push huggingface HEAD:main`, { dryRun: false });
    log.success(`HuggingFace Space updated: https://huggingface.co/spaces/${space}`);
  } else {
    log.info(`[DRY RUN] Would push to HuggingFace Space: ${space}`);
  }
}

async function runBrandCheck() {
  log.step('Brand Compliance Check');
  const domains = [
    'headysystems.com',
    'headyconnection.org',
    'headymcp.com',
    'headyio.com',
    'headybuddy.org',
  ];

  let passed = 0;
  let failed = 0;

  for (const domain of domains) {
    try {
      const response = await fetch(`https://${domain}/health`, {
        signal: AbortSignal.timeout(5000),
      });
      const hasEdgeHeader = response.headers.get('x-heady-edge');
      const hasServeHeader = response.headers.get('x-heady-serve');

      if (hasEdgeHeader && hasServeHeader) {
        log.success(`${domain}: brand headers present ✓`);
        passed++;
      } else {
        log.warn(`${domain}: missing headers — edge:${hasEdgeHeader ? '✓' : '✗'} serve:${hasServeHeader ? '✓' : '✗'}`);
        failed++;
      }
    } catch (e) {
      log.warn(`${domain}: unreachable (${e.message})`);
    }
  }

  log.info(`Brand check complete: ${passed}/${passed + failed} domains passing`);
  return failed === 0;
}

// ─────────────────────────────────────────────────────────────────────────────
// Main
// ─────────────────────────────────────────────────────────────────────────────
function printHelp() {
  console.log(`
${c.bold}Heady™ Systems Deploy Script${c.reset}
${c.dim}Made with Love by HeadySystems & HeadyConnection Team${c.reset}

${c.bold}Usage:${c.reset}
  node scripts/deploy.js [options]

${c.bold}Options:${c.reset}
  --target <target>    Deploy target (default: cloud-run)
                       Options: cloud-run | render | cloudflare | huggingface | git | all
  --tag <tag>          Image tag to deploy (default: git-hash-timestamp)
  --skip-build         Skip Docker build, use existing image
  --skip-tests         Skip test suite before deploy
  --health-check       Run health check after deploy
  --brand-check        Run brand compliance check after deploy
  --dry-run            Print commands without executing
  --help, -h           Show this help

${c.bold}Examples:${c.reset}
  node scripts/deploy.js
  node scripts/deploy.js --target cloud-run --health-check
  node scripts/deploy.js --target all --skip-tests
  node scripts/deploy.js --target git
  node scripts/deploy.js --dry-run --target cloud-run
`);
}

async function main() {
  log.banner('🐝 Heady™ Systems Deploy');
  
  loadEnv();
  const opts = parseArgs();

  if (opts.help) {
    printHelp();
    process.exit(0);
  }

  log.info(`Target: ${c.bold}${opts.target}${c.reset}`);
  log.info(`Tag: ${c.bold}${opts.tag}${c.reset}`);
  if (opts.dryRun) log.warn('DRY RUN — no changes will be made');

  // Run tests unless skipped
  if (!opts.skipTests) {
    log.step('Running Tests');
    exec('npm test -- --passWithNoTests', { dryRun: opts.dryRun });
    log.success('All tests passed');
  }

  const targets = opts.target === 'all'
    ? ['git', 'cloud-run', 'render', 'cloudflare']
    : [opts.target];

  for (const target of targets) {
    switch (target) {
      case 'git':
        await deployGit(opts);
        break;
      case 'cloud-run':
        await deployCloudRun(opts);
        break;
      case 'render':
        await deployRender(opts);
        break;
      case 'cloudflare':
        await deployCloudflare(opts);
        break;
      case 'huggingface':
        await deployHuggingFace(opts);
        break;
      default:
        log.error(`Unknown deploy target: ${target}`);
        process.exit(1);
    }
  }

  // Post-deploy checks
  if (opts.brandCheck) await runBrandCheck();

  log.banner('✓ Deploy Complete — Made with Love by HeadySystems');
}

main().catch((err) => {
  log.error(err.message);
  process.exit(1);
});
