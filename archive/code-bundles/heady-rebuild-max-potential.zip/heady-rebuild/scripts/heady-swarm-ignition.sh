#!/usr/bin/env bash
# =============================================================================
# Heady™ Systems — Swarm Ignition Script
# Version: 2.0.0
# Description: Bootstrap the full Heady™ swarm — verify dependencies,
#              initialize vector memory, spawn supervisors, run health checks,
#              and start the self-awareness loop.
# Usage: ./scripts/heady-swarm-ignition.sh [--skip-checks] [--dev]
# =============================================================================

set -euo pipefail
IFS=$'\n\t'

# ─────────────────────────────────────────────────────────────────────────────
# Color helpers
# ─────────────────────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

log_info()    { echo -e "${CYAN}ℹ${RESET}  $1"; }
log_success() { echo -e "${GREEN}✓${RESET}  $1"; }
log_warn()    { echo -e "${YELLOW}⚠${RESET}  $1"; }
log_error()   { echo -e "${RED}✗${RESET}  $1"; }
log_step()    { echo -e "\n${BOLD}${BLUE}▶${RESET}  ${BOLD}$1${RESET}"; }
log_banner()  { echo -e "\n${MAGENTA}${BOLD}$1${RESET}\n"; }

# ─────────────────────────────────────────────────────────────────────────────
# Script config
# ─────────────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
ENV_FILE="$ROOT_DIR/.env"
DATA_DIR="${DATA_DIR:-$ROOT_DIR/data}"
HEADY_API_URL="${HEADY_API_URL:-http://localhost:8080}"
SKIP_CHECKS=false
DEV_MODE=false

# Parse args
for arg in "$@"; do
  case $arg in
    --skip-checks) SKIP_CHECKS=true ;;
    --dev)         DEV_MODE=true ;;
    --help|-h)
      echo "Usage: $0 [--skip-checks] [--dev] [--help]"
      echo ""
      echo "  --skip-checks  Skip dependency verification"
      echo "  --dev          Development mode (relaxed checks)"
      exit 0
      ;;
    *) log_warn "Unknown argument: $arg" ;;
  esac
done

# ─────────────────────────────────────────────────────────────────────────────
# Load environment
# ─────────────────────────────────────────────────────────────────────────────
load_env() {
  if [[ -f "$ENV_FILE" ]]; then
    log_info "Loading .env from $ENV_FILE"
    set -a
    # shellcheck disable=SC1090
    source "$ENV_FILE"
    set +a
    log_success "Environment loaded"
  else
    log_warn ".env file not found — using system environment"
  fi
}

# ─────────────────────────────────────────────────────────────────────────────
# Step 1: Verify all dependencies
# ─────────────────────────────────────────────────────────────────────────────
verify_dependencies() {
  log_step "Verifying Dependencies"

  local deps_ok=true

  # Node.js
  if command -v node &>/dev/null; then
    local node_version
    node_version=$(node --version | cut -c2-)
    local node_major
    node_major=$(echo "$node_version" | cut -d. -f1)
    if [[ "$node_major" -ge 20 ]]; then
      log_success "Node.js ${node_version} ✓"
    else
      log_error "Node.js 20+ required, found ${node_version}"
      deps_ok=false
    fi
  else
    log_error "Node.js not found"
    deps_ok=false
  fi

  # npm
  if command -v npm &>/dev/null; then
    log_success "npm $(npm --version) ✓"
  else
    log_error "npm not found"
    deps_ok=false
  fi

  # Docker
  if command -v docker &>/dev/null; then
    log_success "Docker $(docker --version | cut -d' ' -f3 | tr -d ',') ✓"
  else
    log_warn "Docker not found — container deploy disabled"
  fi

  # Docker Compose
  if docker compose version &>/dev/null 2>&1; then
    log_success "Docker Compose $(docker compose version --short) ✓"
  else
    log_warn "Docker Compose not found — local compose disabled"
  fi

  # curl
  if command -v curl &>/dev/null; then
    log_success "curl $(curl --version | head -1 | cut -d' ' -f2) ✓"
  else
    log_error "curl not found (required for health checks)"
    deps_ok=false
  fi

  # jq (optional)
  if command -v jq &>/dev/null; then
    log_success "jq $(jq --version) ✓"
  else
    log_warn "jq not found — JSON parsing will be limited"
  fi

  # gcloud (optional)
  if command -v gcloud &>/dev/null; then
    log_success "gcloud $(gcloud --version | head -1 | cut -d' ' -f4) ✓"
  else
    log_warn "gcloud CLI not found — Cloud Run deploy disabled"
  fi

  if [[ "$deps_ok" == false ]]; then
    log_error "Required dependencies missing. Install them and retry."
    exit 1
  fi

  log_success "All required dependencies verified"
}

# ─────────────────────────────────────────────────────────────────────────────
# Step 2: Validate configuration files
# ─────────────────────────────────────────────────────────────────────────────
validate_configs() {
  log_step "Validating Configuration Files"

  local configs=(
    "configs/pipeline/hcfullpipeline.yaml"
    "configs/pipeline/resource-policies.yaml"
    "configs/pipeline/governance-policies.yaml"
    "configs/services/service-catalog.yaml"
    "configs/agent-profiles/HeadySwarmMatrix.json"
    "configs/domains/domain-mappings.yaml"
    "configs/observability/system-self-awareness.yaml"
    "configs/branding/brand-standards.yaml"
  )

  local all_ok=true

  for config in "${configs[@]}"; do
    local config_path="$ROOT_DIR/$config"
    if [[ -f "$config_path" ]]; then
      # Validate YAML syntax using node (if yq not available)
      if [[ "$config" == *.yaml ]] || [[ "$config" == *.yml ]]; then
        if node -e "
          const yaml = require('js-yaml');
          const fs = require('fs');
          try {
            yaml.load(fs.readFileSync('$config_path', 'utf8'));
            process.exit(0);
          } catch(e) {
            console.error(e.message);
            process.exit(1);
          }
        " 2>/dev/null; then
          log_success "$config ✓"
        else
          log_error "$config — YAML syntax error"
          all_ok=false
        fi
      elif [[ "$config" == *.json ]]; then
        if node -e "JSON.parse(require('fs').readFileSync('$config_path', 'utf8'))" 2>/dev/null; then
          log_success "$config ✓"
        else
          log_error "$config — JSON syntax error"
          all_ok=false
        fi
      fi
    else
      log_error "$config — file not found"
      all_ok=false
    fi
  done

  if [[ "$all_ok" == false ]]; then
    log_error "Configuration validation failed. Fix errors before proceeding."
    exit 1
  fi

  log_success "All configuration files valid"
}

# ─────────────────────────────────────────────────────────────────────────────
# Step 3: Initialize vector memory shards
# ─────────────────────────────────────────────────────────────────────────────
init_vector_memory() {
  log_step "Initializing Vector Memory Shards"

  local shard_count="${SHARD_COUNT:-16}"
  local vector_dir="$DATA_DIR/vector-shards"
  local baseline_dir="$DATA_DIR/drift-baselines"
  local telemetry_dir="$DATA_DIR/telemetry"
  local audit_dir="$DATA_DIR/audit"
  local checkpoint_dir="$DATA_DIR/checkpoints"

  # Create data directories
  local dirs=("$vector_dir" "$baseline_dir" "$telemetry_dir" "$audit_dir" "$checkpoint_dir")
  for dir in "${dirs[@]}"; do
    mkdir -p "$dir"
    log_info "Created: $dir"
  done

  # Initialize shard directories
  local pools=("hot" "warm" "cold" "reserve" "governance")
  for pool in "${pools[@]}"; do
    mkdir -p "$vector_dir/$pool"
    # Create shard subdirectories
    for i in $(seq 1 "$shard_count"); do
      mkdir -p "$vector_dir/$pool/shard-$(printf '%04d' "$i")"
    done
    log_success "Initialized $shard_count shards for pool: $pool"
  done

  # Initialize drift baseline placeholder
  if [[ ! -f "$baseline_dir/baseline-meta.json" ]]; then
    cat > "$baseline_dir/baseline-meta.json" << 'EOF'
{
  "version": "2.0.0",
  "initialized": true,
  "baselineTimestamp": null,
  "dimensions": 1536,
  "status": "pending_first_run",
  "note": "Baseline will be computed after first 500 interactions"
}
EOF
    log_success "Drift baseline metadata initialized"
  else
    log_info "Drift baseline metadata already exists"
  fi

  # Initialize audit WAL
  if [[ ! -f "$audit_dir/audit-wal.jsonl" ]]; then
    touch "$audit_dir/audit-wal.jsonl"
    log_success "Audit WAL initialized"
  fi

  # Set permissions
  chmod -R 755 "$DATA_DIR"
  log_success "Vector memory shards initialized in $DATA_DIR"
}

# ─────────────────────────────────────────────────────────────────────────────
# Step 4: Spawn minimum supervisors
# ─────────────────────────────────────────────────────────────────────────────
spawn_supervisors() {
  log_step "Spawning Minimum Supervisors"

  local api_url="$HEADY_API_URL"
  local min_supervisors="${MIN_SUPERVISORS:-3}"

  # Check if the API is running
  if ! curl -sf "$api_url/health" > /dev/null 2>&1; then
    log_warn "Heady API not reachable at $api_url — skipping supervisor spawn"
    log_info "Start the application first with: docker compose up -d || npm run dev"
    return 0
  fi

  log_info "Spawning $min_supervisors core supervisors via API..."

  local supervisor_ids=()
  local supervisors=(
    "context-supervisor"
    "intent-supervisor"
    "resource-supervisor"
    "node-selection-supervisor"
    "execution-supervisor"
    "quality-supervisor"
    "assurance-supervisor"
    "pattern-supervisor"
    "story-supervisor"
    "feedback-supervisor"
    "optimization-supervisor"
    "finalization-supervisor"
  )

  local spawned=0
  for supervisor in "${supervisors[@]}"; do
    if [[ $spawned -ge $min_supervisors ]]; then
      break
    fi

    local response
    response=$(curl -sf -X POST "$api_url/internal/supervisors/spawn" \
      -H "Content-Type: application/json" \
      -H "X-Internal-Token: ${INTERNAL_TOKEN:-}" \
      -d "{\"supervisorId\": \"$supervisor\"}" 2>/dev/null || echo '{"error":"failed"}')

    if echo "$response" | grep -q '"error"'; then
      log_warn "Failed to spawn $supervisor (API may not be fully initialized yet)"
    else
      log_success "Spawned supervisor: $supervisor"
      ((spawned++)) || true
    fi
  done

  log_success "Supervisor spawn complete ($spawned/$min_supervisors spawned)"
}

# ─────────────────────────────────────────────────────────────────────────────
# Step 5: Run health checks
# ─────────────────────────────────────────────────────────────────────────────
run_health_checks() {
  log_step "Running Health Checks"

  local api_url="$HEADY_API_URL"
  local max_retries=20
  local retry_delay=3
  local passed=0
  local failed=0

  # Wait for the API to be healthy
  log_info "Waiting for Heady API to be healthy..."
  for i in $(seq 1 $max_retries); do
    if curl -sf "$api_url/health" > /dev/null 2>&1; then
      log_success "Heady API is healthy"
      break
    fi
    if [[ $i -eq $max_retries ]]; then
      log_warn "API health check timed out after $((max_retries * retry_delay))s"
      log_info "You can check status manually: curl $api_url/health"
      return 0
    fi
    log_info "Waiting... (attempt $i/$max_retries)"
    sleep $retry_delay
  done

  # Run comprehensive health check
  local health_response
  health_response=$(curl -sf "$api_url/api/v2/health" 2>/dev/null || echo '{}')
  
  if command -v jq &>/dev/null; then
    echo "$health_response" | jq '.'
    
    local health_score
    health_score=$(echo "$health_response" | jq -r '.healthScore // "unknown"')
    local status
    status=$(echo "$health_response" | jq -r '.status // "unknown"')
    
    if [[ "$status" == "healthy" ]]; then
      log_success "System status: healthy (score: $health_score)"
      ((passed++)) || true
    else
      log_warn "System status: $status (score: $health_score)"
    fi
  else
    log_info "Health response: $health_response"
  fi

  # Check governance laws
  local law_response
  law_response=$(curl -sf "$api_url/api/v2/governance/laws/status" 2>/dev/null || echo '{}')
  
  if echo "$law_response" | grep -q '"enforced"'; then
    log_success "All 3 Unbreakable Laws: enforced ✓"
    ((passed++)) || true
  else
    log_warn "Governance law status could not be verified"
  fi

  log_success "Health checks complete ($passed checks passed)"
}

# ─────────────────────────────────────────────────────────────────────────────
# Step 6: Start self-awareness loop
# ─────────────────────────────────────────────────────────────────────────────
start_self_awareness() {
  log_step "Starting Self-Awareness Loop"

  local api_url="$HEADY_API_URL"

  if ! curl -sf "$api_url/health" > /dev/null 2>&1; then
    log_warn "API not reachable — self-awareness loop will auto-start when service is running"
    return 0
  fi

  # Trigger self-awareness loop initialization
  local response
  response=$(curl -sf -X POST "$api_url/internal/self-awareness/start" \
    -H "Content-Type: application/json" \
    -H "X-Internal-Token: ${INTERNAL_TOKEN:-}" \
    -d '{"intervalMs": 10000, "enabled": true}' 2>/dev/null || echo '{"error":"not_started"}')

  if echo "$response" | grep -q '"error"'; then
    log_warn "Self-awareness loop auto-start not available — it will initialize with the service"
  else
    log_success "Self-awareness loop started (10s evaluation interval)"
  fi

  log_info "Telemetry ring buffer: ${RING_BUFFER_SIZE:-500} events"
  log_info "Drift detection threshold: ${DRIFT_THRESHOLD:-0.75}"
  log_info "Error rate 1m threshold: 15%"
  log_info "Error rate 5m threshold: 10%"
}

# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────
main() {
  log_banner "🐝 Heady™ Systems — Swarm Ignition"
  log_info "Root: $ROOT_DIR"
  log_info "Data: $DATA_DIR"
  log_info "API:  $HEADY_API_URL"
  if [[ "$DEV_MODE" == true ]]; then
    log_warn "Development mode enabled"
  fi

  # Load environment
  load_env

  # Step 1: Verify dependencies
  if [[ "$SKIP_CHECKS" == false ]]; then
    verify_dependencies
  else
    log_warn "Skipping dependency checks (--skip-checks)"
  fi

  # Step 2: Validate configs
  validate_configs

  # Step 3: Initialize vector memory
  init_vector_memory

  # Step 4: Spawn supervisors
  spawn_supervisors

  # Step 5: Health checks
  run_health_checks

  # Step 6: Start self-awareness loop
  start_self_awareness

  log_banner "✓ Swarm Ignition Complete — Made with Love by HeadySystems"
  echo ""
  log_info "Next steps:"
  echo -e "  ${DIM}→${RESET} Start the platform:   ${CYAN}docker compose up${RESET}"
  echo -e "  ${DIM}→${RESET} View health:          ${CYAN}curl $HEADY_API_URL/api/v2/health | jq${RESET}"
  echo -e "  ${DIM}→${RESET} Monitor dashboard:    ${CYAN}http://localhost:3302${RESET}"
  echo -e "  ${DIM}→${RESET} Architecture docs:    ${CYAN}docs/ARCHITECTURE.md${RESET}"
  echo ""
}

main "$@"
