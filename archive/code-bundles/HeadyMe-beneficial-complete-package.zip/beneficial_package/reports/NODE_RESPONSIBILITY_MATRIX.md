# Node Responsibility Matrix

## Core control plane

| Node / Module | Primary responsibility | Should own | Should not own |
|---|---|---|---|
| `heady-manager.js` | Boot shell only | phase ordering, startup fail-fast, dependency wiring handoff | business logic, routing policy, health synthesis, projection decisions |
| `src/bootstrap/config-globals.js` | global process setup | env validation, app creation, event bus, config surfaces | feature policy, projection logic |
| `src/bootstrap/auth-engine.js` | auth bootstrap | auth middleware, login providers, auth route binding | budget, projection, swarm routing |
| `src/bootstrap/engine-wiring.js` | engine composition | instantiate engines, pass dependencies, lifecycle wiring | public route policy, UI concerns |
| `src/bootstrap/service-registry.js` | service mounting | deterministic mount table, route registration, service availability receipts | hidden soft-fail ownership, complex orchestration policy |
| `src/bootstrap/vector-stack.js` | memory/runtime bootstrap | vector services, buddy/watchdog attachment, memory route registration | broad platform service loading, security scheduling, unrelated product routes |

## Orchestration

| Node / Module | Primary responsibility | Should own | Should not own |
|---|---|---|---|
| `src/orchestration/heady-conductor.js` | task-routing control plane | task classification, bee dispatch policy, execution receipts, retry budget | macro health polling UI, unrelated REST summary logic |
| `src/routes/conductor.js` | system perspective API | macro health view, conductor-vs-lens comparisons, operator summaries | bee dispatch internals, worker lifecycle ownership |
| `src/orchestration/agent-orchestrator.js` | agent execution fabric | agent lifecycle, vector-aware execution, agent route binding | top-level platform health and projection control |
| `configs/pipeline/hcfullpipeline.yaml` | canonical workflow contract | stage ordering, stop rules, pool policy, recovery rules | direct runtime-specific code |

## Memory and intelligence

| Node / Module | Primary responsibility | Should own | Should not own |
|---|---|---|---|
| `src/memory/vector-memory.js` | canonical memory store | embeddings lifecycle, retrieval API, memory persistence | UI route policy, unrelated provider rules |
| `src/memory/vector-space-ops.js` | spatial operations | zoning, anti-sprawl, projection support | broad service orchestration |
| `src/memory/vector-federation.js` | memory federation | cross-store / cross-target memory access | auth and product rendering |
| `src/intelligence/hc_monte_carlo.js` | strategy simulation | plan ranking, candidate evaluation | service mount logic |
| `src/observability/hc_self_critique.js` | critique and learning signals | post-run critique, weaknesses, improvement candidates | route mounting |

## Bee layer

| Node / Module | Primary responsibility | Should own | Should not own |
|---|---|---|---|
| `src/bees/registry.js` | discovery registry | static bee discovery, health, domain listing | business policy, persistence beyond registry metadata |
| `src/bees/bee-factory.js` | runtime bee creation | ephemeral bee creation, dynamic work units, template-based bee spawn | acting as full scheduler or conductor |
| Bee domain files | domain-specific work | single-domain actions and work generation | cross-platform routing policy |

## Projection and deployment

| Node / Module | Primary responsibility | Should own | Should not own |
|---|---|---|---|
| `src/services/projection-engine.js` | projection manifest and sync state | target registry, staleness checks, sync receipts | product business logic |
| `src/services/projection-governance.js` | projection policy | projection allow/deny rules, schema checks, release gating | runtime memory behavior |
| projected repos | projection-specific surface | domain-specific entrypoint, health, docs, approved APIs, projection manifest | hidden dependence on monorepo internals without declared contract |

## Recommended ownership correction

1. Make `heady-manager.js` permanently thin.
2. Reduce `vector-stack` to memory-runtime concerns only.
3. Make `service-registry` deterministic and auditable rather than soft-fail-heavy.
4. Split conductor into:
   - task dispatch control plane
   - macro health perspective API
5. Treat projections as generated contract outputs, not hand-maintained stubs.
