# Workflow Gaps And Fixes

## Major workflow gaps

### 1. Registry-to-runtime drift

The registry declares a broad system surface, but live runtime paths and imports do not consistently resolve to stable modules. This creates a gap between declared capability and bootable capability.

Fix:
- add registry parity tests
- add boot-path integrity tests
- fail CI when declared engine paths do not exist

### 2. Soft-fail service mounting hides missing capability

`service-registry.js` uses flexible try/load behavior that is useful during experimentation, but it can hide missing modules and create false confidence.

Fix:
- classify mounts as `required`, `optional`, or `experimental`
- emit startup receipts listing what loaded and what was skipped
- fail fast in production for required services

### 3. Conductor role ambiguity

Dispatch routing and macro system-perspective behavior are split across more than one conductor concept.

Fix:
- designate one dispatcher contract
- designate one health-perspective contract
- define handoff API between the two

### 4. Projection repos lack real responsibility embodiment

Projected repos are mostly wrappers instead of domain-specific products or controlled slices.

Fix:
- generate projections from manifests
- require each projection to publish contract metadata
- attach projection tests and minimum surface checks

### 5. Secret governance does not match system claims

Security posture is weakened by committed key material and token-like strings.

Fix:
- rotate and revoke all exposed keys
- replace checked-in secrets with templates and generation scripts
- run secret scanning in CI and block merges on detection

### 6. File placement drift

Many modules appear referenced as if they live at repo-root aliases, while actual files live under nested domain folders.

Fix:
- normalize import conventions
- create a stable alias map or move files to match intended import locations
- avoid mixed root-level and namespaced historical patterns

## Suggested implementation sequence

### Phase 0
- freeze secret-bearing files
- rotate credentials and certs
- establish import normalization target

### Phase 1
- define control plane contracts
- classify services as required/optional/experimental
- make boot receipts mandatory

### Phase 2
- generate projections from manifest contracts
- add projection CI checks
- add repo-role docs across all public repos

### Phase 3
- reduce bootstrap hot spots
- move nonessential runtime concerns out of `vector-stack`
- keep orchestration ownership explicit and testable
