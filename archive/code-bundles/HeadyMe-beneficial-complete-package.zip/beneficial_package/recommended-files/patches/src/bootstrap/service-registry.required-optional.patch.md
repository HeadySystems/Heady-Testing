# Patch suggestion: classify services in service-registry

Target file: `src/bootstrap/service-registry.js`

## Intent

Keep the try/require flexibility, but make it explicit which services are:

- required (fail fast in production)
- optional (warn)
- experimental (silent or warn)

## Minimal patch sketch

- introduce a mount table with `{ name, mod, mount, level }`.
- on boot, emit a startup receipt listing loaded/skipped.
- in production, if a `required` service fails to load, terminate startup.

This is provided as a patch plan rather than direct code replacement because your final service list and strictness policy should follow your registry and environment model.
