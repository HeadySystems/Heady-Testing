# Patch suggestion: reduce scope of vector-stack

Target file: `src/bootstrap/vector-stack.js`

## Intent

Reduce this file to “vector runtime only” responsibilities:

- vector-memory init + routes
- vector-space-ops
- vector pipeline + federation
- attach buddy/watchdog and conductor wiring

Move unrelated service route loading to service-registry.

## Why

Vector-stack currently behaves like a second service loader, which makes boot ownership unclear and increases the blast radius of any change.
