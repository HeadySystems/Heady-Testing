/*
 * Control Plane Contract
 * Recommended interface boundary for Heady dispatcher and macro-health layers.
 */

/**
 * Task envelope shape:
 * {
 *   action: string,
 *   payload: object,
 *   priority?: 'standard' | 'admin',
 *   requestId?: string,
 *   traceId?: string,
 *   requestedBy?: string,
 * }
 */

/**
 * Dispatch receipt shape:
 * {
 *   ok: boolean,
 *   executionId: string,
 *   route: {
 *     serviceGroup: string,
 *     beeId?: string,
 *     vectorZone?: string,
 *   },
 *   startedAt: string,
 *   finishedAt?: string,
 *   durationMs?: number,
 *   error?: string,
 * }
 */

/**
 * Macro health report shape:
 * {
 *   overallHealth: number,
 *   perspective: string,
 *   lastPoll: string,
 *   services: Record<string, {
 *     healthy: boolean,
 *     status: string,
 *     latencyMs?: number,
 *     source: string,
 *   }>,
 * }
 */

module.exports = {
  CONTRACT_VERSION: '1.0.0',
};
