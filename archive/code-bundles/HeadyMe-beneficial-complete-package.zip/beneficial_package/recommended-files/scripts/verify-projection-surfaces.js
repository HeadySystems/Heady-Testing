#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const yaml = require('yaml');

const contracts = yaml.parse(fs.readFileSync(path.join(process.cwd(), 'configs/projection/projection-contracts.yaml'), 'utf8'));
for (const [name, def] of Object.entries(contracts.projections || {})) {
  if (!def.minimum_surface || def.minimum_surface.length === 0) {
    console.error(`Projection ${name} has no minimum surface`);
    process.exit(1);
  }
}
console.log('projection surfaces verified');
