#!/usr/bin/env node
// Minimal validator intended to run inside a projection repo.
// Confirms that the projection is not just a wrapper.

const fs = require('fs');

const requiredFiles = ['projection-manifest.json'];
let ok = true;
for (const f of requiredFiles) {
  if (!fs.existsSync(f)) {
    console.error(`Missing ${f}`);
    ok = false;
  }
}

if (!ok) process.exit(1);
console.log('projection repo validated');
