#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = process.cwd();
const requireRe = /require\((['"])(.+?)\1\)/g;
const failures = [];

function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === '.git' || entry.name === 'node_modules') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full);
    else if (entry.isFile() && full.endsWith('.js')) inspect(full);
  }
}

function existsFrom(base, target) {
  const candidate = path.resolve(path.dirname(base), target);
  return [candidate, `${candidate}.js`, `${candidate}.json`, path.join(candidate, 'index.js')].some(fs.existsSync);
}

function inspect(file) {
  const text = fs.readFileSync(file, 'utf8');
  let m;
  while ((m = requireRe.exec(text))) {
    const target = m[2];
    if (!target.startsWith('.')) continue;
    if (!existsFrom(file, target)) failures.push({ file: path.relative(root, file), require: target });
  }
}

walk(path.join(root, 'src'));
if (failures.length) {
  console.error(JSON.stringify(failures, null, 2));
  process.exit(1);
}
console.log('live imports verified');
