#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const registryPath = path.join(process.cwd(), 'heady-registry.json');
const registry = JSON.parse(fs.readFileSync(registryPath, 'utf8'));
const failures = [];

function checkEnginePath(p) {
  if (!p) return;
  const full = path.join(process.cwd(), p);
  if (!fs.existsSync(full)) failures.push(p);
}

const core = registry?.services?.core || {};
for (const svc of Object.values(core)) {
  if (svc && typeof svc === 'object' && svc.engine) checkEnginePath(svc.engine);
}
if (registry?.projections?.engine) checkEnginePath(registry.projections.engine);

if (failures.length) {
  console.error('Missing registry engine paths:');
  for (const f of failures) console.error(` - ${f}`);
  process.exit(1);
}
console.log('registry parity verified');
