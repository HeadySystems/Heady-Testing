# Projection Uplift Plan

## Current state

Many projection repos are minimal wrappers with a landing page and /health.

## Goal

Make every projection responsibility-true and contract-verified.

## Minimum uplift per projection

1. Add `projection-manifest.json` (template included).
2. Add minimum API surfaces for the projection’s declared role.
3. Add a projection CI gate (starter workflow included).
4. Publish `README.md` that states:
   - what this repo is
   - what it is not
   - how it is generated

## Enforcement

- block merges if the projection lacks its manifest
- block merges if the projection surface does not meet minimum endpoints
- block merges if secrets are detected
