# Broken Imports Triage

The evidence bundle includes `missing_live_requires.json`, which lists missing relative requires found under `src/` and other live paths.

## How to use it

1. Split the list into:
   - boot-critical (startup path, conductor, auth, vector, service registry)
   - non-critical (scripts, optional services)

2. Fix boot-critical first.

## Common root causes

- module moved into a domain folder but imports still point to legacy location
- duplicate versions exist in `_archive/` and live code imports the wrong one
- “core/heady-*” utilities are referenced but not present under `src/core/`

## Recommended stabilization sequence

1. Define an alias or move plan for internal modules.
2. Implement `verify-live-imports.js` gate.
3. Fix boot-critical imports until the gate passes.
4. Then fix the long tail.
