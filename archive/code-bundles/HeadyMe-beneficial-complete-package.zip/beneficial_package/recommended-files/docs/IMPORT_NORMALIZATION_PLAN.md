# Import Normalization Plan

## Problem

A large number of modules are referenced as if they exist at repo-root or legacy locations, but actual files live under other folders. This causes brittle boot behavior, hidden try/require failures, and test drift.

The scan also indicates at least one critical module (`secret-rotation`) exists only in archive paths, while live code references it.

## Goal

Create a single, stable import convention for internal modules and enforce it with CI.

## Recommendation

1. Pick one of these approaches and apply it consistently:
   - A: physical move: move files to match current import paths.
   - B: alias layer: create `src/aliases/*` and import through it.
   - C: module exports: adopt `exports` maps in `package.json` (more involved).

2. Add a pre-merge import verifier (starter included in this package).

3. Reduce try/require to only optional or experimental services.

## Minimum acceptance criteria

- No missing relative requires in `src/`.
- Boot-critical path fails fast if required services are missing.
- Registry engine paths must exist.
