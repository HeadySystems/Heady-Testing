# Projection Governance

## Purpose

Projected repos should be generated, minimal, and responsibility-true. They should not pretend to be full products while only exposing landing pages.

## Rules

1. The pre-production monorepo remains the implementation source of truth.
2. Every projection must be generated from a declared contract.
3. Every projection must expose a `projection-manifest.json` file.
4. Every projection must meet its minimum API and health surface.
5. Every projection must declare which domain responsibilities are intentionally excluded.
6. Projection builds fail if secret material or undeclared imports are present.

## Required metadata

Each projection should publish:

- name
- domain
- version
- generatedFrom commit hash
- purpose
- included surfaces
- excluded surfaces
- upstream contract path

## Why this matters

Without governance, public projection repos become symbolic wrappers, which creates architectural confusion and weakens trust in the repo topology.
