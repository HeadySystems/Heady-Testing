# Developer Quickstart

## Recommended local flow

- Use the main monorepo as the source of truth.
- Treat projection repos as generated outputs unless explicitly developing projection-specific UI.

## Guardrails

- Do not commit secrets.
- Keep boot path deterministic.
- Keep conductor responsibilities explicit.
- Keep projections contract-bound.
