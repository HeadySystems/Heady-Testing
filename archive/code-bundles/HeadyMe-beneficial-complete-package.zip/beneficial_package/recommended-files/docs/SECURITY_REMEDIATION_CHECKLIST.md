# Security Remediation Checklist

## Immediate (P0)

- Treat committed key material as exposed.
- Revoke/rotate any certs, tokens, or credentials related to:
  - `configs/nginx/ssl/*.key|*.pem`
  - `_archive/configs/nginx/ssl/*.key|*.pem`
- Remove all key material from the working tree and Git history.
- Replace with templates only.

## Near-term (P1)

- Add CI secret scan gate.
- Ensure `.env.example` contains placeholders only.
- Ensure tests never include real access-key-like strings.
- Ensure email/provider integrations only read secrets from a real secret manager.

## Ongoing

- Establish a single “Secrets Contract” owned by one subsystem.
- Emit a daily secret audit receipt.
