# Conductor Role Split

## Current ambiguity

Heady has more than one “conductor” concept:

- a dispatcher and bee execution controller
- a macro system perspective and polling API

## Desired split

### 1. Dispatcher Control Plane

- owns: task classification, bee selection, execution receipts, retry budgets
- file target: `src/orchestration/heady-conductor.js`
- outputs: dispatch receipts

### 2. Macro Perspective API

- owns: system polling, operator summaries, comparison against Lens
- file target: `src/routes/conductor.js`
- outputs: health/perspective reports

## Contract

Use a shared contract object (starter included) so the two layers can evolve independently while remaining compatible.
