# Operator Quickstart

## What to do first

1. Rotate secrets and remove key material.
2. Normalize imports and fix boot-critical missing modules.
3. Decide and enforce conductor role split.
4. Enforce projection governance in CI.

## What success looks like

- Boot fails fast for required services.
- Registry declared engine paths exist.
- No committed secrets.
- Projections publish manifests and minimum surfaces.
