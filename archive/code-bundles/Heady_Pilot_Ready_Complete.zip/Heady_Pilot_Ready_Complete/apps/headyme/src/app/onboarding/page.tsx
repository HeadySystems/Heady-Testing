'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

/**
 * Heady 5-Stage Onboarding Wizard
 * 
 * Stage 1: Create Account & Username (@heady... identity)
 * Stage 2: HeadyCloud Permissions (multi-cloud access)
 * Stage 3: HeadyBuddy Customization (AI contexts & personality)
 * Stage 4: Workspace Setup (Arena Mode, IDE preferences)
 * Stage 5: API Key Generation (HeadyMCP key - FINAL STAGE)
 */

type OnboardingStage = 1 | 2 | 3 | 4 | 5;

interface OnboardingState {
  stage: OnboardingStage;
  username: string;
  email: string;
  cloudPermissions: string[];
  buddyConfig: {
    personality: 'professional' | 'casual' | 'technical';
    voice: 'neutral' | 'enthusiastic' | 'concise';
    contexts: string[];
  };
  workspaceConfig: {
    arenaMode: boolean;
    ideTheme: 'dark' | 'light' | 'auto';
    notifications: boolean;
  };
  apiKey: string | null;
}

export default function OnboardingWizard() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [state, setState] = useState<OnboardingState>({
    stage: 1,
    username: '',
    email: '',
    cloudPermissions: [],
    buddyConfig: {
      personality: 'professional',
      voice: 'neutral',
      contexts: []
    },
    workspaceConfig: {
      arenaMode: true,
      ideTheme: 'dark',
      notifications: true
    },
    apiKey: null
  });

  const updateState = (updates: Partial<OnboardingState>) => {
    setState(prev => ({ ...prev, ...updates }));
  };

  const nextStage = async () => {
    setLoading(true);
    setError(null);

    try {
      // Save current stage data
      await fetch('/api/onboarding/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stage: state.stage, data: state })
      });

      if (state.stage === 5) {
        // Final stage - mark onboarding complete
        await fetch('/api/onboarding/complete', { method: 'POST' });
        document.cookie = 'onboarding_complete=true; path=/; max-age=31536000';
        router.push('/dashboard');
      } else {
        updateState({ stage: (state.stage + 1) as OnboardingStage });
      }
    } catch (err) {
      setError('Failed to save progress. Please try again.');
      console.error('[Onboarding] Error:', err);
    } finally {
      setLoading(false);
    }
  };

  const renderStage = () => {
    switch (state.stage) {
      case 1:
        return (
          <div className="stage-container">
            <h2 className="text-2xl font-bold mb-4">Welcome to Heady Systems</h2>
            <p className="mb-6">Let's create your Heady identity</p>

            <div className="form-group">
              <label className="block mb-2">Choose your username</label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={state.username}
                  onChange={(e) => updateState({ username: e.target.value })}
                  className="flex-1 px-4 py-2 bg-gray-800 rounded border border-gray-700"
                  placeholder="yourname"
                />
                <span className="text-gray-400">@heady.systems</span>
              </div>
            </div>

            <div className="form-group mt-4">
              <label className="block mb-2">Email</label>
              <input
                type="email"
                value={state.email}
                onChange={(e) => updateState({ email: e.target.value })}
                className="w-full px-4 py-2 bg-gray-800 rounded border border-gray-700"
                placeholder="you@example.com"
              />
            </div>

            <button
              onClick={nextStage}
              disabled={!state.username || !state.email || loading}
              className="mt-6 px-6 py-3 bg-blue-600 rounded hover:bg-blue-700 disabled:bg-gray-600"
            >
              {loading ? 'Creating...' : 'Create Account'}
            </button>
          </div>
        );

      case 2:
        return (
          <div className="stage-container">
            <h2 className="text-2xl font-bold mb-4">Cloud Permissions</h2>
            <p className="mb-6">Grant HeadyCloud access to your infrastructure</p>

            <div className="space-y-3">
              {['AWS', 'Cloudflare', 'Render', 'Google Cloud', 'Azure'].map(provider => (
                <label key={provider} className="flex items-center gap-3 p-3 bg-gray-800 rounded cursor-pointer">
                  <input
                    type="checkbox"
                    checked={state.cloudPermissions.includes(provider)}
                    onChange={(e) => {
                      const perms = e.target.checked
                        ? [...state.cloudPermissions, provider]
                        : state.cloudPermissions.filter(p => p !== provider);
                      updateState({ cloudPermissions: perms });
                    }}
                    className="w-5 h-5"
                  />
                  <span>{provider}</span>
                </label>
              ))}
            </div>

            <button
              onClick={nextStage}
              disabled={state.cloudPermissions.length === 0 || loading}
              className="mt-6 px-6 py-3 bg-blue-600 rounded hover:bg-blue-700 disabled:bg-gray-600"
            >
              {loading ? 'Saving...' : 'Continue'}
            </button>
          </div>
        );

      case 3:
        return (
          <div className="stage-container">
            <h2 className="text-2xl font-bold mb-4">Customize HeadyBuddy</h2>
            <p className="mb-6">Configure your AI companion</p>

            <div className="space-y-4">
              <div>
                <label className="block mb-2">Personality</label>
                <select
                  value={state.buddyConfig.personality}
                  onChange={(e) => updateState({
                    buddyConfig: { ...state.buddyConfig, personality: e.target.value as any }
                  })}
                  className="w-full px-4 py-2 bg-gray-800 rounded border border-gray-700"
                >
                  <option value="professional">Professional</option>
                  <option value="casual">Casual</option>
                  <option value="technical">Technical</option>
                </select>
              </div>

              <div>
                <label className="block mb-2">Voice Tone</label>
                <select
                  value={state.buddyConfig.voice}
                  onChange={(e) => updateState({
                    buddyConfig: { ...state.buddyConfig, voice: e.target.value as any }
                  })}
                  className="w-full px-4 py-2 bg-gray-800 rounded border border-gray-700"
                >
                  <option value="neutral">Neutral</option>
                  <option value="enthusiastic">Enthusiastic</option>
                  <option value="concise">Concise</option>
                </select>
              </div>

              <div>
                <label className="block mb-2">Default Contexts</label>
                <div className="space-y-2">
                  {['Development', 'Operations', 'Research', 'Creative'].map(ctx => (
                    <label key={ctx} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={state.buddyConfig.contexts.includes(ctx)}
                        onChange={(e) => {
                          const contexts = e.target.checked
                            ? [...state.buddyConfig.contexts, ctx]
                            : state.buddyConfig.contexts.filter(c => c !== ctx);
                          updateState({
                            buddyConfig: { ...state.buddyConfig, contexts }
                          });
                        }}
                      />
                      <span>{ctx}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={nextStage}
              disabled={loading}
              className="mt-6 px-6 py-3 bg-blue-600 rounded hover:bg-blue-700"
            >
              {loading ? 'Saving...' : 'Continue'}
            </button>
          </div>
        );

      case 4:
        return (
          <div className="stage-container">
            <h2 className="text-2xl font-bold mb-4">Workspace Setup</h2>
            <p className="mb-6">Configure your development environment</p>

            <div className="space-y-4">
              <label className="flex items-center justify-between p-3 bg-gray-800 rounded">
                <div>
                  <div className="font-medium">Arena Mode</div>
                  <div className="text-sm text-gray-400">Run competing AI solutions in parallel</div>
                </div>
                <input
                  type="checkbox"
                  checked={state.workspaceConfig.arenaMode}
                  onChange={(e) => updateState({
                    workspaceConfig: { ...state.workspaceConfig, arenaMode: e.target.checked }
                  })}
                  className="w-5 h-5"
                />
              </label>

              <div>
                <label className="block mb-2">IDE Theme</label>
                <select
                  value={state.workspaceConfig.ideTheme}
                  onChange={(e) => updateState({
                    workspaceConfig: { ...state.workspaceConfig, ideTheme: e.target.value as any }
                  })}
                  className="w-full px-4 py-2 bg-gray-800 rounded border border-gray-700"
                >
                  <option value="dark">Dark</option>
                  <option value="light">Light</option>
                  <option value="auto">Auto (system)</option>
                </select>
              </div>

              <label className="flex items-center justify-between p-3 bg-gray-800 rounded">
                <div>
                  <div className="font-medium">Desktop Notifications</div>
                  <div className="text-sm text-gray-400">Get notified about builds and deployments</div>
                </div>
                <input
                  type="checkbox"
                  checked={state.workspaceConfig.notifications}
                  onChange={(e) => updateState({
                    workspaceConfig: { ...state.workspaceConfig, notifications: e.target.checked }
                  })}
                  className="w-5 h-5"
                />
              </label>
            </div>

            <button
              onClick={nextStage}
              disabled={loading}
              className="mt-6 px-6 py-3 bg-blue-600 rounded hover:bg-blue-700"
            >
              {loading ? 'Saving...' : 'Continue'}
            </button>
          </div>
        );

      case 5:
        return (
          <div className="stage-container">
            <h2 className="text-2xl font-bold mb-4">Your HeadyMCP API Key</h2>
            <p className="mb-6">You're all set! Here's your API key for HeadyMCP</p>

            {state.apiKey ? (
              <div className="p-4 bg-gray-800 rounded border border-gray-700 mb-4">
                <code className="text-green-400 font-mono">{state.apiKey}</code>
              </div>
            ) : (
              <button
                onClick={async () => {
                  const res = await fetch('/api/mcp/generate-key', { method: 'POST' });
                  const { apiKey } = await res.json();
                  updateState({ apiKey });
                }}
                className="px-6 py-3 bg-green-600 rounded hover:bg-green-700 mb-4"
              >
                Generate API Key
              </button>
            )}

            <div className="p-4 bg-blue-900/30 border border-blue-700 rounded mb-4">
              <h3 className="font-medium mb-2">🎉 Welcome to Heady Systems!</h3>
              <p className="text-sm text-gray-300">
                Your account is ready. Access your dashboard to start building with the Heady platform.
              </p>
            </div>

            <button
              onClick={nextStage}
              disabled={!state.apiKey || loading}
              className="px-6 py-3 bg-blue-600 rounded hover:bg-blue-700 disabled:bg-gray-600"
            >
              {loading ? 'Completing...' : 'Go to Dashboard'}
            </button>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center p-8">
      <div className="max-w-2xl w-full">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex justify-between mb-2">
            {[1, 2, 3, 4, 5].map(step => (
              <div
                key={step}
                className={`w-12 h-12 rounded-full flex items-center justify-center font-bold border-2 \
                  ${state.stage >= step ? 'bg-blue-600 border-blue-600' : 'bg-gray-800 border-gray-700'}`}
              >
                {step}
              </div>
            ))}
          </div>
          <div className="text-sm text-gray-400 text-center">
            Step {state.stage} of 5
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="mb-4 p-4 bg-red-900/30 border border-red-700 rounded">
            {error}
          </div>
        )}

        {/* Stage Content */}
        {renderStage()}
      </div>
    </div>
  );
}
