/**
 * HeadyStack v3.0.1 "Aether" — PM2 Ecosystem Configuration
 * 
 * Usage:
 *   pm2 start ecosystem.config.cjs
 *   pm2 start ecosystem.config.cjs --env production
 *   pm2 reload headystack
 *   pm2 stop headystack
 *   pm2 delete headystack
 *   pm2 logs headystack
 *   pm2 monit
 * 
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

module.exports = {
    apps: [
        {
            // ── Main Application ────────────────────────────────────
            name: 'headystack',
            script: 'heady-manager.js',
            cwd: __dirname,

            // Cluster mode: spawn one process per CPU core (production)
            // Set instances: 1 for staging/debugging
            instances: process.env.NODE_ENV === 'production' ? 'max' : 1,
            exec_mode: process.env.NODE_ENV === 'production' ? 'cluster' : 'fork',

            // Auto-restart on crash
            autorestart: true,
            watch: false,               // Use 'npm run dev' for hot reload
            max_memory_restart: '1800M',

            // Graceful shutdown
            kill_timeout: 10000,        // 10s to finish in-flight requests
            wait_ready: true,           // Wait for process.send('ready')
            listen_timeout: 30000,      // 30s for process to send ready

            // Restart delay for crash loops
            restart_delay: 1000,
            max_restarts: 10,
            min_uptime: 5000,

            // Logging
            log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
            error_file: './logs/heady-error.log',
            out_file: './logs/heady-out.log',
            combine_logs: true,
            merge_logs: true,

            // Source maps
            source_map_support: false,

            // Env: shared
            env: {
                NODE_ENV: 'development',
                PORT: 8080,
            },

            // Env: staging
            env_staging: {
                NODE_ENV: 'staging',
                PORT: 8080,
                LOG_LEVEL: 'debug',
            },

            // Env: production
            env_production: {
                NODE_ENV: 'production',
                PORT: 8080,
                LOG_LEVEL: 'info',
                // Secrets injected from environment — not hardcoded here
            },

            // Node.js flags
            node_args: [
                '--max-old-space-size=1536',    // 1.5GB heap limit
            ],
        },

        // ── Dev Watch Mode (standalone, not cluster) ─────────────────
        {
            name: 'headystack-dev',
            script: 'heady-manager.js',
            cwd: __dirname,
            instances: 1,
            exec_mode: 'fork',
            watch: ['src/', 'heady-manager.js', 'configs/'],
            watch_delay: 1000,
            ignore_watch: ['node_modules', 'logs', 'uploads', 'coverage'],
            autorestart: true,
            env: {
                NODE_ENV: 'development',
                PORT: 8080,
                LOG_LEVEL: 'debug',
            },
        },
    ],
};
