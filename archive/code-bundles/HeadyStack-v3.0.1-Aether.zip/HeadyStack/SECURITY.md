# Security Policy

**HeadyStack v3.0.1 "Aether"**  
**© 2026 HeadySystems Inc.**

---

## Supported Versions

| Version | Supported |
|---------|-----------|
| 3.0.x (Aether) | ✅ Active security support |
| 2.x | ⚠️ Critical fixes only |
| 1.x | ❌ End of life — upgrade required |

---

## Reporting a Vulnerability

**Do not open a public GitHub issue for security vulnerabilities.**

### Contact

- **Email:** security@headysystems.ai
- **PGP Key:** Available at https://headysystems.ai/.well-known/security.txt
- **Response SLA:** Initial acknowledgment within 24 hours; triage within 72 hours

### What to Include

1. Description of the vulnerability
2. Steps to reproduce (proof-of-concept if available)
3. Affected version(s)
4. Potential impact assessment
5. Your name and contact (for credit, if desired)

### Responsible Disclosure

We follow coordinated disclosure:
1. You report to us privately
2. We triage and confirm within 72 hours
3. We develop and test a fix
4. We release the fix with a CVE (if applicable)
5. You may publish details 90 days after fix release, or upon mutual agreement

We do not pursue legal action against good-faith security researchers who follow this process.

---

## Security Architecture

### Authentication

- JWT (HS256) with short-lived access tokens (15 minutes)
- Refresh token rotation — each use invalidates the previous token
- Refresh tokens stored as hashed values in Redis with TTL
- OAuth2 PKCE — no client secrets transmitted in browser
- API keys stored as bcrypt hashes (cost factor 12) in database

### Transport

- TLS 1.2+ required in production (enforced by Cloudflare/Cloud Run)
- HSTS header with `max-age=31536000; includeSubDomains`
- CORS restricted to whitelisted origins
- CSP headers via Helmet

### Data

- Passwords hashed with bcryptjs (cost factor 12 minimum)
- API keys hashed before storage — never stored in plaintext
- Database connections over TLS (configurable via `DB_SSL=true`)
- No PII logged; request logging excludes Authorization headers
- Audit trail in `audit_log` table for all privileged actions

### Infrastructure

- Non-root container user (`heady:heady`)
- Read-only container filesystem (source code layers)
- Secrets injected as environment variables from Secret Manager
- No hardcoded credentials — environment validation at boot
- Rate limiting on all endpoints; auth routes have stricter windows

### Dependencies

- Dependencies are pinned to minor versions in `package.json`
- `npm audit` runs on every PR and daily via CI
- SBOM generated on every release (CycloneDX JSON)
- Trivy container scans on every Docker build

---

## Known Security Considerations

### LLM Prompt Injection

HeadyStack processes untrusted user input and routes it to LLMs. Mitigations:
- System prompts are injected server-side and cannot be overridden by API callers
- Tool execution is gated behind the `tool-use` pipeline stage with validation
- Agent `maxSteps` limits prevent runaway tool call loops

### Vector Memory Isolation

- Memory namespaces are enforced server-side — users can only access their own `user/<id>` namespace
- Cross-namespace queries require `admin` role
- Vectors do not contain decryptable plaintext — only embeddings

### Webhook Verification

- Stripe webhooks verified via `stripe.webhooks.constructEvent` with signing secret
- GitHub webhooks verified via HMAC-SHA256 signature header

---

## Security Headers

HeadyStack sets the following security headers via Helmet:

```
Content-Security-Policy: default-src 'self'; script-src 'self'; object-src 'none'
X-Frame-Options: DENY
X-Content-Type-Options: nosniff
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: camera=(), microphone=(), geolocation=()
Strict-Transport-Security: max-age=31536000; includeSubDomains
```

---

## Hall of Fame

We thank the following researchers for responsible disclosure:

*(None yet — be the first!)*

---

## Bug Bounty

HeadyStack does not currently operate a formal bug bounty program. High-severity findings may receive discretionary recognition (swag, credit, reference letter).
