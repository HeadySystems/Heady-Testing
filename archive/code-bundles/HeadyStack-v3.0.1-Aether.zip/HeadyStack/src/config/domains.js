'use strict';

/**
 * HeadyStack — Domain Configuration
 * Maps all Heady domains to their respective service identifiers.
 */

const HEADY_DOMAINS = [
  'headyme.com',
  'headysystems.com',
  'headyconnection.org',
  'headyai.org',
  'headymcp.com',
  'headyapi.com',
  'headybuddy.com',
  'headybot.com',
  'headyio.com',
];

/**
 * Domain → primary service mapping.
 * The value is the service key used in the service registry.
 */
const DOMAIN_SERVICE_MAP = {
  'headyme.com':          'site-headyme',
  'www.headyme.com':      'site-headyme',
  'headysystems.com':     'site-headysystems',
  'www.headysystems.com': 'site-headysystems',
  'headyconnection.org':  'site-headyconnection',
  'www.headyconnection.org': 'site-headyconnection',
  'headyai.org':          'site-headyai',
  'www.headyai.org':      'site-headyai',
  'headymcp.com':         'mcp-server',
  'www.headymcp.com':     'mcp-server',
  'headyapi.com':         'api-gateway',
  'www.headyapi.com':     'api-gateway',
  'headybuddy.com':       'buddy-service',
  'www.headybuddy.com':   'buddy-service',
  'headybot.com':         'bot-service',
  'www.headybot.com':     'bot-service',
  'headyio.com':          'io-service',
  'www.headyio.com':      'io-service',
};

/**
 * Allowed CORS origins.
 * Includes all Heady domains (http + https) and localhost variants.
 */
const CORS_ORIGINS = [
  ...HEADY_DOMAINS.flatMap((d) => [`https://${d}`, `https://www.${d}`, `http://${d}`]),
  'http://localhost',
  'http://localhost:3000',
  'http://localhost:3001',
  'http://localhost:5173',
  'http://localhost:8080',
  'http://localhost:8081',
  'http://127.0.0.1:3000',
  'http://127.0.0.1:8080',
];

/**
 * Resolve the service key for a given hostname.
 * @param {string} hostname
 * @returns {string|null}
 */
function resolveService(hostname) {
  if (!hostname) return null;
  const clean = hostname.toLowerCase().split(':')[0]; // strip port
  return DOMAIN_SERVICE_MAP[clean] || null;
}

/**
 * Check whether a hostname is a known Heady domain.
 * @param {string} hostname
 * @returns {boolean}
 */
function isHeadyDomain(hostname) {
  if (!hostname) return false;
  const clean = hostname.toLowerCase().split(':')[0];
  return HEADY_DOMAINS.some((d) => clean === d || clean.endsWith(`.${d}`));
}

module.exports = {
  HEADY_DOMAINS,
  DOMAIN_SERVICE_MAP,
  CORS_ORIGINS,
  resolveService,
  isHeadyDomain,
};
