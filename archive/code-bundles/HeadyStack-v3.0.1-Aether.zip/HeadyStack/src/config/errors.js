'use strict';

/**
 * HeadyStack — Custom Error Classes
 * Structured error hierarchy for consistent error handling across all services.
 */

/**
 * Base error class for all HeadyStack errors.
 */
class HeadyError extends Error {
  /**
   * @param {string} message
   * @param {string} [code] - Machine-readable error code (e.g. 'VALIDATION_FAILED')
   * @param {number} [statusCode] - HTTP status code
   * @param {object} [meta] - Additional context
   */
  constructor(message, code, statusCode, meta) {
    super(message);
    this.name = this.constructor.name;
    this.code = code || 'HEADY_ERROR';
    this.statusCode = statusCode || 500;
    this.meta = meta || {};
    this.isHeadyError = true;
    // Capture stack trace, excluding the constructor
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    }
  }

  toJSON() {
    return {
      error: this.name,
      code: this.code,
      message: this.message,
      statusCode: this.statusCode,
      meta: this.meta,
    };
  }
}

/**
 * Authentication and authorization failures.
 */
class AuthError extends HeadyError {
  constructor(message, code, meta) {
    super(message || 'Authentication failed', code || 'AUTH_FAILED', 401, meta);
  }
}

/**
 * Input validation failures.
 */
class ValidationError extends HeadyError {
  constructor(message, code, meta) {
    super(message || 'Validation failed', code || 'VALIDATION_FAILED', 422, meta);
  }
}

/**
 * Resource not found.
 */
class NotFoundError extends HeadyError {
  constructor(message, code, meta) {
    super(message || 'Resource not found', code || 'NOT_FOUND', 404, meta);
  }
}

/**
 * Rate limit exceeded.
 */
class RateLimitError extends HeadyError {
  constructor(message, meta) {
    super(message || 'Rate limit exceeded', 'RATE_LIMIT_EXCEEDED', 429, meta);
    this.retryAfter = (meta && meta.retryAfter) || 60;
  }
}

/**
 * Circuit breaker is open — upstream service unavailable.
 */
class CircuitOpenError extends HeadyError {
  constructor(message, meta) {
    super(message || 'Circuit breaker open — service unavailable', 'CIRCUIT_OPEN', 503, meta);
    this.service = (meta && meta.service) || 'unknown';
  }
}

/**
 * External upstream service failure.
 */
class UpstreamError extends HeadyError {
  constructor(message, code, meta) {
    super(message || 'Upstream service error', code || 'UPSTREAM_ERROR', 502, meta);
  }
}

/**
 * Configuration error — missing or invalid system config.
 */
class ConfigError extends HeadyError {
  constructor(message, meta) {
    super(message || 'Configuration error', 'CONFIG_ERROR', 500, meta);
  }
}

/**
 * Express error handler middleware.
 * Catches HeadyError instances and formats them as JSON.
 */
function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  if (res.headersSent) return next(err);

  if (err && err.isHeadyError) {
    if (err instanceof RateLimitError) {
      res.set('Retry-After', String(err.retryAfter));
    }
    return res.status(err.statusCode).json(err.toJSON());
  }

  // Generic unhandled error
  const statusCode = (err && err.status) || (err && err.statusCode) || 500;
  res.status(statusCode).json({
    error: 'InternalError',
    code: 'INTERNAL_ERROR',
    message: process.env.NODE_ENV === 'production'
      ? 'An internal error occurred'
      : (err && err.message) || 'Unknown error',
    statusCode,
  });
}

module.exports = {
  HeadyError,
  AuthError,
  ValidationError,
  NotFoundError,
  RateLimitError,
  CircuitOpenError,
  UpstreamError,
  ConfigError,
  errorHandler,
};
