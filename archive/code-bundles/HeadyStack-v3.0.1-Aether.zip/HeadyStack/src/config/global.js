'use strict';

/**
 * HeadyStack — Global Constants
 */

const EMBEDDING_DIM    = 384;       // Default embedding dimension (all-MiniLM-L6-v2 compatible)
const PROJECTION_DIM   = 3;         // 3D projection for spatial visualization
const VERSION          = '3.0.1';
const CODENAME         = 'Aether';

const HEADY_EPOCH      = new Date('2024-01-01T00:00:00.000Z').getTime();
const MAX_VECTOR_BATCH  = 512;
const MAX_CONTEXT_TOKENS = 8192;
const DEFAULT_TIMEOUT   = 30_000;  // ms
const HEARTBEAT_INTERVAL = 10_000; // ms

const ENV = process.env.NODE_ENV || 'development';
const IS_PRODUCTION  = ENV === 'production';
const IS_DEVELOPMENT = ENV === 'development';
const IS_TEST        = ENV === 'test';

module.exports = {
  EMBEDDING_DIM,
  PROJECTION_DIM,
  VERSION,
  CODENAME,
  HEADY_EPOCH,
  MAX_VECTOR_BATCH,
  MAX_CONTEXT_TOKENS,
  DEFAULT_TIMEOUT,
  HEARTBEAT_INTERVAL,
  ENV,
  IS_PRODUCTION,
  IS_DEVELOPMENT,
  IS_TEST,
};
