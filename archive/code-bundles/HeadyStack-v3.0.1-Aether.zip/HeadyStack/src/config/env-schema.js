'use strict';

/**
 * HeadyStack — Environment Variable Schema + Validation
 * Validates and normalizes all environment variables at startup.
 */

const REQUIRED_VARS = ['NODE_ENV', 'PORT'];

const OPTIONAL_VARS = {
  // Database
  DATABASE_URL:            { default: null,        description: 'PostgreSQL connection string' },
  REDIS_URL:               { default: 'redis://localhost:6379', description: 'Redis connection URL' },
  REDIS_POOL_SIZE:         { default: '5',         description: 'Redis pool connection count' },

  // Heady API
  HEADY_API_KEY:           { default: null,        description: 'HeadyStack internal API key' },
  ADMIN_TOKEN:             { default: null,        description: 'Admin bearer token' },
  RENDER_API_KEY:          { default: null,        description: 'Render.com deploy API key' },

  // Authentication
  JWT_SECRET:              { default: null,        description: 'JWT signing secret' },
  JWT_EXPIRY:              { default: '1h',        description: 'JWT token expiry (e.g. 1h, 7d)' },
  JWT_REFRESH_EXPIRY:      { default: '7d',        description: 'JWT refresh token expiry' },
  OAUTH_CLIENT_ID:         { default: null,        description: 'OAuth 2.1 client ID' },
  OAUTH_CLIENT_SECRET:     { default: null,        description: 'OAuth 2.1 client secret' },
  OAUTH_REDIRECT_URI:      { default: null,        description: 'OAuth callback URL' },
  SESSION_SECRET:          { default: null,        description: 'Express session secret' },

  // External services
  HF_TOKEN:                { default: null,        description: 'Hugging Face API token' },
  NOTION_TOKEN:            { default: null,        description: 'Notion integration token' },
  GITHUB_TOKEN:            { default: null,        description: 'GitHub personal access token' },
  STRIPE_SECRET_KEY:       { default: null,        description: 'Stripe secret key' },
  STRIPE_WEBHOOK_SECRET:   { default: null,        description: 'Stripe webhook signing secret' },
  OPENAI_API_KEY:          { default: null,        description: 'OpenAI API key' },
  ANTHROPIC_API_KEY:       { default: null,        description: 'Anthropic API key' },
  GOOGLE_API_KEY:          { default: null,        description: 'Google API key' },

  // Cloudflare
  CF_API_TOKEN:            { default: null,        description: 'Cloudflare API token' },
  CF_ACCOUNT_ID:           { default: null,        description: 'Cloudflare account ID' },
  CF_ZONE_ID:              { default: null,        description: 'Cloudflare zone ID' },
  CF_KV_NAMESPACE_ID:      { default: null,        description: 'Cloudflare KV namespace ID' },

  // System
  LOG_LEVEL:               { default: 'info',      description: 'Log level (debug|info|warn|error)' },
  HEADY_VERSION:           { default: '3.0.1',     description: 'Application version string' },
  HEADY_CODENAME:          { default: 'Aether',    description: 'Release codename' },
  CORS_ORIGINS:            { default: null,        description: 'Comma-separated extra allowed origins' },
  RATE_LIMIT_MAX:          { default: '120',       description: 'Max requests per minute per IP' },
  RATE_LIMIT_WINDOW_MS:    { default: '60000',     description: 'Rate limit window in ms' },
  BODY_LIMIT:              { default: '10mb',      description: 'JSON body parser size limit' },
  TRUST_PROXY:             { default: 'true',      description: 'Trust X-Forwarded-For header' },

  // Vector
  VECTOR_DIM:              { default: '384',       description: 'Vector embedding dimension' },
  VECTOR_BACKEND:          { default: 'memory',    description: 'Vector store backend (memory|postgres|qdrant)' },
  QDRANT_URL:              { default: null,        description: 'Qdrant vector DB URL' },
};

/**
 * Validates environment variables against the schema.
 * @param {object} [options]
 * @param {boolean} [options.strict] - Fail on missing required vars in production
 * @param {boolean} [options.warnOptional] - Log warnings for missing optional vars
 * @returns {{ valid: boolean, errors: string[], warnings: string[], env: object }}
 */
function validateEnvironment(options = {}) {
  const strict = options.strict !== false
    ? (process.env.NODE_ENV === 'production')
    : options.strict;

  const errors = [];
  const warnings = [];
  const env = {};

  // Validate required vars
  for (const key of REQUIRED_VARS) {
    const val = process.env[key];
    if (val === undefined || val === '') {
      if (strict) {
        errors.push(`Missing required env var: ${key}`);
      } else {
        warnings.push(`Missing required env var: ${key}`);
      }
    } else {
      env[key] = val;
    }
  }

  // Apply optional defaults
  for (const [key, schema] of Object.entries(OPTIONAL_VARS)) {
    const val = process.env[key];
    if (val !== undefined && val !== '') {
      env[key] = val;
    } else if (schema.default !== null) {
      env[key] = schema.default;
      // Don't override process.env — but note the default
    } else {
      env[key] = null;
      if (options.warnOptional) {
        warnings.push(`Optional env var not set: ${key} — ${schema.description}`);
      }
    }
  }

  // NODE_ENV normalization
  if (!['development', 'production', 'test', 'staging'].includes(process.env.NODE_ENV || '')) {
    warnings.push(`Unusual NODE_ENV value: "${process.env.NODE_ENV}" — expected development|production|test|staging`);
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    env,
  };
}

/**
 * Runs validateEnvironment and throws if there are errors.
 * @param {object} [options]
 */
function assertEnvironment(options = {}) {
  const result = validateEnvironment(options);
  if (!result.valid) {
    throw new Error(`Environment validation failed:\n${result.errors.join('\n')}`);
  }
  return result;
}

module.exports = {
  REQUIRED_VARS,
  OPTIONAL_VARS,
  validateEnvironment,
  assertEnvironment,
};
