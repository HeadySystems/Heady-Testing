'use strict';

/**
 * HeadyStack — Config Barrel Export
 * Aggregates all config modules into a single import point.
 */

const globals   = require('./global');
const domains   = require('./domains');
const errors    = require('./errors');
const envSchema = require('./env-schema');

module.exports = {
  // Global constants
  ...globals,

  // Domain config
  HEADY_DOMAINS:      domains.HEADY_DOMAINS,
  DOMAIN_SERVICE_MAP: domains.DOMAIN_SERVICE_MAP,
  CORS_ORIGINS:       domains.CORS_ORIGINS,
  resolveService:     domains.resolveService,
  isHeadyDomain:      domains.isHeadyDomain,

  // Error classes
  HeadyError:       errors.HeadyError,
  AuthError:        errors.AuthError,
  ValidationError:  errors.ValidationError,
  NotFoundError:    errors.NotFoundError,
  RateLimitError:   errors.RateLimitError,
  CircuitOpenError: errors.CircuitOpenError,
  UpstreamError:    errors.UpstreamError,
  ConfigError:      errors.ConfigError,
  errorHandler:     errors.errorHandler,

  // Environment schema
  validateEnvironment: envSchema.validateEnvironment,
  assertEnvironment:   envSchema.assertEnvironment,
  REQUIRED_VARS:       envSchema.REQUIRED_VARS,
  OPTIONAL_VARS:       envSchema.OPTIONAL_VARS,

  // Sub-module access
  globals,
  domains,
  errors,
  envSchema,
};
