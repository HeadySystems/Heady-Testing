'use strict';

/**
 * @fileoverview Connection Pool for HeadyStack
 * Generic connection pooling with min/max sizing, acquire timeout,
 * idle timeout, and runtime statistics.
 *
 * @module resilience/pool
 */

const { EventEmitter } = require('events');
const logger = require('../utils/logger');

/**
 * @class ConnectionPool
 * @extends EventEmitter
 * @description Generic connection pool supporting any resource that has
 * an async factory function and a destroy function.
 */
class ConnectionPool extends EventEmitter {
  /**
   * @param {object} opts
   * @param {Function} opts.factory           - Async () => connection
   * @param {Function} [opts.destroyer]       - Async (conn) => void
   * @param {Function} [opts.validator]       - Async (conn) => boolean
   * @param {number}   [opts.min=2]           - Minimum connections to pre-warm
   * @param {number}   [opts.max=20]          - Maximum concurrent connections
   * @param {number}   [opts.acquireTimeout=5000] - Ms to wait for an available conn
   * @param {number}   [opts.idleTimeout=30000]   - Ms before idle conn is destroyed
   * @param {string}   [opts.name='pool']     - Pool name for logging
   */
  constructor(opts = {}) {
    super();

    if (typeof opts.factory !== 'function') {
      throw new TypeError('ConnectionPool requires opts.factory (async function)');
    }

    this._factory        = opts.factory;
    this._destroyer      = opts.destroyer  ?? (async () => {});
    this._validator      = opts.validator  ?? (async () => true);
    this._min            = opts.min            ?? 2;
    this._max            = opts.max            ?? 20;
    this._acquireTimeout = opts.acquireTimeout ?? 5000;
    this._idleTimeout    = opts.idleTimeout    ?? 30000;
    this._name           = opts.name           ?? 'pool';

    /** @type {object[]} - idle (available) connections */
    this._idle = [];

    /** @type {Set} - connections currently in use */
    this._active = new Set();

    /** @type {Array<{resolve: Function, reject: Function, timer: NodeJS.Timeout}>} */
    this._waiting = [];

    this._totalCreated   = 0;
    this._totalDestroyed = 0;
    this._totalAcquires  = 0;
    this._totalReleases  = 0;
    this._totalTimeouts  = 0;

    this._destroyed = false;
    this._idleTimer  = null;

    // Start idle timeout sweeper
    this._startIdleSweeper();
  }

  // ─── Initialization ─────────────────────────────────────────────────────────

  /**
   * Warms the pool to the minimum connection count.
   * @returns {Promise<void>}
   */
  async warmUp() {
    const needed = this._min - (this._idle.length + this._active.size);
    if (needed <= 0) return;

    const warmPromises = Array.from({ length: needed }, () => this._createConnection());
    const results = await Promise.allSettled(warmPromises);
    const failed = results.filter(r => r.status === 'rejected');
    if (failed.length > 0) {
      logger.logNodeActivity('POOL',
        `[${this._name}] ${failed.length} warm-up connections failed`);
    }
  }

  // ─── Connection Management ───────────────────────────────────────────────────

  /**
   * @private
   * Creates a new connection and adds it to the idle pool.
   * @returns {Promise<object>} The wrapped connection entry
   */
  async _createConnection() {
    const raw = await this._factory();
    const entry = {
      raw,
      createdAt:  Date.now(),
      lastUsedAt: Date.now(),
      id:         ++this._totalCreated,
    };
    this._idle.push(entry);
    logger.logNodeActivity('POOL',
      `[${this._name}] Created connection #${entry.id}`);
    return entry;
  }

  /**
   * @private
   * Destroys a connection entry.
   * @param {object} entry
   */
  async _destroyEntry(entry) {
    try {
      await this._destroyer(entry.raw);
    } catch (err) {
      logger.logNodeActivity('POOL',
        `[${this._name}] Error destroying connection #${entry.id}: ${err.message}`);
    } finally {
      this._totalDestroyed++;
    }
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Acquires a connection from the pool.
   * If none is available and max is not reached, creates a new one.
   * Otherwise waits up to acquireTimeout ms.
   *
   * @returns {Promise<*>} The raw connection (from factory)
   * @throws {Error} On timeout or pool destroyed
   */
  acquire() {
    if (this._destroyed) {
      return Promise.reject(new Error(`Pool [${this._name}] has been destroyed`));
    }

    this._totalAcquires++;

    // Try to get an idle connection
    const entry = this._popIdleValid();
    if (entry) {
      entry.lastUsedAt = Date.now();
      this._active.add(entry);
      return Promise.resolve(entry.raw);
    }

    // Can we create a new one?
    const total = this._idle.length + this._active.size + this._waiting.length;
    if (total < this._max) {
      return this._createConnection().then(entry => {
        // Move from idle to active
        const idx = this._idle.indexOf(entry);
        if (idx !== -1) this._idle.splice(idx, 1);
        entry.lastUsedAt = Date.now();
        this._active.add(entry);
        return entry.raw;
      });
    }

    // Wait for a release
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        const idx = this._waiting.findIndex(w => w.timer === timer);
        if (idx !== -1) this._waiting.splice(idx, 1);
        this._totalTimeouts++;
        reject(new Error(
          `[${this._name}] acquire() timed out after ${this._acquireTimeout}ms`
        ));
      }, this._acquireTimeout);

      this._waiting.push({ resolve, reject, timer });
    });
  }

  /**
   * @private
   * Pops the first valid idle connection.
   * @returns {object|null}
   */
  _popIdleValid() {
    while (this._idle.length > 0) {
      const entry = this._idle.shift();
      const age = Date.now() - entry.lastUsedAt;
      if (age < this._idleTimeout) return entry;
      // Stale — destroy async
      this._destroyEntry(entry).catch(() => {});
    }
    return null;
  }

  /**
   * Releases a connection back to the pool.
   * @param {*} rawConn - The raw connection returned by acquire()
   * @returns {Promise<void>}
   */
  async release(rawConn) {
    if (this._destroyed) {
      await this._destroyRaw(rawConn);
      return;
    }

    // Find the entry in active
    let found = null;
    for (const entry of this._active) {
      if (entry.raw === rawConn) { found = entry; break; }
    }

    if (!found) {
      logger.logNodeActivity('POOL',
        `[${this._name}] release() called with unknown connection`);
      return;
    }

    this._active.delete(found);
    this._totalReleases++;

    // Validate before returning to idle
    let valid = false;
    try {
      valid = await this._validator(found.raw);
    } catch { valid = false; }

    if (!valid) {
      await this._destroyEntry(found);
      // Replace with a new one if below min
      if (this._idle.length + this._active.size < this._min) {
        this._createConnection().catch(() => {});
      }
    } else {
      found.lastUsedAt = Date.now();
      this._idle.push(found);
    }

    // Dispatch to next waiter
    this._dispatchToWaiter();
  }

  /**
   * @private
   * Gives the next idle connection to a waiting requester.
   */
  _dispatchToWaiter() {
    if (this._waiting.length === 0) return;
    const entry = this._popIdleValid();
    if (!entry) return;

    const waiter = this._waiting.shift();
    clearTimeout(waiter.timer);
    entry.lastUsedAt = Date.now();
    this._active.add(entry);
    waiter.resolve(entry.raw);
  }

  /**
   * @private
   * Destroy a raw connection that is not tracked.
   */
  async _destroyRaw(rawConn) {
    try {
      await this._destroyer(rawConn);
    } catch { /* ignore */ }
  }

  /**
   * Fully destroys all connections and rejects pending acquires.
   * @returns {Promise<void>}
   */
  async destroy() {
    this._destroyed = true;
    if (this._idleTimer) clearInterval(this._idleTimer);

    // Reject all waiters
    while (this._waiting.length > 0) {
      const waiter = this._waiting.shift();
      clearTimeout(waiter.timer);
      waiter.reject(new Error(`Pool [${this._name}] destroyed`));
    }

    // Destroy all idle connections
    const idleDestroys = this._idle.splice(0).map(e => this._destroyEntry(e));
    await Promise.allSettled(idleDestroys);

    // Active connections will be destroyed when released
    logger.logNodeActivity('POOL', `[${this._name}] Pool destroyed`);
    this.emit('destroyed');
  }

  // ─── Idle Sweeper ────────────────────────────────────────────────────────────

  /**
   * @private
   * Periodically removes idle connections that have exceeded idleTimeout.
   */
  _startIdleSweeper() {
    const sweepInterval = Math.max(5000, Math.floor(this._idleTimeout / 4));
    this._idleTimer = setInterval(() => {
      if (this._destroyed) return;
      const now = Date.now();
      const toRemove = [];

      for (let i = this._idle.length - 1; i >= 0; i--) {
        const entry = this._idle[i];
        const age = now - entry.lastUsedAt;
        const total = this._idle.length + this._active.size;

        if (age >= this._idleTimeout && total > this._min) {
          toRemove.push(...this._idle.splice(i, 1));
        }
      }

      if (toRemove.length > 0) {
        logger.logNodeActivity('POOL',
          `[${this._name}] Sweeping ${toRemove.length} idle connections`);
        toRemove.forEach(e => this._destroyEntry(e).catch(() => {}));
      }
    }, sweepInterval);

    if (this._idleTimer.unref) this._idleTimer.unref();
  }

  // ─── Stats ───────────────────────────────────────────────────────────────────

  /**
   * Returns runtime statistics for this pool.
   * @returns {object}
   */
  getStats() {
    return {
      name:           this._name,
      active:         this._active.size,
      idle:           this._idle.length,
      waiting:        this._waiting.length,
      total:          this._active.size + this._idle.length,
      min:            this._min,
      max:            this._max,
      totalCreated:   this._totalCreated,
      totalDestroyed: this._totalDestroyed,
      totalAcquires:  this._totalAcquires,
      totalReleases:  this._totalReleases,
      totalTimeouts:  this._totalTimeouts,
      destroyed:      this._destroyed,
    };
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = { ConnectionPool };
