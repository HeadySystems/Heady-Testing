'use strict';

/**
 * @fileoverview Resilience Module Index — HeadyStack
 * Barrel export for all resilience primitives.
 *
 * @module resilience
 */

const { CircuitBreaker, STATE, REGISTERED_SERVICES, getBreaker, getAllHealth } =
  require('./circuit-breaker');

const { PHI, PRE_COMPUTED_SEQUENCE, PhiBackoff, defaultBackoff } =
  require('./exponential-backoff');

const { ConnectionPool } =
  require('./pool');

const { RateLimiter, DistributedRateLimiter, createRateLimitMiddleware } =
  require('./rate-limiter');

const { LRUCache } =
  require('./cache');

const { retry, createRetrier, BACKOFF_TYPE } =
  require('./retry');

const { AutoHeal } =
  require('./auto-heal');

module.exports = {
  // Circuit Breaker
  CircuitBreaker,
  STATE,
  REGISTERED_SERVICES,
  getBreaker,
  getAllHealth,

  // Exponential Backoff (φ)
  PHI,
  PRE_COMPUTED_SEQUENCE,
  PhiBackoff,
  defaultBackoff,

  // Connection Pool
  ConnectionPool,

  // Rate Limiter
  RateLimiter,
  DistributedRateLimiter,
  createRateLimitMiddleware,

  // LRU Cache
  LRUCache,

  // Retry
  retry,
  createRetrier,
  BACKOFF_TYPE,

  // Auto Heal
  AutoHeal,
};
