'use strict';

/**
 * @fileoverview Multi-service Circuit Breaker for HeadyStack
 * Implements the classic CLOSED → OPEN → HALF_OPEN state machine
 * with per-service configuration and global health monitoring.
 *
 * @module resilience/circuit-breaker
 */

const { EventEmitter } = require('events');
const logger = require('../utils/logger');

/** Circuit breaker states */
const STATE = Object.freeze({
  CLOSED:    'CLOSED',
  OPEN:      'OPEN',
  HALF_OPEN: 'HALF_OPEN',
});

/** Pre-registered HeadyStack services */
const REGISTERED_SERVICES = [
  'anthropic',
  'openai',
  'google',
  'groq',
  'perplexity',
  'cloudflare',
  'postgresql',
  'redis',
  'huggingface',
  'github',
  'render',
  'notion',
  'stripe',
  'edge-proxy',
  'vector-memory',
  'self-awareness',
];

/**
 * @class CircuitBreaker
 * @extends EventEmitter
 * @description Protects a named service from cascading failures.
 */
class CircuitBreaker extends EventEmitter {
  /**
   * @param {string} serviceName - Logical name of the protected service
   * @param {object} [opts={}]
   * @param {number} [opts.failureThreshold=5] - Consecutive failures before opening
   * @param {number} [opts.resetTimeout=30000] - Ms to wait in OPEN before trying HALF_OPEN
   * @param {number} [opts.halfOpenMax=3] - Max probe calls allowed in HALF_OPEN state
   */
  constructor(serviceName, opts = {}) {
    super();
    this.serviceName      = serviceName;
    this.failureThreshold = opts.failureThreshold ?? 5;
    this.resetTimeout     = opts.resetTimeout     ?? 30000;
    this.halfOpenMax      = opts.halfOpenMax       ?? 3;

    this._state           = STATE.CLOSED;
    this._failures        = 0;
    this._successes       = 0;
    this._totalCalls      = 0;
    this._halfOpenCalls   = 0;
    this._lastFailureTime = null;
    this._openedAt        = null;
    this._createdAt       = Date.now();
    this._stateHistory    = [];
  }

  // ─── Internal State Management ──────────────────────────────────────────────

  /**
   * @private
   * Transitions to a new state and records audit history.
   * @param {string} newState
   */
  _transition(newState) {
    const prev = this._state;
    if (prev === newState) return;

    this._state = newState;
    const entry = { from: prev, to: newState, at: Date.now() };
    this._stateHistory.push(entry);

    if (newState === STATE.OPEN) {
      this._openedAt = Date.now();
      this._halfOpenCalls = 0;
    } else if (newState === STATE.CLOSED) {
      this._failures = 0;
      this._halfOpenCalls = 0;
    } else if (newState === STATE.HALF_OPEN) {
      this._halfOpenCalls = 0;
    }

    logger.logNodeActivity('CIRCUIT-BREAKER',
      `[${this.serviceName}] ${prev} → ${newState}`);
    this.emit('stateChange', { service: this.serviceName, ...entry });
  }

  /**
   * @private
   * Checks whether we should transition from OPEN → HALF_OPEN.
   */
  _checkReset() {
    if (this._state === STATE.OPEN) {
      const elapsed = Date.now() - this._openedAt;
      if (elapsed >= this.resetTimeout) {
        this._transition(STATE.HALF_OPEN);
      }
    }
  }

  /**
   * @private
   * Records a successful call outcome.
   */
  _recordSuccess() {
    this._successes++;
    if (this._state === STATE.HALF_OPEN) {
      this._halfOpenCalls++;
      if (this._halfOpenCalls >= this.halfOpenMax) {
        this._transition(STATE.CLOSED);
      }
    } else if (this._state === STATE.CLOSED) {
      // Reset consecutive failure counter on success
      this._failures = 0;
    }
  }

  /**
   * @private
   * Records a failed call outcome.
   */
  _recordFailure() {
    this._failures++;
    this._lastFailureTime = Date.now();

    if (this._state === STATE.HALF_OPEN) {
      // Any failure in HALF_OPEN re-opens the circuit
      this._transition(STATE.OPEN);
    } else if (this._state === STATE.CLOSED) {
      if (this._failures >= this.failureThreshold) {
        this._transition(STATE.OPEN);
      }
    }
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Wraps a function call with circuit-breaker protection.
   * @param {Function} fn - Async function to execute
   * @returns {Promise<*>} Result of fn()
   * @throws {Error} If circuit is OPEN or fn throws and threshold exceeded
   */
  async execute(fn) {
    this._checkReset();
    this._totalCalls++;

    if (this._state === STATE.OPEN) {
      const err = new Error(
        `Circuit OPEN for service "${this.serviceName}" — rejecting call`
      );
      err.code = 'CIRCUIT_OPEN';
      err.service = this.serviceName;
      this.emit('rejected', { service: this.serviceName, at: Date.now() });
      throw err;
    }

    if (this._state === STATE.HALF_OPEN && this._halfOpenCalls >= this.halfOpenMax) {
      const err = new Error(
        `Circuit HALF_OPEN probe limit reached for "${this.serviceName}"`
      );
      err.code = 'CIRCUIT_HALF_OPEN_LIMIT';
      err.service = this.serviceName;
      throw err;
    }

    try {
      const result = await fn();
      this._recordSuccess();
      return result;
    } catch (err) {
      this._recordFailure();
      throw err;
    }
  }

  /**
   * Returns the current circuit state.
   * @returns {'CLOSED'|'OPEN'|'HALF_OPEN'}
   */
  getState() {
    this._checkReset();
    return this._state;
  }

  /**
   * Returns detailed statistics for this breaker.
   * @returns {object}
   */
  getStats() {
    this._checkReset();
    return {
      service:          this.serviceName,
      state:            this._state,
      failures:         this._failures,
      successes:        this._successes,
      totalCalls:       this._totalCalls,
      halfOpenCalls:    this._halfOpenCalls,
      lastFailureTime:  this._lastFailureTime,
      openedAt:         this._openedAt,
      createdAt:        this._createdAt,
      stateHistory:     this._stateHistory.slice(-20), // last 20 transitions
      failureThreshold: this.failureThreshold,
      resetTimeout:     this.resetTimeout,
      halfOpenMax:      this.halfOpenMax,
    };
  }

  /**
   * Manually force-closes the circuit (for use by AutoHeal).
   */
  forceClose() {
    this._transition(STATE.CLOSED);
  }

  /**
   * Manually force-opens the circuit (for maintenance).
   */
  forceOpen() {
    this._transition(STATE.OPEN);
  }
}

// ─── Breaker Registry ────────────────────────────────────────────────────────

/** @type {Map<string, CircuitBreaker>} */
const _registry = new Map();

/**
 * Returns (or creates) the CircuitBreaker for a given service name.
 * Pre-registered services are automatically seeded on module load.
 *
 * @param {string} serviceName
 * @param {object} [opts={}] - Passed to CircuitBreaker constructor on first creation
 * @returns {CircuitBreaker}
 */
function getBreaker(serviceName, opts = {}) {
  if (!_registry.has(serviceName)) {
    const breaker = new CircuitBreaker(serviceName, opts);
    _registry.set(serviceName, breaker);
    logger.logNodeActivity('CIRCUIT-BREAKER',
      `Registered breaker for service: ${serviceName}`);
  }
  return _registry.get(serviceName);
}

/**
 * Returns health status of all registered circuit breakers.
 * @returns {object[]} Array of stat objects, one per service
 */
function getAllHealth() {
  const health = [];
  for (const [, breaker] of _registry) {
    const stats = breaker.getStats();
    health.push({
      ...stats,
      healthy: stats.state === STATE.CLOSED,
    });
  }
  return health;
}

// ─── Pre-register all HeadyStack services ───────────────────────────────────
for (const svc of REGISTERED_SERVICES) {
  getBreaker(svc);
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  CircuitBreaker,
  STATE,
  REGISTERED_SERVICES,
  getBreaker,
  getAllHealth,
};
