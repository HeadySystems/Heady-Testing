'use strict';

/**
 * @fileoverview Token-Bucket Rate Limiter for HeadyStack
 * Implements the classic token bucket algorithm with burst support
 * and an Express middleware factory.
 *
 * @module resilience/rate-limiter
 */

const logger = require('../utils/logger');

/**
 * @class RateLimiter
 * @description Token-bucket rate limiter. Tokens refill continuously over
 * the configured interval. Burst capacity allows temporary spikes above
 * the sustained rate.
 */
class RateLimiter {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.tokensPerInterval=120] - Tokens added per interval
   * @param {number} [opts.interval=60000]         - Refill interval in ms
   * @param {number} [opts.maxBurst=200]           - Maximum token bucket capacity
   * @param {string} [opts.name='default']         - Limiter name for logging
   */
  constructor(opts = {}) {
    this.tokensPerInterval = opts.tokensPerInterval ?? 120;
    this.interval          = opts.interval          ?? 60000;
    this.maxBurst          = opts.maxBurst          ?? 200;
    this.name              = opts.name              ?? 'default';

    // Start full
    this._tokens    = this.maxBurst;
    this._lastRefill = Date.now();

    // Stats
    this._totalConsumed = 0;
    this._totalRejected = 0;
    this._totalRefilled = 0;
  }

  // ─── Internal ────────────────────────────────────────────────────────────────

  /**
   * @private
   * Refills tokens based on elapsed time since last refill.
   */
  _refill() {
    const now     = Date.now();
    const elapsed = now - this._lastRefill;
    if (elapsed <= 0) return;

    const rate  = this.tokensPerInterval / this.interval; // tokens per ms
    const added = elapsed * rate;

    if (added >= 1) {
      const prev    = this._tokens;
      this._tokens  = Math.min(this._tokens + added, this.maxBurst);
      this._totalRefilled += (this._tokens - prev);
      this._lastRefill = now;
    }
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Attempts to consume tokens from the bucket.
   * @param {number} [tokens=1] - Number of tokens to consume
   * @returns {boolean} true if tokens were available and consumed
   */
  tryConsume(tokens = 1) {
    if (tokens < 0) throw new RangeError('tokens must be >= 0');

    this._refill();

    if (this._tokens >= tokens) {
      this._tokens -= tokens;
      this._totalConsumed += tokens;
      return true;
    }

    this._totalRejected++;
    return false;
  }

  /**
   * Returns the current number of available tokens.
   * @returns {number}
   */
  getTokens() {
    this._refill();
    return this._tokens;
  }

  /**
   * Returns statistics for this rate limiter.
   * @returns {object}
   */
  getStats() {
    this._refill();
    return {
      name:              this.name,
      tokens:            this._tokens,
      maxBurst:          this.maxBurst,
      tokensPerInterval: this.tokensPerInterval,
      interval:          this.interval,
      totalConsumed:     this._totalConsumed,
      totalRejected:     this._totalRejected,
      totalRefilled:     this._totalRefilled,
      utilizationPct:    Math.round(
        (1 - this._tokens / this.maxBurst) * 100
      ),
    };
  }

  /**
   * Resets the bucket to full capacity.
   */
  reset() {
    this._tokens    = this.maxBurst;
    this._lastRefill = Date.now();
  }
}

// ─── Per-IP / Per-Key Limiter Store ─────────────────────────────────────────

/**
 * @class DistributedRateLimiter
 * @description Manages per-key (e.g. per-IP) rate limiters with automatic
 * eviction of stale entries to prevent memory leaks.
 */
class DistributedRateLimiter {
  /**
   * @param {object} [opts={}] - Same as RateLimiter opts; applied to each key
   * @param {number} [opts.evictAfterMs=300000] - Evict inactive entries after N ms
   */
  constructor(opts = {}) {
    this._opts       = opts;
    this._evictAfter = opts.evictAfterMs ?? 300000; // 5 min
    this._limiters   = new Map(); // key → { limiter, lastActivity }
    this._sweepTimer = setInterval(() => this._sweep(), 60000);
    if (this._sweepTimer.unref) this._sweepTimer.unref();
  }

  /**
   * @param {string} key - e.g. IP address or API key
   * @returns {RateLimiter}
   */
  getLimiter(key) {
    if (!this._limiters.has(key)) {
      this._limiters.set(key, {
        limiter:      new RateLimiter({ ...this._opts, name: key }),
        lastActivity: Date.now(),
      });
    }
    const entry = this._limiters.get(key);
    entry.lastActivity = Date.now();
    return entry.limiter;
  }

  /**
   * @param {string} key
   * @param {number} [tokens=1]
   * @returns {boolean}
   */
  tryConsume(key, tokens = 1) {
    return this.getLimiter(key).tryConsume(tokens);
  }

  /**
   * @private
   */
  _sweep() {
    const cutoff = Date.now() - this._evictAfter;
    for (const [key, entry] of this._limiters) {
      if (entry.lastActivity < cutoff) {
        this._limiters.delete(key);
      }
    }
  }

  /** @returns {number} */
  get size() { return this._limiters.size; }

  destroy() {
    clearInterval(this._sweepTimer);
    this._limiters.clear();
  }
}

// ─── Express Middleware ───────────────────────────────────────────────────────

/**
 * Creates an Express rate-limit middleware backed by a DistributedRateLimiter.
 *
 * @param {object} [opts={}] - RateLimiter options
 * @param {Function} [opts.keyFn] - (req) => string — defaults to IP
 * @param {number}   [opts.tokens=1] - Tokens consumed per request
 * @param {string}   [opts.message='Too Many Requests']
 * @returns {Function} Express middleware (req, res, next)
 */
function createRateLimitMiddleware(opts = {}) {
  const {
    keyFn   = (req) => req.ip || req.connection.remoteAddress || 'unknown',
    tokens  = 1,
    message = 'Too Many Requests',
    ...limiterOpts
  } = opts;

  const distributed = new DistributedRateLimiter(limiterOpts);

  /**
   * @param {import('express').Request}  req
   * @param {import('express').Response} res
   * @param {Function} next
   */
  function rateLimitMiddleware(req, res, next) {
    const key     = keyFn(req);
    const allowed = distributed.tryConsume(key, tokens);
    const limiter = distributed.getLimiter(key);
    const avail   = limiter.getTokens();

    res.setHeader('X-RateLimit-Limit',     limiter.maxBurst);
    res.setHeader('X-RateLimit-Remaining', Math.floor(avail));
    res.setHeader('X-RateLimit-Interval',  limiter.interval);

    if (!allowed) {
      logger.logNodeActivity('RATE-LIMITER',
        `Request rejected for key=${key} (tokens available: ${Math.floor(avail)})`);
      res.setHeader('Retry-After',
        Math.ceil(limiter.interval / limiter.tokensPerInterval));
      return res.status(429).json({
        error:   'rate_limit_exceeded',
        message,
        retryAfterMs: Math.ceil(
          (tokens - avail) * (limiter.interval / limiter.tokensPerInterval)
        ),
      });
    }

    next();
  }

  rateLimitMiddleware._distributed = distributed;
  return rateLimitMiddleware;
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  RateLimiter,
  DistributedRateLimiter,
  createRateLimitMiddleware,
};
