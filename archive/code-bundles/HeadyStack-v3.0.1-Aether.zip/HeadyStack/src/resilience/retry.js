'use strict';

/**
 * @fileoverview Generic Retry Wrapper for HeadyStack
 * Supports phi (golden-ratio), exponential, and linear backoff strategies.
 * Uses PhiBackoff by default.
 *
 * @module resilience/retry
 */

const { PhiBackoff } = require('./exponential-backoff');
const logger = require('../utils/logger');

/** @constant {object} BACKOFF_TYPES */
const BACKOFF_TYPE = Object.freeze({
  PHI:         'phi',
  EXPONENTIAL: 'exponential',
  LINEAR:      'linear',
});

/**
 * @private
 * Computes delay for a standard exponential backoff.
 * @param {number} attempt   - Zero-indexed attempt
 * @param {number} baseDelay - Base delay in ms
 * @param {number} maxDelay  - Max delay cap in ms
 * @param {boolean} jitter
 * @returns {number}
 */
function _exponentialDelay(attempt, baseDelay, maxDelay, jitter) {
  const raw = Math.min(Math.pow(2, attempt) * baseDelay, maxDelay);
  if (!jitter) return Math.round(raw);
  const j = 0.9 + Math.random() * 0.2;
  return Math.round(Math.min(raw * j, maxDelay));
}

/**
 * @private
 * Computes delay for linear backoff.
 * @param {number} attempt
 * @param {number} baseDelay
 * @param {number} maxDelay
 * @returns {number}
 */
function _linearDelay(attempt, baseDelay, maxDelay) {
  return Math.min((attempt + 1) * baseDelay, maxDelay);
}

/**
 * @private
 * @param {number} ms
 * @returns {Promise<void>}
 */
function _sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Retries an async function with configurable backoff strategy.
 *
 * @param {Function} fn                    - Async function to retry. Receives (attempt: number, lastError?: Error).
 * @param {object}   [opts={}]
 * @param {number}   [opts.maxRetries=3]   - Maximum retry count (total = maxRetries + 1 calls)
 * @param {string}   [opts.backoffType='phi'] - 'phi' | 'exponential' | 'linear'
 * @param {number}   [opts.baseDelay=1000] - Base delay in ms
 * @param {number}   [opts.maxDelay=30000] - Max delay cap in ms
 * @param {boolean}  [opts.jitter=true]    - Apply jitter
 * @param {Function} [opts.onRetry]        - (attempt, delay, err) => void — called before each retry
 * @param {Function} [opts.shouldRetry]    - (err) => boolean — return false to abort
 * @param {string}   [opts.label]          - Label for log messages
 * @returns {Promise<*>} Resolves with fn result
 * @throws {Error} Re-throws last error after exhausting retries
 *
 * @example
 * const result = await retry(
 *   async () => fetch('https://api.example.com/data'),
 *   { maxRetries: 5, backoffType: 'phi', label: 'fetch-data' }
 * );
 */
async function retry(fn, opts = {}) {
  const maxRetries  = opts.maxRetries  ?? 3;
  const backoffType = opts.backoffType ?? BACKOFF_TYPE.PHI;
  const baseDelay   = opts.baseDelay   ?? 1000;
  const maxDelay    = opts.maxDelay    ?? 30000;
  const jitter      = opts.jitter      !== undefined ? opts.jitter : true;
  const onRetry     = opts.onRetry     ?? null;
  const shouldRetry = opts.shouldRetry ?? (() => true);
  const label       = opts.label       ?? 'retry';

  // Build delay function
  let delayFn;
  if (backoffType === BACKOFF_TYPE.PHI) {
    const backoff = new PhiBackoff({ baseDelay, maxDelay, jitter });
    delayFn = (attempt) => backoff.getDelay(attempt);
  } else if (backoffType === BACKOFF_TYPE.EXPONENTIAL) {
    delayFn = (attempt) => _exponentialDelay(attempt, baseDelay, maxDelay, jitter);
  } else if (backoffType === BACKOFF_TYPE.LINEAR) {
    delayFn = (attempt) => _linearDelay(attempt, baseDelay, maxDelay);
  } else {
    throw new Error(`Unknown backoffType: "${backoffType}"`);
  }

  let lastError;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn(attempt, lastError);
    } catch (err) {
      lastError = err;

      const isLast = attempt >= maxRetries;
      const abort  = !shouldRetry(err);

      if (isLast || abort) {
        logger.logNodeActivity('RETRY',
          `[${label}] Failed after ${attempt + 1} attempt(s): ${err.message}`);
        throw err;
      }

      const delay = delayFn(attempt);

      if (onRetry) {
        try { onRetry(attempt + 1, delay, err); } catch { /* ignore */ }
      }

      logger.logNodeActivity('RETRY',
        `[${label}] Attempt ${attempt + 1}/${maxRetries + 1} failed ` +
        `(${backoffType}, next in ${delay}ms): ${err.message}`);

      await _sleep(delay);
    }
  }

  throw lastError;
}

/**
 * Creates a reusable retry wrapper with pre-configured defaults.
 * @param {object} defaults - Default options for retry()
 * @returns {Function} (fn, opts?) => Promise
 */
function createRetrier(defaults = {}) {
  return (fn, opts = {}) => retry(fn, { ...defaults, ...opts });
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  retry,
  createRetrier,
  BACKOFF_TYPE,
};
