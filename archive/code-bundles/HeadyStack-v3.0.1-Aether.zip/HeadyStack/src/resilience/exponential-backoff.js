'use strict';

/**
 * @fileoverview Golden-Ratio (φ = 1.618…) Exponential Backoff for HeadyStack
 * Uses the mathematical constant phi to generate a naturally progressive
 * delay sequence: 1s → 1.6s → 2.6s → 4.2s → 6.9s → 11.1s → 17.9s → 29s
 *
 * @module resilience/exponential-backoff
 */

const logger = require('../utils/logger');

/** @constant {number} PHI - The golden ratio φ = (1 + √5) / 2 */
const PHI = 1.618033988749895;

/** @constant {number[]} PRE_COMPUTED_SEQUENCE - Delay sequence in seconds for attempts 0–7 */
const PRE_COMPUTED_SEQUENCE = [1, 1.6, 2.6, 4.2, 6.9, 11.1, 17.9, 29.0];

/**
 * @class PhiBackoff
 * @description Computes backoff delays using the golden ratio and optionally
 * retries an async function with those delays.
 */
class PhiBackoff {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.baseDelay=1000]   - Base delay in ms (first attempt)
   * @param {number} [opts.maxDelay=30000]   - Maximum delay cap in ms
   * @param {number} [opts.maxRetries=8]     - Maximum number of retry attempts
   * @param {boolean} [opts.jitter=true]     - Apply ±10% random jitter
   */
  constructor(opts = {}) {
    this.baseDelay  = opts.baseDelay  ?? 1000;
    this.maxDelay   = opts.maxDelay   ?? 30000;
    this.maxRetries = opts.maxRetries ?? 8;
    this.jitter     = opts.jitter     !== undefined ? opts.jitter : true;
  }

  /**
   * Computes the delay for a given retry attempt using φ^attempt * baseDelay.
   * @param {number} attempt - Zero-indexed attempt number (0 = first retry)
   * @returns {number} Delay in milliseconds (with jitter if enabled)
   */
  getDelay(attempt) {
    const raw = Math.min(
      Math.pow(PHI, attempt) * this.baseDelay,
      this.maxDelay
    );

    if (!this.jitter) return Math.round(raw);

    // ±10% random jitter
    const jitterFactor = 0.9 + Math.random() * 0.2; // [0.9, 1.1]
    return Math.round(Math.min(raw * jitterFactor, this.maxDelay));
  }

  /**
   * Returns the full delay sequence for all configured retry attempts.
   * @returns {number[]} Array of delays in ms
   */
  getSequence() {
    return Array.from({ length: this.maxRetries }, (_, i) => this.getDelay(i));
  }

  /**
   * Executes an async function, retrying with phi-based backoff on failure.
   * @param {Function} fn - Async function to execute. Receives (attempt, lastError).
   * @param {object} [opts={}]
   * @param {number}   [opts.maxRetries]  - Override instance maxRetries for this call
   * @param {Function} [opts.onRetry]     - Called before each retry: (attempt, delay, err) => void
   * @param {Function} [opts.shouldRetry] - (err) => boolean. Return false to abort retries.
   * @returns {Promise<*>} Resolves with fn result on success
   * @throws {Error} Re-throws last error after exhausting retries
   */
  async execute(fn, opts = {}) {
    const maxRetries  = opts.maxRetries  ?? this.maxRetries;
    const onRetry     = opts.onRetry     ?? null;
    const shouldRetry = opts.shouldRetry ?? (() => true);

    let lastError;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        return await fn(attempt, lastError);
      } catch (err) {
        lastError = err;

        const isLastAttempt = attempt >= maxRetries;
        if (isLastAttempt || !shouldRetry(err)) {
          logger.logNodeActivity('PHI-BACKOFF',
            `Exhausted retries (${attempt}/${maxRetries}): ${err.message}`);
          throw err;
        }

        const delay = this.getDelay(attempt);

        if (onRetry) {
          try { onRetry(attempt + 1, delay, err); } catch { /* ignore */ }
        }

        logger.logNodeActivity('PHI-BACKOFF',
          `Attempt ${attempt + 1}/${maxRetries} failed. Retrying in ${delay}ms. ` +
          `Error: ${err.message}`);

        await _sleep(delay);
      }
    }

    throw lastError;
  }
}

// ─── Utilities ───────────────────────────────────────────────────────────────

/**
 * @private
 * @param {number} ms
 * @returns {Promise<void>}
 */
function _sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ─── Singleton default instance ──────────────────────────────────────────────

/** Default PhiBackoff instance with production-ready settings */
const defaultBackoff = new PhiBackoff();

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  PHI,
  PRE_COMPUTED_SEQUENCE,
  PhiBackoff,
  defaultBackoff,
};
