'use strict';

/**
 * @fileoverview Auto-Healing Self-Recovery Mesh for HeadyStack
 * Monitors all circuit breakers, detects degraded services, and
 * attempts automated recovery via the conductor or direct probes.
 *
 * @module resilience/auto-heal
 */

const { EventEmitter } = require('events');
const { getAllHealth, getBreaker, STATE } = require('./circuit-breaker');
const { retry } = require('./retry');
const logger = require('../utils/logger');

/** @constant {number} MAX_HEAL_HISTORY - Maximum healing events to retain */
const MAX_HEAL_HISTORY = 200;

/**
 * @class AutoHeal
 * @extends EventEmitter
 * @description Periodically checks all registered circuit breakers.
 * When a service is OPEN, it attempts to probe and restore it.
 */
class AutoHeal extends EventEmitter {
  /**
   * @param {object|null} [conductor=null] - Reference to the HeadyStack conductor
   */
  constructor(conductor = null) {
    super();

    this._conductor    = conductor;
    this._intervalId   = null;
    this._running      = false;
    this._healHistory  = [];
    this._healAttempts = {};  // serviceName → { count, lastAt, successes, failures }
    this._createdAt    = Date.now();

    /** @type {Map<string, Function>} - Custom heal probes by service name */
    this._customProbes = new Map();
  }

  // ─── Configuration ───────────────────────────────────────────────────────────

  /**
   * Sets or replaces the conductor reference.
   * @param {object} conductor
   */
  setConductor(conductor) {
    this._conductor = conductor;
  }

  /**
   * Registers a custom probe function for a specific service.
   * The probe should throw on failure, resolve on success.
   * @param {string}   serviceName
   * @param {Function} probeFn - async () => void
   */
  registerProbe(serviceName, probeFn) {
    this._customProbes.set(serviceName, probeFn);
    logger.logNodeActivity('AUTO-HEAL',
      `Registered custom probe for: ${serviceName}`);
  }

  // ─── Lifecycle ───────────────────────────────────────────────────────────────

  /**
   * Starts the auto-heal monitor loop.
   * @param {number} [intervalMs=30000] - How often to check, in ms
   * @returns {AutoHeal} this (for chaining)
   */
  start(intervalMs = 30000) {
    if (this._running) return this;

    this._running    = true;
    this._intervalId = setInterval(() => this.check(), intervalMs);
    if (this._intervalId.unref) this._intervalId.unref();

    logger.logNodeActivity('AUTO-HEAL',
      `Auto-heal mesh started (interval: ${intervalMs}ms)`);

    // Run an immediate check
    this.check().catch(err =>
      logger.logNodeActivity('AUTO-HEAL', `Initial check error: ${err.message}`)
    );

    return this;
  }

  /**
   * Stops the auto-heal monitor loop.
   * @returns {AutoHeal} this
   */
  stop() {
    if (!this._running) return this;

    this._running = false;
    if (this._intervalId) {
      clearInterval(this._intervalId);
      this._intervalId = null;
    }

    logger.logNodeActivity('AUTO-HEAL', 'Auto-heal mesh stopped');
    return this;
  }

  // ─── Core Check & Heal ───────────────────────────────────────────────────────

  /**
   * Inspects all circuit breakers and attempts healing for any that are OPEN.
   * @returns {Promise<object[]>} Array of healing results
   */
  async check() {
    const health   = getAllHealth();
    const degraded = health.filter(h => h.state === STATE.OPEN);

    if (degraded.length === 0) return [];

    logger.logNodeActivity('AUTO-HEAL',
      `Detected ${degraded.length} degraded service(s): ` +
      degraded.map(h => h.service).join(', ')
    );

    const results = await Promise.allSettled(
      degraded.map(h => this.heal(h.service))
    );

    return results.map((r, i) => ({
      service: degraded[i].service,
      success: r.status === 'fulfilled' && r.value?.healed === true,
      result:  r.status === 'fulfilled' ? r.value : { error: r.reason?.message },
    }));
  }

  /**
   * Attempts to restore a single degraded service.
   * @param {string} serviceName
   * @returns {Promise<object>} { healed: boolean, service, method, duration }
   */
  async heal(serviceName) {
    const breaker = getBreaker(serviceName);
    const startAt = Date.now();

    // Track attempt
    if (!this._healAttempts[serviceName]) {
      this._healAttempts[serviceName] = {
        count: 0, lastAt: null, successes: 0, failures: 0
      };
    }
    const track = this._healAttempts[serviceName];
    track.count++;
    track.lastAt = Date.now();

    logger.logNodeActivity('AUTO-HEAL',
      `Attempting to heal service: ${serviceName} (attempt #${track.count})`);

    let healed = false;
    let method = 'probe';

    try {
      // 1. Try custom probe if registered
      if (this._customProbes.has(serviceName)) {
        await retry(this._customProbes.get(serviceName), {
          maxRetries: 2,
          baseDelay:  2000,
          backoffType: 'phi',
          label: `heal:${serviceName}:custom-probe`,
        });
        healed = true;
        method = 'custom-probe';

      // 2. Try conductor health check
      } else if (this._conductor && typeof this._conductor.healthCheck === 'function') {
        await this._conductor.healthCheck(serviceName);
        healed = true;
        method = 'conductor-health-check';

      // 3. Generic default: just force the circuit into HALF_OPEN
      } else {
        // Let the natural reset cycle take over — just log
        const stats = breaker.getStats();
        const elapsed = Date.now() - (stats.openedAt || 0);
        if (elapsed >= stats.resetTimeout) {
          breaker.forceClose();
          healed = true;
          method = 'force-close-timeout-elapsed';
        } else {
          method = 'awaiting-natural-reset';
          healed = false;
        }
      }

      if (healed) {
        track.successes++;
        breaker.forceClose();
        logger.logNodeActivity('AUTO-HEAL',
          `Service "${serviceName}" healed via ${method}`);
        this.emit('healed', { service: serviceName, method, at: Date.now() });
      }

    } catch (err) {
      track.failures++;
      logger.logNodeActivity('AUTO-HEAL',
        `Failed to heal "${serviceName}": ${err.message}`);
      this.emit('healFailed', { service: serviceName, error: err.message, at: Date.now() });
    }

    const result = {
      healed,
      service:  serviceName,
      method,
      duration: Date.now() - startAt,
      attempt:  track.count,
      at:       Date.now(),
    };

    this._recordHistory(result);
    return result;
  }

  // ─── History ─────────────────────────────────────────────────────────────────

  /**
   * @private
   */
  _recordHistory(entry) {
    this._healHistory.push(entry);
    if (this._healHistory.length > MAX_HEAL_HISTORY) {
      this._healHistory.shift();
    }
  }

  /**
   * Returns the healing history log.
   * @returns {object[]}
   */
  getHealingHistory() {
    return [...this._healHistory];
  }

  /**
   * Returns summary statistics for auto-heal activity.
   * @returns {object}
   */
  getStats() {
    const allHealth = getAllHealth();
    return {
      running:       this._running,
      createdAt:     this._createdAt,
      servicesTotal: allHealth.length,
      servicesOpen:  allHealth.filter(h => h.state === STATE.OPEN).length,
      servicesClosed: allHealth.filter(h => h.state === STATE.CLOSED).length,
      servicesHalfOpen: allHealth.filter(h => h.state === STATE.HALF_OPEN).length,
      healAttempts:  { ...this._healAttempts },
      historyCount:  this._healHistory.length,
    };
  }

  // ─── Express Routes ───────────────────────────────────────────────────────────

  /**
   * Registers auto-heal management routes on an Express app.
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    app.get('/api/autoheal/status', (req, res) => {
      res.json(this.getStats());
    });

    app.get('/api/autoheal/history', (req, res) => {
      res.json(this.getHealingHistory());
    });

    app.post('/api/autoheal/heal/:service', async (req, res) => {
      const { service } = req.params;
      try {
        const result = await this.heal(service);
        res.json(result);
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    app.post('/api/autoheal/check', async (req, res) => {
      try {
        const results = await this.check();
        res.json({ results });
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    logger.logNodeActivity('AUTO-HEAL', 'Auto-heal routes registered');
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = { AutoHeal };
