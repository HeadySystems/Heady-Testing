'use strict';

/**
 * @fileoverview In-Memory LRU Cache for HeadyStack
 * Doubly-linked list + hashmap LRU eviction with per-entry TTL support
 * and comprehensive hit/miss statistics.
 *
 * @module resilience/cache
 */

const logger = require('../utils/logger');

/**
 * @private
 * @class LRUNode
 * @description Doubly-linked list node for O(1) LRU eviction.
 */
class LRUNode {
  constructor(key, value, expiry) {
    this.key   = key;
    this.value = value;
    this.expiry = expiry; // absolute timestamp in ms, or null for immortal
    this.prev  = null;
    this.next  = null;
  }
}

/**
 * @class LRUCache
 * @description In-memory LRU cache with per-entry TTL and global stats.
 * O(1) get/set/delete via doubly-linked list + Map.
 */
class LRUCache {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.maxSize=1000]   - Maximum number of entries
   * @param {number} [opts.ttlMs=300000]   - Default TTL in ms (5 min)
   * @param {string} [opts.name='cache']   - Cache name for logging
   */
  constructor(opts = {}) {
    this.maxSize  = opts.maxSize ?? 1000;
    this.ttlMs    = opts.ttlMs  ?? 300000;
    this.name     = opts.name   ?? 'cache';

    /** @type {Map<string, LRUNode>} */
    this._map  = new Map();

    // Sentinel head and tail for O(1) operations
    this._head = new LRUNode(null, null, null); // most-recently-used side
    this._tail = new LRUNode(null, null, null); // least-recently-used side
    this._head.next = this._tail;
    this._tail.prev = this._head;

    // Stats
    this._hits       = 0;
    this._misses     = 0;
    this._sets       = 0;
    this._evictions  = 0;
    this._expirations = 0;
  }

  // ─── Linked List Helpers ─────────────────────────────────────────────────────

  /** @private */
  _removeNode(node) {
    node.prev.next = node.next;
    node.next.prev = node.prev;
  }

  /** @private — insert immediately after head (MRU position) */
  _insertFront(node) {
    node.prev      = this._head;
    node.next      = this._head.next;
    this._head.next.prev = node;
    this._head.next = node;
  }

  /** @private — move existing node to MRU position */
  _moveToFront(node) {
    this._removeNode(node);
    this._insertFront(node);
  }

  // ─── Public API ─────────────────────────────────────────────────────────────

  /**
   * Retrieves a value by key.
   * @param {string} key
   * @returns {*} The cached value, or undefined on miss/expiry
   */
  get(key) {
    const node = this._map.get(key);
    if (!node) {
      this._misses++;
      return undefined;
    }

    // Check TTL
    if (node.expiry !== null && Date.now() > node.expiry) {
      this._expire(key, node);
      this._misses++;
      return undefined;
    }

    this._hits++;
    this._moveToFront(node);
    return node.value;
  }

  /**
   * Stores a key-value pair.
   * @param {string} key
   * @param {*}      value
   * @param {number} [ttlMs] - Per-entry TTL override in ms. Pass 0 for immortal.
   */
  set(key, value, ttlMs) {
    this._sets++;

    const effectiveTtl = ttlMs !== undefined ? ttlMs : this.ttlMs;
    const expiry = effectiveTtl > 0 ? Date.now() + effectiveTtl : null;

    if (this._map.has(key)) {
      const node  = this._map.get(key);
      node.value  = value;
      node.expiry = expiry;
      this._moveToFront(node);
      return;
    }

    // Evict LRU if at capacity
    if (this._map.size >= this.maxSize) {
      this._evictLRU();
    }

    const node = new LRUNode(key, value, expiry);
    this._map.set(key, node);
    this._insertFront(node);
  }

  /**
   * Deletes a key.
   * @param {string} key
   * @returns {boolean} true if key existed
   */
  delete(key) {
    const node = this._map.get(key);
    if (!node) return false;

    this._removeNode(node);
    this._map.delete(key);
    return true;
  }

  /**
   * Checks if a key exists and is not expired.
   * @param {string} key
   * @returns {boolean}
   */
  has(key) {
    const node = this._map.get(key);
    if (!node) return false;
    if (node.expiry !== null && Date.now() > node.expiry) {
      this._expire(key, node);
      return false;
    }
    return true;
  }

  /**
   * Removes all entries.
   */
  clear() {
    this._map.clear();
    this._head.next = this._tail;
    this._tail.prev = this._head;
    logger.logNodeActivity('LRU-CACHE', `[${this.name}] Cache cleared`);
  }

  /**
   * Returns runtime statistics.
   * @returns {object}
   */
  getStats() {
    const total    = this._hits + this._misses;
    const hitRate  = total > 0 ? parseFloat((this._hits / total).toFixed(4)) : 0;
    return {
      name:         this.name,
      size:         this._map.size,
      maxSize:      this.maxSize,
      ttlMs:        this.ttlMs,
      hits:         this._hits,
      misses:       this._misses,
      sets:         this._sets,
      evictions:    this._evictions,
      expirations:  this._expirations,
      hitRate,
      hitRatePct:   Math.round(hitRate * 100),
    };
  }

  // ─── Internals ───────────────────────────────────────────────────────────────

  /**
   * @private
   * Evicts the least-recently-used entry.
   */
  _evictLRU() {
    const lru = this._tail.prev;
    if (lru === this._head) return; // empty
    this._removeNode(lru);
    this._map.delete(lru.key);
    this._evictions++;
  }

  /**
   * @private
   * Removes an expired node.
   * @param {string}  key
   * @param {LRUNode} node
   */
  _expire(key, node) {
    this._removeNode(node);
    this._map.delete(key);
    this._expirations++;
  }

  /**
   * Actively purges all expired entries (optional maintenance sweep).
   * @returns {number} Number of entries removed
   */
  sweepExpired() {
    const now = Date.now();
    let removed = 0;
    for (const [key, node] of this._map) {
      if (node.expiry !== null && now > node.expiry) {
        this._expire(key, node);
        removed++;
      }
    }
    if (removed > 0) {
      logger.logNodeActivity('LRU-CACHE',
        `[${this.name}] Swept ${removed} expired entries`);
    }
    return removed;
  }

  /** @returns {number} Current number of entries */
  get size() { return this._map.size; }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = { LRUCache };
