'use strict';

/**
 * @module heady-conductor
 * @description Central orchestration conductor for HeadyStack v3.0.1 "Aether".
 *
 * HeadyConductor is the top-level router: it classifies incoming tasks and
 * dispatches them to the appropriate downstream handler (LLM router, pipeline,
 * specialist bees, vector memory, etc.).
 *
 * Exports:
 *  - HeadyConductor class
 *  - getConductor() — singleton accessor
 */

const logger = require('./utils/logger');

// ─── Task type constants ──────────────────────────────────────────────────────

const TASK_TYPES = Object.freeze({
  CODE_GENERATION:  'code_generation',
  CODE_REVIEW:      'code_review',
  ARCHITECTURE:     'architecture',
  RESEARCH:         'research',
  QUICK_TASKS:      'quick_tasks',
  CREATIVE:         'creative',
  SECURITY_AUDIT:   'security_audit',
  DOCUMENTATION:    'documentation',
  EMBEDDINGS:       'embeddings',
  UNKNOWN:          'unknown',
});

// Classification keywords per task type (order = priority)
const TASK_CLASSIFIERS = [
  {
    type: TASK_TYPES.EMBEDDINGS,
    patterns: [/\bembed(ding)?s?\b/, /\bvector(s|ize|ization)?\b/, /\bsimilarity search\b/, /\bsemantic search\b/],
  },
  {
    type: TASK_TYPES.SECURITY_AUDIT,
    patterns: [/\bsecurity\b/, /\baudit\b/, /\bvulnerabilit(y|ies)\b/, /\bpenetration test\b/, /\bpenttest\b/, /\bcve\b/, /\bexploit\b/, /\binjection\b/],
  },
  {
    type: TASK_TYPES.CODE_REVIEW,
    patterns: [/\breview\b/, /\bcode review\b/, /\brefactor\b/, /\bfeedback\b/, /\bsuggestion(s)?\b/, /\bpull request\b/, /\bpr\b/],
  },
  {
    type: TASK_TYPES.CODE_GENERATION,
    patterns: [/\bwrite( a)? (function|class|module|script|code)\b/, /\bgenerate code\b/, /\bimplement\b/, /\bcreate (a|the)? (function|class|api|endpoint)\b/, /\bbuild( a)? (service|component|module)\b/],
  },
  {
    type: TASK_TYPES.ARCHITECTURE,
    patterns: [/\barchitect(ure)?\b/, /\bdesign( pattern)?\b/, /\bsystem design\b/, /\bdiagram\b/, /\bschema\b/, /\bmicroservice\b/, /\binfrastructure\b/],
  },
  {
    type: TASK_TYPES.DOCUMENTATION,
    patterns: [/\bdocument(ation)?\b/, /\breadme\b/, /\bjsdoc\b/, /\bapi doc\b/, /\bchangelog\b/, /\bexplain( this| the| how)?\b/],
  },
  {
    type: TASK_TYPES.RESEARCH,
    patterns: [/\bresearch\b/, /\banalys(is|e|ize)\b/, /\bcompare\b/, /\bbenchmark\b/, /\bsurvey\b/, /\bsummariz(e|ation)\b/, /\bfind (information|data|papers)\b/],
  },
  {
    type: TASK_TYPES.CREATIVE,
    patterns: [/\bwrit(e|ing) (a story|poem|blog|post|content)\b/, /\bcreative\b/, /\bbrainstorm\b/, /\bideate\b/, /\bgenerat(e|ing) ideas\b/],
  },
  {
    type: TASK_TYPES.QUICK_TASKS,
    patterns: [/\bquick(ly)?\b/, /\bsimple\b/, /\bfast\b/, /\bone-liner\b/, /\bsnippet\b/, /\bformat\b/, /\bconvert\b/, /\btranslate\b/],
  },
];

// ─── Handler registry ─────────────────────────────────────────────────────────

// Default no-op handler — replaced by setOrchestrator / registerHandler
function _defaultHandler(task) {
  return Promise.resolve({
    status: 'queued',
    taskId: task.id,
    taskType: task.type,
    message: 'No handler registered for this task type; queued for later processing.',
  });
}

// ─── HeadyConductor class ─────────────────────────────────────────────────────

class HeadyConductor {
  constructor() {
    /** @type {Map<string, Function>} */
    this._handlers = new Map();

    /** @type {object|null} — upstream LLM router */
    this._orchestrator = null;

    /** @type {object|null} — vector memory reference */
    this._vectorMemory = null;

    /** Task counter and history. */
    this._taskCounter   = 0;
    this._taskHistory   = []; // last 200 routed tasks (summary only)
    this._errorHistory  = []; // last 50 errors
    this._startedAt     = Date.now();

    // Register a fallback for all known task types
    for (const type of Object.values(TASK_TYPES)) {
      this._handlers.set(type, _defaultHandler);
    }
  }

  // ── Configuration ────────────────────────────────────────────────────────

  /**
   * Set the upstream LLM orchestrator (e.g. HeadyOrchestrator).
   * @param {object} orchestrator - must implement routeToLLM(task) or similar
   */
  setOrchestrator(orchestrator) {
    this._orchestrator = orchestrator;
    logger.info('heady-conductor: orchestrator attached');
  }

  /**
   * Set the vector memory instance for embedding-based routing.
   * @param {object} vectorMemory - VectorMemory instance
   */
  setVectorMemory(vectorMemory) {
    this._vectorMemory = vectorMemory;
    logger.info('heady-conductor: vectorMemory attached');
  }

  /**
   * Register a handler for a specific task type.
   * @param {string} taskType
   * @param {Function} handler — async (task) => result
   */
  registerHandler(taskType, handler) {
    if (typeof handler !== 'function') throw new Error('handler must be a function');
    this._handlers.set(taskType, handler);
    logger.info(`heady-conductor: handler registered for "${taskType}"`);
  }

  // ── Classification ───────────────────────────────────────────────────────

  /**
   * Classify a task into a TASK_TYPES value based on its prompt/content.
   * @param {object} task
   * @param {string} [task.prompt]
   * @param {string} [task.type]   — explicit type override
   * @param {string} [task.content]
   * @returns {string} TASK_TYPES value
   */
  classifyTask(task) {
    // Explicit type provided and known — use it
    if (task.type && TASK_TYPES[task.type.toUpperCase()]) {
      return TASK_TYPES[task.type.toUpperCase()];
    }
    if (task.type && Object.values(TASK_TYPES).includes(task.type)) {
      return task.type;
    }

    const text = ((task.prompt || '') + ' ' + (task.content || '')).toLowerCase().trim();
    if (!text) return TASK_TYPES.UNKNOWN;

    for (const classifier of TASK_CLASSIFIERS) {
      for (const pattern of classifier.patterns) {
        if (pattern.test(text)) return classifier.type;
      }
    }

    // Heuristic: very short tasks are likely quick_tasks
    if (text.split(/\s+/).length <= 6) return TASK_TYPES.QUICK_TASKS;

    return TASK_TYPES.UNKNOWN;
  }

  // ── Routing ──────────────────────────────────────────────────────────────

  /**
   * Route a task to the appropriate handler.
   *
   * @param {object} task
   * @param {string}  [task.id]       — caller-provided ID (auto-generated if absent)
   * @param {string}  [task.type]     — explicit task type override
   * @param {string}  [task.prompt]   — task prompt / instruction
   * @param {string}  [task.content]  — task content (alternative to prompt)
   * @param {object}  [task.metadata] — arbitrary metadata
   * @param {number}  [task.priority] — 1 (highest) to 10 (lowest), default 5
   *
   * @returns {Promise<object>} handler result augmented with routing metadata
   */
  async routeTask(task) {
    if (!task || typeof task !== 'object') {
      throw new Error('task must be an object');
    }

    const id = task.id || `task-${Date.now()}-${++this._taskCounter}`;
    const priority = typeof task.priority === 'number' ? task.priority : 5;
    const receivedAt = Date.now();

    // Classify
    const taskType = this.classifyTask(task);

    const enrichedTask = {
      ...task,
      id,
      type: taskType,
      priority,
      receivedAt,
    };

    logger.info(`heady-conductor: routing task "${id}" type="${taskType}" priority=${priority}`);

    // Get handler
    const handler = this._handlers.get(taskType) || this._handlers.get(TASK_TYPES.UNKNOWN) || _defaultHandler;

    let result;
    const startMs = Date.now();

    try {
      // If orchestrator is attached and has a routeTask, delegate first
      if (this._orchestrator && typeof this._orchestrator.routeTask === 'function') {
        result = await this._orchestrator.routeTask(enrichedTask);
      } else {
        result = await handler(enrichedTask);
      }
    } catch (err) {
      const durationMs = Date.now() - startMs;
      logger.error(`heady-conductor: handler error for "${id}"`, err);

      const errorRecord = {
        taskId: id, taskType, error: err.message, timestamp: Date.now(), durationMs,
      };
      this._errorHistory.push(errorRecord);
      if (this._errorHistory.length > 50) this._errorHistory.shift();

      this._recordHistory({ id, taskType, priority, receivedAt, durationMs, status: 'error' });

      return {
        ok: false,
        taskId: id,
        taskType,
        error: err.message,
        durationMs,
        timestamp: Date.now(),
      };
    }

    const durationMs = Date.now() - startMs;
    this._recordHistory({ id, taskType, priority, receivedAt, durationMs, status: 'ok' });

    logger.debug(`heady-conductor: task "${id}" completed in ${durationMs}ms`);

    return {
      ok: true,
      taskId: id,
      taskType,
      durationMs,
      timestamp: Date.now(),
      result,
    };
  }

  // ── History ──────────────────────────────────────────────────────────────

  _recordHistory(entry) {
    this._taskHistory.push(entry);
    if (this._taskHistory.length > 200) this._taskHistory.shift();
  }

  // ── Status ───────────────────────────────────────────────────────────────

  /**
   * Return conductor status summary.
   * @returns {object}
   */
  status() {
    const typeBreakdown = {};
    for (const entry of this._taskHistory) {
      typeBreakdown[entry.taskType] = (typeBreakdown[entry.taskType] || 0) + 1;
    }

    const avgDuration = this._taskHistory.length
      ? this._taskHistory.reduce((s, e) => s + (e.durationMs || 0), 0) / this._taskHistory.length
      : 0;

    const errorRate = this._taskHistory.length
      ? this._errorHistory.length / this._taskHistory.length
      : 0;

    return {
      platform:         'HeadyStack',
      version:          '3.0.1',
      codename:         'Aether',
      uptime:           Date.now() - this._startedAt,
      totalTasksRouted: this._taskHistory.length,
      taskTypeBreakdown: typeBreakdown,
      avgDurationMs:    Math.round(avgDuration),
      errorRate:        Math.round(errorRate * 10000) / 10000,
      recentErrors:     this._errorHistory.slice(-5),
      orchestratorAttached: !!this._orchestrator,
      vectorMemoryAttached: !!this._vectorMemory,
      registeredHandlers: [...this._handlers.keys()],
    };
  }

  // ── Express Routes ───────────────────────────────────────────────────────

  /**
   * Register conductor Express routes.
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    /**
     * POST /api/conductor/route
     * Body: task object
     */
    app.post('/api/conductor/route', async (req, res) => {
      try {
        const task = req.body;
        if (!task || typeof task !== 'object') {
          return res.status(400).json({ error: 'request body must be a task object' });
        }
        const result = await this.routeTask(task);
        res.json(result);
      } catch (err) {
        logger.error('POST /api/conductor/route error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * POST /api/conductor/classify
     * Body: { prompt?, content?, type? }
     */
    app.post('/api/conductor/classify', (req, res) => {
      try {
        const taskType = this.classifyTask(req.body || {});
        res.json({ taskType });
      } catch (err) {
        logger.error('POST /api/conductor/classify error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * GET /api/conductor/status
     */
    app.get('/api/conductor/status', (req, res) => {
      try {
        res.json(this.status());
      } catch (err) {
        logger.error('GET /api/conductor/status error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * GET /api/conductor/health
     */
    app.get('/api/conductor/health', (req, res) => {
      const s = this.status();
      const healthy = s.errorRate < 0.1 && s.totalTasksRouted >= 0;
      res.status(healthy ? 200 : 503).json({
        status: healthy ? 'healthy' : 'degraded',
        errorRate: s.errorRate,
        uptimeMs: s.uptime,
      });
    });

    /**
     * GET /api/conductor/history
     * Query: limit (default 20)
     */
    app.get('/api/conductor/history', (req, res) => {
      const limit = req.query.limit ? parseInt(req.query.limit, 10) : 20;
      res.json({ history: this._taskHistory.slice(-limit), count: this._taskHistory.length });
    });

    logger.info('heady-conductor: Express routes registered');
  }
}

// ─── Singleton ────────────────────────────────────────────────────────────────

let _instance = null;

/**
 * Get or create the HeadyConductor singleton.
 * @returns {HeadyConductor}
 */
function getConductor() {
  if (!_instance) _instance = new HeadyConductor();
  return _instance;
}

// ─── Module exports ───────────────────────────────────────────────────────────

module.exports = {
  HeadyConductor,
  getConductor,
  TASK_TYPES,
};
