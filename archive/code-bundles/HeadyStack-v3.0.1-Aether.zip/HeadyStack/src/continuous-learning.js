'use strict';

/**
 * @module continuous-learning
 * @description Continuous learning engine for HeadyStack v3.0.1 "Aether".
 *
 * Observes completed tasks and extracts durable patterns that can be queried
 * to inform future task routing, prompt augmentation, and system optimisation.
 *
 * Features:
 *  - learn(content, context) — store a learned pattern with embedding
 *  - getPatterns(query) — retrieve patterns matching optional criteria
 *  - generateInsights() — statistical summary of accumulated knowledge
 *  - Express routes: GET /api/learning/patterns, GET /api/learning/insights,
 *                    POST /api/learning/learn
 */

const logger = require('./utils/logger');

// ─── Constants ────────────────────────────────────────────────────────────────

const MAX_PATTERNS = parseInt(process.env.MAX_PATTERNS || '10000', 10);
const PATTERN_RETENTION_MS = parseInt(process.env.PATTERN_RETENTION_MS || String(30 * 24 * 60 * 60 * 1000), 10); // 30 days

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Simple keyword frequency extractor.
 * @param {string} text
 * @returns {Map<string, number>}
 */
function extractKeywords(text) {
  const stop = new Set([
    'the', 'a', 'an', 'is', 'it', 'in', 'of', 'to', 'and', 'or', 'for',
    'with', 'on', 'at', 'from', 'by', 'that', 'this', 'was', 'are', 'be',
    'as', 'i', 'we', 'you', 'he', 'she', 'they', 'not', 'but', 'if', 'so',
  ]);
  const words = text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(w => w.length > 2 && !stop.has(w));
  const freq = new Map();
  for (const w of words) freq.set(w, (freq.get(w) || 0) + 1);
  return freq;
}

/**
 * Cosine similarity between two keyword-frequency Maps.
 * @param {Map<string,number>} a
 * @param {Map<string,number>} b
 * @returns {number}
 */
function keywordCosineSim(a, b) {
  let dot = 0, magA = 0, magB = 0;
  for (const [k, va] of a.entries()) {
    const vb = b.get(k) || 0;
    dot  += va * vb;
    magA += va * va;
  }
  for (const [, vb] of b.entries()) magB += vb * vb;
  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);
  if (magA === 0 || magB === 0) return 0;
  return dot / (magA * magB);
}

// ─── ContinuousLearning class ─────────────────────────────────────────────────

class ContinuousLearning {
  constructor() {
    /**
     * @type {Map<string, {
     *   id: string,
     *   content: string,
     *   context: object,
     *   keywords: Map<string,number>,
     *   category: string,
     *   confidence: number,
     *   learnedAt: number,
     *   accessCount: number,
     *   lastAccessedAt: number,
     * }>}
     */
    this._patterns = new Map();
    this._idCounter = 0;

    /** Category frequency counts. */
    this._categoryStats = new Map();

    /** Running insight cache. */
    this._insightCache = null;
    this._insightCacheTs = 0;
  }

  // ── Core learn ───────────────────────────────────────────────────────────

  /**
   * Store a learned pattern.
   *
   * @param {string} content  - the knowledge/pattern text
   * @param {object} [context]
   * @param {string}  [context.taskType]    - e.g. 'code_generation'
   * @param {string}  [context.source]      - where this was learned from
   * @param {number}  [context.confidence]  - 0-1 confidence score
   * @param {string}  [context.category]    - explicit category override
   * @param {object}  [context.metadata]    - arbitrary extra data
   *
   * @returns {{ id: string, category: string, confidence: number }}
   */
  learn(content, context = {}) {
    if (typeof content !== 'string' || content.trim().length === 0) {
      throw new Error('content must be a non-empty string');
    }

    // Enforce capacity limit: evict oldest on overflow
    if (this._patterns.size >= MAX_PATTERNS) {
      this._evictOldest();
    }

    const id = `pat-${Date.now()}-${++this._idCounter}`;
    const keywords = extractKeywords(content);

    // Auto-categorise based on content signals
    const category = context.category || this._autoClassify(content, context.taskType);
    const confidence = Math.min(1, Math.max(0, typeof context.confidence === 'number' ? context.confidence : 0.7));

    const pattern = {
      id,
      content,
      context: {
        taskType:  context.taskType  || 'unknown',
        source:    context.source    || 'system',
        metadata:  context.metadata  || {},
      },
      keywords,
      category,
      confidence,
      learnedAt:      Date.now(),
      accessCount:    0,
      lastAccessedAt: null,
    };

    this._patterns.set(id, pattern);
    this._categoryStats.set(category, (this._categoryStats.get(category) || 0) + 1);
    this._insightCache = null; // invalidate cache

    logger.debug(`continuous-learning: learned pattern "${id}" category="${category}" confidence=${confidence}`);
    return { id, category, confidence };
  }

  /**
   * Auto-classify content into a category based on keyword heuristics.
   * @param {string} content
   * @param {string} [taskType]
   * @returns {string}
   */
  _autoClassify(content, taskType) {
    if (taskType && taskType !== 'unknown') return taskType;
    const lower = content.toLowerCase();
    if (/\b(function|class|import|require|const|let|var|async|await)\b/.test(lower)) return 'code_pattern';
    if (/\b(security|vulnerability|exploit|injection|xss|csrf)\b/.test(lower)) return 'security';
    if (/\b(architecture|design|pattern|diagram|schema|structure)\b/.test(lower)) return 'architecture';
    if (/\b(error|exception|bug|fix|patch|debug)\b/.test(lower)) return 'debugging';
    if (/\b(performance|latency|throughput|cache|optimis)\b/.test(lower)) return 'performance';
    if (/\b(test|spec|unit|integration|mock|stub)\b/.test(lower)) return 'testing';
    if (/\b(deploy|ci|cd|pipeline|container|docker|k8s)\b/.test(lower)) return 'devops';
    if (/\b(document|readme|comment|explain|describe)\b/.test(lower)) return 'documentation';
    return 'general';
  }

  /**
   * Evict the single oldest pattern.
   */
  _evictOldest() {
    let oldestId = null;
    let oldestTs = Infinity;
    for (const [id, p] of this._patterns.entries()) {
      if (p.learnedAt < oldestTs) { oldestTs = p.learnedAt; oldestId = id; }
    }
    if (oldestId) {
      const p = this._patterns.get(oldestId);
      this._patterns.delete(oldestId);
      const cat = p.category;
      if (this._categoryStats.has(cat)) {
        const count = this._categoryStats.get(cat) - 1;
        if (count <= 0) this._categoryStats.delete(cat);
        else this._categoryStats.set(cat, count);
      }
      logger.debug(`continuous-learning: evicted oldest pattern "${oldestId}"`);
    }
  }

  // ── Retrieval ────────────────────────────────────────────────────────────

  /**
   * Retrieve patterns, optionally filtered and/or ranked by relevance to a query.
   *
   * @param {object} [opts]
   * @param {string}  [opts.query]      - free-text relevance query
   * @param {string}  [opts.category]   - filter to a specific category
   * @param {string}  [opts.taskType]   - filter by task type in context
   * @param {number}  [opts.topK=20]    - max results
   * @param {number}  [opts.minConfidence=0] - minimum confidence threshold
   * @param {boolean} [opts.includeKeywords=false]
   *
   * @returns {object[]}
   */
  getPatterns(opts = {}) {
    const {
      query,
      category,
      taskType,
      topK = 20,
      minConfidence = 0,
      includeKeywords = false,
    } = opts;

    const now = Date.now();
    let results = [];

    const queryKeywords = query ? extractKeywords(query) : null;

    for (const [, pattern] of this._patterns.entries()) {
      // Age filter: skip if older than retention window
      if (now - pattern.learnedAt > PATTERN_RETENTION_MS) continue;
      // Confidence filter
      if (pattern.confidence < minConfidence) continue;
      // Category filter
      if (category && pattern.category !== category) continue;
      // Task type filter
      if (taskType && pattern.context.taskType !== taskType) continue;

      let relevance = pattern.confidence;
      if (queryKeywords && queryKeywords.size > 0) {
        relevance = keywordCosineSim(queryKeywords, pattern.keywords);
        if (relevance === 0) continue; // no overlap
      }

      const entry = {
        id:          pattern.id,
        content:     pattern.content,
        category:    pattern.category,
        confidence:  pattern.confidence,
        taskType:    pattern.context.taskType,
        source:      pattern.context.source,
        relevance:   Math.round(relevance * 10000) / 10000,
        learnedAt:   pattern.learnedAt,
        accessCount: pattern.accessCount,
      };
      if (includeKeywords) {
        entry.keywords = Object.fromEntries(pattern.keywords);
      }

      results.push(entry);
      pattern.accessCount++;
      pattern.lastAccessedAt = now;
    }

    results.sort((a, b) => b.relevance - a.relevance);
    return results.slice(0, topK);
  }

  // ── Insights ─────────────────────────────────────────────────────────────

  /**
   * Generate statistical insights from accumulated patterns.
   * Results are cached for 10 seconds to avoid repeated computation.
   * @returns {object}
   */
  generateInsights() {
    const now = Date.now();
    if (this._insightCache && now - this._insightCacheTs < 10000) {
      return this._insightCache;
    }

    const categoryDist = Object.fromEntries(this._categoryStats);
    const total = this._patterns.size;

    let avgConfidence = 0;
    let maxConfidence = 0;
    let mostAccessed = null;
    let maxAccess = -1;

    const taskTypeCounts = new Map();

    for (const p of this._patterns.values()) {
      avgConfidence += p.confidence;
      if (p.confidence > maxConfidence) maxConfidence = p.confidence;
      if (p.accessCount > maxAccess) { maxAccess = p.accessCount; mostAccessed = p.id; }
      const tt = p.context.taskType;
      taskTypeCounts.set(tt, (taskTypeCounts.get(tt) || 0) + 1);
    }

    if (total > 0) avgConfidence /= total;

    // Top 5 categories
    const topCategories = [...this._categoryStats.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([cat, count]) => ({ category: cat, count, pct: ((count / total) * 100).toFixed(1) }));

    // Top 5 task types
    const topTaskTypes = [...taskTypeCounts.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([tt, count]) => ({ taskType: tt, count }));

    const insights = {
      totalPatterns: total,
      avgConfidence:   Math.round(avgConfidence * 10000) / 10000,
      maxConfidence:   Math.round(maxConfidence * 10000) / 10000,
      categoryDistribution: categoryDist,
      topCategories,
      topTaskTypes,
      mostAccessedPatternId: mostAccessed,
      maxAccessCount: maxAccess,
      capacity: { used: total, max: MAX_PATTERNS, pct: ((total / MAX_PATTERNS) * 100).toFixed(1) },
      generatedAt: now,
    };

    this._insightCache = insights;
    this._insightCacheTs = now;
    return insights;
  }

  // ── Express Routes ───────────────────────────────────────────────────────

  /**
   * Register Express routes for the learning engine.
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    /**
     * GET /api/learning/patterns
     * Query params: query, category, taskType, topK, minConfidence
     */
    app.get('/api/learning/patterns', (req, res) => {
      try {
        const opts = {
          query:         req.query.query,
          category:      req.query.category,
          taskType:      req.query.taskType,
          topK:          req.query.topK        ? parseInt(req.query.topK, 10)         : 20,
          minConfidence: req.query.minConfidence ? parseFloat(req.query.minConfidence) : 0,
        };
        const patterns = this.getPatterns(opts);
        res.json({ patterns, count: patterns.length });
      } catch (err) {
        logger.error('GET /api/learning/patterns error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * GET /api/learning/insights
     */
    app.get('/api/learning/insights', (req, res) => {
      try {
        res.json(this.generateInsights());
      } catch (err) {
        logger.error('GET /api/learning/insights error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * POST /api/learning/learn
     * Body: { content: string, context?: object }
     */
    app.post('/api/learning/learn', (req, res) => {
      try {
        const { content, context } = req.body;
        if (typeof content !== 'string' || !content.trim()) {
          return res.status(400).json({ error: 'content (string) is required' });
        }
        const result = this.learn(content, context);
        res.json({ ok: true, ...result });
      } catch (err) {
        logger.error('POST /api/learning/learn error', err);
        res.status(500).json({ error: err.message });
      }
    });

    logger.info('continuous-learning: Express routes registered');
  }
}

// ─── Module singleton ─────────────────────────────────────────────────────────

let _instance = null;

/**
 * Get or create the global ContinuousLearning singleton.
 * @returns {ContinuousLearning}
 */
function getContinuousLearning() {
  if (!_instance) _instance = new ContinuousLearning();
  return _instance;
}

// ─── Module exports ───────────────────────────────────────────────────────────

module.exports = {
  ContinuousLearning,
  getContinuousLearning,
};
