'use strict';

/**
 * @module self-awareness
 * @description Self-Awareness Telemetry Loop for HeadyStack v3.0.1 "Aether".
 *
 * Maintains a 384D system-state embedding (the platform's "self-model") and
 * continuously monitors semantic coherence against a baseline. When coherence
 * drops below COHERENCE_THRESHOLD the system logs a state transition and can
 * trigger corrective workflows.
 *
 * Exports:
 *  - SelfAwareness class
 *  - startSelfAwareness() — creates and starts the singleton instance
 */

const os = require('os');
const logger = require('./utils/logger');

// Lazy-require to avoid circular dependencies during module init
let _MonteCarloEngine = null;
function getMonteCarloEngine() {
  if (!_MonteCarloEngine) {
    _MonteCarloEngine = require('./monte-carlo').MonteCarloEngine;
  }
  return _MonteCarloEngine;
}

let _EmbeddingProvider = null;
function getEmbeddingProvider() {
  if (!_EmbeddingProvider) {
    _EmbeddingProvider = require('./embedding-provider').EmbeddingProvider;
  }
  return _EmbeddingProvider;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const COHERENCE_THRESHOLD = 0.75;
const EMBEDDING_DIM = 384;
const DEFAULT_INTERVAL_MS = 30000;

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Build a textual description of the current system state for embedding.
 * @returns {string}
 */
function buildStateText() {
  const mem   = process.memoryUsage();
  const cpus  = os.cpus();
  const uptime = os.uptime();

  const heapPct  = mem.heapUsed / mem.heapTotal;
  const rssMB    = (mem.rss / 1024 / 1024).toFixed(1);
  const cpuModel = cpus[0] ? cpus[0].model.split(' ')[0] : 'unknown';
  const cpuCount = cpus.length;

  return (
    `HeadyStack v3.0.1 Aether ` +
    `uptime=${uptime.toFixed(0)}s heap=${(heapPct * 100).toFixed(1)}% ` +
    `rss=${rssMB}MB cpus=${cpuCount}x${cpuModel} ` +
    `node=${process.version} platform=${process.platform} ` +
    `pid=${process.pid} ts=${Date.now()}`
  );
}

/**
 * Cosine similarity between two Float64Arrays (inline, no dependency cycle).
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {number}
 */
function cosine(a, b) {
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot  += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);
  if (magA === 0 || magB === 0) return 0;
  return dot / (magA * magB);
}

// ─── SelfAwareness class ──────────────────────────────────────────────────────

class SelfAwareness {
  /**
   * @param {object} [opts]
   * @param {number} [opts.coherenceThreshold=0.75]
   * @param {number} [opts.intervalMs=30000]
   * @param {object} [opts.embeddingProvider] — EmbeddingProvider instance (optional)
   * @param {object} [opts.monteCarloEngine]  — MonteCarloEngine instance (optional)
   */
  constructor(opts = {}) {
    this._coherenceThreshold = opts.coherenceThreshold || COHERENCE_THRESHOLD;
    this._intervalMs = opts.intervalMs || DEFAULT_INTERVAL_MS;

    /** @type {Float64Array|null} */
    this._baselineEmbedding = null;

    /** @type {Float64Array|null} */
    this._currentEmbedding = null;

    this._embeddingProvider = opts.embeddingProvider || null;
    this._monteCarloEngine  = opts.monteCarloEngine  || null;

    this._coherenceHistory  = []; // last 100 coherence readings
    this._stateTransitions  = []; // log of state transitions
    this._heartbeatCount    = 0;
    this._lastHeartbeat     = null;
    this._intervalHandle    = null;
    this._running           = false;
    this._currentState      = 'INITIALIZING';

    // Lazy-create internal providers on first use
    this._getEmbeddingProvider = () => {
      if (!this._embeddingProvider) {
        const EP = getEmbeddingProvider();
        this._embeddingProvider = new EP({ providerChain: ['local'] });
      }
      return this._embeddingProvider;
    };

    this._getMonteCarloEngine = () => {
      if (!this._monteCarloEngine) {
        const MCE = getMonteCarloEngine();
        this._monteCarloEngine = new MCE();
      }
      return this._monteCarloEngine;
    };
  }

  // ── Baseline ─────────────────────────────────────────────────────────────

  /**
   * Establish the baseline embedding from current system state.
   * Should be called once during system warm-up.
   * @returns {Promise<void>}
   */
  async establishBaseline() {
    const text = buildStateText();
    this._baselineEmbedding = await this._getEmbeddingProvider().generateEmbedding(text);
    this._currentEmbedding  = new Float64Array(this._baselineEmbedding);
    this.logStateTransition(this._currentState, 'BASELINE_ESTABLISHED', 'initial baseline set');
    this._currentState = 'NOMINAL';
    logger.info('self-awareness: baseline embedding established');
  }

  // ── Heartbeat ────────────────────────────────────────────────────────────

  /**
   * Re-embed current system state and compare to baseline.
   * Logs a state transition if coherence drops below threshold.
   * @returns {Promise<{ coherence: number, state: string }>}
   */
  async heartbeat() {
    const text = buildStateText();
    let embedding;

    try {
      embedding = await this._getEmbeddingProvider().generateEmbedding(text);
    } catch (err) {
      logger.error('self-awareness: heartbeat embedding failed', err);
      return { coherence: 0, state: this._currentState };
    }

    this._currentEmbedding = embedding;

    let coherence = 1.0;
    if (this._baselineEmbedding) {
      coherence = cosine(this._baselineEmbedding, embedding);
    }

    this._coherenceHistory.push({ coherence, timestamp: Date.now() });
    if (this._coherenceHistory.length > 100) this._coherenceHistory.shift();

    const prevState = this._currentState;

    if (coherence < this._coherenceThreshold) {
      if (this._currentState !== 'DRIFTED') {
        this.logStateTransition(prevState, 'DRIFTED', `coherence=${coherence.toFixed(4)} below threshold=${this._coherenceThreshold}`);
        this._currentState = 'DRIFTED';
        logger.warn(`self-awareness: coherence drift detected (${coherence.toFixed(4)})`);
      }
    } else {
      if (this._currentState === 'DRIFTED') {
        this.logStateTransition(prevState, 'NOMINAL', `coherence restored to ${coherence.toFixed(4)}`);
        this._currentState = 'NOMINAL';
        logger.info(`self-awareness: coherence restored (${coherence.toFixed(4)})`);
      }
    }

    this._heartbeatCount++;
    this._lastHeartbeat = Date.now();

    logger.debug(`self-awareness: heartbeat #${this._heartbeatCount} coherence=${coherence.toFixed(4)} state=${this._currentState}`);
    return { coherence, state: this._currentState };
  }

  // ── ORS ──────────────────────────────────────────────────────────────────

  /**
   * Get the Operational Readiness Score via MonteCarloEngine.quickReadiness.
   * @returns {object} ORS result { score, grade, factors }
   */
  getORS() {
    const memUsage = process.memoryUsage();
    const cpus = os.cpus();

    // Estimate CPU pressure from load average
    const loadAvg = os.loadavg();
    const cpuPressure = Math.min(1, loadAvg[0] / (cpus.length || 1));
    const memoryPressure = memUsage.heapUsed / memUsage.heapTotal;

    // Coherence-based error rate: treat low coherence as higher error rate
    const recentCoherences = this._coherenceHistory.slice(-10);
    const avgCoherence = recentCoherences.length
      ? recentCoherences.reduce((s, h) => s + h.coherence, 0) / recentCoherences.length
      : 1.0;
    const errorRate = Math.max(0, 1 - avgCoherence);

    const signals = {
      errorRate,
      lastDeploySuccess: true,
      cpuPressure,
      memoryPressure,
      serviceHealthRatio: this._currentState === 'NOMINAL' ? 1.0 : 0.5,
      openIncidents: this._stateTransitions.filter(t => t.to === 'DRIFTED').length,
    };

    return this._getMonteCarloEngine().quickReadiness(signals);
  }

  // ── Identity & resources ──────────────────────────────────────────────────

  /**
   * Return the current system identity (embedding + metadata).
   * @returns {object}
   */
  getSystemIdentity() {
    return {
      platform: 'HeadyStack',
      version: '3.0.1',
      codename: 'Aether',
      pid: process.pid,
      nodeVersion: process.version,
      platform_os: process.platform,
      arch: process.arch,
      state: this._currentState,
      heartbeatCount: this._heartbeatCount,
      embeddingDim: EMBEDDING_DIM,
      currentEmbedding: this._currentEmbedding ? Array.from(this._currentEmbedding) : null,
      baselineEmbedding: this._baselineEmbedding ? Array.from(this._baselineEmbedding) : null,
      timestamp: Date.now(),
    };
  }

  /**
   * Return current resource utilisation metrics.
   * @returns {object}
   */
  getResourceUtilization() {
    const mem = process.memoryUsage();
    const cpus = os.cpus();
    const loadAvg = os.loadavg();
    const freeMemMB  = (os.freemem()  / 1024 / 1024).toFixed(2);
    const totalMemMB = (os.totalmem() / 1024 / 1024).toFixed(2);

    return {
      cpu: {
        count: cpus.length,
        model: cpus[0] ? cpus[0].model : 'unknown',
        loadAvg1m: loadAvg[0],
        loadAvg5m: loadAvg[1],
        loadAvg15m: loadAvg[2],
        pressureRatio: Math.min(1, loadAvg[0] / (cpus.length || 1)),
      },
      memory: {
        heapUsedMB:  (mem.heapUsed  / 1024 / 1024).toFixed(2),
        heapTotalMB: (mem.heapTotal / 1024 / 1024).toFixed(2),
        rssMB:       (mem.rss       / 1024 / 1024).toFixed(2),
        externalMB:  (mem.external  / 1024 / 1024).toFixed(2),
        heapUsedPct: ((mem.heapUsed / mem.heapTotal) * 100).toFixed(1),
        systemFreeMB: freeMemMB,
        systemTotalMB: totalMemMB,
      },
      uptime: {
        processSec: process.uptime().toFixed(1),
        systemSec: os.uptime().toFixed(1),
      },
      timestamp: Date.now(),
    };
  }

  // ── State transitions ─────────────────────────────────────────────────────

  /**
   * Log a state transition.
   * @param {string} from
   * @param {string} to
   * @param {string} reason
   */
  logStateTransition(from, to, reason) {
    const transition = { from, to, reason, timestamp: Date.now() };
    this._stateTransitions.push(transition);
    if (this._stateTransitions.length > 200) this._stateTransitions.shift();
    logger.info(`self-awareness: state transition ${from} → ${to} (${reason})`);
  }

  /**
   * Get recent state transitions.
   * @param {number} [limit=20]
   * @returns {object[]}
   */
  getStateTransitions(limit = 20) {
    return this._stateTransitions.slice(-limit);
  }

  /**
   * Get recent coherence readings.
   * @param {number} [limit=20]
   * @returns {object[]}
   */
  getCoherenceHistory(limit = 20) {
    return this._coherenceHistory.slice(-limit);
  }

  // ── Lifecycle ────────────────────────────────────────────────────────────

  /**
   * Start the heartbeat loop.
   * @param {number} [intervalMs=30000]
   * @returns {Promise<void>}
   */
  async start(intervalMs = this._intervalMs) {
    if (this._running) return;
    this._running = true;

    if (!this._baselineEmbedding) {
      await this.establishBaseline();
    }

    // First heartbeat immediately
    await this.heartbeat();

    this._intervalHandle = setInterval(async () => {
      try {
        await this.heartbeat();
      } catch (err) {
        logger.error('self-awareness: heartbeat error', err);
      }
    }, intervalMs);

    logger.info(`self-awareness: loop started (interval=${intervalMs}ms)`);
  }

  /**
   * Stop the heartbeat loop.
   */
  stop() {
    if (this._intervalHandle) {
      clearInterval(this._intervalHandle);
      this._intervalHandle = null;
    }
    this._running = false;
    logger.info('self-awareness: loop stopped');
  }
}

// ─── Singleton ────────────────────────────────────────────────────────────────

let _singleton = null;

/**
 * Create (if needed) and start the SelfAwareness singleton.
 * @param {object} [opts]
 * @param {number} [opts.intervalMs=30000]
 * @returns {Promise<SelfAwareness>}
 */
async function startSelfAwareness(opts = {}) {
  if (!_singleton) {
    _singleton = new SelfAwareness(opts);
  }
  await _singleton.start(opts.intervalMs);
  return _singleton;
}

/**
 * Get the existing SelfAwareness singleton (or null).
 * @returns {SelfAwareness|null}
 */
function getSelfAwareness() {
  return _singleton;
}

// ─── Module exports ───────────────────────────────────────────────────────────

module.exports = {
  SelfAwareness,
  startSelfAwareness,
  getSelfAwareness,
  COHERENCE_THRESHOLD,
  EMBEDDING_DIM,
};
