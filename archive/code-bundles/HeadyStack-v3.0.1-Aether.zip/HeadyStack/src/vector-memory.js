'use strict';

/**
 * @module vector-memory
 * @description RAM-first 3D Vector Memory — the brain of HeadyStack v3.0.1 "Aether".
 *
 * Stores 384-dimensional Float64Array embeddings in in-process Maps partitioned
 * by namespace. Data is persisted as newline-delimited JSON (JSON-lines) files
 * under data/vector-shards/ so it survives process restarts.
 *
 * Key capabilities:
 *  - Namespace isolation (multi-tenant safe)
 *  - Cosine-similarity top-k search
 *  - Drift detection (DRIFT_THRESHOLD = 0.75)
 *  - Import / export
 *  - Express REST routes
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const logger = require('./utils/logger');
const { cosineSimilarity, normalize } = require('./vector-space-ops');

// ─── Constants ────────────────────────────────────────────────────────────────

const EMBEDDING_DIM = 384;
const DRIFT_THRESHOLD = 0.75;
const SHARDS_DIR = path.resolve(__dirname, '../data/vector-shards');
const DEFAULT_NAMESPACE = 'default';
const MAX_ENTRIES_PER_NAMESPACE = parseInt(process.env.VM_MAX_ENTRIES || '100000', 10);

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * Encode a Float64Array as a compact base64 string.
 * @param {Float64Array} arr
 * @returns {string}
 */
function encodeVector(arr) {
  return Buffer.from(arr.buffer, arr.byteOffset, arr.byteLength).toString('base64');
}

/**
 * Decode a base64 string back to Float64Array.
 * @param {string} b64
 * @returns {Float64Array}
 */
function decodeVector(b64) {
  const buf = Buffer.from(b64, 'base64');
  return new Float64Array(buf.buffer, buf.byteOffset, buf.byteLength / 8);
}

/**
 * Validate that a value is a 384D Float64Array.
 * @param {*} v
 * @throws {Error}
 */
function assertVector(v) {
  if (!(v instanceof Float64Array) || v.length !== EMBEDDING_DIM) {
    throw new Error(`vector must be a Float64Array of length ${EMBEDDING_DIM}`);
  }
}

// ─── VectorMemory class ───────────────────────────────────────────────────────

class VectorMemory {
  /**
   * @param {object} [opts]
   * @param {string} [opts.shardsDir] - override storage directory
   */
  constructor(opts = {}) {
    /** @type {Map<string, Map<string, {vector: Float64Array, metadata: object, timestamp: number, baseline?: Float64Array}>>} */
    this._namespaces = new Map();
    this._shardsDir = opts.shardsDir || SHARDS_DIR;
    this._driftLog = []; // { id, namespace, similarity, timestamp }
    this._initialized = false;
    this._dirty = new Set(); // namespaces with unsaved changes
  }

  // ── Private helpers ──────────────────────────────────────────────────────

  /**
   * Get or create the namespace map.
   * @param {string} ns
   * @returns {Map}
   */
  _ns(ns = DEFAULT_NAMESPACE) {
    if (!this._namespaces.has(ns)) {
      this._namespaces.set(ns, new Map());
    }
    return this._namespaces.get(ns);
  }

  /**
   * Shard file path for a namespace.
   * @param {string} ns
   * @returns {string}
   */
  _shardPath(ns) {
    // Sanitize namespace to safe filename
    const safe = ns.replace(/[^a-zA-Z0-9_-]/g, '_');
    return path.join(this._shardsDir, `shard-${safe}.jsonl`);
  }

  // ── Lifecycle ────────────────────────────────────────────────────────────

  /**
   * Load persisted data from JSON-lines shard files.
   * @returns {Promise<void>}
   */
  async init() {
    if (this._initialized) return;

    try {
      await fs.promises.mkdir(this._shardsDir, { recursive: true });
    } catch (e) {
      logger.warn('vector-memory: could not create shards dir', e);
    }

    let files;
    try {
      files = await fs.promises.readdir(this._shardsDir);
    } catch (e) {
      logger.warn('vector-memory: could not read shards dir', e);
      this._initialized = true;
      return;
    }

    let totalLoaded = 0;

    for (const file of files) {
      if (!file.endsWith('.jsonl')) continue;
      const filePath = path.join(this._shardsDir, file);
      let raw;
      try {
        raw = await fs.promises.readFile(filePath, 'utf8');
      } catch (e) {
        logger.warn(`vector-memory: could not read shard ${file}`, e);
        continue;
      }

      const lines = raw.split('\n').filter(Boolean);
      for (const line of lines) {
        try {
          const record = JSON.parse(line);
          const { id, namespace, vectorB64, metadata, timestamp, baselineB64 } = record;
          const nsMap = this._ns(namespace || DEFAULT_NAMESPACE);
          const vector = decodeVector(vectorB64);
          const entry = { vector, metadata: metadata || {}, timestamp: timestamp || Date.now() };
          if (baselineB64) {
            entry.baseline = decodeVector(baselineB64);
          }
          nsMap.set(id, entry);
          totalLoaded++;
        } catch (parseErr) {
          logger.warn(`vector-memory: skipping malformed line in ${file}`, parseErr);
        }
      }
    }

    logger.info(`vector-memory: loaded ${totalLoaded} entries from ${files.length} shard(s)`);
    this._initialized = true;
  }

  /**
   * Persist all dirty namespaces to JSON-lines files.
   * @returns {Promise<void>}
   */
  async persist() {
    await fs.promises.mkdir(this._shardsDir, { recursive: true });

    const targets = this._dirty.size > 0
      ? [...this._dirty]
      : [...this._namespaces.keys()];

    for (const ns of targets) {
      const nsMap = this._namespaces.get(ns);
      if (!nsMap) continue;

      const lines = [];
      for (const [id, entry] of nsMap.entries()) {
        const record = {
          id,
          namespace: ns,
          vectorB64: encodeVector(entry.vector),
          metadata: entry.metadata,
          timestamp: entry.timestamp,
        };
        if (entry.baseline) {
          record.baselineB64 = encodeVector(entry.baseline);
        }
        lines.push(JSON.stringify(record));
      }

      const filePath = this._shardPath(ns);
      try {
        await fs.promises.writeFile(filePath, lines.join('\n') + (lines.length ? '\n' : ''), 'utf8');
        logger.debug(`vector-memory: persisted namespace "${ns}" (${lines.length} entries)`);
      } catch (e) {
        logger.error(`vector-memory: failed to persist namespace "${ns}"`, e);
      }
    }

    this._dirty.clear();
  }

  // ── CRUD ─────────────────────────────────────────────────────────────────

  /**
   * Store a 384D embedding.
   * @param {string} id - unique identifier within the namespace
   * @param {Float64Array} vector - 384D embedding
   * @param {object} [metadata] - arbitrary JSON metadata
   * @param {string} [namespace]
   * @returns {{ drifted: boolean, similarity?: number }}
   */
  store(id, vector, metadata = {}, namespace = DEFAULT_NAMESPACE) {
    assertVector(vector);

    const nsMap = this._ns(namespace);
    if (nsMap.size >= MAX_ENTRIES_PER_NAMESPACE) {
      throw new Error(`namespace "${namespace}" has reached capacity (${MAX_ENTRIES_PER_NAMESPACE})`);
    }

    const existing = nsMap.get(id);
    let drifted = false;
    let similarity;

    // Set or update baseline; detect drift on update
    let baseline = existing ? existing.baseline || existing.vector : vector;
    if (existing) {
      similarity = cosineSimilarity(existing.vector, vector);
      if (similarity < DRIFT_THRESHOLD) {
        drifted = true;
        this._driftLog.push({ id, namespace, similarity, timestamp: Date.now() });
        logger.warn(`vector-memory: drift detected for "${id}" in "${namespace}" (sim=${similarity.toFixed(4)})`);
      }
    }

    nsMap.set(id, {
      vector: new Float64Array(vector), // defensive copy
      metadata: Object.assign({}, metadata),
      timestamp: Date.now(),
      baseline,
    });

    this._dirty.add(namespace);
    return { drifted, similarity };
  }

  /**
   * Retrieve a single entry.
   * @param {string} id
   * @param {string} [namespace]
   * @returns {{ id: string, vector: Float64Array, metadata: object, timestamp: number } | null}
   */
  get(id, namespace = DEFAULT_NAMESPACE) {
    const entry = this._ns(namespace).get(id);
    if (!entry) return null;
    return { id, vector: entry.vector, metadata: entry.metadata, timestamp: entry.timestamp };
  }

  /**
   * Delete an entry.
   * @param {string} id
   * @param {string} [namespace]
   * @returns {boolean}
   */
  delete(id, namespace = DEFAULT_NAMESPACE) {
    const nsMap = this._ns(namespace);
    const existed = nsMap.delete(id);
    if (existed) this._dirty.add(namespace);
    return existed;
  }

  // ── Search ───────────────────────────────────────────────────────────────

  /**
   * Cosine-similarity search.
   * @param {Float64Array} queryVector - 384D query embedding
   * @param {object} [opts]
   * @param {number} [opts.topK=10] - max results
   * @param {number} [opts.minScore=0.0] - minimum cosine similarity
   * @param {string} [opts.namespace] - restrict to one namespace, or search all if omitted
   * @param {object} [opts.metadataFilter] - exact-match key/value metadata filter
   * @returns {Array<{ id: string, score: number, metadata: object, namespace: string }>}
   */
  search(queryVector, opts = {}) {
    assertVector(queryVector);

    const {
      topK = 10,
      minScore = 0.0,
      namespace,
      metadataFilter,
    } = opts;

    const namespacesToSearch = namespace
      ? [namespace]
      : [...this._namespaces.keys()];

    const results = [];

    for (const ns of namespacesToSearch) {
      const nsMap = this._namespaces.get(ns);
      if (!nsMap) continue;

      for (const [id, entry] of nsMap.entries()) {
        // Metadata filter (AND logic across all filter keys)
        if (metadataFilter) {
          let pass = true;
          for (const [k, v] of Object.entries(metadataFilter)) {
            if (entry.metadata[k] !== v) { pass = false; break; }
          }
          if (!pass) continue;
        }

        const score = cosineSimilarity(queryVector, entry.vector);
        if (score >= minScore) {
          results.push({ id, score, metadata: entry.metadata, namespace: ns });
        }
      }
    }

    // Sort descending, take topK
    results.sort((a, b) => b.score - a.score);
    return results.slice(0, topK);
  }

  // ── Stats ────────────────────────────────────────────────────────────────

  /**
   * Return memory usage and per-namespace entry counts.
   * @returns {object}
   */
  getStats() {
    const memUsage = process.memoryUsage();
    const namespaceStats = {};
    let totalEntries = 0;

    for (const [ns, nsMap] of this._namespaces.entries()) {
      namespaceStats[ns] = nsMap.size;
      totalEntries += nsMap.size;
    }

    const estimatedBytesPerEntry = EMBEDDING_DIM * 8 + 200; // vector + overhead
    const estimatedVectorBytes = totalEntries * estimatedBytesPerEntry;

    return {
      totalEntries,
      namespaceCount: this._namespaces.size,
      namespaceStats,
      driftEvents: this._driftLog.length,
      recentDrift: this._driftLog.slice(-5),
      estimatedVectorMemoryMB: (estimatedVectorBytes / 1024 / 1024).toFixed(2),
      heapUsedMB: (memUsage.heapUsed / 1024 / 1024).toFixed(2),
      heapTotalMB: (memUsage.heapTotal / 1024 / 1024).toFixed(2),
      rssMB: (memUsage.rss / 1024 / 1024).toFixed(2),
      dirtyNamespaces: [...this._dirty],
    };
  }

  // ── Import / Export ──────────────────────────────────────────────────────

  /**
   * Export all entries as a plain JSON-serialisable array.
   * @param {string} [namespace] - export only this namespace (or all)
   * @returns {Array<object>}
   */
  exportEntries(namespace) {
    const namespacesToExport = namespace
      ? [namespace]
      : [...this._namespaces.keys()];

    const out = [];
    for (const ns of namespacesToExport) {
      const nsMap = this._namespaces.get(ns);
      if (!nsMap) continue;
      for (const [id, entry] of nsMap.entries()) {
        out.push({
          id,
          namespace: ns,
          vector: Array.from(entry.vector),
          metadata: entry.metadata,
          timestamp: entry.timestamp,
        });
      }
    }
    return out;
  }

  /**
   * Import entries from an array (as produced by exportEntries).
   * @param {Array<object>} entries
   * @param {boolean} [overwrite=false]
   * @returns {{ imported: number, skipped: number }}
   */
  importEntries(entries, overwrite = false) {
    let imported = 0;
    let skipped = 0;

    for (const entry of entries) {
      const { id, namespace = DEFAULT_NAMESPACE, vector, metadata, timestamp } = entry;
      if (!id || !Array.isArray(vector) || vector.length !== EMBEDDING_DIM) {
        skipped++;
        continue;
      }
      const nsMap = this._ns(namespace);
      if (nsMap.has(id) && !overwrite) {
        skipped++;
        continue;
      }
      const f64 = new Float64Array(vector);
      nsMap.set(id, { vector: f64, metadata: metadata || {}, timestamp: timestamp || Date.now(), baseline: f64 });
      this._dirty.add(namespace);
      imported++;
    }

    logger.info(`vector-memory: imported ${imported} entries, skipped ${skipped}`);
    return { imported, skipped };
  }

  // ── Express Routes ───────────────────────────────────────────────────────

  /**
   * Register Express routes.
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    /**
     * POST /api/memory/store
     * Body: { id, vector: number[], metadata?, namespace? }
     */
    app.post('/api/memory/store', async (req, res) => {
      try {
        const { id, vector, metadata, namespace } = req.body;
        if (!id || !Array.isArray(vector)) {
          return res.status(400).json({ error: 'id and vector[] are required' });
        }
        if (vector.length !== EMBEDDING_DIM) {
          return res.status(400).json({ error: `vector must have ${EMBEDDING_DIM} dimensions` });
        }
        const f64 = new Float64Array(vector);
        const result = this.store(id, f64, metadata, namespace);
        res.json({ ok: true, id, ...result });
      } catch (err) {
        logger.error('POST /api/memory/store error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * POST /api/memory/search
     * Body: { vector: number[], topK?, minScore?, namespace?, metadataFilter? }
     */
    app.post('/api/memory/search', (req, res) => {
      try {
        const { vector, topK, minScore, namespace, metadataFilter } = req.body;
        if (!Array.isArray(vector) || vector.length !== EMBEDDING_DIM) {
          return res.status(400).json({ error: `vector must be a ${EMBEDDING_DIM}-element array` });
        }
        const f64 = new Float64Array(vector);
        const results = this.search(f64, { topK, minScore, namespace, metadataFilter });
        res.json({ results });
      } catch (err) {
        logger.error('POST /api/memory/search error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * GET /api/memory/stats
     */
    app.get('/api/memory/stats', (req, res) => {
      try {
        res.json(this.getStats());
      } catch (err) {
        logger.error('GET /api/memory/stats error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * GET /api/memory/get/:namespace/:id
     */
    app.get('/api/memory/get/:namespace/:id', (req, res) => {
      try {
        const entry = this.get(req.params.id, req.params.namespace);
        if (!entry) return res.status(404).json({ error: 'not found' });
        res.json({ ...entry, vector: Array.from(entry.vector) });
      } catch (err) {
        logger.error('GET /api/memory/get error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * DELETE /api/memory/delete/:namespace/:id
     */
    app.delete('/api/memory/delete/:namespace/:id', (req, res) => {
      try {
        const deleted = this.delete(req.params.id, req.params.namespace);
        res.json({ deleted });
      } catch (err) {
        logger.error('DELETE /api/memory/delete error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * POST /api/memory/export
     * Body: { namespace? }
     */
    app.post('/api/memory/export', (req, res) => {
      try {
        const entries = this.exportEntries(req.body.namespace);
        res.json({ entries, count: entries.length });
      } catch (err) {
        logger.error('POST /api/memory/export error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * POST /api/memory/import
     * Body: { entries: object[], overwrite?: boolean }
     */
    app.post('/api/memory/import', (req, res) => {
      try {
        const { entries, overwrite } = req.body;
        if (!Array.isArray(entries)) return res.status(400).json({ error: 'entries[] required' });
        const result = this.importEntries(entries, overwrite);
        res.json(result);
      } catch (err) {
        logger.error('POST /api/memory/import error', err);
        res.status(500).json({ error: err.message });
      }
    });

    logger.info('vector-memory: Express routes registered');
  }
}

// ─── Module exports ───────────────────────────────────────────────────────────

module.exports = {
  VectorMemory,
  EMBEDDING_DIM,
  DRIFT_THRESHOLD,
};
