'use strict';

/**
 * HeadyStack — Code Governance
 * Loads governance rules, validates code submissions,
 * and exposes management routes for the governance API.
 */

const fs = require('fs');
const path = require('path');

const DEFAULT_RULES = {
  version: '1.0',
  rules: [
    {
      id: 'no-eval',
      name: 'No eval()',
      description: 'Prohibits use of eval() which can execute arbitrary code',
      pattern: '\\beval\\s*\\(',
      severity: 'error',
      enabled: true,
    },
    {
      id: 'no-process-env-mutation',
      name: 'No process.env mutation',
      description: 'Prevents direct assignment to process.env outside bootstrap',
      pattern: 'process\\.env\\.[A-Z_]+ *=',
      severity: 'warning',
      enabled: true,
    },
    {
      id: 'no-console',
      name: 'No bare console calls',
      description: 'Use the structured logger instead of console.*',
      pattern: '\\bconsole\\.(log|warn|error|info|debug)\\(',
      severity: 'info',
      enabled: true,
    },
    {
      id: 'use-strict',
      name: "'use strict' required",
      description: "All CommonJS modules must declare 'use strict'",
      pattern: null,
      check: 'use-strict',
      severity: 'error',
      enabled: true,
    },
    {
      id: 'no-require-fs-sync-in-hot-path',
      name: 'No synchronous fs in hot paths',
      description: 'Prohibits readFileSync/writeFileSync in request handlers',
      pattern: null, // structural check, handled separately
      severity: 'warning',
      enabled: false,
    },
    {
      id: 'no-hardcoded-secrets',
      name: 'No hardcoded secrets',
      description: 'Detects likely hardcoded API keys, tokens, or passwords',
      pattern: '(?:api_?key|secret|password|token|passwd)\\s*[=:]\\s*["\'][^"\']{8,}["\']',
      severity: 'error',
      enabled: true,
      flags: 'i',
    },
    {
      id: 'no-require-child-process-exec',
      name: 'No child_process.exec without sanitization',
      description: 'child_process.exec with user input is dangerous',
      pattern: 'child_process.*\\.exec\\(',
      severity: 'warning',
      enabled: true,
    },
    {
      id: 'max-file-lines',
      name: 'Maximum file length',
      description: 'Files should not exceed 2000 lines',
      pattern: null,
      check: 'max-lines',
      maxLines: 2000,
      severity: 'warning',
      enabled: true,
    },
  ],
};

class CodeGovernance {
  constructor(options = {}) {
    this._logger = options.logger || console;
    this._config = null;
    this._configPath = options.configPath || path.resolve(process.cwd(), '.heady-governance.json');
  }

  /**
   * Load governance configuration from disk or use defaults.
   * @returns {object} governance config
   */
  loadConfig() {
    if (this._config) return this._config;

    if (fs.existsSync(this._configPath)) {
      try {
        const raw = fs.readFileSync(this._configPath, 'utf8');
        this._config = JSON.parse(raw);
        this._logger.info && this._logger.info('Loaded governance config', { path: this._configPath });
      } catch (err) {
        this._logger.warn && this._logger.warn('Failed to parse governance config — using defaults', { error: err.message });
        this._config = DEFAULT_RULES;
      }
    } else {
      this._config = DEFAULT_RULES;
    }

    return this._config;
  }

  /**
   * Save governance configuration to disk.
   * @param {object} config
   */
  saveConfig(config) {
    fs.writeFileSync(this._configPath, JSON.stringify(config, null, 2), 'utf8');
    this._config = config;
  }

  /**
   * Validate code against governance rules.
   * @param {string} code - Source code string
   * @param {object} [options]
   * @param {string} [options.filename] - Filename for context
   * @returns {{ passed: boolean, violations: object[], warnings: object[], infos: object[] }}
   */
  validate(code, options = {}) {
    const config = this.loadConfig();
    const violations = [];
    const warnings = [];
    const infos = [];
    const lines = code.split('\n');
    const filename = options.filename || '<unknown>';

    for (const rule of config.rules) {
      if (!rule.enabled) continue;

      // Pattern-based checks
      if (rule.pattern) {
        const flags = rule.flags || '';
        let regex;
        try {
          regex = new RegExp(rule.pattern, flags);
        } catch (_) {
          continue;
        }

        lines.forEach((line, idx) => {
          if (regex.test(line)) {
            const finding = {
              ruleId: rule.id,
              ruleName: rule.name,
              severity: rule.severity,
              message: rule.description,
              line: idx + 1,
              column: line.search(regex) + 1,
              excerpt: line.trim().slice(0, 120),
              filename,
            };
            if (rule.severity === 'error') violations.push(finding);
            else if (rule.severity === 'warning') warnings.push(finding);
            else infos.push(finding);
          }
        });
      }

      // Structural checks
      if (rule.check === 'use-strict') {
        const hasUseStrict = lines.slice(0, 5).some((l) => l.trim() === "'use strict';" || l.trim() === '"use strict";');
        if (!hasUseStrict) {
          const finding = {
            ruleId: rule.id,
            ruleName: rule.name,
            severity: rule.severity,
            message: rule.description,
            line: 1,
            column: 1,
            filename,
          };
          if (rule.severity === 'error') violations.push(finding);
          else warnings.push(finding);
        }
      }

      if (rule.check === 'max-lines' && rule.maxLines) {
        if (lines.length > rule.maxLines) {
          warnings.push({
            ruleId: rule.id,
            ruleName: rule.name,
            severity: rule.severity,
            message: `File has ${lines.length} lines, exceeds maximum of ${rule.maxLines}`,
            line: lines.length,
            filename,
          });
        }
      }
    }

    return {
      passed: violations.length === 0,
      violations,
      warnings,
      infos,
      summary: {
        violations: violations.length,
        warnings: warnings.length,
        infos: infos.length,
        filename,
      },
    };
  }

  /**
   * Register Express routes for the governance API.
   * @param {object} app - Express app
   */
  registerRoutes(app) {
    // GET /api/governance/rules — list all governance rules
    app.get('/api/governance/rules', (req, res) => {
      const config = this.loadConfig();
      res.json({
        version: config.version,
        rules: config.rules,
        total: config.rules.length,
        enabled: config.rules.filter((r) => r.enabled).length,
      });
    });

    // POST /api/governance/validate — validate submitted code
    app.post('/api/governance/validate', (req, res) => {
      const { code, filename } = req.body || {};
      if (!code || typeof code !== 'string') {
        return res.status(422).json({ error: 'ValidationError', message: 'code (string) is required' });
      }
      try {
        const result = this.validate(code, { filename });
        res.json(result);
      } catch (err) {
        res.status(500).json({ error: 'GovernanceError', message: err.message });
      }
    });

    // GET /api/governance/config — get current config
    app.get('/api/governance/config', (req, res) => {
      res.json(this.loadConfig());
    });

    // PUT /api/governance/rules/:ruleId — enable/disable a rule
    app.put('/api/governance/rules/:ruleId', (req, res) => {
      const config = this.loadConfig();
      const rule = config.rules.find((r) => r.id === req.params.ruleId);
      if (!rule) {
        return res.status(404).json({ error: 'NotFound', message: `Rule "${req.params.ruleId}" not found` });
      }
      if (req.body && typeof req.body.enabled === 'boolean') {
        rule.enabled = req.body.enabled;
      }
      try {
        this.saveConfig(config);
      } catch (_) { /* non-critical */ }
      res.json(rule);
    });

    this._logger.info && this._logger.info('Code governance routes registered', {
      routes: [
        'GET /api/governance/rules',
        'POST /api/governance/validate',
        'GET /api/governance/config',
        'PUT /api/governance/rules/:ruleId',
      ],
    });
  }
}

module.exports = { CodeGovernance };
