'use strict';

/**
 * HeadyStack — Service-to-Service Handshake
 * Challenge/response authentication and mutual TLS support
 * for inter-service communication.
 */

const crypto = require('crypto');
const { EventEmitter } = require('events');

const CHALLENGE_TTL_MS = 30_000;       // 30 seconds
const HMAC_ALGORITHM = 'sha256';
const TOKEN_BYTES = 32;

class Handshake extends EventEmitter {
  /**
   * @param {object} options
   * @param {string} options.serviceId - Identity of this service
   * @param {string} [options.sharedSecret] - HMAC signing secret
   * @param {object} [options.logger]
   * @param {boolean} [options.mtls] - Whether mutual TLS is enforced
   */
  constructor(options = {}) {
    super();
    if (!options.serviceId) throw new Error('Handshake: serviceId is required');

    this._serviceId = options.serviceId;
    this._sharedSecret = options.sharedSecret || process.env.HEADY_API_KEY || 'heady-default-handshake-secret';
    this._logger = options.logger || console;
    this._mtls = options.mtls || false;
    this._pendingChallenges = new Map(); // token → { serviceId, issuedAt, nonce }
    this._trustedServices = new Map();   // serviceId → { sharedSecret, lastSeen }
    this._cleanupTimer = null;
    this._startCleanup();
  }

  /**
   * Register a trusted peer service with its shared secret.
   * @param {string} peerServiceId
   * @param {string} peerSecret
   */
  registerPeer(peerServiceId, peerSecret) {
    this._trustedServices.set(peerServiceId, {
      sharedSecret: peerSecret,
      registeredAt: new Date(),
      lastSeen: null,
    });
  }

  /**
   * Issue a challenge token for a peer service.
   * @param {string} serviceId - ID of the service being challenged
   * @returns {{ token: string, nonce: string, issuedAt: string, expiresAt: string }}
   */
  challenge(serviceId) {
    const token = crypto.randomBytes(TOKEN_BYTES).toString('hex');
    const nonce = crypto.randomBytes(16).toString('hex');
    const issuedAt = Date.now();
    const expiresAt = issuedAt + CHALLENGE_TTL_MS;

    this._pendingChallenges.set(token, {
      serviceId,
      nonce,
      issuedAt,
      expiresAt,
    });

    this._logger.debug && this._logger.debug('Handshake challenge issued', {
      serviceId,
      token: token.slice(0, 8) + '…',
      expiresIn: `${CHALLENGE_TTL_MS / 1000}s`,
    });

    this.emit('challenge:issued', { serviceId, token });

    return {
      token,
      nonce,
      issuedAt: new Date(issuedAt).toISOString(),
      expiresAt: new Date(expiresAt).toISOString(),
    };
  }

  /**
   * Compute the expected HMAC response to a challenge.
   * @param {string} token - Challenge token
   * @param {string} nonce - Challenge nonce
   * @param {string} secret - Shared secret to sign with
   * @returns {string} hex HMAC
   */
  computeResponse(token, nonce, secret) {
    const payload = `${token}:${nonce}:${this._serviceId}`;
    return crypto.createHmac(HMAC_ALGORITHM, secret)
      .update(payload)
      .digest('hex');
  }

  /**
   * Verify a challenge response from a peer service.
   * @param {string} serviceId - Claiming identity
   * @param {string} token - Challenge token
   * @param {string} response - HMAC response from peer
   * @returns {{ valid: boolean, reason?: string }}
   */
  verify(serviceId, token, response) {
    const pending = this._pendingChallenges.get(token);
    if (!pending) {
      return { valid: false, reason: 'UNKNOWN_CHALLENGE' };
    }

    if (pending.serviceId !== serviceId) {
      return { valid: false, reason: 'SERVICE_ID_MISMATCH' };
    }

    if (Date.now() > pending.expiresAt) {
      this._pendingChallenges.delete(token);
      return { valid: false, reason: 'CHALLENGE_EXPIRED' };
    }

    // Determine secret to verify against
    const peer = this._trustedServices.get(serviceId);
    const secret = (peer && peer.sharedSecret) || this._sharedSecret;

    const expected = this.computeResponse(token, pending.nonce, secret);

    let valid;
    try {
      valid = crypto.timingSafeEqual(
        Buffer.from(expected, 'hex'),
        Buffer.from(response, 'hex')
      );
    } catch (_) {
      valid = false;
    }

    // Consume the challenge (single-use)
    this._pendingChallenges.delete(token);

    if (valid) {
      if (peer) peer.lastSeen = new Date();
      this.emit('handshake:verified', { serviceId });
      this._logger.info && this._logger.info('Handshake verified', { serviceId });
    } else {
      this.emit('handshake:failed', { serviceId, reason: 'HMAC_MISMATCH' });
      this._logger.warn && this._logger.warn('Handshake failed: HMAC mismatch', { serviceId });
    }

    return { valid, reason: valid ? undefined : 'HMAC_MISMATCH' };
  }

  /**
   * Generate a signed service token for use in Authorization headers.
   * @param {string} targetServiceId
   * @returns {string} Bearer-compatible token
   */
  signServiceToken(targetServiceId) {
    const peer = this._trustedServices.get(targetServiceId);
    const secret = (peer && peer.sharedSecret) || this._sharedSecret;
    const nonce = crypto.randomBytes(16).toString('hex');
    const ts = Date.now();
    const payload = `${this._serviceId}:${targetServiceId}:${ts}:${nonce}`;
    const sig = crypto.createHmac(HMAC_ALGORITHM, secret).update(payload).digest('hex');
    const tokenData = Buffer.from(JSON.stringify({ payload, sig })).toString('base64url');
    return tokenData;
  }

  /**
   * Validate an incoming service token.
   * @param {string} tokenData
   * @param {string} claimingServiceId
   * @returns {{ valid: boolean, sourceServiceId?: string, reason?: string }}
   */
  validateServiceToken(tokenData, claimingServiceId) {
    let parsed;
    try {
      parsed = JSON.parse(Buffer.from(tokenData, 'base64url').toString('utf8'));
    } catch (_) {
      return { valid: false, reason: 'MALFORMED_TOKEN' };
    }

    const { payload, sig } = parsed;
    if (!payload || !sig) return { valid: false, reason: 'MISSING_FIELDS' };

    const parts = payload.split(':');
    if (parts.length < 4) return { valid: false, reason: 'INVALID_PAYLOAD' };

    const [sourceServiceId, targetServiceId, ts, nonce] = parts;
    if (targetServiceId !== this._serviceId) {
      return { valid: false, reason: 'WRONG_TARGET' };
    }
    if (claimingServiceId && sourceServiceId !== claimingServiceId) {
      return { valid: false, reason: 'SERVICE_ID_MISMATCH' };
    }

    // Check age (5 minutes)
    if (Date.now() - parseInt(ts, 10) > 5 * 60 * 1000) {
      return { valid: false, reason: 'TOKEN_EXPIRED' };
    }

    const peer = this._trustedServices.get(sourceServiceId);
    const secret = (peer && peer.sharedSecret) || this._sharedSecret;
    const expected = crypto.createHmac(HMAC_ALGORITHM, secret).update(payload).digest('hex');

    let valid;
    try {
      valid = crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(sig, 'hex'));
    } catch (_) {
      valid = false;
    }

    if (valid && peer) peer.lastSeen = new Date();

    return { valid, sourceServiceId: valid ? sourceServiceId : undefined, reason: valid ? undefined : 'HMAC_MISMATCH' };
  }

  /**
   * Express middleware that enforces service handshake auth.
   * @returns {function}
   */
  middleware() {
    return (req, res, next) => {
      const authHeader = req.headers['x-heady-service-token'];
      if (!authHeader) {
        return res.status(401).json({ error: 'AuthError', code: 'MISSING_SERVICE_TOKEN', message: 'Service token required' });
      }

      const claimingId = req.headers['x-heady-service-id'];
      const result = this.validateServiceToken(authHeader, claimingId);
      if (!result.valid) {
        return res.status(401).json({ error: 'AuthError', code: result.reason, message: 'Service token invalid' });
      }

      req.serviceId = result.sourceServiceId;
      next();
    };
  }

  /**
   * mTLS: Read client certificate from request and validate.
   * Express must be configured with `https.createServer({ requestCert: true, ... })`.
   * @returns {function} Express middleware
   */
  mtlsMiddleware() {
    return (req, res, next) => {
      if (!this._mtls) return next();
      const cert = req.socket && req.socket.getPeerCertificate && req.socket.getPeerCertificate();
      if (!cert || !cert.subject) {
        return res.status(401).json({ error: 'AuthError', code: 'MTLS_REQUIRED', message: 'Client certificate required' });
      }
      req.peerCert = cert;
      next();
    };
  }

  /**
   * Cleanup expired pending challenges.
   * @private
   */
  _startCleanup() {
    this._cleanupTimer = setInterval(() => {
      const now = Date.now();
      for (const [token, meta] of this._pendingChallenges.entries()) {
        if (now > meta.expiresAt) {
          this._pendingChallenges.delete(token);
        }
      }
    }, 60_000);
    if (this._cleanupTimer.unref) this._cleanupTimer.unref();
  }

  destroy() {
    if (this._cleanupTimer) {
      clearInterval(this._cleanupTimer);
      this._cleanupTimer = null;
    }
    this._pendingChallenges.clear();
  }
}

module.exports = { Handshake };
