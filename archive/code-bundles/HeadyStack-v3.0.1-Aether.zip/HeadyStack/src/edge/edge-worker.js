'use strict';

/**
 * HeadyStack — Cloudflare Worker Script
 * Handles edge routing, caching, KV access, and embedding generation.
 *
 * This file is designed to be deployed as a Cloudflare Worker (Module Syntax).
 * For local development, the HeadyEdgeDaemon wraps this logic.
 *
 * Cloudflare Worker bindings expected:
 *   env.HEADY_KV          — KV Namespace binding
 *   env.HEADY_CACHE       — Cache API (use caches.default)
 *   env.HEADY_API_KEY     — Heady internal API key
 *   env.HEADY_ORIGIN      — Origin server URL
 */

// ──────────────────────────────────────────────
// Route table
// ──────────────────────────────────────────────
const ROUTES = [
  { pattern: /^\/api\/embed($|\/)/, handler: handleEmbedRequest, cache: false },
  { pattern: /^\/api\/kv($|\/)/, handler: handleKVRequest, cache: false },
  { pattern: /^\/api\/health$/, handler: handleHealthCheck, cache: false },
  { pattern: /^\/static\//, handler: handleStaticAsset, cache: true, ttl: 86400 },
  { pattern: /^\/_edge\//, handler: handleEdgeInternal, cache: false },
];

// ──────────────────────────────────────────────
// Main request handler
// ──────────────────────────────────────────────
async function handleRequest(request, env, ctx) {
  const url = new URL(request.url);
  const { pathname } = url;

  // Security: block non-Heady origins in production
  const origin = request.headers.get('Origin') || '';
  if (origin && !isAllowedOrigin(origin)) {
    return new Response('Forbidden', { status: 403 });
  }

  // Dispatch to route handlers
  for (const route of ROUTES) {
    if (route.pattern.test(pathname)) {
      try {
        // Check cache for cacheable routes
        if (route.cache && ctx) {
          const cache = caches.default;
          const cacheKey = new Request(request.url, request);
          const cached = await cache.match(cacheKey);
          if (cached) {
            return withCORSHeaders(cached, origin);
          }
          const response = await route.handler(request, env, ctx, url);
          ctx.waitUntil(cache.put(cacheKey, response.clone()));
          return withCORSHeaders(response, origin);
        }
        const response = await route.handler(request, env, ctx, url);
        return withCORSHeaders(response, origin);
      } catch (err) {
        return errorResponse(err, 500);
      }
    }
  }

  // Pass-through to origin
  return proxyToOrigin(request, env);
}

// ──────────────────────────────────────────────
// Route handlers
// ──────────────────────────────────────────────

/**
 * /api/embed — Generate text embeddings at the edge
 * POST { text: string } → { embedding: number[], model: string, dim: number }
 */
async function handleEmbedRequest(request, env) {
  if (request.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }

  let body;
  try {
    body = await request.json();
  } catch (_) {
    return new Response(JSON.stringify({ error: 'Invalid JSON body' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const text = body && body.text;
  if (!text || typeof text !== 'string') {
    return new Response(JSON.stringify({ error: 'text (string) is required' }), {
      status: 422,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // Use Cloudflare Workers AI if available, otherwise forward to origin
  if (env && env.AI) {
    try {
      const result = await env.AI.run('@cf/baai/bge-small-en-v1.5', { text: [text] });
      const embedding = result.data[0];
      return jsonResponse({ embedding, model: '@cf/baai/bge-small-en-v1.5', dim: embedding.length });
    } catch (aiErr) {
      // Fall through to origin proxy on AI error
    }
  }

  // Fallback: forward to origin
  return proxyToOrigin(request, env);
}

/**
 * /api/kv — KV Store access
 * GET /api/kv?key=xxx → { key, value }
 * PUT /api/kv { key, value, ttl? } → { ok: true }
 * DELETE /api/kv?key=xxx → { ok: true }
 */
async function handleKVRequest(request, env, ctx, url) {
  if (!env || !env.HEADY_KV) {
    return new Response(JSON.stringify({ error: 'KV binding not configured' }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  const key = url.searchParams.get('key');

  if (request.method === 'GET') {
    if (!key) return new Response(JSON.stringify({ error: 'key param required' }), { status: 422, headers: { 'Content-Type': 'application/json' } });
    const value = await env.HEADY_KV.get(key);
    if (value === null) return new Response(JSON.stringify({ key, value: null, found: false }), { status: 404, headers: { 'Content-Type': 'application/json' } });
    return jsonResponse({ key, value, found: true });
  }

  if (request.method === 'PUT') {
    const body = await request.json();
    if (!body.key) return new Response(JSON.stringify({ error: 'key required' }), { status: 422, headers: { 'Content-Type': 'application/json' } });
    const opts = body.ttl ? { expirationTtl: body.ttl } : undefined;
    await env.HEADY_KV.put(body.key, JSON.stringify(body.value), opts);
    return jsonResponse({ ok: true, key: body.key });
  }

  if (request.method === 'DELETE') {
    if (!key) return new Response(JSON.stringify({ error: 'key param required' }), { status: 422, headers: { 'Content-Type': 'application/json' } });
    await env.HEADY_KV.delete(key);
    return jsonResponse({ ok: true, key });
  }

  return new Response('Method Not Allowed', { status: 405 });
}

/**
 * /api/health — Edge health check
 */
async function handleHealthCheck(request, env) {
  return jsonResponse({
    status: 'ok',
    edge: true,
    timestamp: new Date().toISOString(),
    kv: !!(env && env.HEADY_KV),
    ai: !!(env && env.AI),
  });
}

/**
 * /static/* — Static asset handler with cache
 */
async function handleStaticAsset(request, env) {
  return proxyToOrigin(request, env);
}

/**
 * /_edge/* — Internal edge management endpoints
 */
async function handleEdgeInternal(request, env, ctx, url) {
  const apiKey = request.headers.get('X-Heady-API-Key');
  const expectedKey = env && env.HEADY_API_KEY;
  if (!apiKey || apiKey !== expectedKey) {
    return new Response('Unauthorized', { status: 401 });
  }

  const subpath = url.pathname.replace('/_edge/', '');

  if (subpath === 'cache/purge') {
    return jsonResponse({ ok: true, message: 'Cache purge acknowledged' });
  }

  if (subpath === 'info') {
    return jsonResponse({
      version: '3.0.1',
      codename: 'Aether',
      timestamp: new Date().toISOString(),
    });
  }

  return new Response(JSON.stringify({ error: 'Unknown edge endpoint' }), {
    status: 404,
    headers: { 'Content-Type': 'application/json' },
  });
}

// ──────────────────────────────────────────────
// Helpers
// ──────────────────────────────────────────────

async function proxyToOrigin(request, env) {
  const originUrl = (env && env.HEADY_ORIGIN) || process.env.HEADY_ORIGIN || 'https://headyapi.com';
  const url = new URL(request.url);
  const targetUrl = originUrl.replace(/\/$/, '') + url.pathname + url.search;

  const proxyRequest = new Request(targetUrl, {
    method: request.method,
    headers: request.headers,
    body: ['GET', 'HEAD'].includes(request.method) ? null : request.body,
    redirect: 'follow',
  });

  return fetch(proxyRequest);
}

function jsonResponse(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });
}

function errorResponse(err, status = 500) {
  return new Response(
    JSON.stringify({ error: err.name || 'Error', message: err.message }),
    { status, headers: { 'Content-Type': 'application/json' } }
  );
}

function withCORSHeaders(response, origin) {
  const newHeaders = new Headers(response.headers);
  if (origin && isAllowedOrigin(origin)) {
    newHeaders.set('Access-Control-Allow-Origin', origin);
    newHeaders.set('Vary', 'Origin');
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: newHeaders,
  });
}

const ALLOWED_ORIGIN_PATTERNS = [
  /^https:\/\/(www\.)?headyme\.com$/,
  /^https:\/\/(www\.)?headysystems\.com$/,
  /^https:\/\/(www\.)?headyconnection\.org$/,
  /^https:\/\/(www\.)?headyai\.org$/,
  /^https:\/\/(www\.)?headymcp\.com$/,
  /^https:\/\/(www\.)?headyapi\.com$/,
  /^https:\/\/(www\.)?headybuddy\.com$/,
  /^https:\/\/(www\.)?headybot\.com$/,
  /^https:\/\/(www\.)?headyio\.com$/,
  /^http:\/\/localhost(:\d+)?$/,
  /^http:\/\/127\.0\.0\.1(:\d+)?$/,
];

function isAllowedOrigin(origin) {
  return ALLOWED_ORIGIN_PATTERNS.some((re) => re.test(origin));
}

// Cloudflare Worker Module export
module.exports = { handleRequest, handleEmbedRequest, handleKVRequest, handleHealthCheck, isAllowedOrigin };

// For Workers Module syntax (when bundled for CF):
// export default { fetch: handleRequest };
