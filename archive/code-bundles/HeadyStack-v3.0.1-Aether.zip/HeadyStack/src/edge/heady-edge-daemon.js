'use strict';

/**
 * HeadyStack — Edge Daemon for Local Deployments
 * Runs an HTTP server that mimics Cloudflare Worker edge behavior locally.
 * Registers with the central conductor and accepts routing rules dynamically.
 */

const http = require('http');
const https = require('https');
const { EventEmitter } = require('events');
const crypto = require('crypto');

const DEFAULT_PORT = 9876;
const CONDUCTOR_URL = process.env.HEADY_CONDUCTOR_URL || 'http://localhost:8080';
const HEARTBEAT_INTERVAL_MS = 15_000;

class HeadyEdgeDaemon extends EventEmitter {
  /**
   * @param {object} options
   * @param {object} [options.logger]
   * @param {string} [options.serviceId]
   * @param {string} [options.conductorUrl]
   * @param {object} [options.kvStore] - In-memory KV fallback store
   */
  constructor(options = {}) {
    super();
    this._logger = options.logger || console;
    this._serviceId = options.serviceId || `edge-daemon-${crypto.randomBytes(4).toString('hex')}`;
    this._conductorUrl = options.conductorUrl || CONDUCTOR_URL;
    this._kvStore = options.kvStore || new Map();
    this._server = null;
    this._port = null;
    this._running = false;
    this._heartbeatTimer = null;
    this._routes = [];         // Dynamic route table from conductor
    this._middlewares = [];    // Edge middleware stack
    this._stats = { requests: 0, errors: 0, cacheHits: 0 };
    this._cache = new Map();   // In-memory response cache
  }

  /**
   * Start the edge daemon.
   * @param {number} [port]
   * @returns {Promise<void>}
   */
  async start(port) {
    this._port = port || DEFAULT_PORT;
    if (this._running) {
      this._logger.warn && this._logger.warn('HeadyEdgeDaemon already running', { port: this._port });
      return;
    }

    return new Promise((resolve, reject) => {
      this._server = http.createServer((req, res) => {
        this._handleRequest(req, res).catch((err) => {
          this._stats.errors++;
          this._logger.error && this._logger.error('Edge daemon request error', { error: err.message });
          if (!res.headersSent) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'InternalError', message: err.message }));
          }
        });
      });

      this._server.on('error', (err) => {
        this._logger.error && this._logger.error('Edge daemon server error', { error: err.message });
        this.emit('error', err);
        reject(err);
      });

      this._server.listen(this._port, () => {
        this._running = true;
        this._logger.info && this._logger.info('HeadyEdgeDaemon started', {
          port: this._port,
          serviceId: this._serviceId,
        });
        this.emit('started', { port: this._port, serviceId: this._serviceId });
        this._startHeartbeat();
        this._registerWithConductor().catch((err) => {
          this._logger.warn && this._logger.warn('Failed to register with conductor', { error: err.message });
        });
        resolve();
      });
    });
  }

  /**
   * Stop the edge daemon.
   * @returns {Promise<void>}
   */
  async stop() {
    this._stopHeartbeat();
    if (!this._server) return;
    return new Promise((resolve) => {
      this._server.close(() => {
        this._running = false;
        this._logger.info && this._logger.info('HeadyEdgeDaemon stopped');
        this.emit('stopped');
        resolve();
      });
    });
  }

  /**
   * Request handler — processes incoming edge requests.
   * @private
   */
  async _handleRequest(req, res) {
    this._stats.requests++;
    const url = new URL(req.url, `http://localhost:${this._port}`);
    const pathname = url.pathname;
    const method = req.method;
    const origin = req.headers['origin'] || '';

    // CORS preflight
    if (method === 'OPTIONS') {
      res.writeHead(204, {
        'Access-Control-Allow-Origin': origin || '*',
        'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Heady-API-Key,X-Heady-Service-Token',
        'Access-Control-Max-Age': '86400',
      });
      res.end();
      return;
    }

    // Edge daemon management endpoints
    if (pathname === '/_edge/health') {
      this._sendJSON(res, 200, { status: 'ok', serviceId: this._serviceId, uptime: process.uptime(), stats: this._stats });
      return;
    }

    if (pathname === '/_edge/routes') {
      this._sendJSON(res, 200, { routes: this._routes });
      return;
    }

    if (pathname === '/_edge/cache/clear' && method === 'POST') {
      this._cache.clear();
      this._sendJSON(res, 200, { ok: true, cleared: true });
      return;
    }

    if (pathname === '/_edge/kv' ) {
      await this._handleKV(req, res, url, method);
      return;
    }

    // Check dynamic routes from conductor
    for (const route of this._routes) {
      let match = false;
      if (route.pattern) {
        try {
          match = new RegExp(route.pattern).test(pathname);
        } catch (_) {
          match = pathname.startsWith(route.pattern);
        }
      }
      if (match) {
        await this._proxyToTarget(req, res, route.target, { origin });
        return;
      }
    }

    // Default: proxy to conductor/origin
    await this._proxyToConductor(req, res, { origin });
  }

  /**
   * KV store CRUD handler.
   * @private
   */
  async _handleKV(req, res, url, method) {
    const key = url.searchParams.get('key');

    if (method === 'GET') {
      if (!key) { this._sendJSON(res, 422, { error: 'key required' }); return; }
      const val = this._kvStore.get(key);
      this._sendJSON(res, val !== undefined ? 200 : 404, { key, value: val !== undefined ? val : null, found: val !== undefined });
      return;
    }

    if (method === 'PUT') {
      const body = await this._readBody(req);
      let parsed;
      try { parsed = JSON.parse(body); } catch (_) { this._sendJSON(res, 400, { error: 'Invalid JSON' }); return; }
      this._kvStore.set(parsed.key, parsed.value);
      if (parsed.ttl) setTimeout(() => this._kvStore.delete(parsed.key), parsed.ttl * 1000);
      this._sendJSON(res, 200, { ok: true, key: parsed.key });
      return;
    }

    if (method === 'DELETE') {
      if (!key) { this._sendJSON(res, 422, { error: 'key required' }); return; }
      const existed = this._kvStore.has(key);
      this._kvStore.delete(key);
      this._sendJSON(res, 200, { ok: true, key, existed });
      return;
    }

    this._sendJSON(res, 405, { error: 'Method Not Allowed' });
  }

  /**
   * Proxy request to a specific target URL.
   * @private
   */
  async _proxyToTarget(req, res, targetBase, context) {
    const body = ['GET', 'HEAD'].includes(req.method) ? null : await this._readBody(req);
    const url = new URL(req.url, `http://localhost:${this._port}`);
    const targetUrl = `${targetBase.replace(/\/$/, '')}${url.pathname}${url.search}`;

    const options = new URL(targetUrl);
    const client = options.protocol === 'https:' ? https : http;

    return new Promise((resolve, reject) => {
      const proxyReq = client.request({
        hostname: options.hostname,
        port: options.port || (options.protocol === 'https:' ? 443 : 80),
        path: options.pathname + options.search,
        method: req.method,
        headers: { ...req.headers, host: options.hostname },
      }, (proxyRes) => {
        res.writeHead(proxyRes.statusCode, proxyRes.headers);
        proxyRes.pipe(res, { end: true });
        proxyRes.on('end', resolve);
      });

      proxyReq.on('error', (err) => {
        if (!res.headersSent) {
          res.writeHead(502);
          res.end('Bad Gateway');
        }
        resolve();
      });

      if (body) proxyReq.write(body);
      proxyReq.end();
    });
  }

  /**
   * Proxy to conductor/origin.
   * @private
   */
  async _proxyToConductor(req, res, context) {
    try {
      await this._proxyToTarget(req, res, this._conductorUrl, context);
    } catch (err) {
      if (!res.headersSent) {
        res.writeHead(502, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'ProxyError', message: err.message }));
      }
    }
  }

  /**
   * Register this daemon with the central conductor.
   * @private
   */
  async _registerWithConductor() {
    const payload = JSON.stringify({
      serviceId: this._serviceId,
      type: 'edge-daemon',
      port: this._port,
      host: require('os').hostname(),
      startedAt: new Date().toISOString(),
    });

    await this._httpPost(`${this._conductorUrl}/api/conductor/register`, payload);
    this._logger.info && this._logger.info('Registered with conductor', { conductorUrl: this._conductorUrl });
  }

  /**
   * Start heartbeat timer.
   * @private
   */
  _startHeartbeat() {
    this._heartbeatTimer = setInterval(async () => {
      try {
        const payload = JSON.stringify({
          serviceId: this._serviceId,
          uptime: process.uptime(),
          stats: this._stats,
          timestamp: new Date().toISOString(),
        });
        await this._httpPost(`${this._conductorUrl}/api/conductor/heartbeat`, payload);
      } catch (_) { /* silent — conductor may be down */ }
    }, HEARTBEAT_INTERVAL_MS);
    if (this._heartbeatTimer.unref) this._heartbeatTimer.unref();
  }

  _stopHeartbeat() {
    if (this._heartbeatTimer) {
      clearInterval(this._heartbeatTimer);
      this._heartbeatTimer = null;
    }
  }

  /**
   * Update dynamic routes from conductor.
   * @param {object[]} routes
   */
  updateRoutes(routes) {
    this._routes = routes || [];
    this._logger.info && this._logger.info('Edge daemon routes updated', { count: this._routes.length });
  }

  // ── Utility ──────────────────────────────────

  _sendJSON(res, status, data) {
    const body = JSON.stringify(data);
    res.writeHead(status, { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) });
    res.end(body);
  }

  _readBody(req) {
    return new Promise((resolve) => {
      const chunks = [];
      req.on('data', (c) => chunks.push(c));
      req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
      req.on('error', () => resolve(''));
    });
  }

  _httpPost(url, body) {
    return new Promise((resolve, reject) => {
      const parsed = new URL(url);
      const client = parsed.protocol === 'https:' ? https : http;
      const req = client.request({
        hostname: parsed.hostname,
        port: parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
        path: parsed.pathname + parsed.search,
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      }, (res) => {
        res.resume();
        res.on('end', resolve);
      });
      req.on('error', reject);
      req.write(body);
      req.end();
    });
  }

  get isRunning() { return this._running; }
  get port() { return this._port; }
  get serviceId() { return this._serviceId; }
  get stats() { return { ...this._stats }; }
}

module.exports = { HeadyEdgeDaemon };
