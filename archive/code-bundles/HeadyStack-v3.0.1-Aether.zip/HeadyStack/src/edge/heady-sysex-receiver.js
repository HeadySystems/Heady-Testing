'use strict';

/**
 * HeadyStack — SysEx MIDI Message Receiver
 * Handles MIDI System Exclusive messages for system control.
 * Supports WebMIDI (browser), node-midi, and raw buffer parsing.
 *
 * SysEx message format:
 *   [0xF0, manufacturerId(1B), deviceId(1B), command(1B), ...data, 0xF7]
 *
 * HeadyStack manufacturer ID: 0x7D (non-commercial / educational)
 */

const { EventEmitter } = require('events');
const crypto = require('crypto');

// HeadyStack SysEx identifiers
const HEADY_MANUFACTURER_ID = 0x7D;
const SYSEX_START = 0xF0;
const SYSEX_END   = 0xF7;

// Command byte definitions
const COMMANDS = {
  0x01: 'PING',
  0x02: 'CONFIG_SET',
  0x03: 'CONFIG_GET',
  0x04: 'SYSTEM_RESET',
  0x05: 'MUTE_CHANNEL',
  0x06: 'UNMUTE_CHANNEL',
  0x07: 'SET_TEMPO',
  0x08: 'SCENE_RECALL',
  0x09: 'SCENE_STORE',
  0x0A: 'TRANSPORT_PLAY',
  0x0B: 'TRANSPORT_STOP',
  0x0C: 'TRANSPORT_RECORD',
  0x0D: 'VOLUME_SET',
  0x0E: 'PATCH_CHANGE',
  0x10: 'HEADY_CUSTOM',     // Custom HeadyStack command
  0x11: 'VECTOR_PUSH',      // Push vector embedding via MIDI
  0x12: 'EVENT_BUS_EMIT',   // Emit event bus event
  0x7F: 'IDENTITY_REQUEST',
};

class HeadySysexReceiver extends EventEmitter {
  /**
   * @param {object} options
   * @param {object} [options.logger]
   * @param {object} [options.eventBus] - HeadyStack event bus
   * @param {number} [options.deviceId] - MIDI device ID (default 0x00 = broadcast)
   * @param {boolean} [options.strict] - Reject unknown commands
   */
  constructor(options = {}) {
    super();
    this._logger = options.logger || console;
    this._eventBus = options.eventBus || null;
    this._deviceId = options.deviceId != null ? options.deviceId : 0x00;
    this._strict = options.strict || false;
    this._sessions = new Map();   // channel → { muted, volume, patch }
    this._messageCount = 0;
    this._errorCount = 0;
    this._midiInput = null;       // node-midi input (if attached)
    this._buffer = [];            // accumulation buffer for streaming input
    this._inSysEx = false;
  }

  /**
   * Process a raw SysEx buffer or byte array.
   * @param {Buffer|number[]} data
   * @returns {{ command: string, deviceId: number, data: number[], parsed: object }|null}
   */
  processMessage(data) {
    const bytes = Array.from(data);

    // Validate SysEx framing
    if (bytes[0] !== SYSEX_START) {
      this._errorCount++;
      this._logger.warn && this._logger.warn('SysEx: Invalid start byte', { byte: bytes[0] });
      return null;
    }
    if (bytes[bytes.length - 1] !== SYSEX_END) {
      this._errorCount++;
      this._logger.warn && this._logger.warn('SysEx: Missing end byte');
      return null;
    }

    // Parse header: [F0, mfr, device, cmd, ...data..., F7]
    if (bytes.length < 5) {
      this._errorCount++;
      return null;
    }

    const manufacturerId = bytes[1];
    const deviceId = bytes[2];
    const commandByte = bytes[3];
    const payload = bytes.slice(4, bytes.length - 1);

    // Validate manufacturer
    if (manufacturerId !== HEADY_MANUFACTURER_ID) {
      // Not for us — emit but don't process
      this.emit('sysex:foreign', { manufacturerId, deviceId, commandByte, payload });
      return null;
    }

    // Validate device ID (0x00 = broadcast, or must match our device ID)
    if (deviceId !== 0x00 && deviceId !== this._deviceId) {
      return null;
    }

    const commandName = COMMANDS[commandByte] || `UNKNOWN_0x${commandByte.toString(16).toUpperCase()}`;

    if (this._strict && !COMMANDS[commandByte]) {
      this._errorCount++;
      this._logger.warn && this._logger.warn(`SysEx: Unknown command byte 0x${commandByte.toString(16)}`, { commandByte });
      return null;
    }

    this._messageCount++;

    const parsed = this._parsePayload(commandByte, commandName, payload);

    const message = { command: commandName, commandByte, deviceId, data: payload, parsed };

    this._logger.debug && this._logger.debug('SysEx received', {
      command: commandName,
      deviceId,
      payloadBytes: payload.length,
    });

    // Dispatch
    this._dispatch(message);

    return message;
  }

  /**
   * Parse command-specific payload.
   * @private
   */
  _parsePayload(commandByte, commandName, payload) {
    switch (commandByte) {
      case 0x01: // PING
        return { timestamp: Date.now() };

      case 0x02: { // CONFIG_SET — payload: [keyLen, ...key bytes, valueLen, ...value bytes]
        if (payload.length < 2) return { raw: payload };
        const keyLen = payload[0];
        const key = Buffer.from(payload.slice(1, 1 + keyLen)).toString('ascii');
        const valueBytes = payload.slice(1 + keyLen);
        const value = Buffer.from(valueBytes).toString('utf8');
        return { key, value };
      }

      case 0x05: // MUTE_CHANNEL
      case 0x06: // UNMUTE_CHANNEL
        return { channel: payload[0] };

      case 0x07: // SET_TEMPO — 3 bytes BPM (MSB, mid, LSB) in 14-bit MIDI
        if (payload.length >= 2) {
          const bpm = ((payload[0] & 0x7F) << 7) | (payload[1] & 0x7F);
          return { bpm };
        }
        return { raw: payload };

      case 0x08: // SCENE_RECALL
      case 0x09: // SCENE_STORE
        return { sceneId: payload[0], bankId: payload[1] || 0 };

      case 0x0D: // VOLUME_SET
        return { channel: payload[0], volume: payload[1] };

      case 0x0E: // PATCH_CHANGE
        return { channel: payload[0], program: payload[1], bank: payload[2] || 0 };

      case 0x10: // HEADY_CUSTOM — JSON payload encoded as 7-bit MIDI bytes
        try {
          // Decode 7-bit MIDI data back to 8-bit
          const decoded = this._decode7bit(payload);
          return JSON.parse(decoded);
        } catch (_) {
          return { raw: payload };
        }

      case 0x11: { // VECTOR_PUSH — vector bytes (float32 as 7-bit encoded)
        const decoded = this._decode7bit(payload);
        const floats = [];
        for (let i = 0; i + 3 < decoded.length; i += 4) {
          floats.push(Buffer.from(decoded, 'binary').readFloatLE(i));
        }
        return { embedding: floats, dim: floats.length };
      }

      case 0x12: { // EVENT_BUS_EMIT — JSON-encoded event
        try {
          const decoded = this._decode7bit(payload);
          return JSON.parse(decoded);
        } catch (_) {
          return { raw: payload };
        }
      }

      case 0x7F: // IDENTITY_REQUEST
        return {
          manufacturer: HEADY_MANUFACTURER_ID,
          deviceId: this._deviceId,
          version: '3.0.1',
          codename: 'Aether',
        };

      default:
        return { raw: payload };
    }
  }

  /**
   * Dispatch a parsed message to event listeners and event bus.
   * @private
   */
  _dispatch(message) {
    const { command, commandByte, parsed } = message;

    // Emit typed events
    this.emit('sysex', message);
    this.emit(`sysex:${command.toLowerCase()}`, parsed);

    // Handle specific commands internally
    switch (commandByte) {
      case 0x01: // PING → PONG
        this.emit('sysex:pong', { timestamp: Date.now() });
        break;

      case 0x05: // MUTE_CHANNEL
        if (parsed.channel !== undefined) {
          this._setChannelState(parsed.channel, { muted: true });
        }
        break;

      case 0x06: // UNMUTE_CHANNEL
        if (parsed.channel !== undefined) {
          this._setChannelState(parsed.channel, { muted: false });
        }
        break;

      case 0x0D: // VOLUME_SET
        if (parsed.channel !== undefined) {
          this._setChannelState(parsed.channel, { volume: parsed.volume });
        }
        break;

      case 0x12: // EVENT_BUS_EMIT
        if (this._eventBus && parsed.event) {
          try {
            this._eventBus.emit(parsed.event, parsed.data);
          } catch (_) { /* ignore bus errors */ }
        }
        break;

      case 0x7F: // IDENTITY_REQUEST → send identity response
        this.emit('sysex:identity-response', parsed);
        break;
    }
  }

  /**
   * Feed streaming bytes into the receiver.
   * Call this when receiving byte-by-byte from a MIDI stream.
   * @param {number} byte
   */
  feedByte(byte) {
    if (byte === SYSEX_START) {
      this._buffer = [byte];
      this._inSysEx = true;
      return;
    }
    if (!this._inSysEx) return;
    this._buffer.push(byte);
    if (byte === SYSEX_END) {
      this._inSysEx = false;
      this.processMessage(this._buffer);
      this._buffer = [];
    }
  }

  /**
   * Attach a node-midi Input object.
   * @param {object} midiInput - node-midi Input instance
   */
  attachMidiInput(midiInput) {
    this._midiInput = midiInput;
    midiInput.on('message', (deltaTime, message) => {
      if (message[0] === SYSEX_START) {
        this.processMessage(message);
      }
    });
    // Enable SysEx
    if (typeof midiInput.ignoreTypes === 'function') {
      midiInput.ignoreTypes(false, false, false);
    }
    this._logger.info && this._logger.info('SysEx receiver: node-midi input attached');
  }

  /**
   * Build a SysEx message buffer.
   * @param {number} commandByte
   * @param {number[]} payload
   * @param {number} [deviceId]
   * @returns {Buffer}
   */
  buildMessage(commandByte, payload = [], deviceId) {
    const device = deviceId !== undefined ? deviceId : this._deviceId;
    return Buffer.from([SYSEX_START, HEADY_MANUFACTURER_ID, device, commandByte, ...payload, SYSEX_END]);
  }

  /**
   * Encode UTF-8 string to 7-bit MIDI safe bytes.
   * @param {string} str
   * @returns {number[]}
   */
  _encode7bit(str) {
    const bytes = Buffer.from(str, 'utf8');
    const result = [];
    for (const b of bytes) {
      result.push(b & 0x7F);        // low 7 bits
      result.push((b >> 7) & 0x01); // MSB as separate byte
    }
    return result;
  }

  /**
   * Decode 7-bit MIDI bytes to string.
   * @param {number[]} bytes
   * @returns {string}
   */
  _decode7bit(bytes) {
    const result = [];
    for (let i = 0; i + 1 < bytes.length; i += 2) {
      result.push((bytes[i] & 0x7F) | ((bytes[i + 1] & 0x01) << 7));
    }
    return Buffer.from(result).toString('utf8');
  }

  /**
   * Channel state management.
   * @private
   */
  _setChannelState(channel, update) {
    const existing = this._sessions.get(channel) || { muted: false, volume: 100, patch: 0 };
    this._sessions.set(channel, Object.assign(existing, update));
    this.emit('channel:update', { channel, state: this._sessions.get(channel) });
  }

  get stats() {
    return {
      messageCount: this._messageCount,
      errorCount: this._errorCount,
      channels: this._sessions.size,
    };
  }

  get channelStates() {
    return Object.fromEntries(this._sessions.entries());
  }
}

module.exports = { HeadySysexReceiver, HEADY_MANUFACTURER_ID, COMMANDS, SYSEX_START, SYSEX_END };
