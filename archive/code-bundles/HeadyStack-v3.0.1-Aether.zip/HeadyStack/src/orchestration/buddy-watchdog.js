'use strict';

/**
 * @fileoverview HeadyBuddy Hallucination Detection Watchdog
 * Monitors buddy responses for consistency issues, confidence drops,
 * timeouts, and semantic drift. Raises alerts to subscribers.
 *
 * @module orchestration/buddy-watchdog
 */

const { EventEmitter } = require('events');
const logger           = require('../utils/logger');

/** @constant {number} MAX_ALERTS - Maximum alerts to retain in memory */
const MAX_ALERTS = 200;

/** @enum {string} */
const ALERT_TYPE = Object.freeze({
  RESPONSE_INCONSISTENCY: 'RESPONSE_INCONSISTENCY',
  CONFIDENCE_DROP:        'CONFIDENCE_DROP',
  TIMEOUT:                'TIMEOUT',
  HALLUCINATION_DETECTED: 'HALLUCINATION_DETECTED',
  BUDDY_UNRESPONSIVE:     'BUDDY_UNRESPONSIVE',
  SESSION_DRIFT:          'SESSION_DRIFT',
});

/**
 * @class BuddyWatchdog
 * @extends EventEmitter
 * @description Monitors HeadyBuddy response quality and emits alerts
 * when anomalies are detected.
 */
class BuddyWatchdog extends EventEmitter {
  /**
   * @param {object} buddy  - BuddyCore instance to monitor
   * @param {object} [opts={}]
   * @param {number} [opts.responseWindowMs=60000]   - Sliding window for analysis
   * @param {number} [opts.minConfidenceThreshold=0.4] - Alert below this confidence
   * @param {number} [opts.maxResponseTimeMs=15000]   - Alert if response exceeds this
   * @param {number} [opts.inconsistencyThreshold=3]  - Consecutive inconsistencies before alert
   */
  constructor(buddy, opts = {}) {
    super();

    this._buddy         = buddy;
    this._responseWindow    = opts.responseWindowMs      ?? 60000;
    this._minConfidence     = opts.minConfidenceThreshold ?? 0.4;
    this._maxResponseTime   = opts.maxResponseTimeMs      ?? 15000;
    this._inconsistencyThreshold = opts.inconsistencyThreshold ?? 3;

    this._intervalId        = null;
    this._running           = false;

    this._alerts            = [];
    this._responseLog       = [];  // { at, sessionId, durationMs, confidence, content }
    this._consecutiveErrors = 0;

    this._totalChecks     = 0;
    this._totalAlerts     = 0;
    this._createdAt       = Date.now();

    // Listen to buddy events for real-time monitoring
    if (buddy && typeof buddy.on === 'function') {
      buddy.on('chat:response', (evt) => this._onResponse(evt));
    }
  }

  // ─── Lifecycle ───────────────────────────────────────────────────────────────

  /**
   * Starts the watchdog periodic check loop.
   * @param {number} [intervalMs=10000] - Check interval in ms
   * @returns {BuddyWatchdog} this
   */
  start(intervalMs = 10000) {
    if (this._running) return this;

    this._running    = true;
    this._intervalId = setInterval(() => this.check(), intervalMs);
    if (this._intervalId.unref) this._intervalId.unref();

    logger.logNodeActivity('BUDDY-WATCHDOG',
      `Watchdog started (interval: ${intervalMs}ms)`);
    return this;
  }

  /**
   * Stops the watchdog.
   * @returns {BuddyWatchdog} this
   */
  stop() {
    if (!this._running) return this;

    this._running = false;
    if (this._intervalId) {
      clearInterval(this._intervalId);
      this._intervalId = null;
    }

    logger.logNodeActivity('BUDDY-WATCHDOG', 'Watchdog stopped');
    return this;
  }

  // ─── Core Check ──────────────────────────────────────────────────────────────

  /**
   * Runs a full consistency and health check on the buddy.
   * @returns {Promise<object[]>} Array of any new alerts raised
   */
  async check() {
    this._totalChecks++;
    const newAlerts = [];

    // 1. Check if buddy is responsive
    const buddyStatus = this._buddy ? this._buddy.getStatus?.() : null;
    if (!buddyStatus) {
      const alert = this._raise(ALERT_TYPE.BUDDY_UNRESPONSIVE, {
        message: 'BuddyCore.getStatus() returned null — buddy may be crashed',
        severity: 'critical',
      });
      newAlerts.push(alert);
      return newAlerts;
    }

    // 2. Check error rate
    if (buddyStatus.totalErrors > 0 && buddyStatus.totalMessages > 0) {
      const errRate = buddyStatus.totalErrors / buddyStatus.totalMessages;
      if (errRate > 0.3) {
        const alert = this._raise(ALERT_TYPE.CONFIDENCE_DROP, {
          message: `High error rate: ${(errRate * 100).toFixed(1)}%`,
          errorRate: errRate,
          severity: 'warning',
        });
        newAlerts.push(alert);
      }
    }

    // 3. Analyze response log for consistency
    this._pruneResponseLog();
    const inconsistencies = this._detectInconsistencies();
    if (inconsistencies.count >= this._inconsistencyThreshold) {
      const alert = this._raise(ALERT_TYPE.RESPONSE_INCONSISTENCY, {
        message: `Detected ${inconsistencies.count} inconsistent responses in window`,
        samples: inconsistencies.samples,
        severity: 'warning',
      });
      newAlerts.push(alert);
    }

    // 4. Check for slow responses
    const slowResponses = this._responseLog.filter(
      r => r.durationMs > this._maxResponseTime
    );
    if (slowResponses.length > 0) {
      const worst = Math.max(...slowResponses.map(r => r.durationMs));
      const alert = this._raise(ALERT_TYPE.TIMEOUT, {
        message:      `${slowResponses.length} responses exceeded ${this._maxResponseTime}ms`,
        worstMs:      worst,
        count:        slowResponses.length,
        severity:     worst > this._maxResponseTime * 2 ? 'critical' : 'warning',
      });
      newAlerts.push(alert);
    }

    // 5. Check confidence drop
    const lowConfidence = this._responseLog.filter(
      r => r.confidence !== null && r.confidence < this._minConfidence
    );
    if (lowConfidence.length >= 3) {
      const avgConf = lowConfidence.reduce((s, r) => s + r.confidence, 0) / lowConfidence.length;
      const alert = this._raise(ALERT_TYPE.CONFIDENCE_DROP, {
        message:  `${lowConfidence.length} low-confidence responses (avg: ${avgConf.toFixed(2)})`,
        avgConfidence: avgConf,
        count:    lowConfidence.length,
        severity: 'warning',
      });
      newAlerts.push(alert);
    }

    return newAlerts;
  }

  // ─── Response Monitoring ──────────────────────────────────────────────────────

  /**
   * @private
   * Called when BuddyCore emits a chat:response event.
   */
  _onResponse(evt) {
    const { sessionId, message, response } = evt;

    const entry = {
      at:         Date.now(),
      sessionId,
      messageLen: message ? message.length : 0,
      replyLen:   typeof response.reply === 'string' ? response.reply.length : 0,
      durationMs: response.at ? (Date.now() - response.at) : 0,
      confidence: this._extractConfidence(response),
      cached:     response.cached || false,
    };

    this._responseLog.push(entry);
    if (this._responseLog.length > 500) {
      this._responseLog.shift();
    }

    // Real-time timeout detection
    if (entry.durationMs > this._maxResponseTime) {
      this._raise(ALERT_TYPE.TIMEOUT, {
        message:   `Response timeout: ${entry.durationMs}ms for session ${sessionId}`,
        durationMs: entry.durationMs,
        sessionId,
        severity:  'warning',
      });
    }
  }

  /**
   * @private
   * Extracts a confidence score from a buddy response.
   * @param {object} response
   * @returns {number|null}
   */
  _extractConfidence(response) {
    if (typeof response.confidence === 'number') return response.confidence;
    if (response.usage && typeof response.usage.confidence === 'number') {
      return response.usage.confidence;
    }
    return null;
  }

  /**
   * @private
   * Removes response log entries older than the window.
   */
  _pruneResponseLog() {
    const cutoff = Date.now() - this._responseWindow;
    while (this._responseLog.length > 0 && this._responseLog[0].at < cutoff) {
      this._responseLog.shift();
    }
  }

  /**
   * @private
   * Detects inconsistencies in recent responses.
   * Heuristic: sudden large reply length drops may indicate hallucination resets.
   * @returns {{ count: number, samples: object[] }}
   */
  _detectInconsistencies() {
    const samples = [];
    const log     = this._responseLog.slice(-20);

    for (let i = 1; i < log.length; i++) {
      const prev = log[i - 1];
      const curr = log[i];

      // Same session should not wildly shrink reply length
      if (prev.sessionId === curr.sessionId && !curr.cached) {
        const prevLen = prev.replyLen || 1;
        const ratio   = curr.replyLen / prevLen;
        if (ratio < 0.1 && curr.replyLen < 20) {
          samples.push({ idx: i, prev, curr, reason: 'abrupt_truncation' });
        }
      }
    }

    return { count: samples.length, samples };
  }

  // ─── Alerts ───────────────────────────────────────────────────────────────────

  /**
   * @private
   * Raises a new alert.
   * @param {string} type
   * @param {object} data
   * @returns {object}
   */
  _raise(type, data) {
    const alert = {
      id:        `alert_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      type,
      ...data,
      at:        Date.now(),
    };

    this._alerts.push(alert);
    if (this._alerts.length > MAX_ALERTS) this._alerts.shift();
    this._totalAlerts++;

    logger.logNodeActivity('BUDDY-WATCHDOG',
      `ALERT [${type}] ${data.severity?.toUpperCase() || 'INFO'}: ${data.message}`);

    this.emit('alert', alert);

    if (data.severity === 'critical') {
      this.emit('critical', alert);
    }

    return alert;
  }

  /**
   * Returns all stored alerts.
   * @param {object} [filter={}]
   * @param {string} [filter.type]
   * @param {string} [filter.severity]
   * @param {number} [filter.since]    - Unix ms timestamp
   * @returns {object[]}
   */
  getAlerts(filter = {}) {
    let alerts = [...this._alerts];
    if (filter.type)     alerts = alerts.filter(a => a.type     === filter.type);
    if (filter.severity) alerts = alerts.filter(a => a.severity === filter.severity);
    if (filter.since)    alerts = alerts.filter(a => a.at       >= filter.since);
    return alerts;
  }

  /**
   * Clears all alerts.
   */
  clearAlerts() {
    this._alerts = [];
    logger.logNodeActivity('BUDDY-WATCHDOG', 'Alerts cleared');
  }

  /**
   * Returns watchdog status.
   * @returns {object}
   */
  getStatus() {
    return {
      running:         this._running,
      totalChecks:     this._totalChecks,
      totalAlerts:     this._totalAlerts,
      recentAlerts:    this._alerts.slice(-10),
      responseLogSize: this._responseLog.length,
      config: {
        responseWindowMs:       this._responseWindow,
        minConfidenceThreshold: this._minConfidence,
        maxResponseTimeMs:      this._maxResponseTime,
        inconsistencyThreshold: this._inconsistencyThreshold,
      },
      createdAt: this._createdAt,
    };
  }

  // ─── Express Routes ───────────────────────────────────────────────────────────

  /**
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    app.get('/api/watchdog/status', (req, res) => {
      res.json(this.getStatus());
    });

    app.get('/api/watchdog/alerts', (req, res) => {
      const filter = {};
      if (req.query.type)     filter.type     = req.query.type;
      if (req.query.severity) filter.severity = req.query.severity;
      if (req.query.since)    filter.since    = parseInt(req.query.since, 10);
      res.json(this.getAlerts(filter));
    });

    app.delete('/api/watchdog/alerts', (req, res) => {
      this.clearAlerts();
      res.json({ cleared: true });
    });

    app.post('/api/watchdog/check', async (req, res) => {
      try {
        const alerts = await this.check();
        res.json({ alerts });
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    logger.logNodeActivity('BUDDY-WATCHDOG', 'Watchdog routes registered');
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = { BuddyWatchdog, ALERT_TYPE };
