'use strict';

/**
 * @fileoverview HeadyBuddy AI Companion Core
 * Singleton AI companion that processes user messages through the conductor,
 * manages MCP tool registration, and exposes REST routes.
 *
 * @module orchestration/buddy-core
 */

const { EventEmitter } = require('events');
const { LRUCache }    = require('../resilience/cache');
const { retry }       = require('../resilience/retry');
const logger          = require('../utils/logger');

/** @type {BuddyCore|null} */
let _instance = null;

/**
 * @class BuddyCore
 * @extends EventEmitter
 * @description HeadyBuddy AI companion core. Singleton.
 */
class BuddyCore extends EventEmitter {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.historyLimit=50]      - Max messages in context history
   * @param {number} [opts.responseCacheTtl=300000] - Cache TTL for identical queries
   */
  constructor(opts = {}) {
    super();

    if (_instance) return _instance;

    this._conductor    = null;
    this._vectorMemory = null;
    this._redis        = null;

    this._historyLimit = opts.historyLimit      ?? 50;
    this._cache        = new LRUCache({
      maxSize: 200,
      ttlMs:   opts.responseCacheTtl ?? 300000,
      name:    'buddy-response-cache',
    });

    /** @type {Map<string, object>} name → MCP tool config */
    this._mcpTools = new Map();

    /** @type {Map<string, object[]>} sessionId → message history */
    this._sessions = new Map();

    this._totalMessages   = 0;
    this._totalCacheHits  = 0;
    this._totalErrors     = 0;
    this._createdAt       = Date.now();

    // Register singleton
    _instance = this;

    logger.logNodeActivity('BUDDY-CORE', 'HeadyBuddy initialized');
  }

  // ─── Wiring ──────────────────────────────────────────────────────────────────

  /**
   * Sets the conductor reference used for AI inference.
   * @param {object} conductor
   */
  setConductor(conductor) {
    this._conductor = conductor;
    logger.logNodeActivity('BUDDY-CORE', 'Conductor wired');
  }

  /**
   * Sets the vector memory reference for RAG context.
   * @param {object} vm - Vector memory instance
   */
  setVectorMemory(vm) {
    this._vectorMemory = vm;
    logger.logNodeActivity('BUDDY-CORE', 'Vector memory wired');
  }

  /**
   * Sets the Redis client for session persistence.
   * @param {object} client - Redis client
   */
  setRedis(client) {
    this._redis = client;
    logger.logNodeActivity('BUDDY-CORE', 'Redis wired');
  }

  // ─── MCP Tools ───────────────────────────────────────────────────────────────

  /**
   * Registers an MCP tool configuration.
   * @param {string} name   - Tool name
   * @param {object} config - MCP tool config: { description, inputSchema, handler }
   */
  registerMCPTool(name, config) {
    if (!name || typeof name !== 'string') {
      throw new TypeError('registerMCPTool requires a string name');
    }
    this._mcpTools.set(name, {
      name,
      description:  config.description  ?? '',
      inputSchema:  config.inputSchema  ?? {},
      handler:      config.handler      ?? null,
      registeredAt: Date.now(),
    });
    logger.logNodeActivity('BUDDY-CORE', `MCP tool registered: ${name}`);
    this.emit('mcp:registered', { name });
  }

  /**
   * Returns all registered MCP tools.
   * @returns {object[]}
   */
  getMCPTools() {
    return Array.from(this._mcpTools.values()).map(t => ({
      name:        t.name,
      description: t.description,
      inputSchema: t.inputSchema,
      hasHandler:  typeof t.handler === 'function',
      registeredAt: t.registeredAt,
    }));
  }

  /**
   * Invokes a registered MCP tool.
   * @param {string} name
   * @param {object} args
   * @returns {Promise<*>}
   */
  async callMCPTool(name, args = {}) {
    const tool = this._mcpTools.get(name);
    if (!tool) throw new Error(`MCP tool not found: "${name}"`);
    if (typeof tool.handler !== 'function') {
      throw new Error(`MCP tool "${name}" has no handler`);
    }
    return tool.handler(args);
  }

  // ─── Chat ─────────────────────────────────────────────────────────────────────

  /**
   * Processes a user message through the AI conductor.
   * @param {string} message          - User input
   * @param {object} [context={}]
   * @param {string} [context.sessionId]   - Session ID for history tracking
   * @param {string} [context.userId]
   * @param {object} [context.meta]        - Extra metadata passed to conductor
   * @param {boolean} [context.useCache=true]
   * @returns {Promise<object>} { reply, sessionId, usage, cached }
   */
  async chat(message, context = {}) {
    if (!message || typeof message !== 'string') {
      throw new TypeError('chat() requires a non-empty string message');
    }

    const sessionId  = context.sessionId || this._newSessionId();
    const useCache   = context.useCache !== false;
    const cacheKey   = `${sessionId}:${message}`;

    this._totalMessages++;

    // Check response cache
    if (useCache) {
      const cached = this._cache.get(cacheKey);
      if (cached) {
        this._totalCacheHits++;
        logger.logNodeActivity('BUDDY-CORE', `Cache hit for session ${sessionId}`);
        return { ...cached, cached: true };
      }
    }

    // Build history for this session
    const history = this._getHistory(sessionId);

    // Optionally enrich with vector memory context
    let memoryContext = '';
    if (this._vectorMemory && typeof this._vectorMemory.search === 'function') {
      try {
        const results = await this._vectorMemory.search(message, { topK: 3 });
        if (results && results.length > 0) {
          memoryContext = results.map(r => r.content || r.text || '').join('\n');
        }
      } catch (err) {
        logger.logNodeActivity('BUDDY-CORE',
          `Vector memory search error: ${err.message}`);
      }
    }

    // Build prompt payload
    const payload = {
      messages: [
        ...(memoryContext ? [{
          role:    'system',
          content: `Relevant context:\n${memoryContext}`,
        }] : []),
        ...history,
        { role: 'user', content: message },
      ],
      tools:  this.getMCPTools().filter(t => t.hasHandler),
      meta:   context.meta || {},
      userId: context.userId,
    };

    let reply;

    try {
      if (this._conductor && typeof this._conductor.chat === 'function') {
        reply = await retry(
          () => this._conductor.chat(payload),
          { maxRetries: 2, backoffType: 'phi', label: 'buddy:chat' }
        );
      } else {
        // Fallback: echo mode when no conductor attached
        reply = {
          content: `[HeadyBuddy] No conductor attached. You said: "${message}"`,
          usage:   {},
          model:   'echo',
        };
        logger.logNodeActivity('BUDDY-CORE',
          'No conductor — using echo fallback');
      }
    } catch (err) {
      this._totalErrors++;
      logger.logNodeActivity('BUDDY-CORE', `Chat error: ${err.message}`);
      throw err;
    }

    // Update history
    this._addToHistory(sessionId, { role: 'user',      content: message });
    this._addToHistory(sessionId, { role: 'assistant', content: reply.content || reply });

    const response = {
      reply:     reply.content || reply,
      sessionId,
      usage:     reply.usage   || {},
      model:     reply.model   || 'unknown',
      cached:    false,
      at:        Date.now(),
    };

    // Cache response
    if (useCache) {
      this._cache.set(cacheKey, response);
    }

    this.emit('chat:response', { sessionId, message, response });

    // Persist to Redis if available
    if (this._redis) {
      this._persistSession(sessionId).catch(() => {});
    }

    return response;
  }

  // ─── Session Management ───────────────────────────────────────────────────────

  /**
   * @private
   */
  _newSessionId() {
    return `buddy_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  }

  /**
   * @private
   */
  _getHistory(sessionId) {
    return this._sessions.get(sessionId) || [];
  }

  /**
   * @private
   */
  _addToHistory(sessionId, message) {
    if (!this._sessions.has(sessionId)) {
      this._sessions.set(sessionId, []);
    }
    const history = this._sessions.get(sessionId);
    history.push(message);
    // Trim to limit
    if (history.length > this._historyLimit * 2) {
      history.splice(0, history.length - this._historyLimit * 2);
    }
  }

  /**
   * @private
   */
  async _persistSession(sessionId) {
    if (!this._redis) return;
    try {
      const history = this._sessions.get(sessionId) || [];
      await this._redis.set(
        `buddy:session:${sessionId}`,
        JSON.stringify(history),
        'EX',
        86400
      );
    } catch (err) {
      logger.logNodeActivity('BUDDY-CORE',
        `Session persist error: ${err.message}`);
    }
  }

  // ─── Status ───────────────────────────────────────────────────────────────────

  /**
   * Returns buddy status information.
   * @returns {object}
   */
  getStatus() {
    return {
      hasConductor:    !!this._conductor,
      hasVectorMemory: !!this._vectorMemory,
      hasRedis:        !!this._redis,
      mcpTools:        this._mcpTools.size,
      activeSessions:  this._sessions.size,
      totalMessages:   this._totalMessages,
      totalCacheHits:  this._totalCacheHits,
      totalErrors:     this._totalErrors,
      cacheStats:      this._cache.getStats(),
      createdAt:       this._createdAt,
    };
  }

  // ─── Express Routes ───────────────────────────────────────────────────────────

  /**
   * Registers HeadyBuddy REST routes on an Express app.
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    /**
     * POST /api/buddy/chat
     * Body: { message, sessionId?, userId?, meta?, useCache? }
     */
    app.post('/api/buddy/chat', async (req, res) => {
      const { message, ...context } = req.body || {};
      if (!message) {
        return res.status(400).json({ error: 'message is required' });
      }
      try {
        const response = await this.chat(message, context);
        res.json(response);
      } catch (err) {
        logger.logNodeActivity('BUDDY-CORE', `Chat route error: ${err.message}`);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * GET /api/buddy/tools
     */
    app.get('/api/buddy/tools', (req, res) => {
      res.json({ tools: this.getMCPTools() });
    });

    /**
     * POST /api/buddy/tools/:name/call
     * Body: { args }
     */
    app.post('/api/buddy/tools/:name/call', async (req, res) => {
      try {
        const result = await this.callMCPTool(
          req.params.name,
          req.body.args || {}
        );
        res.json({ result });
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    /**
     * GET /api/buddy/status
     */
    app.get('/api/buddy/status', (req, res) => {
      res.json(this.getStatus());
    });

    logger.logNodeActivity('BUDDY-CORE', 'HeadyBuddy routes registered');
  }
}

// ─── Singleton Factory ────────────────────────────────────────────────────────

/**
 * Returns the BuddyCore singleton, creating it on first call.
 * @param {object} [opts={}]
 * @returns {BuddyCore}
 */
function getBuddy(opts = {}) {
  if (!_instance) {
    _instance = new BuddyCore(opts);
  }
  return _instance;
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = { BuddyCore, getBuddy };
