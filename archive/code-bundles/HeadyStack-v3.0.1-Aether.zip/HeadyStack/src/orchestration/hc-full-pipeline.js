'use strict';

/**
 * @fileoverview HC Full Pipeline Orchestrator
 * Integrates PipelineCore with all 12 stages, wiring Monte Carlo simulation
 * at MONTE_CARLO, Arena multi-model comparison at ARENA, and full lifecycle
 * management including PipelinePools scheduling.
 *
 * @module orchestration/hc-full-pipeline
 */

const { EventEmitter }   = require('events');
const { PipelineCore, STAGE, STAGE_ORDER, TASK_STATUS, StageHooks } =
  require('../pipeline/pipeline-core');
const { PipelineStore, StageTimeoutManager, PipelineMetrics } =
  require('../pipeline/pipeline-infra');
const { PipelinePools, POOL } =
  require('../pipeline/pipeline-pools');
const { SwarmConsensus }  = require('./swarm-consensus');
const { SwarmIntelligence } = require('./swarm-intelligence');
const logger              = require('../utils/logger');

// ─── Stage Hook Implementations ──────────────────────────────────────────────

/**
 * @class IntakeHooks
 * @extends StageHooks
 * @description Validates and normalizes incoming tasks.
 */
class IntakeHooks extends StageHooks {
  constructor() { super(STAGE.INTAKE); }

  async validate(task) {
    return !!(task.type && task.payload !== undefined);
  }

  async execute(task) {
    return {
      stage:      STAGE.INTAKE,
      normalized: true,
      inputType:  typeof task.payload,
      receivedAt: Date.now(),
    };
  }
}

/**
 * @class TriageHooks
 * @extends StageHooks
 * @description Classifies task priority and routing.
 */
class TriageHooks extends StageHooks {
  constructor() { super(STAGE.TRIAGE); }

  async execute(task) {
    const priority = task.priority || 'normal';
    const complexity = this._estimateComplexity(task);

    return {
      stage:      STAGE.TRIAGE,
      priority,
      complexity,
      routing:    complexity > 0.7 ? 'full-pipeline' : 'fast-track',
      triagedAt:  Date.now(),
    };
  }

  _estimateComplexity(task) {
    const payloadStr = JSON.stringify(task.payload || {});
    // Simple heuristic: longer payloads = higher complexity
    return Math.min(payloadStr.length / 5000, 1.0);
  }
}

/**
 * @class ContextHooks
 * @extends StageHooks
 * @description Loads conversation history and enriches task with context.
 */
class ContextHooks extends StageHooks {
  constructor(conductor) {
    super(STAGE.CONTEXT);
    this._conductor = conductor;
  }

  async execute(task) {
    let context = { enriched: false };

    if (this._conductor && typeof this._conductor.getContext === 'function') {
      try {
        context = await this._conductor.getContext(task);
        context.enriched = true;
      } catch (err) {
        logger.logNodeActivity('HC-PIPELINE',
          `Context enrichment failed: ${err.message}`);
      }
    }

    return {
      stage:     STAGE.CONTEXT,
      context,
      loadedAt:  Date.now(),
    };
  }
}

/**
 * @class MonteCarloHooks
 * @extends StageHooks
 * @description Runs Monte Carlo simulations to estimate outcome probabilities.
 */
class MonteCarloHooks extends StageHooks {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.iterations=1000] - Simulation iterations
   */
  constructor(opts = {}) {
    super(STAGE.MONTE_CARLO);
    this._iterations = opts.iterations ?? 1000;
  }

  async execute(task) {
    const trials = this._runSimulation(task, this._iterations);
    return {
      stage:       STAGE.MONTE_CARLO,
      iterations:  this._iterations,
      successRate: trials.successRate,
      p10:         trials.p10,
      p50:         trials.p50,
      p90:         trials.p90,
      confidence:  trials.confidence,
      simulatedAt: Date.now(),
    };
  }

  /**
   * @private
   * Simple Monte Carlo simulation using payload complexity as an input.
   */
  _runSimulation(task, iterations) {
    const complexity = task.stageData[STAGE.TRIAGE]?.complexity ?? 0.5;
    const successProb = 1 - complexity * 0.3;  // higher complexity = more variance

    let successes = 0;
    const outcomes = [];

    for (let i = 0; i < iterations; i++) {
      const outcome = Math.random() < successProb ? 1 : 0;
      successes += outcome;
      outcomes.push(outcome);
    }

    const sorted     = outcomes.sort((a, b) => a - b);
    const successRate = successes / iterations;

    return {
      successRate: parseFloat(successRate.toFixed(4)),
      p10:         sorted[Math.floor(iterations * 0.1)],
      p50:         sorted[Math.floor(iterations * 0.5)],
      p90:         sorted[Math.floor(iterations * 0.9)],
      confidence:  parseFloat(Math.abs(successRate - 0.5) * 2).toFixed(4),
    };
  }
}

/**
 * @class ArenaHooks
 * @extends StageHooks
 * @description Runs multi-model arena comparison via swarm intelligence.
 */
class ArenaHooks extends StageHooks {
  /**
   * @param {SwarmIntelligence} swarm
   * @param {object} conductor
   */
  constructor(swarm, conductor) {
    super(STAGE.ARENA);
    this._swarm     = swarm;
    this._conductor = conductor;
  }

  async execute(task) {
    // Default arena: compare 2 approaches
    const options = [
      { id: 'approach_a', label: 'Approach A — Greedy' },
      { id: 'approach_b', label: 'Approach B — Conservative' },
    ];

    // Simulate agent evaluations
    const agentScores = [
      { agentId: 'arena-agent-1', optionId: 'approach_a', score: 0.72, confidence: 0.8 },
      { agentId: 'arena-agent-2', optionId: 'approach_a', score: 0.65, confidence: 0.7 },
      { agentId: 'arena-agent-1', optionId: 'approach_b', score: 0.58, confidence: 0.75 },
      { agentId: 'arena-agent-2', optionId: 'approach_b', score: 0.61, confidence: 0.65 },
    ];

    let arenaResult = { winner: options[0], ranked: options };

    if (this._swarm) {
      try {
        arenaResult = this._swarm.evaluate(options, agentScores, { taskId: task.id });
      } catch (err) {
        logger.logNodeActivity('HC-PIPELINE',
          `Arena evaluation failed: ${err.message}`);
      }
    }

    return {
      stage:       STAGE.ARENA,
      winner:      arenaResult.winner?.id || arenaResult.winner?.label,
      ranked:      arenaResult.ranked?.map(o => o.id || o.label),
      margin:      arenaResult.margin,
      evaluatedAt: Date.now(),
    };
  }
}

/**
 * @class JudgeHooks
 * @extends StageHooks
 * @description Reviews arena output and Monte Carlo results for quality.
 */
class JudgeHooks extends StageHooks {
  constructor() { super(STAGE.JUDGE); }

  async execute(task) {
    const mc     = task.stageData[STAGE.MONTE_CARLO] || {};
    const arena  = task.stageData[STAGE.ARENA]       || {};

    const score  = ((mc.successRate ?? 0.5) + (mc.confidence ?? 0.5)) / 2;
    const verdict = score >= 0.6 ? 'APPROVE' : score >= 0.4 ? 'REVIEW' : 'REJECT';

    return {
      stage:     STAGE.JUDGE,
      score:     parseFloat(score.toFixed(4)),
      verdict,
      reasoning: `MC success rate: ${mc.successRate ?? 'N/A'}, confidence: ${mc.confidence ?? 'N/A'}`,
      judgedAt:  Date.now(),
    };
  }
}

/**
 * @class ApproveHooks
 * @extends StageHooks
 */
class ApproveHooks extends StageHooks {
  constructor() { super(STAGE.APPROVE); }

  async validate(task) {
    const judge = task.stageData[STAGE.JUDGE] || {};
    return judge.verdict !== 'REJECT';
  }

  async execute(task) {
    const judge = task.stageData[STAGE.JUDGE] || {};
    return {
      stage:      STAGE.APPROVE,
      approved:   judge.verdict !== 'REJECT',
      approvedAt: Date.now(),
      approver:   'auto-conductor',
    };
  }
}

/**
 * @class PlanHooks
 * @extends StageHooks
 */
class PlanHooks extends StageHooks {
  constructor(conductor) { super(STAGE.PLAN); this._conductor = conductor; }

  async execute(task) {
    let plan = { steps: [], estimatedMs: 5000 };

    if (this._conductor && typeof this._conductor.plan === 'function') {
      try {
        plan = await this._conductor.plan(task);
      } catch (err) {
        logger.logNodeActivity('HC-PIPELINE', `Plan generation error: ${err.message}`);
      }
    } else {
      plan.steps = [
        { id: 1, action: 'process', description: `Process task ${task.id}` },
        { id: 2, action: 'verify',  description: 'Verify output' },
      ];
    }

    return { stage: STAGE.PLAN, plan, plannedAt: Date.now() };
  }
}

/**
 * @class ExecuteHooks
 * @extends StageHooks
 */
class ExecuteHooks extends StageHooks {
  constructor(conductor) { super(STAGE.EXECUTE); this._conductor = conductor; }

  async execute(task) {
    let output = null;
    let success = true;

    if (this._conductor && typeof this._conductor.execute === 'function') {
      try {
        output = await this._conductor.execute(task);
      } catch (err) {
        success = false;
        output  = { error: err.message };
        logger.logNodeActivity('HC-PIPELINE', `Execution error: ${err.message}`);
      }
    } else {
      output = { result: `Processed: ${task.type}`, mock: true };
    }

    return {
      stage:       STAGE.EXECUTE,
      output,
      success,
      executedAt:  Date.now(),
    };
  }
}

/**
 * @class VerifyHooks
 * @extends StageHooks
 */
class VerifyHooks extends StageHooks {
  constructor() { super(STAGE.VERIFY); }

  async execute(task) {
    const exec   = task.stageData[STAGE.EXECUTE] || {};
    const passed = exec.success !== false && exec.output && !exec.output.error;

    return {
      stage:      STAGE.VERIFY,
      passed,
      issues:     passed ? [] : ['execution_failed'],
      verifiedAt: Date.now(),
    };
  }
}

/**
 * @class ReceiptHooks
 * @extends StageHooks
 */
class ReceiptHooks extends StageHooks {
  constructor() { super(STAGE.RECEIPT); }

  async execute(task) {
    const elapsed = Date.now() - task.createdAt;
    return {
      stage:     STAGE.RECEIPT,
      taskId:    task.id,
      type:      task.type,
      elapsed,
      summary:   this._buildSummary(task),
      issuedAt:  Date.now(),
    };
  }

  _buildSummary(task) {
    const verify = task.stageData[STAGE.VERIFY] || {};
    const exec   = task.stageData[STAGE.EXECUTE] || {};
    return {
      success:     verify.passed !== false,
      stagesRun:   STAGE_ORDER.filter(s => task.stageData[s] !== undefined).length,
      output:      exec.output || null,
    };
  }
}

/**
 * @class LearnHooks
 * @extends StageHooks
 */
class LearnHooks extends StageHooks {
  constructor() { super(STAGE.LEARN); }

  async execute(task) {
    // Extract learnable patterns from the run
    const mc     = task.stageData[STAGE.MONTE_CARLO] || {};
    const judge  = task.stageData[STAGE.JUDGE]       || {};
    const verify = task.stageData[STAGE.VERIFY]      || {};

    const insight = {
      taskType:    task.type,
      priority:    task.priority,
      successRate: mc.successRate,
      judgeScore:  judge.score,
      passed:      verify.passed,
      elapsed:     Date.now() - task.createdAt,
      learnedAt:   Date.now(),
    };

    return {
      stage:    STAGE.LEARN,
      insight,
      recorded: true,
    };
  }
}

// ─── HCFullPipeline ───────────────────────────────────────────────────────────

/**
 * @class HCFullPipeline
 * @extends EventEmitter
 * @description Integrates PipelineCore, PipelinePools, PipelineStore, and all
 * stage hooks into a single orchestrated HC Full Pipeline instance.
 */
class HCFullPipeline extends EventEmitter {
  /**
   * @param {object} [opts={}]
   * @param {object} [opts.conductor]      - Conductor instance
   * @param {object} [opts.redis]          - Redis client
   * @param {object} [opts.swarm]          - SwarmIntelligence instance
   * @param {number} [opts.mcIterations=1000] - Monte Carlo iterations
   */
  constructor(opts = {}) {
    super();

    this._conductor = opts.conductor || null;
    this._redis     = opts.redis     || null;

    // Sub-systems
    this._store    = new PipelineStore({ redis: this._redis });
    this._metrics  = new PipelineMetrics();
    this._timeouts = new StageTimeoutManager();
    this._pools    = new PipelinePools();
    this._swarm    = opts.swarm || new SwarmIntelligence();
    this._consensus = new SwarmConsensus();

    // Build hooks for each stage
    const hooks = {
      [STAGE.INTAKE]:      new IntakeHooks(),
      [STAGE.TRIAGE]:      new TriageHooks(),
      [STAGE.CONTEXT]:     new ContextHooks(this._conductor),
      [STAGE.MONTE_CARLO]: new MonteCarloHooks({ iterations: opts.mcIterations }),
      [STAGE.ARENA]:       new ArenaHooks(this._swarm, this._conductor),
      [STAGE.JUDGE]:       new JudgeHooks(),
      [STAGE.APPROVE]:     new ApproveHooks(),
      [STAGE.PLAN]:        new PlanHooks(this._conductor),
      [STAGE.EXECUTE]:     new ExecuteHooks(this._conductor),
      [STAGE.VERIFY]:      new VerifyHooks(),
      [STAGE.RECEIPT]:     new ReceiptHooks(),
      [STAGE.LEARN]:       new LearnHooks(),
    };

    this._core = new PipelineCore({
      hooks,
      stageTimeout: 60000,
      eventBus:     opts.eventBus || global.eventBus,
    });

    // Forward core events
    this._core.on('task:submitted',  e => this.emit('task:submitted', e));
    this._core.on('task:advanced',   e => this.emit('task:advanced',  e));
    this._core.on('task:completed',  e => this.emit('task:completed', e));
    this._core.on('task:failed',     e => this.emit('task:failed',    e));

    // Timeout → fail task
    this._timeouts.on('timeout', ({ taskId, stage }) => {
      logger.logNodeActivity('HC-PIPELINE',
        `Task ${taskId} timed out at ${stage}`);
      try { this._core.failTask(taskId, `Stage timeout: ${stage}`); } catch { /* */ }
    });

    this._pools.start();

    logger.logNodeActivity('HC-PIPELINE', 'HC Full Pipeline initialized');
  }

  // ─── Wiring ───────────────────────────────────────────────────────────────────

  setConductor(conductor) {
    this._conductor = conductor;
    logger.logNodeActivity('HC-PIPELINE', 'Conductor wired');
  }

  setRedis(client) {
    this._redis = client;
    this._store._redis = client;
  }

  // ─── Task Lifecycle ───────────────────────────────────────────────────────────

  /**
   * Submits a task and runs it through all 12 pipeline stages automatically.
   * @param {object} taskInput
   * @param {boolean} [opts.autoAdvance=true] - If true, auto-advances through all stages
   * @returns {Promise<object>} Completed task record
   */
  async run(taskInput, opts = {}) {
    const autoAdvance = opts.autoAdvance !== false;

    // Enqueue to appropriate pool based on priority
    this._pools.enqueue({
      id:       taskInput.id || `task_${Date.now()}`,
      payload:  taskInput,
      priority: taskInput.priority || 'normal',
    });

    const task = await this._core.submit(taskInput);
    await this._store.save(task.id, task);

    this._timeouts.start(task.id, STAGE.INTAKE);

    if (!autoAdvance) return task;

    // Auto-advance through all stages
    for (const stage of STAGE_ORDER.slice(1)) {
      this._timeouts.cancel(task.id, STAGE_ORDER[STAGE_ORDER.indexOf(stage) - 1]);
      this._metrics.recordEntry(task.id, stage);

      const stageStart = Date.now();
      try {
        await this._core.advance(task.id);
        this._metrics.recordDuration(stage, Date.now() - stageStart);
        await this._store.save(task.id, task);
      } catch (err) {
        this._metrics.recordError(stage);
        logger.logNodeActivity('HC-PIPELINE',
          `Advance failed at ${stage}: ${err.message}`);
        this._core.failTask(task.id, err);
        await this._store.save(task.id, task);
        return task;
      }

      this._timeouts.start(task.id, stage);

      // Short yield to allow event loop
      await new Promise(r => setImmediate(r));
    }

    this._timeouts.cancelAll(task.id);
    return this._core.getState(task.id);
  }

  /**
   * Returns a task record (from memory or store).
   * @param {string} taskId
   * @returns {Promise<object>}
   */
  async getTask(taskId) {
    try {
      return this._core.getState(taskId);
    } catch {
      return this._store.load(taskId);
    }
  }

  /**
   * Returns all pipeline statistics.
   * @returns {object}
   */
  getStats() {
    return {
      pipeline: this._core.getStats(),
      store:    this._store.getStats(),
      pools:    this._pools.getPoolStatus(),
      metrics:  this._metrics.getMetrics(),
      timeouts: this._timeouts.getStats(),
    };
  }

  // ─── Express Routes ───────────────────────────────────────────────────────────

  /**
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    this._core.registerRoutes(app);
    this._pools.registerRoutes(app);

    app.post('/api/hc-pipeline/run', async (req, res) => {
      try {
        const task = await this.run(req.body);
        res.json(task);
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    app.get('/api/hc-pipeline/task/:taskId', async (req, res) => {
      try {
        const task = await this.getTask(req.params.taskId);
        if (!task) return res.status(404).json({ error: 'Task not found' });
        res.json(task);
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    app.get('/api/hc-pipeline/stats', (req, res) => {
      res.json(this.getStats());
    });

    logger.logNodeActivity('HC-PIPELINE', 'HC Full Pipeline routes registered');
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  HCFullPipeline,
  IntakeHooks,
  TriageHooks,
  ContextHooks,
  MonteCarloHooks,
  ArenaHooks,
  JudgeHooks,
  ApproveHooks,
  PlanHooks,
  ExecuteHooks,
  VerifyHooks,
  ReceiptHooks,
  LearnHooks,
};
