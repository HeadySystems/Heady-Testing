'use strict';

/**
 * @fileoverview Swarm Consensus — Multi-Agent Voting and Agreement Protocol
 * Agents submit proposals and cast votes. Consensus is reached when a
 * configurable threshold of participating agents agree.
 *
 * @module orchestration/swarm-consensus
 */

const { EventEmitter } = require('events');
const logger           = require('../utils/logger');

/** @enum {string} */
const PROPOSAL_STATUS = Object.freeze({
  PENDING:  'PENDING',
  OPEN:     'OPEN',
  ACCEPTED: 'ACCEPTED',
  REJECTED: 'REJECTED',
  EXPIRED:  'EXPIRED',
  TIED:     'TIED',
});

/** @enum {string} */
const VOTE = Object.freeze({
  YES:     'YES',
  NO:      'NO',
  ABSTAIN: 'ABSTAIN',
});

/**
 * @class SwarmConsensus
 * @extends EventEmitter
 * @description Manages a ledger of proposals and votes across a swarm of agents.
 */
class SwarmConsensus extends EventEmitter {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.defaultThreshold=0.7]   - Fraction of YES votes for acceptance
   * @param {number} [opts.proposalTtlMs=60000]     - Auto-expire proposals after N ms
   * @param {number} [opts.minVoters=1]             - Minimum votes before consensus can be reached
   * @param {number} [opts.sweepIntervalMs=5000]    - How often expired proposals are swept
   */
  constructor(opts = {}) {
    super();

    this._defaultThreshold = opts.defaultThreshold ?? 0.7;
    this._proposalTtl      = opts.proposalTtlMs    ?? 60000;
    this._minVoters        = opts.minVoters         ?? 1;
    this._sweepInterval    = opts.sweepIntervalMs   ?? 5000;

    /** @type {Map<string, object>} proposalId → proposal record */
    this._proposals = new Map();

    /** @type {Map<string, Map<string, string>>} proposalId → (agentId → vote) */
    this._votes = new Map();

    /** @type {Set<string>} registered agent IDs */
    this._agents = new Set();

    this._totalProposals = 0;
    this._totalAccepted  = 0;
    this._totalRejected  = 0;
    this._createdAt      = Date.now();

    this._sweepTimer = setInterval(() => this._sweep(), this._sweepInterval);
    if (this._sweepTimer.unref) this._sweepTimer.unref();
  }

  // ─── Agent Registry ───────────────────────────────────────────────────────────

  /**
   * Registers an agent with the swarm.
   * @param {string} agentId
   */
  registerAgent(agentId) {
    this._agents.add(agentId);
    logger.logNodeActivity('SWARM-CONSENSUS', `Agent registered: ${agentId}`);
  }

  /**
   * Removes an agent from the swarm.
   * @param {string} agentId
   */
  removeAgent(agentId) {
    this._agents.delete(agentId);
  }

  // ─── Proposal API ────────────────────────────────────────────────────────────

  /**
   * Submits a new proposal to the swarm.
   * @param {string} agentId    - Proposing agent ID
   * @param {object} proposal   - { topic, content, ttlMs?, threshold? }
   * @returns {object} The created proposal record
   */
  propose(agentId, proposal = {}) {
    if (!agentId) throw new TypeError('propose() requires agentId');

    const id        = `proposal_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    const ttl       = proposal.ttlMs     ?? this._proposalTtl;
    const threshold = proposal.threshold ?? this._defaultThreshold;
    const now       = Date.now();

    const record = {
      id,
      agentId,
      topic:      proposal.topic   || 'general',
      content:    proposal.content || proposal,
      threshold,
      status:     PROPOSAL_STATUS.OPEN,
      createdAt:  now,
      expiresAt:  now + ttl,
      decidedAt:  null,
      meta:       proposal.meta || {},
    };

    this._proposals.set(id, record);
    this._votes.set(id, new Map());
    this._totalProposals++;

    // Auto-vote YES from proposing agent
    this.vote(agentId, id, VOTE.YES);

    logger.logNodeActivity('SWARM-CONSENSUS',
      `Proposal ${id} created by ${agentId}: "${record.topic}"`);
    this.emit('proposal:created', record);

    return record;
  }

  /**
   * Casts a vote on a proposal.
   * @param {string} agentId
   * @param {string} proposalId
   * @param {'YES'|'NO'|'ABSTAIN'} vote
   * @returns {object} Updated proposal (may include consensus result)
   */
  vote(agentId, proposalId, vote) {
    const proposal = this._proposals.get(proposalId);
    if (!proposal) throw new Error(`Proposal not found: ${proposalId}`);

    if (proposal.status !== PROPOSAL_STATUS.OPEN) {
      throw new Error(
        `Proposal ${proposalId} is not OPEN (status: ${proposal.status})`
      );
    }

    if (Date.now() > proposal.expiresAt) {
      this._expire(proposalId);
      throw new Error(`Proposal ${proposalId} has expired`);
    }

    if (!Object.values(VOTE).includes(vote)) {
      throw new Error(`Invalid vote: "${vote}". Must be YES, NO, or ABSTAIN`);
    }

    const votes = this._votes.get(proposalId);
    votes.set(agentId, vote);

    logger.logNodeActivity('SWARM-CONSENSUS',
      `Vote: ${agentId} voted ${vote} on ${proposalId}`);
    this.emit('vote:cast', { agentId, proposalId, vote });

    // Check if consensus is reached
    return this._evaluateConsensus(proposal, votes);
  }

  /**
   * Checks whether consensus has been reached on a proposal.
   * @param {string} proposalId
   * @returns {object} { reached, status, yesCount, noCount, abstainCount, total, threshold }
   */
  getConsensus(proposalId) {
    const proposal = this._proposals.get(proposalId);
    if (!proposal) throw new Error(`Proposal not found: ${proposalId}`);

    const votes = this._votes.get(proposalId) || new Map();
    return this._buildConsensusResult(proposal, votes);
  }

  /**
   * Returns a full proposal record.
   * @param {string} proposalId
   * @returns {object}
   */
  getProposal(proposalId) {
    const proposal = this._proposals.get(proposalId);
    if (!proposal) throw new Error(`Proposal not found: ${proposalId}`);
    const votes = this._votes.get(proposalId) || new Map();
    return {
      ...proposal,
      votes:    Object.fromEntries(votes),
      consensus: this._buildConsensusResult(proposal, votes),
    };
  }

  /**
   * Blocks until consensus is reached on all proposals, or timeout.
   * @param {object[]} proposals  - Array of proposal inputs (passed to propose())
   * @param {number}   [threshold=0.7]
   * @param {string}   [coordinatorId='coordinator']
   * @param {number}   [timeoutMs=30000]
   * @returns {Promise<object[]>} Resolved proposal records
   */
  async requireConsensus(proposals, threshold = 0.7, coordinatorId = 'coordinator', timeoutMs = 30000) {
    const created = proposals.map(p => this.propose(coordinatorId, {
      ...p, threshold,
    }));

    return Promise.all(created.map(record =>
      new Promise((resolve, reject) => {
        const deadline = setTimeout(() => {
          reject(new Error(
            `Consensus timeout for proposal ${record.id} after ${timeoutMs}ms`
          ));
        }, timeoutMs);

        const check = () => {
          const current = this._proposals.get(record.id);
          if (!current) { clearTimeout(deadline); reject(new Error('Proposal lost')); return; }

          if (current.status === PROPOSAL_STATUS.ACCEPTED ||
              current.status === PROPOSAL_STATUS.REJECTED) {
            clearTimeout(deadline);
            resolve(this.getProposal(record.id));
          }
        };

        this.on('proposal:decided', (evt) => {
          if (evt.id === record.id) check();
        });

        // Check immediately in case already decided
        check();
      })
    ));
  }

  /**
   * Returns all proposals (optionally filtered).
   * @param {object} [filter={}]
   * @param {string} [filter.status]
   * @param {string} [filter.agentId]
   * @returns {object[]}
   */
  getProposals(filter = {}) {
    let proposals = Array.from(this._proposals.values());
    if (filter.status)  proposals = proposals.filter(p => p.status  === filter.status);
    if (filter.agentId) proposals = proposals.filter(p => p.agentId === filter.agentId);
    return proposals;
  }

  // ─── Internals ───────────────────────────────────────────────────────────────

  /**
   * @private
   */
  _evaluateConsensus(proposal, votes) {
    const result = this._buildConsensusResult(proposal, votes);

    if (result.total < this._minVoters) return proposal;

    if (result.yesFraction >= proposal.threshold) {
      proposal.status    = PROPOSAL_STATUS.ACCEPTED;
      proposal.decidedAt = Date.now();
      this._totalAccepted++;
      logger.logNodeActivity('SWARM-CONSENSUS',
        `CONSENSUS ACCEPTED: ${proposal.id}`);
      this.emit('proposal:decided', proposal);
      this.emit('proposal:accepted', proposal);

    } else if (result.noFraction > (1 - proposal.threshold)) {
      proposal.status    = PROPOSAL_STATUS.REJECTED;
      proposal.decidedAt = Date.now();
      this._totalRejected++;
      logger.logNodeActivity('SWARM-CONSENSUS',
        `CONSENSUS REJECTED: ${proposal.id}`);
      this.emit('proposal:decided', proposal);
      this.emit('proposal:rejected', proposal);
    }

    return proposal;
  }

  /**
   * @private
   */
  _buildConsensusResult(proposal, votes) {
    const voteValues = Array.from(votes.values());
    const total      = voteValues.length;
    const yesCount   = voteValues.filter(v => v === VOTE.YES).length;
    const noCount    = voteValues.filter(v => v === VOTE.NO).length;
    const abstain    = voteValues.filter(v => v === VOTE.ABSTAIN).length;
    const effective  = total - abstain;

    const yesFraction = effective > 0 ? yesCount / effective : 0;
    const noFraction  = effective > 0 ? noCount  / effective : 0;

    return {
      reached:     proposal.status === PROPOSAL_STATUS.ACCEPTED,
      status:      proposal.status,
      yesCount,
      noCount,
      abstainCount: abstain,
      total,
      effective,
      yesFraction:  parseFloat(yesFraction.toFixed(4)),
      noFraction:   parseFloat(noFraction.toFixed(4)),
      threshold:    proposal.threshold,
      proposalId:   proposal.id,
    };
  }

  /**
   * @private
   */
  _expire(proposalId) {
    const proposal = this._proposals.get(proposalId);
    if (!proposal || proposal.status !== PROPOSAL_STATUS.OPEN) return;
    proposal.status    = PROPOSAL_STATUS.EXPIRED;
    proposal.decidedAt = Date.now();
    this.emit('proposal:expired', proposal);
    logger.logNodeActivity('SWARM-CONSENSUS',
      `Proposal expired: ${proposalId}`);
  }

  /**
   * @private
   * Sweeps expired open proposals.
   */
  _sweep() {
    const now = Date.now();
    for (const [id, proposal] of this._proposals) {
      if (proposal.status === PROPOSAL_STATUS.OPEN && now > proposal.expiresAt) {
        this._expire(id);
      }
    }
  }

  /**
   * Returns swarm consensus statistics.
   * @returns {object}
   */
  getStats() {
    return {
      agents:          this._agents.size,
      proposals:       this._proposals.size,
      totalProposals:  this._totalProposals,
      totalAccepted:   this._totalAccepted,
      totalRejected:   this._totalRejected,
      open:            this.getProposals({ status: PROPOSAL_STATUS.OPEN }).length,
      defaultThreshold: this._defaultThreshold,
      createdAt:       this._createdAt,
    };
  }

  /**
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    app.post('/api/consensus/propose', (req, res) => {
      try {
        const { agentId, ...proposal } = req.body;
        const record = this.propose(agentId, proposal);
        res.status(201).json(record);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.post('/api/consensus/vote', (req, res) => {
      try {
        const { agentId, proposalId, vote } = req.body;
        const proposal = this.vote(agentId, proposalId, vote);
        res.json(proposal);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.get('/api/consensus/proposal/:id', (req, res) => {
      try {
        res.json(this.getProposal(req.params.id));
      } catch (err) {
        res.status(404).json({ error: err.message });
      }
    });

    app.get('/api/consensus/proposals', (req, res) => {
      res.json(this.getProposals(req.query));
    });

    app.get('/api/consensus/stats', (req, res) => {
      res.json(this.getStats());
    });

    logger.logNodeActivity('SWARM-CONSENSUS', 'Consensus routes registered');
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = { SwarmConsensus, PROPOSAL_STATUS, VOTE };
