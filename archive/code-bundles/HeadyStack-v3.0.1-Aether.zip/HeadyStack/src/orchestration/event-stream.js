'use strict';

/**
 * @fileoverview SSE Event Stream for HeadyStack
 * Server-Sent Events (SSE) multi-channel broadcasting system.
 * Supports per-client subscriptions, topic filtering, and heartbeat.
 *
 * @module orchestration/event-stream
 */

const { EventEmitter } = require('events');
const logger           = require('../utils/logger');

/** @constant {number} HEARTBEAT_INTERVAL_MS - SSE keep-alive ping interval */
const HEARTBEAT_INTERVAL_MS = 15000;

/** @constant {number} MAX_QUEUE - Max buffered events per client */
const MAX_QUEUE = 100;

/**
 * @class EventStream
 * @extends EventEmitter
 * @description Manages SSE connections and broadcasts events to subscribers.
 */
class EventStream extends EventEmitter {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.heartbeatMs=15000]  - Heartbeat interval in ms
   * @param {number} [opts.maxQueue=100]       - Max queued events per client before drop
   * @param {boolean} [opts.retry=true]        - Send SSE retry directive
   * @param {number} [opts.retryMs=3000]       - Client reconnect hint in ms
   */
  constructor(opts = {}) {
    super();

    this._heartbeatMs = opts.heartbeatMs ?? HEARTBEAT_INTERVAL_MS;
    this._maxQueue    = opts.maxQueue    ?? MAX_QUEUE;
    this._sendRetry   = opts.retry       !== false;
    this._retryMs     = opts.retryMs     ?? 3000;

    /** @type {Map<string, object>} clientId → client record */
    this._clients = new Map();

    /** @type {Map<string, Set<string>>} topic → Set of clientIds */
    this._topics  = new Map();

    this._heartbeatTimer = null;
    this._totalPublished = 0;
    this._totalDelivered = 0;
    this._totalDropped   = 0;
    this._eventSeq       = 0;
    this._createdAt      = Date.now();

    this._startHeartbeat();
  }

  // ─── Subscription Management ─────────────────────────────────────────────────

  /**
   * Subscribes a new SSE client.
   * @param {string}                          clientId - Unique client identifier
   * @param {import('http').ServerResponse}   res      - Express/HTTP response object
   * @param {object}                          [opts={}]
   * @param {string[]}                        [opts.topics=[]] - Subscribe to specific topics
   * @param {object}                          [opts.meta={}]   - Extra client metadata
   */
  subscribe(clientId, res, opts = {}) {
    if (this._clients.has(clientId)) {
      // Close existing connection
      this.unsubscribe(clientId);
    }

    // Set SSE headers
    res.setHeader('Content-Type',  'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache, no-transform');
    res.setHeader('Connection',    'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no'); // Nginx: disable buffering
    res.flushHeaders();

    const client = {
      id:           clientId,
      res,
      topics:       new Set(opts.topics || []),
      connectedAt:  Date.now(),
      lastEventAt:  null,
      sentCount:    0,
      droppedCount: 0,
      meta:         opts.meta || {},
    };

    this._clients.set(clientId, client);

    // Register topic subscriptions
    for (const topic of client.topics) {
      this._addToTopic(topic, clientId);
    }

    // Send connected event
    this._writeEvent(client, 'connected', {
      clientId,
      topics:    Array.from(client.topics),
      serverAt:  Date.now(),
    });

    // Send retry hint
    if (this._sendRetry) {
      res.write(`retry: ${this._retryMs}\n\n`);
    }

    // Handle client disconnect
    const cleanup = () => this.unsubscribe(clientId);
    res.on('close',  cleanup);
    res.on('finish', cleanup);
    res.on('error',  cleanup);

    logger.logNodeActivity('EVENT-STREAM',
      `Client subscribed: ${clientId} (topics: ${Array.from(client.topics).join(', ') || 'all'})`);
    this.emit('client:connected', { clientId, topics: Array.from(client.topics) });
  }

  /**
   * Unsubscribes a client.
   * @param {string} clientId
   */
  unsubscribe(clientId) {
    const client = this._clients.get(clientId);
    if (!client) return;

    // Remove from topic maps
    for (const topic of client.topics) {
      this._removeFromTopic(topic, clientId);
    }

    // Attempt to end the response cleanly
    try {
      if (!client.res.writableEnded) client.res.end();
    } catch { /* ignore */ }

    this._clients.delete(clientId);
    logger.logNodeActivity('EVENT-STREAM', `Client disconnected: ${clientId}`);
    this.emit('client:disconnected', { clientId });
  }

  /**
   * Subscribes a client to a specific topic.
   * @param {string} clientId
   * @param {string} topic
   */
  subscribeTopic(clientId, topic) {
    const client = this._clients.get(clientId);
    if (!client) return;
    client.topics.add(topic);
    this._addToTopic(topic, clientId);
  }

  /**
   * Unsubscribes a client from a specific topic.
   * @param {string} clientId
   * @param {string} topic
   */
  unsubscribeTopic(clientId, topic) {
    const client = this._clients.get(clientId);
    if (!client) return;
    client.topics.delete(topic);
    this._removeFromTopic(topic, clientId);
  }

  // ─── Publishing ───────────────────────────────────────────────────────────────

  /**
   * Publishes an event to all subscribed clients.
   * If a topic is provided, only clients subscribed to that topic receive it.
   * Clients with no topic filter receive all events.
   *
   * @param {string} event   - Event type name
   * @param {*}      data    - Event payload (will be JSON-serialized)
   * @param {object} [opts={}]
   * @param {string} [opts.topic]    - Restrict delivery to topic subscribers
   * @param {string} [opts.clientId] - Send only to specific client
   * @returns {number} Number of clients delivered to
   */
  publish(event, data, opts = {}) {
    this._totalPublished++;
    const id      = ++this._eventSeq;
    const payload = { ...data, _event: event, _seq: id, _at: Date.now() };

    let targets;

    if (opts.clientId) {
      const c = this._clients.get(opts.clientId);
      targets = c ? [c] : [];

    } else if (opts.topic) {
      const subscribers = this._topics.get(opts.topic) || new Set();
      targets = [];
      for (const [clientId, client] of this._clients) {
        // Deliver to: topic subscribers OR clients with no filter
        if (subscribers.has(clientId) || client.topics.size === 0) {
          targets.push(client);
        }
      }

    } else {
      // Broadcast to all
      targets = Array.from(this._clients.values());
    }

    let delivered = 0;
    for (const client of targets) {
      const ok = this._writeEvent(client, event, payload, id);
      if (ok) delivered++;
    }

    this._totalDelivered += delivered;

    this.emit('published', { event, topic: opts.topic, delivered, seq: id });

    return delivered;
  }

  // ─── Internals ───────────────────────────────────────────────────────────────

  /**
   * @private
   * Writes a single SSE event to a client.
   * @returns {boolean} true if written successfully
   */
  _writeEvent(client, event, data, id) {
    try {
      if (client.res.writableEnded || client.res.destroyed) {
        this.unsubscribe(client.id);
        return false;
      }

      let msg = '';
      if (id)    msg += `id: ${id}\n`;
      if (event) msg += `event: ${event}\n`;
      msg += `data: ${JSON.stringify(data)}\n\n`;

      client.res.write(msg);
      client.sentCount++;
      client.lastEventAt = Date.now();
      return true;

    } catch (err) {
      logger.logNodeActivity('EVENT-STREAM',
        `Write error for client ${client.id}: ${err.message}`);
      this._totalDropped++;
      client.droppedCount++;
      this.unsubscribe(client.id);
      return false;
    }
  }

  /**
   * @private
   */
  _addToTopic(topic, clientId) {
    if (!this._topics.has(topic)) this._topics.set(topic, new Set());
    this._topics.get(topic).add(clientId);
  }

  /**
   * @private
   */
  _removeFromTopic(topic, clientId) {
    const set = this._topics.get(topic);
    if (set) {
      set.delete(clientId);
      if (set.size === 0) this._topics.delete(topic);
    }
  }

  /**
   * @private
   * Sends a heartbeat comment to keep connections alive.
   */
  _startHeartbeat() {
    this._heartbeatTimer = setInterval(() => {
      const now = Date.now();
      for (const client of this._clients.values()) {
        try {
          if (!client.res.writableEnded) {
            client.res.write(`: heartbeat ${now}\n\n`);
          }
        } catch { this.unsubscribe(client.id); }
      }
    }, this._heartbeatMs);

    if (this._heartbeatTimer.unref) this._heartbeatTimer.unref();
  }

  // ─── Stats ───────────────────────────────────────────────────────────────────

  /**
   * Returns stream statistics.
   * @returns {object}
   */
  getStats() {
    return {
      clients:        this._clients.size,
      topics:         this._topics.size,
      totalPublished: this._totalPublished,
      totalDelivered: this._totalDelivered,
      totalDropped:   this._totalDropped,
      eventSeq:       this._eventSeq,
      createdAt:      this._createdAt,
      clientList:     Array.from(this._clients.values()).map(c => ({
        id:           c.id,
        topics:       Array.from(c.topics),
        connectedAt:  c.connectedAt,
        sentCount:    c.sentCount,
        droppedCount: c.droppedCount,
      })),
    };
  }

  // ─── Graceful Shutdown ───────────────────────────────────────────────────────

  /**
   * Closes all SSE connections and stops heartbeat.
   */
  shutdown() {
    if (this._heartbeatTimer) clearInterval(this._heartbeatTimer);

    for (const clientId of this._clients.keys()) {
      this.publish('server:shutdown', { message: 'Server shutting down' }, { clientId });
      this.unsubscribe(clientId);
    }

    logger.logNodeActivity('EVENT-STREAM', 'EventStream shut down');
  }

  // ─── Express Routes ───────────────────────────────────────────────────────────

  /**
   * Registers SSE stream routes on an Express app.
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    /**
     * GET /api/events/stream
     * Query params: clientId?, topics? (comma-separated)
     */
    app.get('/api/events/stream', (req, res) => {
      const clientId = req.query.clientId
        || `sse_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
      const topics   = req.query.topics
        ? req.query.topics.split(',').map(t => t.trim()).filter(Boolean)
        : [];

      this.subscribe(clientId, res, {
        topics,
        meta: {
          ip:        req.ip,
          userAgent: req.headers['user-agent'],
        },
      });
    });

    /**
     * POST /api/events/publish
     * Body: { event, data, topic?, clientId? }
     */
    app.post('/api/events/publish', (req, res) => {
      const { event, data, topic, clientId } = req.body || {};
      if (!event) return res.status(400).json({ error: 'event is required' });

      const delivered = this.publish(event, data || {}, { topic, clientId });
      res.json({ delivered, seq: this._eventSeq });
    });

    /**
     * GET /api/events/stats
     */
    app.get('/api/events/stats', (req, res) => {
      res.json(this.getStats());
    });

    /**
     * DELETE /api/events/client/:clientId
     */
    app.delete('/api/events/client/:clientId', (req, res) => {
      this.unsubscribe(req.params.clientId);
      res.json({ disconnected: true });
    });

    logger.logNodeActivity('EVENT-STREAM', 'SSE event stream routes registered');
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = { EventStream };
