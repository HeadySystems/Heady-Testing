'use strict';

/**
 * @fileoverview Swarm Intelligence — Collective Decision-Making Engine
 * Aggregates scores and evaluations from multiple agents to produce
 * emergent decisions using configurable aggregation strategies.
 *
 * @module orchestration/swarm-intelligence
 */

const { EventEmitter } = require('events');
const logger           = require('../utils/logger');

/** @constant {number} MAX_DECISIONS - Max decision history to retain */
const MAX_DECISIONS = 500;

/** @constant {number} MAX_INSIGHTS - Max insight entries to retain */
const MAX_INSIGHTS  = 200;

/**
 * @typedef {object} AgentScore
 * @property {string} agentId
 * @property {string} optionId
 * @property {number} score     - Normalized score [0, 1]
 * @property {number} confidence - Agent's confidence in this score [0, 1]
 * @property {object} [rationale]
 */

/**
 * @class SwarmIntelligence
 * @extends EventEmitter
 * @description Collective decision-making via scored multi-agent evaluations.
 */
class SwarmIntelligence extends EventEmitter {
  /**
   * @param {object} [opts={}]
   * @param {string} [opts.aggregation='weighted_confidence'] - 'mean'|'weighted_confidence'|'borda'|'plurality'
   * @param {number} [opts.minAgents=1]    - Minimum agents needed for a valid decision
   */
  constructor(opts = {}) {
    super();

    this._aggregation = opts.aggregation ?? 'weighted_confidence';
    this._minAgents   = opts.minAgents   ?? 1;

    /** @type {object[]} - Decision history */
    this._decisions  = [];

    /** @type {object[]} - Learned patterns/insights */
    this._insights   = [];

    /** @type {Map<string, object>} - Registered agent profiles */
    this._agents     = new Map();

    /** @type {Map<string, number>} - Agent reputation scores [0, 1] */
    this._reputation = new Map();

    this._totalDecisions = 0;
    this._createdAt      = Date.now();
  }

  // ─── Agent Registry ───────────────────────────────────────────────────────────

  /**
   * Registers an agent with an optional initial reputation score.
   * @param {string} agentId
   * @param {object} [profile={}]
   * @param {number} [reputation=0.5] - Initial reputation [0, 1]
   */
  registerAgent(agentId, profile = {}, reputation = 0.5) {
    this._agents.set(agentId, {
      id:           agentId,
      type:         profile.type        || 'generic',
      specialty:    profile.specialty   || [],
      registeredAt: Date.now(),
      ...profile,
    });
    this._reputation.set(agentId, Math.max(0, Math.min(1, reputation)));
    logger.logNodeActivity('SWARM-INTELLIGENCE',
      `Agent registered: ${agentId} (rep: ${reputation})`);
  }

  // ─── Evaluation ──────────────────────────────────────────────────────────────

  /**
   * Evaluates a set of options using scores from multiple agents.
   * @param {object[]} options   - Options to evaluate: [{ id, label, ...meta }]
   * @param {AgentScore[]} agentScores - Scores: [{ agentId, optionId, score, confidence }]
   * @param {object} [context={}]      - Extra context for this evaluation
   * @returns {object} Decision result with ranked options
   */
  evaluate(options, agentScores, context = {}) {
    if (!Array.isArray(options) || options.length === 0) {
      throw new TypeError('evaluate() requires a non-empty options array');
    }
    if (!Array.isArray(agentScores) || agentScores.length === 0) {
      throw new TypeError('evaluate() requires at least one agent score');
    }

    const agentIds = [...new Set(agentScores.map(s => s.agentId))];
    if (agentIds.length < this._minAgents) {
      throw new Error(
        `Insufficient agents: ${agentIds.length} < minimum ${this._minAgents}`
      );
    }

    // Group scores by option
    const scoresByOption = {};
    for (const opt of options) {
      scoresByOption[opt.id] = agentScores.filter(s => s.optionId === opt.id);
    }

    // Aggregate
    const ranked = options.map(opt => {
      const scores  = scoresByOption[opt.id] || [];
      const agg     = this._aggregate(scores, this._aggregation);
      return {
        ...opt,
        aggregatedScore: agg.score,
        confidence:      agg.confidence,
        voteCount:       scores.length,
        rawScores:       scores,
      };
    }).sort((a, b) => b.aggregatedScore - a.aggregatedScore);

    const winner  = ranked[0];
    const runnerUp = ranked[1];
    const margin   = winner && runnerUp
      ? winner.aggregatedScore - runnerUp.aggregatedScore
      : 1;

    const decision = {
      id:          `decision_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      winner,
      ranked,
      margin,
      agentCount:  agentIds.length,
      optionCount: options.length,
      aggregation: this._aggregation,
      context,
      at:          Date.now(),
      unanimous:   ranked.every(o => o.aggregatedScore === winner.aggregatedScore) === false
        && agentIds.length > 1
        && ranked.filter(o => o.voteCount > 0).every(o => o.aggregatedScore === winner.aggregatedScore),
    };

    this._recordDecision(decision);
    this._learnFromDecision(decision, agentScores);
    this.emit('decision', decision);

    logger.logNodeActivity('SWARM-INTELLIGENCE',
      `Decision: winner="${winner.id || winner.label}" ` +
      `(score: ${winner.aggregatedScore.toFixed(3)}, margin: ${margin.toFixed(3)})`);

    return decision;
  }

  /**
   * Aggregates multi-agent inputs into an emergent decision.
   * Accepts free-form inputs with optional scoring.
   *
   * @param {object[]} inputs - [{ agentId, value, weight?, confidence? }]
   * @param {object}   [opts={}]
   * @returns {object} Emergent result: { decision, confidence, inputs }
   */
  emergentDecision(inputs, opts = {}) {
    if (!Array.isArray(inputs) || inputs.length === 0) {
      throw new TypeError('emergentDecision() requires non-empty inputs');
    }

    // Numeric inputs: take weighted average
    const numericInputs = inputs.filter(i => typeof i.value === 'number');
    if (numericInputs.length > 0) {
      let weightedSum = 0;
      let totalWeight = 0;
      for (const inp of numericInputs) {
        const w = (inp.weight ?? 1) * (inp.confidence ?? 1);
        weightedSum += inp.value * w;
        totalWeight += w;
      }
      const emergent   = totalWeight > 0 ? weightedSum / totalWeight : 0;
      const confidence = inputs.reduce((s, i) => s + (i.confidence ?? 0.5), 0) / inputs.length;

      return {
        decision:   emergent,
        confidence: parseFloat(confidence.toFixed(4)),
        type:       'numeric_aggregate',
        inputs,
        at:         Date.now(),
      };
    }

    // Categorical inputs: plurality vote
    const counts = {};
    for (const inp of inputs) {
      const key    = String(inp.value);
      counts[key]  = (counts[key] || 0) + (inp.weight ?? 1);
    }
    const sorted  = Object.entries(counts).sort(([, a], [, b]) => b - a);
    const total   = Object.values(counts).reduce((s, v) => s + v, 0);
    const topVal  = sorted[0];

    return {
      decision:   topVal[0],
      confidence: parseFloat((topVal[1] / total).toFixed(4)),
      type:       'plurality',
      distribution: Object.fromEntries(sorted.map(([k, v]) => [k, v / total])),
      inputs,
      at:         Date.now(),
    };
  }

  // ─── Insights ────────────────────────────────────────────────────────────────

  /**
   * Returns learned insights from swarm decisions.
   * @param {object} [filter={}]
   * @param {number} [filter.limit=20]
   * @returns {object[]}
   */
  getInsights(filter = {}) {
    const limit = filter.limit ?? 20;
    return this._insights.slice(-limit);
  }

  /**
   * Returns all recorded decisions.
   * @param {number} [limit=50]
   * @returns {object[]}
   */
  getDecisions(limit = 50) {
    return this._decisions.slice(-limit);
  }

  /**
   * Returns swarm intelligence statistics.
   * @returns {object}
   */
  getStats() {
    const repValues = Array.from(this._reputation.values());
    const avgRep    = repValues.length > 0
      ? repValues.reduce((s, v) => s + v, 0) / repValues.length
      : 0;

    return {
      agents:          this._agents.size,
      totalDecisions:  this._totalDecisions,
      insightCount:    this._insights.length,
      avgReputation:   parseFloat(avgRep.toFixed(4)),
      aggregation:     this._aggregation,
      createdAt:       this._createdAt,
    };
  }

  // ─── Reputation ───────────────────────────────────────────────────────────────

  /**
   * Updates agent reputation based on outcome feedback.
   * @param {string} agentId
   * @param {boolean} wasCorrect  - Whether agent's top-scored option was selected
   * @param {number}  [delta=0.05]
   */
  updateReputation(agentId, wasCorrect, delta = 0.05) {
    const current = this._reputation.get(agentId) ?? 0.5;
    const updated = Math.max(0, Math.min(1,
      wasCorrect ? current + delta : current - delta
    ));
    this._reputation.set(agentId, updated);
  }

  /**
   * Returns reputation scores for all agents.
   * @returns {object}
   */
  getReputations() {
    return Object.fromEntries(this._reputation);
  }

  // ─── Internals ───────────────────────────────────────────────────────────────

  /**
   * @private
   * Aggregates a set of scores using the configured strategy.
   * @param {AgentScore[]} scores
   * @param {string}       strategy
   * @returns {{ score: number, confidence: number }}
   */
  _aggregate(scores, strategy) {
    if (scores.length === 0) return { score: 0, confidence: 0 };

    switch (strategy) {
      case 'mean': {
        const avg  = scores.reduce((s, r) => s + r.score, 0) / scores.length;
        const conf = scores.reduce((s, r) => s + (r.confidence ?? 0.5), 0) / scores.length;
        return { score: avg, confidence: conf };
      }

      case 'weighted_confidence': {
        let wSum = 0;
        let wTot = 0;
        for (const s of scores) {
          const rep = this._reputation.get(s.agentId) ?? 0.5;
          const w   = (s.confidence ?? 0.5) * rep;
          wSum += s.score * w;
          wTot += w;
        }
        const score = wTot > 0 ? wSum / wTot : 0;
        const conf  = scores.reduce((s, r) => s + (r.confidence ?? 0.5), 0) / scores.length;
        return { score, confidence: conf };
      }

      case 'borda': {
        // Each score maps to a Borda position — here we use the score directly
        // since we have continuous scores rather than rankings
        const sorted  = [...scores].sort((a, b) => b.score - a.score);
        const n       = sorted.length;
        const bordaMap = new Map(sorted.map((s, i) => [s.agentId, n - i]));
        const total   = [...bordaMap.values()].reduce((s, v) => s + v, 0);
        const normalized = total > 0 ? (scores.reduce((s, r) => s + r.score, 0) / scores.length) : 0;
        return { score: normalized, confidence: 0.7 };
      }

      case 'plurality': {
        // Highest individual score wins; confidence = fraction of agents who agree it's best
        const maxScore  = Math.max(...scores.map(s => s.score));
        const winners   = scores.filter(s => s.score === maxScore);
        return {
          score:      maxScore,
          confidence: winners.length / scores.length,
        };
      }

      default:
        throw new Error(`Unknown aggregation strategy: "${strategy}"`);
    }
  }

  /**
   * @private
   */
  _recordDecision(decision) {
    this._decisions.push(decision);
    this._totalDecisions++;
    if (this._decisions.length > MAX_DECISIONS) this._decisions.shift();
  }

  /**
   * @private
   * Extracts and stores insights from a completed decision.
   */
  _learnFromDecision(decision, agentScores) {
    // Track consensus strength over time
    const insight = {
      at:          decision.at,
      decisionId:  decision.id,
      winnerScore: decision.winner?.aggregatedScore,
      margin:      decision.margin,
      agentCount:  decision.agentCount,
      consensus:   decision.margin > 0.3 ? 'strong' : decision.margin > 0.1 ? 'moderate' : 'weak',
    };

    this._insights.push(insight);
    if (this._insights.length > MAX_INSIGHTS) this._insights.shift();
  }

  // ─── Express Routes ───────────────────────────────────────────────────────────

  /**
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    app.post('/api/swarm/evaluate', (req, res) => {
      try {
        const { options, agentScores, context } = req.body;
        const result = this.evaluate(options, agentScores, context);
        res.json(result);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.post('/api/swarm/emergent', (req, res) => {
      try {
        const { inputs, opts } = req.body;
        const result = this.emergentDecision(inputs, opts);
        res.json(result);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.get('/api/swarm/insights', (req, res) => {
      const limit = parseInt(req.query.limit, 10) || 20;
      res.json(this.getInsights({ limit }));
    });

    app.get('/api/swarm/decisions', (req, res) => {
      const limit = parseInt(req.query.limit, 10) || 50;
      res.json(this.getDecisions(limit));
    });

    app.get('/api/swarm/reputations', (req, res) => {
      res.json(this.getReputations());
    });

    app.get('/api/swarm/stats', (req, res) => {
      res.json(this.getStats());
    });

    logger.logNodeActivity('SWARM-INTELLIGENCE',
      'Swarm intelligence routes registered');
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = { SwarmIntelligence };
