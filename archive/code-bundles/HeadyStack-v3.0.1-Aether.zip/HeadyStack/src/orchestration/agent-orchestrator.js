'use strict';

/**
 * @fileoverview Multi-Agent Orchestrator for HeadyStack
 * Manages a registry of specialist agents, routes tasks to the best agent,
 * and provides runtime spawn/retire lifecycle management.
 *
 * @module orchestration/agent-orchestrator
 */

const { EventEmitter } = require('events');
const { LRUCache }     = require('../resilience/cache');
const { retry }        = require('../resilience/retry');
const logger           = require('../utils/logger');

/** @type {AgentOrchestrator|null} */
let _instance = null;

/** @enum {string} */
const AGENT_STATE = Object.freeze({
  IDLE:     'IDLE',
  BUSY:     'BUSY',
  ERROR:    'ERROR',
  RETIRED:  'RETIRED',
  SPAWNING: 'SPAWNING',
});

/** @enum {string} */
const AGENT_TYPE = Object.freeze({
  GENERAL:    'general',
  RESEARCHER: 'researcher',
  PLANNER:    'planner',
  EXECUTOR:   'executor',
  VALIDATOR:  'validator',
  SYNTHESIZER: 'synthesizer',
  MONITOR:    'monitor',
  CUSTOM:     'custom',
});

// ─── BaseAgent ────────────────────────────────────────────────────────────────

/**
 * @class BaseAgent
 * @description Abstract base for all orchestrated agents.
 */
class BaseAgent extends EventEmitter {
  /**
   * @param {object} config
   * @param {string} config.id
   * @param {string} [config.type]
   * @param {string} [config.name]
   * @param {number} [config.maxConcurrent=3]
   */
  constructor(config) {
    super();
    this.id            = config.id;
    this.type          = config.type    || AGENT_TYPE.GENERAL;
    this.name          = config.name    || `agent-${config.id}`;
    this.maxConcurrent = config.maxConcurrent ?? 3;

    this.state         = AGENT_STATE.IDLE;
    this.activeTasks   = 0;
    this.totalTasks    = 0;
    this.totalErrors   = 0;
    this.spawnedAt     = Date.now();
    this.lastTaskAt    = null;
    this.meta          = config.meta || {};

    /** @type {Function|null} Custom task handler */
    this._handler      = config.handler || null;
  }

  /**
   * Returns true if this agent can accept more tasks.
   * @returns {boolean}
   */
  isAvailable() {
    return this.state !== AGENT_STATE.RETIRED
        && this.state !== AGENT_STATE.ERROR
        && this.activeTasks < this.maxConcurrent;
  }

  /**
   * Executes a task.
   * @param {object} task
   * @returns {Promise<object>} Task result
   */
  async run(task) {
    if (!this.isAvailable()) {
      throw new Error(`Agent ${this.id} is not available (state: ${this.state})`);
    }

    this.state = AGENT_STATE.BUSY;
    this.activeTasks++;
    this.totalTasks++;
    this.lastTaskAt = Date.now();

    const startAt = Date.now();

    try {
      let result;
      if (typeof this._handler === 'function') {
        result = await this._handler(task, this);
      } else {
        result = await this._defaultHandle(task);
      }

      return {
        agentId:  this.id,
        taskId:   task.id,
        result,
        duration: Date.now() - startAt,
        success:  true,
      };

    } catch (err) {
      this.totalErrors++;
      this.emit('error', { agentId: this.id, taskId: task.id, error: err.message });
      throw err;

    } finally {
      this.activeTasks--;
      if (this.activeTasks === 0) this.state = AGENT_STATE.IDLE;
    }
  }

  /**
   * @protected
   * Default task handler when no custom handler is provided.
   * @param {object} task
   * @returns {Promise<object>}
   */
  async _defaultHandle(task) {
    // No-op: returns the task payload as-is
    return {
      processed: true,
      type:      this.type,
      payload:   task.payload,
    };
  }

  /**
   * Returns agent status snapshot.
   * @returns {object}
   */
  getStatus() {
    return {
      id:           this.id,
      name:         this.name,
      type:         this.type,
      state:        this.state,
      activeTasks:  this.activeTasks,
      totalTasks:   this.totalTasks,
      totalErrors:  this.totalErrors,
      maxConcurrent: this.maxConcurrent,
      spawnedAt:    this.spawnedAt,
      lastTaskAt:   this.lastTaskAt,
      available:    this.isAvailable(),
      errorRate:    this.totalTasks > 0
        ? parseFloat((this.totalErrors / this.totalTasks).toFixed(4))
        : 0,
    };
  }

  retire() {
    this.state = AGENT_STATE.RETIRED;
    this.emit('retired', { agentId: this.id });
  }
}

// ─── AgentOrchestrator ───────────────────────────────────────────────────────

/**
 * @class AgentOrchestrator
 * @extends EventEmitter
 * @description Manages the agent registry, task routing, and lifecycle.
 * Singleton — use getOrchestrator() to obtain the instance.
 */
class AgentOrchestrator extends EventEmitter {
  /**
   * @param {object} [opts={}]
   * @param {string} [opts.routingStrategy='least-loaded'] - 'least-loaded'|'round-robin'|'type-match'
   * @param {number} [opts.taskTimeoutMs=30000]
   */
  constructor(opts = {}) {
    super();

    if (_instance) return _instance;

    this._strategy     = opts.routingStrategy ?? 'least-loaded';
    this._taskTimeout  = opts.taskTimeoutMs   ?? 30000;
    this._vectorMemory = null;

    /** @type {Map<string, BaseAgent>} */
    this._agents = new Map();

    this._routeCache   = new LRUCache({ maxSize: 500, ttlMs: 10000, name: 'route-cache' });
    this._taskLog      = [];
    this._roundRobinIdx = 0;

    this._totalRouted  = 0;
    this._totalSuccess = 0;
    this._totalFailed  = 0;
    this._createdAt    = Date.now();

    // Pre-spawn default agent types
    this._seedDefaultAgents();

    _instance = this;
    logger.logNodeActivity('AGENT-ORCHESTRATOR', 'AgentOrchestrator initialized');
  }

  // ─── Wiring ──────────────────────────────────────────────────────────────────

  /**
   * @param {object} vm - Vector memory instance
   */
  setVectorMemory(vm) {
    this._vectorMemory = vm;
    logger.logNodeActivity('AGENT-ORCHESTRATOR', 'Vector memory wired');
  }

  // ─── Agent Lifecycle ─────────────────────────────────────────────────────────

  /**
   * Spawns a new agent and registers it.
   * @param {string} type   - Agent type (AGENT_TYPE value or 'custom')
   * @param {object} [config={}] - Agent configuration
   * @returns {BaseAgent}
   */
  spawnAgent(type, config = {}) {
    const id = config.id || `${type}_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    const agent = new BaseAgent({ ...config, id, type });

    agent.on('error', (evt) => {
      logger.logNodeActivity('AGENT-ORCHESTRATOR',
        `Agent ${evt.agentId} error on task ${evt.taskId}: ${evt.error}`);
      this.emit('agent:error', evt);
    });

    agent.on('retired', (evt) => {
      logger.logNodeActivity('AGENT-ORCHESTRATOR',
        `Agent ${evt.agentId} retired`);
      this.emit('agent:retired', evt);
    });

    this._agents.set(id, agent);
    logger.logNodeActivity('AGENT-ORCHESTRATOR',
      `Spawned agent: ${id} (type: ${type})`);
    this.emit('agent:spawned', { id, type });

    return agent;
  }

  /**
   * Retires an agent (marks as RETIRED; removes from routing).
   * @param {string} agentId
   */
  retireAgent(agentId) {
    const agent = this._agents.get(agentId);
    if (!agent) throw new Error(`Agent not found: ${agentId}`);
    agent.retire();
  }

  /**
   * Removes a retired/errored agent from the registry.
   * @param {string} agentId
   */
  removeAgent(agentId) {
    this._agents.delete(agentId);
  }

  // ─── Routing ─────────────────────────────────────────────────────────────────

  /**
   * Routes a task to the best available agent and executes it.
   * @param {object} task
   * @param {string} [task.id]
   * @param {string} [task.type]    - Preferred agent type
   * @param {*}      [task.payload]
   * @returns {Promise<object>} Task result from the chosen agent
   */
  async routeToAgent(task) {
    this._totalRouted++;
    const taskId = task.id || `task_${Date.now()}`;
    const taskWithId = { ...task, id: taskId };

    const agent = this._selectAgent(taskWithId);
    if (!agent) {
      this._totalFailed++;
      throw new Error(
        `No available agent for task type "${task.type || 'any'}". ` +
        `Active agents: ${this._agents.size}`
      );
    }

    logger.logNodeActivity('AGENT-ORCHESTRATOR',
      `Routing task ${taskId} → agent ${agent.id} (${agent.type})`);

    try {
      const result = await retry(
        () => agent.run(taskWithId),
        {
          maxRetries:  1,
          backoffType: 'phi',
          label:       `route:${agent.id}`,
          shouldRetry: () => agent.isAvailable(),
        }
      );

      this._totalSuccess++;
      this._logTask({ taskId, agentId: agent.id, success: true, at: Date.now() });
      this.emit('task:routed', { taskId, agentId: agent.id, result });
      return result;

    } catch (err) {
      this._totalFailed++;
      this._logTask({ taskId, agentId: agent.id, success: false, error: err.message, at: Date.now() });
      this.emit('task:failed', { taskId, agentId: agent.id, error: err.message });
      throw err;
    }
  }

  // ─── Agent Selection ──────────────────────────────────────────────────────────

  /**
   * @private
   * Selects an agent based on the configured routing strategy.
   * @param {object} task
   * @returns {BaseAgent|null}
   */
  _selectAgent(task) {
    const available = Array.from(this._agents.values())
      .filter(a => a.isAvailable());

    if (available.length === 0) return null;

    switch (this._strategy) {
      case 'type-match': {
        // Prefer matching type, fall back to any
        const typed = task.type
          ? available.filter(a => a.type === task.type)
          : available;
        return typed.length > 0
          ? this._leastLoaded(typed)
          : this._leastLoaded(available);
      }

      case 'round-robin': {
        const idx = this._roundRobinIdx % available.length;
        this._roundRobinIdx++;
        return available[idx];
      }

      case 'least-loaded':
      default:
        return this._leastLoaded(available);
    }
  }

  /**
   * @private
   * Returns the agent with the fewest active tasks.
   * @param {BaseAgent[]} agents
   * @returns {BaseAgent}
   */
  _leastLoaded(agents) {
    return agents.reduce((best, curr) =>
      curr.activeTasks < best.activeTasks ? curr : best
    );
  }

  // ─── Agent Status ─────────────────────────────────────────────────────────────

  /**
   * Returns the status of all registered agents.
   * @returns {object[]}
   */
  getAgentStatus() {
    return Array.from(this._agents.values()).map(a => a.getStatus());
  }

  /**
   * Returns orchestrator-level statistics.
   * @returns {object}
   */
  getStats() {
    const agents      = this.getAgentStatus();
    const available   = agents.filter(a => a.available).length;
    const busy        = agents.filter(a => a.state === AGENT_STATE.BUSY).length;

    return {
      strategy:      this._strategy,
      totalAgents:   this._agents.size,
      available,
      busy,
      retired:       agents.filter(a => a.state === AGENT_STATE.RETIRED).length,
      totalRouted:   this._totalRouted,
      totalSuccess:  this._totalSuccess,
      totalFailed:   this._totalFailed,
      successRate:   this._totalRouted > 0
        ? parseFloat((this._totalSuccess / this._totalRouted).toFixed(4))
        : 0,
      recentTasks:   this._taskLog.slice(-20),
      createdAt:     this._createdAt,
    };
  }

  // ─── Internals ───────────────────────────────────────────────────────────────

  /**
   * @private
   */
  _logTask(entry) {
    this._taskLog.push(entry);
    if (this._taskLog.length > 200) this._taskLog.shift();
  }

  /**
   * @private
   * Seeds one agent per default type.
   */
  _seedDefaultAgents() {
    const types = [
      AGENT_TYPE.GENERAL,
      AGENT_TYPE.RESEARCHER,
      AGENT_TYPE.PLANNER,
      AGENT_TYPE.EXECUTOR,
      AGENT_TYPE.VALIDATOR,
    ];
    for (const type of types) {
      this.spawnAgent(type, {
        name:         `default-${type}`,
        maxConcurrent: 5,
      });
    }
  }

  // ─── Express Routes ───────────────────────────────────────────────────────────

  /**
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    /**
     * GET /api/orchestrator/agents
     */
    app.get('/api/orchestrator/agents', (req, res) => {
      res.json(this.getAgentStatus());
    });

    /**
     * POST /api/orchestrator/agents/spawn
     * Body: { type, ...config }
     */
    app.post('/api/orchestrator/agents/spawn', (req, res) => {
      try {
        const { type, ...config } = req.body || {};
        const agent = this.spawnAgent(type || AGENT_TYPE.GENERAL, config);
        res.status(201).json(agent.getStatus());
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    /**
     * DELETE /api/orchestrator/agents/:id
     */
    app.delete('/api/orchestrator/agents/:id', (req, res) => {
      try {
        this.retireAgent(req.params.id);
        res.json({ retired: true });
      } catch (err) {
        res.status(404).json({ error: err.message });
      }
    });

    /**
     * GET /api/orchestrator/tasks
     */
    app.get('/api/orchestrator/tasks', (req, res) => {
      const limit = parseInt(req.query.limit, 10) || 50;
      res.json(this._taskLog.slice(-limit));
    });

    /**
     * POST /api/orchestrator/tasks/route
     * Body: task object
     */
    app.post('/api/orchestrator/tasks/route', async (req, res) => {
      try {
        const result = await this.routeToAgent(req.body);
        res.json(result);
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * GET /api/orchestrator/stats
     */
    app.get('/api/orchestrator/stats', (req, res) => {
      res.json(this.getStats());
    });

    logger.logNodeActivity('AGENT-ORCHESTRATOR',
      'Agent orchestrator routes registered');
  }
}

// ─── Singleton Factory ────────────────────────────────────────────────────────

/**
 * Returns the AgentOrchestrator singleton.
 * @param {object} [opts={}]
 * @returns {AgentOrchestrator}
 */
function getOrchestrator(opts = {}) {
  if (!_instance) {
    _instance = new AgentOrchestrator(opts);
  }
  return _instance;
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  AgentOrchestrator,
  BaseAgent,
  getOrchestrator,
  AGENT_STATE,
  AGENT_TYPE,
};
