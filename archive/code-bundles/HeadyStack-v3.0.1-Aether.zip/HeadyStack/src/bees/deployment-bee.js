'use strict';

/**
 * @fileoverview Deployment bee — manages deployment workflows, verification, and rollback.
 * @module bees/deployment-bee
 */

const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
const logger = require('../utils/logger');

const execFileAsync = promisify(execFile);

const domain = 'deployment';
const description = 'Manages deployment workflows: pre-deploy checks, version tracking, rollback';
const priority = 0.87;

/**
 * Reads the current git HEAD commit hash.
 * @param {string} cwd
 * @returns {Promise<string>}
 */
async function getGitCommit(cwd) {
  try {
    const { stdout } = await execFileAsync('git', ['rev-parse', 'HEAD'], { cwd, timeout: 5000 });
    return stdout.trim();
  } catch {
    return 'unknown';
  }
}

/**
 * Gets git branch name.
 * @param {string} cwd
 * @returns {Promise<string>}
 */
async function getGitBranch(cwd) {
  try {
    const { stdout } = await execFileAsync('git', ['rev-parse', '--abbrev-ref', 'HEAD'], { cwd, timeout: 5000 });
    return stdout.trim();
  } catch {
    return 'unknown';
  }
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Run pre-deployment checks (tests exist, no uncommitted changes on main, etc.).
   * @returns {Promise<Object>}
   */
  async function runPreDeployChecks() {
    const projectDir = context.projectDir || process.cwd();
    logger.debug(`[deployment] running pre-deploy checks for ${projectDir}`);

    const checks = [];

    // Check package.json has test script
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(projectDir, 'package.json'), 'utf8'));
      const hasTest = !!(pkg.scripts && pkg.scripts.test);
      const hasBuild = !!(pkg.scripts && pkg.scripts.build);
      const hasStart = !!(pkg.scripts && pkg.scripts.start);
      checks.push(
        { name: 'test-script', pass: hasTest, detail: hasTest ? 'found' : 'missing' },
        { name: 'build-script', pass: hasBuild, detail: hasBuild ? 'found' : 'missing' },
        { name: 'start-script', pass: hasStart, detail: hasStart ? 'found' : 'missing' },
      );
    } catch (err) {
      checks.push({ name: 'package-json', pass: false, detail: err.message });
    }

    // Check git status for uncommitted changes
    try {
      const { stdout } = await execFileAsync('git', ['status', '--porcelain'], { cwd: projectDir, timeout: 5000 });
      const dirty = stdout.trim().length > 0;
      checks.push({ name: 'clean-working-tree', pass: !dirty, detail: dirty ? 'uncommitted changes present' : 'clean' });
    } catch {
      checks.push({ name: 'git-status', pass: false, detail: 'git not available' });
    }

    // Check Dockerfile or deployment manifest exists
    const deployFiles = ['Dockerfile', 'docker-compose.yml', 'app.yaml', 'cloudbuild.yaml', 'k8s'];
    const foundDeployFiles = deployFiles.filter((f) => fs.existsSync(path.join(projectDir, f)));
    checks.push({
      name: 'deployment-manifest',
      pass: foundDeployFiles.length > 0,
      detail: foundDeployFiles.length > 0 ? `found: ${foundDeployFiles.join(', ')}` : 'no deployment files found',
    });

    const failed = checks.filter((c) => !c.pass);
    if (failed.length > 0) {
      logger.warn(`[deployment] ${failed.length} pre-deploy check(s) failed`, { failed: failed.map((c) => c.name) });
    }

    return {
      domain,
      check: 'pre-deploy',
      total: checks.length,
      passed: checks.filter((c) => c.pass).length,
      failed: failed.length,
      ready: failed.length === 0,
      checks,
    };
  }

  /**
   * Collect deployment metadata (commit, branch, version, environment).
   * @returns {Promise<Object>}
   */
  async function collectDeploymentMetadata() {
    const projectDir = context.projectDir || process.cwd();
    logger.debug('[deployment] collecting deployment metadata');

    const [commit, branch] = await Promise.all([
      getGitCommit(projectDir),
      getGitBranch(projectDir),
    ]);

    let version = 'unknown';
    try {
      const pkg = JSON.parse(fs.readFileSync(path.join(projectDir, 'package.json'), 'utf8'));
      version = pkg.version || 'unknown';
    } catch { /* ok */ }

    const metadata = {
      domain,
      check: 'deployment-metadata',
      commit,
      branch,
      version,
      environment: process.env.NODE_ENV || 'development',
      deploymentTarget: context.target || process.env.DEPLOY_TARGET || 'unset',
      timestamp: new Date().toISOString(),
      buildId: process.env.BUILD_ID || `build-${Date.now()}`,
    };

    logger.info('[deployment] metadata collected', { commit: commit.slice(0, 8), branch, version });
    return metadata;
  }

  /**
   * Verify deployment health after a deployment by checking endpoints.
   * @returns {Promise<Object>}
   */
  async function verifyDeploymentHealth() {
    const http = require('http');
    const https = require('https');
    const baseUrl = context.deployedUrl || process.env.DEPLOYED_URL || 'http://localhost:3000';
    const healthPath = context.healthPath || '/health';
    const fullUrl = `${baseUrl}${healthPath}`;

    logger.debug(`[deployment] verifying deployment at ${fullUrl}`);

    return new Promise((resolve) => {
      const lib = fullUrl.startsWith('https') ? https : http;
      const req = lib.get(fullUrl, { timeout: 10000 }, (res) => {
        let body = '';
        res.on('data', (c) => { body += c; });
        res.on('end', () => {
          const healthy = res.statusCode >= 200 && res.statusCode < 400;
          logger.info(`[deployment] post-deploy health: ${res.statusCode}`, { url: fullUrl });
          resolve({
            domain,
            check: 'post-deploy-health',
            url: fullUrl,
            status: res.statusCode,
            healthy,
            body: body.slice(0, 200),
            timestamp: new Date().toISOString(),
          });
        });
      });
      req.on('error', (err) => {
        resolve({ domain, check: 'post-deploy-health', url: fullUrl, healthy: false, error: err.message });
      });
      req.on('timeout', () => {
        req.destroy();
        resolve({ domain, check: 'post-deploy-health', url: fullUrl, healthy: false, error: 'timeout' });
      });
    });
  }

  runPreDeployChecks.workerName = 'runPreDeployChecks';
  runPreDeployChecks.domain = domain;
  runPreDeployChecks.priority = priority;

  collectDeploymentMetadata.workerName = 'collectDeploymentMetadata';
  collectDeploymentMetadata.domain = domain;
  collectDeploymentMetadata.priority = priority;

  verifyDeploymentHealth.workerName = 'verifyDeploymentHealth';
  verifyDeploymentHealth.domain = domain;
  verifyDeploymentHealth.priority = priority;

  return [runPreDeployChecks, collectDeploymentMetadata, verifyDeploymentHealth];
}

module.exports = { domain, description, priority, getWork };
