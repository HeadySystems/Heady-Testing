'use strict';

/**
 * @fileoverview Dynamic bee creation factory for HeadyStack.
 * Creates, manages, and dissolves bee workers at runtime.
 * @module bees/bee-factory
 */

const logger = require('../utils/logger');

/** @type {Map<string, Object>} Registry of dynamically created bees */
const _dynamicRegistry = new Map();

/** @type {Map<string, Object>} Registry of ephemeral single-purpose bees */
const _ephemeralBees = new Map();

/**
 * Built-in bee templates.
 * @type {Object.<string, Function>}
 */
const TEMPLATES = {
  'health-check': (config) => ({
    domain: config.domain,
    description: config.description || `Health check for ${config.domain}`,
    priority: config.priority || 0.9,
    workers: config.workers || [
      {
        name: 'checkEndpoint',
        fn: async (ctx) => {
          const http = require('http');
          const https = require('https');
          const url = ctx.endpoint || config.endpoint || 'http://localhost:3000/health';
          return new Promise((resolve) => {
            const lib = url.startsWith('https') ? https : http;
            const req = lib.get(url, { timeout: 5000 }, (res) => {
              resolve({ status: res.statusCode, healthy: res.statusCode < 400, url });
            });
            req.on('error', (err) => resolve({ healthy: false, url, error: err.message }));
            req.on('timeout', () => { req.destroy(); resolve({ healthy: false, url, error: 'timeout' }); });
          });
        },
      },
    ],
  }),

  monitor: (config) => ({
    domain: config.domain,
    description: config.description || `Monitor for ${config.domain}`,
    priority: config.priority || 0.8,
    workers: config.workers || [
      {
        name: 'collectMetrics',
        fn: async (ctx) => {
          const os = require('os');
          return {
            domain: config.domain,
            timestamp: new Date().toISOString(),
            uptime: os.uptime(),
            loadAvg: os.loadavg(),
            freeMemMB: Math.round(os.freemem() / 1024 / 1024),
            totalMemMB: Math.round(os.totalmem() / 1024 / 1024),
            cpus: os.cpus().length,
          };
        },
      },
    ],
  }),

  processor: (config) => ({
    domain: config.domain,
    description: config.description || `Data processor for ${config.domain}`,
    priority: config.priority || 0.7,
    workers: config.workers || [
      {
        name: 'processQueue',
        fn: async (ctx) => {
          const items = ctx.queue || [];
          const results = [];
          for (const item of items) {
            results.push({
              id: item.id || Math.random().toString(36).slice(2),
              status: 'processed',
              timestamp: new Date().toISOString(),
              data: item,
            });
          }
          return { processed: results.length, results };
        },
      },
    ],
  }),

  scanner: (config) => ({
    domain: config.domain,
    description: config.description || `Scanner for ${config.domain}`,
    priority: config.priority || 0.75,
    workers: config.workers || [
      {
        name: 'scan',
        fn: async (ctx) => {
          const fs = require('fs');
          const path = require('path');
          const target = ctx.target || config.scanTarget || process.cwd();
          const findings = [];
          try {
            const entries = fs.readdirSync(target, { withFileTypes: true });
            for (const entry of entries) {
              findings.push({
                name: entry.name,
                type: entry.isDirectory() ? 'dir' : 'file',
                path: path.join(target, entry.name),
              });
            }
          } catch (err) {
            logger.warn(`[bee-factory:scanner] scan error for ${target}: ${err.message}`);
          }
          return { scanned: target, count: findings.length, findings };
        },
      },
    ],
  }),
};

/**
 * Validates a bee configuration object.
 * @param {string} domain
 * @param {Object} config
 * @throws {Error} if required fields are missing or invalid
 */
function _validateConfig(domain, config) {
  if (!domain || typeof domain !== 'string') throw new Error('domain must be a non-empty string');
  if (!config || typeof config !== 'object') throw new Error('config must be an object');
}

/**
 * Builds a getWork function from a list of worker descriptors.
 * @param {Array<{name: string, fn: Function}>} workers
 * @param {string} domain
 * @param {number} priority
 * @returns {Function}
 */
function _buildGetWork(workers, domain, priority) {
  return (context = {}) => {
    return workers.map(({ name, fn }) => {
      const work = async () => {
        logger.debug(`[bee-factory] executing worker ${domain}:${name}`);
        const result = await fn(context);
        logger.debug(`[bee-factory] worker ${domain}:${name} complete`);
        return result;
      };
      work.workerName = name;
      work.domain = domain;
      work.priority = priority;
      return work;
    });
  };
}

/**
 * Creates a bee dynamically at runtime and registers it.
 * @param {string} domain - Unique domain identifier
 * @param {Object} config - Bee configuration
 * @param {string} config.description - Human-readable description
 * @param {number} [config.priority=0.8] - Execution priority 0-1
 * @param {Array<{name: string, fn: Function}>} [config.workers=[]] - Worker descriptors
 * @param {boolean} [config.persist=false] - Whether to persist across restarts (no-op for runtime)
 * @returns {Object} The created bee module
 */
function createBee(domain, config) {
  _validateConfig(domain, config);

  if (_dynamicRegistry.has(domain)) {
    logger.warn(`[bee-factory] bee domain '${domain}' already exists — overwriting`);
  }

  const priority = typeof config.priority === 'number' ? config.priority : 0.8;
  const workers = Array.isArray(config.workers) ? config.workers : [];
  const description = config.description || `Dynamic bee: ${domain}`;

  const bee = {
    domain,
    description,
    priority,
    persist: config.persist === true,
    createdAt: new Date().toISOString(),
    isDynamic: true,
    getWork: _buildGetWork(workers, domain, priority),
    _workers: workers,
  };

  _dynamicRegistry.set(domain, bee);
  logger.info(`[bee-factory] created bee '${domain}'`, { priority, workers: workers.length });
  return bee;
}

/**
 * Spawns an ephemeral single-purpose bee.
 * @param {string} name - Unique name for this ephemeral bee
 * @param {Function} work - Async work function to execute
 * @param {number} [priority=0.8] - Execution priority
 * @returns {Object} The spawned ephemeral bee
 */
function spawnBee(name, work, priority = 0.8) {
  if (typeof name !== 'string' || !name) throw new Error('name must be a non-empty string');
  if (typeof work !== 'function') throw new Error('work must be a function');

  const id = `ephemeral:${name}:${Date.now()}`;
  const bee = {
    id,
    name,
    priority,
    ephemeral: true,
    createdAt: new Date().toISOString(),
    execute: async (context = {}) => {
      logger.debug(`[bee-factory] spawned bee '${name}' executing`);
      const result = await work(context);
      _ephemeralBees.delete(id);
      logger.debug(`[bee-factory] spawned bee '${name}' dissolved after execution`);
      return result;
    },
  };

  _ephemeralBees.set(id, bee);
  logger.info(`[bee-factory] spawned ephemeral bee '${name}'`, { id, priority });
  return bee;
}

/**
 * Adds a work unit to an existing bee domain, or creates a new one-worker bee.
 * @param {string} domain - Target domain
 * @param {string} name - Worker name
 * @param {Function} fn - Async worker function
 * @returns {Object} The updated or created bee
 */
function createWorkUnit(domain, name, fn) {
  if (typeof name !== 'string' || !name) throw new Error('name must be a non-empty string');
  if (typeof fn !== 'function') throw new Error('fn must be a function');

  if (_dynamicRegistry.has(domain)) {
    const bee = _dynamicRegistry.get(domain);
    bee._workers.push({ name, fn });
    bee.getWork = _buildGetWork(bee._workers, domain, bee.priority);
    logger.info(`[bee-factory] added work unit '${name}' to bee '${domain}'`);
    return bee;
  }

  return createBee(domain, {
    description: `Auto-created domain for work unit '${name}'`,
    priority: 0.8,
    workers: [{ name, fn }],
  });
}

/**
 * Creates a bee from a built-in template.
 * @param {'health-check'|'monitor'|'processor'|'scanner'} template - Template name
 * @param {Object} config - Configuration merged into template
 * @returns {Object} The created bee module
 * @throws {Error} if template not found or domain missing
 */
function createFromTemplate(template, config) {
  if (!TEMPLATES[template]) {
    throw new Error(`Unknown template '${template}'. Available: ${Object.keys(TEMPLATES).join(', ')}`);
  }
  if (!config || !config.domain) throw new Error('config.domain is required');

  const merged = TEMPLATES[template](config);
  return createBee(merged.domain, {
    description: merged.description,
    priority: merged.priority,
    workers: merged.workers,
    persist: config.persist,
  });
}

/**
 * Returns all dynamically created bees.
 * @returns {Array<Object>}
 */
function listDynamicBees() {
  return Array.from(_dynamicRegistry.values()).map((bee) => ({
    domain: bee.domain,
    description: bee.description,
    priority: bee.priority,
    persist: bee.persist,
    createdAt: bee.createdAt,
    workerCount: bee._workers.length,
    isDynamic: true,
  }));
}

/**
 * Removes a dynamic bee from the registry.
 * @param {string} domain - Domain to dissolve
 * @returns {boolean} true if removed, false if not found
 */
function dissolveBee(domain) {
  if (!_dynamicRegistry.has(domain)) {
    logger.warn(`[bee-factory] dissolveBee: domain '${domain}' not found`);
    return false;
  }
  _dynamicRegistry.delete(domain);
  logger.info(`[bee-factory] dissolved bee '${domain}'`);
  return true;
}

module.exports = {
  createBee,
  spawnBee,
  createWorkUnit,
  createFromTemplate,
  listDynamicBees,
  dissolveBee,
  _dynamicRegistry,
  _ephemeralBees,
};
