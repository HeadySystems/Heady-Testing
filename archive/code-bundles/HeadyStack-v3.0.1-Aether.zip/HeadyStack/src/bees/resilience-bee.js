'use strict';

/**
 * @fileoverview Resilience bee — monitors circuit breakers, retry policies, and failure patterns.
 * @module bees/resilience-bee
 */

const logger = require('../utils/logger');

const domain = 'resilience';
const description = 'Monitors circuit breakers, retry budgets, failure rates, and recovery patterns';
const priority = 0.89;

/**
 * Circuit breaker states.
 */
const STATES = { CLOSED: 'closed', OPEN: 'open', HALF_OPEN: 'half-open' };

/** In-memory circuit breaker registry */
const _breakers = new Map();

/**
 * Gets or creates a circuit breaker instance.
 * @param {string} name
 * @param {Object} [opts]
 * @returns {Object}
 */
function getBreaker(name, opts = {}) {
  if (!_breakers.has(name)) {
    _breakers.set(name, {
      name,
      state: STATES.CLOSED,
      failureCount: 0,
      successCount: 0,
      totalCalls: 0,
      lastFailure: null,
      lastSuccess: null,
      openedAt: null,
      threshold: opts.threshold || 5,
      resetTimeoutMs: opts.resetTimeoutMs || 30000,
      halfOpenProbeMs: opts.halfOpenProbeMs || 5000,
    });
  }
  return _breakers.get(name);
}

/**
 * Records a success for a breaker.
 * @param {string} name
 */
function recordSuccess(name) {
  const b = getBreaker(name);
  b.successCount++;
  b.totalCalls++;
  b.lastSuccess = Date.now();
  if (b.state === STATES.HALF_OPEN) {
    b.state = STATES.CLOSED;
    b.failureCount = 0;
    logger.info(`[resilience] circuit '${name}' closed after recovery`);
  }
}

/**
 * Records a failure for a breaker.
 * @param {string} name
 */
function recordFailure(name) {
  const b = getBreaker(name);
  b.failureCount++;
  b.totalCalls++;
  b.lastFailure = Date.now();
  if (b.state === STATES.CLOSED && b.failureCount >= b.threshold) {
    b.state = STATES.OPEN;
    b.openedAt = Date.now();
    logger.warn(`[resilience] circuit '${name}' OPENED after ${b.failureCount} failures`);
  }
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Survey all circuit breakers and report their states.
   * @returns {Promise<Object>}
   */
  async function surveyCircuitBreakers() {
    logger.debug('[resilience] surveying circuit breakers');
    const now = Date.now();

    // Auto-transition OPEN -> HALF_OPEN after reset timeout
    for (const b of _breakers.values()) {
      if (b.state === STATES.OPEN && b.openedAt && (now - b.openedAt) >= b.resetTimeoutMs) {
        b.state = STATES.HALF_OPEN;
        logger.info(`[resilience] circuit '${b.name}' transitioning to half-open`);
      }
    }

    const breakers = Array.from(_breakers.values());
    const open = breakers.filter((b) => b.state === STATES.OPEN);
    const halfOpen = breakers.filter((b) => b.state === STATES.HALF_OPEN);
    const closed = breakers.filter((b) => b.state === STATES.CLOSED);

    if (open.length > 0) {
      logger.warn(`[resilience] ${open.length} circuit(s) OPEN`, { circuits: open.map((b) => b.name) });
    }

    return {
      domain,
      check: 'circuit-breakers',
      total: breakers.length,
      open: open.length,
      halfOpen: halfOpen.length,
      closed: closed.length,
      healthy: open.length === 0,
      breakers: breakers.map((b) => ({
        name: b.name,
        state: b.state,
        failureCount: b.failureCount,
        successCount: b.successCount,
        totalCalls: b.totalCalls,
        failureRate: b.totalCalls > 0 ? Math.round((b.failureCount / b.totalCalls) * 100) : 0,
        openDurationMs: b.openedAt ? now - b.openedAt : null,
      })),
    };
  }

  /**
   * Analyze failure patterns and generate resilience recommendations.
   * @returns {Promise<Object>}
   */
  async function analyzeFailurePatterns() {
    logger.debug('[resilience] analyzing failure patterns');
    const breakers = Array.from(_breakers.values());

    const recommendations = [];
    const hotCircuits = breakers.filter((b) => {
      const rate = b.totalCalls > 0 ? b.failureCount / b.totalCalls : 0;
      return rate > 0.1; // >10% failure rate
    });

    for (const b of hotCircuits) {
      const rate = Math.round((b.failureCount / b.totalCalls) * 100);
      recommendations.push({
        circuit: b.name,
        failureRate: rate,
        recommendation: rate > 50
          ? 'Critical: investigate and fix dependency, consider disabling feature flag'
          : 'Warning: increase retry budget or add exponential backoff',
        currentState: b.state,
      });
    }

    // Compute aggregate failure rate
    const totalCalls = breakers.reduce((s, b) => s + b.totalCalls, 0);
    const totalFailures = breakers.reduce((s, b) => s + b.failureCount, 0);
    const overallFailureRate = totalCalls > 0 ? (totalFailures / totalCalls) * 100 : 0;

    return {
      domain,
      check: 'failure-patterns',
      overallFailureRate: Math.round(overallFailureRate * 10) / 10,
      hotCircuits: hotCircuits.length,
      recommendations,
      systemHealthy: overallFailureRate < 5,
    };
  }

  /**
   * Test resilience by simulating probes against circuit breakers.
   * @returns {Promise<Object>}
   */
  async function probeResilienceTargets() {
    const targets = context.probeTargets || [];
    const results = [];

    for (const target of targets) {
      const breaker = getBreaker(target.name);
      if (breaker.state === STATES.OPEN) {
        results.push({ name: target.name, probed: false, reason: 'circuit open' });
        continue;
      }

      try {
        if (typeof target.fn === 'function') {
          await target.fn();
          recordSuccess(target.name);
          results.push({ name: target.name, probed: true, success: true });
        } else {
          results.push({ name: target.name, probed: false, reason: 'no probe function' });
        }
      } catch (err) {
        recordFailure(target.name);
        results.push({ name: target.name, probed: true, success: false, error: err.message });
      }
    }

    return {
      domain,
      check: 'resilience-probes',
      total: targets.length,
      probed: results.filter((r) => r.probed).length,
      passed: results.filter((r) => r.success).length,
      results,
    };
  }

  surveyCircuitBreakers.workerName = 'surveyCircuitBreakers';
  surveyCircuitBreakers.domain = domain;
  surveyCircuitBreakers.priority = priority;

  analyzeFailurePatterns.workerName = 'analyzeFailurePatterns';
  analyzeFailurePatterns.domain = domain;
  analyzeFailurePatterns.priority = priority;

  probeResilienceTargets.workerName = 'probeResilienceTargets';
  probeResilienceTargets.domain = domain;
  probeResilienceTargets.priority = priority;

  return [surveyCircuitBreakers, analyzeFailurePatterns, probeResilienceTargets];
}

module.exports = { domain, description, priority, getWork, getBreaker, recordSuccess, recordFailure };
