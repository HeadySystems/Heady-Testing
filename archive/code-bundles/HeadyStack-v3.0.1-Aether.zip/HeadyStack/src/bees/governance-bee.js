'use strict';

/**
 * @fileoverview Governance bee — enforces policies, coding standards, and compliance rules.
 * @module bees/governance-bee
 */

const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

const domain = 'governance';
const description = 'Enforces policies, coding standards, license compliance, and governance rules';
const priority = 0.85;

/** Allowed SPDX license identifiers */
const ALLOWED_LICENSES = new Set([
  'MIT', 'ISC', 'Apache-2.0', 'BSD-2-Clause', 'BSD-3-Clause',
  '0BSD', 'CC0-1.0', 'Unlicense', 'LGPL-2.1', 'MPL-2.0',
]);

/** Disallowed licenses that may require commercial licensing */
const RESTRICTED_LICENSES = new Set([
  'GPL-2.0', 'GPL-3.0', 'AGPL-3.0', 'SSPL-1.0', 'BUSL-1.1',
  'Commons Clause', 'CC-BY-NC', 'Proprietary',
]);

/**
 * Reads and parses package.json safely.
 * @param {string} dir
 * @returns {Object|null}
 */
function readPackageJson(dir) {
  try {
    const raw = fs.readFileSync(path.join(dir, 'package.json'), 'utf8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Scan dependency licenses for compliance.
   * @returns {Promise<Object>}
   */
  async function auditLicenses() {
    const projectDir = context.projectDir || process.cwd();
    logger.debug(`[governance] auditing licenses in ${projectDir}`);

    const pkg = readPackageJson(projectDir);
    if (!pkg) {
      return { domain, check: 'licenses', skipped: true, reason: 'no package.json' };
    }

    const nodeModules = path.join(projectDir, 'node_modules');
    if (!fs.existsSync(nodeModules)) {
      return { domain, check: 'licenses', skipped: true, reason: 'no node_modules directory' };
    }

    const allDeps = {
      ...pkg.dependencies,
      ...pkg.devDependencies,
    };

    const results = [];
    const restricted = [];
    const unknown = [];

    for (const dep of Object.keys(allDeps)) {
      const depPkg = readPackageJson(path.join(nodeModules, dep));
      if (!depPkg) continue;

      const license = depPkg.license || 'UNKNOWN';
      const status = RESTRICTED_LICENSES.has(license) ? 'restricted'
        : ALLOWED_LICENSES.has(license) ? 'allowed'
          : 'unknown';

      results.push({ dep, version: depPkg.version, license, status });
      if (status === 'restricted') restricted.push(dep);
      if (status === 'unknown') unknown.push(dep);
    }

    if (restricted.length > 0) {
      logger.warn(`[governance] restricted licenses found`, { restricted });
    }

    return {
      domain,
      check: 'licenses',
      totalDeps: results.length,
      restricted: restricted.length,
      unknown: unknown.length,
      allowed: results.filter((r) => r.status === 'allowed').length,
      compliant: restricted.length === 0,
      restrictedDeps: restricted,
      details: results,
    };
  }

  /**
   * Enforce code style policies: no console.log, require 'use strict', etc.
   * @returns {Promise<Object>}
   */
  async function enforceCodePolicies() {
    const srcDir = context.srcDir || path.join(process.cwd(), 'src');
    logger.debug(`[governance] enforcing code policies in ${srcDir}`);

    if (!fs.existsSync(srcDir)) {
      return { domain, check: 'code-policies', skipped: true, reason: `srcDir not found: ${srcDir}` };
    }

    const violations = [];

    function scanDir(dir) {
      let entries;
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const entry of entries) {
        if (['node_modules', '.git', 'dist', 'build'].includes(entry.name)) continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          scanDir(full);
        } else if (entry.name.endsWith('.js')) {
          let src;
          try { src = fs.readFileSync(full, 'utf8'); } catch { continue; }

          const lines = src.split('\n');

          // Policy: 'use strict' must be present
          if (!src.includes("'use strict'") && !src.includes('"use strict"')) {
            violations.push({ file: full, rule: 'missing-use-strict', line: 1 });
          }

          // Policy: no raw console.log (use logger)
          lines.forEach((line, i) => {
            if (/console\.(log|warn|error|info|debug)/.test(line) && !line.trim().startsWith('//')) {
              violations.push({ file: full, rule: 'no-console', line: i + 1, snippet: line.trim().slice(0, 60) });
            }
          });

          // Policy: no TODO/FIXME left in production code
          lines.forEach((line, i) => {
            if (/\b(TODO|FIXME|HACK|XXX)\b/.test(line)) {
              violations.push({ file: full, rule: 'no-todo-comments', line: i + 1, snippet: line.trim().slice(0, 60) });
            }
          });
        }
      }
    }

    scanDir(srcDir);

    if (violations.length > 0) {
      logger.warn(`[governance] ${violations.length} code policy violation(s)`);
    }

    return {
      domain,
      check: 'code-policies',
      violationCount: violations.length,
      compliant: violations.length === 0,
      violations: violations.slice(0, 100),
    };
  }

  /**
   * Validate that required governance artifacts exist (LICENSE, CONTRIBUTING, etc.).
   * @returns {Promise<Object>}
   */
  async function validateGovernanceArtifacts() {
    const projectDir = context.projectDir || process.cwd();
    const required = context.requiredFiles || ['LICENSE', 'README.md', 'package.json'];
    const recommended = context.recommendedFiles || ['CONTRIBUTING.md', 'SECURITY.md', '.gitignore', '.eslintrc.js'];

    const missing = required.filter((f) => !fs.existsSync(path.join(projectDir, f)));
    const missingRecommended = recommended.filter((f) => !fs.existsSync(path.join(projectDir, f)));

    if (missing.length > 0) {
      logger.warn(`[governance] missing required artifacts: ${missing.join(', ')}`);
    }

    return {
      domain,
      check: 'governance-artifacts',
      compliant: missing.length === 0,
      missingRequired: missing,
      missingRecommended,
      present: required.filter((f) => !missing.includes(f)),
    };
  }

  auditLicenses.workerName = 'auditLicenses';
  auditLicenses.domain = domain;
  auditLicenses.priority = priority;

  enforceCodePolicies.workerName = 'enforceCodePolicies';
  enforceCodePolicies.domain = domain;
  enforceCodePolicies.priority = priority;

  validateGovernanceArtifacts.workerName = 'validateGovernanceArtifacts';
  validateGovernanceArtifacts.domain = domain;
  validateGovernanceArtifacts.priority = priority;

  return [auditLicenses, enforceCodePolicies, validateGovernanceArtifacts];
}

module.exports = { domain, description, priority, getWork };
