'use strict';

/**
 * @fileoverview Health bee — checks system health endpoints and service availability.
 * @module bees/health-bee
 */

const http = require('http');
const https = require('https');
const os = require('os');
const logger = require('../utils/logger');

const domain = 'health';
const description = 'Monitors system health endpoints, process vitals, and service availability';
const priority = 0.95;

/**
 * Performs an HTTP/HTTPS GET to a health endpoint.
 * @param {string} url
 * @param {number} [timeoutMs=5000]
 * @returns {Promise<{url: string, status: number, healthy: boolean, latencyMs: number, error?: string}>}
 */
async function checkEndpoint(url, timeoutMs = 5000) {
  const start = Date.now();
  return new Promise((resolve) => {
    const lib = url.startsWith('https') ? https : http;
    const req = lib.get(url, { timeout: timeoutMs }, (res) => {
      let body = '';
      res.on('data', (chunk) => { body += chunk; });
      res.on('end', () => {
        resolve({
          url,
          status: res.statusCode,
          healthy: res.statusCode >= 200 && res.statusCode < 400,
          latencyMs: Date.now() - start,
          body: body.slice(0, 200),
        });
      });
    });
    req.on('error', (err) => resolve({ url, status: 0, healthy: false, latencyMs: Date.now() - start, error: err.message }));
    req.on('timeout', () => { req.destroy(); resolve({ url, status: 0, healthy: false, latencyMs: timeoutMs, error: 'timeout' }); });
  });
}

/**
 * Returns the work units for this bee.
 * @param {Object} [context={}]
 * @param {string[]} [context.endpoints] - Override default endpoints to check
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Check all configured health endpoints.
   * @returns {Promise<Object>}
   */
  async function checkHealthEndpoints() {
    const endpoints = context.endpoints || [
      'http://localhost:3000/health',
      'http://localhost:3001/health',
      'http://localhost:8080/health',
    ];

    logger.debug(`[health] checking ${endpoints.length} endpoints`);
    const results = await Promise.allSettled(endpoints.map((url) => checkEndpoint(url)));

    const checks = results.map((r, i) =>
      r.status === 'fulfilled' ? r.value : { url: endpoints[i], healthy: false, error: r.reason?.message }
    );

    const healthy = checks.filter((c) => c.healthy).length;
    const unhealthy = checks.filter((c) => !c.healthy).length;

    if (unhealthy > 0) {
      logger.warn(`[health] ${unhealthy} endpoint(s) unhealthy`, { checks });
    }

    return { domain, check: 'endpoints', healthy, unhealthy, total: checks.length, checks };
  }

  /**
   * Collect process and OS vitals.
   * @returns {Promise<Object>}
   */
  async function collectProcessVitals() {
    const mem = process.memoryUsage();
    const cpuUsage = process.cpuUsage();

    const vitals = {
      domain,
      check: 'process-vitals',
      pid: process.pid,
      uptime: process.uptime(),
      nodeVersion: process.version,
      platform: process.platform,
      memory: {
        rss: Math.round(mem.rss / 1024 / 1024),
        heapUsed: Math.round(mem.heapUsed / 1024 / 1024),
        heapTotal: Math.round(mem.heapTotal / 1024 / 1024),
        external: Math.round(mem.external / 1024 / 1024),
        unit: 'MB',
      },
      cpu: {
        userMs: Math.round(cpuUsage.user / 1000),
        systemMs: Math.round(cpuUsage.system / 1000),
      },
      os: {
        hostname: os.hostname(),
        uptime: os.uptime(),
        loadAvg: os.loadavg(),
        freeMem: Math.round(os.freemem() / 1024 / 1024),
        totalMem: Math.round(os.totalmem() / 1024 / 1024),
        cpus: os.cpus().length,
      },
      timestamp: new Date().toISOString(),
    };

    const memPct = (mem.heapUsed / mem.heapTotal) * 100;
    if (memPct > 90) {
      logger.warn(`[health] high heap usage: ${memPct.toFixed(1)}%`);
    }

    return vitals;
  }

  /**
   * Verify critical environment variables are present.
   * @returns {Promise<Object>}
   */
  async function verifyEnvironment() {
    const required = (context.requiredEnv || [
      'NODE_ENV',
    ]);
    const optional = (context.optionalEnv || [
      'PORT', 'LOG_LEVEL', 'HEADY_API_KEY',
    ]);

    const missing = required.filter((k) => !process.env[k]);
    const present = required.filter((k) => !!process.env[k]);
    const optPresent = optional.filter((k) => !!process.env[k]);

    if (missing.length > 0) {
      logger.warn(`[health] missing required env vars: ${missing.join(', ')}`);
    }

    return {
      domain,
      check: 'environment',
      healthy: missing.length === 0,
      required: { total: required.length, present: present.length, missing },
      optional: { total: optional.length, present: optPresent.length },
      nodeEnv: process.env.NODE_ENV || 'unset',
    };
  }

  const checkHealthEndpointsWork = checkHealthEndpoints;
  const collectProcessVitalsWork = collectProcessVitals;
  const verifyEnvironmentWork = verifyEnvironment;

  checkHealthEndpointsWork.workerName = 'checkHealthEndpoints';
  checkHealthEndpointsWork.domain = domain;
  checkHealthEndpointsWork.priority = priority;

  collectProcessVitalsWork.workerName = 'collectProcessVitals';
  collectProcessVitalsWork.domain = domain;
  collectProcessVitalsWork.priority = priority;

  verifyEnvironmentWork.workerName = 'verifyEnvironment';
  verifyEnvironmentWork.domain = domain;
  verifyEnvironmentWork.priority = priority;

  return [checkHealthEndpointsWork, collectProcessVitalsWork, verifyEnvironmentWork];
}

module.exports = { domain, description, priority, getWork };
