'use strict';

/**
 * @fileoverview MCP bee — orchestrates MCP tool execution and server health.
 * @module bees/mcp-bee
 */

const http = require('http');
const logger = require('../utils/logger');

const domain = 'mcp';
const description = 'Orchestrates MCP tool execution, monitors server health, tracks tool usage';
const priority = 0.88;

/**
 * Makes an HTTP POST request to the MCP server.
 * @param {string} url
 * @param {Object} body
 * @param {Object} [headers={}]
 * @returns {Promise<{status: number, body: string}>}
 */
async function httpPost(url, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const parsed = new URL(url);
    const options = {
      hostname: parsed.hostname,
      port: parsed.port || 80,
      path: parsed.pathname + parsed.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        ...headers,
      },
      timeout: 15000,
    };
    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (c) => { data += c; });
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('request timeout')); });
    req.write(payload);
    req.end();
  });
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  const mcpBase = context.mcpBase || process.env.MCP_SERVER_URL || 'http://localhost:3001';
  const bearerToken = context.bearerToken || process.env.MCP_BEARER_TOKEN;

  const authHeaders = bearerToken ? { Authorization: `Bearer ${bearerToken}` } : {};

  /**
   * Check MCP server health and list available tools.
   * @returns {Promise<Object>}
   */
  async function checkMcpServerHealth() {
    logger.debug(`[mcp] checking MCP server health at ${mcpBase}`);

    return new Promise((resolve) => {
      const req = http.get(`${mcpBase}/api/mcp/health`, { timeout: 5000 }, (res) => {
        let body = '';
        res.on('data', (c) => { body += c; });
        res.on('end', () => {
          let parsed = {};
          try { parsed = JSON.parse(body); } catch { /* ok */ }
          resolve({
            domain,
            check: 'mcp-health',
            status: res.statusCode,
            healthy: res.statusCode === 200,
            server: parsed,
            url: mcpBase,
          });
        });
      });
      req.on('error', (err) => {
        resolve({ domain, check: 'mcp-health', healthy: false, error: err.message, url: mcpBase });
      });
      req.on('timeout', () => {
        req.destroy();
        resolve({ domain, check: 'mcp-health', healthy: false, error: 'timeout', url: mcpBase });
      });
    });
  }

  /**
   * Discover all available MCP tools by calling the tools/list endpoint.
   * @returns {Promise<Object>}
   */
  async function discoverMcpTools() {
    logger.debug('[mcp] discovering MCP tools');

    try {
      const response = await httpPost(`${mcpBase}/api/mcp/tools`, {
        jsonrpc: '2.0',
        method: 'tools/list',
        id: 1,
        params: {},
      }, authHeaders);

      if (response.status !== 200) {
        return { domain, check: 'tool-discovery', success: false, status: response.status };
      }

      const result = JSON.parse(response.body);
      const tools = result.result?.tools || [];

      logger.info(`[mcp] discovered ${tools.length} tool(s)`);

      return {
        domain,
        check: 'tool-discovery',
        success: true,
        toolCount: tools.length,
        categories: [...new Set(tools.map((t) => t.category))],
        tools: tools.map((t) => ({ name: t.name, category: t.category, description: t.description })),
      };
    } catch (err) {
      return { domain, check: 'tool-discovery', success: false, error: err.message };
    }
  }

  /**
   * Execute a sample MCP tool to verify the execution pipeline.
   * @returns {Promise<Object>}
   */
  async function verifyMcpExecution() {
    const toolName = context.testTool || 'heady_health';
    const toolParams = context.testParams || {};

    logger.debug(`[mcp] verifying MCP execution with tool '${toolName}'`);

    try {
      const response = await httpPost(`${mcpBase}/api/mcp/execute`, {
        jsonrpc: '2.0',
        method: 'tools/call',
        id: 2,
        params: { name: toolName, arguments: toolParams },
      }, authHeaders);

      const success = response.status === 200;
      let result = {};
      try { result = JSON.parse(response.body); } catch { /* ok */ }

      logger.info(`[mcp] execution verification: ${success ? 'passed' : 'failed'}`, { status: response.status });

      return {
        domain,
        check: 'execution-verify',
        success,
        toolName,
        status: response.status,
        result: result.result || result.error,
        latencyMs: 0, // measured externally
      };
    } catch (err) {
      return { domain, check: 'execution-verify', success: false, toolName, error: err.message };
    }
  }

  checkMcpServerHealth.workerName = 'checkMcpServerHealth';
  checkMcpServerHealth.domain = domain;
  checkMcpServerHealth.priority = priority;

  discoverMcpTools.workerName = 'discoverMcpTools';
  discoverMcpTools.domain = domain;
  discoverMcpTools.priority = priority;

  verifyMcpExecution.workerName = 'verifyMcpExecution';
  verifyMcpExecution.domain = domain;
  verifyMcpExecution.priority = priority;

  return [checkMcpServerHealth, discoverMcpTools, verifyMcpExecution];
}

module.exports = { domain, description, priority, getWork };
