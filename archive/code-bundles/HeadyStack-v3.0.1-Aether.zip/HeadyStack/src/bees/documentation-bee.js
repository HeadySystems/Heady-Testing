'use strict';

/**
 * @fileoverview Documentation bee — generates docs from code, maintains API reference.
 * @module bees/documentation-bee
 */

const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
const logger = require('../utils/logger');

const execFileAsync = promisify(execFile);

const domain = 'documentation';
const description = 'Generates documentation from code: JSDoc extraction, README validation, API reference';
const priority = 0.72;

/**
 * Extracts JSDoc comments from a JavaScript file.
 * @param {string} filePath
 * @returns {Array<{file, symbol, description, params, returns}>}
 */
function extractJsDoc(filePath) {
  let content;
  try {
    content = fs.readFileSync(filePath, 'utf8');
  } catch {
    return [];
  }

  const docs = [];
  const docPattern = /\/\*\*\s*([\s\S]*?)\s*\*\/\s*(?:async\s+)?(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=)/g;
  let match;

  while ((match = docPattern.exec(content)) !== null) {
    const rawDoc = match[1];
    const name = match[2] || match[3] || 'anonymous';

    const descLine = rawDoc.match(/@(?!param|returns?|throws?|type|module|fileoverview).*|^[^@].*/);
    const description = rawDoc.split('\n').map((l) => l.replace(/^\s*\*\s?/, '')).find((l) => l.trim() && !l.startsWith('@')) || '';

    const params = [];
    const paramPattern = /@param\s+\{([^}]+)\}\s+\[?(\w+)\]?\s*[-–]?\s*(.*)/g;
    let paramMatch;
    while ((paramMatch = paramPattern.exec(rawDoc)) !== null) {
      params.push({ type: paramMatch[1], name: paramMatch[2], description: paramMatch[3].trim() });
    }

    const returnsMatch = rawDoc.match(/@returns?\s+\{([^}]+)\}\s*(.*)/);
    const returns = returnsMatch ? { type: returnsMatch[1], description: returnsMatch[2].trim() } : null;

    docs.push({ file: filePath, symbol: name, description: description.trim(), params, returns });
  }

  return docs;
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Scan source files and generate a JSDoc inventory.
   * @returns {Promise<Object>}
   */
  async function generateJsDocInventory() {
    const srcDir = context.srcDir || path.join(process.cwd(), 'src');
    logger.debug(`[documentation] generating JSDoc inventory for ${srcDir}`);

    if (!fs.existsSync(srcDir)) {
      return { domain, check: 'jsdoc-inventory', skipped: true, reason: `srcDir not found: ${srcDir}` };
    }

    const allDocs = [];
    const undocumented = [];

    function scanDir(dir) {
      let entries;
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const entry of entries) {
        if (['node_modules', '.git', 'dist', 'build'].includes(entry.name)) continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          scanDir(full);
        } else if (entry.name.endsWith('.js')) {
          const docs = extractJsDoc(full);
          allDocs.push(...docs);
          if (docs.length === 0) {
            undocumented.push(full.replace(srcDir + path.sep, ''));
          }
        }
      }
    }

    scanDir(srcDir);

    logger.info(`[documentation] found ${allDocs.length} documented symbols`);

    return {
      domain,
      check: 'jsdoc-inventory',
      totalSymbols: allDocs.length,
      undocumentedFiles: undocumented.length,
      docs: allDocs.slice(0, 200),
      undocumented,
    };
  }

  /**
   * Validate README.md completeness against a checklist.
   * @returns {Promise<Object>}
   */
  async function validateReadme() {
    const projectDir = context.projectDir || process.cwd();
    const readmePath = path.join(projectDir, 'README.md');

    if (!fs.existsSync(readmePath)) {
      return { domain, check: 'readme', missing: true, score: 0 };
    }

    const content = fs.readFileSync(readmePath, 'utf8');
    const checks = [
      { name: 'title', test: /^#\s+\S+/m, description: 'Has main heading' },
      { name: 'description', test: /^#{1,2}\s+(?:Description|About|Overview)/im, description: 'Has description section' },
      { name: 'installation', test: /^#{1,3}\s+Install/im, description: 'Has installation section' },
      { name: 'usage', test: /^#{1,3}\s+Usage/im, description: 'Has usage section' },
      { name: 'api-docs', test: /^#{1,3}\s+API/im, description: 'Has API section' },
      { name: 'contributing', test: /^#{1,3}\s+Contribut/im, description: 'Has contributing section' },
      { name: 'license', test: /^#{1,3}\s+License/im, description: 'Has license section' },
      { name: 'code-blocks', test: /```/m, description: 'Contains code examples' },
      { name: 'badges', test: /!\[.*?\]\(.*?\)/m, description: 'Contains badges or images' },
      { name: 'length', test: content.length > 500, description: 'README is substantial (>500 chars)' },
    ];

    const results = checks.map((c) => ({
      name: c.name,
      description: c.description,
      pass: typeof c.test === 'boolean' ? c.test : c.test.test(content),
    }));

    const score = Math.round((results.filter((r) => r.pass).length / results.length) * 100);
    const missing = results.filter((r) => !r.pass).map((r) => r.name);

    return {
      domain,
      check: 'readme',
      path: readmePath,
      score,
      totalChecks: results.length,
      passed: results.filter((r) => r.pass).length,
      missing,
      checks: results,
    };
  }

  /**
   * Generate an API endpoint reference from Express route files.
   * @returns {Promise<Object>}
   */
  async function generateApiReference() {
    const srcDir = context.srcDir || path.join(process.cwd(), 'src');
    const endpoints = [];

    const routePattern = /(?:router|app)\.(get|post|put|patch|delete|use)\s*\(\s*['"`]([^'"`]+)['"`]/gi;

    function scanForRoutes(dir) {
      let entries;
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const entry of entries) {
        if (['node_modules', '.git', 'dist'].includes(entry.name)) continue;
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) {
          scanForRoutes(full);
        } else if (entry.name.endsWith('.js')) {
          let src;
          try { src = fs.readFileSync(full, 'utf8'); } catch { continue; }
          let match;
          while ((match = routePattern.exec(src)) !== null) {
            endpoints.push({
              method: match[1].toUpperCase(),
              path: match[2],
              file: full.replace(srcDir + path.sep, ''),
            });
          }
        }
      }
    }

    scanForRoutes(srcDir);

    const grouped = endpoints.reduce((acc, ep) => {
      const key = ep.file;
      if (!acc[key]) acc[key] = [];
      acc[key].push({ method: ep.method, path: ep.path });
      return acc;
    }, {});

    return {
      domain,
      check: 'api-reference',
      totalEndpoints: endpoints.length,
      fileCount: Object.keys(grouped).length,
      endpoints: grouped,
    };
  }

  generateJsDocInventory.workerName = 'generateJsDocInventory';
  generateJsDocInventory.domain = domain;
  generateJsDocInventory.priority = priority;

  validateReadme.workerName = 'validateReadme';
  validateReadme.domain = domain;
  validateReadme.priority = priority;

  generateApiReference.workerName = 'generateApiReference';
  generateApiReference.domain = domain;
  generateApiReference.priority = priority;

  return [generateJsDocInventory, validateReadme, generateApiReference];
}

module.exports = { domain, description, priority, getWork };
