'use strict';

/**
 * @fileoverview Orchestration bee — manages agent coordination, task routing, and swarm health.
 * @module bees/orchestration-bee
 */

const logger = require('../utils/logger');

const domain = 'orchestration';
const description = 'Manages agent coordination, task queue routing, priority scheduling, and swarm health';
const priority = 0.86;

/** In-memory task registry */
const _taskRegistry = new Map();
/** In-memory agent registry */
const _agentRegistry = new Map();

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Survey all registered agents and report their status.
   * @returns {Promise<Object>}
   */
  async function surveyAgentStatus() {
    logger.debug('[orchestration] surveying agent status');

    const agents = Array.from(_agentRegistry.values());
    const now = Date.now();

    // Mark stale agents (no heartbeat in 60s)
    const staleThreshold = context.staleThresholdMs || 60000;
    const active = agents.filter((a) => now - a.lastSeen <= staleThreshold);
    const stale = agents.filter((a) => now - a.lastSeen > staleThreshold);

    if (stale.length > 0) {
      logger.warn(`[orchestration] ${stale.length} stale agent(s)`, { agents: stale.map((a) => a.id) });
    }

    return {
      domain,
      check: 'agent-status',
      totalAgents: agents.length,
      active: active.length,
      stale: stale.length,
      agents: agents.map((a) => ({
        id: a.id,
        type: a.type,
        lastSeen: new Date(a.lastSeen).toISOString(),
        staleSince: now - a.lastSeen > staleThreshold ? `${Math.round((now - a.lastSeen) / 1000)}s ago` : null,
        taskCount: a.taskCount || 0,
        status: now - a.lastSeen <= staleThreshold ? 'active' : 'stale',
      })),
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Balance work across registered agents using round-robin with priority weighting.
   * @returns {Promise<Object>}
   */
  async function balanceWorkload() {
    logger.debug('[orchestration] balancing workload');

    const pendingTasks = Array.from(_taskRegistry.values()).filter((t) => t.status === 'pending');
    const agents = Array.from(_agentRegistry.values()).filter((a) => a.available !== false);

    if (pendingTasks.length === 0) {
      return { domain, check: 'workload-balance', pendingTasks: 0, assigned: 0 };
    }

    if (agents.length === 0) {
      logger.warn(`[orchestration] ${pendingTasks.length} pending tasks but no available agents`);
      return { domain, check: 'workload-balance', pendingTasks: pendingTasks.length, assigned: 0, warning: 'no available agents' };
    }

    // Sort tasks by priority descending
    const sorted = [...pendingTasks].sort((a, b) => (b.priority || 0) - (a.priority || 0));
    const assignments = [];

    sorted.forEach((task, idx) => {
      const agent = agents[idx % agents.length];
      assignments.push({ taskId: task.id, agentId: agent.id, priority: task.priority });
      task.status = 'assigned';
      task.assignedAgent = agent.id;
      task.assignedAt = new Date().toISOString();
    });

    logger.info(`[orchestration] assigned ${assignments.length} task(s) across ${agents.length} agent(s)`);

    return {
      domain,
      check: 'workload-balance',
      pendingTasks: pendingTasks.length,
      assigned: assignments.length,
      agents: agents.length,
      assignments,
    };
  }

  /**
   * Check for deadlocked or timed-out tasks and release them.
   * @returns {Promise<Object>}
   */
  async function detectAndResolveDeadlocks() {
    const taskTimeoutMs = context.taskTimeoutMs || 300000; // 5 min default
    const now = Date.now();
    const stuck = [];
    const released = [];

    for (const [id, task] of _taskRegistry) {
      if (task.status === 'assigned' && task.assignedAt) {
        const age = now - new Date(task.assignedAt).getTime();
        if (age > taskTimeoutMs) {
          stuck.push({ id, ageMs: age, agentId: task.assignedAgent });
          // Release back to pending
          task.status = 'pending';
          task.assignedAgent = null;
          task.assignedAt = null;
          task.retries = (task.retries || 0) + 1;
          released.push(id);
        }
      }
    }

    if (stuck.length > 0) {
      logger.warn(`[orchestration] released ${stuck.length} stuck task(s)`, { taskIds: stuck.map((s) => s.id) });
    }

    // Check for tasks with too many retries
    const exhausted = Array.from(_taskRegistry.values()).filter((t) => (t.retries || 0) >= 3);
    for (const t of exhausted) {
      t.status = 'failed';
      logger.error(`[orchestration] task ${t.id} exhausted retries — marked failed`);
    }

    return {
      domain,
      check: 'deadlock-detection',
      stuckTasks: stuck.length,
      releasedTasks: released.length,
      exhaustedTasks: exhausted.length,
      taskTimeoutMs,
      details: stuck,
    };
  }

  surveyAgentStatus.workerName = 'surveyAgentStatus';
  surveyAgentStatus.domain = domain;
  surveyAgentStatus.priority = priority;

  balanceWorkload.workerName = 'balanceWorkload';
  balanceWorkload.domain = domain;
  balanceWorkload.priority = priority;

  detectAndResolveDeadlocks.workerName = 'detectAndResolveDeadlocks';
  detectAndResolveDeadlocks.domain = domain;
  detectAndResolveDeadlocks.priority = priority;

  return [surveyAgentStatus, balanceWorkload, detectAndResolveDeadlocks];
}

/**
 * Registers an agent with the orchestrator.
 * @param {string} id
 * @param {Object} meta
 */
function registerAgent(id, meta = {}) {
  _agentRegistry.set(id, { id, ...meta, lastSeen: Date.now(), registeredAt: new Date().toISOString() });
}

/**
 * Records a heartbeat for an agent.
 * @param {string} id
 */
function heartbeat(id) {
  const agent = _agentRegistry.get(id);
  if (agent) agent.lastSeen = Date.now();
}

/**
 * Enqueues a task for orchestration.
 * @param {string} id
 * @param {Object} task
 */
function enqueueTask(id, task) {
  _taskRegistry.set(id, { id, status: 'pending', createdAt: new Date().toISOString(), ...task });
}

module.exports = { domain, description, priority, getWork, registerAgent, heartbeat, enqueueTask };
