'use strict';

/**
 * @fileoverview Cloud Run deployer bee — deploys services to Google Cloud Run.
 * @module bees/cloud-run-deployer-bee
 */

const { execFile } = require('child_process');
const { promisify } = require('util');
const logger = require('../utils/logger');

const execFileAsync = promisify(execFile);

const domain = 'cloud-run';
const description = 'Deploys services to Google Cloud Run, manages revisions and traffic';
const priority = 0.82;

/**
 * Checks if gcloud CLI is available.
 * @returns {Promise<boolean>}
 */
async function isGcloudAvailable() {
  try {
    await execFileAsync('gcloud', ['version'], { timeout: 5000 });
    return true;
  } catch {
    return false;
  }
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Deploy a Cloud Run service using gcloud CLI.
   * @returns {Promise<Object>}
   */
  async function deployCloudRunService() {
    const serviceName = context.serviceName || process.env.CLOUD_RUN_SERVICE || 'heady-service';
    const image = context.image || process.env.CLOUD_RUN_IMAGE;
    const region = context.region || process.env.CLOUD_RUN_REGION || 'us-central1';
    const project = context.project || process.env.GOOGLE_CLOUD_PROJECT;
    const memory = context.memory || process.env.CLOUD_RUN_MEMORY || '512Mi';
    const concurrency = context.concurrency || 80;
    const maxInstances = context.maxInstances || 10;

    logger.info(`[cloud-run] deploying service '${serviceName}'`, { region, image: image ? image.slice(0, 60) : 'none' });

    if (!image) {
      return { domain, check: 'deploy', skipped: true, reason: 'no image specified (set context.image or CLOUD_RUN_IMAGE)' };
    }

    if (!project) {
      return { domain, check: 'deploy', skipped: true, reason: 'no project specified (set GOOGLE_CLOUD_PROJECT)' };
    }

    const available = await isGcloudAvailable();
    if (!available) {
      return { domain, check: 'deploy', skipped: true, reason: 'gcloud CLI not available' };
    }

    const args = [
      'run', 'deploy', serviceName,
      '--image', image,
      '--platform', 'managed',
      '--region', region,
      '--project', project,
      '--memory', memory,
      `--concurrency=${concurrency}`,
      `--max-instances=${maxInstances}`,
      '--allow-unauthenticated',
      '--format', 'json',
    ];

    // Add env vars if provided
    if (context.envVars && typeof context.envVars === 'object') {
      const envStr = Object.entries(context.envVars).map(([k, v]) => `${k}=${v}`).join(',');
      args.push('--set-env-vars', envStr);
    }

    try {
      const { stdout } = await execFileAsync('gcloud', args, { timeout: 300000 });
      const result = JSON.parse(stdout);
      logger.info(`[cloud-run] service '${serviceName}' deployed`, { url: result.status?.url });
      return {
        domain,
        check: 'deploy',
        success: true,
        serviceName,
        url: result.status?.url,
        revision: result.status?.latestCreatedRevisionName,
        region,
        timestamp: new Date().toISOString(),
      };
    } catch (err) {
      logger.error(`[cloud-run] deployment failed: ${err.message}`);
      return { domain, check: 'deploy', success: false, error: err.message, stderr: err.stderr?.slice(0, 500) };
    }
  }

  /**
   * List active Cloud Run services and their status.
   * @returns {Promise<Object>}
   */
  async function listCloudRunServices() {
    const region = context.region || process.env.CLOUD_RUN_REGION || 'us-central1';
    const project = context.project || process.env.GOOGLE_CLOUD_PROJECT;

    if (!project) {
      return { domain, check: 'list-services', skipped: true, reason: 'no project configured' };
    }

    const available = await isGcloudAvailable();
    if (!available) {
      return { domain, check: 'list-services', skipped: true, reason: 'gcloud CLI not available' };
    }

    try {
      const { stdout } = await execFileAsync('gcloud', [
        'run', 'services', 'list',
        '--platform', 'managed',
        '--region', region,
        '--project', project,
        '--format', 'json',
      ], { timeout: 30000 });

      const services = JSON.parse(stdout);
      logger.info(`[cloud-run] found ${services.length} service(s)`);

      return {
        domain,
        check: 'list-services',
        count: services.length,
        services: services.map((s) => ({
          name: s.metadata?.name,
          url: s.status?.url,
          ready: s.status?.conditions?.find((c) => c.type === 'Ready')?.status === 'True',
          latestRevision: s.status?.latestReadyRevisionName,
        })),
        region,
      };
    } catch (err) {
      return { domain, check: 'list-services', error: err.message };
    }
  }

  /**
   * Set traffic routing between Cloud Run revisions.
   * @returns {Promise<Object>}
   */
  async function manageTrafficSplit() {
    const serviceName = context.serviceName || process.env.CLOUD_RUN_SERVICE;
    const region = context.region || process.env.CLOUD_RUN_REGION || 'us-central1';
    const project = context.project || process.env.GOOGLE_CLOUD_PROJECT;
    const trafficSplit = context.trafficSplit; // e.g. [{revision: 'v1', percent: 90}, {revision: 'v2', percent: 10}]

    if (!serviceName || !trafficSplit || !project) {
      return { domain, check: 'traffic-split', skipped: true, reason: 'serviceName, trafficSplit, and project required' };
    }

    const available = await isGcloudAvailable();
    if (!available) {
      return { domain, check: 'traffic-split', skipped: true, reason: 'gcloud CLI not available' };
    }

    const toFlag = trafficSplit.map((t) => `${t.revision}=${t.percent}`).join(',');

    try {
      await execFileAsync('gcloud', [
        'run', 'services', 'update-traffic', serviceName,
        '--to-revisions', toFlag,
        '--region', region,
        '--project', project,
      ], { timeout: 60000 });

      logger.info(`[cloud-run] traffic split updated for '${serviceName}'`);
      return { domain, check: 'traffic-split', success: true, serviceName, split: trafficSplit };
    } catch (err) {
      return { domain, check: 'traffic-split', success: false, error: err.message };
    }
  }

  deployCloudRunService.workerName = 'deployCloudRunService';
  deployCloudRunService.domain = domain;
  deployCloudRunService.priority = priority;

  listCloudRunServices.workerName = 'listCloudRunServices';
  listCloudRunServices.domain = domain;
  listCloudRunServices.priority = priority;

  manageTrafficSplit.workerName = 'manageTrafficSplit';
  manageTrafficSplit.domain = domain;
  manageTrafficSplit.priority = priority;

  return [deployCloudRunService, listCloudRunServices, manageTrafficSplit];
}

module.exports = { domain, description, priority, getWork };
