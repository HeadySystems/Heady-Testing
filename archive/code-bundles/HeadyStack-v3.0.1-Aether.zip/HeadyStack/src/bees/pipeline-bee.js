'use strict';

/**
 * @fileoverview Pipeline bee — monitors pipeline stages, tracks throughput and latency.
 * @module bees/pipeline-bee
 */

const logger = require('../utils/logger');

const domain = 'pipeline';
const description = 'Monitors pipeline stages, stage throughput, processing latency, and bottlenecks';
const priority = 0.81;

/**
 * In-memory pipeline registry.
 * @type {Map<string, Object>}
 */
const _pipelines = new Map();

/**
 * Registers a pipeline with stages.
 * @param {string} id
 * @param {Array<{name: string, handler: Function}>} stages
 * @param {Object} [meta={}]
 */
function registerPipeline(id, stages, meta = {}) {
  _pipelines.set(id, {
    id,
    stages: stages.map((s) => ({
      name: s.name,
      handler: s.handler,
      processedCount: 0,
      errorCount: 0,
      totalLatencyMs: 0,
      lastRunAt: null,
    })),
    meta,
    createdAt: new Date().toISOString(),
    runCount: 0,
    lastRunAt: null,
  });
  logger.debug(`[pipeline] registered pipeline '${id}' with ${stages.length} stage(s)`);
}

/**
 * Executes a pipeline with the given input.
 * @param {string} id
 * @param {*} input
 * @returns {Promise<{pipelineId, stages, output, success, totalMs}>}
 */
async function executePipeline(id, input) {
  const pipeline = _pipelines.get(id);
  if (!pipeline) throw new Error(`Pipeline '${id}' not found`);

  const stageResults = [];
  let current = input;
  const start = Date.now();

  for (const stage of pipeline.stages) {
    const stageStart = Date.now();
    try {
      current = await stage.handler(current);
      const ms = Date.now() - stageStart;
      stage.processedCount++;
      stage.totalLatencyMs += ms;
      stage.lastRunAt = new Date().toISOString();
      stageResults.push({ name: stage.name, success: true, latencyMs: ms });
    } catch (err) {
      const ms = Date.now() - stageStart;
      stage.errorCount++;
      stage.totalLatencyMs += ms;
      stageResults.push({ name: stage.name, success: false, latencyMs: ms, error: err.message });
      logger.error(`[pipeline] stage '${stage.name}' failed: ${err.message}`);
      break; // halt on stage failure
    }
  }

  pipeline.runCount++;
  pipeline.lastRunAt = new Date().toISOString();

  return {
    pipelineId: id,
    stages: stageResults,
    output: current,
    success: stageResults.every((s) => s.success),
    totalMs: Date.now() - start,
  };
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Report on all registered pipelines and their throughput metrics.
   * @returns {Promise<Object>}
   */
  async function reportPipelineMetrics() {
    logger.debug('[pipeline] reporting pipeline metrics');
    const pipelines = Array.from(_pipelines.values());

    const metrics = pipelines.map((p) => {
      const stageMetrics = p.stages.map((s) => ({
        name: s.name,
        processedCount: s.processedCount,
        errorCount: s.errorCount,
        errorRate: s.processedCount > 0 ? Math.round((s.errorCount / s.processedCount) * 100) : 0,
        avgLatencyMs: s.processedCount > 0 ? Math.round(s.totalLatencyMs / s.processedCount) : 0,
        lastRunAt: s.lastRunAt,
      }));

      return {
        id: p.id,
        runCount: p.runCount,
        lastRunAt: p.lastRunAt,
        stageCount: p.stages.length,
        stages: stageMetrics,
        bottleneck: stageMetrics.length > 0
          ? stageMetrics.reduce((max, s) => s.avgLatencyMs > max.avgLatencyMs ? s : max, stageMetrics[0])?.name
          : null,
      };
    });

    return {
      domain,
      check: 'pipeline-metrics',
      totalPipelines: pipelines.length,
      pipelines: metrics,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Detect bottleneck stages across all pipelines.
   * @returns {Promise<Object>}
   */
  async function detectBottlenecks() {
    logger.debug('[pipeline] detecting bottlenecks');
    const bottlenecks = [];

    for (const pipeline of _pipelines.values()) {
      for (const stage of pipeline.stages) {
        if (stage.processedCount < 5) continue; // not enough data
        const avgMs = stage.totalLatencyMs / stage.processedCount;
        const errorRate = stage.errorCount / stage.processedCount;

        if (avgMs > 1000 || errorRate > 0.05) {
          bottlenecks.push({
            pipelineId: pipeline.id,
            stage: stage.name,
            avgLatencyMs: Math.round(avgMs),
            errorRate: Math.round(errorRate * 100),
            severity: avgMs > 5000 || errorRate > 0.20 ? 'critical' : 'warning',
          });
        }
      }
    }

    bottlenecks.sort((a, b) => b.avgLatencyMs - a.avgLatencyMs);

    if (bottlenecks.length > 0) {
      logger.warn(`[pipeline] ${bottlenecks.length} bottleneck(s) detected`);
    }

    return {
      domain,
      check: 'bottleneck-detection',
      bottlenecks: bottlenecks.length,
      critical: bottlenecks.filter((b) => b.severity === 'critical').length,
      details: bottlenecks,
    };
  }

  /**
   * Run health-check pipelines registered in context.
   * @returns {Promise<Object>}
   */
  async function runHealthPipelines() {
    const healthPipelines = context.healthPipelines || [];
    const results = [];

    for (const pipelineId of healthPipelines) {
      if (!_pipelines.has(pipelineId)) {
        results.push({ pipelineId, success: false, error: 'pipeline not found' });
        continue;
      }
      try {
        const result = await executePipeline(pipelineId, context.healthInput || {});
        results.push({ pipelineId, success: result.success, totalMs: result.totalMs });
      } catch (err) {
        results.push({ pipelineId, success: false, error: err.message });
      }
    }

    return {
      domain,
      check: 'health-pipelines',
      ran: results.length,
      passed: results.filter((r) => r.success).length,
      results,
    };
  }

  reportPipelineMetrics.workerName = 'reportPipelineMetrics';
  reportPipelineMetrics.domain = domain;
  reportPipelineMetrics.priority = priority;

  detectBottlenecks.workerName = 'detectBottlenecks';
  detectBottlenecks.domain = domain;
  detectBottlenecks.priority = priority;

  runHealthPipelines.workerName = 'runHealthPipelines';
  runHealthPipelines.domain = domain;
  runHealthPipelines.priority = priority;

  return [reportPipelineMetrics, detectBottlenecks, runHealthPipelines];
}

module.exports = { domain, description, priority, getWork, registerPipeline, executePipeline };
