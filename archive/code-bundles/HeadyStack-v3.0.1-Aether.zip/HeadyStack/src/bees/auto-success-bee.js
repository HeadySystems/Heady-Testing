'use strict';

/**
 * @fileoverview Auto-success bee — automatic correction and recovery strategies.
 * @module bees/auto-success-bee
 */

const logger = require('../utils/logger');

const domain = 'auto-success';
const description = 'Auto-correction strategies: retry policies, self-healing checks, failure recovery playbooks';
const priority = 0.87;

/**
 * Retry a function with exponential backoff.
 * @param {Function} fn
 * @param {Object} [opts]
 * @param {number} [opts.maxAttempts=3]
 * @param {number} [opts.baseDelayMs=100]
 * @param {number} [opts.maxDelayMs=10000]
 * @returns {Promise<{success: boolean, result?: any, error?: string, attempts: number}>}
 */
async function retryWithBackoff(fn, opts = {}) {
  const maxAttempts = opts.maxAttempts || 3;
  const baseDelayMs = opts.baseDelayMs || 100;
  const maxDelayMs = opts.maxDelayMs || 10000;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const result = await fn();
      return { success: true, result, attempts: attempt };
    } catch (err) {
      if (attempt === maxAttempts) {
        return { success: false, error: err.message, attempts: attempt };
      }
      const delay = Math.min(baseDelayMs * Math.pow(2, attempt - 1), maxDelayMs);
      logger.debug(`[auto-success] attempt ${attempt}/${maxAttempts} failed, retrying in ${delay}ms: ${err.message}`);
      await new Promise((r) => setTimeout(r, delay));
    }
  }
  return { success: false, error: 'max attempts exceeded', attempts: maxAttempts };
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Run registered auto-correction strategies.
   * @returns {Promise<Object>}
   */
  async function runCorrectionStrategies() {
    const strategies = context.strategies || [];
    logger.debug(`[auto-success] running ${strategies.length} correction strategy/ies`);

    if (strategies.length === 0) {
      // Run built-in self-checks
      const selfChecks = [
        {
          name: 'memory-leak-guard',
          fn: async () => {
            const mem = process.memoryUsage();
            const heapPct = (mem.heapUsed / mem.heapTotal) * 100;
            if (heapPct > 95) {
              if (global.gc) { global.gc(); return 'forced GC'; }
              throw new Error(`heap at ${heapPct.toFixed(1)}% — consider restarting`);
            }
            return `heap at ${heapPct.toFixed(1)}% — ok`;
          },
        },
        {
          name: 'event-loop-lag',
          fn: async () => {
            const start = Date.now();
            await new Promise((r) => setImmediate(r));
            const lag = Date.now() - start;
            if (lag > 100) throw new Error(`event loop lag: ${lag}ms`);
            return `event loop lag: ${lag}ms`;
          },
        },
      ];

      const results = [];
      for (const check of selfChecks) {
        const result = await retryWithBackoff(check.fn, { maxAttempts: 2, baseDelayMs: 50 });
        results.push({ name: check.name, ...result });
      }

      return {
        domain,
        check: 'correction-strategies',
        ran: results.length,
        succeeded: results.filter((r) => r.success).length,
        failed: results.filter((r) => !r.success).length,
        results,
      };
    }

    const results = [];
    for (const strategy of strategies) {
      const result = await retryWithBackoff(strategy.fn, {
        maxAttempts: strategy.maxAttempts || 3,
        baseDelayMs: strategy.baseDelayMs || 100,
      });
      results.push({ name: strategy.name, ...result });
      if (result.success) {
        logger.info(`[auto-success] strategy '${strategy.name}' succeeded after ${result.attempts} attempt(s)`);
      } else {
        logger.warn(`[auto-success] strategy '${strategy.name}' failed: ${result.error}`);
      }
    }

    return {
      domain,
      check: 'correction-strategies',
      ran: results.length,
      succeeded: results.filter((r) => r.success).length,
      failed: results.filter((r) => !r.success).length,
      results,
    };
  }

  /**
   * Execute recovery playbooks for known failure patterns.
   * @returns {Promise<Object>}
   */
  async function executeRecoveryPlaybooks() {
    const playbooks = context.playbooks || [];
    const failures = context.detectedFailures || [];

    const BUILTIN_PLAYBOOKS = {
      'high-memory': async () => {
        const mem = process.memoryUsage();
        const heapPct = (mem.heapUsed / mem.heapTotal) * 100;
        if (heapPct < 80) return 'memory usage normal — no action needed';
        if (global.gc) global.gc();
        return `attempted GC at ${heapPct.toFixed(1)}% heap usage`;
      },
      'stale-cache': async () => {
        // Clear Node.js require cache of non-core modules
        let cleared = 0;
        for (const key of Object.keys(require.cache)) {
          if (!key.includes('node_modules') && key.includes('cache')) {
            delete require.cache[key];
            cleared++;
          }
        }
        return `cleared ${cleared} cache module(s)`;
      },
      'log-flood': async () => {
        // Increase log level to reduce output
        process.env.LOG_LEVEL = 'error';
        return 'log level elevated to error to reduce flood';
      },
    };

    const executed = [];

    // Execute playbooks for detected failures
    for (const failure of failures) {
      const playbook = BUILTIN_PLAYBOOKS[failure.type] || playbooks.find((p) => p.name === failure.type)?.fn;
      if (!playbook) {
        executed.push({ failure: failure.type, status: 'no-playbook' });
        continue;
      }
      try {
        const result = await playbook(failure);
        executed.push({ failure: failure.type, status: 'executed', result });
        logger.info(`[auto-success] playbook '${failure.type}' executed: ${result}`);
      } catch (err) {
        executed.push({ failure: failure.type, status: 'failed', error: err.message });
      }
    }

    return {
      domain,
      check: 'recovery-playbooks',
      detectedFailures: failures.length,
      executed: executed.length,
      successful: executed.filter((e) => e.status === 'executed').length,
      results: executed,
    };
  }

  /**
   * Score overall system auto-success rate and recommend improvements.
   * @returns {Promise<Object>}
   */
  async function scoreAutoSuccessRate() {
    const recentEvents = context.recentEvents || [];
    const successes = recentEvents.filter((e) => e.success === true || e.status === 'success').length;
    const failures = recentEvents.filter((e) => e.success === false || e.status === 'error').length;
    const total = recentEvents.length || 1;

    const successRate = Math.round((successes / total) * 100);
    const grade = successRate >= 99 ? 'A+' : successRate >= 95 ? 'A' : successRate >= 90 ? 'B' : successRate >= 80 ? 'C' : 'D';

    const recommendations = [];
    if (successRate < 95) recommendations.push('Implement retry policies on failing operations');
    if (successRate < 90) recommendations.push('Add circuit breakers to protect cascading failures');
    if (successRate < 80) recommendations.push('Review error logs and add targeted recovery playbooks');

    return {
      domain,
      check: 'success-rate',
      total: recentEvents.length,
      successes,
      failures,
      successRate,
      grade,
      recommendations,
    };
  }

  runCorrectionStrategies.workerName = 'runCorrectionStrategies';
  runCorrectionStrategies.domain = domain;
  runCorrectionStrategies.priority = priority;

  executeRecoveryPlaybooks.workerName = 'executeRecoveryPlaybooks';
  executeRecoveryPlaybooks.domain = domain;
  executeRecoveryPlaybooks.priority = priority;

  scoreAutoSuccessRate.workerName = 'scoreAutoSuccessRate';
  scoreAutoSuccessRate.domain = domain;
  scoreAutoSuccessRate.priority = priority;

  return [runCorrectionStrategies, executeRecoveryPlaybooks, scoreAutoSuccessRate];
}

module.exports = { domain, description, priority, getWork, retryWithBackoff };
