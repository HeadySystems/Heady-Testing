'use strict';

/**
 * @fileoverview Memory bee — vector memory maintenance, compaction, and health.
 * @module bees/memory-bee
 */

const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

const domain = 'memory';
const description = 'Vector memory maintenance: compaction, expiry pruning, index health, usage stats';
const priority = 0.83;

/**
 * Reads a JSON memory store file safely.
 * @param {string} filePath
 * @returns {Array<Object>|null}
 */
function readMemoryStore(filePath) {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : parsed.entries || parsed.memories || [];
  } catch {
    return null;
  }
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Scan vector memory stores and report usage statistics.
   * @returns {Promise<Object>}
   */
  async function scanMemoryUsage() {
    const memoryDir = context.memoryDir || path.join(process.cwd(), 'data', 'memory');
    logger.debug(`[memory] scanning memory store at ${memoryDir}`);

    if (!fs.existsSync(memoryDir)) {
      return { domain, check: 'memory-usage', exists: false, totalEntries: 0, stores: [] };
    }

    let entries;
    try { entries = fs.readdirSync(memoryDir); } catch (err) {
      return { domain, check: 'memory-usage', error: err.message };
    }

    const storeFiles = entries.filter((f) => f.endsWith('.json') || f.endsWith('.ndjson'));
    const stores = [];
    let totalEntries = 0;
    let totalSizeBytes = 0;

    for (const file of storeFiles) {
      const filePath = path.join(memoryDir, file);
      const stat = fs.statSync(filePath);
      const memories = readMemoryStore(filePath);
      const count = memories ? memories.length : 0;

      totalEntries += count;
      totalSizeBytes += stat.size;

      stores.push({
        file,
        entries: count,
        sizeBytes: stat.size,
        lastModified: stat.mtime.toISOString(),
        hasEmbeddings: memories ? memories.some((m) => Array.isArray(m.embedding)) : false,
      });
    }

    logger.info(`[memory] scanned ${storeFiles.length} store(s), ${totalEntries} total entries`);

    return {
      domain,
      check: 'memory-usage',
      totalStores: storeFiles.length,
      totalEntries,
      totalSizeMB: Math.round(totalSizeBytes / 1024 / 1024 * 100) / 100,
      stores,
    };
  }

  /**
   * Prune expired or stale memory entries based on TTL.
   * @returns {Promise<Object>}
   */
  async function pruneExpiredMemories() {
    const memoryDir = context.memoryDir || path.join(process.cwd(), 'data', 'memory');
    const ttlDays = context.ttlDays || 30;
    const cutoff = Date.now() - ttlDays * 86400000;

    if (!fs.existsSync(memoryDir)) {
      return { domain, check: 'prune-memories', skipped: true, reason: 'memory directory not found' };
    }

    let entries;
    try { entries = fs.readdirSync(memoryDir); } catch (err) {
      return { domain, check: 'prune-memories', error: err.message };
    }

    let totalPruned = 0;
    let totalKept = 0;
    const storeResults = [];

    for (const file of entries.filter((f) => f.endsWith('.json'))) {
      const filePath = path.join(memoryDir, file);
      const memories = readMemoryStore(filePath);
      if (!memories) continue;

      const kept = memories.filter((m) => {
        if (!m.timestamp) return true; // keep if no timestamp
        return new Date(m.timestamp).getTime() > cutoff;
      });

      const pruned = memories.length - kept.length;
      totalPruned += pruned;
      totalKept += kept.length;

      if (pruned > 0 && context.dryRun !== true) {
        fs.writeFileSync(filePath, JSON.stringify(kept, null, 2), 'utf8');
        logger.info(`[memory] pruned ${pruned} entries from ${file}`);
      }

      storeResults.push({ file, original: memories.length, kept, pruned });
    }

    return {
      domain,
      check: 'prune-memories',
      ttlDays,
      totalPruned,
      totalKept,
      dryRun: context.dryRun === true,
      stores: storeResults,
    };
  }

  /**
   * Check vector index health and fragmentation.
   * @returns {Promise<Object>}
   */
  async function checkVectorIndexHealth() {
    const memoryDir = context.memoryDir || path.join(process.cwd(), 'data', 'memory');
    logger.debug('[memory] checking vector index health');

    if (!fs.existsSync(memoryDir)) {
      return { domain, check: 'vector-index-health', healthy: true, reason: 'no index yet — clean state' };
    }

    const indexFiles = [];
    try {
      const entries = fs.readdirSync(memoryDir);
      indexFiles.push(...entries.filter((f) => f.endsWith('.index') || f.endsWith('.faiss') || f.endsWith('.hnsw')));
    } catch { /* ok */ }

    let totalVectors = 0;
    let withEmbeddings = 0;
    let withoutEmbeddings = 0;

    try {
      const entries = fs.readdirSync(memoryDir);
      for (const file of entries.filter((f) => f.endsWith('.json'))) {
        const memories = readMemoryStore(path.join(memoryDir, file));
        if (!memories) continue;
        for (const m of memories) {
          totalVectors++;
          if (Array.isArray(m.embedding) && m.embedding.length > 0) withEmbeddings++;
          else withoutEmbeddings++;
        }
      }
    } catch { /* ok */ }

    const embeddingCoverage = totalVectors > 0 ? (withEmbeddings / totalVectors) * 100 : 100;
    const healthy = embeddingCoverage >= 80 || totalVectors === 0;

    if (!healthy) {
      logger.warn(`[memory] low embedding coverage: ${embeddingCoverage.toFixed(1)}%`);
    }

    return {
      domain,
      check: 'vector-index-health',
      healthy,
      totalVectors,
      withEmbeddings,
      withoutEmbeddings,
      embeddingCoverage: Math.round(embeddingCoverage * 10) / 10,
      indexFiles: indexFiles.length,
      recommendation: withoutEmbeddings > 0 ? `Re-embed ${withoutEmbeddings} entries` : 'All vectors have embeddings',
    };
  }

  scanMemoryUsage.workerName = 'scanMemoryUsage';
  scanMemoryUsage.domain = domain;
  scanMemoryUsage.priority = priority;

  pruneExpiredMemories.workerName = 'pruneExpiredMemories';
  pruneExpiredMemories.domain = domain;
  pruneExpiredMemories.priority = priority;

  checkVectorIndexHealth.workerName = 'checkVectorIndexHealth';
  checkVectorIndexHealth.domain = domain;
  checkVectorIndexHealth.priority = priority;

  return [scanMemoryUsage, pruneExpiredMemories, checkVectorIndexHealth];
}

module.exports = { domain, description, priority, getWork };
