'use strict';

/**
 * @fileoverview Providers bee — health-checks external service providers.
 * @module bees/providers-bee
 */

const https = require('https');
const http = require('http');
const logger = require('../utils/logger');

const domain = 'providers';
const description = 'Health-checks external service providers: databases, APIs, storage, messaging';
const priority = 0.84;

/**
 * Default provider catalogue with health check endpoints.
 */
const DEFAULT_PROVIDERS = [
  { name: 'stripe', url: 'https://status.stripe.com/api/v2/status.json', path: '$.status.indicator', expected: 'none' },
  { name: 'sendgrid', url: 'https://status.sendgrid.com/api/v2/status.json', path: '$.status.indicator', expected: 'none' },
  { name: 'twilio', url: 'https://status.twilio.com/api/v2/status.json', path: '$.status.indicator', expected: 'none' },
  { name: 'firebase', url: 'https://status.firebase.google.com/incidents.json', path: null },
  { name: 'github', url: 'https://www.githubstatus.com/api/v2/status.json', path: '$.status.indicator', expected: 'none' },
];

/**
 * Performs a GET request and returns status + body.
 * @param {string} url
 * @param {number} [timeoutMs=8000]
 * @returns {Promise<{status, body, latencyMs}>}
 */
async function httpGet(url, timeoutMs = 8000) {
  return new Promise((resolve, reject) => {
    const lib = url.startsWith('https') ? https : http;
    const start = Date.now();
    const req = lib.get(url, { timeout: timeoutMs }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => resolve({ status: res.statusCode, body, latencyMs: Date.now() - start }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

/**
 * Evaluates a status page response.
 * @param {Object} provider
 * @param {Object} response
 * @returns {{operational: boolean, indicator: string}}
 */
function evaluateResponse(provider, response) {
  if (response.status !== 200) {
    return { operational: false, indicator: `HTTP ${response.status}` };
  }

  if (!provider.path) {
    return { operational: true, indicator: 'reachable' };
  }

  try {
    const parsed = JSON.parse(response.body);
    // Simple dot-path traversal: $.status.indicator => obj.status.indicator
    const parts = provider.path.replace('$.', '').split('.');
    let val = parsed;
    for (const p of parts) { val = val[p]; }
    return {
      operational: val === (provider.expected || 'none'),
      indicator: String(val || 'unknown'),
    };
  } catch {
    return { operational: response.status === 200, indicator: 'parse-error' };
  }
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Check health of all configured external providers.
   * @returns {Promise<Object>}
   */
  async function checkExternalProviders() {
    const providers = context.providers || DEFAULT_PROVIDERS;
    logger.debug(`[providers] checking ${providers.length} external provider(s)`);

    const results = await Promise.allSettled(providers.map(async (p) => {
      try {
        const response = await httpGet(p.url);
        const eval_ = evaluateResponse(p, response);
        return {
          name: p.name,
          url: p.url,
          operational: eval_.operational,
          indicator: eval_.indicator,
          latencyMs: response.latencyMs,
          status: response.status,
        };
      } catch (err) {
        return { name: p.name, url: p.url, operational: false, error: err.message, latencyMs: 0 };
      }
    }));

    const checks = results.map((r) => r.status === 'fulfilled' ? r.value : { operational: false, error: r.reason?.message });
    const operational = checks.filter((c) => c.operational).length;
    const degraded = checks.filter((c) => !c.operational).length;

    if (degraded > 0) {
      logger.warn(`[providers] ${degraded} provider(s) degraded`, { providers: checks.filter((c) => !c.operational).map((c) => c.name) });
    }

    return {
      domain,
      check: 'external-providers',
      total: checks.length,
      operational,
      degraded,
      allHealthy: degraded === 0,
      providers: checks,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Check connectivity to configured databases.
   * @returns {Promise<Object>}
   */
  async function checkDatabaseConnectivity() {
    const dbConfigs = context.databases || [];
    const results = [];

    for (const db of dbConfigs) {
      const start = Date.now();
      try {
        if (db.type === 'postgres' || db.type === 'postgresql') {
          // Attempt a TCP connection check
          const net = require('net');
          await new Promise((resolve, reject) => {
            const sock = new net.Socket();
            sock.setTimeout(5000);
            sock.connect(db.port || 5432, db.host || 'localhost', () => { sock.destroy(); resolve(); });
            sock.on('error', reject);
            sock.on('timeout', () => { sock.destroy(); reject(new Error('connection timeout')); });
          });
          results.push({ name: db.name || db.type, reachable: true, latencyMs: Date.now() - start });
        } else if (db.type === 'redis') {
          const net = require('net');
          await new Promise((resolve, reject) => {
            const sock = new net.Socket();
            sock.setTimeout(5000);
            sock.connect(db.port || 6379, db.host || 'localhost', () => { sock.destroy(); resolve(); });
            sock.on('error', reject);
            sock.on('timeout', () => { sock.destroy(); reject(new Error('connection timeout')); });
          });
          results.push({ name: db.name || db.type, reachable: true, latencyMs: Date.now() - start });
        } else {
          results.push({ name: db.name || db.type, reachable: false, error: `unsupported db type: ${db.type}` });
        }
      } catch (err) {
        results.push({ name: db.name || db.type, reachable: false, latencyMs: Date.now() - start, error: err.message });
      }
    }

    if (dbConfigs.length === 0) {
      return { domain, check: 'database-connectivity', skipped: true, reason: 'no databases configured' };
    }

    return {
      domain,
      check: 'database-connectivity',
      total: results.length,
      reachable: results.filter((r) => r.reachable).length,
      unreachable: results.filter((r) => !r.reachable).length,
      results,
    };
  }

  /**
   * Aggregate provider SLA metrics and flag SLA breaches.
   * @returns {Promise<Object>}
   */
  async function aggregateSlaMetrics() {
    const slaTargets = context.slaTargets || {};
    // Example: { 'stripe': 0.9999, 'sendgrid': 0.999 }

    const providers = context.providers || DEFAULT_PROVIDERS;
    const breaches = [];
    const metrics = [];

    for (const p of providers) {
      const slaTarget = slaTargets[p.name] || 0.999;
      // Simulated availability from in-memory state (in production, query time-series DB)
      const availability = p._simulatedAvailability || 0.9995;
      const breach = availability < slaTarget;

      if (breach) {
        breaches.push({ provider: p.name, availability, target: slaTarget });
        logger.warn(`[providers] SLA breach for '${p.name}': ${(availability * 100).toFixed(3)}% < ${(slaTarget * 100).toFixed(3)}%`);
      }

      metrics.push({ provider: p.name, availability, target: slaTarget, breach });
    }

    return {
      domain,
      check: 'sla-metrics',
      breaches: breaches.length,
      allMeetingSLA: breaches.length === 0,
      metrics,
    };
  }

  checkExternalProviders.workerName = 'checkExternalProviders';
  checkExternalProviders.domain = domain;
  checkExternalProviders.priority = priority;

  checkDatabaseConnectivity.workerName = 'checkDatabaseConnectivity';
  checkDatabaseConnectivity.domain = domain;
  checkDatabaseConnectivity.priority = priority;

  aggregateSlaMetrics.workerName = 'aggregateSlaMetrics';
  aggregateSlaMetrics.domain = domain;
  aggregateSlaMetrics.priority = priority;

  return [checkExternalProviders, checkDatabaseConnectivity, aggregateSlaMetrics];
}

module.exports = { domain, description, priority, getWork };
