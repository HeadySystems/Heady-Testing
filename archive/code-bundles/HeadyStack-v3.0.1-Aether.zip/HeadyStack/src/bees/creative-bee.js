'use strict';

/**
 * @fileoverview Creative bee — handles creative content generation workflows.
 * @module bees/creative-bee
 */

const logger = require('../utils/logger');

const domain = 'creative';
const description = 'Handles creative content generation: templates, variation generation, creative scoring';
const priority = 0.70;

/**
 * A simple Markov-style sentence variation engine for creative text.
 * @param {string} template
 * @param {Object} vars
 * @returns {string}
 */
function renderTemplate(template, vars) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] || `[${key}]`);
}

/**
 * Generates stylistic variations of a text.
 * @param {string} text
 * @param {number} count
 * @returns {string[]}
 */
function generateVariations(text, count = 3) {
  const styles = [
    (t) => t.split('. ').map((s) => s.charAt(0).toUpperCase() + s.slice(1)).join('. '),
    (t) => t.replace(/\b(\w)/g, (c) => c.toUpperCase()),
    (t) => t.toLowerCase(),
    (t) => t.replace(/([.!?])\s+/g, '$1\n\n'),
    (t) => `✨ ${t} ✨`,
    (t) => t.split(' ').reverse().slice(0, Math.floor(t.split(' ').length * 0.8)).reverse().join(' ') + '...',
  ];

  const variations = [];
  for (let i = 0; i < Math.min(count, styles.length); i++) {
    variations.push(styles[i](text));
  }
  return variations;
}

/**
 * Computes a simple creativity score based on vocabulary diversity and length.
 * @param {string} text
 * @returns {{score: number, metrics: Object}}
 */
function scoreCreativity(text) {
  const words = text.toLowerCase().match(/\b\w+\b/g) || [];
  const unique = new Set(words);
  const ttr = words.length > 0 ? unique.size / words.length : 0; // type-token ratio
  const avgWordLen = words.length > 0 ? words.reduce((s, w) => s + w.length, 0) / words.length : 0;
  const sentences = (text.match(/[.!?]+/g) || []).length;
  const avgSentenceLen = sentences > 0 ? words.length / sentences : words.length;

  const score = Math.min(100, Math.round(
    ttr * 40 + // vocabulary diversity: 0-40
    Math.min(20, avgWordLen * 3) + // word complexity: 0-20
    Math.min(20, sentences * 5) + // sentence variety: 0-20
    Math.min(20, Math.log(words.length + 1) * 4) // length: 0-20
  ));

  return {
    score,
    metrics: {
      wordCount: words.length,
      uniqueWords: unique.size,
      typeTokenRatio: Math.round(ttr * 100) / 100,
      avgWordLength: Math.round(avgWordLen * 10) / 10,
      sentenceCount: sentences,
      avgSentenceLength: Math.round(avgSentenceLen * 10) / 10,
    },
  };
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Generate creative content from a template and context variables.
   * @returns {Promise<Object>}
   */
  async function generateCreativeContent() {
    const template = context.template || 'Hello, {{name}}! Welcome to {{project}}.';
    const vars = context.vars || { name: 'World', project: 'HeadyStack' };
    const variationCount = context.variationCount || 3;

    logger.debug('[creative] generating creative content');

    const rendered = renderTemplate(template, vars);
    const variations = generateVariations(rendered, variationCount);
    const scored = variations.map((v) => ({ text: v, ...scoreCreativity(v) }));
    const best = scored.reduce((max, v) => v.score > max.score ? v : max, scored[0] || { text: rendered, score: 0 });

    return {
      domain,
      check: 'content-generation',
      template,
      rendered,
      variationCount: variations.length,
      variations: scored,
      best,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Process a content generation queue if provided in context.
   * @returns {Promise<Object>}
   */
  async function processContentQueue() {
    const queue = context.contentQueue || [];
    logger.debug(`[creative] processing ${queue.length} content item(s)`);

    const results = [];
    for (const item of queue) {
      try {
        const rendered = renderTemplate(item.template || item.text || '', item.vars || {});
        const { score, metrics } = scoreCreativity(rendered);
        results.push({ id: item.id, status: 'generated', rendered, score, metrics });
      } catch (err) {
        results.push({ id: item.id, status: 'error', error: err.message });
      }
    }

    return {
      domain,
      check: 'content-queue',
      total: queue.length,
      generated: results.filter((r) => r.status === 'generated').length,
      errors: results.filter((r) => r.status === 'error').length,
      results,
    };
  }

  /**
   * Score and rank a set of creative texts.
   * @returns {Promise<Object>}
   */
  async function rankCreativeTexts() {
    const texts = context.textsToRank || [];
    if (texts.length === 0) {
      return { domain, check: 'creative-ranking', skipped: true, reason: 'no texts provided' };
    }

    const scored = texts.map((t, i) => ({
      index: i,
      text: typeof t === 'string' ? t : t.text,
      ...scoreCreativity(typeof t === 'string' ? t : t.text),
    }));

    scored.sort((a, b) => b.score - a.score);

    return {
      domain,
      check: 'creative-ranking',
      total: texts.length,
      top: scored[0],
      bottom: scored[scored.length - 1],
      ranked: scored,
    };
  }

  generateCreativeContent.workerName = 'generateCreativeContent';
  generateCreativeContent.domain = domain;
  generateCreativeContent.priority = priority;

  processContentQueue.workerName = 'processContentQueue';
  processContentQueue.domain = domain;
  processContentQueue.priority = priority;

  rankCreativeTexts.workerName = 'rankCreativeTexts';
  rankCreativeTexts.domain = domain;
  rankCreativeTexts.priority = priority;

  return [generateCreativeContent, processContentQueue, rankCreativeTexts];
}

module.exports = { domain, description, priority, getWork };
