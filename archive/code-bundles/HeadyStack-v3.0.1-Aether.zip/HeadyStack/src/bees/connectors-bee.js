'use strict';

/**
 * @fileoverview Connectors bee — manages external service connections and integration health.
 * @module bees/connectors-bee
 */

const https = require('https');
const http = require('http');
const logger = require('../utils/logger');

const domain = 'connectors';
const description = 'Manages external service connections: webhook validation, OAuth tokens, API keys';
const priority = 0.80;

/**
 * In-memory connector registry.
 * @type {Map<string, Object>}
 */
const _connectors = new Map();

/**
 * Registers an external service connector.
 * @param {string} name
 * @param {Object} config
 */
function registerConnector(name, config) {
  _connectors.set(name, {
    name,
    ...config,
    registeredAt: new Date().toISOString(),
    lastChecked: null,
    healthy: null,
  });
}

/**
 * Makes a health check request to a connector endpoint.
 * @param {string} url
 * @param {Object} [headers={}]
 * @param {number} [timeoutMs=5000]
 * @returns {Promise<{status: number, latencyMs: number, healthy: boolean}>}
 */
async function probeEndpoint(url, headers = {}, timeoutMs = 5000) {
  return new Promise((resolve) => {
    const lib = url.startsWith('https') ? https : http;
    const start = Date.now();
    const options = { timeout: timeoutMs, headers };
    const req = lib.get(url, options, (res) => {
      res.resume();
      resolve({ status: res.statusCode, latencyMs: Date.now() - start, healthy: res.statusCode < 400 });
    });
    req.on('error', (err) => resolve({ status: 0, latencyMs: Date.now() - start, healthy: false, error: err.message }));
    req.on('timeout', () => { req.destroy(); resolve({ status: 0, latencyMs: timeoutMs, healthy: false, error: 'timeout' }); });
  });
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Check health of all registered connectors.
   * @returns {Promise<Object>}
   */
  async function checkConnectorHealth() {
    const connectors = Array.from(_connectors.values());
    logger.debug(`[connectors] checking ${connectors.length} connector(s)`);

    const results = await Promise.allSettled(connectors.map(async (c) => {
      if (!c.healthUrl) {
        return { name: c.name, healthy: null, reason: 'no health URL configured' };
      }

      const headers = {};
      if (c.apiKey) headers['Authorization'] = `Bearer ${c.apiKey}`;
      if (c.apiKeyHeader) headers[c.apiKeyHeader] = c.apiKey;

      const probe = await probeEndpoint(c.healthUrl, headers);
      c.lastChecked = new Date().toISOString();
      c.healthy = probe.healthy;

      return {
        name: c.name,
        healthy: probe.healthy,
        status: probe.status,
        latencyMs: probe.latencyMs,
        lastChecked: c.lastChecked,
        error: probe.error,
      };
    }));

    const checks = results.map((r) => r.status === 'fulfilled' ? r.value : { healthy: false, error: r.reason?.message });
    const healthy = checks.filter((c) => c.healthy === true).length;
    const unhealthy = checks.filter((c) => c.healthy === false).length;
    const unknown = checks.filter((c) => c.healthy === null).length;

    return {
      domain,
      check: 'connector-health',
      total: checks.length,
      healthy,
      unhealthy,
      unknown,
      connectors: checks,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Validate webhook configurations and test endpoints.
   * @returns {Promise<Object>}
   */
  async function validateWebhooks() {
    const webhooks = context.webhooks || [];
    logger.debug(`[connectors] validating ${webhooks.length} webhook(s)`);

    const results = [];
    for (const webhook of webhooks) {
      if (!webhook.url) {
        results.push({ name: webhook.name, valid: false, reason: 'no URL configured' });
        continue;
      }

      // Check URL format
      let parsed;
      try { parsed = new URL(webhook.url); } catch {
        results.push({ name: webhook.name, valid: false, reason: 'invalid URL format' });
        continue;
      }

      // Verify HTTPS in production
      const nodeEnv = process.env.NODE_ENV;
      const httpsRequired = nodeEnv === 'production' && parsed.protocol !== 'https:';
      if (httpsRequired) {
        results.push({ name: webhook.name, valid: false, reason: 'HTTPS required in production' });
        continue;
      }

      // Check secret is configured
      const hasSecret = !!(webhook.secret || webhook.signingKey);
      if (!hasSecret) {
        results.push({ name: webhook.name, valid: true, warning: 'no signing secret configured', url: webhook.url });
        continue;
      }

      results.push({ name: webhook.name, valid: true, hasSecret: true, url: webhook.url });
    }

    return {
      domain,
      check: 'webhook-validation',
      total: webhooks.length,
      valid: results.filter((r) => r.valid).length,
      invalid: results.filter((r) => !r.valid).length,
      results,
    };
  }

  /**
   * Check OAuth token expiry for configured connectors.
   * @returns {Promise<Object>}
   */
  async function checkOAuthTokens() {
    const tokens = context.oauthTokens || [];
    const results = [];

    for (const token of tokens) {
      if (!token.expiresAt) {
        results.push({ name: token.name, status: 'unknown', reason: 'no expiry metadata' });
        continue;
      }

      const expiresAt = new Date(token.expiresAt).getTime();
      const now = Date.now();
      const daysLeft = Math.floor((expiresAt - now) / 86400000);

      results.push({
        name: token.name,
        expiresAt: new Date(expiresAt).toISOString(),
        daysLeft,
        status: daysLeft < 0 ? 'expired' : daysLeft <= 7 ? 'expiring-soon' : 'valid',
        refreshNeeded: daysLeft <= 7,
      });

      if (daysLeft < 0) logger.error(`[connectors] OAuth token '${token.name}' has expired`);
      else if (daysLeft <= 7) logger.warn(`[connectors] OAuth token '${token.name}' expires in ${daysLeft} days`);
    }

    return {
      domain,
      check: 'oauth-tokens',
      total: tokens.length,
      valid: results.filter((r) => r.status === 'valid').length,
      expiringSoon: results.filter((r) => r.status === 'expiring-soon').length,
      expired: results.filter((r) => r.status === 'expired').length,
      results,
    };
  }

  checkConnectorHealth.workerName = 'checkConnectorHealth';
  checkConnectorHealth.domain = domain;
  checkConnectorHealth.priority = priority;

  validateWebhooks.workerName = 'validateWebhooks';
  validateWebhooks.domain = domain;
  validateWebhooks.priority = priority;

  checkOAuthTokens.workerName = 'checkOAuthTokens';
  checkOAuthTokens.domain = domain;
  checkOAuthTokens.priority = priority;

  return [checkConnectorHealth, validateWebhooks, checkOAuthTokens];
}

module.exports = { domain, description, priority, getWork, registerConnector };
