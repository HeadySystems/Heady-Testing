'use strict';

/**
 * @fileoverview Sync Projection bee — synchronizes projections to targets (DB, cache, files).
 * @module bees/sync-projection-bee
 */

const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

const domain = 'sync-projection';
const description = 'Synchronizes projections to targets: DB read models, cache, event store replays';
const priority = 0.77;

/**
 * In-memory projection registry.
 * @type {Map<string, Object>}
 */
const _projections = new Map();

/**
 * Registers a projection with its source and target.
 * @param {string} name
 * @param {Object} config
 */
function registerProjection(name, config) {
  _projections.set(name, {
    name,
    ...config,
    lastSyncAt: null,
    syncCount: 0,
    errorCount: 0,
  });
}

/**
 * Computes a checksum of a serialized object.
 * @param {*} obj
 * @returns {string}
 */
function checksum(obj) {
  const crypto = require('crypto');
  return crypto.createHash('sha256').update(JSON.stringify(obj)).digest('hex').slice(0, 16);
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Sync all registered projections to their targets.
   * @returns {Promise<Object>}
   */
  async function syncProjections() {
    const projections = Array.from(_projections.values());
    logger.debug(`[sync-projection] syncing ${projections.length} projection(s)`);

    const results = [];
    for (const projection of projections) {
      const start = Date.now();
      try {
        // Get source data
        let sourceData;
        if (typeof projection.source === 'function') {
          sourceData = await projection.source(context);
        } else if (typeof projection.source === 'object') {
          sourceData = projection.source;
        } else {
          sourceData = {};
        }

        // Apply transformation if defined
        const transformed = typeof projection.transform === 'function'
          ? await projection.transform(sourceData)
          : sourceData;

        // Write to target
        if (projection.target === 'file' && projection.targetPath) {
          fs.mkdirSync(path.dirname(projection.targetPath), { recursive: true });
          fs.writeFileSync(projection.targetPath, JSON.stringify(transformed, null, 2), 'utf8');
        } else if (typeof projection.target === 'function') {
          await projection.target(transformed, context);
        }

        projection.lastSyncAt = new Date().toISOString();
        projection.syncCount++;
        results.push({ name: projection.name, success: true, durationMs: Date.now() - start, checksum: checksum(transformed) });
      } catch (err) {
        projection.errorCount++;
        logger.error(`[sync-projection] sync failed for '${projection.name}': ${err.message}`);
        results.push({ name: projection.name, success: false, durationMs: Date.now() - start, error: err.message });
      }
    }

    const succeeded = results.filter((r) => r.success).length;
    return {
      domain,
      check: 'sync-projections',
      total: projections.length,
      succeeded,
      failed: results.length - succeeded,
      results,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Detect projection staleness (projections not synced recently).
   * @returns {Promise<Object>}
   */
  async function detectStaleness() {
    const maxAgeMs = context.maxProjectionAgeMs || 300000; // 5 min default
    const now = Date.now();
    const stale = [];
    const fresh = [];

    for (const projection of _projections.values()) {
      if (!projection.lastSyncAt) {
        stale.push({ name: projection.name, reason: 'never synced' });
        continue;
      }
      const ageMs = now - new Date(projection.lastSyncAt).getTime();
      if (ageMs > maxAgeMs) {
        stale.push({ name: projection.name, ageMs, lastSyncAt: projection.lastSyncAt });
      } else {
        fresh.push({ name: projection.name, ageMs, lastSyncAt: projection.lastSyncAt });
      }
    }

    if (stale.length > 0) {
      logger.warn(`[sync-projection] ${stale.length} stale projection(s)`, { names: stale.map((p) => p.name) });
    }

    return {
      domain,
      check: 'projection-staleness',
      total: _projections.size,
      stale: stale.length,
      fresh: fresh.length,
      maxAgeMs,
      staleProjections: stale,
    };
  }

  /**
   * Rebuild all projections from event source (full replay).
   * @returns {Promise<Object>}
   */
  async function rebuildProjections() {
    const targets = context.rebuildTargets || Array.from(_projections.keys());
    const eventSource = context.eventSource;

    if (!eventSource && typeof eventSource !== 'function') {
      // Simulate a rebuild by resetting sync counters
      const reset = [];
      for (const name of targets) {
        const p = _projections.get(name);
        if (p) {
          p.lastSyncAt = null;
          p.syncCount = 0;
          p.errorCount = 0;
          reset.push(name);
        }
      }
      return {
        domain,
        check: 'rebuild-projections',
        mode: 'reset',
        reset: reset.length,
        targets,
      };
    }

    logger.info(`[sync-projection] rebuilding ${targets.length} projection(s) from event source`);

    let eventsProcessed = 0;
    try {
      const events = await eventSource(context);
      eventsProcessed = events.length;

      // Apply all events to each target projection
      for (const name of targets) {
        const p = _projections.get(name);
        if (!p || typeof p.applyEvent !== 'function') continue;

        p.state = {};
        for (const event of events) {
          p.state = p.applyEvent(p.state, event);
        }
        p.lastSyncAt = new Date().toISOString();
        p.syncCount = eventsProcessed;
      }
    } catch (err) {
      return { domain, check: 'rebuild-projections', success: false, error: err.message };
    }

    return {
      domain,
      check: 'rebuild-projections',
      mode: 'full-replay',
      targets: targets.length,
      eventsProcessed,
      success: true,
      completedAt: new Date().toISOString(),
    };
  }

  syncProjections.workerName = 'syncProjections';
  syncProjections.domain = domain;
  syncProjections.priority = priority;

  detectStaleness.workerName = 'detectStaleness';
  detectStaleness.domain = domain;
  detectStaleness.priority = priority;

  rebuildProjections.workerName = 'rebuildProjections';
  rebuildProjections.domain = domain;
  rebuildProjections.priority = priority;

  return [syncProjections, detectStaleness, rebuildProjections];
}

module.exports = { domain, description, priority, getWork, registerProjection };
