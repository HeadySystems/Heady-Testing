'use strict';

/**
 * @fileoverview Brain bee — manages LLM provider health, routing, and fallback.
 * @module bees/brain-bee
 */

const http = require('http');
const https = require('https');
const logger = require('../utils/logger');

const domain = 'brain-providers';
const description = 'Manages LLM provider health, model availability, latency tracking, and failover';
const priority = 0.91;

/**
 * Known LLM provider health check configurations.
 * @type {Array<{name, url, method, path, headers, expectedStatus}>}
 */
const PROVIDERS = [
  {
    name: 'openai',
    url: 'https://api.openai.com',
    path: '/v1/models',
    envKey: 'OPENAI_API_KEY',
    authHeader: 'Authorization',
    authPrefix: 'Bearer ',
  },
  {
    name: 'anthropic',
    url: 'https://api.anthropic.com',
    path: '/v1/models',
    envKey: 'ANTHROPIC_API_KEY',
    authHeader: 'x-api-key',
    authPrefix: '',
    extraHeaders: { 'anthropic-version': '2023-06-01' },
  },
  {
    name: 'google-ai',
    url: 'https://generativelanguage.googleapis.com',
    path: '/v1beta/models',
    envKey: 'GOOGLE_AI_API_KEY',
    authHeader: null,
    queryParam: 'key',
  },
];

/**
 * Pings an LLM provider's models endpoint.
 * @param {Object} provider
 * @returns {Promise<{name, available, latencyMs, status, modelCount, error}>}
 */
async function pingProvider(provider) {
  const apiKey = process.env[provider.envKey];
  if (!apiKey) {
    return { name: provider.name, available: false, latencyMs: 0, status: 0, modelCount: 0, error: 'no api key configured' };
  }

  const start = Date.now();
  const lib = https;
  const headers = { 'Content-Type': 'application/json' };

  if (provider.authHeader) {
    headers[provider.authHeader] = (provider.authPrefix || '') + apiKey;
  }
  if (provider.extraHeaders) Object.assign(headers, provider.extraHeaders);

  const path = provider.queryParam ? `${provider.path}?${provider.queryParam}=${apiKey}` : provider.path;

  return new Promise((resolve) => {
    const req = https.get({
      hostname: new URL(provider.url).hostname,
      path,
      headers,
      timeout: 8000,
    }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => {
        const latencyMs = Date.now() - start;
        let modelCount = 0;
        try {
          const parsed = JSON.parse(body);
          modelCount = (parsed.data || parsed.models || []).length;
        } catch { /* ok */ }
        resolve({
          name: provider.name,
          available: res.statusCode >= 200 && res.statusCode < 400,
          latencyMs,
          status: res.statusCode,
          modelCount,
        });
      });
    });
    req.on('error', (err) => resolve({ name: provider.name, available: false, latencyMs: Date.now() - start, status: 0, error: err.message }));
    req.on('timeout', () => { req.destroy(); resolve({ name: provider.name, available: false, latencyMs: 8000, status: 0, error: 'timeout' }); });
  });
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Check health of all configured LLM providers.
   * @returns {Promise<Object>}
   */
  async function checkProviderHealth() {
    logger.debug('[brain-providers] checking LLM provider health');

    const providers = context.providers || PROVIDERS;
    const results = await Promise.allSettled(providers.map((p) => pingProvider(p)));

    const checks = results.map((r, i) =>
      r.status === 'fulfilled' ? r.value : { name: providers[i].name, available: false, error: r.reason?.message }
    );

    const available = checks.filter((c) => c.available).length;
    const unavailable = checks.filter((c) => !c.available).length;

    if (unavailable > 0) {
      logger.warn(`[brain-providers] ${unavailable} provider(s) unavailable`, {
        providers: checks.filter((c) => !c.available).map((c) => c.name),
      });
    } else {
      logger.info(`[brain-providers] all ${available} provider(s) healthy`);
    }

    // Sort by latency ascending for routing recommendations
    const sortedByLatency = [...checks].filter((c) => c.available).sort((a, b) => a.latencyMs - b.latencyMs);

    return {
      domain,
      check: 'provider-health',
      total: checks.length,
      available,
      unavailable,
      primaryProvider: sortedByLatency[0]?.name || null,
      fallbackProvider: sortedByLatency[1]?.name || null,
      providers: checks,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Track and report LLM routing recommendations based on availability and latency.
   * @returns {Promise<Object>}
   */
  async function computeRoutingRecommendations() {
    logger.debug('[brain-providers] computing routing recommendations');

    // Re-run health checks to get fresh latency data
    const results = await Promise.allSettled(PROVIDERS.map((p) => pingProvider(p)));
    const checks = results.map((r, i) =>
      r.status === 'fulfilled' ? r.value : { name: PROVIDERS[i].name, available: false, error: r.reason?.message }
    );

    const available = checks.filter((c) => c.available).sort((a, b) => a.latencyMs - b.latencyMs);

    const routing = {
      primary: null,
      fallbacks: [],
      strategy: 'latency-weighted',
    };

    if (available.length > 0) {
      routing.primary = {
        provider: available[0].name,
        latencyMs: available[0].latencyMs,
        models: available[0].modelCount,
      };
      routing.fallbacks = available.slice(1).map((p) => ({
        provider: p.name,
        latencyMs: p.latencyMs,
      }));
    }

    return {
      domain,
      check: 'routing-recommendations',
      routing,
      available: available.length,
      total: checks.length,
    };
  }

  /**
   * Monitor token usage and budget for configured providers.
   * @returns {Promise<Object>}
   */
  async function monitorTokenBudget() {
    // This reads from an optional budget tracking file or env vars
    const budgetConfig = context.tokenBudget || {};
    const dailyLimit = budgetConfig.dailyTokenLimit || parseInt(process.env.DAILY_TOKEN_LIMIT || '100000', 10);
    const usedToday = budgetConfig.usedToday || parseInt(process.env.TOKENS_USED_TODAY || '0', 10);

    const percentUsed = dailyLimit > 0 ? (usedToday / dailyLimit) * 100 : 0;
    const remaining = Math.max(0, dailyLimit - usedToday);
    const critical = percentUsed >= 90;
    const warning = percentUsed >= 75;

    if (critical) {
      logger.warn(`[brain-providers] token budget critical: ${percentUsed.toFixed(1)}% used`);
    } else if (warning) {
      logger.warn(`[brain-providers] token budget warning: ${percentUsed.toFixed(1)}% used`);
    }

    return {
      domain,
      check: 'token-budget',
      dailyLimit,
      usedToday,
      remaining,
      percentUsed: Math.round(percentUsed * 10) / 10,
      status: critical ? 'critical' : warning ? 'warning' : 'ok',
    };
  }

  checkProviderHealth.workerName = 'checkProviderHealth';
  checkProviderHealth.domain = domain;
  checkProviderHealth.priority = priority;

  computeRoutingRecommendations.workerName = 'computeRoutingRecommendations';
  computeRoutingRecommendations.domain = domain;
  computeRoutingRecommendations.priority = priority;

  monitorTokenBudget.workerName = 'monitorTokenBudget';
  monitorTokenBudget.domain = domain;
  monitorTokenBudget.priority = priority;

  return [checkProviderHealth, computeRoutingRecommendations, monitorTokenBudget];
}

module.exports = { domain, description, priority, getWork };
