'use strict';

/**
 * @fileoverview Config bee — configuration management, validation, and drift detection.
 * @module bees/config-bee
 */

const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

const domain = 'config';
const description = 'Configuration management: validation, schema enforcement, drift detection, hot-reload';
const priority = 0.85;

/**
 * Supported config file formats and their parsers.
 */
const PARSERS = {
  '.json': JSON.parse,
  '.js': (src, filePath) => {
    delete require.cache[require.resolve(filePath)];
    return require(filePath);
  },
};

/**
 * Loads a config file from disk.
 * @param {string} filePath
 * @returns {{config: Object|null, error: string|null}}
 */
function loadConfig(filePath) {
  const ext = path.extname(filePath);
  if (!fs.existsSync(filePath)) return { config: null, error: 'file not found' };

  try {
    const src = fs.readFileSync(filePath, 'utf8');
    const parser = PARSERS[ext];
    if (!parser) return { config: null, error: `unsupported format: ${ext}` };

    const config = ext === '.js' ? parser(src, filePath) : parser(src);
    return { config, error: null };
  } catch (err) {
    return { config: null, error: err.message };
  }
}

/**
 * Validates a config object against a simple schema.
 * @param {Object} config
 * @param {Object} schema - { fieldName: { type, required, default } }
 * @returns {{valid: boolean, errors: string[], warnings: string[]}}
 */
function validateSchema(config, schema) {
  const errors = [];
  const warnings = [];

  for (const [field, rules] of Object.entries(schema)) {
    const value = config[field];
    const missing = value === undefined || value === null;

    if (rules.required && missing) {
      errors.push(`Required field '${field}' is missing`);
      continue;
    }

    if (!missing && rules.type) {
      const actual = typeof value;
      const expected = rules.type;
      if (actual !== expected && !(expected === 'array' && Array.isArray(value))) {
        errors.push(`Field '${field}' should be ${expected} but got ${actual}`);
      }
    }

    if (missing && rules.default !== undefined) {
      warnings.push(`Field '${field}' missing, default will be used: ${JSON.stringify(rules.default)}`);
    }
  }

  return { valid: errors.length === 0, errors, warnings };
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Load and validate configuration files.
   * @returns {Promise<Object>}
   */
  async function validateConfigurations() {
    const configFiles = context.configFiles || [
      path.join(process.cwd(), 'config.json'),
      path.join(process.cwd(), 'config', 'default.json'),
      path.join(process.cwd(), 'package.json'),
    ];

    logger.debug(`[config] validating ${configFiles.length} config file(s)`);

    const results = [];
    for (const filePath of configFiles) {
      const { config, error } = loadConfig(filePath);
      if (error) {
        results.push({ file: filePath, status: 'error', error });
        continue;
      }

      const schema = context.schemas?.[path.basename(filePath)] || {};
      const validation = validateSchema(config, schema);

      results.push({
        file: filePath,
        status: validation.valid ? 'valid' : 'invalid',
        errors: validation.errors,
        warnings: validation.warnings,
        keys: Object.keys(config || {}).length,
      });
    }

    const invalid = results.filter((r) => r.status === 'invalid');
    if (invalid.length > 0) {
      logger.warn(`[config] ${invalid.length} invalid config(s)`, { files: invalid.map((r) => r.file) });
    }

    return {
      domain,
      check: 'config-validation',
      total: results.length,
      valid: results.filter((r) => r.status === 'valid').length,
      invalid: invalid.length,
      errors: results.filter((r) => r.status === 'error').length,
      results,
    };
  }

  /**
   * Detect configuration drift by comparing current config against a baseline.
   * @returns {Promise<Object>}
   */
  async function detectConfigDrift() {
    const baselinePath = context.baselinePath || path.join(process.cwd(), '.config-baseline.json');
    const currentConfig = context.currentConfig || {};

    if (!fs.existsSync(baselinePath)) {
      // Write current config as baseline
      try {
        fs.writeFileSync(baselinePath, JSON.stringify(currentConfig, null, 2), 'utf8');
        logger.info('[config] created config baseline');
      } catch (err) {
        logger.warn(`[config] could not write baseline: ${err.message}`);
      }
      return { domain, check: 'config-drift', drifted: false, reason: 'baseline created' };
    }

    const { config: baseline } = loadConfig(baselinePath);
    if (!baseline) {
      return { domain, check: 'config-drift', drifted: false, reason: 'could not load baseline' };
    }

    const drifts = [];

    function diff(a, b, prefix = '') {
      const keys = new Set([...Object.keys(a || {}), ...Object.keys(b || {})]);
      for (const key of keys) {
        const fullKey = prefix ? `${prefix}.${key}` : key;
        const aVal = a?.[key];
        const bVal = b?.[key];
        if (typeof aVal === 'object' && typeof bVal === 'object' && aVal && bVal) {
          diff(aVal, bVal, fullKey);
        } else if (JSON.stringify(aVal) !== JSON.stringify(bVal)) {
          drifts.push({ key: fullKey, baseline: aVal, current: bVal });
        }
      }
    }

    diff(baseline, currentConfig);

    if (drifts.length > 0) {
      logger.warn(`[config] ${drifts.length} config drift(s) detected`);
    }

    return {
      domain,
      check: 'config-drift',
      drifted: drifts.length > 0,
      driftCount: drifts.length,
      drifts: drifts.slice(0, 50),
    };
  }

  /**
   * Ensure required environment variables are set and correctly formatted.
   * @returns {Promise<Object>}
   */
  async function validateEnvironmentConfig() {
    const rules = context.envRules || [
      { key: 'NODE_ENV', required: false, enum: ['development', 'staging', 'production', 'test'] },
      { key: 'PORT', required: false, type: 'number', min: 1024, max: 65535 },
      { key: 'LOG_LEVEL', required: false, enum: ['debug', 'info', 'warn', 'error'] },
    ];

    const violations = [];
    const checks = [];

    for (const rule of rules) {
      const val = process.env[rule.key];
      const missing = val === undefined || val === '';

      if (rule.required && missing) {
        violations.push({ key: rule.key, issue: 'required but missing' });
        checks.push({ key: rule.key, pass: false, issue: 'required but missing' });
        continue;
      }

      if (!missing) {
        if (rule.enum && !rule.enum.includes(val)) {
          violations.push({ key: rule.key, value: val, issue: `must be one of: ${rule.enum.join(', ')}` });
          checks.push({ key: rule.key, pass: false, issue: `invalid value: ${val}` });
          continue;
        }
        if (rule.type === 'number') {
          const num = parseFloat(val);
          if (isNaN(num) || (rule.min !== undefined && num < rule.min) || (rule.max !== undefined && num > rule.max)) {
            violations.push({ key: rule.key, value: val, issue: `must be number in range [${rule.min}, ${rule.max}]` });
            checks.push({ key: rule.key, pass: false, issue: 'out of range' });
            continue;
          }
        }
      }

      checks.push({ key: rule.key, pass: true, value: missing ? undefined : val });
    }

    return {
      domain,
      check: 'env-config',
      total: rules.length,
      passed: checks.filter((c) => c.pass).length,
      violations: violations.length,
      valid: violations.length === 0,
      checks,
      violations,
    };
  }

  validateConfigurations.workerName = 'validateConfigurations';
  validateConfigurations.domain = domain;
  validateConfigurations.priority = priority;

  detectConfigDrift.workerName = 'detectConfigDrift';
  detectConfigDrift.domain = domain;
  detectConfigDrift.priority = priority;

  validateEnvironmentConfig.workerName = 'validateEnvironmentConfig';
  validateEnvironmentConfig.domain = domain;
  validateEnvironmentConfig.priority = priority;

  return [validateConfigurations, detectConfigDrift, validateEnvironmentConfig];
}

module.exports = { domain, description, priority, getWork };
