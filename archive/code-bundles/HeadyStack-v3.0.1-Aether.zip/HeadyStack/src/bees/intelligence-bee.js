'use strict';

/**
 * @fileoverview Intelligence bee — pattern recognition, anomaly detection, and analysis.
 * @module bees/intelligence-bee
 */

const logger = require('../utils/logger');

const domain = 'intelligence';
const description = 'Pattern recognition, anomaly detection, trend analysis, and predictive intelligence';
const priority = 0.82;

/**
 * Computes mean of an array.
 * @param {number[]} arr
 * @returns {number}
 */
function mean(arr) {
  return arr.length === 0 ? 0 : arr.reduce((s, v) => s + v, 0) / arr.length;
}

/**
 * Computes standard deviation.
 * @param {number[]} arr
 * @param {number} [m]
 * @returns {number}
 */
function stdDev(arr, m) {
  if (arr.length < 2) return 0;
  const mu = m !== undefined ? m : mean(arr);
  const variance = arr.reduce((s, v) => s + Math.pow(v - mu, 2), 0) / arr.length;
  return Math.sqrt(variance);
}

/**
 * Detects anomalies using Z-score method (|z| > threshold).
 * @param {number[]} values
 * @param {number} [zThreshold=2.5]
 * @returns {Array<{index, value, zScore}>}
 */
function detectAnomalies(values, zThreshold = 2.5) {
  const mu = mean(values);
  const sigma = stdDev(values, mu);
  if (sigma === 0) return [];

  return values
    .map((v, i) => ({ index: i, value: v, zScore: Math.abs((v - mu) / sigma) }))
    .filter((a) => a.zScore > zThreshold);
}

/**
 * Computes a simple linear trend (slope + intercept).
 * @param {number[]} values
 * @returns {{slope: number, intercept: number, direction: string}}
 */
function computeTrend(values) {
  const n = values.length;
  if (n < 2) return { slope: 0, intercept: values[0] || 0, direction: 'flat' };

  const xs = Array.from({ length: n }, (_, i) => i);
  const meanX = mean(xs);
  const meanY = mean(values);

  let numerator = 0;
  let denominator = 0;
  for (let i = 0; i < n; i++) {
    numerator += (xs[i] - meanX) * (values[i] - meanY);
    denominator += Math.pow(xs[i] - meanX, 2);
  }

  const slope = denominator === 0 ? 0 : numerator / denominator;
  const intercept = meanY - slope * meanX;
  const direction = slope > 0.01 ? 'rising' : slope < -0.01 ? 'falling' : 'flat';

  return { slope: Math.round(slope * 1000) / 1000, intercept: Math.round(intercept * 1000) / 1000, direction };
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Analyze time-series data for anomalies and trends.
   * @returns {Promise<Object>}
   */
  async function analyzeTimeSeries() {
    const series = context.timeSeries || context.data || [];
    if (series.length === 0) {
      return { domain, check: 'time-series-analysis', skipped: true, reason: 'no time-series data provided' };
    }

    const values = series.map((v) => typeof v === 'number' ? v : (v.value || v.y || 0));
    logger.debug(`[intelligence] analyzing ${values.length}-point time series`);

    const mu = mean(values);
    const sigma = stdDev(values, mu);
    const trend = computeTrend(values);
    const anomalies = detectAnomalies(values, context.zThreshold || 2.5);
    const minVal = Math.min(...values);
    const maxVal = Math.max(...values);

    return {
      domain,
      check: 'time-series-analysis',
      dataPoints: values.length,
      statistics: {
        mean: Math.round(mu * 1000) / 1000,
        stdDev: Math.round(sigma * 1000) / 1000,
        min: minVal,
        max: maxVal,
        range: maxVal - minVal,
      },
      trend,
      anomalies: {
        count: anomalies.length,
        points: anomalies.slice(0, 20),
      },
      insights: [
        trend.direction !== 'flat' ? `Trend is ${trend.direction} (slope: ${trend.slope})` : 'Trend is flat',
        anomalies.length > 0 ? `${anomalies.length} anomaly/ies detected` : 'No anomalies detected',
        sigma / mu > 0.3 ? 'High variance — consider smoothing' : 'Variance is within normal range',
      ].filter(Boolean),
    };
  }

  /**
   * Identify patterns in event logs or structured data.
   * @returns {Promise<Object>}
   */
  async function identifyPatterns() {
    const events = context.events || [];
    if (events.length === 0) {
      return { domain, check: 'pattern-identification', skipped: true, reason: 'no events provided' };
    }

    logger.debug(`[intelligence] identifying patterns in ${events.length} events`);

    // Frequency analysis
    const frequencies = new Map();
    for (const event of events) {
      const key = event.type || event.category || event.name || JSON.stringify(event).slice(0, 30);
      frequencies.set(key, (frequencies.get(key) || 0) + 1);
    }

    // Time clustering (if events have timestamps)
    const withTimestamps = events.filter((e) => e.timestamp || e.ts || e.time);
    let clusters = [];
    if (withTimestamps.length > 0) {
      const times = withTimestamps.map((e) => new Date(e.timestamp || e.ts || e.time).getTime());
      const sortedTimes = [...times].sort((a, b) => a - b);

      // Detect bursts: intervals significantly shorter than median
      const intervals = sortedTimes.slice(1).map((t, i) => t - sortedTimes[i]);
      const medianInterval = intervals.sort((a, b) => a - b)[Math.floor(intervals.length / 2)] || 1;
      const burstThreshold = medianInterval * 0.1;

      let clusterStart = 0;
      for (let i = 1; i < sortedTimes.length; i++) {
        if (sortedTimes[i] - sortedTimes[i - 1] > burstThreshold * 10) {
          clusters.push({ start: new Date(sortedTimes[clusterStart]).toISOString(), count: i - clusterStart });
          clusterStart = i;
        }
      }
      clusters.push({ start: new Date(sortedTimes[clusterStart]).toISOString(), count: sortedTimes.length - clusterStart });
    }

    const topPatterns = Array.from(frequencies.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([key, count]) => ({ pattern: key, count, frequency: Math.round((count / events.length) * 100) }));

    return {
      domain,
      check: 'pattern-identification',
      totalEvents: events.length,
      uniquePatterns: frequencies.size,
      topPatterns,
      temporalClusters: clusters.length,
      clusters: clusters.slice(0, 10),
    };
  }

  /**
   * Generate predictive insights from historical data.
   * @returns {Promise<Object>}
   */
  async function generatePredictiveInsights() {
    const historicalData = context.historicalData || context.timeSeries || [];
    if (historicalData.length < 5) {
      return { domain, check: 'predictive-insights', skipped: true, reason: 'insufficient historical data (need >= 5 points)' };
    }

    const values = historicalData.map((v) => typeof v === 'number' ? v : (v.value || 0));
    const trend = computeTrend(values);
    const lastN = values.slice(-5);
    const recentMean = mean(lastN);
    const overallMean = mean(values);

    // Predict next N values using linear extrapolation
    const forecastSteps = context.forecastSteps || 5;
    const n = values.length;
    const forecast = Array.from({ length: forecastSteps }, (_, i) =>
      Math.round((trend.intercept + trend.slope * (n + i)) * 100) / 100
    );

    const momentum = recentMean > overallMean ? 'accelerating' : recentMean < overallMean * 0.9 ? 'decelerating' : 'stable';

    return {
      domain,
      check: 'predictive-insights',
      dataPoints: values.length,
      trend: trend.direction,
      momentum,
      currentMean: Math.round(overallMean * 100) / 100,
      recentMean: Math.round(recentMean * 100) / 100,
      forecast,
      forecastSteps,
      confidence: values.length >= 20 ? 'high' : values.length >= 10 ? 'medium' : 'low',
    };
  }

  analyzeTimeSeries.workerName = 'analyzeTimeSeries';
  analyzeTimeSeries.domain = domain;
  analyzeTimeSeries.priority = priority;

  identifyPatterns.workerName = 'identifyPatterns';
  identifyPatterns.domain = domain;
  identifyPatterns.priority = priority;

  generatePredictiveInsights.workerName = 'generatePredictiveInsights';
  generatePredictiveInsights.domain = domain;
  generatePredictiveInsights.priority = priority;

  return [analyzeTimeSeries, identifyPatterns, generatePredictiveInsights];
}

module.exports = { domain, description, priority, getWork };
