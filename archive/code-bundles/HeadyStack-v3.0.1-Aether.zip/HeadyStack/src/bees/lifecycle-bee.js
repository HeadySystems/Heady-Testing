'use strict';

/**
 * @fileoverview Lifecycle bee — manages graceful shutdown/startup, process signals, cleanup.
 * @module bees/lifecycle-bee
 */

const logger = require('../utils/logger');

const domain = 'lifecycle';
const description = 'Manages application lifecycle: graceful shutdown, startup validation, cleanup hooks';
const priority = 0.90;

/** Registry of cleanup callbacks */
const _cleanupHandlers = [];

/** Whether shutdown has been initiated */
let _shutdownInitiated = false;

/** Startup timestamp */
const _startedAt = Date.now();

/**
 * Registers a cleanup handler to run on shutdown.
 * @param {string} name
 * @param {Function} fn
 */
function registerCleanup(name, fn) {
  _cleanupHandlers.push({ name, fn });
  logger.debug(`[lifecycle] registered cleanup handler: ${name}`);
}

/**
 * Runs all registered cleanup handlers in order.
 * @param {number} [timeoutMs=10000]
 * @returns {Promise<Array<{name: string, success: boolean, error?: string}>>}
 */
async function runCleanupHandlers(timeoutMs = 10000) {
  const results = [];
  for (const { name, fn } of _cleanupHandlers) {
    try {
      await Promise.race([
        fn(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), timeoutMs)),
      ]);
      results.push({ name, success: true });
      logger.debug(`[lifecycle] cleanup '${name}' completed`);
    } catch (err) {
      results.push({ name, success: false, error: err.message });
      logger.error(`[lifecycle] cleanup '${name}' failed: ${err.message}`);
    }
  }
  return results;
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Report application uptime and startup health.
   * @returns {Promise<Object>}
   */
  async function reportStartupHealth() {
    const uptime = process.uptime();
    const uptimeMs = Date.now() - _startedAt;
    const nodeEnv = process.env.NODE_ENV || 'unknown';

    const startup = {
      domain,
      check: 'startup-health',
      pid: process.pid,
      uptime,
      uptimeMs,
      startedAt: new Date(_startedAt).toISOString(),
      nodeEnv,
      nodeVersion: process.version,
      shutdownInitiated: _shutdownInitiated,
      cleanupHandlers: _cleanupHandlers.length,
      status: _shutdownInitiated ? 'shutting-down' : uptime < 30 ? 'starting' : 'running',
    };

    logger.debug(`[lifecycle] startup health: ${startup.status}`, { uptime: `${uptime.toFixed(1)}s` });
    return startup;
  }

  /**
   * Validate that all required startup conditions are met.
   * @returns {Promise<Object>}
   */
  async function validateStartupConditions() {
    const conditions = [];

    // Check Node.js version meets minimum
    const [major] = process.versions.node.split('.').map(Number);
    conditions.push({
      name: 'node-version',
      pass: major >= 16,
      detail: `Node.js ${process.versions.node} (minimum: v16)`,
    });

    // Check memory is adequate
    const freeMemMB = require('os').freemem() / 1024 / 1024;
    conditions.push({
      name: 'available-memory',
      pass: freeMemMB > 128,
      detail: `${Math.round(freeMemMB)}MB free (minimum: 128MB)`,
    });

    // Check required env vars for startup
    const requiredEnv = context.requiredEnv || [];
    for (const key of requiredEnv) {
      conditions.push({
        name: `env:${key}`,
        pass: !!process.env[key],
        detail: process.env[key] ? 'present' : 'missing',
      });
    }

    // Check process isn't already shutting down
    conditions.push({
      name: 'not-shutting-down',
      pass: !_shutdownInitiated,
      detail: _shutdownInitiated ? 'shutdown in progress' : 'normal',
    });

    const failed = conditions.filter((c) => !c.pass);
    if (failed.length > 0) {
      logger.warn(`[lifecycle] ${failed.length} startup condition(s) failed`, { failed: failed.map((c) => c.name) });
    }

    return {
      domain,
      check: 'startup-conditions',
      total: conditions.length,
      passed: conditions.filter((c) => c.pass).length,
      failed: failed.length,
      ready: failed.length === 0,
      conditions,
    };
  }

  /**
   * Initiate a graceful shutdown sequence.
   * @returns {Promise<Object>}
   */
  async function initiateGracefulShutdown() {
    if (_shutdownInitiated) {
      return { domain, check: 'graceful-shutdown', status: 'already-initiated', skipped: true };
    }

    const gracePeriod = context.gracePeriodMs || 5000;
    _shutdownInitiated = true;
    logger.info(`[lifecycle] graceful shutdown initiated, grace period: ${gracePeriod}ms`);

    // If not actually shutting down (just a health check), revert after reporting
    const dryRun = context.dryRun !== false;

    const results = await runCleanupHandlers(gracePeriod);
    const failed = results.filter((r) => !r.success);

    if (!dryRun) {
      logger.info('[lifecycle] cleanup complete, exiting');
      setTimeout(() => process.exit(0), 100);
    } else {
      _shutdownInitiated = false;
    }

    return {
      domain,
      check: 'graceful-shutdown',
      status: dryRun ? 'dry-run' : 'initiated',
      cleanupHandlers: results.length,
      cleanupFailed: failed.length,
      gracePeriodMs: gracePeriod,
      results,
    };
  }

  reportStartupHealth.workerName = 'reportStartupHealth';
  reportStartupHealth.domain = domain;
  reportStartupHealth.priority = priority;

  validateStartupConditions.workerName = 'validateStartupConditions';
  validateStartupConditions.domain = domain;
  validateStartupConditions.priority = priority;

  initiateGracefulShutdown.workerName = 'initiateGracefulShutdown';
  initiateGracefulShutdown.domain = domain;
  initiateGracefulShutdown.priority = priority;

  return [reportStartupHealth, validateStartupConditions, initiateGracefulShutdown];
}

module.exports = { domain, description, priority, getWork, registerCleanup };
