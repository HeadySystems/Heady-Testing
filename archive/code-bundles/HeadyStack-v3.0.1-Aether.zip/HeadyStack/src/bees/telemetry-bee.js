'use strict';

/**
 * @fileoverview Telemetry bee — collects system metrics, event rates, and performance data.
 * @module bees/telemetry-bee
 */

const os = require('os');
const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

const domain = 'telemetry';
const description = 'Collects system metrics, event rates, latency histograms, and performance telemetry';
const priority = 0.78;

/** In-memory metrics accumulator */
const _metrics = {
  counters: new Map(),
  gauges: new Map(),
  histograms: new Map(),
  events: [],
};

/**
 * Increments a counter.
 * @param {string} name
 * @param {number} [value=1]
 */
function increment(name, value = 1) {
  _metrics.counters.set(name, (_metrics.counters.get(name) || 0) + value);
}

/**
 * Sets a gauge value.
 * @param {string} name
 * @param {number} value
 */
function gauge(name, value) {
  _metrics.gauges.set(name, value);
}

/**
 * Records a value into a histogram.
 * @param {string} name
 * @param {number} value
 */
function histogram(name, value) {
  if (!_metrics.histograms.has(name)) _metrics.histograms.set(name, []);
  const values = _metrics.histograms.get(name);
  values.push(value);
  if (values.length > 1000) values.shift(); // keep last 1000
}

/**
 * Computes percentile from a sorted array.
 * @param {number[]} sorted
 * @param {number} p
 * @returns {number}
 */
function percentile(sorted, p) {
  if (sorted.length === 0) return 0;
  const idx = Math.ceil(sorted.length * (p / 100)) - 1;
  return sorted[Math.min(idx, sorted.length - 1)];
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Collect OS and process performance metrics.
   * @returns {Promise<Object>}
   */
  async function collectSystemMetrics() {
    logger.debug('[telemetry] collecting system metrics');

    const cpus = os.cpus();
    const cpuTimes = cpus.reduce((acc, cpu) => {
      acc.user += cpu.times.user;
      acc.sys += cpu.times.sys;
      acc.idle += cpu.times.idle;
      return acc;
    }, { user: 0, sys: 0, idle: 0 });
    const cpuTotal = cpuTimes.user + cpuTimes.sys + cpuTimes.idle;
    const cpuUsagePct = cpuTotal > 0 ? ((cpuTimes.user + cpuTimes.sys) / cpuTotal) * 100 : 0;

    const mem = process.memoryUsage();
    const osMem = { free: os.freemem(), total: os.totalmem() };
    const memUsagePct = ((osMem.total - osMem.free) / osMem.total) * 100;

    // Update gauges
    gauge('cpu.usage_pct', cpuUsagePct);
    gauge('mem.heap_used_mb', mem.heapUsed / 1024 / 1024);
    gauge('mem.rss_mb', mem.rss / 1024 / 1024);
    gauge('os.mem_free_mb', osMem.free / 1024 / 1024);
    gauge('process.uptime_s', process.uptime());

    const metrics = {
      domain,
      check: 'system-metrics',
      cpu: {
        count: cpus.length,
        model: cpus[0]?.model || 'unknown',
        usagePct: Math.round(cpuUsagePct * 10) / 10,
        loadAvg: os.loadavg(),
      },
      memory: {
        heapUsedMB: Math.round(mem.heapUsed / 1024 / 1024),
        heapTotalMB: Math.round(mem.heapTotal / 1024 / 1024),
        rssMB: Math.round(mem.rss / 1024 / 1024),
        externalMB: Math.round(mem.external / 1024 / 1024),
        osFreeMemMB: Math.round(osMem.free / 1024 / 1024),
        osTotalMemMB: Math.round(osMem.total / 1024 / 1024),
        usagePct: Math.round(memUsagePct * 10) / 10,
      },
      process: {
        pid: process.pid,
        uptime: process.uptime(),
        nodeVersion: process.version,
        platform: process.platform,
      },
      timestamp: new Date().toISOString(),
    };

    return metrics;
  }

  /**
   * Export all accumulated metrics as a structured snapshot.
   * @returns {Promise<Object>}
   */
  async function exportMetricsSnapshot() {
    logger.debug('[telemetry] exporting metrics snapshot');

    const snapshot = {
      domain,
      check: 'metrics-snapshot',
      counters: Object.fromEntries(_metrics.counters),
      gauges: Object.fromEntries(_metrics.gauges),
      histograms: {},
      timestamp: new Date().toISOString(),
    };

    for (const [name, values] of _metrics.histograms) {
      const sorted = [...values].sort((a, b) => a - b);
      snapshot.histograms[name] = {
        count: sorted.length,
        min: sorted[0] ?? 0,
        max: sorted[sorted.length - 1] ?? 0,
        mean: sorted.length > 0 ? sorted.reduce((s, v) => s + v, 0) / sorted.length : 0,
        p50: percentile(sorted, 50),
        p90: percentile(sorted, 90),
        p99: percentile(sorted, 99),
      };
    }

    return snapshot;
  }

  /**
   * Write telemetry data to a local file for persistence.
   * @returns {Promise<Object>}
   */
  async function persistTelemetry() {
    const telemetryDir = context.telemetryDir || path.join(process.cwd(), 'data', 'telemetry');
    const retentionDays = context.retentionDays || 7;

    try {
      fs.mkdirSync(telemetryDir, { recursive: true });
    } catch (err) {
      return { domain, check: 'persist-telemetry', success: false, error: err.message };
    }

    const today = new Date().toISOString().split('T')[0];
    const filePath = path.join(telemetryDir, `metrics-${today}.ndjson`);

    const entry = {
      ts: new Date().toISOString(),
      counters: Object.fromEntries(_metrics.counters),
      gauges: Object.fromEntries(_metrics.gauges),
      pid: process.pid,
      uptime: process.uptime(),
    };

    try {
      fs.appendFileSync(filePath, JSON.stringify(entry) + '\n', 'utf8');
    } catch (err) {
      return { domain, check: 'persist-telemetry', success: false, error: err.message };
    }

    // Prune old files
    let pruned = 0;
    try {
      const cutoff = Date.now() - retentionDays * 86400000;
      const files = fs.readdirSync(telemetryDir);
      for (const f of files) {
        const fp = path.join(telemetryDir, f);
        if (fs.statSync(fp).mtimeMs < cutoff) {
          fs.unlinkSync(fp);
          pruned++;
        }
      }
    } catch { /* ok */ }

    return {
      domain,
      check: 'persist-telemetry',
      success: true,
      file: filePath,
      pruned,
      retentionDays,
    };
  }

  collectSystemMetrics.workerName = 'collectSystemMetrics';
  collectSystemMetrics.domain = domain;
  collectSystemMetrics.priority = priority;

  exportMetricsSnapshot.workerName = 'exportMetricsSnapshot';
  exportMetricsSnapshot.domain = domain;
  exportMetricsSnapshot.priority = priority;

  persistTelemetry.workerName = 'persistTelemetry';
  persistTelemetry.domain = domain;
  persistTelemetry.priority = priority;

  return [collectSystemMetrics, exportMetricsSnapshot, persistTelemetry];
}

module.exports = { domain, description, priority, getWork, increment, gauge, histogram };
