'use strict';

/**
 * @fileoverview Auto-discovering bee registry for HeadyStack.
 * Scans the bees directory for valid bee modules and exposes them
 * to the blast scheduler as work arrays.
 * @module bees/registry
 */

const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');
const {
  createBee,
  spawnBee,
  createWorkUnit,
  createFromTemplate,
  listDynamicBees,
  dissolveBee,
} = require('./bee-factory');

/** @type {Map<string, Object>} domain -> bee module */
const _registry = new Map();

/** @type {boolean} */
let _discovered = false;

/** @type {string} */
const BEES_DIR = path.resolve(__dirname);

/** Files to skip during auto-discovery */
const SKIP_FILES = new Set([
  'registry.js',
  'bee-factory.js',
  'bee-template.js',
  'index.js',
]);

/**
 * Checks if a loaded module looks like a valid bee module.
 * @param {*} mod
 * @returns {boolean}
 */
function _isValidBee(mod) {
  return (
    mod &&
    typeof mod === 'object' &&
    typeof mod.domain === 'string' &&
    mod.domain.length > 0 &&
    typeof mod.getWork === 'function'
  );
}

/**
 * Scans the bees directory and registers all valid bee modules.
 * Safe to call multiple times — subsequent calls refresh the registry.
 * @returns {Map<string, Object>} The populated registry
 */
function discover() {
  _registry.clear();

  let files;
  try {
    files = fs.readdirSync(BEES_DIR).filter((f) => f.endsWith('.js') && !SKIP_FILES.has(f));
  } catch (err) {
    logger.error(`[registry] failed to read bees directory: ${err.message}`);
    return _registry;
  }

  for (const file of files) {
    const filePath = path.join(BEES_DIR, file);
    try {
      // Clear from require cache to allow hot reload
      delete require.cache[require.resolve(filePath)];
      const mod = require(filePath);

      // Modules may export directly or as module.exports default
      const bee = _isValidBee(mod) ? mod : (_isValidBee(mod.default) ? mod.default : null);

      if (!bee) {
        logger.debug(`[registry] skipping ${file}: no valid bee export`);
        continue;
      }

      if (_registry.has(bee.domain)) {
        logger.warn(`[registry] duplicate domain '${bee.domain}' from ${file} — overwriting`);
      }

      _registry.set(bee.domain, {
        domain: bee.domain,
        description: bee.description || `Bee: ${bee.domain}`,
        priority: typeof bee.priority === 'number' ? bee.priority : 0.8,
        meta: bee.meta || {},
        getWork: bee.getWork,
        sourceFile: file,
        loadedAt: new Date().toISOString(),
      });

      logger.debug(`[registry] registered '${bee.domain}' from ${file}`);
    } catch (err) {
      logger.error(`[registry] failed to load ${file}: ${err.message}`, { stack: err.stack });
    }
  }

  // Also register any live dynamic bees
  for (const dynBee of listDynamicBees()) {
    if (!_registry.has(dynBee.domain)) {
      const { _dynamicRegistry } = require('./bee-factory');
      const fullBee = _dynamicRegistry.get(dynBee.domain);
      if (fullBee) {
        _registry.set(fullBee.domain, {
          domain: fullBee.domain,
          description: fullBee.description,
          priority: fullBee.priority,
          meta: {},
          getWork: fullBee.getWork,
          sourceFile: '<dynamic>',
          loadedAt: fullBee.createdAt,
        });
      }
    }
  }

  _discovered = true;
  logger.info(`[registry] discovery complete`, { domains: _registry.size });
  return _registry;
}

/**
 * Returns work arrays for a specific domain.
 * Auto-discovers if not yet run.
 * @param {string} domain
 * @param {Object} [context={}]
 * @returns {Array<Function>} Array of async work functions
 */
function getWork(domain, context = {}) {
  if (!_discovered) discover();

  const bee = _registry.get(domain);
  if (!bee) {
    logger.warn(`[registry] getWork: domain '${domain}' not found`);
    return [];
  }

  try {
    return bee.getWork(context);
  } catch (err) {
    logger.error(`[registry] getWork error for '${domain}': ${err.message}`);
    return [];
  }
}

/**
 * Lists all registered domains with metadata.
 * @returns {Array<Object>}
 */
function listDomains() {
  if (!_discovered) discover();

  return Array.from(_registry.values()).map((bee) => ({
    domain: bee.domain,
    description: bee.description,
    priority: bee.priority,
    sourceFile: bee.sourceFile,
    loadedAt: bee.loadedAt,
    meta: bee.meta,
  }));
}

/**
 * Returns all work from all registered domains.
 * @param {Object} [context={}]
 * @returns {Array<Function>}
 */
function getAllWork(context = {}) {
  if (!_discovered) discover();

  const allWork = [];
  for (const [domain, bee] of _registry) {
    try {
      const work = bee.getWork(context);
      allWork.push(...work);
    } catch (err) {
      logger.error(`[registry] getAllWork error for '${domain}': ${err.message}`);
    }
  }

  // Sort by priority descending
  allWork.sort((a, b) => (b.priority || 0) - (a.priority || 0));
  logger.debug(`[registry] getAllWork: collected ${allWork.length} work units`);
  return allWork;
}

/**
 * Returns health/discovery statistics.
 * @returns {Object}
 */
function getHealth() {
  if (!_discovered) discover();

  const domains = Array.from(_registry.values());
  return {
    discovered: _discovered,
    totalDomains: domains.length,
    beesDir: BEES_DIR,
    domains: domains.map((d) => ({
      domain: d.domain,
      priority: d.priority,
      source: d.sourceFile,
    })),
    timestamp: new Date().toISOString(),
  };
}

module.exports = {
  discover,
  getWork,
  listDomains,
  getAllWork,
  getHealth,
  // Re-export factory functions so consumers can import everything from registry
  createBee,
  spawnBee,
  createWorkUnit,
  createFromTemplate,
  listDynamicBees,
  dissolveBee,
};
