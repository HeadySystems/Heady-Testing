'use strict';

/**
 * @fileoverview Security bee — secrets detection, vulnerability checks, dependency auditing.
 * @module bees/security-bee
 */

const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
const logger = require('../utils/logger');

const execFileAsync = promisify(execFile);

const domain = 'security';
const description = 'Runs security scans: secrets detection, vulnerability checks, dependency auditing';
const priority = 0.92;

/** Patterns that indicate potential secrets in source files */
const SECRET_PATTERNS = [
  { name: 'AWS Access Key',      pattern: /AKIA[0-9A-Z]{16}/g },
  { name: 'AWS Secret Key',      pattern: /(?:aws.?secret|AWS_SECRET)[^\n]{0,20}['"=]([A-Za-z0-9/+]{40})/gi },
  { name: 'Private Key Header',  pattern: /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/g },
  { name: 'Generic API Key',     pattern: /(?:api[_-]?key|apikey)\s*[=:]\s*['"]?[A-Za-z0-9_\-]{20,}/gi },
  { name: 'Bearer Token',        pattern: /Bearer\s+[A-Za-z0-9._\-]{20,}/g },
  { name: 'Google API Key',      pattern: /AIza[0-9A-Za-z_\-]{35}/g },
  { name: 'Stripe Secret Key',   pattern: /sk_(?:live|test)_[0-9a-zA-Z]{24}/g },
  { name: 'GitHub Token',        pattern: /(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36}/g },
  { name: 'JWT Token',           pattern: /eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+/g },
  { name: 'Password in code',    pattern: /(?:password|passwd|pwd)\s*[=:]\s*['"][^'"]{6,}['"]/gi },
];

/** Extensions to scan for secrets */
const SCAN_EXTENSIONS = new Set(['.js', '.ts', '.json', '.env', '.yaml', '.yml', '.sh', '.py', '.rb', '.go']);

/** Paths to always skip */
const SKIP_DIRS = new Set(['node_modules', '.git', 'dist', 'build', '.next', 'coverage', 'vendor']);

/**
 * Recursively collects files for scanning.
 * @param {string} dir
 * @param {string[]} [results=[]]
 * @returns {string[]}
 */
function collectFiles(dir, results = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return results;
  }
  for (const entry of entries) {
    if (SKIP_DIRS.has(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      collectFiles(full, results);
    } else if (SCAN_EXTENSIONS.has(path.extname(entry.name))) {
      results.push(full);
    }
  }
  return results;
}

/**
 * Scans a single file for secret patterns.
 * @param {string} filePath
 * @returns {Array<{file, patternName, line, snippet}>}
 */
function scanFileForSecrets(filePath) {
  let content;
  try {
    content = fs.readFileSync(filePath, 'utf8');
  } catch {
    return [];
  }

  const findings = [];
  const lines = content.split('\n');

  for (const { name: patternName, pattern } of SECRET_PATTERNS) {
    pattern.lastIndex = 0;
    let match;
    while ((match = pattern.exec(content)) !== null) {
      // Find line number
      const before = content.slice(0, match.index);
      const lineNum = before.split('\n').length;
      findings.push({
        file: filePath,
        patternName,
        line: lineNum,
        snippet: lines[lineNum - 1]?.trim().slice(0, 80) || '',
      });
    }
  }

  return findings;
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Scan workspace for hardcoded secrets.
   * @returns {Promise<Object>}
   */
  async function scanForSecrets() {
    const scanDir = context.scanDir || process.cwd();
    logger.debug(`[security] scanning for secrets in: ${scanDir}`);

    const files = collectFiles(scanDir);
    logger.debug(`[security] scanning ${files.length} files`);

    const allFindings = [];
    for (const file of files) {
      const findings = scanFileForSecrets(file);
      allFindings.push(...findings);
    }

    if (allFindings.length > 0) {
      logger.warn(`[security] found ${allFindings.length} potential secret(s)`, {
        count: allFindings.length,
        files: [...new Set(allFindings.map((f) => f.file))].length,
      });
    } else {
      logger.info('[security] no secrets detected');
    }

    return {
      domain,
      check: 'secrets',
      scannedFiles: files.length,
      findingsCount: allFindings.length,
      clean: allFindings.length === 0,
      findings: allFindings.slice(0, 50), // cap output
    };
  }

  /**
   * Run npm audit to detect known vulnerabilities.
   * @returns {Promise<Object>}
   */
  async function runDependencyAudit() {
    logger.debug('[security] running dependency vulnerability audit');
    const cwd = context.projectDir || process.cwd();

    // Check if package.json exists
    const pkgPath = path.join(cwd, 'package.json');
    if (!fs.existsSync(pkgPath)) {
      return { domain, check: 'dependency-audit', skipped: true, reason: 'no package.json found' };
    }

    try {
      const { stdout } = await execFileAsync('npm', ['audit', '--json', '--audit-level=moderate'], {
        cwd,
        timeout: 30000,
      });
      const report = JSON.parse(stdout);
      const vulns = report.metadata?.vulnerabilities || {};
      const total = Object.values(vulns).reduce((s, v) => s + v, 0);

      if (total > 0) {
        logger.warn(`[security] ${total} vulnerability/ies found`, vulns);
      }

      return {
        domain,
        check: 'dependency-audit',
        vulnerabilities: vulns,
        total,
        clean: total === 0,
        auditLevel: report.metadata?.auditLevel,
      };
    } catch (err) {
      // npm audit exits non-zero when vulns found; parse stdout anyway
      try {
        const report = JSON.parse(err.stdout || '{}');
        const vulns = report.metadata?.vulnerabilities || {};
        const total = Object.values(vulns).reduce((s, v) => s + v, 0);
        return { domain, check: 'dependency-audit', vulnerabilities: vulns, total, clean: total === 0 };
      } catch {
        return { domain, check: 'dependency-audit', error: err.message, clean: false };
      }
    }
  }

  /**
   * Check for dangerous file permissions and world-writable dirs.
   * @returns {Promise<Object>}
   */
  async function checkFilePermissions() {
    logger.debug('[security] checking file permissions');
    const checkPaths = context.checkPaths || [process.cwd()];
    const issues = [];

    for (const p of checkPaths) {
      try {
        const stat = fs.statSync(p);
        const mode = stat.mode & 0o777;
        // World-writable check
        if (mode & 0o002) {
          issues.push({ path: p, issue: 'world-writable', mode: mode.toString(8) });
        }
        // Executable .env files
        if (p.endsWith('.env') && (mode & 0o111)) {
          issues.push({ path: p, issue: 'executable .env file', mode: mode.toString(8) });
        }
      } catch {
        // skip unreadable paths
      }
    }

    return {
      domain,
      check: 'file-permissions',
      checkedPaths: checkPaths.length,
      issues,
      clean: issues.length === 0,
    };
  }

  scanForSecrets.workerName = 'scanForSecrets';
  scanForSecrets.domain = domain;
  scanForSecrets.priority = priority;

  runDependencyAudit.workerName = 'runDependencyAudit';
  runDependencyAudit.domain = domain;
  runDependencyAudit.priority = priority;

  checkFilePermissions.workerName = 'checkFilePermissions';
  checkFilePermissions.domain = domain;
  checkFilePermissions.priority = priority;

  return [scanForSecrets, runDependencyAudit, checkFilePermissions];
}

module.exports = { domain, description, priority, getWork };
