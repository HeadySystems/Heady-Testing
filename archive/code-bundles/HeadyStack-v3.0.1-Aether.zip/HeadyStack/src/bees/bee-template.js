'use strict';

/**
 * @fileoverview Base template generator for HeadyStack bee workers.
 * Provides a consistent structure for creating bee modules.
 * @module bees/bee-template
 */

const logger = require('../utils/logger');

/**
 * @typedef {Object} WorkerDescriptor
 * @property {string} name - Worker name
 * @property {Function} fn - Async worker function (context) => result
 */

/**
 * @typedef {Object} BeeConfig
 * @property {string} domain - Unique domain identifier
 * @property {string} [description] - Human-readable description
 * @property {number} [priority=0.8] - Execution priority 0-1
 * @property {WorkerDescriptor[]} [workers=[]] - Worker descriptors
 * @property {Object} [meta={}] - Additional metadata
 */

/**
 * @typedef {Object} BeeModule
 * @property {string} domain
 * @property {string} description
 * @property {number} priority
 * @property {Object} meta
 * @property {Function} getWork - (context) => Array<AsyncFunction>
 */

/**
 * Creates a bee module from a configuration object.
 * This is the canonical factory for all domain bee files.
 *
 * @param {BeeConfig} config - Bee configuration
 * @returns {BeeModule} A fully constructed bee module
 *
 * @example
 * const { createBeeModule } = require('./bee-template');
 * module.exports = createBeeModule({
 *   domain: 'my-domain',
 *   description: 'Does something useful',
 *   priority: 0.8,
 *   workers: [
 *     {
 *       name: 'doWork',
 *       fn: async (ctx) => ({ result: 'done', ctx }),
 *     },
 *   ],
 * });
 */
function createBeeModule(config) {
  if (!config || typeof config !== 'object') throw new Error('config is required');
  if (!config.domain || typeof config.domain !== 'string') throw new Error('config.domain is required');

  const domain = config.domain;
  const description = config.description || `Bee worker for domain: ${domain}`;
  const priority = typeof config.priority === 'number' ? Math.min(1, Math.max(0, config.priority)) : 0.8;
  const workers = Array.isArray(config.workers) ? config.workers : [];
  const meta = config.meta || {};

  /**
   * Returns an array of async work functions for the blast scheduler.
   * @param {Object} [context={}] - Runtime context passed to each worker
   * @returns {Array<AsyncFunction>}
   */
  function getWork(context = {}) {
    return workers.map(({ name, fn }) => {
      const work = async () => {
        const start = Date.now();
        logger.debug(`[${domain}] starting worker '${name}'`);
        try {
          const result = await fn({ ...context, domain, workerName: name });
          const ms = Date.now() - start;
          logger.info(`[${domain}] worker '${name}' completed`, { ms });
          return { domain, worker: name, success: true, ms, result };
        } catch (err) {
          const ms = Date.now() - start;
          logger.error(`[${domain}] worker '${name}' failed: ${err.message}`, { ms, stack: err.stack });
          return { domain, worker: name, success: false, ms, error: err.message };
        }
      };
      work.workerName = name;
      work.domain = domain;
      work.priority = priority;
      return work;
    });
  }

  return {
    domain,
    description,
    priority,
    meta,
    getWork,
  };
}

module.exports = { createBeeModule };
