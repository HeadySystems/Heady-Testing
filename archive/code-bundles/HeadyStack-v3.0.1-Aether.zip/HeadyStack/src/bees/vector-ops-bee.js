'use strict';

/**
 * @fileoverview Vector Ops bee — vector space operations, similarity search, index maintenance.
 * @module bees/vector-ops-bee
 */

const fs = require('fs');
const path = require('path');
const logger = require('../utils/logger');

const domain = 'vector-ops';
const description = 'Vector space operations: cosine similarity, index maintenance, nearest-neighbor search';
const priority = 0.79;

/**
 * Computes cosine similarity between two vectors.
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number} Similarity in [-1, 1]
 */
function cosineSimilarity(a, b) {
  if (a.length !== b.length || a.length === 0) return 0;
  let dot = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

/**
 * Computes Euclidean distance between two vectors.
 * @param {number[]} a
 * @param {number[]} b
 * @returns {number}
 */
function euclideanDistance(a, b) {
  if (a.length !== b.length) return Infinity;
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    sum += Math.pow(a[i] - b[i], 2);
  }
  return Math.sqrt(sum);
}

/**
 * L2-normalizes a vector.
 * @param {number[]} v
 * @returns {number[]}
 */
function l2Normalize(v) {
  const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
  if (norm === 0) return v;
  return v.map((x) => x / norm);
}

/**
 * Finds the k nearest neighbors using cosine similarity.
 * @param {number[]} query
 * @param {Array<{id: string|number, embedding: number[]}>} corpus
 * @param {number} [k=10]
 * @returns {Array<{id, similarity, rank}>}
 */
function knnSearch(query, corpus, k = 10) {
  const qNorm = l2Normalize(query);
  const scored = corpus
    .filter((item) => Array.isArray(item.embedding) && item.embedding.length === query.length)
    .map((item) => ({
      id: item.id,
      similarity: cosineSimilarity(qNorm, l2Normalize(item.embedding)),
    }))
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, k);

  return scored.map((s, i) => ({ ...s, rank: i + 1 }));
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Perform vector similarity searches on the memory store.
   * @returns {Promise<Object>}
   */
  async function runSimilaritySearches() {
    const queries = context.vectorQueries || [];
    if (queries.length === 0) {
      return { domain, check: 'similarity-search', skipped: true, reason: 'no queries provided' };
    }

    const memoryDir = context.memoryDir || path.join(process.cwd(), 'data', 'memory');
    let corpus = [];

    // Load all vectors from memory store
    if (fs.existsSync(memoryDir)) {
      for (const file of fs.readdirSync(memoryDir).filter((f) => f.endsWith('.json'))) {
        try {
          const raw = JSON.parse(fs.readFileSync(path.join(memoryDir, file), 'utf8'));
          const entries = Array.isArray(raw) ? raw : raw.entries || [];
          corpus.push(...entries.filter((e) => Array.isArray(e.embedding)));
        } catch { /* skip */ }
      }
    }

    logger.debug(`[vector-ops] searching ${corpus.length} vectors for ${queries.length} query/ies`);

    const results = queries.map((q) => ({
      query: q.id || 'query',
      results: knnSearch(q.embedding || [], corpus, q.k || 10),
    }));

    return {
      domain,
      check: 'similarity-search',
      corpusSize: corpus.length,
      queries: queries.length,
      results,
    };
  }

  /**
   * Maintain vector index: recompute norms, deduplicate, compact.
   * @returns {Promise<Object>}
   */
  async function maintainVectorIndex() {
    const memoryDir = context.memoryDir || path.join(process.cwd(), 'data', 'memory');
    logger.debug('[vector-ops] maintaining vector index');

    if (!fs.existsSync(memoryDir)) {
      return { domain, check: 'index-maintenance', skipped: true, reason: 'no memory directory' };
    }

    let totalEntries = 0;
    let withEmbeddings = 0;
    let duplicates = 0;
    let malformed = 0;
    const seen = new Set();

    for (const file of fs.readdirSync(memoryDir).filter((f) => f.endsWith('.json'))) {
      const filePath = path.join(memoryDir, file);
      try {
        const raw = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        const entries = Array.isArray(raw) ? raw : raw.entries || [];
        const cleaned = [];

        for (const entry of entries) {
          totalEntries++;

          // Check for duplicates
          const key = entry.id || JSON.stringify(entry).slice(0, 100);
          if (seen.has(key)) { duplicates++; continue; }
          seen.add(key);

          // Validate embedding
          if (Array.isArray(entry.embedding)) {
            if (entry.embedding.some((v) => typeof v !== 'number' || isNaN(v))) {
              malformed++;
              entry.embedding = entry.embedding.map((v) => typeof v === 'number' && !isNaN(v) ? v : 0);
            }
            withEmbeddings++;
          }

          // Normalize embedding in-place
          if (Array.isArray(entry.embedding) && entry.embedding.length > 0) {
            entry.embedding = l2Normalize(entry.embedding);
          }

          cleaned.push(entry);
        }

        if (context.dryRun !== true && (duplicates > 0 || malformed > 0)) {
          fs.writeFileSync(filePath, JSON.stringify(cleaned, null, 2), 'utf8');
        }
      } catch (err) {
        logger.warn(`[vector-ops] failed to process ${file}: ${err.message}`);
      }
    }

    return {
      domain,
      check: 'index-maintenance',
      totalEntries,
      withEmbeddings,
      duplicatesRemoved: duplicates,
      malformedFixed: malformed,
      dryRun: context.dryRun === true,
    };
  }

  /**
   * Compute vector space health statistics.
   * @returns {Promise<Object>}
   */
  async function computeVectorSpaceStats() {
    const vectors = context.vectors || [];
    if (vectors.length === 0) {
      return { domain, check: 'vector-space-stats', skipped: true, reason: 'no vectors provided' };
    }

    const dims = vectors.map((v) => (Array.isArray(v.embedding) ? v.embedding.length : 0));
    const uniqueDims = [...new Set(dims.filter((d) => d > 0))];
    const norms = vectors
      .filter((v) => Array.isArray(v.embedding))
      .map((v) => Math.sqrt(v.embedding.reduce((s, x) => s + x * x, 0)));

    const meanNorm = norms.length > 0 ? norms.reduce((s, n) => s + n, 0) / norms.length : 0;
    const maxNorm = norms.length > 0 ? Math.max(...norms) : 0;
    const minNorm = norms.length > 0 ? Math.min(...norms) : 0;

    return {
      domain,
      check: 'vector-space-stats',
      totalVectors: vectors.length,
      withEmbeddings: norms.length,
      dimensions: uniqueDims,
      dimensionConsistent: uniqueDims.length <= 1,
      norms: {
        mean: Math.round(meanNorm * 1000) / 1000,
        min: Math.round(minNorm * 1000) / 1000,
        max: Math.round(maxNorm * 1000) / 1000,
      },
      normalized: norms.every((n) => Math.abs(n - 1.0) < 0.01),
    };
  }

  runSimilaritySearches.workerName = 'runSimilaritySearches';
  runSimilaritySearches.domain = domain;
  runSimilaritySearches.priority = priority;

  maintainVectorIndex.workerName = 'maintainVectorIndex';
  maintainVectorIndex.domain = domain;
  maintainVectorIndex.priority = priority;

  computeVectorSpaceStats.workerName = 'computeVectorSpaceStats';
  computeVectorSpaceStats.domain = domain;
  computeVectorSpaceStats.priority = priority;

  return [runSimilaritySearches, maintainVectorIndex, computeVectorSpaceStats];
}

module.exports = { domain, description, priority, getWork, cosineSimilarity, euclideanDistance, l2Normalize, knnSearch };
