'use strict';

/**
 * @fileoverview Ops bee — system operations, disk management, log rotation, cleanup.
 * @module bees/ops-bee
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');
const { promisify } = require('util');
const logger = require('../utils/logger');

const execFileAsync = promisify(execFile);

const domain = 'ops';
const description = 'System operations: disk usage monitoring, log rotation, temp cleanup, process management';
const priority = 0.76;

/**
 * Recursively computes directory size in bytes.
 * @param {string} dir
 * @returns {number}
 */
function dirSize(dir) {
  let total = 0;
  try {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      try {
        if (entry.isDirectory()) {
          total += dirSize(full);
        } else {
          total += fs.statSync(full).size;
        }
      } catch { /* skip permission errors */ }
    }
  } catch { /* skip */ }
  return total;
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Monitor disk usage across configured paths.
   * @returns {Promise<Object>}
   */
  async function monitorDiskUsage() {
    const watchPaths = context.watchPaths || [process.cwd(), os.tmpdir()];
    logger.debug(`[ops] monitoring disk usage for ${watchPaths.length} path(s)`);

    const results = [];
    for (const p of watchPaths) {
      if (!fs.existsSync(p)) {
        results.push({ path: p, exists: false });
        continue;
      }

      const sizeMB = Math.round(dirSize(p) / 1024 / 1024 * 100) / 100;
      results.push({ path: p, sizeMB, exists: true });
    }

    // OS-level disk stats via df
    let diskStats = null;
    try {
      const { stdout } = await execFileAsync('df', ['-k', '/'], { timeout: 5000 });
      const lines = stdout.trim().split('\n');
      if (lines.length >= 2) {
        const parts = lines[1].split(/\s+/);
        diskStats = {
          total: Math.round(parseInt(parts[1]) / 1024),
          used: Math.round(parseInt(parts[2]) / 1024),
          available: Math.round(parseInt(parts[3]) / 1024),
          usagePercent: parts[4],
          unit: 'MB',
        };
      }
    } catch { /* df not available on all platforms */ }

    const highUsage = results.some((r) => r.sizeMB > 1000);
    if (highUsage) logger.warn('[ops] high disk usage detected', { paths: results });

    return {
      domain,
      check: 'disk-usage',
      paths: results,
      diskStats,
      healthy: !highUsage,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Rotate log files older than maxAgeDays.
   * @returns {Promise<Object>}
   */
  async function rotateLogFiles() {
    const logDirs = context.logDirs || [path.join(process.cwd(), 'logs')];
    const maxAgeDays = context.maxLogAgeDays || 7;
    const cutoff = Date.now() - maxAgeDays * 86400000;
    const rotated = [];
    const errors = [];

    for (const dir of logDirs) {
      if (!fs.existsSync(dir)) continue;
      let entries;
      try { entries = fs.readdirSync(dir); } catch { continue; }

      for (const file of entries) {
        if (!['.log', '.ndjson', '.jsonl'].includes(path.extname(file))) continue;
        const fp = path.join(dir, file);
        try {
          const stat = fs.statSync(fp);
          if (stat.mtimeMs < cutoff) {
            const archiveName = `${fp}.${new Date(stat.mtime).toISOString().split('T')[0]}.gz`;
            // Compress using gzip if available
            try {
              await execFileAsync('gzip', ['-k', fp], { timeout: 30000 });
              fs.unlinkSync(fp);
              rotated.push({ file: fp, archived: `${fp}.gz` });
            } catch {
              // gzip not available — just delete
              fs.unlinkSync(fp);
              rotated.push({ file: fp, archived: null, deleted: true });
            }
          }
        } catch (err) {
          errors.push({ file: fp, error: err.message });
        }
      }
    }

    logger.info(`[ops] rotated ${rotated.length} log file(s)`);
    return {
      domain,
      check: 'log-rotation',
      rotated: rotated.length,
      errors: errors.length,
      maxAgeDays,
      files: rotated,
    };
  }

  /**
   * Clean up temporary files and stale build artifacts.
   * @returns {Promise<Object>}
   */
  async function cleanTempFiles() {
    const tempDirs = context.tempDirs || [
      path.join(process.cwd(), '.tmp'),
      path.join(process.cwd(), 'tmp'),
    ];
    const maxAgeMinutes = context.maxTempAgeMinutes || 60;
    const cutoff = Date.now() - maxAgeMinutes * 60000;
    const cleaned = [];
    let freedBytes = 0;

    for (const dir of tempDirs) {
      if (!fs.existsSync(dir)) continue;
      let entries;
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { continue; }

      for (const entry of entries) {
        const fp = path.join(dir, entry.name);
        try {
          const stat = fs.statSync(fp);
          if (stat.mtimeMs < cutoff && !entry.isDirectory()) {
            freedBytes += stat.size;
            fs.unlinkSync(fp);
            cleaned.push(fp);
          }
        } catch { /* skip locked files */ }
      }
    }

    logger.info(`[ops] cleaned ${cleaned.length} temp file(s), freed ${Math.round(freedBytes / 1024)}KB`);

    return {
      domain,
      check: 'temp-cleanup',
      cleaned: cleaned.length,
      freedKB: Math.round(freedBytes / 1024),
      maxAgeMinutes,
      files: cleaned.slice(0, 50),
    };
  }

  monitorDiskUsage.workerName = 'monitorDiskUsage';
  monitorDiskUsage.domain = domain;
  monitorDiskUsage.priority = priority;

  rotateLogFiles.workerName = 'rotateLogFiles';
  rotateLogFiles.domain = domain;
  rotateLogFiles.priority = priority;

  cleanTempFiles.workerName = 'cleanTempFiles';
  cleanTempFiles.domain = domain;
  cleanTempFiles.priority = priority;

  return [monitorDiskUsage, rotateLogFiles, cleanTempFiles];
}

module.exports = { domain, description, priority, getWork };
