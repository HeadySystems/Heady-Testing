'use strict';

/**
 * @fileoverview Full Cloud Deploy Swarm bee — coordinates multi-platform deployments.
 * Orchestrates Cloud Run, GKE, Firebase, and static hosting in a single swarm.
 * @module bees/full-cloud-deploy-swarm-bee
 */

const { execFile } = require('child_process');
const { promisify } = require('util');
const logger = require('../utils/logger');

const execFileAsync = promisify(execFile);

const domain = 'full-cloud-deploy';
const description = 'Coordinates multi-platform cloud deployments: Cloud Run, GKE, Firebase, CDN';
const priority = 0.80;

/**
 * Attempts to execute a deployment step, returning success/failure.
 * @param {string} name
 * @param {Function} fn
 * @returns {Promise<{name: string, success: boolean, result?: any, error?: string, durationMs: number}>}
 */
async function tryStep(name, fn) {
  const start = Date.now();
  try {
    const result = await fn();
    return { name, success: true, result, durationMs: Date.now() - start };
  } catch (err) {
    return { name, success: false, error: err.message, durationMs: Date.now() - start };
  }
}

/**
 * @param {Object} [context={}]
 * @returns {Array<AsyncFunction>}
 */
function getWork(context = {}) {
  /**
   * Coordinate a full multi-platform cloud deployment swarm.
   * @returns {Promise<Object>}
   */
  async function coordinateFullCloudDeploy() {
    const platforms = context.platforms || ['cloud-run', 'firebase'];
    const project = context.project || process.env.GOOGLE_CLOUD_PROJECT;
    const region = context.region || 'us-central1';
    const image = context.image || process.env.CLOUD_RUN_IMAGE;
    const serviceName = context.serviceName || process.env.CLOUD_RUN_SERVICE || 'heady-service';

    logger.info(`[full-cloud-deploy] starting swarm deploy`, { platforms, project });

    const steps = [];

    if (platforms.includes('cloud-run') && image && project) {
      steps.push(await tryStep('cloud-run-deploy', async () => {
        const { stdout } = await execFileAsync('gcloud', [
          'run', 'deploy', serviceName,
          '--image', image,
          '--platform', 'managed',
          '--region', region,
          '--project', project,
          '--allow-unauthenticated',
          '--format', 'json',
        ], { timeout: 300000 });
        return JSON.parse(stdout);
      }));
    } else if (platforms.includes('cloud-run')) {
      steps.push({ name: 'cloud-run-deploy', success: false, error: 'missing image or project', durationMs: 0 });
    }

    if (platforms.includes('firebase')) {
      steps.push(await tryStep('firebase-deploy', async () => {
        const { stdout, stderr } = await execFileAsync('npx', ['firebase', 'deploy', '--non-interactive'], {
          cwd: context.projectDir || process.cwd(),
          timeout: 300000,
        });
        return { stdout: stdout.slice(0, 500), stderr: stderr.slice(0, 500) };
      }));
    }

    if (platforms.includes('gke')) {
      const namespace = context.k8sNamespace || 'default';
      const manifest = context.k8sManifest || 'k8s/deployment.yaml';
      steps.push(await tryStep('gke-deploy', async () => {
        const { stdout } = await execFileAsync('kubectl', ['apply', '-f', manifest, '-n', namespace], {
          timeout: 120000,
        });
        return { output: stdout.slice(0, 500) };
      }));
    }

    const successful = steps.filter((s) => s.success).length;
    const failed = steps.filter((s) => !s.success).length;
    const totalMs = steps.reduce((sum, s) => sum + s.durationMs, 0);

    if (failed > 0) {
      logger.warn(`[full-cloud-deploy] ${failed}/${steps.length} step(s) failed`);
    } else {
      logger.info(`[full-cloud-deploy] all ${steps.length} step(s) succeeded in ${totalMs}ms`);
    }

    return {
      domain,
      check: 'full-cloud-deploy',
      platforms,
      steps: steps.length,
      successful,
      failed,
      totalDurationMs: totalMs,
      deploymentId: `deploy-${Date.now()}`,
      results: steps,
      timestamp: new Date().toISOString(),
    };
  }

  /**
   * Run post-deploy smoke tests across all deployed platforms.
   * @returns {Promise<Object>}
   */
  async function runSmokeTests() {
    const http = require('http');
    const https = require('https');
    const endpoints = context.smokeTestEndpoints || [
      process.env.DEPLOYED_URL ? `${process.env.DEPLOYED_URL}/health` : null,
    ].filter(Boolean);

    logger.debug(`[full-cloud-deploy] running smoke tests on ${endpoints.length} endpoint(s)`);

    const results = await Promise.all(endpoints.map((url) => new Promise((resolve) => {
      const start = Date.now();
      const lib = url.startsWith('https') ? https : http;
      const req = lib.get(url, { timeout: 10000 }, (res) => {
        resolve({ url, status: res.statusCode, pass: res.statusCode < 400, latencyMs: Date.now() - start });
      });
      req.on('error', (err) => resolve({ url, pass: false, error: err.message, latencyMs: Date.now() - start }));
      req.on('timeout', () => { req.destroy(); resolve({ url, pass: false, error: 'timeout', latencyMs: 10000 }); });
    })));

    const passed = results.filter((r) => r.pass).length;
    return {
      domain,
      check: 'smoke-tests',
      total: results.length,
      passed,
      failed: results.length - passed,
      allPassed: passed === results.length && results.length > 0,
      results,
    };
  }

  /**
   * Rollback the last deployment using gcloud or kubectl.
   * @returns {Promise<Object>}
   */
  async function rollbackDeployment() {
    const strategy = context.rollbackStrategy || 'cloud-run';
    const serviceName = context.serviceName || process.env.CLOUD_RUN_SERVICE;
    const project = context.project || process.env.GOOGLE_CLOUD_PROJECT;
    const region = context.region || 'us-central1';

    logger.info(`[full-cloud-deploy] initiating rollback via ${strategy}`);

    if (strategy === 'cloud-run' && serviceName && project) {
      try {
        // Get revisions
        const { stdout } = await execFileAsync('gcloud', [
          'run', 'revisions', 'list',
          '--service', serviceName,
          '--region', region,
          '--project', project,
          '--format', 'json',
          '--limit', '3',
        ], { timeout: 30000 });

        const revisions = JSON.parse(stdout);
        if (revisions.length < 2) {
          return { domain, check: 'rollback', success: false, reason: 'no previous revision to roll back to' };
        }

        const previousRevision = revisions[1].metadata.name;
        await execFileAsync('gcloud', [
          'run', 'services', 'update-traffic', serviceName,
          '--to-revisions', `${previousRevision}=100`,
          '--region', region,
          '--project', project,
        ], { timeout: 60000 });

        logger.info(`[full-cloud-deploy] rolled back to ${previousRevision}`);
        return { domain, check: 'rollback', success: true, rolledBackTo: previousRevision, strategy };
      } catch (err) {
        return { domain, check: 'rollback', success: false, error: err.message };
      }
    }

    return { domain, check: 'rollback', skipped: true, reason: `strategy '${strategy}' not supported or missing config` };
  }

  coordinateFullCloudDeploy.workerName = 'coordinateFullCloudDeploy';
  coordinateFullCloudDeploy.domain = domain;
  coordinateFullCloudDeploy.priority = priority;

  runSmokeTests.workerName = 'runSmokeTests';
  runSmokeTests.domain = domain;
  runSmokeTests.priority = priority;

  rollbackDeployment.workerName = 'rollbackDeployment';
  rollbackDeployment.domain = domain;
  rollbackDeployment.priority = priority;

  return [coordinateFullCloudDeploy, runSmokeTests, rollbackDeployment];
}

module.exports = { domain, description, priority, getWork };
