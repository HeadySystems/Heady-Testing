'use strict';

/**
 * @fileoverview HC Full Pipeline Core — 12-Stage Task Orchestrator
 * Implements the HCFullPipeline state machine with full audit trail,
 * stage hooks, rollback, and event emission.
 *
 * Stages: INTAKE → TRIAGE → CONTEXT → MONTE_CARLO → ARENA →
 *         JUDGE → APPROVE → PLAN → EXECUTE → VERIFY → RECEIPT → LEARN
 *
 * @module pipeline/pipeline-core
 */

const { EventEmitter } = require('events');
const { randomUUID: uuidv4 } = require('crypto');
const logger = require('../utils/logger');

// ─── Stage Definitions ───────────────────────────────────────────────────────

/** @enum {string} */
const STAGE = Object.freeze({
  INTAKE:      'INTAKE',
  TRIAGE:      'TRIAGE',
  CONTEXT:     'CONTEXT',
  MONTE_CARLO: 'MONTE_CARLO',
  ARENA:       'ARENA',
  JUDGE:       'JUDGE',
  APPROVE:     'APPROVE',
  PLAN:        'PLAN',
  EXECUTE:     'EXECUTE',
  VERIFY:      'VERIFY',
  RECEIPT:     'RECEIPT',
  LEARN:       'LEARN',
});

const STAGE_ORDER = [
  STAGE.INTAKE,
  STAGE.TRIAGE,
  STAGE.CONTEXT,
  STAGE.MONTE_CARLO,
  STAGE.ARENA,
  STAGE.JUDGE,
  STAGE.APPROVE,
  STAGE.PLAN,
  STAGE.EXECUTE,
  STAGE.VERIFY,
  STAGE.RECEIPT,
  STAGE.LEARN,
];

/** @enum {string} */
const TASK_STATUS = Object.freeze({
  ACTIVE:    'ACTIVE',
  PAUSED:    'PAUSED',
  COMPLETED: 'COMPLETED',
  FAILED:    'FAILED',
  ROLLED_BACK: 'ROLLED_BACK',
});

// ─── Stage Hook Registry ─────────────────────────────────────────────────────

/**
 * @class StageHooks
 * @description Default no-op hooks for each pipeline stage.
 * Can be subclassed or replaced for real implementations.
 */
class StageHooks {
  /** @param {string} stage - Stage name */
  constructor(stage) {
    this.stage = stage;
  }

  /**
   * Called when a task enters this stage.
   * @param {object} task - Task record
   * @returns {Promise<void>}
   */
  async enter(task) {
    logger.logNodeActivity('PIPELINE',
      `[${task.id}] ENTER stage: ${this.stage}`);
  }

  /**
   * Validates whether the task is ready for this stage.
   * @param {object} task
   * @returns {Promise<boolean>} true if valid
   */
  async validate(task) {
    return true;
  }

  /**
   * Core stage processing.
   * @param {object} task
   * @returns {Promise<object>} Stage result to merge into task.stageData
   */
  async execute(task) {
    return { stage: this.stage, processedAt: Date.now() };
  }

  /**
   * Called when a task exits this stage (before advancing).
   * @param {object} task
   * @returns {Promise<void>}
   */
  async exit(task) {
    logger.logNodeActivity('PIPELINE',
      `[${task.id}] EXIT stage: ${this.stage}`);
  }
}

// ─── PipelineCore ────────────────────────────────────────────────────────────

/**
 * @class PipelineCore
 * @extends EventEmitter
 * @description Orchestrates tasks through the 12-stage HC Full Pipeline.
 */
class PipelineCore extends EventEmitter {
  /**
   * @param {object} [opts={}]
   * @param {object} [opts.hooks={}]         - Map of stage → StageHooks instance
   * @param {number} [opts.stageTimeout=60000] - Default stage execution timeout in ms
   * @param {object} [opts.eventBus]         - Global event bus for cross-system events
   */
  constructor(opts = {}) {
    super();

    this._hooks        = opts.hooks        ?? {};
    this._stageTimeout = opts.stageTimeout ?? 60000;
    this._eventBus     = opts.eventBus     ?? (global.eventBus || new EventEmitter());

    /** @type {Map<string, object>} taskId → task record */
    this._tasks = new Map();

    /** @type {Map<string, NodeJS.Timeout>} taskId → stage timeout timer */
    this._timers = new Map();

    this._totalSubmitted  = 0;
    this._totalCompleted  = 0;
    this._totalFailed     = 0;
    this._createdAt       = Date.now();

    // Build default hooks for any stage not provided
    for (const stage of STAGE_ORDER) {
      if (!this._hooks[stage]) {
        this._hooks[stage] = new StageHooks(stage);
      }
    }
  }

  // ─── Stage Hooks API ─────────────────────────────────────────────────────────

  /**
   * Registers custom hooks for a stage.
   * @param {string}     stage
   * @param {StageHooks} hooks
   */
  registerHooks(stage, hooks) {
    if (!STAGE_ORDER.includes(stage)) {
      throw new Error(`Unknown stage: "${stage}"`);
    }
    this._hooks[stage] = hooks;
  }

  // ─── Task Lifecycle ───────────────────────────────────────────────────────────

  /**
   * Submits a new task to the pipeline at the INTAKE stage.
   * @param {object} taskInput
   * @param {string} [taskInput.id]       - Optional task ID (auto-generated if absent)
   * @param {string} [taskInput.type]     - Task type/category
   * @param {*}      [taskInput.payload]  - Task payload
   * @param {string} [taskInput.priority] - 'high' | 'normal' | 'low'
   * @returns {Promise<object>} The created task record
   */
  async submit(taskInput = {}) {
    const id = taskInput.id || uuidv4();
    const now = Date.now();

    const task = {
      id,
      type:      taskInput.type     || 'generic',
      payload:   taskInput.payload  || {},
      priority:  taskInput.priority || 'normal',
      status:    TASK_STATUS.ACTIVE,
      stage:     STAGE.INTAKE,
      stageData: {},
      audit:     [],
      createdAt: now,
      updatedAt: now,
      meta:      taskInput.meta || {},
    };

    this._tasks.set(id, task);
    this._totalSubmitted++;

    logger.logNodeActivity('PIPELINE',
      `Task submitted: ${id} (type: ${task.type})`);

    // Run INTAKE hooks
    await this._runStageHooks(task, STAGE.INTAKE);
    this._emit('task:submitted', task);

    return task;
  }

  /**
   * Advances a task to the next pipeline stage.
   * @param {string} taskId
   * @returns {Promise<object>} Updated task record
   * @throws {Error} If task not found, already at terminal stage, or validation fails
   */
  async advance(taskId) {
    const task = this._getTask(taskId);

    if (task.status !== TASK_STATUS.ACTIVE) {
      throw new Error(
        `Task ${taskId} is not ACTIVE (current status: ${task.status})`
      );
    }

    const currentIdx = STAGE_ORDER.indexOf(task.stage);
    if (currentIdx === -1) {
      throw new Error(`Unknown stage on task ${taskId}: ${task.stage}`);
    }
    if (currentIdx >= STAGE_ORDER.length - 1) {
      // Last stage — mark completed
      return this._complete(task);
    }

    const nextStage = STAGE_ORDER[currentIdx + 1];

    // Validate transition
    const hooks  = this._hooks[task.stage];
    const valid  = await this._withTimeout(hooks.validate(task), this._stageTimeout);
    if (!valid) {
      throw new Error(
        `Stage validation failed: cannot advance from ${task.stage} to ${nextStage}`
      );
    }

    // Exit current stage
    await this._withTimeout(hooks.exit(task), this._stageTimeout);

    // Record audit entry
    this._auditEntry(task, `advance: ${task.stage} → ${nextStage}`);

    // Transition
    task.stage     = nextStage;
    task.updatedAt = Date.now();
    task.stageData[nextStage] = null; // will be populated by execute

    // Enter next stage
    await this._runStageHooks(task, nextStage);

    this._emit('task:advanced', { taskId, stage: nextStage });

    return task;
  }

  /**
   * Rolls back a task to a previous stage.
   * @param {string} taskId
   * @param {string} toStage - Target stage to roll back to
   * @returns {Promise<object>} Updated task record
   */
  async rollback(taskId, toStage) {
    const task = this._getTask(taskId);

    if (!STAGE_ORDER.includes(toStage)) {
      throw new Error(`Cannot rollback to unknown stage: "${toStage}"`);
    }

    const currentIdx = STAGE_ORDER.indexOf(task.stage);
    const targetIdx  = STAGE_ORDER.indexOf(toStage);

    if (targetIdx >= currentIdx) {
      throw new Error(
        `Cannot rollback from ${task.stage} to ${toStage} — target is not behind current`
      );
    }

    const from = task.stage;
    task.stage     = toStage;
    task.status    = TASK_STATUS.ROLLED_BACK;
    task.updatedAt = Date.now();

    this._auditEntry(task, `rollback: ${from} → ${toStage}`);

    logger.logNodeActivity('PIPELINE',
      `Task ${taskId} rolled back: ${from} → ${toStage}`);

    this._emit('task:rolledback', { taskId, from, to: toStage });

    // Re-activate
    task.status = TASK_STATUS.ACTIVE;
    return task;
  }

  /**
   * Returns the current state and metadata for a task.
   * @param {string} taskId
   * @returns {object}
   */
  getState(taskId) {
    return this._getTask(taskId);
  }

  /**
   * Returns all tasks (optionally filtered by status or stage).
   * @param {object} [filter={}]
   * @param {string} [filter.status]
   * @param {string} [filter.stage]
   * @returns {object[]}
   */
  getTasks(filter = {}) {
    let tasks = Array.from(this._tasks.values());
    if (filter.status) tasks = tasks.filter(t => t.status === filter.status);
    if (filter.stage)  tasks = tasks.filter(t => t.stage  === filter.stage);
    return tasks;
  }

  /**
   * Marks a task as failed with an error.
   * @param {string} taskId
   * @param {Error|string} err
   * @returns {object}
   */
  failTask(taskId, err) {
    const task = this._getTask(taskId);
    task.status    = TASK_STATUS.FAILED;
    task.error     = typeof err === 'string' ? err : err.message;
    task.updatedAt = Date.now();
    this._totalFailed++;
    this._clearTimer(taskId);
    this._auditEntry(task, `failed: ${task.error}`);
    this._emit('task:failed', { taskId, error: task.error });
    logger.logNodeActivity('PIPELINE', `Task ${taskId} FAILED: ${task.error}`);
    return task;
  }

  /**
   * Returns pipeline-level statistics.
   * @returns {object}
   */
  getStats() {
    const tasks = Array.from(this._tasks.values());
    const byStage = {};
    for (const s of STAGE_ORDER) {
      byStage[s] = tasks.filter(t => t.stage === s).length;
    }
    return {
      totalSubmitted:  this._totalSubmitted,
      totalCompleted:  this._totalCompleted,
      totalFailed:     this._totalFailed,
      active:          tasks.filter(t => t.status === TASK_STATUS.ACTIVE).length,
      paused:          tasks.filter(t => t.status === TASK_STATUS.PAUSED).length,
      byStage,
      createdAt:       this._createdAt,
    };
  }

  // ─── Internals ───────────────────────────────────────────────────────────────

  /**
   * @private
   */
  _getTask(taskId) {
    const task = this._tasks.get(taskId);
    if (!task) throw new Error(`Task not found: ${taskId}`);
    return task;
  }

  /**
   * @private
   * Runs enter → execute on a stage's hooks and stores result in stageData.
   */
  async _runStageHooks(task, stage) {
    const hooks = this._hooks[stage];

    await this._withTimeout(hooks.enter(task), this._stageTimeout);

    const result = await this._withTimeout(hooks.execute(task), this._stageTimeout);
    task.stageData[stage] = result;
    task.updatedAt = Date.now();

    this._auditEntry(task, `stage:execute:${stage}`);
    this._emit(`stage:${stage}`, { taskId: task.id, result });
  }

  /**
   * @private
   * Marks a task as completed (after LEARN stage).
   */
  async _complete(task) {
    const hooks = this._hooks[task.stage];
    await this._withTimeout(hooks.exit(task), this._stageTimeout);

    task.status      = TASK_STATUS.COMPLETED;
    task.completedAt = Date.now();
    task.updatedAt   = Date.now();
    this._totalCompleted++;
    this._clearTimer(task.id);

    this._auditEntry(task, 'pipeline:completed');
    this._emit('task:completed', { taskId: task.id });
    logger.logNodeActivity('PIPELINE', `Task ${task.id} COMPLETED`);
    return task;
  }

  /**
   * @private
   * Wraps a promise with a timeout.
   */
  _withTimeout(promise, ms) {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => {
        reject(new Error(`Stage timed out after ${ms}ms`));
      }, ms);
      Promise.resolve(promise)
        .then(v => { clearTimeout(t); resolve(v); })
        .catch(e => { clearTimeout(t); reject(e); });
    });
  }

  /**
   * @private
   */
  _clearTimer(taskId) {
    if (this._timers.has(taskId)) {
      clearTimeout(this._timers.get(taskId));
      this._timers.delete(taskId);
    }
  }

  /**
   * @private
   */
  _auditEntry(task, action) {
    task.audit.push({
      action,
      stage:  task.stage,
      status: task.status,
      at:     Date.now(),
    });
  }

  /**
   * @private
   * Emits on both `this` and the global eventBus.
   */
  _emit(event, data) {
    this.emit(event, data);
    if (this._eventBus && typeof this._eventBus.emit === 'function') {
      this._eventBus.emit(`pipeline:${event}`, data);
    }
  }

  // ─── Express Routes ───────────────────────────────────────────────────────────

  /**
   * Registers pipeline management routes on an Express app.
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    app.post('/api/pipeline/submit', async (req, res) => {
      try {
        const task = await this.submit(req.body);
        res.status(201).json(task);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.post('/api/pipeline/advance/:taskId', async (req, res) => {
      try {
        const task = await this.advance(req.params.taskId);
        res.json(task);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.post('/api/pipeline/rollback/:taskId', async (req, res) => {
      try {
        const { toStage } = req.body;
        const task = await this.rollback(req.params.taskId, toStage);
        res.json(task);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.get('/api/pipeline/task/:taskId', (req, res) => {
      try {
        res.json(this.getState(req.params.taskId));
      } catch (err) {
        res.status(404).json({ error: err.message });
      }
    });

    app.get('/api/pipeline/tasks', (req, res) => {
      res.json(this.getTasks(req.query));
    });

    app.get('/api/pipeline/stats', (req, res) => {
      res.json(this.getStats());
    });

    logger.logNodeActivity('PIPELINE', 'Pipeline routes registered');
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  PipelineCore,
  StageHooks,
  STAGE,
  STAGE_ORDER,
  TASK_STATUS,
};
