'use strict';

/**
 * @fileoverview Pipeline Infrastructure — HeadyStack
 * Persistence, timeout management, parallel execution, and observability
 * for the HC Full Pipeline.
 *
 * @module pipeline/pipeline-infra
 */

const { EventEmitter } = require('events');
const logger = require('../utils/logger');

// ─── PipelineStore ───────────────────────────────────────────────────────────

/**
 * @class PipelineStore
 * @description In-memory pipeline state store with optional Redis backend.
 * Persists task records and stage data. Falls back to in-memory if Redis
 * is unavailable.
 */
class PipelineStore {
  /**
   * @param {object} [opts={}]
   * @param {object} [opts.redis]          - Redis client (optional)
   * @param {string} [opts.keyPrefix='hc:pipeline:'] - Redis key prefix
   * @param {number} [opts.ttlSeconds=86400]          - Redis TTL in seconds
   */
  constructor(opts = {}) {
    this._redis     = opts.redis     ?? null;
    this._prefix    = opts.keyPrefix ?? 'hc:pipeline:';
    this._ttl       = opts.ttlSeconds ?? 86400;

    /** @type {Map<string, object>} In-memory fallback store */
    this._memory    = new Map();

    this._reads  = 0;
    this._writes = 0;
    this._hits   = 0;
    this._misses = 0;
  }

  /**
   * Persists a task record.
   * @param {string} taskId
   * @param {object} task
   * @returns {Promise<void>}
   */
  async save(taskId, task) {
    this._writes++;
    const key  = this._prefix + taskId;
    const data = JSON.stringify(task);

    if (this._redis) {
      try {
        await this._redis.set(key, data, 'EX', this._ttl);
        // Also mirror in memory for fast local reads
        this._memory.set(taskId, task);
        return;
      } catch (err) {
        logger.logNodeActivity('PIPELINE-STORE',
          `Redis save failed, falling back to memory: ${err.message}`);
      }
    }

    this._memory.set(taskId, task);
  }

  /**
   * Loads a task record by ID.
   * @param {string} taskId
   * @returns {Promise<object|null>}
   */
  async load(taskId) {
    this._reads++;

    // Check memory cache first
    if (this._memory.has(taskId)) {
      this._hits++;
      return this._memory.get(taskId);
    }

    if (this._redis) {
      try {
        const key  = this._prefix + taskId;
        const data = await this._redis.get(key);
        if (data) {
          this._hits++;
          const task = JSON.parse(data);
          this._memory.set(taskId, task); // warm local cache
          return task;
        }
      } catch (err) {
        logger.logNodeActivity('PIPELINE-STORE',
          `Redis load failed: ${err.message}`);
      }
    }

    this._misses++;
    return null;
  }

  /**
   * Deletes a task record.
   * @param {string} taskId
   * @returns {Promise<void>}
   */
  async delete(taskId) {
    this._memory.delete(taskId);
    if (this._redis) {
      try {
        await this._redis.del(this._prefix + taskId);
      } catch { /* ignore */ }
    }
  }

  /**
   * Returns all tasks currently in memory.
   * @returns {object[]}
   */
  getAll() {
    return Array.from(this._memory.values());
  }

  /**
   * Returns store statistics.
   * @returns {object}
   */
  getStats() {
    return {
      memorySize:  this._memory.size,
      reads:       this._reads,
      writes:      this._writes,
      hits:        this._hits,
      misses:      this._misses,
      hitRate:     this._reads > 0
        ? parseFloat((this._hits / this._reads).toFixed(4))
        : 0,
      hasRedis:    !!this._redis,
    };
  }
}

// ─── StageTimeoutManager ─────────────────────────────────────────────────────

/**
 * @class StageTimeoutManager
 * @description Manages per-task stage execution timeouts.
 * Fires a 'timeout' event when a task exceeds its allowed stage duration.
 */
class StageTimeoutManager extends EventEmitter {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.defaultTimeoutMs=60000] - Default stage timeout
   * @param {object} [opts.stageTimeouts={}]        - Per-stage overrides { STAGE: ms }
   */
  constructor(opts = {}) {
    super();
    this._defaultTimeout = opts.defaultTimeoutMs ?? 60000;
    this._stageTimeouts  = opts.stageTimeouts    ?? {};
    this._timers         = new Map(); // `${taskId}:${stage}` → timer
    this._expirations    = 0;
  }

  /**
   * Starts a timeout for a task at a specific stage.
   * @param {string} taskId
   * @param {string} stage
   * @param {number} [overrideMs] - Optional timeout override
   */
  start(taskId, stage, overrideMs) {
    const key = `${taskId}:${stage}`;
    this.cancel(taskId, stage); // cancel any existing

    const ms = overrideMs
      ?? this._stageTimeouts[stage]
      ?? this._defaultTimeout;

    const timer = setTimeout(() => {
      this._timers.delete(key);
      this._expirations++;
      logger.logNodeActivity('PIPELINE-TIMEOUT',
        `Task ${taskId} timed out at stage ${stage} after ${ms}ms`);
      this.emit('timeout', { taskId, stage, ms });
    }, ms);

    if (timer.unref) timer.unref();
    this._timers.set(key, timer);
  }

  /**
   * Cancels the timeout for a task at a stage.
   * @param {string} taskId
   * @param {string} stage
   */
  cancel(taskId, stage) {
    const key = `${taskId}:${stage}`;
    if (this._timers.has(key)) {
      clearTimeout(this._timers.get(key));
      this._timers.delete(key);
    }
  }

  /**
   * Cancels all timeouts for a task.
   * @param {string} taskId
   */
  cancelAll(taskId) {
    for (const key of this._timers.keys()) {
      if (key.startsWith(`${taskId}:`)) {
        clearTimeout(this._timers.get(key));
        this._timers.delete(key);
      }
    }
  }

  /** @returns {object} */
  getStats() {
    return {
      active:      this._timers.size,
      expirations: this._expirations,
    };
  }
}

// ─── ParallelExecutor ────────────────────────────────────────────────────────

/**
 * @class ParallelExecutor
 * @description Runs multiple async operations concurrently with
 * configurable concurrency limits and error aggregation.
 */
class ParallelExecutor {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.concurrency=5] - Max simultaneous tasks
   * @param {boolean} [opts.failFast=false] - Abort all on first error
   */
  constructor(opts = {}) {
    this._concurrency = opts.concurrency ?? 5;
    this._failFast    = opts.failFast    ?? false;
    this._running     = 0;
    this._queue       = [];
    this._executed    = 0;
    this._failed      = 0;
  }

  /**
   * Executes an array of async functions with bounded concurrency.
   * @param {Function[]} fns - Array of () => Promise functions
   * @returns {Promise<object[]>} Array of { status, value, reason } per fn
   */
  async run(fns) {
    return new Promise((resolve, reject) => {
      const results   = new Array(fns.length);
      let completed   = 0;
      let aborted     = false;
      let nextIdx     = 0;

      const runNext = () => {
        while (this._running < this._concurrency && nextIdx < fns.length) {
          const idx = nextIdx++;
          this._running++;

          Promise.resolve()
            .then(() => fns[idx]())
            .then(value => {
              this._executed++;
              results[idx] = { status: 'fulfilled', value };
            })
            .catch(reason => {
              this._failed++;
              results[idx] = { status: 'rejected', reason };
              if (this._failFast && !aborted) {
                aborted = true;
                reject(reason);
                return;
              }
            })
            .finally(() => {
              this._running--;
              completed++;
              if (!aborted && completed === fns.length) {
                resolve(results);
              } else if (!aborted) {
                runNext();
              }
            });
        }
      };

      if (fns.length === 0) return resolve([]);
      runNext();
    });
  }

  /** @returns {object} */
  getStats() {
    return {
      concurrency: this._concurrency,
      running:     this._running,
      queued:      this._queue.length,
      executed:    this._executed,
      failed:      this._failed,
    };
  }
}

// ─── PipelineMetrics ─────────────────────────────────────────────────────────

/**
 * @class PipelineMetrics
 * @description Collects and aggregates pipeline observability metrics.
 */
class PipelineMetrics {
  constructor() {
    this._stageDurations  = {}; // stage → [ms, ...]
    this._stageCounts     = {}; // stage → count
    this._stageErrors     = {}; // stage → errorCount
    this._transitions     = [];
    this._createdAt       = Date.now();
  }

  /**
   * Records a stage entry event.
   * @param {string} taskId
   * @param {string} stage
   */
  recordEntry(taskId, stage) {
    if (!this._stageCounts[stage]) this._stageCounts[stage] = 0;
    this._stageCounts[stage]++;
    this._transitions.push({ taskId, stage, event: 'enter', at: Date.now() });
    if (this._transitions.length > 500) this._transitions.shift();
  }

  /**
   * Records stage duration.
   * @param {string} stage
   * @param {number} durationMs
   */
  recordDuration(stage, durationMs) {
    if (!this._stageDurations[stage]) this._stageDurations[stage] = [];
    this._stageDurations[stage].push(durationMs);
    // Keep last 100 samples per stage
    if (this._stageDurations[stage].length > 100) {
      this._stageDurations[stage].shift();
    }
  }

  /**
   * Records a stage error.
   * @param {string} stage
   */
  recordError(stage) {
    if (!this._stageErrors[stage]) this._stageErrors[stage] = 0;
    this._stageErrors[stage]++;
  }

  /**
   * Returns aggregated metrics.
   * @returns {object}
   */
  getMetrics() {
    const stageStats = {};
    for (const stage of Object.keys(this._stageDurations)) {
      const durations = this._stageDurations[stage];
      if (durations.length === 0) continue;
      const sum  = durations.reduce((a, b) => a + b, 0);
      const avg  = sum / durations.length;
      const sorted = [...durations].sort((a, b) => a - b);
      stageStats[stage] = {
        count:   this._stageCounts[stage] || 0,
        errors:  this._stageErrors[stage] || 0,
        avgMs:   Math.round(avg),
        p50Ms:   sorted[Math.floor(sorted.length * 0.5)],
        p95Ms:   sorted[Math.floor(sorted.length * 0.95)],
        p99Ms:   sorted[Math.floor(sorted.length * 0.99)],
        minMs:   sorted[0],
        maxMs:   sorted[sorted.length - 1],
      };
    }
    return {
      createdAt:   this._createdAt,
      stageStats,
      recentTransitions: this._transitions.slice(-50),
    };
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = {
  PipelineStore,
  StageTimeoutManager,
  ParallelExecutor,
  PipelineMetrics,
};
