'use strict';

/**
 * @fileoverview Pipeline Pools — Hot/Warm/Cold Pool Scheduler
 * Three-tier task scheduling system with automatic priority promotion.
 *
 * HOT  — immediate execution (high priority, SLA < 1s)
 * WARM — queued for next cycle (normal priority, SLA < 10s)
 * COLD — deferred/batch processing (low priority, SLA < 60s)
 *
 * Promotion rules: COLD → WARM (age > warmThreshold), WARM → HOT (age > hotThreshold)
 *
 * @module pipeline/pipeline-pools
 */

const { EventEmitter } = require('events');
const logger = require('../utils/logger');

/** @enum {string} */
const POOL = Object.freeze({
  HOT:  'HOT',
  WARM: 'WARM',
  COLD: 'COLD',
});

/** @constant {object} DEFAULT_THRESHOLDS - Time (ms) before auto-promotion */
const DEFAULT_THRESHOLDS = {
  COLD_TO_WARM: 30000,  // 30s in COLD → promote to WARM
  WARM_TO_HOT:  10000,  // 10s in WARM → promote to HOT
};

/**
 * @typedef {object} PoolItem
 * @property {string} id            - Unique item ID
 * @property {*}      payload       - Item payload (task or reference)
 * @property {string} pool          - Current pool name
 * @property {string} priority      - 'high' | 'normal' | 'low'
 * @property {number} enqueuedAt    - Timestamp when item entered the pool
 * @property {number} poolEnteredAt - Timestamp when item entered current pool
 * @property {number} promotions    - Number of times this item was promoted
 */

/**
 * @class PipelinePools
 * @extends EventEmitter
 * @description Manages three-tier task scheduling with automatic promotion
 * based on aging and urgency scoring.
 */
class PipelinePools extends EventEmitter {
  /**
   * @param {object} [opts={}]
   * @param {number} [opts.coldToWarmMs=30000]    - Age threshold: COLD → WARM
   * @param {number} [opts.warmToHotMs=10000]     - Age threshold: WARM → HOT
   * @param {number} [opts.promotionIntervalMs=5000] - How often to check for promotions
   * @param {number} [opts.hotCapacity=50]         - Max items in HOT pool
   * @param {number} [opts.warmCapacity=200]       - Max items in WARM pool
   * @param {number} [opts.coldCapacity=1000]      - Max items in COLD pool
   */
  constructor(opts = {}) {
    super();

    this._thresholds = {
      coldToWarm: opts.coldToWarmMs ?? DEFAULT_THRESHOLDS.COLD_TO_WARM,
      warmToHot:  opts.warmToHotMs  ?? DEFAULT_THRESHOLDS.WARM_TO_HOT,
    };

    this._capacities = {
      [POOL.HOT]:  opts.hotCapacity  ?? 50,
      [POOL.WARM]: opts.warmCapacity ?? 200,
      [POOL.COLD]: opts.coldCapacity ?? 1000,
    };

    this._promotionInterval = opts.promotionIntervalMs ?? 5000;

    /** @type {Map<string, PoolItem>} - All items by ID */
    this._items = new Map();

    /** @type {Set<string>} HOT pool item IDs */
    this._hot  = [];
    /** @type {Set<string>} WARM pool item IDs */
    this._warm = [];
    /** @type {Set<string>} COLD pool item IDs */
    this._cold = [];

    this._totalEnqueued  = 0;
    this._totalDequeued  = 0;
    this._totalPromoted  = 0;
    this._totalDropped   = 0;
    this._createdAt      = Date.now();

    this._promotionTimer = null;
    this._started = false;
  }

  // ─── Lifecycle ───────────────────────────────────────────────────────────────

  /**
   * Starts the promotion sweep loop.
   * @returns {PipelinePools} this
   */
  start() {
    if (this._started) return this;
    this._started = true;
    this._promotionTimer = setInterval(
      () => this._sweepPromotions(),
      this._promotionInterval
    );
    if (this._promotionTimer.unref) this._promotionTimer.unref();
    logger.logNodeActivity('PIPELINE-POOLS', 'Pool scheduler started');
    return this;
  }

  /**
   * Stops the promotion sweep loop.
   * @returns {PipelinePools} this
   */
  stop() {
    if (!this._started) return this;
    this._started = false;
    if (this._promotionTimer) {
      clearInterval(this._promotionTimer);
      this._promotionTimer = null;
    }
    logger.logNodeActivity('PIPELINE-POOLS', 'Pool scheduler stopped');
    return this;
  }

  // ─── Enqueue ─────────────────────────────────────────────────────────────────

  /**
   * Adds a task to the appropriate pool based on priority.
   * @param {object} item
   * @param {string} item.id       - Unique item ID
   * @param {*}      item.payload  - Task or payload object
   * @param {string} [item.priority='normal'] - 'high' | 'normal' | 'low'
   * @returns {PoolItem} The enqueued item record
   */
  enqueue(item) {
    if (!item || !item.id) {
      throw new TypeError('enqueue() requires item.id');
    }

    if (this._items.has(item.id)) {
      logger.logNodeActivity('PIPELINE-POOLS',
        `Item ${item.id} already in pool — skipping`);
      return this._items.get(item.id);
    }

    const priority = item.priority || 'normal';
    const pool     = this._priorityToPool(priority);

    // Capacity check
    const poolArr = this._getPoolArray(pool);
    if (poolArr.length >= this._capacities[pool]) {
      logger.logNodeActivity('PIPELINE-POOLS',
        `Pool ${pool} at capacity (${this._capacities[pool]}). ` +
        `Dropping item ${item.id}.`);
      this._totalDropped++;
      this.emit('dropped', { id: item.id, pool });
      return null;
    }

    const now = Date.now();
    const entry = {
      id:           item.id,
      payload:      item.payload ?? item,
      pool,
      priority,
      enqueuedAt:   now,
      poolEnteredAt: now,
      promotions:   0,
      meta:         item.meta || {},
    };

    this._items.set(item.id, entry);
    poolArr.push(item.id);
    this._totalEnqueued++;

    logger.logNodeActivity('PIPELINE-POOLS',
      `Enqueued item ${item.id} → ${pool}`);
    this.emit('enqueued', { id: item.id, pool });

    return entry;
  }

  // ─── Dequeue ─────────────────────────────────────────────────────────────────

  /**
   * Dequeues the next item from the highest-priority non-empty pool.
   * HOT > WARM > COLD
   * @returns {PoolItem|null}
   */
  dequeue() {
    const item = this._dequeueFrom(this._hot, POOL.HOT)
      ?? this._dequeueFrom(this._warm, POOL.WARM)
      ?? this._dequeueFrom(this._cold, POOL.COLD);

    if (item) {
      this._totalDequeued++;
      this.emit('dequeued', { id: item.id, pool: item.pool });
    }

    return item;
  }

  /**
   * Dequeues from a specific pool.
   * @param {string} poolName
   * @returns {PoolItem|null}
   */
  dequeueFrom(poolName) {
    const arr = this._getPoolArray(poolName);
    return this._dequeueFrom(arr, poolName);
  }

  /**
   * Peeks at the next item without removing it.
   * @param {string} [poolName] - Optional: peek only in specific pool
   * @returns {PoolItem|null}
   */
  peek(poolName) {
    if (poolName) {
      const arr = this._getPoolArray(poolName);
      return arr.length > 0 ? this._items.get(arr[0]) : null;
    }
    return (
      (this._hot.length  > 0 ? this._items.get(this._hot[0])  : null) ??
      (this._warm.length > 0 ? this._items.get(this._warm[0]) : null) ??
      (this._cold.length > 0 ? this._items.get(this._cold[0]) : null)
    );
  }

  // ─── Promotion ───────────────────────────────────────────────────────────────

  /**
   * Manually promotes an item to a higher-priority pool.
   * @param {string} itemId
   * @param {string} [targetPool] - Optional target pool; defaults to next tier
   * @returns {PoolItem|null}
   */
  promote(itemId, targetPool) {
    const item = this._items.get(itemId);
    if (!item) return null;

    const from = item.pool;
    const to   = targetPool || this._nextPool(from);
    if (!to || to === from) return item;

    this._removeFromPool(item.id, from);
    item.pool          = to;
    item.poolEnteredAt = Date.now();
    item.promotions++;

    const toArr = this._getPoolArray(to);
    // Urgent items go to front of HOT
    if (to === POOL.HOT) {
      toArr.unshift(itemId);
    } else {
      toArr.push(itemId);
    }

    this._totalPromoted++;
    logger.logNodeActivity('PIPELINE-POOLS',
      `Promoted item ${itemId}: ${from} → ${to}`);
    this.emit('promoted', { id: itemId, from, to });

    return item;
  }

  /**
   * @private
   * Sweeps all COLD and WARM items for age-based promotion.
   */
  _sweepPromotions() {
    const now = Date.now();
    let promoted = 0;

    // WARM → HOT
    for (let i = this._warm.length - 1; i >= 0; i--) {
      const item = this._items.get(this._warm[i]);
      if (!item) continue;
      const age = now - item.poolEnteredAt;
      if (age >= this._thresholds.warmToHot) {
        if (this._hot.length < this._capacities[POOL.HOT]) {
          this.promote(item.id, POOL.HOT);
          promoted++;
        }
      }
    }

    // COLD → WARM
    for (let i = this._cold.length - 1; i >= 0; i--) {
      const item = this._items.get(this._cold[i]);
      if (!item) continue;
      const age = now - item.poolEnteredAt;
      if (age >= this._thresholds.coldToWarm) {
        if (this._warm.length < this._capacities[POOL.WARM]) {
          this.promote(item.id, POOL.WARM);
          promoted++;
        }
      }
    }

    if (promoted > 0) {
      logger.logNodeActivity('PIPELINE-POOLS',
        `Promotion sweep: promoted ${promoted} item(s)`);
    }
  }

  // ─── Pool Status ─────────────────────────────────────────────────────────────

  /**
   * Returns counts per pool and global statistics.
   * @returns {object}
   */
  getPoolStatus() {
    return {
      [POOL.HOT]:  this._hot.length,
      [POOL.WARM]: this._warm.length,
      [POOL.COLD]: this._cold.length,
      total:          this._items.size,
      capacities:     { ...this._capacities },
      totalEnqueued:  this._totalEnqueued,
      totalDequeued:  this._totalDequeued,
      totalPromoted:  this._totalPromoted,
      totalDropped:   this._totalDropped,
      createdAt:      this._createdAt,
    };
  }

  /**
   * Returns all items in a specific pool.
   * @param {string} poolName
   * @returns {PoolItem[]}
   */
  getPoolItems(poolName) {
    return this._getPoolArray(poolName)
      .map(id => this._items.get(id))
      .filter(Boolean);
  }

  // ─── Internals ───────────────────────────────────────────────────────────────

  /**
   * @private
   */
  _priorityToPool(priority) {
    switch (priority) {
      case 'high':   return POOL.HOT;
      case 'low':    return POOL.COLD;
      case 'normal':
      default:       return POOL.WARM;
    }
  }

  /**
   * @private
   */
  _nextPool(pool) {
    if (pool === POOL.COLD)  return POOL.WARM;
    if (pool === POOL.WARM)  return POOL.HOT;
    return null; // already at HOT
  }

  /**
   * @private
   */
  _getPoolArray(pool) {
    switch (pool) {
      case POOL.HOT:  return this._hot;
      case POOL.WARM: return this._warm;
      case POOL.COLD: return this._cold;
      default: throw new Error(`Unknown pool: "${pool}"`);
    }
  }

  /**
   * @private
   */
  _removeFromPool(itemId, pool) {
    const arr = this._getPoolArray(pool);
    const idx = arr.indexOf(itemId);
    if (idx !== -1) arr.splice(idx, 1);
  }

  /**
   * @private
   */
  _dequeueFrom(arr, poolName) {
    if (arr.length === 0) return null;
    const id   = arr.shift();
    const item = this._items.get(id);
    if (item) {
      this._items.delete(id);
      item.dequeuedAt = Date.now();
      item.waitMs     = item.dequeuedAt - item.enqueuedAt;
    }
    return item || null;
  }

  // ─── Express Routes ───────────────────────────────────────────────────────────

  /**
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    app.get('/api/pools/status', (req, res) => {
      res.json(this.getPoolStatus());
    });

    app.get('/api/pools/:pool/items', (req, res) => {
      try {
        const items = this.getPoolItems(req.params.pool.toUpperCase());
        res.json(items);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.post('/api/pools/enqueue', (req, res) => {
      try {
        const item = this.enqueue(req.body);
        if (!item) return res.status(429).json({ error: 'Pool at capacity' });
        res.status(201).json(item);
      } catch (err) {
        res.status(400).json({ error: err.message });
      }
    });

    app.post('/api/pools/dequeue', (req, res) => {
      const item = req.body.pool
        ? this.dequeueFrom(req.body.pool.toUpperCase())
        : this.dequeue();
      if (!item) return res.status(204).end();
      res.json(item);
    });

    app.post('/api/pools/promote/:id', (req, res) => {
      const item = this.promote(req.params.id, req.body.targetPool);
      if (!item) return res.status(404).json({ error: 'Item not found' });
      res.json(item);
    });

    logger.logNodeActivity('PIPELINE-POOLS', 'Pool routes registered');
  }
}

// ─── Exports ─────────────────────────────────────────────────────────────────

module.exports = { PipelinePools, POOL };
