'use strict';

/**
 * Buddy Routes — HeadyBuddy chat and session management endpoints.
 * POST /api/buddy/chat    — send a message and get a response
 * GET  /api/buddy/history — retrieve session history
 */

const express = require('express');
const router = express.Router();

function getBuddySystem() {
  const { getBuddySystem } = require('../services/buddy-system');
  return getBuddySystem();
}

// ─── Routes ───────────────────────────────────────────────────────────────────

/**
 * POST /api/buddy/chat
 * Body: { sessionId?, userId?, deviceId?, message, taskType?, maxTokens? }
 */
router.post('/api/buddy/chat', async (req, res) => {
  try {
    const { sessionId, userId, deviceId, message, taskType, maxTokens, temperature } = req.body || {};
    if (!message) return res.status(400).json({ ok: false, error: 'message is required' });

    const buddy = getBuddySystem();

    // Auto-create session if none provided
    let activeSessionId = sessionId;
    if (!activeSessionId) {
      const session = buddy.getOrCreateSession({ userId, deviceId });
      activeSessionId = session.id;
    }

    const result = await buddy.chat(activeSessionId, message, { taskType, maxTokens, temperature, deviceId });

    res.json({
      ok: true,
      sessionId: activeSessionId,
      reply: result.message.content,
      message: result.message,
      messageCount: result.messageCount,
      history: result.history,
    });
  } catch (err) {
    const status = err.message.includes('not found') ? 404 : 500;
    res.status(status).json({ ok: false, error: err.message });
  }
});

/**
 * GET /api/buddy/history
 * Query: { sessionId, limit? }
 */
router.get('/api/buddy/history', (req, res) => {
  try {
    const { sessionId, limit } = req.query;
    if (!sessionId) return res.status(400).json({ ok: false, error: 'sessionId is required' });

    const buddy = getBuddySystem();
    const session = buddy.getSession(sessionId);
    if (!session) return res.status(404).json({ ok: false, error: 'Session not found' });

    const historyLimit = parseInt(limit) || 50;
    const history = session.history.slice(-historyLimit);

    res.json({
      ok: true,
      sessionId,
      history,
      messageCount: session.messageCount,
      createdAt: session.createdAt,
      lastActiveAt: session.lastActiveAt,
      status: session.status,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * POST /api/buddy/session — Create or retrieve a buddy session
 */
router.post('/api/buddy/session', (req, res) => {
  try {
    const { userId, deviceId, sessionId } = req.body || {};
    const buddy = getBuddySystem();
    const session = buddy.getOrCreateSession({ userId, deviceId, sessionId });
    res.json({
      ok: true,
      sessionId: session.id,
      status: session.status,
      createdAt: session.createdAt,
      messageCount: session.messageCount,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * DELETE /api/buddy/session/:sessionId — Archive a session
 */
router.delete('/api/buddy/session/:sessionId', (req, res) => {
  const buddy = getBuddySystem();
  buddy.archiveSession(req.params.sessionId);
  res.json({ ok: true, archived: req.params.sessionId });
});

/**
 * GET /api/buddy/sessions/:userId — List sessions for a user
 */
router.get('/api/buddy/sessions/:userId', (req, res) => {
  const buddy = getBuddySystem();
  const sessions = buddy.listUserSessions(req.params.userId);
  res.json({ ok: true, sessions });
});

/**
 * GET /api/buddy/stats — Buddy system stats
 */
router.get('/api/buddy/stats', (req, res) => {
  const buddy = getBuddySystem();
  res.json({ ok: true, stats: buddy.getStats() });
});

module.exports = router;
