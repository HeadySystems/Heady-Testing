'use strict';

/**
 * Brain Routes — LLM generation and content analysis endpoints.
 * POST /api/brain/generate — LLM text generation
 * POST /api/brain/analyze  — Content analysis (classify, summarize, extract)
 */

const express = require('express');
const router = express.Router();

let _vectorMemory = null;

/**
 * Inject vector memory wrapper (called from server setup).
 */
function setMemoryWrapper(vectorMemory) {
  _vectorMemory = vectorMemory;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

async function getRouter() {
  const { getLLMRouter } = require('../services/llm-router');
  return getLLMRouter();
}

async function enrichWithContext(prompt, taskType) {
  if (!_vectorMemory || typeof _vectorMemory.search !== 'function') return prompt;
  try {
    const results = await _vectorMemory.search(prompt, { topK: 3, taskType });
    if (!results || results.length === 0) return prompt;
    const context = results.map((r, i) => `[Context ${i + 1}]: ${r.text || r.content}`).join('\n');
    return `Relevant context from memory:\n${context}\n\n---\n\n${prompt}`;
  } catch (e) {
    return prompt; // graceful degradation
  }
}

// ─── Routes ───────────────────────────────────────────────────────────────────

/**
 * POST /api/brain/generate
 * Body: { prompt, taskType, systemPrompt, maxTokens, temperature, useMemory, stream }
 */
router.post('/api/brain/generate', async (req, res) => {
  try {
    const {
      prompt,
      taskType = 'default',
      systemPrompt,
      maxTokens,
      temperature,
      useMemory = true,
      stream = false,
    } = req.body || {};

    if (!prompt) return res.status(400).json({ ok: false, error: 'prompt is required' });

    const llm = await getRouter();

    // Optionally enrich with vector context
    const enrichedPrompt = useMemory ? await enrichWithContext(prompt, taskType) : prompt;

    if (stream) {
      // Streaming not implemented yet — fall through to standard response
      res.setHeader('Content-Type', 'text/event-stream');
      res.setHeader('Cache-Control', 'no-cache');
      res.setHeader('Connection', 'keep-alive');
    }

    const result = await llm.generate(enrichedPrompt, { taskType, systemPrompt, maxTokens, temperature });

    // Optionally store this interaction in vector memory
    if (useMemory && _vectorMemory && typeof _vectorMemory.store === 'function') {
      const interactionText = `Q: ${prompt}\nA: ${result.text}`;
      _vectorMemory.store(null, null, interactionText, { type: 'brain_interaction', taskType }).catch(() => {});
    }

    if (stream) {
      res.write(`data: ${JSON.stringify({ type: 'content', text: result.text })}\n\n`);
      res.write(`data: ${JSON.stringify({ type: 'done', ...result })}\n\n`);
      return res.end();
    }

    res.json({
      ok: true,
      text: result.text,
      provider: result.provider,
      model: result.model,
      tokens: result.tokens,
      taskType,
      enriched: enrichedPrompt !== prompt,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * POST /api/brain/analyze
 * Body: { content, analysisType, context, maxTokens }
 * analysisType: 'classify' | 'summarize' | 'extract' | 'sentiment' | 'entities' | 'translate' | 'custom'
 */
router.post('/api/brain/analyze', async (req, res) => {
  try {
    const { content, analysisType = 'summarize', context = '', maxTokens = 1024 } = req.body || {};
    if (!content) return res.status(400).json({ ok: false, error: 'content is required' });

    const llm = await getRouter();

    const ANALYSIS_PROMPTS = {
      classify: `Classify the following content into relevant categories. Return JSON: { "categories": [...], "primaryCategory": "...", "confidence": 0.0-1.0 }\n\nContent:\n${content}`,
      summarize: `Summarize the following content concisely. Return the key points.\n\nContent:\n${content}`,
      extract: `Extract structured information from the following content. Return JSON with all key entities, facts, and relationships.\n\nContent:\n${content}`,
      sentiment: `Analyze the sentiment of the following content. Return JSON: { "sentiment": "positive|negative|neutral|mixed", "score": -1.0 to 1.0, "emotions": [...] }\n\nContent:\n${content}`,
      entities: `Extract named entities from the following content. Return JSON: { "persons": [...], "organizations": [...], "locations": [...], "dates": [...], "other": [...] }\n\nContent:\n${content}`,
      translate: `Translate the following content to ${context || 'English'}:\n\n${content}`,
      custom: context ? `${context}\n\nContent:\n${content}` : content,
    };

    const prompt = ANALYSIS_PROMPTS[analysisType] || ANALYSIS_PROMPTS.summarize;
    const taskTypeMap = {
      classify: 'quick_tasks',
      summarize: 'documentation',
      extract: 'research',
      sentiment: 'quick_tasks',
      entities: 'quick_tasks',
      translate: 'documentation',
      custom: 'quick_tasks',
    };

    const result = await llm.generate(prompt, {
      taskType: taskTypeMap[analysisType] || 'quick_tasks',
      maxTokens,
      systemPrompt: 'You are a precise content analyst. Follow the output format exactly.',
    });

    // Try to parse JSON for structured analysis types
    let structured = null;
    if (['classify', 'extract', 'sentiment', 'entities'].includes(analysisType)) {
      try {
        const match = result.text.match(/\{[\s\S]*\}/);
        if (match) structured = JSON.parse(match[0]);
      } catch { /* fallback to raw text */ }
    }

    res.json({
      ok: true,
      analysisType,
      text: result.text,
      structured,
      provider: result.provider,
      model: result.model,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * POST /api/brain/embed
 * Body: { text }
 */
router.post('/api/brain/embed', async (req, res) => {
  try {
    const { text } = req.body || {};
    if (!text) return res.status(400).json({ ok: false, error: 'text is required' });
    const llm = await getRouter();
    const result = await llm.embed(text);
    res.json({ ok: true, ...result });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * GET /api/brain/status — LLM router status.
 */
router.get('/api/brain/status', async (req, res) => {
  try {
    const llm = await getRouter();
    const health = await llm.health();
    res.json({ ok: true, ...health, memoryAttached: !!_vectorMemory });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

module.exports = router;
module.exports.setMemoryWrapper = setMemoryWrapper;
