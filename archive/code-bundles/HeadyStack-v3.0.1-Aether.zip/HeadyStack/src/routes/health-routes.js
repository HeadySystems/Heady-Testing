'use strict';

/**
 * Health Routes — Kubernetes-compatible liveness, readiness, and full health checks.
 * GET /live  — liveness probe (is the process alive?)
 * GET /ready — readiness probe (can it serve traffic?)
 * GET /full  — deep health introspection (all subsystems)
 */

const express = require('express');
const router = express.Router();

// Subsystem check registry — modules register their health functions here
const _checks = new Map();

/**
 * Register a health check function.
 * @param {string} name
 * @param {Function} fn — async () => { ok: boolean, details?: object }
 */
function registerCheck(name, fn) {
  _checks.set(name, fn);
}

// ─── Built-in checks ──────────────────────────────────────────────────────────

async function checkDatabase() {
  try {
    // Try to ping the DB if a pool is available globally
    if (global._headyDb && typeof global._headyDb.query === 'function') {
      await global._headyDb.query('SELECT 1');
      return { ok: true, latencyMs: 0 };
    }
    const dbUrl = process.env.DATABASE_URL;
    if (!dbUrl) return { ok: null, message: 'DATABASE_URL not configured' };
    return { ok: true, message: 'DB ping skipped (no pool)' };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function checkRedis() {
  try {
    if (global._headyRedis && typeof global._headyRedis.ping === 'function') {
      await global._headyRedis.ping();
      return { ok: true };
    }
    const redisUrl = process.env.REDIS_URL;
    if (!redisUrl) return { ok: null, message: 'REDIS_URL not configured' };
    return { ok: true, message: 'Redis ping skipped (no client)' };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function checkVectorMemory() {
  try {
    if (global._headyVectorMemory && typeof global._headyVectorMemory.ping === 'function') {
      await global._headyVectorMemory.ping();
      return { ok: true };
    }
    return { ok: null, message: 'VectorMemory not initialized' };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function checkLLMRouter() {
  try {
    const { getLLMRouter } = require('../services/llm-router');
    const router = getLLMRouter();
    const configured = Object.values(router.providers).some(p => {
      const envKey = { anthropic: 'ANTHROPIC_API_KEY', openai: 'OPENAI_API_KEY', groq: 'GROQ_API_KEY', google: 'GOOGLE_AI_API_KEY' }[p.vendor];
      return !envKey || !!process.env[envKey];
    });
    return { ok: configured, message: configured ? 'At least one LLM provider configured' : 'No LLM providers configured' };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

async function checkServiceManager() {
  try {
    const { getServiceManager } = require('../services/service-manager');
    const sm = getServiceManager();
    const status = sm.getSystemStatus();
    return { ok: status.allHealthy, ...status };
  } catch (err) {
    return { ok: null, message: 'Service manager not initialized' };
  }
}

// Register built-in checks
registerCheck('database', checkDatabase);
registerCheck('redis', checkRedis);
registerCheck('vectorMemory', checkVectorMemory);
registerCheck('llmRouter', checkLLMRouter);
registerCheck('serviceManager', checkServiceManager);

// ─── Routes ───────────────────────────────────────────────────────────────────

/**
 * GET /live — Liveness probe.
 * Returns 200 if the Node.js process is alive and responsive.
 * Kubernetes will restart the pod if this fails.
 */
router.get('/live', (req, res) => {
  res.status(200).json({
    status: 'alive',
    pid: process.pid,
    uptime: Math.floor(process.uptime()),
    ts: new Date().toISOString(),
  });
});

/**
 * GET /ready — Readiness probe.
 * Returns 200 if the service is ready to accept traffic.
 * Kubernetes will remove the pod from load balancer rotation if this fails.
 */
router.get('/ready', async (req, res) => {
  const timeout = parseInt(req.query.timeout) || 5000;
  const readinessChecks = ['database', 'redis'];

  const results = {};
  let allReady = true;

  await Promise.all(
    readinessChecks.map(async (name) => {
      const fn = _checks.get(name);
      if (!fn) return;
      try {
        const result = await Promise.race([
          fn(),
          new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), timeout)),
        ]);
        results[name] = result;
        if (result.ok === false) allReady = false;
      } catch (err) {
        results[name] = { ok: false, error: err.message };
        allReady = false;
      }
    })
  );

  const statusCode = allReady ? 200 : 503;
  res.status(statusCode).json({
    status: allReady ? 'ready' : 'not-ready',
    checks: results,
    ts: new Date().toISOString(),
  });
});

/**
 * GET /full — Deep health introspection.
 * Runs all registered health checks and returns comprehensive system status.
 * Not called by Kubernetes; used for dashboards and admin tooling.
 */
router.get('/full', async (req, res) => {
  const timeout = parseInt(req.query.timeout) || 10000;
  const results = {};
  let overallOk = true;

  await Promise.all(
    Array.from(_checks.entries()).map(async ([name, fn]) => {
      const start = Date.now();
      try {
        const result = await Promise.race([
          fn(),
          new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), timeout)),
        ]);
        result.latencyMs = Date.now() - start;
        results[name] = result;
        if (result.ok === false) overallOk = false;
      } catch (err) {
        results[name] = { ok: false, error: err.message, latencyMs: Date.now() - start };
        overallOk = false;
      }
    })
  );

  const mem = process.memoryUsage();
  const system = {
    uptime: Math.floor(process.uptime()),
    pid: process.pid,
    nodeVersion: process.version,
    platform: process.platform,
    memory: {
      rss: Math.round(mem.rss / 1024 / 1024) + 'MB',
      heapUsed: Math.round(mem.heapUsed / 1024 / 1024) + 'MB',
      heapTotal: Math.round(mem.heapTotal / 1024 / 1024) + 'MB',
    },
    env: process.env.NODE_ENV || 'development',
  };

  res.status(overallOk ? 200 : 207).json({
    status: overallOk ? 'healthy' : 'degraded',
    checks: results,
    system,
    ts: new Date().toISOString(),
  });
});

module.exports = router;
module.exports.registerCheck = registerCheck;
