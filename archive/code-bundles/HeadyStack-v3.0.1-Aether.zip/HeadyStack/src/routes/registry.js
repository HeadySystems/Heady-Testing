'use strict';

/**
 * Registry Routes — Service registry discovery.
 * GET /api/registry/services — list all registered services
 */

const express = require('express');
const path = require('path');
const fs = require('fs');
const router = express.Router();

// ─── Registry store ───────────────────────────────────────────────────────────

const _registry = new Map();

/**
 * Load registry from a JSON file (optional — registry is also built dynamically).
 */
function loadRegistry(registryPath) {
  if (!registryPath) {
    registryPath = path.resolve(process.cwd(), 'registry.json');
  }
  if (fs.existsSync(registryPath)) {
    try {
      const data = JSON.parse(fs.readFileSync(registryPath, 'utf8'));
      for (const [name, entry] of Object.entries(data.services || data)) {
        registerService(name, entry);
      }
      return true;
    } catch (err) {
      console.error('[registry] Failed to load registry file:', err.message);
      return false;
    }
  }
  return false;
}

function registerService(name, cfg = {}) {
  _registry.set(name, {
    name,
    description: cfg.description || '',
    version: cfg.version || '1.0.0',
    url: cfg.url || null,
    port: cfg.port || null,
    type: cfg.type || 'service',
    tags: cfg.tags || [],
    health: cfg.health || null,
    registeredAt: _registry.has(name) ? _registry.get(name).registeredAt : new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    meta: cfg.meta || {},
  });
}

function unregisterService(name) {
  return _registry.delete(name);
}

function getService(name) {
  return _registry.get(name) || null;
}

function listServices(opts = {}) {
  let services = Array.from(_registry.values());
  if (opts.type) services = services.filter(s => s.type === opts.type);
  if (opts.tag) services = services.filter(s => s.tags.includes(opts.tag));
  return services;
}

// Pre-register built-in HeadyStack services
function registerBuiltins() {
  const builtins = [
    { name: 'llm-router', description: 'Dynamic LLM provider routing', type: 'ai', port: null, tags: ['llm', 'core'] },
    { name: 'budget-tracker', description: 'LLM cost tracking', type: 'monitoring', tags: ['cost', 'core'] },
    { name: 'domain-router', description: 'Multi-domain request routing', type: 'routing', tags: ['domains', 'core'] },
    { name: 'autonomous-scheduler', description: 'Cron-based task scheduling', type: 'scheduler', tags: ['automation'] },
    { name: 'projection-engine', description: 'Monorepo projection', type: 'devops', tags: ['git', 'sync'] },
    { name: 'projection-governance', description: 'Projection governance rules', type: 'devops', tags: ['git', 'governance'] },
    { name: 'sdk-registration', description: 'External SDK registry', type: 'registry', tags: ['sdks'] },
    { name: 'ui-registry', description: 'HeadyWeb shell app registry', type: 'registry', tags: ['ui', 'apps'] },
    { name: 'continuous-embedder', description: 'Continuous embedding pipeline', type: 'ai', tags: ['vectors', 'embeddings'] },
    { name: 'arena-mode', description: 'Competitive model evaluation', type: 'ai', tags: ['arena', 'benchmarking'] },
    { name: 'battle-arena', description: 'Arena battle execution', type: 'ai', tags: ['arena'] },
    { name: 'buddy-system', description: 'Buddy companion sessions', type: 'user', tags: ['buddy', 'chat'] },
    { name: 'headybee-templates', description: 'Bee template registry', type: 'registry', tags: ['bees', 'agents'] },
    { name: 'admin-citadel', description: 'Admin control panel', type: 'admin', tags: ['admin'] },
    { name: 'service-manager', description: 'Service lifecycle manager', type: 'ops', tags: ['lifecycle'] },
    { name: 'error-sentinel', description: 'Error monitoring', type: 'monitoring', tags: ['errors', 'alerts'] },
    { name: 'vector-pipeline', description: 'Vector-augmented response pipeline', type: 'ai', tags: ['vectors'] },
    { name: 'vector-federation', description: 'Vector memory federation', type: 'ai', tags: ['vectors', 'distributed'] },
    { name: 'cross-device-sync', description: 'Cross-device sync hub', type: 'sync', tags: ['devices', 'sync'] },
    { name: 'system-monitor', description: 'System monitoring', type: 'monitoring', tags: ['monitoring'] },
    { name: 'self-optimizer', description: 'Self-optimization engine', type: 'ai', tags: ['optimization'] },
    { name: 'deep-research', description: 'Deep research engine', type: 'ai', tags: ['research'] },
    { name: 'agent-orchestrator', description: 'Agent orchestration', type: 'ai', tags: ['agents', 'orchestration'] },
  ];
  for (const svc of builtins) registerService(svc.name, svc);
}

registerBuiltins();

// ─── Routes ───────────────────────────────────────────────────────────────────

/**
 * GET /api/registry/services
 */
router.get('/api/registry/services', (req, res) => {
  const { type, tag } = req.query;
  const services = listServices({ type, tag });
  res.json({
    ok: true,
    services,
    total: services.length,
    allTotal: _registry.size,
  });
});

/**
 * GET /api/registry/services/:name
 */
router.get('/api/registry/services/:name', (req, res) => {
  const svc = getService(req.params.name);
  if (!svc) return res.status(404).json({ ok: false, error: 'Service not found' });
  res.json({ ok: true, service: svc });
});

/**
 * POST /api/registry/services — register or update a service
 */
router.post('/api/registry/services', (req, res) => {
  try {
    const { name, ...cfg } = req.body || {};
    if (!name) return res.status(400).json({ ok: false, error: 'name required' });
    registerService(name, cfg);
    res.status(201).json({ ok: true, service: getService(name) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * DELETE /api/registry/services/:name
 */
router.delete('/api/registry/services/:name', (req, res) => {
  const removed = unregisterService(req.params.name);
  res.json({ ok: removed, name: req.params.name });
});

/**
 * GET /api/registry/tags — list all unique tags
 */
router.get('/api/registry/tags', (req, res) => {
  const tags = new Set();
  for (const svc of _registry.values()) for (const tag of svc.tags) tags.add(tag);
  res.json({ ok: true, tags: Array.from(tags).sort() });
});

module.exports = router;
module.exports.loadRegistry = loadRegistry;
module.exports.registerService = registerService;
module.exports.unregisterService = unregisterService;
module.exports.getService = getService;
module.exports.listServices = listServices;
