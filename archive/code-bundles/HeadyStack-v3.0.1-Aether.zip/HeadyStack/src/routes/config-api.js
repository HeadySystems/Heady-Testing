'use strict';

/**
 * Config API Routes — System configuration management.
 * GET /api/config  — get current system configuration
 * PUT /api/config  — update configuration values
 */

const express = require('express');
const router = express.Router();

// ─── Config store ─────────────────────────────────────────────────────────────

const _config = new Map();
const _schema = new Map(); // key → { type, description, default, secret }
const _history = [];
const MAX_HISTORY = 500;

// ─── Schema definitions ───────────────────────────────────────────────────────

const DEFAULT_CONFIG = {
  // App
  'app.name': { value: 'HeadyStack', type: 'string', description: 'Application name' },
  'app.version': { value: process.env.APP_VERSION || '1.0.0', type: 'string', description: 'Application version' },
  'app.env': { value: process.env.NODE_ENV || 'development', type: 'string', description: 'Node environment' },
  'app.port': { value: parseInt(process.env.PORT) || 3000, type: 'number', description: 'HTTP port' },
  'app.debug': { value: process.env.DEBUG === 'true', type: 'boolean', description: 'Debug mode' },

  // LLM
  'llm.defaultTaskType': { value: 'quick_tasks', type: 'string', description: 'Default LLM task type' },
  'llm.maxTokens': { value: 2048, type: 'number', description: 'Default max tokens' },
  'llm.temperature': { value: 0.7, type: 'number', description: 'Default temperature' },
  'llm.monthlyCap': { value: 500, type: 'number', description: 'Monthly LLM spend cap (USD)' },

  // Budget
  'budget.dailyCap.default': { value: 20, type: 'number', description: 'Default daily budget per provider (USD)' },
  'budget.alertThreshold': { value: 0.8, type: 'number', description: 'Alert threshold (0-1)' },

  // Vector
  'vector.dims': { value: 384, type: 'number', description: 'Vector embedding dimensions' },
  'vector.model': { value: 'all-MiniLM-L6-v2', type: 'string', description: 'Embedding model' },
  'vector.topK': { value: 5, type: 'number', description: 'Default top-K for vector search' },

  // Arena
  'arena.defaultRounds': { value: 3, type: 'number', description: 'Default arena rounds per tournament' },
  'arena.judgeModel': { value: 'claude-3-5-sonnet', type: 'string', description: 'Arena judge model' },

  // Scheduler
  'scheduler.enabled': { value: true, type: 'boolean', description: 'Enable autonomous scheduler' },

  // Projection
  'projection.autoSync': { value: false, type: 'boolean', description: 'Auto-sync projections on change' },
  'projection.dryRun': { value: false, type: 'boolean', description: 'Dry-run projections by default' },

  // Buddy
  'buddy.idleTimeoutMinutes': { value: 30, type: 'number', description: 'Buddy session idle timeout (minutes)' },
  'buddy.maxHistoryMessages': { value: 50, type: 'number', description: 'Max buddy session history messages' },

  // Features
  'features.arena': { value: true, type: 'boolean', description: 'Enable Arena mode' },
  'features.vectorMemory': { value: true, type: 'boolean', description: 'Enable vector memory' },
  'features.continuousEmbedding': { value: false, type: 'boolean', description: 'Enable continuous embedding pipeline' },
  'features.selfOptimizer': { value: false, type: 'boolean', description: 'Enable self-optimizer' },
  'features.deepResearch': { value: true, type: 'boolean', description: 'Enable deep research engine' },
};

// Initialize from defaults and env
function initConfig() {
  for (const [key, def] of Object.entries(DEFAULT_CONFIG)) {
    const envKey = 'HEADY_' + key.replace(/\./g, '_').toUpperCase();
    const envVal = process.env[envKey];
    let value = def.value;
    if (envVal !== undefined) {
      if (def.type === 'number') value = parseFloat(envVal);
      else if (def.type === 'boolean') value = envVal === 'true';
      else value = envVal;
    }
    _config.set(key, { ...def, value, key });
  }
}

initConfig();

// ─── Config API ───────────────────────────────────────────────────────────────

function get(key) {
  const entry = _config.get(key);
  return entry ? entry.value : undefined;
}

function getAll(opts = {}) {
  const result = {};
  for (const [key, entry] of _config.entries()) {
    if (opts.prefix && !key.startsWith(opts.prefix)) continue;
    result[key] = entry.secret ? '[REDACTED]' : entry.value;
  }
  return result;
}

function set(key, value, opts = {}) {
  const existing = _config.get(key);
  const entry = existing ? { ...existing } : { key, type: typeof value, description: '' };

  // Type coercion
  if (entry.type === 'number') value = Number(value);
  else if (entry.type === 'boolean') value = value === true || value === 'true';

  const oldValue = existing ? existing.value : undefined;
  entry.value = value;
  entry.updatedAt = new Date().toISOString();
  if (opts.updatedBy) entry.updatedBy = opts.updatedBy;

  _config.set(key, entry);

  _history.push({ key, oldValue, newValue: value, ts: entry.updatedAt, updatedBy: opts.updatedBy || 'api' });
  if (_history.length > MAX_HISTORY) _history.shift();

  return entry;
}

function setMany(updates, opts = {}) {
  const results = {};
  for (const [key, value] of Object.entries(updates)) {
    results[key] = set(key, value, opts);
  }
  return results;
}

// ─── Routes ───────────────────────────────────────────────────────────────────

/**
 * GET /api/config — get all configuration
 */
router.get('/api/config', (req, res) => {
  const { prefix } = req.query;
  res.json({ ok: true, config: getAll({ prefix }) });
});

/**
 * GET /api/config/:key — get a single config value
 */
router.get('/api/config/:key(*)', (req, res) => {
  const key = req.params.key;
  const entry = _config.get(key);
  if (!entry) return res.status(404).json({ ok: false, error: `Config key not found: ${key}` });
  res.json({ ok: true, key, value: entry.secret ? '[REDACTED]' : entry.value, type: entry.type, description: entry.description });
});

/**
 * PUT /api/config — update multiple config values
 */
router.put('/api/config', (req, res) => {
  try {
    const updates = req.body || {};
    if (typeof updates !== 'object') return res.status(400).json({ ok: false, error: 'Request body must be an object' });
    const results = setMany(updates, { updatedBy: req.user?.sub || 'api' });
    res.json({ ok: true, updated: Object.keys(results), config: getAll() });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * PUT /api/config/:key — update a single config value
 */
router.put('/api/config/:key(*)', (req, res) => {
  try {
    const key = req.params.key;
    const { value } = req.body || {};
    if (value === undefined) return res.status(400).json({ ok: false, error: 'value required' });
    const entry = set(key, value, { updatedBy: req.user?.sub || 'api' });
    res.json({ ok: true, key, value: entry.value });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * GET /api/config/history — configuration change history
 */
router.get('/api/config/history', (req, res) => {
  const limit = parseInt(req.query.limit) || 100;
  res.json({ ok: true, history: _history.slice(-limit).reverse() });
});

/**
 * GET /api/config/schema — full config schema with descriptions
 */
router.get('/api/config/schema', (req, res) => {
  const schema = {};
  for (const [key, entry] of _config.entries()) {
    schema[key] = {
      type: entry.type,
      description: entry.description,
      default: entry.secret ? '[REDACTED]' : entry.value,
    };
  }
  res.json({ ok: true, schema });
});

module.exports = router;
module.exports.get = get;
module.exports.getAll = getAll;
module.exports.set = set;
module.exports.setMany = setMany;
