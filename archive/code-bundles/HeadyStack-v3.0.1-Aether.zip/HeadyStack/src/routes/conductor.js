'use strict';

/**
 * Conductor Routes — Task routing and orchestration.
 * POST /api/conductor/route — route a task to the appropriate handler
 */

const express = require('express');
const router = express.Router();

// ─── Task type detection ──────────────────────────────────────────────────────

const TASK_PATTERNS = [
  { pattern: /\b(write|create|generate|build|implement|code)\b.*\b(function|class|module|script|component|api|endpoint)\b/i, type: 'code_generation' },
  { pattern: /\b(review|audit|check|analyze|inspect)\b.*\b(code|function|module|implementation)\b/i, type: 'code_review' },
  { pattern: /\b(design|architect|plan|structure)\b.*\b(system|architecture|database|schema|api)\b/i, type: 'architecture' },
  { pattern: /\b(research|find|search|look up|investigate|explore)\b/i, type: 'research' },
  { pattern: /\b(quick|simple|short|brief|small|tiny)\b|\b(what is|how to|define)\b/i, type: 'quick_tasks' },
  { pattern: /\b(write|create|draft|compose)\b.*\b(story|blog|post|essay|poem|creative|narrative)\b/i, type: 'creative' },
  { pattern: /\b(security|vulnerability|exploit|penetration|threat|risk)\b/i, type: 'security_audit' },
  { pattern: /\b(document|docs|readme|explain|describe|how does)\b/i, type: 'documentation' },
  { pattern: /\b(embed|vector|semantic|similarity|encode)\b/i, type: 'embeddings' },
];

function detectTaskType(prompt) {
  for (const { pattern, type } of TASK_PATTERNS) {
    if (pattern.test(prompt)) return type;
  }
  return 'quick_tasks';
}

// ─── Routing handlers ─────────────────────────────────────────────────────────

const _handlers = new Map();

/**
 * Register a handler for a task type.
 */
function registerHandler(taskType, handler) {
  _handlers.set(taskType, handler);
}

/**
 * Default handler: route through LLM router.
 */
async function defaultHandler(task) {
  const { getLLMRouter } = require('../services/llm-router');
  const llmRouter = getLLMRouter();
  const result = await llmRouter.generate(task.prompt, {
    taskType: task.type,
    systemPrompt: task.systemPrompt,
    maxTokens: task.maxTokens,
    temperature: task.temperature,
  });
  return { ...result, handledBy: 'llm-router' };
}

// ─── Routes ───────────────────────────────────────────────────────────────────

/**
 * POST /api/conductor/route
 * Body: { prompt, type?, priority?, systemPrompt?, maxTokens?, temperature?, metadata? }
 */
router.post('/api/conductor/route', async (req, res) => {
  try {
    const {
      prompt,
      type,
      priority = 'normal',
      systemPrompt,
      maxTokens,
      temperature,
      metadata = {},
    } = req.body || {};

    if (!prompt) return res.status(400).json({ ok: false, error: 'prompt is required' });

    const detectedType = type || detectTaskType(prompt);
    const task = { prompt, type: detectedType, priority, systemPrompt, maxTokens, temperature, metadata };

    const handler = _handlers.get(detectedType) || defaultHandler;
    const startMs = Date.now();
    const result = await handler(task);
    const latencyMs = Date.now() - startMs;

    res.json({
      ok: true,
      taskType: detectedType,
      detected: !type,
      result,
      latencyMs,
      metadata,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * POST /api/conductor/detect-type — Detect the task type without routing
 */
router.post('/api/conductor/detect-type', (req, res) => {
  const { prompt } = req.body || {};
  if (!prompt) return res.status(400).json({ ok: false, error: 'prompt is required' });
  const type = detectTaskType(prompt);
  res.json({ ok: true, type, prompt: prompt.slice(0, 100) });
});

/**
 * GET /api/conductor/routing-matrix — Show which handlers are registered
 */
router.get('/api/conductor/routing-matrix', (req, res) => {
  const { ROUTING_MATRIX } = require('../services/llm-router');
  const customHandlers = Array.from(_handlers.keys());
  res.json({
    ok: true,
    llmRoutingMatrix: ROUTING_MATRIX,
    customHandlers,
    taskPatterns: TASK_PATTERNS.map(p => ({ pattern: p.pattern.toString(), type: p.type })),
  });
});

module.exports = router;
module.exports.registerHandler = registerHandler;
module.exports.detectTaskType = detectTaskType;
