'use strict';

/**
 * Pipeline API Routes — Task pipeline submission and lifecycle management.
 * POST /api/pipeline/submit        — submit a new task
 * GET  /api/pipeline/status/:id    — get task status
 * POST /api/pipeline/advance/:id   — advance to next stage
 */

const express = require('express');
const crypto = require('crypto');
const router = express.Router();

// ─── Pipeline stages ──────────────────────────────────────────────────────────

const STAGES = ['queued', 'validating', 'processing', 'reviewing', 'finalizing', 'complete', 'failed'];

const PIPELINE_STATUS = {
  QUEUED: 'queued',
  VALIDATING: 'validating',
  PROCESSING: 'processing',
  REVIEWING: 'reviewing',
  FINALIZING: 'finalizing',
  COMPLETE: 'complete',
  FAILED: 'failed',
  CANCELLED: 'cancelled',
};

// ─── In-memory pipeline store ─────────────────────────────────────────────────

const _tasks = new Map();
const _queue = [];    // ordered list of queued task IDs
let _isProcessing = false;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function createTask(cfg) {
  const id = 'task_' + crypto.randomBytes(10).toString('hex');
  const task = {
    id,
    type: cfg.type || 'default',
    priority: cfg.priority || 'normal',
    payload: cfg.payload || {},
    status: PIPELINE_STATUS.QUEUED,
    stage: 0,
    stages: cfg.stages || STAGES,
    result: null,
    error: null,
    submittedAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    completedAt: null,
    metadata: cfg.metadata || {},
    history: [{ stage: 'queued', ts: new Date().toISOString() }],
  };
  _tasks.set(id, task);
  _queue.push(id);
  return task;
}

function advanceTask(task) {
  const nextStageIndex = STAGES.indexOf(task.status) + 1;
  if (nextStageIndex >= STAGES.length || task.status === PIPELINE_STATUS.FAILED) {
    throw new Error(`Cannot advance from status: ${task.status}`);
  }
  const nextStatus = STAGES[nextStageIndex];
  task.status = nextStatus;
  task.stage = nextStageIndex;
  task.updatedAt = new Date().toISOString();
  task.history.push({ stage: nextStatus, ts: task.updatedAt });
  if (nextStatus === PIPELINE_STATUS.COMPLETE) {
    task.completedAt = task.updatedAt;
  }
  return task;
}

async function processNextInQueue() {
  if (_isProcessing || _queue.length === 0) return;
  _isProcessing = true;

  const taskId = _queue.shift();
  const task = _tasks.get(taskId);
  if (!task || task.status !== PIPELINE_STATUS.QUEUED) {
    _isProcessing = false;
    return processNextInQueue();
  }

  try {
    task.status = PIPELINE_STATUS.VALIDATING;
    task.history.push({ stage: 'validating', ts: new Date().toISOString() });

    // Validate
    await new Promise(r => setTimeout(r, 100));

    task.status = PIPELINE_STATUS.PROCESSING;
    task.history.push({ stage: 'processing', ts: new Date().toISOString() });

    // Process via LLM router if payload has a prompt
    if (task.payload.prompt) {
      const { getLLMRouter } = require('../services/llm-router');
      const llm = getLLMRouter();
      const result = await llm.generate(task.payload.prompt, {
        taskType: task.type,
        maxTokens: task.payload.maxTokens,
        systemPrompt: task.payload.systemPrompt,
      });
      task.result = result;
    }

    task.status = PIPELINE_STATUS.REVIEWING;
    task.history.push({ stage: 'reviewing', ts: new Date().toISOString() });

    await new Promise(r => setTimeout(r, 50));

    task.status = PIPELINE_STATUS.FINALIZING;
    task.history.push({ stage: 'finalizing', ts: new Date().toISOString() });

    task.status = PIPELINE_STATUS.COMPLETE;
    task.completedAt = new Date().toISOString();
    task.history.push({ stage: 'complete', ts: task.completedAt });
  } catch (err) {
    task.status = PIPELINE_STATUS.FAILED;
    task.error = err.message;
    task.history.push({ stage: 'failed', ts: new Date().toISOString(), error: err.message });
  } finally {
    task.updatedAt = new Date().toISOString();
    _isProcessing = false;
    // Process next task asynchronously
    setImmediate(processNextInQueue);
  }
}

// ─── Routes ───────────────────────────────────────────────────────────────────

/**
 * POST /api/pipeline/submit
 * Body: { type, priority, payload, stages?, metadata? }
 */
router.post('/api/pipeline/submit', (req, res) => {
  try {
    const { type, priority, payload, stages, metadata } = req.body || {};
    if (!payload) return res.status(400).json({ ok: false, error: 'payload is required' });

    const task = createTask({ type, priority, payload, stages, metadata });

    // Start processing asynchronously
    setImmediate(processNextInQueue);

    res.status(201).json({
      ok: true,
      taskId: task.id,
      status: task.status,
      submittedAt: task.submittedAt,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * GET /api/pipeline/status/:id
 */
router.get('/api/pipeline/status/:id', (req, res) => {
  const task = _tasks.get(req.params.id);
  if (!task) return res.status(404).json({ ok: false, error: 'Task not found' });
  res.json({
    ok: true,
    id: task.id,
    type: task.type,
    status: task.status,
    stage: task.stage,
    result: task.result,
    error: task.error,
    history: task.history,
    submittedAt: task.submittedAt,
    updatedAt: task.updatedAt,
    completedAt: task.completedAt,
    metadata: task.metadata,
  });
});

/**
 * POST /api/pipeline/advance/:id — Manually advance a task to the next stage.
 */
router.post('/api/pipeline/advance/:id', (req, res) => {
  try {
    const task = _tasks.get(req.params.id);
    if (!task) return res.status(404).json({ ok: false, error: 'Task not found' });
    const advanced = advanceTask(task);
    res.json({ ok: true, id: advanced.id, status: advanced.status, stage: advanced.stage });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/**
 * POST /api/pipeline/cancel/:id
 */
router.post('/api/pipeline/cancel/:id', (req, res) => {
  const task = _tasks.get(req.params.id);
  if (!task) return res.status(404).json({ ok: false, error: 'Task not found' });
  if ([PIPELINE_STATUS.COMPLETE, PIPELINE_STATUS.FAILED].includes(task.status)) {
    return res.status(400).json({ ok: false, error: `Cannot cancel task in status: ${task.status}` });
  }
  task.status = PIPELINE_STATUS.CANCELLED;
  task.updatedAt = new Date().toISOString();
  task.history.push({ stage: 'cancelled', ts: task.updatedAt });
  res.json({ ok: true, id: task.id, status: task.status });
});

/**
 * GET /api/pipeline/tasks — List all tasks
 */
router.get('/api/pipeline/tasks', (req, res) => {
  const { status, limit } = req.query;
  let tasks = Array.from(_tasks.values());
  if (status) tasks = tasks.filter(t => t.status === status);
  const lim = parseInt(limit) || 100;
  tasks = tasks.slice(-lim).reverse();
  res.json({ ok: true, tasks, total: _tasks.size, queueDepth: _queue.length });
});

/**
 * GET /api/pipeline/stats
 */
router.get('/api/pipeline/stats', (req, res) => {
  const all = Array.from(_tasks.values());
  const byStatus = {};
  for (const t of all) byStatus[t.status] = (byStatus[t.status] || 0) + 1;
  res.json({ ok: true, total: all.length, byStatus, queueDepth: _queue.length });
});

module.exports = router;
module.exports.PIPELINE_STATUS = PIPELINE_STATUS;
