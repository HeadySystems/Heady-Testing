'use strict';

/**
 * Auth Routes — JWT-based authentication.
 * POST /login    — authenticate and receive tokens
 * POST /register — create new user account
 * POST /refresh  — exchange refresh token for new access token
 * POST /logout   — invalidate session
 * GET  /me       — current user info
 */

const express = require('express');
const crypto = require('crypto');
const router = express.Router();

// Lazy-load JWT to avoid hard dependency on startup
function getJwt() {
  try { return require('jsonwebtoken'); } catch (e) { return null; }
}

function getBcrypt() {
  try { return require('bcryptjs'); } catch (e) {
    try { return require('bcrypt'); } catch (e2) { return null; }
  }
}

const ACCESS_TOKEN_TTL = process.env.ACCESS_TOKEN_TTL || '1h';
const REFRESH_TOKEN_TTL = process.env.REFRESH_TOKEN_TTL || '7d';
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString('hex');
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || crypto.randomBytes(32).toString('hex');

if (!process.env.JWT_SECRET) {
  console.warn('[auth-routes] WARNING: JWT_SECRET not set in environment — using ephemeral key. Sessions will not persist across restarts.');
}

// ─── In-memory user store (replace with DB in production) ────────────────────
const _users = new Map();      // userId → UserRecord
const _usersByEmail = new Map(); // email → userId
const _refreshTokens = new Set(); // valid refresh tokens

// ─── Helpers ──────────────────────────────────────────────────────────────────

function generateUserId() {
  return 'usr_' + crypto.randomBytes(12).toString('hex');
}

async function hashPassword(password) {
  const bcrypt = getBcrypt();
  if (bcrypt) return await bcrypt.hash(password, 12);
  // Fallback: PBKDF2
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16).toString('hex');
    crypto.pbkdf2(password, salt, 100000, 64, 'sha512', (err, dk) => {
      if (err) reject(err);
      else resolve(`pbkdf2:${salt}:${dk.toString('hex')}`);
    });
  });
}

async function comparePassword(password, hash) {
  const bcrypt = getBcrypt();
  if (bcrypt) return await bcrypt.compare(password, hash);
  // Fallback: PBKDF2
  const [, salt, stored] = hash.split(':');
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(password, salt, 100000, 64, 'sha512', (err, dk) => {
      if (err) reject(err);
      else resolve(dk.toString('hex') === stored);
    });
  });
}

function signToken(payload, secret, expiresIn) {
  const jwt = getJwt();
  if (jwt) return jwt.sign(payload, secret, { expiresIn });
  // Fallback: simple base64 token (NOT secure, only for dev without jwt package)
  const header = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
  const body = Buffer.from(JSON.stringify({ ...payload, exp: Math.floor(Date.now() / 1000) + 3600 })).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
}

function verifyToken(token, secret) {
  const jwt = getJwt();
  if (jwt) return jwt.verify(token, secret);
  // Fallback verifier
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('Invalid token format');
  const sig = crypto.createHmac('sha256', secret).update(`${parts[0]}.${parts[1]}`).digest('base64url');
  if (sig !== parts[2]) throw new Error('Invalid signature');
  const payload = JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'));
  if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) throw new Error('Token expired');
  return payload;
}

function sanitizeUser(user) {
  const { passwordHash, ...safe } = user;
  return safe;
}

// ─── Auth middleware (exported for use in other routes) ───────────────────────

function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : req.cookies?.accessToken;
  if (!token) return res.status(401).json({ ok: false, error: 'Authentication required' });
  try {
    const payload = verifyToken(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ ok: false, error: 'Invalid or expired token' });
  }
}

function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : req.cookies?.accessToken;
  if (token) {
    try {
      req.user = verifyToken(token, JWT_SECRET);
    } catch { /* ignore */ }
  }
  next();
}

// ─── Routes ───────────────────────────────────────────────────────────────────

/**
 * POST /register — Create a new account.
 */
router.post('/register', async (req, res) => {
  try {
    const { email, password, name, role } = req.body || {};
    if (!email || !password) return res.status(400).json({ ok: false, error: 'email and password required' });
    if (password.length < 8) return res.status(400).json({ ok: false, error: 'Password must be at least 8 characters' });
    if (_usersByEmail.has(email.toLowerCase())) {
      return res.status(409).json({ ok: false, error: 'Email already registered' });
    }

    const userId = generateUserId();
    const passwordHash = await hashPassword(password);
    const user = {
      id: userId,
      email: email.toLowerCase(),
      name: name || email.split('@')[0],
      role: role === 'admin' ? 'user' : (role || 'user'), // can't self-assign admin
      passwordHash,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      active: true,
    };

    _users.set(userId, user);
    _usersByEmail.set(email.toLowerCase(), userId);

    const accessToken = signToken({ sub: userId, email: user.email, role: user.role }, JWT_SECRET, ACCESS_TOKEN_TTL);
    const refreshToken = crypto.randomBytes(40).toString('hex');
    _refreshTokens.add(refreshToken);

    res.status(201).json({
      ok: true,
      user: sanitizeUser(user),
      accessToken,
      refreshToken,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * POST /login — Authenticate and receive JWT tokens.
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (!email || !password) return res.status(400).json({ ok: false, error: 'email and password required' });

    const userId = _usersByEmail.get(email.toLowerCase());
    if (!userId) return res.status(401).json({ ok: false, error: 'Invalid credentials' });

    const user = _users.get(userId);
    if (!user || !user.active) return res.status(401).json({ ok: false, error: 'Account inactive' });

    const valid = await comparePassword(password, user.passwordHash);
    if (!valid) return res.status(401).json({ ok: false, error: 'Invalid credentials' });

    const accessToken = signToken({ sub: userId, email: user.email, role: user.role }, JWT_SECRET, ACCESS_TOKEN_TTL);
    const refreshToken = crypto.randomBytes(40).toString('hex');
    _refreshTokens.add(refreshToken);

    user.lastLogin = new Date().toISOString();

    res.json({
      ok: true,
      user: sanitizeUser(user),
      accessToken,
      refreshToken,
    });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * POST /refresh — Exchange refresh token for new access token.
 */
router.post('/refresh', (req, res) => {
  const { refreshToken } = req.body || {};
  if (!refreshToken) return res.status(400).json({ ok: false, error: 'refreshToken required' });
  if (!_refreshTokens.has(refreshToken)) return res.status(401).json({ ok: false, error: 'Invalid refresh token' });

  // Refresh tokens are one-use
  _refreshTokens.delete(refreshToken);

  // We need the user context from the request or a user lookup
  const userId = req.body.userId;
  if (!userId) return res.status(400).json({ ok: false, error: 'userId required' });

  const user = _users.get(userId);
  if (!user || !user.active) return res.status(401).json({ ok: false, error: 'User not found or inactive' });

  const newAccessToken = signToken({ sub: user.id, email: user.email, role: user.role }, JWT_SECRET, ACCESS_TOKEN_TTL);
  const newRefreshToken = crypto.randomBytes(40).toString('hex');
  _refreshTokens.add(newRefreshToken);

  res.json({ ok: true, accessToken: newAccessToken, refreshToken: newRefreshToken });
});

/**
 * POST /logout — Invalidate refresh token.
 */
router.post('/logout', (req, res) => {
  const { refreshToken } = req.body || {};
  if (refreshToken) _refreshTokens.delete(refreshToken);
  // Access tokens are stateless JWTs — they expire on their own
  // For immediate invalidation, use a token blacklist (Redis)
  res.json({ ok: true, message: 'Logged out' });
});

/**
 * GET /me — Current user info (requires auth).
 */
router.get('/me', requireAuth, (req, res) => {
  const user = _users.get(req.user.sub);
  if (!user) return res.status(404).json({ ok: false, error: 'User not found' });
  res.json({ ok: true, user: sanitizeUser(user) });
});

/**
 * PUT /me — Update current user profile.
 */
router.put('/me', requireAuth, async (req, res) => {
  try {
    const user = _users.get(req.user.sub);
    if (!user) return res.status(404).json({ ok: false, error: 'User not found' });

    const { name, password } = req.body || {};
    if (name) user.name = name;
    if (password) {
      if (password.length < 8) return res.status(400).json({ ok: false, error: 'Password must be at least 8 characters' });
      user.passwordHash = await hashPassword(password);
    }
    user.updatedAt = new Date().toISOString();

    res.json({ ok: true, user: sanitizeUser(user) });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

module.exports = router;
module.exports.requireAuth = requireAuth;
module.exports.optionalAuth = optionalAuth;
module.exports.verifyToken = verifyToken;
module.exports.JWT_SECRET = JWT_SECRET;
