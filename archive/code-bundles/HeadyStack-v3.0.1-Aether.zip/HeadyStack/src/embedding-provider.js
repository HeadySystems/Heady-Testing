'use strict';

/**
 * @module embedding-provider
 * @description Multi-provider embedding generation for HeadyStack v3.0.1 "Aether".
 *
 * Provider chain: ['local', 'openai', 'cloudflare']
 *  - local    — deterministic hash-based 384D embeddings (no API required)
 *  - openai   — text-embedding-3-small via OpenAI REST API
 *  - cloudflare — @cf/baai/bge-base-en-v1.5 via Cloudflare Workers AI
 *
 * Each provider has a circuit-breaker: after CIRCUIT_OPEN_THRESHOLD failures
 * the breaker opens (blocks calls) for CIRCUIT_RESET_MS before retrying.
 */

const https = require('https');
const logger = require('./utils/logger');

// ─── Constants ────────────────────────────────────────────────────────────────

const EMBEDDING_DIM = 384;
const CIRCUIT_OPEN_THRESHOLD = parseInt(process.env.CB_THRESHOLD || '5', 10);
const CIRCUIT_RESET_MS = parseInt(process.env.CB_RESET_MS || '30000', 10);

// ─── Circuit Breaker ──────────────────────────────────────────────────────────

class CircuitBreaker {
  /**
   * @param {string} name
   */
  constructor(name) {
    this.name = name;
    this._failures = 0;
    this._state = 'CLOSED'; // CLOSED | OPEN | HALF_OPEN
    this._openedAt = 0;
  }

  /** @returns {boolean} */
  isOpen() {
    if (this._state === 'OPEN') {
      if (Date.now() - this._openedAt >= CIRCUIT_RESET_MS) {
        this._state = 'HALF_OPEN';
        logger.info(`circuit-breaker [${this.name}]: entering HALF_OPEN`);
        return false;
      }
      return true;
    }
    return false;
  }

  recordSuccess() {
    this._failures = 0;
    this._state = 'CLOSED';
  }

  recordFailure() {
    this._failures++;
    if (this._failures >= CIRCUIT_OPEN_THRESHOLD) {
      this._state = 'OPEN';
      this._openedAt = Date.now();
      logger.warn(`circuit-breaker [${this.name}]: OPEN after ${this._failures} failures`);
    }
  }

  status() {
    return { name: this.name, state: this._state, failures: this._failures };
  }
}

// ─── HTTP helpers ─────────────────────────────────────────────────────────────

/**
 * Simple HTTPS POST with JSON body and JSON response.
 * @param {string} url
 * @param {object} body
 * @param {object} headers
 * @param {number} [timeoutMs=10000]
 * @returns {Promise<object>}
 */
function httpsPost(url, body, headers, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    const raw = JSON.stringify(body);
    const parsedUrl = new URL(url);

    const options = {
      hostname: parsedUrl.hostname,
      port: parsedUrl.port || 443,
      path: parsedUrl.pathname + parsedUrl.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(raw),
        ...headers,
      },
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (res.statusCode >= 400) {
            reject(new Error(`HTTP ${res.statusCode}: ${JSON.stringify(parsed)}`));
          } else {
            resolve(parsed);
          }
        } catch (e) {
          reject(new Error(`JSON parse error: ${data.slice(0, 200)}`));
        }
      });
    });

    req.on('error', reject);
    req.setTimeout(timeoutMs, () => {
      req.destroy(new Error(`Request timed out after ${timeoutMs}ms`));
    });

    req.write(raw);
    req.end();
  });
}

// ─── Hash-based local embedding ───────────────────────────────────────────────

/**
 * Deterministic 32-bit hash (FNV-1a variant).
 * @param {string} str
 * @param {number} seed
 * @returns {number}
 */
function fnv1a32(str, seed = 0x811c9dc5) {
  let hash = seed >>> 0;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193) >>> 0;
  }
  return hash;
}

/**
 * Generate a deterministic 384D Float64Array from a text string.
 * Uses FNV-1a with varying seeds to fill all 384 dimensions, then normalises.
 * @param {string} text
 * @returns {Float64Array}
 */
function localEmbedding(text) {
  const vec = new Float64Array(EMBEDDING_DIM);
  // Generate dimensions in 32-value chunks using different seeds
  for (let chunk = 0; chunk < Math.ceil(EMBEDDING_DIM / 32); chunk++) {
    const seed = fnv1a32(String(chunk), 0xdeadbeef);
    for (let i = 0; i < 32; i++) {
      const idx = chunk * 32 + i;
      if (idx >= EMBEDDING_DIM) break;
      const h = fnv1a32(text + '\x00' + idx, seed ^ fnv1a32(text.slice(0, 64)));
      // Map uint32 → [-1, 1]
      vec[idx] = (h / 0xffffffff) * 2 - 1;
    }
  }
  // L2 normalise
  let mag = 0;
  for (let i = 0; i < EMBEDDING_DIM; i++) mag += vec[i] * vec[i];
  mag = Math.sqrt(mag);
  if (mag > 0) for (let i = 0; i < EMBEDDING_DIM; i++) vec[i] /= mag;
  return vec;
}

// ─── EmbeddingProvider class ──────────────────────────────────────────────────

class EmbeddingProvider {
  /**
   * @param {object} [opts]
   * @param {string[]} [opts.providerChain] - ordered provider list
   * @param {string}  [opts.openaiApiKey]   - overrides OPENAI_API_KEY env var
   * @param {string}  [opts.cloudflareAccountId] - overrides CF_ACCOUNT_ID
   * @param {string}  [opts.cloudflareApiToken]  - overrides CF_API_TOKEN
   */
  constructor(opts = {}) {
    this.providerChain = opts.providerChain || ['local', 'openai', 'cloudflare'];

    this._openaiApiKey        = opts.openaiApiKey        || process.env.OPENAI_API_KEY        || '';
    this._cloudflareAccountId = opts.cloudflareAccountId || process.env.CF_ACCOUNT_ID         || '';
    this._cloudflareApiToken  = opts.cloudflareApiToken  || process.env.CF_API_TOKEN          || '';

    this._breakers = {
      local:      new CircuitBreaker('local'),
      openai:     new CircuitBreaker('openai'),
      cloudflare: new CircuitBreaker('cloudflare'),
    };

    this._stats = {
      local: { calls: 0, errors: 0 },
      openai: { calls: 0, errors: 0 },
      cloudflare: { calls: 0, errors: 0 },
    };
  }

  // ── Provider implementations ─────────────────────────────────────────────

  /**
   * Local deterministic embedding.
   * @param {string} text
   * @returns {Promise<Float64Array>}
   */
  async _localEmbed(text) {
    return localEmbedding(text);
  }

  /**
   * OpenAI text-embedding-3-small (padded/truncated to 384D).
   * @param {string} text
   * @returns {Promise<Float64Array>}
   */
  async _openaiEmbed(text) {
    if (!this._openaiApiKey) throw new Error('OPENAI_API_KEY not set');
    const response = await httpsPost(
      'https://api.openai.com/v1/embeddings',
      { model: 'text-embedding-3-small', input: text.slice(0, 8191), dimensions: EMBEDDING_DIM },
      { Authorization: `Bearer ${this._openaiApiKey}` }
    );
    const raw = response.data?.[0]?.embedding;
    if (!Array.isArray(raw)) throw new Error('Unexpected OpenAI response shape');
    const vec = new Float64Array(EMBEDDING_DIM);
    for (let i = 0; i < EMBEDDING_DIM; i++) vec[i] = raw[i] !== undefined ? raw[i] : 0;
    return vec;
  }

  /**
   * Cloudflare Workers AI embedding.
   * Model: @cf/baai/bge-base-en-v1.5 (768D output → padded/truncated to 384D).
   * @param {string} text
   * @returns {Promise<Float64Array>}
   */
  async _cloudflareEmbed(text) {
    if (!this._cloudflareAccountId || !this._cloudflareApiToken) {
      throw new Error('CF_ACCOUNT_ID or CF_API_TOKEN not set');
    }
    const url = `https://api.cloudflare.com/client/v4/accounts/${this._cloudflareAccountId}/ai/run/@cf/baai/bge-base-en-v1.5`;
    const response = await httpsPost(
      url,
      { text: text.slice(0, 4096) },
      { Authorization: `Bearer ${this._cloudflareApiToken}` }
    );
    const raw = response.result?.data?.[0];
    if (!Array.isArray(raw)) throw new Error('Unexpected Cloudflare AI response shape');
    const vec = new Float64Array(EMBEDDING_DIM);
    for (let i = 0; i < EMBEDDING_DIM; i++) vec[i] = raw[i] !== undefined ? raw[i] : 0;
    // L2 normalise to match other providers
    let mag = 0;
    for (let i = 0; i < EMBEDDING_DIM; i++) mag += vec[i] * vec[i];
    mag = Math.sqrt(mag);
    if (mag > 0) for (let i = 0; i < EMBEDDING_DIM; i++) vec[i] /= mag;
    return vec;
  }

  // ── Public API ───────────────────────────────────────────────────────────

  /**
   * Generate a 384D embedding for the given text using the provider chain.
   * Falls back to the next provider if a breaker is open or an error occurs.
   * @param {string} text
   * @returns {Promise<Float64Array>}
   */
  async generateEmbedding(text) {
    if (typeof text !== 'string' || text.trim().length === 0) {
      throw new Error('text must be a non-empty string');
    }

    const errors = [];

    for (const provider of this.providerChain) {
      const breaker = this._breakers[provider];
      if (!breaker) {
        logger.warn(`embedding-provider: unknown provider "${provider}", skipping`);
        continue;
      }

      if (breaker.isOpen()) {
        logger.debug(`embedding-provider: circuit OPEN for "${provider}", skipping`);
        continue;
      }

      try {
        let embedding;
        this._stats[provider].calls++;

        switch (provider) {
          case 'local':
            embedding = await this._localEmbed(text);
            break;
          case 'openai':
            embedding = await this._openaiEmbed(text);
            break;
          case 'cloudflare':
            embedding = await this._cloudflareEmbed(text);
            break;
          default:
            throw new Error(`Unknown provider: ${provider}`);
        }

        breaker.recordSuccess();
        logger.debug(`embedding-provider: used provider "${provider}"`);
        return embedding;

      } catch (err) {
        this._stats[provider].errors++;
        breaker.recordFailure();
        errors.push(`${provider}: ${err.message}`);
        logger.warn(`embedding-provider: provider "${provider}" failed — ${err.message}`);
      }
    }

    // All providers failed
    throw new Error(`All embedding providers failed: ${errors.join(' | ')}`);
  }

  /**
   * Generate embeddings for an array of texts (batched, sequential).
   * @param {string[]} texts
   * @returns {Promise<Float64Array[]>}
   */
  async generateBatch(texts) {
    const results = [];
    for (const text of texts) {
      results.push(await this.generateEmbedding(text));
    }
    return results;
  }

  /**
   * Status summary for all providers.
   * @returns {object}
   */
  status() {
    return {
      providerChain: this.providerChain,
      breakers: Object.fromEntries(
        Object.entries(this._breakers).map(([k, b]) => [k, b.status()])
      ),
      stats: this._stats,
    };
  }
}

// ─── Module exports ───────────────────────────────────────────────────────────

module.exports = {
  EmbeddingProvider,
  localEmbedding,
  CircuitBreaker,
  EMBEDDING_DIM,
};
