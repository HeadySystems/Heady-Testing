'use strict';

/**
 * HeadyStack — Redis Connection Pool
 * Provides a pool of Redis clients with graceful fallback when Redis is unavailable.
 */

let redis;
try {
  redis = require('redis');
} catch (_) {
  redis = null;
}

const logger = require('./logger').child('redis-pool');

const DEFAULT_POOL_SIZE = parseInt(process.env.REDIS_POOL_SIZE || '5', 10);
const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';

class RedisPool {
  constructor(options = {}) {
    this._url = options.url || REDIS_URL;
    this._poolSize = options.poolSize || DEFAULT_POOL_SIZE;
    this._pool = [];
    this._available = [];
    this._waitQueue = [];
    this._available_flag = true;
    this._initialized = false;
    this._unavailable = false;
  }

  async init() {
    if (this._initialized) return;
    if (!redis) {
      logger.warn('redis module not installed — Redis pool running in no-op mode');
      this._unavailable = true;
      this._initialized = true;
      return;
    }
    try {
      for (let i = 0; i < this._poolSize; i++) {
        const client = redis.createClient({ url: this._url });
        client.on('error', (err) => {
          logger.warn('Redis client error', { error: err.message });
        });
        await client.connect();
        this._pool.push(client);
        this._available.push(client);
      }
      this._initialized = true;
      logger.info(`Redis pool initialized with ${this._poolSize} connections`, { url: this._url });
    } catch (err) {
      logger.warn('Redis unavailable — pool running in no-op mode', { error: err.message });
      this._unavailable = true;
      this._initialized = true;
    }
  }

  /**
   * Acquires a Redis client from the pool.
   * Returns null if Redis is unavailable (graceful fallback).
   * @returns {Promise<object|null>}
   */
  async getClient() {
    if (!this._initialized) await this.init();
    if (this._unavailable) return null;

    if (this._available.length > 0) {
      return this._available.pop();
    }

    // Wait for a client to be released
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        const idx = this._waitQueue.indexOf(resolve);
        if (idx !== -1) this._waitQueue.splice(idx, 1);
        logger.warn('Redis pool getClient timeout — returning null');
        resolve(null);
      }, 5000);

      this._waitQueue.push((client) => {
        clearTimeout(timeout);
        resolve(client);
      });
    });
  }

  /**
   * Releases a client back to the pool.
   * @param {object} client
   */
  releaseClient(client) {
    if (!client || this._unavailable) return;
    if (this._waitQueue.length > 0) {
      const next = this._waitQueue.shift();
      next(client);
    } else {
      this._available.push(client);
    }
  }

  /**
   * Execute a Redis command with automatic acquire/release.
   * @param {function} fn - async (client) => result
   * @returns {Promise<any|null>}
   */
  async execute(fn) {
    const client = await this.getClient();
    if (!client) return null;
    try {
      return await fn(client);
    } finally {
      this.releaseClient(client);
    }
  }

  /**
   * Gracefully close all pool connections.
   */
  async close() {
    if (this._unavailable) return;
    for (const client of this._pool) {
      try {
        await client.quit();
      } catch (_) { /* ignore */ }
    }
    this._pool = [];
    this._available = [];
    this._initialized = false;
    logger.info('Redis pool closed');
  }

  get isAvailable() {
    return !this._unavailable;
  }
}

// Singleton pool
let _pool = null;

function getPool(options) {
  if (!_pool) {
    _pool = new RedisPool(options);
  }
  return _pool;
}

async function getClient(options) {
  return getPool(options).getClient();
}

function releaseClient(client) {
  if (_pool) _pool.releaseClient(client);
}

module.exports = { RedisPool, getPool, getClient, releaseClient };
