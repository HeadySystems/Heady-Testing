'use strict';

/**
 * HeadyStack — Structured JSON Logger
 * Provides leveled, structured logging with child logger support
 * and node activity logging for the conductor subsystem.
 */

const os = require('os');

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const LEVEL_NAMES = { 10: 'debug', 20: 'info', 30: 'warn', 40: 'error' };

function getMinLevel() {
  const env = (process.env.LOG_LEVEL || 'info').toLowerCase();
  return LEVELS[env] != null ? LEVELS[env] : LEVELS.info;
}

function formatEntry(level, message, extra, component) {
  const entry = {
    timestamp: new Date().toISOString(),
    level: LEVEL_NAMES[level] || 'info',
    pid: process.pid,
    host: os.hostname(),
    message,
  };
  if (component) entry.component = component;
  if (extra && typeof extra === 'object') {
    // Merge extra fields, but never overwrite core fields
    for (const key of Object.keys(extra)) {
      if (!entry[key]) entry[key] = extra[key];
    }
  }
  return entry;
}

function writeLog(level, message, extra, component) {
  if (level < getMinLevel()) return;
  const entry = formatEntry(level, message, extra, component);
  const line = JSON.stringify(entry);
  if (level >= LEVELS.error) {
    process.stderr.write(line + '\n');
  } else {
    process.stdout.write(line + '\n');
  }
}

class Logger {
  constructor(component) {
    this._component = component || null;
  }

  debug(message, extra) {
    writeLog(LEVELS.debug, message, extra, this._component);
  }

  info(message, extra) {
    writeLog(LEVELS.info, message, extra, this._component);
  }

  warn(message, extra) {
    writeLog(LEVELS.warn, message, extra, this._component);
  }

  error(message, extra) {
    // Support error objects
    if (extra instanceof Error) {
      extra = { errorMessage: extra.message, stack: extra.stack };
    }
    writeLog(LEVELS.error, message, extra, this._component);
  }

  /**
   * Creates a child logger with a specific component context.
   * @param {string} component
   * @returns {Logger}
   */
  child(component) {
    const child = new Logger(component);
    return child;
  }

  /**
   * Logs node activity for the conductor subsystem.
   * @param {string} node
   * @param {string} message
   * @param {object} [meta]
   */
  logNodeActivity(node, message, meta) {
    writeLog(LEVELS.info, message, Object.assign({ node }, meta || {}), this._component || 'conductor');
  }
}

// Singleton root logger
const rootLogger = new Logger();

module.exports = rootLogger;
module.exports.Logger = Logger;
module.exports.createLogger = function createLogger(component) {
  return new Logger(component);
};
