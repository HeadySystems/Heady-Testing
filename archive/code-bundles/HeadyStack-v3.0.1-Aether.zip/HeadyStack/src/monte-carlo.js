'use strict';

/**
 * @module monte-carlo
 * @description Monte Carlo Simulation Engine for HeadyStack v3.0.1 "Aether".
 *
 * Provides:
 *  - Mulberry32 seeded PRNG for reproducible runs
 *  - quickReadiness(signals) — fast Operational Readiness Score (ORS) with grade
 *  - runFullCycle(scenario, iterations) — full risk simulation with Wilson confidence intervals
 *  - History tracking (last 20 runs)
 */

const logger = require('./utils/logger');

// ─── Constants ────────────────────────────────────────────────────────────────

const RISK_GRADE = Object.freeze({
  GREEN:  'GREEN',   // score >= 80
  YELLOW: 'YELLOW',  // score >= 60
  ORANGE: 'ORANGE',  // score >= 40
  RED:    'RED',     // score <  40
});

const DEFAULT_ITERATIONS = 10000;

// ─── Mulberry32 PRNG ──────────────────────────────────────────────────────────

/**
 * Create a Mulberry32 seeded PRNG function.
 * @param {number} seed - 32-bit unsigned integer seed
 * @returns {() => number} — returns a float in [0, 1)
 */
function mulberry32(seed) {
  let s = seed >>> 0;
  return function () {
    s += 0x6d2b79f5;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), 1 | t);
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ─── Statistical helpers ──────────────────────────────────────────────────────

/**
 * Wilson score confidence interval for a proportion.
 * @param {number} successes
 * @param {number} trials
 * @param {number} [z=1.96] — z-score for desired confidence (1.96 ≈ 95%)
 * @returns {{ lower: number, upper: number, center: number }}
 */
function wilsonInterval(successes, trials, z = 1.96) {
  if (trials === 0) return { lower: 0, upper: 0, center: 0 };
  const p = successes / trials;
  const denom = 1 + (z * z) / trials;
  const center = (p + (z * z) / (2 * trials)) / denom;
  const margin = (z * Math.sqrt(p * (1 - p) / trials + (z * z) / (4 * trials * trials))) / denom;
  return {
    lower: Math.max(0, center - margin),
    upper: Math.min(1, center + margin),
    center,
  };
}

/**
 * Map a numeric score to a RISK_GRADE.
 * @param {number} score — 0-100
 * @returns {string}
 */
function scoreToGrade(score) {
  if (score >= 80) return RISK_GRADE.GREEN;
  if (score >= 60) return RISK_GRADE.YELLOW;
  if (score >= 40) return RISK_GRADE.ORANGE;
  return RISK_GRADE.RED;
}

// ─── MonteCarloEngine class ───────────────────────────────────────────────────

class MonteCarloEngine {
  constructor() {
    this._history = []; // last 20 run results
    this._totalRuns = 0;
    this._lastRun = null;
    // Default seed: current epoch seconds (deterministic within same second)
    this._defaultSeed = Math.floor(Date.now() / 1000);
  }

  // ── Quick readiness ──────────────────────────────────────────────────────

  /**
   * Fast Operational Readiness Score from system health signals.
   *
   * @param {object} signals
   * @param {number} [signals.errorRate=0]            — fraction of errors, 0-1
   * @param {boolean} [signals.lastDeploySuccess=true] — last deploy result
   * @param {number} [signals.cpuPressure=0]           — CPU pressure 0-1
   * @param {number} [signals.memoryPressure=0]        — memory pressure 0-1
   * @param {number} [signals.serviceHealthRatio=1]    — healthy services / total
   * @param {number} [signals.openIncidents=0]         — count of open incidents
   *
   * @returns {{ score: number, grade: string, factors: object }}
   */
  quickReadiness(signals = {}) {
    const {
      errorRate          = 0,
      lastDeploySuccess  = true,
      cpuPressure        = 0,
      memoryPressure     = 0,
      serviceHealthRatio = 1,
      openIncidents      = 0,
    } = signals;

    // Clamp all values to valid range
    const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

    const safeErrorRate    = clamp(errorRate, 0, 1);
    const safeCpu          = clamp(cpuPressure, 0, 1);
    const safeMem          = clamp(memoryPressure, 0, 1);
    const safeHealthRatio  = clamp(serviceHealthRatio, 0, 1);
    const safeIncidents    = Math.max(0, openIncidents);

    // Weighted component scores (each 0-100):
    //   errorRate        weight 30% — 0% errors = 100 points
    //   deploySuccess    weight 20% — success = 100, failure = 0
    //   cpuPressure      weight 15% — 0 pressure = 100
    //   memoryPressure   weight 15% — 0 pressure = 100
    //   serviceHealth    weight 15% — full health = 100
    //   openIncidents    weight  5% — 0 incidents = 100 (−10 per incident, floor 0)
    const errorScore    = (1 - safeErrorRate) * 100;
    const deployScore   = lastDeploySuccess ? 100 : 0;
    const cpuScore      = (1 - safeCpu) * 100;
    const memScore      = (1 - safeMem) * 100;
    const healthScore   = safeHealthRatio * 100;
    const incidentScore = Math.max(0, 100 - safeIncidents * 10);

    const score =
      errorScore   * 0.30 +
      deployScore  * 0.20 +
      cpuScore     * 0.15 +
      memScore     * 0.15 +
      healthScore  * 0.15 +
      incidentScore * 0.05;

    const result = {
      score: Math.round(score * 100) / 100,
      grade: scoreToGrade(score),
      factors: {
        errorScore, deployScore, cpuScore, memScore, healthScore, incidentScore,
      },
      signals,
      timestamp: Date.now(),
    };

    logger.debug('monte-carlo: quickReadiness', { score: result.score, grade: result.grade });
    return result;
  }

  // ── Full cycle simulation ─────────────────────────────────────────────────

  /**
   * Run a full Monte Carlo simulation for a given scenario.
   *
   * @param {object} scenario
   * @param {string} [scenario.name='unnamed']
   * @param {object} [scenario.riskFactors] — named factors with { probability: 0-1, impact: 0-1 }
   * @param {number} [scenario.baseSuccessRate=0.9] — base trial success probability
   * @param {object} [scenario.mitigations] — named mitigations with { effectiveness: 0-1, cost: number }
   * @param {number} [iterations=10000]
   * @param {number} [seed] — PRNG seed for reproducibility (default: auto)
   *
   * @returns {object} detailed simulation result
   */
  runFullCycle(scenario = {}, iterations = DEFAULT_ITERATIONS, seed) {
    const {
      name           = 'unnamed',
      riskFactors    = {},
      baseSuccessRate = 0.9,
      mitigations    = {},
    } = scenario;

    const usedSeed = seed !== undefined ? seed : (this._defaultSeed ^ iterations);
    const rand = mulberry32(usedSeed);

    let successes = 0;
    let totalRiskImpact = 0;
    const riskCounts = {};

    for (const rf of Object.keys(riskFactors)) riskCounts[rf] = 0;

    // ── Simulation loop ─────────────────────────────────────────────────────
    for (let i = 0; i < iterations; i++) {
      let trialSuccess = rand() < baseSuccessRate;
      let trialRisk = 0;

      for (const [rfName, rf] of Object.entries(riskFactors)) {
        const { probability = 0, impact = 0 } = rf;

        // Apply mitigation reduction
        let effectiveProb = probability;
        let effectiveImpact = impact;
        for (const mit of Object.values(mitigations)) {
          const eff = Math.min(1, mit.effectiveness || 0);
          effectiveProb   *= (1 - eff * 0.5);
          effectiveImpact *= (1 - eff * 0.5);
        }

        if (rand() < effectiveProb) {
          riskCounts[rfName]++;
          trialRisk += effectiveImpact;
          if (rand() < effectiveImpact) trialSuccess = false;
        }
      }

      if (trialSuccess) successes++;
      totalRiskImpact += trialRisk;
    }

    // ── Aggregate statistics ────────────────────────────────────────────────
    const successRate = successes / iterations;
    const avgRiskImpact = totalRiskImpact / iterations;
    const ci = wilsonInterval(successes, iterations);

    // ORS-equivalent score: weight success rate + inverse risk impact
    const score = Math.max(0, Math.min(100, successRate * 100 * (1 - avgRiskImpact * 0.3)));

    const riskBreakdown = {};
    for (const [rf, count] of Object.entries(riskCounts)) {
      riskBreakdown[rf] = {
        occurrenceRate: count / iterations,
        ...wilsonInterval(count, iterations),
      };
    }

    const mitigationSummary = Object.fromEntries(
      Object.entries(mitigations).map(([k, v]) => [k, {
        effectiveness: v.effectiveness,
        cost: v.cost,
        estimatedSaving: v.effectiveness * avgRiskImpact * 100,
      }])
    );

    const result = {
      name,
      iterations,
      seed: usedSeed,
      score: Math.round(score * 100) / 100,
      grade: scoreToGrade(score),
      successRate: Math.round(successRate * 10000) / 10000,
      successCount: successes,
      confidence95: {
        lower: Math.round(ci.lower * 10000) / 10000,
        upper: Math.round(ci.upper * 10000) / 10000,
      },
      avgRiskImpact: Math.round(avgRiskImpact * 10000) / 10000,
      riskBreakdown,
      mitigationSummary,
      timestamp: Date.now(),
    };

    // Store history
    this._history.push(result);
    if (this._history.length > 20) this._history.shift();
    this._totalRuns++;
    this._lastRun = result.timestamp;

    logger.info(`monte-carlo: fullCycle "${name}" score=${result.score} grade=${result.grade} iterations=${iterations}`);
    return result;
  }

  // ── History & status ──────────────────────────────────────────────────────

  /**
   * Retrieve recent run history.
   * @param {number} [limit=20]
   * @returns {object[]}
   */
  getHistory(limit = 20) {
    return this._history.slice(-Math.min(limit, this._history.length));
  }

  /**
   * Engine status summary.
   * @returns {object}
   */
  status() {
    return {
      totalRuns: this._totalRuns,
      lastRun: this._lastRun,
      historyLength: this._history.length,
      defaultSeed: this._defaultSeed,
    };
  }
}

// ─── Module exports ───────────────────────────────────────────────────────────

module.exports = {
  MonteCarloEngine,
  RISK_GRADE,
  mulberry32,
  wilsonInterval,
  scoreToGrade,
};
