'use strict';

/**
 * HeadyStack Bootstrap — Phase 2: Security Middleware
 *
 * Applies:
 *   - Helmet.js security headers
 *   - CORS with configurable Heady domain origins
 *   - Rate limiting (120 req/min default)
 *   - JSON body parser (10mb limit)
 *   - Request logging middleware
 *   - Domain-based site rendering
 *
 * module.exports = function(app, { logger, remoteConfig })
 */

const { CORS_ORIGINS, resolveService } = require('../config/domains');

/**
 * @param {import('express').Application} app
 * @param {object} deps
 * @param {object} deps.logger
 * @param {object} deps.remoteConfig
 */
module.exports = function applyMiddlewareStack(app, { logger, remoteConfig }) {
  const log = logger.child ? logger.child('middleware') : logger;

  // ── Helmet — Security Headers ──────────────────────────────────────────────
  let helmet;
  try {
    helmet = require('helmet');
    app.use(helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc:  ["'self'"],
          scriptSrc:   ["'self'", "'unsafe-inline'", 'cdn.jsdelivr.net'],
          styleSrc:    ["'self'", "'unsafe-inline'", 'fonts.googleapis.com'],
          fontSrc:     ["'self'", 'fonts.gstatic.com'],
          imgSrc:      ["'self'", 'data:', 'blob:', '*.headyme.com', '*.headysystems.com'],
          connectSrc:  ["'self'", 'wss:', 'ws:', '*.headyapi.com', '*.headyme.com'],
          frameSrc:    ["'none'"],
          objectSrc:   ["'none'"],
          upgradeInsecureRequests: [],
        },
      },
      crossOriginEmbedderPolicy: false, // Disable for cross-origin embedding of media
      hsts: {
        maxAge: 31536000,
        includeSubDomains: true,
        preload: true,
      },
    }));
    log.info('Helmet security headers applied');
  } catch (err) {
    log.warn('helmet not installed — skipping security headers', { error: err.message });
  }

  // ── CORS ───────────────────────────────────────────────────────────────────
  let cors;
  try {
    cors = require('cors');

    // Merge static origins with any runtime config
    const configOrigins = remoteConfig.get('cors.origins', []);
    const extraEnvOrigins = process.env.CORS_ORIGINS
      ? process.env.CORS_ORIGINS.split(',').map((o) => o.trim()).filter(Boolean)
      : [];

    const allowedOrigins = new Set([
      ...CORS_ORIGINS,
      ...configOrigins,
      ...extraEnvOrigins,
    ]);

    app.use(cors({
      origin(origin, callback) {
        // Allow same-origin and server-to-server (no Origin header)
        if (!origin) return callback(null, true);
        if (allowedOrigins.has(origin)) return callback(null, true);
        // Allow any *.heady* subdomain pattern
        if (/^https?:\/\/([a-z0-9-]+\.)?heady[a-z]+\.[a-z]+/.test(origin)) {
          return callback(null, true);
        }
        callback(new Error(`CORS: origin not allowed — ${origin}`));
      },
      methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
      allowedHeaders: [
        'Content-Type',
        'Authorization',
        'X-Heady-API-Key',
        'X-Heady-Service-Token',
        'X-Heady-Service-Id',
        'X-Request-Id',
      ],
      exposedHeaders: ['X-Request-Id', 'X-Heady-Version', 'Retry-After'],
      credentials: true,
      maxAge: 86400,
    }));
    log.info('CORS configured', { origins: allowedOrigins.size });
  } catch (err) {
    log.warn('cors not installed — skipping CORS headers', { error: err.message });
  }

  // ── Rate Limiting ──────────────────────────────────────────────────────────
  let rateLimit;
  try {
    rateLimit = require('express-rate-limit');
    const windowMs  = parseInt(remoteConfig.get('rateLimit.windowMs', process.env.RATE_LIMIT_WINDOW_MS || '60000'), 10);
    const max       = parseInt(remoteConfig.get('rateLimit.max',      process.env.RATE_LIMIT_MAX      || '120'),   10);

    const limiter = rateLimit({
      windowMs,
      max,
      standardHeaders: true,
      legacyHeaders: false,
      keyGenerator: (req) => {
        // Use CF-Connecting-IP if present (behind Cloudflare)
        return req.headers['cf-connecting-ip']
          || req.headers['x-forwarded-for']?.split(',')[0].trim()
          || req.ip;
      },
      skip: (req) => {
        // Skip rate limiting for internal health checks
        return req.path === '/health' || req.path === '/api/pulse';
      },
      handler: (req, res) => {
        res.status(429).json({
          error: 'RateLimitError',
          code: 'RATE_LIMIT_EXCEEDED',
          message: 'Too many requests — please slow down',
          retryAfter: Math.ceil(windowMs / 1000),
        });
      },
    });

    app.use('/api', limiter);
    log.info('Rate limiting applied', { windowMs, max, paths: ['/api'] });
  } catch (err) {
    log.warn('express-rate-limit not installed — skipping rate limiting', { error: err.message });
  }

  // ── Body Parser ────────────────────────────────────────────────────────────
  const express = require('express');
  const bodyLimit = remoteConfig.get('body.limit', process.env.BODY_LIMIT || '10mb');

  app.use(express.json({ limit: bodyLimit }));
  app.use(express.urlencoded({ extended: true, limit: bodyLimit }));
  log.info('Body parser configured', { limit: bodyLimit });

  // ── Request Logging Middleware ─────────────────────────────────────────────
  app.use((req, res, next) => {
    const startTime = Date.now();
    const requestId = req.headers['x-request-id'] || generateRequestId();
    req.requestId = requestId;
    res.setHeader('X-Request-Id', requestId);
    res.setHeader('X-Heady-Version', process.env.HEADY_VERSION || '3.0.1');

    res.on('finish', () => {
      const duration = Date.now() - startTime;
      const level = res.statusCode >= 500 ? 'error'
        : res.statusCode >= 400 ? 'warn'
        : 'info';

      log[level]('HTTP request', {
        method: req.method,
        path: req.path,
        status: res.statusCode,
        durationMs: duration,
        requestId,
        ip: req.headers['cf-connecting-ip'] || req.ip,
        userAgent: req.headers['user-agent'],
        contentLength: res.get('content-length'),
      });
    });

    next();
  });

  // ── Domain-Based Site Rendering ────────────────────────────────────────────
  app.use((req, res, next) => {
    const hostname = req.hostname || req.headers.host || '';
    const serviceKey = resolveService(hostname);
    if (serviceKey) {
      req.headyService = serviceKey;
      req.headyDomain = hostname;
    }
    next();
  });

  log.info('Middleware stack fully applied');
};

// ── Helpers ────────────────────────────────────────────────────────────────────

const crypto = require('crypto');

function generateRequestId() {
  return crypto.randomBytes(8).toString('hex');
}
