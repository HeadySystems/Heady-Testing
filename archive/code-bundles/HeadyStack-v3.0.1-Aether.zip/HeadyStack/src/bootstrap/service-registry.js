'use strict';

/**
 * HeadyStack Bootstrap — Phase 7: Service Registry
 *
 * Mounts 40+ services via try/require pattern.
 * Each service is logged on load or failure.
 *
 * module.exports = function mountServices(app, {
 *   logger, authEngine, vectorMemory, buddy, pipeline,
 *   _engines, secretsManager, cfManager, eventBus, projectRoot
 * })
 */

/**
 * Mount a service from a given path with try/require.
 * @param {import('express').Application} app
 * @param {string} servicePath - Require path
 * @param {object} deps - Dependency injection
 * @param {object} log - Logger
 * @param {string} label - Human-readable service name
 */
function mountService(app, servicePath, deps, log, label) {
  try {
    const service = require(servicePath);
    if (typeof service === 'function') {
      service(app, deps);
    } else if (service && typeof service.mount === 'function') {
      service.mount(app, deps);
    } else if (service && typeof service.register === 'function') {
      service.register(app, deps);
    }
    log.info(`Service loaded: ${label}`, { path: servicePath });
    return true;
  } catch (err) {
    if (err.code === 'MODULE_NOT_FOUND' && err.message.includes(servicePath)) {
      log.warn(`Service not found: ${label} — skipping`, { path: servicePath });
    } else {
      log.warn(`Service load error: ${label}`, { path: servicePath, error: err.message });
    }
    return false;
  }
}

/**
 * @param {import('express').Application} app
 * @param {object} deps
 */
module.exports = function mountServices(app, deps) {
  const {
    logger,
    authEngine,
    vectorMemory,
    buddy,
    pipeline,
    _engines,
    secretsManager,
    cfManager,
    eventBus,
    projectRoot,
  } = deps;

  const log = logger.child ? logger.child('service-registry') : logger;
  const root = projectRoot || require('path').resolve(process.cwd(), 'src', 'services');

  let loaded = 0;
  let failed = 0;

  function mount(relativePath, label) {
    const fullPath = require('path').join(root, relativePath);
    const ok = mountService(app, fullPath, deps, log, label);
    if (ok) loaded++; else failed++;
  }

  // ── Core API Services ──────────────────────────────────────────────────────
  mount('api/chat',              'chat-api');
  mount('api/completions',       'completions-api');
  mount('api/embeddings',        'embeddings-api');
  mount('api/images',            'images-api');
  mount('api/audio',             'audio-api');
  mount('api/files',             'files-api');
  mount('api/search',            'search-api');

  // ── Vector / Memory Services ───────────────────────────────────────────────
  mount('vector/federation',     'vector-federation');
  mount('vector/cluster',        'vector-cluster');
  mount('vector/snapshot',       'vector-snapshot');
  mount('vector/export',         'vector-export');

  // ── Agent / Buddy Services ─────────────────────────────────────────────────
  mount('agents/buddy',          'buddy-agent');
  mount('agents/conductor',      'conductor-agent');
  mount('agents/orchestrator',   'orchestrator-agent');
  mount('agents/planner',        'planner-agent');
  mount('agents/researcher',     'researcher-agent');
  mount('agents/coder',          'coder-agent');
  mount('agents/reviewer',       'reviewer-agent');

  // ── Knowledge / Notion ─────────────────────────────────────────────────────
  mount('knowledge/notion',      'notion-knowledge');
  mount('knowledge/github',      'github-knowledge');
  mount('knowledge/web',         'web-knowledge');
  mount('knowledge/documents',   'document-knowledge');

  // ── MCP (Model Control Protocol) ──────────────────────────────────────────
  mount('mcp/server',            'mcp-server');
  mount('mcp/tools',             'mcp-tools');
  mount('mcp/resources',         'mcp-resources');
  mount('mcp/prompts',           'mcp-prompts');

  // ── Auth / User Services ───────────────────────────────────────────────────
  mount('auth/users',            'users-service');
  mount('auth/roles',            'roles-service');
  mount('auth/audit',            'auth-audit');

  // ── Payments / Stripe ──────────────────────────────────────────────────────
  mount('payments/stripe',       'stripe-payments');
  mount('payments/webhooks',     'stripe-webhooks');
  mount('payments/subscriptions','subscriptions-service');

  // ── Render / Deploy ────────────────────────────────────────────────────────
  mount('deploy/render',         'render-deploy');
  mount('deploy/cloudflare',     'cloudflare-deploy');
  mount('deploy/git',            'git-deploy');

  // ── Monitoring / Observability ─────────────────────────────────────────────
  mount('monitoring/metrics',    'metrics-service');
  mount('monitoring/alerts',     'alerts-service');
  mount('monitoring/traces',     'trace-service');
  mount('monitoring/logs',       'log-aggregation');

  // ── Media Services ─────────────────────────────────────────────────────────
  mount('media/uploads',         'uploads-service');
  mount('media/transcription',   'transcription-service');
  mount('media/tts',             'tts-service');

  // ── Scheduler / Jobs ──────────────────────────────────────────────────────
  mount('jobs/scheduler',        'job-scheduler');
  mount('jobs/queue',            'job-queue');
  mount('jobs/workers',          'job-workers');

  // ── Site Rendering ─────────────────────────────────────────────────────────
  mount('sites/renderer',        'site-renderer');
  mount('sites/headyme',         'site-headyme');
  mount('sites/headysystems',    'site-headysystems');

  // ── Utilities ──────────────────────────────────────────────────────────────
  mount('utils/webhooks',        'webhooks-service');
  mount('utils/proxy',           'proxy-service');

  // ── Governance ─────────────────────────────────────────────────────────────
  // Code governance routes registered from security module
  try {
    const { CodeGovernance } = require('../security/code-governance');
    const governance = new CodeGovernance({ logger: log });
    governance.registerRoutes(app);
    log.info('Code governance registered');
    loaded++;
  } catch (err) {
    log.warn('Code governance registration error', { error: err.message });
  }

  // ── Service Registry API ───────────────────────────────────────────────────
  const _serviceManifest = {
    loaded,
    failed,
    total: loaded + failed,
    timestamp: new Date().toISOString(),
  };

  app.get('/api/services', (req, res) => {
    res.json(_serviceManifest);
  });

  log.info('Service registry complete', {
    loaded,
    failed,
    total: loaded + failed,
  });

  return { loaded, failed };
};
