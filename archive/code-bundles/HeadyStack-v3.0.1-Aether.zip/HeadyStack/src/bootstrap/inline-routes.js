'use strict';

/**
 * HeadyStack Bootstrap — Phase 8: Health, Pulse, and Layer Routes
 *
 * Registers:
 *   GET /health        — System health check
 *   GET /api/pulse     — Heartbeat / liveness
 *   GET /api/layer     — System layer info
 *   GET /api/status    — Extended status
 *   GET /api/version   — Version info
 *
 * module.exports = function(app, { logger, secretsManager, cfManager, authEngine, _engines })
 */

const os = require('os');

/**
 * @param {import('express').Application} app
 * @param {object} deps
 * @param {object} deps.logger
 * @param {object} deps.secretsManager
 * @param {object} deps.cfManager
 * @param {object} [deps.authEngine]
 * @param {object} [deps._engines]
 */
module.exports = function mountInlineRoutes(app, {
  logger,
  secretsManager,
  cfManager,
  authEngine,
  _engines,
}) {
  const log = logger.child ? logger.child('inline-routes') : logger;
  const startTime = Date.now();

  // ── GET /health ────────────────────────────────────────────────────────────
  app.get('/health', (req, res) => {
    const mem = process.memoryUsage();
    const uptimeSeconds = Math.floor((Date.now() - startTime) / 1000);

    const health = {
      status: 'ok',
      timestamp: new Date().toISOString(),
      uptime: uptimeSeconds,
      version: process.env.HEADY_VERSION || '3.0.1',
      codename: process.env.HEADY_CODENAME || 'Aether',
      env: process.env.NODE_ENV || 'development',
      pid: process.pid,
      hostname: os.hostname(),
      memory: {
        heapUsed:  bytesToMB(mem.heapUsed),
        heapTotal: bytesToMB(mem.heapTotal),
        rss:       bytesToMB(mem.rss),
        unit: 'MB',
      },
      load: os.loadavg(),
    };

    // Non-critical sub-checks
    const checks = {};

    // Secrets check
    if (secretsManager) {
      const audit = secretsManager.audit();
      const available = audit.filter((s) => s.available).length;
      checks.secrets = {
        available,
        total: audit.length,
        healthy: available > 0,
      };
    }

    // Cloudflare check
    if (cfManager) {
      checks.cloudflare = { configured: cfManager.isAvailable };
    }

    // Engines check
    if (_engines) {
      checks.engines = { active: Object.keys(_engines).length };
    }

    const allHealthy = Object.values(checks).every((c) => c.healthy !== false);
    health.checks = checks;
    health.healthy = allHealthy;

    res.status(allHealthy ? 200 : 503).json(health);
  });

  // ── GET /api/pulse ─────────────────────────────────────────────────────────
  app.get('/api/pulse', (req, res) => {
    res.json({
      alive: true,
      timestamp: new Date().toISOString(),
      uptime: Math.floor((Date.now() - startTime) / 1000),
      pid: process.pid,
    });
  });

  // ── GET /api/layer ─────────────────────────────────────────────────────────
  app.get('/api/layer', (req, res) => {
    const layer = {
      layer:    'application',
      stack:    'HeadyStack',
      version:  process.env.HEADY_VERSION || '3.0.1',
      codename: process.env.HEADY_CODENAME || 'Aether',
      node:     process.version,
      platform: process.platform,
      arch:     process.arch,
      env:      process.env.NODE_ENV || 'development',
      pid:      process.pid,
      hostname: os.hostname(),
      cpus:     os.cpus().length,
      modules: {
        bootstrap: true,
        vectorStack:   !!(global._headyVectorMemory),
        authEngine:    !!(authEngine),
        cfManager:     !!(cfManager && cfManager.isAvailable),
        engines:       !!(_engines),
      },
      uptime: {
        processSeconds: Math.floor(process.uptime()),
        serverMs:       Date.now() - startTime,
      },
      memory: {
        free:    bytesToMB(os.freemem()),
        total:   bytesToMB(os.totalmem()),
        process: bytesToMB(process.memoryUsage().rss),
        unit: 'MB',
      },
    };
    res.json(layer);
  });

  // ── GET /api/version ───────────────────────────────────────────────────────
  app.get('/api/version', (req, res) => {
    res.json({
      version:  process.env.HEADY_VERSION  || '3.0.1',
      codename: process.env.HEADY_CODENAME || 'Aether',
      buildAt:  process.env.BUILD_TIME     || null,
      commit:   process.env.GIT_COMMIT     || null,
      branch:   process.env.GIT_BRANCH     || null,
    });
  });

  // ── GET /api/status ────────────────────────────────────────────────────────
  app.get('/api/status', (req, res) => {
    const mem = process.memoryUsage();
    res.json({
      status: 'running',
      version: process.env.HEADY_VERSION || '3.0.1',
      uptime: Math.floor(process.uptime()),
      memory: {
        heapUsed:  bytesToMB(mem.heapUsed),
        heapTotal: bytesToMB(mem.heapTotal),
        rss:       bytesToMB(mem.rss),
        external:  bytesToMB(mem.external),
        unit: 'MB',
      },
      env: process.env.NODE_ENV || 'development',
      timestamp: new Date().toISOString(),
    });
  });

  // ── 404 catch-all for /api/* ───────────────────────────────────────────────
  app.use('/api/*', (req, res) => {
    res.status(404).json({
      error: 'NotFound',
      code: 'API_ENDPOINT_NOT_FOUND',
      message: `${req.method} ${req.path} is not a known API endpoint`,
      statusCode: 404,
    });
  });

  // ── Global error handler ──────────────────────────────────────────────────
  // Must be last middleware registered
  const { errorHandler } = require('../config/errors');
  app.use(errorHandler);

  log.info('Inline routes registered', {
    routes: [
      'GET /health',
      'GET /api/pulse',
      'GET /api/layer',
      'GET /api/version',
      'GET /api/status',
    ],
  });
};

// ── Helpers ────────────────────────────────────────────────────────────────────
function bytesToMB(bytes) {
  return Math.round((bytes / 1024 / 1024) * 100) / 100;
}
