'use strict';

/**
 * HeadyStack Bootstrap — Phase 3: Authentication Engine
 *
 * Provides:
 *   - JWT-based auth with refresh tokens
 *   - Bearer token validation middleware
 *   - API key authentication
 *   - OAuth 2.1 callback handling
 *   - Session management
 *
 * module.exports = function(app, { logger, secretsManager, cfManager })
 * Returns: { authEngine }
 */

const crypto = require('crypto');

// ─────────────────────────────────────────────────────────────────────────────
// JWT utility (supports both jsonwebtoken and a minimal built-in fallback)
// ─────────────────────────────────────────────────────────────────────────────
let _jwt = null;
function getJwt() {
  if (_jwt) return _jwt;
  try {
    _jwt = require('jsonwebtoken');
    return _jwt;
  } catch (_) {
    return null;
  }
}

/** Minimal JWT HS256 implementation for fallback when jsonwebtoken not installed */
function minimalJwtSign(payload, secret, expirySeconds) {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const claimsObj = { ...payload, iat: Math.floor(Date.now() / 1000) };
  if (expirySeconds) claimsObj.exp = claimsObj.iat + expirySeconds;
  const claims = Buffer.from(JSON.stringify(claimsObj)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(`${header}.${claims}`).digest('base64url');
  return `${header}.${claims}.${sig}`;
}

function minimalJwtVerify(token, secret) {
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('Invalid JWT format');
  const [header, claims, sig] = parts;
  const expected = crypto.createHmac('sha256', secret).update(`${header}.${claims}`).digest('base64url');
  if (!crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) {
    throw new Error('JWT signature invalid');
  }
  const payload = JSON.parse(Buffer.from(claims, 'base64url').toString('utf8'));
  if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
    throw new Error('JWT expired');
  }
  return payload;
}

// ─────────────────────────────────────────────────────────────────────────────
// Parse expiry string to seconds
// ─────────────────────────────────────────────────────────────────────────────
function parseExpiry(str) {
  if (typeof str === 'number') return str;
  const match = String(str).match(/^(\d+)(s|m|h|d|w)$/);
  if (!match) return 3600;
  const n = parseInt(match[1], 10);
  const unit = match[2];
  const multipliers = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 };
  return n * (multipliers[unit] || 1);
}

// ─────────────────────────────────────────────────────────────────────────────
// AuthEngine class
// ─────────────────────────────────────────────────────────────────────────────
class AuthEngine {
  constructor(options = {}) {
    this._logger = options.logger || console;
    this._secretsManager = options.secretsManager || null;
    this._cfManager = options.cfManager || null;
    this._jwtSecret = null;
    this._jwtExpiry = null;
    this._jwtRefreshExpiry = null;
    this._refreshTokenStore = new Map(); // token → { userId, issuedAt, expiresAt }
    this._sessionStore = new Map();      // sessionId → { userId, data, expiresAt }
    this._revokedTokens = new Set();     // jti set
    this._apiKeys = new Map();           // apiKey → { userId, scopes, name }
    this._initialized = false;
  }

  /**
   * Initialize the auth engine — resolves secrets and configures JWT.
   */
  async initialize() {
    if (this._initialized) return;

    // Resolve JWT secret
    this._jwtSecret = (this._secretsManager && this._secretsManager.get('jwt_secret'))
      || process.env.JWT_SECRET
      || crypto.randomBytes(64).toString('hex');

    if (!process.env.JWT_SECRET) {
      this._logger.warn && this._logger.warn('JWT_SECRET not set — using ephemeral random secret (tokens will not survive restart)');
    }

    this._jwtExpiry = process.env.JWT_EXPIRY || '1h';
    this._jwtRefreshExpiry = process.env.JWT_REFRESH_EXPIRY || '7d';

    // Register admin token as API key if present
    const adminToken = (this._secretsManager && this._secretsManager.get('admin_token'))
      || process.env.ADMIN_TOKEN;
    if (adminToken) {
      this._apiKeys.set(adminToken, { userId: 'admin', scopes: ['*'], name: 'admin-token' });
    }

    // Register heady_api_key as an API key
    const headyApiKey = (this._secretsManager && this._secretsManager.get('heady_api_key'))
      || process.env.HEADY_API_KEY;
    if (headyApiKey) {
      this._apiKeys.set(headyApiKey, { userId: 'heady-system', scopes: ['api', 'internal'], name: 'heady-api-key' });
    }

    this._initialized = true;
    this._logger.info && this._logger.info('AuthEngine initialized', {
      jwtExpiry: this._jwtExpiry,
      apiKeys: this._apiKeys.size,
    });
  }

  /**
   * Create a JWT access token.
   * @param {object} payload - Claims to include (userId, email, scopes, etc.)
   * @param {object} [options]
   * @param {string} [options.expiresIn]
   * @returns {string}
   */
  createToken(payload, options = {}) {
    const jti = crypto.randomBytes(16).toString('hex');
    const claims = { ...payload, jti };
    const expiry = options.expiresIn || this._jwtExpiry || '1h';
    const jwt = getJwt();
    if (jwt) {
      return jwt.sign(claims, this._jwtSecret, { expiresIn: expiry, algorithm: 'HS256' });
    }
    return minimalJwtSign(claims, this._jwtSecret, parseExpiry(expiry));
  }

  /**
   * Create a refresh token.
   * @param {string} userId
   * @returns {string}
   */
  createRefreshToken(userId) {
    const token = crypto.randomBytes(48).toString('base64url');
    const expirySeconds = parseExpiry(this._jwtRefreshExpiry || '7d');
    const expiresAt = new Date(Date.now() + expirySeconds * 1000);
    this._refreshTokenStore.set(token, { userId, issuedAt: new Date(), expiresAt });
    return token;
  }

  /**
   * Refresh an access token using a refresh token.
   * @param {string} refreshToken
   * @returns {{ accessToken: string, refreshToken: string, userId: string }|null}
   */
  refreshToken(refreshToken) {
    const record = this._refreshTokenStore.get(refreshToken);
    if (!record) return null;
    if (record.expiresAt < new Date()) {
      this._refreshTokenStore.delete(refreshToken);
      return null;
    }

    // Rotate refresh token
    this._refreshTokenStore.delete(refreshToken);
    const newRefreshToken = this.createRefreshToken(record.userId);
    const accessToken = this.createToken({ userId: record.userId });

    return { accessToken, refreshToken: newRefreshToken, userId: record.userId };
  }

  /**
   * Validate a JWT access token.
   * @param {string} token
   * @returns {{ valid: boolean, payload?: object, reason?: string }}
   */
  validateToken(token) {
    if (!token) return { valid: false, reason: 'MISSING_TOKEN' };
    try {
      let payload;
      const jwt = getJwt();
      if (jwt) {
        payload = jwt.verify(token, this._jwtSecret, { algorithms: ['HS256'] });
      } else {
        payload = minimalJwtVerify(token, this._jwtSecret);
      }

      // Check revocation
      if (payload.jti && this._revokedTokens.has(payload.jti)) {
        return { valid: false, reason: 'TOKEN_REVOKED' };
      }

      return { valid: true, payload };
    } catch (err) {
      const reason = err.message.includes('expired') ? 'TOKEN_EXPIRED'
        : err.message.includes('signature') ? 'INVALID_SIGNATURE'
        : 'INVALID_TOKEN';
      return { valid: false, reason };
    }
  }

  /**
   * Revoke a JWT by its jti.
   * @param {string} jti
   */
  revokeToken(jti) {
    this._revokedTokens.add(jti);
  }

  /**
   * Validate an API key.
   * @param {string} apiKey
   * @returns {{ valid: boolean, userId?: string, scopes?: string[], name?: string }}
   */
  validateApiKey(apiKey) {
    if (!apiKey) return { valid: false };
    const record = this._apiKeys.get(apiKey);
    if (!record) return { valid: false };
    return { valid: true, ...record };
  }

  /**
   * Register a custom API key.
   * @param {string} apiKey
   * @param {object} meta - { userId, scopes, name }
   */
  registerApiKey(apiKey, meta) {
    this._apiKeys.set(apiKey, meta);
  }

  // ── Session Management ────────────────────────────────────────────────────

  /**
   * Create a server-side session.
   * @param {string} userId
   * @param {object} [data]
   * @param {number} [ttlSeconds]
   * @returns {string} sessionId
   */
  createSession(userId, data = {}, ttlSeconds = 86400) {
    const sessionId = crypto.randomBytes(32).toString('base64url');
    const expiresAt = new Date(Date.now() + ttlSeconds * 1000);
    this._sessionStore.set(sessionId, { userId, data, expiresAt, createdAt: new Date() });
    return sessionId;
  }

  /**
   * Get a session by ID.
   * @param {string} sessionId
   * @returns {{ userId: string, data: object }|null}
   */
  getSession(sessionId) {
    const session = this._sessionStore.get(sessionId);
    if (!session) return null;
    if (session.expiresAt < new Date()) {
      this._sessionStore.delete(sessionId);
      return null;
    }
    return { userId: session.userId, data: session.data };
  }

  /**
   * Destroy a session.
   * @param {string} sessionId
   */
  destroySession(sessionId) {
    this._sessionStore.delete(sessionId);
  }

  // ── Express Middleware ────────────────────────────────────────────────────

  /**
   * Flexible authenticate middleware.
   * Accepts: Bearer JWT, API key (X-Heady-API-Key or x-api-key), or session cookie.
   * Sets req.user on success, calls next() in all cases (permissive by default).
   * Use requireAuth() for strict enforcement.
   */
  authenticate() {
    const self = this;
    return async (req, res, next) => {
      try {
        // Bearer JWT
        const authHeader = req.headers.authorization || '';
        if (authHeader.startsWith('Bearer ')) {
          const token = authHeader.slice(7).trim();
          const result = self.validateToken(token);
          if (result.valid) {
            req.user = { ...result.payload, authMethod: 'jwt' };
            return next();
          }
        }

        // API Key (header variants)
        const apiKey = req.headers['x-heady-api-key']
          || req.headers['x-api-key']
          || req.query.api_key;
        if (apiKey) {
          const keyResult = self.validateApiKey(apiKey);
          if (keyResult.valid) {
            req.user = { userId: keyResult.userId, scopes: keyResult.scopes, authMethod: 'apikey', name: keyResult.name };
            return next();
          }
        }

        // Session cookie
        const sessionId = req.cookies && req.cookies['heady-session'];
        if (sessionId) {
          const session = self.getSession(sessionId);
          if (session) {
            req.user = { userId: session.userId, ...session.data, authMethod: 'session' };
            return next();
          }
        }

        req.user = null;
        next();
      } catch (err) {
        self._logger.error && self._logger.error('Auth middleware error', { error: err.message });
        req.user = null;
        next();
      }
    };
  }

  /**
   * Strict authentication middleware — returns 401 if not authenticated.
   * @param {string[]} [requiredScopes]
   */
  requireAuth(requiredScopes = []) {
    const self = this;
    return [
      this.authenticate(),
      (req, res, next) => {
        if (!req.user) {
          return res.status(401).json({
            error: 'AuthError',
            code: 'AUTH_REQUIRED',
            message: 'Authentication required',
          });
        }
        if (requiredScopes.length > 0) {
          const userScopes = req.user.scopes || [];
          const hasAll = requiredScopes.every(
            (s) => userScopes.includes(s) || userScopes.includes('*')
          );
          if (!hasAll) {
            return res.status(403).json({
              error: 'AuthError',
              code: 'INSUFFICIENT_SCOPE',
              message: `Required scopes: ${requiredScopes.join(', ')}`,
            });
          }
        }
        next();
      },
    ];
  }

  // ── OAuth 2.1 ─────────────────────────────────────────────────────────────

  /**
   * Register OAuth 2.1 callback routes.
   * @param {import('express').Application} app
   */
  registerOAuthRoutes(app) {
    const clientId     = process.env.OAUTH_CLIENT_ID;
    const clientSecret = process.env.OAUTH_CLIENT_SECRET;
    const redirectUri  = process.env.OAUTH_REDIRECT_URI;

    if (!clientId || !clientSecret) {
      this._logger.info && this._logger.info('OAuth 2.1 not configured — skipping OAuth routes');
      return;
    }

    // GET /auth/oauth/authorize — redirect to authorization server
    app.get('/auth/oauth/authorize', (req, res) => {
      const state = crypto.randomBytes(16).toString('hex');
      // Store state in session for CSRF protection
      req.oauthState = state;
      const params = new URLSearchParams({
        response_type: 'code',
        client_id: clientId,
        redirect_uri: redirectUri || `${req.protocol}://${req.hostname}/auth/oauth/callback`,
        scope: req.query.scope || 'openid profile email',
        state,
        code_challenge_method: 'S256',
        code_challenge: this._generatePKCEChallenge(state),
      });
      const authServer = process.env.OAUTH_AUTH_SERVER || 'https://accounts.google.com/o/oauth2/v2/auth';
      res.redirect(`${authServer}?${params.toString()}`);
    });

    // GET /auth/oauth/callback — handle authorization code
    app.get('/auth/oauth/callback', async (req, res) => {
      const { code, state, error } = req.query;

      if (error) {
        return res.status(400).json({ error: 'OAuthError', message: error });
      }

      if (!code) {
        return res.status(400).json({ error: 'OAuthError', message: 'No authorization code received' });
      }

      try {
        // Exchange code for tokens
        const tokenEndpoint = process.env.OAUTH_TOKEN_ENDPOINT || 'https://oauth2.googleapis.com/token';
        let fetch;
        try { fetch = require('node-fetch'); } catch (_) { fetch = global.fetch; }

        const tokenRes = await fetch(tokenEndpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            grant_type: 'authorization_code',
            client_id: clientId,
            client_secret: clientSecret,
            redirect_uri: redirectUri || `${req.protocol}://${req.hostname}/auth/oauth/callback`,
            code,
          }).toString(),
        });

        const tokenData = await tokenRes.json();
        if (!tokenRes.ok) {
          return res.status(400).json({ error: 'OAuthError', message: tokenData.error_description || 'Token exchange failed' });
        }

        // Create internal session
        const accessToken = this.createToken({
          userId: tokenData.sub || 'oauth-user',
          email: tokenData.email,
          oauthToken: tokenData.access_token,
          scopes: (tokenData.scope || '').split(' '),
        });

        const refreshToken = this.createRefreshToken(tokenData.sub || 'oauth-user');

        this._logger.info && this._logger.info('OAuth 2.1 callback successful');

        const returnUrl = req.query.return_url || '/';
        res.redirect(`${returnUrl}?token=${encodeURIComponent(accessToken)}`);

      } catch (err) {
        this._logger.error && this._logger.error('OAuth callback error', { error: err.message });
        res.status(500).json({ error: 'OAuthError', message: 'Token exchange failed' });
      }
    });

    // POST /auth/token/refresh — refresh access token
    app.post('/auth/token/refresh', (req, res) => {
      const { refreshToken } = req.body || {};
      if (!refreshToken) {
        return res.status(400).json({ error: 'AuthError', code: 'MISSING_REFRESH_TOKEN' });
      }
      const result = this.refreshToken(refreshToken);
      if (!result) {
        return res.status(401).json({ error: 'AuthError', code: 'INVALID_REFRESH_TOKEN' });
      }
      res.json(result);
    });

    // POST /auth/token/revoke
    app.post('/auth/token/revoke', this.authenticate(), (req, res) => {
      if (req.user && req.user.jti) {
        this.revokeToken(req.user.jti);
      }
      res.json({ ok: true });
    });

    // GET /auth/me — current user info
    app.get('/auth/me', ...this.requireAuth(), (req, res) => {
      res.json({ user: req.user });
    });

    this._logger.info && this._logger.info('OAuth 2.1 routes registered');
  }

  _generatePKCEChallenge(state) {
    const verifier = crypto.createHash('sha256').update(state).digest('base64url');
    return verifier;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Module factory
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @param {import('express').Application} app
 * @param {object} deps
 * @param {object} deps.logger
 * @param {object} deps.secretsManager
 * @param {object} deps.cfManager
 * @returns {Promise<{ authEngine: AuthEngine }>}
 */
module.exports = async function mountAuthEngine(app, { logger, secretsManager, cfManager }) {
  const authEngine = new AuthEngine({ logger, secretsManager, cfManager });
  await authEngine.initialize();

  // Apply global permissive auth middleware (populates req.user)
  app.use(authEngine.authenticate());

  // Register OAuth routes
  authEngine.registerOAuthRoutes(app);

  return { authEngine };
};

module.exports.AuthEngine = AuthEngine;
