'use strict';

/**
 * HeadyStack Bootstrap — Phase 1: Environment + Globals
 *
 * Initializes:
 *   - Express application
 *   - Global event bus
 *   - Structured logger
 *   - Remote config (YAML)
 *   - Secrets manager
 *   - Cloudflare manager
 *
 * Registers all manifest secrets for the secrets manager.
 *
 * Exports: { app, logger, eventBus, remoteConfig, secretsManager, cfManager }
 */

const path = require('path');
const { EventEmitter } = require('events');

// ── Core helpers ──────────────────────────────
const { loadEnv } = require('../core/heady-env');
const { createApp } = require('../core/heady-server');
const { loadFile: loadYaml, load: parseYaml } = require('../core/heady-yaml');
const loggerModule = require('../utils/logger');

// ── Config ────────────────────────────────────
const { validateEnvironment } = require('../config/env-schema');

// ─────────────────────────────────────────────────────────────────────────────
// Step 1: Load .env
// ─────────────────────────────────────────────────────────────────────────────
const envResult = loadEnv({ path: path.resolve(process.cwd(), '.env') });

// ─────────────────────────────────────────────────────────────────────────────
// Step 2: Logger
// ─────────────────────────────────────────────────────────────────────────────
const logger = loggerModule.child('bootstrap');

if (envResult.loaded) {
  logger.info('Environment loaded', { path: envResult.path });
} else {
  logger.info('No .env file found — using process environment');
}

// ─────────────────────────────────────────────────────────────────────────────
// Step 3: Validate environment
// ─────────────────────────────────────────────────────────────────────────────
const envValidation = validateEnvironment({ warnOptional: false });
if (!envValidation.valid) {
  logger.warn('Environment validation errors', { errors: envValidation.errors });
}
if (envValidation.warnings.length > 0) {
  logger.warn('Environment warnings', { warnings: envValidation.warnings });
}

// ─────────────────────────────────────────────────────────────────────────────
// Step 4: Express app
// ─────────────────────────────────────────────────────────────────────────────
const app = createApp({ trustProxy: true });

// ─────────────────────────────────────────────────────────────────────────────
// Step 5: Global Event Bus
// ─────────────────────────────────────────────────────────────────────────────
const eventBus = new EventEmitter();
eventBus.setMaxListeners(200);
global.eventBus = eventBus;

logger.info('Event bus initialized');

// ─────────────────────────────────────────────────────────────────────────────
// Step 6: Remote Config (YAML)
// ─────────────────────────────────────────────────────────────────────────────
const REMOTE_CONFIG_PATH = process.env.REMOTE_CONFIG_PATH
  || path.resolve(process.cwd(), 'config', 'remote.yml');

let _remoteConfigData = {};
let _remoteConfigLoadedAt = null;

function loadRemoteConfig() {
  try {
    _remoteConfigData = loadYaml(REMOTE_CONFIG_PATH, { allowMissing: true });
    _remoteConfigLoadedAt = new Date();
    logger.info('Remote config loaded', { path: REMOTE_CONFIG_PATH });
  } catch (err) {
    logger.warn('Remote config load failed — using empty config', { error: err.message });
    _remoteConfigData = {};
  }
}

loadRemoteConfig();

const remoteConfig = {
  get(key, defaultValue) {
    const parts = key.split('.');
    let cursor = _remoteConfigData;
    for (const part of parts) {
      if (cursor == null || typeof cursor !== 'object') return defaultValue;
      cursor = cursor[part];
    }
    return cursor !== undefined ? cursor : defaultValue;
  },
  getAll() {
    return { ..._remoteConfigData };
  },
  reload() {
    loadRemoteConfig();
    return _remoteConfigData;
  },
  loadedAt() {
    return _remoteConfigLoadedAt;
  },
  set(key, value) {
    // In-memory override for dynamic config
    const parts = key.split('.');
    let cursor = _remoteConfigData;
    for (let i = 0; i < parts.length - 1; i++) {
      if (!cursor[parts[i]] || typeof cursor[parts[i]] !== 'object') {
        cursor[parts[i]] = {};
      }
      cursor = cursor[parts[i]];
    }
    cursor[parts[parts.length - 1]] = value;
  },
};

// ─────────────────────────────────────────────────────────────────────────────
// Step 7: Secrets Manager
// ─────────────────────────────────────────────────────────────────────────────

const MANIFEST_SECRETS = [
  'render_api_key',
  'heady_api_key',
  'admin_token',
  'database_url',
  'hf_token',
  'notion_token',
  'github_token',
  'stripe_secret_key',
  'stripe_webhook_secret',
  'jwt_secret',
  'session_secret',
  'openai_api_key',
  'anthropic_api_key',
  'google_api_key',
  'cf_api_token',
  'cf_account_id',
  'cf_zone_id',
  'cf_kv_namespace_id',
  'oauth_client_id',
  'oauth_client_secret',
  'redis_url',
];

/** Map secret registry names to env var names */
const SECRET_ENV_MAP = {
  render_api_key:          'RENDER_API_KEY',
  heady_api_key:           'HEADY_API_KEY',
  admin_token:             'ADMIN_TOKEN',
  database_url:            'DATABASE_URL',
  hf_token:                'HF_TOKEN',
  notion_token:            'NOTION_TOKEN',
  github_token:            'GITHUB_TOKEN',
  stripe_secret_key:       'STRIPE_SECRET_KEY',
  stripe_webhook_secret:   'STRIPE_WEBHOOK_SECRET',
  jwt_secret:              'JWT_SECRET',
  session_secret:          'SESSION_SECRET',
  openai_api_key:          'OPENAI_API_KEY',
  anthropic_api_key:       'ANTHROPIC_API_KEY',
  google_api_key:          'GOOGLE_API_KEY',
  cf_api_token:            'CF_API_TOKEN',
  cf_account_id:           'CF_ACCOUNT_ID',
  cf_zone_id:              'CF_ZONE_ID',
  cf_kv_namespace_id:      'CF_KV_NAMESPACE_ID',
  oauth_client_id:         'OAUTH_CLIENT_ID',
  oauth_client_secret:     'OAUTH_CLIENT_SECRET',
  redis_url:               'REDIS_URL',
};

class SecretsManager {
  constructor() {
    this._store = new Map();
    this._registered = new Set();
    this._rotationManager = null;
  }

  /** Register a secret ID for tracking. */
  register(secretId) {
    this._registered.add(secretId);
  }

  /**
   * Retrieve a secret value.
   * Priority: in-memory store → process.env → remoteConfig
   * @param {string} secretId
   * @returns {string|null}
   */
  get(secretId) {
    // In-memory (explicitly set)
    if (this._store.has(secretId)) {
      return this._store.get(secretId);
    }
    // Environment variable
    const envKey = SECRET_ENV_MAP[secretId] || secretId.toUpperCase().replace(/-/g, '_');
    if (process.env[envKey]) {
      return process.env[envKey];
    }
    // Remote config fallback
    const rcValue = remoteConfig.get(`secrets.${secretId}`);
    if (rcValue) return rcValue;

    return null;
  }

  /**
   * Set a secret value in memory.
   * @param {string} secretId
   * @param {string} value
   */
  set(secretId, value) {
    this._store.set(secretId, value);
  }

  /**
   * Check if a secret is available (non-null).
   * @param {string} secretId
   * @returns {boolean}
   */
  has(secretId) {
    return this.get(secretId) !== null;
  }

  /**
   * List all registered secret IDs with their availability status.
   * @returns {object[]}
   */
  audit() {
    return Array.from(this._registered).map((id) => ({
      secretId: id,
      available: this.has(id),
    }));
  }

  /**
   * Trigger rotation for a secret (delegates to SecretRotation if attached).
   * @param {string} secretId
   * @returns {Promise<object>}
   */
  async rotate(secretId) {
    if (this._rotationManager) {
      return this._rotationManager.rotate(secretId);
    }
    throw new Error(`SecretsManager: no rotation manager attached for "${secretId}"`);
  }

  /** Attach a SecretRotation instance. */
  setRotationManager(rotationManager) {
    this._rotationManager = rotationManager;
  }
}

const secretsManager = new SecretsManager();

// Register all manifest secrets
for (const secretId of MANIFEST_SECRETS) {
  secretsManager.register(secretId);
}

const auditResult = secretsManager.audit();
const availableSecrets = auditResult.filter((s) => s.available).length;
logger.info('Secrets manager initialized', {
  registered: auditResult.length,
  available: availableSecrets,
  missing: auditResult.filter((s) => !s.available).map((s) => s.secretId),
});

// ─────────────────────────────────────────────────────────────────────────────
// Step 8: Cloudflare Manager
// ─────────────────────────────────────────────────────────────────────────────

class CloudflareManager {
  constructor(options = {}) {
    this._apiToken  = options.apiToken  || secretsManager.get('cf_api_token');
    this._accountId = options.accountId || secretsManager.get('cf_account_id');
    this._zoneId    = options.zoneId    || secretsManager.get('cf_zone_id');
    this._kvNsId    = options.kvNsId    || secretsManager.get('cf_kv_namespace_id');
    this._baseUrl   = 'https://api.cloudflare.com/client/v4';
    this._available = !!(this._apiToken && this._accountId);
  }

  get isAvailable() { return this._available; }

  _headers() {
    return {
      'Authorization': `Bearer ${this._apiToken}`,
      'Content-Type': 'application/json',
    };
  }

  async _request(method, path, body) {
    if (!this._available) throw new Error('Cloudflare manager: API credentials not configured');
    let fetch;
    try { fetch = require('node-fetch'); } catch (_) { fetch = global.fetch; }
    if (!fetch) throw new Error('fetch not available');

    const url = `${this._baseUrl}${path}`;
    const opts = {
      method,
      headers: this._headers(),
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(url, opts);
    const data = await res.json();
    if (!data.success) {
      throw new Error(`Cloudflare API error: ${JSON.stringify(data.errors)}`);
    }
    return data.result;
  }

  /** Purge cache by URLs. */
  async purgeCache(urls) {
    return this._request('POST', `/zones/${this._zoneId}/purge_cache`, { files: urls });
  }

  /** Purge entire zone cache. */
  async purgeAllCache() {
    return this._request('POST', `/zones/${this._zoneId}/purge_cache`, { purge_everything: true });
  }

  /** List KV namespaces. */
  async listKVNamespaces() {
    return this._request('GET', `/accounts/${this._accountId}/storage/kv/namespaces`);
  }

  /** Read a KV key. */
  async getKV(key) {
    return this._request('GET', `/accounts/${this._accountId}/storage/kv/namespaces/${this._kvNsId}/values/${encodeURIComponent(key)}`);
  }

  /** Write a KV key. */
  async putKV(key, value, options = {}) {
    let fetch;
    try { fetch = require('node-fetch'); } catch (_) { fetch = global.fetch; }
    const url = `${this._baseUrl}/accounts/${this._accountId}/storage/kv/namespaces/${this._kvNsId}/values/${encodeURIComponent(key)}`;
    const res = await fetch(url, {
      method: 'PUT',
      headers: { 'Authorization': `Bearer ${this._apiToken}`, 'Content-Type': 'text/plain' },
      body: typeof value === 'string' ? value : JSON.stringify(value),
    });
    return res.json();
  }

  /** List Workers deployments. */
  async listWorkers() {
    return this._request('GET', `/accounts/${this._accountId}/workers/scripts`);
  }

  /** Get zone info. */
  async getZone() {
    if (!this._zoneId) throw new Error('CF zone ID not configured');
    return this._request('GET', `/zones/${this._zoneId}`);
  }
}

const cfManager = new CloudflareManager();
if (cfManager.isAvailable) {
  logger.info('Cloudflare manager initialized');
} else {
  logger.info('Cloudflare manager initialized (no credentials — limited mode)');
}

// ─────────────────────────────────────────────────────────────────────────────
// Exports
// ─────────────────────────────────────────────────────────────────────────────
module.exports = { app, logger, eventBus, remoteConfig, secretsManager, cfManager };
