'use strict';

/**
 * HeadyStack Bootstrap — Phase 4: Vector Memory + Bees + Spatial
 *
 * Initializes:
 *   - vectorMemory (in-process vector store with cosine similarity)
 *   - VectorSpaceOps (spatial math utilities)
 *   - beeRegistry (service discovery / bee swarm)
 *   - selfAwareness (system introspection)
 *
 * Wires:
 *   - vector pipeline, federation, buddy, watchdog, conductor, orchestrator
 *
 * Returns: { vectorMemory, buddy, pipeline, selfAwareness, watchdog }
 */

const crypto = require('crypto');
const { EventEmitter } = require('events');

const EMBEDDING_DIM  = parseInt(process.env.VECTOR_DIM || '384', 10);
const PROJECTION_DIM = 3;

// ─────────────────────────────────────────────────────────────────────────────
// VectorSpaceOps — spatial math
// ─────────────────────────────────────────────────────────────────────────────
class VectorSpaceOps {
  /** Cosine similarity between two vectors. */
  static cosine(a, b) {
    if (a.length !== b.length) throw new Error('Vector dimension mismatch');
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    const denom = Math.sqrt(normA) * Math.sqrt(normB);
    return denom === 0 ? 0 : dot / denom;
  }

  /** Euclidean distance. */
  static euclidean(a, b) {
    let sum = 0;
    for (let i = 0; i < a.length; i++) sum += (a[i] - b[i]) ** 2;
    return Math.sqrt(sum);
  }

  /** Normalize vector to unit length. */
  static normalize(v) {
    const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
    return norm === 0 ? v : v.map((x) => x / norm);
  }

  /** Element-wise mean of vectors. */
  static mean(vectors) {
    if (vectors.length === 0) return [];
    const dim = vectors[0].length;
    const result = new Array(dim).fill(0);
    for (const v of vectors) {
      for (let i = 0; i < dim; i++) result[i] += v[i];
    }
    return result.map((x) => x / vectors.length);
  }

  /** Project high-dim vector to 3D using simple PCA-like reduction. */
  static project3D(v) {
    // Deterministic projection using first 3 dims scaled to unit cube
    const [x = 0, y = 0, z = 0] = v;
    const scale = Math.sqrt(x * x + y * y + z * z) || 1;
    return [x / scale, y / scale, z / scale];
  }

  /** Add two vectors. */
  static add(a, b) {
    return a.map((x, i) => x + (b[i] || 0));
  }

  /** Scale vector. */
  static scale(v, scalar) {
    return v.map((x) => x * scalar);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// VectorMemory — in-process vector store
// ─────────────────────────────────────────────────────────────────────────────
class VectorMemory extends EventEmitter {
  constructor(options = {}) {
    super();
    this._dim = options.dim || EMBEDDING_DIM;
    this._store = new Map();      // id → { id, vector, metadata, namespace }
    this._namespaces = new Map(); // namespace → Set<id>
    this._logger = options.logger || console;
    this._totalInserted = 0;
  }

  /**
   * Upsert a vector with metadata.
   * @param {string} id
   * @param {number[]} vector
   * @param {object} [metadata]
   * @param {string} [namespace]
   */
  upsert(id, vector, metadata = {}, namespace = 'default') {
    if (!Array.isArray(vector) || vector.length !== this._dim) {
      // Accept and zero-pad if needed
      const padded = new Array(this._dim).fill(0);
      if (Array.isArray(vector)) {
        for (let i = 0; i < Math.min(vector.length, this._dim); i++) padded[i] = vector[i];
      }
      vector = padded;
    }

    const normalizedVec = VectorSpaceOps.normalize(vector);
    this._store.set(id, { id, vector: normalizedVec, metadata, namespace, updatedAt: Date.now() });

    if (!this._namespaces.has(namespace)) this._namespaces.set(namespace, new Set());
    this._namespaces.get(namespace).add(id);

    this._totalInserted++;
    this.emit('upsert', { id, namespace });
    return id;
  }

  /**
   * Get a vector record by ID.
   * @param {string} id
   * @returns {object|null}
   */
  get(id) {
    return this._store.get(id) || null;
  }

  /**
   * Delete a vector record.
   * @param {string} id
   * @returns {boolean}
   */
  delete(id) {
    const record = this._store.get(id);
    if (!record) return false;
    this._store.delete(id);
    const nsSet = this._namespaces.get(record.namespace);
    if (nsSet) nsSet.delete(id);
    this.emit('delete', { id });
    return true;
  }

  /**
   * Search for nearest neighbors by cosine similarity.
   * @param {number[]} queryVector
   * @param {object} [options]
   * @param {number} [options.topK]
   * @param {string} [options.namespace]
   * @param {number} [options.minScore]
   * @param {object} [options.filter] - Metadata key-value filter
   * @returns {{ id: string, score: number, metadata: object }[]}
   */
  search(queryVector, options = {}) {
    const topK = options.topK || 10;
    const namespace = options.namespace || null;
    const minScore = options.minScore != null ? options.minScore : -1;
    const filter = options.filter || null;

    const normalizedQuery = VectorSpaceOps.normalize(queryVector);
    const results = [];

    const candidates = namespace
      ? Array.from((this._namespaces.get(namespace) || new Set())).map((id) => this._store.get(id)).filter(Boolean)
      : Array.from(this._store.values());

    for (const record of candidates) {
      // Apply metadata filter
      if (filter) {
        const matches = Object.entries(filter).every(([k, v]) => record.metadata[k] === v);
        if (!matches) continue;
      }

      const score = VectorSpaceOps.cosine(normalizedQuery, record.vector);
      if (score >= minScore) {
        results.push({ id: record.id, score, metadata: record.metadata, namespace: record.namespace });
      }
    }

    results.sort((a, b) => b.score - a.score);
    return results.slice(0, topK);
  }

  /** Get all IDs in a namespace. */
  listNamespace(namespace) {
    return Array.from((this._namespaces.get(namespace) || new Set()));
  }

  /** Count stored vectors. */
  get size() { return this._store.size; }

  /** Stats snapshot. */
  stats() {
    return {
      totalVectors: this._store.size,
      totalInserted: this._totalInserted,
      namespaces: Array.from(this._namespaces.entries()).map(([ns, ids]) => ({ namespace: ns, count: ids.size })),
      dim: this._dim,
    };
  }

  /**
   * Serialize all vectors to a plain object for persistence.
   * @returns {object}
   */
  serialize() {
    return {
      dim: this._dim,
      vectors: Array.from(this._store.values()),
    };
  }

  /**
   * Load from serialized data.
   * @param {object} data
   */
  deserialize(data) {
    if (data.dim && data.dim !== this._dim) {
      this._logger.warn && this._logger.warn('VectorMemory deserialization: dim mismatch', { stored: data.dim, expected: this._dim });
    }
    for (const record of (data.vectors || [])) {
      this._store.set(record.id, record);
      if (!this._namespaces.has(record.namespace)) this._namespaces.set(record.namespace, new Set());
      this._namespaces.get(record.namespace).add(record.id);
    }
    this._logger.info && this._logger.info('VectorMemory loaded from snapshot', { count: this._store.size });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// BeeRegistry — distributed service / agent registry
// ─────────────────────────────────────────────────────────────────────────────
class BeeRegistry extends EventEmitter {
  constructor(options = {}) {
    super();
    this._bees = new Map();     // beeId → BeeRecord
    this._tags = new Map();     // tag → Set<beeId>
    this._logger = options.logger || console;
  }

  /**
   * Register a bee (service/agent).
   * @param {string} beeId
   * @param {object} meta - { type, tags, endpoint, capabilities }
   */
  register(beeId, meta = {}) {
    const record = {
      id: beeId,
      type: meta.type || 'unknown',
      tags: meta.tags || [],
      endpoint: meta.endpoint || null,
      capabilities: meta.capabilities || [],
      registeredAt: Date.now(),
      lastSeen: Date.now(),
      healthy: true,
    };
    this._bees.set(beeId, record);

    for (const tag of record.tags) {
      if (!this._tags.has(tag)) this._tags.set(tag, new Set());
      this._tags.get(tag).add(beeId);
    }

    this.emit('register', record);
    return record;
  }

  deregister(beeId) {
    const record = this._bees.get(beeId);
    if (!record) return false;
    this._bees.delete(beeId);
    for (const tag of record.tags) {
      const tagSet = this._tags.get(tag);
      if (tagSet) tagSet.delete(beeId);
    }
    this.emit('deregister', { id: beeId });
    return true;
  }

  heartbeat(beeId) {
    const record = this._bees.get(beeId);
    if (record) {
      record.lastSeen = Date.now();
      record.healthy = true;
    }
  }

  findByTag(tag) {
    const ids = this._tags.get(tag) || new Set();
    return Array.from(ids).map((id) => this._bees.get(id)).filter(Boolean);
  }

  findByType(type) {
    return Array.from(this._bees.values()).filter((b) => b.type === type);
  }

  get(beeId) { return this._bees.get(beeId) || null; }
  getAll()    { return Array.from(this._bees.values()); }
  get size()  { return this._bees.size; }
}

// ─────────────────────────────────────────────────────────────────────────────
// SelfAwareness — system introspection
// ─────────────────────────────────────────────────────────────────────────────
class SelfAwareness {
  constructor(options = {}) {
    this._startTime = Date.now();
    this._nodeId = options.nodeId || crypto.randomBytes(6).toString('hex');
    this._serviceName = options.serviceName || 'heady-stack';
    this._version = process.env.HEADY_VERSION || '3.0.1';
    this._codename = process.env.HEADY_CODENAME || 'Aether';
    this._observations = [];
    this._maxObservations = 500;
  }

  observe(event, data = {}) {
    const obs = { timestamp: Date.now(), event, data };
    this._observations.push(obs);
    if (this._observations.length > this._maxObservations) {
      this._observations.shift();
    }
    return obs;
  }

  getIdentity() {
    return {
      nodeId: this._nodeId,
      serviceName: this._serviceName,
      version: this._version,
      codename: this._codename,
      startTime: this._startTime,
      uptime: Date.now() - this._startTime,
      pid: process.pid,
      hostname: require('os').hostname(),
      platform: process.platform,
      nodeVersion: process.version,
    };
  }

  getRecentObservations(n = 20) {
    return this._observations.slice(-n);
  }

  getHealth() {
    const mem = process.memoryUsage();
    return {
      uptime: Date.now() - this._startTime,
      memory: {
        heapUsed: mem.heapUsed,
        heapTotal: mem.heapTotal,
        rss: mem.rss,
        external: mem.external,
      },
      cpuUsage: process.cpuUsage(),
      observationCount: this._observations.length,
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Minimal stubs for optional heavy dependencies
// ─────────────────────────────────────────────────────────────────────────────
function tryRequire(mod) {
  try { return require(mod); } catch (_) { return null; }
}

// ─────────────────────────────────────────────────────────────────────────────
// Watchdog — monitors system health and restarts unhealthy components
// ─────────────────────────────────────────────────────────────────────────────
class Watchdog extends EventEmitter {
  constructor(options = {}) {
    super();
    this._logger = options.logger || console;
    this._checks = new Map();
    this._results = new Map();
    this._intervalMs = options.intervalMs || 30_000;
    this._timer = null;
  }

  register(name, checkFn, { critical = false } = {}) {
    this._checks.set(name, { fn: checkFn, critical });
  }

  async runChecks() {
    const results = {};
    for (const [name, { fn, critical }] of this._checks.entries()) {
      try {
        const result = await fn();
        results[name] = { healthy: true, result, critical };
      } catch (err) {
        results[name] = { healthy: false, error: err.message, critical };
        this.emit('check:failed', { name, error: err.message, critical });
        if (critical) {
          this._logger.error && this._logger.error(`Watchdog: critical check failed — ${name}`, { error: err.message });
        }
      }
      this._results.set(name, results[name]);
    }
    const allHealthy = Object.values(results).every((r) => r.healthy);
    this.emit('heartbeat', { healthy: allHealthy, results });
    return results;
  }

  start() {
    if (this._timer) return;
    this._timer = setInterval(() => this.runChecks().catch(() => {}), this._intervalMs);
    if (this._timer.unref) this._timer.unref();
  }

  stop() {
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
  }

  getStatus() {
    return Object.fromEntries(this._results.entries());
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Module factory
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @param {import('express').Application} app
 * @param {object} deps
 * @param {object} deps.logger
 * @param {object} deps.eventBus
 * @returns {{ vectorMemory, buddy, pipeline, selfAwareness, watchdog }}
 */
module.exports = function mountVectorStack(app, { logger, eventBus }) {
  const log = logger.child ? logger.child('vector-stack') : logger;

  // ── Initialize core subsystems ──────────────────────────────────────────
  const vectorMemory = new VectorMemory({ dim: EMBEDDING_DIM, logger: log });
  const beeRegistry  = new BeeRegistry({ logger: log });
  const selfAwareness = new SelfAwareness({ serviceName: 'heady-stack' });
  const watchdog     = new Watchdog({ logger: log, intervalMs: 30_000 });

  // Register self as a bee
  beeRegistry.register('self', {
    type: 'heady-stack',
    tags: ['core', 'vector', 'api'],
    capabilities: ['vector-search', 'embedding', 'orchestration'],
  });

  // ── Buddy (optional extended agent) ────────────────────────────────────
  // Buddy is a higher-level agent that uses vectorMemory + beeRegistry
  const buddy = {
    vectorMemory,
    beeRegistry,
    selfAwareness,

    remember(id, vector, metadata, namespace) {
      return vectorMemory.upsert(id, vector, metadata, namespace);
    },

    recall(queryVector, options) {
      return vectorMemory.search(queryVector, options);
    },

    observe(event, data) {
      return selfAwareness.observe(event, data);
    },

    identity() {
      return selfAwareness.getIdentity();
    },
  };

  // ── Pipeline (vector processing pipeline) ──────────────────────────────
  const pipeline = {
    _stages: [],
    _vectorMemory: vectorMemory,
    _eventBus: eventBus,
    _logger: log,

    register(name, stageFn) {
      this._stages.push({ name, fn: stageFn });
    },

    async process(input, context = {}) {
      let current = input;
      for (const stage of this._stages) {
        try {
          current = await stage.fn(current, context, this._vectorMemory, eventBus);
        } catch (err) {
          this._logger.error && this._logger.error(`Pipeline stage error: ${stage.name}`, { error: err.message });
          eventBus.emit('pipeline:stage:error', { stage: stage.name, error: err.message });
        }
      }
      return current;
    },

    stats() {
      return { stages: this._stages.map((s) => s.name), vectorMemorySize: vectorMemory.size };
    },
  };

  // ── Watchdog checks ─────────────────────────────────────────────────────
  watchdog.register('vector-memory', () => {
    const stats = vectorMemory.stats();
    return { ok: true, vectors: stats.totalVectors };
  });

  watchdog.register('bee-registry', () => {
    return { ok: true, bees: beeRegistry.size };
  });

  watchdog.register('event-bus', () => {
    return { ok: true, listeners: eventBus.eventNames().length };
  });

  watchdog.start();

  // ── Express Routes ──────────────────────────────────────────────────────

  // GET /api/vector/stats
  app.get('/api/vector/stats', (req, res) => {
    res.json(vectorMemory.stats());
  });

  // POST /api/vector/search
  app.post('/api/vector/search', (req, res) => {
    const { vector, topK = 10, namespace, minScore, filter } = req.body || {};
    if (!vector || !Array.isArray(vector)) {
      return res.status(422).json({ error: 'vector (array) is required' });
    }
    const results = vectorMemory.search(vector, { topK, namespace, minScore, filter });
    res.json({ results, count: results.length });
  });

  // POST /api/vector/upsert
  app.post('/api/vector/upsert', (req, res) => {
    const { id, vector, metadata, namespace } = req.body || {};
    if (!id || !vector) {
      return res.status(422).json({ error: 'id and vector are required' });
    }
    vectorMemory.upsert(id, vector, metadata || {}, namespace || 'default');
    res.json({ ok: true, id });
  });

  // DELETE /api/vector/:id
  app.delete('/api/vector/:id', (req, res) => {
    const deleted = vectorMemory.delete(req.params.id);
    res.json({ ok: deleted, id: req.params.id });
  });

  // GET /api/bees
  app.get('/api/bees', (req, res) => {
    res.json({ bees: beeRegistry.getAll(), count: beeRegistry.size });
  });

  // GET /api/self
  app.get('/api/self', (req, res) => {
    res.json({ identity: selfAwareness.getIdentity(), health: selfAwareness.getHealth() });
  });

  // GET /api/watchdog
  app.get('/api/watchdog', async (req, res) => {
    const status = watchdog.getStatus();
    res.json({ status, healthy: Object.values(status).every((s) => s.healthy) });
  });

  log.info('Vector stack mounted', {
    dim: EMBEDDING_DIM,
    pipelineStages: pipeline._stages.length,
  });

  return { vectorMemory, buddy, pipeline, selfAwareness, watchdog, beeRegistry, VectorSpaceOps };
};

module.exports.VectorMemory   = VectorMemory;
module.exports.VectorSpaceOps = VectorSpaceOps;
module.exports.BeeRegistry    = BeeRegistry;
module.exports.SelfAwareness  = SelfAwareness;
module.exports.Watchdog       = Watchdog;
