'use strict';

/**
 * HeadyStack Bootstrap — Phase 5: Engine + Pipeline Wiring
 *
 * Wires:
 *   - Monte Carlo scheduler
 *   - Pattern recognition engine
 *   - Auto-success engine
 *   - Scientist (A/B experiment engine)
 *   - QA engine
 *
 * wireEngines(app, { pipeline, loadRegistry, eventBus, projectRoot, PORT })
 */

const path  = require('path');
const crypto = require('crypto');
const { EventEmitter } = require('events');

// ─────────────────────────────────────────────────────────────────────────────
// Monte Carlo Scheduler
// ─────────────────────────────────────────────────────────────────────────────
class MonteCarloScheduler extends EventEmitter {
  /**
   * @param {object} options
   * @param {number} [options.simulations] - Number of MC simulations
   * @param {object} [options.logger]
   */
  constructor(options = {}) {
    super();
    this._simulations = options.simulations || 1000;
    this._logger = options.logger || console;
    this._tasks = new Map();   // taskId → TaskMeta
    this._results = new Map(); // taskId → SimResult
  }

  /**
   * Register a task for MC scheduling analysis.
   * @param {string} taskId
   * @param {object} meta
   * @param {number} meta.estimateLow  - Optimistic estimate (units)
   * @param {number} meta.estimateHigh - Pessimistic estimate (units)
   * @param {number} [meta.estimateMid] - Most likely estimate
   * @param {string} [meta.priority]
   * @param {string[]} [meta.dependencies]
   */
  registerTask(taskId, meta) {
    this._tasks.set(taskId, {
      id: taskId,
      estimateLow:  meta.estimateLow  || 1,
      estimateHigh: meta.estimateHigh || 10,
      estimateMid:  meta.estimateMid  || ((meta.estimateLow + meta.estimateHigh) / 2),
      priority:     meta.priority     || 'medium',
      dependencies: meta.dependencies || [],
      status:       'pending',
    });
  }

  /**
   * Run Monte Carlo simulation for a task.
   * Uses PERT (Program Evaluation and Review Technique) distribution.
   * @param {string} taskId
   * @param {number} [simulations]
   * @returns {{ p50: number, p80: number, p95: number, mean: number, samples: number[] }}
   */
  simulate(taskId, simulations) {
    const task = this._tasks.get(taskId);
    if (!task) throw new Error(`MonteCarloScheduler: unknown task "${taskId}"`);

    const n = simulations || this._simulations;
    const { estimateLow: a, estimateMid: m, estimateHigh: b } = task;
    const samples = [];

    for (let i = 0; i < n; i++) {
      // PERT distribution approximation: beta distribution via two random samples
      const u1 = Math.random();
      const u2 = Math.random();
      // Triangular distribution using PERT alpha/beta shape
      const alpha = 4 * m / (b - a);
      const beta  = alpha * (b - m) / m;
      // Box-Muller-based triangular sampling
      const triangular = u1 < (m - a) / (b - a)
        ? a + Math.sqrt(u1 * (b - a) * (m - a))
        : b - Math.sqrt((1 - u1) * (b - a) * (b - m));
      samples.push(Math.max(a, Math.min(b, triangular)));
    }

    samples.sort((x, y) => x - y);
    const mean = samples.reduce((s, x) => s + x, 0) / n;
    const p50  = samples[Math.floor(n * 0.50)];
    const p80  = samples[Math.floor(n * 0.80)];
    const p95  = samples[Math.floor(n * 0.95)];

    const result = { taskId, p50, p80, p95, mean, n, a, m, b };
    this._results.set(taskId, result);
    this.emit('simulation:complete', result);
    return result;
  }

  /**
   * Schedule all tasks using MC simulation results.
   * Returns topologically sorted schedule with estimates.
   * @returns {object[]}
   */
  schedule() {
    const schedule = [];

    // Simulate any tasks that don't have results yet
    for (const taskId of this._tasks.keys()) {
      if (!this._results.has(taskId)) this.simulate(taskId);
    }

    // Topological sort respecting dependencies
    const visited = new Set();
    const visit = (taskId) => {
      if (visited.has(taskId)) return;
      visited.add(taskId);
      const task = this._tasks.get(taskId);
      if (task) {
        for (const dep of task.dependencies) visit(dep);
      }
      schedule.push({ task, result: this._results.get(taskId) });
    };

    for (const taskId of this._tasks.keys()) visit(taskId);
    this.emit('schedule:complete', { tasks: schedule.length });
    return schedule;
  }

  getResult(taskId) { return this._results.get(taskId) || null; }
}

// ─────────────────────────────────────────────────────────────────────────────
// Pattern Engine
// ─────────────────────────────────────────────────────────────────────────────
class PatternEngine extends EventEmitter {
  constructor(options = {}) {
    super();
    this._patterns = new Map();
    this._matches = [];
    this._logger = options.logger || console;
  }

  /**
   * Register a pattern.
   * @param {string} name
   * @param {object} pattern
   * @param {RegExp|function} pattern.match - Pattern to match against input
   * @param {function} pattern.handler - async (input, context) => result
   * @param {number} [pattern.priority]
   */
  register(name, pattern) {
    this._patterns.set(name, {
      name,
      match: pattern.match,
      handler: pattern.handler,
      priority: pattern.priority || 0,
      hitCount: 0,
    });
  }

  /**
   * Test input against all registered patterns.
   * @param {*} input
   * @param {object} [context]
   * @returns {Promise<{ name: string, result: * }[]>}
   */
  async apply(input, context = {}) {
    const results = [];
    const sorted = Array.from(this._patterns.values())
      .sort((a, b) => b.priority - a.priority);

    for (const pattern of sorted) {
      let matched = false;
      try {
        if (pattern.match instanceof RegExp) {
          matched = pattern.match.test(String(input));
        } else if (typeof pattern.match === 'function') {
          matched = await pattern.match(input, context);
        }
      } catch (_) {
        matched = false;
      }

      if (matched) {
        pattern.hitCount++;
        try {
          const result = await pattern.handler(input, context);
          results.push({ name: pattern.name, result });
          this.emit('pattern:match', { name: pattern.name, input, result });
        } catch (err) {
          this._logger.warn && this._logger.warn(`Pattern handler error: ${pattern.name}`, { error: err.message });
        }
      }
    }

    this._matches.push({ input, results, timestamp: Date.now() });
    if (this._matches.length > 1000) this._matches.shift();
    return results;
  }

  getStats() {
    return Array.from(this._patterns.values())
      .map(({ name, hitCount, priority }) => ({ name, hitCount, priority }));
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Auto-Success Engine
// ─────────────────────────────────────────────────────────────────────────────
class AutoSuccessEngine extends EventEmitter {
  constructor(options = {}) {
    super();
    this._logger = options.logger || console;
    this._successCriteria = new Map();
    this._successLog = [];
    this._failureLog = [];
  }

  /**
   * Define success criteria for an operation.
   * @param {string} operationId
   * @param {function} criteriaFn - async (result) => boolean
   * @param {object} [options]
   * @param {number} [options.minSuccessRate] - 0-1, default 0.95
   */
  define(operationId, criteriaFn, options = {}) {
    this._successCriteria.set(operationId, {
      fn: criteriaFn,
      minSuccessRate: options.minSuccessRate || 0.95,
      window: options.window || 100,
      results: [],
    });
  }

  /**
   * Record an operation result.
   * @param {string} operationId
   * @param {*} result
   * @returns {Promise<{ success: boolean, rate: number }>}
   */
  async record(operationId, result) {
    const criteria = this._successCriteria.get(operationId);
    if (!criteria) return { success: true, rate: 1 };

    let success;
    try {
      success = !!(await criteria.fn(result));
    } catch (_) {
      success = false;
    }

    criteria.results.push({ success, timestamp: Date.now() });
    if (criteria.results.length > criteria.window) criteria.results.shift();

    const rate = criteria.results.filter((r) => r.success).length / criteria.results.length;
    const entry = { operationId, success, rate, timestamp: Date.now() };

    if (success) {
      this._successLog.push(entry);
      if (this._successLog.length > 500) this._successLog.shift();
      this.emit('success', entry);
    } else {
      this._failureLog.push(entry);
      if (this._failureLog.length > 500) this._failureLog.shift();
      this.emit('failure', entry);
      if (rate < criteria.minSuccessRate) {
        this.emit('threshold:breach', { operationId, rate, minRequired: criteria.minSuccessRate });
        this._logger.warn && this._logger.warn(`Auto-success threshold breached: ${operationId}`, { rate, min: criteria.minSuccessRate });
      }
    }

    return { success, rate };
  }

  getStats() {
    const stats = {};
    for (const [opId, criteria] of this._successCriteria.entries()) {
      const recentResults = criteria.results;
      const rate = recentResults.length > 0
        ? recentResults.filter((r) => r.success).length / recentResults.length
        : null;
      stats[opId] = { rate, window: recentResults.length, minRequired: criteria.minSuccessRate };
    }
    return stats;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Scientist — A/B experiment engine
// ─────────────────────────────────────────────────────────────────────────────
class Scientist extends EventEmitter {
  constructor(options = {}) {
    super();
    this._experiments = new Map();
    this._logger = options.logger || console;
  }

  /**
   * Define an experiment.
   * @param {string} name
   * @param {object} experiment
   * @param {function} experiment.control   - async (input) => result (baseline)
   * @param {function} experiment.candidate - async (input) => result (new behavior)
   * @param {number} [experiment.percentage] - 0-100, percent of traffic to run candidate
   * @param {function} [experiment.compare] - (control, candidate) => boolean
   */
  define(name, experiment) {
    this._experiments.set(name, {
      name,
      control:    experiment.control,
      candidate:  experiment.candidate,
      percentage: experiment.percentage || 50,
      compare:    experiment.compare || defaultCompare,
      results:    [],
      enabled:    true,
    });
  }

  /**
   * Run an experiment.
   * Always returns control result; runs candidate in parallel for comparison.
   * @param {string} name
   * @param {*} input
   * @returns {Promise<*>} control result
   */
  async run(name, input) {
    const exp = this._experiments.get(name);
    if (!exp || !exp.enabled) {
      // No experiment — just return identity
      return input;
    }

    // Determine if this request participates in candidate
    const runCandidate = Math.random() * 100 < exp.percentage;

    // Always run control
    const controlStart = Date.now();
    let controlResult;
    let controlError;
    try {
      controlResult = await exp.control(input);
    } catch (err) {
      controlError = err;
    }
    const controlDuration = Date.now() - controlStart;

    if (runCandidate) {
      // Run candidate asynchronously (do not block)
      const candidateStart = Date.now();
      exp.candidate(input).then((candidateResult) => {
        const candidateDuration = Date.now() - candidateStart;
        let matched = false;
        try {
          matched = exp.compare(controlResult, candidateResult);
        } catch (_) {}

        const result = {
          name,
          matched,
          controlDuration,
          candidateDuration,
          timestamp: Date.now(),
        };
        exp.results.push(result);
        if (exp.results.length > 1000) exp.results.shift();
        this.emit('observation', result);

        if (!matched) {
          this._logger.info && this._logger.info(`Scientist mismatch: ${name}`, {
            controlDuration,
            candidateDuration,
          });
          this.emit('mismatch', result);
        }
      }).catch((err) => {
        this.emit('candidate:error', { name, error: err.message });
      });
    }

    if (controlError) throw controlError;
    return controlResult;
  }

  getStats(name) {
    const exp = this._experiments.get(name);
    if (!exp) return null;
    const total = exp.results.length;
    const matches = exp.results.filter((r) => r.matched).length;
    return {
      name,
      total,
      matches,
      mismatches: total - matches,
      matchRate: total > 0 ? matches / total : null,
      percentage: exp.percentage,
    };
  }
}

function defaultCompare(a, b) {
  return JSON.stringify(a) === JSON.stringify(b);
}

// ─────────────────────────────────────────────────────────────────────────────
// QA Engine
// ─────────────────────────────────────────────────────────────────────────────
class QAEngine extends EventEmitter {
  constructor(options = {}) {
    super();
    this._suites = new Map();
    this._logger = options.logger || console;
    this._runHistory = [];
  }

  /**
   * Register a test suite.
   * @param {string} suiteName
   * @param {object[]} tests - [{ name, fn: async () => void }]
   */
  registerSuite(suiteName, tests) {
    this._suites.set(suiteName, tests);
  }

  /**
   * Run a test suite.
   * @param {string} suiteName
   * @returns {Promise<{ passed: number, failed: number, duration: number, results: object[] }>}
   */
  async runSuite(suiteName) {
    const tests = this._suites.get(suiteName);
    if (!tests) throw new Error(`QAEngine: unknown suite "${suiteName}"`);

    const results = [];
    let passed = 0, failed = 0;
    const suiteStart = Date.now();

    for (const test of tests) {
      const testStart = Date.now();
      try {
        await test.fn();
        passed++;
        results.push({ name: test.name, passed: true, duration: Date.now() - testStart });
      } catch (err) {
        failed++;
        results.push({ name: test.name, passed: false, error: err.message, duration: Date.now() - testStart });
        this.emit('test:failed', { suite: suiteName, name: test.name, error: err.message });
      }
    }

    const summary = {
      suite: suiteName,
      passed,
      failed,
      total: tests.length,
      duration: Date.now() - suiteStart,
      results,
      timestamp: Date.now(),
    };

    this._runHistory.push(summary);
    if (this._runHistory.length > 100) this._runHistory.shift();

    this.emit('suite:complete', summary);
    this._logger.info && this._logger.info(`QA suite complete: ${suiteName}`, { passed, failed, duration: summary.duration });
    return summary;
  }

  /**
   * Run all registered suites.
   * @returns {Promise<object>}
   */
  async runAll() {
    const results = {};
    for (const suiteName of this._suites.keys()) {
      results[suiteName] = await this.runSuite(suiteName);
    }
    return results;
  }

  getHistory() { return this._runHistory.slice(-20); }
}

// ─────────────────────────────────────────────────────────────────────────────
// Module factory
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @param {import('express').Application} app
 * @param {object} deps
 * @param {object} deps.pipeline
 * @param {object} deps.loadRegistry
 * @param {object} deps.eventBus
 * @param {string} deps.projectRoot
 * @param {number|string} deps.PORT
 * @param {object} [deps.logger]
 * @returns {{ scheduler, patternEngine, autoSuccess, scientist, qaEngine }}
 */
function wireEngines(app, { pipeline, loadRegistry, eventBus, projectRoot, PORT, logger }) {
  const log = logger
    ? (logger.child ? logger.child('engine-wiring') : logger)
    : console;

  // Initialize engines
  const scheduler    = new MonteCarloScheduler({ logger: log });
  const patternEngine = new PatternEngine({ logger: log });
  const autoSuccess  = new AutoSuccessEngine({ logger: log });
  const scientist    = new Scientist({ logger: log });
  const qaEngine     = new QAEngine({ logger: log });

  // Wire pipeline stages
  if (pipeline) {
    // Pattern matching stage
    pipeline.register('pattern-detection', async (input, ctx, vectorMemory) => {
      if (input && input.text) {
        const matches = await patternEngine.apply(input.text, ctx);
        return { ...input, patternMatches: matches };
      }
      return input;
    });

    // Auto-success tracking stage
    pipeline.register('success-tracking', async (input, ctx) => {
      if (input && input.operationId) {
        await autoSuccess.record(input.operationId, input);
      }
      return input;
    });
  }

  // Wire event bus
  eventBus.on('qa:run', async ({ suite } = {}) => {
    try {
      if (suite) {
        await qaEngine.runSuite(suite);
      } else {
        await qaEngine.runAll();
      }
    } catch (err) {
      log.error && log.error('QA run error', { error: err.message });
    }
  });

  eventBus.on('experiment:define', ({ name, experiment }) => {
    if (name && experiment) scientist.define(name, experiment);
  });

  // Register engine routes
  app.get('/api/engines/scheduler/schedule', (req, res) => {
    try {
      const schedule = scheduler.schedule();
      res.json({ schedule });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/engines/patterns', (req, res) => {
    res.json({ patterns: patternEngine.getStats() });
  });

  app.get('/api/engines/success', (req, res) => {
    res.json({ stats: autoSuccess.getStats() });
  });

  app.get('/api/engines/experiments', (req, res) => {
    const stats = {};
    for (const name of (scientist._experiments || new Map()).keys()) {
      stats[name] = scientist.getStats(name);
    }
    res.json({ experiments: stats });
  });

  app.post('/api/engines/qa/run', async (req, res) => {
    const { suite } = req.body || {};
    try {
      const result = suite ? await qaEngine.runSuite(suite) : await qaEngine.runAll();
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/engines/qa/history', (req, res) => {
    res.json({ history: qaEngine.getHistory() });
  });

  log.info('Engines wired', {
    engines: ['MonteCarloScheduler', 'PatternEngine', 'AutoSuccessEngine', 'Scientist', 'QAEngine'],
  });

  return { scheduler, patternEngine, autoSuccess, scientist, qaEngine };
}

module.exports = wireEngines;
module.exports.MonteCarloScheduler = MonteCarloScheduler;
module.exports.PatternEngine       = PatternEngine;
module.exports.AutoSuccessEngine   = AutoSuccessEngine;
module.exports.Scientist           = Scientist;
module.exports.QAEngine            = QAEngine;
