'use strict';

/**
 * HeadyStack Bootstrap — Phase 9: WebSocket Voice Relay
 *
 * Handles WebSocket upgrade for voice sessions:
 *   - /ws/voice        — general voice session
 *   - /ws/voice/stream — streaming audio relay
 *   - /ws/voice/chat   — voice-backed chat
 *
 * module.exports = function(app, { logger })
 * Returns: { voiceSessions }
 */

const crypto = require('crypto');

// Maximum simultaneous voice sessions per IP
const MAX_SESSIONS_PER_IP = 5;
// Session idle timeout (ms)
const SESSION_TIMEOUT_MS = parseInt(process.env.VOICE_SESSION_TIMEOUT_MS || '300000', 10); // 5 minutes

// ─────────────────────────────────────────────────────────────────────────────
// VoiceSession
// ─────────────────────────────────────────────────────────────────────────────
class VoiceSession {
  constructor(ws, options = {}) {
    this.id         = options.sessionId || crypto.randomBytes(8).toString('hex');
    this.ws         = ws;
    this.userId     = options.userId    || null;
    this.ip         = options.ip        || null;
    this.type       = options.type      || 'voice';
    this.createdAt  = Date.now();
    this.lastActivity = Date.now();
    this.metadata   = options.metadata  || {};
    this.audioBuffer = [];
    this.active     = true;
  }

  touch() { this.lastActivity = Date.now(); }

  isExpired(timeoutMs) {
    return Date.now() - this.lastActivity > (timeoutMs || SESSION_TIMEOUT_MS);
  }

  send(data) {
    if (this.ws && this.ws.readyState === 1 /* OPEN */) {
      this.ws.send(typeof data === 'object' ? JSON.stringify(data) : data);
    }
  }

  sendBinary(buffer) {
    if (this.ws && this.ws.readyState === 1) {
      this.ws.send(buffer, { binary: true });
    }
  }

  close(code, reason) {
    this.active = false;
    if (this.ws && this.ws.readyState < 2 /* not CLOSING/CLOSED */) {
      this.ws.close(code || 1000, reason || 'Session ended');
    }
  }

  toJSON() {
    return {
      id:           this.id,
      userId:       this.userId,
      ip:           this.ip,
      type:         this.type,
      createdAt:    this.createdAt,
      lastActivity: this.lastActivity,
      active:       this.active,
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// VoiceSessions — session registry and management
// ─────────────────────────────────────────────────────────────────────────────
class VoiceSessions {
  constructor(options = {}) {
    this._sessions  = new Map();   // sessionId → VoiceSession
    this._byIP      = new Map();   // ip → Set<sessionId>
    this._logger    = options.logger || console;
    this._maxPerIP  = options.maxPerIP || MAX_SESSIONS_PER_IP;
    this._timeout   = options.timeout  || SESSION_TIMEOUT_MS;
    this._cleanupTimer = null;
  }

  create(ws, options = {}) {
    const ip = options.ip || 'unknown';

    // Enforce per-IP session limit
    const ipSessions = this._byIP.get(ip) || new Set();
    if (ipSessions.size >= this._maxPerIP) {
      ws.close(4029, 'Too many voice sessions from this IP');
      return null;
    }

    const session = new VoiceSession(ws, options);
    this._sessions.set(session.id, session);
    ipSessions.add(session.id);
    this._byIP.set(ip, ipSessions);

    this._logger.info && this._logger.info('Voice session created', {
      sessionId: session.id,
      ip,
      type: session.type,
    });

    return session;
  }

  get(sessionId) { return this._sessions.get(sessionId) || null; }

  remove(sessionId) {
    const session = this._sessions.get(sessionId);
    if (!session) return false;
    session.active = false;
    this._sessions.delete(sessionId);
    const ipSet = this._byIP.get(session.ip);
    if (ipSet) {
      ipSet.delete(sessionId);
      if (ipSet.size === 0) this._byIP.delete(session.ip);
    }
    return true;
  }

  getAll() { return Array.from(this._sessions.values()); }
  get size() { return this._sessions.size; }

  broadcast(data, filter) {
    for (const session of this._sessions.values()) {
      if (!filter || filter(session)) {
        session.send(data);
      }
    }
  }

  startCleanup() {
    this._cleanupTimer = setInterval(() => {
      for (const [id, session] of this._sessions.entries()) {
        if (session.isExpired(this._timeout)) {
          this._logger.info && this._logger.info('Voice session expired', { sessionId: id });
          session.close(4000, 'Session timeout');
          this.remove(id);
        }
      }
    }, 60_000);
    if (this._cleanupTimer.unref) this._cleanupTimer.unref();
  }

  stopCleanup() {
    if (this._cleanupTimer) {
      clearInterval(this._cleanupTimer);
      this._cleanupTimer = null;
    }
  }

  stats() {
    return {
      total: this._sessions.size,
      byType: countBy(Array.from(this._sessions.values()), (s) => s.type),
      uniqueIPs: this._byIP.size,
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// WebSocket message handler
// ─────────────────────────────────────────────────────────────────────────────
function handleVoiceMessage(session, raw, voiceSessions, logger) {
  session.touch();

  // Binary: audio chunk
  if (Buffer.isBuffer(raw) || raw instanceof ArrayBuffer) {
    const chunk = Buffer.isBuffer(raw) ? raw : Buffer.from(raw);
    session.audioBuffer.push(chunk);
    // Relay to any other sessions the user is participating in
    voiceSessions.broadcast({ type: 'audio:chunk', sessionId: session.id }, (s) => {
      return s.id !== session.id && s.metadata.roomId === session.metadata.roomId;
    });
    return;
  }

  // Text: JSON control messages
  let msg;
  try {
    msg = JSON.parse(raw);
  } catch (_) {
    session.send({ type: 'error', code: 'INVALID_JSON', message: 'Expected JSON control message or binary audio' });
    return;
  }

  switch (msg.type) {
    case 'ping':
      session.send({ type: 'pong', timestamp: Date.now() });
      break;

    case 'identify':
      session.userId   = msg.userId   || session.userId;
      session.metadata = { ...session.metadata, ...(msg.metadata || {}) };
      session.send({ type: 'identified', sessionId: session.id });
      break;

    case 'join':
      session.metadata.roomId = msg.roomId;
      session.send({ type: 'joined', roomId: msg.roomId, sessionId: session.id });
      break;

    case 'leave':
      session.metadata.roomId = null;
      session.send({ type: 'left', sessionId: session.id });
      break;

    case 'audio:start':
      session.audioBuffer = [];
      session.send({ type: 'audio:ready', sessionId: session.id });
      break;

    case 'audio:end': {
      const totalBytes = session.audioBuffer.reduce((s, c) => s + c.length, 0);
      session.send({ type: 'audio:complete', bytes: totalBytes, sessionId: session.id });
      logger.info && logger.info('Voice session audio received', { sessionId: session.id, bytes: totalBytes });
      break;
    }

    case 'transcript': {
      // Relay transcript to room
      if (session.metadata.roomId) {
        voiceSessions.broadcast(
          { type: 'transcript', text: msg.text, userId: session.userId, sessionId: session.id },
          (s) => s.metadata.roomId === session.metadata.roomId
        );
      }
      break;
    }

    case 'disconnect':
      session.close(1000, 'Client requested disconnect');
      voiceSessions.remove(session.id);
      break;

    default:
      session.send({ type: 'error', code: 'UNKNOWN_MESSAGE_TYPE', message: `Unknown type: ${msg.type}` });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Module factory
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @param {import('express').Application} app
 * @param {object} deps
 * @param {object} deps.logger
 * @returns {{ voiceSessions: VoiceSessions }}
 */
module.exports = function mountVoiceRelay(app, { logger }) {
  const log = logger.child ? logger.child('voice-relay') : logger;

  const voiceSessions = new VoiceSessions({ logger: log });
  voiceSessions.startCleanup();

  // ── HTTP REST endpoints for voice session management ─────────────────────

  app.get('/api/voice/sessions', (req, res) => {
    res.json({
      sessions: voiceSessions.getAll().map((s) => s.toJSON()),
      stats: voiceSessions.stats(),
    });
  });

  app.delete('/api/voice/sessions/:id', (req, res) => {
    const session = voiceSessions.get(req.params.id);
    if (!session) return res.status(404).json({ error: 'Session not found' });
    session.close(4001, 'Terminated by admin');
    voiceSessions.remove(session.id);
    res.json({ ok: true, id: session.id });
  });

  app.get('/api/voice/stats', (req, res) => {
    res.json(voiceSessions.stats());
  });

  // ── WebSocket upgrade paths ───────────────────────────────────────────────
  // Paths handled during HTTP upgrade in server-boot.js
  const VOICE_WS_PATHS = ['/ws/voice', '/ws/voice/stream', '/ws/voice/chat'];

  // Expose upgrade handler for server-boot.js to call
  function handleUpgrade(ws, req, type) {
    const ip = req.headers['cf-connecting-ip']
      || req.headers['x-forwarded-for']?.split(',')[0].trim()
      || (req.socket && req.socket.remoteAddress)
      || 'unknown';

    const userId = (req.user && req.user.userId) || null;

    const session = voiceSessions.create(ws, {
      ip,
      userId,
      type: type || 'voice',
      metadata: {
        path: req.url,
        userAgent: req.headers['user-agent'],
      },
    });

    if (!session) return; // creation rejected (rate limit)

    ws.on('message', (data) => {
      handleVoiceMessage(session, data, voiceSessions, log);
    });

    ws.on('close', (code, reason) => {
      log.info('Voice WebSocket closed', { sessionId: session.id, code, reason: reason && reason.toString() });
      voiceSessions.remove(session.id);
    });

    ws.on('error', (err) => {
      log.warn('Voice WebSocket error', { sessionId: session.id, error: err.message });
      voiceSessions.remove(session.id);
    });

    // Send welcome frame
    session.send({
      type: 'connected',
      sessionId: session.id,
      timestamp: Date.now(),
      version: process.env.HEADY_VERSION || '3.0.1',
    });

    log.info('Voice WebSocket session started', {
      sessionId: session.id,
      type: session.type,
      ip,
      path: req.url,
    });
  }

  // Store upgrade handler on app for server-boot.js
  app._voiceUpgradeHandler = handleUpgrade;
  app._voiceWsPaths = VOICE_WS_PATHS;

  log.info('Voice relay mounted', {
    paths: VOICE_WS_PATHS,
    maxPerIP: MAX_SESSIONS_PER_IP,
    sessionTimeoutMs: SESSION_TIMEOUT_MS,
  });

  return { voiceSessions };
};

module.exports.VoiceSession  = VoiceSession;
module.exports.VoiceSessions = VoiceSessions;

// ── Utilities ─────────────────────────────────────────────────────────────────
function countBy(arr, keyFn) {
  const result = {};
  for (const item of arr) {
    const key = keyFn(item);
    result[key] = (result[key] || 0) + 1;
  }
  return result;
}
