'use strict';

/**
 * HeadyStack Bootstrap — Phase 6: Pipeline Binding + Self-Healing
 *
 * Binds the vector pipeline to buddy, vectorMemory, and selfAwareness.
 * Sets up self-healing loops for pipeline failures.
 * Wires event bus to pipeline triggers.
 *
 * module.exports = function(app, { pipeline, buddy, vectorMemory, selfAwareness, _engines, logger, eventBus })
 */

const crypto = require('crypto');

// ─────────────────────────────────────────────────────────────────────────────
// Self-Healing Pipeline Wrapper
// ─────────────────────────────────────────────────────────────────────────────
class SelfHealingPipeline {
  constructor(pipeline, options = {}) {
    this._pipeline       = pipeline;
    this._logger         = options.logger || console;
    this._eventBus       = options.eventBus || null;
    this._maxRetries     = options.maxRetries || 3;
    this._retryDelayMs   = options.retryDelayMs || 500;
    this._circuitBreakers = new Map(); // stageKey → CircuitState
    this._healingLog     = [];
    this._runCount       = 0;
    this._errorCount     = 0;
  }

  /**
   * Process input through the pipeline with retry and circuit-breaker.
   * @param {*} input
   * @param {object} [context]
   * @returns {Promise<*>}
   */
  async process(input, context = {}) {
    this._runCount++;
    const runId = crypto.randomBytes(4).toString('hex');
    const ctx = { ...context, runId, selfHealing: true };

    let lastError;
    for (let attempt = 1; attempt <= this._maxRetries; attempt++) {
      try {
        const result = await this._pipeline.process(input, ctx);
        if (attempt > 1) {
          this._logHealing('recovery', { runId, attempt });
          this._eventBus && this._eventBus.emit('pipeline:recovered', { runId, attempt });
        }
        return result;
      } catch (err) {
        lastError = err;
        this._errorCount++;
        this._logger.warn && this._logger.warn(`Pipeline error (attempt ${attempt}/${this._maxRetries})`, {
          runId,
          error: err.message,
          stage: err.stage || 'unknown',
        });

        if (attempt < this._maxRetries) {
          await sleep(this._retryDelayMs * attempt);
          this._logHealing('retry', { runId, attempt, error: err.message });
          this._eventBus && this._eventBus.emit('pipeline:retry', { runId, attempt, error: err.message });
        }
      }
    }

    this._logHealing('exhausted', { runId, error: lastError.message });
    this._eventBus && this._eventBus.emit('pipeline:failed', { runId, error: lastError.message });
    throw lastError;
  }

  /**
   * Record a healing event.
   * @private
   */
  _logHealing(type, data) {
    const entry = { type, timestamp: Date.now(), ...data };
    this._healingLog.push(entry);
    if (this._healingLog.length > 200) this._healingLog.shift();
  }

  /**
   * Get pipeline health stats.
   */
  stats() {
    const successRate = this._runCount > 0
      ? (this._runCount - this._errorCount) / this._runCount
      : 1;
    return {
      runCount: this._runCount,
      errorCount: this._errorCount,
      successRate: Math.round(successRate * 10000) / 10000,
      recentHealingEvents: this._healingLog.slice(-10),
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Module factory
// ─────────────────────────────────────────────────────────────────────────────

/**
 * @param {import('express').Application} app
 * @param {object} deps
 * @param {object} deps.pipeline
 * @param {object} deps.buddy
 * @param {object} deps.vectorMemory
 * @param {object} deps.selfAwareness
 * @param {object} [deps._engines]
 * @param {object} deps.logger
 * @param {object} deps.eventBus
 */
module.exports = function wirePipeline(app, {
  pipeline,
  buddy,
  vectorMemory,
  selfAwareness,
  _engines,
  logger,
  eventBus,
}) {
  const log = logger.child ? logger.child('pipeline-wiring') : logger;

  // ── Self-healing pipeline wrapper ──────────────────────────────────────
  const healingPipeline = new SelfHealingPipeline(pipeline, {
    logger: log,
    eventBus,
    maxRetries: 3,
    retryDelayMs: 250,
  });

  // ── Bind buddy → pipeline ──────────────────────────────────────────────
  if (buddy) {
    buddy.pipeline = healingPipeline;

    buddy.process = async function(input, context) {
      selfAwareness && selfAwareness.observe('buddy:process', { inputType: typeof input });
      return healingPipeline.process(input, context);
    };
  }

  // ── Memory persistence stage ──────────────────────────────────────────
  pipeline.register('memory-persist', async (input, ctx, vm) => {
    if (input && input.embedding && input.id) {
      vm.upsert(input.id, input.embedding, input.metadata || {}, input.namespace || 'pipeline');
    }
    return input;
  });

  // ── Self-awareness observation stage ──────────────────────────────────
  pipeline.register('self-observe', async (input, ctx) => {
    if (selfAwareness) {
      selfAwareness.observe('pipeline:process', {
        runId: ctx.runId,
        hasEmbedding: !!(input && input.embedding),
      });
    }
    return input;
  });

  // ── Event bus pipeline triggers ────────────────────────────────────────
  eventBus.on('pipeline:process', async (payload) => {
    try {
      const result = await healingPipeline.process(payload.input, payload.context || {});
      eventBus.emit('pipeline:result', { runId: payload.runId, result });
    } catch (err) {
      eventBus.emit('pipeline:error', { runId: payload.runId, error: err.message });
    }
  });

  eventBus.on('vector:upsert', ({ id, vector, metadata, namespace }) => {
    try {
      vectorMemory.upsert(id, vector, metadata || {}, namespace || 'default');
    } catch (err) {
      log.warn && log.warn('vector:upsert event error', { error: err.message });
    }
  });

  eventBus.on('vector:search', async ({ queryVector, options, replyEvent }) => {
    try {
      const results = vectorMemory.search(queryVector, options || {});
      if (replyEvent) eventBus.emit(replyEvent, { results });
    } catch (err) {
      log.warn && log.warn('vector:search event error', { error: err.message });
    }
  });

  // ── Engine integration ─────────────────────────────────────────────────
  if (_engines) {
    const { autoSuccess, qaEngine } = _engines;

    if (autoSuccess) {
      autoSuccess.define('pipeline-run', (result) => result !== null && result !== undefined);
    }

    if (qaEngine) {
      qaEngine.registerSuite('pipeline', [
        {
          name: 'pipeline-has-stages',
          fn: async () => {
            if (pipeline._stages.length === 0) throw new Error('Pipeline has no stages');
          },
        },
        {
          name: 'vector-memory-accessible',
          fn: async () => {
            if (!vectorMemory) throw new Error('vectorMemory not initialized');
            const stats = vectorMemory.stats();
            if (typeof stats.totalVectors !== 'number') throw new Error('vectorMemory.stats() malformed');
          },
        },
        {
          name: 'self-awareness-identity',
          fn: async () => {
            if (!selfAwareness) throw new Error('selfAwareness not initialized');
            const identity = selfAwareness.getIdentity();
            if (!identity.nodeId) throw new Error('selfAwareness identity missing nodeId');
          },
        },
      ]);
    }
  }

  // ── Express routes ─────────────────────────────────────────────────────

  app.get('/api/pipeline/stats', (req, res) => {
    res.json({
      pipeline: pipeline.stats ? pipeline.stats() : { stages: pipeline._stages.length },
      healing: healingPipeline.stats(),
    });
  });

  app.post('/api/pipeline/process', async (req, res) => {
    const { input, context } = req.body || {};
    try {
      const result = await healingPipeline.process(input, context || {});
      res.json({ ok: true, result });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/pipeline/healing', (req, res) => {
    res.json(healingPipeline.stats());
  });

  log.info('Pipeline wiring complete', {
    stages: pipeline._stages.length,
    selfHealing: true,
    maxRetries: 3,
  });

  return { healingPipeline };
};

module.exports.SelfHealingPipeline = SelfHealingPipeline;

// ── Utilities ────────────────────────────────────────────────────────────────
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
