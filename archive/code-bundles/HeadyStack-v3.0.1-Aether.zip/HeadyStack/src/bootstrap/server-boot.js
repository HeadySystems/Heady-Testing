'use strict';

/**
 * HeadyStack Bootstrap — Phase 10: Server Startup
 *
 * - HTTP server creation
 * - WebSocket upgrade handler (delegates to voice-relay)
 * - Listen on PORT (process.env.PORT || 8080)
 * - Graceful shutdown handler (SIGTERM, SIGINT)
 *
 * module.exports = function(app, { logger, voiceSessions })
 */

const http = require('http');

/**
 * @param {import('express').Application} app
 * @param {object} deps
 * @param {object} deps.logger
 * @param {object} [deps.voiceSessions]
 * @returns {Promise<{ server: http.Server, port: number }>}
 */
module.exports = async function bootServer(app, { logger, voiceSessions }) {
  const log = logger.child ? logger.child('server-boot') : logger;

  const PORT = parseInt(process.env.PORT || '8080', 10);

  // ── Create HTTP server ─────────────────────────────────────────────────────
  const server = http.createServer(app);

  // ── WebSocket upgrade handler ──────────────────────────────────────────────
  let wsServer = null;
  try {
    const WebSocket = require('ws');

    wsServer = new WebSocket.Server({ noServer: true });

    server.on('upgrade', (request, socket, head) => {
      const pathname = new URL(request.url, `http://localhost:${PORT}`).pathname;

      // Delegate to voice relay if path matches
      const voicePaths = app._voiceWsPaths || ['/ws/voice', '/ws/voice/stream', '/ws/voice/chat'];

      if (voicePaths.some((p) => pathname === p || pathname.startsWith(p + '/'))) {
        wsServer.handleUpgrade(request, socket, head, (ws) => {
          const type = pathname.includes('/stream') ? 'stream'
            : pathname.includes('/chat') ? 'chat'
            : 'voice';

          if (app._voiceUpgradeHandler) {
            app._voiceUpgradeHandler(ws, request, type);
          } else {
            ws.close(1011, 'Voice relay not configured');
          }
        });
        return;
      }

      // General WebSocket upgrade — custom route handler lookup
      const customHandler = app._wsHandlers && app._wsHandlers.get(pathname);
      if (customHandler) {
        wsServer.handleUpgrade(request, socket, head, (ws) => customHandler(ws, request));
        return;
      }

      // Unknown path — reject upgrade
      socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
      socket.destroy();
    });

    log.info('WebSocket server configured');
  } catch (err) {
    if (err.code === 'MODULE_NOT_FOUND') {
      log.warn('ws package not installed — WebSocket support disabled');
    } else {
      log.warn('WebSocket setup error', { error: err.message });
    }
  }

  // ── Start listening ────────────────────────────────────────────────────────
  await new Promise((resolve, reject) => {
    server.on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        log.error(`Port ${PORT} is already in use`, { port: PORT });
        reject(err);
        return;
      }
      log.error('Server error', { error: err.message });
      reject(err);
    });

    server.listen(PORT, () => {
      log.info('HeadyStack server listening', {
        port: PORT,
        env: process.env.NODE_ENV || 'development',
        pid: process.pid,
        version: process.env.HEADY_VERSION || '3.0.1',
        codename: process.env.HEADY_CODENAME || 'Aether',
        websocket: !!wsServer,
      });
      resolve();
    });
  });

  // ── Graceful shutdown ──────────────────────────────────────────────────────
  let _shuttingDown = false;

  async function gracefulShutdown(signal) {
    if (_shuttingDown) return;
    _shuttingDown = true;

    log.info(`Graceful shutdown initiated (${signal})`, { signal });

    // Stop accepting new connections
    server.close((err) => {
      if (err) log.warn('Server close error', { error: err.message });
      else log.info('HTTP server closed');
    });

    // Close all active voice sessions
    if (voiceSessions) {
      const sessions = voiceSessions.getAll();
      for (const session of sessions) {
        try {
          session.close(1001, 'Server shutting down');
        } catch (_) { /* ignore */ }
      }
      if (voiceSessions.stopCleanup) voiceSessions.stopCleanup();
      log.info('Voice sessions closed', { count: sessions.length });
    }

    // Close WebSocket server
    if (wsServer) {
      wsServer.close(() => log.info('WebSocket server closed'));
    }

    // Flush logger
    log.info('Shutdown complete', { signal });

    // Allow brief flush window then force exit
    const forceExitTimer = setTimeout(() => {
      log.warn('Force exiting after shutdown timeout');
      process.exit(signal === 'SIGTERM' ? 0 : 1);
    }, 8000);
    if (forceExitTimer.unref) forceExitTimer.unref();

    // Clean exit
    setTimeout(() => process.exit(0), 500).unref();
  }

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT',  () => gracefulShutdown('SIGINT'));

  // Unhandled rejection guard
  process.on('unhandledRejection', (reason, promise) => {
    log.error('Unhandled Promise rejection', {
      reason: reason instanceof Error ? reason.message : String(reason),
      stack:  reason instanceof Error ? reason.stack   : undefined,
    });
  });

  process.on('uncaughtException', (err) => {
    log.error('Uncaught exception', { error: err.message, stack: err.stack });
    // Give logger time to flush then exit
    setTimeout(() => process.exit(1), 500).unref();
  });

  // ── Expose server on app for testing ──────────────────────────────────────
  app._server = server;
  app._wsServer = wsServer;

  return { server, port: PORT };
};
