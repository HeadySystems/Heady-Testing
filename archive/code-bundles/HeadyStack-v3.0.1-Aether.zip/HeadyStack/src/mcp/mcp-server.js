'use strict';

/**
 * @fileoverview Full MCP server implementation for HeadyStack.
 * Implements JSON-RPC 2.0 over SSE transport with Bearer auth.
 * @module mcp/mcp-server
 */

const logger = require('../utils/logger');
const { MCPTransport } = require('./mcp-transport');
const { getAllTools, getTool, executeTool, getToolsByCategory } = require('./mcp-tools');

/**
 * Bearer token for API authentication.
 * Read from environment at startup.
 */
const MCP_BEARER_TOKEN = process.env.MCP_BEARER_TOKEN || process.env.HEADY_API_KEY;

/**
 * MCPServer — Express-mountable MCP server.
 * Registers /api/mcp/* routes with Bearer token authentication.
 */
class MCPServer {
  constructor() {
    this._transport = new MCPTransport();
    this._startedAt = new Date().toISOString();
    this._version = '1.0.0';

    logger.info('[mcp-server] MCPServer created', {
      tools: getAllTools().length,
      authEnabled: !!MCP_BEARER_TOKEN,
    });
  }

  // ─── Auth Middleware ──────────────────────────────────────────────────

  /**
   * Express middleware that validates Bearer token if MCP_BEARER_TOKEN is set.
   * Skips auth if no token is configured (development mode).
   * @param {Object} req
   * @param {Object} res
   * @param {Function} next
   */
  _authMiddleware(req, res, next) {
    if (!MCP_BEARER_TOKEN) {
      // Auth disabled in dev mode
      return next();
    }

    const authHeader = req.headers.authorization || '';
    if (!authHeader.startsWith('Bearer ')) {
      return res.status(401).json({
        error: 'Unauthorized',
        message: 'Authorization: Bearer <token> header required',
      });
    }

    const token = authHeader.slice(7);
    if (token !== MCP_BEARER_TOKEN) {
      logger.warn('[mcp-server] invalid bearer token', { ip: req.ip });
      return res.status(403).json({ error: 'Forbidden', message: 'Invalid bearer token' });
    }

    return next();
  }

  /**
   * Convenience wrapper: auth-checks and catches unhandled errors.
   * @param {Function} handler
   * @returns {Function}
   */
  _route(handler) {
    return async (req, res) => {
      try {
        await handler.call(this, req, res);
      } catch (err) {
        logger.error(`[mcp-server] unhandled route error: ${err.message}`, { stack: err.stack });
        if (!res.headersSent) {
          res.status(500).json({ error: 'Internal Server Error', message: err.message });
        }
      }
    };
  }

  // ─── Route Handlers ───────────────────────────────────────────────────

  /**
   * GET /api/mcp/health
   * Returns server health and statistics.
   */
  async _handleHealth(req, res) {
    const stats = this._transport.getStats();
    res.json({
      status: 'ok',
      version: this._version,
      startedAt: this._startedAt,
      tools: getAllTools().length,
      categories: Object.keys(getToolsByCategory()),
      transport: stats,
      timestamp: new Date().toISOString(),
    });
  }

  /**
   * GET /api/mcp/tools
   * Lists all available tools with optional category filter.
   */
  async _handleListTools(req, res) {
    const { category, limit, cursor, format } = req.query;
    let tools = getAllTools();

    if (category) {
      tools = tools.filter((t) => t.category === category);
    }

    // Handle JSON-RPC style request (POST with jsonrpc body)
    if (req.method === 'POST' && req.body?.jsonrpc === '2.0') {
      return this._transport.handleJSONRPC(req, res);
    }

    // REST style
    const pageSize = parseInt(limit, 10) || tools.length;
    const startIdx = cursor ? parseInt(cursor, 10) : 0;
    const page = tools.slice(startIdx, startIdx + pageSize);
    const nextCursor = startIdx + pageSize < tools.length ? String(startIdx + pageSize) : null;

    const byCategory = format === 'grouped' ? getToolsByCategory() : undefined;

    res.json({
      tools: page.map((t) => ({
        name: t.name,
        description: t.description,
        category: t.category,
        inputSchema: t.inputSchema,
      })),
      nextCursor,
      total: tools.length,
      byCategory,
    });
  }

  /**
   * POST /api/mcp/execute
   * Executes a tool via JSON-RPC 2.0 request body or REST body.
   */
  async _handleExecuteTool(req, res) {
    const body = req.body;

    // JSON-RPC 2.0 format
    if (body?.jsonrpc === '2.0') {
      return this._transport.handleJSONRPC(req, res);
    }

    // REST format: { name, params } or { tool, arguments }
    const name = body?.name || body?.tool;
    const params = body?.params || body?.arguments || body?.input || {};

    if (!name) {
      return res.status(400).json({ error: 'Bad Request', message: 'tool name required (body.name or body.tool)' });
    }

    const tool = getTool(name);
    if (!tool) {
      return res.status(404).json({
        error: 'Not Found',
        message: `Tool '${name}' not found`,
        available: getAllTools().map((t) => t.name),
      });
    }

    logger.info(`[mcp-server] executing tool: ${name}`, { params: Object.keys(params) });
    const result = await executeTool(name, params);

    if (!result.success) {
      return res.status(422).json({ error: 'Tool Execution Failed', ...result });
    }

    res.json(result);
  }

  /**
   * GET /api/mcp/stream
   * Establishes an SSE connection for streaming tool results.
   */
  async _handleStream(req, res) {
    const clientId = this._transport.handleSSE(req, res);
    logger.info(`[mcp-server] SSE stream opened: ${clientId}`);
  }

  /**
   * POST /api/mcp/stream
   * Executes a tool and streams the result to an existing SSE client.
   */
  async _handleStreamExecute(req, res) {
    return this._transport.handleStreamingRPC(req, res);
  }

  /**
   * GET /api/mcp/tools/:name
   * Returns the schema for a specific tool.
   */
  async _handleGetTool(req, res) {
    const { name } = req.params;
    const tool = getTool(name);

    if (!tool) {
      return res.status(404).json({
        error: 'Not Found',
        message: `Tool '${name}' not found`,
      });
    }

    res.json({
      name: tool.name,
      description: tool.description,
      category: tool.category,
      inputSchema: tool.inputSchema,
    });
  }

  /**
   * GET /api/mcp/categories
   * Returns all tool categories with their tools.
   */
  async _handleCategories(req, res) {
    const byCategory = getToolsByCategory();
    res.json({
      categories: Object.keys(byCategory).map((cat) => ({
        name: cat,
        tools: byCategory[cat],
        count: byCategory[cat].length,
      })),
      totalTools: getAllTools().length,
    });
  }

  /**
   * GET /api/mcp/clients
   * Returns info about connected SSE clients (internal/admin only).
   */
  async _handleClients(req, res) {
    const stats = this._transport.getStats();
    res.json({
      connectedClients: stats.connectedClients,
      stats,
    });
  }

  // ─── Route Registration ────────────────────────────────────────────────

  /**
   * Registers all MCP routes on an Express app instance.
   * Routes:
   *   GET  /api/mcp/health       — Server health
   *   GET  /api/mcp/tools        — List all tools (REST)
   *   POST /api/mcp/tools        — JSON-RPC tools/list
   *   GET  /api/mcp/tools/:name  — Get single tool schema
   *   POST /api/mcp/execute      — Execute tool (REST or JSON-RPC)
   *   GET  /api/mcp/stream       — Open SSE stream
   *   POST /api/mcp/stream       — Execute tool and stream result
   *   GET  /api/mcp/categories   — Tool categories
   *   GET  /api/mcp/clients      — Connected clients (admin)
   *
   * @param {Object} app - Express application instance
   */
  registerRoutes(app) {
    const auth = this._authMiddleware.bind(this);

    // Health (no auth — monitoring tools need this)
    app.get('/api/mcp/health', this._route(this._handleHealth));

    // Tools
    app.get('/api/mcp/tools', auth, this._route(this._handleListTools));
    app.post('/api/mcp/tools', auth, this._route(this._handleListTools));
    app.get('/api/mcp/tools/:name', auth, this._route(this._handleGetTool));

    // Execute
    app.post('/api/mcp/execute', auth, this._route(this._handleExecuteTool));

    // SSE Streaming
    app.get('/api/mcp/stream', auth, this._route(this._handleStream));
    app.post('/api/mcp/stream', auth, this._route(this._handleStreamExecute));

    // Categories
    app.get('/api/mcp/categories', auth, this._route(this._handleCategories));

    // Admin
    app.get('/api/mcp/clients', auth, this._route(this._handleClients));

    logger.info('[mcp-server] routes registered', {
      base: '/api/mcp',
      routes: ['health', 'tools', 'execute', 'stream', 'categories', 'clients'],
    });
  }

  // ─── Public API ────────────────────────────────────────────────────────

  /**
   * Returns a list of all registered tools.
   * @returns {Array<Object>}
   */
  listTools() {
    return getAllTools().map((t) => ({
      name: t.name,
      description: t.description,
      category: t.category,
    }));
  }

  /**
   * Executes a tool by name with params.
   * @param {string} name
   * @param {Object} [params]
   * @returns {Promise<Object>}
   */
  async executeTool(name, params = {}) {
    return executeTool(name, params);
  }

  /**
   * Returns the underlying transport instance.
   * @returns {MCPTransport}
   */
  getTransport() {
    return this._transport;
  }

  /**
   * Broadcasts a message to all connected SSE clients.
   * @param {string} event
   * @param {Object} data
   * @returns {number}
   */
  broadcast(event, data) {
    return this._transport.broadcast(event, data);
  }
}

/**
 * Singleton factory — creates or returns the existing MCPServer instance.
 * @type {MCPServer|null}
 */
let _instance = null;

/**
 * Returns the singleton MCPServer instance.
 * @returns {MCPServer}
 */
function getInstance() {
  if (!_instance) _instance = new MCPServer();
  return _instance;
}

module.exports = {
  MCPServer,
  getInstance,
};
