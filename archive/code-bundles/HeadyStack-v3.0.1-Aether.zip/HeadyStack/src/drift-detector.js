'use strict';

/**
 * @module drift-detector
 * @description Semantic drift detection for HeadyStack v3.0.1 "Aether".
 *
 * Tracks per-component embedding histories and fires drift alerts when a
 * component's current embedding deviates beyond a configurable threshold from
 * its registered baseline.
 */

const logger = require('./utils/logger');

// ─── Constants ────────────────────────────────────────────────────────────────

const DEFAULT_THRESHOLD = 0.75;
const MAX_HISTORY_PER_COMPONENT = 100;

// ─── Inline cosine similarity (no circular dependency) ───────────────────────

/**
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {number}
 */
function cosine(a, b) {
  if (a.length !== b.length) throw new Error('Vector length mismatch');
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot  += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);
  if (magA === 0 || magB === 0) return 0;
  return dot / (magA * magB);
}

// ─── DriftDetector class ──────────────────────────────────────────────────────

class DriftDetector {
  /**
   * @param {object} [opts]
   * @param {number} [opts.defaultThreshold=0.75] — global default drift threshold
   */
  constructor(opts = {}) {
    this._defaultThreshold = opts.defaultThreshold || DEFAULT_THRESHOLD;

    /**
     * Per-component state.
     * @type {Map<string, {
     *   baseline: Float64Array,
     *   current: Float64Array,
     *   threshold: number,
     *   history: Array<{similarity: number, timestamp: number, drifted: boolean}>,
     *   driftCount: number,
     *   lastDriftAt: number|null,
     *   registeredAt: number,
     * }>}
     */
    this._components = new Map();

    /** Global drift event log (last 500 events). */
    this._driftLog = [];
  }

  // ── Core detection ───────────────────────────────────────────────────────

  /**
   * Detect whether currentEmbedding has drifted from baselineEmbedding.
   *
   * @param {Float64Array} currentEmbedding
   * @param {Float64Array} baselineEmbedding
   * @param {number} [threshold=0.75]
   * @returns {{ drifted: boolean, similarity: number, threshold: number, delta: number }}
   */
  detectDrift(currentEmbedding, baselineEmbedding, threshold = this._defaultThreshold) {
    if (!(currentEmbedding instanceof Float64Array) || !(baselineEmbedding instanceof Float64Array)) {
      throw new Error('Both currentEmbedding and baselineEmbedding must be Float64Array');
    }
    const similarity = cosine(currentEmbedding, baselineEmbedding);
    const drifted    = similarity < threshold;
    return {
      drifted,
      similarity,
      threshold,
      delta: threshold - similarity, // positive when drifted
    };
  }

  // ── Component tracking ───────────────────────────────────────────────────

  /**
   * Register a new component with its initial (baseline) embedding.
   * If the component already exists, re-baselines it.
   *
   * @param {string} componentId
   * @param {Float64Array} embedding - initial baseline embedding
   * @param {object} [opts]
   * @param {number} [opts.threshold] - per-component threshold override
   */
  registerComponent(componentId, embedding, opts = {}) {
    if (!(embedding instanceof Float64Array)) {
      throw new Error('embedding must be a Float64Array');
    }
    const threshold = opts.threshold !== undefined ? opts.threshold : this._defaultThreshold;

    this._components.set(componentId, {
      baseline:     new Float64Array(embedding),
      current:      new Float64Array(embedding),
      threshold,
      history:      [],
      driftCount:   0,
      lastDriftAt:  null,
      registeredAt: Date.now(),
    });

    logger.debug(`drift-detector: registered component "${componentId}" (threshold=${threshold})`);
  }

  /**
   * Track a new embedding observation for a component.
   * Auto-registers the component on first observation (using the first
   * embedding as baseline).
   *
   * @param {string} componentId
   * @param {Float64Array} embedding
   * @returns {{ drifted: boolean, similarity: number, delta: number }}
   */
  trackComponent(componentId, embedding) {
    if (!(embedding instanceof Float64Array)) {
      throw new Error('embedding must be a Float64Array');
    }

    if (!this._components.has(componentId)) {
      this.registerComponent(componentId, embedding);
      return { drifted: false, similarity: 1.0, delta: 0 };
    }

    const comp = this._components.get(componentId);
    comp.current = new Float64Array(embedding);

    const result = this.detectDrift(embedding, comp.baseline, comp.threshold);
    const record = {
      similarity: result.similarity,
      timestamp: Date.now(),
      drifted: result.drifted,
    };

    comp.history.push(record);
    if (comp.history.length > MAX_HISTORY_PER_COMPONENT) comp.history.shift();

    if (result.drifted) {
      comp.driftCount++;
      comp.lastDriftAt = Date.now();

      const event = {
        componentId,
        similarity: result.similarity,
        threshold: comp.threshold,
        delta: result.delta,
        driftCount: comp.driftCount,
        timestamp: Date.now(),
      };
      this._driftLog.push(event);
      if (this._driftLog.length > 500) this._driftLog.shift();

      logger.warn(
        `drift-detector: drift in "${componentId}" sim=${result.similarity.toFixed(4)} delta=${result.delta.toFixed(4)} count=${comp.driftCount}`
      );
    }

    return result;
  }

  /**
   * Re-baseline a component to its current embedding (drift acknowledged).
   * @param {string} componentId
   * @returns {boolean} true if component existed
   */
  rebaseline(componentId) {
    const comp = this._components.get(componentId);
    if (!comp) return false;
    comp.baseline = new Float64Array(comp.current);
    logger.info(`drift-detector: rebased component "${componentId}"`);
    return true;
  }

  // ── Reporting ────────────────────────────────────────────────────────────

  /**
   * Get drift status for all tracked components.
   * @returns {{
   *   components: object,
   *   summary: { total: number, drifted: number, nominal: number, totalDriftEvents: number }
   * }}
   */
  getDriftReport() {
    const components = {};
    let driftedCount = 0;

    for (const [id, comp] of this._components.entries()) {
      const currentSimilarity = cosine(comp.current, comp.baseline);
      const isDrifted = currentSimilarity < comp.threshold;
      if (isDrifted) driftedCount++;

      // Trend: average similarity from last 5 history entries
      const recent = comp.history.slice(-5);
      const avgSimilarity = recent.length
        ? recent.reduce((s, h) => s + h.similarity, 0) / recent.length
        : currentSimilarity;

      components[id] = {
        status: isDrifted ? 'DRIFTED' : 'NOMINAL',
        currentSimilarity: Math.round(currentSimilarity * 10000) / 10000,
        threshold: comp.threshold,
        delta: Math.round((comp.threshold - currentSimilarity) * 10000) / 10000,
        driftCount: comp.driftCount,
        lastDriftAt: comp.lastDriftAt,
        registeredAt: comp.registeredAt,
        recentAvgSimilarity: Math.round(avgSimilarity * 10000) / 10000,
        historyLength: comp.history.length,
      };
    }

    return {
      components,
      summary: {
        total: this._components.size,
        drifted: driftedCount,
        nominal: this._components.size - driftedCount,
        totalDriftEvents: this._driftLog.length,
      },
      recentEvents: this._driftLog.slice(-10),
      timestamp: Date.now(),
    };
  }

  /**
   * Get drift history for a specific component.
   * @param {string} componentId
   * @param {number} [limit=20]
   * @returns {object[]|null}
   */
  getComponentHistory(componentId, limit = 20) {
    const comp = this._components.get(componentId);
    if (!comp) return null;
    return comp.history.slice(-limit);
  }

  /**
   * List all tracked component IDs.
   * @returns {string[]}
   */
  listComponents() {
    return [...this._components.keys()];
  }

  /**
   * Remove a component from tracking.
   * @param {string} componentId
   * @returns {boolean}
   */
  removeComponent(componentId) {
    const existed = this._components.delete(componentId);
    if (existed) logger.debug(`drift-detector: removed component "${componentId}"`);
    return existed;
  }
}

// ─── Module singleton ─────────────────────────────────────────────────────────

let _instance = null;

/**
 * Get or create the global DriftDetector singleton.
 * @param {object} [opts]
 * @returns {DriftDetector}
 */
function getDriftDetector(opts) {
  if (!_instance) _instance = new DriftDetector(opts);
  return _instance;
}

// ─── Module exports ───────────────────────────────────────────────────────────

module.exports = {
  DriftDetector,
  getDriftDetector,
  DEFAULT_THRESHOLD,
};
