'use strict';

/**
 * @module vector-space-ops
 * @description Vector space mathematics and continuous operations for HeadyStack v3.0.1 "Aether".
 *
 * Provides:
 *  - cosineSimilarity, euclideanDistance, normalize — pure math on Float64Array
 *  - projectTo3D — PCA-inspired projection of 384D embeddings to 3D for visualization
 *  - VectorSpaceOps class — continuous background loops (anti-sprawl, security, maintenance,
 *    projection updates) and Express REST routes
 */

const logger = require('./utils/logger');

// ─── Constants ────────────────────────────────────────────────────────────────

const EMBEDDING_DIM = 384;
const PROJECTION_DIM = 3;

// Pre-computed deterministic projection matrix seeded from Golden Ratio rows
// so that projectTo3D is stable across restarts without training data.
// Each row is a EMBEDDING_DIM-length unit vector (normalised inside generateProjectionMatrix).
const _projectionMatrix = (() => {
  const PHI = 1.6180339887498948482;
  const rows = [];
  for (let r = 0; r < PROJECTION_DIM; r++) {
    const row = new Float64Array(EMBEDDING_DIM);
    for (let c = 0; c < EMBEDDING_DIM; c++) {
      // Deterministic pseudo-random: use fractional part of phi^(r*dim+c)
      const x = Math.pow(PHI, (r * EMBEDDING_DIM + c) % 17) % 1;
      row[c] = x * 2 - 1; // centre around 0
    }
    // Normalise the row
    let mag = 0;
    for (let c = 0; c < EMBEDDING_DIM; c++) mag += row[c] * row[c];
    mag = Math.sqrt(mag);
    for (let c = 0; c < EMBEDDING_DIM; c++) row[c] /= mag;
    rows.push(row);
  }
  return rows;
})();

// ─── Pure math exports ────────────────────────────────────────────────────────

/**
 * Cosine similarity between two 384D Float64Arrays.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {number} value in [-1, 1]
 */
function cosineSimilarity(a, b) {
  if (a.length !== b.length) throw new Error('Vectors must have equal length');
  let dot = 0, magA = 0, magB = 0;
  for (let i = 0; i < a.length; i++) {
    dot  += a[i] * b[i];
    magA += a[i] * a[i];
    magB += b[i] * b[i];
  }
  magA = Math.sqrt(magA);
  magB = Math.sqrt(magB);
  if (magA === 0 || magB === 0) return 0;
  return dot / (magA * magB);
}

/**
 * Euclidean (L2) distance between two equal-length Float64Arrays.
 * @param {Float64Array} a
 * @param {Float64Array} b
 * @returns {number}
 */
function euclideanDistance(a, b) {
  if (a.length !== b.length) throw new Error('Vectors must have equal length');
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const d = a[i] - b[i];
    sum += d * d;
  }
  return Math.sqrt(sum);
}

/**
 * L2-normalise a Float64Array in-place and return it.
 * @param {Float64Array} v
 * @returns {Float64Array}
 */
function normalize(v) {
  let mag = 0;
  for (let i = 0; i < v.length; i++) mag += v[i] * v[i];
  mag = Math.sqrt(mag);
  if (mag === 0) return v;
  for (let i = 0; i < v.length; i++) v[i] /= mag;
  return v;
}

/**
 * Project a 384D embedding to 3D using the stable pre-computed projection matrix.
 * @param {Float64Array} embedding384D - input vector of length 384
 * @returns {[number, number, number]} x, y, z coordinates
 */
function projectTo3D(embedding384D) {
  if (embedding384D.length !== EMBEDDING_DIM) {
    throw new Error(`projectTo3D expects a ${EMBEDDING_DIM}-element Float64Array`);
  }
  const result = new Array(PROJECTION_DIM);
  for (let r = 0; r < PROJECTION_DIM; r++) {
    let val = 0;
    const row = _projectionMatrix[r];
    for (let c = 0; c < EMBEDDING_DIM; c++) {
      val += row[c] * embedding384D[c];
    }
    result[r] = val;
  }
  return result; // [x, y, z]
}

/**
 * Cluster an array of Float64Array vectors using k-means (k iterations, Lloyd's algorithm).
 * @param {Float64Array[]} vectors
 * @param {number} k - number of clusters
 * @param {number} [maxIter=20]
 * @returns {{ centroids: Float64Array[], assignments: number[] }}
 */
function kMeansCluster(vectors, k, maxIter = 20) {
  if (vectors.length === 0 || k <= 0) return { centroids: [], assignments: [] };
  const n = vectors.length;
  const dim = vectors[0].length;
  k = Math.min(k, n);

  // Initialise centroids as first k vectors
  let centroids = vectors.slice(0, k).map(v => new Float64Array(v));
  let assignments = new Array(n).fill(0);

  for (let iter = 0; iter < maxIter; iter++) {
    let changed = false;

    // Assignment step
    for (let i = 0; i < n; i++) {
      let bestIdx = 0;
      let bestDist = Infinity;
      for (let j = 0; j < k; j++) {
        const d = euclideanDistance(vectors[i], centroids[j]);
        if (d < bestDist) { bestDist = d; bestIdx = j; }
      }
      if (assignments[i] !== bestIdx) { assignments[i] = bestIdx; changed = true; }
    }

    if (!changed) break;

    // Update step
    const sums = Array.from({ length: k }, () => new Float64Array(dim));
    const counts = new Array(k).fill(0);
    for (let i = 0; i < n; i++) {
      const c = assignments[i];
      for (let d = 0; d < dim; d++) sums[c][d] += vectors[i][d];
      counts[c]++;
    }
    for (let j = 0; j < k; j++) {
      if (counts[j] > 0) {
        for (let d = 0; d < dim; d++) sums[j][d] /= counts[j];
        centroids[j] = sums[j];
      }
    }
  }

  return { centroids, assignments };
}

// ─── VectorSpaceOps class ─────────────────────────────────────────────────────

class VectorSpaceOps {
  /**
   * @param {import('./vector-memory').VectorMemory} vectorMemory
   */
  constructor(vectorMemory) {
    this._vectorMemory = vectorMemory;
    this._running = false;
    this._intervals = [];
    this._projectionCache = new Map(); // id → [x,y,z]
    this._securityAlerts = [];
    this._stats = {
      antiSprawlRuns: 0,
      securityScans: 0,
      maintenanceRuns: 0,
      projectionUpdates: 0,
    };
  }

  // ── Background loops ─────────────────────────────────────────────────────

  /**
   * Anti-sprawl: prune namespaces that exceed their per-namespace size budget.
   * Removes lowest-scored (oldest) entries when over capacity.
   */
  _runAntiSprawl() {
    const MAX_PER_NS = parseInt(process.env.VM_MAX_ENTRIES || '100000', 10);
    const stats = this._vectorMemory.getStats();
    for (const [ns, count] of Object.entries(stats.namespaceStats)) {
      if (count > MAX_PER_NS) {
        const excess = count - MAX_PER_NS;
        logger.warn(`vector-space-ops: anti-sprawl pruning ${excess} entries from "${ns}"`);
        // Export, sort by timestamp asc, delete oldest
        const entries = this._vectorMemory.exportEntries(ns);
        entries.sort((a, b) => a.timestamp - b.timestamp);
        for (let i = 0; i < excess; i++) {
          this._vectorMemory.delete(entries[i].id, ns);
        }
      }
    }
    this._stats.antiSprawlRuns++;
  }

  /**
   * Security scan: detect anomalous vectors (NaN, Infinity, or zero-magnitude).
   */
  _runSecurityScan() {
    let anomalies = 0;
    const stats = this._vectorMemory.getStats();
    for (const ns of Object.keys(stats.namespaceStats)) {
      const entries = this._vectorMemory.exportEntries(ns);
      for (const e of entries) {
        const vec = new Float64Array(e.vector);
        let mag = 0;
        let invalid = false;
        for (let i = 0; i < vec.length; i++) {
          if (!isFinite(vec[i])) { invalid = true; break; }
          mag += vec[i] * vec[i];
        }
        if (invalid || mag === 0) {
          anomalies++;
          this._securityAlerts.push({
            id: e.id,
            namespace: ns,
            reason: invalid ? 'non-finite values' : 'zero-magnitude vector',
            timestamp: Date.now(),
          });
          logger.warn(`vector-space-ops: security anomaly in "${ns}/${e.id}": ${invalid ? 'non-finite' : 'zero-magnitude'}`);
          this._vectorMemory.delete(e.id, ns);
        }
      }
    }
    if (anomalies > 0) {
      logger.warn(`vector-space-ops: security scan removed ${anomalies} anomalous vector(s)`);
    }
    this._stats.securityScans++;
  }

  /**
   * Maintenance: persist dirty namespaces to disk.
   */
  async _runMaintenance() {
    try {
      await this._vectorMemory.persist();
    } catch (e) {
      logger.error('vector-space-ops: maintenance persist failed', e);
    }
    this._stats.maintenanceRuns++;
  }

  /**
   * Projection update: re-project all stored vectors to 3D and cache results.
   */
  _runProjectionUpdate() {
    const stats = this._vectorMemory.getStats();
    let updated = 0;
    for (const ns of Object.keys(stats.namespaceStats)) {
      const entries = this._vectorMemory.exportEntries(ns);
      for (const e of entries) {
        try {
          const f64 = new Float64Array(e.vector);
          const point = projectTo3D(f64);
          this._projectionCache.set(`${ns}::${e.id}`, point);
          updated++;
        } catch {
          // ignore invalid entries
        }
      }
    }
    logger.debug(`vector-space-ops: updated ${updated} 3D projections`);
    this._stats.projectionUpdates++;
  }

  /**
   * Start all continuous background operations.
   */
  start() {
    if (this._running) return;
    this._running = true;

    const ANTI_SPRAWL_MS   = parseInt(process.env.ANTI_SPRAWL_INTERVAL   || '300000',  10); // 5 min
    const SECURITY_SCAN_MS  = parseInt(process.env.SECURITY_SCAN_INTERVAL  || '120000',  10); // 2 min
    const MAINTENANCE_MS    = parseInt(process.env.MAINTENANCE_INTERVAL    || '60000',   10); // 1 min
    const PROJECTION_UPD_MS = parseInt(process.env.PROJECTION_UPD_INTERVAL || '30000',  10); // 30 s

    this._intervals.push(setInterval(() => this._runAntiSprawl(), ANTI_SPRAWL_MS));
    this._intervals.push(setInterval(() => this._runSecurityScan(), SECURITY_SCAN_MS));
    this._intervals.push(setInterval(() => this._runMaintenance(), MAINTENANCE_MS));
    this._intervals.push(setInterval(() => this._runProjectionUpdate(), PROJECTION_UPD_MS));

    // Run immediately on first tick
    process.nextTick(() => {
      this._runProjectionUpdate();
      this._runSecurityScan();
    });

    logger.info('vector-space-ops: background loops started');
  }

  /**
   * Stop all background loops.
   */
  stop() {
    for (const iv of this._intervals) clearInterval(iv);
    this._intervals = [];
    this._running = false;
    logger.info('vector-space-ops: background loops stopped');
  }

  // ── Express Routes ───────────────────────────────────────────────────────

  /**
   * Register Express routes for vector operations.
   * @param {import('express').Application} app
   */
  registerRoutes(app) {
    /**
     * POST /api/vector-ops/project
     * Body: { vector: number[] }
     * Response: { point: [x,y,z] }
     */
    app.post('/api/vector-ops/project', (req, res) => {
      try {
        const { vector } = req.body;
        if (!Array.isArray(vector) || vector.length !== EMBEDDING_DIM) {
          return res.status(400).json({ error: `vector must be a ${EMBEDDING_DIM}-element array` });
        }
        const point = projectTo3D(new Float64Array(vector));
        res.json({ point });
      } catch (err) {
        logger.error('POST /api/vector-ops/project error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * POST /api/vector-ops/similarity
     * Body: { a: number[], b: number[] }
     * Response: { cosine: number, euclidean: number }
     */
    app.post('/api/vector-ops/similarity', (req, res) => {
      try {
        const { a, b } = req.body;
        if (!Array.isArray(a) || !Array.isArray(b)) {
          return res.status(400).json({ error: 'a[] and b[] required' });
        }
        const fa = new Float64Array(a);
        const fb = new Float64Array(b);
        res.json({
          cosine: cosineSimilarity(fa, fb),
          euclidean: euclideanDistance(fa, fb),
        });
      } catch (err) {
        logger.error('POST /api/vector-ops/similarity error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * POST /api/vector-ops/cluster
     * Body: { vectors: number[][], k: number, maxIter?: number }
     * Response: { k, assignments: number[], centroids: number[][] }
     */
    app.post('/api/vector-ops/cluster', (req, res) => {
      try {
        const { vectors, k, maxIter } = req.body;
        if (!Array.isArray(vectors) || typeof k !== 'number') {
          return res.status(400).json({ error: 'vectors[][] and k (number) required' });
        }
        const f64Vectors = vectors.map(v => new Float64Array(v));
        const { centroids, assignments } = kMeansCluster(f64Vectors, k, maxIter);
        res.json({
          k,
          assignments,
          centroids: centroids.map(c => Array.from(c)),
        });
      } catch (err) {
        logger.error('POST /api/vector-ops/cluster error', err);
        res.status(500).json({ error: err.message });
      }
    });

    /**
     * GET /api/vector-ops/projections
     * Returns cached 3D projections for all known IDs.
     */
    app.get('/api/vector-ops/projections', (req, res) => {
      const output = {};
      for (const [key, point] of this._projectionCache.entries()) {
        output[key] = point;
      }
      res.json({ projections: output, count: this._projectionCache.size });
    });

    /**
     * GET /api/vector-ops/status
     */
    app.get('/api/vector-ops/status', (req, res) => {
      res.json({
        running: this._running,
        stats: this._stats,
        securityAlerts: this._securityAlerts.slice(-10),
        projectionCacheSize: this._projectionCache.size,
      });
    });

    logger.info('vector-space-ops: Express routes registered');
  }
}

// ─── Module exports ───────────────────────────────────────────────────────────

module.exports = {
  cosineSimilarity,
  euclideanDistance,
  normalize,
  projectTo3D,
  kMeansCluster,
  VectorSpaceOps,
  EMBEDDING_DIM,
  PROJECTION_DIM,
};
