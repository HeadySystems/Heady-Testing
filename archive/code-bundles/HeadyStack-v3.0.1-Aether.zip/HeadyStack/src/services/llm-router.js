'use strict';

/**
 * LLMRouter — Dynamic LLM provider routing with liquid failover,
 * budget enforcement, and per-task routing matrices.
 */

const EventEmitter = require('events');
const { getBudgetTracker } = require('./budget-tracker');

// ─── Provider definitions ────────────────────────────────────────────────────

const PROVIDERS = {
  'claude-3-5-sonnet': {
    id: 'claude-3-5-sonnet',
    vendor: 'anthropic',
    model: 'claude-3-5-sonnet-20241022',
    costPer1kTokens: 0.003,
    maxTokens: 8192,
    supportsEmbeddings: false,
  },
  'claude-3-opus': {
    id: 'claude-3-opus',
    vendor: 'anthropic',
    model: 'claude-3-opus-20240229',
    costPer1kTokens: 0.015,
    maxTokens: 4096,
    supportsEmbeddings: false,
  },
  'gpt-4o': {
    id: 'gpt-4o',
    vendor: 'openai',
    model: 'gpt-4o',
    costPer1kTokens: 0.005,
    maxTokens: 4096,
    supportsEmbeddings: false,
  },
  'gpt-4o-mini': {
    id: 'gpt-4o-mini',
    vendor: 'openai',
    model: 'gpt-4o-mini',
    costPer1kTokens: 0.00015,
    maxTokens: 4096,
    supportsEmbeddings: false,
  },
  'gemini-pro': {
    id: 'gemini-pro',
    vendor: 'google',
    model: 'gemini-1.5-pro',
    costPer1kTokens: 0.0035,
    maxTokens: 8192,
    supportsEmbeddings: false,
  },
  'gemini-flash': {
    id: 'gemini-flash',
    vendor: 'google',
    model: 'gemini-1.5-flash',
    costPer1kTokens: 0.00035,
    maxTokens: 8192,
    supportsEmbeddings: false,
  },
  'groq-llama': {
    id: 'groq-llama',
    vendor: 'groq',
    model: 'llama-3.3-70b-versatile',
    costPer1kTokens: 0.00059,
    maxTokens: 32768,
    supportsEmbeddings: false,
  },
  'perplexity-sonar': {
    id: 'perplexity-sonar',
    vendor: 'perplexity',
    model: 'sonar-pro',
    costPer1kTokens: 0.003,
    maxTokens: 4096,
    supportsEmbeddings: false,
  },
  'cloudflare-edge': {
    id: 'cloudflare-edge',
    vendor: 'cloudflare',
    model: '@cf/baai/bge-base-en-v1.5',
    costPer1kTokens: 0.0001,
    supportsEmbeddings: true,
    embeddingDims: 768,
  },
  'openai-ada': {
    id: 'openai-ada',
    vendor: 'openai',
    model: 'text-embedding-3-small',
    costPer1kTokens: 0.00002,
    supportsEmbeddings: true,
    embeddingDims: 1536,
  },
  'local': {
    id: 'local',
    vendor: 'local',
    model: 'all-MiniLM-L6-v2',
    costPer1kTokens: 0,
    supportsEmbeddings: true,
    embeddingDims: 384,
  },
};

// ─── Routing matrix ──────────────────────────────────────────────────────────

const ROUTING_MATRIX = {
  code_generation:  ['claude-3-5-sonnet', 'gpt-4o', 'groq-llama'],
  code_review:      ['claude-3-5-sonnet', 'gpt-4o', 'gemini-pro'],
  architecture:     ['claude-3-opus', 'gpt-4o', 'claude-3-5-sonnet'],
  research:         ['perplexity-sonar', 'claude-3-5-sonnet', 'gpt-4o'],
  quick_tasks:      ['groq-llama', 'gpt-4o-mini', 'gemini-flash'],
  creative:         ['claude-3-opus', 'gpt-4o', 'gemini-pro'],
  security_audit:   ['claude-3-5-sonnet', 'gpt-4o', 'claude-3-opus'],
  documentation:    ['gpt-4o', 'claude-3-5-sonnet', 'gemini-pro'],
  embeddings:       ['cloudflare-edge', 'openai-ada', 'local'],
  default:          ['gpt-4o', 'claude-3-5-sonnet', 'groq-llama'],
};

const RATE_LIMIT_RETRY_COUNT = 2;
const RATE_LIMIT_RETRY_DELAY_MS = 2000;

// ─── Provider call adapters ──────────────────────────────────────────────────

async function callProvider(provider, prompt, opts = {}) {
  const def = PROVIDERS[provider];
  if (!def) throw new Error(`Unknown provider: ${provider}`);

  const { vendor, model } = def;
  const maxTokens = opts.maxTokens || def.maxTokens || 2048;
  const temperature = opts.temperature != null ? opts.temperature : 0.7;
  const systemPrompt = opts.systemPrompt || opts.system || '';

  switch (vendor) {
    case 'anthropic': {
      const Anthropic = require('@anthropic-ai/sdk');
      const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
      const messages = [{ role: 'user', content: prompt }];
      const params = { model, max_tokens: maxTokens, messages };
      if (systemPrompt) params.system = systemPrompt;
      if (temperature != null) params.temperature = temperature;
      const resp = await client.messages.create(params);
      const content = resp.content[0]?.text || '';
      const usage = resp.usage || {};
      return {
        text: content,
        provider,
        model,
        tokens: { input: usage.input_tokens || 0, output: usage.output_tokens || 0 },
      };
    }

    case 'openai': {
      const OpenAI = require('openai');
      const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      const messages = [];
      if (systemPrompt) messages.push({ role: 'system', content: systemPrompt });
      messages.push({ role: 'user', content: prompt });
      const resp = await client.chat.completions.create({
        model,
        messages,
        max_tokens: maxTokens,
        temperature,
      });
      const text = resp.choices[0]?.message?.content || '';
      const usage = resp.usage || {};
      return {
        text,
        provider,
        model,
        tokens: { input: usage.prompt_tokens || 0, output: usage.completion_tokens || 0 },
      };
    }

    case 'google': {
      const { GoogleGenerativeAI } = require('@google/generative-ai');
      const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_API_KEY || process.env.GEMINI_API_KEY);
      const genModel = genAI.getGenerativeModel({ model, generationConfig: { maxOutputTokens: maxTokens, temperature } });
      const result = await genModel.generateContent(prompt);
      const text = result.response?.text() || '';
      return {
        text,
        provider,
        model,
        tokens: { input: 0, output: 0 }, // Gemini doesn't always return token counts in basic API
      };
    }

    case 'groq': {
      const Groq = require('groq-sdk');
      const client = new Groq({ apiKey: process.env.GROQ_API_KEY });
      const messages = [];
      if (systemPrompt) messages.push({ role: 'system', content: systemPrompt });
      messages.push({ role: 'user', content: prompt });
      const resp = await client.chat.completions.create({
        model,
        messages,
        max_tokens: maxTokens,
        temperature,
      });
      const text = resp.choices[0]?.message?.content || '';
      const usage = resp.usage || {};
      return {
        text,
        provider,
        model,
        tokens: { input: usage.prompt_tokens || 0, output: usage.completion_tokens || 0 },
      };
    }

    case 'perplexity': {
      const axios = require('axios');
      const messages = [];
      if (systemPrompt) messages.push({ role: 'system', content: systemPrompt });
      messages.push({ role: 'user', content: prompt });
      const resp = await axios.post(
        'https://api.perplexity.ai/chat/completions',
        { model, messages, max_tokens: maxTokens },
        { headers: { Authorization: `Bearer ${process.env.PERPLEXITY_API_KEY}`, 'Content-Type': 'application/json' } }
      );
      const text = resp.data.choices[0]?.message?.content || '';
      const usage = resp.data.usage || {};
      return {
        text,
        provider,
        model,
        tokens: { input: usage.prompt_tokens || 0, output: usage.completion_tokens || 0 },
        citations: resp.data.citations || [],
      };
    }

    default:
      throw new Error(`No call adapter for vendor: ${vendor}`);
  }
}

async function callEmbeddingProvider(provider, text) {
  const def = PROVIDERS[provider];
  if (!def) throw new Error(`Unknown provider: ${provider}`);
  if (!def.supportsEmbeddings) throw new Error(`${provider} does not support embeddings`);

  switch (def.vendor) {
    case 'openai': {
      const OpenAI = require('openai');
      const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
      const resp = await client.embeddings.create({ model: def.model, input: text });
      return {
        embedding: resp.data[0].embedding,
        dims: def.embeddingDims,
        provider,
        model: def.model,
        tokens: resp.usage?.total_tokens || 0,
      };
    }

    case 'cloudflare': {
      const axios = require('axios');
      const accountId = process.env.CLOUDFLARE_ACCOUNT_ID;
      const apiToken = process.env.CLOUDFLARE_API_TOKEN;
      const resp = await axios.post(
        `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/run/${def.model}`,
        { text: Array.isArray(text) ? text : [text] },
        { headers: { Authorization: `Bearer ${apiToken}`, 'Content-Type': 'application/json' } }
      );
      const embedding = resp.data?.result?.data?.[0] || [];
      return { embedding, dims: def.embeddingDims, provider, model: def.model, tokens: 0 };
    }

    case 'local': {
      // Attempt local sentence-transformers via Python subprocess or pre-loaded model
      // Falls back to a zero vector if unavailable
      try {
        const { execFileSync } = require('child_process');
        const payload = JSON.stringify({ text });
        const out = execFileSync('python3', ['-c', `
import sys, json
from sentence_transformers import SentenceTransformer
data = json.loads(sys.argv[1])
model = SentenceTransformer('all-MiniLM-L6-v2')
emb = model.encode(data['text']).tolist()
print(json.dumps(emb))
`, payload], { timeout: 30000 });
        const embedding = JSON.parse(out.toString().trim());
        return { embedding, dims: 384, provider, model: def.model, tokens: 0 };
      } catch (e) {
        const embedding = Array(384).fill(0);
        return { embedding, dims: 384, provider, model: def.model, tokens: 0, warning: 'local model unavailable, zero vector returned' };
      }
    }

    default:
      throw new Error(`No embedding adapter for vendor: ${def.vendor}`);
  }
}

// ─── Health check adapters ───────────────────────────────────────────────────

async function checkProviderHealth(provider) {
  const def = PROVIDERS[provider];
  if (!def) return { provider, ok: false, error: 'unknown provider' };

  const envKeys = {
    anthropic: 'ANTHROPIC_API_KEY',
    openai: 'OPENAI_API_KEY',
    google: 'GOOGLE_AI_API_KEY',
    groq: 'GROQ_API_KEY',
    perplexity: 'PERPLEXITY_API_KEY',
    cloudflare: 'CLOUDFLARE_API_TOKEN',
    local: null,
  };

  const envKey = envKeys[def.vendor];
  const hasKey = !envKey || !!process.env[envKey];

  return {
    provider,
    vendor: def.vendor,
    model: def.model,
    ok: hasKey,
    apiKeyConfigured: hasKey,
    supportsEmbeddings: def.supportsEmbeddings || false,
    checkedAt: new Date().toISOString(),
  };
}

// ─── LLMRouter class ─────────────────────────────────────────────────────────

class LLMRouter extends EventEmitter {
  constructor(opts = {}) {
    super();
    this.routingMatrix = Object.assign({}, ROUTING_MATRIX, opts.routingMatrix || {});
    this.providers = Object.assign({}, PROVIDERS, opts.providers || {});
    this.budget = getBudgetTracker(opts.budgetOpts);
    this._healthCache = new Map();
    this._healthCacheTTL = opts.healthCacheTTL || 60000; // 1 minute
  }

  // ─── Routing logic ─────────────────────────────────────────────────────────

  _getChain(taskType) {
    return this.routingMatrix[taskType] || this.routingMatrix.default;
  }

  _shouldSkipProvider(provider) {
    if (this.budget.isOverBudget(provider)) {
      this.emit('provider-skipped', { provider, reason: 'over-budget' });
      return true;
    }
    return false;
  }

  _shouldDowngrade(provider) {
    return this.budget.isNearBudget(provider) || this.budget.isMonthlyNearBudget();
  }

  _estimateCost(provider, inputTokens, outputTokens) {
    const def = this.providers[provider];
    if (!def) return 0;
    return ((inputTokens + outputTokens) / 1000) * def.costPer1kTokens;
  }

  async _callWithRetry(provider, prompt, opts, retries = 0) {
    try {
      const result = await callProvider(provider, prompt, opts);
      const totalTokens = (result.tokens.input || 0) + (result.tokens.output || 0);
      const cost = this._estimateCost(provider, result.tokens.input || 0, result.tokens.output || 0);
      this.budget.trackUsage(provider, totalTokens, cost, { taskType: opts.taskType });
      this.emit('success', { provider, totalTokens, cost, taskType: opts.taskType });
      return result;
    } catch (err) {
      const isRateLimit = /rate.?limit|429|quota/i.test(err.message || '');
      if (isRateLimit && retries < RATE_LIMIT_RETRY_COUNT) {
        this.emit('rate-limit-retry', { provider, attempt: retries + 1 });
        await new Promise(r => setTimeout(r, RATE_LIMIT_RETRY_DELAY_MS * (retries + 1)));
        return this._callWithRetry(provider, prompt, opts, retries + 1);
      }
      throw err;
    }
  }

  /**
   * Generate a response, routing through the appropriate chain for taskType.
   *
   * @param {string} prompt
   * @param {object} opts
   * @param {string} [opts.taskType]  — key into routing matrix
   * @param {boolean} [opts.stream]   — streaming (not yet implemented)
   * @param {string} [opts.systemPrompt]
   * @param {number} [opts.maxTokens]
   * @param {number} [opts.temperature]
   * @returns {Promise<{text, provider, model, tokens, taskType, chain}>}
   */
  async generate(prompt, opts = {}) {
    const taskType = opts.taskType || 'default';
    const chain = this._getChain(taskType);
    const errors = [];

    for (const provider of chain) {
      if (this._shouldSkipProvider(provider)) continue;

      try {
        const result = await this._callWithRetry(provider, prompt, { ...opts, taskType });
        return { ...result, taskType, chain, attemptedProviders: errors.map(e => e.provider) };
      } catch (err) {
        errors.push({ provider, error: err.message });
        this.emit('provider-failed', { provider, taskType, error: err.message });
        // Self-healing: mark provider degraded for a short period
        this._markDegraded(provider);
      }
    }

    // All providers failed — self-healing event
    const aggregatedError = new Error(
      `All providers failed for task type "${taskType}": ${errors.map(e => `${e.provider}(${e.error})`).join(', ')}`
    );
    this.emit('all-failed', { taskType, chain, errors });
    throw aggregatedError;
  }

  /**
   * Generate embeddings via the embeddings chain.
   */
  async embed(text, opts = {}) {
    const chain = this.routingMatrix.embeddings;
    const errors = [];

    for (const provider of chain) {
      if (this._shouldSkipProvider(provider)) continue;

      try {
        const result = await callEmbeddingProvider(provider, text);
        const cost = this._estimateCost(provider, result.tokens || 0, 0);
        this.budget.trackUsage(provider, result.tokens || 0, cost, { taskType: 'embeddings' });
        this.emit('embed-success', { provider });
        return result;
      } catch (err) {
        errors.push({ provider, error: err.message });
        this.emit('provider-failed', { provider, taskType: 'embeddings', error: err.message });
        this._markDegraded(provider);
      }
    }

    throw new Error(`All embedding providers failed: ${errors.map(e => `${e.provider}(${e.error})`).join(', ')}`);
  }

  // ─── Degradation tracking ──────────────────────────────────────────────────

  _markDegraded(provider, durationMs = 30000) {
    this._degraded = this._degraded || new Map();
    this._degraded.set(provider, Date.now() + durationMs);
    this.emit('provider-degraded', { provider, until: new Date(Date.now() + durationMs).toISOString() });
    setTimeout(() => {
      if (this._degraded) this._degraded.delete(provider);
      this.emit('provider-recovered', { provider });
    }, durationMs).unref?.();
  }

  isDegraded(provider) {
    if (!this._degraded) return false;
    const until = this._degraded.get(provider);
    return until && until > Date.now();
  }

  // ─── Health ────────────────────────────────────────────────────────────────

  async health() {
    const now = Date.now();
    const results = {};

    for (const provider of Object.keys(this.providers)) {
      const cached = this._healthCache.get(provider);
      if (cached && now - cached.ts < this._healthCacheTTL) {
        results[provider] = cached.data;
        continue;
      }
      const data = await checkProviderHealth(provider);
      data.degraded = this.isDegraded(provider);
      data.overBudget = this.budget.isOverBudget(provider);
      data.nearBudget = this.budget.isNearBudget(provider);
      this._healthCache.set(provider, { ts: now, data });
      results[provider] = data;
    }

    const budget = this.budget.getBudgetStatus();
    return { providers: results, budget, checkedAt: new Date().toISOString() };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** POST /api/llm/generate */
    app.post('/api/llm/generate', async (req, res) => {
      try {
        const { prompt, taskType, systemPrompt, maxTokens, temperature, stream } = req.body || {};
        if (!prompt) return res.status(400).json({ ok: false, error: 'prompt is required' });
        const result = await this.generate(prompt, { taskType, systemPrompt, maxTokens, temperature, stream });
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/llm/embed */
    app.post('/api/llm/embed', async (req, res) => {
      try {
        const { text } = req.body || {};
        if (!text) return res.status(400).json({ ok: false, error: 'text is required' });
        const result = await this.embed(text);
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/llm/health */
    app.get('/api/llm/health', async (req, res) => {
      try {
        const data = await this.health();
        res.json({ ok: true, ...data });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/llm/routing-matrix */
    app.get('/api/llm/routing-matrix', (req, res) => {
      res.json({
        ok: true,
        routingMatrix: this.routingMatrix,
        providers: Object.fromEntries(
          Object.entries(this.providers).map(([k, v]) => [k, {
            id: v.id,
            vendor: v.vendor,
            model: v.model,
            costPer1kTokens: v.costPer1kTokens,
            supportsEmbeddings: v.supportsEmbeddings || false,
          }])
        ),
      });
    });

    /** POST /api/llm/routing-matrix — update matrix at runtime */
    app.post('/api/llm/routing-matrix', (req, res) => {
      try {
        const { taskType, chain } = req.body || {};
        if (!taskType || !Array.isArray(chain)) {
          return res.status(400).json({ ok: false, error: 'taskType (string) and chain (array) required' });
        }
        this.routingMatrix[taskType] = chain;
        this.emit('matrix-updated', { taskType, chain });
        res.json({ ok: true, routingMatrix: this.routingMatrix });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    return app;
  }
}

// ─── Singleton ───────────────────────────────────────────────────────────────

let _instance = null;
function getLLMRouter(opts) {
  if (!_instance) _instance = new LLMRouter(opts);
  return _instance;
}

module.exports = { LLMRouter, getLLMRouter, PROVIDERS, ROUTING_MATRIX };
