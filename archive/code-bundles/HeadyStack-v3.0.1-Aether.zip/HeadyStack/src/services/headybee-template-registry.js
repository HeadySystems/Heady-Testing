'use strict';

/**
 * HeadybeeTemplateRegistry — Manages Headybee (AI agent/worker bee) templates.
 * Templates define agent behavior, capabilities, prompts, and execution configs.
 */

const EventEmitter = require('events');
const crypto = require('crypto');

const TEMPLATE_CATEGORIES = {
  RESEARCHER: 'researcher',
  CODER: 'coder',
  REVIEWER: 'reviewer',
  WRITER: 'writer',
  ANALYST: 'analyst',
  ORCHESTRATOR: 'orchestrator',
  MONITOR: 'monitor',
  EMBEDDER: 'embedder',
  CLASSIFIER: 'classifier',
  CUSTOM: 'custom',
};

const BUILTIN_TEMPLATES = [
  {
    id: 'bee-researcher-v1',
    name: 'Research Bee',
    category: TEMPLATE_CATEGORIES.RESEARCHER,
    version: '1.0.0',
    description: 'Performs deep web research and synthesizes findings',
    systemPrompt: 'You are a research specialist. Gather comprehensive information on the given topic, cite sources, and synthesize findings into a clear structured report.',
    taskType: 'research',
    maxTokens: 4096,
    tools: ['web_search', 'document_reader', 'citation_builder'],
    inputs: [{ name: 'topic', type: 'string', required: true }, { name: 'depth', type: 'number', default: 3 }],
    outputs: [{ name: 'report', type: 'string' }, { name: 'sources', type: 'array' }],
  },
  {
    id: 'bee-coder-v1',
    name: 'Coder Bee',
    category: TEMPLATE_CATEGORIES.CODER,
    version: '1.0.0',
    description: 'Writes and refactors code based on specifications',
    systemPrompt: 'You are an expert software engineer. Write clean, well-documented, production-ready code. Follow best practices and include error handling.',
    taskType: 'code_generation',
    maxTokens: 8192,
    tools: ['code_executor', 'file_writer', 'linter'],
    inputs: [{ name: 'spec', type: 'string', required: true }, { name: 'language', type: 'string', default: 'javascript' }],
    outputs: [{ name: 'code', type: 'string' }, { name: 'tests', type: 'string' }],
  },
  {
    id: 'bee-reviewer-v1',
    name: 'Review Bee',
    category: TEMPLATE_CATEGORIES.REVIEWER,
    version: '1.0.0',
    description: 'Reviews code, documents, and provides structured feedback',
    systemPrompt: 'You are a thorough code reviewer. Identify bugs, security issues, performance problems, and style violations. Provide specific, actionable feedback.',
    taskType: 'code_review',
    maxTokens: 4096,
    tools: ['static_analyzer', 'security_scanner'],
    inputs: [{ name: 'content', type: 'string', required: true }, { name: 'type', type: 'string', default: 'code' }],
    outputs: [{ name: 'feedback', type: 'array' }, { name: 'score', type: 'number' }],
  },
  {
    id: 'bee-embedder-v1',
    name: 'Embedder Bee',
    category: TEMPLATE_CATEGORIES.EMBEDDER,
    version: '1.0.0',
    description: 'Generates and stores vector embeddings for text chunks',
    systemPrompt: '',
    taskType: 'embeddings',
    maxTokens: 512,
    tools: ['vector_store'],
    inputs: [{ name: 'text', type: 'string', required: true }, { name: 'namespace', type: 'string', default: 'default' }],
    outputs: [{ name: 'vectorId', type: 'string' }, { name: 'dims', type: 'number' }],
  },
  {
    id: 'bee-orchestrator-v1',
    name: 'Orchestrator Bee',
    category: TEMPLATE_CATEGORIES.ORCHESTRATOR,
    version: '1.0.0',
    description: 'Decomposes complex tasks and coordinates other bees',
    systemPrompt: 'You are a task orchestrator. Break down complex goals into atomic subtasks, assign them to appropriate specialists, and synthesize results.',
    taskType: 'architecture',
    maxTokens: 4096,
    tools: ['task_spawner', 'bee_registry', 'result_aggregator'],
    inputs: [{ name: 'goal', type: 'string', required: true }],
    outputs: [{ name: 'plan', type: 'object' }, { name: 'results', type: 'array' }],
  },
];

class HeadybeeTemplateRegistry extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._templates = new Map();
    this._versions = new Map();  // id → [versions]

    if (opts.loadBuiltins !== false) {
      for (const t of BUILTIN_TEMPLATES) this.register(t);
    }
  }

  // ─── CRUD ──────────────────────────────────────────────────────────────────

  register(template) {
    if (!template.id) template.id = 'bee_' + crypto.randomBytes(6).toString('hex');
    const existing = this._templates.get(template.id);
    const record = {
      ...template,
      registeredAt: existing ? existing.registeredAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      usageCount: existing ? existing.usageCount : 0,
      enabled: template.enabled !== false,
    };
    this._templates.set(template.id, record);

    // Version history
    if (!this._versions.has(template.id)) this._versions.set(template.id, []);
    this._versions.get(template.id).push({ version: template.version || '1.0.0', registeredAt: record.updatedAt });

    this.emit('template-registered', { id: template.id, name: template.name });
    return template.id;
  }

  update(id, updates) {
    const template = this._templates.get(id);
    if (!template) throw new Error(`Template not found: ${id}`);
    const updated = { ...template, ...updates, id, updatedAt: new Date().toISOString() };
    this._templates.set(id, updated);
    this.emit('template-updated', { id });
    return updated;
  }

  unregister(id) {
    const existed = this._templates.delete(id);
    if (existed) this.emit('template-unregistered', { id });
    return existed;
  }

  get(id) {
    return this._templates.get(id) || null;
  }

  list(opts = {}) {
    let templates = Array.from(this._templates.values());
    if (opts.category) templates = templates.filter(t => t.category === opts.category);
    if (opts.enabled !== undefined) templates = templates.filter(t => t.enabled === opts.enabled);
    if (opts.search) {
      const q = opts.search.toLowerCase();
      templates = templates.filter(t => t.name.toLowerCase().includes(q) || t.description?.toLowerCase().includes(q));
    }
    return templates;
  }

  getVersionHistory(id) {
    return this._versions.get(id) || [];
  }

  // ─── Instantiation ─────────────────────────────────────────────────────────

  /**
   * Create a bee instance from a template, merging in runtime overrides.
   */
  instantiate(templateId, inputOverrides = {}, opts = {}) {
    const template = this._templates.get(templateId);
    if (!template) throw new Error(`Template not found: ${templateId}`);
    if (!template.enabled) throw new Error(`Template is disabled: ${templateId}`);

    // Validate required inputs
    const errors = [];
    for (const input of (template.inputs || [])) {
      if (input.required && !(input.name in inputOverrides)) {
        errors.push(`Missing required input: ${input.name}`);
      }
    }
    if (errors.length > 0) throw new Error(errors.join(', '));

    // Merge defaults
    const inputs = {};
    for (const input of (template.inputs || [])) {
      inputs[input.name] = input.name in inputOverrides ? inputOverrides[input.name] : input.default;
    }

    const instance = {
      instanceId: 'bee_inst_' + crypto.randomBytes(8).toString('hex'),
      templateId,
      templateName: template.name,
      category: template.category,
      systemPrompt: opts.systemPrompt || template.systemPrompt,
      taskType: template.taskType,
      maxTokens: opts.maxTokens || template.maxTokens,
      tools: template.tools || [],
      inputs,
      createdAt: new Date().toISOString(),
    };

    template.usageCount++;
    this.emit('template-instantiated', { templateId, instanceId: instance.instanceId });
    return instance;
  }

  getSummary() {
    const templates = this.list();
    const byCategory = {};
    for (const t of templates) {
      byCategory[t.category] = (byCategory[t.category] || 0) + 1;
    }
    return { total: templates.length, enabled: templates.filter(t => t.enabled).length, byCategory };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerHeadybeeTemplateRegistryRoutes(app) {
    /** GET /api/headybee/templates */
    app.get('/api/headybee/templates', (req, res) => {
      const { category, enabled, search } = req.query;
      res.json({
        ok: true,
        templates: this.list({ category, enabled: enabled === undefined ? undefined : enabled === 'true', search }),
        summary: this.getSummary(),
      });
    });

    /** GET /api/headybee/templates/:id */
    app.get('/api/headybee/templates/:id', (req, res) => {
      const template = this.get(req.params.id);
      if (!template) return res.status(404).json({ ok: false, error: 'Template not found' });
      res.json({ ok: true, template, versionHistory: this.getVersionHistory(req.params.id) });
    });

    /** POST /api/headybee/templates */
    app.post('/api/headybee/templates', (req, res) => {
      try {
        const id = this.register(req.body || {});
        res.status(201).json({ ok: true, id });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** PUT /api/headybee/templates/:id */
    app.put('/api/headybee/templates/:id', (req, res) => {
      try {
        const updated = this.update(req.params.id, req.body || {});
        res.json({ ok: true, template: updated });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** DELETE /api/headybee/templates/:id */
    app.delete('/api/headybee/templates/:id', (req, res) => {
      const removed = this.unregister(req.params.id);
      res.json({ ok: removed, id: req.params.id });
    });

    /** POST /api/headybee/templates/:id/instantiate */
    app.post('/api/headybee/templates/:id/instantiate', (req, res) => {
      try {
        const { inputs, systemPrompt, maxTokens } = req.body || {};
        const instance = this.instantiate(req.params.id, inputs || {}, { systemPrompt, maxTokens });
        res.json({ ok: true, instance });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/headybee/categories */
    app.get('/api/headybee/categories', (req, res) => {
      res.json({ ok: true, categories: Object.values(TEMPLATE_CATEGORIES) });
    });

    return app;
  }
}

let _instance = null;
function getHeadybeeTemplateRegistry(opts) {
  if (!_instance) _instance = new HeadybeeTemplateRegistry(opts);
  return _instance;
}

module.exports = { HeadybeeTemplateRegistry, getHeadybeeTemplateRegistry, TEMPLATE_CATEGORIES, BUILTIN_TEMPLATES };
