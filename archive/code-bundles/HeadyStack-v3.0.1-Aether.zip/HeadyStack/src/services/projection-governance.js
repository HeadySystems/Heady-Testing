'use strict';

/**
 * ProjectionGovernance — Validates projections against governance rules
 * before they are applied. Enforces path restrictions, file size limits,
 * forbidden patterns, and approval workflows.
 */

const EventEmitter = require('events');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const RULE_TYPES = {
  PATH_WHITELIST: 'path_whitelist',
  PATH_BLACKLIST: 'path_blacklist',
  FILE_SIZE_LIMIT: 'file_size_limit',
  FORBIDDEN_PATTERN: 'forbidden_pattern',
  REQUIRED_REVIEW: 'required_review',
  CHECKSUM_VERIFY: 'checksum_verify',
  EXTENSION_WHITELIST: 'extension_whitelist',
  RATE_LIMIT: 'rate_limit',
};

const VERDICT = {
  ALLOW: 'allow',
  DENY: 'deny',
  REQUIRE_APPROVAL: 'require_approval',
};

class ProjectionGovernance extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._rules = new Map();       // ruleId → Rule
    this._approvals = new Map();   // requestId → ApprovalRequest
    this._auditLog = [];
    this._maxAuditLog = opts.maxAuditLog || 1000;
    this._rateWindows = new Map(); // projectionId → [timestamps]

    // Register default rules
    if (opts.defaultRules !== false) this._registerDefaultRules();
  }

  // ─── Default rules ─────────────────────────────────────────────────────────

  _registerDefaultRules() {
    this.addRule({
      id: 'default-size-limit',
      type: RULE_TYPES.FILE_SIZE_LIMIT,
      name: 'Default file size limit (10MB)',
      maxBytes: 10 * 1024 * 1024,
      severity: 'deny',
    });

    this.addRule({
      id: 'no-secrets',
      type: RULE_TYPES.FORBIDDEN_PATTERN,
      name: 'No secrets in projected files',
      patterns: [
        /(?:password|passwd|secret|api_key|apikey|private_key)\s*=\s*['"][^'"]{8,}/i,
        /-----BEGIN\s+(RSA|EC|OPENSSH)\s+PRIVATE KEY-----/,
        /AWS_SECRET_ACCESS_KEY\s*=\s*[A-Za-z0-9\/+=]{20,}/,
      ],
      severity: 'deny',
    });

    this.addRule({
      id: 'no-node-modules',
      type: RULE_TYPES.PATH_BLACKLIST,
      name: 'Block node_modules projection',
      paths: ['node_modules', '.git', '.env', 'dist', 'build'],
      severity: 'deny',
    });
  }

  // ─── Rule management ───────────────────────────────────────────────────────

  addRule(rule) {
    if (!rule.id) rule.id = 'rule_' + crypto.randomBytes(6).toString('hex');
    this._rules.set(rule.id, { ...rule, createdAt: new Date().toISOString() });
    this.emit('rule-added', { id: rule.id, name: rule.name });
    return rule.id;
  }

  removeRule(ruleId) {
    const existed = this._rules.delete(ruleId);
    if (existed) this.emit('rule-removed', { id: ruleId });
    return existed;
  }

  listRules() {
    return Array.from(this._rules.values());
  }

  // ─── Validation ────────────────────────────────────────────────────────────

  /**
   * Validate a projection before applying.
   * @param {object} projection — from ProjectionEngine
   * @param {object[]} files — [{source, target, action, relPath}]
   * @returns {Promise<{verdict, violations, approvalRequired, requestId}>}
   */
  async validate(projection, files = []) {
    const violations = [];
    let approvalRequired = false;

    for (const rule of this._rules.values()) {
      for (const file of files) {
        const v = await this._applyRule(rule, file, projection);
        if (v) violations.push(v);
        if (v && v.severity === 'require_approval') approvalRequired = true;
      }

      // Rate limit check (projection-level)
      if (rule.type === RULE_TYPES.RATE_LIMIT) {
        const rateViolation = this._checkRateLimit(rule, projection.id);
        if (rateViolation) violations.push(rateViolation);
      }
    }

    const denyViolations = violations.filter(v => v.severity === 'deny');
    let verdict = VERDICT.ALLOW;
    if (denyViolations.length > 0) verdict = VERDICT.DENY;
    else if (approvalRequired) verdict = VERDICT.REQUIRE_APPROVAL;

    let requestId = null;
    if (verdict === VERDICT.REQUIRE_APPROVAL) {
      requestId = this._createApprovalRequest(projection, files, violations);
    }

    const entry = {
      projectionId: projection.id,
      verdict,
      violations: violations.length,
      ts: new Date().toISOString(),
    };
    this._auditLog.push(entry);
    if (this._auditLog.length > this._maxAuditLog) this._auditLog.shift();

    this.emit('validation-complete', { projectionId: projection.id, verdict, violations });

    return { verdict, violations, approvalRequired, requestId };
  }

  async _applyRule(rule, file, projection) {
    try {
      switch (rule.type) {
        case RULE_TYPES.PATH_BLACKLIST: {
          const blocked = (rule.paths || []).some(p => file.relPath.includes(p) || file.source.includes(p));
          if (blocked) return { rule: rule.id, name: rule.name, file: file.relPath, severity: rule.severity || 'deny', reason: 'Path is blacklisted' };
          break;
        }

        case RULE_TYPES.PATH_WHITELIST: {
          const allowed = (rule.paths || []).some(p => file.relPath.startsWith(p));
          if (!allowed) return { rule: rule.id, name: rule.name, file: file.relPath, severity: rule.severity || 'deny', reason: 'Path not in whitelist' };
          break;
        }

        case RULE_TYPES.FILE_SIZE_LIMIT: {
          if (fs.existsSync(file.source)) {
            const stat = fs.statSync(file.source);
            if (stat.size > rule.maxBytes) {
              return { rule: rule.id, name: rule.name, file: file.relPath, severity: rule.severity || 'deny', reason: `File too large: ${stat.size} > ${rule.maxBytes}` };
            }
          }
          break;
        }

        case RULE_TYPES.FORBIDDEN_PATTERN: {
          if (fs.existsSync(file.source)) {
            const content = fs.readFileSync(file.source, 'utf8');
            for (const pattern of (rule.patterns || [])) {
              const re = pattern instanceof RegExp ? pattern : new RegExp(pattern, 'gi');
              if (re.test(content)) {
                return { rule: rule.id, name: rule.name, file: file.relPath, severity: rule.severity || 'deny', reason: `Forbidden pattern found: ${pattern}` };
              }
            }
          }
          break;
        }

        case RULE_TYPES.EXTENSION_WHITELIST: {
          const ext = path.extname(file.relPath).toLowerCase();
          if (rule.extensions && !rule.extensions.includes(ext)) {
            return { rule: rule.id, name: rule.name, file: file.relPath, severity: rule.severity || 'deny', reason: `Extension not allowed: ${ext}` };
          }
          break;
        }

        case RULE_TYPES.REQUIRED_REVIEW: {
          if ((rule.paths || []).some(p => file.relPath.startsWith(p))) {
            return { rule: rule.id, name: rule.name, file: file.relPath, severity: 'require_approval', reason: 'File requires manual review' };
          }
          break;
        }
      }
    } catch (err) {
      return { rule: rule.id, name: rule.name, file: file.relPath, severity: 'warn', reason: `Rule check error: ${err.message}` };
    }
    return null;
  }

  _checkRateLimit(rule, projectionId) {
    const key = `${projectionId}:${rule.id}`;
    const now = Date.now();
    const window = rule.windowMs || 60000;
    const max = rule.maxSyncs || 10;

    let timestamps = this._rateWindows.get(key) || [];
    timestamps = timestamps.filter(t => now - t < window);
    timestamps.push(now);
    this._rateWindows.set(key, timestamps);

    if (timestamps.length > max) {
      return { rule: rule.id, name: rule.name, severity: 'deny', reason: `Rate limit exceeded: ${timestamps.length}/${max} syncs in ${window}ms` };
    }
    return null;
  }

  // ─── Approval workflow ─────────────────────────────────────────────────────

  _createApprovalRequest(projection, files, violations) {
    const requestId = 'apr_' + crypto.randomBytes(8).toString('hex');
    this._approvals.set(requestId, {
      id: requestId,
      projectionId: projection.id,
      projectionName: projection.name,
      files: files.length,
      violations,
      status: 'pending',
      createdAt: new Date().toISOString(),
      resolvedAt: null,
      resolvedBy: null,
    });
    this.emit('approval-requested', { requestId, projectionId: projection.id });
    return requestId;
  }

  approveRequest(requestId, approver = 'system') {
    const req = this._approvals.get(requestId);
    if (!req) throw new Error(`Approval request not found: ${requestId}`);
    req.status = 'approved';
    req.resolvedAt = new Date().toISOString();
    req.resolvedBy = approver;
    this.emit('approved', { requestId, approver });
    return req;
  }

  denyRequest(requestId, approver = 'system', reason = '') {
    const req = this._approvals.get(requestId);
    if (!req) throw new Error(`Approval request not found: ${requestId}`);
    req.status = 'denied';
    req.resolvedAt = new Date().toISOString();
    req.resolvedBy = approver;
    req.denyReason = reason;
    this.emit('denied', { requestId, approver, reason });
    return req;
  }

  getPendingApprovals() {
    return Array.from(this._approvals.values()).filter(a => a.status === 'pending');
  }

  getAuditLog(limit = 100) {
    return this._auditLog.slice(-limit);
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** GET /api/governance/rules */
    app.get('/api/governance/rules', (req, res) => {
      res.json({ ok: true, rules: this.listRules() });
    });

    /** POST /api/governance/rules */
    app.post('/api/governance/rules', (req, res) => {
      try {
        const id = this.addRule(req.body || {});
        res.status(201).json({ ok: true, id });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** DELETE /api/governance/rules/:id */
    app.delete('/api/governance/rules/:id', (req, res) => {
      const removed = this.removeRule(req.params.id);
      res.json({ ok: removed, removed: req.params.id });
    });

    /** POST /api/governance/validate */
    app.post('/api/governance/validate', async (req, res) => {
      try {
        const { projection, files } = req.body || {};
        if (!projection) return res.status(400).json({ ok: false, error: 'projection required' });
        const result = await this.validate(projection, files || []);
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/governance/approvals */
    app.get('/api/governance/approvals', (req, res) => {
      const { status } = req.query;
      let approvals = Array.from(this._approvals.values());
      if (status) approvals = approvals.filter(a => a.status === status);
      res.json({ ok: true, approvals });
    });

    /** POST /api/governance/approvals/:id/approve */
    app.post('/api/governance/approvals/:id/approve', (req, res) => {
      try {
        const { approver } = req.body || {};
        const result = this.approveRequest(req.params.id, approver);
        res.json({ ok: true, approval: result });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/governance/approvals/:id/deny */
    app.post('/api/governance/approvals/:id/deny', (req, res) => {
      try {
        const { approver, reason } = req.body || {};
        const result = this.denyRequest(req.params.id, approver, reason);
        res.json({ ok: true, approval: result });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/governance/audit */
    app.get('/api/governance/audit', (req, res) => {
      const limit = parseInt(req.query.limit) || 100;
      res.json({ ok: true, auditLog: this.getAuditLog(limit) });
    });

    return app;
  }
}

let _instance = null;
function getGovernance(opts) {
  if (!_instance) _instance = new ProjectionGovernance(opts);
  return _instance;
}

module.exports = { ProjectionGovernance, getGovernance, RULE_TYPES, VERDICT };
