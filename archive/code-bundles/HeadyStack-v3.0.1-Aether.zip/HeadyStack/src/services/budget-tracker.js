'use strict';

/**
 * BudgetTracker — LLM cost tracking and budget enforcement
 * Tracks per-provider daily usage, global monthly caps, and auto-downgrade signals.
 */

const EventEmitter = require('events');

const DEFAULT_DAILY_CAPS = {
  'claude-3-5-sonnet': 20.00,
  'claude-3-opus': 30.00,
  'gpt-4o': 25.00,
  'gpt-4o-mini': 5.00,
  'gemini-pro': 10.00,
  'gemini-flash': 3.00,
  'groq-llama': 5.00,
  'perplexity-sonar': 10.00,
  'cloudflare-edge': 2.00,
  'openai-ada': 2.00,
  'local': 0.00,
};

const DEFAULT_MONTHLY_CAP = 500.00;
const NEAR_BUDGET_THRESHOLD = 0.80; // 80% consumed triggers "near budget"

class BudgetTracker extends EventEmitter {
  constructor(opts = {}) {
    super();
    this.dailyCaps = Object.assign({}, DEFAULT_DAILY_CAPS, opts.dailyCaps || {});
    this.monthlyCap = opts.monthlyCap || DEFAULT_MONTHLY_CAP;
    this.nearBudgetThreshold = opts.nearBudgetThreshold || NEAR_BUDGET_THRESHOLD;

    // Storage: keyed by "YYYY-MM-DD:provider"
    this._usage = new Map();
    // Monthly totals keyed by "YYYY-MM"
    this._monthly = new Map();

    this._startPruneLoop();
  }

  // ─── Internal helpers ────────────────────────────────────────────────────────

  _todayKey(provider) {
    return `${this._today()}:${provider}`;
  }

  _today() {
    return new Date().toISOString().slice(0, 10);
  }

  _monthKey() {
    return new Date().toISOString().slice(0, 7);
  }

  _ensureDay(provider) {
    const key = this._todayKey(provider);
    if (!this._usage.has(key)) {
      this._usage.set(key, { tokens: 0, cost: 0, requests: 0 });
    }
    return this._usage.get(key);
  }

  _ensureMonth() {
    const key = this._monthKey();
    if (!this._monthly.has(key)) {
      this._monthly.set(key, { cost: 0, tokens: 0 });
    }
    return this._monthly.get(key);
  }

  /** Prune usage entries older than 35 days every hour */
  _startPruneLoop() {
    this._pruneTimer = setInterval(() => {
      const cutoff = new Date(Date.now() - 35 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
      for (const key of this._usage.keys()) {
        const date = key.split(':')[0];
        if (date < cutoff) this._usage.delete(key);
      }
    }, 60 * 60 * 1000);
    if (this._pruneTimer.unref) this._pruneTimer.unref();
  }

  // ─── Public API ──────────────────────────────────────────────────────────────

  /**
   * Record token usage and cost for a provider.
   * @param {string} provider
   * @param {number} tokens
   * @param {number} cost  — USD
   * @param {object} [meta]  — optional extra metadata
   */
  trackUsage(provider, tokens, cost, meta = {}) {
    tokens = Number(tokens) || 0;
    cost = Number(cost) || 0;

    const day = this._ensureDay(provider);
    day.tokens += tokens;
    day.cost += cost;
    day.requests += 1;
    day.lastUsed = new Date().toISOString();
    if (meta.model) day.model = meta.model;
    if (meta.taskType) day.lastTaskType = meta.taskType;

    const month = this._ensureMonth();
    month.cost += cost;
    month.tokens += tokens;

    this.emit('usage', { provider, tokens, cost, day, month, meta });

    if (this.isOverBudget(provider)) {
      this.emit('over-budget', { provider, day, cap: this.dailyCaps[provider] });
    } else if (this.isNearBudget(provider)) {
      this.emit('near-budget', { provider, day, cap: this.dailyCaps[provider] });
    }

    if (this.isMonthlyOverBudget()) {
      this.emit('monthly-over-budget', { month, cap: this.monthlyCap });
    } else if (this.isMonthlyNearBudget()) {
      this.emit('monthly-near-budget', { month, cap: this.monthlyCap });
    }

    return { day, month };
  }

  /**
   * Get today's usage for a provider.
   */
  getDailyUsage(provider) {
    const key = this._todayKey(provider);
    return this._usage.get(key) || { tokens: 0, cost: 0, requests: 0 };
  }

  /**
   * Get all providers' usage for today.
   */
  getAllDailyUsage() {
    const today = this._today();
    const result = {};
    for (const [key, val] of this._usage.entries()) {
      const [date, provider] = key.split(/:(.+)/); // split on first colon only
      if (date === today) result[provider] = val;
    }
    return result;
  }

  /**
   * Get this month's total spend.
   */
  getMonthlyTotal() {
    return this._ensureMonth();
  }

  /**
   * True if a provider has exceeded its daily cap.
   */
  isOverBudget(provider) {
    const cap = this.dailyCaps[provider];
    if (cap == null) return false;
    const usage = this.getDailyUsage(provider);
    return usage.cost >= cap;
  }

  /**
   * True if a provider is within nearBudgetThreshold of its cap.
   */
  isNearBudget(provider) {
    const cap = this.dailyCaps[provider];
    if (cap == null) return false;
    const usage = this.getDailyUsage(provider);
    return usage.cost >= cap * this.nearBudgetThreshold;
  }

  isMonthlyOverBudget() {
    return this.getMonthlyTotal().cost >= this.monthlyCap;
  }

  isMonthlyNearBudget() {
    return this.getMonthlyTotal().cost >= this.monthlyCap * this.nearBudgetThreshold;
  }

  /**
   * Get budget status summary for all providers.
   */
  getBudgetStatus() {
    const today = this._today();
    const month = this._monthKey();
    const monthData = this._monthly.get(month) || { cost: 0, tokens: 0 };

    const providers = {};
    for (const provider of Object.keys(this.dailyCaps)) {
      const usage = this.getDailyUsage(provider);
      const cap = this.dailyCaps[provider];
      providers[provider] = {
        usage,
        cap,
        percentUsed: cap > 0 ? (usage.cost / cap * 100).toFixed(1) : '0.0',
        overBudget: this.isOverBudget(provider),
        nearBudget: this.isNearBudget(provider),
        remaining: Math.max(0, cap - usage.cost),
      };
    }

    return {
      date: today,
      providers,
      monthly: {
        total: monthData.cost,
        cap: this.monthlyCap,
        percentUsed: (monthData.cost / this.monthlyCap * 100).toFixed(1),
        remaining: Math.max(0, this.monthlyCap - monthData.cost),
        overBudget: this.isMonthlyOverBudget(),
        nearBudget: this.isMonthlyNearBudget(),
      },
    };
  }

  /**
   * Update the daily cap for a provider.
   */
  setDailyCap(provider, amount) {
    this.dailyCaps[provider] = amount;
    this.emit('cap-updated', { provider, amount, type: 'daily' });
  }

  /**
   * Update the global monthly cap.
   */
  setMonthlyCap(amount) {
    this.monthlyCap = amount;
    this.emit('cap-updated', { amount, type: 'monthly' });
  }

  // ─── Express routes ──────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** GET /api/budget/usage — daily usage for all providers */
    app.get('/api/budget/usage', (req, res) => {
      try {
        const all = this.getAllDailyUsage();
        const monthly = this.getMonthlyTotal();
        res.json({ ok: true, daily: all, monthly });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/budget/status — full budget status with caps */
    app.get('/api/budget/status', (req, res) => {
      try {
        res.json({ ok: true, status: this.getBudgetStatus() });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/budget/limits — current caps */
    app.get('/api/budget/limits', (req, res) => {
      res.json({
        ok: true,
        dailyCaps: this.dailyCaps,
        monthlyCap: this.monthlyCap,
        nearBudgetThreshold: this.nearBudgetThreshold,
      });
    });

    /** PUT /api/budget/limits — update caps */
    app.put('/api/budget/limits', (req, res) => {
      try {
        const { dailyCaps, monthlyCap } = req.body || {};
        if (dailyCaps && typeof dailyCaps === 'object') {
          for (const [p, v] of Object.entries(dailyCaps)) {
            this.setDailyCap(p, Number(v));
          }
        }
        if (monthlyCap != null) this.setMonthlyCap(Number(monthlyCap));
        res.json({ ok: true, message: 'Caps updated', dailyCaps: this.dailyCaps, monthlyCap: this.monthlyCap });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/budget/track — manual usage entry (for external callers) */
    app.post('/api/budget/track', (req, res) => {
      try {
        const { provider, tokens, cost, meta } = req.body || {};
        if (!provider) return res.status(400).json({ ok: false, error: 'provider required' });
        const result = this.trackUsage(provider, tokens, cost, meta);
        res.json({ ok: true, result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    return app;
  }
}

// Singleton
let _instance = null;
function getBudgetTracker(opts) {
  if (!_instance) _instance = new BudgetTracker(opts);
  return _instance;
}

module.exports = { BudgetTracker, getBudgetTracker };
