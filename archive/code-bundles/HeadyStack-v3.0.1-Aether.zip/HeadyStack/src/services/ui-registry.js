'use strict';

/**
 * UIRegistry — Registers and manages HeadyWeb shell apps.
 * Tracks app metadata, health, active instances, and asset manifests.
 */

const EventEmitter = require('events');
const crypto = require('crypto');

const BUILTIN_APPS = [
  {
    id: 'antigravity',
    name: 'Antigravity Shell',
    description: 'Primary HeadyWeb shell application',
    path: '/apps/antigravity',
    port: 3001,
    entry: 'index.html',
    tags: ['shell', 'primary'],
  },
  {
    id: 'landing',
    name: 'Landing Page',
    description: 'Public-facing marketing and landing page',
    path: '/apps/landing',
    port: 3002,
    entry: 'index.html',
    tags: ['public', 'marketing'],
  },
  {
    id: 'heady-ide',
    name: 'Heady IDE',
    description: 'In-browser code editor and development environment',
    path: '/apps/heady-ide',
    port: 3003,
    entry: 'index.html',
    tags: ['dev', 'editor'],
  },
  {
    id: 'swarm-dashboard',
    name: 'Swarm Dashboard',
    description: 'Agent swarm monitoring and control dashboard',
    path: '/apps/swarm-dashboard',
    port: 3004,
    entry: 'index.html',
    tags: ['ops', 'monitoring'],
  },
  {
    id: 'governance-panel',
    name: 'Governance Panel',
    description: 'Projection governance and rule management UI',
    path: '/apps/governance-panel',
    port: 3005,
    entry: 'index.html',
    tags: ['governance', 'admin'],
  },
  {
    id: 'projection-monitor',
    name: 'Projection Monitor',
    description: 'Real-time projection sync status and diff viewer',
    path: '/apps/projection-monitor',
    port: 3006,
    entry: 'index.html',
    tags: ['ops', 'projections'],
  },
  {
    id: 'vector-explorer',
    name: 'Vector Explorer',
    description: 'Visual exploration of vector memory embeddings',
    path: '/apps/vector-explorer',
    port: 3007,
    entry: 'index.html',
    tags: ['ai', 'vectors'],
  },
];

const APP_STATUS = {
  REGISTERED: 'registered',
  RUNNING: 'running',
  STOPPED: 'stopped',
  ERROR: 'error',
  BUILDING: 'building',
};

class UIRegistry extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._apps = new Map();
    this._manifests = new Map(); // appId → asset manifest

    if (opts.loadBuiltins !== false) {
      for (const app of BUILTIN_APPS) this.register(app);
    }
  }

  // ─── Registry ──────────────────────────────────────────────────────────────

  register(cfg) {
    if (!cfg.id) cfg.id = 'app_' + crypto.randomBytes(6).toString('hex');
    const record = {
      ...cfg,
      status: APP_STATUS.REGISTERED,
      registeredAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      pid: null,
      lastStarted: null,
      lastStopped: null,
      version: cfg.version || '0.0.0',
      buildHash: cfg.buildHash || null,
    };
    this._apps.set(cfg.id, record);
    this.emit('app-registered', { id: cfg.id, name: cfg.name });
    return cfg.id;
  }

  unregister(id) {
    const existed = this._apps.delete(id);
    this._manifests.delete(id);
    if (existed) this.emit('app-unregistered', { id });
    return existed;
  }

  getApp(id) {
    return this._apps.get(id) || null;
  }

  listApps(opts = {}) {
    let apps = Array.from(this._apps.values());
    if (opts.tag) apps = apps.filter(a => (a.tags || []).includes(opts.tag));
    if (opts.status) apps = apps.filter(a => a.status === opts.status);
    return apps;
  }

  // ─── Lifecycle ─────────────────────────────────────────────────────────────

  markRunning(id, pid = null) {
    const app = this._apps.get(id);
    if (!app) throw new Error(`App not found: ${id}`);
    app.status = APP_STATUS.RUNNING;
    app.pid = pid;
    app.lastStarted = new Date().toISOString();
    app.updatedAt = app.lastStarted;
    this.emit('app-running', { id, pid });
  }

  markStopped(id) {
    const app = this._apps.get(id);
    if (!app) return;
    app.status = APP_STATUS.STOPPED;
    app.pid = null;
    app.lastStopped = new Date().toISOString();
    app.updatedAt = app.lastStopped;
    this.emit('app-stopped', { id });
  }

  markError(id, error) {
    const app = this._apps.get(id);
    if (!app) return;
    app.status = APP_STATUS.ERROR;
    app.lastError = error;
    app.updatedAt = new Date().toISOString();
    this.emit('app-error', { id, error });
  }

  // ─── Manifests ─────────────────────────────────────────────────────────────

  /**
   * Store an asset manifest for an app (e.g., from Vite/webpack build).
   */
  setManifest(appId, manifest) {
    this._manifests.set(appId, { ...manifest, updatedAt: new Date().toISOString() });
    const app = this._apps.get(appId);
    if (app && manifest.buildHash) {
      app.buildHash = manifest.buildHash;
      app.version = manifest.version || app.version;
    }
    this.emit('manifest-updated', { appId });
  }

  getManifest(appId) {
    return this._manifests.get(appId) || null;
  }

  // ─── Health ────────────────────────────────────────────────────────────────

  async healthCheck(id) {
    const app = this._apps.get(id);
    if (!app) return { id, ok: false, error: 'App not registered' };

    // Ping the app if it's running on a local port
    if (app.status === APP_STATUS.RUNNING && app.port) {
      try {
        const http = require('http');
        await new Promise((resolve, reject) => {
          const req = http.request({ hostname: 'localhost', port: app.port, path: '/', timeout: 2000 }, resolve);
          req.on('error', reject);
          req.end();
        });
        return { id, ok: true, status: app.status, port: app.port };
      } catch (e) {
        this.markError(id, e.message);
        return { id, ok: false, status: APP_STATUS.ERROR, error: e.message };
      }
    }

    return { id, ok: app.status === APP_STATUS.REGISTERED || app.status === APP_STATUS.STOPPED, status: app.status };
  }

  async healthCheckAll() {
    const results = [];
    for (const id of this._apps.keys()) {
      results.push(await this.healthCheck(id));
    }
    return results;
  }

  getSummary() {
    const apps = this.listApps();
    const byStatus = {};
    for (const a of apps) {
      byStatus[a.status] = (byStatus[a.status] || 0) + 1;
    }
    return { total: apps.length, byStatus };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** GET /api/ui/apps */
    app.get('/api/ui/apps', (req, res) => {
      const { tag, status } = req.query;
      res.json({ ok: true, apps: this.listApps({ tag, status }), summary: this.getSummary() });
    });

    /** GET /api/ui/apps/:id */
    app.get('/api/ui/apps/:id', (req, res) => {
      const appDef = this.getApp(req.params.id);
      if (!appDef) return res.status(404).json({ ok: false, error: 'App not found' });
      res.json({ ok: true, app: appDef, manifest: this.getManifest(req.params.id) });
    });

    /** POST /api/ui/apps — register a new UI app */
    app.post('/api/ui/apps', (req, res) => {
      try {
        const id = this.register(req.body || {});
        res.status(201).json({ ok: true, id });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** DELETE /api/ui/apps/:id */
    app.delete('/api/ui/apps/:id', (req, res) => {
      const removed = this.unregister(req.params.id);
      res.json({ ok: removed, id: req.params.id });
    });

    /** POST /api/ui/apps/:id/manifest */
    app.post('/api/ui/apps/:id/manifest', (req, res) => {
      try {
        this.setManifest(req.params.id, req.body || {});
        res.json({ ok: true });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/ui/apps/:id/health */
    app.get('/api/ui/apps/:id/health', async (req, res) => {
      const result = await this.healthCheck(req.params.id);
      res.json({ ok: result.ok, ...result });
    });

    /** GET /api/ui/health */
    app.get('/api/ui/health', async (req, res) => {
      const results = await this.healthCheckAll();
      res.json({ ok: true, results });
    });

    return app;
  }
}

let _instance = null;
function getUIRegistry(opts) {
  if (!_instance) _instance = new UIRegistry(opts);
  return _instance;
}

module.exports = { UIRegistry, getUIRegistry, APP_STATUS, BUILTIN_APPS };
