'use strict';

/**
 * DomainRouter — Routes incoming requests based on hostname to the correct
 * service handler. Supports all Heady-family domains.
 */

const DOMAIN_MAP = {
  'headyme.com':          { service: 'heady-me',          description: 'Personal AI companion' },
  'www.headyme.com':      { service: 'heady-me',          description: 'Personal AI companion' },
  'headysystems.com':     { service: 'heady-systems',     description: 'Enterprise AI systems' },
  'www.headysystems.com': { service: 'heady-systems',     description: 'Enterprise AI systems' },
  'headyconnection.org':  { service: 'heady-connection',  description: 'Community & org portal' },
  'www.headyconnection.org': { service: 'heady-connection', description: 'Community & org portal' },
  'headyai.org':          { service: 'heady-ai',          description: 'AI research & experiments' },
  'www.headyai.org':      { service: 'heady-ai',          description: 'AI research & experiments' },
  'headymcp.com':         { service: 'heady-mcp',         description: 'MCP server hub' },
  'www.headymcp.com':     { service: 'heady-mcp',         description: 'MCP server hub' },
  'headyapi.com':         { service: 'heady-api',         description: 'Public API gateway' },
  'www.headyapi.com':     { service: 'heady-api',         description: 'Public API gateway' },
  'headybuddy.com':       { service: 'heady-buddy',       description: 'Buddy companion service' },
  'www.headybuddy.com':   { service: 'heady-buddy',       description: 'Buddy companion service' },
  'headybot.com':         { service: 'heady-bot',         description: 'Bot platform' },
  'www.headybot.com':     { service: 'heady-bot',         description: 'Bot platform' },
  'headyio.com':          { service: 'heady-io',          description: 'IO data pipeline service' },
  'www.headyio.com':      { service: 'heady-io',          description: 'IO data pipeline service' },
};

// Per-service request handlers (can be overridden at runtime)
const _serviceHandlers = new Map();

// Fallback handler for unregistered services
function defaultHandler(service, req, res, next) {
  // Pass to next middleware — the service is identified but no special routing needed
  req.headyService = service;
  next();
}

/**
 * Register a handler function for a service name.
 * handler(req, res, next) — standard Express signature
 */
function registerServiceHandler(service, handler) {
  _serviceHandlers.set(service, handler);
}

/**
 * Express middleware that detects the Heady domain and annotates req.headyService.
 * Falls back to X-Heady-Service header, then query param, then 'default'.
 */
function domainMiddleware(req, res, next) {
  const hostname = req.hostname || req.headers.host || '';
  // Strip port if present
  const host = hostname.split(':')[0].toLowerCase();

  const entry = DOMAIN_MAP[host];
  if (entry) {
    req.headyDomain = host;
    req.headyService = entry.service;
  } else {
    // Allow override via header (useful for local dev / proxies)
    req.headyService = (req.headers['x-heady-service'] || req.query._headyService || 'default').toLowerCase();
  }

  const handler = _serviceHandlers.get(req.headyService);
  if (handler) {
    return handler(req, res, next);
  }
  return defaultHandler(req.headyService, req, res, next);
}

/**
 * Register routes on the Express app.
 */
function registerRoutes(app) {
  // Middleware applied globally
  app.use(domainMiddleware);

  /** GET /api/domains — list all configured domains */
  app.get('/api/domains', (req, res) => {
    res.json({
      ok: true,
      domains: Object.entries(DOMAIN_MAP).map(([host, cfg]) => ({
        host,
        service: cfg.service,
        description: cfg.description,
      })),
    });
  });

  /** GET /api/domains/current — which domain/service is this request */
  app.get('/api/domains/current', (req, res) => {
    res.json({
      ok: true,
      host: req.headyDomain || req.hostname,
      service: req.headyService || 'default',
    });
  });

  /** POST /api/domains/handler — register a handler for a service (dev use) */
  app.post('/api/domains/handler', (req, res) => {
    const { service } = req.body || {};
    if (!service) return res.status(400).json({ ok: false, error: 'service required' });
    // Actual handler registration is done programmatically; this endpoint just acknowledges
    res.json({ ok: true, message: `Handler registration acknowledged for service: ${service}` });
  });

  return app;
}

module.exports = { registerRoutes, domainMiddleware, registerServiceHandler, DOMAIN_MAP };
