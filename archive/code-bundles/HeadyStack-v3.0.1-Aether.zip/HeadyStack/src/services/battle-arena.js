'use strict';

/**
 * BattleArena — Arena battle execution engine.
 * Runs parallel model evaluations, judges results, and maintains leaderboards.
 */

const EventEmitter = require('events');
const crypto = require('crypto');

const SCORING_CRITERIA = {
  QUALITY: 'quality',
  SPEED: 'speed',
  COST: 'cost',
  ACCURACY: 'accuracy',
  COHERENCE: 'coherence',
};

class BattleArena extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._battles = new Map();
    this._leaderboard = new Map(); // model → { wins, losses, draws, totalScore, taskTypes: {} }
    this._judgeModel = opts.judgeModel || 'claude-3-5-sonnet';
    this._llmRouter = opts.llmRouter || null;
  }

  // ─── Battle execution ──────────────────────────────────────────────────────

  /**
   * Start a battle between contestants on a given task.
   * @param {string[]} contestants — array of provider/model IDs
   * @param {object} task — { prompt, taskType, systemPrompt, maxTokens, criteria }
   * @returns {Promise<BattleResult>}
   */
  async startBattle(contestants, task) {
    if (!Array.isArray(contestants) || contestants.length < 2) {
      throw new Error('At least 2 contestants required');
    }
    if (!task || !task.prompt) throw new Error('task.prompt required');

    const battleId = 'battle_' + crypto.randomBytes(8).toString('hex');
    const startedAt = new Date().toISOString();

    const battleRecord = {
      id: battleId,
      contestants,
      task: { ...task, prompt: task.prompt.slice(0, 500) }, // truncate for storage
      status: 'running',
      startedAt,
      completedAt: null,
      results: {},
      winner: null,
      scores: {},
      judgeRationale: null,
    };

    this._battles.set(battleId, battleRecord);
    this.emit('battle-started', { battleId, contestants, taskType: task.taskType });

    // Run all contestants in parallel
    const evaluations = await Promise.allSettled(
      contestants.map(contestant => this._runContestant(contestant, task, battleId))
    );

    const results = {};
    for (let i = 0; i < contestants.length; i++) {
      const contestant = contestants[i];
      const eval_ = evaluations[i];
      if (eval_.status === 'fulfilled') {
        results[contestant] = eval_.value;
      } else {
        results[contestant] = {
          contestant,
          error: eval_.reason?.message || 'Unknown error',
          text: '',
          latencyMs: 0,
          tokens: 0,
          cost: 0,
          failed: true,
        };
      }
    }

    battleRecord.results = results;

    // Judge the results
    const judgment = await this.judge(results, task);
    battleRecord.winner = judgment.winner;
    battleRecord.scores = judgment.scores;
    battleRecord.judgeRationale = judgment.rationale;
    battleRecord.status = 'completed';
    battleRecord.completedAt = new Date().toISOString();

    // Update leaderboard
    this._updateLeaderboard(contestants, judgment.winner, task.taskType, judgment.scores);

    this.emit('battle-complete', { battleId, winner: judgment.winner, scores: judgment.scores });

    return battleRecord;
  }

  async _runContestant(contestant, task, battleId) {
    const startMs = Date.now();
    try {
      const router = this._llmRouter || require('./llm-router').getLLMRouter();
      const result = await router.generate(task.prompt, {
        taskType: task.taskType || 'default',
        systemPrompt: task.systemPrompt,
        maxTokens: task.maxTokens || 1024,
        temperature: task.temperature,
        _forceProvider: contestant, // signal to router to use this specific provider
      });
      const latencyMs = Date.now() - startMs;
      return {
        contestant,
        text: result.text,
        provider: result.provider,
        model: result.model,
        tokens: (result.tokens?.input || 0) + (result.tokens?.output || 0),
        latencyMs,
        failed: false,
      };
    } catch (err) {
      return {
        contestant,
        error: err.message,
        text: '',
        latencyMs: Date.now() - startMs,
        tokens: 0,
        failed: true,
      };
    }
  }

  /**
   * Judge battle results using a judge model or heuristics.
   * @param {object} results — { [contestant]: { text, latencyMs, tokens } }
   * @param {object} task
   * @returns {{ winner, scores, rationale }}
   */
  async judge(results, task = {}) {
    const contestants = Object.keys(results);
    const criteria = task.criteria || [SCORING_CRITERIA.QUALITY, SCORING_CRITERIA.SPEED, SCORING_CRITERIA.COST];
    const scores = {};

    for (const contestant of contestants) {
      scores[contestant] = 0;
    }

    // Speed scoring (lower latency = higher score)
    if (criteria.includes(SCORING_CRITERIA.SPEED)) {
      const sorted = [...contestants].sort((a, b) => (results[a].latencyMs || 99999) - (results[b].latencyMs || 99999));
      for (let i = 0; i < sorted.length; i++) {
        scores[sorted[i]] += (sorted.length - i) * 10;
      }
    }

    // Cost scoring (lower tokens = lower cost)
    if (criteria.includes(SCORING_CRITERIA.COST)) {
      const sorted = [...contestants].sort((a, b) => (results[a].tokens || 0) - (results[b].tokens || 0));
      for (let i = 0; i < sorted.length; i++) {
        scores[sorted[i]] += (sorted.length - i) * 5;
      }
    }

    // Quality scoring via judge model (if available)
    let judgeRationale = 'Scored by heuristics (speed + cost).';
    if (criteria.includes(SCORING_CRITERIA.QUALITY)) {
      try {
        const router = this._llmRouter || require('./llm-router').getLLMRouter();
        const judgePrompt = buildJudgePrompt(task.prompt, results);
        const judgeResult = await router.generate(judgePrompt, { taskType: 'code_review', maxTokens: 1024 });
        const parsed = parseJudgeResponse(judgeResult.text, contestants);
        for (const [c, score] of Object.entries(parsed.scores || {})) {
          scores[c] = (scores[c] || 0) + score * 20;
        }
        judgeRationale = parsed.rationale || judgeResult.text.slice(0, 500);
      } catch (e) {
        judgeRationale += ` (Judge model failed: ${e.message})`;
      }
    }

    // Penalize failed contestants
    for (const contestant of contestants) {
      if (results[contestant]?.failed) scores[contestant] = -1;
    }

    const winner = contestants.reduce((best, c) => scores[c] > scores[best] ? c : best, contestants[0]);

    return { winner, scores, rationale: judgeRationale };
  }

  // ─── Leaderboard ───────────────────────────────────────────────────────────

  _updateLeaderboard(contestants, winner, taskType, scores) {
    for (const contestant of contestants) {
      if (!this._leaderboard.has(contestant)) {
        this._leaderboard.set(contestant, { model: contestant, wins: 0, losses: 0, draws: 0, totalScore: 0, taskTypes: {} });
      }
      const entry = this._leaderboard.get(contestant);
      entry.totalScore += scores[contestant] || 0;

      if (contestant === winner) {
        entry.wins++;
      } else {
        entry.losses++;
      }

      if (taskType) {
        if (!entry.taskTypes[taskType]) entry.taskTypes[taskType] = { wins: 0, losses: 0 };
        if (contestant === winner) entry.taskTypes[taskType].wins++;
        else entry.taskTypes[taskType].losses++;
      }
    }
  }

  getLeaderboard(taskType = null) {
    let entries = Array.from(this._leaderboard.values());
    if (taskType) {
      entries = entries
        .filter(e => e.taskTypes[taskType])
        .map(e => ({
          ...e,
          wins: e.taskTypes[taskType].wins,
          losses: e.taskTypes[taskType].losses,
          taskType,
        }));
    }
    return entries
      .map(e => ({
        ...e,
        winRate: (e.wins + e.losses) > 0 ? (e.wins / (e.wins + e.losses) * 100).toFixed(1) + '%' : 'N/A',
      }))
      .sort((a, b) => b.wins - a.wins);
  }

  getBattle(battleId) {
    return this._battles.get(battleId) || null;
  }

  listBattles(limit = 50) {
    return Array.from(this._battles.values()).slice(-limit).reverse();
  }
}

// ─── Judge prompt helpers ─────────────────────────────────────────────────────

function buildJudgePrompt(originalPrompt, results) {
  const entries = Object.entries(results)
    .filter(([, r]) => !r.failed)
    .map(([id, r]) => `--- ${id} ---\n${r.text || '[no output]'}`)
    .join('\n\n');

  return `You are a neutral judge evaluating AI model responses.

Original prompt: "${originalPrompt?.slice(0, 300)}"

Responses:
${entries}

Rate each response 1-10 for quality, accuracy, and helpfulness.
Respond in JSON:
{
  "scores": { "<model_id>": <1-10>, ... },
  "winner": "<model_id>",
  "rationale": "<brief explanation>"
}`;
}

function parseJudgeResponse(text, contestants) {
  try {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) return { scores: {}, rationale: text };
    const parsed = JSON.parse(match[0]);
    return { scores: parsed.scores || {}, rationale: parsed.rationale || '', winner: parsed.winner };
  } catch {
    return { scores: {}, rationale: text.slice(0, 200) };
  }
}

let _instance = null;
function getBattleArena(opts) {
  if (!_instance) _instance = new BattleArena(opts);
  return _instance;
}

module.exports = { BattleArena, getBattleArena, SCORING_CRITERIA };
