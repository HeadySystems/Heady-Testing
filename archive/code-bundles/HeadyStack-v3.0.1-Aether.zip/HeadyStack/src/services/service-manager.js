'use strict';

/**
 * ServiceManager — Service lifecycle manager for all HeadyStack services.
 * Tracks running services, coordinates startup/shutdown, and exposes health APIs.
 */

const EventEmitter = require('events');

const SERVICE_STATUS = {
  REGISTERED: 'registered',
  STARTING: 'starting',
  RUNNING: 'running',
  STOPPING: 'stopping',
  STOPPED: 'stopped',
  FAILED: 'failed',
  DEGRADED: 'degraded',
};

class ServiceManager extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._services = new Map();     // name → ServiceRecord
    this._startOrder = [];
    this._stopOrder = [];
    this._startupTimeoutMs = opts.startupTimeoutMs || 30000;
  }

  // ─── Registration ──────────────────────────────────────────────────────────

  /**
   * Register a service with the manager.
   * @param {object} cfg
   * @param {string} cfg.name
   * @param {Function} [cfg.start] — async start function
   * @param {Function} [cfg.stop] — async stop function
   * @param {Function} [cfg.health] — async health check → {ok, details}
   * @param {string[]} [cfg.dependencies] — names of services that must start first
   * @param {boolean} [cfg.critical] — if true, system fails if this service fails
   */
  register(cfg) {
    if (!cfg.name) throw new Error('Service name required');
    const record = {
      name: cfg.name,
      description: cfg.description || '',
      start: cfg.start || null,
      stop: cfg.stop || null,
      health: cfg.health || null,
      dependencies: cfg.dependencies || [],
      critical: cfg.critical !== false,
      status: SERVICE_STATUS.REGISTERED,
      error: null,
      startedAt: null,
      stoppedAt: null,
      restarts: 0,
      registeredAt: new Date().toISOString(),
    };
    this._services.set(cfg.name, record);
    this.emit('service-registered', { name: cfg.name });
    return this;
  }

  unregister(name) {
    const existed = this._services.delete(name);
    if (existed) this.emit('service-unregistered', { name });
    return existed;
  }

  // ─── Lifecycle ─────────────────────────────────────────────────────────────

  /**
   * Start a single service.
   */
  async startService(name) {
    const svc = this._services.get(name);
    if (!svc) throw new Error(`Service not registered: ${name}`);
    if (svc.status === SERVICE_STATUS.RUNNING) return svc;

    // Check dependencies
    for (const dep of svc.dependencies) {
      const depSvc = this._services.get(dep);
      if (!depSvc || depSvc.status !== SERVICE_STATUS.RUNNING) {
        throw new Error(`Dependency not running: ${dep} (required by ${name})`);
      }
    }

    svc.status = SERVICE_STATUS.STARTING;
    this.emit('service-starting', { name });

    try {
      if (typeof svc.start === 'function') {
        await Promise.race([
          svc.start(),
          new Promise((_, rej) => setTimeout(() => rej(new Error(`Startup timeout: ${name}`)), this._startupTimeoutMs)),
        ]);
      }
      svc.status = SERVICE_STATUS.RUNNING;
      svc.startedAt = new Date().toISOString();
      svc.error = null;
      this.emit('service-started', { name });
    } catch (err) {
      svc.status = SERVICE_STATUS.FAILED;
      svc.error = err.message;
      this.emit('service-failed', { name, error: err.message });
      if (svc.critical) throw err;
    }

    return svc;
  }

  /**
   * Stop a single service.
   */
  async stopService(name) {
    const svc = this._services.get(name);
    if (!svc) return;
    if (svc.status === SERVICE_STATUS.STOPPED) return svc;

    svc.status = SERVICE_STATUS.STOPPING;
    this.emit('service-stopping', { name });

    try {
      if (typeof svc.stop === 'function') await svc.stop();
    } catch (err) {
      this.emit('service-stop-error', { name, error: err.message });
    }

    svc.status = SERVICE_STATUS.STOPPED;
    svc.stoppedAt = new Date().toISOString();
    this.emit('service-stopped', { name });
    return svc;
  }

  /**
   * Start all registered services in dependency order.
   */
  async startAll() {
    const sorted = this._topoSort();
    const results = {};
    for (const name of sorted) {
      try {
        await this.startService(name);
        results[name] = { ok: true };
      } catch (err) {
        results[name] = { ok: false, error: err.message };
      }
    }
    this.emit('all-started', { results });
    return results;
  }

  /**
   * Stop all services in reverse order.
   */
  async stopAll() {
    const sorted = this._topoSort().reverse();
    for (const name of sorted) {
      await this.stopService(name);
    }
    this.emit('all-stopped');
  }

  /**
   * Restart a service.
   */
  async restartService(name) {
    const svc = this._services.get(name);
    if (!svc) throw new Error(`Service not registered: ${name}`);
    await this.stopService(name);
    await this.startService(name);
    svc.restarts++;
    this.emit('service-restarted', { name, restarts: svc.restarts });
    return svc;
  }

  // ─── Topological sort ──────────────────────────────────────────────────────

  _topoSort() {
    const visited = new Set();
    const order = [];

    const visit = (name) => {
      if (visited.has(name)) return;
      visited.add(name);
      const svc = this._services.get(name);
      if (svc) {
        for (const dep of svc.dependencies) visit(dep);
      }
      order.push(name);
    };

    for (const name of this._services.keys()) visit(name);
    return order;
  }

  // ─── Health ────────────────────────────────────────────────────────────────

  async checkHealth(name) {
    const svc = this._services.get(name);
    if (!svc) return { name, ok: false, error: 'Not registered' };

    let details = {};
    let ok = svc.status === SERVICE_STATUS.RUNNING;

    if (svc.status === SERVICE_STATUS.RUNNING && typeof svc.health === 'function') {
      try {
        const result = await svc.health();
        ok = result.ok !== false;
        details = result.details || {};
        if (!ok) svc.status = SERVICE_STATUS.DEGRADED;
      } catch (err) {
        ok = false;
        details.error = err.message;
        svc.status = SERVICE_STATUS.DEGRADED;
      }
    }

    return { name, ok, status: svc.status, details, startedAt: svc.startedAt, restarts: svc.restarts };
  }

  async checkAllHealth() {
    const results = {};
    for (const name of this._services.keys()) {
      results[name] = await this.checkHealth(name);
    }
    return results;
  }

  getServiceInfo(name) {
    const svc = this._services.get(name);
    if (!svc) return null;
    return {
      name: svc.name,
      description: svc.description,
      status: svc.status,
      critical: svc.critical,
      dependencies: svc.dependencies,
      startedAt: svc.startedAt,
      stoppedAt: svc.stoppedAt,
      restarts: svc.restarts,
      error: svc.error,
    };
  }

  listServices() {
    return Array.from(this._services.values()).map(svc => ({
      name: svc.name,
      description: svc.description,
      status: svc.status,
      critical: svc.critical,
      dependencies: svc.dependencies,
      startedAt: svc.startedAt,
      restarts: svc.restarts,
    }));
  }

  getSystemStatus() {
    const services = this.listServices();
    const byStatus = {};
    for (const s of services) byStatus[s.status] = (byStatus[s.status] || 0) + 1;
    const healthy = services.filter(s => s.status === SERVICE_STATUS.RUNNING).length;
    return {
      total: services.length,
      healthy,
      unhealthy: services.length - healthy,
      byStatus,
      allHealthy: healthy === services.length,
    };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** GET /api/services/list */
    app.get('/api/services/list', (req, res) => {
      res.json({ ok: true, services: this.listServices(), status: this.getSystemStatus() });
    });

    /** GET /api/services/health */
    app.get('/api/services/health', async (req, res) => {
      try {
        const health = await this.checkAllHealth();
        const status = this.getSystemStatus();
        res.json({ ok: status.allHealthy, health, status });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/services/:name */
    app.get('/api/services/:name', (req, res) => {
      const info = this.getServiceInfo(req.params.name);
      if (!info) return res.status(404).json({ ok: false, error: 'Service not found' });
      res.json({ ok: true, service: info });
    });

    /** POST /api/services/:name/start */
    app.post('/api/services/:name/start', async (req, res) => {
      try {
        const svc = await this.startService(req.params.name);
        res.json({ ok: true, service: this.getServiceInfo(svc.name) });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/services/:name/stop */
    app.post('/api/services/:name/stop', async (req, res) => {
      try {
        await this.stopService(req.params.name);
        res.json({ ok: true, service: this.getServiceInfo(req.params.name) });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/services/:name/restart */
    app.post('/api/services/:name/restart', async (req, res) => {
      try {
        const svc = await this.restartService(req.params.name);
        res.json({ ok: true, service: this.getServiceInfo(svc.name) });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    return app;
  }
}

let _instance = null;
function getServiceManager(opts) {
  if (!_instance) _instance = new ServiceManager(opts);
  return _instance;
}

module.exports = { ServiceManager, getServiceManager, SERVICE_STATUS };
