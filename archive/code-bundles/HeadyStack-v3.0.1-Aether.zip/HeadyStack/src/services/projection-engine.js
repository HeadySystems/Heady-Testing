'use strict';

/**
 * ProjectionEngine — Projects monorepo source code to target repositories.
 * Supports event-driven sync, selective projection by path globs, and dry-run mode.
 */

const EventEmitter = require('events');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const PROJECTION_STATUS = {
  IDLE: 'idle',
  SYNCING: 'syncing',
  ERROR: 'error',
  VALIDATING: 'validating',
};

class ProjectionEngine extends EventEmitter {
  constructor(opts = {}) {
    super();
    this.monorepoRoot = opts.monorepoRoot || process.cwd();
    this.projections = new Map();       // id → ProjectionConfig
    this._syncQueue = [];
    this._status = PROJECTION_STATUS.IDLE;
    this._stats = { totalProjections: 0, totalFiles: 0, errors: 0, lastSync: null };

    if (opts.projections) {
      for (const p of opts.projections) this.addProjection(p);
    }

    // Event-driven sync: watch for file changes
    this._watchers = new Map();
  }

  // ─── Config ────────────────────────────────────────────────────────────────

  /**
   * Add a projection configuration.
   * @param {object} cfg
   * @param {string} cfg.id
   * @param {string} cfg.name
   * @param {string} cfg.sourceGlob — relative glob from monorepo root (e.g. 'packages/api/**')
   * @param {string} cfg.targetRepo — target repo path or remote URL
   * @param {string} cfg.targetBranch
   * @param {boolean} cfg.autoSync
   * @param {string[]} cfg.exclude
   */
  addProjection(cfg) {
    if (!cfg.id) cfg.id = 'proj_' + crypto.randomBytes(6).toString('hex');
    this.projections.set(cfg.id, {
      ...cfg,
      status: PROJECTION_STATUS.IDLE,
      lastSync: null,
      filesProjected: 0,
      errors: [],
    });
    this.emit('projection-added', { id: cfg.id, name: cfg.name });
    return cfg.id;
  }

  removeProjection(id) {
    const existed = this.projections.has(id);
    this.projections.delete(id);
    this._watchers.get(id)?.close?.();
    this._watchers.delete(id);
    if (existed) this.emit('projection-removed', { id });
    return existed;
  }

  getProjection(id) {
    return this.projections.get(id) || null;
  }

  listProjections() {
    return Array.from(this.projections.values());
  }

  // ─── Sync logic ────────────────────────────────────────────────────────────

  /**
   * Run a projection sync. Discovers files via glob, copies/diffs to target.
   */
  async sync(projectionId, opts = {}) {
    const proj = this.projections.get(projectionId);
    if (!proj) throw new Error(`Projection not found: ${projectionId}`);

    const dryRun = opts.dryRun || proj.dryRun || false;
    proj.status = PROJECTION_STATUS.SYNCING;
    this.emit('sync-start', { id: projectionId, name: proj.name, dryRun });

    const result = {
      id: projectionId,
      name: proj.name,
      dryRun,
      files: [],
      errors: [],
      startedAt: new Date().toISOString(),
      completedAt: null,
    };

    try {
      const sourceDir = path.resolve(this.monorepoRoot, proj.sourcePath || '.');
      const targetDir = path.resolve(proj.targetRepo);

      const files = this._walkDir(sourceDir, proj.exclude || []);

      for (const file of files) {
        const relPath = path.relative(sourceDir, file);
        const targetFile = path.join(targetDir, relPath);
        const action = this._determineAction(file, targetFile);

        result.files.push({ source: file, target: targetFile, action, relPath });

        if (!dryRun && action !== 'skip') {
          try {
            fs.mkdirSync(path.dirname(targetFile), { recursive: true });
            fs.copyFileSync(file, targetFile);
          } catch (copyErr) {
            result.errors.push({ file, error: copyErr.message });
            this._stats.errors++;
          }
        }
      }

      proj.filesProjected = result.files.length;
      proj.lastSync = new Date().toISOString();
      proj.status = PROJECTION_STATUS.IDLE;
      proj.errors = result.errors;

      this._stats.totalProjections++;
      this._stats.totalFiles += result.files.length;
      this._stats.lastSync = proj.lastSync;

      result.completedAt = proj.lastSync;
      this.emit('sync-complete', { id: projectionId, result });
    } catch (err) {
      proj.status = PROJECTION_STATUS.ERROR;
      result.errors.push({ error: err.message });
      this.emit('sync-error', { id: projectionId, error: err.message });
      throw err;
    }

    return result;
  }

  _walkDir(dir, exclude = []) {
    const results = [];
    if (!fs.existsSync(dir)) return results;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (exclude.some(ex => fullPath.includes(ex))) continue;
      if (entry.isDirectory()) {
        results.push(...this._walkDir(fullPath, exclude));
      } else {
        results.push(fullPath);
      }
    }
    return results;
  }

  _determineAction(source, target) {
    if (!fs.existsSync(target)) return 'create';
    const srcHash = this._hashFile(source);
    const tgtHash = this._hashFile(target);
    return srcHash !== tgtHash ? 'update' : 'skip';
  }

  _hashFile(filePath) {
    try {
      const content = fs.readFileSync(filePath);
      return crypto.createHash('sha256').update(content).digest('hex');
    } catch {
      return '';
    }
  }

  /**
   * Sync all projections.
   */
  async syncAll(opts = {}) {
    const results = [];
    for (const id of this.projections.keys()) {
      try {
        const r = await this.sync(id, opts);
        results.push(r);
      } catch (err) {
        results.push({ id, error: err.message });
      }
    }
    return results;
  }

  /**
   * Enable event-driven watch sync for a projection.
   */
  watchProjection(projectionId) {
    const proj = this.projections.get(projectionId);
    if (!proj) throw new Error(`Projection not found: ${projectionId}`);
    const sourceDir = path.resolve(this.monorepoRoot, proj.sourcePath || '.');
    if (!fs.existsSync(sourceDir)) return;

    let debounce = null;
    const watcher = fs.watch(sourceDir, { recursive: true }, (eventType, filename) => {
      clearTimeout(debounce);
      debounce = setTimeout(() => {
        this.emit('file-changed', { projectionId, eventType, filename });
        this.sync(projectionId).catch(err => this.emit('sync-error', { projectionId, error: err.message }));
      }, 500);
    });

    this._watchers.set(projectionId, watcher);
    this.emit('watching', { projectionId });
    return watcher;
  }

  stopWatch(projectionId) {
    const watcher = this._watchers.get(projectionId);
    if (watcher) { watcher.close(); this._watchers.delete(projectionId); }
  }

  getStats() {
    return { ...this._stats, activeProjections: this.projections.size, watching: this._watchers.size };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** GET /api/projections */
    app.get('/api/projections', (req, res) => {
      res.json({ ok: true, projections: this.listProjections(), stats: this.getStats() });
    });

    /** GET /api/projections/:id */
    app.get('/api/projections/:id', (req, res) => {
      const p = this.getProjection(req.params.id);
      if (!p) return res.status(404).json({ ok: false, error: 'Projection not found' });
      res.json({ ok: true, projection: p });
    });

    /** POST /api/projections — add a new projection */
    app.post('/api/projections', (req, res) => {
      try {
        const id = this.addProjection(req.body || {});
        res.status(201).json({ ok: true, id });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** DELETE /api/projections/:id */
    app.delete('/api/projections/:id', (req, res) => {
      const removed = this.removeProjection(req.params.id);
      if (!removed) return res.status(404).json({ ok: false, error: 'Projection not found' });
      res.json({ ok: true, removed: req.params.id });
    });

    /** POST /api/projections/:id/sync */
    app.post('/api/projections/:id/sync', async (req, res) => {
      try {
        const result = await this.sync(req.params.id, req.body || {});
        res.json({ ok: true, result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/projections/sync-all */
    app.post('/api/projections/sync-all', async (req, res) => {
      try {
        const results = await this.syncAll(req.body || {});
        res.json({ ok: true, results });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/projections/:id/watch */
    app.post('/api/projections/:id/watch', (req, res) => {
      try {
        this.watchProjection(req.params.id);
        res.json({ ok: true, watching: req.params.id });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** DELETE /api/projections/:id/watch */
    app.delete('/api/projections/:id/watch', (req, res) => {
      this.stopWatch(req.params.id);
      res.json({ ok: true, stopped: req.params.id });
    });

    /** GET /api/projections/stats */
    app.get('/api/projections/stats', (req, res) => {
      res.json({ ok: true, stats: this.getStats() });
    });

    return app;
  }
}

let _instance = null;
function getProjectionEngine(opts) {
  if (!_instance) _instance = new ProjectionEngine(opts);
  return _instance;
}

module.exports = { ProjectionEngine, getProjectionEngine, PROJECTION_STATUS };
