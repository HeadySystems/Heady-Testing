'use strict';

/**
 * BuddySystem — Manages buddy companion sessions across devices.
 * Maintains conversation history, personality profiles, and cross-device sync.
 */

const EventEmitter = require('events');
const crypto = require('crypto');

const DEFAULT_BUDDY_PERSONALITY = {
  name: 'HeadyBuddy',
  tone: 'friendly, concise, helpful',
  expertise: ['coding', 'research', 'planning', 'general'],
  maxHistoryMessages: 50,
};

const SESSION_STATUS = {
  ACTIVE: 'active',
  IDLE: 'idle',
  ARCHIVED: 'archived',
  TRANSFERRED: 'transferred',
};

class BuddySystem extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._sessions = new Map();          // sessionId → BuddySession
    this._userSessions = new Map();      // userId → Set<sessionId>
    this._deviceSessions = new Map();    // deviceId → sessionId
    this._personality = Object.assign({}, DEFAULT_BUDDY_PERSONALITY, opts.personality || {});
    this._llmRouter = opts.llmRouter || null;
    this._idleTimeoutMs = opts.idleTimeoutMs || 30 * 60 * 1000; // 30 min
    this._gcInterval = setInterval(() => this._gc(), 5 * 60 * 1000);
    if (this._gcInterval.unref) this._gcInterval.unref();
  }

  // ─── Session management ────────────────────────────────────────────────────

  /**
   * Create or resume a buddy session.
   */
  getOrCreateSession(opts = {}) {
    const { userId, deviceId, sessionId: existingId } = opts;

    // Try to resume by sessionId or deviceId
    if (existingId && this._sessions.has(existingId)) {
      const session = this._sessions.get(existingId);
      session.status = SESSION_STATUS.ACTIVE;
      session.lastActiveAt = new Date().toISOString();
      if (deviceId) session.devices.add(deviceId);
      return session;
    }

    if (deviceId && this._deviceSessions.has(deviceId)) {
      const sId = this._deviceSessions.get(deviceId);
      const session = this._sessions.get(sId);
      if (session) {
        session.status = SESSION_STATUS.ACTIVE;
        session.lastActiveAt = new Date().toISOString();
        return session;
      }
    }

    // Create new session
    const sessionId = 'buddy_' + crypto.randomBytes(10).toString('hex');
    const session = {
      id: sessionId,
      userId: userId || null,
      devices: new Set(deviceId ? [deviceId] : []),
      status: SESSION_STATUS.ACTIVE,
      history: [],
      personality: { ...this._personality },
      context: {},
      createdAt: new Date().toISOString(),
      lastActiveAt: new Date().toISOString(),
      messageCount: 0,
      totalTokensUsed: 0,
    };

    this._sessions.set(sessionId, session);
    if (userId) {
      if (!this._userSessions.has(userId)) this._userSessions.set(userId, new Set());
      this._userSessions.get(userId).add(sessionId);
    }
    if (deviceId) this._deviceSessions.set(deviceId, sessionId);

    this.emit('session-created', { sessionId, userId, deviceId });
    return session;
  }

  getSession(sessionId) {
    return this._sessions.get(sessionId) || null;
  }

  listUserSessions(userId) {
    const sessionIds = this._userSessions.get(userId) || new Set();
    return Array.from(sessionIds)
      .map(id => this._sessions.get(id))
      .filter(Boolean)
      .map(s => ({ ...s, devices: Array.from(s.devices) }));
  }

  archiveSession(sessionId) {
    const session = this._sessions.get(sessionId);
    if (session) {
      session.status = SESSION_STATUS.ARCHIVED;
      session.archivedAt = new Date().toISOString();
      this.emit('session-archived', { sessionId });
    }
  }

  // ─── Chat ──────────────────────────────────────────────────────────────────

  /**
   * Send a message in a buddy session and get a response.
   */
  async chat(sessionId, message, opts = {}) {
    const session = this._sessions.get(sessionId);
    if (!session) throw new Error(`Session not found: ${sessionId}`);
    if (session.status === SESSION_STATUS.ARCHIVED) throw new Error('Session is archived');

    session.lastActiveAt = new Date().toISOString();
    session.status = SESSION_STATUS.ACTIVE;
    session.messageCount++;

    // Add user message to history
    const userMsg = {
      role: 'user',
      content: message,
      ts: new Date().toISOString(),
      device: opts.deviceId || 'unknown',
    };
    session.history.push(userMsg);

    // Trim history if needed
    const maxHistory = session.personality.maxHistoryMessages || 50;
    if (session.history.length > maxHistory * 2) {
      session.history = session.history.slice(-maxHistory * 2);
    }

    // Build system prompt
    const systemPrompt = buildBuddySystemPrompt(session.personality, session.context);

    // Build messages for LLM
    const recentHistory = session.history.slice(-20);
    const messagesContext = recentHistory
      .filter(m => m.role !== 'system')
      .map(m => `${m.role === 'user' ? 'User' : 'Buddy'}: ${m.content}`)
      .slice(0, -1) // Exclude last (current) message
      .join('\n');

    const fullPrompt = messagesContext
      ? `Previous conversation:\n${messagesContext}\n\nUser: ${message}\n\nBuddy:`
      : `User: ${message}\n\nBuddy:`;

    let responseText = '';
    let tokensUsed = 0;

    try {
      const router = this._llmRouter || require('./llm-router').getLLMRouter();
      const result = await router.generate(fullPrompt, {
        taskType: opts.taskType || 'quick_tasks',
        systemPrompt,
        maxTokens: opts.maxTokens || 512,
        temperature: opts.temperature || 0.8,
      });
      responseText = result.text;
      tokensUsed = (result.tokens?.input || 0) + (result.tokens?.output || 0);
    } catch (err) {
      responseText = `I'm having trouble connecting right now. Please try again in a moment. (${err.message})`;
    }

    const assistantMsg = {
      role: 'assistant',
      content: responseText,
      ts: new Date().toISOString(),
      tokensUsed,
    };
    session.history.push(assistantMsg);
    session.totalTokensUsed += tokensUsed;

    this.emit('message', { sessionId, userId: session.userId, messageCount: session.messageCount });

    return {
      sessionId,
      message: assistantMsg,
      history: session.history.slice(-10),
      messageCount: session.messageCount,
    };
  }

  /**
   * Transfer session from one device to another.
   */
  transferSession(sessionId, fromDeviceId, toDeviceId) {
    const session = this._sessions.get(sessionId);
    if (!session) throw new Error(`Session not found: ${sessionId}`);
    session.devices.add(toDeviceId);
    this._deviceSessions.set(toDeviceId, sessionId);
    session.status = SESSION_STATUS.TRANSFERRED;
    session.lastActiveAt = new Date().toISOString();
    this.emit('session-transferred', { sessionId, fromDeviceId, toDeviceId });
    return session;
  }

  /**
   * Update buddy personality for a session.
   */
  updatePersonality(sessionId, updates) {
    const session = this._sessions.get(sessionId);
    if (!session) throw new Error(`Session not found: ${sessionId}`);
    session.personality = { ...session.personality, ...updates };
    this.emit('personality-updated', { sessionId });
    return session.personality;
  }

  /**
   * Update session context (key-value facts about the user).
   */
  updateContext(sessionId, context) {
    const session = this._sessions.get(sessionId);
    if (!session) throw new Error(`Session not found: ${sessionId}`);
    session.context = { ...session.context, ...context };
    return session.context;
  }

  // ─── Garbage collection ────────────────────────────────────────────────────

  _gc() {
    const cutoff = Date.now() - this._idleTimeoutMs;
    for (const [id, session] of this._sessions.entries()) {
      if (session.status === SESSION_STATUS.ACTIVE) {
        const lastActive = new Date(session.lastActiveAt).getTime();
        if (lastActive < cutoff) {
          session.status = SESSION_STATUS.IDLE;
          this.emit('session-idle', { sessionId: id });
        }
      }
    }
  }

  getStats() {
    const all = Array.from(this._sessions.values());
    const byStatus = {};
    for (const s of all) byStatus[s.status] = (byStatus[s.status] || 0) + 1;
    return { total: all.length, byStatus, totalMessages: all.reduce((n, s) => n + s.messageCount, 0) };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** POST /api/buddy/session — create or resume session */
    app.post('/api/buddy/session', (req, res) => {
      try {
        const { userId, deviceId, sessionId } = req.body || {};
        const session = this.getOrCreateSession({ userId, deviceId, sessionId });
        res.json({ ok: true, sessionId: session.id, status: session.status });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/buddy/chat */
    app.post('/api/buddy/chat', async (req, res) => {
      try {
        const { sessionId, message, taskType, maxTokens, deviceId } = req.body || {};
        if (!sessionId) return res.status(400).json({ ok: false, error: 'sessionId required' });
        if (!message) return res.status(400).json({ ok: false, error: 'message required' });
        const result = await this.chat(sessionId, message, { taskType, maxTokens, deviceId });
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(err.message.includes('not found') ? 404 : 500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/buddy/history/:sessionId */
    app.get('/api/buddy/history/:sessionId', (req, res) => {
      const session = this.getSession(req.params.sessionId);
      if (!session) return res.status(404).json({ ok: false, error: 'Session not found' });
      const limit = parseInt(req.query.limit) || 50;
      res.json({ ok: true, history: session.history.slice(-limit), messageCount: session.messageCount });
    });

    /** GET /api/buddy/sessions/:userId */
    app.get('/api/buddy/sessions/:userId', (req, res) => {
      const sessions = this.listUserSessions(req.params.userId);
      res.json({ ok: true, sessions });
    });

    /** POST /api/buddy/transfer */
    app.post('/api/buddy/transfer', (req, res) => {
      try {
        const { sessionId, fromDeviceId, toDeviceId } = req.body || {};
        const session = this.transferSession(sessionId, fromDeviceId, toDeviceId);
        res.json({ ok: true, sessionId: session.id });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** PUT /api/buddy/session/:sessionId/personality */
    app.put('/api/buddy/session/:sessionId/personality', (req, res) => {
      try {
        const personality = this.updatePersonality(req.params.sessionId, req.body || {});
        res.json({ ok: true, personality });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** PUT /api/buddy/session/:sessionId/context */
    app.put('/api/buddy/session/:sessionId/context', (req, res) => {
      try {
        const context = this.updateContext(req.params.sessionId, req.body || {});
        res.json({ ok: true, context });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/buddy/session/:sessionId/archive */
    app.post('/api/buddy/session/:sessionId/archive', (req, res) => {
      this.archiveSession(req.params.sessionId);
      res.json({ ok: true, archived: req.params.sessionId });
    });

    /** GET /api/buddy/stats */
    app.get('/api/buddy/stats', (req, res) => {
      res.json({ ok: true, stats: this.getStats() });
    });

    return app;
  }
}

function buildBuddySystemPrompt(personality, context = {}) {
  const contextStr = Object.keys(context).length > 0
    ? `\nUser context: ${JSON.stringify(context)}`
    : '';
  return `You are ${personality.name}, a ${personality.tone} AI companion.
Your areas of expertise: ${(personality.expertise || []).join(', ')}.
Be helpful, direct, and conversational. Keep responses concise unless detail is needed.${contextStr}`;
}

let _instance = null;
function getBuddySystem(opts) {
  if (!_instance) _instance = new BuddySystem(opts);
  return _instance;
}

module.exports = { BuddySystem, getBuddySystem, SESSION_STATUS, DEFAULT_BUDDY_PERSONALITY };
