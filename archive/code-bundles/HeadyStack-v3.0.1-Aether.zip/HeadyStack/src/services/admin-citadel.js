'use strict';

/**
 * AdminCitadel — Administrative control panel for HeadyStack system management.
 * Provides secure admin routes for system inspection, configuration, and control.
 */

const EventEmitter = require('events');
const crypto = require('crypto');

const ADMIN_ACTIONS = {
  CONFIG_UPDATE: 'config_update',
  SERVICE_RESTART: 'service_restart',
  CACHE_CLEAR: 'cache_clear',
  USER_BAN: 'user_ban',
  BUDGET_OVERRIDE: 'budget_override',
  PROJECTION_OVERRIDE: 'projection_override',
  SYSTEM_DRAIN: 'system_drain',
  FEATURE_FLAG: 'feature_flag',
};

class AdminCitadel extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._adminKeys = new Set(opts.adminKeys || []);
    this._sessions = new Map();           // token → AdminSession
    this._auditLog = [];
    this._maxAuditLog = opts.maxAuditLog || 2000;
    this._featureFlags = new Map(Object.entries(opts.featureFlags || {}));
    this._bannedUsers = new Set(opts.bannedUsers || []);
    this._config = new Map(Object.entries(opts.config || {}));
    this._services = new Map();           // serviceName → ServiceRecord
    this._sessionTTLMs = opts.sessionTTLMs || 4 * 60 * 60 * 1000; // 4 hours

    // Clean expired sessions every 5 minutes
    this._cleanInterval = setInterval(() => this._cleanSessions(), 5 * 60 * 1000);
    if (this._cleanInterval.unref) this._cleanInterval.unref();
  }

  // ─── Auth ──────────────────────────────────────────────────────────────────

  /**
   * Authenticate with an admin key and return a session token.
   */
  authenticate(adminKey) {
    if (!this._adminKeys.has(adminKey)) {
      // Also check env-based admin key
      const envKey = process.env.HEADY_ADMIN_KEY;
      if (!envKey || adminKey !== envKey) {
        this._audit('auth_failed', null, {});
        throw new Error('Invalid admin key');
      }
    }
    const token = crypto.randomBytes(32).toString('hex');
    const session = {
      token,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + this._sessionTTLMs).toISOString(),
      actions: [],
    };
    this._sessions.set(token, session);
    this._audit('auth_success', token, {});
    return { token, expiresAt: session.expiresAt };
  }

  /**
   * Verify a session token.
   */
  verifyToken(token) {
    const session = this._sessions.get(token);
    if (!session) return false;
    if (new Date(session.expiresAt) < new Date()) {
      this._sessions.delete(token);
      return false;
    }
    return session;
  }

  /**
   * Express middleware that enforces admin authentication.
   */
  authMiddleware() {
    return (req, res, next) => {
      const token = req.headers['x-admin-token'] || req.query.adminToken;
      if (!token) return res.status(401).json({ ok: false, error: 'Admin token required' });
      const session = this.verifyToken(token);
      if (!session) return res.status(403).json({ ok: false, error: 'Invalid or expired admin token' });
      req.adminSession = session;
      next();
    };
  }

  _cleanSessions() {
    const now = new Date();
    for (const [token, session] of this._sessions.entries()) {
      if (new Date(session.expiresAt) < now) this._sessions.delete(token);
    }
  }

  // ─── Audit ─────────────────────────────────────────────────────────────────

  _audit(action, token, details = {}) {
    const entry = {
      action,
      token: token ? token.slice(0, 8) + '...' : null,
      ts: new Date().toISOString(),
      ...details,
    };
    this._auditLog.push(entry);
    if (this._auditLog.length > this._maxAuditLog) this._auditLog.shift();
    this.emit('admin-action', entry);
  }

  getAuditLog(limit = 100) {
    return this._auditLog.slice(-limit);
  }

  // ─── Feature flags ─────────────────────────────────────────────────────────

  setFeatureFlag(flag, value) {
    this._featureFlags.set(flag, value);
    this._audit(ADMIN_ACTIONS.FEATURE_FLAG, null, { flag, value });
    this.emit('feature-flag-changed', { flag, value });
  }

  getFeatureFlag(flag) {
    return this._featureFlags.get(flag);
  }

  isFeatureEnabled(flag) {
    return this._featureFlags.get(flag) === true || this._featureFlags.get(flag) === 'true';
  }

  listFeatureFlags() {
    return Object.fromEntries(this._featureFlags.entries());
  }

  // ─── User management ───────────────────────────────────────────────────────

  banUser(userId, reason = '') {
    this._bannedUsers.add(userId);
    this._audit(ADMIN_ACTIONS.USER_BAN, null, { userId, reason, action: 'ban' });
    this.emit('user-banned', { userId, reason });
  }

  unbanUser(userId) {
    this._bannedUsers.delete(userId);
    this._audit(ADMIN_ACTIONS.USER_BAN, null, { userId, action: 'unban' });
    this.emit('user-unbanned', { userId });
  }

  isUserBanned(userId) {
    return this._bannedUsers.has(userId);
  }

  getBannedUsers() {
    return Array.from(this._bannedUsers);
  }

  // ─── Service registry ──────────────────────────────────────────────────────

  registerService(name, meta = {}) {
    this._services.set(name, { name, ...meta, registeredAt: new Date().toISOString(), status: 'running' });
  }

  getServiceStatus(name) {
    return this._services.get(name) || null;
  }

  listServices() {
    return Array.from(this._services.values());
  }

  // ─── System config ─────────────────────────────────────────────────────────

  setConfig(key, value) {
    this._config.set(key, value);
    this._audit(ADMIN_ACTIONS.CONFIG_UPDATE, null, { key });
    this.emit('config-changed', { key, value });
  }

  getConfig(key) {
    return this._config.get(key);
  }

  getAllConfig() {
    return Object.fromEntries(this._config.entries());
  }

  // ─── System introspection ──────────────────────────────────────────────────

  getSystemInfo() {
    const mem = process.memoryUsage();
    return {
      uptime: process.uptime(),
      nodeVersion: process.version,
      platform: process.platform,
      arch: process.arch,
      pid: process.pid,
      memory: {
        rss: Math.round(mem.rss / 1024 / 1024) + 'MB',
        heapUsed: Math.round(mem.heapUsed / 1024 / 1024) + 'MB',
        heapTotal: Math.round(mem.heapTotal / 1024 / 1024) + 'MB',
      },
      env: process.env.NODE_ENV || 'development',
      services: this.listServices().length,
      activeSessions: this._sessions.size,
      featureFlags: this.listFeatureFlags(),
      bannedUsers: this._bannedUsers.size,
    };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    const auth = this.authMiddleware();

    /** POST /api/admin/auth — get session token */
    app.post('/api/admin/auth', (req, res) => {
      try {
        const { adminKey } = req.body || {};
        if (!adminKey) return res.status(400).json({ ok: false, error: 'adminKey required' });
        const result = this.authenticate(adminKey);
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(403).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/admin/system — system info */
    app.get('/api/admin/system', auth, (req, res) => {
      this._audit('system_info', req.adminSession.token, {});
      res.json({ ok: true, system: this.getSystemInfo() });
    });

    /** GET /api/admin/audit */
    app.get('/api/admin/audit', auth, (req, res) => {
      const limit = parseInt(req.query.limit) || 100;
      res.json({ ok: true, auditLog: this.getAuditLog(limit) });
    });

    /** GET /api/admin/feature-flags */
    app.get('/api/admin/feature-flags', auth, (req, res) => {
      res.json({ ok: true, flags: this.listFeatureFlags() });
    });

    /** PUT /api/admin/feature-flags/:flag */
    app.put('/api/admin/feature-flags/:flag', auth, (req, res) => {
      const { value } = req.body || {};
      this.setFeatureFlag(req.params.flag, value);
      this._audit(ADMIN_ACTIONS.FEATURE_FLAG, req.adminSession.token, { flag: req.params.flag, value });
      res.json({ ok: true, flag: req.params.flag, value });
    });

    /** GET /api/admin/config */
    app.get('/api/admin/config', auth, (req, res) => {
      res.json({ ok: true, config: this.getAllConfig() });
    });

    /** PUT /api/admin/config */
    app.put('/api/admin/config', auth, (req, res) => {
      const updates = req.body || {};
      for (const [k, v] of Object.entries(updates)) this.setConfig(k, v);
      this._audit(ADMIN_ACTIONS.CONFIG_UPDATE, req.adminSession.token, { keys: Object.keys(updates) });
      res.json({ ok: true, config: this.getAllConfig() });
    });

    /** GET /api/admin/users/banned */
    app.get('/api/admin/users/banned', auth, (req, res) => {
      res.json({ ok: true, bannedUsers: this.getBannedUsers() });
    });

    /** POST /api/admin/users/:userId/ban */
    app.post('/api/admin/users/:userId/ban', auth, (req, res) => {
      const { reason } = req.body || {};
      this.banUser(req.params.userId, reason);
      this._audit(ADMIN_ACTIONS.USER_BAN, req.adminSession.token, { userId: req.params.userId, reason });
      res.json({ ok: true, banned: req.params.userId });
    });

    /** POST /api/admin/users/:userId/unban */
    app.post('/api/admin/users/:userId/unban', auth, (req, res) => {
      this.unbanUser(req.params.userId);
      this._audit(ADMIN_ACTIONS.USER_BAN, req.adminSession.token, { userId: req.params.userId, action: 'unban' });
      res.json({ ok: true, unbanned: req.params.userId });
    });

    /** GET /api/admin/services */
    app.get('/api/admin/services', auth, (req, res) => {
      res.json({ ok: true, services: this.listServices() });
    });

    /** POST /api/admin/cache/clear */
    app.post('/api/admin/cache/clear', auth, (req, res) => {
      this._audit(ADMIN_ACTIONS.CACHE_CLEAR, req.adminSession.token, {});
      this.emit('cache-clear-requested', { token: req.adminSession.token });
      res.json({ ok: true, message: 'Cache clear event emitted' });
    });

    return app;
  }
}

let _instance = null;
function getAdminCitadel(opts) {
  if (!_instance) _instance = new AdminCitadel(opts);
  return _instance;
}

module.exports = { AdminCitadel, getAdminCitadel, ADMIN_ACTIONS };
