'use strict';

/**
 * ArenaModeService — Battle Arena competitive model evaluation service.
 * Orchestrates arena battles, tracks win rates per model per task type,
 * and exposes a full REST API.
 */

const EventEmitter = require('events');
const { getBattleArena } = require('./battle-arena');
const crypto = require('crypto');

const DEFAULT_ARENA_CONFIGS = {
  code_generation: {
    contestants: ['claude-3-5-sonnet', 'gpt-4o', 'groq-llama'],
    rounds: 3,
    criteria: ['quality', 'speed', 'cost'],
  },
  research: {
    contestants: ['perplexity-sonar', 'claude-3-5-sonnet', 'gpt-4o'],
    rounds: 2,
    criteria: ['quality', 'accuracy'],
  },
  quick_tasks: {
    contestants: ['groq-llama', 'gpt-4o-mini', 'gemini-flash'],
    rounds: 3,
    criteria: ['speed', 'quality'],
  },
  creative: {
    contestants: ['claude-3-opus', 'gpt-4o', 'gemini-pro'],
    rounds: 2,
    criteria: ['quality', 'coherence'],
  },
};

class ArenaModeService extends EventEmitter {
  constructor(opts = {}) {
    super();
    this.arena = opts.arena || getBattleArena(opts);
    this._arenaConfigs = Object.assign({}, DEFAULT_ARENA_CONFIGS, opts.arenaConfigs || {});
    this._sessions = new Map();  // sessionId → ArenaSession
    this._winRates = new Map();  // provider:taskType → { wins, total }
    this._running = false;

    // Relay events from battle arena
    this.arena.on('battle-complete', data => {
      this._updateWinRates(data);
      this.emit('battle-complete', data);
    });
    this.arena.on('battle-started', data => this.emit('battle-started', data));
  }

  // ─── Session management ────────────────────────────────────────────────────

  /**
   * Create a new arena session.
   */
  createSession(opts = {}) {
    const sessionId = 'session_' + crypto.randomBytes(8).toString('hex');
    const session = {
      id: sessionId,
      taskType: opts.taskType || 'code_generation',
      contestants: opts.contestants || this._arenaConfigs[opts.taskType]?.contestants || [],
      rounds: opts.rounds || this._arenaConfigs[opts.taskType]?.rounds || 3,
      criteria: opts.criteria || this._arenaConfigs[opts.taskType]?.criteria || ['quality'],
      status: 'active',
      battlesRun: 0,
      createdAt: new Date().toISOString(),
      results: [],
    };
    this._sessions.set(sessionId, session);
    this.emit('session-created', { sessionId });
    return session;
  }

  getSession(id) {
    return this._sessions.get(id) || null;
  }

  listSessions() {
    return Array.from(this._sessions.values());
  }

  // ─── Battle execution ──────────────────────────────────────────────────────

  /**
   * Run an arena battle on a prompt.
   * @param {string} prompt
   * @param {object} opts — { taskType, contestants, criteria, sessionId }
   */
  async runBattle(prompt, opts = {}) {
    const taskType = opts.taskType || 'code_generation';
    const config = this._arenaConfigs[taskType] || {};
    const contestants = opts.contestants || config.contestants || ['claude-3-5-sonnet', 'gpt-4o'];
    const criteria = opts.criteria || config.criteria || ['quality', 'speed'];

    const task = { prompt, taskType, criteria, maxTokens: opts.maxTokens || 1024, systemPrompt: opts.systemPrompt };
    const result = await this.arena.startBattle(contestants, task);

    // Link to session if provided
    if (opts.sessionId) {
      const session = this._sessions.get(opts.sessionId);
      if (session) {
        session.battlesRun++;
        session.results.push({ battleId: result.id, winner: result.winner, scores: result.scores });
      }
    }

    return result;
  }

  /**
   * Run a full arena tournament (multiple rounds on the same task type).
   */
  async runTournament(prompts, opts = {}) {
    const session = this.createSession(opts);
    const tournamentResults = [];

    for (const prompt of prompts) {
      const result = await this.runBattle(prompt, { ...opts, sessionId: session.id });
      tournamentResults.push(result);
    }

    session.status = 'completed';
    session.completedAt = new Date().toISOString();

    return { session, battles: tournamentResults, leaderboard: this.getLeaderboard(opts.taskType) };
  }

  // ─── Win rate tracking ─────────────────────────────────────────────────────

  _updateWinRates(battleData) {
    if (!battleData.winner) return;
    const taskType = battleData.taskType || 'default';

    // Increment for all participants
    const battle = this.arena.getBattle(battleData.battleId);
    if (!battle) return;

    for (const contestant of battle.contestants || []) {
      const key = `${contestant}:${taskType}`;
      if (!this._winRates.has(key)) this._winRates.set(key, { wins: 0, total: 0 });
      const rate = this._winRates.get(key);
      rate.total++;
      if (contestant === battle.winner) rate.wins++;
    }
  }

  /**
   * Get win rates for all models, optionally filtered by task type.
   */
  getWinRates(taskType = null) {
    const result = {};
    for (const [key, data] of this._winRates.entries()) {
      const [model, type] = key.split(':');
      if (taskType && type !== taskType) continue;
      if (!result[model]) result[model] = {};
      result[model][type] = {
        wins: data.wins,
        total: data.total,
        winRate: data.total > 0 ? (data.wins / data.total * 100).toFixed(1) + '%' : 'N/A',
      };
    }
    return result;
  }

  getLeaderboard(taskType = null) {
    return this.arena.getLeaderboard(taskType);
  }

  // ─── Config management ─────────────────────────────────────────────────────

  setArenaConfig(taskType, config) {
    this._arenaConfigs[taskType] = { ...this._arenaConfigs[taskType], ...config };
    this.emit('config-updated', { taskType });
  }

  getArenaConfig(taskType) {
    return this._arenaConfigs[taskType] || null;
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** POST /api/arena/battle — run a quick battle */
    app.post('/api/arena/battle', async (req, res) => {
      try {
        const { prompt, taskType, contestants, criteria, maxTokens, sessionId } = req.body || {};
        if (!prompt) return res.status(400).json({ ok: false, error: 'prompt required' });
        const result = await this.runBattle(prompt, { taskType, contestants, criteria, maxTokens, sessionId });
        res.json({ ok: true, battle: result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/arena/tournament — run a multi-prompt tournament */
    app.post('/api/arena/tournament', async (req, res) => {
      try {
        const { prompts, taskType, contestants, criteria } = req.body || {};
        if (!Array.isArray(prompts) || prompts.length === 0) {
          return res.status(400).json({ ok: false, error: 'prompts array required' });
        }
        const result = await this.runTournament(prompts, { taskType, contestants, criteria });
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/arena/leaderboard */
    app.get('/api/arena/leaderboard', (req, res) => {
      const { taskType } = req.query;
      res.json({ ok: true, leaderboard: this.getLeaderboard(taskType) });
    });

    /** GET /api/arena/win-rates */
    app.get('/api/arena/win-rates', (req, res) => {
      const { taskType } = req.query;
      res.json({ ok: true, winRates: this.getWinRates(taskType) });
    });

    /** GET /api/arena/battles */
    app.get('/api/arena/battles', (req, res) => {
      const limit = parseInt(req.query.limit) || 50;
      res.json({ ok: true, battles: this.arena.listBattles(limit) });
    });

    /** GET /api/arena/battles/:id */
    app.get('/api/arena/battles/:id', (req, res) => {
      const battle = this.arena.getBattle(req.params.id);
      if (!battle) return res.status(404).json({ ok: false, error: 'Battle not found' });
      res.json({ ok: true, battle });
    });

    /** GET /api/arena/sessions */
    app.get('/api/arena/sessions', (req, res) => {
      res.json({ ok: true, sessions: this.listSessions() });
    });

    /** POST /api/arena/sessions */
    app.post('/api/arena/sessions', (req, res) => {
      const session = this.createSession(req.body || {});
      res.status(201).json({ ok: true, session });
    });

    /** GET /api/arena/configs */
    app.get('/api/arena/configs', (req, res) => {
      res.json({ ok: true, configs: this._arenaConfigs });
    });

    /** PUT /api/arena/configs/:taskType */
    app.put('/api/arena/configs/:taskType', (req, res) => {
      this.setArenaConfig(req.params.taskType, req.body || {});
      res.json({ ok: true, config: this.getArenaConfig(req.params.taskType) });
    });

    return app;
  }
}

let _instance = null;
function getArenaModeService(opts) {
  if (!_instance) _instance = new ArenaModeService(opts);
  return _instance;
}

module.exports = { ArenaModeService, getArenaModeService, DEFAULT_ARENA_CONFIGS };
