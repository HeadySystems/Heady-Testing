'use strict';

/**
 * AutonomousScheduler — Cron-based task scheduling for autonomous HeadyStack operations.
 * Uses node-cron under the hood with full task lifecycle management.
 */

const EventEmitter = require('events');
const crypto = require('crypto');

let cron;
try { cron = require('node-cron'); } catch (e) { cron = null; }

const STATUS = {
  SCHEDULED: 'scheduled',
  RUNNING: 'running',
  PAUSED: 'paused',
  COMPLETED: 'completed',
  FAILED: 'failed',
  CANCELLED: 'cancelled',
};

class AutonomousScheduler extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._tasks = new Map();    // taskId → TaskRecord
    this._jobs = new Map();     // taskId → cron.ScheduledTask
    this._history = [];         // execution history (capped)
    this._maxHistory = opts.maxHistory || 500;
  }

  // ─── Internal ──────────────────────────────────────────────────────────────

  _genId() {
    return 'task_' + crypto.randomBytes(8).toString('hex');
  }

  _record(taskId, status, meta = {}) {
    this._history.push({ taskId, status, ts: new Date().toISOString(), ...meta });
    if (this._history.length > this._maxHistory) this._history.shift();
  }

  // ─── Public API ────────────────────────────────────────────────────────────

  /**
   * Schedule a task.
   * @param {object} task
   * @param {string} task.name
   * @param {Function} task.fn — async function to call
   * @param {object} [task.meta] — arbitrary metadata
   * @param {string} cronExpr — cron expression (e.g. '* * * * *')
   * @returns {string} taskId
   */
  schedule(task, cronExpr) {
    if (!task || typeof task.fn !== 'function') throw new Error('task.fn must be a function');
    if (!cronExpr) throw new Error('cronExpr is required');

    if (cron && !cron.validate(cronExpr)) {
      throw new Error(`Invalid cron expression: ${cronExpr}`);
    }

    const taskId = task.id || this._genId();
    const record = {
      id: taskId,
      name: task.name || taskId,
      cronExpr,
      status: STATUS.SCHEDULED,
      meta: task.meta || {},
      createdAt: new Date().toISOString(),
      lastRun: null,
      nextRun: null,
      runCount: 0,
      failCount: 0,
    };

    this._tasks.set(taskId, record);

    if (cron) {
      const job = cron.schedule(cronExpr, async () => {
        record.status = STATUS.RUNNING;
        record.lastRun = new Date().toISOString();
        this.emit('task-start', { taskId, name: record.name });
        try {
          const result = await task.fn({ taskId, name: record.name, meta: record.meta });
          record.status = STATUS.SCHEDULED;
          record.runCount++;
          this._record(taskId, 'completed', { result: result !== undefined ? String(result).slice(0, 200) : undefined });
          this.emit('task-complete', { taskId, name: record.name, result });
        } catch (err) {
          record.status = STATUS.FAILED;
          record.failCount++;
          this._record(taskId, 'failed', { error: err.message });
          this.emit('task-error', { taskId, name: record.name, error: err.message });
          // Re-schedule after failure
          record.status = STATUS.SCHEDULED;
        }
      }, { scheduled: true });

      this._jobs.set(taskId, job);
    } else {
      // Fallback: simple interval-based if cron not available
      // Parse simplistic "every N minutes" from common expressions
      const intervalMs = this._cronToMs(cronExpr);
      if (intervalMs) {
        const timer = setInterval(async () => {
          record.status = STATUS.RUNNING;
          record.lastRun = new Date().toISOString();
          record.runCount++;
          this.emit('task-start', { taskId });
          try {
            await task.fn({ taskId, name: record.name, meta: record.meta });
            record.status = STATUS.SCHEDULED;
            this._record(taskId, 'completed');
            this.emit('task-complete', { taskId });
          } catch (err) {
            record.status = STATUS.SCHEDULED;
            record.failCount++;
            this._record(taskId, 'failed', { error: err.message });
            this.emit('task-error', { taskId, error: err.message });
          }
        }, intervalMs);
        if (timer.unref) timer.unref();
        this._jobs.set(taskId, { stop: () => clearInterval(timer), start: () => {}, _type: 'interval' });
      }
    }

    this._record(taskId, 'scheduled', { cronExpr, name: record.name });
    this.emit('task-scheduled', { taskId, name: record.name, cronExpr });
    return taskId;
  }

  _cronToMs(expr) {
    // Best-effort: '*/N * * * *' → N * 60000
    const m = expr.match(/^\*\/(\d+)\s+\*\s+\*\s+\*\s+\*$/);
    if (m) return parseInt(m[1], 10) * 60000;
    if (expr === '* * * * *') return 60000;
    return null;
  }

  /**
   * Cancel a scheduled task.
   */
  cancel(taskId) {
    const job = this._jobs.get(taskId);
    if (job) {
      job.stop();
      this._jobs.delete(taskId);
    }
    const record = this._tasks.get(taskId);
    if (record) {
      record.status = STATUS.CANCELLED;
      this._record(taskId, 'cancelled');
    }
    this.emit('task-cancelled', { taskId });
    return !!record;
  }

  /**
   * Pause a task (stop firing but keep record).
   */
  pause(taskId) {
    const job = this._jobs.get(taskId);
    if (job && typeof job.stop === 'function') job.stop();
    const record = this._tasks.get(taskId);
    if (record) record.status = STATUS.PAUSED;
    this.emit('task-paused', { taskId });
  }

  /**
   * Resume a paused task.
   */
  resume(taskId) {
    const job = this._jobs.get(taskId);
    if (job && typeof job.start === 'function') job.start();
    const record = this._tasks.get(taskId);
    if (record && record.status === STATUS.PAUSED) record.status = STATUS.SCHEDULED;
    this.emit('task-resumed', { taskId });
  }

  /**
   * Get all scheduled tasks.
   */
  getScheduled() {
    return Array.from(this._tasks.values());
  }

  /**
   * Get task by ID.
   */
  getTask(taskId) {
    return this._tasks.get(taskId) || null;
  }

  /**
   * Get execution history.
   */
  getHistory(taskId) {
    if (taskId) return this._history.filter(h => h.taskId === taskId);
    return this._history.slice();
  }

  /**
   * Run a task immediately (on-demand).
   */
  async runNow(taskId) {
    const record = this._tasks.get(taskId);
    if (!record) throw new Error(`Task not found: ${taskId}`);
    // We stored fn on schedule — re-attach via a scheduled action proxy
    // Since we don't keep fn reference, emit an event that callers can handle
    this.emit('run-now', { taskId, name: record.name });
    return { triggered: true, taskId };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** GET /api/scheduler/tasks */
    app.get('/api/scheduler/tasks', (req, res) => {
      res.json({ ok: true, tasks: this.getScheduled() });
    });

    /** GET /api/scheduler/tasks/:id */
    app.get('/api/scheduler/tasks/:id', (req, res) => {
      const task = this.getTask(req.params.id);
      if (!task) return res.status(404).json({ ok: false, error: 'Task not found' });
      res.json({ ok: true, task });
    });

    /** POST /api/scheduler/tasks — schedule a new task (fn must be pre-registered) */
    app.post('/api/scheduler/tasks', (req, res) => {
      try {
        const { name, cronExpr, meta } = req.body || {};
        if (!cronExpr) return res.status(400).json({ ok: false, error: 'cronExpr required' });
        // Register a no-op placeholder — real fn should be injected programmatically
        const taskId = this.schedule({ name: name || 'api-task', fn: async () => {}, meta }, cronExpr);
        res.status(201).json({ ok: true, taskId });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** DELETE /api/scheduler/tasks/:id */
    app.delete('/api/scheduler/tasks/:id', (req, res) => {
      const cancelled = this.cancel(req.params.id);
      if (!cancelled) return res.status(404).json({ ok: false, error: 'Task not found' });
      res.json({ ok: true, cancelled: req.params.id });
    });

    /** POST /api/scheduler/tasks/:id/pause */
    app.post('/api/scheduler/tasks/:id/pause', (req, res) => {
      this.pause(req.params.id);
      res.json({ ok: true, paused: req.params.id });
    });

    /** POST /api/scheduler/tasks/:id/resume */
    app.post('/api/scheduler/tasks/:id/resume', (req, res) => {
      this.resume(req.params.id);
      res.json({ ok: true, resumed: req.params.id });
    });

    /** POST /api/scheduler/tasks/:id/run-now */
    app.post('/api/scheduler/tasks/:id/run-now', async (req, res) => {
      try {
        const result = await this.runNow(req.params.id);
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/scheduler/history */
    app.get('/api/scheduler/history', (req, res) => {
      const { taskId } = req.query;
      res.json({ ok: true, history: this.getHistory(taskId) });
    });

    return app;
  }
}

// Singleton
let _instance = null;
function getScheduler(opts) {
  if (!_instance) _instance = new AutonomousScheduler(opts);
  return _instance;
}

module.exports = { AutonomousScheduler, getScheduler, STATUS };
