'use strict';

/**
 * ContinuousEmbedder — Continuous embedding pipeline using all-MiniLM-L6-v2 (384D).
 * Manages embed intervals, projection intervals, and environment capture intervals.
 * Queues text for embedding and pushes vectors to vector memory.
 */

const EventEmitter = require('events');
const crypto = require('crypto');

const MODEL_ID = 'all-MiniLM-L6-v2';
const EMBED_DIMS = 384;

const DEFAULT_INTERVALS = {
  embedIntervalMs: 5000,       // Process embed queue every 5s
  projectionIntervalMs: 30000, // Push to projection targets every 30s
  envCaptureIntervalMs: 60000, // Capture environment context every 60s
};

class ContinuousEmbedder extends EventEmitter {
  constructor(opts = {}) {
    super();
    this.model = opts.model || MODEL_ID;
    this.dims = opts.dims || EMBED_DIMS;
    this.vectorMemory = opts.vectorMemory || null;
    this.intervals = Object.assign({}, DEFAULT_INTERVALS, opts.intervals || {});

    this._queue = [];             // [{id, text, meta, priority}]
    this._processing = false;
    this._stats = {
      embedded: 0,
      projected: 0,
      errors: 0,
      queueDepth: 0,
      lastEmbedAt: null,
      lastProjectionAt: null,
      lastEnvCaptureAt: null,
    };

    this._timers = {};
    this._running = false;
    this._embeddingFn = opts.embeddingFn || null; // Optional: inject a custom embedding function
  }

  // ─── Lifecycle ─────────────────────────────────────────────────────────────

  start() {
    if (this._running) return;
    this._running = true;

    this._timers.embed = setInterval(() => this._processQueue(), this.intervals.embedIntervalMs);
    this._timers.projection = setInterval(() => this._runProjectionCycle(), this.intervals.projectionIntervalMs);
    this._timers.envCapture = setInterval(() => this._captureEnvironment(), this.intervals.envCaptureIntervalMs);

    for (const t of Object.values(this._timers)) { if (t.unref) t.unref(); }

    this.emit('started', { model: this.model, intervals: this.intervals });
  }

  stop() {
    this._running = false;
    for (const [key, timer] of Object.entries(this._timers)) {
      clearInterval(timer);
      delete this._timers[key];
    }
    this.emit('stopped');
  }

  // ─── Queue management ──────────────────────────────────────────────────────

  /**
   * Enqueue text for embedding.
   * @param {string} text
   * @param {object} [meta]
   * @param {number} [priority=0] — higher = processed first
   * @returns {string} itemId
   */
  enqueue(text, meta = {}, priority = 0) {
    if (!text || typeof text !== 'string') throw new Error('text must be a non-empty string');
    const id = meta.id || ('emb_' + crypto.randomBytes(6).toString('hex'));
    this._queue.push({ id, text, meta, priority, enqueuedAt: new Date().toISOString() });
    this._queue.sort((a, b) => b.priority - a.priority);
    this._stats.queueDepth = this._queue.length;
    this.emit('enqueued', { id, queueDepth: this._queue.length });
    return id;
  }

  /**
   * Bulk enqueue.
   */
  enqueueBatch(items) {
    const ids = [];
    for (const item of items) {
      ids.push(this.enqueue(item.text, item.meta || {}, item.priority || 0));
    }
    return ids;
  }

  clearQueue() {
    const count = this._queue.length;
    this._queue = [];
    this._stats.queueDepth = 0;
    return count;
  }

  // ─── Core embedding ────────────────────────────────────────────────────────

  async _embed(text) {
    // 1. Use injected embedding function if available
    if (this._embeddingFn) {
      return await this._embeddingFn(text);
    }

    // 2. Try sentence-transformers via Python
    try {
      const { execFileSync } = require('child_process');
      const payload = JSON.stringify({ text });
      const out = execFileSync('python3', ['-c', `
import sys, json
from sentence_transformers import SentenceTransformer
data = json.loads(sys.argv[1])
model = SentenceTransformer('all-MiniLM-L6-v2')
emb = model.encode(data['text']).tolist()
print(json.dumps(emb))
`, payload], { timeout: 15000 });
      return JSON.parse(out.toString().trim());
    } catch (e) {
      // 3. Fallback to Cloudflare/OpenAI via LLM router
      try {
        const { getLLMRouter } = require('./llm-router');
        const router = getLLMRouter();
        const result = await router.embed(text);
        return result.embedding;
      } catch (e2) {
        // 4. Zero vector fallback
        this.emit('embed-fallback', { error: e2.message });
        return Array(this.dims).fill(0);
      }
    }
  }

  async _processQueue() {
    if (this._processing || this._queue.length === 0) return;
    this._processing = true;

    const batch = this._queue.splice(0, 20); // Process up to 20 at a time
    this._stats.queueDepth = this._queue.length;

    for (const item of batch) {
      try {
        const vector = await this._embed(item.text);
        const result = {
          id: item.id,
          text: item.text,
          vector,
          dims: this.dims,
          model: this.model,
          meta: item.meta,
          embeddedAt: new Date().toISOString(),
        };

        this._stats.embedded++;
        this._stats.lastEmbedAt = result.embeddedAt;
        this.emit('embedded', result);

        // Push to vector memory if available
        if (this.vectorMemory && typeof this.vectorMemory.store === 'function') {
          await this.vectorMemory.store(item.id, vector, item.text, item.meta);
        }
      } catch (err) {
        this._stats.errors++;
        this.emit('embed-error', { id: item.id, error: err.message });
      }
    }

    this._processing = false;
  }

  // ─── Projection cycle ──────────────────────────────────────────────────────

  async _runProjectionCycle() {
    this._stats.lastProjectionAt = new Date().toISOString();
    this.emit('projection-cycle', { ts: this._stats.lastProjectionAt });
    this._stats.projected++;
  }

  // ─── Environment capture ───────────────────────────────────────────────────

  async _captureEnvironment() {
    const envContext = {
      timestamp: new Date().toISOString(),
      nodeVersion: process.version,
      memoryUsage: process.memoryUsage(),
      uptime: process.uptime(),
      env: Object.keys(process.env).length + ' env vars',
    };

    const text = JSON.stringify(envContext);
    this.enqueue(text, { type: 'env_capture', ...envContext }, -1); // low priority

    this._stats.lastEnvCaptureAt = envContext.timestamp;
    this.emit('env-captured', envContext);
  }

  // ─── Direct embed ──────────────────────────────────────────────────────────

  /**
   * Embed text immediately (bypass queue).
   */
  async embedNow(text, meta = {}) {
    const vector = await this._embed(text);
    return {
      id: meta.id || ('emb_' + crypto.randomBytes(6).toString('hex')),
      text,
      vector,
      dims: this.dims,
      model: this.model,
      meta,
      embeddedAt: new Date().toISOString(),
    };
  }

  /**
   * Semantic similarity between two texts.
   */
  async similarity(textA, textB) {
    const [vecA, vecB] = await Promise.all([this._embed(textA), this._embed(textB)]);
    return cosineSimilarity(vecA, vecB);
  }

  getStats() {
    return { ...this._stats, queueDepth: this._queue.length, running: this._running, model: this.model, dims: this.dims };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** POST /api/embedder/enqueue */
    app.post('/api/embedder/enqueue', (req, res) => {
      try {
        const { text, meta, priority } = req.body || {};
        if (!text) return res.status(400).json({ ok: false, error: 'text required' });
        const id = this.enqueue(text, meta || {}, priority || 0);
        res.json({ ok: true, id, queueDepth: this._queue.length });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/embedder/embed-now */
    app.post('/api/embedder/embed-now', async (req, res) => {
      try {
        const { text, meta } = req.body || {};
        if (!text) return res.status(400).json({ ok: false, error: 'text required' });
        const result = await this.embedNow(text, meta || {});
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/embedder/similarity */
    app.post('/api/embedder/similarity', async (req, res) => {
      try {
        const { textA, textB } = req.body || {};
        if (!textA || !textB) return res.status(400).json({ ok: false, error: 'textA and textB required' });
        const score = await this.similarity(textA, textB);
        res.json({ ok: true, similarity: score });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** POST /api/embedder/batch */
    app.post('/api/embedder/batch', (req, res) => {
      try {
        const { items } = req.body || {};
        if (!Array.isArray(items)) return res.status(400).json({ ok: false, error: 'items array required' });
        const ids = this.enqueueBatch(items);
        res.json({ ok: true, ids, queueDepth: this._queue.length });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/embedder/stats */
    app.get('/api/embedder/stats', (req, res) => {
      res.json({ ok: true, stats: this.getStats() });
    });

    /** POST /api/embedder/start */
    app.post('/api/embedder/start', (req, res) => {
      this.start();
      res.json({ ok: true, running: this._running });
    });

    /** POST /api/embedder/stop */
    app.post('/api/embedder/stop', (req, res) => {
      this.stop();
      res.json({ ok: true, running: this._running });
    });

    return app;
  }
}

// ─── Utilities ───────────────────────────────────────────────────────────────

function cosineSimilarity(a, b) {
  if (a.length !== b.length) return 0;
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  const denom = Math.sqrt(normA) * Math.sqrt(normB);
  return denom === 0 ? 0 : dot / denom;
}

let _instance = null;
function getContinuousEmbedder(opts) {
  if (!_instance) _instance = new ContinuousEmbedder(opts);
  return _instance;
}

module.exports = { ContinuousEmbedder, getContinuousEmbedder, cosineSimilarity, MODEL_ID, EMBED_DIMS };
