'use strict';

/**
 * ErrorSentinelService — Real-time error monitoring, pattern detection, and alerting.
 * Tracks error rates, recurring patterns, and provides aggregated diagnostics.
 */

const EventEmitter = require('events');
const crypto = require('crypto');

const SEVERITY = {
  DEBUG: 'debug',
  INFO: 'info',
  WARN: 'warn',
  ERROR: 'error',
  CRITICAL: 'critical',
  FATAL: 'fatal',
};

const ERROR_WINDOW_MS = 5 * 60 * 1000;   // 5-minute rolling window for rate calc
const PATTERN_THRESHOLD = 3;               // Same error 3x = pattern detected
const CRITICAL_RATE_PER_MIN = 10;         // >10 errors/min = critical alert

class ErrorSentinelService extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._errors = [];
    this._maxErrors = opts.maxErrors || 5000;
    this._patterns = new Map();              // errorKey → PatternRecord
    this._alertHandlers = [];
    this._rateCache = { count: 0, window: [] };
    this._stats = {
      totalErrors: 0,
      totalWarnings: 0,
      totalCritical: 0,
      patternsDetected: 0,
      alertsFired: 0,
    };

    this._windowMs = opts.windowMs || ERROR_WINDOW_MS;
    this._patternThreshold = opts.patternThreshold || PATTERN_THRESHOLD;
    this._criticalRatePerMin = opts.criticalRatePerMin || CRITICAL_RATE_PER_MIN;

    // Prune old errors every minute
    this._pruneInterval = setInterval(() => this._prune(), 60000);
    if (this._pruneInterval.unref) this._pruneInterval.unref();
  }

  // ─── Capture ───────────────────────────────────────────────────────────────

  /**
   * Capture an error event.
   */
  capture(error, opts = {}) {
    const severity = opts.severity || (error instanceof Error ? SEVERITY.ERROR : SEVERITY.WARN);
    const service = opts.service || opts.source || 'unknown';
    const now = new Date().toISOString();

    const entry = {
      id: 'err_' + crypto.randomBytes(6).toString('hex'),
      severity,
      service,
      message: error instanceof Error ? error.message : String(error),
      stack: error instanceof Error ? error.stack : null,
      code: opts.code || (error?.code) || null,
      context: opts.context || {},
      userId: opts.userId || null,
      requestId: opts.requestId || null,
      ts: now,
    };

    this._errors.push(entry);
    if (this._errors.length > this._maxErrors) this._errors.shift();

    // Stats
    if (severity === SEVERITY.ERROR || severity === SEVERITY.CRITICAL || severity === SEVERITY.FATAL) {
      this._stats.totalErrors++;
    }
    if (severity === SEVERITY.WARN) this._stats.totalWarnings++;
    if (severity === SEVERITY.CRITICAL || severity === SEVERITY.FATAL) this._stats.totalCritical++;

    // Rate tracking
    this._rateCache.window.push(Date.now());

    // Pattern detection
    this._detectPattern(entry);

    // Rate alert
    this._checkRateAlert();

    this.emit('error-captured', entry);

    // Trigger alert handlers
    if (severity === SEVERITY.CRITICAL || severity === SEVERITY.FATAL) {
      this._fireAlert({ type: 'critical-error', entry });
    }

    return entry.id;
  }

  /**
   * Convenience methods.
   */
  warn(msg, opts = {}) { return this.capture(msg, { ...opts, severity: SEVERITY.WARN }); }
  error(msg, opts = {}) { return this.capture(msg instanceof Error ? msg : new Error(msg), { ...opts, severity: SEVERITY.ERROR }); }
  critical(msg, opts = {}) { return this.capture(msg instanceof Error ? msg : new Error(msg), { ...opts, severity: SEVERITY.CRITICAL }); }

  // ─── Pattern detection ─────────────────────────────────────────────────────

  _detectPattern(entry) {
    const key = `${entry.service}:${entry.message.slice(0, 80)}`;
    if (!this._patterns.has(key)) {
      this._patterns.set(key, { key, count: 0, firstSeen: entry.ts, lastSeen: entry.ts, services: new Set(), severities: new Set() });
    }
    const pattern = this._patterns.get(key);
    pattern.count++;
    pattern.lastSeen = entry.ts;
    pattern.services.add(entry.service);
    pattern.severities.add(entry.severity);

    if (pattern.count === this._patternThreshold) {
      this._stats.patternsDetected++;
      this._fireAlert({ type: 'pattern-detected', pattern: { ...pattern, services: Array.from(pattern.services), severities: Array.from(pattern.severities) } });
      this.emit('pattern-detected', pattern);
    }
  }

  // ─── Rate alerting ─────────────────────────────────────────────────────────

  _checkRateAlert() {
    const now = Date.now();
    this._rateCache.window = this._rateCache.window.filter(t => now - t < 60000);
    const rate = this._rateCache.window.length;
    if (rate >= this._criticalRatePerMin) {
      this._fireAlert({ type: 'high-error-rate', rate, threshold: this._criticalRatePerMin });
      this.emit('high-error-rate', { rate });
    }
  }

  _fireAlert(alert) {
    this._stats.alertsFired++;
    for (const handler of this._alertHandlers) {
      try { handler(alert); } catch (e) { /* don't let alert handler crash sentinel */ }
    }
    this.emit('alert', alert);
  }

  /**
   * Register an alert handler.
   */
  onAlert(handler) {
    this._alertHandlers.push(handler);
    return () => { this._alertHandlers = this._alertHandlers.filter(h => h !== handler); };
  }

  // ─── Querying ──────────────────────────────────────────────────────────────

  getErrors(opts = {}) {
    let errors = this._errors.slice();
    if (opts.severity) errors = errors.filter(e => e.severity === opts.severity);
    if (opts.service) errors = errors.filter(e => e.service === opts.service);
    if (opts.since) {
      const since = new Date(opts.since).getTime();
      errors = errors.filter(e => new Date(e.ts).getTime() >= since);
    }
    const limit = opts.limit || 100;
    return errors.slice(-limit).reverse();
  }

  getErrorById(id) {
    return this._errors.find(e => e.id === id) || null;
  }

  getPatterns(minCount = 1) {
    return Array.from(this._patterns.values())
      .filter(p => p.count >= minCount)
      .map(p => ({ ...p, services: Array.from(p.services), severities: Array.from(p.severities) }))
      .sort((a, b) => b.count - a.count);
  }

  getErrorRate(windowMs = 60000) {
    const cutoff = Date.now() - windowMs;
    return this._errors.filter(e => new Date(e.ts).getTime() > cutoff).length;
  }

  getStats() {
    return {
      ...this._stats,
      recentErrors: this.getErrorRate(60000),
      recentErrors5min: this.getErrorRate(5 * 60000),
      totalStored: this._errors.length,
      activePatterns: this._patterns.size,
    };
  }

  // ─── Express middleware ────────────────────────────────────────────────────

  /**
   * Express error middleware — captures unhandled errors in routes.
   */
  expressErrorMiddleware() {
    return (err, req, res, next) => {
      this.capture(err, {
        service: 'express',
        severity: SEVERITY.ERROR,
        context: { method: req.method, url: req.url, ip: req.ip },
        requestId: req.id || req.headers['x-request-id'],
      });
      next(err);
    };
  }

  _prune() {
    const cutoff = Date.now() - 24 * 60 * 60 * 1000; // keep 24h
    this._errors = this._errors.filter(e => new Date(e.ts).getTime() > cutoff);
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** GET /api/errors */
    app.get('/api/errors', (req, res) => {
      const { severity, service, limit, since } = req.query;
      res.json({
        ok: true,
        errors: this.getErrors({ severity, service, limit: parseInt(limit) || 100, since }),
      });
    });

    /** GET /api/errors/stats */
    app.get('/api/errors/stats', (req, res) => {
      res.json({ ok: true, stats: this.getStats() });
    });

    /** GET /api/errors/patterns */
    app.get('/api/errors/patterns', (req, res) => {
      const minCount = parseInt(req.query.minCount) || 1;
      res.json({ ok: true, patterns: this.getPatterns(minCount) });
    });

    /** GET /api/errors/rate */
    app.get('/api/errors/rate', (req, res) => {
      const windowMs = parseInt(req.query.windowMs) || 60000;
      res.json({ ok: true, rate: this.getErrorRate(windowMs), windowMs });
    });

    /** GET /api/errors/:id */
    app.get('/api/errors/:id', (req, res) => {
      const error = this.getErrorById(req.params.id);
      if (!error) return res.status(404).json({ ok: false, error: 'Error not found' });
      res.json({ ok: true, error });
    });

    /** POST /api/errors — manually capture an error */
    app.post('/api/errors', (req, res) => {
      try {
        const { message, severity, service, context, code } = req.body || {};
        if (!message) return res.status(400).json({ ok: false, error: 'message required' });
        const id = this.capture(new Error(message), { severity, service, context, code });
        res.status(201).json({ ok: true, id });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    // Attach error middleware
    app.use(this.expressErrorMiddleware());

    return app;
  }
}

let _instance = null;
function getErrorSentinel(opts) {
  if (!_instance) _instance = new ErrorSentinelService(opts);
  return _instance;
}

module.exports = { ErrorSentinelService, getErrorSentinel, SEVERITY };
