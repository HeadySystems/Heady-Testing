'use strict';

/**
 * SDKRegistration — Registers and manages external SDKs and API integrations.
 * Provides a central registry with health-check, versioning, and credential management.
 */

const EventEmitter = require('events');
const crypto = require('crypto');

const SDK_STATUS = {
  REGISTERED: 'registered',
  ACTIVE: 'active',
  DEGRADED: 'degraded',
  INACTIVE: 'inactive',
  ERROR: 'error',
};

// Built-in SDK definitions
const BUILTIN_SDKS = [
  { id: 'anthropic', name: 'Anthropic Claude SDK', vendor: 'anthropic', package: '@anthropic-ai/sdk', envKey: 'ANTHROPIC_API_KEY', category: 'llm' },
  { id: 'openai', name: 'OpenAI SDK', vendor: 'openai', package: 'openai', envKey: 'OPENAI_API_KEY', category: 'llm' },
  { id: 'groq', name: 'Groq SDK', vendor: 'groq', package: 'groq-sdk', envKey: 'GROQ_API_KEY', category: 'llm' },
  { id: 'google-genai', name: 'Google Generative AI SDK', vendor: 'google', package: '@google/generative-ai', envKey: 'GOOGLE_AI_API_KEY', category: 'llm' },
  { id: 'perplexity', name: 'Perplexity API', vendor: 'perplexity', package: null, envKey: 'PERPLEXITY_API_KEY', category: 'llm', httpBase: 'https://api.perplexity.ai' },
  { id: 'cloudflare-ai', name: 'Cloudflare AI SDK', vendor: 'cloudflare', package: '@cloudflare/ai', envKey: 'CLOUDFLARE_API_TOKEN', category: 'edge' },
  { id: 'redis', name: 'Redis (ioredis)', vendor: 'redis-labs', package: 'ioredis', envKey: 'REDIS_URL', category: 'storage' },
  { id: 'postgres', name: 'PostgreSQL (pg)', vendor: 'postgresql', package: 'pg', envKey: 'DATABASE_URL', category: 'storage' },
  { id: 'pinecone', name: 'Pinecone Vector DB', vendor: 'pinecone', package: '@pinecone-database/pinecone', envKey: 'PINECONE_API_KEY', category: 'vector' },
  { id: 'weaviate', name: 'Weaviate Client', vendor: 'weaviate', package: 'weaviate-ts-client', envKey: 'WEAVIATE_URL', category: 'vector' },
  { id: 'stripe', name: 'Stripe SDK', vendor: 'stripe', package: 'stripe', envKey: 'STRIPE_SECRET_KEY', category: 'payments' },
  { id: 'sendgrid', name: 'SendGrid SDK', vendor: 'sendgrid', package: '@sendgrid/mail', envKey: 'SENDGRID_API_KEY', category: 'email' },
  { id: 'twilio', name: 'Twilio SDK', vendor: 'twilio', package: 'twilio', envKey: 'TWILIO_ACCOUNT_SID', category: 'messaging' },
  { id: 'github', name: 'GitHub Octokit', vendor: 'github', package: '@octokit/rest', envKey: 'GITHUB_TOKEN', category: 'devtools' },
  { id: 'aws-sdk', name: 'AWS SDK v3', vendor: 'amazon', package: '@aws-sdk/client-s3', envKey: 'AWS_ACCESS_KEY_ID', category: 'cloud' },
];

class SDKRegistration extends EventEmitter {
  constructor(opts = {}) {
    super();
    this._registry = new Map();   // id → SDKRecord
    this._credentials = new Map(); // id → { key, secret, ... }

    if (opts.loadBuiltins !== false) {
      for (const sdk of BUILTIN_SDKS) this.register(sdk);
    }
  }

  // ─── Registry operations ───────────────────────────────────────────────────

  /**
   * Register an SDK.
   */
  register(cfg) {
    if (!cfg.id) cfg.id = 'sdk_' + crypto.randomBytes(6).toString('hex');
    const existing = this._registry.get(cfg.id);
    const record = {
      ...cfg,
      status: SDK_STATUS.REGISTERED,
      registeredAt: existing ? existing.registeredAt : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      version: cfg.version || null,
      healthCheckedAt: null,
      healthy: null,
    };
    this._registry.set(cfg.id, record);
    this.emit('sdk-registered', { id: cfg.id, name: cfg.name });
    return cfg.id;
  }

  unregister(id) {
    const existed = this._registry.delete(id);
    this._credentials.delete(id);
    if (existed) this.emit('sdk-unregistered', { id });
    return existed;
  }

  /**
   * Store credentials for an SDK (never logged/exposed).
   */
  setCredentials(id, credentials) {
    this._credentials.set(id, credentials);
    const record = this._registry.get(id);
    if (record) {
      record.hasCredentials = true;
      record.updatedAt = new Date().toISOString();
    }
    this.emit('credentials-set', { id });
  }

  getCredentials(id) {
    return this._credentials.get(id) || null;
  }

  /**
   * Resolve credentials for an SDK: explicit creds → env vars → null.
   */
  resolveCredentials(id) {
    const explicit = this._credentials.get(id);
    if (explicit) return explicit;
    const record = this._registry.get(id);
    if (!record) return null;
    if (record.envKey) {
      const val = process.env[record.envKey];
      return val ? { apiKey: val } : null;
    }
    return null;
  }

  /**
   * Check if SDK credentials are available (from registry, env, or stored).
   */
  isConfigured(id) {
    return !!this.resolveCredentials(id);
  }

  listSDKs(opts = {}) {
    let sdks = Array.from(this._registry.values());
    if (opts.category) sdks = sdks.filter(s => s.category === opts.category);
    if (opts.status) sdks = sdks.filter(s => s.status === opts.status);
    // Never expose credentials
    return sdks.map(s => ({ ...s, configured: this.isConfigured(s.id) }));
  }

  getSDK(id) {
    const s = this._registry.get(id);
    if (!s) return null;
    return { ...s, configured: this.isConfigured(id) };
  }

  /**
   * Perform a health check on all registered SDKs.
   */
  async healthCheck(id) {
    const record = this._registry.get(id);
    if (!record) return { id, ok: false, error: 'Not registered' };

    const configured = this.isConfigured(id);
    let healthy = configured;
    let error = null;

    // Try to require the package if local
    if (record.package) {
      try {
        require.resolve(record.package);
      } catch (e) {
        healthy = false;
        error = `Package not installed: ${record.package}`;
      }
    }

    record.status = healthy ? SDK_STATUS.ACTIVE : (configured ? SDK_STATUS.DEGRADED : SDK_STATUS.INACTIVE);
    record.healthy = healthy;
    record.healthCheckedAt = new Date().toISOString();
    if (error) record.lastError = error;

    this.emit('health-checked', { id, healthy });
    return { id, ok: healthy, configured, error };
  }

  async healthCheckAll() {
    const results = [];
    for (const id of this._registry.keys()) {
      results.push(await this.healthCheck(id));
    }
    return results;
  }

  /**
   * Get a summary of SDK statuses by category.
   */
  getSummary() {
    const sdks = this.listSDKs();
    const byCategory = {};
    for (const s of sdks) {
      if (!byCategory[s.category]) byCategory[s.category] = { total: 0, configured: 0, active: 0 };
      byCategory[s.category].total++;
      if (s.configured) byCategory[s.category].configured++;
      if (s.status === SDK_STATUS.ACTIVE) byCategory[s.category].active++;
    }
    return { total: sdks.length, byCategory };
  }

  // ─── Express routes ────────────────────────────────────────────────────────

  registerRoutes(app) {
    /** GET /api/sdks */
    app.get('/api/sdks', (req, res) => {
      const { category, status } = req.query;
      res.json({ ok: true, sdks: this.listSDKs({ category, status }), summary: this.getSummary() });
    });

    /** GET /api/sdks/:id */
    app.get('/api/sdks/:id', (req, res) => {
      const sdk = this.getSDK(req.params.id);
      if (!sdk) return res.status(404).json({ ok: false, error: 'SDK not found' });
      res.json({ ok: true, sdk });
    });

    /** POST /api/sdks — register a new SDK */
    app.post('/api/sdks', (req, res) => {
      try {
        const id = this.register(req.body || {});
        res.status(201).json({ ok: true, id });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** DELETE /api/sdks/:id */
    app.delete('/api/sdks/:id', (req, res) => {
      const removed = this.unregister(req.params.id);
      res.json({ ok: removed, id: req.params.id });
    });

    /** POST /api/sdks/:id/credentials */
    app.post('/api/sdks/:id/credentials', (req, res) => {
      try {
        this.setCredentials(req.params.id, req.body);
        res.json({ ok: true, message: 'Credentials stored' });
      } catch (err) {
        res.status(400).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/sdks/:id/health */
    app.get('/api/sdks/:id/health', async (req, res) => {
      try {
        const result = await this.healthCheck(req.params.id);
        res.json({ ok: true, ...result });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    /** GET /api/sdks/health/all */
    app.get('/api/sdks/health/all', async (req, res) => {
      try {
        const results = await this.healthCheckAll();
        res.json({ ok: true, results });
      } catch (err) {
        res.status(500).json({ ok: false, error: err.message });
      }
    });

    return app;
  }
}

let _instance = null;
function getSDKRegistry(opts) {
  if (!_instance) _instance = new SDKRegistration(opts);
  return _instance;
}

module.exports = { SDKRegistration, getSDKRegistry, SDK_STATUS, BUILTIN_SDKS };
