'use strict';

/**
 * HeadyStack — YAML Loader Wrapper
 * Safe YAML parsing with schema enforcement and error normalization.
 */

let jsYaml;
try {
  jsYaml = require('js-yaml');
} catch (_) {
  jsYaml = null;
}

const fs = require('fs');
const path = require('path');

/**
 * Safely parses a YAML string.
 * Uses js-yaml's DEFAULT_SAFE_SCHEMA to prevent arbitrary code execution.
 * Falls back to a minimal key=value parser if js-yaml is not installed.
 * @param {string} str - Raw YAML string
 * @param {object} [options]
 * @param {boolean} [options.allowEmpty] - Return {} instead of throwing on empty input
 * @returns {object}
 */
function load(str, options = {}) {
  if (!str || (typeof str === 'string' && str.trim() === '')) {
    if (options.allowEmpty) return {};
    throw new Error('heady-yaml: empty input');
  }

  if (jsYaml) {
    try {
      const result = jsYaml.load(str, { schema: jsYaml.DEFAULT_SAFE_SCHEMA });
      return result == null ? {} : result;
    } catch (err) {
      throw new Error(`heady-yaml: YAML parse error — ${err.message}`);
    }
  }

  // Fallback: minimal line-based key: value parser
  const result = {};
  const lines = str.split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const colonIdx = trimmed.indexOf(':');
    if (colonIdx === -1) continue;
    const key = trimmed.slice(0, colonIdx).trim();
    let value = trimmed.slice(colonIdx + 1).trim();
    // Handle quoted values
    if ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    result[key] = value;
  }
  return result;
}

/**
 * Loads a YAML file from disk.
 * @param {string} filePath - Absolute or relative path
 * @param {object} [options]
 * @returns {object}
 */
function loadFile(filePath, options = {}) {
  const resolved = path.isAbsolute(filePath)
    ? filePath
    : path.resolve(process.cwd(), filePath);

  if (!fs.existsSync(resolved)) {
    if (options.allowMissing) return {};
    throw new Error(`heady-yaml: file not found — ${resolved}`);
  }

  const content = fs.readFileSync(resolved, 'utf8');
  return load(content, options);
}

/**
 * Dumps an object to a YAML string.
 * @param {object} obj
 * @returns {string}
 */
function dump(obj) {
  if (jsYaml) {
    return jsYaml.dump(obj, { lineWidth: 120, noRefs: true });
  }
  // Minimal fallback serializer (top-level keys only)
  return Object.entries(obj)
    .map(([k, v]) => `${k}: ${JSON.stringify(v)}`)
    .join('\n') + '\n';
}

module.exports = { load, loadFile, dump };
