'use strict';

/**
 * HeadyStack — Express Factory
 * Returns a configured Express application instance with baseline settings.
 */

const express = require('express');

/**
 * Creates and returns a configured Express app instance.
 * Baseline settings only — middleware stack is applied separately in Phase 2.
 * @param {object} [options]
 * @param {boolean} [options.trustProxy] - Enable proxy trust (default: true)
 * @param {string} [options.viewEngine] - View engine to configure (optional)
 * @param {string} [options.viewsDir] - Views directory (optional)
 * @returns {express.Application}
 */
function createApp(options = {}) {
  const app = express();

  // Trust proxy for accurate IP logging behind load balancers / Cloudflare
  const trustProxy = options.trustProxy !== false;
  if (trustProxy) {
    app.set('trust proxy', true);
  }

  // Disable X-Powered-By header
  app.disable('x-powered-by');

  // View engine (optional)
  if (options.viewEngine) {
    app.set('view engine', options.viewEngine);
  }
  if (options.viewsDir) {
    app.set('views', options.viewsDir);
  }

  // Case-sensitive and strict routing off by default for flexibility
  app.set('case sensitive routing', false);
  app.set('strict routing', false);

  // Attach metadata for introspection
  app._headyCreatedAt = new Date().toISOString();
  app._headyVersion = process.env.HEADY_VERSION || '3.0.1';

  return app;
}

module.exports = { createApp };
