'use strict';

/**
 * HeadyStack — Environment Loader
 * Loads .env file and validates critical environment variables.
 */

const fs = require('fs');
const path = require('path');

/**
 * Minimal dotenv parser — supports KEY=VALUE, quoted values, and #-comments.
 * @param {string} content
 * @returns {object}
 */
function parseDotenv(content) {
  const result = {};
  const lines = content.split(/\r?\n/);
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx === -1) continue;
    const key = trimmed.slice(0, eqIdx).trim();
    let value = trimmed.slice(eqIdx + 1).trim();
    // Strip surrounding quotes
    if ((value.startsWith('"') && value.endsWith('"')) ||
        (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    // Handle inline comments (only after unquoted values)
    const commentIdx = value.indexOf(' #');
    if (commentIdx !== -1) value = value.slice(0, commentIdx).trim();
    result[key] = value;
  }
  return result;
}

/**
 * Loads .env file from the given directory (defaults to process.cwd()).
 * Sets variables into process.env only if they are not already set.
 * @param {object} [options]
 * @param {string} [options.path] - Path to .env file
 * @param {boolean} [options.override] - Override existing env vars
 * @returns {{ loaded: boolean, path: string, vars: object }}
 */
function loadEnv(options = {}) {
  const envPath = options.path || path.resolve(process.cwd(), '.env');
  const override = options.override === true;

  if (!fs.existsSync(envPath)) {
    return { loaded: false, path: envPath, vars: {} };
  }

  const content = fs.readFileSync(envPath, 'utf8');
  const vars = parseDotenv(content);
  let loaded = 0;

  for (const [key, value] of Object.entries(vars)) {
    if (override || process.env[key] === undefined) {
      process.env[key] = value;
      loaded++;
    }
  }

  return { loaded: loaded > 0, path: envPath, vars };
}

/**
 * Validates that critical environment variables are present.
 * Throws if any required var is missing and strict=true.
 * @param {string[]} required
 * @param {object} [options]
 * @param {boolean} [options.strict]
 * @returns {{ missing: string[], present: string[] }}
 */
function validateCritical(required, options = {}) {
  const strict = options.strict !== false;
  const missing = [];
  const present = [];

  for (const key of required) {
    if (process.env[key] !== undefined && process.env[key] !== '') {
      present.push(key);
    } else {
      missing.push(key);
    }
  }

  if (strict && missing.length > 0) {
    throw new Error(`Missing critical environment variables: ${missing.join(', ')}`);
  }

  return { missing, present };
}

/**
 * Get an env var with a default value.
 * @param {string} key
 * @param {*} defaultValue
 * @returns {string|*}
 */
function get(key, defaultValue) {
  const val = process.env[key];
  return (val !== undefined && val !== '') ? val : defaultValue;
}

/**
 * Get a boolean env var.
 * @param {string} key
 * @param {boolean} [defaultValue]
 * @returns {boolean}
 */
function getBool(key, defaultValue = false) {
  const val = process.env[key];
  if (val === undefined || val === '') return defaultValue;
  return ['true', '1', 'yes', 'on'].includes(val.toLowerCase());
}

/**
 * Get an integer env var.
 * @param {string} key
 * @param {number} [defaultValue]
 * @returns {number}
 */
function getInt(key, defaultValue = 0) {
  const val = process.env[key];
  if (val === undefined || val === '') return defaultValue;
  const n = parseInt(val, 10);
  return isNaN(n) ? defaultValue : n;
}

module.exports = { loadEnv, validateCritical, parseDotenv, get, getBool, getInt };
