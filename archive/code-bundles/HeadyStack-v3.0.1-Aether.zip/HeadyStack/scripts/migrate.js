#!/usr/bin/env node
/**
 * HeadyStack Database Migration Runner
 * Applies SQL migration files from migrations/ in order.
 * Idempotent — tracks applied migrations in schema_migrations table.
 *
 * Usage:
 *   node scripts/migrate.js
 *   DATABASE_URL=postgresql://... node scripts/migrate.js
 *
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

require('dotenv').config();

const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
    console.error('[migrate] ERROR: DATABASE_URL environment variable is required');
    process.exit(1);
}

const MIGRATIONS_DIR = path.join(__dirname, '..', 'migrations');

async function ensureMigrationsTable(client) {
    await client.query(`
        CREATE TABLE IF NOT EXISTS schema_migrations (
            id          SERIAL PRIMARY KEY,
            name        VARCHAR(255) NOT NULL UNIQUE,
            applied_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
    `);
}

async function getAppliedMigrations(client) {
    const result = await client.query(
        'SELECT name FROM schema_migrations ORDER BY applied_at ASC'
    );
    return new Set(result.rows.map((r) => r.name));
}

async function runMigration(client, name, sql) {
    console.log(`[migrate] Applying: ${name}`);
    const start = Date.now();

    // Run in a transaction for safety
    await client.query('BEGIN');
    try {
        await client.query(sql);
        // Record migration (the SQL itself may have done this, use ON CONFLICT)
        await client.query(
            'INSERT INTO schema_migrations (name) VALUES ($1) ON CONFLICT (name) DO NOTHING',
            [name]
        );
        await client.query('COMMIT');
        console.log(`[migrate] ✓ ${name} (${Date.now() - start}ms)`);
    } catch (err) {
        await client.query('ROLLBACK');
        throw err;
    }
}

async function getMigrationFiles() {
    const files = fs
        .readdirSync(MIGRATIONS_DIR)
        .filter((f) => f.endsWith('.sql'))
        .sort(); // lexicographic order (001_, 002_, etc.)

    return files.map((f) => ({
        name: path.basename(f, '.sql'),
        path: path.join(MIGRATIONS_DIR, f),
    }));
}

async function main() {
    const pool = new Pool({
        connectionString: DATABASE_URL,
        ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
    });

    let client;
    try {
        client = await pool.connect();
        console.log('[migrate] Connected to database');

        // Bootstrap migrations table
        await ensureMigrationsTable(client);

        const applied = await getAppliedMigrations(client);
        const files = await getMigrationFiles();

        const pending = files.filter((f) => !applied.has(f.name));

        if (pending.length === 0) {
            console.log('[migrate] All migrations are up to date ✓');
            return;
        }

        console.log(`[migrate] Found ${pending.length} pending migration(s)`);

        for (const migration of pending) {
            const sql = fs.readFileSync(migration.path, 'utf8');
            await runMigration(client, migration.name, sql);
        }

        console.log(`[migrate] Applied ${pending.length} migration(s) successfully ✓`);

        // Print migration status
        const allApplied = await getAppliedMigrations(client);
        console.log(`[migrate] Total applied: ${allApplied.size}`);

    } catch (err) {
        console.error('[migrate] FATAL:', err.message);
        console.error(err.stack);
        process.exitCode = 1;
    } finally {
        if (client) { client.release(); }
        await pool.end();
    }
}

main();
