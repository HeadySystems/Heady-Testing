#!/usr/bin/env bash
# ============================================================
# HeadyStack v3.0.1 "Aether" — Swarm Ignition Script
# Initializes the full HeadyStack environment for a fresh deploy.
#
# Usage:
#   ./scripts/heady-swarm-ignition.sh [--env production|staging|development]
#   ./scripts/heady-swarm-ignition.sh --skip-deps --skip-migrate
#
# Options:
#   --env         Target environment (default: development)
#   --skip-deps   Skip npm install
#   --skip-docker Skip Docker Compose startup
#   --skip-migrate Skip database migrations
#   --skip-health Skip health check
#   --dry-run     Print steps without executing
#
# © 2026 HeadySystems Inc. — Proprietary
# ============================================================

set -euo pipefail

# ── Colors ────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ── Banner ────────────────────────────────────────────────────
echo -e "${PURPLE}"
echo "  ∞ HeadyStack v3.0.1 Aether — Swarm Ignition"
echo "  © 2026 HeadySystems Inc."
echo -e "${NC}"

# ── Defaults ──────────────────────────────────────────────────
ENV="development"
SKIP_DEPS=false
SKIP_DOCKER=false
SKIP_MIGRATE=false
SKIP_HEALTH=false
DRY_RUN=false
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
PORT="${PORT:-8080}"

# ── Parse Args ────────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
    case "$1" in
        --env)          ENV="$2"; shift 2 ;;
        --skip-deps)    SKIP_DEPS=true; shift ;;
        --skip-docker)  SKIP_DOCKER=true; shift ;;
        --skip-migrate) SKIP_MIGRATE=true; shift ;;
        --skip-health)  SKIP_HEALTH=true; shift ;;
        --dry-run)      DRY_RUN=true; shift ;;
        *)
            echo -e "${RED}Unknown option: $1${NC}"
            exit 1
            ;;
    esac
done

log() { echo -e "${CYAN}[ignition]${NC} $1"; }
success() { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
error() { echo -e "${RED}[✗]${NC} $1"; }
step() { echo -e "\n${BLUE}── $1 ──────────────────────────────────────────${NC}"; }

run() {
    if [[ "$DRY_RUN" == true ]]; then
        echo -e "${YELLOW}[dry-run]${NC} $*"
    else
        "$@"
    fi
}

# ── Validate Prerequisites ────────────────────────────────────
step "Checking prerequisites"

check_cmd() {
    if command -v "$1" &>/dev/null; then
        success "$1 found ($(command -v "$1"))"
    else
        error "$1 not found — please install it"
        exit 1
    fi
}

check_cmd node
check_cmd npm
check_cmd docker
check_cmd curl

NODE_VERSION=$(node --version | sed 's/v//')
MAJOR_VERSION=$(echo "$NODE_VERSION" | cut -d. -f1)

if [[ "$MAJOR_VERSION" -lt 20 ]]; then
    error "Node.js >= 20 required (found: $NODE_VERSION)"
    exit 1
fi

success "Node.js $NODE_VERSION (>= 20 required)"

# ── Environment ────────────────────────────────────────────────
step "Environment setup"

cd "$PROJECT_ROOT"
log "Project root: $PROJECT_ROOT"
log "Target environment: $ENV"

if [[ ! -f ".env" ]]; then
    if [[ -f ".env.example" ]]; then
        warn ".env not found — copying from .env.example"
        run cp .env.example .env
        warn "Please edit .env with your actual credentials before proceeding!"
        if [[ "$ENV" == "production" ]]; then
            error "Production deploy requires .env to be configured. Aborting."
            exit 1
        fi
    else
        error ".env.example not found. Cannot continue."
        exit 1
    fi
else
    success ".env file found"
fi

# ── Install Dependencies ───────────────────────────────────────
step "Node.js dependencies"

if [[ "$SKIP_DEPS" == false ]]; then
    log "Running npm ci..."
    if [[ "$ENV" == "production" ]]; then
        run npm ci --production
    else
        run npm ci
    fi
    success "Dependencies installed"
else
    warn "Skipping npm install (--skip-deps)"
fi

# ── Docker Services ───────────────────────────────────────────
step "Docker services (PostgreSQL, Redis, etc.)"

if [[ "$SKIP_DOCKER" == false ]]; then
    if ! docker info &>/dev/null 2>&1; then
        error "Docker daemon is not running. Start Docker and retry."
        exit 1
    fi

    log "Starting Docker Compose services..."
    run docker compose up -d postgres redis pgbouncer otel-collector

    log "Waiting for PostgreSQL to be ready..."
    MAX_WAIT=60
    WAITED=0
    until run docker compose exec -T postgres pg_isready -U heady -d headydb &>/dev/null 2>&1; do
        if [[ $WAITED -ge $MAX_WAIT ]]; then
            error "PostgreSQL did not become ready after ${MAX_WAIT}s"
            exit 1
        fi
        sleep 2
        WAITED=$((WAITED + 2))
        log "Waiting for PostgreSQL... (${WAITED}s)"
    done
    success "PostgreSQL is ready"

    log "Waiting for Redis to be ready..."
    WAITED=0
    until run docker compose exec -T redis redis-cli ping 2>/dev/null | grep -q PONG; do
        if [[ $WAITED -ge 30 ]]; then
            error "Redis did not become ready after 30s"
            exit 1
        fi
        sleep 1
        WAITED=$((WAITED + 1))
    done
    success "Redis is ready"

else
    warn "Skipping Docker Compose (--skip-docker)"
fi

# ── Database Migrations ───────────────────────────────────────
step "Database migrations"

if [[ "$SKIP_MIGRATE" == false ]]; then
    log "Running migrations..."
    run node scripts/migrate.js
    success "Migrations complete"
else
    warn "Skipping migrations (--skip-migrate)"
fi

# ── Start Application ─────────────────────────────────────────
step "Starting HeadyStack"

if [[ "$ENV" == "production" ]]; then
    log "Starting in production mode (NODE_ENV=production)"
    run NODE_ENV=production npm start &
    APP_PID=$!
elif [[ "$ENV" == "staging" ]]; then
    log "Starting in staging mode (NODE_ENV=staging)"
    run NODE_ENV=staging npm start &
    APP_PID=$!
else
    log "Starting in development mode (NODE_ENV=development)"
    run npm run dev &
    APP_PID=$!
fi

if [[ "$DRY_RUN" == false ]]; then
    log "App started with PID: $APP_PID"
fi

# ── Health Check ──────────────────────────────────────────────
step "Health verification"

if [[ "$SKIP_HEALTH" == false && "$DRY_RUN" == false ]]; then
    log "Waiting for HeadyStack to be healthy..."
    MAX_WAIT=60
    WAITED=0
    until curl -sf "http://localhost:${PORT}/health" &>/dev/null; do
        if [[ $WAITED -ge $MAX_WAIT ]]; then
            error "HeadyStack did not become healthy after ${MAX_WAIT}s"
            if [[ -n "${APP_PID:-}" ]]; then
                kill "$APP_PID" 2>/dev/null || true
            fi
            exit 1
        fi
        sleep 2
        WAITED=$((WAITED + 2))
        log "Waiting for health check... (${WAITED}s)"
    done

    HEALTH=$(curl -sf "http://localhost:${PORT}/health")
    success "HeadyStack is healthy: $HEALTH"

    PULSE=$(curl -sf "http://localhost:${PORT}/pulse" 2>/dev/null || echo '{}')
    log "System pulse: $PULSE"
else
    warn "Skipping health check (--skip-health or --dry-run)"
fi

# ── Summary ───────────────────────────────────────────────────
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  ∞ HeadyStack Swarm Ignition Complete!          ║${NC}"
echo -e "${GREEN}╠══════════════════════════════════════════════════╣${NC}"
echo -e "${GREEN}║${NC}  API:      http://localhost:${PORT}/api           ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}  Health:   http://localhost:${PORT}/health         ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}  Pulse:    http://localhost:${PORT}/pulse          ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}  Metrics:  http://localhost:${PORT}/metrics        ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}  MCP:      http://localhost:${PORT}/mcp            ${GREEN}║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""
