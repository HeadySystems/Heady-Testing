# Changelog

All notable changes to HeadyStack are documented here.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).  
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [3.0.1] — 2026-03-07 — "Aether" (Current)

### Added
- `heady-manager.js` thin orchestrator shell — 10-phase boot sequence replacing the God class
- `src/config/env-schema.js` — Phase 0 environment validation with strict production mode
- `src/bootstrap/config-globals.js` — Phase 1 app init, Pino logger, EventEmitter bus
- `src/bootstrap/middleware-stack.js` — Phase 2 CORS, Helmet CSP, rate limiting
- `src/bootstrap/auth-engine.js` — Phase 3 JWT HS256, refresh rotation, OAuth2 PKCE, API keys
- `src/bootstrap/vector-stack.js` — Phase 4 pgvector memory, bee swarm, buddy AI, watchdog
- `src/bootstrap/engine-wiring.js` — Phase 5 LLM adapters (Anthropic, OpenAI, Google, Groq, Perplexity)
- `src/bootstrap/pipeline-wiring.js` — Phase 6 self-healing 12-stage task pipeline
- `src/bootstrap/service-registry.js` — Phase 7 40+ service route mounts
- `src/bootstrap/inline-routes.js` — Phase 8 /health, /ready, /pulse, /metrics, /version
- `src/bootstrap/voice-relay.js` — Phase 9 WebSocket voice relay with session management
- `src/bootstrap/server-boot.js` — Phase 10 HTTP bind + graceful SIGTERM/SIGINT shutdown
- MCP server with 31 tools across 10 categories
- 24-domain bee swarm (research, coding, writing, analysis, planning, memory, ...)
- Vector memory with HNSW index (384-dim, cosine distance) via pgvector
- `heady-registry.json` — platform registry v3.0.1
- Multi-stage Dockerfile (builder → production, non-root heady user, dumb-init)
- `docker-compose.yml` with heady-manager, postgres (pgvector:pg16), redis:7-alpine, pgbouncer, otel-collector
- GitHub Actions CI/CD pipeline: lint → test → security-scan → build-docker → deploy-cloud-run
- GitHub Actions security pipeline: CodeQL, Gitleaks, npm audit, SBOM CycloneDX, Trivy
- OpenTelemetry collector config with traces + metrics + logs pipelines
- `configs/remote-resources.yaml` — all service endpoints, DB pools, feature flags, rate limits
- Initial database migration: users, vector_memories, sessions, api_keys, pipeline_tasks, audit_log
- `heady-hive-sdk` — client gateway library for programmatic access
- `scripts/heady-swarm-ignition.sh` — swarm initialization
- `scripts/migrate.js` — idempotent database migration runner
- `tests/core.test.js` — core module unit tests (32 test cases)
- `tests/resilience.test.js` — resilience, retry, circuit breaker tests
- PM2 ecosystem config (`ecosystem.config.cjs`) with cluster mode
- Full documentation suite: README, ARCHITECTURE, API, DEPLOYMENT, MCP, REPO_ROLES
- SECURITY.md, CONTRIBUTING.md
- Tooling: `.eslintrc.json`, `.prettierrc`, `tsconfig.json`, `.gitignore`, `.dockerignore`

### Changed
- **BREAKING:** Entry point renamed from `heady-server.js` to `heady-manager.js`
- **BREAKING:** Boot logic decomposed from single God class into 10 focused modules
- Environment variable `HEADY_PORT` is now an alias for `PORT` (both supported)
- Logger upgraded from console to Pino (structured JSON, levels, correlation IDs)
- Auth middleware now supports both Bearer JWT and X-Heady-Key API key headers
- Vector memory now uses namespace-scoped HNSW index partitioning
- Pipeline stages now emit OTEL spans for full distributed tracing

### Fixed
- Race condition in JWT refresh token rotation (Redis atomic SET NX)
- pgvector connection pool leak on unhandled rejection
- Voice WebSocket sessions not cleaned up on abnormal close
- Rate limiter bypass via X-Forwarded-For header spoofing
- Docker container running as root (now `heady:heady` non-root user)

### Security
- All auth endpoints rate-limited (10 req / 15 min per IP)
- Refresh tokens stored as SHA-256 hashes in Redis
- API keys stored as bcrypt hashes (cost 12) in database
- CORS restricted to configured origin whitelist
- Helmet CSP added: `default-src 'self'`
- TruffleHog secret scanning added to CI pipeline
- npm audit added to CI pipeline (high severity blocks deploy)

### Removed
- `heady-server.js` (replaced by `heady-manager.js`)
- Legacy God class (`src/HeadyGod.js`)
- `console.log` throughout codebase (replaced with Pino logger)

---

## [2.8.0] — 2025-12-15 — "Cosmos"

### Added
- Groq engine adapter (llama3-70b, mixtral, gemma2)
- Perplexity AI sonar integration (`sonar-large-online`)
- Initial MCP server (18 tools)
- PgBouncer connection pooling

### Changed
- Node.js minimum version raised from 18 to 20
- Redis client upgraded from `redis` to `ioredis`

### Fixed
- Memory leak in long-running agent sessions
- Stripe webhook signature verification on production HTTPS

---

## [2.5.0] — 2025-09-01 — "Nebula"

### Added
- Google Gemini engine (gemini-1.5-pro)
- 16-domain bee swarm (8 new domains added)
- pgvector integration (replacing in-memory vector store)
- Self-healing watchdog

### Changed
- Pipeline expanded from 8 to 12 stages
- Auth upgraded to JWT + refresh rotation (from session cookies)

---

## [2.0.0] — 2025-06-01 — "Horizon"

### Added
- OpenAI GPT-4o engine
- Anthropic Claude engine
- 8-domain bee swarm
- 8-stage task pipeline
- REST API (30 endpoints)
- PostgreSQL persistence
- Docker support

### Breaking Changes
- Complete rewrite from v1 monolith
- New authentication system (JWT)
- New API design (`/api/*` prefix)

---

## [1.0.0] — 2025-01-01 — "Genesis"

Initial release. Single-LLM chatbot with basic Express server.

---

[3.0.1]: https://github.com/HeadyMe/HeadyStack/compare/v2.8.0...v3.0.1
[2.8.0]: https://github.com/HeadyMe/HeadyStack/compare/v2.5.0...v2.8.0
[2.5.0]: https://github.com/HeadyMe/HeadyStack/compare/v2.0.0...v2.5.0
[2.0.0]: https://github.com/HeadyMe/HeadyStack/compare/v1.0.0...v2.0.0
[1.0.0]: https://github.com/HeadyMe/HeadyStack/releases/tag/v1.0.0
