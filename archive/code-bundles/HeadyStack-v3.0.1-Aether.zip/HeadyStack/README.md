# HeadyStack v3.0.1 "Aether"

> **Heady™ Autonomous Multi-Agent AI Platform**  
> 3D Vector Space + Sacred Geometry Orchestration

[![Node.js](https://img.shields.io/badge/Node.js-≥20.0.0-brightgreen)](https://nodejs.org)
[![Version](https://img.shields.io/badge/version-3.0.1--Aether-blueviolet)](./CHANGELOG.md)
[![License](https://img.shields.io/badge/license-PROPRIETARY-red)](./LICENSE)
[![Docker](https://img.shields.io/badge/Docker-ready-blue)](./Dockerfile)

---

## Overview

HeadyStack is a production-grade autonomous AI orchestration platform. It coordinates multiple LLM engines (Anthropic, OpenAI, Google, Groq, Perplexity), a 24-domain bee swarm, a 12-stage task pipeline, vector memory via pgvector, and 31 MCP tools — all wired together through a 10-phase boot sequence.

```
┌─────────────────────────────────────────────────────────────────┐
│                    HeadyStack v3.0.1 "Aether"                   │
├──────────────────────┬──────────────────────────────────────────┤
│  INTERFACE / EDGE    │  REST API  │  MCP Server  │  WS Voice    │
├──────────────────────┴──────────────────────────────────────────┤
│  GATEWAY / ROUTING   │  HeadyAuth  │  Rate Limit  │  CORS/CSP  │
├──────────────────────────────────────────────────────────────────┤
│  EXECUTION / MODEL   │  Anthropic │ OpenAI │ Groq │ Gemini      │
│                      │  Bee Swarm (24 domains)                   │
│                      │  12-Stage Task Pipeline                   │
├──────────────────────────────────────────────────────────────────┤
│  MEMORY / PERSISTENCE│  pgvector  │  Redis  │  PostgreSQL 16    │
├──────────────────────────────────────────────────────────────────┤
│  OBSERVABILITY       │  OpenTelemetry  │  Pino  │  /metrics     │
└──────────────────────────────────────────────────────────────────┘
```

---

## Quick Start

### Prerequisites

- Node.js ≥ 20.0.0
- Docker + Docker Compose (for full stack)
- PostgreSQL 16 with pgvector extension
- Redis 7

### Docker Compose (Recommended)

```bash
# Clone repository
git clone https://github.com/HeadyMe/HeadyStack
cd HeadyStack

# Configure environment
cp .env.example .env
# Edit .env and fill in your API keys

# Start all services
npm run compose:up

# Verify health
npm run health
```

### Manual (Node.js only)

```bash
# Install dependencies
npm install

# Configure environment
cp .env.example .env

# Run database migrations
npm run migrate

# Start in development mode (hot reload)
npm run dev

# Start in production mode
npm start
```

### Docker only

```bash
npm run docker:build
npm run docker:run
```

---

## Boot Phases

HeadyStack boots in 10 sequential phases orchestrated by `heady-manager.js`:

| Phase | Module | Responsibility |
|-------|--------|----------------|
| 0 | `src/config/env-schema.js` | Environment validation (strict in production) |
| 1 | `src/bootstrap/config-globals.js` | Express app, Pino logger, event bus, secrets |
| 2 | `src/bootstrap/middleware-stack.js` | CORS, Helmet CSP, rate limiting, body parsing |
| 3 | `src/bootstrap/auth-engine.js` | JWT, refresh tokens, OAuth2, API keys |
| 4 | `src/bootstrap/vector-stack.js` | pgvector memory, bee swarm, buddy AI, watchdog |
| 5 | `src/bootstrap/engine-wiring.js` | LLM engine adapters, tool routers |
| 6 | `src/bootstrap/pipeline-wiring.js` | 12-stage pipeline with self-healing |
| 7 | `src/bootstrap/service-registry.js` | All 40+ service route handlers |
| 8 | `src/bootstrap/inline-routes.js` | /health, /ready, /pulse, /metrics |
| 9 | `src/bootstrap/voice-relay.js` | WebSocket voice sessions |
| 10 | `src/bootstrap/server-boot.js` | HTTP bind + graceful shutdown |

---

## API Endpoints

### Core

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Liveness probe |
| GET | `/ready` | Readiness probe |
| GET | `/pulse` | Deep system status |
| GET | `/metrics` | Prometheus metrics |
| GET | `/version` | Version info |

### Authentication

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Get JWT + refresh token |
| POST | `/api/auth/refresh` | Refresh access token |
| POST | `/api/auth/logout` | Revoke session |
| GET | `/api/auth/oauth/:provider` | OAuth2 flow |

### AI Services

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/chat` | Chat with best-fit LLM |
| POST | `/api/chat/stream` | Streaming chat |
| POST | `/api/agents/spawn` | Spawn autonomous agent |
| GET | `/api/agents` | List active agents |
| POST | `/api/bees/:domain` | Invoke bee agent |
| POST | `/api/pipeline/enqueue` | Queue pipeline task |

### Memory

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/memory` | Store vector memory |
| GET | `/api/memory/search` | Semantic search |
| DELETE | `/api/memory/:id` | Delete memory |

### MCP Server

| Method | Path | Description |
|--------|------|-------------|
| GET | `/mcp` | MCP server info |
| POST | `/mcp/tools/call` | Invoke MCP tool |
| GET | `/mcp/tools/list` | List all 31 tools |

See [docs/API.md](docs/API.md) for the complete reference.

---

## MCP Tools (31 total)

HeadyStack implements the Model Context Protocol (MCP) server with 31 tools:

| Category | Tools |
|----------|-------|
| Chat | `heady_chat` |
| Memory | `heady_memory_store`, `heady_memory_search`, `heady_memory_delete` |
| Bees | `heady_bee_invoke`, `heady_bee_list` |
| Pipeline | `heady_pipeline_enqueue`, `heady_pipeline_status` |
| Agents | `heady_agent_spawn`, `heady_agent_list`, `heady_agent_terminate` |
| Tools | `heady_tool_execute`, `heady_tool_list` |
| Files | `heady_file_upload`, `heady_file_search` |
| Notion | `heady_notion_page_create`, `heady_notion_page_read`, `heady_notion_db_query` |
| GitHub | `heady_github_repo_read`, `heady_github_file_read`, `heady_github_issue_create`, `heady_github_pr_create` |
| Search | `heady_perplexity_search` |
| Cloudflare | `heady_cloudflare_dns_list`, `heady_cloudflare_dns_create`, `heady_cloudflare_zone_purge` |
| Render | `heady_render_deploy`, `heady_render_service_list` |
| Stripe | `heady_stripe_customer_create`, `heady_stripe_subscription_list` |
| System | `heady_system_pulse` |

See [docs/MCP.md](docs/MCP.md) for full schemas.

---

## Deployment

### Google Cloud Run

```bash
# Authenticate
gcloud auth login
gcloud config set project YOUR_PROJECT_ID

# Build and push
docker build -t gcr.io/YOUR_PROJECT/headystack:3.0.1 .
docker push gcr.io/YOUR_PROJECT/headystack:3.0.1

# Deploy
gcloud run deploy headystack \
  --image gcr.io/YOUR_PROJECT/headystack:3.0.1 \
  --region us-central1 \
  --min-instances 1 \
  --max-instances 20 \
  --memory 2Gi \
  --cpu 2
```

### CI/CD (GitHub Actions)

Push to `main` triggers the full pipeline:
1. Lint + test
2. Security scan (TruffleHog, npm audit)
3. Docker build + push to GCR
4. Trivy container scan
5. Deploy to Cloud Run

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) for detailed deployment guides.

---

## Environment Variables

See [.env.example](.env.example) for the complete reference with descriptions.

**Required for production:**

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | PostgreSQL connection string |
| `REDIS_URL` | Redis connection URL |
| `JWT_SECRET` | JWT signing secret (≥32 chars) |
| `JWT_REFRESH_SECRET` | Refresh token secret |
| `HEADY_API_KEY` | Platform API key |
| `ANTHROPIC_API_KEY` | Claude API key |

---

## Project Structure

```
HeadyStack/
├── heady-manager.js          # Thin orchestrator entry point
├── package.json
├── Dockerfile
├── docker-compose.yml
├── heady-registry.json       # Platform registry v3.0.1
├── .env.example
├── src/
│   ├── config/
│   │   └── env-schema.js     # Environment validation
│   ├── bootstrap/            # 10 boot phase modules
│   │   ├── config-globals.js
│   │   ├── middleware-stack.js
│   │   ├── auth-engine.js
│   │   ├── vector-stack.js
│   │   ├── engine-wiring.js
│   │   ├── pipeline-wiring.js
│   │   ├── service-registry.js
│   │   ├── inline-routes.js
│   │   ├── voice-relay.js
│   │   └── server-boot.js
│   └── routes/
│       └── registry.js
├── configs/
│   ├── remote-resources.yaml
│   └── observability/
│       └── otel-config.yml
├── migrations/
│   └── 001_initial_schema.sql
├── docs/
│   ├── ARCHITECTURE.md
│   ├── API.md
│   ├── DEPLOYMENT.md
│   ├── MCP.md
│   └── REPO_ROLES.md
├── heady-hive-sdk/           # Client SDK
│   ├── lib/gateway.js
│   └── package.json
├── scripts/
│   ├── migrate.js
│   └── heady-swarm-ignition.sh
├── tests/
│   ├── core.test.js
│   └── resilience.test.js
└── .github/
    └── workflows/
        ├── deploy.yml
        └── security-scan.yml
```

---

## Architecture

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the full 5-layer architecture with data flow diagrams.

---

## Security

See [SECURITY.md](SECURITY.md) for the vulnerability disclosure policy.

---

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for development guidelines.

---

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history.

---

## License

© 2026 HeadySystems Inc. — Proprietary. All rights reserved.
