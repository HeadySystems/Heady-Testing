# Contributing to HeadyStack

**© 2026 HeadySystems Inc. — Proprietary**

HeadyStack is proprietary software. Contributions are welcome from authorized team members and invited collaborators only.

---

## Development Setup

### Prerequisites

- Node.js ≥ 20.0.0 (use `nvm` or `fnm` for version management)
- Docker + Docker Compose (for full local stack)
- Git with SSH key configured for `github.com/HeadyMe`
- Access to at least one LLM API key (Anthropic recommended for testing)

### First-Time Setup

```bash
# Clone primary remote
git clone git@github.com:HeadyMe/HeadyStack.git
cd HeadyStack

# Install dependencies
npm install

# Copy and configure environment
cp .env.example .env
# Fill in at minimum: DATABASE_URL, REDIS_URL, JWT_SECRET, JWT_REFRESH_SECRET, ANTHROPIC_API_KEY

# Start PostgreSQL + Redis via Docker
docker compose up -d postgres redis

# Run migrations
npm run migrate

# Start dev server (hot reload)
npm run dev
```

---

## Code Style

HeadyStack uses ESLint + Prettier for consistent code style.

```bash
# Lint all source files
npm run lint

# Auto-fix lint issues
npm run lint -- --fix

# Format all files
npx prettier --write "src/**/*.js"
```

### Rules Summary

- **ESLint:** `eslint:recommended` + no-console (use logger), no-unused-vars, eqeqeq
- **Prettier:** single quotes, 2-space indent, 100-char line length, trailing commas
- **CommonJS:** This codebase uses `require/module.exports` (not ESM `import/export`)
- **`'use strict'`** at the top of every module
- **No `console.log`** — use `logger.info()`, `logger.debug()`, etc.
- **Error handling:** Never swallow errors silently; always log with context

---

## Architecture Principles

Before writing code, read [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

Key rules:
1. **Each bootstrap module exports a function** that takes `(app, { ...deps })` and returns what subsequent phases need
2. **No circular dependencies** between bootstrap modules
3. **Critical failures throw** — non-critical failures emit events and log
4. **Use the event bus** (`eventBus.emit()`) for cross-cutting concerns, not direct coupling
5. **All DB queries go through pool** — never create ad-hoc connections
6. **Vector memory namespaces are sacred** — always validate namespace ownership
7. **LLM calls are wrapped** in the engine adapter layer — don't call Anthropic/OpenAI directly in route handlers

---

## Testing

```bash
# Run all tests
npm test

# Run specific test file
node --test tests/core.test.js

# Run with verbose output
node --test --reporter spec tests/

# Test with coverage (Node.js built-in)
node --test --experimental-test-coverage tests/
```

### Test Guidelines

- Tests live in `tests/` with `.test.js` suffix
- Use Node.js built-in `node:test` module (no Jest/Mocha)
- Unit tests must not make real network calls — mock LLM APIs
- Integration tests require local Docker services (postgres + redis)
- Name tests descriptively: `it('stores vector and retrieves by semantic similarity', ...)`
- Every new feature needs at least one test
- Resilience tests cover retry logic, circuit breakers, and graceful degradation

---

## Branch Workflow

See [docs/REPO_ROLES.md](docs/REPO_ROLES.md) for the full branching strategy.

```bash
# Create feature branch from latest main
git fetch heady-sys
git checkout -b feature/my-feature heady-sys/main

# Commit with conventional commit messages
git commit -m "feat(auth): add OAuth2 PKCE for Google provider"
git commit -m "fix(pipeline): handle stage 6 timeout without crashing"
git commit -m "chore(deps): upgrade jsonwebtoken to 9.0.2"
git commit -m "docs(api): document /api/memory/search query params"

# Push and open PR
git push heady-sys feature/my-feature
```

### Conventional Commit Types

| Type | When |
|------|------|
| `feat` | New feature |
| `fix` | Bug fix |
| `chore` | Maintenance, deps, CI |
| `docs` | Documentation only |
| `refactor` | Code restructure (no behavior change) |
| `test` | Test additions/fixes |
| `perf` | Performance improvement |
| `security` | Security fix |

---

## Pull Request Process

1. Branch from `heady-sys/main` (not from another feature branch)
2. Keep PRs focused — one logical change per PR
3. Write a clear PR description: what, why, how, how to test
4. Ensure all CI checks pass (lint, test, security scan, docker build)
5. Self-review your diff before requesting review
6. At least 1 approving review required for merge to `main`
7. Squash-and-merge for features; merge commit for releases
8. Delete branch after merge

---

## Environment Variables

When adding a new environment variable:

1. Add it to `.env.example` with a description
2. Add validation in `src/config/env-schema.js` (mark required or optional)
3. Document in `README.md` environment variables table
4. Add to the GitHub Actions secrets list in `.github/workflows/deploy.yml` if needed for CI

---

## Adding a New Service Route

1. Create `src/routes/your-service.js` with an Express Router
2. Register it in `src/routes/registry.js`
3. Add entry to `heady-registry.json` under `services.api`
4. Add MCP tool(s) in `src/mcp/tools/` if appropriate
5. Document in `docs/API.md`
6. Write tests in `tests/`

---

## Adding a New MCP Tool

1. Create tool definition in `src/mcp/tools/your-tool.js`
2. Register in `src/mcp/registry.js`
3. Add to `heady-registry.json` under `architecture.mcpTools`
4. Document in `docs/MCP.md`
5. Update tool count in `README.md`

---

## Adding a New Bee Domain

1. Create bee handler in `src/bees/your-domain.js`
2. Register in `src/bees/registry.js`
3. Add to `heady-registry.json` under `architecture.beeDomains`
4. Document in `docs/ARCHITECTURE.md`

---

## Releasing

Only maintainers with admin access cut releases. See `docs/REPO_ROLES.md` for the release protocol.

---

## Questions

Open a discussion in the GitHub repository or reach out via the team channel.
