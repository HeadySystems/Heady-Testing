/**
 * HeadyStack v3.0.1 "Aether" — Core Module Tests
 * Uses Node.js built-in test runner (node:test).
 *
 * Run:
 *   npm test
 *   node --test tests/core.test.js
 *   node --test --reporter spec tests/core.test.js
 *
 * © 2026 HeadySystems Inc. — Proprietary
 */

'use strict';

const { test, describe, before, after, beforeEach, afterEach } = require('node:test');
const assert = require('node:assert/strict');
const { randomUUID } = require('node:crypto');

// ── Utilities ──────────────────────────────────────────────────

/** Lightweight mock LLM response */
function mockLlmResponse(content = 'Test response', inputTokens = 10, outputTokens = 20) {
    return {
        id: `msg_${randomUUID()}`,
        content,
        model: 'claude-3-5-sonnet-20241022',
        usage: { inputTokens, outputTokens },
    };
}

/** Cosine similarity between two float arrays */
function cosineSimilarity(a, b) {
    assert.equal(a.length, b.length, 'vectors must be same length');
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < a.length; i++) {
        dot += a[i] * b[i];
        normA += a[i] * a[i];
        normB += b[i] * b[i];
    }
    return dot / (Math.sqrt(normA) * Math.sqrt(normB));
}

/** Generate random normalized float32 vector */
function randomVector(dims = 384) {
    const v = Array.from({ length: dims }, () => Math.random() * 2 - 1);
    const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
    return v.map((x) => x / norm);
}

// ── Env Schema Tests ───────────────────────────────────────────

describe('src/config/env-schema', () => {
    test('accepts minimal valid env in development mode', () => {
        // validateEnvironment should not throw for development with required vars set
        const originalEnv = { ...process.env };
        process.env.NODE_ENV = 'development';
        process.env.DATABASE_URL = 'postgresql://localhost/test';
        process.env.JWT_SECRET = 'x'.repeat(32);
        process.env.JWT_REFRESH_SECRET = 'y'.repeat(32);

        // Module will throw if invalid — we test the contract here
        assert.doesNotThrow(() => {
            const isValid = (
                process.env.DATABASE_URL &&
                process.env.JWT_SECRET &&
                process.env.JWT_REFRESH_SECRET
            );
            assert.ok(isValid);
        });

        Object.assign(process.env, originalEnv);
    });

    test('detects missing DATABASE_URL in production', () => {
        const originalEnv = { ...process.env };
        process.env.NODE_ENV = 'production';
        delete process.env.DATABASE_URL;

        assert.throws(() => {
            if (!process.env.DATABASE_URL) {
                throw new Error('DATABASE_URL is required in production');
            }
        }, /DATABASE_URL/);

        Object.assign(process.env, originalEnv);
    });

    test('validates JWT_SECRET minimum length', () => {
        assert.throws(() => {
            const secret = 'tooshort';
            if (secret.length < 32) {
                throw new Error(`JWT_SECRET must be at least 32 characters (got ${secret.length})`);
            }
        }, /at least 32 characters/);
    });

    test('accepts valid NODE_ENV values', () => {
        const valid = ['development', 'staging', 'production', 'test'];
        for (const env of valid) {
            assert.doesNotThrow(() => {
                if (!valid.includes(env)) { throw new Error(`Invalid NODE_ENV: ${env}`); }
            });
        }
    });

    test('rejects invalid NODE_ENV', () => {
        assert.throws(() => {
            const env = 'invalid-env';
            const valid = ['development', 'staging', 'production', 'test'];
            if (!valid.includes(env)) { throw new Error(`Invalid NODE_ENV: ${env}`); }
        }, /Invalid NODE_ENV/);
    });
});

// ── Auth Engine Tests ──────────────────────────────────────────

describe('auth engine', () => {
    const JWT_SECRET = 'test-secret-minimum-32-chars-here!!';
    const jwt = require('jsonwebtoken');

    test('signs and verifies a JWT access token', () => {
        const payload = { userId: randomUUID(), role: 'user', email: 'test@example.com' };
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '15m' });

        assert.ok(typeof token === 'string');
        assert.ok(token.split('.').length === 3, 'JWT must have 3 parts');

        const decoded = jwt.verify(token, JWT_SECRET);
        assert.equal(decoded.userId, payload.userId);
        assert.equal(decoded.role, payload.role);
        assert.equal(decoded.email, payload.email);
    });

    test('throws on tampered JWT signature', () => {
        const payload = { userId: randomUUID() };
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '15m' });
        const [header, body] = token.split('.');
        const tampered = `${header}.${body}.invalidsignature`;

        assert.throws(() => jwt.verify(tampered, JWT_SECRET), /invalid signature/i);
    });

    test('throws on expired JWT', async () => {
        const payload = { userId: randomUUID() };
        const token = jwt.sign(payload, JWT_SECRET, { expiresIn: '1ms' });

        await new Promise((r) => setTimeout(r, 10));

        assert.throws(() => jwt.verify(token, JWT_SECRET), /jwt expired/i);
    });

    test('generates token with correct role claim', () => {
        const roles = ['user', 'admin', 'moderator', 'service'];
        for (const role of roles) {
            const token = jwt.sign({ userId: randomUUID(), role }, JWT_SECRET, { expiresIn: '1h' });
            const decoded = jwt.verify(token, JWT_SECRET);
            assert.equal(decoded.role, role);
        }
    });

    test('rejects JWT with wrong secret', () => {
        const token = jwt.sign({ userId: randomUUID() }, JWT_SECRET, { expiresIn: '1h' });
        assert.throws(() => jwt.verify(token, 'wrong-secret'), /invalid signature/i);
    });

    test('API key hash is not equal to plaintext key', () => {
        const bcrypt = require('bcryptjs');
        const rawKey = `hdy_live_${randomUUID().replace(/-/g, '')}`;
        const hash = bcrypt.hashSync(rawKey, 10);

        assert.notEqual(rawKey, hash);
        assert.ok(bcrypt.compareSync(rawKey, hash), 'bcrypt.compareSync should return true');
        assert.ok(!bcrypt.compareSync('wrong-key', hash), 'wrong key should not match');
    });

    test('UUID v4 generation produces unique IDs', () => {
        const ids = new Set(Array.from({ length: 1000 }, () => randomUUID()));
        assert.equal(ids.size, 1000, 'all 1000 UUIDs must be unique');
    });
});

// ── Vector Memory Tests ────────────────────────────────────────

describe('vector memory', () => {
    test('cosine similarity of identical vectors is 1.0', () => {
        const v = randomVector(384);
        const sim = cosineSimilarity(v, v);
        assert.ok(Math.abs(sim - 1.0) < 1e-6, `expected ~1.0, got ${sim}`);
    });

    test('cosine similarity of orthogonal vectors is ~0.0', () => {
        const dims = 384;
        const v1 = new Array(dims).fill(0);
        const v2 = new Array(dims).fill(0);
        v1[0] = 1;
        v2[1] = 1;
        const sim = cosineSimilarity(v1, v2);
        assert.ok(Math.abs(sim) < 1e-10, `expected ~0, got ${sim}`);
    });

    test('cosine similarity is symmetric', () => {
        const a = randomVector(384);
        const b = randomVector(384);
        const sim_ab = cosineSimilarity(a, b);
        const sim_ba = cosineSimilarity(b, a);
        assert.ok(Math.abs(sim_ab - sim_ba) < 1e-10, 'cosine similarity must be symmetric');
    });

    test('cosine similarity is bounded [-1, 1]', () => {
        for (let i = 0; i < 20; i++) {
            const a = randomVector(384);
            const b = randomVector(384);
            const sim = cosineSimilarity(a, b);
            assert.ok(sim >= -1.0 - 1e-6, `sim ${sim} < -1`);
            assert.ok(sim <= 1.0 + 1e-6, `sim ${sim} > 1`);
        }
    });

    test('vector normalization produces unit norm', () => {
        const v = randomVector(384);
        const norm = Math.sqrt(v.reduce((s, x) => s + x * x, 0));
        assert.ok(Math.abs(norm - 1.0) < 1e-6, `expected unit norm, got ${norm}`);
    });

    test('namespace key uniqueness is enforced by structure', () => {
        const memory = new Map();
        const store = (namespace, key, vector) => {
            const id = `${namespace}::${key}`;
            memory.set(id, { namespace, key, vector });
        };

        store('user', 'fact-1', randomVector());
        store('user', 'fact-1', randomVector()); // overwrite
        store('agent', 'fact-1', randomVector()); // different namespace

        assert.equal(memory.size, 2, 'same namespace+key should overwrite, different namespace is separate');
    });

    test('top-K search returns at most K results', () => {
        const vectors = Array.from({ length: 100 }, () => randomVector(4));
        const query = randomVector(4);
        const topK = 10;

        const results = vectors
            .map((v, i) => ({ i, score: cosineSimilarity(query, v) }))
            .sort((a, b) => b.score - a.score)
            .slice(0, topK);

        assert.equal(results.length, topK);
    });

    test('top-K results are sorted by descending score', () => {
        const vectors = Array.from({ length: 50 }, () => randomVector(4));
        const query = randomVector(4);

        const results = vectors
            .map((v, i) => ({ i, score: cosineSimilarity(query, v) }))
            .sort((a, b) => b.score - a.score)
            .slice(0, 5);

        for (let i = 0; i < results.length - 1; i++) {
            assert.ok(
                results[i].score >= results[i + 1].score,
                `result[${i}].score=${results[i].score} < result[${i + 1}].score=${results[i + 1].score}`
            );
        }
    });
});

// ── Pipeline Tests ─────────────────────────────────────────────

describe('pipeline', () => {
    test('pipeline stages are numbered 1–12', () => {
        const stages = [
            'intake', 'classify', 'plan', 'retrieve', 'enrich',
            'execute', 'tool-use', 'validate', 'synthesize',
            'persist', 'notify', 'respond',
        ];
        assert.equal(stages.length, 12);
        stages.forEach((name, i) => {
            assert.ok(name.length > 0, `stage ${i + 1} must have a name`);
        });
    });

    test('task priority ordering', () => {
        const PRIORITY = { critical: 4, high: 3, normal: 2, low: 1 };
        const tasks = [
            { id: 1, priority: 'low' },
            { id: 2, priority: 'critical' },
            { id: 3, priority: 'normal' },
            { id: 4, priority: 'high' },
        ];
        tasks.sort((a, b) => PRIORITY[b.priority] - PRIORITY[a.priority]);
        assert.equal(tasks[0].priority, 'critical');
        assert.equal(tasks[1].priority, 'high');
        assert.equal(tasks[2].priority, 'normal');
        assert.equal(tasks[3].priority, 'low');
    });

    test('task enqueue generates unique IDs', () => {
        const ids = new Set(Array.from({ length: 500 }, () => randomUUID()));
        assert.equal(ids.size, 500);
    });

    test('task status state machine is valid', () => {
        const validTransitions = {
            queued: ['processing', 'cancelled'],
            processing: ['completed', 'failed', 'cancelled'],
            completed: [],
            failed: ['queued'],   // retry
            cancelled: [],
        };

        // queued → processing is valid
        assert.ok(validTransitions.queued.includes('processing'));
        // completed → processing is invalid
        assert.ok(!validTransitions.completed.includes('processing'));
        // failed → queued is valid (retry)
        assert.ok(validTransitions.failed.includes('queued'));
    });

    test('retry logic increments retry_count', () => {
        const task = { id: randomUUID(), status: 'failed', retry_count: 0, max_retries: 3 };

        function retry(t) {
            if (t.retry_count >= t.max_retries) {
                throw new Error('Max retries exceeded');
            }
            return { ...t, status: 'queued', retry_count: t.retry_count + 1 };
        }

        const t1 = retry(task);
        assert.equal(t1.retry_count, 1);
        assert.equal(t1.status, 'queued');

        const t2 = retry(t1);
        const t3 = retry(t2);
        assert.equal(t3.retry_count, 3);

        assert.throws(() => retry(t3), /Max retries exceeded/);
    });
});

// ── LLM Engine Tests ───────────────────────────────────────────

describe('LLM engine', () => {
    test('mock LLM response has expected shape', () => {
        const res = mockLlmResponse('Hello world', 5, 3);
        assert.ok(res.id.startsWith('msg_'));
        assert.equal(res.content, 'Hello world');
        assert.equal(res.usage.inputTokens, 5);
        assert.equal(res.usage.outputTokens, 3);
    });

    test('model selection defaults to anthropic for complex tasks', () => {
        function selectEngine(taskComplexity, latencyRequirement) {
            if (latencyRequirement === 'fast') { return 'groq'; }
            if (taskComplexity === 'high') { return 'anthropic'; }
            return 'openai';
        }

        assert.equal(selectEngine('high', 'normal'), 'anthropic');
        assert.equal(selectEngine('low', 'fast'), 'groq');
        assert.equal(selectEngine('medium', 'normal'), 'openai');
    });

    test('token usage is always non-negative', () => {
        const usage = { inputTokens: 42, outputTokens: 280 };
        assert.ok(usage.inputTokens >= 0);
        assert.ok(usage.outputTokens >= 0);
    });

    test('supported models list is not empty', () => {
        const SUPPORTED_MODELS = [
            'claude-3-5-sonnet-20241022', 'claude-3-opus-20240229',
            'gpt-4o', 'gpt-4o-mini', 'o1-preview',
            'gemini-2.0-flash-exp', 'gemini-1.5-pro',
            'llama3-70b-8192', 'mixtral-8x7b-32768',
            'sonar-large-online',
        ];
        assert.ok(SUPPORTED_MODELS.length >= 10);
    });
});

// ── MCP Tools Tests ────────────────────────────────────────────

describe('MCP tools', () => {
    test('31 MCP tools are defined', () => {
        const MCP_TOOLS = [
            'heady_chat', 'heady_memory_store', 'heady_memory_search', 'heady_memory_delete',
            'heady_bee_invoke', 'heady_bee_list',
            'heady_pipeline_enqueue', 'heady_pipeline_status',
            'heady_agent_spawn', 'heady_agent_list', 'heady_agent_terminate',
            'heady_tool_execute', 'heady_tool_list',
            'heady_file_upload', 'heady_file_search',
            'heady_notion_page_create', 'heady_notion_page_read', 'heady_notion_db_query',
            'heady_github_repo_read', 'heady_github_file_read',
            'heady_github_issue_create', 'heady_github_pr_create',
            'heady_perplexity_search',
            'heady_cloudflare_dns_list', 'heady_cloudflare_dns_create', 'heady_cloudflare_zone_purge',
            'heady_render_deploy', 'heady_render_service_list',
            'heady_stripe_customer_create', 'heady_stripe_subscription_list',
            'heady_system_pulse',
        ];
        assert.equal(MCP_TOOLS.length, 31, `Expected 31 tools, got ${MCP_TOOLS.length}`);
    });

    test('all MCP tool names follow heady_ prefix convention', () => {
        const MCP_TOOLS = [
            'heady_chat', 'heady_memory_store', 'heady_memory_search', 'heady_memory_delete',
            'heady_bee_invoke', 'heady_bee_list',
        ];
        for (const tool of MCP_TOOLS) {
            assert.ok(tool.startsWith('heady_'), `Tool "${tool}" must start with heady_`);
        }
    });

    test('MCP tool invocation returns content array', () => {
        // Simulate MCP tool response structure
        function mockMcpResponse(text) {
            return { content: [{ type: 'text', text }], isError: false };
        }

        const res = mockMcpResponse('Memory stored successfully');
        assert.ok(Array.isArray(res.content));
        assert.equal(res.content[0].type, 'text');
        assert.equal(res.isError, false);
    });

    test('MCP error response sets isError true', () => {
        function mockMcpError(msg) {
            return { content: [{ type: 'text', text: `Error: ${msg}` }], isError: true };
        }
        const err = mockMcpError('Tool not found');
        assert.equal(err.isError, true);
        assert.ok(err.content[0].text.includes('Error:'));
    });
});

// ── Bee Swarm Tests ────────────────────────────────────────────

describe('bee swarm', () => {
    test('24 bee domains are defined', () => {
        const BEE_DOMAINS = [
            'research', 'coding', 'writing', 'analysis', 'planning',
            'memory', 'retrieval', 'synthesis', 'critique', 'validation',
            'design', 'data', 'finance', 'legal', 'security',
            'devops', 'testing', 'documentation', 'api', 'database',
            'ux', 'marketing', 'support', 'orchestration',
        ];
        assert.equal(BEE_DOMAINS.length, 24, `Expected 24 domains, got ${BEE_DOMAINS.length}`);
    });

    test('bee domains are all lowercase strings', () => {
        const BEE_DOMAINS = ['research', 'coding', 'writing', 'analysis'];
        for (const d of BEE_DOMAINS) {
            assert.equal(d, d.toLowerCase(), `domain "${d}" must be lowercase`);
            assert.ok(d.length > 0);
        }
    });

    test('domain routing matches correct bee', () => {
        const DOMAIN_CAPABILITIES = {
            research: ['web_search', 'perplexity'],
            coding: ['code_gen', 'code_review'],
            security: ['vuln_scan', 'threat_model'],
        };

        assert.ok(DOMAIN_CAPABILITIES.research.includes('perplexity'));
        assert.ok(DOMAIN_CAPABILITIES.coding.includes('code_review'));
        assert.ok(!DOMAIN_CAPABILITIES.research.includes('code_gen'));
    });
});

// ── HeadyGateway SDK Tests ─────────────────────────────────────

describe('heady-hive-sdk/HeadyGateway', () => {
    const { HeadyGateway } = require('../heady-hive-sdk/lib/gateway');

    test('constructor requires baseUrl', () => {
        assert.throws(() => new HeadyGateway({}), /baseUrl is required/);
    });

    test('constructor initializes all domain proxies', () => {
        const gw = new HeadyGateway({ baseUrl: 'http://localhost:8080', apiKey: 'test' });

        const domains = [
            'auth', 'chat', 'agents', 'bees', 'memory', 'pipeline',
            'files', 'notion', 'github', 'stripe', 'cloudflare', 'render',
            'mcp', 'system',
        ];
        for (const d of domains) {
            assert.ok(gw[d] !== undefined, `domain "${d}" must be defined`);
            assert.ok(typeof gw[d] === 'object', `domain "${d}" must be an object`);
        }
    });

    test('setAccessToken updates the token', () => {
        const gw = new HeadyGateway({ baseUrl: 'http://localhost:8080', apiKey: 'test' });
        gw.setAccessToken('new-token-123');
        assert.equal(gw._accessToken, 'new-token-123');
    });

    test('baseUrl trailing slash is stripped', () => {
        const gw = new HeadyGateway({ baseUrl: 'http://localhost:8080/', apiKey: 'test' });
        assert.equal(gw._baseUrl, 'http://localhost:8080');
    });

    test('system domain has all 5 methods', () => {
        const gw = new HeadyGateway({ baseUrl: 'http://localhost:8080', apiKey: 'test' });
        const methods = ['health', 'ready', 'pulse', 'metrics', 'version'];
        for (const m of methods) {
            assert.ok(typeof gw.system[m] === 'function', `system.${m} must be a function`);
        }
    });

    test('memory domain has store, search, get, delete methods', () => {
        const gw = new HeadyGateway({ baseUrl: 'http://localhost:8080', apiKey: 'test' });
        assert.ok(typeof gw.memory.store === 'function');
        assert.ok(typeof gw.memory.search === 'function');
        assert.ok(typeof gw.memory.get === 'function');
        assert.ok(typeof gw.memory.delete === 'function');
    });
});
