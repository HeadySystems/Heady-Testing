/**
 * ∞ Heady Conductor — Thin Orchestrator Shell
 * Re-crystallized from the God class into focused micro-modules.
 *
 * This file orchestrates 10 boot phases:
 *   Phase 0: src/config/env-schema.js        — env validation
 *   Phase 1: src/bootstrap/config-globals.js — env, globals, event bus
 *   Phase 2: src/bootstrap/middleware-stack.js     — CORS, helmet, rate limiting
 *   Phase 3: src/bootstrap/auth-engine.js         — HeadyAuth + JWT + OAuth
 *   Phase 4: src/bootstrap/vector-stack.js        — vector memory, bees, buddy
 *   Phase 5: src/bootstrap/engine-wiring.js       — pipeline + engines
 *   Phase 6: src/bootstrap/pipeline-wiring.js     — self-healing
 *   Phase 7: src/bootstrap/service-registry.js    — 40+ services
 *   Phase 8: src/bootstrap/inline-routes.js       — health, pulse
 *   Phase 9: src/bootstrap/voice-relay.js         — WebSocket
 *   Phase 10: src/bootstrap/server-boot.js        — HTTP + listen
 *
 * © 2026 HeadySystems Inc. — Proprietary
 */
'use strict';

// Phase 0: Environment Validation
const { validateEnvironment } = require('./src/config/env-schema');
validateEnvironment({ strict: process.env.NODE_ENV === 'production' });

// Phase 1: Environment + Globals
const { app, logger, eventBus, remoteConfig, secretsManager, cfManager } = require('./src/bootstrap/config-globals');

// Phase 2: Middleware Stack
require('./src/bootstrap/middleware-stack')(app, { logger, remoteConfig });

// Phase 3: Auth Engine
const { authEngine } = require('./src/bootstrap/auth-engine')(app, { logger, secretsManager, cfManager });

// Phase 4: Vector Stack
const { vectorMemory, buddy, pipeline, selfAwareness, watchdog } = require('./src/bootstrap/vector-stack')(app, { logger, eventBus });

// Phase 5: Engine Wiring
const { wireEngines } = require('./src/bootstrap/engine-wiring');
const { loadRegistry } = require('./src/routes/registry');
const _engines = wireEngines(app, {
    pipeline,
    loadRegistry,
    eventBus,
    projectRoot: __dirname,
    PORT: process.env.PORT || process.env.HEADY_PORT || 8080,
});

// Phase 6: Pipeline + self-healing
require('./src/bootstrap/pipeline-wiring')(app, { pipeline, buddy, vectorMemory, selfAwareness, _engines, logger, eventBus });

// Phase 7: Service Registry (40+ services)
require('./src/bootstrap/service-registry')(app, {
    logger, authEngine, vectorMemory, buddy, pipeline, _engines,
    secretsManager, cfManager, eventBus,
    projectRoot: __dirname,
});

// Phase 8: Inline Routes
require('./src/bootstrap/inline-routes')(app, { logger, secretsManager, cfManager, authEngine, _engines });

// Phase 9: Voice Relay WebSocket
const { voiceSessions } = require('./src/bootstrap/voice-relay')(app, { logger });

// Phase 10: Server Boot
require('./src/bootstrap/server-boot')(app, { logger, voiceSessions });
