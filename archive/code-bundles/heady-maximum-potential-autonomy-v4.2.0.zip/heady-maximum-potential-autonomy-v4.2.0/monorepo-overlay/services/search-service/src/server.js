const http = require('http');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readJson, sendJson, requestUrl } = require('../../../shared/http-helpers');
const { addDocument, search } = require('./search-index');

const logger = createLogger('search-service');
const port = Number(process.env.PORT || 4314);

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'search-service' });
    }
    if (req.method === 'POST' && url.pathname === '/index') {
      const body = await readJson(req);
      return sendJson(res, 200, { ok: true, document: addDocument(body) });
    }
    if (req.method === 'POST' && url.pathname === '/search') {
      const body = await readJson(req);
      return sendJson(res, 200, { ok: true, results: search(body.query || '', Number(body.limit || 8)) });
    }
    return sendJson(res, 404, { error: 'HEADY-SEARCH-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-SEARCH-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server };
