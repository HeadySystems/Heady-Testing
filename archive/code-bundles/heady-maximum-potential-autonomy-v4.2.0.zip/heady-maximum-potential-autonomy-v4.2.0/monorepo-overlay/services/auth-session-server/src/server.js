const http = require('http');
const { createLogger } = require('../../../shared/structured-logger');
const { deriveContext } = require('../../../shared/heady-auto-context');
const { readJson, sendJson, getCookies, requestUrl } = require('../../../shared/http-helpers');
const { createSession, verifySession, checkQuota } = require('./session-store');
const { isAllowedOrigin, loadOrigins } = require('./relay-origins');
const errors = require('./error-codes');

const logger = createLogger('auth-session-server');
const port = Number(process.env.PORT || 4310);

function cookieHeader(token) {
  return `__Host-heady_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=4895`;
}

const server = http.createServer(async (req, res) => {
  const context = deriveContext(req);
  const url = requestUrl(req);
  try {
    if (req.method === 'GET' && url.pathname === '/health/live') {
      return sendJson(res, 200, { status: 'healthy', service: 'auth-session-server' });
    }
    if (req.method === 'GET' && url.pathname === '/health/ready') {
      return sendJson(res, 200, { status: 'ready', relayOrigins: loadOrigins().relayOrigins.length });
    }
    if (req.method === 'POST' && url.pathname === '/session/create') {
      const body = await readJson(req);
      const subject = body.subject || 'anonymous:guest';
      const anonymous = Boolean(body.anonymous);
      const origin = body.origin || context.origin;
      if (!origin || !isAllowedOrigin(origin)) {
        return sendJson(res, 403, { error: errors.INVALID_ORIGIN, message: 'Origin not allowlisted.' });
      }
      const quota = checkQuota(subject, anonymous);
      if (!quota.ok) {
        return sendJson(res, 429, { error: errors.QUOTA_EXCEEDED, message: 'Quota exceeded.', quota });
      }
      const { token, payload } = createSession({
        sub: subject,
        provider: body.provider || 'firebase',
        roles: body.roles || ['member'],
        anonymous,
        ip: context.ip,
        userAgent: context.userAgent,
        origin
      });
      logger.info('session_created', { correlationId: context.requestId, subject, origin });
      return sendJson(res, 200, { ok: true, session: payload }, { 'set-cookie': cookieHeader(token) });
    }
    if (req.method === 'POST' && url.pathname === '/session/verify') {
      const cookies = getCookies(req);
      const body = await readJson(req);
      const token = body.token || cookies['__Host-heady_session'] || req.headers.authorization?.replace('Bearer ', '');
      const verification = verifySession(token, context.ip, context.userAgent);
      if (!verification.ok) {
        return sendJson(res, 401, { error: errors.INVALID_SESSION, ...verification });
      }
      return sendJson(res, 200, { ok: true, session: verification.payload });
    }
    if (req.method === 'POST' && url.pathname === '/relay/bootstrap') {
      const body = await readJson(req);
      const sourceOrigin = body.origin || context.origin;
      const targetOrigin = body.targetOrigin || 'https://auth.headysystems.com';
      if (!isAllowedOrigin(sourceOrigin)) {
        return sendJson(res, 403, { error: errors.RELAY_DENIED, message: 'Relay source denied.' });
      }
      return sendJson(res, 200, {
        ok: true,
        relay: {
          sourceOrigin,
          targetOrigin,
          iframeAncestors: loadOrigins().iframeAncestors,
          cookieName: '__Host-heady_session'
        }
      });
    }
    if (req.method === 'POST' && url.pathname === '/quota/check') {
      const body = await readJson(req);
      return sendJson(res, 200, checkQuota(body.subject || 'anonymous:guest', Boolean(body.anonymous)));
    }
    return sendJson(res, 404, { error: 'HEADY-AUTH-404', message: 'Route not found.' });
  } catch (error) {
    logger.error('request_failed', { correlationId: context.requestId, message: error.message });
    return sendJson(res, 500, { error: 'HEADY-AUTH-500', message: error.message });
  }
});

if (require.main === module) {
  server.listen(port, () => logger.info('listening', { port }));
}

module.exports = { server };
