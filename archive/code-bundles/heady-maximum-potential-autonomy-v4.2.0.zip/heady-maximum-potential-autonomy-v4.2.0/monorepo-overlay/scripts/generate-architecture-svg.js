const fs = require('fs');
const path = require('path');

const svg = `
<svg xmlns="http://www.w3.org/2000/svg" width="1400" height="920" viewBox="0 0 1400 920" role="img" aria-label="Heady architecture graph">
  <rect width="1400" height="920" fill="#08131a"/>
  <text x="60" y="72" fill="#f3fbff" font-family="Inter, sans-serif" font-size="36" font-weight="700">Heady Maximum Potential Overlay</text>
  <text x="60" y="112" fill="#9ec5cf" font-family="Inter, sans-serif" font-size="18">Auth, notifications, analytics, billing, search, scheduler, migration, asset pipeline, and governance controls.</text>
  <g font-family="Inter, sans-serif">
    <rect x="60" y="170" width="260" height="132" rx="18" fill="#0f1e27" stroke="#244652"/>
    <text x="84" y="212" fill="#49dcb1" font-size="18">Auth Session Server</text>
    <text x="84" y="246" fill="#f3fbff" font-size="14">__Host- cookie issuance</text>
    <text x="84" y="270" fill="#f3fbff" font-size="14">relay origin validation</text>
    <text x="84" y="294" fill="#f3fbff" font-size="14">client binding hashes</text>

    <rect x="370" y="170" width="260" height="132" rx="18" fill="#0f1e27" stroke="#244652"/>
    <text x="394" y="212" fill="#49dcb1" font-size="18">Notification Service</text>
    <text x="394" y="246" fill="#f3fbff" font-size="14">SSE + WebSocket</text>
    <text x="394" y="270" fill="#f3fbff" font-size="14">per-frame auth recheck</text>
    <text x="394" y="294" fill="#f3fbff" font-size="14">push registry contract</text>

    <rect x="680" y="170" width="260" height="132" rx="18" fill="#0f1e27" stroke="#244652"/>
    <text x="704" y="212" fill="#49dcb1" font-size="18">Search Service</text>
    <text x="704" y="246" fill="#f3fbff" font-size="14">384-dim embeddings</text>
    <text x="704" y="270" fill="#f3fbff" font-size="14">lexical + vector fusion</text>
    <text x="704" y="294" fill="#f3fbff" font-size="14">schema-first indexing</text>

    <rect x="990" y="170" width="260" height="132" rx="18" fill="#0f1e27" stroke="#244652"/>
    <text x="1014" y="212" fill="#49dcb1" font-size="18">Analytics + Billing</text>
    <text x="1014" y="246" fill="#f3fbff" font-size="14">privacy-first events</text>
    <text x="1014" y="270" fill="#f3fbff" font-size="14">ledgered intents</text>
    <text x="1014" y="294" fill="#f3fbff" font-size="14">webhook verification</text>

    <rect x="200" y="420" width="260" height="132" rx="18" fill="#0f1e27" stroke="#244652"/>
    <text x="224" y="462" fill="#49dcb1" font-size="18">Scheduler + Migration</text>
    <text x="224" y="496" fill="#f3fbff" font-size="14">phi-scaled jobs</text>
    <text x="224" y="520" fill="#f3fbff" font-size="14">checksum migrations</text>
    <text x="224" y="544" fill="#f3fbff" font-size="14">rollback state</text>

    <rect x="520" y="420" width="260" height="132" rx="18" fill="#0f1e27" stroke="#244652"/>
    <text x="544" y="462" fill="#49dcb1" font-size="18">Asset Pipeline</text>
    <text x="544" y="496" fill="#f3fbff" font-size="14">digests and variants</text>
    <text x="544" y="520" fill="#f3fbff" font-size="14">immutable CDN keys</text>
    <text x="544" y="544" fill="#f3fbff" font-size="14">responsive manifests</text>

    <rect x="840" y="420" width="350" height="132" rx="18" fill="#0f1e27" stroke="#244652"/>
    <text x="864" y="462" fill="#49dcb1" font-size="18">Infra + Governance</text>
    <text x="864" y="496" fill="#f3fbff" font-size="14">NATS JetStream · OTEL · Prometheus · Vector · PgBouncer</text>
    <text x="864" y="520" fill="#f3fbff" font-size="14">feature flags · CSP · autonomy guardrails · ADRs</text>
    <text x="864" y="544" fill="#f3fbff" font-size="14">runbooks · onboarding · error catalog · C4 diagrams</text>
  </g>
  <g stroke="#49dcb1" stroke-width="3" fill="none">
    <path d="M320 236 C 340 236, 350 236, 370 236"/>
    <path d="M630 236 C 650 236, 660 236, 680 236"/>
    <path d="M940 236 C 960 236, 970 236, 990 236"/>
    <path d="M810 302 C 820 360, 890 380, 960 420"/>
    <path d="M500 302 C 480 360, 390 380, 330 420"/>
    <path d="M650 302 C 650 340, 650 372, 650 420"/>
  </g>
</svg>`;

fs.writeFileSync(path.join(__dirname, '..', 'ARCHITECTURE.svg'), svg.trimStart());
process.stdout.write(JSON.stringify({ ok: true, path: path.join(__dirname, '..', 'ARCHITECTURE.svg') }, null, 2));
