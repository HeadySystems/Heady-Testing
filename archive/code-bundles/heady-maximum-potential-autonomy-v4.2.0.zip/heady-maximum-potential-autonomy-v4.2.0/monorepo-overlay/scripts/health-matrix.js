const { spawn } = require('child_process');
const path = require('path');

const services = [
  ['auth-session-server', 4310],
  ['notification-service', 4311],
  ['analytics-service', 4312],
  ['billing-service', 4313],
  ['search-service', 4314],
  ['scheduler-service', 4315],
  ['migration-service', 4316],
  ['asset-pipeline', 4317]
];

async function wait(milliseconds) {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
}

async function main() {
  const children = services.map(([service, port]) => spawn(process.execPath, [path.join(__dirname, '..', 'services', service, 'src', 'server.js')], {
    env: { ...process.env, PORT: String(port) },
    stdio: ['ignore', 'pipe', 'pipe']
  }));
  try {
    await wait(900);
    const results = [];
    for (const [service, port] of services) {
      const response = await fetch(`http://127.0.0.1:${port}/health/live`);
      results.push({ service, port, status: response.status, body: await response.json() });
    }
    process.stdout.write(JSON.stringify({ ok: true, results }, null, 2));
  } finally {
    for (const child of children) child.kill('SIGTERM');
  }
}

main().catch(error => {
  process.stderr.write(`${error.stack}\n`);
  process.exitCode = 1;
});
