const { spawn } = require('child_process');
const path = require('path');

const services = [
  ['auth-session-server', 4310],
  ['notification-service', 4311],
  ['analytics-service', 4312],
  ['billing-service', 4313],
  ['search-service', 4314],
  ['scheduler-service', 4315],
  ['migration-service', 4316],
  ['asset-pipeline', 4317]
];

for (const [service, port] of services) {
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'services', service, 'src', 'server.js')], {
    env: { ...process.env, PORT: String(port) },
    stdio: 'inherit'
  });
  process.on('exit', () => child.kill('SIGTERM'));
}

setInterval(() => {}, 1000);
