# Heady Phi Scale Architecture - Implementation Files

This archive contains all the necessary files to replace fixed numeric constants
throughout the Heady codebase with continuously adjusting phi-bounded dynamic scales.

## Files Included

### Core Implementation
- src/core/phi-scales.js - Core Phi Scale Engine with PhiRange, PhiScale, PhiBackoff, PhiDecay, PhiPartitioner, PhiNormalizer
- src/core/dynamic-constants.js - Dynamic replacements for all magic numbers with self-adjusting PhiScale instances
- src/lib/phi-telemetry-feed.js - Real-time telemetry collector feeding system metrics into PhiScales
- src/middleware/phi-scale-middleware.js - Express middleware applying phi-scaled timeouts, rate limits, and concurrency

### Tools & Testing
- scripts/audit-fixed-values.js - Audit script that scans codebase for remaining hardcoded constants
- scripts/test-phi-scales.js - Comprehensive test suite with benchmarks proving phi-scales outperform fixed values

### Configuration & Documentation
- configs/phi-scales.yaml - Configuration mapping every dynamic parameter to its PhiScale bounds and telemetry
- docs/PHI_SCALE_ARCHITECTURE.md - Complete documentation with mathematical foundation, API reference, and migration guide

## Installation

1. Extract this archive to your Heady repository root
2. Install dependencies (if any new ones needed):
   ```bash
   npm install
   ```

3. Start telemetry monitoring and adjustment:
   ```javascript
   const telemetryFeed = require('./src/lib/phi-telemetry-feed');
   const { startAdjustment } = require('./src/core/dynamic-constants');

   telemetryFeed.start(1000);
   startAdjustment(() => telemetryFeed.getMetrics(), 5000);
   ```

4. Run audit to find remaining fixed values:
   ```bash
   node scripts/audit-fixed-values.js
   ```

5. Run test suite:
   ```bash
   node scripts/test-phi-scales.js
   ```

## Integration with CSL

All CSL gates in src/core/semantic-logic.js can now use dynamic thresholds:

```javascript
const { 
    DynamicResonanceThreshold,
    DynamicTernaryPositiveThreshold,
    DynamicTernaryNegativeThreshold 
} = require('./dynamic-constants');

// Use in resonance_gate
CSL.resonance_gate(vecA, vecB, DynamicResonanceThreshold.value);

// Use in ternary_gate
CSL.ternary_gate(
    score, 
    DynamicTernaryPositiveThreshold.value,
    DynamicTernaryNegativeThreshold.value
);
```

## Golden Ratio Constants

φ = 1.618033988749895 (phi)
1/φ = 0.618033988749895 (phi inverse - natural balance point)

These are available as exports:
```javascript
const { PHI, PHI_INVERSE } = require('./src/core/phi-scales');
```

## Key Features

✓ Phi-bounded ranges using golden ratio coordinates
✓ Continuous adjustment based on real-time telemetry
✓ Phi-exponential backoff (φ^n instead of 2^n)
✓ Golden spiral decay for cache TTLs and memory importance
✓ Fibonacci partitioning for optimal work chunking
✓ Full integration with existing CSL semantic gates
✓ Express middleware for automatic HTTP request scaling
✓ Comprehensive telemetry monitoring
✓ Audit tools to find remaining hardcoded values
✓ Test suite proving superiority over fixed values

## Next Steps

1. Review the documentation in docs/PHI_SCALE_ARCHITECTURE.md
2. Run the audit script to identify all hardcoded constants
3. Systematically replace fixed values with DynamicXxx constants
4. Add custom PhiScales for domain-specific parameters
5. Monitor metrics endpoint for adjustment behavior
6. Iterate sensitivity values in configs/phi-scales.yaml

## Support

For questions or issues, refer to the comprehensive documentation in
docs/PHI_SCALE_ARCHITECTURE.md or review the inline code comments.

---
Generated: 2026-03-07 12:10:12.895103
HeadySystems Inc. - Patent Pending
