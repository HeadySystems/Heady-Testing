from __future__ import annotations
import argparse
import os
import subprocess
import sys


def run(cmd: list[str]):
    print('>>', ' '.join(cmd))
    subprocess.run(cmd, check=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--role', required=True, choices=['alpha', 'beta', 'gamma'])
    parser.add_argument('--mode', default='minimal', choices=['minimal', 'optimal'])
    args = parser.parse_args()

    os.environ['PYTHONPATH'] = '/content/Heady:/content/Heady/heady-liquid-rebuild-bundle'
    os.environ['HEADY_CLUSTER_ROLE'] = args.role
    os.environ['HEADY_MODE'] = args.mode

    run([sys.executable, '-m', 'pip', 'install', '-r', 'requirements-minimal.txt'])

    if args.role == 'alpha':
        print('Start gateway and conductor on alpha')
    elif args.role == 'beta':
        print('Start memory service on beta')
    else:
        print('Start worker fabric on gamma')

    print({'role': args.role, 'mode': args.mode, 'status': 'bootstrapped'})


if __name__ == '__main__':
    main()
