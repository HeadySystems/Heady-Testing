from __future__ import annotations
from pathlib import Path
import hashlib
import json
import shutil

SOURCE_ROOT = Path('/home/user/workspace/repos')
OUT_ROOT = Path('/home/user/workspace/heady-liquid-rebuild-bundle/_integration_output')
MANIFEST = OUT_ROOT / 'merge-manifest.json'


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    OUT_ROOT.mkdir(parents=True, exist_ok=True)
    seen = {}
    manifest = []
    for repo in sorted(SOURCE_ROOT.glob('*')):
        if not repo.is_dir():
            continue
        for path in repo.rglob('*'):
            if not path.is_file():
                continue
            if '.git' in path.parts or 'node_modules' in path.parts:
                continue
            digest = sha256(path)
            rel = path.relative_to(repo)
            target = OUT_ROOT / repo.name / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            status = 'copied'
            if digest in seen:
                status = 'duplicate_of:' + seen[digest]
            else:
                shutil.copy2(path, target)
                seen[digest] = f'{repo.name}/{rel}'
            manifest.append({'repo': repo.name, 'path': str(rel), 'sha256': digest, 'status': status})
    MANIFEST.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    print(f'Wrote {MANIFEST}')


if __name__ == '__main__':
    main()
