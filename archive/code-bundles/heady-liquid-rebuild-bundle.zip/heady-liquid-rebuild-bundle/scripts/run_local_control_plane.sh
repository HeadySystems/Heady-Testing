#!/usr/bin/env bash
set -euo pipefail
python -m uvicorn services.gateway.app:app --host 0.0.0.0 --port 8010 &
python -m uvicorn services.conductor.app:app --host 0.0.0.0 --port 8011 &
python -m uvicorn services.memory_service.app:app --host 0.0.0.0 --port 8012 &
python -m uvicorn services.projection_service.app:app --host 0.0.0.0 --port 8013 &
python -m uvicorn services.worker_fabric.app:app --host 0.0.0.0 --port 8014 &
python -m uvicorn services.mesh_bus.app:app --host 0.0.0.0 --port 8015 &
wait
