import subprocess, sys
subprocess.run([sys.executable, '-m', 'uvicorn', 'services.worker_fabric.app:app', '--host', '0.0.0.0', '--port', '8014'])
