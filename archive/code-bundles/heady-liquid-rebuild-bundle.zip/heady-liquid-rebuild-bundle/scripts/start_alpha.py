import subprocess, sys
subprocess.run([sys.executable, '-m', 'uvicorn', 'services.gateway.app:app', '--host', '0.0.0.0', '--port', '8010'])
