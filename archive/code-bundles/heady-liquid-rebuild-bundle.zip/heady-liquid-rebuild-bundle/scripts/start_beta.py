import subprocess, sys
subprocess.run([sys.executable, '-m', 'uvicorn', 'services.memory_service.app:app', '--host', '0.0.0.0', '--port', '8012'])
