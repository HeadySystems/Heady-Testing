export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/health') {
      return new Response(JSON.stringify({ ok: true, edge: 'heady-liquid-worker' }), {
        headers: { 'content-type': 'application/json' }
      });
    }
    const upstream = env.GATEWAY_URL || 'https://example.com';
    return fetch(upstream + url.pathname + url.search, request);
  }
};
