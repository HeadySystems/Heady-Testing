# Target operating model

## Canonical shape

Heady should run as one canonical monorepo with these layers, matching the six-layer architecture already defined in the docs ([Heady architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md)):

1. Edge layer
2. Gateway layer
3. Orchestration layer
4. Intelligence layer
5. Memory layer
6. Persistence layer

## Runtime planes

The liquid runtime should remain organized by the three existing planes from the docs, but they should now be implemented as bounded code instead of broad concept language ([Heady architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md)):

- Projection plane -> thin repos, UI manifests, environment projections
- Builder plane -> code generation, projection emission, policy-driven mutation
- Orchestration plane -> conductor, worker fabric, node scheduling, health policy

## Canonical services

- `gateway` handles ingress, auth, rate policies, and domain dispatch.
- `conductor` decomposes tasks and chooses runtime lanes.
- `memory_service` owns vector memory and semantic recall.
- `projection_service` emits repo projections and deployable views.
- `worker_fabric` schedules jobs across Colab roles.
- `mesh_bus` is the minimal internal queue and event rail.

## Why Python-first

The latent blueprint recommends replacing sprawling manager logic with a compact Python VSA state machine and using Colab as the heavy execution substrate ([latent OS blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/strategic/latent-os-blueprint.md)). A Python-first control plane therefore removes cross-language sprawl at the core while leaving a tiny JS surface only where Cloudflare edge behavior is required.
