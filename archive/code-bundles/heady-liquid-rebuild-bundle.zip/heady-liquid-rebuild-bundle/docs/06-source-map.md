# Source map

## Repositories scanned

- `HeadySystems/Heady` ([GitHub](https://github.com/HeadySystems/Heady))
- `HeadyMe/Heady-pre-production-9f2f0642` ([GitHub](https://github.com/HeadyMe/Heady-pre-production-9f2f0642))
- `HeadyMe/headyme-core` ([GitHub](https://github.com/HeadyMe/headyme-core))
- `HeadyMe/headysystems-core` ([GitHub](https://github.com/HeadyMe/headysystems-core))
- `HeadyMe/headymcp-core` ([GitHub](https://github.com/HeadyMe/headymcp-core))
- `HeadyMe/headyos-core` ([GitHub](https://github.com/HeadyMe/headyos-core))
- `HeadyMe/headyapi-core` ([GitHub](https://github.com/HeadyMe/headyapi-core))
- `HeadyMe/headybuddy-core` ([GitHub](https://github.com/HeadyMe/headybuddy-core))
- `HeadyMe/headyconnection-core` ([GitHub](https://github.com/HeadyMe/headyconnection-core))
- `HeadyMe/headyio-core` ([GitHub](https://github.com/HeadyMe/headyio-core))
- `HeadyMe/heady-docs` ([GitHub](https://github.com/HeadyMe/heady-docs))

## Most influential files

- `README.md` and `package.json` in `HeadySystems/Heady` ([README](https://github.com/HeadySystems/Heady/blob/main/README.md), [package.json](https://github.com/HeadySystems/Heady/blob/main/package.json))
- `DEEP_SCAN_REPORT.md` and `IMMEDIATE_ACTION_PLAN.md` in `HeadySystems/Heady` ([DEEP_SCAN_REPORT](https://github.com/HeadySystems/Heady/blob/main/DEEP_SCAN_REPORT.md), [IMMEDIATE_ACTION_PLAN](https://github.com/HeadySystems/Heady/blob/main/IMMEDIATE_ACTION_PLAN.md))
- `heady-manager.js`, `src/bootstrap/service-registry.js`, `src/bootstrap/vector-stack.js`, and `heady-registry.json` in pre-production ([heady-manager.js](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/heady-manager.js), [service-registry.js](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/bootstrap/service-registry.js), [vector-stack.js](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/bootstrap/vector-stack.js), [heady-registry.json](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/heady-registry.json))
- The public architecture docs and rebuild blueprint docs ([architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md), [rebuild blueprint README](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/rebuild-blueprints/max-v2/README.md), [deployment blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/rebuild-blueprints/max-v2/03-deployment-blueprint.md))
