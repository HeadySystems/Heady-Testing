# Integration plan

## Goal

Absorb the current Heady repos into one canonical rebuild without preserving the existing architectural sprawl.

## Order of work

1. Freeze the current repos as reference inputs.
2. Use `scripts/merge_existing_repos.py` to inventory files and deduplicate by checksum.
3. Promote only canonical files into the new bounded folders.
4. Move deploy-specific outputs into projections rather than core source.
5. Stand up the memory service, conductor, and gateway first.
6. Map Colab alpha, beta, and gamma roles.
7. Emit thin public projections after the core plane is stable.

## Canonical mapping

| Existing pattern | New location |
|---|---|
| `heady-manager.js` shell | `services/conductor/` |
| vector and memory logic | `packages/heady_core/` + `services/memory_service/` |
| projection and public repo generation | `packages/heady_core/projection.py` + `services/projection_service/` |
| domain and routing policy | `configs/domains/` + `services/gateway/` |
| cloud deployment intent | `infra/` |
| notebooks and Colab entry | `colab/` and `scripts/` |

## What not to carry forward

- hardcoded secrets
- local-only paths
- duplicate parsers
- desktop packages inside server runtimes
- giant route registries with silent service failures
- backup files and version-drift artifacts

Those risks were all directly identified in the scanned repos ([HeadySystems deep scan report](https://github.com/HeadySystems/Heady/blob/main/DEEP_SCAN_REPORT.md), [HeadySystems immediate action plan](https://github.com/HeadySystems/Heady/blob/main/IMMEDIATE_ACTION_PLAN.md)).
