# Colab cluster plan

## Topology

The strongest fit for your stated target is a 3-subscription cluster using one primary role per subscription with secondary runtime lanes under each. This keeps the topology simple while still matching the docs that describe 3 to 4 concurrent runtimes per account ([Heady architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md)).

## Cluster roles

- Alpha subscription: conductor head, hot routing, memory coordination
- Beta subscription: embeddings, vector indexing, medium-depth reasoning
- Gamma subscription: heavy jobs, simulation, batch rebuilds, model-heavy work

## Runtime lanes per subscription

- lane 0: always-on service runtime
- lane 1: active compute runtime
- lane 2: burst runtime

## Minimal mode

Use HTTP mesh plus JSONL event store and local SQLite per notebook. This is enough to begin proving the architecture without Redis or pgvector.

## Optimal mode

Use Tailscale mesh, Redis hot state, and PostgreSQL with pgvector for durable memory, which is the same general direction already described in the latent OS blueprint and architecture docs ([latent OS blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/strategic/latent-os-blueprint.md), [Heady architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md)).

## Scheduling policy

- interactive -> Alpha first
- memory and embedding -> Beta first
- heavy simulation and rebuild -> Gamma first
- overflow -> least-loaded lane

## Why this works

This preserves the liquid architecture idea while making the runtime physically legible. Each subscription has a primary identity, but the lanes keep the system elastic.
