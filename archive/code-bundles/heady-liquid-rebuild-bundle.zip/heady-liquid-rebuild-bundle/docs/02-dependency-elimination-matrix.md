# Dependency elimination matrix

## Short answer

Total elimination is not realistic if Heady must remain distributed, cloud-native, edge-aware, and durably stateful. Large-scale elimination is realistic if you internalize orchestration and standardize the runtime surface.

## Eliminate now

| Category | Current problem | Replace with | Why |
|---|---|---|---|
| Multiple source repos | Thin repos drift from each other | One monorepo + generated projections | Public repos already behave like projections ([HeadyMe headyme-core README](https://github.com/HeadyMe/headyme-core/blob/main/README.md), [Heady rebuild blueprint README](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/rebuild-blueprints/max-v2/README.md)) |
| God-class orchestration | Large manager and service registration sprawl | Internal conductor + bounded services | The current repo already moved toward a thin shell pattern ([Heady pre-production heady-manager.js](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/heady-manager.js)) |
| Duplicate YAML tooling | `js-yaml` and `yamljs` | One parser only | Duplicate tooling was identified directly in the deep scan ([HeadySystems deep scan report](https://github.com/HeadySystems/Heady/blob/main/DEEP_SCAN_REPORT.md)) |
| Electron in server runtime | Heavy prod dependency | Isolated desktop package only | Deep scan flagged this as wrong placement ([HeadySystems deep scan report](https://github.com/HeadySystems/Heady/blob/main/DEEP_SCAN_REPORT.md)) |
| Local Windows path assumptions | Cloud-first config still names local paths | Pure env-driven paths | Existing pipeline config still contains `C:\Users\...` assumptions ([cloud-first pipeline](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/configs/infrastructure/cloud/cloud-first-pipeline.yaml)) |
| Mixed language boundaries | JS and Python mixed inside source tree | `packages/heady_core` plus service folders | Deep scan flagged mixed boundaries as a maintainability issue ([HeadySystems deep scan report](https://github.com/HeadySystems/Heady/blob/main/DEEP_SCAN_REPORT.md)) |
| Ad hoc service mounts | 40+ try/require route loads | Explicit service manifests | Service sprawl is visible in `service-registry.js` ([Heady pre-production service registry](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/src/bootstrap/service-registry.js)) |
| Package manager drift | Mixed lockfiles and tool expectations | Single Python baseline for core, optional JS edge worker | Versioning and lockfile drift were called out in the scans ([latent OS blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/strategic/latent-os-blueprint.md), [HeadySystems deep scan report](https://github.com/HeadySystems/Heady/blob/main/DEEP_SCAN_REPORT.md)) |

## Internalize where beneficial

| Function | Internal system in this bundle | External service becomes optional |
|---|---|---|
| Queueing | `services/mesh_bus` | Redis |
| Event sourcing | `packages/heady_core/event_store.py` | Kafka / cloud event bus |
| Vector memory | `packages/heady_core/vector_memory.py` | pgvector until durability is needed |
| Projection emission | `packages/heady_core/projection.py` | Separate deploy/projection generator |
| Routing policy | `packages/heady_core/liquid_router.py` | External workflow router |
| Colab bootstrap | `scripts/bootstrap_colab_node.py` | Notebook-by-notebook manual boot |

## Keep as intentional baseline

| Dependency | Keep? | Reason |
|---|---|---|
| Python 3.11+ | Yes | Best fit for Colab-first execution and the latent blueprint's VSA direction ([latent OS blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/strategic/latent-os-blueprint.md)) |
| Cloudflare edge worker | Yes, if edge ingress matters | The architecture and registry both keep Cloudflare as a first-class edge layer ([Heady architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md), [Heady pre-production registry](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/heady-registry.json)) |
| PostgreSQL + pgvector | Recommended for optimal mode | Durable semantic memory and persistence are core to the design ([Heady architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md), [deployment blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/rebuild-blueprints/max-v2/03-deployment-blueprint.md)) |
| Redis | Optional but recommended | Best for hot coordination across Colab nodes, though minimal mode can run without it ([latent OS blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/strategic/latent-os-blueprint.md)) |
| GitHub | Yes | Source-of-truth and projection sync target are part of the registry model ([Heady pre-production registry](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/heady-registry.json)) |
| Colab Pro+ | Yes for your stated target | The architecture docs and blueprint explicitly rely on the Colab fabric for heavy compute ([Heady architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md), [latent OS blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/strategic/latent-os-blueprint.md)) |

## Recommendation

Treat dependency elimination as a control-plane design problem, not a fantasy of zero software. Minimize to one primary runtime, one intentional data plane, one intentional edge plane, and one projection system.
