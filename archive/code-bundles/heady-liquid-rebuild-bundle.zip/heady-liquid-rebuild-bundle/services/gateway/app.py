from fastapi import FastAPI
from fastapi.responses import JSONResponse

app = FastAPI(title='Heady Gateway')


@app.get('/health')
def health():
    return {'ok': True, 'service': 'gateway'}


@app.get('/domains')
def domains():
    return JSONResponse({
        'headyme.com': 'personal',
        'headysystems.com': 'platform',
        'headyconnection.org': 'nonprofit',
        'headybuddy.org': 'companion',
    })
