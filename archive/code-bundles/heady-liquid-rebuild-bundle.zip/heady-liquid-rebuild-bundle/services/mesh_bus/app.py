from fastapi import FastAPI
from pydantic import BaseModel
from collections import defaultdict

app = FastAPI(title='Heady Mesh Bus')
queues = defaultdict(list)


class Message(BaseModel):
    topic: str
    payload: dict


@app.get('/health')
def health():
    return {'ok': True, 'service': 'mesh_bus'}


@app.post('/publish')
def publish(msg: Message):
    queues[msg.topic].append(msg.payload)
    return {'ok': True, 'queued': len(queues[msg.topic])}


@app.get('/drain/{topic}')
def drain(topic: str):
    items = list(queues[topic])
    queues[topic].clear()
    return {'topic': topic, 'items': items}
