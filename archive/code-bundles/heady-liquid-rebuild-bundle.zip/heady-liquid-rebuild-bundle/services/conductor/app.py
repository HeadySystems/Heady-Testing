from fastapi import FastAPI
from pydantic import BaseModel
from packages.heady_core.liquid_router import LiquidRouter

app = FastAPI(title='Heady Conductor')
router = LiquidRouter()


class RouteRequest(BaseModel):
    workload: str = 'interactive'
    priority: str = 'normal'
    payload: dict = {}


@app.get('/health')
def health():
    return {'ok': True, 'service': 'conductor'}


@app.post('/route')
def route(req: RouteRequest):
    decision = router.decide(req.model_dump())
    return {
        'lane': decision.lane,
        'reason': decision.reason,
        'workload_class': decision.workload_class,
    }
