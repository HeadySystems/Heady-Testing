from fastapi import FastAPI
from pydantic import BaseModel
from packages.heady_core.liquid_router import LiquidRouter

app = FastAPI(title='Heady Worker Fabric')
router = LiquidRouter()


class TaskRequest(BaseModel):
    task_id: str
    workload: str
    priority: str = 'normal'


@app.get('/health')
def health():
    return {'ok': True, 'service': 'worker_fabric'}


@app.post('/schedule')
def schedule(req: TaskRequest):
    decision = router.decide(req.model_dump())
    return {'task_id': req.task_id, 'assigned_lane': decision.lane, 'reason': decision.reason}
