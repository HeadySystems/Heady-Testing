from fastapi import FastAPI
from pydantic import BaseModel
from packages.heady_core.projection import emit_projection

app = FastAPI(title='Heady Projection Service')


class ProjectionRequest(BaseModel):
    name: str
    manifest: dict


@app.get('/health')
def health():
    return {'ok': True, 'service': 'projection_service'}


@app.post('/emit')
def emit(req: ProjectionRequest):
    path = emit_projection('/tmp/heady-projections', req.name, req.manifest)
    return {'ok': True, 'path': str(path)}
