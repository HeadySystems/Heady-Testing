from fastapi import FastAPI
from pydantic import BaseModel
from packages.heady_core.vector_memory import VectorMemory

app = FastAPI(title='Heady Memory Service')
memory = VectorMemory('/tmp/heady-memory/events.jsonl')


class AddMemoryRequest(BaseModel):
    id: str
    text: str
    meta: dict = {}


class QueryRequest(BaseModel):
    text: str
    top_k: int = 5


@app.get('/health')
def health():
    return {'ok': True, 'service': 'memory_service'}


@app.post('/memory/add')
def add_memory(req: AddMemoryRequest):
    return memory.add(req.id, req.text, req.meta)


@app.post('/memory/query')
def query_memory(req: QueryRequest):
    return {'matches': memory.query(req.text, req.top_k)}
