from scripts.bootstrap_colab_node import main
if __name__ == '__main__':
    import sys
    sys.argv = ['bootstrap_alpha.py', '--role', 'alpha', '--mode', 'optimal']
    main()
