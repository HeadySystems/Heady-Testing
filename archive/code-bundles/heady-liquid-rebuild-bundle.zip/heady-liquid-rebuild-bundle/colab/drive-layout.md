# Suggested Drive layout

- `/content/drive/MyDrive/Heady/monorepo/`
- `/content/drive/MyDrive/Heady/cache/`
- `/content/drive/MyDrive/Heady/projections/`
- `/content/drive/MyDrive/Heady/events/`

Mount the same Drive structure across alpha, beta, and gamma when you want shared lightweight persistence before moving fully to PostgreSQL and pgvector.
