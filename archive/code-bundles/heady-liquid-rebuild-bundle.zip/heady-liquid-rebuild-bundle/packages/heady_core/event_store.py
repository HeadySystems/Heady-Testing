from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime, timezone
from typing import Dict, Any, Iterable


class JsonlEventStore:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, event_type: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        record = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "event_type": event_type,
            "payload": payload,
        }
        with self.path.open('a', encoding='utf-8') as f:
            f.write(json.dumps(record) + "
")
        return record

    def read_all(self) -> Iterable[Dict[str, Any]]:
        if not self.path.exists():
            return []
        with self.path.open('r', encoding='utf-8') as f:
            return [json.loads(line) for line in f if line.strip()]
