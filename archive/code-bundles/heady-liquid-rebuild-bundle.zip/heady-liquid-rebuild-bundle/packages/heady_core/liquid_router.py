from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any


@dataclass
class RouteDecision:
    lane: str
    reason: str
    workload_class: str


class LiquidRouter:
    def decide(self, payload: Dict[str, Any]) -> RouteDecision:
        workload = payload.get('workload', 'interactive')
        priority = payload.get('priority', 'normal')
        if priority == 'founder' and workload in {'interactive', 'control'}:
            return RouteDecision('alpha', 'founder interactive lane', workload)
        if workload in {'embedding', 'memory', 'retrieval'}:
            return RouteDecision('beta', 'memory-optimized lane', workload)
        if workload in {'batch', 'simulation', 'rebuild', 'heavy'}:
            return RouteDecision('gamma', 'heavy compute lane', workload)
        return RouteDecision('alpha', 'default hot lane', workload)
