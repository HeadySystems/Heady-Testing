from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Any
from .vector_math import embed_text_384, project_to_3d, cosine_similarity
from .event_store import JsonlEventStore


@dataclass
class MemoryItem:
    id: str
    text: str
    vector: List[float]
    point3d: List[float]
    meta: Dict[str, Any]


class VectorMemory:
    def __init__(self, event_store_path: str = '/tmp/heady-memory/events.jsonl'):
        self.items: Dict[str, MemoryItem] = {}
        self.event_store = JsonlEventStore(event_store_path)

    def add(self, item_id: str, text: str, meta: Dict[str, Any] | None = None) -> Dict[str, Any]:
        meta = meta or {}
        vector = embed_text_384(text)
        point = list(project_to_3d(vector))
        item = MemoryItem(id=item_id, text=text, vector=vector, point3d=point, meta=meta)
        self.items[item_id] = item
        self.event_store.append('memory.added', {'id': item_id, 'text': text, 'meta': meta, 'point3d': point})
        return asdict(item)

    def query(self, text: str, top_k: int = 5) -> List[Dict[str, Any]]:
        qv = embed_text_384(text)
        scored = []
        for item in self.items.values():
            scored.append((cosine_similarity(qv, item.vector), item))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            {**asdict(item), 'score': score}
            for score, item in scored[:top_k]
        ]
