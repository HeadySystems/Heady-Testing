from __future__ import annotations
import hashlib
import math
from typing import Iterable, List, Tuple

DIMENSIONS = 384


def _hash_token(token: str) -> List[float]:
    digest = hashlib.sha256(token.encode('utf-8')).digest()
    values = []
    for i in range(DIMENSIONS):
        byte = digest[i % len(digest)]
        values.append((byte / 127.5) - 1.0)
    return values


def _normalize(vector: List[float]) -> List[float]:
    mag = math.sqrt(sum(v * v for v in vector)) or 1.0
    return [v / mag for v in vector]


def embed_text_384(text: str) -> List[float]:
    tokens = [t for t in text.lower().split() if t.strip()]
    if not tokens:
        return [0.0] * DIMENSIONS
    acc = [0.0] * DIMENSIONS
    for token in tokens:
        hv = _hash_token(token)
        for i, value in enumerate(hv):
            acc[i] += value
    return _normalize(acc)


def project_to_3d(vector: Iterable[float]) -> Tuple[float, float, float]:
    vector = list(vector)
    x = sum(vector[i] for i in range(0, len(vector), 3))
    y = sum(vector[i] for i in range(1, len(vector), 3))
    z = sum(vector[i] for i in range(2, len(vector), 3))
    mag = math.sqrt(x * x + y * y + z * z) or 1.0
    return (x / mag, y / mag, z / mag)


def cosine_similarity(a: Iterable[float], b: Iterable[float]) -> float:
    a = list(a)
    b = list(b)
    if not a or not b:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    amag = math.sqrt(sum(x * x for x in a)) or 1.0
    bmag = math.sqrt(sum(y * y for y in b)) or 1.0
    return dot / (amag * bmag)
