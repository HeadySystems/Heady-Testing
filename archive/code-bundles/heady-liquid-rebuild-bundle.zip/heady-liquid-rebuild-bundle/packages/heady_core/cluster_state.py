from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict


@dataclass
class NodeState:
    node_id: str
    role: str
    status: str
    load: float = 0.0


class ClusterState:
    def __init__(self):
        self.nodes: Dict[str, NodeState] = {}

    def upsert(self, node_id: str, role: str, status: str, load: float = 0.0):
        self.nodes[node_id] = NodeState(node_id=node_id, role=role, status=status, load=load)

    def snapshot(self):
        return [asdict(node) for node in self.nodes.values()]
