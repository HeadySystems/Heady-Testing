from __future__ import annotations
from pathlib import Path
import json
from typing import Dict, Any


def emit_projection(dist_dir: str | Path, name: str, manifest: Dict[str, Any]) -> Path:
    dist = Path(dist_dir)
    target = dist / name
    target.mkdir(parents=True, exist_ok=True)
    (target / 'projection-manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    (target / 'README.md').write_text(
        f'# {name}

This is a thin projection emitted from the canonical Heady rebuild source.
',
        encoding='utf-8'
    )
    return target
