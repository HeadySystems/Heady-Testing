# Heady Liquid Rebuild Bundle

This bundle is a from-scratch rebuild scaffold for Heady that turns the scanned repo sprawl into one canonical source monorepo, thin projections, a Python-first control plane, and a Colab-oriented liquid runtime model.

## What this bundle does

- Replaces multi-repo drift with one source monorepo and projection outputs.
- Internalizes key orchestration systems instead of depending on scattered ad hoc route mounts.
- Gives you a minimal mode and an optimal mode.
- Targets 3 Colab Pro+ subscriptions as the primary compute fabric.
- Keeps 3D vector memory and liquid routing as first-class runtime primitives.

## Core conclusion

You can eliminate a large amount of package sprawl, duplicate tooling, local-machine prerequisites, Windows-path assumptions, and brittle orchestration glue, but you cannot responsibly eliminate every runtime dependency if you still want distributed cloud execution, durable memory, edge routing, and projection-based delivery. The practical win is to collapse the dependency surface to a very small, intentional baseline.

## Modes

### Minimal mode

Use the internal mesh bus, local JSONL event store, SQLite fallback, and pure-Python vector layer. This avoids Redis and avoids making pgvector mandatory on day one.

### Optimal mode

Use PostgreSQL with pgvector for durable memory, Redis for hot coordination, Cloudflare Workers for edge ingress, and Colab nodes for heavy compute. This matches the strongest direction already described in the Heady docs and registry.

## Key scanned evidence

- The public Heady picture already points to one rich monorepo plus thin projected repos instead of many hand-maintained siblings ([HeadyMe heady-docs README](https://github.com/HeadyMe/heady-docs/blob/main/README.md), [HeadyMe profile](https://github.com/HeadyMe)).
- The strongest current implementation signal is a thin `heady-manager.js` shell delegating into focused bootstrap modules ([Heady pre-production heady-manager.js](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/heady-manager.js)).
- The registry already encodes Cloud Run, Cloudflare, 384-dimensional vectors, 3 projection dimensions, and the GitHub monorepo as source of truth ([Heady pre-production registry](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/heady-registry.json)).
- The architecture docs define the six-layer stack and the three runtime planes, which are more coherent than the current service sprawl ([Heady architecture patterns](https://github.com/HeadyMe/heady-docs/blob/main/sources/05-heady-architecture-and-patterns.md)).
- The latent OS blueprint explicitly recommends refactoring the monolithic manager into a distributed Colab-oriented vector system using Tailscale, Redis, and Ray, while also calling out security and dependency drift problems in the current repo ([latent OS blueprint](https://github.com/HeadyMe/Heady-pre-production-9f2f0642/blob/main/docs/strategic/latent-os-blueprint.md)).
- A separate deep scan of `HeadySystems/Heady` found critical hardcoded secrets, duplicate YAML tooling, Electron in production dependencies, mixed language boundaries, and CI gaps ([HeadySystems deep scan report](https://github.com/HeadySystems/Heady/blob/main/DEEP_SCAN_REPORT.md)).

## Bundle layout

- `docs/` deep scan findings, elimination matrix, operating model, and integration path.
- `packages/heady_core/` internal runtime primitives.
- `services/` thin network services for gateway, conductor, memory, projections, worker fabric, and mesh bus.
- `configs/` canonical registry, policies, memory, projection, and Colab topology.
- `infra/` Docker, Cloudflare, Cloud Run, and SQL scaffolding.
- `scripts/` repo merge, bootstrap, and Colab start helpers.
- `colab/` concrete node boot files for alpha, beta, and gamma roles.

## Fast path

1. Start with `docs/02-dependency-elimination-matrix.md`.
2. Adopt the canonical configs under `configs/`.
3. Stand up `services/memory_service`, `services/conductor`, and `services/gateway` first.
4. Use the `colab/` boot files to map three subscriptions into the cluster roles.
5. Use `scripts/merge_existing_repos.py` to absorb the current Heady repos into the new monorepo.
